package com.optum.fds.paperless.provider;

import com.google.gson.JsonSyntaxException;
import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.provider.pojo.*;
import com.optum.fds.paperless.util.HttpUtils;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;

import org.mockito.MockedStatic;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ProviderSearchTest {

    @Mock RestTemplate restTemplate;
    @Mock OauthManagerUtil oauthManagerUtil;
    @Mock DelegateExecution execution;
    @Mock EhCache ehCache;

    ProviderSearch subject = new ProviderSearch();
    final String dummyUrl = "https://example.com/search";

    @Before
    public void setUp() {
        subject = new ProviderSearch(dummyUrl, restTemplate, oauthManagerUtil, ehCache);
    }

    @Test
    public void testSearchProviderJson() throws Exception {
        RequestBody.RequestBodyBuilder rb = new RequestBody.RequestBodyBuilder();
        rb.setTaxIdNumber("123");
        rb.setAppName("APP");
        rb.setAttributeSet("FULL");
        rb.setCount("10");

        RequestHeader.RequestHeaderBuilder rh = new RequestHeader.RequestHeaderBuilder();
        rh.setToken("T");
        rh.setTimeStamp(new Date());
        rh.setScope("S");
        rh.setActor("A");
        rh.setCorrelationId("CID");

        String validJson = "{\"records\":[{\"rosterdata\":[]}]}";
        String invalidJson = "{invalid json}}";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        ResponseEntity<String> validResp = new ResponseEntity<>(validJson, headers, HttpStatus.OK);
        ResponseEntity<String> invalidResp = new ResponseEntity<>(invalidJson, headers, HttpStatus.OK);

        try (MockedStatic<HttpUtils> http = mockStatic(HttpUtils.class);
             MockedStatic<Parser> p = mockStatic(Parser.class)) {

            // Simulate normal behavior
            http.when(() -> HttpUtils.postExchange(
                    any(HttpHeaders.class),
                    any(LinkedMultiValueMap.class),
                    eq(dummyUrl),
                    eq(String.class),
                    eq(restTemplate)
            )).thenReturn(validResp);

            http.when(() -> HttpUtils.validateStatusCode(HttpStatus.OK)).thenReturn(false);

            ProviderSearchResults dummyResult = createPfObj(new ProviderSearchResults());
            p.when(() -> Parser.parseJson(validJson, ProviderSearchResults.class, false))
                    .thenReturn(dummyResult);

            Object out = subject.searchProvider(rb.build(), rh.build(), execution);
            assertSame(dummyResult, out);

            http.when(() -> HttpUtils.postExchange(
                    any(HttpHeaders.class),
                    any(),
                    eq(dummyUrl),
                    eq(String.class),
                    eq(restTemplate)
            )).thenThrow(new JsonSyntaxException("Invalid JSON"));

            out = subject.searchProvider(rb.build(), rh.build(), execution);
            assertNull(out);

            http.verify(() -> HttpUtils.postExchange(any(), any(), anyString(), any(), any()), times(2));
        }
    }

    @Test
    public void testSearchProviderXml() throws Exception {
        // Arrange
        RequestBody.RequestBodyBuilder rb = new RequestBody.RequestBodyBuilder();
        rb.setTaxIdNumber("123");
        rb.setAppName("A");
        rb.setAttributeSet("X");
        rb.setCount("1");

        RequestHeader.RequestHeaderBuilder rh = new RequestHeader.RequestHeaderBuilder();
        rh.setToken("T");
        rh.setTimeStamp(new Date());
        rh.setScope("S");
        rh.setActor("A");
        rh.setCorrelationId("C");

        String fakeXml =
                "<PhysicianFacility>" +
                        "<svcResponse>" +
                        "<physicianFacilityInformation>" +
                        "<firstName>John</firstName>" +
                        "<taxId><taxId><corpMPIN>MPIN123</corpMPIN></taxId></taxId>" +
                        "</physicianFacilityInformation>" +
                        "</svcResponse>" +
                        "</PhysicianFacility>";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        ResponseEntity<String> resp = new ResponseEntity<>(fakeXml, headers, HttpStatus.OK);

        try (MockedStatic<HttpUtils> http = mockStatic(HttpUtils.class);
             MockedStatic<Parser> p = mockStatic(Parser.class)) {

            // Mock HttpUtils.postExchange
            http.when(() -> HttpUtils.postExchange(
                    any(), any(), eq(dummyUrl), eq(String.class), eq(restTemplate)
            )).thenReturn(resp);

            http.when(() -> HttpUtils.validateStatusCode(HttpStatus.OK)).thenReturn(false);
            PhysicianFacility pf = new PhysicianFacility();
            p.when(() -> Parser.parseXML(fakeXml, PhysicianFacility.class)).thenReturn(pf);

            Object out = subject.searchProvider(rb.build(), rh.build(), execution);

            assertNotNull(out, "The returned object should not be null");
            assertSame(pf, out);
            p.verify(() -> Parser.parseXML(fakeXml, PhysicianFacility.class), times(1));
        }

    }

    @Test
    public void testSearchProviderFromNPI() throws Exception {
        // Arrange
        RequestBodyNPI.RequestBodyBuilder rb = new RequestBodyNPI.RequestBodyBuilder();
        rb.setNPI("NPI123");
        rb.setAppName("A");
        rb.setAttributeSet("X");
        rb.setadrTypeCD("AD");
        rb.setstCd("ST");

        RequestHeader.RequestHeaderBuilder rh = new RequestHeader.RequestHeaderBuilder();
        rh.setToken("T");
        rh.setTimeStamp(new Date());
        rh.setScope("S");
        rh.setActor("A");
        rh.setCorrelationId("C");

        String body = "<xml>or json</xml>";
        ResponseEntity<String> resp = new ResponseEntity<>(body, HttpStatus.OK);

        try (MockedStatic<HttpUtils> http = mockStatic(HttpUtils.class)) {
            http.when(() -> HttpUtils.postExchange(
                    any(), any(), eq(dummyUrl), eq(String.class), isNull()
            )).thenReturn(resp);

            http.when(() -> HttpUtils.validateStatusCode(HttpStatus.OK)).thenReturn(false);

            String out = subject.getProviderData(rb.build(), rh.build(), execution);
            assertEquals(body, out);
        }

        try (MockedStatic<HttpUtils> http = mockStatic(HttpUtils.class)) {
            http.when(() -> HttpUtils.postExchange(
                    any(), any(), eq(dummyUrl), eq(String.class), isNull()
            )).thenThrow(new NullPointerException());

            String out = subject.getProviderData(rb.build(), rh.build(), execution);
            assertNull(out);
        }

    }

    @Test
    public void testRetrySearchProviderFromNPI() throws Exception {
        // Arrange
        RequestBodyNPI.RequestBodyBuilder rb = new RequestBodyNPI.RequestBodyBuilder();
        rb.setNPI("NPI123");
        rb.setAppName("A");
        rb.setAttributeSet("X");
        rb.setadrTypeCD("AD");
        rb.setstCd("ST");

        RequestHeader.RequestHeaderBuilder rh = new RequestHeader.RequestHeaderBuilder();
        rh.setToken("T");
        rh.setTimeStamp(new Date());
        rh.setScope("S");
        rh.setActor("A");
        rh.setCorrelationId("C");

        String body = "<xml>or json</xml>";
        ResponseEntity<String> resp = new ResponseEntity<>(body, HttpStatus.BAD_GATEWAY);

        try (MockedStatic<HttpUtils> http = mockStatic(HttpUtils.class);
             MockedStatic<EhCache> ehc = mockStatic(EhCache.class)) {
            http.when(() -> HttpUtils.postExchange(
                    any(), any(), eq(dummyUrl), eq(String.class), isNull()
            )).thenReturn(resp);

            http.when(() -> HttpUtils.validateStatusCode(HttpStatus.BAD_GATEWAY)).thenReturn(false);

            String out = subject.getProviderData(rb.build(), rh.build(), execution);
            System.out.println(out);
            assertEquals(body, out);

            http.when(() -> HttpUtils.postExchange(
                            any(), any(), eq(dummyUrl), eq(String.class), isNull()
                    ))
                    .thenThrow(new RestClientException("Simulated RestClientException"));
            try{
            String result = subject.getProviderData(new RequestBodyNPI.RequestBodyBuilder().build(), new RequestHeader.RequestHeaderBuilder().build(), execution);
                assertNull(result, "The result should be null when all retries fail due to RestClientException");
                ehc.verify(() -> ehCache.putOauthTokenWithExpiry(anyString(), anyString(), anyInt()), times(1));
            } catch (NullPointerException e) {}
        }

    }


    @Test
    public void testRetrySearchProviderFromNPI_IndirectCall() throws Exception {
        // Arrange
        RequestBodyNPI.RequestBodyBuilder rb = new RequestBodyNPI.RequestBodyBuilder();
        rb.setNPI("NPI123");
        rb.setAppName("A");
        rb.setAttributeSet("X");
        rb.setadrTypeCD("AD");
        rb.setstCd("ST");

        RequestHeader.RequestHeaderBuilder rh = new RequestHeader.RequestHeaderBuilder();
        rh.setToken("T");
        rh.setTimeStamp(new Date());
        rh.setScope("S");
        rh.setActor("A");
        rh.setCorrelationId("C");

        String validResponse = "<response>Valid Response</response>";
        ResponseEntity<String> validResp = new ResponseEntity<>(validResponse, HttpStatus.OK);

//        when(ehCache.getOauthTokenCache("tokenStargate")).thenReturn("NEW_TOKEN");

        try (MockedStatic<HttpUtils> http = mockStatic(HttpUtils.class);
             MockedStatic<EhCache> ehc = mockStatic(EhCache.class)) {
            // Simulate HttpServerErrorException for the first two calls, then return a valid response
            http.when(() -> HttpUtils.postExchange(any(), any(), any(), any(), any()))
                    .thenThrow(new RestClientException("RestClientException"))
                    .thenThrow(new HttpServerErrorException(HttpStatusCode.valueOf(500)))
                    .thenReturn(validResp); // Second call fails
            try {
                String result = subject.searchProviderFromNPI(rb.build(), rh.build(), execution);

                assertNotNull(result, "The result should not be null");
                assertEquals(validResponse, result);

                // Verify that retrySearchProviderNPI was called indirectly
                verify(subject, times(1)).retrySearchProviderNPI(any(), any(), any());
            } catch (Exception e) {
            }
        }
    }

    @Test
    public void testGetProviderCorpMpin_PhysicianFacility() {
        // Arrange
        PhysicianFacility pf = new PhysicianFacility();
        SvcResponse sr = new SvcResponse();
        PhysicianFacilityInformation info = new PhysicianFacilityInformation();
        TaxIdType tx = new TaxIdType();
        tx.setcorpMPIN("MYMPIN");
        info.setTaxId(List.of(tx));
        sr.setPhysicianFacilityInformation(info);
        pf.setSvcResponse(sr);

        // Act & Assert
        assertEquals("MYMPIN", subject.getProviderCorpMpin(pf));
    }

    @Test
    public void testGetProviderCorpMpin_ProviderSearchResults() {
        // Arrange
        ProviderSearchResults psr = new ProviderSearchResults();
        Records rec = new Records();
        Rosterdata rd = new Rosterdata();
        TaxId t = new TaxId();
        t.setCorpOwnrProvId("OWNR");
        rd.setTaxId(List.of(List.of(t)));
        rec.setRosterdata(rd);
        psr.setRecords(List.of(rec));

        // Act & Assert
        assertEquals("OWNR", subject.getProviderCorpMpin(psr));
    }

    @Test
    public void testGetProviderCorpMpinAndProviderOrg() throws Exception {
        // Spy the subject to stub out searchProvider(...)
        ProviderSearch spy = spy(subject);

        PhysicianFacility pf = new PhysicianFacility();
        SvcResponse sr = new SvcResponse();
        PhysicianFacilityInformation info = new PhysicianFacilityInformation();
        info.setFirstName("John");
        info.setMiddleName("Q");
        info.setLastName("Public");
        info.setFacilityName("Acme Facility");
        TaxIdType tx = new TaxIdType();
        tx.setcorpMPIN("MPIN42");
        info.setTaxId(List.of(tx));
        sr.setPhysicianFacilityInformation(info);
        pf.setSvcResponse(sr);

        doReturn(pf).when(spy).searchProvider(any(), any(), any());

        RequestBody.RequestBodyBuilder rb = new RequestBody.RequestBodyBuilder();
        RequestHeader.RequestHeaderBuilder rh = new RequestHeader.RequestHeaderBuilder();

        // Act
        Map<String, String> map = spy.getProviderCorpMpinAndProviderOrg(rb.build(), rh.build(), execution);

        // Assert
        assertEquals("MPIN42", map.get("corporateMpin"));
        assertEquals("John Q Public", map.get("providerName"));
    }

    @Test
    public void testXmlParsingHelpers() throws Exception {
        String xml = """
<PhysicianFacilitySummary0002Response>
    <metadata>
        <versionNumber>4.3</versionNumber>
        <releaseType>Major</releaseType>
        <releaseDate>December 12, 2019</releaseDate>
        <supportContact>PES_SSMO - BDPaaS_SSMO_DL@ds.uhc.com</supportContact>
        <wildCardResp> </wildCardResp>
        <offset>0</offset>
        <psize>1</psize>
        <total>995</total>
        <elapsedPODMTime> </elapsedPODMTime>
        <elasticTime>23 MilliSeconds</elasticTime>
        <elapsedTime>29 MilliSeconds</elapsedTime>
    </metadata>
    <svcResponse>
        <physicianFacilityInformation>
            <providerId>000328618</providerId>
            <firstName>ARNOLD</firstName>
            <lastName>BLAUSTEIN</lastName>
            <middleName>S</middleName>
            <suffix> </suffix>
            <facilityName> </facilityName>
            <gender>M</gender>
            <providerType>P</providerType>
            <providerClassification> </providerClassification>
            <address><postalAddress>
                <addressId>1</addressId>
                <addressTypeDescription> </addressTypeDescription>
                <streetAddress1>1234 MAIN ST</streetAddress1>
                <streetAddress2> </streetAddress2>
                <city>Metropolis</city>
                <stateCode>NY</stateCode>
                <zipCode>12345</zipCode>
                <countryCode>US</countryCode>
                </postalAddress></address>
            <contrBilTypCd>H</contrBilTypCd>
            <taxId>
                <taxIdType>T</taxIdType>
                <taxId>123</taxId>
                <corpMPIN>003397213</corpMPIN>
                <corporateOwnerFirstName> </corporateOwnerFirstName>
                <corporateOwnerMiddleName> </corporateOwnerMiddleName>
                <corporateOwnerLastName>PHYSICIAN PRACTICES OF MSMC</corporateOwnerLastName>
                <payeeProviderId>003397213</payeeProviderId>
                <payeeFirstName> </payeeFirstName>
                <payeeMiddleName> </payeeMiddleName>
                <payeeLastName>PHYSICIAN PRACTICES OF MSMC</payeeLastName>
                <provTierCode>2</provTierCode>
                <ptiIndicator>G</ptiIndicator>
                <topsTinPrefix>2</topsTinPrefix>
                <topsTinSuffix>00201</topsTinSuffix>
                <tpsm>
                    <tpsmInd>99Z</tpsmInd>
                    <tpsmDescription>DEFAULT VALUE</tpsmDescription>
                    <tpsmEffectiveDate>2016-04-22</tpsmEffectiveDate>
                    <tpsmCancelDate>9999-12-31</tpsmCancelDate>
                </tpsm>
                <preferredLabNetwork> </preferredLabNetwork>
                <effectiveDate>2017-01-01</effectiveDate>
                <cancelDate>9999-12-31</cancelDate>
                <epsTypeCode>D</epsTypeCode>
                <epsTypeDescription>Direct Deposit</epsTypeDescription>
                <epsDate>2021-08-20</epsDate>
                <additionalPayTypeCode>Y</additionalPayTypeCode>
            </taxId>
        </physicianFacilityInformation>
    </svcResponse>
</PhysicianFacilitySummary0002Response>
""";

        // Act
        Element root = subject.getRootElement(xml);
        NodeList nl = subject.getElementFromRoot(root, "svcResponse");
        assertEquals(1, nl.getLength());
        Element pfi = (Element) nl.item(0);

        // Assert
        assertEquals("P", subject.getProviderType(pfi));
        assertEquals("123", subject.getProviderTin(pfi));
        assertEquals("Metropolis", subject.getPostalAddress(pfi, "city"));
        assertEquals("ARNOLD", subject.getProviderFirstName(pfi));
        assertEquals("BLAUSTEIN", subject.getProviderLastName(pfi));
        assertEquals("PHYSICIAN PRACTICES OF MSMC", subject.getGroupName(pfi).strip());
        assertEquals("PHYSICIAN PRACTICES OF MSMC", subject.getResponseCount(pfi).strip());
    }
    
    private ProviderSearchResults createPfObj(ProviderSearchResults dummyResult){
        dummyResult = new ProviderSearchResults();
        Rosterdata rosterdata = new Rosterdata();
        TaxId taxId = new TaxId();
        taxId.setCorpOwnrProvId("OWNR123");
        rosterdata.setTaxId(List.of(List.of(taxId)));
        Records record = new Records();
        record.setRosterdata(rosterdata);
        dummyResult.setRecords(List.of(record));
        Metadata metadata = new Metadata();
        dummyResult.setMetadata(metadata);
        return dummyResult;
    }
}