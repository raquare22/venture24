package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;

public class ContractInformationTypeTest {

    private static ObjectMapper mapper;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    @Test
    public void testGettersAndSetters() {
        ContractInformationType contract = new ContractInformationType();
        assertNull(contract.getContractId());
        assertNull(contract.getIncentiveDisincentiveId());
        assertNull(contract.getPreferredNetworkIndicator());
        assertNull(contract.getTierIndicator());
        assertNull(contract.getContractRoleCode());
        assertNull(contract.getDemoteIndicator());
        assertNull(contract.getAcoId());
        assertNull(contract.getAcoName());

        contract.setContractId("C123");
        contract.setIncentiveDisincentiveId("ID123");
        contract.setPreferredNetworkIndicator("PNI");
        contract.setTierIndicator("Tier1");
        contract.setContractRoleCode("RoleCode");
        contract.setDemoteIndicator("No");
        contract.setAcoId("ACO123");
        contract.setAcoName("ACOName");

        assertEquals("C123", contract.getContractId());
        assertEquals("ID123", contract.getIncentiveDisincentiveId());
        assertEquals("PNI", contract.getPreferredNetworkIndicator());
        assertEquals("Tier1", contract.getTierIndicator());
        assertEquals("RoleCode", contract.getContractRoleCode());
        assertEquals("No", contract.getDemoteIndicator());
        assertEquals("ACO123", contract.getAcoId());
        assertEquals("ACOName", contract.getAcoName());
    }

    @Test
    public void testJsonSerializationAndDeserialization() throws JsonProcessingException {
        ContractInformationType contract = new ContractInformationType();
        contract.setContractId("C123");
        contract.setAcoName("ACOName");

        String json = mapper.writeValueAsString(contract);
        assertTrue(json.contains("C123"));
        assertTrue(json.contains("ACOName"));

        ContractInformationType deserialized = mapper.readValue(json, ContractInformationType.class);
        assertEquals("C123", deserialized.getContractId());
        assertEquals("ACOName", deserialized.getAcoName());
    }
}