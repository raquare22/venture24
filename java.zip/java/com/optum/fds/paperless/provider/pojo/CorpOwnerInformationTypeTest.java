package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;

public class CorpOwnerInformationTypeTest {

    private static ObjectMapper mapper;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    @Test
    public void testGettersAndSetters() {
        CorpOwnerInformationType corpOwner = new CorpOwnerInformationType();
        assertNull(corpOwner.getProviderId());
        assertNull(corpOwner.getLastName());
        assertNull(corpOwner.getFirstName());
        assertNull(corpOwner.getMiddleName());
        assertNull(corpOwner.getSuffix());

        corpOwner.setProviderId("12345");
        corpOwner.setLastName("Smith");
        corpOwner.setFirstName("John");
        corpOwner.setMiddleName("A.");
        corpOwner.setSuffix("Jr.");

        assertEquals("12345", corpOwner.getProviderId());
        assertEquals("Smith", corpOwner.getLastName());
        assertEquals("John", corpOwner.getFirstName());
        assertEquals("A.", corpOwner.getMiddleName());
        assertEquals("Jr.", corpOwner.getSuffix());
    }

    @Test
    public void testJsonSerializationAndDeserialization() throws JsonProcessingException {
        CorpOwnerInformationType corpOwner = new CorpOwnerInformationType();
        corpOwner.setProviderId("12345");
        corpOwner.setLastName("Smith");
        corpOwner.setFirstName("John");

        String json = mapper.writeValueAsString(corpOwner);
        assertTrue(json.contains("12345"));
        assertTrue(json.contains("Smith"));
        assertTrue(json.contains("John"));

        CorpOwnerInformationType deserialized = mapper.readValue(json, CorpOwnerInformationType.class);
        assertEquals("12345", deserialized.getProviderId());
        assertEquals("Smith", deserialized.getLastName());
        assertEquals("John", deserialized.getFirstName());
    }

    @Test
    public void testJsonIgnoreUnknownProperties() throws JsonProcessingException {
        String jsonWithExtra = "{"
                + "\"providerId\":\"12345\","
                + "\"lastName\":\"Smith\","
                + "\"firstName\":\"John\","
                + "\"extraField\":\"ignoredValue\""
                + "}";

        CorpOwnerInformationType corpOwner = mapper.readValue(jsonWithExtra, CorpOwnerInformationType.class);
        assertEquals("12345", corpOwner.getProviderId());
        assertEquals("Smith", corpOwner.getLastName());
        assertEquals("John", corpOwner.getFirstName());
    }
}