package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;

public class EfficiencyTypeTest {

    private static ObjectMapper mapper;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    @Test
    public void testGettersAndSetters() {
        EfficiencyType efficiency = new EfficiencyType();
        efficiency.setName("EfficiencyName");
        efficiency.setValue("90");

        assertEquals("90", efficiency.getValue());
        assertEquals("EfficiencyName", efficiency.getName());
    }

    @Test
    public void testJsonSerializationAndDeserialization() throws JsonProcessingException {
        EfficiencyType efficiency = new EfficiencyType();
        efficiency.setValue("90");

        String json = mapper.writeValueAsString(efficiency);
        assertTrue(json.contains("90"));

        EfficiencyType deserialized = mapper.readValue(json, EfficiencyType.class);
        assertEquals("90", deserialized.getValue());
    }
}