package com.optum.fds.paperless.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class RecordsTest {
    @Test
    public void testIt() {
        Records records = new Records();

        records.setRosterdata(new Rosterdata());

        records.getRosterdata();
        assertNotNull(records);
    }
}
