package com.optum.fds.paperless.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class UnetContractTest {
    @Test
    public void testIt() {
        UnetContract unetContract = new UnetContract();

        unetContract.setAcptPtntCd(new String());
        unetContract.setProvContrRoleCd(new String());

        unetContract.getAcptPtntCd();
        unetContract.getProvContrRoleCd();
        assertNotNull(unetContract);
    }
}
