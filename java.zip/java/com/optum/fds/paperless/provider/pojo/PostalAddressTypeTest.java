package com.optum.fds.paperless.provider.pojo;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;


public class PostalAddressTypeTest {

    private PostalAddressType postalAddressType;

    @Before
    public void setUp() {
        postalAddressType = new PostalAddressType();
    }

    @Test
    public void testGetSetAddressLine1() {
        String addressLine1 = "123 Main St";
        postalAddressType.setAddressLine1(addressLine1);
        assertEquals(addressLine1, postalAddressType.getAddressLine1());
    }

    @Test
    public void testGetSetAddressLine2() {
        String addressLine2 = "Apt 4B";
        postalAddressType.setAddressLine2(addressLine2);
        assertEquals(addressLine2, postalAddressType.getAddressLine2());
    }

    @Test
    public void testGetSetCity() {
        String city = "Springfield";
        postalAddressType.setCity(city);
        assertEquals(city, postalAddressType.getCity());
    }

    @Test
    public void testGetSetCounty() {
        String county = "Greene";
        postalAddressType.setCounty(county);
        assertEquals(county, postalAddressType.getCounty());
    }

    @Test
    public void testGetSetState() {
        String state = "IL";
        postalAddressType.setState(state);
        assertEquals(state, postalAddressType.getState());
    }

    @Test
    public void testGetSetZip() {
        String zip = "62704";
        postalAddressType.setZip(zip);
        assertEquals(zip, postalAddressType.getZip());
    }

    @Test
    public void testGetSetZip4() {
        String zip4 = "1234";
        postalAddressType.setZip4(zip4);
        assertEquals(zip4, postalAddressType.getZip4());
    }

    @Test
    public void testNotNull() {
        assertNotNull(postalAddressType);
    }
}