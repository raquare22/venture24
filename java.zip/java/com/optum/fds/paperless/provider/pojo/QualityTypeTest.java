package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;

public class QualityTypeTest {

    private static ObjectMapper mapper;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    @Test
    public void testGettersAndSetters() {
        QualityType quality = new QualityType();
        assertNull(quality.getValue());

        quality.setValue("85");
        quality.setName("QualityName");

        assertEquals("85", quality.getValue());
        assertEquals("QualityName", quality.getName());
    }

    @Test
    public void testJsonSerializationAndDeserialization() throws JsonProcessingException {
        QualityType quality = new QualityType();
        quality.setValue("85");

        String json = mapper.writeValueAsString(quality);
        assertTrue(json.contains("85"));

        QualityType deserialized = mapper.readValue(json, QualityType.class);
        assertEquals("85", deserialized.getValue());
    }
}