package com.optum.fds.paperless.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class MetadataTest {

    @Test
    public void testIt() {
        Metadata metadata = new Metadata();

        metadata.setOffset(0);
        metadata.setPsize(0);
        metadata.setTotal(0);
        metadata.setElapsedtime(new String());
        metadata.setElastictime(new String());

        metadata.getOffset();
        metadata.getPsize();
        metadata.getElapsedtime();
        metadata.getElastictime();
        metadata.getTotal();
        assertNotNull(metadata);
    }
}
