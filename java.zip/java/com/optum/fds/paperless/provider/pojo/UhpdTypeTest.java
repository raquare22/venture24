package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;

public class UhpdTypeTest {

    private static ObjectMapper mapper;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    @Test
    public void testGettersAndSetters() {
        UhpdType uhpdType = new UhpdType();
        assertNull(uhpdType.getEfficiency());
        assertNull(uhpdType.getFocusCode());
        assertNull(uhpdType.getFocusDescription());
        assertNull(uhpdType.getQeDesignationTierNumber());
        assertNull(uhpdType.getQeDesignationPriority());
        assertNull(uhpdType.getQuality());
        assertNull(uhpdType.getUhpdDateRange());

        EfficiencyType efficiency = new EfficiencyType();
        QualityType quality = new QualityType();
        UhpdDateRangeType dateRange = new UhpdDateRangeType();

        uhpdType.setEfficiency(efficiency);
        uhpdType.setFocusCode("FocusCode123");
        uhpdType.setFocusDescription("FocusDescription123");
        uhpdType.setQeDesignationTierNumber("Tier1");
        uhpdType.setQeDesignationPriority("High");
        uhpdType.setQuality(quality);
        uhpdType.setUhpdDateRange(dateRange);

        assertEquals(efficiency, uhpdType.getEfficiency());
        assertEquals("FocusCode123", uhpdType.getFocusCode());
        assertEquals("FocusDescription123", uhpdType.getFocusDescription());
        assertEquals("Tier1", uhpdType.getQeDesignationTierNumber());
        assertEquals("High", uhpdType.getQeDesignationPriority());
        assertEquals(quality, uhpdType.getQuality());
        assertEquals(dateRange, uhpdType.getUhpdDateRange());
    }

    @Test
    public void testJsonSerializationAndDeserialization() throws JsonProcessingException {
        UhpdType uhpdType = new UhpdType();
        uhpdType.setFocusCode("FocusCode123");
        uhpdType.setFocusDescription("FocusDescription123");

        String json = mapper.writeValueAsString(uhpdType);
        assertTrue(json.contains("FocusCode123"));
        assertTrue(json.contains("FocusDescription123"));

        UhpdType deserialized = mapper.readValue(json, UhpdType.class);
        assertEquals("FocusCode123", deserialized.getFocusCode());
        assertEquals("FocusDescription123", deserialized.getFocusDescription());
    }

    @Test
    public void testJsonIgnoreUnknownProperties() throws JsonProcessingException {
        String jsonWithExtra = "{"
                + "\"focusCode\":\"FocusCode123\","
                + "\"focusDescription\":\"FocusDescription123\","
                + "\"extraField\":\"ignoredValue\""
                + "}";

        UhpdType uhpdType = mapper.readValue(jsonWithExtra, UhpdType.class);
        assertEquals("FocusCode123", uhpdType.getFocusCode());
        assertEquals("FocusDescription123", uhpdType.getFocusDescription());
    }
}