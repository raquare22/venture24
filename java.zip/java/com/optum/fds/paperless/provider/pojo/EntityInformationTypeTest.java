package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;

public class EntityInformationTypeTest {

    private static ObjectMapper mapper;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    @Test
    public void testGettersAndSetters() {
        EntityInformationType entity = new EntityInformationType();
        assertNull(entity.getEntityId());
        assertNull(entity.getEntityName());

        entity.setEntityId("E123");
        entity.setEntityName("EntityName");
        entity.setEntityType("EntityType");

        assertEquals("E123", entity.getEntityId());
        assertEquals("EntityName", entity.getEntityName());
        assertEquals("EntityType", entity.getEntityType());
    }

    @Test
    public void testJsonSerializationAndDeserialization() throws JsonProcessingException {
        EntityInformationType entity = new EntityInformationType();
        entity.setEntityId("E123");
        entity.setEntityName("EntityName");
        entity.setEntityType("EntityType");

        String json = mapper.writeValueAsString(entity);
        assertTrue(json.contains("E123"));
        assertTrue(json.contains("EntityName"));
        assertTrue(json.contains("EntityType"));

        EntityInformationType deserialized = mapper.readValue(json, EntityInformationType.class);
        assertEquals("E123", deserialized.getEntityId());
        assertEquals("EntityName", deserialized.getEntityName());
        assertEquals("EntityType", deserialized.getEntityType());
    }
}