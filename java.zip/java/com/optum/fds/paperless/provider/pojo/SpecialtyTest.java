package com.optum.fds.paperless.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class SpecialtyTest {
    @Test
    public void testIt() {
        Specialty specialty = new Specialty();

        specialty.setSpclTypCd(new String());
        specialty.setSpclPriCd(new String());
        specialty.setSpclEffDt(new java.util.Date());
        specialty.setSpclCancDt(new java.util.Date());
        specialty.setSpclTypShrtDesc(new String());
        specialty.setSpclTypFullDesc(new String());

        specialty.getSpclTypCd();
        specialty.getSpclPriCd();
        specialty.getSpclEffDt();
        specialty.getSpclCancDt();
        specialty.getSpclTypShrtDesc();
        specialty.getSpclTypFullDesc();
        assertNotNull(specialty);
    }

    @Test
    public void testItNull() {
        Specialty specialty = new Specialty();

        specialty.setSpclEffDt(null);
        specialty.setSpclCancDt(null);

        specialty.getSpclEffDt();
        specialty.getSpclCancDt();
        assertNotNull(specialty);
    }

}
