package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;

public class RequestTest {

    private static ObjectMapper mapper;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    @Test
    public void testGettersAndSetters() {
        Request request = new Request.RequestBuilder().build();
        assertNull(request.getRequestBody());
        assertNull(request.getRequestHeader());

        Request.RequestBuilder req = new Request.RequestBuilder();

        RequestHeader.RequestHeaderBuilder reqH = new RequestHeader.RequestHeaderBuilder();
        reqH.setActor("actor");
        reqH.setScope("scope");
        reqH.setToken("token");
        reqH.setCorrelationId("corrId");
        reqH.setTimeStamp(new java.util.Date());

        RequestBody.RequestBodyBuilder reqB = new RequestBody.RequestBodyBuilder();
        reqB.setTaxIdNumber("123456789");
        reqB.setAppName("appName");
        reqB.setAttributeSet("attributeSet");
        reqB.setCount("count");

        req.setRequestBody(reqB.build());
        req.setRequestHeader(reqH.build());

        request = req.build();
        System.out.println(reqH.toString());
        System.out.println(reqH.toString());

        assertEquals("actor", request.getRequestHeader().getActor());
        assertTrue(request.getRequestBody().toString().contains("123456789"));
    }

    @Test
    public void testJsonSerializationAndDeserialization() throws JsonProcessingException {
        Request request = new Request.RequestBuilder().build();

        String json = mapper.writeValueAsString(request);
        assertFalse(json.contains("123"));
        assertFalse(json.contains("TypeA"));

//        Request deserialized = mapper.readValue(json, Request.class);
//        assertEquals("123", deserialized.getRequestId());
//        assertEquals("TypeA", deserialized.getRequestType());
    }
}