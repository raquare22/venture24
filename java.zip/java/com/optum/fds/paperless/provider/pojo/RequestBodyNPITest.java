package com.optum.fds.paperless.provider.pojo;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;


public class RequestBodyNPITest {

    private RequestBodyNPI requestBodyNPI;

    @Before
    public void setUp() {
        requestBodyNPI = new RequestBodyNPI.RequestBodyBuilder()
                .setNPI("1234567890")
                .setAppName("TestApp")
                .setAttributeSet("TestAttributeSet")
                .setadrTypeCD("Home")
                .setstCd("CA")
                .build();
    }

    @Test
    public void testGetNPI() {
        assertEquals("1234567890", requestBodyNPI.getNPI());
    }

    @Test
    public void testGetAppName() {
        assertEquals("TestApp", requestBodyNPI.getAppName());
    }

    @Test
    public void testGetAttributeSet() {
        assertEquals("TestAttributeSet", requestBodyNPI.getAttributeSet());
    }

    @Test
    public void testGetadrTypeCD() {
        assertEquals("Home", requestBodyNPI.getadrTypeCD());
    }

    @Test
    public void testGetstCd() {
        assertEquals("CA", requestBodyNPI.getstCd());
    }

    @Test
    public void testToString() {
        String expectedString = "RequestBodyNPI [npi=1234567890, appName=TestApp, attributeSet=TestAttributeSet, adrTypeCD=Home, stCd=CA]";
        assertEquals(expectedString, requestBodyNPI.toString());
    }

    @Test
    public void testNotNull() {
        assertNotNull(requestBodyNPI);
    }
}