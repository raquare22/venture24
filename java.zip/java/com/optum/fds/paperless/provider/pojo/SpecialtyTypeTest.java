package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import org.junit.Before;
import org.junit.Test;

public class SpecialtyTypeTest {

    private static ObjectMapper mapper;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        // make sure NON_NULL inclusion is in effect (as per your @JsonInclude)
        // this is the default for that annotation, but we can be explicit:
        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    @Test
    public void testGettersAndSetters() {
        SpecialtyType st = new SpecialtyType();
        assertNull(st.getPrimarySpecialtyIndicator());
        assertNull(st.getSpecialtyTypeCode());
        assertNull(st.getSpecialtyFullDescription());

        st.setPrimarySpecialtyIndicator("Y");
        st.setSpecialtyTypeCode("CARD");
        st.setSpecialtyFullDescription("Cardiology");

        assertEquals("Y", st.getPrimarySpecialtyIndicator());
        assertEquals("CARD", st.getSpecialtyTypeCode());
        assertEquals("Cardiology", st.getSpecialtyFullDescription());
    }

    @Test
    public void testJsonSerializationAndDeserialization() throws JsonProcessingException {
        SpecialtyType st = new SpecialtyType();
        st.setPrimarySpecialtyIndicator("N");
        st.setSpecialtyTypeCode("DERM");
        // leave fullDescription null to test NON_NULL

        String json = mapper.writeValueAsString(st);
        // primarySpecialtyIndicator and specialtyTypeCode must appear; specialtyFullDescription must NOT
        assertTrue(json.contains("primarySpecialtyIndicator"));
        assertTrue(json.contains("specialtyTypeCode"));
        assertFalse(json.contains("specialtyFullDescription"));

        // now read it back
        SpecialtyType roundTrip = mapper.readValue(json, SpecialtyType.class);
        assertEquals("N", roundTrip.getPrimarySpecialtyIndicator());
        assertEquals("DERM", roundTrip.getSpecialtyTypeCode());
        assertNull(roundTrip.getSpecialtyFullDescription());
    }

    @Test
    public void testIgnoreUnknownProperties() throws JsonProcessingException {
        // create JSON with an extra field "fooBar" that does not exist on SpecialtyType
        String jsonWithExtra = "{"
                + "\"primarySpecialtyIndicator\":\"Y\","
                + "\"specialtyTypeCode\":\"ENT\","
                + "\"specialtyFullDescription\":\"Ear Nose Throat\","
                + "\"fooBar\":\"shouldBeIgnored\""
                + "}";

        // Because of @JsonIgnoreProperties(ignoreUnknown=true) this should succeed
        SpecialtyType st = mapper.readValue(jsonWithExtra, SpecialtyType.class);
        assertEquals("Y", st.getPrimarySpecialtyIndicator());
        assertEquals("ENT", st.getSpecialtyTypeCode());
        assertEquals("Ear Nose Throat", st.getSpecialtyFullDescription());
    }

    @Test
    public void testFailOnUnknownIfAnnotationRemoved() {
        // simulate a mapper that does NOT ignore unknown properties
        ObjectMapper strictMapper = new ObjectMapper()
                .configure(com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);

        String jsonWithExtra = "{"
                + "\"primarySpecialtyIndicator\":\"Y\","
                + "\"specialtyTypeCode\":\"ENT\","
                + "\"fooBar\":\"shouldFail\""
                + "\"specialtyFullDescription\":\"Ear Nose Throat\""
                + "}";

        // Even though the class has @JsonIgnoreProperties, a strict mapper will still fail
        assertThrows(JsonParseException.class,
                () -> strictMapper.readValue(jsonWithExtra, SpecialtyType.class));
    }
}