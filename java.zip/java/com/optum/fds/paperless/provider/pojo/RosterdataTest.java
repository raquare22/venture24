package com.optum.fds.paperless.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class RosterdataTest {

    @Test
    public void testIt() {
        Rosterdata rosterdata = new Rosterdata();

        rosterdata.setProvKey(new String());
        rosterdata.setProvId(new String());
        rosterdata.setTaxIdNbr(new String());
        rosterdata.setTaxIdTypCd(new String());
        rosterdata.setProvider(new java.util.ArrayList<>());
        rosterdata.setTaxId(new java.util.ArrayList<>());
        rosterdata.setSpecialty(new java.util.ArrayList<>());
        rosterdata.setOrganization(new java.util.ArrayList<>());
        rosterdata.setNpi(new java.util.ArrayList<>());
        rosterdata.setUnetContract(new java.util.ArrayList<>());
        rosterdata.setDegree(new java.util.ArrayList<>());
        rosterdata.setAddressData(new java.util.ArrayList<>());

        rosterdata.getProvKey();
        rosterdata.getProvId();
        rosterdata.getTaxIdNbr();
        rosterdata.getTaxIdTypCd();
        rosterdata.getProvider();
        rosterdata.getTaxId();
        rosterdata.getSpecialty();
        rosterdata.getOrganization();
        rosterdata.getNpi();
        rosterdata.getUnetContract();
        rosterdata.getDegree();
        rosterdata.getAddressData();

        assertNotNull(rosterdata);
    }
}
