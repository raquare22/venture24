package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
public class NpiTypeTest {

    private static ObjectMapper mapper;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    @Test
    public void testGettersAndSetters() {
        NpiType npiType = new NpiType();
        assertNull(npiType.getNpi());
        assertNull(npiType.getNpiLevelCode());

        npiType.setNpi("1234567890");
        npiType.setNpiLevelCode("Level1");

        assertEquals("1234567890", npiType.getNpi());
        assertEquals("Level1", npiType.getNpiLevelCode());
    }

    @Test
    public void testJsonSerializationAndDeserialization() throws JsonProcessingException {
        NpiType npiType = new NpiType();
        npiType.setNpi("1234567890");
        npiType.setNpiLevelCode("Level1");

        String json = mapper.writeValueAsString(npiType);
        assertTrue(json.contains("1234567890"));
        assertTrue(json.contains("Level1"));

        NpiType deserialized = mapper.readValue(json, NpiType.class);
        assertEquals("1234567890", deserialized.getNpi());
        assertEquals("Level1", deserialized.getNpiLevelCode());
    }

    @Test
    public void testJsonIgnoreUnknownProperties() throws JsonProcessingException {
        String jsonWithExtra = "{"
                + "\"npi\":\"1234567890\","
                + "\"npiLevelCode\":\"Level1\","
                + "\"extraField\":\"ignoredValue\""
                + "}";

        NpiType npiType = mapper.readValue(jsonWithExtra, NpiType.class);
        assertEquals("1234567890", npiType.getNpi());
        assertEquals("Level1", npiType.getNpiLevelCode());
    }
}