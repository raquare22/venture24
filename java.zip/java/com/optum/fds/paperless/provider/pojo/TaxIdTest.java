package com.optum.fds.paperless.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class TaxIdTest {

    @Test
    public void testIt() {
        TaxId taxId = new TaxId();

        taxId.setTaxIdNbr(new String());
        taxId.setTaxIdTypCd(new String());
        taxId.setTinEffDt(new java.util.Date());
        taxId.setTinCancDt(new java.util.Date());
        taxId.setTaxEffDt(new java.util.Date());
        taxId.setTaxCancDt(new java.util.Date());
        taxId.setCorpOwnrProvId(new String());
        taxId.setCorpOwnerLstNm(new String());
        taxId.setCorpOwnerFstNm(new String());
        taxId.setCorpOwnerMdlNm(new String());
        taxId.setCorpOwnerNmSufxCd(new String());
        taxId.setPayTypCd(new String());
        taxId.setPayeeProvId(new String());
        taxId.setPayeeProvLstNm(new String());
        taxId.setPayeeProvFstNm(new String());
        taxId.setPayeeProvMdlNm(new String());
        taxId.setPayeeProvNmSufxCd(new String());

        taxId.getTaxIdNbr();
        taxId.getTaxIdTypCd();
        taxId.getTinEffDt();
        taxId.getTinCancDt();
        taxId.getTaxEffDt();
        taxId.getTaxCancDt();
        taxId.getCorpOwnrProvId();
        taxId.getCorpOwnerLstNm();
        taxId.getCorpOwnerFstNm();
        taxId.getCorpOwnerMdlNm();
        taxId.getCorpOwnerNmSufxCd();
        taxId.getPayTypCd();
        taxId.getPayeeProvId();
        taxId.getPayeeProvLstNm();
        taxId.getPayeeProvFstNm();
        taxId.getPayeeProvMdlNm();
        taxId.getPayeeProvNmSufxCd();
        assertNotNull(taxId);
    }

    @Test
    public void testItNull() {
        TaxId taxId = new TaxId();

        taxId.setTinEffDt(null);
        taxId.setTinCancDt(null);
        taxId.setTaxEffDt(null);
        taxId.setTaxCancDt(null);

        taxId.getTinEffDt();
        taxId.getTinCancDt();
        taxId.getTaxEffDt();
        taxId.getTaxCancDt();
        assertNotNull(taxId);
    }
}
