package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;

public class RequestNPITest {

    @Test
    public void testRequestNPIBuilder() {
        RequestBodyNPI mockRequestBodyNPI = new RequestBodyNPI.RequestBodyBuilder().build();
        RequestHeader mockRequestHeader = new RequestHeader.RequestHeaderBuilder().build();   

        RequestNPI requestNPI = new RequestNPI.RequestBuilder()
                .setRequestBodyNPI(mockRequestBodyNPI)
                .setRequestHeader(mockRequestHeader)
                .build();

        assertNotNull(requestNPI);
        assertEquals(mockRequestBodyNPI, requestNPI.getRequestBodyNPI());
        assertEquals(mockRequestHeader, requestNPI.getRequestHeader());
    }

    @Test
    public void testToString() {
        RequestBodyNPI mockRequestBodyNPI = new RequestBodyNPI.RequestBodyBuilder().build();
        RequestHeader mockRequestHeader = new RequestHeader.RequestHeaderBuilder().build();   

        RequestNPI requestNPI = new RequestNPI.RequestBuilder()
                .setRequestBodyNPI(mockRequestBodyNPI)
                .setRequestHeader(mockRequestHeader)
                .build();

        String result = requestNPI.toString();

        assertNotNull(result);
        assertTrue(result.contains("RequestBodyNPI="));
        assertTrue(result.contains("requestHeader="));
    }
}