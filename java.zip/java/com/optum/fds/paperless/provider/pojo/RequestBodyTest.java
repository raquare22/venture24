package com.optum.fds.paperless.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class RequestBodyTest {
    @Test
    public void testIt() {
        RequestBody requestBody = new RequestBody.RequestBodyBuilder()
                .setCount("")
                .setTaxIdNumber("")
                .setAppName("")
                .setAttributeSet("")
                .build();

        requestBody.getCount();
        requestBody.getTaxIdNumber();
        requestBody.getAppName();
        requestBody.getAttributeSet();
        assertNotNull(requestBody);
    }
}
