package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;

public class UhpdDateRangeTypeTest {

    private static ObjectMapper mapper;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    @Test
    public void testGettersAndSetters() {
        UhpdDateRangeType dateRange = new UhpdDateRangeType();
        assertNull(dateRange.getEnd());
        assertNull(dateRange.getStart());

        dateRange.setEnd("2023-12-31");
        dateRange.setStart("2023-01-01");

        assertEquals("2023-12-31", dateRange.getEnd());
        assertEquals("2023-01-01", dateRange.getStart());
    }

    @Test
    public void testJsonSerializationAndDeserialization() throws JsonProcessingException {
        UhpdDateRangeType dateRange = new UhpdDateRangeType();
        dateRange.setEnd("2023-12-31");
        dateRange.setStart("2023-01-01");

        String json = mapper.writeValueAsString(dateRange);
        assertTrue(json.contains("2023-12-31"));
        assertTrue(json.contains("2023-01-01"));

        UhpdDateRangeType deserialized = mapper.readValue(json, UhpdDateRangeType.class);
        assertEquals("2023-12-31", deserialized.getEnd());
        assertEquals("2023-01-01", deserialized.getStart());
    }

    @Test
    public void testJsonIgnoreUnknownProperties() throws JsonProcessingException {
        String jsonWithExtra = "{"
                + "\"end\":\"2023-12-31\","
                + "\"start\":\"2023-01-01\","
                + "\"extraField\":\"ignoredValue\""
                + "}";

        UhpdDateRangeType dateRange = mapper.readValue(jsonWithExtra, UhpdDateRangeType.class);
        assertEquals("2023-12-31", dateRange.getEnd());
        assertEquals("2023-01-01", dateRange.getStart());
    }
}