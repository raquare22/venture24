package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class PhysicianFacilityInformationTest {

    private static ObjectMapper mapper;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    @Test
    public void testGettersAndSetters() {
        PhysicianFacilityInformation info = new PhysicianFacilityInformation();
        assertNull(info.getFirstName());
        assertNull(info.getLastName());
        assertNull(info.getFacilityName());
        assertSame(0, info.getNpi().size());

        info.setFirstName("John");
        info.setLastName("Doe");
        info.setFacilityName("Health Facility");
        info.setGender("M");
        info.setNhpInd("NI");
        info.setNhpFlexInd("NFI");
        info.setUnetTciParStatus("UNET");
        info.setDivPanelParStatus("DIV");
        info.setLobParStatus("LOB");
        info.setSuffix("Sr.");
        info.setOrganizationalType("ORG");
        info.setOrganizationalTypeDescription("Organization Description");

        ContractInformationType contractInfo = new ContractInformationType();
        info.setContractInformation(contractInfo);

        CorpOwnerInformationType corpOwnerInfo = new CorpOwnerInformationType();
        corpOwnerInfo.setFirstName("Jane");
        corpOwnerInfo.setLastName("Smith");
        corpOwnerInfo.setMiddleName("A.");
        corpOwnerInfo.setSuffix("Jr.");
        corpOwnerInfo.setProviderId("12345");
        List<CorpOwnerInformationType> corpOwnerList = new ArrayList<>();
        corpOwnerList.add(corpOwnerInfo);
        info.setCorpOwnerInformation(corpOwnerList);

        List<NpiType> npiList = new ArrayList<>();
        NpiType npi = new NpiType();
        npi.setNpi("1234567890");
        npiList.add(npi);

        assertEquals("John", info.getFirstName());
        assertEquals("Doe", info.getLastName());
        assertEquals("Health Facility", info.getFacilityName());
        assertEquals("M", info.getGender());
        assertEquals("NI", info.getNhpInd());
        assertEquals("NFI", info.getNhpFlexInd());
        assertEquals("UNET", info.getUnetTciParStatus());
        assertEquals("DIV", info.getDivPanelParStatus());
        assertEquals("LOB", info.getLobParStatus());
        assertEquals("Sr.", info.getSuffix());
        assertEquals("ORG", info.getOrganizationalType());
        assertEquals("Organization Description", info.getOrganizationalTypeDescription());
        assertEquals(contractInfo, info.getContractInformation());
        assertEquals(corpOwnerList, info.getCorpOwnerInformation());
    }

    @Test
    public void testJsonSerializationAndDeserialization() throws JsonProcessingException {
        PhysicianFacilityInformation info = new PhysicianFacilityInformation();
        info.setFirstName("John");
        info.setLastName("Doe");

        String json = mapper.writeValueAsString(info);
        assertTrue(json.contains("John"));
        assertTrue(json.contains("Doe"));

        PhysicianFacilityInformation deserialized = mapper.readValue(json, PhysicianFacilityInformation.class);
        assertEquals("John", deserialized.getFirstName());
        assertEquals("Doe", deserialized.getLastName());
    }

    @Test
    public void testJsonIgnoreUnknownProperties() throws JsonProcessingException {
        String jsonWithExtra = "{"
                + "\"firstName\":\"John\","
                + "\"lastName\":\"Doe\","
                + "\"extraField\":\"ignoredValue\""
                + "}";

        PhysicianFacilityInformation info = mapper.readValue(jsonWithExtra, PhysicianFacilityInformation.class);
        assertEquals("John", info.getFirstName());
        assertEquals("Doe", info.getLastName());
    }
}