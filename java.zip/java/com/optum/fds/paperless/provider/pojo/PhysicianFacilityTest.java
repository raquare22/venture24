package com.optum.fds.paperless.provider.pojo;

import org.junit.Test;

public class PhysicianFacilityTest {

    PhysicianFacilityInformation physicianFacilityInformation = new PhysicianFacilityInformation();

    @Test
    public void testPojoV2GettersSetters() {
        physicianFacilityInformation.getNpi();
        physicianFacilityInformation.getSpecialty();
        physicianFacilityInformation.getCorpOwnerInformation();
        physicianFacilityInformation.getEntityInformation();
        physicianFacilityInformation.getUhpd();

        GetterSetterVerifier.forClass(QualityType.class).verify();
        GetterSetterVerifier.forClass(PhysicianFacility.class).verify();
        GetterSetterVerifier.forClass(ContractInformationType.class).verify();
        GetterSetterVerifier.forClass(CorpOwnerInformationType.class).verify();
        GetterSetterVerifier.forClass(EfficiencyType.class).verify();
        GetterSetterVerifier.forClass(EntityInformationType.class).verify();
        GetterSetterVerifier.forClass(NpiType.class).verify();
//        GetterSetterVerifier.forClass(PhysicianFacilityInformation.class).exclude("corpOwnerInformation").verify();
        GetterSetterVerifier.forClass(SpecialtyType.class).verify();
        GetterSetterVerifier.forClass(SvcResponse.class).verify();
        GetterSetterVerifier.forClass(TaxIdType.class).verify();
        GetterSetterVerifier.forClass(UhpdDateRangeType.class).verify();
        GetterSetterVerifier.forClass(UhpdType.class).verify();
    }

}
