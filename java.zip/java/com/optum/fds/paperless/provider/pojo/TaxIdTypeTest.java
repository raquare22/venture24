package com.optum.fds.paperless.provider.pojo;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;

public class TaxIdTypeTest {

    private static ObjectMapper mapper;

    @Before
    public void setUp() {
        mapper = new ObjectMapper();
        mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL);
    }

    @Test
    public void testGettersAndSetters() {
        TaxIdType taxId = new TaxIdType();
        assertNull(taxId.getTaxId());
        assertNull(taxId.getTaxIdType());
        assertNull(taxId.getTpsmInd());
        assertNull(taxId.getTpsmDesc());
        assertNull(taxId.getcorpMPIN());

        taxId.setTaxId("T123");
        taxId.setTaxIdType("TIN");
        taxId.setTpsmInd("Y");
        taxId.setTpsmDesc("Description");
        taxId.setcorpMPIN("MPIN123");

        assertEquals("T123", taxId.getTaxId());
        assertEquals("TIN", taxId.getTaxIdType());
        assertEquals("Y", taxId.getTpsmInd());
        assertEquals("Description", taxId.getTpsmDesc());
        assertEquals("MPIN123", taxId.getcorpMPIN());
    }

    @Test
    public void testJsonSerializationAndDeserialization() throws JsonProcessingException {
        TaxIdType taxId = new TaxIdType();
        taxId.setTaxId("T123");
        taxId.setTaxIdType("TIN");

        String json = mapper.writeValueAsString(taxId);
        assertTrue(json.contains("T123"));
        assertTrue(json.contains("TIN"));

        TaxIdType deserialized = mapper.readValue(json, TaxIdType.class);
        assertEquals("T123", deserialized.getTaxId());
        assertEquals("TIN", deserialized.getTaxIdType());
    }
}