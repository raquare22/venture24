package com.optum.fds.paperless.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class RequestHeaderTest {

    @Test
    public void testIt() {
        RequestHeader requestHeader = new RequestHeader.RequestHeaderBuilder()
                .setScope("")
                .setActor("")
                .setToken("")
                .setTimeStamp(new java.util.Date())
                .setCorrelationId("")
                .build();


        requestHeader.getScope();
        requestHeader.getActor();
        requestHeader.getToken();
        requestHeader.getTimeStamp();
        requestHeader.getCorrelationId();
        assertNotNull(requestHeader);
    }

    @Test
    public void testItNull() {
        RequestHeader requestHeader = new RequestHeader.RequestHeaderBuilder().build();

        requestHeader.getTimeStamp();
        assertNotNull(requestHeader);
    }
}
