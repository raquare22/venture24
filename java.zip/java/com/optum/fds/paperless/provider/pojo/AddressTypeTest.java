package com.optum.fds.paperless.provider.pojo;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class AddressTypeTest {

    private AddressType addressType;

    @Before
    public void setUp() {
        addressType = new AddressType();
    }

    @Test
    public void testGetSetAddressId() {
        String addressId = "123";
        addressType.setAddressId(addressId);
        assertEquals(addressId, addressType.getAddressId());
    }

    @Test
    public void testGetSetAddressTypeDescription() {
        String addressTypeDescription = "Home";
        addressType.setAddressTypeDescription(addressTypeDescription);
        assertEquals(addressTypeDescription, addressType.getAddressTypeDescription());
    }

    @Test
    public void testGetSetPostalAddress() {
        PostalAddressType postalAddress = new PostalAddressType();
        addressType.setPostalAddress(postalAddress);
        assertEquals(postalAddress, addressType.getPostalAddress());
    }

    @Test
    public void testNotNull() {
        assertNotNull(addressType);
    }
}