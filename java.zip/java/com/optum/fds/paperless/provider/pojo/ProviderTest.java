package com.optum.fds.paperless.provider.pojo;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class ProviderTest {

    @Test
    public void testIt() {
        Provider provider = new Provider();

        provider.setProvEffDt(new java.util.Date());
        provider.setProvCancDt(new java.util.Date());
        provider.setLstNm(new String());
        provider.setFstNm(new String());
        provider.setMdlNm(new String());
        provider.setNmSufxCd(new String());
        provider.setProvBthDt(new java.util.Date());
        provider.setProvGdrCd(new String());
        provider.setProvTypCd(new String());
        provider.setOrgTypCd(new String());

        provider.getProvEffDt();
        provider.getProvCancDt();
        provider.getLstNm();
        provider.getFstNm();
        provider.getMdlNm();
        provider.getNmSufxCd();
        provider.getProvBthDt();
        provider.getProvGdrCd();
        provider.getProvTypCd();
        provider.getOrgTypCd();
        assertNotNull(provider);
    }

    public void testItNulls() {
        Provider provider = new Provider();

        provider.setProvEffDt(null);
        provider.setProvCancDt(null);
        provider.setProvBthDt(null);

        provider.getProvEffDt();
        provider.getProvCancDt();

    }

}
