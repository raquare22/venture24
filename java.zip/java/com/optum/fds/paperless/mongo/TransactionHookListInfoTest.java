package com.optum.fds.paperless.mongo;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;

public class TransactionHookListInfoTest {

    @Test
    public void testAddAndGet() {
        TransactionHookListInfo listInfo = new TransactionHookListInfo();
        TransactionHookInfo hookInfo1 = new TransactionHookInfo();
        TransactionHookInfo hookInfo2 = new TransactionHookInfo();

        listInfo.add(hookInfo1);
        listInfo.add(hookInfo2);

        assertEquals(2, listInfo.size());
        assertEquals(hookInfo1, listInfo.get(0));
        assertEquals(hookInfo2, listInfo.get(1));
    }

    @Test
    public void testIsEmpty() {
        TransactionHookListInfo listInfo = new TransactionHookListInfo();
        assertTrue(listInfo.isEmpty());

        TransactionHookInfo hookInfo = new TransactionHookInfo();
        listInfo.add(hookInfo);
        assertFalse(listInfo.isEmpty());
    }

    @Test
    public void testClear() {
        TransactionHookListInfo listInfo = new TransactionHookListInfo();
        TransactionHookInfo hookInfo = new TransactionHookInfo();
        listInfo.add(hookInfo);

        listInfo.clear();
        assertTrue(listInfo.isEmpty());
    }
}