package com.optum.fds.paperless.mongo;

import org.junit.Assert;
import org.junit.Test;

import java.util.Date;

public class TransactionAttachmentInfoTest {

    TransactionAttachmentInfo object = new TransactionAttachmentInfo();

    @Test
    public void testGettersSetters(){

        object.setStatus(new String());
        Assert.assertEquals(new String(),object.getStatus());

        object.setSpaceId(109);
        Assert.assertEquals(109,object.getSpaceId());

        object.setFileName(new String());
        Assert.assertEquals(new String(),object.getFileName());

        object.setFileSize(10L);
        Assert.assertEquals(10L,object.getFileSize());

        object.setId(new String());
        Assert.assertEquals(new String(),object.getId());

        object.setExternalId(new String());
        Assert.assertEquals(new String(),object.getExternalId());

        object.setDateCreated(new Date());
        Assert.assertEquals(new Date(),object.getDateCreated());

        object.setContentType(new String());
        Assert.assertEquals(new String(),object.getContentType());

        object.setSourceSystemName(new String());
        Assert.assertEquals(new String(),object.getSourceSystemName());
        
        Date currentDate = new Date();
        
        object.setSourceSystemDateCreated(currentDate);
        Assert.assertEquals(currentDate,object.getSourceSystemDateCreated());
        
        object.setDateModified(currentDate);
        Assert.assertEquals(currentDate,object.getDateModified());
    }

}
