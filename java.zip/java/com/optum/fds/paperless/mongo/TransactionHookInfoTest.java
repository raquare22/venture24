package com.optum.fds.paperless.mongo;

import org.bson.Document;
import org.junit.Assert;
import org.junit.Test;

import java.util.Date;

public class TransactionHookInfoTest {
    TransactionHookInfo transactionHookInfo = new TransactionHookInfo();

    @Test
    public void testGettersSetters(){
        transactionHookInfo.setHookId(new String());
        Assert.assertEquals(new String(),transactionHookInfo.getHookId());

        transactionHookInfo.setStatus(new String());
        Assert.assertEquals(new String(),transactionHookInfo.getStatus());

        transactionHookInfo.setVersion(new String());
        Assert.assertEquals(new String(),transactionHookInfo.getVersion());


        Date date = new Date();
        transactionHookInfo.setExpires(date);
        Assert.assertEquals(date, transactionHookInfo.getExpires());

        transactionHookInfo.setExternalId(new String());
        Assert.assertEquals(new String(),transactionHookInfo.getExternalId());

        transactionHookInfo.setParentId(new String());
        Assert.assertEquals(new String(),transactionHookInfo.getParentId());

        Integer value = 1099;
        transactionHookInfo.setSpaceId(value);
        Assert.assertEquals(value,transactionHookInfo.getSpaceId());

        org.bson.Document hook = new Document();
        transactionHookInfo.setMetadata(hook);
        Assert.assertEquals(hook,transactionHookInfo.getHook());


    }

}
