package com.optum.fds.paperless.mongo;

import org.junit.Test;

public class HookEventTypeTest {


    @Test
    public void testIt() {
        com.optum.fds.paperless.mongo.HookEventType hookEventType = new com.optum.fds.paperless.mongo.HookEventType();
        hookEventType.equals(new java.lang.Object());
        hookEventType.toString();
        hookEventType.hashCode();

        hookEventType.setTarget(new java.lang.String());
        hookEventType.setId(new java.lang.String());
        hookEventType.setEvalTime(HookEventType.EvalTime.POST_PROCESS);
        hookEventType.setDocumentMetaData(new com.optum.fds.paperless.mongo.DocumentMetaData());
        hookEventType.setSpaceId(0);
        hookEventType.setTransactionId(new java.lang.String());
        hookEventType.setDateCreated(new java.util.Date());
        hookEventType.setDateModified(new java.util.Date());
        hookEventType.setStatus(HookEventType.Status.IN_PROCESS);
        hookEventType.setMethod(new java.lang.String());

        hookEventType.getMethod();
        hookEventType.getId();
        hookEventType.getTarget();
        hookEventType.getEvalTime();
        hookEventType.getDocumentMetaData();
        hookEventType.getSpaceId();
        hookEventType.getTransactionId();
        hookEventType.getDateCreated();
        hookEventType.getDateModified();
        hookEventType.getStatus();

    }

    @Test
    public void testItNull() {
        com.optum.fds.paperless.mongo.HookEventType hookEventType = new com.optum.fds.paperless.mongo.HookEventType();

        hookEventType.setDocumentMetaData(new com.optum.fds.paperless.mongo.DocumentMetaData());
        hookEventType.setDateCreated(null);
        hookEventType.setDateModified(null);

        hookEventType.getDocumentMetaData();
        hookEventType.getDateCreated();
        hookEventType.getDateModified();

    }

    @Test
    public void testItConstructorFields() {
        com.optum.fds.paperless.mongo.HookEventType hookEventTypeOne = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", "document");

        com.optum.fds.paperless.mongo.HookEventType hookEventTypeTwo = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", "document");

        hookEventTypeOne.equals(hookEventTypeTwo);
    }

    @Test
    public void testItConstructorFieldsTwo() {
        com.optum.fds.paperless.mongo.HookEventType hookEventTypeOne = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", "document");

        com.optum.fds.paperless.mongo.HookEventType hookEventTypeTwo = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", "document");
        hookEventTypeTwo.equals(hookEventTypeOne);
    }

    @Test
    public void testItConstructorFieldsThree() {
        com.optum.fds.paperless.mongo.HookEventType hookEventTypeOne = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", "document");

        com.optum.fds.paperless.mongo.HookEventType hookEventTypeTwo = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "GET", "document");
        hookEventTypeTwo.equals(hookEventTypeOne);
    }

    @Test
    public void testItConstructorFieldsFour() {
        com.optum.fds.paperless.mongo.HookEventType hookEventTypeOne = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", "document");

        com.optum.fds.paperless.mongo.HookEventType hookEventTypeTwo = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 321, "POST", "document");
        hookEventTypeTwo.equals(hookEventTypeOne);
    }

    @Test
    public void testItConstructorFieldsNull() {
        com.optum.fds.paperless.mongo.HookEventType hookEventTypeOne = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", "document");

        com.optum.fds.paperless.mongo.HookEventType hookEventTypeTwo = new com.optum.fds.paperless.mongo.HookEventType(null, 0, null, null);

        hookEventTypeOne.equals(hookEventTypeOne);
        hookEventTypeOne.equals(hookEventTypeTwo);
        hookEventTypeOne.hashCode();
        hookEventTypeOne.equals(null);
    }

    @Test
    public void testItConstructorFieldsMethodOne() {
        com.optum.fds.paperless.mongo.HookEventType hookEventTypeOne = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", "document");

        com.optum.fds.paperless.mongo.HookEventType hookEventTypeTwo = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "GET", "document");
        hookEventTypeOne.equals(hookEventTypeTwo);

    }

    @Test
    public void testItConstructorFieldsMethodOneNull() {
        com.optum.fds.paperless.mongo.HookEventType hookEventTypeOne = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, null, "document");

        com.optum.fds.paperless.mongo.HookEventType hookEventTypeTwo = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "GET", "document");
        hookEventTypeOne.equals(hookEventTypeTwo);
    }

    @Test
    public void testItConstructorFieldsMethodThreeNull() {
        com.optum.fds.paperless.mongo.HookEventType hookEventTypeOne = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, null, "document");

        com.optum.fds.paperless.mongo.HookEventType hookEventTypeTwo = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, null, "document");
        hookEventTypeOne.equals(hookEventTypeTwo);
    }

    @Test
    public void testItConstructorFieldsMethodTwoNull() {
        com.optum.fds.paperless.mongo.HookEventType hookEventTypeOne = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", "document");

        com.optum.fds.paperless.mongo.HookEventType hookEventTypeTwo = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, null, "document");
        hookEventTypeOne.equals(hookEventTypeTwo);

    }

    @Test
    public void testItConstructorFieldsTargetNull() {
        com.optum.fds.paperless.mongo.HookEventType hookEventTypeOne = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", "document");

        com.optum.fds.paperless.mongo.HookEventType hookEventTypeTwo = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", null);
        hookEventTypeOne.equals(hookEventTypeTwo);

    }

    @Test
    public void testItConstructorFieldsTargetTwoNull() {
        com.optum.fds.paperless.mongo.HookEventType hookEventTypeOne = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", null);

        com.optum.fds.paperless.mongo.HookEventType hookEventTypeTwo = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", "document");
        hookEventTypeOne.equals(hookEventTypeTwo);

    }

    @Test
    public void testItConstructorFieldsTargetThreeNull() {
        com.optum.fds.paperless.mongo.HookEventType hookEventTypeOne = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", null);

        com.optum.fds.paperless.mongo.HookEventType hookEventTypeTwo = new com.optum.fds.paperless.mongo.HookEventType(HookEventType.EvalTime.POST_PROCESS, 1234, "POST", null);
        hookEventTypeOne.equals(hookEventTypeTwo);

    }

}
