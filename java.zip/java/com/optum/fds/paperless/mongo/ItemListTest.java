package com.optum.fds.paperless.mongo;

import org.junit.Test;
import static org.junit.Assert.*;

public class ItemListTest {

    @Test
    public void testGettersAndSetters() {
        ItemList itemList = new ItemList();

        itemList.setPassThroughData("data");
        assertEquals("data", itemList.getPassThroughData());

        itemList.setFilecreationDate("2023-10-01T12:00:00.000Z");
        assertEquals("2023-10-01T12:00:00.000Z", itemList.getFilecreationDate());

        itemList.setFiledateEmailSent("2023-10-02");
        assertEquals("2023-10-02", itemList.getFiledateEmailSent());

        itemList.setDispatchedDate("2023-10-03");
        assertEquals("2023-10-03", itemList.getDispatchedDate());

        itemList.setRecipientId("recipient123");
        assertEquals("recipient123", itemList.getRecipientId());

        itemList.setFiledeliveryMethod("email");
        assertEquals("email", itemList.getFiledeliveryMethod());

        itemList.setSuccesscount(10);
        assertEquals(Integer.valueOf(10), itemList.getSuccesscount());

        itemList.setDeliveryTypeValue("type1");
        assertEquals("type1", itemList.getDeliveryTypeValue());

        itemList.setReceivedDate("2023-10-04");
        assertEquals("2023-10-04", itemList.getReceivedDate());

        itemList.setDeliveryMethod1("method1");
        assertEquals("method1", itemList.getDeliveryMethod1());
    }
}