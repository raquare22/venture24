package com.optum.fds.paperless.mongo;

import org.junit.Test;

public class ProcessKeyToErrorCodeTest {

    @Test
    public void test(){
        ProcessKeyToErrorCode.getErrorCodeFromProcessKey(new String());
    }
}
