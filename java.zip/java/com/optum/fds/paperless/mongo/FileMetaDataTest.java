package com.optum.fds.paperless.mongo;

import org.junit.Test;

import java.util.Date;

public class FileMetaDataTest {
    @Test
    public void testFileMetaData() {
        FileMetaData fileMetaData=new FileMetaData();
        fileMetaData.setDateCreated(new Date());
        fileMetaData.getDateCreated();
        fileMetaData.setDateModified(new Date());
        fileMetaData.getDateModified();
        fileMetaData.setDateCreated(null);
        fileMetaData.getDateCreated();
        fileMetaData.setDateModified(null);
        fileMetaData.getDateModified();
        fileMetaData.setAttachmentId("attachmentId");
        fileMetaData.getAttachmentId();
        fileMetaData.setSourceSystemDateCreated(new Date());
        fileMetaData.getSourceSystemDateCreated();
        fileMetaData.setSourceSystemDateCreated(null);
        fileMetaData.getSourceSystemDateCreated();
        fileMetaData.setExternalId("externalId");
        fileMetaData.getExternalId();
        fileMetaData.setFilename("fileName");
        fileMetaData.getFilename();
        fileMetaData.setFileSize(4L);
        fileMetaData.getFileSize();
        fileMetaData.setSourceSystemName("Name");
        fileMetaData.getSourceSystemName();

    }

}
