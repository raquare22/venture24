package com.optum.fds.paperless.mongo;

import org.junit.Assert;
import org.junit.Test;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class DocvaultTransactionTest {
    DocvaultTransaction docvaultTransaction = new DocvaultTransaction();

    @Test
    public void testGetSetId(){
        docvaultTransaction.setId(new String());
        Assert.assertEquals(new String(),docvaultTransaction.getId());
    }

    @Test
    public void testGetSetSpaceId(){
        int value = 1087;
        docvaultTransaction.setSpaceId(value);
        Assert.assertEquals(value,docvaultTransaction.getSpaceId());
    }

    @Test
    public void testGetSetFsId(){
        docvaultTransaction.setFsId(new String());
        Assert.assertEquals(new String(),docvaultTransaction.getFsId());
    }

    @Test
    public void testGetSetDocumentId(){
        docvaultTransaction.setDocumentId(new String());
        Assert.assertEquals(new String(),docvaultTransaction.getDocumentId());
    }

    @Test
    public void testGetSetFileName(){
        docvaultTransaction.setFileName(new String());
        Assert.assertEquals(new String(),docvaultTransaction.getFileName());
    }

    @Test
    public void testGetSetPodName(){
        docvaultTransaction.setPodName(new String());
        Assert.assertEquals(new String(),docvaultTransaction.getPodName());
    }

    @Test
    public void testGetSetDateSent(){
        Date dateSent = new Date();
        docvaultTransaction.setDateSent(dateSent);
        Assert.assertEquals(dateSent,docvaultTransaction.getDateSent());
    }

    @Test
    public void testGetSetResponseCode(){
        int value = 10;
        docvaultTransaction.setResponseCode(value);
        Assert.assertEquals(value,docvaultTransaction.getResponseCode());
    }

    @Test
    public void testGetSetResponseMsg(){
        docvaultTransaction.setResponseMsg(new String());
        Assert.assertEquals(new String(),docvaultTransaction.getResponseMsg());
    }

    @Test
    public void testGetSetErrorMap(){
        Map<String, Object> map = new HashMap<>();
        docvaultTransaction.setErrorMap(map);
        Assert.assertEquals(map,docvaultTransaction.getErrorMap());
    }

}
