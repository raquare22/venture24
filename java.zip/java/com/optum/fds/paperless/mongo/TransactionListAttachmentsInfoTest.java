package com.optum.fds.paperless.mongo;

import org.junit.Test;

import java.util.ArrayList;

public class TransactionListAttachmentsInfoTest {

    @Test
    public void testTransactionListAttachmentsInfo() {
        TransactionListAttachmentsInfo transactionListAttachmentsInfo=new TransactionListAttachmentsInfo();
        transactionListAttachmentsInfo.setAttachments(null);
        transactionListAttachmentsInfo.setCount(3);
        transactionListAttachmentsInfo.setStart(2);
        transactionListAttachmentsInfo.setTotalRecords(2L);
        transactionListAttachmentsInfo.getAttachments();
        transactionListAttachmentsInfo.getCount();
        transactionListAttachmentsInfo.getStart();
        transactionListAttachmentsInfo.getTotalRecords();
    }
    @Test
    public void testTransactionListAttachmentsInfoNull() {
        TransactionListAttachmentsInfo transactionListAttachmentsInfo=new TransactionListAttachmentsInfo();
        transactionListAttachmentsInfo.setAttachments(new ArrayList<TransactionAttachmentInfo>());
        transactionListAttachmentsInfo.getAttachments();
    }
}
