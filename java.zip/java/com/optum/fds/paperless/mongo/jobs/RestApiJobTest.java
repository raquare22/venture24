package com.optum.fds.paperless.mongo.jobs;

import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;

import java.net.URI;

import static org.junit.Assert.*;

public class RestApiJobTest {

    @Test
    public void testGettersAndSetters() {
        RestApiJob restApiJob = new RestApiJob();

        restApiJob.setAppIdentifier("App123");
        assertEquals("App123", restApiJob.getAppIdentifier());

        restApiJob.setClientId(1001);
        assertEquals(1001, restApiJob.getClientId());

        restApiJob.setDbStatusObjectId("dbStatus123");
        assertEquals("dbStatus123", restApiJob.getDbStatusObjectId());

        restApiJob.setMethod(HttpMethod.POST);
        assertEquals(HttpMethod.POST, restApiJob.getMethod());

        HttpEntity<Object> request = new HttpEntity<>(new Object());
        restApiJob.setRequest(request);
        assertEquals(request, restApiJob.getRequest());

        restApiJob.setSourceId("source123");
        assertEquals("source123", restApiJob.getSourceId());

        restApiJob.setSourceType("hook");
        assertEquals("hook", restApiJob.getSourceType());

        restApiJob.setSourceJobType("processorRestApiJob");
        assertEquals("processorRestApiJob", restApiJob.getSourceJobType());

        restApiJob.setSpaceId(2002);
        assertEquals(2002, restApiJob.getSpaceId());

        URI uri = URI.create("http://example.com");
        restApiJob.setUri(uri);
        assertEquals(uri, restApiJob.getUri());

        restApiJob.setWorkFlow("TestWorkFlow");
        assertEquals("TestWorkFlow", restApiJob.getWorkFlow());

        restApiJob.setCsvFileName("test.csv");
        assertEquals("test.csv", restApiJob.getCsvFileName());

        restApiJob.setJsonFileName("test.json");
        assertEquals("test.json", restApiJob.getJsonFileName());
    }

    @Test
    public void testToString() {
        RestApiJob restApiJob = new RestApiJob();
        restApiJob.setJobId("job123");
        restApiJob.setJobType("TypeA");
        restApiJob.setAppIdentifier("App123");
        restApiJob.setClientId(1001);
        restApiJob.setDbStatusObjectId("dbStatus123");
        restApiJob.setMethod(HttpMethod.POST);
        restApiJob.setSourceId("source123");
        restApiJob.setSourceType("hook");
        restApiJob.setSourceJobType("processorRestApiJob");
        restApiJob.setSpaceId(2002);
        restApiJob.setUri(URI.create("http://example.com"));
        restApiJob.setWorkFlow("TestWorkFlow");
        restApiJob.setCsvFileName("test.csv");
        restApiJob.setJsonFileName("test.json");

        String expected = "Job [jobId=job123, jobType=TypeA, executionDateTime=null, executionOrder=0, transactionId=null, targetType=null, targetId=null, serverName=null, serverType=null]";
        assertEquals(expected, restApiJob.toString());
    }
}