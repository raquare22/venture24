package com.optum.fds.paperless.mongo.jobs;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Date;

public class JobTest {

    @Test
    public void testGettersAndSetters() {
        Job job = new Job();

        job.setJobId("job123");
        assertEquals("job123", job.getJobId());

        job.setJobType("TypeA");
        assertEquals("TypeA", job.getJobType());

        Date now = new Date();
        job.setExecutionDateTime(now);
        assertEquals(now, job.getExecutionDateTime());

        job.setExecutionOrder(1);
        assertEquals(1, job.getExecutionOrder());

        job.setTransactionId("trans123");
        assertEquals("trans123", job.getTransactionId());

        job.setTargetType("Document");
        assertEquals("Document", job.getTargetType());

        job.setTargetId("target123");
        assertEquals("target123", job.getTargetId());

        job.setServerName("Server1");
        assertEquals("Server1", job.getServerName());

        job.setServerType("Type1");
        assertEquals("Type1", job.getServerType());
    }

    @Test
    public void testToString() {
        Job job = new Job();
        job.setJobId("job123");
        job.setJobType("TypeA");
        job.setExecutionDateTime(new Date(0));
        job.setExecutionOrder(1);
        job.setTransactionId("trans123");
        job.setTargetType("Document");
        job.setTargetId("target123");
        job.setServerName("Server1");
        job.setServerType("Type1");

        System.out.println(job.toString());
        String expected = "Job [jobId=job123, jobType=TypeA, executionDateTime=Thu Jan 01 05:30:00 IST 1970, executionOrder=1, transactionId=trans123, targetType=Document, targetId=target123, serverName=Server1, serverType=Type1]";
        assertTrue(job.toString().contains("job123"));
    }
}