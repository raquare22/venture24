package com.optum.fds.paperless.mongo.jobs;

import org.junit.Test;
import static org.junit.Assert.*;

public class CsvProcessorJobTest {

    @Test
    public void testGettersAndSetters() {
        CsvProcessorJob csvProcessorJob = new CsvProcessorJob();

        csvProcessorJob.setCsvProcessorTransactionId("12345");
        assertEquals("12345", csvProcessorJob.getCsvProcessorTransactionId());

        csvProcessorJob.setTemplateDefinition("Template Definition");
        assertEquals("Template Definition", csvProcessorJob.getTemplateDefinition());

        csvProcessorJob.setTemplateId("TemplateID");
        assertEquals("TemplateID", csvProcessorJob.getTemplateId());

        csvProcessorJob.setDelimit(",");
        assertEquals(",", csvProcessorJob.getDelimit());

        csvProcessorJob.setCompanionTRL(true);
        assertTrue(csvProcessorJob.getCompanionTRL());
    }

    @Test
    public void testToString() {
        CsvProcessorJob csvProcessorJob = new CsvProcessorJob();
        csvProcessorJob.setCsvProcessorTransactionId("12345");
        assertEquals("CsvProcessorJob [csvProcessorTransactionId=12345]", csvProcessorJob.toString());
    }
}