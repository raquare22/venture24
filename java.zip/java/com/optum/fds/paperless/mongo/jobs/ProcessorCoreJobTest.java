package com.optum.fds.paperless.mongo.jobs;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProcessorCoreJobTest {

    @Test
    public void testGettersAndSetters() {
        ProcessorCoreJob processorCoreJob = new ProcessorCoreJob();

        processorCoreJob.setWorkFlow("TestWorkFlow");
        assertEquals("TestWorkFlow", processorCoreJob.getWorkFlow());

        processorCoreJob.setFilePath("/path/to/file");
        assertEquals("/path/to/file", processorCoreJob.getFilePath());

        processorCoreJob.setFileName("testfile.txt");
        assertEquals("testfile.txt", processorCoreJob.getFileName());

        processorCoreJob.setProcessorId("processor123");
        assertEquals("processor123", processorCoreJob.getProcessorId());

        processorCoreJob.setProcessorJobType("JobTypeA");
        assertEquals("JobTypeA", processorCoreJob.processorJobType());

        processorCoreJob.setAppIdentifier("App123");
        assertEquals("App123", processorCoreJob.getAppIdentifier());

        processorCoreJob.setClientId(1001);
        assertEquals(1001, processorCoreJob.getClientId());

        processorCoreJob.setSpaceId(2002);
        assertEquals(2002, processorCoreJob.getSpaceId());
    }

    @Test
    public void testToString() {
        ProcessorCoreJob processorCoreJob = new ProcessorCoreJob();
        processorCoreJob.setJobId("job123");
        processorCoreJob.setJobType("TypeA");
        processorCoreJob.setProcessorId("processor123");
        processorCoreJob.setFileName("testfile.txt");
        processorCoreJob.setFilePath("/path/to/file");
        processorCoreJob.setWorkFlow("TestWorkFlow");

        String expected = "Job [jobId=job123, jobType=TypeA, processorId=processor123, fileName=testfile.txt, filePath=/path/to/file, workFlow=TestWorkFlow]";
        assertEquals(expected, processorCoreJob.toString());
    }
}