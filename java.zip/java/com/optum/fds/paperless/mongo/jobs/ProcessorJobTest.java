package com.optum.fds.paperless.mongo.jobs;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProcessorJobTest {

    @Test
    public void testGettersAndSetters() {
        ProcessorJob processorJob = new ProcessorJob();

        processorJob.setProcessorTransactionId("trans123");
        assertEquals("trans123", processorJob.getProcessorTransactionId());
    }

    @Test
    public void testToString() {
        ProcessorJob processorJob = new ProcessorJob();
        processorJob.setProcessorTransactionId("trans123");
        processorJob.setJobId("job123");
        processorJob.setJobType("TypeA");

        String expected = "Job [jobId=job123, jobType=TypeA, processorTransactionId=trans123]";
        assertEquals(expected, processorJob.toString());
    }
}