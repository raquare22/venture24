package com.optum.fds.paperless.mongo;

import org.junit.Test;
import static org.junit.Assert.*;

public class CodesTXGCTest {

    @Test
    public void testGettersAndSetters() {
        CodesTXGC codesTXGC = new CodesTXGC();

        codesTXGC.setProcedureCodeType("TypeA");
        assertEquals("TypeA", codesTXGC.getProcedureCodeType());

        codesTXGC.setProcCodeDescription("DescriptionA");
        assertEquals("DescriptionA", codesTXGC.getProcCodeDescription());

        codesTXGC.setApprovalRate("90%");
        assertEquals("90%", codesTXGC.getApprovalRate());

        codesTXGC.setNumberOfCodesInCluster("5");
        assertEquals("5", codesTXGC.getNumberOfCodesInCluster());
    }

    @Test
    public void testToString() {
        CodesTXGC codesTXGC = new CodesTXGC();
        codesTXGC.setProcedureCodeType("TypeA");
        codesTXGC.setProcCodeDescription("DescriptionA");
        codesTXGC.setApprovalRate("90%");
        codesTXGC.setNumberOfCodesInCluster("5");

        String expected = "CodesTXGC [procedureCodeType=TypeA, procCodeDescription=DescriptionA, approvalRate=90%, numberOfCodesInCluster=5]";
        assertEquals(expected, codesTXGC.toString());
    }
}