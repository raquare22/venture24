package com.optum.fds.paperless.mongo;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.expression.AccessException;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class DocumentMetadataTest {

    DocumentMetaData documentMetaData = new DocumentMetaData();

    @Test
    public void TestDocumentMetadata(){
        documentMetaData.setFsId(new String());
        String fsId = documentMetaData.getFsId();
        documentMetaData.setFdsDocumentId(new String());
        String fdsDocumentId = documentMetaData.getFdsDocumentId();
        documentMetaData.setSpaceId(1087);
        Integer spaceID = 1088;
        documentMetaData.setSpaceId(spaceID);
        int spaceId = documentMetaData.getSpaceId();
        documentMetaData.setExternalId(new String());
        String externalId = documentMetaData.getExternalId();
        documentMetaData.setParentId(new String());
        String parentId = documentMetaData.getParentId();
        documentMetaData.setExpires(new Date());
        Date expires  = documentMetaData.getExpires();
        documentMetaData.setErrorMessage(new String());
        String errorMessage = documentMetaData.getErrorMessage();
        org.bson.Document metadata = new Document();
        documentMetaData.setMetadata(metadata);
        org.bson.Document metadata2 = documentMetaData.getMetadata();

        List<DocumentAttachmentMetaData> dataList = new ArrayList<>();
        documentMetaData.setDocumentAttachments(dataList);
        List<DocumentAttachmentMetaData> dataList2 = documentMetaData.getDocumentAttachments();

        documentMetaData.getRevisions();

        String testString = "DocumentMetaData [documentAttachments=" + dataList2 + ", externalId=" + externalId + ", expires="
                + expires + ", errorMessage=" + errorMessage + ", metadata=" + metadata + ", parentId=" + parentId + ", spaceId="
                + spaceId + "]";
        assertTrue(testString.contains("1088"));
//        assertEquals(testString, documentMetaData.toString());
    }

}
