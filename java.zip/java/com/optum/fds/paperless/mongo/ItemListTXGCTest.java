package com.optum.fds.paperless.mongo;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;

public class ItemListTXGCTest {

    @Test
    public void testGettersAndSetters() {
        ItemListTXGC itemListTXGC = new ItemListTXGC();

        BatchInfoTXGC batchInfo = new BatchInfoTXGC();
        itemListTXGC.setBatchInfo(batchInfo);
        assertEquals(batchInfo, itemListTXGC.getBatchInfo());

        List<CodesTXGC> codes = new ArrayList<>();
        itemListTXGC.setCodes(codes);
        assertEquals(codes, itemListTXGC.getCodes());

        itemListTXGC.setTXGCID("TXGC123");
        assertEquals("TXGC123", itemListTXGC.getTXGCID());

        itemListTXGC.setCLLibraryNme("LibraryName");
        assertEquals("LibraryName", itemListTXGC.getCLLibraryNme());

        itemListTXGC.setGroupName("GroupName");
        assertEquals("GroupName", itemListTXGC.getGroupName());

        itemListTXGC.setTemplateName("TemplateName");
        assertEquals("TemplateName", itemListTXGC.getTemplateName());

        itemListTXGC.setProvFirstName("FirstName");
        assertEquals("FirstName", itemListTXGC.getProvFirstName());

        itemListTXGC.setProvLastName("LastName");
        assertEquals("LastName", itemListTXGC.getProvLastName());

        itemListTXGC.setProvFullName("FullName");
        assertEquals("FullName", itemListTXGC.getProvFullName());

        itemListTXGC.setProvAddr1("Address1");
        assertEquals("Address1", itemListTXGC.getProvAddr1());

        itemListTXGC.setProvAddr2("Address2");
        assertEquals("Address2", itemListTXGC.getProvAddr2());

        itemListTXGC.setProvCity("City");
        assertEquals("City", itemListTXGC.getProvCity());

        itemListTXGC.setProvSt("State");
        assertEquals("State", itemListTXGC.getProvSt());

        itemListTXGC.setProvZip("Zip");
        assertEquals("Zip", itemListTXGC.getProvZip());

        itemListTXGC.setProvProvinceRegion("ProvinceRegion");
        assertEquals("ProvinceRegion", itemListTXGC.getProvProvinceRegion());

        itemListTXGC.setProvCountry("Country");
        assertEquals("Country", itemListTXGC.getProvCountry());

        itemListTXGC.setCount(5);
        assertEquals("005", itemListTXGC.getCount());

        itemListTXGC.setTin("TIN123");
        assertEquals("TIN123", itemListTXGC.getTin());

        itemListTXGC.setNpi("NPI123");
        assertEquals("NPI123", itemListTXGC.getNpi());

        itemListTXGC.setExemptionEffectiveStartDate("2023-01-01");
        assertEquals("2023-01-01", itemListTXGC.getExemptionEffectiveStartDate());

        itemListTXGC.setExemptionEffectiveEndDate("2023-12-31");
        assertEquals("2023-12-31", itemListTXGC.getExemptionEffectiveEndDate());

        itemListTXGC.setCycleStartDate("2023-01-01");
        assertEquals("2023-01-01", itemListTXGC.getCycleStartDate());

        itemListTXGC.setCycleEndDate("2023-12-31");
        assertEquals("2023-12-31", itemListTXGC.getCycleEndDate());

        itemListTXGC.setProviderType("P");
        assertEquals("Provider", itemListTXGC.getProviderType());
    }
}