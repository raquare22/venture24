package com.optum.fds.paperless.mongo.processors;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MetaDataTest {
    com.optum.fds.paperless.mongo.processors.MetaData metaData = new com.optum.fds.paperless.mongo.processors.MetaData();

    @Test
    public void testGettersSetters(){

        metaData.setId("id");
        Assert.assertEquals("id",metaData.getId());

        metaData.setAppIdentifier("appIdentifier");
        Assert.assertEquals("appIdentifier",metaData.getAppIdentifier());

        int clientId = 1088;
        metaData.setClientId(clientId);
        Assert.assertEquals(1088,metaData.getClientId());

//        metaData.setDateCreated(new Date());
//        Assert.assertEquals(new Date(),metaData.getDateCreated());
//
//        metaData.setDateModified(new Date());
//        Assert.assertEquals(new Date(),metaData.getDateModified());

        metaData.setName("name");
        Assert.assertEquals("name",metaData.getName());

        List revision =  new ArrayList();
        metaData.setRevisions(revision);
        Assert.assertEquals(revision,metaData.getRevisions());

        metaData.setStatus(MetaDataStatus.ACTIVE);
        metaData.setStatus("ACTIVE");
        Assert.assertEquals(MetaDataStatus.ACTIVE,metaData.getStatus());

        metaData.setTransactionId("1099");
        Assert.assertEquals("1099",metaData.getTransactionId());

        metaData.setVersion("3");
        Assert.assertEquals("3",metaData.getVersion());
        metaData.incrementVersion();
    }
}
