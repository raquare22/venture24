package com.optum.fds.paperless.mongo.processors;

import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import org.junit.Test;
import org.mockito.Mock;
import org.mvel2.util.Make;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;

public class ProcessorTaskTest {

    @Mock
    ProcessorExecutionRecord processorExecutionRecord;

    @Test
    public void testGetSetServerType() {
        ProcessorTask processorTask = new ProcessorTask();
        processorTask.setServerType("xaas");
        assertEquals("xaas", processorTask.getServerType());
        processorTask.addProcessorExecutionRecord(null);
        processorTask.addProcessorExecutionRecord(processorExecutionRecord);
        processorTask.setUnprocessedRecordList(null);
        processorTask.getUnprocessedRecordList();
        List<com.optum.fds.paperless.mongo.executions.UnprocessedRecord> list= new ArrayList<>();
        processorTask.setUnprocessedRecordList(list);
        processorTask.getUnprocessedRecordList();
        processorTask.setEndTime();
        processorTask.setStartTime();

        processorTask.setProcessorId(new String());
        processorTask.getProcessorId();
        processorTask.setProcessorId(null);

        processorTask.setFileName(new String());
        processorTask.getFileName();
        processorTask.setFileName(null);

        processorTask.setProcessedByHost(new String());
        processorTask.getProcessedByHost();
        processorTask.setProcessedByHost(null);

        processorTask.setLocation(new String());
        processorTask.getLocation();
        processorTask.setLocation(null);

        List<ProcessorExecutionRecord> list1 = new ArrayList<>();
        processorTask.setProcessorExecutionRecordList(list1);
        processorTask.getProcessorExecutionRecordList();
        processorTask.setProcessorExecutionRecordList(null);
        processorTask.getProcessorExecutionRecordList();
    }
}
