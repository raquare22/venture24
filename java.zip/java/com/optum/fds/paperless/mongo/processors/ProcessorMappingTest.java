package com.optum.fds.paperless.mongo.processors;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class ProcessorMappingTest {


    ProcessorMapping processorMapping = new ProcessorMapping();
    @Test
    public void testProcessorMapping() {
        ProcessorMap processorMap=new ProcessorMap();
        List<ProcessorMap> list=new ArrayList<>();
        list.add(processorMap);
        processorMapping.setMapping(list);
        processorMapping.setSpaceId(3007);
        processorMapping.addMap(processorMap);
        processorMapping.setProcessorRecordType(ProcessorRecordTypes.csvProcessorRowTask);
        assertNotNull(processorMapping.getMapping());
        assertNotNull(processorMapping.getSpaceId());
        assertNotNull(processorMapping.getProcessorRecordType());



    }
    @Test
    public void testProcessorMappingWithNull() {
        processorMapping.setMapping(null);
        assertNull(processorMapping.getMapping());
        processorMapping.addMap(null);



    }

}
