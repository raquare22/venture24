package com.optum.fds.paperless.mongo.processors;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
public class ProcessingMetricsTest {

    ProcessingMetrics processingMetrics = new ProcessingMetrics();

    @Test
    public void testGetSetAverageRunTime(){
        Long value = 10L;
        processingMetrics.setAverageRunTime(value);
        assertEquals(value,processingMetrics.getAverageRunTime());
    }

    @Test
    public void testGetSetAverageFileSize(){
        Long value = 123L;
        processingMetrics.setAverageFileSize(value);
        assertEquals(value,processingMetrics.getAverageFileSize());
    }

    @Test
    public void testGetSetFileCount(){
        Integer value = 50;
        processingMetrics.setFileCount(value);
        assertEquals(value,processingMetrics.getFileCount());
    }

}
