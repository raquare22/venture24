package com.optum.fds.paperless.mongo.processors;

import org.joda.time.DateTime;
import org.junit.Test;

import java.util.ArrayList;

public class ProcessorSummaryCoreTest {

    @Test
    public void testProcessorSummaryCore() {
        ProcessorSummaryCore core=new ProcessorSummaryCore();
        core.setStartTime(DateTime.now().toDate());
        core.getStartTime();
        core.setStartTime(null);
        core.getStartTime();
        core.setEndTime(DateTime.now().toDate());
        core.getEndTime();
        core.setEndTime(null);
        core.getEndTime();
        core.setErrorList(null);
        core.getErrorList();
        core.setErrorList(new ArrayList<ProcessorError>());
        core.getErrorList();
        core.setRunTime(100L);
        core.getRunTime();
        core.setRunTime(null);


    }
    @Test
    public void testError() {
        ProcessorSummaryCore core=new ProcessorSummaryCore();
        ProcessorError error =new ProcessorError();
        core.addError(error);
        core.setErrorList(new ArrayList<ProcessorError>());
        core.addError(error);
    }
}
