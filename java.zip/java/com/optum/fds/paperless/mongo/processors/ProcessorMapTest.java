package com.optum.fds.paperless.mongo.processors;

import org.junit.Assert;
import org.junit.Test;

public class ProcessorMapTest {


    @Test
    public void testProcessorMapr(){
        ProcessorMap map = new ProcessorMap();
        Assert.assertNotNull(map);

    }

    @Test
    public void testProcessorMapConstructor(){
        ProcessorMap map = new ProcessorMap("test");
        map.setKey("test");
        Assert.assertNotNull(map.getKey());

    }

    @Test
    public void testProcessorMapConstructor1(){
        ProcessorMap map = new ProcessorMap("test","test");
        map.setNewKey("test");
        Assert.assertNotNull(map.getNewKey());

    }
    @Test
    public void testProcessorMapConstructor2(){
        ProcessorMap map = new ProcessorMap("test","test",true);
        map.setRequired(true);
        Assert.assertNotNull(map.getRequired());

    }
    @Test
    public void testProcessorMapConstructor3(){
        ProcessorMap map = new ProcessorMap("test","test",true,"test");
        map.setDescription("test");
        Assert.assertNotNull(map.getDescription());

    }
    @Test
    public void testProcessorMapConstructor5(){
        ProcessorMap map = new ProcessorMap("test","test",true,"test","test");
        map.setRequiredCriteria("test");
        Assert.assertNotNull(map.getRequiredCriteria());

    }
    @Test
    public void testProcessorMapConstructor6(){
        ProcessorMap map = new ProcessorMap("test","test",true,"test","test",true);
        map.setSevereError(true);
        Assert.assertNotNull(map.getSevereError());

    }
    @Test
    public void testProcessorMapConstructor7(){
        ProcessorMap map = new ProcessorMap("test","test",true,"test","test",true,"test");
        map.setValueRegex("test");
        Assert.assertNotNull(map.getValueRegex());

    }
}
