package com.optum.fds.paperless.mongo.processors;

import org.junit.Test;
import org.mockito.InjectMocks;

import javax.naming.event.NamingListener;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ProcessorSummaryTest {

    @Test
    public void testGetProcessingMetrics() {
        ProcessorSummary processorSummary = new ProcessorSummary();
        ProcessingMetrics processingMetrics=processorSummary.getProcessingMetrics();

        assertNotNull(processingMetrics);

        Object xmlObject=new Object();
        processorSummary.setProcessingMetrics(processingMetrics);
        processorSummary.setXmlObject(xmlObject);
        processorSummary.getXmlObject();
    }
    @Test
    public void testGetProcessingMetricsNull() {
        ProcessorSummary processorSummary = new ProcessorSummary();
        ProcessingMetrics processingMetrics=new ProcessingMetrics();
        processorSummary.setProcessingMetrics(processingMetrics);
        processorSummary.getProcessingMetrics();
    }

}
