package com.optum.fds.paperless.mongo.processors;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Date;


public class ProcessorFileTaskTest {
    @Test
    public void testProcessorFileTask() {
        ProcessorFileTask processorFileTask=new ProcessorFileTask();
        processorFileTask.setRequest("request");
        processorFileTask.setResponse("Response");
        processorFileTask.setTargetType(ProcessorTargetType.attachments);
        processorFileTask.setTargetId("targetId");
        processorFileTask.setProcessorTransactionId("processorTransactionId");
        processorFileTask.setMetadata(new java.util.HashMap<>());
        processorFileTask.setFileType("fileType");
        processorFileTask.setFileSize(1098L);
        processorFileTask.setDateProcessed(new Date());
        processorFileTask.setPostFDSResponse(true);
        processorFileTask.setFdsDocumentId("FdsDocumentId");
        processorFileTask.setFsId("FsId");


        processorFileTask.getRequest();
        processorFileTask.getResponse();
        processorFileTask.getTargetType();
        processorFileTask.getTargetId();
        processorFileTask.getProcessorTransactionId();
        processorFileTask.getMetadata();
        processorFileTask.getFileType();
        processorFileTask.getFileSize();
        processorFileTask.getDateProcessed();
        processorFileTask.isPostFDSResponse();
        processorFileTask.getFdsDocumentId();
        processorFileTask.getFsId();

    }
}
