package com.optum.fds.paperless.mongo.processors;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class ProcessorTransactionTest {
    @Test
    @RallyTestCase(references = "TC28851")
    public void TestGetAckStatus(){
        ProcessorTransaction t = new ProcessorTransaction();
        t.setAckStatus(AckStatus.IN_PROCESS);
        assertTrue( t.getAckStatus().equals(AckStatus.IN_PROCESS));
        t.addMissingFile("fileName");
        t.addExtraFile("fileName");
        t.addFileToProcess("fileName");

        t.setFileCount(10);
        t.getFileCount();

        List<String> listString = new ArrayList<>();

        t.setMissingFileList(listString);
        t.getMissingFileList();

        t.setExtraFileList(listString);
        t.getExtraFileList();

        t.setFileToProcessList(listString);
        t.getFileToProcessList();


    }
}
