package com.optum.fds.paperless.mongo.processors;

import org.junit.Test;

public class RevisionTest {


    @Test
    public void test() {
        com.optum.fds.paperless.mongo.processors.Revision revision = new com.optum.fds.paperless.mongo.processors.Revision();
        revision.getSpaceId();
        revision.setSpaceId("8001");
        revision.getTransactionId();
        revision.setTransactionId(new java.lang.String());
        revision.getClientId();
        revision.setClientId(0);
        revision.getAppIdentifier();
        revision.setAppIdentifier(new java.lang.String());
        revision.getDateCreated();
        revision.setDateCreated(new java.util.Date());
        revision.getDateModified();
        revision.setDateModified(new java.util.Date());
        revision.getStatus();
        revision.setStatus(MetaDataStatus.ACTIVE);

    }

}
