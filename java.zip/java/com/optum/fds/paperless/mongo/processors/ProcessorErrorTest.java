package com.optum.fds.paperless.mongo.processors;

import junit.framework.TestCase;
import org.junit.Test;

public class ProcessorErrorTest extends TestCase {


    @Test
    public void testProcessorErrorWithErrorCode(){
        ProcessorError processorError = new ProcessorError(ProcessorErrorCode.FILE_NOT_FOUND);

        assertEquals("Error Code not set correctly", ProcessorErrorCode.FILE_NOT_FOUND.getErrorCode(), processorError.getErrorCode());
        assertEquals("Error Message not set correctly", ProcessorErrorCode.FILE_NOT_FOUND.getErrorMessage(), processorError.getErrorMessage());
    }
    @Test
    public void testProcessorErrorWithErrorCodeAndFileName(){
        ProcessorError processorError = new ProcessorError(ProcessorErrorCode.FILE_NOT_FOUND, "FileName.extension");

        assertEquals("Error Code not set correctly", ProcessorErrorCode.FILE_NOT_FOUND.getErrorCode(), processorError.getErrorCode());
        assertEquals("Error Message not set correctly", ProcessorErrorCode.FILE_NOT_FOUND.getErrorMessage(), processorError.getErrorMessage());
        assertEquals("FileName not set correctly", "FileName.extension", processorError.getFileName());
    }
    @Test
    public void testProcessorErrorWithErrorCodeWithCustomMessage(){
        ProcessorError processorError = new ProcessorError(ProcessorErrorCode.FILE_NOT_FOUND);
        processorError.setErrorMessage("New Message");

        assertEquals("Error Code not set correctly", ProcessorErrorCode.FILE_NOT_FOUND.getErrorCode(), processorError.getErrorCode());
        assertEquals("Error Message not set correctly", "New Message", processorError.getErrorMessage());
    }
    @Test
    public void testProcessorErrorWithError(){
        ProcessorError processorError = new ProcessorError("Error Message",404);
        ProcessorError processorError2=new ProcessorError();
        assertNotNull(processorError2);
        processorError.setFileName("error.txt");
    }
}
