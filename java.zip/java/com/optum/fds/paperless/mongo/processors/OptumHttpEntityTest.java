package com.optum.fds.paperless.mongo.processors;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;


public class OptumHttpEntityTest {
    @Test
    public void test(){
        OptumHttpEntity optumHttpEntity = new OptumHttpEntity();

        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        OptumHttpEntity optumHttpEntityNew = new OptumHttpEntity(body,headers);

        Assert.assertNotNull(optumHttpEntity);
        Assert.assertNotNull(optumHttpEntityNew);
    }
}
