package com.optum.fds.paperless.mongo.processors;

import org.junit.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

public class ProcessorRevisionTest {

    @Test
    public void testIt() {
        com.optum.fds.paperless.mongo.processors.ProcessorRevision processorRevision = new com.optum.fds.paperless.mongo.processors.ProcessorRevision();
        processorRevision.getConfigSpaceId();
        processorRevision.setConfigSpaceId(new java.lang.Integer("1"));

        processorRevision.setEndDate(new java.util.Date());
        processorRevision.getEndDate();

        processorRevision.getProcess();
        processorRevision.setProcess(new java.util.HashMap());

        processorRevision.setStartDate(new java.util.Date());
        processorRevision.getStartDate();

        processorRevision.getErrors();
        processorRevision.setErrors(new java.util.ArrayList());
        processorRevision.getName();
        processorRevision.setName(new java.lang.String());
        processorRevision.getAppIdentifier();
        processorRevision.setAppIdentifier(new java.lang.String());
        processorRevision.getClientId();
        processorRevision.setClientId(0);

        processorRevision.setDateCreated(new java.util.Date());
        processorRevision.getDateCreated();

        processorRevision.setDateModified(new java.util.Date());
        processorRevision.getDateModified();

        processorRevision.getSpaceId();
        processorRevision.setSpaceId(new java.lang.String("1"));
        processorRevision.setSpaceId(0);
        processorRevision.getStatus();
        processorRevision.setStatus(MetaDataStatus.ACTIVE.name());
        processorRevision.setStatus(MetaDataStatus.ACTIVE);
        processorRevision.getTransactionId();
        processorRevision.setTransactionId(new java.lang.String("1"));
        processorRevision.setVersion(new java.lang.String ("1"));
        processorRevision.getVersion();

    }

    @Test
    public void TestNullCase() {
        com.optum.fds.paperless.mongo.processors.ProcessorRevision processorRevision = new com.optum.fds.paperless.mongo.processors.ProcessorRevision();
        processorRevision.setConfigSpaceId(null);
        assertThat(processorRevision.getConfigSpaceId(), equalTo(0));
    }

    @Test
    public void nullDateTest() {
        ProcessorRevision processorRevision = new ProcessorRevision();
        processorRevision.setStartDate(null);
        processorRevision.setEndDate(null);
        assertNull(processorRevision.getStartDate());
        assertNull(processorRevision.getEndDate());
    }
}
