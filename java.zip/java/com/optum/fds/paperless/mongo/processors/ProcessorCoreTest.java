package com.optum.fds.paperless.mongo.processors;

import org.junit.Test;

import java.util.ArrayList;

public class ProcessorCoreTest {

    @Test
    public void testProcessorCore() {
        ProcessorSummary processorSummary=new ProcessorSummary();
        processorSummary.setProcessingMetrics(new ProcessingMetrics());
        processorSummary.setErrorList(new ArrayList<ProcessorError>());
        processorSummary.setRunTime(2L);
        ProcessorCore processorCore=new ProcessorCore();
        processorCore.setSummary(processorSummary);
        processorCore.getSummary();
        processorCore.setConfigSpaceId(1);
        processorCore.getConfigSpaceId();
        processorCore.setConfigSpaceId(null);
        processorCore.getConfigSpaceId();
        processorCore.setProcessorRecordType(ProcessorRecordTypes.processor);
        processorCore.getProcessorRecordType();

    }
    @Test
    public void testProcessorCoremetricsNull() {
        ProcessorSummary processorSummary=new ProcessorSummary();
        processorSummary.setProcessingMetrics(null);
        processorSummary.setErrorList(null);
        processorSummary.setRunTime(null);
        ProcessorCore processorCore=new ProcessorCore();
        processorCore.setSummary(processorSummary);
        processorCore.getSummaryForDB();

    }
    @Test
    public void testProcessorCoremetricsErrorNull() {
        ProcessorSummary processorSummary=new ProcessorSummary();
        processorSummary.setProcessingMetrics(new ProcessingMetrics());
        processorSummary.setErrorList(null);
        processorSummary.setRunTime(2L);
        ProcessorCore processorCore=new ProcessorCore();
        processorCore.setSummary(processorSummary);
        processorCore.getSummaryForDB();

    }
    @Test
    public void testProcessorCoremetricsRunNull() {
        ProcessorSummary processorSummary=new ProcessorSummary();
        processorSummary.setProcessingMetrics(new ProcessingMetrics());
        processorSummary.setErrorList(new ArrayList<ProcessorError>());
        processorSummary.setRunTime(null);
        ProcessorCore processorCore=new ProcessorCore();
        processorCore.setSummary(processorSummary);
        processorCore.getSummaryForDB();

    }
    @Test
    public void testProcessorCoremetricsProcessNull() {
        ProcessorSummary processorSummary=new ProcessorSummary();
        processorSummary.setProcessingMetrics(null);
        processorSummary.setErrorList(new ArrayList<ProcessorError>());
        processorSummary.setRunTime(2L);
        ProcessorCore processorCore=new ProcessorCore();
        processorCore.setSummary(processorSummary);
        processorCore.getSummaryForDB();

    }
    @Test
    public void testProcessorCoremetricsProcessorNull() {
        ProcessorSummary processorSummary=new ProcessorSummary();
        processorSummary.setProcessingMetrics(null);
        processorSummary.setErrorList(null);
        processorSummary.setRunTime(null);
        ProcessorCore processorCore=new ProcessorCore();
        processorCore.setSummary(null);
        processorCore.getSummary();
        processorCore.getSummaryForDB();

    }
    @Test
    public void testProcessorCoremetricsErrorListNull() {
        ProcessorSummary processorSummary=null;
        ProcessorCore processorCore=new ProcessorCore();
        processorCore.setSummary(processorSummary);
        processorCore.getSummaryForDB();

    }
}
