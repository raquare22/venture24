package com.optum.fds.paperless.mongo.processors;

import com.google.gson.JsonObject;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProcessorTransactionsTest {

    @Test
    public void testProcessorTransactions() {
        List<JsonObject> list = new ArrayList<>();
        ProcessorTransactions processorTransactions = new ProcessorTransactions();
        processorTransactions.setProcessorTransactions(list);
        processorTransactions.getProcessorTransactions();
    }
    @Test
    public void testProcessorMetrics() {
        ProcessingMetricsCore core=new ProcessingMetricsCore();
        Map<Integer,Integer> map=new HashMap<>();
        map.put(404, 6);
        core.setErrorCount(map);
        core.incrementErrorCodeCount(404);
        map.put(404, null);
        core.setErrorCount(map);
        core.incrementErrorCodeCount(404);
    }

}
