package com.optum.fds.paperless.mongo.processors;

import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.*;
import static org.junit.Assert.assertNotNull;

public class ProcessorMetaDataTest {


    ProcessorMetaData processorMetaData = new ProcessorMetaData();
    Map<String, String> configMap = new HashMap<>();
    Map<String, Object> processMap;

    @Before
    public void setup() {
        processMap = new HashMap<>();
        configMap.put("template_definition", "myTemplateDefinition");
        processMap.put("config", configMap);
    }

    @Test
    public void getGetSetProcess() {
        processMap = new HashMap<>();
        processorMetaData.setProcess(processMap);
        assertEquals(processMap, processorMetaData.getProcess());
    }

    @Test
    public void getProcessConfig() {
        processorMetaData.setProcess(processMap);
        assertEquals(configMap, processorMetaData.getProcessConfig());
    }
    @Test
    public void testPriorityNotNull() {
        processorMetaData.setPriority(200);
        assertNotNull(processorMetaData.getPriority());
    }
    @Test
    public void testPriorityNull() {
        processorMetaData.setPriority(null);
        assertNull(processorMetaData.getPriority());
    }

    @Test
    public void getProcessConfigWithNullProcess() {
        processorMetaData.setProcess(null);
        assertNull(processorMetaData.getProcessConfig());
    }

    @Test
    public void TestProcessorTransactionMetadata(){

        ProcessorMetaData processorMetaDataObj = new ProcessorMetaData();
        ProcessorRevision revision=new ProcessorRevision();
        revision.setAppIdentifier("5c49a908fde3920056bd94ac");

        processorMetaDataObj.setAppIdentifier("5c49a908fde3920056bd94ac");
        processorMetaDataObj.setCleanupWorkflow("cleanupWorkflow");
        processorMetaDataObj.setClientId(685);
        processorMetaDataObj.setConfigSpaceId(10102);
        processorMetaDataObj.setDateCreated(new Date());
        processorMetaDataObj.setDateModified(new Date());
        processorMetaDataObj.setDates();
        processorMetaDataObj.setEndDate(new Date());
        processorMetaDataObj.setLastCleanUpRun(new Date());
        processorMetaDataObj.setLastRun(new Date());
        processorMetaDataObj.setLocked(false);
        processorMetaDataObj.setName("Workflow");
        processorMetaDataObj.setProcess(processMap);
        processorMetaDataObj.setProcessorType("processor");
        processorMetaDataObj.setRetryCount(5);
        processorMetaDataObj.setResolveIncompleteProcessorTransactionLastRun(new Date());
        processorMetaDataObj.setResolveIncompleteProcessorTransactionLocked(false);
        processorMetaDataObj.setStartDate(new java.util.Date());
        processorMetaDataObj.setStartDate("2018-11-07T00:00:00.000Z");
        processorMetaDataObj.addRevision(revision);
        processorMetaDataObj.setEndDate("2018-11-07T00:00:00.000Z");

        assertTrue(processorMetaDataObj.getAppIdentifier().contentEquals("5c49a908fde3920056bd94ac"));
        assertTrue(processorMetaDataObj.getCleanupWorkflow().contentEquals("cleanupWorkflow"));
        assertTrue(processorMetaDataObj.getClientId()==685);
        assertTrue(processorMetaDataObj.getConfigSpaceId()==10102);
        assertNotNull(processorMetaDataObj.getDateCreated());
        assertNotNull(processorMetaDataObj.getDateModified());
        assertNotNull(processorMetaDataObj.getEndDate());
        assertNotNull(processorMetaDataObj.getLastCleanUpRun());
        assertNotNull(processorMetaDataObj.getLastRun());
        assertTrue(processorMetaDataObj.getName().contentEquals("Workflow"));
        assertNotNull(processorMetaDataObj.getProcess());
        assertTrue(processorMetaDataObj.getProcessorType().contentEquals("processor"));
        assertTrue(processorMetaDataObj.getRetryCount()==5);
        assertNotNull(processorMetaDataObj.getResolveIncompleteProcessorTransactionLastRun());
        assertFalse(processorMetaDataObj.getResolveIncompleteProcessorTransactionLocked());
        //assertNotNull(processorMetaDataObj.getStartDate());
//        assertEquals(processorMetaDataObj.getStartDate(), new java.util.Date());
        assertNotNull(processorMetaDataObj.getRevisions());
        assertNotNull(processorMetaDataObj.getEndDateString());
        assertFalse(processorMetaDataObj.isLocked());
//        assertNotNull(processorMetaDataObj.getStartDateString());

    }

}
