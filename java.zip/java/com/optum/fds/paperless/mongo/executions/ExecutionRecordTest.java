package com.optum.fds.paperless.mongo.executions;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;

public class ExecutionRecordTest {


    @Test
    public void testIt() {
        com.optum.fds.paperless.mongo.executions.ExecutionRecord executionRecord = new com.optum.fds.paperless.mongo.executions.ExecutionRecord();

        executionRecord.setAppIdentifier(new java.lang.String());
        executionRecord.setClientId(0);
        executionRecord.setDateCreated(new java.util.Date());
        executionRecord.setDateModified(new java.util.Date());
        executionRecord.setMessageList(new java.util.ArrayList<>());
        executionRecord.setServerName(new java.lang.String());
        executionRecord.setServerIp(new java.lang.String());
        executionRecord.setSpaceId(0);
        executionRecord.setStatus(new java.lang.String());
        executionRecord.setVersion(new java.lang.String());
        executionRecord.setActivitiJobId(new java.lang.String());
        executionRecord.setActivitiJobStatus(new java.lang.String());
        executionRecord.setActivitiProcessKey(new java.lang.String());
        executionRecord.setDateActivitiJobCompleted(new java.util.Date());
        executionRecord.setDateActivitiJobCreated(new java.util.Date());
        executionRecord.setDateActivitiJobModified(new java.util.Date());

        executionRecord.addMessage(new java.util.HashMap<>());

        executionRecord.getAppIdentifier();
        executionRecord.getClientId();
        executionRecord.getDateCreated();
        executionRecord.getDateModified();
        executionRecord.getMessageList();
        executionRecord.getServerName();
        executionRecord.getServerIp();
        executionRecord.getSpaceId();
        executionRecord.getStatus();
        executionRecord.getActivitiJobId();
        executionRecord.getActivitiJobStatus();
        executionRecord.getActivitiProcessKey();
        executionRecord.getDateActivitiJobCompleted();
        executionRecord.getDateActivitiJobCreated();
        executionRecord.getDateActivitiJobModified();
        executionRecord.getVersion();

    }

    @Test
    public void testItNull() {
        com.optum.fds.paperless.mongo.executions.ExecutionRecord executionRecord = new com.optum.fds.paperless.mongo.executions.ExecutionRecord();


        executionRecord.setDateCreated(null);
        executionRecord.setDateModified(null);
        executionRecord.setMessageList(null);
        executionRecord.setDateActivitiJobCompleted(null);
        executionRecord.setDateActivitiJobCreated(null);
        executionRecord.setDateActivitiJobModified(null);


        executionRecord.getAppIdentifier();
        executionRecord.getClientId();
        executionRecord.getDateCreated();
        executionRecord.getDateModified();
        executionRecord.getMessageList();
        executionRecord.getServerName();
        executionRecord.getServerIp();
        executionRecord.getSpaceId();
        executionRecord.getStatus();
        executionRecord.getActivitiJobId();
        executionRecord.getActivitiJobStatus();
        executionRecord.getActivitiProcessKey();
        executionRecord.getDateActivitiJobCompleted();
        executionRecord.getDateActivitiJobCreated();
        executionRecord.getDateActivitiJobModified();
        executionRecord.getVersion();

    }
    @Test
    public void testProcessorExecutionrecord() {
        ProcessorExecutionRecord processorExecutionRecord=new ProcessorExecutionRecord();
        processorExecutionRecord.setDescription("description");
        assertNotNull(processorExecutionRecord.getDescription());

    }

    @Test
    public void testMessageListNullInAddMessage(){
        com.optum.fds.paperless.mongo.executions.ExecutionRecord executionRecord = new com.optum.fds.paperless.mongo.executions.ExecutionRecord();
        executionRecord.addMessage(null);

    }

}
