package com.optum.fds.paperless.mongo.executions;

import org.junit.Assert;
import org.junit.Test;

import java.util.Date;

public class HookExecutionRecordMetaDataTest {
    HookExecutionRecordMetaData hookExecutionRecordMetaData = new HookExecutionRecordMetaData();
    @Test
    public void testGetSetExpires(){
        hookExecutionRecordMetaData.setExpires(new Date());
        Assert.assertEquals(hookExecutionRecordMetaData.getExpires(),new Date());
    }

    @Test
    public void testGetSetHookExecutionId(){
        hookExecutionRecordMetaData.setHookExecutionId(new String());
        Assert.assertEquals(new String(),hookExecutionRecordMetaData.getHookExecutionId());
    }

    @Test
    public void testGetSetHookId(){
        hookExecutionRecordMetaData.setHookId(new String());
        Assert.assertEquals(hookExecutionRecordMetaData.getHookId(),new String());
    }

    @Test
    public void testToString(){
        String testString = "HookExecutionRecordMetaData [hookExecutionId=" + hookExecutionRecordMetaData.getHookExecutionId()+ ", clientId=" + hookExecutionRecordMetaData.getClientId() +
                ", spaceId=" + hookExecutionRecordMetaData.getSpaceId() + ", appIdentifier=" + hookExecutionRecordMetaData.getAppIdentifier() + ", status=" + hookExecutionRecordMetaData.getStatus() +
                ", version=" + hookExecutionRecordMetaData.getVersion() + ", expires=" + hookExecutionRecordMetaData.getExpires() + ", dateCreated=" + hookExecutionRecordMetaData.getDateCreated() +
                ", dateModified=" + hookExecutionRecordMetaData.getDateModified() + ", messageList=" + hookExecutionRecordMetaData.getMessageList() + ", hookId=" + hookExecutionRecordMetaData.getHookId()+
                ", activitiProcessKey=" + hookExecutionRecordMetaData.getActivitiProcessKey() + ", activitiJobId=" + hookExecutionRecordMetaData.getActivitiJobId() +
                ", dateActivitiJobCreated=" + hookExecutionRecordMetaData.getDateActivitiJobCreated() + ", dateActivitiJobModified=" +
                hookExecutionRecordMetaData.getDateActivitiJobModified() + ", activitiJobStatus=" + hookExecutionRecordMetaData.getActivitiJobStatus() +
                ", dateActivitiJobCompleted=" + hookExecutionRecordMetaData.getDateActivitiJobCompleted() + "]";

        Assert.assertNotNull(hookExecutionRecordMetaData.toString());
        Assert.assertEquals(testString,hookExecutionRecordMetaData.toString());
    }
}
