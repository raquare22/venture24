package com.optum.fds.paperless.mongo.executions;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class UnprocessedRecordTest {
    @Test
    public void testConstructor() throws Exception {
        UnprocessedRecord unprocessedRecord = new UnprocessedRecord("test", 1);
        assertNotNull(unprocessedRecord);
    }


    @Test
    public void testUnprocessedRecord() throws Exception {
        UnprocessedRecord unprocessedRecord = new UnprocessedRecord("test", 1);
        unprocessedRecord.setUnprocessRecord("test");
        unprocessedRecord.setIndex(1);
        assertEquals(1,unprocessedRecord.getIndex());
        assertEquals("test",unprocessedRecord.getUnprocessRecord());
    }


}
