package com.optum.fds.paperless.mongo;


import com.optum.fds.paperless.mongo.executions.HookExecutionRecordMetaData;
import com.optum.fds.paperless.mongo.processors.OptumHttpEntity;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpMethod;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;

import static junit.framework.Assert.assertEquals;

public class JobMetaDataTest {

    JobMetaData jobMetaData = new JobMetaData();

    @Before
    public void setup() {
        jobMetaData.setServerName("test.uhc.com");
        jobMetaData.setServerType("xaas");
        jobMetaData.setCsvProcessorTransactionId("csvProcessorTransactionId");
        jobMetaData.setCsvProcessorRowTaskId("csvProcessorRowTaskId");
        jobMetaData.setProcessorJobType("csvProcessorJob");
        jobMetaData.setTemplateDefinition("templateDefinition");
        jobMetaData.setDelimit("|");
    }

    @Test
    public void testServerName() {
        assertEquals("test.uhc.com", jobMetaData.getServerName());
    }

    @Test
    public void testServerType() {
        assertEquals("xaas", jobMetaData.getServerType() );
    }

    @Test
    public void testCsvProcessorTransactionId() {
        assertEquals("csvProcessorTransactionId", jobMetaData.getCsvProcessorTransactionId());
    }

    @Test
    public void testCsvProcessorRowTaskId() {
        assertEquals("csvProcessorRowTaskId", jobMetaData.getCsvProcessorRowTaskId());
    }

    @Test
    public void testProcessorJobType() {
        assertEquals("csvProcessorJob", jobMetaData.getProcessorJobType());
    }

    @Test
    public void setTemplateDefinition() {
        assertEquals("templateDefinition", jobMetaData.getTemplateDefinition());
    }

    @Test
    public void testDelimit() {
        org.junit.Assert.assertSame(jobMetaData.getDelimit(), "|");
    }

    @Test
    public void testToString() {
        String expectedResult = "JobMetaData [id=null, parentId=null, clientId=0, spaceId=0, appIdentifier=null, status=null, version=null, expires=null, dateCreated=null, dateModified=null, transactionId=null, errorMessage=null, targetType=null, targetId=null, hookId=null, hook=null, hookExecution=null, serverName =test.uhc.com, serverType=xaas]";
        assertEquals(expectedResult, jobMetaData.toString());
    }
    @Test
    public void testJobMetadata() throws URISyntaxException {
        jobMetaData.setAppIdentifier("identifier");
        jobMetaData.getAppIdentifier();
        jobMetaData.setAttachments(new ArrayList<AttachmentMetaData>());
        jobMetaData.getAttachments();
        jobMetaData.setAttachments(null);
        jobMetaData.getAttachments();
        jobMetaData.setDateCreated(new Date());
        jobMetaData.setDateModified(new Date());
        jobMetaData.setExecutionDateTime(new Date());
        jobMetaData.getDateCreated();
        jobMetaData.getDateModified();
        jobMetaData.getExecutionDateTime();
        jobMetaData.setDateCreated(null);
        jobMetaData.setDateModified(null);
        jobMetaData.setExecutionDateTime(null);
        jobMetaData.getDateCreated();
        jobMetaData.getDateModified();
        jobMetaData.getExecutionDateTime();
        jobMetaData.setExpires(new Date());
        jobMetaData.getExpires();
        jobMetaData.setExpires(null);
        jobMetaData.getExpires();
        jobMetaData.setTemplateId("temp");
        jobMetaData.getTemplateId();
        jobMetaData.setCompanionTRL(true);
        jobMetaData.getCompanionTRL();
        jobMetaData.setMethod(HttpMethod.GET);
        jobMetaData.getMethod();
        jobMetaData.setRequest(new OptumHttpEntity());
        jobMetaData.getRequest();
        jobMetaData.setSourceType("source");
        jobMetaData.getSourceType();
        jobMetaData.setUri(new URI("uri"));
        jobMetaData.getUri();

        jobMetaData.setId(new java.lang.String());
        jobMetaData.getId();

        jobMetaData.setParentId(new String());
        jobMetaData.getParentId();

        jobMetaData.setClientId(1087);
        jobMetaData.getClientId();

        jobMetaData.setSpaceId(1087);
        jobMetaData.getSpaceId();

        jobMetaData.setStatus(new String());
        jobMetaData.getStatus();

        jobMetaData.setVersion(new String());
        jobMetaData.getVersion();

        jobMetaData.setExecutionOrder(1);
        jobMetaData.getExecutionOrder();

        jobMetaData.setTransactionId(new String());
        jobMetaData.getTransactionId();

        jobMetaData.setJobType(new String());
        jobMetaData.getJobType();

        jobMetaData.setPriority(1);
        jobMetaData.isPriority();

        jobMetaData.setErrorMessage(new String());
        jobMetaData.getErrorMessage();

        jobMetaData.setTargetType(new String());
        jobMetaData.getTargetType();

        jobMetaData.setTargetId(new String());
        jobMetaData.getTargetId();

        HookMetaData hook = new HookMetaData();
        jobMetaData.setHook(hook);
        jobMetaData.getHook();

        HookExecutionRecordMetaData hookExecutionRecordMetaData = new HookExecutionRecordMetaData();
        jobMetaData.setHookExecution(hookExecutionRecordMetaData);
        jobMetaData.getHookExecution();

        jobMetaData.setHookId(new String());
        jobMetaData.getHookId();

        DocumentMetaData documentMetaData = new DocumentMetaData();
        jobMetaData.setDocument(documentMetaData);
        jobMetaData.getDocument();

        jobMetaData.setProcessorId(new String());
        jobMetaData.getProcessorId();

        jobMetaData.setProcessorTransactionId(new String());
        jobMetaData.getProcessorTransactionId();

        jobMetaData.setFileName(new String());
        jobMetaData.getFileName();

        jobMetaData.setFilePath(new String());
        jobMetaData.getFilePath();

        jobMetaData.setWorkFlow(new String());
        jobMetaData.getWorkFlow();


    }
}
