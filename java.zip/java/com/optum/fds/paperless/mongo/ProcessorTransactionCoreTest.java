package com.optum.fds.paperless.mongo;

import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorError;
import com.optum.fds.paperless.mongo.processors.ProcessorSummary;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ProcessorTransactionCoreTest {


    ProcessorTransactionCore processorTransactionCore = new ProcessorTransactionCore();

    @Test
    public void testSetReadyStatus() throws Exception {
        processorTransactionCore.setStartTime();
        processorTransactionCore.setReadyStatus();
        assertEquals(MetaDataStatus.READY, processorTransactionCore.getStatus());
        assertNotNull(processorTransactionCore.getSummary().getEndTime());
        assertNotNull(processorTransactionCore.getSummary().getRunTime());
    }

    @Test
    public void testSetCompleteStatus() throws Exception {
        processorTransactionCore.setCompleteStatus();
        assertEquals(MetaDataStatus.COMPLETE, processorTransactionCore.getStatus());
    }

    @Test
    public void testSetCompleteStatusWithErrors() throws Exception {
        ProcessorSummary processorSummary = new ProcessorSummary();
        ProcessorError processorError = new ProcessorError();
        List errorList = new ArrayList<>();
        errorList.add(processorError);
        processorSummary.setErrorList(errorList);
        processorTransactionCore.setSummary(processorSummary);
        processorTransactionCore.setCompleteStatus();
        assertEquals(MetaDataStatus.COMPLETE_WITH_ERRORS, processorTransactionCore.getStatus());
    }
}
