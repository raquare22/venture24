package com.optum.fds.paperless.mongo;

import com.optum.fds.paperless.exception.ErrorCode;
import org.bson.Document;
import org.junit.Assert;
import org.junit.Test;

public class ErrorMetadataTest {
    ErrorMetaData errorMetaData = new ErrorMetaData();

    @Test
    public void testGettersSetters(){
        errorMetaData.setTargetType(new String());
        Assert.assertEquals(new String(),errorMetaData.getTargetType());

        errorMetaData.setIdentifier(new String());
        Assert.assertEquals(new String(),errorMetaData.getIdentifier());

        errorMetaData.setTargetId(new String());
        Assert.assertEquals(new String(),errorMetaData.getTargetId());

        errorMetaData.setQueue(new String());
        Assert.assertEquals(new String(),errorMetaData.getQueue());

        errorMetaData.setConnectionType(new String());
        Assert.assertEquals(new String(),errorMetaData.getConnectionType());

        Long sequenceNumberValue = 100L;
        errorMetaData.setSequenceNumber(100L);
        Assert.assertEquals(sequenceNumberValue,errorMetaData.getSequenceNumber());

        errorMetaData.setMessageId(new String());
        Assert.assertEquals(new String(),errorMetaData.getMessageId());

        errorMetaData.setCorrelationId(new String());
        Assert.assertEquals(new String(),errorMetaData.getCorrelationId());

        errorMetaData.setReplyTo(new String());
        Assert.assertEquals(new String(),errorMetaData.getReplyTo());

        Integer retryCountValue = 10;
        errorMetaData.setRetryCount(retryCountValue);
        Assert.assertEquals(retryCountValue,errorMetaData.getRetryCount());

        Long deliveryCountValue = 100L;
        errorMetaData.setDeliveryCount(deliveryCountValue);
        Assert.assertEquals(deliveryCountValue,errorMetaData.getDeliveryCount());

        errorMetaData.setErrorMessage(new String());
        Assert.assertEquals(new String(),errorMetaData.getErrorMessage());

        org.bson.Document document= new org.bson.Document();
        errorMetaData.setMetadata(document);
        Assert.assertEquals(document,errorMetaData.getMetadata());

        errorMetaData.setErrorCode(ErrorCode.PROCESS);
        Assert.assertEquals(ErrorCode.PROCESS,errorMetaData.getErrorCode());

        errorMetaData.setErrorCodeAndErrorMessageAndDefaultErrorStatus(ErrorCode.PROCESS);

        Assert.assertNotNull(errorMetaData.setCompleteStatus());

        errorMetaData.getRevisions();

        System.out.println(errorMetaData.toString());

    }

    @Test
    public void testToString(){
         String identifier = "identifier";
         String targetId = "targetId";
         String targetType = "targetType";
         String queue = "queue";
         String connectionType="connectionType";
         Long sequenceNumber = 10L;
         String correlationId = "correlationId";
         String messageId = "messageId";
         String replyTo = "replyTo";
         Long deliveryCount = 100L;
         Integer retryCount = 90;
         String errorMessage = ErrorCode.PROCESS.getDescription();
         ErrorCode errorCode = ErrorCode.PROCESS;
         org.bson.Document metadata = new Document();

        errorMetaData.setTargetType(targetType);
        errorMetaData.setIdentifier(identifier);
        errorMetaData.setTargetId(targetId);
        errorMetaData.setQueue(queue);
        errorMetaData.setConnectionType(connectionType);
        errorMetaData.setSequenceNumber(sequenceNumber);
        errorMetaData.setMessageId(messageId);
        errorMetaData.setCorrelationId(correlationId);
        errorMetaData.setReplyTo(replyTo);
        errorMetaData.setRetryCount(retryCount);
        errorMetaData.setDeliveryCount(deliveryCount);
        errorMetaData.setErrorMessage(errorMessage);
        errorMetaData.setMetadata(metadata);
        errorMetaData.setErrorCode(errorCode);



        String testString = "ErrorMetaData [identifier=" + identifier + ", targetId=" + targetId
                + ", queue=" + queue + ", connectionType=" + connectionType
                + ", sequenceNumber=" + sequenceNumber + ", correlationId=" + correlationId + ", messageId=" + messageId
                + ", replyTo=" + replyTo + ", deliveryCount=" + deliveryCount + ", retryCount=" + retryCount
                + ", errorMessage=" + errorMessage + ", errorCode=" + errorCode + ", metadata: {" + metadata + " } ]";

        Assert.assertEquals(testString,errorMetaData.toString());
    }



}
