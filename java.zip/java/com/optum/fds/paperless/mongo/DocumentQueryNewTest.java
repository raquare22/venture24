package com.optum.fds.paperless.mongo;

import org.bson.Document;
import org.junit.Assert;
import org.junit.Test;

import java.util.Date;

public class DocumentQueryNewTest {
    @Test
    public void testDocumentQuery() {
        String dt = new Date().toString();
        Document metaDataMap = new Document();
        DocumentsQueryNew documentsQuery = new DocumentsQueryNew()
                .setStartDateCreation(dt)
                .setEndDateCreation(dt)
                .setSpaceId("3006")
                .setStartDateModified(dt)
                .setEndDateModified(dt)
                .setMetaDataMap(metaDataMap)
                .add("metadata.providerEmailId", "none@none.com")
                .addJsonCriteria("{\"metadata.merged\":true}");


        Assert.assertEquals(documentsQuery.getEndDateCreation(), dt);
        Assert.assertNotNull(documentsQuery.getMetaDataMap());
        Assert.assertEquals(documentsQuery.getSpaceId(), "3006");
        Assert.assertEquals(documentsQuery.getStartDateCreation(), dt);
        Assert.assertEquals(documentsQuery.getStartDateModified(), dt);
        Assert.assertEquals(documentsQuery.getEndDateModified(), dt);
    }


    @Test
    public void testDocumentQueryWithEmptyCriteria() {
        String dt = new Date().toString();
        DocumentsQueryNew documentsQuery = new DocumentsQueryNew()
                .setStartDateCreation(dt)
                .setEndDateCreation(dt)
                .setSpaceId("3006")
                .setStartDateModified(dt)
                .setEndDateModified(dt)
                .add("metadata.providerEmailId", "none@none.com");

        try {
            documentsQuery.addJsonCriteria("");
        } catch (NullPointerException e) {
            Assert.assertTrue("cannot add empty criteria", true);
        }
        Assert.assertEquals(documentsQuery.getEndDateCreation(), dt);
        Assert.assertNotNull(documentsQuery.getMetaDataMap());
        Assert.assertEquals(documentsQuery.getSpaceId(), "3006");
        Assert.assertEquals(documentsQuery.getStartDateCreation(), dt);
        Assert.assertEquals(documentsQuery.getStartDateModified(), dt);
        Assert.assertEquals(documentsQuery.getEndDateModified(), dt);
    }
}
