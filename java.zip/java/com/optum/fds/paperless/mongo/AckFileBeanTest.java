package com.optum.fds.paperless.mongo;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;

public class AckFileBeanTest {

    @Test
    public void testGettersAndSetters() {
        AckFileBean ackFileBean = new AckFileBean();

        ackFileBean.setBatchId("batch123");
        assertEquals("batch123", ackFileBean.getBatchId());

        ackFileBean.setCount(10);
        assertEquals(Integer.valueOf(10), ackFileBean.getCount());

        List<FileDetail> fileList = new ArrayList<>();
        ackFileBean.setFileList(fileList);
        assertEquals(fileList, ackFileBean.getFileList());

        ackFileBean.setUploadDate("2023-10-01");
        assertEquals("2023-10-01", ackFileBean.getUploadDate());
    }
}