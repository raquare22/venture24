package com.optum.fds.paperless.mongo;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BatchTest {

    @Test
    public void testGettersAndSetters() {
        Batch batch = new Batch();

        batch.setBatchId("batch123");
        assertEquals("batch123", batch.getBatchId());

        batch.setCount(10);
        assertEquals(Integer.valueOf(10), batch.getCount());

        List<FileDetail> fileList = new ArrayList<>();
        batch.setFileList(fileList);
        assertEquals(fileList, batch.getFileList());

        Date uploadDate = new Date();
        batch.setUploadDate(uploadDate);
        assertEquals(uploadDate, batch.getUploadDate());
    }
}