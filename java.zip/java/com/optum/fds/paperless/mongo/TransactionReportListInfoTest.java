package com.optum.fds.paperless.mongo;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;

public class TransactionReportListInfoTest {

    @Test
    public void testAddAndGet() {
        TransactionReportListInfo listInfo = new TransactionReportListInfo();
        TransactionReportInfo reportInfo1 = new TransactionReportInfo();
        TransactionReportInfo reportInfo2 = new TransactionReportInfo();

        listInfo.add(reportInfo1);
        listInfo.add(reportInfo2);

        assertEquals(2, listInfo.size());
        assertEquals(reportInfo1, listInfo.get(0));
        assertEquals(reportInfo2, listInfo.get(1));
    }

    @Test
    public void testIsEmpty() {
        TransactionReportListInfo listInfo = new TransactionReportListInfo();
        assertTrue(listInfo.isEmpty());

        TransactionReportInfo reportInfo = new TransactionReportInfo();
        listInfo.add(reportInfo);
        assertFalse(listInfo.isEmpty());
    }

    @Test
    public void testClear() {
        TransactionReportListInfo listInfo = new TransactionReportListInfo();
        TransactionReportInfo reportInfo = new TransactionReportInfo();
        listInfo.add(reportInfo);

        listInfo.clear();
        assertTrue(listInfo.isEmpty());
    }
}