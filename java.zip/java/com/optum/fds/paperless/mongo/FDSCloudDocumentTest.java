package com.optum.fds.paperless.mongo;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FDSCloudDocumentTest {

    @Test
    public void testGettersAndSetters() {
        FDSCloudDocument document = new FDSCloudDocument();

        document.setDocumentId("doc123");
        assertEquals("doc123", document.getDocumentId());

        document.setSpaceId("space123");
        assertEquals("space123", document.getSpaceId());

        document.setMetadata("metadata");
        assertEquals("metadata", document.getMetadata());

        List<String> searchTerms = new ArrayList<>();
        searchTerms.add("term1");
        document.setSearchTerms(searchTerms);
        assertEquals(searchTerms, document.getSearchTerms());

        Date createdOn = new Date();
        document.setCreatedOn(createdOn);
        assertEquals(createdOn, document.getCreatedOn());

        Date modifiedOn = new Date();
        document.setModifiedOn(modifiedOn);
        assertEquals(modifiedOn, document.getModifiedOn());

        document.setCreatedBy("user1");
        assertEquals("user1", document.getCreatedBy());

        document.setModifiedBy("user2");
        assertEquals("user2", document.getModifiedBy());

        List<DocumentAttachmentMetaData> attachments = new ArrayList<>();
        document.setAttachments(attachments);
        assertEquals(attachments, document.getAttachments());
    }

    @Test
    public void testToString() {
        FDSCloudDocument document = new FDSCloudDocument();
        document.setDocumentId("doc123");
        document.setSpaceId("space123");
        document.setMetadata("metadata");
        List<String> searchTerms = new ArrayList<>();
        searchTerms.add("term1");
        document.setSearchTerms(searchTerms);
        Date createdOn = new Date();
        document.setCreatedOn(createdOn);
        Date modifiedOn = new Date();
        document.setModifiedOn(modifiedOn);
        document.setCreatedBy("user1");
        document.setModifiedBy("user2");
        List<DocumentAttachmentMetaData> attachments = new ArrayList<>();
        document.setAttachments(attachments);

        String expected = "FDSCloudDocument [documentId=doc123, spaceId=space123, metadata=metadata, searchTerms=[term1], createdOn=" + createdOn + ", modifiedOn=" + modifiedOn + ", createdBy=user1, modifiedBy=user2, attachments=" + attachments + "]";
        assertEquals(expected, document.toString());
    }
}