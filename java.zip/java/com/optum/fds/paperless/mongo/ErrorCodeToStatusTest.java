package com.optum.fds.paperless.mongo;

import com.optum.fds.paperless.exception.ErrorCode;
import org.junit.Assert;
import org.junit.Test;

public class ErrorCodeToStatusTest {

    @Test
    public void test(){
        Assert.assertNotNull(ErrorCodeToStatus.getErrorCodeStatusDefault(ErrorCode.PROCESS));
    }
}
