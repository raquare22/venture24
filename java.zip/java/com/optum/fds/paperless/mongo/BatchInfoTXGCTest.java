package com.optum.fds.paperless.mongo;

import org.junit.Test;
import static org.junit.Assert.*;

public class BatchInfoTXGCTest {

    @Test
    public void testGettersAndSetters() {
        BatchInfoTXGC batchInfoTXGC = new BatchInfoTXGC();

        batchInfoTXGC.setNpi("1234567890");
        assertEquals("1234567890", batchInfoTXGC.getNpi());

        batchInfoTXGC.setExemptionEffectiveStartDate("2023-01-01");
        assertEquals("2023-01-01", batchInfoTXGC.getExemptionEffectiveStartDate());

        batchInfoTXGC.setExemptionEffectiveEndDate("2023-12-31");
        assertEquals("2023-12-31", batchInfoTXGC.getExemptionEffectiveEndDate());

        batchInfoTXGC.setTemplateName("Template1");
        assertEquals("Template1", batchInfoTXGC.getTemplateName());

        batchInfoTXGC.setCycleStartDate("2023-01-01");
        assertEquals("2023-01-01", batchInfoTXGC.getCycleStartDate());

        batchInfoTXGC.setCycleEndDate("2023-12-31");
        assertEquals("2023-12-31", batchInfoTXGC.getCycleEndDate());
    }
}