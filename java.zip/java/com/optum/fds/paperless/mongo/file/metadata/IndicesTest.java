package com.optum.fds.paperless.mongo.file.metadata;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class IndicesTest {
    Indices indices =  new Indices();

    @Test
    public void testGetSetIndices(){
        List<IndexField> indexFieldList = new ArrayList<>();
        indices.setIndexField(indexFieldList);
        assertEquals(new ArrayList<>(), indices.getIndexField());
    }

}
