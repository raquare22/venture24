package com.optum.fds.paperless.mongo.file.metadata;

import com.optum.fds.paperless.domain.service.*;
import com.optum.fds.paperless.mongo.processors.*;
import com.optum.fds.paperless.template.java.impl.Doc360MetadataTemplate;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.logging.log4j.Level;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.Configurator;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;

import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.exception.HttpServerException;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.processing.bean.Document;
import com.optum.fds.paperless.template.java.impl.FDSCloudSearchTermsTemplate;

import static org.mockito.Mockito.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.*;

@UserStory(references = {"US5486815"})
@RunWith(MockitoJUnitRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProcessFileTaskTest {
	private static final Logger LOGGER = LogManager.getLogger(ProcessFileTaskTest.class);

	@Mock
	private static DelegateExecution delegateExecution;

	@Mock
	private ProcessorService processorService;

	@Mock
	private ProcessorMetaData processorMetaData;

	@Mock
	private ErrorMetaData errorMetaData;

	@Mock
	private Document document;
	
	@Mock
	private DocumentMetaData documentMetaData;

	@Mock
	private DocumentMetaDataService documentMetaDataService;

	@Mock
	private SendQueueService sendQueueService;

	@Mock
	private ErrorMetaDataService errorMetaDataService;

	@Mock
	private static ProcessorFileTask processorFileTask = new ProcessorFileTask();

	@Mock
	private ProcessorTaskUtil processorTaskUtil;

	@Mock
	private ProcessorExecutionRecord processorExecutionRecord;

	@Mock
	private ProcessorFileTaskService processorFileTaskService;

	@Mock
	private MongoTemplate mongoTemplate;
	
	@Mock
	FDSCloudSearchTermsTemplate fdsCloudSearchTermsTemplate;

    @Mock
    Doc360MetadataTemplate doc360MetadataTemplate;
	
    @Mock
	private ObjectMapper mapper;

    @Mock
    private ProcessorTransactionService processorTransactionService;

	@InjectMocks
	private ProcessFileTask processFileTask = new ProcessFileTask();

	@Rule
	public TemporaryFolder temporaryFolder = new TemporaryFolder();

	private final String XML_DATA_OK = "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?>\n"
			+ "<Document>\n"
			+ "  <ApplicationID>ETS</ApplicationID>\n"
			+ "  <Datagroup>mult</Datagroup>\n"
			+ "  <FileFormat>PDF</FileFormat>\n"
			+ "  <Indices>"
			+ "    <IndexField>"
			+ "      <idxName>AltId</idxName>"
			+ "      <idxValue>999999999</idxValue>"
			+ "    </IndexField>"
			+ "    <IndexField>"
			+ "      <idxName>createdDate</idxName>"
			+ "      <idxValue>3/1/2023 5:59:44 AM</idxValue>"
			+ "    </IndexField>"
			+ "  </Indices>\n"
			+ "</Document>";
	
	private final String XML_DATA_NPE = "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?>\n"
			+ "<Document>\n"
			+ "  <ApplicationID>ETS</ApplicationID>\n"
			+ "  <Datagroup>mult</Datagroup>\n"
			+ "  <FileFormat>PDF</FileFormat>\n"
			+ "  <Indices />\n"
			+ "</Document>";
	
	private final String XML_DATA_CREATEDATE_VALUE_IS_EMPTY = "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?>\n"
			+ "<Document>\n"
			+ "  <ApplicationID>ETS</ApplicationID>\n"
			+ "  <Datagroup>mult</Datagroup>\n"
			+ "  <FileFormat/>\n"
			+ "  <Indices>"
			+ "    <IndexField>"
			+ "      <idxName>AltId</idxName>"
			+ "      <idxValue>999999999</idxValue>"
			+ "    </IndexField>"
			+ "    <IndexField>"
			+ "      <idxName>createdDate</idxName>"
			+ "      <idxValue />"
			+ "    </IndexField>"
			+ "  </Indices>\n"
			+ "</Document>";

	private final String XML_DATA_CREATEDATE_VALUE_IS_NULL = "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?>\n"
			+ "<Document>\n"
			+ "  <ApplicationID>ETS</ApplicationID>\n"
			+ "  <Datagroup>mult</Datagroup>\n"
			+ "  <FileFormat/>\n"
			+ "  <Indices>"
			+ "    <IndexField>"
			+ "      <idxName>AltId</idxName>"
			+ "      <idxValue>999999999</idxValue>"
			+ "    </IndexField>"
			+ "    <IndexField>"
			+ "      <idxName>createdDate</idxName>"
			+ "    </IndexField>"
			+ "  </Indices>\n"
			+ "</Document>";

	private final String XML_DATA_CREATEDATE_UNEXPECTED_CHARACTER = "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?>\n"
			+ "<Document>\n"
			+ "  <ApplicationID>ETS</ApplicationID>\n"
			+ "  <Datagroup>mult</Datagroup>\n"
			+ "  <FileFormat/>\n"
			+ "  <Indices>"
			+ "    <IndexField>"
			+ "      <idxName>AltId</idxName>"
			+ "      <idxValue>999999999</idxValue>"
			+ "    </IndexField>"
			+ "    <IndexField>"
			+ "      <idxName/ >createdDate</idxName>"
			+ "    </IndexField>"
			+ "  </Indices>\n"
			+ "</Document>";

	private final String XML_DATA_CLOSE_TAG = "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?>\n"
			+ "<Document>\n"
			+ "  <ApplicationID>ETS</ApplicationID>\n"
			+ "  <Datagroup>mult</Datagroup>\n"
			+ "  <FileFormat/>\n"
			+ "  <Indices>"
			+ "    <IndexField>"
			+ "      <idxName>AltId</idxName>"
			+ "      <idxValue>999999999</idxValue>"
			+ "    </IndexField>"
			+ "    <IndexField>"
			+ "      <idxName>createdDate</idxName>"
			+ "      <idxValue>ABCDEF</idxValue>"
			+ "    </IndexField>"
			+ "  </Indices>\n"
			+ "<Document>";

	private final String schemaData = "{\"$schema\": \"http://json-schema.org/draft-07/schema#\",\"type\": \"object\",\"properties\": {\"createdDate\": {\"type\": \"string\",\"minLength\": 1},\"AltId\": {\"type\": \"string\",\"minLength\": 1}}";

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		processFileTask.mapper = new ObjectMapper();
		when(processorFileTaskService.updateProcessorFileTask(any())).thenReturn(new ProcessorFileTask());
		when(processorFileTask.getLocation()).thenReturn(temporaryFolder.getRoot().toString());
		when(processorFileTask.getFileName()).thenReturn("junk.metadata");
		when(processorFileTask.getSummary()).thenReturn(new ProcessorSummary());
		when(processorService.getProcessorMetaData(any(), any())).thenReturn(processorMetaData);
		when(processorMetaData.getProcessConfig()).thenReturn(new HashMap<String, String>());
        when(doc360MetadataTemplate.getDoc360MetadataString(any())).thenReturn("searchTerms");

    }

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testProcessFileTaskWithRequiredFieldsCheckMetadataFileIsEmptyTrue() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		LOGGER.info("testProcessFileTaskWithRequiredFieldsCheckMetadataFileIsEmptyTrue");

		when(processorFileTask.getFileName()).thenReturn("fileNotFound.metadata");

		processFileTask.processFileTaskWithRequiredFields(delegateExecution, processorFileTask);
		assertNotNull(processFileTask);
	}

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testProcessFileTaskWithRequiredFieldClientNameNull() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		LOGGER.info("testProcessFileTaskWithRequiredFieldClientNameNull");

		File file = createFile("junk.metadata", "clientName is null");	
		LOGGER.error("testProcessFileTaskWithRequiredFieldClientNameNull: file.toString()={}", file.toString());

		processFileTask.processFileTaskWithRequiredFields(delegateExecution, processorFileTask);
		assertNotNull(processFileTask);
	}

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testConvertMetadataJsonParseExceptionUnexpectedEOF() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		LOGGER.info("testConvertMetadataJsonParseExceptionUnexpectedEOF");
		when(errorMetaDataService.writeToErrorCollection(any(),any())).thenReturn(errorMetaData);
		File file = createFileEmpty();
		Set<String> errors = new HashSet<> (Arrays.asList("a", "b", "c"));
		Map<String, String> message = new HashMap<>();
		processFileTask.convertMetadata(processorFileTask, file, errors, "clientName", processorExecutionRecord, message);
		assertNotNull(processFileTask);
	}

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testConvertMetadataToMapOK() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		LOGGER.info("testConvertMetadataToMapOK");
		File file = createFile("junk.metadata", XML_DATA_OK);
		Map<String, String> message = new HashMap<String, String>();
		Map<String, String> map = processFileTask.convertMetadataToMap(processorFileTask, file, processorExecutionRecord, message);
		LOGGER.error("testConvertMetadataToMapOK: map={}", map);
		assertEquals(2, map.size());
	}

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testConvertMetadataToMapNPE() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		LOGGER.info("testConvertMetadataToMapNPE");
		File file = createFile("junk.metadata", XML_DATA_NPE);
		Map<String, String> message = new HashMap<String, String>();
		Map<String, String> map = processFileTask.convertMetadataToMap(processorFileTask, file, processorExecutionRecord, message);
		LOGGER.error("testConvertMetadataToMapNPE: map={}", map);
		assertTrue(map.isEmpty());
	}

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testConvertMetadataToMapFileEmpty() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		LOGGER.info("testConvertMetadataToMapFileEmpty");
		File file = createFileEmpty();
		LOGGER.error("testConvertMetadataToMapFileEmpty: file.toString()={}", file.toString());
		Map<String, String> message = new HashMap<String, String>();
		Map<String, String> map = processFileTask.convertMetadataToMap(processorFileTask, file, processorExecutionRecord, message);
		LOGGER.error("testConvertMetadataToMapFileEmpty: map={}", map);
		assertTrue(map.isEmpty());
	}

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testConvertMetadataToMapCreateDateValueIsEmpty() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		LOGGER.info("testConvertMetadataToMapCreateDateValueIsEmpty");
		File file = createFile("valueEmpty.metadata", XML_DATA_CREATEDATE_VALUE_IS_EMPTY);
		Map<String, String> message = new HashMap<String, String>();
		Map<String, String> map = processFileTask.convertMetadataToMap(processorFileTask, file, processorExecutionRecord, message);
		LOGGER.error("testConvertMetadataToMapCreateDateValueIsEmpty: map={}", map);
		assertEquals(2, map.size());
	}

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testConvertMetadataToMapCreateDateValueIsNull() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		LOGGER.info("testConvertMetadataToMapCreateDateValueIsNull");
		File file = createFile("valueNull.metadata", XML_DATA_CREATEDATE_VALUE_IS_NULL);
		Map<String, String> message = new HashMap<String, String>();
		Map<String, String> map = processFileTask.convertMetadataToMap(processorFileTask, file, processorExecutionRecord, message);
		LOGGER.error("testConvertMetadataToMapCreateDateValueIsNull: map={}", map);
		assertEquals(2, map.size());
	}

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testConvertMetadataToMapCreateDateUnexpectedCharacter() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		LOGGER.info("testConvertMetadataToMapCreateDateUnexpectedCharacter");
		File file = createFile("valueNull.metadata", XML_DATA_CREATEDATE_UNEXPECTED_CHARACTER);
		Map<String, String> message = new HashMap<String, String>();
		Map<String, String> map = processFileTask.convertMetadataToMap(processorFileTask, file, processorExecutionRecord, message);
		LOGGER.error("testConvertMetadataToMapCreateDateUnexpectedCharacter: map={}", map);
		assertTrue(map.isEmpty());
	}

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testConvertMetadataToMapCloseTag() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		LOGGER.info("testConvertMetadataToMapCloseTag");
		File file = createFile("valueNull.metadata", XML_DATA_CLOSE_TAG);
		Map<String, String> message = new HashMap<String, String>();
		Map<String, String> map = processFileTask.convertMetadataToMap(processorFileTask, file, processorExecutionRecord, message);
		LOGGER.error("testConvertMetadataToMapCloseTag: map={}", map);
		assertTrue(map.isEmpty());
	}

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testConvertMetadataToMapFileNPE() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		LOGGER.info("testConvertMetadataToMapFileNPE");
		Map<String, String> message = new HashMap<String, String>();
		Map<String, String> map = processFileTask.convertMetadataToMap(processorFileTask, null, processorExecutionRecord, message);
		LOGGER.error("testConvertMetadataToMapFileNPE: map={}", map);
		assertTrue(map.isEmpty());
	}

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testProcessFileTaskWithRequiredFieldsSchemaThrowable() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		LOGGER.info("testProcessFileTaskWithRequiredFieldsSchemaThrowable");
		processFileTask.mapper = new ObjectMapper();
		processFileTask.schemaFileBasePath = temporaryFolder.getRoot().getPath() + "/";
		LOGGER.info("testProcessFileTaskWithRequiredFieldsSchemaThrowable: processFileTask.schemaFileBasePath={}", processFileTask.schemaFileBasePath);
		File file = createFile("UHCWest_client_schema.json", schemaData);

		when(processorMetaData.getProcessConfig()).thenReturn(new HashMap<String, String>(){{put("clientName", "UHCWest");}});
		createFile("junk.metadata", XML_DATA_OK);
		LOGGER.error("testProcessFileTaskWithRequiredFieldsSchemaThrowable: file.toString()={}", file.toString());

		try {
			processFileTask.processFileTaskWithRequiredFields(delegateExecution, processorFileTask);
		} catch(NoSuchMethodError e) {
		}
		assertNotNull(processFileTask);
	}

	@UserStory(references = {"US5486815"})
	@RallyTestCase(references = {"TC3435410"})
	@Test
	public void testProcessFileTaskWithRequiredFieldsSchemaNotFound() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		processFileTask.mapper = new ObjectMapper();
		createFile("UHCWest_client_schema.json", schemaData);
		when(processorMetaData.getProcessConfig()).thenReturn(new HashMap<String, String>(){{put("clientName", "UHCWest");}});
		createFile("junk.metadata", XML_DATA_OK);
		try {
			processFileTask.processFileTaskWithRequiredFields(delegateExecution, processorFileTask);
		} catch(NoSuchMethodError e) {
		}
		assertNotNull(processFileTask);
	}

	@Test
	public void testSetCreatedAndExpiryDate() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		Map<String, Object> convertedMetaData = new HashMap<>();
		processFileTask.fDSRetentionPeriod = 1;
		processFileTask.setCreatedAndExpiryDate(convertedMetaData);
		assertNotNull(processFileTask);
	}

	@Test
	public void testValidateMetadataFileErrorsIsEmpty() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		Set<String> errors = new HashSet<String>();
		Map<String, Object> convertedMetaData = new HashMap<>();
		Map<String, String> message = new HashMap<>();
		processFileTask.validateMetadataFileErrors(processorFileTask, errors, convertedMetaData, message, processorExecutionRecord);
		assertNotNull(processFileTask);
	}

	@Test
	public void testValidateMetadataFileErrors() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		Set<String> errors = new HashSet<> (Arrays.asList("a", "b", "c"));
		Map<String, Object> convertedMetaData = new HashMap<>();
		Map<String, String> message = new HashMap<>();
		processFileTask.validateMetadataFileErrors(processorFileTask, errors, convertedMetaData, message, processorExecutionRecord);
		assertNotNull(processFileTask);
	}

	@Test
	public void testUpdateProcessorFileTaskWithPostDocumentToMongoResultInsertDocumentNull() throws Exception {
		Map<String, String> message = new HashMap<>();
		processFileTask.updateProcessorFileTaskWithPostDocumentToMongoResult(processorFileTask, documentMetaData, processorExecutionRecord, message);
		assertNotNull(processFileTask);
	}

	@Test
	public void testUpdateProcessorFileTaskWithPostDocumentToMongoResultInsertDocumentOK() throws Exception {
		Map<String, String> message = new HashMap<>();
		when(documentMetaData.getId()).thenReturn("data");
		processFileTask.updateProcessorFileTaskWithPostDocumentToMongoResult(processorFileTask, documentMetaData, processorExecutionRecord, message);
		assertNotNull(processFileTask);
	}

	@Test
	public void testPostDocumentToFDSaddSendDocumentRequestToFdsTrue() throws Exception {
		when(sendQueueService.addSendDocumentRequestToFds(any(), any(), any(), any(), any(), any(), any())).thenReturn(true);
		document = getDocument();
		documentMetaData = new DocumentMetaData();
		documentMetaData.setMetadata(getMetadata());
		processFileTask.mapper = new ObjectMapper();
		processFileTask.postDocumentToFDS(processorFileTask, "filePath", documentMetaData, processorMetaData);
		assertNotNull(processFileTask);
	}

	@Test
	public void testPostDocumentToFDSaddSendDocumentRequestToFdsFalse() throws Exception {
		when(fdsCloudSearchTermsTemplate.getSearchTermsString(any())).thenReturn("searchTerms");
		when(sendQueueService.addSendDocumentRequestToFds(any(), any(), any(), any(), any(), any(), any())).thenReturn(false);
		document = getDocument();
		documentMetaData = new DocumentMetaData();
		documentMetaData.setMetadata(getMetadata());
		processFileTask.mapper = new ObjectMapper();
		processFileTask.postDocumentToFDS(processorFileTask, "filePath", documentMetaData, processorMetaData);
		assertNotNull(processFileTask);
	}

	@Test
	public void testPostDocumentToFDSaddSendDocumentRequestToFdsThrowHttpServerException() throws Exception {
		when(sendQueueService.addSendDocumentRequestToFds(any(), any(), any(), any(), any(), any(), any())).thenThrow(new HttpServerException("TEST"));
		document = getDocument();
		documentMetaData = new DocumentMetaData();
		documentMetaData.setMetadata(getMetadata());
		processFileTask.mapper = new ObjectMapper();
		processFileTask.postDocumentToFDS(processorFileTask, "filePath", documentMetaData, processorMetaData);
		assertNotNull(processFileTask);
	}

	@Test
	public void testSetDocumentStatus() throws Exception {
		Map<String, Object> convertedMetaData = new HashMap<>();
		when(processorFileTask.getStatus()).thenReturn(MetaDataStatus.SEVERE_ERROR);
		processFileTask.mapper = new ObjectMapper();
		processFileTask.setDocumentStatus(processorFileTask, convertedMetaData);
		assertNotNull(processFileTask);
	}

	@Test
	public void testSetDocumentStatusNotSevere() throws Exception {
		Map<String, Object> convertedMetaData = new HashMap<>();
		when(processorFileTask.getStatus()).thenReturn(MetaDataStatus.ERROR);
		processFileTask.mapper = new ObjectMapper();
		processFileTask.setDocumentStatus(processorFileTask, convertedMetaData);
		assertNotNull(processFileTask);
	}

	@Test
	public void testAddErrorCodeAndEndTime() throws Exception {
		processFileTask.mapper = new ObjectMapper();
		processFileTask.addErrorCodeAndEndTime(processorFileTask, "logMsg", ProcessorErrorCode.EMPTY_METADATA_FILE);
		assertNotNull(processFileTask);
	}

	@Test
	public void testGetClassFromClientNameException() throws Exception {
		@SuppressWarnings("rawtypes")
		Class clazz = processFileTask.getClassFromClientName("className");
		assertNull(clazz);
	}

	@Test
	public void testGetErrEnumFromClientNameException() throws Exception {
		@SuppressWarnings("rawtypes")
		Class clazz = processFileTask.getErrEnumFromClientName("className");
		assertNull(clazz);
	}
	
	
	@Test
    public void testPostDocumentToDoc360_success() throws Exception {
        
		when(processorFileTask.getId()).thenReturn("taskId");
        when(processorFileTask.getAppIdentifier()).thenReturn("appId");
        when(documentMetaData.getId()).thenReturn("docId");
        when(processorMetaData.getConfigSpaceId()).thenReturn(123);
        HashMap<String, Object> config = new HashMap<>();
        config.put("docClass", "testClass");
        when(processorMetaData.getProcessConfig()).thenReturn(config);
        when(documentMetaData.getMetadata()).thenReturn(new org.bson.Document());
        when(sendQueueService.addSendDocumentRequestToDoc360(anyInt(), anyString(), anyString(), anyString(), any(), any(), any())).thenReturn(true);
        
        processFileTask.postDocumentToDoc360(processorFileTask, "filePath", documentMetaData, processorMetaData);
        verify(sendQueueService, times(1)).addSendDocumentRequestToDoc360(anyInt(), anyString(), anyString(), anyString(), any(), any(), any());
    }

	public org.bson.Document getMetadata() throws Exception {
    	org.bson.Document metadata = new org.bson.Document();
    	metadata.put("createApplication", "ELGS");
    	metadata.put("tin", "1234567");
    	metadata.put("mpin", "1234567");
    	metadata.put("createdDate", "2023-02-01T12:00:00.000Z");
    	metadata.put("expiryDate", "2023-07-19T12:38:43.204Z");
    	metadata.put("category", "Claim");
    	metadata.put("subCategory", "C1");
    	metadata.put("filePath", "Commercial/Additional Info Needed");
    	metadata.put("emailAlertReq", "Y");
    	metadata.put("policyNumber", "9F5633");
    	metadata.put("providerName", "PENNY S TURTEL MD");
    	metadata.put("PatientName", "LAUREN LUCAS");
    	metadata.put("patientAccountNumber", "943818795");
    	metadata.put("memberName", "LIONEL LUCAS");
    	metadata.put("claimNumber", "CV61054877");
        metadata.put("MemberAltID", "943818795");    	
    	return metadata;
    }
	
	public Document getDocument() {
		Document document = new Document();
		Map<String, Object> metadata = new HashMap<>();
		metadata.put("createApplication", "ELGS");
    	metadata.put("tin", "1234567");
    	metadata.put("mpin", "1234567");
    	metadata.put("expiryDate", "2023-07-19T12:38:43.204Z");
    	metadata.put("category", "Claim");
    	metadata.put("subCategory", "C1");
    	metadata.put("filePath", "Commercial/Additional Info Needed");
    	metadata.put("emailAlertReq", "Y");
    	metadata.put("policyNumber", "9F5633");
    	metadata.put("providerName", "PENNY S TURTEL MD");
    	metadata.put("PatientName", "LAUREN LUCAS");
    	metadata.put("patientAccountNumber", "943818795");
    	metadata.put("memberName", "LIONEL LUCAS");
    	metadata.put("claimNumber", "CV61054877");
        metadata.put("MemberAltID", "943818795");   
        
        document.setMetadata(metadata);
        document.setId("id");
        return document;
	}


	private File createFileEmpty() throws Exception {
		File file = null;
		try
		{
			file = temporaryFolder.newFile("junk.metadata");
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		return file;
	}

	private File createFile(String fileName, String data) throws Exception {
		File file = null;
		try
		{
			file = temporaryFolder.newFile(fileName);
			BufferedWriter output = new BufferedWriter(new FileWriter(file));
			output.write(data);
			output.close();
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
		return file;
	}

    @Test
    public void testProcessFileTaskWithRequiredFields_shouldAddUnknownErrorAndReturn_whenInitSetsFatalError() throws Exception {
        ProcessFileTask processFileTaskSpy = org.mockito.Mockito.spy(processFileTask);

        ProcessorFileTask realProcessorFileTask = new ProcessorFileTask();
        realProcessorFileTask.setId("pft-123");
        realProcessorFileTask.setFileName("sample.pdf");
        realProcessorFileTask.setSummary(new ProcessorSummary());

        doAnswer(invocation -> {
            ProcessorFileTask arg = invocation.getArgument(0);
            arg.setStatus(MetaDataStatus.FATAL_ERROR);
            return null;
        }).when(processFileTaskSpy).initProcessorFileTask(realProcessorFileTask);

        doNothing().when(processFileTaskSpy).addErrorCodeAndEndTime(
                realProcessorFileTask,
                "initProcessorFileTask",
                ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS
        );

        processFileTaskSpy.processFileTaskWithRequiredFields(delegateExecution, realProcessorFileTask);

        verify(processFileTaskSpy).initProcessorFileTask(realProcessorFileTask);
        verify(processFileTaskSpy).addErrorCodeAndEndTime(
                realProcessorFileTask,
                "initProcessorFileTask",
                ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS
        );

        verifyNoInteractions(processorService, documentMetaDataService, sendQueueService, errorMetaDataService);
    }

    @Test
    public void testProcessFileTaskWithRequiredFields_shouldReturnAfterCheckIfFilesExist_whenStatusBecomesFatalError() throws Exception {
        ProcessFileTask processFileTaskSpy = spy(processFileTask);

        ProcessorFileTask realProcessorFileTask = new ProcessorFileTask();
        realProcessorFileTask.setId("pft-404");
        realProcessorFileTask.setFileName("missing.pdf");
        realProcessorFileTask.setLocation(temporaryFolder.getRoot().getAbsolutePath());
        realProcessorFileTask.setConfigSpaceId(1);
        realProcessorFileTask.setSummary(new ProcessorSummary());

        doAnswer(invocation -> {
            ProcessorFileTask arg = invocation.getArgument(0);
            arg.setStatus(MetaDataStatus.IN_PROCESS);
            return null;
        }).when(processFileTaskSpy).initProcessorFileTask(realProcessorFileTask);

        processFileTaskSpy.processFileTaskWithRequiredFields(delegateExecution, realProcessorFileTask);

        assertEquals(MetaDataStatus.FATAL_ERROR, realProcessorFileTask.getStatus());
        assertNotNull(realProcessorFileTask.getSummary());
        assertNotNull(realProcessorFileTask.getSummary().getErrorList());
        assertFalse(realProcessorFileTask.getSummary().getErrorList().isEmpty());
        assertEquals(
                ProcessorErrorCode.FILE_NOT_FOUND.getErrorCode(),
                realProcessorFileTask.getSummary().getErrorList().get(0).getErrorCode()
        );

        verify(processFileTaskSpy).initProcessorFileTask(realProcessorFileTask);
        verify(processFileTaskSpy).checkIfFilesExist(
                eq(realProcessorFileTask),
                any(ProcessorExecutionRecord.class),
                any(File.class),
                any(File.class)
        );

        verify(processFileTaskSpy, never())
                .checkMetadataFileIsEmpty(any(ProcessorFileTask.class), any(File.class), any(ProcessorExecutionRecord.class));

        verifyNoInteractions(processorService, documentMetaDataService, sendQueueService, errorMetaDataService);
    }

    private ProcessorFileTask createRealProcessorFileTask(String baseName) throws Exception {
        File dir = temporaryFolder.newFolder(baseName);

        File pdfFile = new File(dir, baseName + ".pdf");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(pdfFile))) {
            writer.write("pdf-content");
        }

        File metadataFile = new File(dir, baseName + ".metadata");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(metadataFile))) {
            writer.write("metadata-content");
        }

        ProcessorFileTask task = new ProcessorFileTask();
        task.setId("task-" + baseName);
        task.setFileName(baseName + ".pdf");
        task.setLocation(dir.getAbsolutePath());
        task.setProcessorId("processor-1");
        task.setProcessorTransactionId("txn-1");
        task.setAppIdentifier("app-1");
        task.setClientId(101);
        task.setConfigSpaceId(1);
        task.setSummary(new ProcessorSummary());
        task.setStatus(MetaDataStatus.IN_PROCESS);
        return task;
    }

    private ProcessorMetaData createProcessorMetaData(Map<String, Object> config, Integer spaceId) {
        ProcessorMetaData pmd = mock(ProcessorMetaData.class);
        when(pmd.getProcessConfig()).thenReturn(config);
        when(pmd.getConfigSpaceId()).thenReturn(spaceId);
        return pmd;
    }

    @Test
    public void testProcessFileTaskWithRequiredFields_shouldReturn_whenConvertJsonMetadataToMapSetsFatal() throws Exception {
        ProcessFileTask spyTask = spy(processFileTask);
        ProcessorFileTask task = createRealProcessorFileTask("fatal-after-convert");

        Map<String, Object> config = new HashMap<>();
        config.put("clientName", "TestClient");
        config.put("sendToDoc360", false);

        ProcessorMetaData pmd = createProcessorMetaData(config, 1001);
        when(processorService.getProcessorMetaData("processor-1", "app-1")).thenReturn(pmd);

        JSONObject jsonMetadata = new JSONObject().put("metadata", new JSONObject().put("k", "v"));

        doNothing().when(spyTask).initProcessorFileTask(task);
        doReturn(jsonMetadata).when(spyTask)
                .convertMetadata(eq(task), any(File.class), any(), eq("TestClient"), any(ProcessorExecutionRecord.class), any());

        doAnswer(invocation -> {
            task.setStatus(MetaDataStatus.FATAL_ERROR);
            return new HashMap<String, Object>();
        }).when(spyTask).convertJsonMetadataToMap(eq(task), eq(jsonMetadata), any(), any(ProcessorExecutionRecord.class));

        spyTask.processFileTaskWithRequiredFields(delegateExecution, task);

        verify(spyTask, never()).validateMetadataFileErrors(any(), any(), any(), any(), any());
        verify(spyTask, never()).setCreatedAndExpiryDate(any());
        verify(spyTask, never()).saveDocumentToMongo(any(), any());
        verify(spyTask, never()).postDocumentToFDS(any(), anyString(), any(), any());
        verify(spyTask, never()).postDocumentToDoc360(any(), anyString(), any(), any());
    }

    @Test
    public void testProcessFileTaskWithRequiredFields_shouldReturn_whenValidationSetsFatal() throws Exception {
        ProcessFileTask spyTask = spy(processFileTask);
        ProcessorFileTask task = createRealProcessorFileTask("fatal-after-validation");

        Map<String, Object> config = new HashMap<>();
        config.put("clientName", "TestClient");
        config.put("sendToDoc360", false);

        ProcessorMetaData pmd = createProcessorMetaData(config, 1002);
        when(processorService.getProcessorMetaData("processor-1", "app-1")).thenReturn(pmd);

        JSONObject jsonMetadata = new JSONObject().put("metadata", new JSONObject().put("field", "value"));
        Map<String, Object> converted = new HashMap<>();
        converted.put("field", "value");

        doNothing().when(spyTask).initProcessorFileTask(task);
        doReturn(jsonMetadata).when(spyTask)
                .convertMetadata(eq(task), any(File.class), any(), eq("TestClient"), any(ProcessorExecutionRecord.class), any());
        doReturn(converted).when(spyTask)
                .convertJsonMetadataToMap(eq(task), eq(jsonMetadata), any(), any(ProcessorExecutionRecord.class));

        doAnswer(invocation -> {
            task.setStatus(MetaDataStatus.FATAL_ERROR);
            return null;
        }).when(spyTask).validateMetadataFileErrors(eq(task), any(), eq(converted), any(), any(ProcessorExecutionRecord.class));

        spyTask.processFileTaskWithRequiredFields(delegateExecution, task);

        verify(spyTask).validateMetadataFileErrors(eq(task), any(), eq(converted), any(), any(ProcessorExecutionRecord.class));
        verify(spyTask, never()).setCreatedAndExpiryDate(any());
        verify(spyTask, never()).saveDocumentToMongo(any(), any());
        verify(spyTask, never()).postDocumentToFDS(any(), anyString(), any(), any());
        verify(spyTask, never()).postDocumentToDoc360(any(), anyString(), any(), any());
    }

    @Test
    public void testProcessFileTaskWithRequiredFields_shouldPopulateZipFieldsAndPostToDoc360_forUSPClaims() throws Exception {
        ProcessFileTask spyTask = spy(processFileTask);
        ProcessorFileTask task = createRealProcessorFileTask("uspclaims-doc360");

        Map<String, Object> config = new HashMap<>();
        config.put("clientName", "USPClaims");
        config.put("sendToDoc360", true);
        config.put("docClass", "CLAIM");

        ProcessorMetaData pmd = createProcessorMetaData(config, 1003);
        when(processorService.getProcessorMetaData("processor-1", "app-1")).thenReturn(pmd);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setFileName("batch-001.zip");
        txn.setDateCreated(new Date());
        when(processorTransactionService.getProcessTransactionInfoByTransactionId("txn-1")).thenReturn(txn);

        JSONObject jsonMetadata = new JSONObject().put("metadata", new JSONObject().put("memberId", "M1"));
        Map<String, Object> converted = new HashMap<>();
        converted.put("memberId", "M1");

        DocumentMetaData inserted = new DocumentMetaData();
        inserted.setId("doc-123");

        doNothing().when(spyTask).initProcessorFileTask(task);
        doReturn(jsonMetadata).when(spyTask)
                .convertMetadata(eq(task), any(File.class), any(), eq("USPClaims"), any(ProcessorExecutionRecord.class), any());
        doReturn(converted).when(spyTask)
                .convertJsonMetadataToMap(eq(task), eq(jsonMetadata), any(), any(ProcessorExecutionRecord.class));
        doNothing().when(spyTask)
                .validateMetadataFileErrors(eq(task), any(), eq(converted), any(), any(ProcessorExecutionRecord.class));
        doNothing().when(spyTask).setCreatedAndExpiryDate(converted);
        when(documentMetaDataService.saveDocumentMetaData(any(DocumentMetaData.class))).thenReturn(inserted);
        doNothing().when(spyTask)
                .updateProcessorFileTaskWithPostDocumentToMongoResult(eq(task), eq(inserted), any(ProcessorExecutionRecord.class), any());
        doNothing().when(spyTask).postDocumentToDoc360(eq(task), anyString(), eq(inserted), eq(pmd));

        spyTask.processFileTaskWithRequiredFields(delegateExecution, task);

        assertNotNull(task.getMetadata());
        assertEquals("batch-001.zip", task.getMetadata().get("zipFileName"));
        assertEquals(txn.getDateCreated(), task.getMetadata().get("zipFileCreatedDate"));
        assertEquals(task.getFileName(), task.getMetadata().get("fileName"));
        assertEquals("doc-123", task.getTargetId());

        verify(spyTask).postDocumentToDoc360(eq(task), anyString(), eq(inserted), eq(pmd));
        verify(spyTask, never()).postDocumentToFDS(any(), anyString(), any(), any());
    }

    @Test
    public void testProcessFileTaskWithRequiredFields_shouldPostToFds_andSetSuccessOutcome_forNonUSPClaims() throws Exception {
        ProcessFileTask spyTask = spy(processFileTask);
        ProcessorFileTask task = createRealProcessorFileTask("non-uspclaims-fds");

        Map<String, Object> config = new HashMap<>();
        config.put("clientName", "OtherClient");
        config.put("sendToDoc360", false);

        ProcessorMetaData pmd = createProcessorMetaData(config, 1004);
        when(processorService.getProcessorMetaData("processor-1", "app-1")).thenReturn(pmd);

        JSONObject jsonMetadata = new JSONObject().put("metadata", new JSONObject().put("claimNumber", "C123"));
        Map<String, Object> converted = new HashMap<>();
        converted.put("claimNumber", "C123");

        DocumentMetaData inserted = new DocumentMetaData();
        inserted.setId("doc-456");

        final String[] capturedOutcome = new String[1];

        doNothing().when(spyTask).initProcessorFileTask(task);
        doReturn(jsonMetadata).when(spyTask)
                .convertMetadata(eq(task), any(File.class), any(), eq("OtherClient"), any(ProcessorExecutionRecord.class), any());
        doReturn(converted).when(spyTask)
                .convertJsonMetadataToMap(eq(task), eq(jsonMetadata), any(), any(ProcessorExecutionRecord.class));
        doNothing().when(spyTask)
                .validateMetadataFileErrors(eq(task), any(), eq(converted), any(), any(ProcessorExecutionRecord.class));
        doNothing().when(spyTask).setCreatedAndExpiryDate(converted);
        when(documentMetaDataService.saveDocumentMetaData(any(DocumentMetaData.class))).thenReturn(inserted);

        doAnswer(invocation -> {
            Map<String, String> message = invocation.getArgument(3);
            capturedOutcome[0] = message.get("outcome");
            return null;
        }).when(spyTask).updateProcessorFileTaskWithPostDocumentToMongoResult(
                eq(task), eq(inserted), any(ProcessorExecutionRecord.class), any());

        doNothing().when(spyTask).postDocumentToFDS(eq(task), anyString(), eq(inserted), eq(pmd));

        spyTask.processFileTaskWithRequiredFields(delegateExecution, task);

        assertEquals("MetaData Posted Sucessfully to Mongo", capturedOutcome[0]);
        assertFalse(task.getMetadata().containsKey("zipFileName"));
        assertFalse(task.getMetadata().containsKey("zipFileCreatedDate"));

        verify(spyTask).postDocumentToFDS(eq(task), anyString(), eq(inserted), eq(pmd));
        verify(spyTask, never()).postDocumentToDoc360(any(), anyString(), any(), any());
    }

    @Test
    public void testProcessFileTaskWithRequiredFields_shouldNotSetSuccessOutcome_whenStatusIsCompleteWithErrors() throws Exception {
        ProcessFileTask spyTask = spy(processFileTask);
        ProcessorFileTask task = createRealProcessorFileTask("complete-with-errors");

        Map<String, Object> config = new HashMap<>();
        config.put("clientName", "OtherClient");
        config.put("sendToDoc360", false);

        ProcessorMetaData pmd = createProcessorMetaData(config, 1005);
        when(processorService.getProcessorMetaData("processor-1", "app-1")).thenReturn(pmd);

        JSONObject jsonMetadata = new JSONObject().put("metadata", new JSONObject().put("claimNumber", "C999"));
        Map<String, Object> converted = new HashMap<>();
        converted.put("claimNumber", "C999");

        DocumentMetaData inserted = new DocumentMetaData();
        inserted.setId("doc-789");

        final boolean[] successMessagePresent = new boolean[1];

        doNothing().when(spyTask).initProcessorFileTask(task);
        doReturn(jsonMetadata).when(spyTask)
                .convertMetadata(eq(task), any(File.class), any(), eq("OtherClient"), any(ProcessorExecutionRecord.class), any());
        doReturn(converted).when(spyTask)
                .convertJsonMetadataToMap(eq(task), eq(jsonMetadata), any(), any(ProcessorExecutionRecord.class));

        doAnswer(invocation -> {
            task.setStatus(MetaDataStatus.COMPLETE_WITH_ERRORS);
            return null;
        }).when(spyTask).validateMetadataFileErrors(eq(task), any(), eq(converted), any(), any(ProcessorExecutionRecord.class));

        doNothing().when(spyTask).setCreatedAndExpiryDate(converted);
        when(documentMetaDataService.saveDocumentMetaData(any(DocumentMetaData.class))).thenReturn(inserted);

        doAnswer(invocation -> {
            Map<String, String> message = invocation.getArgument(3);
            successMessagePresent[0] = message.containsKey("outcome");
            return null;
        }).when(spyTask).updateProcessorFileTaskWithPostDocumentToMongoResult(
                eq(task), eq(inserted), any(ProcessorExecutionRecord.class), any());

        doNothing().when(spyTask).postDocumentToFDS(eq(task), anyString(), eq(inserted), eq(pmd));

        spyTask.processFileTaskWithRequiredFields(delegateExecution, task);

        assertFalse(successMessagePresent[0]);
        verify(spyTask).postDocumentToFDS(eq(task), anyString(), eq(inserted), eq(pmd));
        verify(spyTask, never()).postDocumentToDoc360(any(), anyString(), any(), any());
    }

    @Test
    public void testValidateMetadataFileErrors_whenErrorsContainSevere_shouldSetSevereAndStopProcessing() {
        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-severe");
        realTask.setConfigSpaceId(1);
        realTask.setSummary(new ProcessorSummary());
        realTask.setStatus(MetaDataStatus.IN_PROCESS);

        Set<String> errors = new HashSet<>(Arrays.asList("FIELD_A_SEVERE", "FIELD_B"));
        Map<String, Object> convertedMetaData = new HashMap<>();
        Map<String, String> message = new HashMap<>();
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();

        processFileTask.validateMetadataFileErrors(
                realTask,
                errors,
                convertedMetaData,
                message,
                executionRecord
        );

        assertEquals(MetaDataStatus.SEVERE_ERROR, realTask.getStatus());
        assertEquals(Boolean.TRUE, convertedMetaData.get("stopProcessing"));
        assertNotNull(realTask.getSummary());
        assertNotNull(realTask.getSummary().getErrorList());
        assertEquals(2, realTask.getSummary().getErrorList().size());
        assertEquals("Metadata validation failed.", message.get("outcome"));
        assertEquals(
                ProcessorErrorCode.REQUIRED_METADATA_FIELDS_MISSING.getErrorMessage(),
                message.get("error")
        );

        verify(processorFileTaskService, times(1)).updateProcessorFileTask(any(ProcessorFileTask.class));
    }

    @Test
    public void testValidateMetadataFileErrors_whenErrorsDoNotContainSevere_shouldSetCompleteWithErrors() {
        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-complete-with-errors");
        realTask.setConfigSpaceId(1);
        realTask.setSummary(new ProcessorSummary());
        realTask.setStatus(MetaDataStatus.IN_PROCESS);

        Set<String> errors = new HashSet<>(Arrays.asList("FIELD_A_MISSING", "FIELD_B_MISSING"));
        Map<String, Object> convertedMetaData = new HashMap<>();
        Map<String, String> message = new HashMap<>();
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();

        processFileTask.validateMetadataFileErrors(
                realTask,
                errors,
                convertedMetaData,
                message,
                executionRecord
        );

        assertEquals(MetaDataStatus.COMPLETE_WITH_ERRORS, realTask.getStatus());
        assertFalse(convertedMetaData.containsKey("stopProcessing"));
        assertNotNull(realTask.getSummary());
        assertNotNull(realTask.getSummary().getErrorList());
        assertEquals(2, realTask.getSummary().getErrorList().size());
        assertEquals("Metadata validation failed.", message.get("outcome"));
        assertEquals(
                ProcessorErrorCode.REQUIRED_METADATA_FIELDS_MISSING.getErrorMessage(),
                message.get("error")
        );

        verify(processorFileTaskService, times(1)).updateProcessorFileTask(any(ProcessorFileTask.class));
    }

    @Test
    public void testValidateMetadataFileErrors_whenErrorsEmpty_shouldKeepSuccessPath() {
        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-success");
        realTask.setConfigSpaceId(1);
        realTask.setSummary(new ProcessorSummary());
        realTask.setStatus(MetaDataStatus.IN_PROCESS);

        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetaData = new HashMap<>();
        Map<String, String> message = new HashMap<>();
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();

        processFileTask.validateMetadataFileErrors(
                realTask,
                errors,
                convertedMetaData,
                message,
                executionRecord
        );

        assertEquals(MetaDataStatus.IN_PROCESS, realTask.getStatus());
        assertEquals("Metadata Validated sucessfully.", message.get("outcome"));
        assertNull(message.get("error"));
        assertTrue(realTask.getSummary().getErrorList() == null || realTask.getSummary().getErrorList().isEmpty());

        verify(processorFileTaskService, times(1)).updateProcessorFileTask(any(ProcessorFileTask.class));
    }

    @Test
    public void testConvertJsonMetadataToMap_whenJsonMetadataIsNotNull_shouldReturnConvertedMap() throws JSONException {
        ProcessFileTask spyTask = spy(processFileTask);

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-convert-ok");
        realTask.setConfigSpaceId(1);
        ProcessorSummary summary = new ProcessorSummary();
        summary.setErrorList(new ArrayList<>());
        realTask.setSummary(summary);

        Map<String, String> message = new HashMap<>();
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();

        JSONObject jsonMetadata = new JSONObject();
        jsonMetadata.put("metadata", new JSONObject()
                .put("claimNumber", "CLM-1001")
                .put("memberId", "MBR-2002"));

        Map<String, Object> result =
                spyTask.convertJsonMetadataToMap(realTask, jsonMetadata, message, executionRecord);

        assertNotNull(result);
        assertEquals("CLM-1001", result.get("claimNumber"));
        assertEquals("MBR-2002", result.get("memberId"));
        assertEquals("Parse metadata file successfull.", message.get("outcome"));

        verify(processorFileTaskService, atLeastOnce()).updateProcessorFileTask(any(ProcessorFileTask.class));
    }

    @Test
    public void testConvertJsonMetadataToMap_whenJsonMetadataIsNullAndErrorListEmpty_shouldUpdateDbAndReturnNull() {
        ProcessFileTask spyTask = spy(processFileTask);

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-null-empty-errors");
        realTask.setConfigSpaceId(1);
        ProcessorSummary summary = new ProcessorSummary();
        summary.setErrorList(new ArrayList<>());
        realTask.setSummary(summary);

        Map<String, String> message = new HashMap<>();
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();

        doNothing().when(spyTask).updateDbWithProcessorError(
                eq(realTask),
                eq(executionRecord),
                any(Map.class),
                eq(ProcessorErrorCode.UNKNOWN_ERROR_READING_FILE)
        );

        Map<String, Object> result =
                spyTask.convertJsonMetadataToMap(realTask, null, message, executionRecord);

        assertNull(result);

        verify(spyTask, times(1)).updateDbWithProcessorError(
                eq(realTask),
                eq(executionRecord),
                any(Map.class),
                eq(ProcessorErrorCode.UNKNOWN_ERROR_READING_FILE)
        );
    }

    @Test
    public void testConvertJsonMetadataToMap_whenJsonMetadataIsNullAndErrorListAlreadyExists_shouldReturnNullWithoutUpdateDb() {
        ProcessFileTask spyTask = spy(processFileTask);

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setConfigSpaceId(1);
        ProcessorSummary summary = new ProcessorSummary();
        summary.addError(new ProcessorError(ProcessorErrorCode.FILE_NOT_FOUND));
        realTask.setSummary(summary);

        Map<String, String> message = new HashMap<>();
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();

        Map<String, Object> result =
                spyTask.convertJsonMetadataToMap(realTask, null, message, executionRecord);

        assertNull(result);

        verify(spyTask, never()).updateDbWithProcessorError(
                any(ProcessorFileTask.class),
                any(ProcessorExecutionRecord.class),
                any(Map.class),
                any(ProcessorErrorCode.class)
        );
    }

    @Test
    public void testSaveDocumentToMongo_whenStatusIsSevereError_shouldPersistSevereErrorStatus() {
        ProcessFileTask spyTask = spy(processFileTask);

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setClientId(101);
        realTask.setAppIdentifier("app-1");
        realTask.setStatus(MetaDataStatus.SEVERE_ERROR);

        Document document = new Document();
        document.setSpaceId(3001);

        Map<String, Object> metadata = new HashMap<>();
        metadata.put("claimNumber", "CLM-SEVERE");
        document.setMetadata(metadata);

        DocumentMetaData savedDocument = new DocumentMetaData();
        savedDocument.setStatus(MetaDataStatus.SEVERE_ERROR);

        when(documentMetaDataService.saveDocumentMetaData(any(DocumentMetaData.class))).thenReturn(savedDocument);

        DocumentMetaData result = spyTask.saveDocumentToMongo(realTask, document);

        assertNotNull(result);

        verify(documentMetaDataService).saveDocumentMetaData(argThat(arg ->
                arg.getSpaceId() == 3001
                        && arg.getClientId() == 101
                        && "app-1".equals(arg.getAppIdentifier())
                        && MetaDataStatus.SEVERE_ERROR.equals(arg.getStatus())
                        && arg.getMetadata() != null
                        && "CLM-SEVERE".equals(arg.getMetadata().getString("claimNumber"))
        ));
    }

    @Test
    public void testSaveDocumentToMongo_whenStatusIsNotSevereError_shouldPersistAvailableStatus() {
        ProcessFileTask spyTask = spy(processFileTask);

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setClientId(202);
        realTask.setAppIdentifier("app-2");
        realTask.setStatus(MetaDataStatus.IN_PROCESS);

        Document document = new Document();
        document.setSpaceId(4002);

        Map<String, Object> metadata = new HashMap<>();
        metadata.put("claimNumber", "CLM-AVAILABLE");
        document.setMetadata(metadata);

        DocumentMetaData savedDocument = new DocumentMetaData();
        savedDocument.setStatus(MetaDataStatus.AVAILABLE);

        when(documentMetaDataService.saveDocumentMetaData(any(DocumentMetaData.class))).thenReturn(savedDocument);

        DocumentMetaData result = spyTask.saveDocumentToMongo(realTask, document);

        assertNotNull(result);

        verify(documentMetaDataService).saveDocumentMetaData(argThat(arg ->
                arg.getSpaceId() == 4002
                        && arg.getClientId() == 202
                        && "app-2".equals(arg.getAppIdentifier())
                        && MetaDataStatus.AVAILABLE.equals(arg.getStatus())
                        && arg.getMetadata() != null
                        && "CLM-AVAILABLE".equals(arg.getMetadata().getString("claimNumber"))
        ));
    }

    @Test
    public void testPostDocumentToFDS_whenMapperThrowsJsonProcessingException_shouldReturnWithoutCallingQueue() throws Exception {
        processFileTask.mapper = mapper;

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-1");
        realTask.setAppIdentifier("app-1");

        DocumentMetaData insertedDocument = new DocumentMetaData();
        insertedDocument.setId("doc-1");
        insertedDocument.setMetadata(new org.bson.Document("claimNumber", "CLM-123"));

        ProcessorMetaData pmd = mock(ProcessorMetaData.class);
        when(pmd.getConfigSpaceId()).thenReturn(123);

        doThrow(new com.fasterxml.jackson.core.JsonProcessingException("json failure") {})
                .when(mapper).writeValueAsString(insertedDocument.getMetadata());

        processFileTask.postDocumentToFDS(realTask, "C:\\temp\\file.pdf", insertedDocument, pmd);

        verify(mapper, times(1)).writeValueAsString(insertedDocument.getMetadata());
        verifyNoInteractions(fdsCloudSearchTermsTemplate);
        verify(sendQueueService, never()).addSendDocumentRequestToFds(
                anyInt(), anyString(), anyString(), anyString(), any(), any(), any());
        verify(errorMetaDataService, never()).writeToMessageServiceErrorCollection(
                anyString(), anyString(), anyString(), anyInt(), anyString(), anyString(), any());
    }

    @Test
    public void testPostDocumentToFDS_whenGetSearchTermsStringThrowsException_shouldReturnWithoutCallingQueue() throws Exception {
        processFileTask.mapper = mapper;

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-search-err");
        realTask.setAppIdentifier("app-1");

        DocumentMetaData insertedDocument = new DocumentMetaData();
        insertedDocument.setId("doc-1");
        insertedDocument.setMetadata(new org.bson.Document("claimNumber", "CLM-123"));

        ProcessorMetaData pmd = mock(ProcessorMetaData.class);
        when(pmd.getConfigSpaceId()).thenReturn(123);

        when(mapper.writeValueAsString(insertedDocument.getMetadata())).thenReturn("{\"claimNumber\":\"CLM-123\"}");
        when(fdsCloudSearchTermsTemplate.getSearchTermsString(insertedDocument.getMetadata()))
                .thenThrow(new RuntimeException("search terms failure"));

        processFileTask.postDocumentToFDS(realTask, "C:\\temp\\file.pdf", insertedDocument, pmd);

        verify(mapper, times(1)).writeValueAsString(insertedDocument.getMetadata());
        verify(fdsCloudSearchTermsTemplate, times(1)).getSearchTermsString(insertedDocument.getMetadata());

        verify(sendQueueService, never()).addSendDocumentRequestToFds(
                anyInt(), anyString(), anyString(), anyString(), any(), any(), any());

        verify(errorMetaDataService, never()).writeToMessageServiceErrorCollection(
                anyString(), anyString(), anyString(), anyInt(), anyString(), anyString(), any());
    }

    @Test
    public void testPostDocumentToDoc360_whenMapperThrowsJsonProcessingException_shouldReturnWithoutCallingQueue() throws Exception {
        processFileTask.mapper = mapper;

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-doc360");
        realTask.setAppIdentifier("app-doc360");

        DocumentMetaData insertedDocument = new DocumentMetaData();
        insertedDocument.setId("doc-360");
        insertedDocument.setMetadata(new org.bson.Document("memberId", "MBR-123"));

        ProcessorMetaData pmd = mock(ProcessorMetaData.class);
        when(pmd.getConfigSpaceId()).thenReturn(456);

        Map<String, Object> config = new HashMap<>();
        config.put("docClass", "TEST_CLASS");
        when(pmd.getProcessConfig()).thenReturn(config);

        doThrow(new com.fasterxml.jackson.core.JsonProcessingException("json failure") {})
                .when(mapper).writeValueAsString(insertedDocument.getMetadata());

        processFileTask.postDocumentToDoc360(realTask, "C:\\temp\\sample.pdf", insertedDocument, pmd);

        verify(mapper, times(1)).writeValueAsString(insertedDocument.getMetadata());

        verify(sendQueueService, never()).addSendDocumentRequestToDoc360(
                anyInt(), anyString(), anyString(), anyString(), any(), any(), any());

        verify(sendQueueService, never()).getPriorityQueue(anyInt());

        verify(errorMetaDataService, never()).writeToMessageServiceErrorCollection(
                anyString(), anyString(), anyString(), anyInt(), anyString(), anyString(), any());
    }

    @Test
    public void testPostDocumentToDoc360_whenAddSendDocumentRequestThrowsHttpServerException_shouldWriteToMessageServiceErrorCollection() throws Exception {
        processFileTask.mapper = mapper;

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-doc360");
        realTask.setAppIdentifier("app-doc360");

        DocumentMetaData insertedDocument = new DocumentMetaData();
        insertedDocument.setId("doc-360");
        insertedDocument.setMetadata(new org.bson.Document("memberId", "MBR-999"));

        ProcessorMetaData pmd = mock(ProcessorMetaData.class);
        when(pmd.getConfigSpaceId()).thenReturn(789);

        Map<String, Object> config = new HashMap<>();
        config.put("docClass", "DOC_CLASS");
        when(pmd.getProcessConfig()).thenReturn(config);

        when(mapper.writeValueAsString(insertedDocument.getMetadata()))
                .thenReturn("{\"memberId\":\"MBR-999\"}");

        when(sendQueueService.addSendDocumentRequestToDoc360(
                anyInt(), anyString(), anyString(), anyString(), any(), any(), any()))
                .thenThrow(new HttpServerException("queue failed"));

        when(sendQueueService.getPriorityQueue(789)).thenReturn("priority-789");

        processFileTask.postDocumentToDoc360(
                realTask,
                "C:\\temp\\doc360.pdf",
                insertedDocument,
                pmd
        );

        verify(sendQueueService, times(1)).addSendDocumentRequestToDoc360(
                eq(789),
                eq("ProcessFileTask"),
                eq("task-doc360"),
                eq("processMetadataFilesCallback"),
                any(),
                any(),
                any()
        );

        verify(sendQueueService, times(1)).getPriorityQueue(789);

        verify(errorMetaDataService, times(1)).writeToMessageServiceErrorCollection(
                eq("priority-789"),
                eq("callRestApiWithMsgServiceOnErrorCallback"),
                eq("task-doc360"),
                eq(789),
                any(Map.class),
                eq("queue failed"),
                eq(MetaDataStatus.AUTOMATIC)
        );
    }

    @Test
    public void testPostDocumentToFDS_whenMapperThrowsJsonProcessingException_shouldReturnWithoutQueueCall() throws Exception {
        processFileTask.mapper = mapper;

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-fds-json");
        realTask.setAppIdentifier("app-fds");

        DocumentMetaData insertedDocument = new DocumentMetaData();
        insertedDocument.setId("doc-fds-json");
        insertedDocument.setMetadata(new org.bson.Document("claimNumber", "CLM-001"));

        ProcessorMetaData pmd = mock(ProcessorMetaData.class);
        when(pmd.getConfigSpaceId()).thenReturn(101);

        doThrow(new com.fasterxml.jackson.core.JsonProcessingException("json error") {})
                .when(mapper).writeValueAsString(insertedDocument.getMetadata());

        processFileTask.postDocumentToFDS(realTask, "C:\\temp\\file.pdf", insertedDocument, pmd);

        verify(mapper).writeValueAsString(insertedDocument.getMetadata());
        verifyNoInteractions(fdsCloudSearchTermsTemplate);
        verify(sendQueueService, never()).addSendDocumentRequestToFds(
                anyInt(), anyString(), anyString(), anyString(), any(), any(), any());
        verify(errorMetaDataService, never()).writeToMessageServiceErrorCollection(
                anyString(), anyString(), anyString(), anyInt(), anyString(), anyString(), any());
    }

    @Test
    public void testPostDocumentToFDS_whenSearchTermsThrowsException_shouldReturnWithoutQueueCall() throws Exception {
        processFileTask.mapper = mapper;

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-fds-search");
        realTask.setAppIdentifier("app-fds");

        DocumentMetaData insertedDocument = new DocumentMetaData();
        insertedDocument.setId("doc-fds-search");
        insertedDocument.setMetadata(new org.bson.Document("claimNumber", "CLM-002"));

        ProcessorMetaData pmd = mock(ProcessorMetaData.class);
        when(pmd.getConfigSpaceId()).thenReturn(102);

        when(mapper.writeValueAsString(insertedDocument.getMetadata()))
                .thenReturn("{\"claimNumber\":\"CLM-002\"}");
        when(fdsCloudSearchTermsTemplate.getSearchTermsString(insertedDocument.getMetadata()))
                .thenThrow(new RuntimeException("search term failure"));

        processFileTask.postDocumentToFDS(realTask, "C:\\temp\\file.pdf", insertedDocument, pmd);

        verify(mapper).writeValueAsString(insertedDocument.getMetadata());
        verify(fdsCloudSearchTermsTemplate).getSearchTermsString(insertedDocument.getMetadata());
        verify(sendQueueService, never()).addSendDocumentRequestToFds(
                anyInt(), anyString(), anyString(), anyString(), any(), any(), any());
        verify(errorMetaDataService, never()).writeToMessageServiceErrorCollection(
                anyString(), anyString(), anyString(), anyInt(), anyString(), anyString(), any());
    }

    @Test
    public void testPostDocumentToFDS_whenQueueThrowsHttpServerException_shouldWriteMessageServiceError() throws Exception {
        processFileTask.mapper = mapper;

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-fds-http");
        realTask.setAppIdentifier("app-fds");

        DocumentMetaData insertedDocument = new DocumentMetaData();
        insertedDocument.setId("doc-fds-http");
        insertedDocument.setMetadata(new org.bson.Document("claimNumber", "CLM-003"));

        ProcessorMetaData pmd = mock(ProcessorMetaData.class);
        when(pmd.getConfigSpaceId()).thenReturn(103);

        when(mapper.writeValueAsString(insertedDocument.getMetadata()))
                .thenReturn("{\"claimNumber\":\"CLM-003\"}");
        when(fdsCloudSearchTermsTemplate.getSearchTermsString(insertedDocument.getMetadata()))
                .thenReturn("search-terms");
        when(sendQueueService.addSendDocumentRequestToFds(
                anyInt(), anyString(), anyString(), anyString(), any(), any(), any()))
                .thenThrow(new HttpServerException("queue failure"));
        when(sendQueueService.getPriorityQueue(103)).thenReturn("priority-103");

        processFileTask.postDocumentToFDS(realTask, "C:\\temp\\file.pdf", insertedDocument, pmd);

        verify(sendQueueService).getPriorityQueue(103);
        verify(errorMetaDataService).writeToMessageServiceErrorCollection(
                eq("priority-103"),
                eq("callRestApiWithMsgServiceOnErrorCallback"),
                eq("task-fds-http"),
                eq(103),
                any(Map.class),
                eq("queue failure"),
                eq(MetaDataStatus.AUTOMATIC)
        );
    }

    @Test
    public void testPostDocumentToDoc360_whenMapperThrowsJsonProcessingException_shouldReturnWithoutQueueCall() throws Exception {
        processFileTask.mapper = mapper;

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-doc360-json");
        realTask.setAppIdentifier("app-doc360");

        DocumentMetaData insertedDocument = new DocumentMetaData();
        insertedDocument.setId("doc-doc360-json");
        insertedDocument.setMetadata(new org.bson.Document("memberId", "MBR-001"));

        ProcessorMetaData pmd = mock(ProcessorMetaData.class);
        when(pmd.getConfigSpaceId()).thenReturn(201);

        Map<String, Object> config = new HashMap<>();
        config.put("docClass", "TEST_CLASS");
        when(pmd.getProcessConfig()).thenReturn(config);

        doThrow(new com.fasterxml.jackson.core.JsonProcessingException("json error") {})
                .when(mapper).writeValueAsString(insertedDocument.getMetadata());

        processFileTask.postDocumentToDoc360(realTask, "C:\\temp\\file.pdf", insertedDocument, pmd);

        verify(mapper).writeValueAsString(insertedDocument.getMetadata());
        verify(sendQueueService, never()).addSendDocumentRequestToDoc360(
                anyInt(), anyString(), anyString(), anyString(), any(), any(), any());
        verify(errorMetaDataService, never()).writeToMessageServiceErrorCollection(
                anyString(), anyString(), anyString(), anyInt(), anyString(), anyString(), any());
    }

    @Test
    public void testPostDocumentToDoc360_whenQueueThrowsHttpServerException_shouldWriteMessageServiceError() throws Exception {
        processFileTask.mapper = mapper;

        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-doc360-http");
        realTask.setAppIdentifier("app-doc360");

        DocumentMetaData insertedDocument = new DocumentMetaData();
        insertedDocument.setId("doc-doc360-http");
        insertedDocument.setMetadata(new org.bson.Document("memberId", "MBR-002"));

        ProcessorMetaData pmd = mock(ProcessorMetaData.class);
        when(pmd.getConfigSpaceId()).thenReturn(202);

        Map<String, Object> config = new HashMap<>();
        config.put("docClass", "DOC_CLASS_A");
        when(pmd.getProcessConfig()).thenReturn(config);

        when(mapper.writeValueAsString(insertedDocument.getMetadata()))
                .thenReturn("{\"memberId\":\"MBR-002\"}");
        when(sendQueueService.addSendDocumentRequestToDoc360(
                anyInt(), anyString(), anyString(), anyString(), any(), any(), any()))
                .thenThrow(new HttpServerException("doc360 queue failure"));
        when(sendQueueService.getPriorityQueue(202)).thenReturn("priority-202");

        processFileTask.postDocumentToDoc360(realTask, "C:\\temp\\file.pdf", insertedDocument, pmd);

        verify(sendQueueService).getPriorityQueue(202);
        verify(errorMetaDataService).writeToMessageServiceErrorCollection(
                eq("priority-202"),
                eq("callRestApiWithMsgServiceOnErrorCallback"),
                eq("task-doc360-http"),
                eq(202),
                any(Map.class),
                eq("doc360 queue failure"),
                eq(MetaDataStatus.AUTOMATIC)
        );
    }

    @Test
    public void testUpdateProcessorFileTaskWithCriteriaError_whenErrorContainsSevere_shouldSetFlagAndAddSevereErrorCode() {
        ProcessorFileTask realTask = new ProcessorFileTask();
        realTask.setId("task-severe-direct");
        realTask.setSummary(new ProcessorSummary());

        Set<String> errorList = new HashSet<>();
        errorList.add("CLAIM_NUMBER_SEVERE");

        boolean result = processFileTask.updateProcessorFileTaskWithCriteriaError(realTask, errorList);

        assertTrue(result);
        assertNotNull(realTask.getSummary());
        assertNotNull(realTask.getSummary().getErrorList());
        assertEquals(1, realTask.getSummary().getErrorList().size());
        assertEquals(
                ProcessorErrorCode.REQUIRED_METADATA_FIELDS_MISSING_SEVERE_ERROR.getErrorCode(),
                realTask.getSummary().getErrorList().get(0).getErrorCode()
        );
    }
}