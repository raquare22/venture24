package com.optum.fds.paperless.mongo.file.metadata;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.util.Parser;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;

public class FileTaskMetadataTest {
    private static final FileTaskMetadata METADATA = new FileTaskMetadata();

    private static final Logger LOGGER = LoggerFactory.getLogger(FileTaskMetadataTest.class);
    StringBuilder testXmlsb;

    @Before
    public void setUp() {
        testXmlsb = new StringBuilder();
        testXmlsb.append("<xml>");
        testXmlsb.append("<row1>").append("regular text").append("</row1>");
        testXmlsb.append("<row2>").append("contains & ampersand").append("</row2>");
        testXmlsb.append("</xml>");
    }

    @Test
    public void testGetIndices() {
        METADATA.getIndices();
    }

    @Test
    public void testSetIndices() {
        Indices indices = new Indices();
        METADATA.setIndices(indices);
    }

    @Test(expected = JsonParseException.class)
    public void testAmpersandInXml() throws IOException {
        xml xmlBean = null;
        XmlMapper mapper = new XmlMapper();
        xmlBean = mapper.readValue(testXmlsb.toString(), xml.class);
        LOGGER.info("{} - {}", xmlBean.getRow1(), xmlBean.getRow2());
    }
    /*
     * Test replace ampersand & with unicode &#038; for ampersand
     * To get by xml parser exception for unexpected character
     * ampersand is control character in xml and html
     * Final printout to object String field will be just the & and not the unicode
     */
    @Test
    public void testAmpersandInXmlAndReplaceWithUnicode() throws IOException  {
        xml xmlBean = null;
        XmlMapper mapper = new XmlMapper();
        boolean retry = false;
        do {
            try {
                xmlBean = mapper.readValue(testXmlsb.toString(), xml.class);
                LOGGER.info("{} - {}", xmlBean.getRow1(), xmlBean.getRow2());
                retry = false;
                assertThat("Replace did not work", xmlBean.getRow2(), containsString(" & "));
            } catch (JsonParseException e) {
                int ampPlace = testXmlsb.indexOf("&");
                testXmlsb.replace(ampPlace, ampPlace+1, "&#038;");
                retry = true;
            }
        } while (retry);
    }

    @Test
    public void testParseContentMethod() throws IOException {
        xml xmlBean = Parser.parseXML(testXmlsb.toString(), xml.class);
        assertThat("Parse did not work", xmlBean, is(notNullValue()));
        assertThat("Replace did not work", xmlBean.getRow2(), containsString(" & "));
    }


    @Test
    public void testParseFileMethod() throws IOException {
        ClassLoader classLoader = getClass().getClassLoader();
        File xmlFile = new File(classLoader.getResource("xmlWithAmpersand.txt").getFile());
        xml xmlBean = null;
        try {
            xmlBean = Parser.parseXMLFile(xmlFile, xml.class);
            LOGGER.info("{} - {} - {}", xmlBean.getRow1(), xmlBean.getRow2(), xmlBean.getComment());
        } catch (JsonParseException e) {
            LOGGER.error(e.getMessage());
        }
        assertThat("Parse did not work", xmlBean, is(notNullValue()));
        assertThat("Replace did not work", xmlBean.getRow2(), containsString(" & "));

    }

}

class xml {
    private String row1;
    private String row2;
    private String comment;
    public String getRow1() {
        return row1;
    }
    public void setRow1(String row1) {
        this.row1 = row1;
    }
    public String getRow2() {
        return row2;
    }
    public void setRow2(String row2) {
        this.row2 = row2;
    }
    public String getComment() {
        return comment;
    }
    public void setComment(String comment) {
        this.comment = comment;
    }

}