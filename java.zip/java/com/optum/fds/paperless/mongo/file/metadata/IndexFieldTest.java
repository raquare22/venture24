package com.optum.fds.paperless.mongo.file.metadata;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class IndexFieldTest {
    IndexField indexField = new IndexField();
    @Test
    public void testGetSetIdxName(){
        indexField.setIdxName(new String());
        assertEquals(new String(),indexField.getIdxName());
    }

    @Test
    public void testGetSetIdxValue(){
        indexField.setIdxValue(new String());
        assertEquals(new String(),indexField.getIdxValue());
    }
}
