package com.optum.fds.paperless.mongo.file.metadata;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class PostCardIndTest {

    @InjectMocks
    private PostCardInd postCardInd;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(postCardInd, "cosmosDoc1PostCardInd", true);
        ReflectionTestUtils.setField(postCardInd, "cosmosPRAPostCardInd", false);
        ReflectionTestUtils.setField(postCardInd, "cosmosPRACDCPostCardInd", true);
        ReflectionTestUtils.setField(postCardInd, "cspPRAPostCardInd", false);
        ReflectionTestUtils.setField(postCardInd, "cspClaimsPostCardInd", true);
        ReflectionTestUtils.setField(postCardInd, "cspPRA835PostCardInd", false);
        ReflectionTestUtils.setField(postCardInd, "etsAppealsPostCardInd", true);
        ReflectionTestUtils.setField(postCardInd, "letGenPostCardInd", false);
        ReflectionTestUtils.setField(postCardInd, "mrAppealsPostCardInd", true);
        ReflectionTestUtils.setField(postCardInd, "odarPostCardInd", false);
        ReflectionTestUtils.setField(postCardInd, "priorAuth1ClickPostCardInd", true);
        ReflectionTestUtils.setField(postCardInd, "priorAuthCCSManualPostCardInd", false);
        ReflectionTestUtils.setField(postCardInd, "priorAuthNextGenPostCardInd", true);
        ReflectionTestUtils.setField(postCardInd, "uhcWestPostCardInd", false);
        ReflectionTestUtils.setField(postCardInd, "unetPostCardInd", true);
        ReflectionTestUtils.setField(postCardInd, "unetPRAPostCardInd", false);
        ReflectionTestUtils.setField(postCardInd, "uspClaimsPostCardInd", true);
        ReflectionTestUtils.setField(postCardInd, "uspPRAPostCardInd", false);
        ReflectionTestUtils.setField(postCardInd, "ngsAppealsPostCardInd", true);
        ReflectionTestUtils.setField(postCardInd, "txgcPostCardInd", false);
        ReflectionTestUtils.setField(postCardInd, "houseCallsPostCardInd", true);
    }

    @Test
    public void testGetPostCardInd() {
        assertTrue(postCardInd.getPostCardInd("COSMOSDoc1"));
        assertFalse(postCardInd.getPostCardInd("COSMOSPRA"));
        assertTrue(postCardInd.getPostCardInd("COSMOSPRACDC"));
        assertFalse(postCardInd.getPostCardInd("CSPPRA"));
        assertTrue(postCardInd.getPostCardInd("CSPClaims"));
        assertFalse(postCardInd.getPostCardInd("CSPPRA835"));
        assertTrue(postCardInd.getPostCardInd("ETSAppeals"));
        assertFalse(postCardInd.getPostCardInd("LetGen"));
        assertTrue(postCardInd.getPostCardInd("MRAppeals"));
        assertFalse(postCardInd.getPostCardInd("ODAR"));
        assertTrue(postCardInd.getPostCardInd("PriorAuth1Click"));
        assertFalse(postCardInd.getPostCardInd("PriorAuthCCSManual"));
        assertTrue(postCardInd.getPostCardInd("PriorAuthNextGen"));
        assertFalse(postCardInd.getPostCardInd("UHCWest"));
        assertTrue(postCardInd.getPostCardInd("UNET"));
        assertFalse(postCardInd.getPostCardInd("UNETPRA"));
        assertTrue(postCardInd.getPostCardInd("USPClaims"));
        assertFalse(postCardInd.getPostCardInd("USPPRA"));
        assertTrue(postCardInd.getPostCardInd("NGSAppeals"));
        assertFalse(postCardInd.getPostCardInd("TXGC"));
        assertTrue(postCardInd.getPostCardInd("HouseCalls"));
    }
}