package com.optum.fds.paperless.mongo;

import com.optum.fds.paperless.mongo.executions.HookExecutionRecordMetaData;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HookTransactionMetadataTest {

    HookTransactionMetaData hookTransactionMetaData = new HookTransactionMetaData();
    HookTransactionMetaData hookTransactionMetaDataNew;

    @Test
    public void testGettersandSetters(){
     hookTransactionMetaDataNew = hookTransactionMetaData.setId(new String());
     Assert.assertEquals(new String(),hookTransactionMetaData.getId());

     hookTransactionMetaDataNew = hookTransactionMetaData.setParentId(new String());
     Assert.assertEquals(new String(), hookTransactionMetaData.getParentId());

     hookTransactionMetaDataNew = hookTransactionMetaData.setClientId(1087);
     Assert.assertEquals(1087,hookTransactionMetaData.getClientId());

     hookTransactionMetaDataNew = hookTransactionMetaData.setSpaceId(10);
     Assert.assertEquals(10,hookTransactionMetaData.getSpaceId());

     hookTransactionMetaDataNew = hookTransactionMetaData.setAppIdentifier(new String());
     Assert.assertEquals(new String(),hookTransactionMetaData.getAppIdentifier());

     hookTransactionMetaDataNew = hookTransactionMetaData.setStatus(new String());
     Assert.assertEquals(new String(),hookTransactionMetaData.getStatus());

     hookTransactionMetaDataNew = hookTransactionMetaData.setVersion(new String());
     Assert.assertEquals(new String(),hookTransactionMetaData.getVersion());

     hookTransactionMetaDataNew = hookTransactionMetaData.setExpires(new Date());
     Assert.assertEquals(new Date(),hookTransactionMetaData.getExpires());

/*
     hookTransactionMetaDataNew = hookTransactionMetaData.setDateCreated(new Date());
     Assert.assertEquals(new Date(),hookTransactionMetaData.getDateCreated());

     hookTransactionMetaDataNew = hookTransactionMetaData.setDateModified(new Date());
     Assert.assertEquals(new Date(),hookTransactionMetaData.getDateModified());
*/
     hookTransactionMetaDataNew = hookTransactionMetaData.setTransactionId(new String());
     Assert.assertEquals(new String(),hookTransactionMetaData.getTransactionId());

     hookTransactionMetaDataNew = hookTransactionMetaData.setErrorMessage(new String());
     Assert.assertEquals(new String(),hookTransactionMetaData.getErrorMessage());

     hookTransactionMetaDataNew = hookTransactionMetaData.setHookRecordType(new String());
     Assert.assertEquals(new String(),hookTransactionMetaData.getHookRecordType());

     hookTransactionMetaDataNew = hookTransactionMetaData.setTargetType(new String());
     Assert.assertEquals(new String(),hookTransactionMetaData.getTargetType());

     hookTransactionMetaDataNew = hookTransactionMetaData.setTargetId(new String());
     Assert.assertEquals(new String(),hookTransactionMetaData.getTargetId());

     List<HookExecutionRecordMetaData> hookExecutionList = new ArrayList<>();
     hookTransactionMetaDataNew = hookTransactionMetaData.setHookExecutionList(hookExecutionList);
     Assert.assertEquals(hookExecutionList,hookTransactionMetaData.getHookExecutionList());

     hookTransactionMetaDataNew = hookTransactionMetaData.setJobId(new String());
     Assert.assertEquals(new String(),hookTransactionMetaData.getJobId());


    }

    @Test
    public void testToString(){
        Assert.assertNotNull(hookTransactionMetaData.toString());
    }

}
