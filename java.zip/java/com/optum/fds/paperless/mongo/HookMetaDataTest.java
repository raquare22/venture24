package com.optum.fds.paperless.mongo;

import org.junit.Test;

import java.util.Date;

public class HookMetaDataTest {

    @Test
    public void testHookMetaData() {
        HookMetaData hookMetaData=new HookMetaData();
        hookMetaData.isLocked();
        hookMetaData.setLocked(true);
        Boolean locked=true;
        hookMetaData.setLocked(locked);
        hookMetaData.isLocked();
        hookMetaData.setLocked(new Boolean(null));

        hookMetaData.setParentId(new String());
        hookMetaData.getParentId();

        hookMetaData.setMethod(new String());
        hookMetaData.getMethod();

        hookMetaData.setTarget(new String());
        hookMetaData.getTarget();

        hookMetaData.setExpires(new Date());
        hookMetaData.getExpires();

        hookMetaData.setErrorMessage(new String());
        hookMetaData.getErrorMessage();

        hookMetaData.setHook(null);
        hookMetaData.getHook();

        hookMetaData.getRevisions();

        hookMetaData.setHookRecordType(new String());
        hookMetaData.getHookRecordType();

        hookMetaData.setSpaceId(1080);
        hookMetaData.getSpaceId();

        hookMetaData.setExecutionOrder(2);
        hookMetaData.getExecutionOrder();

    }
}
