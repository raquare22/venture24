package com.optum.fds.paperless.mongo;

import org.junit.Test;

import java.util.Date;

import static junit.framework.Assert.assertEquals;

public class TransactionTest {


    Transaction transaction = new Transaction();

    @Test
    public void testSettersGetters() {
        Date dateCreated = new Date();
        Date dateModified = new Date();
        transaction.setActions(null);
        transaction.setFiles(null);
        transaction.setDateModified(dateModified);
        transaction.setDateCreated(dateCreated);
        transaction.setAppIdentifier("testapp");
        transaction.setProtocol("HTTP/1.1");
        transaction.setMethod("POST");
        transaction.setParameters(null);
        transaction.setPayload(null);
        transaction.setUri("/v2/oauth2/token.json");
        transaction.setHeaders("testHeaders");
        transaction.setUserIp("127.0.0.1");
        transaction.setServerIp("123.4.5.6");
        transaction.setSpaceId(3104);
        transaction.setResponseStatusCode(200);
        transaction.setResponseHeader("testResponseHeader");
        transaction.setId("id123");
        transaction.setTransactionId("transactionId123");
        transaction.setTotalFileSize(100);
        transaction.setClientId(1234);
        transaction.setAsync(true);
        transaction.setAttachments(null);
        transaction.setListAttachments(null);
        transaction.setDocumentListInfo(null);
        transaction.setMetadata(null);
        transaction.setHookListInfo(null);
        transaction.setHook(null);
        transaction.setReportListInfo(null);


        assertEquals(null,transaction.getActions());
        assertEquals(null,transaction.getFiles());
        assertEquals(dateModified, transaction.getDateModified());
        assertEquals(dateCreated, transaction.getDateCreated());
        assertEquals("testapp", transaction.getAppIdentifier());
        assertEquals("HTTP/1.1", transaction.getProtocol());
        assertEquals("POST", transaction.getMethod());
        assertEquals(null, transaction.getParameters());
        assertEquals(null, transaction.getPayload());
        assertEquals("/v2/oauth2/token.json", transaction.getUri());
        assertEquals("testHeaders", transaction.getHeaders());
        assertEquals("127.0.0.1", transaction.getUserIp());
        assertEquals("123.4.5.6", transaction.getServerIp());
        assertEquals(3104, transaction.getSpaceId());
        assertEquals(200, transaction.getResponseStatusCode());
        assertEquals("testResponseHeader", transaction.getResponseHeader());
        assertEquals("id123", transaction.getId());
        assertEquals("transactionId123", transaction.getTransactionId());
        assertEquals(100, transaction.getTotalFileSize());
        assertEquals(1234, transaction.getClientId());
        assertEquals(true, transaction.isAsync());
        assertEquals(null, transaction.getAttachments());
        assertEquals(null, transaction.getListAttachments());
        assertEquals(null, transaction.getDocumentListInfo());
        assertEquals(null, transaction.getMetadata());
        assertEquals(null, transaction.getHookListInfo());
        assertEquals(null, transaction.getHook());
        assertEquals(null, transaction.getReportListInfo());
    }
}
