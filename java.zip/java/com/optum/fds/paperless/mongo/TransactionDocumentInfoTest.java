package com.optum.fds.paperless.mongo;

import org.bson.Document;
import org.joda.time.DateTime;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class TransactionDocumentInfoTest {

    @Test
    public void testTransactionDocumentInfo() {
        TransactionDocumentInfo transactionDocumentInfo = new TransactionDocumentInfo();
        transactionDocumentInfo.setExpires(DateTime.now().toDate());
        transactionDocumentInfo.setExternalId("externalId");
        transactionDocumentInfo.setId("docId");
        transactionDocumentInfo.setParentId("ParentId");
        transactionDocumentInfo.setSpaceId(3007);
        transactionDocumentInfo.setStatus("status");
        transactionDocumentInfo.setVersion("version");
        transactionDocumentInfo.setAttachments(null);
        transactionDocumentInfo.setMetadata(null);
        transactionDocumentInfo.getExpires();
        transactionDocumentInfo.getExternalId();
        transactionDocumentInfo.getDocumentId();
        transactionDocumentInfo.getParentId();
        transactionDocumentInfo.getSpaceId();
        transactionDocumentInfo.getStatus();
        transactionDocumentInfo.getVersion();
        transactionDocumentInfo.getAttachments();
        transactionDocumentInfo.getMetadata();
    }

    @Test
    public void testTransactionDocumentInfoWithList() {
        TransactionDocumentInfo transactionDocumentInfo = new TransactionDocumentInfo();
        TransactionAttachmentInfo transactionAttachmentInfo = new TransactionAttachmentInfo();
        Document documentMetaData = new Document();
        List<TransactionAttachmentInfo> list = new ArrayList<>();
        list.add(transactionAttachmentInfo);
        transactionDocumentInfo.setAttachments(list);
        transactionDocumentInfo.setMetadata(documentMetaData);
        transactionDocumentInfo.getAttachments();
        transactionDocumentInfo.getMetadata();
        transactionAttachmentInfo.getExpires();
        transactionAttachmentInfo.setExpires(null);
    }
}
