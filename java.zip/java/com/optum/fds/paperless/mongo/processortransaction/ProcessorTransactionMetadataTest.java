package com.optum.fds.paperless.mongo.processortransaction;

import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

public class ProcessorTransactionMetadataTest {

    ProcessorTransactionMetadata processorTransactionMetadata =  new ProcessorTransactionMetadata();

    @Test
    public void test(){
        Map<String,Object> map = new HashMap<>();
        processorTransactionMetadata.setClient(map);
        Assert.assertEquals(map,processorTransactionMetadata.getClient());
        Long value = 1L;
        Long serialUID = ProcessorTransactionMetadata.getSerialversionuid();
        Assert.assertEquals(value,serialUID);
    }
}
