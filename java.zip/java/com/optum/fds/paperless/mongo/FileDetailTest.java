package com.optum.fds.paperless.mongo;

import org.junit.Test;
import static org.junit.Assert.*;

public class FileDetailTest {

    @Test
    public void testGettersAndSetters() {
        FileDetail fileDetail = new FileDetail();

        fileDetail.setFileName("testFile.txt");
        assertEquals("testFile.txt", fileDetail.getFileName());

        fileDetail.setStatus("Completed");
        assertEquals("Completed", fileDetail.getStatus());
    }
}