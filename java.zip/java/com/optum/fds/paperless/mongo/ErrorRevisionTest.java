package com.optum.fds.paperless.mongo;

import org.bson.Document;
import org.junit.Assert;
import org.junit.Test;

import java.util.Date;

public class ErrorRevisionTest {
    ErrorRevision errorRevision =  new ErrorRevision();

    @Test
    public void test(){
        errorRevision.setExternalId(new String());
        Assert.assertEquals(new String(), errorRevision.getExternalId());

        errorRevision.setDateAttachmentUpdated(new Date());
        Assert.assertNotNull(errorRevision.getDateAttachmentUpdated());

        org.bson.Document metadata = new Document();
        errorRevision.setMetadata(metadata);
        Assert.assertEquals(metadata,errorRevision.getMetadata());

        errorRevision.setErrorMessage(new String());
        Assert.assertEquals(new String(), errorRevision.getErrorMessage());
    }

}
