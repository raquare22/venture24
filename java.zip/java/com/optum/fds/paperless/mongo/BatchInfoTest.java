package com.optum.fds.paperless.mongo;

import org.junit.Test;
import static org.junit.Assert.*;

public class BatchInfoTest {

    @Test
    public void testGettersAndSetters() {
        BatchInfo batchInfo = new BatchInfo();

        batchInfo.setZipFileName("test.zip");
        assertEquals("test.zip", batchInfo.getZipFileName());

        batchInfo.setZipFileCreationDate("2023-10-01");
        assertEquals("2023-10-01", batchInfo.getZipFileCreationDate());

        batchInfo.setItemsCount(5);
        assertEquals(Integer.valueOf(5), batchInfo.getItemsCount());
    }
}