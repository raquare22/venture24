package com.optum.fds.paperless.mongo;

import org.junit.Assert;
import org.junit.Test;

public class VirusscanResultTest {
    VirusscanResult object =new VirusscanResult();

    @Test
    public void testGettersSetters(){
        object.setFilename(new String());
        Assert.assertEquals(new String(),object.getFilename());

        object.setStatus(new String());
        Assert.assertEquals(new String(),object.getStatus());

        object.setDescription(new String());
        Assert.assertEquals(new String(),object.getDescription());

        object.setStatusCode(new String());
        Assert.assertEquals(new String(),object.getStatusCode());

        object.setfileSize(10);
        Assert.assertEquals(10,object.getFileSize());

    }

}
