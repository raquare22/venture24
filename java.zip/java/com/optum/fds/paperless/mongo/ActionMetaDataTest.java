package com.optum.fds.paperless.mongo;

import org.junit.Test;

public class ActionMetaDataTest {

    @Test
    public void testIt() {
        com.optum.fds.paperless.mongo.ActionMetaData actionMetaData = new com.optum.fds.paperless.mongo.ActionMetaData();

        actionMetaData.setAction(new java.lang.String());
        actionMetaData.setDateCreated(new java.util.Date());
        actionMetaData.setDateModified(new java.util.Date());
        actionMetaData.setVirusScanResults(new java.util.ArrayList<>());

        actionMetaData.getAction();
        actionMetaData.getDateCreated();
        actionMetaData.getDateModified();
        actionMetaData.getVirusScanResults();

    }

    @Test
    public void testItNull() {
        com.optum.fds.paperless.mongo.ActionMetaData actionMetaData = new com.optum.fds.paperless.mongo.ActionMetaData();

        actionMetaData.setDateCreated(null);
        actionMetaData.setDateModified(null);
        actionMetaData.setVirusScanResults(null);

        actionMetaData.getDateCreated();
        actionMetaData.getDateModified();
        actionMetaData.getVirusScanResults();

    }

}
