package com.optum.fds.paperless.mongo;

import com.optum.fds.paperless.domain.ReportResult;
import org.joda.time.DateTime;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class TransactionReportInfoTest {

    @Test
    public void testTransactionReportInfo() {
        TransactionReportInfo transactionReportInfo=new TransactionReportInfo();
        transactionReportInfo.setAppId("appId");
        transactionReportInfo.setClientId(0);
        transactionReportInfo.setExpires(DateTime.now().toDate());
        transactionReportInfo.setExternalId("externalId");
        transactionReportInfo.setParentId("parentId");
        transactionReportInfo.setSpaceId(3007);
        transactionReportInfo.setStatus("status");
        transactionReportInfo.setVersion("version");
        transactionReportInfo.setReportResult(null);
        transactionReportInfo.getAppId();
        transactionReportInfo.getClientId();
        transactionReportInfo.getExpires();
        transactionReportInfo.getExternalId();
        transactionReportInfo.getParentId();
        transactionReportInfo.getSpaceId();
        transactionReportInfo.getStatus();
        transactionReportInfo.getVersion();
        transactionReportInfo.getReportResult();
    }
    @Test
    public void testTransactionReportInfoReportResult() {
        TransactionReportInfo transactionReportInfo=new TransactionReportInfo();
        ReportResult reportResult=new ReportResult();
        List<ReportResult> list=new ArrayList<>();
        list.add(reportResult);
        transactionReportInfo.setReportResult(list);
        transactionReportInfo.getReportResult();
        transactionReportInfo.setExpires(null);
        transactionReportInfo.getExpires();

    }
}
