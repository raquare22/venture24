package com.optum.fds.paperless.mongo;

import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.jobs.ProcessorJob;
import com.optum.fds.paperless.mongo.jobs.RestApiJob;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.data.mongodb.core.query.Query;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import static junit.framework.Assert.assertEquals;

public class ProcessorUtilTest {


    @Test
    public void testGetProcessorServerTypeQuery() {
        Query query = ProcessorUtil.getProcessorByServerTypeQuery("id", "appIdentifier", "xaas");
        Assert.assertEquals("Query: { \"id\" : \"id\", \"appIdentifier\" : \"appIdentifier\", \"serverType\" : \"xaas\"}, Fields: {}, Sort: {}", query.toString());

    }

    @Test
    public void testAddServerTypeCriteria() {
        Query query = new Query();
        ProcessorUtil.addServerTypeCriteria("ose", query);
        Assert.assertEquals("Query: { \"serverType\" : \"ose\"}, Fields: {}, Sort: {}", query.toString());
    }

    @Test
    public void testSetExecutionRecordForActiviti() {
        CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
        Map resultMap = new HashMap<String, Object>();
        resultMap.put("activitiProcessKey", "activitiProcessKey");
        ProcessorJob job = new ProcessorJob();

        ProcessorUtil.setExecutionRecordForActiviti(csvProcessorTransaction, resultMap, job);
        assertEquals("activitiProcessKey", csvProcessorTransaction.getProcessorExecutionRecordList().get(0).getActivitiProcessKey());

    }

    @Test
    public void testSetExecutionRecordForActivitiRestJob() {
        CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
        Map resultMap = new HashMap<String, Object>();
        resultMap.put("activitiProcessKey", "activitiProcessKey");
        RestApiJob job = new RestApiJob();
        job.setSpaceId(1234);

        ProcessorUtil.setExecutionRecordForActiviti(csvProcessorTransaction, resultMap, job);
        assertEquals("activitiProcessKey", csvProcessorTransaction.getProcessorExecutionRecordList().get(0).getActivitiProcessKey());

    }

    @Test
    public void testSetTransactionRecord() {
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setConfigSpaceId(new Integer(2));
        ProcessorUtil.setTransactionRecord(processor);
    }

    @Test
    public void testGetProcessorById() {
        ProcessorUtil.getProcessorById("Test");
    }

    @Test
    public void testIsEmpty(){
        Collection collection = new ArrayList();
        boolean value = ProcessorUtil.isEmpty(collection);
        assertEquals(true, value);
    }

}
