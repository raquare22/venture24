package com.optum.fds.paperless.mongo.csvProcessors;

import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import com.optum.fds.paperless.mongo.processors.ProcessorTargetType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

public class CsvProcessorRowTaskTest {


    CsvProcessorRowTask csvProcessorRowTask;

    @Before
    public void setUp() throws Exception {
        csvProcessorRowTask = new CsvProcessorRowTask();
    }

    @Test
    public void testGetSetConfigSpaceId() {
        Integer value = Integer.valueOf(3007);
        csvProcessorRowTask.setConfigSpaceId(value);
        Assert.assertEquals(value, csvProcessorRowTask.getConfigSpaceId());
    }

    @Test
    public void testGetSetProcessorRecordType() {
        csvProcessorRowTask.setProcessorRecordType(ProcessorRecordTypes.csvProcessorRowTask);
        Assert.assertEquals(ProcessorRecordTypes.csvProcessorRowTask, csvProcessorRowTask.getProcessorRecordType());
    }

    @Test
    public void testGetSetCsvProcessorTransactionId() {
        String id = "id";
        csvProcessorRowTask.setCsvProcessorTransactionId(id);
        Assert.assertEquals(id, csvProcessorRowTask.getCsvProcessorTransactionId());
    }

    @Test
    public void testGetSetProcessorId() {
        String id = "id";
        csvProcessorRowTask.setProcessorId(id);
        Assert.assertEquals(id, csvProcessorRowTask.getProcessorId());
    }

    @Test
    public void testGetSetCsvFileName() {
        String value = "csvFileName";
        csvProcessorRowTask.setCsvFileName(value);
        Assert.assertEquals(value, csvProcessorRowTask.getCsvFileName());
    }

    @Test
    public void testGetSetJsonFileName() {
        String value = "jsonFileName";
        csvProcessorRowTask.setJsonFileName(value);
        Assert.assertEquals(value, csvProcessorRowTask.getJsonFileName());
    }

    @Test
    public void testGetSetFileRowNumber() {
        Integer value = Integer.valueOf("32");
        csvProcessorRowTask.setFileRowNumber(value);
        Assert.assertEquals(value, csvProcessorRowTask.getFileRowNumber());
    }

    @Test
    public void testGetSetProcessedByHost() {
        String value = "host";
        csvProcessorRowTask.setProcessedByHost(value);
        Assert.assertEquals(value, csvProcessorRowTask.getProcessedByHost());
    }

    @Test
    public void testGetSetServerType() {
        String value = "xaas";
        csvProcessorRowTask.setServerType(value);
        Assert.assertEquals(value, csvProcessorRowTask.getServerType());
    }

    @Test
    public void testGetSetLocation() {
        String value = "location";
        csvProcessorRowTask.setLocation(value);
        Assert.assertEquals(value, csvProcessorRowTask.getLocation());
    }

    @Test
    public void testGetSetDateProcessed() {
        Date value = new Date();
        csvProcessorRowTask.setDateProcessed(value);
        Assert.assertEquals(value, csvProcessorRowTask.getDateProcessed());
    }

    @Test
    public void testGetSetTargetid() {
        String value = "targetId";
        csvProcessorRowTask.setTargetId(value);
        Assert.assertEquals(value, csvProcessorRowTask.getTargetId());
    }

    @Test
    public void testGetSetTargetType() {
        csvProcessorRowTask.setTargetType(ProcessorTargetType.documents.toString());
        Assert.assertEquals(ProcessorTargetType.documents.toString(), csvProcessorRowTask.getTargetType());
    }

    @Test
    public void testGetSetRequest() {
        String value = "request";
        csvProcessorRowTask.setRequest(value);
        Assert.assertEquals(value, csvProcessorRowTask.getRequest());
    }

    @Test
    public void testGetSetResponse() {
        String value = "response";
        csvProcessorRowTask.setResponse(value);
        Assert.assertEquals(value, csvProcessorRowTask.getResponse());
    }

    @Test
    public void testGetSetRestTargetId() {
        String value = "restTargetId";
        csvProcessorRowTask.setRestTargetId(value);
        Assert.assertEquals(value, csvProcessorRowTask.getRestTargetId());
    }

    @Test
    public void testGetSetIsRestApiSuccessful() {
        Boolean value = true;
        csvProcessorRowTask.setIsRestApiSuccessful(value);
        Assert.assertEquals(value, csvProcessorRowTask.getIsRestApiSuccessful());
    }

}
