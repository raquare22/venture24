package com.optum.fds.paperless.mongo.csvProcessors;

import org.junit.Assert;
import org.junit.Test;

public class CsvProcessorTransactionTest {
    CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();

    @Test
    public void testDefaultConstructor() {
        new CsvProcessorTransaction(); //test default constructor
    }

    @Test
    public void testGetSetRowCount() throws Exception {
        csvProcessorTransaction.setRowCount(100);
        Assert.assertEquals(Integer.valueOf(100), csvProcessorTransaction.getRowCount());
    }

    @Test
    public void testGetSetJsonFileName() throws Exception {
        String JSON_FIlE_NAME = "jsonFile.json";
        csvProcessorTransaction.setJsonFileName(JSON_FIlE_NAME);
        Assert.assertEquals(JSON_FIlE_NAME, csvProcessorTransaction.getJsonFileName());
    }

}
