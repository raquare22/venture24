package com.optum.fds.paperless.mongo.csvProcessors;

import junit.framework.Assert;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;
import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertTrue;

public class CsvProcessorSummaryTest {


    CsvProcessorSummary csvProcessorSummary;

    @Before
    public void setUp() throws Exception {
        csvProcessorSummary = new CsvProcessorSummary();
    }

    @Test
    public void testGetSetCsvRowResult() {
        CsvProcessorSummary csvProcessorSummary = new CsvProcessorSummary();
        String csvRowResultJsonStr = "{ \"errorMessage\" : \"Template parse failure\" , \"errorCode\" : 80}";
        //org.bson.Document csvRowResultObj = org.bson.Document.parse(csvRowResultJsonStr);
        Document csvRowResultObj = Document.parse(csvRowResultJsonStr);
        csvProcessorSummary.setCsvRowResult(csvRowResultObj);
        assertEquals(csvRowResultJsonStr.replaceAll(" ", ""), ((Document)csvProcessorSummary.getCsvRowResult()).toJson().toString().replaceAll(" ",  "") );
    }

    @Test
    public void testGetSetProcessingMetrics() {
        CsvProcessingMetrics csvProcessingMetrics = new CsvProcessingMetrics();
        csvProcessorSummary.setCsvProcessingMetrics(csvProcessingMetrics);
        CsvProcessingMetrics result = csvProcessorSummary.getCsvProcessingMetrics();
        Assert.assertEquals(csvProcessingMetrics, csvProcessorSummary.getCsvProcessingMetrics());
        testCsvProcessorMetricsZero(result);
    }

    @Test
    public void testGetProcessingMetricsAsNull() {
        csvProcessorSummary.setCsvProcessingMetrics(null);
        CsvProcessingMetrics result = csvProcessorSummary.getCsvProcessingMetrics();
        assertNotNull(result);
        testCsvProcessorMetricsZero(result);
    }

    void testCsvProcessorMetricsZero(CsvProcessingMetrics csvProcessingMetrics) {
        assertTrue(0L == csvProcessingMetrics.getBytesProcessed() );
        assertTrue(0 == csvProcessingMetrics.getRowCount() );
        assertTrue(0L == csvProcessingMetrics.getTotalBytes() );
        assertNotNull(csvProcessingMetrics.getErrorCount() );

    }

}
