package com.optum.fds.paperless.mongo.csvProcessors;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CsvProcessingMetricsTest {

    CsvProcessingMetrics csvProcessingMetrics;

    @Before
    public void setUp() throws Exception {
        csvProcessingMetrics = new CsvProcessingMetrics();
    }

    @Test
    public void testGetSetRowCount() {
        Integer value = Integer.valueOf("19");
        csvProcessingMetrics.setRowCount(value);
        Assert.assertEquals(value, csvProcessingMetrics.getRowCount());
    }
}
