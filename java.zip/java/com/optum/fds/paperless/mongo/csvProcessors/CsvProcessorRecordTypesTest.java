package com.optum.fds.paperless.mongo.csvProcessors;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class CsvProcessorRecordTypesTest {

    @Test
    public void csvRecordTypesTest() {
        assertNotNull(CsvProcessorRecordTypes.csvProcessorTransaction);
    }
}
