package com.optum.fds.paperless.mongo;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;

public class TransactionDocumentListInfoTest {

    @Test
    public void testAddAndGet() {
        TransactionDocumentListInfo listInfo = new TransactionDocumentListInfo();
        TransactionDocumentInfo docInfo1 = new TransactionDocumentInfo();
        TransactionDocumentInfo docInfo2 = new TransactionDocumentInfo();

        listInfo.add(docInfo1);
        listInfo.add(docInfo2);

        assertEquals(2, listInfo.size());
        assertEquals(docInfo1, listInfo.get(0));
        assertEquals(docInfo2, listInfo.get(1));
    }

    @Test
    public void testIsEmpty() {
        TransactionDocumentListInfo listInfo = new TransactionDocumentListInfo();
        assertTrue(listInfo.isEmpty());

        TransactionDocumentInfo docInfo = new TransactionDocumentInfo();
        listInfo.add(docInfo);
        assertFalse(listInfo.isEmpty());
    }

    @Test
    public void testClear() {
        TransactionDocumentListInfo listInfo = new TransactionDocumentListInfo();
        TransactionDocumentInfo docInfo = new TransactionDocumentInfo();
        listInfo.add(docInfo);

        listInfo.clear();
        assertTrue(listInfo.isEmpty());
    }
}