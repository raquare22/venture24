package com.optum.fds.paperless.regression.suite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.optum.fds.paperless.domain.service.*;
import com.optum.fds.paperless.domain.util.*;


import junit.framework.TestCase;


@RunWith(Suite.class)

@Suite.SuiteClasses({
	CsvProcessorServiceTest.class,
	CsvProcessorsServiceTest.class,
	DocumentMetaDataServiceTest.class,
	DocvaultTransactionServiceImplTest.class,
	ErrorMetaDataServiceTest.class,
	FilestoreServiceTest.class,
	HookServiceImplTest.class,
	ProcessorServiceTest.class,
	ProcessorsServiceTest.class,
	ProcessorFileTaskServiceImplTest.class,
	ProcessorTransactionServiceTest.class,
	TransactionServiceTest.class,
	ProcessorTaskUtilTest.class
   
})

public class DomainPackageTestSuite extends TestCase {

}
