package com.optum.fds.paperless.regression.suite;

import com.optum.fds.paperless.mongo.*;
import com.optum.fds.paperless.mongo.csvProcessors.*;
import com.optum.fds.paperless.mongo.processortransaction.*;
import com.optum.fds.paperless.mongo.processors.*;
import com.optum.fds.paperless.mongo.processors.MetaDataTest;
import com.optum.fds.paperless.mongo.processors.RevisionTest;
import com.optum.fds.paperless.mongo.file.metadata.*;
import com.optum.fds.paperless.mongo.executions.*;
import com.optum.fds.paperless.model.*;
import junit.framework.TestCase;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)

@Suite.SuiteClasses({
	ActiveUserTest.class,
	FixedLengthMetadataOCMTest.class,
	FixedLengthMetadataTest.class,
	GenericResponseTest.class,
	MultiPostResponseTest.class,
	MultiPutResponseTest.class,
	
	ActionMetaDataTest.class,
	AttachmentMetaDataTest.class,
	DocumentAttachmentMetaDataTest.class,
	DocumentMetadataTest.class,
	DocumentQueryNewTest.class,
	DocvaultTransactionTest.class,
	ErrorCodeToStatusTest.class,
	ErrorMetadataTest.class,
	ErrorRevisionTest.class,
	FileMetaDataTest.class,
	HookEventTypeTest.class,
	HookMetaDataTest.class,
	HookTransactionMetadataTest.class,
	JobMetaDataTest.class,
	com.optum.fds.paperless.mongo.MetaDataTest.class,
	ProcessKeyToErrorCodeTest.class,
	ProcessorTransactionCoreTest.class,
	ProcessorUtilTest.class,
	com.optum.fds.paperless.mongo.RevisionTest.class,
//	TransactionAttachmentInfoTest.class,
	TransactionDocumentInfoTest.class,
	TransactionHookInfoTest.class,
	TransactionListAttachmentsInfoTest.class,
	TransactionReportInfoTest.class,
	TransactionTest.class,
	VirusscanResultTest.class,
	
	CsvProcessingMetricsTest.class,
	CsvProcessorRecordTypesTest.class,
	CsvProcessorRowTaskTest.class,
	CsvProcessorSummaryTest.class,
	CsvProcessorTransactionTest.class,
	
	ExecutionRecordTest.class,
	HookExecutionRecordMetaDataTest.class,
	UnprocessedRecordTest.class,
	
	FileTaskMetadataTest.class,
	IndexFieldTest.class,
	IndicesTest.class,
	ProcessFileTaskTest.class,
	
	MetaDataTest.class,
	OptumHttpEntityTest.class,
	ProcessingMetricsTest.class,
	ProcessorCoreTest.class,
	ProcessorErrorTest.class,
	ProcessorFileTaskTest.class,
	ProcessorMappingTest.class,
	ProcessorMapTest.class,
	ProcessorMetaDataTest.class,
	ProcessorRevisionTest.class,
	ProcessorSummaryCoreTest.class,
	ProcessorSummaryTest.class,
	ProcessorTaskTest.class,
	ProcessorTransactionsTest.class,
	ProcessorTransactionTest.class,
	RevisionTest.class,
	
	ProcessorTransactionMetadataTest.class
	

})

public class MongoTestSuite extends TestCase {
}
