package com.optum.fds.paperless.regression.suite;

import com.optum.fds.paperless.client.pojo.*;
import junit.framework.TestCase;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)

@Suite.SuiteClasses({
    COSMOSDoc1MetadataTest.class,
    COSMOSPRAMetadataTest.class,
    COSMOSPRACDCMetadataTest.class,
    CSPClaimsMetadataTest.class,
    CSPPRAMetadataTest.class,
    ETSAppealsMetadataTest.class,
    HouseCallsMetadataTest.class,
    LetGenMetadataTest.class,
    MRAppealsMetadataTest.class,
    ODARMetadataTest.class,
    PriorAuth1ClickMetadataTest.class,
    PriorAuthCCSManualMetadataTest.class,
    PriorAuthNextGenMetadataTest.class,
        NGSAppealsMetadataTest.class,
        TXGCMetadataTest.class,
        UHCWestMetadataTest.class,
        UNETMetadataTest.class,
    UNETPRAMetadataTest.class,
    USPClaimsMetadataTest.class,
    USPPRAMetadataTest.class
})

public class ClientSchemaTestSuite extends TestCase {
}
