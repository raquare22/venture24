package com.optum.fds.paperless.regression.suite;

import com.optum.fds.paperless.*;
import com.optum.fds.paperless.client.IndexFieldTest;
import com.optum.fds.paperless.client.IndicesTest;
import com.optum.fds.paperless.domain.*;
import com.optum.fds.paperless.domain.revision.*;
import com.optum.fds.paperless.domain.revision.RevisionTest;
import com.optum.fds.paperless.domain.service.*;
import com.optum.fds.paperless.domain.service.ScheduledSftpMonitorTest;
import com.optum.fds.paperless.domain.service.exception.*;
import com.optum.fds.paperless.java.delegate.oauth.bean.HttpConstantsTest;
import com.optum.fds.paperless.kafka.KafkaProducerTest;
import com.optum.fds.paperless.kafka.consumer.model.MemberInfoTest;
import com.optum.fds.paperless.kafka.consumer.model.ProviderDetailsTest;
import com.optum.fds.paperless.kafka.consumer.model.RequestedMemberTest;
import com.optum.fds.paperless.kafka.consumer.model.RequestingMemberTest;
import com.optum.fds.paperless.mongo.*;
import com.optum.fds.paperless.mongo.file.metadata.*;
import com.optum.fds.paperless.mongo.jobs.*;
//import com.optum.fds.paperless.ness.ActivitiNessConfigTest;
import com.optum.fds.paperless.oauth.AuthorizationOauthProviderTest;
import com.optum.fds.paperless.processing.service.ProcessorTransactionsServiceImplTest;
import com.optum.fds.paperless.processors.CsvProcessorsMonitorTest;
import com.optum.fds.paperless.provider.pojo.*;
import com.optum.fds.paperless.redis.model.*;
import com.optum.fds.paperless.java.delegate.common.DelegateUtilsTest;
import com.optum.fds.paperless.template.listener.ErrorListenerTest;
import com.optum.fds.paperless.util.ProcessorUtilTest;
import com.optum.fds.paperless.util.SftpMonitorUtilTest;
import com.optum.fds.paperless.util.csv.*;
import com.optum.fds.paperless.util.handlebar.helper.*;
import com.optum.fds.paperless.util.handlebar.helper.pojo.*;
import com.optum.fds.paperless.workflow.beans.*;
import com.optum.fds.paperless.workflow.service.EmailServiceImplTest;
import com.optum.fds.paperless.workflow.service.ZipUtilImplTest;
import com.optum.fds.paperless.workflow.util.HookTransactionUtilTest;
import com.optum.fds.paperless.workflow.util.WorkFlowUtilTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.optum.fds.paperless.client.*;
import com.optum.fds.paperless.constants.*;
import com.optum.fds.paperless.file.summary.*;
import com.optum.fds.paperless.exception.*;
import com.optum.fds.paperless.email.*;
import com.optum.fds.paperless.queue.*;

import com.optum.fds.paperless.model.*;
import com.optum.fds.paperless.oauth.bean.*;
import com.optum.fds.paperless.oauth.OauthManagerUtilImplTest;
import com.optum.fds.paperless.document.response.util.*;
import com.optum.fds.paperless.document.util.*;
import com.optum.fds.paperless.controller.*;
import com.optum.fds.paperless.domain.service.DocumentMetaDataServiceTest;
import com.optum.fds.paperless.java.delegate.*;
import com.optum.fds.paperless.java.delegate.docvault.*;
import com.optum.fds.paperless.java.delegate.oauth.*;
import com.optum.fds.paperless.java.delegate.oauth.OauthTest;
import com.optum.fds.paperless.mongo.file.metadata.ProcessFileTaskTest;
import com.optum.fds.paperless.provider.ProviderSearchTest;
import com.optum.fds.paperless.util.*;
import com.optum.fds.paperless.template.*;

import junit.framework.TestCase;


@RunWith(Suite.class)

@Suite.SuiteClasses({
	CustomDateDeserializerTest.class,
	ClientMetadataTest.class,
	CustomDateSerializerTest.class,
	IndexFieldTest.class,
	IndicesTest.class,
	UtilitiesTest.class,
	
	FileSplitUtilTest.class,
	RetryUtilTest.class,
	SanitizeUtilTest.class,
	UtilitiesTest.class,
	SendQueueTest.class,
	SendQueueFactoryTest.class,
	ConfigDataTest.class,
	DataSourceConfigTest.class,
	RestTemplateConfigurationTest.class,
	SendDocumentToPENRealTimeTest.class,
	//FDSHelperTest.class,
//	ActivitiNessConfigTest.class,
	RootControllerTest.class,

	
	CheckForDuplicateTest.class,
	PostDocumentDataDocvaultTest.class,
	CreateAckTemplateTest.class,
	UpdateDocumentListDocvaultTest.class,
	
	AuthorizationOauthProviderTest.class,
	OauthTest.class,
	OauthTokenTest.class,
	OauthUtilTest.class,
	OauthManagerUtilImplTest.class,
	
	CAPResponseTemplateTest.class,
	CCDocumentTemplateTest.class,
	CCResponseTemplateTest.class,
	CheckWritePRACompanionTemplateTest.class,
	CheckWritePRAEmailAlertTemplateTest.class,
	CheckWritePRAMatchAndMergeTemplateTest.class,
	CheckWritePRAResponseTemplateTest.class,
	CNSResponseTemplateTest.class,
	COSMOSAckTemplateTest.class,
	COSMOSDoc1StatusTemplateTest.class,
	CosmosPRACompanionTemplateTest.class,
	CSPClaimsResponseTemplateTest.class,
	DocLibPutRequestTemplateTest.class,
	EmailRequestToPENTemplateTest.class,
	ETSAppealsResponseTemplateTest.class,
	FDSCloudSearchTermsTemplateTest.class,
        Doc360MetadataTemplateTest.class,
	FilterReqFieldForDocvaultTemplateTest.class,
	HouseCallsResponseTemplateTest.class,
	IHRDocumentTemplateTest.class,
//	KafkaDocumentTemplateTest.class,
//	MNRResponseTemplateTest.class,
	MRAppealsResponseTemplateTest.class,
	NGSResponseTemplateTest.class,
	OCMResponseTemplateTest.class,
	ODARResponseTemplateTest.class,
	OptumPayNumberDocumentTemplateTest.class,
//	PDOCSVTemplateTest.class,
	PriorAuthResponseTemplateTest.class,
	TexasGoldELGSTemplateTest.class,
	TXGCCsvDocumentTest.class,
	TXGCJsonDocumentTemplateTest.class,
	USPClaimsResponseApiNotifyTest.class,
	USPClaimsResponseTemplateTest.class,
    PCPEmailRequestToPENTemplateTest.class,
	
	CallRestApiTest.class,
	CleanIngestFilesTest.class,
	CleanupFilesCreateACKTest.class,
	CreateACKFileTest.class,
	CreateOneZipfilePrintServicesTest.class,
	CreateShutterflyDocumentsTest.class,
	CsvCleanupFilesProcessTest.class,
	CSVDeleteWorkingDirectoryTest.class,
	CsvMoveOriginalToArchiveFolderTest.class,
	CsvSftpProcessCallbackTest.class,
	CsvToJsonFileTest.class,
	CsvUpdateProcessorTransactionStatusTest.class,
	DeleteWorkingDirectoryTest.class,
	IdentifyDocumentsFromDbTest.class,
	IdentifyDocumentsTest.class,
	IdentifyProcessorTransactionMetadataFromDbTest.class,
	IdentifyShutterflyDocumentsTest.class,
	JsonFileToRestApiTest.class,
	ManipulatePdfFileTest.class,
	MatchAndMergeDocumentsFromDBTest.class,
	MatchAndMergeTest.class,
	MoveOriginalZipToArchiveFolderTest.class,
	com.optum.fds.paperless.java.delegate.OauthTest.class,
	ProcessFileUnzipTest.class,
	ProcessMetadataFilesCallbackTest.class,
	ProcessMetadataFilesTest.class,
	ProcessRequiredFieldRuleTest.class,
	PutDocumentDataDocLibTest.class,
	RequiredVarsCleanUpAndACkTemplateTest.class,
	RequiredVarsForEmailProcessorTransactionMetadataTest.class,
	RequiredVarsForMatchAndMergeDocumentsFromDbTest.class,
	RequiredVarsForProviderEmailNotificationTest.class,
	RequiredVarsResponseFileProcessTest.class,
	RetrieveCorporateMPINv2Test.class,
	RetrieveEmailFromDigiSecTest.class,
	RetrieveProcessorTransactionTest.class,
	RetrieveProviderEmailAddressTest.class,
//	RetriveAdmissionDischargePreferencesTest.class,
	ScheduledCsvSftpMonitorTest.class,
	ScheduledSftpMonitorTest.class,
	SendACKFileToSftpServerTest.class,
	SendEmailListTest.class,
	SendEmailRequestToPENTest.class,
	SendFileToSFTPTest.class,
	SetProcessorTransactionMetadataForCosmosPRATest.class,
//	SftpProcessTest.class,
	
	SftpTest.class,
	TransformJsonAndGenerateFileTest.class,
		TransformJsonAndGenerateFileUSPClaimsTest.class,
	UpdateDocumentListInMongoTest.class,
	UpdateProcessorTransactionMetadataTest.class,
		USPClaimsResponseApiNotifyTest.class,
	ValidEmailRegexTest.class,
	VerifyRequiredVarsForSftpProcessTest.class,
	
	ProviderSearchTest.class,
	RetryUtilTest.class,
	ProcessFileTaskTest.class,
	DocumentMetaDataServiceTest.class,
	
	CommonConstantsTest.class,
	ProcessKeysTest.class,
	WorkflowConstantsTest.class,
	
	CSVProcessorControllerTest.class,
	DocumentControllerTest.class,
	DocumentRecordTest.class,
	FDSServicesControllerTest.class,
	HooksControllerTest.class,
	PDODocumentsControllerTest.class,
	ProcessorControllerTest.class,
	
	DocumentResponseServiceTest.class,
	DocumentResponseUtilTest.class,
	AttachmentTest.class,
	DocumentResponseTest.class,
	RulesTest.class,
	
	EmailConfigTest.class,
	EmailSenderTest.class,
	EmailUtilTest.class,
	
//	FSDataExceptionTest.class,
	InvalidExpressionExceptionTest.class,
	MongoDBApiExceptionTest.class,
	
	ProcessSummaryTest.class,
	SummaryFileTest.class,
	SummaryFileWithAttributesTest.class,
	
//	ConsumerServiceTest.class,

//		ConsumerServiceATSTest.class,
	

	
	ActiveUserTest.class,
	FixedLengthMetadataOCMTest.class,
	FixedLengthMetadataTest.class,
	GenericResponseTest.class,
	MultiPostResponseTest.class,
	MultiPutResponseTest.class,
	
	OauthTokenExtendedTest.class,
	TokenTest.class,
	AuthorizationOauthProviderTest.class,
	OauthManagerUtilImplTest.class,

	CsvSendErrorQueueTest.class,
	CsvSendQueueTest.class,
	HookSendErrorQueueTest.class,
	HookSendQueueTest.class,
	MetadataSendErrorQueueTest.class,
	MetadataSendQueueTest.class,

	ClientJsonTest.class,
	ClientRootMetadataTest.class,
	P360TXGCDocumentTest.class,
	SubCategoryTest.class,
	ReportResultTest.class,
	AttachmentRevisionTest.class,
	DocumentRevisionTest.class,
	HookRevisionTest.class,
	RevisionTest.class,
	CsvProcessorServiceImplTest.class,
	CsvProcessorsServiceImplTest.class,
	DocumentMetaDataServiceImplTest.class,
	DocvaultTransactionServiceImplTest.class,
	ErrorMetaDataServiceImplTest.class,
	JobsServiceImplTest.class,
	ProcessorServiceTest.class,
	ProcessorsServiceTest.class,
	ScheduledSftpMonitorTest.class,
	SendQueueServiceImplTest.class,
	ServiceBaseTest.class,
	ServiceExceptionTest.class,
	AuthorizationInitializeExceptionTest.class,
	ErrorCodeTest.class,
	HttpServerExceptionTest.class,
	OutOfRetriesExceptionTest.class,
	ProcessExceptionTest.class,
	PrunExceptionTest.class,
	ValidationExceptionTest.class,
	CallRestApiWithMsgServiceOnErrorCallbackTest.class,
	CreateStorageErrorZipfilePrintServicesTest.class,
	CsvSftpProcessTest.class,
	DelegateUtilsTest.class,
	KafkaProducerTest.class,
	PENRealTimeResponseMessageTest.class,
	PENRealTimeResponseTest.class,
	PENRealTimeTemplateResponseTest.class,
	PingTest.class,
	AckFileBeanTest.class,
	BatchInfoTXGCTest.class,
	BatchInfoTest.class,
	BatchTest.class,
	CodesTXGCTest.class,
	FDSCloudDocumentTest.class,
	FileDetailTest.class,
	ItemListTXGCTest.class,
	ItemListTest.class,
	TransactionDocumentListInfoTest.class,
	TransactionHookListInfoTest.class,
	TransactionReportListInfoTest.class,
	PostCardIndTest.class,
	CsvProcessorJobTest.class,
	JobTest.class,
	ProcessorCoreJobTest.class,
	ProcessorJobTest.class,
	RestApiJobTest.class,

	// provider.pojo
	AddressTest.class,
	AddressDataTest.class,
	AddressTypeTest.class,
	ContractInformationTypeTest.class,
	CorpOwnerInformationTypeTest.class,
	DegreeTest.class,
	EfficiencyTypeTest.class,
	EntityInformationTypeTest.class,
	MetadataTest.class,
	NpiTest.class,
	NpiTypeTest.class,
	OrganizationTest.class,
	PhoneTest.class,
	PhysicianFacilityInformationTest.class,
	PhysicianFacilityTest.class,
	PostalAddressTypeTest.class,
	ProviderTest.class,
	ProviderSearchResultsTest.class,
	QualityTypeTest.class,
	RecordsTest.class,
	RequestHeaderTest.class,
	RequestBodyTest.class,
	PostalAddressTypeTest.class,
	RequestBodyNPITest.class,
	RequestNPITest.class,
	RequestTest.class,
	RosterdataTest.class,
	SpecialtyTest.class,
	SpecialtyTypeTest.class,
	TaxIdTest.class,
	TaxIdTypeTest.class,
	UhpdDateRangeTypeTest.class,
	UhpdTypeTest.class,
	UnetContractTest.class,

	PayloadTest.class,
	AutoGeneratedTransactionIdHelperTest.class,
	CsvToJsonUtilTest.class,
	CustomHelperTest.class,
	SwitchCaseHelperTest.class,
	UHCWestFixedWidthHelperTest.class,
	SwitchCaseTest.class,
	FDSCloudGetDocumentsResponseTest.class,
	ProviderDocumentMetaDataTest.class,
	ProviderDocumentTest.class,
	ProviderDocumentsTest.class,
	ZipUtilBeanTest.class,

	RetrieveDataFromPESAPITest.class,
	SendKafkaMessageTest.class,
	SftpPPLTest.class,
	TransformJsonAndGenerateFileUSPClaimsTest.class,
	USPClaimsResponseFileApiNotifyTest.class,
	ApplicationUtilTest.class,
	EncryptionUtilTest.class,
	EnvironmentsTest.class,
	FileUtilTest.class,
	FsCredentialsTest.class,
	HookTransactionTest.class,
	StringUtilsTest.class,
	SftpUtilTest.class,
	UtilityTest.class,
	SftpMonitorUtilTest.class,
	HttpConstantsTest.class,
	ConvertFileToDocumentMetaDataTest.class,
	GenerateDataFileForELGSTest.class,
	GroupDocumentsByMetadataTest.class,
	IdentifyDocumentsFromDbUSPClaimsTest.class,
	IdentifyStorageErrorDocumentsTest.class,
	ManipulateStorageErrorPdfFileTest.class,
        MemberInfoTest.class,
        RequestedMemberTest.class,
        RequestingMemberTest.class,
        ProviderDetailsTest.class,
		SSBCIEmailRequestToPENTemplateTest.class,
        ProcessorTransactionsServiceImplTest.class,
        ZipUtilImplTest.class,
        EmailServiceImplTest.class,
        CsvProcessorsMonitorTest.class,
        FilestoreServiceImplTest.class,
        EhCacheTest.class,
        FDSHelperTest.class,
        ErrorListenerTest.class,
        HookTransactionUtilTest.class,
        WorkFlowUtilTest.class,
        ProcessorTaskUtilTest.class,
        ParserTest.class,
        ProcessorUtilTest.class,
        DocumentUtilTest.class,
        OauthTokenCacheExpiryPolicyTest.class

})

public class ActivitiTestSuite extends TestCase {

}
