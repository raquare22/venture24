package com.optum.fds.paperless.processing.service;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.query.Criteria;
import com.optum.fds.paperless.domain.service.ProcessorTransactionService;
import com.optum.fds.paperless.domain.service.TransactionService;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;

@RunWith(MockitoJUnitRunner.class)
public class ProcessorTransactionsServiceImplTest {

	@Mock
	ProcessorTransactionService processorTransactionService;

	@Mock
	TransactionService transactionService;

	@InjectMocks
	ProcessorTransactionsServiceImpl processorTransactionsServiceImpl;

	public String SERVER_TYPE = "SERVER_TYPE";
	public String VERSION = "1";
	public boolean sendCompanionFileMissingEmail;
	public boolean sendCompanionFileUnreadableEmail;
	public String sampleZipFileName;
	public Date companionFileDateReceived;

	@SuppressWarnings("static-access")
	@Test
	public void createHookTransactionTest() throws Exception {
		ProcessorTransactionMetadata processorTransactionMetadata = new ProcessorTransactionMetadata();
		processorTransactionMetadata.setClientId(2323);
		processorTransactionMetadata.setConfigSpaceId(234);
		processorTransactionMetadata.setAppIdentifier("test");
		processorTransactionMetadata.setFileName("test");
		ProcessorTransactionMetadata result = processorTransactionsServiceImpl
				.createProcessorTransactionMetadata(Map.of("test", "one"), "testprocess", 234, "test");
		assertNull(result);
	}

	@SuppressWarnings("static-access")
	@Test
	public void updateProcessorTransactionMetadataTest() throws Exception {
		ProcessorTransactionMetadata processorTransactionMetadata = new ProcessorTransactionMetadata();
		ProcessorTransactionMetadata result = processorTransactionsServiceImpl
				.updateProcessorTransactionMetadata(processorTransactionMetadata);
		assertNull(result);
	}

	@SuppressWarnings("static-access")
	@Test
	public void getProcessorTransactionMetadataWithFileNameTest() throws Exception {
		ProcessorTransactionMetadata processorTransactionResult = processorTransactionsServiceImpl
				.getProcessorTransactionMetadataWithFileName("test");
		assertNull(processorTransactionResult);
	}

	@SuppressWarnings("static-access")
	@Test
	public void getProcessorTransactionMetaDataTest() throws Exception {
		Criteria criteria = new Criteria();
		List<ProcessorTransactionMetadata> processorTransactionResult = processorTransactionsServiceImpl
				.getProcessorTransactionMetaData("searchCriteriaJson", criteria);
		assertNotNull(processorTransactionResult);
	}

	@SuppressWarnings("static-access")
	@Test
	public void findProcessorTransactionByFileNameTest() throws Exception {
		ProcessorTransaction ProcessorTransactionResult = processorTransactionsServiceImpl
				.findProcessorTransactionByFileName("searchCriteriaJson", 12343);
		assertNull(ProcessorTransactionResult);
	}

	@SuppressWarnings("static-access")
	@Test
	public void createProcessorTransactionMetadataClientHashmapTest() throws Exception {
		Map<String, Object> mapexpected = new HashMap<>();
		mapexpected.put("sendCompanionFileMissingEmail", sendCompanionFileMissingEmail);
		mapexpected.put("sendCompanionFileUnreadableEmail", sendCompanionFileUnreadableEmail);
		mapexpected.put("sampleZipFileName", sampleZipFileName);
		mapexpected.put("companionFileDateReceived", companionFileDateReceived);
		Map<String, Object> mapResult = processorTransactionsServiceImpl
				.createProcessorTransactionMetadataClientHashmap(sendCompanionFileMissingEmail,
						sendCompanionFileUnreadableEmail, sampleZipFileName, companionFileDateReceived);
		assertNotNull(mapResult);
	}
}
