package com.optum.fds.paperless.processing.service.util;

import static org.junit.Assert.assertNotNull;

import static org.junit.Assert.assertSame;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;

import java.lang.reflect.Field;

public class ProcessorUtilTest {

	@Mock
	ProcessorMetaData processorMetaDataMocked;

	@InjectMocks
	ProcessorUtil processorUtil;

	@SuppressWarnings("deprecation")
	@Before
	public void init() throws IllegalAccessException, NoSuchFieldException {
		MockitoAnnotations.initMocks(this);
        Field instanceField = ProcessorUtil.class.getDeclaredField("instance");
        instanceField.setAccessible(true);
        instanceField.set(null, null);

    }


    @Before
    public void resetSingleton() throws Exception {
        Field instance = ProcessorUtil.class.getDeclaredField("instance");
        instance.setAccessible(true);
        instance.set(null, null);
    }

    @Test
	public void testSingletonObject() {
		ProcessorUtil object1 = ProcessorUtil.getInstance();
		ProcessorUtil object2 = ProcessorUtil.getInstance();
		assertEquals(object1, object2);
	}

	@Test
	public void testCreateRevisionIsSuccess() {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setId("id745");
		processorMetaData.setName("testname");
		assertNotNull(ProcessorUtil.createRevision(processorMetaData));
	}

	@Test(expected = NullPointerException.class)
	public void testCreateRevisionWithprocessorMetaDataNull() {
		assertNotNull(ProcessorUtil.createRevision(null));
	}


    @Test
    public void testGetInstance_ReturnsSameSingletonInstance() {
        com.optum.fds.paperless.processing.service.util.ProcessorUtil instance1 =
                com.optum.fds.paperless.processing.service.util.ProcessorUtil.getInstance();
        com.optum.fds.paperless.processing.service.util.ProcessorUtil instance2 =
                com.optum.fds.paperless.processing.service.util.ProcessorUtil.getInstance();

        Assert.assertNotNull(instance1);
        assertSame(instance1, instance2);
    }

    @Test
    public void testCreateRevision_WhenCopyPropertiesThrows_ReturnsRevision() {
        ProcessorMetaData metaData = new ProcessorMetaData();
        metaData.setId("p1");
        metaData.setName("processor-name");

        try (org.mockito.MockedStatic<org.springframework.beans.BeanUtils> beanUtilsMock =
                     org.mockito.Mockito.mockStatic(org.springframework.beans.BeanUtils.class)) {

            beanUtilsMock.when(() -> org.springframework.beans.BeanUtils.copyProperties(
                            any(ProcessorMetaData.class),
                            any(com.optum.fds.paperless.mongo.processors.ProcessorRevision.class)))
                    .thenThrow(new RuntimeException("copy failed"));

            com.optum.fds.paperless.mongo.processors.ProcessorRevision revision =
                    com.optum.fds.paperless.processing.service.util.ProcessorUtil.createRevision(metaData);

            Assert.assertNotNull(revision);
            beanUtilsMock.verify(() -> org.springframework.beans.BeanUtils.copyProperties(
                            any(ProcessorMetaData.class),
                            any(com.optum.fds.paperless.mongo.processors.ProcessorRevision.class)),
                    org.mockito.Mockito.times(1));
        }
    }

    @Test
    public void testGetInstance_WhenInstanceIsNull_CreatesNewInstance() throws Exception {
        Field instanceField = ProcessorUtil.class.getDeclaredField("instance");
        instanceField.setAccessible(true);
        instanceField.set(null, null); // force null branch

        ProcessorUtil instance = ProcessorUtil.getInstance();

        assertNotNull(instance);
        assertSame(instance, instanceField.get(null));
    }

    @Test
    public void testGetInstance_WhenInstanceAlreadyExists_ReturnsSameInstance() throws Exception {
        Field instanceField = ProcessorUtil.class.getDeclaredField("instance");
        instanceField.setAccessible(true);
        instanceField.set(null, null);

        ProcessorUtil first = ProcessorUtil.getInstance();
        ProcessorUtil second = ProcessorUtil.getInstance();

        assertNotNull(first);
        assertSame(first, second);
    }

    @Test
    public void testCreateRevision_WhenCopyPropertiesThrows_UsesProcessorMetaDataFieldsInCatchBlock() {
        ProcessorMetaData metaData = mock(ProcessorMetaData.class);
        when(metaData.getId()).thenReturn("meta-123");
        when(metaData.getName()).thenReturn("meta-name");

        try (org.mockito.MockedStatic<org.springframework.beans.BeanUtils> beanUtilsMock =
                     org.mockito.Mockito.mockStatic(org.springframework.beans.BeanUtils.class)) {

            beanUtilsMock.when(() -> org.springframework.beans.BeanUtils.copyProperties(
                            eq(metaData),
                            any(com.optum.fds.paperless.mongo.processors.ProcessorRevision.class)))
                    .thenThrow(new RuntimeException("copy failed"));

            com.optum.fds.paperless.mongo.processors.ProcessorRevision revision =
                    ProcessorUtil.createRevision(metaData);

            assertNotNull(revision);
            verify(metaData, atLeastOnce()).getId();
            verify(metaData, atLeastOnce()).getName();
        }
    }

    @Test
    public void testCreateRevision_WhenCopyPropertiesThrows_ReturnsProcessorRevisionInstance() {
        ProcessorMetaData metaData = new ProcessorMetaData();
        metaData.setId("p1");
        metaData.setName("processor-name");

        try (org.mockito.MockedStatic<org.springframework.beans.BeanUtils> beanUtilsMock =
                     org.mockito.Mockito.mockStatic(org.springframework.beans.BeanUtils.class)) {

            beanUtilsMock.when(() -> org.springframework.beans.BeanUtils.copyProperties(
                            any(ProcessorMetaData.class),
                            any(com.optum.fds.paperless.mongo.processors.ProcessorRevision.class)))
                    .thenThrow(new RuntimeException("copy failed"));

            com.optum.fds.paperless.mongo.processors.ProcessorRevision revision =
                    ProcessorUtil.createRevision(metaData);

            assertNotNull(revision);
        }
    }
}
