package com.optum.fds.paperless.constants;
import org.junit.Test;

import static org.junit.Assert.*;

public class ProcessKeysTest {

    @Test
    public void testProcessKeys() {
        assertEquals("processorMetaData", ProcessKeys.PROCESS_METADATA);
        assertEquals("sftpProcess", ProcessKeys.SFTP_PROCESS_KEY);
        assertEquals("sftpZipUnzipProcess", ProcessKeys.SFTP_ZIP_UNZIP_PROCESS_KEY);
        assertEquals("processFileUnzip", ProcessKeys.UNZIP_FILE_PROCESS_KEY);
        assertEquals("processMetadataFiles", ProcessKeys.PROCESS_METADATA_PROCESS_KEY);
        assertEquals("processMetadataFilesCallback", ProcessKeys.PROCESS_METADATA_CALLBACK_PROCESS_KEY);
        assertEquals("csvSftpProcess", ProcessKeys.CSV_SFTP_PROCESS_KEY);
        assertEquals("createStatusFileAndAckProcess", ProcessKeys.STATUSFILE_PROCESS_KEY);
        assertEquals("sendDocumentsToShutterflyProcess", ProcessKeys.SHUTTERFLY_PROCESS_KEY);
        assertEquals("sendStorageErrorToShutterfly", ProcessKeys.STORAGE_ERROR_SHUTTERFLY_PROCESS_KEY);
        assertEquals("createResponseFileProcess", ProcessKeys.RESPONSEFILE_PROCESS_KEY);
        assertEquals("createResponseFileProcessUSPClaims", ProcessKeys.RESPONSEFILE_PROCESS_KEY_USP_CLAIMS);
        assertEquals("bouncedProviderEmailAddressProcess", ProcessKeys.BOUNCE_PROCESS_KEY);
        assertEquals("retrieveProviderEmailAddressProcess", ProcessKeys.RETRIEVE_PROVIDER_EMAIL_PROCESS_KEY);
        assertEquals("requiredFieldRuleProcess", ProcessKeys.REQUIRED_FIELD_RULE_PROCESS_KEY);
        assertEquals("retrieveCorporateMPINv2Process", ProcessKeys.RETRIEVE_CORPORATE_MPIN_PROCESS_KEY);
        assertEquals("providerEmailNotificationProcess", ProcessKeys.PROVIDER_EMAIL_NOTIFICATION_PROCESS_KEY);
        assertEquals("matchAndMergeDocumentsFromDbProcess", ProcessKeys.MATCH_AND_MERGE_PROCESS_KEY);
        assertEquals("emailProcessorTransactionMetadataProcess", ProcessKeys.EMAIL_PROCESSOR_TRANSACTION_METADATA_PROCESS_KEY);
        assertEquals("processCleanupFilesCreateACK", ProcessKeys.CLEANUP_PROCESS_KEY);
        assertEquals("postDocumentDocvaultForElgsProcess", ProcessKeys.DOCLIB_PROCESS_KEY);
        assertEquals("csvCleanupFilesProcess", ProcessKeys.CSV_CLEANUP_PROCESS_KEY);
        assertEquals("GENERIC_WORKFLOW_PROCESS_KEY", ProcessKeys.GENERIC_WORKFLOW_PROCESS_KEY);
        assertEquals("postDocumentDocvaultForElgsProcess", ProcessKeys.POST_DOCUMENT_DOCLIB_FOR_ELGS_PROCESS_KEY);
        assertEquals("callRestApiWithMsgServiceOnErrorCallback", ProcessKeys.CALL_REST_API_WITH_MSG_SERVICE_ON_ERROR_CALLBACK_PROCESS_KEY);
        assertEquals("processTextFile", ProcessKeys.PROCESS_TEXT_FILE);
        assertEquals("sftpSendEmailProcess", ProcessKeys.PROCESS_SFTP_SEND_EMAIL);
        assertEquals("retrieveAndSendMetadataProcess", ProcessKeys.RETRIEVE_AND_SEND_METADATA_PROCESS);
        assertEquals("createResponseMessageProcess", ProcessKeys.RESPONSE_MESSAGE_PROCESS_KEY);
        assertEquals("retrieveAndSendEmailProcess", ProcessKeys.RETRIEVE_AND_SEND_EMAIL_PROCESS);
        assertEquals("sendBatchDynamicEmailRequestToPEN", ProcessKeys.SEND_BATCH_DYNAMIC_REQUEST_TO_PEN);
    }
}
