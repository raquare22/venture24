package com.optum.fds.paperless.constants;

import org.junit.Test;
import static org.junit.Assert.*;

public class CommonConstantsTest {

    @Test
    public void testConstants() {
        assertEquals("spring.profiles.active", CommonConstants.SPRING_PROFILES_ACTIVE);
        assertEquals("SOMETHING WENT WRONG ERROR={}", CommonConstants.SOMETHING_WENT_WRONG);
        assertEquals("FDSRetryCountMax", CommonConstants.FDS_RETRY_COUNT_MAX);
        assertEquals("FDSRetrySleepTimeMS", CommonConstants.FDS_RETRY_SLEEP_TIME_MS);
        assertEquals("FDSDocumentsUrl", CommonConstants.FDS_DOCUMENTS_URL);
        assertEquals("FDSPostPDODocumentsUrl", CommonConstants.FDS_POST_PDO_DOCUMENTS_URL);
        assertEquals("FDSRetentionPeriod", CommonConstants.FDS_RETENTION_PERIOD);
        assertEquals("documents", CommonConstants.FS2_DOCUMENTS_BODY_NAME);
        assertEquals("INGEST_ROOT", CommonConstants.INGEST_ROOT);
        assertEquals("csv.json", CommonConstants.CSV_JSON_FILENAME);
        assertEquals("id", CommonConstants.QUEUED_ID);
        assertEquals("pathVariable", CommonConstants.QUEUED_PATH_VARIABLE);
        assertEquals("apiUrl", CommonConstants.QUEUED_API_URL);
        assertEquals("delegate", CommonConstants.QUEUED_DELEGATE);
        assertEquals("delegateParms", CommonConstants.QUEUED_DELEGATE_PARMS);
        assertEquals("retryCount", CommonConstants.QUEUED_RETRY_CNT);
        assertEquals("queuedRequest", CommonConstants.QUEUED_REQUEST);
        assertEquals("httpMethod", CommonConstants.QUEUED_HTTP_METHOD);
        assertEquals("SendQueueNeedsSpaceId", CommonConstants.SEND_QUEUE_NEEDS_SPACE_ID);
        assertEquals("CsvSendQueueAutoError", CommonConstants.CSV_SEND_QUEUE_AUTO_ERROR);
        assertEquals("HookSendQueueAutoError", CommonConstants.HOOK_SEND_QUEUE_AUTO_ERROR);
        assertEquals("MetadataSendQueueAutoError", CommonConstants.METADATA_SEND_QUEUE_AUTO_ERROR);
        assertEquals("ftp_rootdir", CommonConstants.FTP_ROOT_DIR);
        assertEquals("emailAlertReq", CommonConstants.EMAIL_ALERT_REQ);
        assertEquals("ELR_SMTP_RELAY_HOST", CommonConstants.ELR_SMTP_RELAY_HOST);
        assertEquals("serverType", CommonConstants.SERVER_TYPE);
        assertEquals("8081", CommonConstants.ENGINE_PORT_DEFAULT);
        assertEquals("AzureWithIdentifiersUrl", CommonConstants.AZURE_WITH_IDENTIFIERS_URL);
        assertEquals("AzureUrl", CommonConstants.AZURE_URL);
        assertEquals("AzureScheduleUrl", CommonConstants.AZURE_SCHEDULE_URL);
        assertEquals("AzureDlqUrl", CommonConstants.AZURE_DLQ_URL);
        assertEquals("EngineDelegateUrl", CommonConstants.ENGINE_DELIGATE_URL);
        assertEquals("HighPriorityQueue", CommonConstants.HIGH_QUEUE);
        assertEquals("MediumPriorityQueue", CommonConstants.MEDIUM_QUEUE);
        assertEquals("LowPriorityQueue", CommonConstants.LOW_QUEUE);
    }


}