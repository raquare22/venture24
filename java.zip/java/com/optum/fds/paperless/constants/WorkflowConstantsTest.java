package com.optum.fds.paperless.constants;

import org.junit.Test;
import static org.junit.Assert.*;

public class WorkflowConstantsTest {

    @Test
    public void testWorkflowConstants() {
        assertEquals("appId", WorkflowConstants.APP_ID);
        assertEquals("appSecret", WorkflowConstants.APP_SECRET);
        assertEquals("grant_type", WorkflowConstants.GRANT_TYPE);
        assertEquals("appIdentifier", WorkflowConstants.APP_IDENTIFIER);
        assertEquals("job", WorkflowConstants.JOB);
        assertEquals("oauth_error_message", WorkflowConstants.OAUTH_ERROR_MESSAGE);
        assertEquals("fdsAuthUrl", WorkflowConstants.OAUTH_URL);
        assertEquals("oauth_token", WorkflowConstants.OAUTH_TOKEN);
        assertEquals("CorrelationID", WorkflowConstants.CORRELATION_IDS);
        assertEquals("oauthToken", WorkflowConstants.OAUTH_TOKEN_V1);
        assertEquals("processorMetaData", WorkflowConstants.PROCESSOR_METADATA);
        assertEquals("errorMap", WorkflowConstants.ERROR_MAP);
        assertEquals("newErrors", WorkflowConstants.NEW_ERRORS);
        assertEquals("Documents", WorkflowConstants.DOCUMENTS);
        assertEquals("eDeliveryError", WorkflowConstants.E_DELIVERY_ERROR);
        assertEquals("search_window", WorkflowConstants.SEARCH_WINDOW);
        assertEquals("time_window", WorkflowConstants.SEARCH_WINDOW_TIMEWINDOW);
        assertEquals("format", WorkflowConstants.SEARCH_WINDOW_FORMAT);
        assertEquals("start_date", WorkflowConstants.SEARCH_WINDOW_START_DATE);
        assertEquals("start_date_offset", WorkflowConstants.SEARCH_WINDOW_START_DATE_OFFSET);
        assertEquals("end_date", WorkflowConstants.SEARCH_WINDOW_END_DATE);
        assertEquals("end_date_offset", WorkflowConstants.SEARCH_WINDOW_END_DATE_OFFSET);
        assertEquals("INGEST_ROOT", WorkflowConstants.INGEST_ROOT);
        assertEquals("dateCreated", WorkflowConstants.PROCESSOR_DATE_CREATED);
        assertEquals("ProcessorTransactions", WorkflowConstants.PROCESSOR_TRANSACTIONS);
        assertEquals("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", WorkflowConstants.DATE_FORMAT);
    }
}