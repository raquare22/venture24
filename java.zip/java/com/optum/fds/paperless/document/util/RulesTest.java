package com.optum.fds.paperless.document.util;

import org.junit.Test;
import static org.junit.Assert.*;

public class RulesTest {

    @Test
    public void testGetAndSetCustomRule() {
        Rules rules = new Rules();
        String customRule = "Custom Rule";
        rules.setCustomRule(customRule);
        assertEquals(customRule, rules.getCustomRule());
    }

    @Test
    public void testGetAndSetEncryptScheme() {
        Rules rules = new Rules();
        String encryptScheme = "AES";
        rules.setEncryptScheme(encryptScheme);
        assertEquals(encryptScheme, rules.getEncryptScheme());
    }

    @Test
    public void testGetAndSetVirusScan() {
        Rules rules = new Rules();
        String virusScan = "Enabled";
        rules.setVirusScan(virusScan);
        assertEquals(virusScan, rules.getVirusScan());
    }

    @Test
    public void testGetAndSetConvertTo() {
        Rules rules = new Rules();
        String convertTo = "PDF";
        rules.setConvertTo(convertTo);
        assertEquals(convertTo, rules.getConvertTo());
    }
}