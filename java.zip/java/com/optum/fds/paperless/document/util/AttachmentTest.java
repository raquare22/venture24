package com.optum.fds.paperless.document.util;

import com.optum.fds.paperless.domain.revision.AttachmentRevision;

import com.optum.fds.paperless.mongo.AttachmentMetaData;
import org.junit.Test;


public class AttachmentTest {

    @Test
    public void testIt() {
        com.optum.fds.paperless.document.util.Attachment attachment = new com.optum.fds.paperless.document.util.Attachment();
        attachment.getId();
        attachment.setId(new java.lang.String());
        attachment.getStatus();
        attachment.setStatus(new java.lang.String());
        attachment.getSpaceId();
        attachment.setSpaceId(0);
        attachment.getExpires();
        attachment.setExpires(null);
        attachment.getFileName();
        attachment.setFileName(new java.lang.String());
        attachment.getFileSize();
        attachment.setFileSize(0L);
        attachment.getContentType();
        attachment.setContentType(new java.lang.String());
        attachment.getDateCreated();
        attachment.setDateCreated(null);
        attachment.getExternalId();
        attachment.setExternalId(new java.lang.String());
        attachment.setIndex(0);
        attachment.getSourceSystemName();
        attachment.setSourceSystemName(new java.lang.String());
        attachment.getSourceSystemDateCreated();
        attachment.setSourceSystemDateCreated(null);
        attachment.getRevisions();
        attachment.setRevisions(null);
        attachment.getIndex();
        attachment.getFileId();
        attachment.setFileId(new java.lang.String());
        attachment.getFileDescription();
        attachment.setFileDescription(new java.lang.String());
        attachment.getFileCreatedDate();
        attachment.setFileCreatedDate(null);
        attachment.getFileSize();
        attachment.setFileSize(new java.lang.String());
        attachment.getSpaceIdUnder();
        attachment.setSpaceIdUnder(new java.lang.Integer("1"));
        attachment.getFileNameUnder();
        attachment.setFileNameUnder(new java.lang.String());
        attachment.getFileSizeUnder();
        attachment.setFileSizeUnder(new java.lang.Integer("1"));
        attachment.getContentTypeUnder();
        attachment.setContentTypeUnder(new java.lang.String());


    }



    @Test
    public void testNotNulls() {
        com.optum.fds.paperless.document.util.Attachment attachment =new  com.optum.fds.paperless.document.util.Attachment();
        attachment.setExpires(new java.util.Date());
        attachment.getExpires();
        attachment.setDateCreated(new java.util.Date());
        attachment.getDateCreated();
        attachment.setSourceSystemName(new java.lang.String());
        attachment.getSourceSystemName();
        attachment.setSourceSystemDateCreated(new java.util.Date());
        attachment.getSourceSystemDateCreated();
        attachment.setRevisions(new java.util.ArrayList<AttachmentRevision>());
        attachment.getRevisions();
    }


}
