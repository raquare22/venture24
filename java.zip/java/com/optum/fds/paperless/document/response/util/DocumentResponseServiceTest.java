package com.optum.fds.paperless.document.response.util;


import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import com.optum.fds.paperless.document.util.DocumentResponse;
import com.optum.fds.paperless.document.util.Rules;
import com.optum.fds.paperless.domain.revision.DocumentRevision;
import com.optum.fds.paperless.domain.service.TransactionService;
import com.optum.fds.paperless.domain.service.exception.ServiceException;
import com.optum.fds.paperless.mongo.*;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.util.Parser;
import org.bson.Document;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static com.optum.fds.paperless.mongo.processors.MetaDataStatus.AVAILABLE;
import static org.mockito.Mockito.when;


public class DocumentResponseServiceTest {

    @Mock
    TransactionService transactionService;
    MetaDataStatus metaDataStatus = AVAILABLE;
    DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    Date dateCreated = sdf.parse("2014-02-11");
    Date dateModified = sdf.parse("2014-02-12");
    List<DocumentAttachmentMetaData> documentAttachments;
    Document metadata;
    List<DocumentRevision> revisions;
    DocumentMetaData documentMetaData;
    List<AttachmentMetaData> attachments;
    DocumentResponseService documentResponseService;

    public DocumentResponseServiceTest() throws ParseException {
    }

    @Before
    public void setup() throws ParseException {

        documentAttachments = createDocumentAttachments();
        metadata = createMetadata();
        revisions = createRevisions(metaDataStatus, dateCreated, dateModified, documentAttachments, metadata);

        Transaction transaction = new Transaction();
        MockitoAnnotations.initMocks(this);
        when(transactionService.saveTransationMetaData(Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), (TransactionDocumentListInfo) Mockito.any())).thenReturn(transaction);

        attachments = createAttachments(metaDataStatus, dateCreated, dateModified);

        documentResponseService = new DocumentResponseService();
    }

    @Test
    public void testBuildDocumentResponseInJsonForPost() throws IOException, ServiceException, ParseException {

        DocumentMetaData documentMetaData = createDocumentMetaData(metaDataStatus, dateCreated, dateModified, documentAttachments, metadata, null);
        List<AttachmentMetaData> attachments = createAttachments(metaDataStatus, dateCreated, dateModified);

        DocumentResponseService documentResponseService = new DocumentResponseService();
        String result = documentResponseService.buildDocumentResponseInJson(documentMetaData, attachments);
        HashMap<String, Object> resultMap = Parser.parseJson(result, HashMap.class);
        Assert.assertEquals("AVAILABLE", resultMap.get("status"));
        Assert.assertEquals("58f723f9d4c6c8877bd12ecb", resultMap.get("id"));
        Assert.assertNotNull("metadata exists", resultMap.get("metadata"));
        Assert.assertEquals(dateCreated.toString(), resultMap.get("dateCreated"));
        Assert.assertEquals(3105, resultMap.get("spaceId"));
        Assert.assertEquals(1, ((LinkedHashMap<String, Object>) resultMap.get("metadata")).size());
        Assert.assertEquals("attachments exists", 1, ((ArrayList) resultMap.get("attachments")).size());
    }

    @Test
    public void testBuildDocumentResponseInJsonForPut() throws IOException, ServiceException, ParseException {
        documentMetaData = createDocumentMetaData(metaDataStatus, dateCreated, dateModified, null, metadata, revisions);
        String result = documentResponseService.buildDocumentResponseInJson(documentMetaData, attachments);
        HashMap<String, Object> resultMap = Parser.parseJson(result, HashMap.class);
        Assert.assertEquals("AVAILABLE", resultMap.get("status"));
        Assert.assertEquals("58f723f9d4c6c8877bd12ecb", resultMap.get("id"));
        Assert.assertNotNull("metadata exists", resultMap.get("metadata"));
        Assert.assertEquals(1, ((LinkedHashMap<String, Object>) resultMap.get("metadata")).size());
        Assert.assertEquals(3105, resultMap.get("spaceId"));
        Assert.assertEquals(dateCreated.toString(), resultMap.get("dateCreated"));
    }

    @Test
    public void testPrepareFullDocumentResponseForPost() {
        DocumentMetaData documentMetaData = createDocumentMetaData(metaDataStatus, dateCreated, dateModified, documentAttachments, metadata, null);
        DocumentResponse documentResponse = documentResponseService.prepareFullDocumentResponse(documentMetaData, attachments);
        Assert.assertEquals(1, documentResponse.getAttachments().length);
        Assert.assertEquals(3105, (long)documentResponse.getSpaceId());
        Assert.assertEquals("AVAILABLE", documentResponse.getStatus());
        Assert.assertEquals("1234", documentResponse.getExternalId());
        Assert.assertEquals(1, documentResponse.getMetadata().size());
        Assert.assertEquals(dateCreated.toString(), documentResponse.getDateCreated());
    }

    @Test
    public void testPrepareFullDocumentResponseForPut() {
        documentMetaData = createDocumentMetaData(metaDataStatus, dateCreated, dateModified, null, metadata, revisions);
        DocumentResponse documentResponse = documentResponseService.prepareFullDocumentResponse(documentMetaData, attachments);
        Assert.assertEquals(3105, (long)documentResponse.getSpaceId());
        Assert.assertEquals("AVAILABLE", documentResponse.getStatus());
        Assert.assertEquals("1234", documentResponse.getExternalId());
        Assert.assertEquals(1, documentResponse.getMetadata().size());
        Assert.assertEquals(dateCreated.toString(), documentResponse.getDateCreated());
        Assert.assertEquals(1, documentResponse.getRevisions().size());
    }

    private DocumentMetaData createDocumentMetaData(MetaDataStatus metaDataStatus,
                                                    Date dateCreated,
                                                    Date dateModified,
                                                    List<DocumentAttachmentMetaData> documentAttachments,
                                                    Document metadata,
                                                    List<DocumentRevision> revisions) {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setId("58f723f9d4c6c8877bd12ecb");
        documentMetaData.setExternalId("1234");
        documentMetaData.setSpaceId(3105);
        documentMetaData.setDateCreated(dateCreated);
        documentMetaData.setDateModified(dateModified);
        documentMetaData.setTransactionId("58f721ffd4c6c8877bd12ec7");
        documentMetaData.setClientId(1);
        documentMetaData.setAppIdentifier("testapp");
        documentMetaData.setStatus(metaDataStatus);
        if (documentAttachments != null) {
            documentMetaData.setDocumentAttachments(documentAttachments);
        }
        documentMetaData.setMetadata(metadata);
        if (revisions != null) {
            documentMetaData.setRevisions(revisions);
        }
        return documentMetaData;
    }

    private List<AttachmentMetaData> createAttachments(MetaDataStatus metaDataStatus, Date dateCreated, Date dateModified) {
        List<AttachmentMetaData> attachments = new ArrayList<AttachmentMetaData>();

        AttachmentMetaData attachment = new AttachmentMetaData();
        attachment.setAdapterId("3105");
        attachment.setAdapterTypeId("20");
        attachment.setContentType("image/png");
        attachment.setFileName("close-active.png");
        attachment.setFsId("2b22398e-b392-4555-abca-4b176177a81b");
        attachment.setAsync(false);
        attachment.setSpaceId(3105);
        attachment.setId("58f723f9d4c6c8877bd12ec9");
        attachment.setAppIdentifier("testapp");
        attachment.setClientId(1);
        attachment.setDateCreated(dateCreated);
        attachment.setDateModified(dateModified);
        attachment.setStatus(metaDataStatus);
        attachment.setTransactionId("58f721ffd4c6c8877bd12ec7");

        attachments.add(attachment);
        return attachments;
    }

    private List<DocumentRevision> createRevisions(MetaDataStatus metaDataStatus, Date dateCreated, Date dateModified, List<DocumentAttachmentMetaData> documentAttachments, Document metadata) {
        DocumentRevision documentRevision = new DocumentRevision();
        documentRevision.setDocumentAttachments(documentAttachments);
        documentRevision.setMetadata(metadata);
        documentRevision.setAppIdentifier("testapp");
        documentRevision.setClientId(1);
        documentRevision.setDateCreated(dateCreated);
        documentRevision.setDateModified(dateModified);
        documentRevision.setSpaceId(3105);
        documentRevision.setStatus(metaDataStatus);
        documentRevision.setTransactionId("58f72bc2d4c6c8877bd12ed8");
        ArrayList<DocumentRevision> revisionList = new ArrayList<DocumentRevision>();
        revisionList.add(documentRevision);
        return revisionList;
    }

    private Document createMetadata() {
        Document metadata = new Document();
        HashMap values = new HashMap();
        values.put("providerId", "sample_provider");
        metadata.putAll(values);
        return metadata;
    }

    private List<DocumentAttachmentMetaData> createDocumentAttachments() {
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("2b22398e-b392-4555-abca-4b176177a81b");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("close-active.png");

        List<DocumentAttachmentMetaData> documentAttachments = new ArrayList<DocumentAttachmentMetaData>();
        documentAttachments.add(documentAttachmentMetaData);
        return documentAttachments;
    }

/*
    @Test
    public void RulesTest()  throws StorageException {
        Rules rules = new Rules();
        rules.setCustomRule("myRule");
        rules.setCustom_rule("myRule");
        rules.getCustom_rule();
        rules.setEncrypt_scheme("myScheme");
        rules.getEncrypt_scheme();
        rules.setVirus_scan("theScan");
        rules.getVirus_scan();
        rules.setConvert_to("this");
        rules.getConvert_to();
    }
*/

/*
    @Test
    public void BaseExceptionTest()  throws StorageException {
        BaseException baseException = new BaseException(null, new ErrorResponse("test","1"));
        BaseException baseException1 = new BaseException(null, null, null);

        baseException.setStatus(null);
        baseException.getStatus();
        baseException.setErrorCode("myScheme");
        baseException.getErrorCode();
        baseException.getErrorResponse();
    }
*/
}
