package com.optum.fds.paperless.client;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class P360TXGCDocumentTest {

    @Test
    public void testGettersAndSetters() {
        P360TXGCDocument document = new P360TXGCDocument();

        document.setNpi("1234567890");
        assertEquals("1234567890", document.getNpi());

        document.setExemptionApprovalStatus("Approved");
        assertEquals("Approved", document.getExemptionApprovalStatus());

        document.setExemptionStartDt("2023-01-01");
        assertEquals("2023-01-01", document.getExemptionStartDt());

        document.setExemptionEndDt("2023-12-31");
        assertEquals("2023-12-31", document.getExemptionEndDt());

        document.setExemptionCycleStartDt("2023-01-01");
        assertEquals("2023-01-01", document.getExemptionCycleStartDt());

        document.setExemptionCycleEndDt("2023-12-31");
        assertEquals("2023-12-31", document.getExemptionCycleEndDt());
    }

    @Test
    public void testToString() {
        P360TXGCDocument document = new P360TXGCDocument();
        document.setNpi("1234567890");
        document.setExemptionApprovalStatus("Approved");
        document.setExemptionStartDt("2023-01-01");
        document.setExemptionEndDt("2023-12-31");
        document.setExemptionCycleStartDt("2023-01-01");
        document.setExemptionCycleEndDt("2023-12-31");

        String expected = "P360TXGCDocument{npi=1234567890, ExemptionApprovalStatus='Approved', ExemptionStartDt='2023-01-01', ExemptionEndDt='2023-12-31', ExemptionCycleStartDt='2023-01-01', ExemptionCycleEndDt='2023-12-31'}";
        assertEquals(expected, document.toString());
    }
}