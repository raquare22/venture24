package com.optum.fds.paperless.client;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Date;

import org.junit.Test;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;

public class CustomDateSerializerTest {

	@SuppressWarnings("deprecation")
	@Test
	public void testSerializeIstrue() throws JsonProcessingException, IOException
	{
		CustomDateSerializer dateSerializer = new CustomDateSerializer();
		 JsonFactory factory = new JsonFactory();
	      StringWriter jsonObjectWriter = new StringWriter();
	      JsonGenerator generator = factory.createGenerator(jsonObjectWriter);
		SerializerProvider provider = null;
		dateSerializer.serialize(new Date(2022,03,10), generator, provider);
	}
}
