package com.optum.fds.paperless.client;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;

import org.junit.Test;

public class ClientMetadataTest {
	
	@SuppressWarnings("deprecation")
	@Test
	public void testGetCreatedDate()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		Date date = new Date(2022, 03, 18);
		clientMetadata.setCreatedDate(date);
		assertEquals(date, clientMetadata.getCreatedDate());
	}
	
	@Test
	public void testGetDocSentTo()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setDocSentTo("testdoc");
		assertEquals("testdoc", clientMetadata.getDocSentTo());
	}
	
	@Test
	public void testGetSendToDocVault()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setSendToDocVault(true);
		assertEquals(true, clientMetadata.getSendToDocVault());
	}
	
	@Test
	public void testGetSendToShutterfly()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setSendToShutterfly(false);
		assertEquals(false, clientMetadata.getSendToShutterfly());
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testGetDateEmailSent()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		Date date = new Date(2022, 03, 18);
		clientMetadata.setDateEmailSent(date);
		assertEquals(date, clientMetadata.getDateEmailSent());
	}
	
	@Test
	public void testGetSendEmailNotifications()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setSendEmailNotifications(false);
		assertEquals(false, clientMetadata.getSendEmailNotifications());
	}
	
	@Test
	public void testGetSendPENAPIRequest()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setSendPENAPIRequest(false);
		assertEquals(false, clientMetadata.getSendPENAPIRequest());
	}
	
	@Test
	public void testGetCategory()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setCategory("categoryOne");
		assertEquals("categoryOne", clientMetadata.getCategory());
	}
	
	@Test
	public void testGetCorporateMpin()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setCorporateMpin("6956966s");
		assertEquals("6956966s", clientMetadata.getCorporateMpin());
	}
	
	@Test
	public void testGetCreateApplication()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setCreateApplication("app");
		assertEquals("app", clientMetadata.getCreateApplication());
	}
	
	@Test
	public void testGetExpiryDate()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setExpiryDate("10-15-2021");
		assertEquals("10-15-2021", clientMetadata.getExpiryDate());
	}
	
	@Test
	public void testGetFileDescription()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setFileDescription("testDescription");
		assertEquals("testDescription", clientMetadata.getFileDescription());
	}
	
	@Test
	public void testGetFileName()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setFileName("myfile.test");
		assertEquals("myfile.test", clientMetadata.getFileName());
	}
	
	@Test
	public void testGetFilePath()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setFilePath("/user/files/file");
		assertEquals("/user/files/file", clientMetadata.getFilePath());
	}
	
	@Test
	public void testGetFileType()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setFileType("pdf");
		assertEquals("pdf", clientMetadata.getFileType());
	}
	
	@Test
	public void testGetProviderEmailId()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setProviderEmailId("user@test.com");
		assertEquals("user@test.com", clientMetadata.getProviderEmailId());
	}
	
	@Test
	public void testGetTenant()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setTenant("testTenent");
		assertEquals("testTenent", clientMetadata.getTenant());
	}
	
	@Test
	public void testGetPrivilege()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setPrivilege("testPrevililage");
		assertEquals("testPrevililage", clientMetadata.getPrivilege());
	}
	
	@Test
	public void testGetPostCardInd()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setPostCardInd(false);
		assertEquals(false, clientMetadata.getPostCardInd());
	}

	@Test
	public void testVcpExpiryDate()
	{
		ClientMetadata clientMetadata = new ClientMetadata();
		clientMetadata.setExpiryDate("05/2022");
		assertEquals("2022-05-31T23:59:59.000Z", clientMetadata.vcpExpiryDateFormat(clientMetadata.getExpiryDate(),"P7"));
	}
	

}
