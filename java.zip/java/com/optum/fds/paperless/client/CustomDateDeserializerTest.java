package com.optum.fds.paperless.client;

import com.fasterxml.jackson.core.JsonParseException;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CustomDateDeserializerTest {

    private void testDate(CustomDateDeserializer deserializer, String jsonDate, String expectedDateStr) {
        JsonFactory factory = new JsonFactory();
        try {
            JsonParser parser = factory.createParser(jsonDate);
            DeserializationContext ctxt = new ObjectMapper().getDeserializationContext();
            parser.nextToken(); // Need to call this to initialize the parser

            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            formatter.setTimeZone(TimeZone.getTimeZone("UTC"));

            Date expectedDate = formatter.parse(expectedDateStr);
            String expected = formatter.format(expectedDate);

            Date actualDate = deserializer.deserialize(parser, ctxt);
            String actual = formatter.format(actualDate);

            assertEquals(expected, actual);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            System.out.println("Failed to parse expected date string: " + expectedDateStr);
            e.printStackTrace();
        }
    }


//    @Test
//    public void testDeserialize() throws IOException, ParseException {
//        CustomDateDeserializer deserializer = new CustomDateDeserializer(Date.class);
//
//        String jsonDate = "\"12/31/2021 5:45:22 AM\"";
//        String expectedDateStr = "2021-12-31T10:45:22.000Z"; // UTC time
//
//        JsonFactory factory = new JsonFactory();
//        JsonParser parser = factory.createParser(jsonDate);
//        DeserializationContext ctxt = new ObjectMapper().getDeserializationContext();
//        parser.nextToken();
//
//        // Input date format with assumed time zone
//        SimpleDateFormat inputFormatter = new SimpleDateFormat("MM/dd/yyyy h:mm:ss a");
//        inputFormatter.setTimeZone(TimeZone.getTimeZone("America/New_York")); // Adjust to input time zone
//
//        Date parsedDate = inputFormatter.parse(jsonDate.replace("\"", "")); // Parse input date
//        SimpleDateFormat outputFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
//        outputFormatter.setTimeZone(TimeZone.getTimeZone("UTC")); // Convert to UTC
//
//        String expectedDateStrFromInput = outputFormatter.format(parsedDate);
//
//        Date actualDate = deserializer.deserialize(parser, ctxt);
//        String actualDateStr = outputFormatter.format(actualDate);
//
//        assertEquals(expectedDateStrFromInput, actualDateStr);
//    }
//
//    @Test
//    public void testDeserialize1() throws IOException, ParseException {
//        CustomDateDeserializer deserializer = new CustomDateDeserializer(Date.class);
//
//        String jsonDate = "\"07262018\"";
//        String expectedDateStr = "2018-07-26T00:00:00.000Z"; // Midnight UTC
//
//        JsonFactory factory = new JsonFactory();
//        JsonParser parser = factory.createParser(jsonDate);
//        DeserializationContext ctxt = new ObjectMapper().getDeserializationContext();
//        parser.nextToken();
//
//        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
//        formatter.setTimeZone(TimeZone.getTimeZone("UTC")); // Ensure UTC
//
//        Date actualDate = deserializer.deserialize(parser, ctxt);
//        String actualDateStr = formatter.format(actualDate);
//
//        assertEquals(expectedDateStr, actualDateStr);
//    }
    @Test
    public void testDeserializeMonthNamePattern() throws IOException, ParseException {
        CustomDateDeserializer deserializer = new CustomDateDeserializer(Date.class);

        String jsonDate = "\"December 31, 2021\"";
        String expectedDateStr = "2021-12-31T00:00:00.000Z";

        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser(jsonDate);
        DeserializationContext ctxt = new ObjectMapper().getDeserializationContext();
        parser.nextToken();

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        // Use system's default timezone
        formatter.setTimeZone(TimeZone.getDefault());

        Date expectedDate = formatter.parse(expectedDateStr);
        Date actualDate = deserializer.deserialize(parser, ctxt);

        assertEquals(expectedDate.getTime(), actualDate.getTime());
    }
    @Test
    public void testDeserializeMonthNamePattern1() throws IOException, ParseException {
        CustomDateDeserializer deserializer = new CustomDateDeserializer(Date.class);

        String jsonDate = "\"December 1, 2021\"";
        String expectedDateStr = "2021-12-01T00:00:00.000Z";

        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser(jsonDate);
        DeserializationContext ctxt = new ObjectMapper().getDeserializationContext();
        parser.nextToken();

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        // Use system's default timezone
        formatter.setTimeZone(TimeZone.getDefault());

        Date expectedDate = formatter.parse(expectedDateStr);
        Date actualDate = deserializer.deserialize(parser, ctxt);

        assertEquals(expectedDate.getTime(), actualDate.getTime());
    }
    @Test
    public void testDeserializeFail() throws JsonParseException, IOException
    {
        Configurator.setAllLevels("", Level.DEBUG);
        String dateJson = "{ \"createdDate\" : \"2024-04-18 12:50:18\"}";
        JsonFactory factory = new JsonFactory();
        JsonParser parser = factory.createParser(dateJson);
        parser.nextToken();
        parser.nextToken();
        parser.nextToken();
        String currentName = parser.getCurrentName();
        System.out.println("currentName=" + currentName + ", date=" +  parser.getText());

        DeserializationContext context = null;
        CustomDateDeserializer dateDeserializer = new CustomDateDeserializer();
        Date date = dateDeserializer.deserialize(parser, context);
        System.out.println("Date=" + ((date != null) ? date : "NULL"));
        assertNull(date);
    }
}