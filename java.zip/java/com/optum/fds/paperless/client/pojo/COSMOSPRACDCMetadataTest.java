package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import com.fasterxml.jackson.databind.ObjectMapper;

public class COSMOSPRACDCMetadataTest extends AbstractMetadataTestUtil {
	
	// emailAlertReq = Y, EFT_Ind = N
	protected static final String PATH_XML_FILE = "files/metadata/COSMOSPRA/COSMOSPRA.metadata";
	
	protected static final String PATH_XML_FILE_P4_FILEPATH = "files/metadata/COSMOSPRA/COSMOSPRA_P4_filePath.metadata";

	// emailAlertReq = null, EFT_Ind = N
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/COSMOSPRA/COSMOSPRAError12.metadata";
	
	// emailAlertReq = Y, EFT_Ind = N
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/COSMOSPRA/COSMOSPRAError22.metadata";
	
	// emailAlertReq = N, EFT_Ind = N
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/COSMOSPRA/COSMOSPRA_emailAlertReq_N.metadata";
	// emailAlertReq = Y, EFT_Ind = Y 
	protected static final String PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_Y = "files/metadata/COSMOSPRA/COSMOSPRA_emailAlertReq_Y_EFT_Ind_Y.metadata";
	// emailAlertReq = N, EFT_Ind = Y 
	protected static final String PATH_XML_FILE_emailAlertReq_N_EFT_Ind_Y = "files/metadata/COSMOSPRA/COSMOSPRA_emailAlertReq_N_EFT_Ind_Y.metadata";
	// emailAlertReq = Y, EFT_Ind = null
	protected static final String PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_null = "files/metadata/COSMOSPRA/COSMOSPRA_emailAlertReq_Y_EFT_Ind_null.metadata";
	// emailAlertReq = N, EFT_Ind = null
	protected static final String PATH_XML_FILE_emailAlertReq_N_EFT_Ind_null = "files/metadata/COSMOSPRA/COSMOSPRA_emailAlertReq_N_EFT_Ind_null.metadata";
	
	// emailAlertReq = null, EFT_Ind = Y
	protected static final String PATH_XML_FILE_emailAlertReq_null_EFT_Ind_Y = "files/metadata/COSMOSPRA/COSMOSPRA_emailAlertReq_null_EFT_Ind_Y.metadata";
	
	protected static final String CLIENT_NAME = "COSMOSPRACDC";
	
	@Test
	public void testCOSMOSPRAHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA HappyPath:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

		assertEquals("CDC", (String) convertedMetadata.get("createApplication"));
		assertEquals("P3", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Detailed PRAs", (String) convertedMetadata.get("filePath"));
		assertEquals("2021-03-29T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
		
	}
	
	@Test
	public void testCOSMOSPRAHappyPathwithP4FilePath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_P4_FILEPATH).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the P4 filepath :"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		
		System.out.println("print convertedMetadata :"+ convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

		assertEquals("CDC", (String) convertedMetadata.get("createApplication"));
		assertEquals("P4", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Virtual Card Payments and Info Only PRAs", (String) convertedMetadata.get("filePath"));
		assertEquals("2021-03-29T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
		
	}
	
	@Test
	public void testCOSMOSPRAError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA Error12:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(5, errors.size());

		assertFalse(errors.contains("Missing or invalid data TIN"));

		assertEquals("CheckWrite", (String) convertedMetadata.get("createApplication"));
		assertEquals("PR", (String) convertedMetadata.get("subCategory"));
		assertEquals("Other PRAs/Other", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testCOSMOSPRAError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA Error22:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(6, errors.size());

		assertEquals("P4", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Virtual Card Payments and Info Only PRAs", (String) convertedMetadata.get("filePath"));
	}
	

	
	@Test
	public void testCOSMOSPRAEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA EmailAlertReqN:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("P3", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Detailed PRAs", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testCOSMOSPRA_emailAlertReq_Y_EFT_Ind_Y() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_Y).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA emailAlertReq_Y_EFT_Ind_Y:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());

		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());
	}
	
	@Test
	public void testCOSMOSPRA_emailAlertReq_N_EFT_Ind_Y() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N_EFT_Ind_Y).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA emailAlertReq_N_EFT_Ind_Y:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());

		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());
	}
	
	@Test
	public void testCOSMOSPRA_emailAlertReq_Y_EFT_Ind_null() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_null).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA emailAlertReq_Y_EFT_Ind_null:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());

		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());
	}
	
	@Test
	public void testCOSMOSPRA_emailAlertReq_N_EFT_Ind_null() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N_EFT_Ind_null).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA emailAlertReq_N_EFT_Ind_null:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());

		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());
		
	}
	
	@Test
	public void testCOSMOSPRA_emailAlertReq_null_EFT_Ind_Y() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_null_EFT_Ind_Y).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA emailAlertReq_null_EFT_Ind_Y:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());

		assertFalse(errors.isEmpty());
		assertEquals(2, errors.size());
	}
	@Test
	public void testGetAndSetTin() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setTin("123456789");

		String tin = cosmospracdc.getTin();

		assertEquals("123456789", tin);
	}
	@Test
	public void testGetAndSetCheckTraceNumber() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setCheckTraceNumber("TRACE123");

		String checkTraceNumber = cosmospracdc.getCheckTraceNumber();

		assertEquals("TRACE123", checkTraceNumber);
	}
	@Test
	public void testGetAndSetPhysicianName() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setPhysicianName("Dr. John Doe");

		String physicianName = cosmospracdc.getPhysicianName();

		assertEquals("Dr. John Doe", physicianName);
	}
	@Test
	public void testGetAndSetMpin() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setMpin("MPIN123");

		String mpin = cosmospracdc.getMpin();

		assertEquals("MPIN123", mpin);
	}
	@Test
	public void testGetAndSetEmailAlertReq() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setEmailAlertReq("N");

		String emailAlertReq = cosmospracdc.getEmailAlertReq();

		assertEquals("N", emailAlertReq);
	}
	@Test
	public void testGetAndSetPTRS() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setPTRS("PTRS123");

		String ptrs = cosmospracdc.getPTRS();

		assertEquals("PTRS123", ptrs);
	}
	@Test
	public void testGetAndSetMultClaimNumber() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setMultClaimNumber("CLAIM123");

		String multClaimNumber = cosmospracdc.getMultClaimNumber();

		assertEquals("CLAIM123", multClaimNumber);
	}
	@Test
	public void testGetAndSetDefaultUsed() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setDefaultUsed("No");

		String defaultUsed = cosmospracdc.getDefaultUsed();

		assertEquals("No", defaultUsed);
	}
	@Test
	public void testGetAndSetCONFIGKEY() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setCONFIGKEY("CONFIG123");

		String configKey = cosmospracdc.getCONFIGKEY();

		assertEquals("CONFIG123", configKey);
	}
	@Test
	public void testGetAndSetPassThruData() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setPassThruData("SampleData");

		String passThruData = cosmospracdc.getPassThruData();

		assertEquals("SampleData", passThruData);
	}
	@Test
	public void testGetAndSetPTRS_FIFTEEN() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setPTRS_FIFTEEN("PTRS15");

		String ptrsFifteen = cosmospracdc.getPTRS_FIFTEEN();

		assertEquals("PTRS15", ptrsFifteen);
	}
	@Test
	public void testGetAndSetOriginalPrintTrail() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setOriginalPrintTrail("Trail123");

		String originalPrintTrail = cosmospracdc.getOriginalPrintTrail();

		assertEquals("Trail123", originalPrintTrail);
	}
	@Test
	public void testSetSubCategory() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setSubCategory("P4");

		String subCategory = cosmospracdc.getSubCategory();

		assertEquals("P4", subCategory);
	}
	@Test
	public void testGetAndSetAddedToCosmosPraResponseFile() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setAddedToCosmosPraResponseFile(true);

		boolean addedToCosmosPraResponseFile = cosmospracdc.isAddedToCosmosPraResponseFile();

		assertTrue(addedToCosmosPraResponseFile);
	}
	@Test
	public void testGetAndSetCheckAmt() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setCheckAmt("1000.50");

		String checkAmt = cosmospracdc.getCheckAmt();

		assertEquals("1000.50", checkAmt);
	}
	@Test
	public void testGetAndSetMerged() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setMerged(true);

		boolean merged = cosmospracdc.isMerged();

		assertTrue(merged);
	}
	@Test
	public void testGetAndSetEFT_Ind() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setEFT_Ind("N");

		String eftInd = cosmospracdc.getEFT_Ind();

		assertEquals("N", eftInd);
	}
	@Test
	public void testGetSubCategory() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();

		String subCategory = cosmospracdc.getSubCategory();

		assertEquals("PR", subCategory);
	}
	@Test
	public void testGetAndSetMailToAddress5() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setMailToAddress5("505 Maple St");

		String mailToAddress5 = cosmospracdc.getMailToAddress5();

		assertEquals("505 Maple St", mailToAddress5);
	}
	@Test
	public void testGetAndSetMailToAddress2() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setMailToAddress2("456 Oak St");

		String mailToAddress2 = cosmospracdc.getMailToAddress2();

		assertEquals("456 Oak St", mailToAddress2);
	}
	@Test
	public void testGetAndSetMailToAddress3() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setMailToAddress3("789 Pine St");

		String mailToAddress3 = cosmospracdc.getMailToAddress3();

		assertEquals("789 Pine St", mailToAddress3);
	}
	@Test
	public void testGetAndSetMailToAddress4() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setMailToAddress4("404 Willow St");

		String mailToAddress4 = cosmospracdc.getMailToAddress4();

		assertEquals("404 Willow St", mailToAddress4);
	}
	@Test
	public void testGetAndSetMailToAddress6() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setMailToAddress6("606 Spruce St");

		String mailToAddress6 = cosmospracdc.getMailToAddress6();

		assertEquals("606 Spruce St", mailToAddress6);
	}
	@Test
	public void testGetAndSetMailToAddress1() {
		COSMOSPRACDC cosmospracdc = new COSMOSPRACDC();
		cosmospracdc.setMailToAddress1("123 Main St");

		String mailToAddress1 = cosmospracdc.getMailToAddress1();

		assertEquals("123 Main St", mailToAddress1);
	}
	
	@Test
	public void shouldDeserializeVendorPayIdIntoPaymentNumber() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		String json = "{ \"vendor_pay_id\": \"V12345\" }";
		COSMOSPRACDC pojo = mapper.readValue(json, COSMOSPRACDC.class);
		assertEquals("V12345", pojo.getPaymentNumber());
	}

}
