package com.optum.fds.paperless.client.pojo;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.*;

public class USPClaimsMetadataTest extends AbstractMetadataTestUtil{

    // emailAlertReq = Y, EFT_Ind = Y
    protected static final String PATH_XML_FILE = "files/metadata/USPClaims/USPClaims.metadata";
    // emailAlertReq = Y, EFT_Ind = Y
    protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/USPClaims/USPClaimsError12.metadata";
    // emailAlertReq = Y, EFT_Ind = null
    protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/USPClaims/USPClaimsError22.metadata";
    // emailAlertReq = N, EFT_Ind = N
    protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/USPClaims/USPClaims_emailAlertReq_N.metadata";
    // emailAlertReq = Y, EFT_Ind = Y


    @Test
    public void testUSPClaimsHappyPath() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "USPClaims");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("C1", (String) convertedMetadata.get("subCategory"));
        assertEquals("BARNABY COLLINS", (String) convertedMetadata.get("memberName"));
        assertEquals("PRUNPP3519", (String) convertedMetadata.get("CONFIGKEY"));
        assertEquals("123456789", convertedMetadata.get("recipientId"));
    }

    @Test
    public void testUSPClaimsError12() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "USPClaims");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(9, errors.size());

        assertEquals("CC", (String) convertedMetadata.get("subCategory"));
        assertEquals("BARNABY COLLINS", (String) convertedMetadata.get("memberName"));
    }

    @Test
    public void testUSPClaimsError22() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "USPClaims");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(6, errors.size());

//        assertFalse(errors.contains("Missing or invalid data tin (severe error)"));

        assertEquals("C1", (String) convertedMetadata.get("subCategory"));
        assertEquals("BARNABY COLLINS", (String) convertedMetadata.get("memberName"));
    }


    @Test
    public void testUSPClaimsEmailAlertReqN() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "USPClaims");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("C1", (String) convertedMetadata.get("subCategory"));
        assertEquals("BARNABY COLLINS", (String) convertedMetadata.get("memberName"));
        assertEquals("123456789", convertedMetadata.get("recipientId"));

    }

    @Test
    public void testUSPClaims(){
        USPClaims uspObj = new USPClaims();
        uspObj.setClaimNumber("Claim 12345");
        uspObj.setCONFIGKEY("Config 12345");
        uspObj.setEmailAlertReq("Y");
        uspObj.setMailToAddress1("Tower 1");
        uspObj.setMailToAddress2("Claire");
        uspObj.setMailToAddress3("Texas");
        uspObj.setMailToAddress4("USA");
        uspObj.setPatientName("Temp Patient");
        uspObj.setMemberName("Test Member");
        uspObj.setMpin("mpin12345");
        uspObj.setTin("tin 123");
        uspObj.setSubCategory("C3");
        uspObj.setProviderName("Test Provider");
        uspObj.setMemberId("ID 123");
        uspObj.setDateOfService("2022/07/29");
        uspObj.setPatientDOB("2000/11/01");

        assertNotNull(uspObj);
        assertEquals("Claim 12345", uspObj.getClaimNumber());
        assertEquals("Tower 1", uspObj.getMailToAddress1());
        assertEquals("Y", uspObj.getEmailAlertReq());
        assertEquals("mpin12345",uspObj.getMpin());
        assertEquals("tin 123", uspObj.getTin());
        assertEquals("C3", uspObj.getSubCategory());
        assertEquals("Test Provider", uspObj.getProviderName());
        assertEquals("ID 123", uspObj.getMemberId());
        assertEquals("2022/07/29", uspObj.getDateOfService());
        assertEquals("2000/11/01", uspObj.getPatientDOB());
        assertNull(uspObj.getMemberAltId());
        assertNull(uspObj.getPassThruData());
        assertNull(uspObj.getPolicyNumber());
        assertNull(uspObj.getDateEmailSent());
        assertNull(uspObj.getExpiryDate());
        assertFalse(uspObj.getSendPENAPIRequest());
    }

    @Test
    public void testUSPClaimsSubcategories() {
        USPClaims USPClaimsObj = new USPClaims();
        for (USPClaims.Subcategory subcategory : USPClaims.Subcategory.values()) {
            USPClaimsObj.setSubCategory(subcategory.getSubCat());
            assertEquals(subcategory.getSubCat(), USPClaimsObj.getSubCategory());
            assertEquals(subcategory.getFilePath(), USPClaimsObj.getFilePath());
        }
    }

    @Test
    public void testUSPClaimsSubcategoryFilePath() {
        USPClaims USPClaimsObj = new USPClaims();
        String[] subCategories = {"C1", "C2", "C3", "C4", "C6", "C7", "C8", "CC"};

        for (String subCategory : subCategories) {
            USPClaimsObj.setSubCategory(subCategory);
            String expectedFilePath = USPClaims.Subcategory.valueOf(subCategory).getFilePath();
            assertEquals(expectedFilePath, USPClaimsObj.getFilePath());
        }
    }
    
    @Test
    public void testSetSubCategoryWithNull() {
        USPClaims USPClaimsObj = new USPClaims();
        USPClaimsObj.setSubCategory(null);
        assertEquals("CC", USPClaimsObj.getSubCategory());
        assertEquals("Commercial/Other", USPClaimsObj.getFilePath());
    }

    @Test
    public void testSetSubCategoryWithEmptyString() {
        USPClaims USPClaimsObj = new USPClaims();
        USPClaimsObj.setSubCategory("");
        assertEquals("CC", USPClaimsObj.getSubCategory());
        assertEquals("Commercial/Other", USPClaimsObj.getFilePath());
    }

}


