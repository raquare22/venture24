package com.optum.fds.paperless.client.pojo;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;


public class PaymentSummaryMetadataTest extends AbstractMetadataTestUtil {

    private static final String CLIENT_NAME = "PaymentSummary";

    private Schema jsonSchema;

    @Before
    public void loadSchemaFromClasspath() throws IOException, JSONException {
        JSONTokener tokener = getClientSchema(CLIENT_NAME);
        assertNotNull(
                "PaymentSummary_client_schema.json must be present at /schemas/ on the classpath",
                tokener);
        JSONObject schemaJson = new JSONObject(tokener);
        jsonSchema = SchemaLoader.builder()
                .schemaJson(schemaJson)
                .build()
                .load()
                .build();
    }


    @Test
    public void constructor_default_setsImmutableClientContract() {
        PaymentSummary ps = new PaymentSummary();

        assertEquals("Payment Documents", ps.getCategory());
        assertEquals("PmntEng",            ps.getCreateApplication());
        assertEquals("Claim Status",       ps.getPrivilege());
        assertEquals("PRUN",               ps.getSource());

        // Routing flags
        assertFalse ("PaymentSummary MUST NOT use legacy DocVault persist to DocLib",          ps.getSendToDocVault());
        assertFalse("PaymentSummary MUST NOT print via Shutterfly",   ps.getSendToShutterfly());
        assertFalse("PaymentSummary MUST NOT trigger email",          ps.getSendEmailNotifications());
        assertFalse("PaymentSummary MUST NOT call PEN API",           ps.getSendPENAPIRequest());
        assertTrue("PaymentSummary inherits parent postCardInd defaults ",   ps.getPostCardInd());
    }


    @Test
    public void setPaymentType_DLY_routesToDailyFolder() {
        PaymentSummary ps = new PaymentSummary();
        ps.setPaymentType("DLY");
        assertEquals("DLY",                              ps.getPaymentType());
        assertEquals("Payment Summary Reports/Daily",    ps.getFilePath());
    }

    @Test
    public void setPaymentType_MTY_routesToMonthlyFolder() {
        PaymentSummary ps = new PaymentSummary();
        ps.setPaymentType("MTY");
        assertEquals("MTY",                              ps.getPaymentType());
        assertEquals("Payment Summary Reports/Monthly",  ps.getFilePath());
    }


    @Test(expected = NullPointerException.class)
    public void setPaymentType_null_throwsNpe() {
        new PaymentSummary().setPaymentType(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setPaymentType_blank_throwsIae() {
        new PaymentSummary().setPaymentType("   ");
    }

    @Test(expected = IllegalArgumentException.class)
    public void setPaymentType_unsupportedValue_throwsIae() {
        new PaymentSummary().setPaymentType("DAILY");
    }



    @Test
    public void objectMapper_deserialize_upstreamAliasKeys() throws IOException {
        String upstreamJson = ""
                + "{"
                +   "\"u_tax_id\":\"123456789\","
                +   "\"u_payment_summary_dt\":\"2026-05-20\","
                +   "\"u_payment_typ\":\"DLY\","
                +   "\"u_payment_nbr\":\"PMT-001\""
                + "}";

        PaymentSummary ps = objectMapper.readValue(upstreamJson, PaymentSummary.class);

        assertEquals("123456789", ps.getTin());
        assertEquals("2026-05-20", ps.getPaymentDate());
        assertEquals("DLY",        ps.getPaymentType());
        assertEquals("PMT-001",    ps.getPaymentNumber());
        assertEquals("Payment Summary Reports/Daily", ps.getFilePath());
    }

    @Test
    public void objectMapper_deserialize_canonicalKeys() throws IOException {
        String canonicalJson = ""
                + "{"
                +   "\"tin\":\"123456789\","
                +   "\"paymentDate\":\"2026-05-20\","
                +   "\"paymentType\":\"MTY\","
                +   "\"paymentNumber\":\"PMT-002\""
                + "}";

        PaymentSummary ps = objectMapper.readValue(canonicalJson, PaymentSummary.class);

        assertEquals("123456789", ps.getTin());
        assertEquals("MTY",       ps.getPaymentType());
        assertEquals("Payment Summary Reports/Monthly", ps.getFilePath());
    }



    @Test
    public void schema_happyPath_passesWithoutErrors() throws JSONException {
        JSONObject payload = new JSONObject()
                .put("u_tax_id",             "123456789")
                .put("u_payment_summary_dt", "2026-05-20")
                .put("u_payment_typ",        "DLY")
                .put("u_payment_nbr",        "PMT-001");

        jsonSchema.validate(payload);
    }



    @Test
    public void schema_missingTaxId_producesTaxIdError() throws JSONException {
        Set<String> errors = collectErrors(new JSONObject()
                .put("u_payment_summary_dt", "2026-05-20")
                .put("u_payment_typ",        "DLY")
                .put("u_payment_nbr",        "PMT-001"));

        assertTrue("Expected Tax ID error, got " + errors,
                errors.contains("Missing or invalid data: Tax ID"));
    }

    @Test
    public void schema_missingPaymentDate_producesPaymentDateError() throws JSONException {
        Set<String> errors = collectErrors(new JSONObject()
                .put("u_tax_id",      "123456789")
                .put("u_payment_typ", "DLY")
                .put("u_payment_nbr", "PMT-001"));

        assertTrue("Expected Payment Summary Date error, got " + errors,
                errors.contains("Missing or invalid data: Payment Summary Date"));
    }

    @Test
    public void schema_missingPaymentType_producesPaymentTypeError() throws JSONException {
        Set<String> errors = collectErrors(new JSONObject()
                .put("u_tax_id",             "123456789")
                .put("u_payment_summary_dt", "2026-05-20")
                .put("u_payment_nbr",        "PMT-001"));

        assertTrue("Expected Payment Type error, got " + errors,
                errors.contains("Missing or invalid data: Payment Type"));
    }

    @Test
    public void schema_missingPaymentNumber_producesPaymentNumberError() throws JSONException {
        Set<String> errors = collectErrors(new JSONObject()
                .put("u_tax_id",             "123456789")
                .put("u_payment_summary_dt", "2026-05-20")
                .put("u_payment_typ",        "DLY"));

        assertTrue("Expected Payment Number error, got " + errors,
                errors.contains("Missing or invalid data: Payment Number"));
    }

    @Test
    public void schema_invalidPaymentTypeEnum_failsValidation() throws JSONException {
        JSONObject payload = new JSONObject()
                .put("u_tax_id",             "123456789")
                .put("u_payment_summary_dt", "2026-05-20")
                .put("u_payment_typ",        "WEEKLY")     // not in {DLY, MTY}
                .put("u_payment_nbr",        "PMT-001");
        try {
            jsonSchema.validate(payload);
            fail("Expected ValidationException for u_payment_typ=WEEKLY");
        } catch (ValidationException expected) {
            assertTrue(
                    "Validation error should reference u_payment_typ, got: " + expected.getAllMessages(),
                    expected.getAllMessages().toString().contains("u_payment_typ"));
        }
    }


    @Test
    public void errorMsgEnum_hasExactlyFourMembers_allCode12() {
        PaymentSummary.ErrorMsg[] values = PaymentSummary.ErrorMsg.values();

        assertEquals("ErrorMsg should expose exactly 4 required-field codes", 4, values.length);
        for (PaymentSummary.ErrorMsg e : values) {
            assertEquals(
                    "All PaymentSummary errors are recoverable (code 12) - severe (22) is reserved for unrecoverable",
                    12, e.getErrorCode());
            assertNotNull("ErrorMsg." + e.name() + " has null message", e.getErrorMessage());
            assertFalse ("ErrorMsg." + e.name() + " has blank message", e.getErrorMessage().isBlank());
        }
    }

    @Test
    public void paymentTypeFilePathEnum_hasExactlyTwoMembers() {

        assertEquals(2, PaymentSummary.PaymentTypeFilePath.values().length);
    }


    @SuppressWarnings("rawtypes")
    private Set<String> collectErrors(JSONObject payload) {
        Set<String> errors = new HashSet<>();
        try {
            jsonSchema.validate(payload);
        } catch (ValidationException ve) {
            Class enumClass = getErrEnumFromClientName(CLIENT_NAME);
            assertNotNull("ErrorMsg enum must resolve via reflection for client=" + CLIENT_NAME, enumClass);
            for (String m : ve.getAllMessages()) {
                getErrors(m, errors, enumClass);
            }
        }
        return errors;
    }
}