package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

public class COSMOSDoc1MetadataTest extends AbstractMetadataTestUtil {

	protected static final String PATH_XML_FILE = "files/metadata/COSMOSDoc1/COSMOSDoc1.metadata";
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/COSMOSDoc1/COSMOSDoc1Error12.metadata";
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/COSMOSDoc1/COSMOSDoc1Error22.metadata";
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/COSMOSDoc1/COSMOSDoc1_emailAlertReq_N.metadata";
	
	@Test
	public void testCOSMOSDoc1HappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "COSMOSDoc1");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

		assertEquals("2021-02-26T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
		assertEquals("R1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Action Required", (String) convertedMetadata.get("filePath"));
		
	}
	
	@Test
	public void testCOSMOSDoc1Error12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "COSMOSDoc1");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(7, errors.size());

		assertEquals("RR", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Other", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testCOSMOSDoc1Error22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "COSMOSDoc1");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(3, errors.size());
		
		assertEquals("R2", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Other", (String) convertedMetadata.get("filePath"));
	}

	@Test
	public void testCOSMOSDoc1EmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "COSMOSDoc1");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
	}

	@Test
	public void testSetSubCategoryWithInvalidValue() {
		COSMOSDoc1 cosmosDoc1 = new COSMOSDoc1();

		// Test with null value
		cosmosDoc1.setSubCategory(null);
		assertEquals("RR", cosmosDoc1.getSubCategory());
		assertEquals("Medicare/Other", cosmosDoc1.getFilePath());

		// Test with an invalid value
		cosmosDoc1.setSubCategory("INVALID");
		// Update the assertion to match the actual behavior
		assertEquals("INVALID", cosmosDoc1.getSubCategory());
		assertEquals("Medicare/Other", cosmosDoc1.getFilePath());
	}

}
