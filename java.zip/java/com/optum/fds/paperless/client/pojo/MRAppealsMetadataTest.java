package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

public class MRAppealsMetadataTest extends AbstractMetadataTestUtil {
	
	
	protected static final String PATH_XML_FILE = "files/metadata/MRAppeals/MRAppeals.metadata";
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/MRAppeals/MRAppealsError12.metadata";
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/MRAppeals/MRAppealsError22.metadata";
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/MRAppeals/MRAppeals_emailAlertReq_N.metadata";
	
	@Before
	public void setUp() {
		
	}
	
	@Test
	public void testMRAppealsHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "MRAppeals");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("X6", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare Appeals and Disputes / Resolution", (String) convertedMetadata.get("filePath"));
		assertEquals("2021-03-22T17:59:02.000Z", (String) convertedMetadata.get("createdDate"));
		assertEquals("MnR", (String) convertedMetadata.get("createApplication"));
	}
	
	@Test
	public void testMRAppealsError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "MRAppeals");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(7, errors.size());

		assertEquals("XX", (String) convertedMetadata.get("subCategory"));
		assertEquals("Other Appeals and Disputes / Other", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testMRAppealsError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "MRAppeals");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(7, errors.size());

		assertEquals("Y3", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare  Appeals and Disputes / Resolution (Rx)", (String) convertedMetadata.get("filePath"));
	}
	
	
	@Test
	public void testMRAppealsEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "MRAppeals");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("Y7", (String) convertedMetadata.get("subCategory"));
		assertEquals("Special Needs Plan Appeals and Disputes / Notification and Acknowledgement", (String) convertedMetadata.get("filePath"));
	}

}
