package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.fail;

public class PriorAuthCCSManualMetadataTest extends AbstractMetadataTestUtil {

	protected static final String PATH_XML_FILE = "files/metadata/PriorAuthCCSManual/PriorAuthCCSManual.metadata";
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/PriorAuthCCSManual/PriorAuthCCSManualError12.metadata";
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/PriorAuthCCSManual/PriorAuthCCSManualError22.metadata";
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/PriorAuthCCSManual/PriorAuthCCSManual_emailAlertReq_N.metadata";

	@Test
	public void testPriorAuthCCSManualHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();

		String testDate = null;
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuthCCSManual");
			SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			isoFormat.setTimeZone(TimeZone.getTimeZone("EST"));
			Date date = isoFormat.parse((String)convertedMetadata.get("dateOfService")); // 11292017
			testDate = isoFormat.format(date);
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

		assertEquals(testDate, (String) convertedMetadata.get("dateOfService"));
		assertEquals("2018-06-27T10:02:31.000Z", (String) convertedMetadata.get("createdDate"));
		assertEquals("A1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial Prior Auth/Approved", (String) convertedMetadata.get("filePath"));

	}

	@Test
	public void testPriorAuthCCSManualError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();

		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuthCCSManual");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(6, errors.size());

		assertEquals("ZZ", (String) convertedMetadata.get("subCategory"));
		assertEquals("Misc. Prior Auth/Other", (String) convertedMetadata.get("filePath"));
	}

	@Test
	public void testPriorAuthCCSManualError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();

		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuthCCSManual");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(9, errors.size());

		assertEquals("A1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial Prior Auth/Approved", (String) convertedMetadata.get("filePath"));
	}


	@Test
	public void testPriorAuthCCSManualEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();

		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuthCCSManual");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

	}

	@Test
	public void testPriorAuthCCSManualInvalidSubCategory() {
		// Path to a metadata file with an invalid subCategory
		String resourcePath = "files/metadata/PriorAuthCCSManual/PriorAuthCCSManualInvalidSubCategory.metadata";
		System.out.println("Looking for resource: " + resourcePath);
		URL resource = getClass().getClassLoader().getResource(resourcePath);

		// Check if the resource is null
		if (resource == null) {
			System.out.println("Resource not found: " + resourcePath);
			fail("Resource not found: " + resourcePath);
		}

		File file = new File(resource.getFile());
		System.out.println("Resource found at: " + file.getAbsolutePath());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<>();

		try {
			System.out.println("Attempting to convert and validate metadata...");

			// Check if the file content is XML
			if (file.getName().endsWith(".metadata")) {
				String content = new String(java.nio.file.Files.readAllBytes(file.toPath()));
				if (content.trim().startsWith("{")) {
					System.out.println("File content is JSON, skipping XML conversion.");
					fail("File content is JSON, but XML was expected.");
				}
			}

			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuthCCSManual");
			System.out.println("Metadata conversion successful.");
		} catch (IOException | JSONException e) {
			System.out.println("Exception occurred during metadata conversion: " + e.getMessage());
			e.printStackTrace();
		}

		System.out.println("Converted Metadata: " + convertedMetadata);
		System.out.println("Errors: " + errors);
		assertFalse("Converted metadata should not be empty", convertedMetadata.isEmpty());
		assertFalse("Errors should not be empty", errors.isEmpty());

		// Validate that the default subCategory is applied
		assertEquals("A1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial Prior Auth/Approved", (String) convertedMetadata.get("filePath"));
	}

	@Test
	public void testPriorAuthCCSManualMissingRequiredField() {
		// Path to a metadata file with a missing required field
		String resourcePath = "files/metadata/PriorAuthCCSManual/PriorAuthCCSManualMissingRequiredField.metadata";
		System.out.println("Looking for resource: " + resourcePath);
		URL resource = getClass().getClassLoader().getResource(resourcePath);

		// Check if the resource is null
		if (resource == null) {
			System.out.println("Resource not found: " + resourcePath);
			fail("Resource not found: " + resourcePath);
		}

		File file = new File(resource.getFile());
		System.out.println("Resource found at: " + file.getAbsolutePath());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<>();

		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuthCCSManual");
		} catch (IOException | JSONException e) {
			System.out.println("Exception occurred during metadata conversion: " + e.getMessage());
			e.printStackTrace();
		}

		System.out.println("Converted Metadata: " + convertedMetadata);
		System.out.println("Errors: " + errors);
		assertFalse("Converted metadata should not be empty", convertedMetadata.isEmpty());
		assertFalse("Errors should not be empty", errors.isEmpty());

		// Validate that the error for the missing field is captured
		assertTrue(errors.stream().anyMatch(error -> error.contains("Missing or invalid data: ServiceReferenceNum")));
	}

	@Test
	public void testPriorAuthCCSManualEmailAlertReq() {
		// Create an instance of PriorAuthCCSManual
		PriorAuthCCSManual manual = new PriorAuthCCSManual();

		// Test with a valid value
		manual.setEmailAlertReq("N");
		assertEquals("N", manual.getEmailAlertReq());

		// Test with an empty value
		manual.setEmailAlertReq("");
		assertEquals("N", manual.getEmailAlertReq());

		// Test with a null value
		manual.setEmailAlertReq(null);
		assertEquals("N", manual.getEmailAlertReq());

		manual.setEmailAlertReq("Y");
		assertEquals("Y", manual.getEmailAlertReq());
	}

	@Test
	public void testGetPolicyNumber() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setPolicyNumber("POL12345");

		String policyNumber = manual.getPolicyNumber();

		assertEquals("POL12345", policyNumber);
	}
	@Test
	public void testGetMailToAddress2() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setMailToAddress2("456 Elm St");

		String mailToAddress2 = manual.getMailToAddress2();

		assertEquals("456 Elm St", mailToAddress2);
	}
	@Test
	public void testGetMailToAddress3() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setMailToAddress3("789 Oak St");

		String mailToAddress3 = manual.getMailToAddress3();

		assertEquals("789 Oak St", mailToAddress3);
	}
	@Test
	public void testGetMailToAddress4() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setMailToAddress4("101 Pine St");

		String mailToAddress4 = manual.getMailToAddress4();

		assertEquals("101 Pine St", mailToAddress4);
	}
	@Test
	public void testGetMailToAddress5() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setMailToAddress5("202 Birch St");

		String mailToAddress5 = manual.getMailToAddress5();

		assertEquals("202 Birch St", mailToAddress5);
	}
	@Test
	public void testGetMailToAddress6() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setMailToAddress6("303 Cedar St");

		String mailToAddress6 = manual.getMailToAddress6();

		assertEquals("303 Cedar St", mailToAddress6);
	}
	@Test
	public void testGetNotificationNumber() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setNotificationNumber("NOTIF12345");

		String notificationNumber = manual.getNotificationNumber();

		assertEquals("NOTIF12345", notificationNumber);
	}
	@Test
	public void testGetSubCategory() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setSubCategory("A1");

		String subCategory = manual.getSubCategory();

		assertEquals("A1", subCategory);
	}
	@Test
	public void testGetTin() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setTin("TIN12345");

		String tin = manual.getTin();

		assertEquals("TIN12345", tin);
	}
	@Test
	public void testGetProviderName() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setProviderName("Provider ABC");

		String providerName = manual.getProviderName();

		assertEquals("Provider ABC", providerName);
	}
	@Test
	public void testGetMpin() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setMpin("MPIN123");

		String mpin = manual.getMpin();

		assertEquals("MPIN123", mpin);
	}
	@Test
	public void testGetMemberId() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setMemberId("MEM12345");

		String memberId = manual.getMemberId();

		assertEquals("MEM12345", memberId);
	}
	@Test
	public void testGetMemberName() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setMemberName("John Doe");

		String memberName = manual.getMemberName();

		assertEquals("John Doe", memberName);
	}
	@Test
	public void testGetOriginalPrintTrail() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setOriginalPrintTrail("Trail123");

		String originalPrintTrail = manual.getOriginalPrintTrail();

		assertEquals("Trail123", originalPrintTrail);
	}
	@Test
	public void testGetCONFIGKEY() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setCONFIGKEY("CONFIG123");

		String configKey = manual.getCONFIGKEY();

		assertEquals("CONFIG123", configKey);
	}
	@Test
	public void testGetDMSecurityClass() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setDMSecurityClass("Secure123");

		String dmSecurityClass = manual.getDMSecurityClass();

		assertEquals("Secure123", dmSecurityClass);
	}
	@Test
	public void testGetRelatedID() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setRelatedID("REL12345");

		String relatedID = manual.getRelatedID();

		assertEquals("REL12345", relatedID);
	}
	@Test
	public void testGetPassThruData() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setPassThruData("Data123");

		String passThruData = manual.getPassThruData();

		assertEquals("Data123", passThruData);
	}
	@Test
	public void testGetMemberAltID() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setMemberAltID("ALT12345");

		String memberAltID = manual.getMemberAltID();

		assertEquals("ALT12345", memberAltID);
	}
	@Test
	public void testGetEmailAlertReq() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setEmailAlertReq("N");

		String emailAlertReq = manual.getEmailAlertReq();

		assertEquals("N", emailAlertReq);
	}
	@Test
	public void testGetMailToAddress1() {
		PriorAuthCCSManual manual = new PriorAuthCCSManual();
		manual.setMailToAddress1("123 Maple St");

		String mailToAddress1 = manual.getMailToAddress1();

		assertEquals("123 Maple St", mailToAddress1);
	}


}
