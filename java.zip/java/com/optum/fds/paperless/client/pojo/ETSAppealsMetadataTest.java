package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

public class ETSAppealsMetadataTest extends AbstractMetadataTestUtil {
	
	
	protected static final String PATH_XML_FILE = "files/metadata/ETSAppeals/ETSAppeals.metadata";
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/ETSAppeals/ETSAppealsError12.metadata";
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/ETSAppeals/ETSAppealsError22.metadata";
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/ETSAppeals/ETSAppeals_emailAlertReq_N.metadata";
	
	@Before
	public void setUp() {
		
	}
	
	@Test
	public void testETSAppealsHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();

		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "ETSAppeals");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

		assertEquals("2021-01-05T05:59:44.000Z", (String) convertedMetadata.get("createdDate"));
		assertEquals("X2", (String) convertedMetadata.get("subCategory"));
		assertEquals("Community Plan Appeals and Disputes / Acknowledgement, Notification, and Response", (String) convertedMetadata.get("filePath"));
		
	}
	
	@Test
	public void testETSAppealsError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "ETSAppeals");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(5, errors.size());
		
		assertEquals("XX", (String) convertedMetadata.get("subCategory"));
		assertEquals("Other Appeals and Disputes / Other", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testETSAppealsError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "ETSAppeals");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(8, errors.size());
		
		assertEquals("X1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial Appeals and Disputes / Acknowledgement, Notification, and Response", (String) convertedMetadata.get("filePath"));
	}
	
	
	@Test
	public void testETSAppealsEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "ETSAppeals");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
//		assertTrue(errors.isEmpty());


	}
	@Test
	public void testGetMpin() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setMpin("12345");

		String mpin = etsAppeals.getMpin();

		assertEquals("12345", mpin);
	}
	@Test
	public void testGetPhysicianName() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setPhysicianName("Dr. John Doe");

		String physicianName = etsAppeals.getPhysicianName();

		assertEquals("Dr. John Doe", physicianName);
	}
	@Test
	public void testGetCaseId() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setCaseId("CASE123");

		String caseId = etsAppeals.getCaseId();

		assertEquals("CASE123", caseId);
	}
	@Test
	public void testGetHistoryId() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setHistoryId("HIST123");

		String historyId = etsAppeals.getHistoryId();

		assertEquals("HIST123", historyId);
	}
	@Test
	public void testGetPatientAccountNumber() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setPatientAccountNumber("ACC12345");

		String patientAccountNumber = etsAppeals.getPatientAccountNumber();

		assertEquals("ACC12345", patientAccountNumber);
	}
	@Test
	public void testGetMailToAddress1() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setMailToAddress1("123 Main St");

		String mailToAddress1 = etsAppeals.getMailToAddress1();

		assertEquals("123 Main St", mailToAddress1);
	}
	@Test
	public void testGetMailToAddress4() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setMailToAddress4("101 Birch St");

		String mailToAddress4 = etsAppeals.getMailToAddress4();

		assertEquals("101 Birch St", mailToAddress4);
	}
	@Test
	public void testGetMailToAddress5() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setMailToAddress5("202 Elm St");

		String mailToAddress5 = etsAppeals.getMailToAddress5();

		assertEquals("202 Elm St", mailToAddress5);
	}
	@Test
	public void testGetMailToAddress2() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setMailToAddress2("456 Oak St");

		String mailToAddress2 = etsAppeals.getMailToAddress2();

		assertEquals("456 Oak St", mailToAddress2);
	}
	@Test
	public void testGetMailToAddress3() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setMailToAddress3("789 Pine St");

		String mailToAddress3 = etsAppeals.getMailToAddress3();

		assertEquals("789 Pine St", mailToAddress3);
	}
	@Test
	public void testGetSubCategory() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setSubCategory("X1");

		String subCategory = etsAppeals.getSubCategory();

		assertEquals("X1", subCategory);
	}
	@Test
	public void testGetTin() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setTin("TIN12345");

		String tin = etsAppeals.getTin();

		assertEquals("TIN12345", tin);
	}
	@Test
	public void testGetMailToAddress6() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setMailToAddress6("303 Cedar St");

		String mailToAddress6 = etsAppeals.getMailToAddress6();

		assertEquals("303 Cedar St", mailToAddress6);
	}
	@Test
	public void testGetEmailAlertReq() {
		ETSAppeals etsAppeals = new ETSAppeals();
		etsAppeals.setEmailAlertReq("Y");

		String emailAlertReq = etsAppeals.getEmailAlertReq();

		assertEquals("Y", emailAlertReq);
	}

}
