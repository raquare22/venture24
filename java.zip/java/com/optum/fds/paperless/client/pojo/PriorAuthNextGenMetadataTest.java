package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertNotNull;

public class PriorAuthNextGenMetadataTest extends AbstractMetadataTestUtil {

	protected static final String PATH_XML_FILE = "files/metadata/PriorAuthNextGen/PriorAuthNextGen.metadata";
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/PriorAuthNextGen/PriorAuthNextGenError12.metadata";
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/PriorAuthNextGen/PriorAuthNextGenError22.metadata";
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/PriorAuthNextGen/PriorAuthNextGen_emailAlertReq_N.metadata";

	@Test
	public void testPriorAuthNextGenHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();

		String testDate = null;
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuthNextGen");
			SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			isoFormat.setTimeZone(TimeZone.getTimeZone("EST"));
			Date date = isoFormat.parse((String)convertedMetadata.get("dateOfService")); // 11292017
			testDate = isoFormat.format(date);
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

		assertEquals(testDate, (String) convertedMetadata.get("dateOfService"));
		assertEquals("2021-03-04T09:15:45.000Z", (String) convertedMetadata.get("createdDate"));
		assertEquals("A1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial Prior Auth/Approved", (String) convertedMetadata.get("filePath"));

	}

	@Test
	public void testPriorAuthNextGenError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();

		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuthNextGen");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(6, errors.size());
		
		assertEquals("ZZ", (String) convertedMetadata.get("subCategory"));
		assertEquals("Misc. Prior Auth/Other", (String) convertedMetadata.get("filePath"));
	}

	@Test
	public void testPriorAuthNextGenError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();

		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuthNextGen");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(9, errors.size());

		assertEquals("A1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial Prior Auth/Approved", (String) convertedMetadata.get("filePath"));
	}

	@Test
	public void testPriorAuthNextGenEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();

		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuthNextGen");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

	}

	@Test
	public void testPriorAuthNextGenWithMissingOptionalFields() {
		// Load the resource
		URL resource = getClass().getClassLoader().getResource("files/metadata/PriorAuthNextGen/PriorAuthNextGenMissingOptionalFields.metadata");
		assertNotNull("Resource file 'PriorAuthNextGenMissingOptionalFields.metadata' not found in classpath", resource);

		File file = new File(resource.getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<>();

		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuthNextGen");
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}

		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

		// Validate default values for missing fields
		assertEquals("Prior Auth Notification", (String) convertedMetadata.get("subCategory"));
		assertEquals("Misc. Prior Auth/Other", (String) convertedMetadata.get("filePath"));
		assertEquals("Y", (String) convertedMetadata.get("emailAlertReq")); // Default value
	}
	@Test
	public void testGetNotificationNumber() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setNotificationNumber("12345");

		String notificationNumber = priorAuthNextGen.getNotificationNumber();

		assertEquals("12345", notificationNumber);
	}
	@Test
	public void testGetSubCategory() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setSubCategory("A1");

		String subCategory = priorAuthNextGen.getSubCategory();

		assertEquals("A1", subCategory);
	}
	@Test
	public void testGetMpin() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setMpin("98765");

		String mpin = priorAuthNextGen.getMpin();

		assertEquals("98765", mpin);
	}
	@Test
	public void testGetProviderName() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setProviderName("Optum");

		String providerName = priorAuthNextGen.getProviderName();

		assertEquals("Optum", providerName);
	}
	@Test
	public void testGetTin() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setTin("123456789");

		String tin = priorAuthNextGen.getTin();

		assertEquals("123456789", tin);
	}
	@Test
	public void testGetMemberId() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setMemberId("M12345");

		String memberId = priorAuthNextGen.getMemberId();

		assertEquals("M12345", memberId);
	}
	@Test
	public void testGetMemberName() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setMemberName("John Doe");

		String memberName = priorAuthNextGen.getMemberName();

		assertEquals("John Doe", memberName);
	}
	@Test
	public void testGetPolicyNumber() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setPolicyNumber("P123456");

		String policyNumber = priorAuthNextGen.getPolicyNumber();

		assertEquals("P123456", policyNumber);
	}
	@Test
	public void testGetEmailAlertReq() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setEmailAlertReq("N");

		String emailAlertReq = priorAuthNextGen.getEmailAlertReq();

		assertEquals("N", emailAlertReq);
	}
	@Test
	public void testGetLetterHistoryID() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setLetterHistoryID("LH12345");

		String letterHistoryID = priorAuthNextGen.getLetterHistoryID();

		assertEquals("LH12345", letterHistoryID);
	}
	@Test
	public void testGetPassThruData() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setPassThruData("SampleData");

		String passThruData = priorAuthNextGen.getPassThruData();

		assertEquals("SampleData", passThruData);
	}
	@Test
	public void testGetOriginalPrintTrail() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setOriginalPrintTrail("Trail123");

		String originalPrintTrail = priorAuthNextGen.getOriginalPrintTrail();

		assertEquals("Trail123", originalPrintTrail);
	}
	@Test
	public void testGetCONFIGKEY() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setCONFIGKEY("Config123");

		String configKey = priorAuthNextGen.getCONFIGKEY();

		assertEquals("Config123", configKey);
	}
	@Test
	public void testGetDMSecurityClass() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setDMSecurityClass("SecureClass123");

		String dmSecurityClass = priorAuthNextGen.getDMSecurityClass();

		assertEquals("SecureClass123", dmSecurityClass);
	}
	@Test
	public void testGetRelatedID() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setRelatedID("RID12345");

		String relatedID = priorAuthNextGen.getRelatedID();

		assertEquals("RID12345", relatedID);
	}
	@Test
	public void testGetMemberAltID() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setMemberAltID("AltID123");

		String memberAltID = priorAuthNextGen.getMemberAltID();

		assertEquals("AltID123", memberAltID);
	}
	@Test
	public void testGetELGSLETTERGENID() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setELGSLETTERGENID("ELG12345");

		String elgsLetterGenID = priorAuthNextGen.getELGSLETTERGENID();

		assertEquals("ELG12345", elgsLetterGenID);
	}
	@Test
	public void testGetProviderDEC() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setProviderDEC("DEC123");

		String providerDEC = priorAuthNextGen.getProviderDEC();

		assertEquals("DEC123", providerDEC);
	}
	@Test
	public void testGetNotificationLetterID() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setNotificationLetterID("NLID12345");

		String notificationLetterID = priorAuthNextGen.getNotificationLetterID();

		assertEquals("NLID12345", notificationLetterID);
	}
	@Test
	public void testGetELGSREQUESTID() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setELGSREQUESTID("REQ12345");

		String elgsRequestID = priorAuthNextGen.getELGSREQUESTID();

		assertEquals("REQ12345", elgsRequestID);
	}
	@Test
	public void testGetGenerationType() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setGenerationType("Auto");

		String generationType = priorAuthNextGen.getGenerationType();

		assertEquals("Auto", generationType);
	}
	@Test
	public void testGetWORKGROUP_NME() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setWORKGROUP_NME("WorkGroup123");

		String workGroupName = priorAuthNextGen.getWORKGROUP_NME();

		assertEquals("WorkGroup123", workGroupName);
	}
	@Test
	public void testGetLetterPriority() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setLetterPriority("High");

		String letterPriority = priorAuthNextGen.getLetterPriority();

		assertEquals("High", letterPriority);
	}
	@Test
	public void testGetLegacyEntity() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setLegacyEntity("Legacy123");

		String legacyEntity = priorAuthNextGen.getLegacyEntity();

		assertEquals("Legacy123", legacyEntity);
	}
	@Test
	public void testGetBusinessSegment() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setBusinessSegment("Commercial");

		String businessSegment = priorAuthNextGen.getBusinessSegment();

		assertEquals("Commercial", businessSegment);
	}
	@Test
	public void testGetDefaultUsed() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setDefaultUsed("Yes");

		String defaultUsed = priorAuthNextGen.getDefaultUsed();

		assertEquals("Yes", defaultUsed);
	}
	@Test
	public void testGetHHKey() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setHHKey("HH12345");

		String hhKey = priorAuthNextGen.getHHKey();

		assertEquals("HH12345", hhKey);
	}
	@Test
	public void testGetDUPLEXSIMPLEX() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setDUPLEXSIMPLEX("Duplex");

		String duplexSimplex = priorAuthNextGen.getDUPLEXSIMPLEX();

		assertEquals("Duplex", duplexSimplex);
	}
	@Test
	public void testGetRequesterID() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setRequesterID("REQ123");

		String requesterID = priorAuthNextGen.getRequesterID();

		assertEquals("REQ123", requesterID);
	}
	@Test
	public void testGetMailToAddress1() {
		PriorAuthNextGen priorAuthNextGen = new PriorAuthNextGen();
		priorAuthNextGen.setMailToAddress1("123 Main St");

		String mailToAddress1 = priorAuthNextGen.getMailToAddress1();

		assertEquals("123 Main St", mailToAddress1);
	}
}
