package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.*;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

public class HouseCallsMetadataTest extends AbstractMetadataTestUtil {

    protected static final String PATH_XML_FILE = "files/metadata/HouseCalls/HouseCalls.metadata";
    protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/HouseCalls/HouseCallsError12.metadata";
    protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/HouseCalls/HouseCallsError22.metadata";
    protected static final String PATH_XML_FILE_EMAIL_ALERT_REQ_N = "files/metadata/HouseCalls/HouseCalls_emailAlertReq_N.metadata";


    @Test
    public void testHouseCallsHappyPath() {
        File file = new File(Objects.requireNonNull(getClass().getClassLoader().getResource(PATH_XML_FILE)).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "HouseCalls");
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("H1", (String) convertedMetadata.get("subCategory"));
        assertEquals("HouseCalls Documentation/Post Assessment Letter", (String) convertedMetadata.get("filePath"));
        assertEquals("2021-03-22T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
    }

    @Test
    public void testHouseCallsError12() {
        File file = new File(Objects.requireNonNull(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12)).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "HouseCalls");
        } catch (IOException | JSONException e) {
            System.out.println("Error occured while converting metadata");
            e.printStackTrace();
        }

        System.out.println("convertedMetadata=" + convertedMetadata);
        System.out.println("errors=" + errors);

        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(3, errors.size());

        assertEquals("HH", (String) convertedMetadata.get("subCategory"));
        assertEquals("HouseCalls Documentation/Other", (String) convertedMetadata.get("filePath"));
        assertEquals("2021-03-22T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
    }

    @Test
    public void testHouseCallsError22() {
        File file = new File(Objects.requireNonNull(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22)).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "HouseCalls");
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        System.out.println("convertedMetadata=" + convertedMetadata);
        System.out.println("errors=" + errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(1, errors.size());

        assertEquals("Y", convertedMetadata.get("emailAlertReq"));
        assertEquals("H1", (String) convertedMetadata.get("subCategory"));
        assertEquals("HouseCalls Documentation/Post Assessment Letter", (String) convertedMetadata.get("filePath"));
        assertEquals("2021-03-22T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
    }

    @Test
    public void testHouseCallsEmailAlertReqN() {
        File file = new File(Objects.requireNonNull(getClass().getClassLoader().getResource(PATH_XML_FILE_EMAIL_ALERT_REQ_N)).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "HouseCalls");
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("H1", (String) convertedMetadata.get("subCategory"));
        assertEquals("HouseCalls Documentation/Post Assessment Letter", (String) convertedMetadata.get("filePath"));
        assertEquals("2021-03-22T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
    }
}
