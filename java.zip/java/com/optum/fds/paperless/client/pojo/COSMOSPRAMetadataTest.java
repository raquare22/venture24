package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

public class COSMOSPRAMetadataTest extends AbstractMetadataTestUtil {
	
	// emailAlertReq = Y, EFT_Ind = N
	protected static final String PATH_XML_FILE = "files/metadata/COSMOSPRA/COSMOSPRA.metadata";
	
	protected static final String PATH_XML_FILE_P4_FILEPATH = "files/metadata/COSMOSPRA/COSMOSPRA_P4_filePath.metadata";

	// emailAlertReq = null, EFT_Ind = N
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/COSMOSPRA/COSMOSPRAError12.metadata";
	
	// emailAlertReq = Y, EFT_Ind = N
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/COSMOSPRA/COSMOSPRAError22.metadata";
	
	// emailAlertReq = N, EFT_Ind = N
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/COSMOSPRA/COSMOSPRA_emailAlertReq_N.metadata";
	// emailAlertReq = Y, EFT_Ind = Y 
	protected static final String PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_Y = "files/metadata/COSMOSPRA/COSMOSPRA_emailAlertReq_Y_EFT_Ind_Y.metadata";
	// emailAlertReq = N, EFT_Ind = Y 
	protected static final String PATH_XML_FILE_emailAlertReq_N_EFT_Ind_Y = "files/metadata/COSMOSPRA/COSMOSPRA_emailAlertReq_N_EFT_Ind_Y.metadata";
	// emailAlertReq = Y, EFT_Ind = null
	protected static final String PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_null = "files/metadata/COSMOSPRA/COSMOSPRA_emailAlertReq_Y_EFT_Ind_null.metadata";
	// emailAlertReq = N, EFT_Ind = null
	protected static final String PATH_XML_FILE_emailAlertReq_N_EFT_Ind_null = "files/metadata/COSMOSPRA/COSMOSPRA_emailAlertReq_N_EFT_Ind_null.metadata";
	
	// emailAlertReq = null, EFT_Ind = Y
	protected static final String PATH_XML_FILE_emailAlertReq_null_EFT_Ind_Y = "files/metadata/COSMOSPRA/COSMOSPRA_emailAlertReq_null_EFT_Ind_Y.metadata";
	
	protected static final String CLIENT_NAME = "COSMOSPRA";
	
	@Test
	public void testCOSMOSPRAHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA HappyPath:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

		assertEquals("CDC", (String) convertedMetadata.get("createApplication"));
		assertEquals("P3", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Detailed PRAs", (String) convertedMetadata.get("filePath"));
		assertEquals("2021-03-29T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
		
	}
	
	@Test
	public void testCOSMOSPRAHappyPathwithP4FilePath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_P4_FILEPATH).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the P4 filepath :"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		
		System.out.println("print convertedMetadata :"+ convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

		assertEquals("CDC", (String) convertedMetadata.get("createApplication"));
		assertEquals("P4", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Virtual Card Payments and Info Only PRAs", (String) convertedMetadata.get("filePath"));
		assertEquals("2021-03-29T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
		
	}
	
	@Test
	public void testCOSMOSPRAError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA Error12:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(5, errors.size());

		assertFalse(errors.contains("Missing or invalid data TIN"));

		assertEquals("CheckWrite", (String) convertedMetadata.get("createApplication"));
		assertEquals("PR", (String) convertedMetadata.get("subCategory"));
		assertEquals("Other PRAs/Other", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testCOSMOSPRAError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA Error22:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(8, errors.size());

		assertEquals("P4", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Virtual Card Payments and Info Only PRAs", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testCOSMOSPRAEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA EmailAlertReqN:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("P3", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Detailed PRAs", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testCOSMOSPRA_emailAlertReq_Y_EFT_Ind_Y() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_Y).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA emailAlertReq_Y_EFT_Ind_Y:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());

		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());
		
	}
	
	@Test
	public void testCOSMOSPRA_emailAlertReq_N_EFT_Ind_Y() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N_EFT_Ind_Y).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA emailAlertReq_N_EFT_Ind_Y:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());

		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());
		
	}
	
	@Test
	public void testCOSMOSPRA_emailAlertReq_Y_EFT_Ind_null() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_null).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA emailAlertReq_Y_EFT_Ind_null:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());

		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());
		
	}
	
	@Test
	public void testCOSMOSPRA_emailAlertReq_N_EFT_Ind_null() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N_EFT_Ind_null).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA emailAlertReq_N_EFT_Ind_null:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());

		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());
		
	}
	
	@Test
	public void testCOSMOSPRA_emailAlertReq_null_EFT_Ind_Y() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_null_EFT_Ind_Y).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
		} catch (IOException | JSONException e) {
			System.out.println("getting exception to process the COSMOSPRA emailAlertReq_null_EFT_Ind_Y:"+ ExceptionUtils.getStackTrace(e));
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());

		assertFalse(errors.isEmpty());
		assertEquals(2, errors.size());
		
	}
	@Test
	public void testGetAndSetTin() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setTin("123456789");

		String tin = cosmospra.getTin();

		assertEquals("123456789", tin);
	}
	@Test
	public void testGetAndSetMpin() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setMpin("MPIN123");

		String mpin = cosmospra.getMpin();

		assertEquals("MPIN123", mpin);
	}
	@Test
	public void testGetAndSetInd835() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setInd_835("835_IND_VALUE");

		String ind835 = cosmospra.getInd_835();

		assertEquals("835_IND_VALUE", ind835);
	}
	@Test
	public void testGetAndSetPTRS() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setPTRS("PTRS123");

		String ptrs = cosmospra.getPTRS();

		assertEquals("PTRS123", ptrs);
	}
	@Test
	public void testGetAndSetDIV() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setDIV("DIV123");

		String div = cosmospra.getDIV();

		assertEquals("DIV123", div);
	}
	@Test
	public void testGetAndSetMultClaimNumber() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setMultClaimNumber("CLAIM123");

		String multClaimNumber = cosmospra.getMultClaimNumber();

		assertEquals("CLAIM123", multClaimNumber);
	}
	@Test
	public void testGetAndSetDefaultUsed() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setDefaultUsed("DEFAULT123");

		String defaultUsed = cosmospra.getDefaultUsed();

		assertEquals("DEFAULT123", defaultUsed);
	}
	@Test
	public void testGetAndSetOriginalPrintTrail() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setOriginalPrintTrail("Trail123");

		String originalPrintTrail = cosmospra.getOriginalPrintTrail();

		assertEquals("Trail123", originalPrintTrail);
	}
	@Test
	public void testGetAndSetPTRS_FIFTEEN() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setPTRS_FIFTEEN("PTRS15");

		String ptrsFifteen = cosmospra.getPTRS_FIFTEEN();

		assertEquals("PTRS15", ptrsFifteen);
	}
	@Test
	public void testGetAndSetAddedToCosmosPraResponseFile() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setAddedToCosmosPraResponseFile(true);

		boolean addedToResponseFile = cosmospra.isAddedToCosmosPraResponseFile();

		assertTrue(addedToResponseFile);
	}
	@Test
	public void testGetAndSetMerged() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setMerged(true);

		boolean merged = cosmospra.isMerged();

		assertTrue(merged);
	}
	@Test
	public void testGetAndSetCheckTraceNumber() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setCheckTraceNumber("TRACE12345");

		String checkTraceNumber = cosmospra.getCheckTraceNumber();

		assertEquals("TRACE12345", checkTraceNumber);
	}
	@Test
	public void testGetAndSetPassThruData() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setPassThruData("SamplePassThruData");

		String passThruData = cosmospra.getPassThruData();

		assertEquals("SamplePassThruData", passThruData);
	}
	@Test
	public void testGetAndSetEmailAlertReq() {
		COSMOSPRA cosmospra = new COSMOSPRA();
		cosmospra.setEmailAlertReq("N");

		String emailAlertReq = cosmospra.getEmailAlertReq();

		assertEquals("N", emailAlertReq);
	}
	
	@Test
	public void shouldDeserializeVendorPayIdIntoPaymentNumber() throws Exception {
	    ObjectMapper mapper = new ObjectMapper();
	    String json = "{ \"vendor_pay_id\": \"V12345\" }";
	    COSMOSPRA pojo = mapper.readValue(json, COSMOSPRA.class);
	    assertEquals("V12345", pojo.getPaymentNumber());
	}

}
