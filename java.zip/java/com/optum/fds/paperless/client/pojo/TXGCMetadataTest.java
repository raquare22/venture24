package com.optum.fds.paperless.client.pojo;

import org.json.JSONException;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.junit.Assert.*;
import static org.junit.Assert.assertTrue;

public class TXGCMetadataTest extends AbstractMetadataTestUtil{
    protected static final String PATH_XML_FILE = "files/metadata/TXGC/TXGC.metadata";
    protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/TXGC/TXGCError12.metadata";

    @Test
    public void testTXGCHappyPath() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();


        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "TXGC");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("N4", (String) convertedMetadata.get("subCategory"));
        assertEquals("Texas Gold Card/Approved", (String) convertedMetadata.get("filePath"));
        assertEquals("2024-02-05T00:00:00.000Z", (String) convertedMetadata.get("createdDate"));
    }

    @Test
    public void testTXGCError12() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "TXGC");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(3, errors.size());

        assertEquals("NN", (String) convertedMetadata.get("subCategory"));
        assertEquals("Texas Gold Card/Other", (String) convertedMetadata.get("filePath"));
    }

}
