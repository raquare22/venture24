package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UHCWestMetadataTest extends AbstractMetadataTestUtil {
	
	// emailAlertReq = Y, EFT_Ind = Y
	protected static final String PATH_XML_FILE = "files/metadata/UHCWest/UHCWest.metadata";
	// emailAlertReq = Y, EFT_Ind = Y
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/UHCWest/UHCWestError12.metadata";
	// emailAlertReq = Y, EFT_Ind = null
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/UHCWest/UHCWestError22.metadata";
	// emailAlertReq = N, EFT_Ind = N
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/UHCWest/UHCWest_emailAlertReq_N.metadata";
	// emailAlertReq = Y, EFT_Ind = Y
	protected static final String PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_Y = "files/metadata/UHCWest/UHCWest_emailAlertReq_Y_EFT_Ind_Y.metadata";
	// emailAlertReq = Y, EFT_Ind = N
	protected static final String PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_N = "files/metadata/UHCWest/UHCWest_emailAlertReq_Y_EFT_Ind_N.metadata";
	// emailAlertReq = N, EFT_Ind = Y
	protected static final String PATH_XML_FILE_emailAlertReq_N_EFT_Ind_Y = "files/metadata/UHCWest/UHCWest_emailAlertReq_N_EFT_Ind_Y.metadata";

	
	@Test
	public void testUHCWestHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UHCWest");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("P5", (String) convertedMetadata.get("subCategory"));
		assertEquals("UHC West Payment Packages/Detailed Pmt Docs", (String) convertedMetadata.get("filePath"));
		assertEquals("2021-03-22T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
		
	}
	
	@Test
	public void testUHCWestError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UHCWest");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(4, errors.size());
		
		assertEquals("PR", (String) convertedMetadata.get("subCategory"));
	}
	
	@Test
	public void testUHCWestError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UHCWest");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(7, errors.size());
		
		assertFalse(errors.contains("Missing or invalid data tin (severe error)"));
		
		assertEquals("P5", (String) convertedMetadata.get("subCategory"));
		assertEquals("UHC West Payment Packages/Detailed Pmt Docs", (String) convertedMetadata.get("filePath"));
	}
	
	
	@Test
	public void testUHCWestEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UHCWest");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("P5", (String) convertedMetadata.get("subCategory"));
		assertEquals("UHC West Payment Packages/Detailed Pmt Docs", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testUHCWestEmailAlertReqY_EFT_Ind_Y() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_Y).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UHCWest");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertEquals(1, errors.size());

		
		assertEquals("P5", (String) convertedMetadata.get("subCategory"));
		assertEquals("UHC West Payment Packages/Detailed Pmt Docs", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testUHCWestEmailAlertReqY_EFT_Ind_N() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UHCWest");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

		
		assertEquals("P5", (String) convertedMetadata.get("subCategory"));
		assertEquals("UHC West Payment Packages/Detailed Pmt Docs", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testUHCWestEmailAlertReqN_EFT_Ind_Y() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N_EFT_Ind_Y).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UHCWest");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("P5", (String) convertedMetadata.get("subCategory"));
		assertEquals("UHC West Payment Packages/Detailed Pmt Docs", (String) convertedMetadata.get("filePath"));
	}
	@Test
	public void testGetAndSetCONFIGKEY() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setCONFIGKEY("CONFIG123");

		String configKey = uhcWest.getCONFIGKEY();

		assertEquals("CONFIG123", configKey);
	}
	@Test
	public void testGetAndSetMailToAddress1() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setMailToAddress1("123 Main St");

		String mailToAddress1 = uhcWest.getMailToAddress1();

		assertEquals("123 Main St", mailToAddress1);
	}
	@Test
	public void testGetAndSetMailToAddress2() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setMailToAddress2("456 Elm St");

		String mailToAddress2 = uhcWest.getMailToAddress2();

		assertEquals("456 Elm St", mailToAddress2);
	}
	@Test
	public void testGetAndSetMailToAddress3() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setMailToAddress3("789 Oak St");

		String mailToAddress3 = uhcWest.getMailToAddress3();

		assertEquals("789 Oak St", mailToAddress3);
	}
	@Test
	public void testGetAndSetMailToAddress4() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setMailToAddress4("101 Pine St");

		String mailToAddress4 = uhcWest.getMailToAddress4();

		assertEquals("101 Pine St", mailToAddress4);
	}
	@Test
	public void testGetAndSetMailToAddress5() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setMailToAddress5("202 Birch St");

		String mailToAddress5 = uhcWest.getMailToAddress5();

		assertEquals("202 Birch St", mailToAddress5);
	}
	@Test
	public void testGetAndSetMailToAddress6() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setMailToAddress6("303 Cedar St");

		String mailToAddress6 = uhcWest.getMailToAddress6();

		assertEquals("303 Cedar St", mailToAddress6);
	}
	@Test
	public void testGetAndSetEFT_Ind() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setEFT_Ind("Y");

		String eftInd = uhcWest.getEFT_Ind();

		assertEquals("Y", eftInd);
	}
	@Test
	public void testGetAndSetPhysicianName() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setPhysicianName("Dr. John Doe");

		String physicianName = uhcWest.getPhysicianName();

		assertEquals("Dr. John Doe", physicianName);
	}
	@Test
	public void testGetAndSetCheckAmt() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setCheckAmt("500.00");

		String checkAmt = uhcWest.getCheckAmt();

		assertEquals("500.00", checkAmt);
	}
	@Test
	public void testGetAndSetSubCategory() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setSubCategory("PR");

		String subCategory = uhcWest.getSubCategory();

		assertEquals("PR", subCategory);
	}
	@Test
	public void testGetAndSetPassThruData() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setPassThruData("SampleData");

		String passThruData = uhcWest.getPassThruData();

		assertEquals("SampleData", passThruData);
	}
	@Test
	public void testGetAndSetTin() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setTin("TIN123456");

		String tin = uhcWest.getTin();

		assertEquals("TIN123456", tin);
	}
	@Test
	public void testGetAndSetOriginalPrintTrail() {
		UHCWest uhcWest = new UHCWest();
		uhcWest.setOriginalPrintTrail("Trail456");

		String originalPrintTrail = uhcWest.getOriginalPrintTrail();

		assertEquals("Trail456", originalPrintTrail);
	}
	
	@Test
	public void shouldDeserializeVendorPayIdIntoPaymentNumber() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		String json = "{ \"vendor_pay_id\": \"V12345\" }";
		UHCWest pojo = mapper.readValue(json, UHCWest.class);
		assertEquals("V12345", pojo.getPaymentNumber());
	}


}
