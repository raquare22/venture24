package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.json.JSONException;
import org.junit.Test;

public class PriorAuth1ClickMetadataTest extends AbstractMetadataTestUtil {
	
	protected static final String PATH_XML_FILE = "files/metadata/PriorAuth1Click/PriorAuth1Click.metadata";
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/PriorAuth1Click/PriorAuth1ClickError12.metadata";
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/PriorAuth1Click/PriorAuth1ClickError22.metadata";
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/PriorAuth1Click/PriorAuth1Click_emailAlertReq_N.metadata";

	@Test
	public void testPriorAuth1ClickHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		String testDate = null;
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuth1Click");
			SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			 isoFormat.setTimeZone(TimeZone.getTimeZone("EST"));
			 Date date = isoFormat.parse((String)convertedMetadata.get("dateOfService")); // 11292017
				testDate = isoFormat.format(date);
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());

		assertEquals(testDate, (String) convertedMetadata.get("dateOfService"));
		assertEquals("2018-06-19T12:54:57.000Z", (String) convertedMetadata.get("createdDate"));
		assertEquals("A4", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare Prior Auth/Approved", (String) convertedMetadata.get("filePath"));
		assertEquals("WEIR RONALD", (String) convertedMetadata.get("memberName"));
		assertEquals("ALLINA HEALTH UNITED WOMENS HEALTH CLINI", (String) convertedMetadata.get("providerName"));
		assertEquals("ALLINA HEALTH UNITED WOMENS HEALTH CLINI", (String) convertedMetadata.get("physicianName"));

	}
	
	@Test
	public void testPriorAuth1ClickError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuth1Click");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(8, errors.size());
		
		assertEquals("ZZ", (String) convertedMetadata.get("subCategory"));
		assertEquals("Misc. Prior Auth/Other", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testPriorAuth1ClickError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuth1Click");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(9, errors.size());
		
		assertEquals("A4", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare Prior Auth/Approved", (String) convertedMetadata.get("filePath"));
	}

	@Test
	public void testPriorAuth1ClickEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "PriorAuth1Click");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
	}
	@Test
	public void testGetMailToAddress1() {
		PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
		pecosmospra.setMailToAddress1("123 Main St");

		String mailToAddress1 = pecosmospra.getMailToAddress1();

		assertEquals("123 Main St", mailToAddress1);
	}
	@Test
	public void testGetProviderFirstName() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setProviderFirstName("John");

		String providerFirstName = priorAuth1Click.getProviderFirstName();

		assertEquals("John", providerFirstName);
	}
	@Test
	public void testGetProviderLastName() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setProviderLastName("Doe");

		String providerLastName = priorAuth1Click.getProviderLastName();

		assertEquals("Doe", providerLastName);
	}
	@Test
	public void testGetPhysicianName() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setPhysicianName("Dr. Smith");

		String physicianName = priorAuth1Click.getPhysicianName();

		assertEquals("Dr. Smith", physicianName);
	}
	@Test
	public void testGetMemberFirstName() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setMemberFirstName("Alice");

		String memberFirstName = priorAuth1Click.getMemberFirstName();

		assertEquals("Alice", memberFirstName);
	}
	@Test
	public void testGetMemberLastName() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setMemberLastName("Johnson");

		String memberLastName = priorAuth1Click.getMemberLastName();

		assertEquals("Johnson", memberLastName);
	}
	@Test
	public void testGetPolicyNumber() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setPolicyNumber("POL12345");

		String policyNumber = priorAuth1Click.getPolicyNumber();

		assertEquals("POL12345", policyNumber);
	}
	@Test
	public void testGetSubCategory() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setSubCategory("A1");

		String subCategory = priorAuth1Click.getSubCategory();

		assertEquals("A1", subCategory);
	}
	@Test
	public void testGetTin() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setTin("123456789");

		String tin = priorAuth1Click.getTin();

		assertEquals("123456789", tin);
	}
	@Test
	public void testGetEmailAlertReq() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setEmailAlertReq("N");

		String emailAlertReq = priorAuth1Click.getEmailAlertReq();

		assertEquals("N", emailAlertReq);
	}
	@Test
	public void testGetRELATEDID() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setRELATEDID("REL12345");

		String relatedId = priorAuth1Click.getRELATEDID();

		assertEquals("REL12345", relatedId);
	}
	@Test
	public void testGetNotificationNumber() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setNotificationNumber("NOTIF123");

		String notificationNumber = priorAuth1Click.getNotificationNumber();

		assertEquals("NOTIF123", notificationNumber);
	}
	@Test
	public void testGetMemberId() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setMemberId("MEM12345");

		String memberId = priorAuth1Click.getMemberId();

		assertEquals("MEM12345", memberId);
	}
	@Test
	public void testGetCONFIGKEY() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setCONFIGKEY("CONFIG123");

		String configKey = priorAuth1Click.getCONFIGKEY();

		assertEquals("CONFIG123", configKey);
	}
	@Test
	public void testGetPassThruData() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setPassThruData("TestData");

		String passThruData = priorAuth1Click.getPassThruData();

		assertEquals("TestData", passThruData);
	}
	@Test
	public void testGetOriginalPrintTrail() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setOriginalPrintTrail("Trail123");

		String originalPrintTrail = priorAuth1Click.getOriginalPrintTrail();

		assertEquals("Trail123", originalPrintTrail);
	}
	@Test
	public void testGetProviderName() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setProviderName("Provider ABC");

		String providerName = priorAuth1Click.getProviderName();

		assertEquals("Provider ABC", providerName);
	}
	@Test
	public void testGetMailToAddress6() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setMailToAddress6("303 Cedar St");

		String mailToAddress6 = priorAuth1Click.getMailToAddress6();

		assertEquals("303 Cedar St", mailToAddress6);
	}
	@Test
	public void testGetMailToAddress2() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setMailToAddress2("456 Oak St");

		String mailToAddress2 = priorAuth1Click.getMailToAddress2();

		assertEquals("456 Oak St", mailToAddress2);
	}
	@Test
	public void testGetMailToAddress3() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setMailToAddress3("789 Pine St");

		String mailToAddress3 = priorAuth1Click.getMailToAddress3();

		assertEquals("789 Pine St", mailToAddress3);
	}
	@Test
	public void testGetMailToAddress4() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setMailToAddress4("101 Birch St");

		String mailToAddress4 = priorAuth1Click.getMailToAddress4();

		assertEquals("101 Birch St", mailToAddress4);
	}
	@Test
	public void testGetMailToAddress5() {
		PriorAuth1Click priorAuth1Click = new PriorAuth1Click();
		priorAuth1Click.setMailToAddress5("202 Elm St");

		String mailToAddress5 = priorAuth1Click.getMailToAddress5();

		assertEquals("202 Elm St", mailToAddress5);
	}

}
