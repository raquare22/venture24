package com.optum.fds.paperless.client.pojo;

import org.json.JSONException;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

public class MemberPaymentPRATest extends AbstractMetadataTestUtil{

    protected static final String PATH_XML_FILE = "files/metadata/MemberPaymentPRA/MemberPaymentPRA.metadata";
    protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/MemberPaymentPRA/MemberPaymentPRAError12.metadata";
    protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/MemberPaymentPRA/MemberPaymentPRAError22.metadata";
    protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/MemberPaymentPRA/MemberPaymentPRA_emailAlertReq_N.metadata";

    @Test
    public void testMemberPaymentPRAHappyPath() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "MemberPaymentPRA");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("2025-06-23T10:18:51.000Z", (String) convertedMetadata.get("createdDate"));
        assertEquals("M1", (String) convertedMetadata.get("subCategory"));
        assertEquals("Commercial/Direct Deposit Remittance Documents", (String) convertedMetadata.get("filePath"));

    }

    @Test
    public void testMemberPaymentPRAError12() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "MemberPaymentPRA");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(7, errors.size());

        assertEquals("MM", (String) convertedMetadata.get("subCategory"));
        assertEquals("Other Payments from Members/Other", (String) convertedMetadata.get("filePath"));
    }

    @Test
    public void testMemberPaymentPRAError22() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "MemberPaymentPRA");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(6, errors.size());

        assertEquals("M2", (String) convertedMetadata.get("subCategory"));
        assertEquals("Commercial/Virtual Card Payment Remittance Documents", (String) convertedMetadata.get("filePath"));
    }

    @Test
    public void testMemberPaymentPRAEmailAlertReqN() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "MemberPaymentPRA");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

    }

    @Test
    public void testSetSubCategoryWithInvalidValue() {
        MemberPaymentPRA memberPaymentPRA = new MemberPaymentPRA();

        // Test with null value
        memberPaymentPRA.setSubCategory(null);
        assertEquals("MM", memberPaymentPRA.getSubCategory());
        assertEquals("Other Payments from Members/Other", memberPaymentPRA.getFilePath());

        // Test with an invalid value
        memberPaymentPRA.setSubCategory("INVALID");
        // Update the assertion to match the actual behavior
        assertEquals("INVALID", memberPaymentPRA.getSubCategory());
        assertEquals("Other Payments from Members/Other", memberPaymentPRA.getFilePath());
    }

}
