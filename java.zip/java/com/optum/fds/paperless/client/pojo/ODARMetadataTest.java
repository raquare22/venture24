package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

public class ODARMetadataTest extends AbstractMetadataTestUtil {
	
	
	protected static final String PATH_XML_FILE = "files/metadata/ODAR/ODAR.metadata";
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/ODAR/ODARError12.metadata";
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/ODAR/ODARError22.metadata";
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/ODAR/ODAR_emailAlertReq_N.metadata";

	
	@Test
	public void testODARHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "ODAR");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("C5", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial Overpayment Letters/Overpayment Identified", (String) convertedMetadata.get("filePath"));
		assertEquals("2021-03-22T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
		
	}
	
	@Test
	public void testODARError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "ODAR");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(11, errors.size());
		
		assertEquals("OP", (String) convertedMetadata.get("subCategory"));
		assertEquals("Other Overpayment Letters/Other Overpayment Letters", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testODARError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "ODAR");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(5, errors.size());

		assertEquals("R4", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare Overpayment Letters/Overpayment Identified", (String) convertedMetadata.get("filePath"));
	}
	
	
	@Test
	public void testODAREmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "ODAR");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("S3", (String) convertedMetadata.get("subCategory"));
		assertEquals("Community Plan Overpayment Letters/Overpayment Identified", (String) convertedMetadata.get("filePath"));
	}
	@Test
	public void testGetAndSetMpin() {
		ODAR odar = new ODAR();
		odar.setMpin("12345");

		String mpin = odar.getMpin();

		assertEquals("12345", mpin);
	}
	@Test
	public void testGetAndSetEmailAlertReq() {
		ODAR odar = new ODAR();
		odar.setEmailAlertReq("Y");

		String emailAlertReq = odar.getEmailAlertReq();

		assertEquals("Y", emailAlertReq);
	}
	@Test
	public void testGetAndSetMultDivisionCode() {
		ODAR odar = new ODAR();
		odar.setMultDivisionCode("DIV123");

		String multDivisionCode = odar.getMultDivisionCode();

		assertEquals("DIV123", multDivisionCode);
	}
	@Test
	public void testGetAndSetMultMemberName() {
		ODAR odar = new ODAR();
		odar.setMultMemberName("John Doe");

		String multMemberName = odar.getMultMemberName();

		assertEquals("John Doe", multMemberName);
	}
	@Test
	public void testGetAndSetMultCheckNumber() {
		ODAR odar = new ODAR();
		odar.setMultCheckNumber("CHK789");

		String multCheckNumber = odar.getMultCheckNumber();

		assertEquals("CHK789", multCheckNumber);
	}
	@Test
	public void testGetAndSetLetterGroupId() {
		ODAR odar = new ODAR();
		odar.setLetterGroupId("LG123");

		String letterGroupId = odar.getLetterGroupId();

		assertEquals("LG123", letterGroupId);
	}
	@Test
	public void testGetAndSetMultClaimNumber() {
		ODAR odar = new ODAR();
		odar.setMultClaimNumber("CLAIM123");

		String multClaimNumber = odar.getMultClaimNumber();

		assertEquals("CLAIM123", multClaimNumber);
	}
	@Test
	public void testGetAndSetSource() {
		ODAR odar = new ODAR();
		odar.setSource("TestSource");

		String source = odar.getSource();

		assertEquals("TestSource", source);
	}
	@Test
	public void testGetAndSetLetterType() {
		ODAR odar = new ODAR();
		odar.setLetterType("TypeA");

		String letterType = odar.getLetterType();

		assertEquals("TypeA", letterType);
	}
	@Test
	public void testGetAndSetFacilityType() {
		ODAR odar = new ODAR();
		odar.setFacilityType("Hospital");

		String facilityType = odar.getFacilityType();

		assertEquals("Hospital", facilityType);
	}
	@Test
	public void testGetAndSetReturnAddress1() {
		ODAR odar = new ODAR();
		odar.setReturnAddress1("123 Return St");

		String returnAddress1 = odar.getReturnAddress1();

		assertEquals("123 Return St", returnAddress1);
	}
	@Test
	public void testGetAndSetReturnAddress2() {
		ODAR odar = new ODAR();
		odar.setReturnAddress2("456 Return Ave");

		String returnAddress2 = odar.getReturnAddress2();

		assertEquals("456 Return Ave", returnAddress2);
	}
	@Test
	public void testGetAndSetReturnAddress3() {
		ODAR odar = new ODAR();
		odar.setReturnAddress3("789 Return Blvd");

		String returnAddress3 = odar.getReturnAddress3();

		assertEquals("789 Return Blvd", returnAddress3);
	}
	@Test
	public void testGetAndSetReturnAddress4() {
		ODAR odar = new ODAR();
		odar.setReturnAddress4("101 Return Lane");

		String returnAddress4 = odar.getReturnAddress4();

		assertEquals("101 Return Lane", returnAddress4);
	}
	@Test
	public void testGetAndSetReturnAddress5() {
		ODAR odar = new ODAR();
		odar.setReturnAddress5("202 Return Circle");

		String returnAddress5 = odar.getReturnAddress5();

		assertEquals("202 Return Circle", returnAddress5);
	}
	@Test
	public void testGetAndSetReturnAddress6() {
		ODAR odar = new ODAR();
		odar.setReturnAddress6("303 Return Plaza");

		String returnAddress6 = odar.getReturnAddress6();

		assertEquals("303 Return Plaza", returnAddress6);
	}

}
