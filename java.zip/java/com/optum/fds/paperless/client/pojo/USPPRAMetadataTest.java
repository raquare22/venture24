package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import com.fasterxml.jackson.databind.ObjectMapper;


public class USPPRAMetadataTest extends AbstractMetadataTestUtil {
		
	protected static final String PATH_XML_FILE = "files/metadata/USPPRA/USP_PRA.metadata";
    protected static final String PATH_XML_FILE_MISSING_LETTERTYPE = "files/metadata/USPPRA/USP_PRAMissingLetterType.metadata";
    protected static final String PATH_XML_FILE_INVALID_LETTERTYPE = "files/metadata/USPPRA/USP_PRAInvalidLetterType.metadata";
    protected static final String PATH_XML_FILE_MISSING_MPIN = "files/metadata/USPPRA/USP_PRAMissingMpin.metadata";
    protected static final String PATH_XML_FILE_MISSING_MULT_CLAIM_NUMBER = "files/metadata/USPPRA/USP_PRAMissingMultClaimNumber.metadata";
    protected static final String PATH_XML_FILE_MISSING_IS_PRINT_SUPPRESSED_FIELD = "files/metadata/USPPRA/USP_PRAMissingIsPrintSuppressedField.metadata";
    protected static final String PATH_XML_FILE_MISSING_CREATED_DATE = "files/metadata/USPPRA/USP_PRAMissingCreatedDate.metadata";
    protected static final String PATH_XML_FILE_WITH_BLANK_CONFIG_KEY_VALUE = "files/metadata/USPPRA/USP_PRABlankConfigKey.metadata";
    protected static final String  PATH_XML_FILE_MAIL_TO_ADDRESS1 = "files/metadata/USPPRA/USP_PRAMissingMailToAddress1.metadata";

	@Test
	public void testUNETPRAHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "USPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("P1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Detailed PRAs", (String) convertedMetadata.get("filePath"));
		assertEquals("2021-03-19T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
		
	}
		
 	@Test
	public void testUSP_PRA_MISSING_LETTERTYPE() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_MISSING_LETTERTYPE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "USPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());

		assertTrue(errors.contains("Missing or invalid data: LETTERTYPE"));
		
		assertEquals("PR", (String) convertedMetadata.get("subCategory"));
		assertEquals("Other PRAs/Other", (String) convertedMetadata.get("filePath"));
	}
		
	@Test
	public void testUSP_PRA_InVALID_LETTERTYPE() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_INVALID_LETTERTYPE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "USPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		assertEquals(0, errors.size());
		
		assertNotEquals("P1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Other PRAs/Other", (String) convertedMetadata.get("filePath"));
	}
	
	
	@Test
	public void testUSP_PRA_MISSING_MPIN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_MISSING_MPIN).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "USPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertTrue(errors.contains("Missing or invalid data: IndivProviderMPIN"));

		assertEquals("P1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Detailed PRAs", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testUSP_PRA_MISSING_MULT_CLAIM_NUMBER() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_MISSING_MULT_CLAIM_NUMBER).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "USPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());

		assertTrue(errors.contains("Missing or invalid data: claimNumber"));
		
	}
	
//	@Test
	public void testUSP_PRA_MISSING_IS_PRINT_SUPPRESSED_FIELD() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_MISSING_IS_PRINT_SUPPRESSED_FIELD).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "USPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());
		
		assertTrue(errors.contains("Missing or invalid data: isPrintSuppressed"));
		
		}
	
	@Test
	public void testUSP_PRA_MISSING_PROCESSED_DATE() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_MISSING_CREATED_DATE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "USPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());

		assertTrue(errors.contains("Missing or invalid data: PROCESSDATE"));
	}
	
	@Test
	public void testUSP_PRA_BLANK_CONFIG_KEY_VALUE() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_WITH_BLANK_CONFIG_KEY_VALUE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "USPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());

		assertTrue(errors.contains("Missing or invalid data: CONFIGKEY(SEVERE)"));
	}
	@Test
	public void testGetTin() {
		USPPRA usppra = new USPPRA();
		usppra.setTin("123456789");

		String tin = usppra.getTin();

		assertEquals("123456789", tin);
	}
	@Test
	public void testGetMpin() {
		USPPRA usppra = new USPPRA();
		usppra.setMpin("MPIN123");

		String mpin = usppra.getMpin();

		assertEquals("MPIN123", mpin);
	}
	@Test
	public void testGetEmailAlertReq() {
		USPPRA usppra = new USPPRA();
		usppra.setEmailAlertReq("N");

		String emailAlertReq = usppra.getEmailAlertReq();

		assertEquals("N", emailAlertReq);
	}
	@Test
	public void testGetEFT_Ind() {
		USPPRA usppra = new USPPRA();
		usppra.setEFT_Ind("EFT123");

		String eftInd = usppra.getEFT_Ind();

		assertEquals("EFT123", eftInd);
	}
	@Test
	public void testGetPhysicianName() {
		USPPRA usppra = new USPPRA();
		usppra.setPhysicianName("Dr. John Doe");

		String physicianName = usppra.getPhysicianName();

		assertEquals("Dr. John Doe", physicianName);
	}
	@Test
	public void testGetCheckAmt() {
		USPPRA usppra = new USPPRA();
		usppra.setCheckAmt("1000.50");

		String checkAmt = usppra.getCheckAmt();

		assertEquals("1000.50", checkAmt);
	}
	@Test
	public void testGetMailToAddress2() {
		USPPRA usppra = new USPPRA();
		usppra.setMailToAddress2("456 Oak St");

		String mailToAddress2 = usppra.getMailToAddress2();

		assertEquals("456 Oak St", mailToAddress2);
	}
	@Test
	public void testGetMailToAddress3() {
		USPPRA usppra = new USPPRA();
		usppra.setMailToAddress3("789 Pine St");

		String mailToAddress3 = usppra.getMailToAddress3();

		assertEquals("789 Pine St", mailToAddress3);
	}
	@Test
	public void testGetMailToAddress4() {
		USPPRA usppra = new USPPRA();
		usppra.setMailToAddress4("404 Willow St");

		String mailToAddress4 = usppra.getMailToAddress4();

		assertEquals("404 Willow St", mailToAddress4);
	}
	@Test
	public void testGetMailToAddress5() {
		USPPRA usppra = new USPPRA();
		usppra.setMailToAddress5("505 Maple St");

		String mailToAddress5 = usppra.getMailToAddress5();

		assertEquals("505 Maple St", mailToAddress5);
	}
	@Test
	public void testGetMailToAddress6() {
		USPPRA usppra = new USPPRA();
		usppra.setMailToAddress6("606 Spruce St");

		String mailToAddress6 = usppra.getMailToAddress6();

		assertEquals("606 Spruce St", mailToAddress6);
	}
	@Test
	public void testGetMemberId() {
		USPPRA usppra = new USPPRA();
		usppra.setMemberId("MEM123");

		String memberId = usppra.getMemberId();

		assertEquals("MEM123", memberId);
	}
	@Test
	public void testGetMailToAddress1() {
		USPPRA usppra = new USPPRA();
		usppra.setMailToAddress1("123 Main St");

		String mailToAddress1 = usppra.getMailToAddress1();

		assertEquals("123 Main St", mailToAddress1);
	}
	@Test
	public void testGetSubCategory() {
		USPPRA usppra = new USPPRA();
		usppra.setSubCategory("P2");

		String subCategory = usppra.getSubCategory();

		assertEquals("P2", subCategory);
	}
	@Test
	public void testGetCheckTraceNumber() {
		USPPRA usppra = new USPPRA();
		usppra.setCheckTraceNumber("TRACE67890");

		String checkTraceNumber = usppra.getCheckTraceNumber();

		assertEquals("TRACE67890", checkTraceNumber);
	}
	@Test
	public void testGetPassThruData() {
		USPPRA usppra = new USPPRA();
		usppra.setPassThruData("SampleData");

		String passThruData = usppra.getPassThruData();

		assertEquals("SampleData", passThruData);
	}
	@Test
	public void testGetCONFIGKEY() {
		USPPRA usppra = new USPPRA();
		usppra.setCONFIGKEY("CONFIG456");

		String configKey = usppra.getCONFIGKEY();

		assertEquals("CONFIG456", configKey);
	}


	@Test
	public void testUSPPRASubcategories() {
		USPPRA uspPraObj = new USPPRA();
		for (USPPRA.Subcategory subcategory : USPPRA.Subcategory.values()) {
			uspPraObj.setSubCategory(subcategory.getSubCat());
			assertEquals(subcategory.getSubCat(), uspPraObj.getSubCategory());
			assertEquals(subcategory.getFilePath(), uspPraObj.getFilePath());
		}
	}

	@Test
	public void testUSPPRASubcategoryFilePath() {
		USPPRA uspPraObj = new USPPRA();
		String[] subCategories = {"P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P0", "E1", "E2", "E3", "E4", "PR"};
		for (String subCategory : subCategories) {
			uspPraObj.setSubCategory(subCategory);
			String expectedFilePath = USPPRA.Subcategory.valueOf(subCategory).getFilePath();
			assertEquals(expectedFilePath, uspPraObj.getFilePath());
		}
	}

	@Test  
	public void testSetSubCategoryWithNull() {  
		USPPRA uspPraObj = new USPPRA();  
		uspPraObj.setSubCategory(null);  
		assertEquals("PR", uspPraObj.getSubCategory());  
		assertEquals("Other PRAs/Other", uspPraObj.getFilePath());  
	}
	
	@Test  
	public void testSetSubCategoryWithEmptyString() {  
		USPPRA uspPraObj = new USPPRA();  
		uspPraObj.setSubCategory("");  
		assertEquals("PR", uspPraObj.getSubCategory());  
		assertEquals("Other PRAs/Other", uspPraObj.getFilePath());  
	}
	
	@Test
	public void shouldDeserializeVendorPayIdIntoPaymentNumber() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		String json = "{ \"vendor_pay_id\": \"V12345\" }";
		USPPRA pojo = mapper.readValue(json, USPPRA.class);
		assertEquals("V12345", pojo.getPaymentNumber());
	}

}
