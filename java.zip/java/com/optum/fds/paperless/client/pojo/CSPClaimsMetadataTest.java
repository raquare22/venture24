package com.optum.fds.paperless.client.pojo;

import org.json.JSONException;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.*;

public class CSPClaimsMetadataTest extends AbstractMetadataTestUtil {

    // emailAlertReq = Y, EFT_Ind = Y
    protected static final String PATH_XML_FILE = "files/metadata/CSPClaims/CSPClaims.metadata";
    // emailAlertReq = Y, EFT_Ind = Y, SubCategory = X2
    protected static final String PATH_XML_FILE_X2 = "files/metadata/CSPClaims/CSPClaimsSubCategoryX2.metadata";
    // emailAlertReq = Y, EFT_Ind = Y
    protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/CSPClaims/CSPClaimsError12.metadata";
    // emailAlertReq = Y, EFT_Ind = null
    protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/CSPClaims/CSPClaimsError22.metadata";
    // emailAlertReq = N, EFT_Ind = N
    protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/CSPClaims/CSPClaims_emailAlertReq_N.metadata";
    // emailAlertReq = Y, EFT_Ind = Y


    @Test
    public void testCSPClaimsHappyPath() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "CSPClaims");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("2018-07-26T00:00:00.000Z", (String) convertedMetadata.get("createdDate"));
        assertEquals("PRUNPP3515", (String) convertedMetadata.get("CONFIGKEY"));
        assertEquals("12345", (String) convertedMetadata.get("Macess_SF_ID"));
    }

    @Test
    public void testCSPClaimsSubCategoryX2() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_X2).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "CSPClaims");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("Appeals and Disputes", (String) convertedMetadata.get("category"));
        assertEquals("PRUNPP3515", (String) convertedMetadata.get("CONFIGKEY"));
    }

    @Test
    public void testCSPClaimsError12() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "CSPClaims");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(6, errors.size());

        assertEquals("BARNABY COLLINS", (String) convertedMetadata.get("providerName"));
        assertEquals("11223344", (String) convertedMetadata.get("memberId"));
    }

    @Test
    public void testCSPClaimsError22() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "CSPClaims");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(8, errors.size());

//        assertFalse(errors.contains("Missing or invalid data tin (severe error)"));

        assertEquals("8954613900", (String) convertedMetadata.get("claimNumber"));
        assertEquals("11223344", (String) convertedMetadata.get("memberId"));
    }


    @Test
    public void testCSPClaimsEmailAlertReqN() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "CSPClaims");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("8954613900", (String) convertedMetadata.get("claimNumber"));
        assertEquals("11223344", (String) convertedMetadata.get("memberId"));
    }

    @Test
    public void testCSPClaims(){
        CSPClaims cspObj = new CSPClaims();
        cspObj.setClaimNumber("Claim 12345");
        cspObj.setCONFIGKEY("Config 12345");
        cspObj.setEmailAlertReq("Y");
        cspObj.setMailToAddress1("Tower 1");
        cspObj.setMailToAddress2("Claire");
        cspObj.setMailToAddress3("Texas");
        cspObj.setMailToAddress4("USA");
        cspObj.setMpin("mpin 123");
        cspObj.setTin("tin 123");
        cspObj.setSubCategory("C3");
        cspObj.setProviderName("Test Provider");
        cspObj.setMemberId("ID 123");
        cspObj.setMacess_SF_ID("macess 123");

        assertNotNull(cspObj);
        assertEquals("Claim 12345", cspObj.getClaimNumber());
        assertEquals("Tower 1", cspObj.getMailToAddress1());
        assertEquals("Y", cspObj.getEmailAlertReq());
        assertEquals("mpin 123",cspObj.getMpin());
        assertEquals("tin 123", cspObj.getTin());
        assertEquals("C3", cspObj.getSubCategory());
        assertEquals("Test Provider", cspObj.getProviderName());
        assertEquals("ID 123", cspObj.getMemberId());
        assertEquals("macess 123", cspObj.getMacess_SF_ID());
        assertNull(cspObj.getPassThruData());
        assertNull(cspObj.getDateEmailSent());
        assertNull(cspObj.getExpiryDate());
        assertFalse(cspObj.getSendPENAPIRequest());
    }



}


