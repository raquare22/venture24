package com.optum.fds.paperless.client.pojo;

import org.json.JSONException;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.*;

import static org.junit.Assert.*;

public class NGSClaimsMetadataTest extends AbstractMetadataTestUtil {

    protected static final String PATH_XML_FILE = "files/metadata/NGSClaims/NGSClaims.metadata";
    protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/NGSClaims/NGSClaimsError12.metadata";
    protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/NGSClaims/NGSClaimsError22.metadata";
    protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/NGSClaims/NGSClaims_emailAlertReq_N.metadata";


    @Test
    public void testNGSClaimsHappyPath() {
        File file = new File(Objects.requireNonNull(getClass().getClassLoader().getResource(PATH_XML_FILE)).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "NGSClaims");
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());
        assertEquals("R1", (String) convertedMetadata.get("subCategory"));
        assertEquals("Medicare/Action Required", (String) convertedMetadata.get("filePath"));
        assertEquals("2025-02-25T14:11:59.000Z", (String) convertedMetadata.get("createdDate"));
        // test ProviderName is copied to MailToAddress1
        assertEquals("KUBAT HEALTHCARE", (String) convertedMetadata.get("providerName"));
        assertEquals("KUBAT HEALTHCARE", (String) convertedMetadata.get("MailToAddress1"));
        // Test MailToAddress1 is copied to MailToAddress2
        assertEquals("11111 OLD MILL ROAD", (String) convertedMetadata.get("MailToAddress2"));
        // Test MailToAddress2 is copied to MailToAddress3
        assertEquals("Suite 1", (String) convertedMetadata.get("MailToAddress3"));
    }

    @Test
    public void testNGSClaimsError12() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "NGSClaims");
        } catch (IOException | JSONException e) {
            System.out.println("Error occured while converting metadata");
            e.printStackTrace();
        }

        System.out.println("convertedMetadata=" + convertedMetadata);
        System.out.println("errors=" + errors);

        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(4, errors.size());

        assertEquals("R0", (String) convertedMetadata.get("subCategory"));
        assertEquals("Medicare/Copy of Member Letters", (String) convertedMetadata.get("filePath"));
        assertEquals("2024-06-22T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
    }

   @Test
    public void testNGSClaimsError22() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "NGSClaims");
        } catch (IOException | JSONException e) {
            System.out.println("Error occured while converting metadata");
            e.printStackTrace();
        }

        System.out.println("convertedMetadata=" + convertedMetadata);
        System.out.println("errors=" + errors);

        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(6, errors.size());

        assertEquals("R0", (String) convertedMetadata.get("subCategory"));
        assertEquals("Medicare/Copy of Member Letters", (String) convertedMetadata.get("filePath"));
        assertEquals("2022-06-24T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
    }

    @Test
    public void testNGSClaimsEmailAlertReqN() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "NGSClaims");
        } catch (IOException | JSONException e) {
            System.out.println("Error occured while converting metadata");
            e.printStackTrace();
        }

        System.out.println("convertedMetadata=" + convertedMetadata);
        System.out.println("errors=" + errors);

        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("ORTHOSPORTS ASSOCIATES LLC", (String) convertedMetadata.get("providerName"));
        assertEquals("Vaughn Stewart Dds", (String) convertedMetadata.get("MailToAddress1"));
        assertEquals("R0", (String) convertedMetadata.get("subCategory"));
        assertEquals("Medicare/Copy of Member Letters", (String) convertedMetadata.get("filePath"));
        assertEquals("2022-06-24T11:18:51.000Z", (String) convertedMetadata.get("createdDate"));
    }
    @Test
    public void testGetNpi() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setNpi("NPI12345");

        String npi = ngsClaims.getNpi();

        assertEquals("NPI12345", npi);
    }
    @Test
    public void testGetNgsId() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setNgsId("NGS12345");

        String ngsId = ngsClaims.getNgsId();

        assertEquals("NGS12345", ngsId);
    }
    @Test
    public void testGetMemberId() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setMemberId("MEM12345");

        String memberId = ngsClaims.getMemberId();

        assertEquals("MEM12345", memberId);
    }
    @Test
    public void testGetPolicyNumber() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setPolicyNumber("POL12345");

        String policyNumber = ngsClaims.getPolicyNumber();

        assertEquals("POL12345", policyNumber);
    }
    @Test
    public void testGetClaimNumber() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setClaimNumber("CLAIM12345");

        String claimNumber = ngsClaims.getClaimNumber();

        assertEquals("CLAIM12345", claimNumber);
    }
    @Test
    public void testGetPassThruData() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setPassThruData("DATA123");

        String passThruData = ngsClaims.getPassThruData();

        assertEquals("DATA123", passThruData);
    }
    @Test
    public void testGetOriginalPrintTrail() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setOriginalPrintTrail("PRINT123");

        String originalPrintTrail = ngsClaims.getOriginalPrintTrail();

        assertEquals("PRINT123", originalPrintTrail);
    }
    @Test
    public void testGetCONFIGKEY() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setCONFIGKEY("CONFIG123");

        String configKey = ngsClaims.getCONFIGKEY();

        assertEquals("CONFIG123", configKey);
    }
    @Test
    public void testGetPatientDOB() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setPatientDOB("01/01/1990");

        String patientDOB = ngsClaims.getPatientDOB();

        assertEquals("01/01/1990", patientDOB);
    }
    @Test
    public void testGetDateOfService() {
        NGSClaims ngsClaims = new NGSClaims();
        Date dateOfService = new Date();
        ngsClaims.setDateOfService(dateOfService);

        Date retrievedDateOfService = ngsClaims.getDateOfService();

        assertEquals(dateOfService, retrievedDateOfService);
    }
    @Test
    public void testGetProviderName() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setProviderName("Provider ABC");

        String providerName = ngsClaims.getProviderName();

        assertEquals("Provider ABC", providerName);
    }
    @Test
    public void testGetMemberName() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setMemberName("John Smith");

        String memberName = ngsClaims.getMemberName();

        assertEquals("John Smith", memberName);
    }
    @Test
    public void testGetMailToAddress6() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setMailToAddress6("404 Maple St");

        String mailToAddress6 = ngsClaims.getMailToAddress6();

        assertEquals("404 Maple St", mailToAddress6);
    }
    @Test
    public void testGetPatientAccountNumber() {
        NGSClaims ngsClaims = new NGSClaims();
        ngsClaims.setPatientAccountNumber("ACC67890");

        String patientAccountNumber = ngsClaims.getPatientAccountNumber();

        assertEquals("ACC67890", patientAccountNumber);
    }
}
