package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CSPPRAMetadataTest extends AbstractMetadataTestUtil {
	
	// emailAlertReq = Y, EFT_Ind = Y
	protected static final String PATH_XML_FILE = "files/metadata/CSPPRA/CSPPRA.metadata";
	// emailAlertReq = null, EFT_Ind = Y
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/CSPPRA/CSPPRAError12.metadata";
	// emailAlertReq = Y, EFT_Ind = Y
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/CSPPRA/CSPPRAError22.metadata";
	
	// emailAlertReq = N, EFT_Ind = N
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/CSPPRA/CSPPRA_emailAlertReq_N.metadata";
	
	// emailAlertReq = Y, EFT_Ind = null
	protected static final String PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_null = "files/metadata/CSPPRA/CSPPRA_emailAlertReq_Y_EFT_Ind_null.metadata";
	// emailAlertReq = Y, EFT_Ind = N
	protected static final String PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_N = "files/metadata/CSPPRA/CSPPRA_emailAlertReq_Y_EFT_Ind_N.metadata";
	// emailAlertReq = N, EFT_Ind = Y
	protected static final String PATH_XML_FILE_emailAlertReq_N_EFT_Ind_Y = "files/metadata/CSPPRA/CSPPRA_emailAlertReq_N_EFT_Ind_Y.metadata";

		
	@Test
	public void testCSPPRAHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "CSPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		assertNotNull(convertedMetadata.get("checkAmt"));
		assertEquals("P1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Detailed PRAs", (String) convertedMetadata.get("filePath"));
		assertEquals("2021-03-21T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
		assertEquals("WEST ORANGE NJ 07052-4229", (String) convertedMetadata.get("MailToAddress4"));
		assertEquals("", convertedMetadata.get("MailToAddress3"));
		
	}
	
	@Test
	public void testCSPPRAError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "CSPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(4, errors.size());
		
		assertEquals("PR", (String) convertedMetadata.get("subCategory"));
		assertEquals("Other PRAs/Other", (String) convertedMetadata.get("filePath"));
	}
	
//	@Test
	public void testCSPPRAError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "CSPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(7, errors.size());
		
		assertEquals("P7", (String) convertedMetadata.get("subCategory"));
		assertEquals("Community Plan/Virtual Card Payments", (String) convertedMetadata.get("filePath"));
	}
	
	
	@Test
	public void testCSPPRAEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "CSPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("P6", (String) convertedMetadata.get("subCategory"));
		assertEquals("Community Plan/PRA", (String) convertedMetadata.get("filePath"));
	}
	
//	@Test
	public void testCSPPRA_emailAlertReq_N_EFT_Ind_null() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_null).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "CSPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("P7", (String) convertedMetadata.get("subCategory"));
		assertEquals("Community Plan/Virtual Card Payments", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testCSPPRA_emailAlertReq_Y_EFT_Ind_N() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_Y_EFT_Ind_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "CSPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("P6", (String) convertedMetadata.get("subCategory"));
		assertEquals("Community Plan/PRA", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testCSPPRA_emailAlertReq_N_EFT_Ind_Y() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N_EFT_Ind_Y).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "CSPPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("P6", (String) convertedMetadata.get("subCategory"));
		assertEquals("Community Plan/PRA", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testCSPPRA_Ind_835()  {  
        CSPPRA csppra= new CSPPRA(); 
        csppra.setInd_835("Y");
        assertEquals("Y", csppra.getInd_835());
	}
	@Test
	public void testGetAndSetMpin() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMpin("12345");

		String mpin = csppra.getMpin();

		assertEquals("12345", mpin);
	}
	@Test
	public void testGetAndSetCheckAmt() {
		CSPPRA csppra = new CSPPRA();
		csppra.setCheckAmt("100.50");

		String checkAmt = csppra.getCheckAmt();

		assertEquals("100.50", checkAmt);
	}
	@Test
	public void testGetAndSetEmailAlertReq() {
		CSPPRA csppra = new CSPPRA();
		csppra.setEmailAlertReq("N");

		String emailAlertReq = csppra.getEmailAlertReq();

		assertEquals("N", emailAlertReq);
	}
	@Test
	public void testGetAndSetPhysicianName() {
		CSPPRA csppra = new CSPPRA();
		csppra.setPhysicianName("Dr. John Doe");

		String physicianName = csppra.getPhysicianName();

		assertEquals("Dr. John Doe", physicianName);
	}
	@Test
	public void testGetAndSetCheckTraceNumber() {
		CSPPRA csppra = new CSPPRA();
		csppra.setCheckTraceNumber("Trace123");

		String checkTraceNumber = csppra.getCheckTraceNumber();

		assertEquals("Trace123", checkTraceNumber);
	}
	@Test
	public void testGetAndSetMultClaimNumber() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMultClaimNumber("Claim123");

		String multClaimNumber = csppra.getMultClaimNumber();

		assertEquals("Claim123", multClaimNumber);
	}
	@Test
	public void testGetAndSetMultMemberId() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMultMemberId("Member123");

		String multMemberId = csppra.getMultMemberId();

		assertEquals("Member123", multMemberId);
	}
	@Test
	public void testGetAndSetMultSubscriberId() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMultSubscriberId("Subscriber123");

		String multSubscriberId = csppra.getMultSubscriberId();

		assertEquals("Subscriber123", multSubscriberId);
	}
	@Test
	public void testGetAndSetPrivilege() {
		CSPPRA csppra = new CSPPRA();
		csppra.setPrivilege("Admin");

		String privilege = csppra.getPrivilege();

		assertEquals("Admin", privilege);
	}
	@Test
	public void testGetAndSetCONFIGKEY() {
		CSPPRA csppra = new CSPPRA();
		csppra.setCONFIGKEY("Config456");

		String configKey = csppra.getCONFIGKEY();

		assertEquals("Config456", configKey);
	}
	@Test
	public void testGetAndSetMailToAddress5() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMailToAddress5("505 Cedar St");

		String mailToAddress5 = csppra.getMailToAddress5();

		assertEquals("505 Cedar St", mailToAddress5);
	}
	@Test
	public void testGetAndSetMailToAddress6() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMailToAddress6("606 Walnut St");

		String mailToAddress6 = csppra.getMailToAddress6();

		assertEquals("606 Walnut St", mailToAddress6);
	}
	@Test
	public void testGetAndSetInd835() {
		CSPPRA csppra = new CSPPRA();
		csppra.setInd_835("N");

		String ind835 = csppra.getInd_835();

		assertEquals("N", ind835);
	}
	@Test
	public void testGetAndSetMailToAddress1() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMailToAddress1("123 Main St");

		String mailToAddress1 = csppra.getMailToAddress1();

		assertEquals("123 Main St", mailToAddress1);
	}
	@Test
	public void testGetAndSetMailToAddress2() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMailToAddress2("456 Elm St");

		String mailToAddress2 = csppra.getMailToAddress2();

		assertEquals("456 Elm St", mailToAddress2);
	}
	@Test
	public void testGetAndSetEFTInd() {
		CSPPRA csppra = new CSPPRA();
		csppra.setEFT_Ind("Y");

		String eftInd = csppra.getEFT_Ind();

		assertEquals("Y", eftInd);
	}
	@Test
	public void testGetAndSetMailToAddress3() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMailToAddress3("789 Pine St");

		String mailToAddress3 = csppra.getMailToAddress3();

		assertEquals("789 Pine St", mailToAddress3);
	}
	@Test
	public void testGetAndSetMailToAddress4() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMailToAddress4("404 Spruce St");

		String mailToAddress4 = csppra.getMailToAddress4();

		assertEquals("404 Spruce St", mailToAddress4);
	}
	@Test
	public void testGetAndSetSubCategory() {
		CSPPRA csppra = new CSPPRA();
		csppra.setSubCategory("P1");

		String subCategory = csppra.getSubCategory();

		assertEquals("P1", subCategory);
	}
	@Test
	public void testGetAndSetTin() {
		CSPPRA csppra = new CSPPRA();
		csppra.setTin("TIN12345");

		String tin = csppra.getTin();

		assertEquals("TIN12345", tin);
	}
	@Test
	public void testSetExpiryDate() {
		CSPPRA csppra = new CSPPRA();
		csppra.setExpiryDate("202312");

		String expiryDate = csppra.getExpiryDate();

		assertEquals("202312", expiryDate);
	}
	@Test
	public void testGetAndSetEmailAlertReqWithEmptyValue() {
		CSPPRA csppra = new CSPPRA();
		csppra.setEmailAlertReq("");

		String emailAlertReq = csppra.getEmailAlertReq();

		assertEquals("Y", emailAlertReq); // Default value should remain "Y" as per the setter logic
	}
	@Test
	public void testGetAndSetCheckAmtWithNullValue() {
		CSPPRA csppra = new CSPPRA();
		csppra.setCheckAmt(null);

		String checkAmt = csppra.getCheckAmt();

		assertNull(checkAmt); // Ensures that null is handled correctly
	}
	@Test
	public void testGetAndSetPassThruData() {
		CSPPRA csppra = new CSPPRA();
		csppra.setPassThruData("Data456");

		String passThruData = csppra.getPassThruData();

		assertEquals("Data456", passThruData);
	}
	@Test
	public void testGetAndSetPhysicianNameWithNullValue() {
		CSPPRA csppra = new CSPPRA();
		csppra.setPhysicianName(null);

		String physicianName = csppra.getPhysicianName();

		assertNull(physicianName); // Ensures that null is handled correctly
	}
	@Test
	public void testGetAndSetMultClaimNumberWithNullValue() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMultClaimNumber(null);

		String multClaimNumber = csppra.getMultClaimNumber();

		assertNull(multClaimNumber); // Ensures that null is handled correctly
	}
	@Test
	public void testGetAndSetMultSubscriberIdWithNullValue() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMultSubscriberId(null);

		String multSubscriberId = csppra.getMultSubscriberId();

		assertNull(multSubscriberId); // Ensures that null is handled correctly
	}
	@Test
	public void testGetAndSetInd835WithNullValue() {
		CSPPRA csppra = new CSPPRA();
		csppra.setInd_835(null);

		String ind835 = csppra.getInd_835();

		assertNull(ind835); // Ensures that null is handled correctly
	}
	@Test
	public void testGetAndSetCheckTraceNumberWithNullValue() {
		CSPPRA csppra = new CSPPRA();
		csppra.setCheckTraceNumber(null);

		String checkTraceNumber = csppra.getCheckTraceNumber();

		assertNull(checkTraceNumber); // Ensures that null is handled correctly
	}
	@Test
	public void testGetAndSetEFTIndWithNullValue() {
		CSPPRA csppra = new CSPPRA();
		csppra.setEFT_Ind(null);

		String eftInd = csppra.getEFT_Ind();

		assertNull(eftInd); // Ensures that null is handled correctly
	}
	@Test
	public void testGetAndSetPrivilegeWithNullValue() {
		CSPPRA csppra = new CSPPRA();
		csppra.setPrivilege(null);

		String privilege = csppra.getPrivilege();

		assertNull(privilege); // Ensures that null is handled correctly
	}
	@Test
	public void testGetAndSetMpinWithNullValue() {
		CSPPRA csppra = new CSPPRA();
		csppra.setMpin(null);

		String mpin = csppra.getMpin();

		assertEquals("", mpin); // Ensures that null is handled correctly and defaults to an empty string
	}
	
	@Test
	public void shouldDeserializeVendorPayIdIntoPaymentNumber() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		String json = "{ \"vendor_pay_id\": \"V12345\" }";
		CSPPRA pojo = mapper.readValue(json, CSPPRA.class);
		assertEquals("V12345", pojo.getPaymentNumber());
	}

}
