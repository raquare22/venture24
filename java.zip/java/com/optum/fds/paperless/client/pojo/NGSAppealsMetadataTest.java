package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

public class NGSAppealsMetadataTest extends AbstractMetadataTestUtil {


    protected static final String PATH_XML_FILE = "files/metadata/NGSAppeals/NGSAppeals.metadata";
    protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/NGSAppeals/NGSAppealsError12.metadata";
    protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/NGSAppeals/NGSAppealsError22.metadata";
    protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/NGSAppeals/NGSAppeals_emailAlertReq_N.metadata";

    @Before
    public void setUp() {

    }

    @Test
    public void testNGSAppealsHappyPath() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "NGSAppeals");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertEquals(0, errors.size());

        assertEquals("X2", (String) convertedMetadata.get("subCategory"));
        assertEquals("Community Plan Appeals and Disputes / Acknowledgement, Notification, and Response", (String) convertedMetadata.get("filePath"));
        assertEquals("2021-01-05T05:59:44.000Z", (String) convertedMetadata.get("createdDate"));

    }

    @Test
    public void testNGSAppealsError12() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "NGSAppeals");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println("convertedMetadata=" + convertedMetadata);
        System.out.println("errors=" + errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(7, errors.size());

        assertEquals("XX", (String) convertedMetadata.get("subCategory"));
        assertEquals("Other Appeals and Disputes / Other", (String) convertedMetadata.get("filePath"));
    }

    @Test
    public void testNGSAppealsError22() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "NGSAppeals");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println("convertedMetadata=" + convertedMetadata);
        System.out.println("errors=" + errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
        assertEquals(9, errors.size());

        assertEquals("X1", (String) convertedMetadata.get("subCategory"));
        assertEquals("Commercial Appeals and Disputes / Acknowledgement, Notification, and Response", (String) convertedMetadata.get("filePath"));
    }


    @Test
    public void testNGSAppealsEmailAlertReqN() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, "NGSAppeals");
        } catch (IOException | JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("X2", (String) convertedMetadata.get("subCategory"));
        assertEquals("Community Plan Appeals and Disputes / Acknowledgement, Notification, and Response", (String) convertedMetadata.get("filePath"));
    }

}
