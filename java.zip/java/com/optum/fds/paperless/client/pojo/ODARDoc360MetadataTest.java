package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.junit.Test;

public class ODARDoc360MetadataTest extends AbstractMetadataTestUtil {

    private static final String CLIENT_NAME = "ODARDoc360";
    
    protected static final String PATH_XML_FILE = "files/metadata/ODARDoc360/ODARDoc360.metadata";
    protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/ODARDoc360/ODARDoc360Error12.metadata";
    protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/ODARDoc360/ODARDoc360Error22.metadata";

    @Test
    public void testODARDoc360HappyPath() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<>();
        
        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        
        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());
    }
    
    @Test
    public void testODARDoc360Error12() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<>();
        
        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        
        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
    }
    
    @Test
    public void testODARDoc360Error22() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<>();
        
        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        
        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertFalse(errors.isEmpty());
    }

    @Test
    public void testDoc360FieldsMapToPrunMetadata() {
        Map<String, Object> payload = new HashMap<>();
        payload.put("u_attch_ctl_id", "567890123456");
        payload.put("u_attch_prov_id", "654321098765");
        payload.put("u_batch_id", "N");
        payload.put("u_dcc_nbr", "CLAIMS");
        payload.put("u_div", "ACC123456");
        payload.put("u_document_id", "DOC20260519001");
        payload.put("u_doc_catgy_cd", "JOHN");
        payload.put("u_doc_src_cd", "CHK987654");
        payload.put("u_doc_sub_typ_cd", "OV_LETTER_GRP1");
        payload.put("u_doc_typ_cd", "ICN001234567");
        payload.put("u_email_addr", "ODAR");
        payload.put("u_gbl_doc_id", "OVERPAY_NOTICE");
        payload.put("u_int_chnl", "MAIL");
        payload.put("u_mbr_fst_nm", "CONFIG_OV");
        payload.put("u_mbr_id", "MBR123456");
        payload.put("u_mbr_lst_nm", "DOE");
        payload.put("u_payloc_engine", "PAYLOC_X");
        payload.put("u_pol_grp_nbr", "GRP_OV_001");
        payload.put("u_pol_nbr", "POL123456");
        payload.put("u_received_dt", "2026-05-18T14:30:00.000Z");
        payload.put("u_sa_oi", "SA_CODE");
        payload.put("u_seq_nbr", "001");
        payload.put("u_st", "CA");
        payload.put("u_st_cd", "ACTIVE");
        payload.put("u_queue", "QUEUE_01");
        payload.put("u_srt_typ", "2026-05-19T10:00:00.000Z");

        Class<?> metadataClass = getClassFromClientName(CLIENT_NAME);
        assertNotNull(metadataClass);
        ODARDoc360 metadata = (ODARDoc360) objectMapper.convertValue(payload, metadataClass);

        assertEquals("567890123456", metadata.getTin());
        assertEquals("654321098765", metadata.getMpin());
        assertEquals("N", metadata.getEmailAlertReq());
        assertEquals("CLAIMS", metadata.getMultDivisionCode());
        assertEquals("CA", metadata.getReturnAddress1());
        assertEquals("ACTIVE", metadata.getReturnAddress2());
        assertEquals("QUEUE_01", metadata.getReturnAddress3());
    }

    @Test
    public void testGetAndSetTin() {
        ODARDoc360 doc = new ODARDoc360();
        doc.setTin("567890123456");
        assertEquals("567890123456", doc.getTin());
    }

    @Test
    public void testGetAndSetMpin() {
        ODARDoc360 doc = new ODARDoc360();
        doc.setMpin("654321098765");
        assertEquals("654321098765", doc.getMpin());
    }

    @Test
    public void testGetAndSetEmailAlertReq() {
        ODARDoc360 doc = new ODARDoc360();
        doc.setEmailAlertReq("Y");
        assertEquals("Y", doc.getEmailAlertReq());
    }

    @Test
    public void testGetAndSetCONFIGKEY() {
        ODARDoc360 doc = new ODARDoc360();
        doc.setCONFIGKEY("CONFIG_OV");
        assertEquals("CONFIG_OV", doc.getCONFIGKEY());
    }

    @Test
    public void testGetAndSetOriginalPrintTrail() {
        ODARDoc360 doc = new ODARDoc360();
        doc.setOriginalPrintTrail("MBR123456");
        assertEquals("MBR123456", doc.getOriginalPrintTrail());
    }

    @Test
    public void testGetAndSetPassThruData() {
        ODARDoc360 doc = new ODARDoc360();
        doc.setPassThruData("DOE");
        assertEquals("DOE", doc.getPassThruData());
    }

    @Test
    public void testGetAndSetMailToAddress1() {
        ODARDoc360 doc = new ODARDoc360();
        doc.setMailToAddress1("PAYLOC_X");
        assertEquals("PAYLOC_X", doc.getMailToAddress1());
    }

    @Test
    public void testGetAndSetMailToAddress2() {
        ODARDoc360 doc = new ODARDoc360();
        doc.setMailToAddress2("GRP_OV_001");
        assertEquals("GRP_OV_001", doc.getMailToAddress2());
    }

    @Test
    public void testGetAndSetMailToAddress4() {
        ODARDoc360 doc = new ODARDoc360();
        doc.setMailToAddress4("2026-05-18T14:30:00.000Z");
        assertEquals("2026-05-18T14:30:00.000Z", doc.getMailToAddress4());
    }

    @Test
    public void testGetAndSetReturnAddress1() {
        ODARDoc360 doc = new ODARDoc360();
        doc.setReturnAddress1("CA");
        assertEquals("CA", doc.getReturnAddress1());
    }

    @Test
    public void testGetAndSetReturnAddress2() {
        ODARDoc360 doc = new ODARDoc360();
        doc.setReturnAddress2("ACTIVE");
        assertEquals("ACTIVE", doc.getReturnAddress2());
    }

    @Test
    public void testGetAndSetReturnAddress3() {
        ODARDoc360 doc = new ODARDoc360();
        doc.setReturnAddress3("QUEUE_01");
        assertEquals("QUEUE_01", doc.getReturnAddress3());
    }
}
