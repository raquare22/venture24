package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

public class UNETMetadataTest extends AbstractMetadataTestUtil {

	protected static final String PATH_XML_FILE = "files/metadata/UNET/UNET.metadata";
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/UNET/UNETError12.metadata";
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/UNET/UNETError22.metadata";
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/UNET/UNET_emailAlertReq_N.metadata";
	
	@Test
	public void testUNETHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		String testDate = null;
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNET");
			SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			 isoFormat.setTimeZone(TimeZone.getTimeZone("EST"));
			 Date date = isoFormat.parse((String)convertedMetadata.get("dateOfService")); // 11292017
				testDate = isoFormat.format(date);
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("C5", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial Overpayment Letters/Overpayment Identified", (String) convertedMetadata.get("filePath"));
		assertEquals("2021-03-05T00:34:28.000Z", (String) convertedMetadata.get("createdDate"));
		assertEquals(testDate, (String) convertedMetadata.get("dateOfService"));
		assertEquals("591113901", (String) convertedMetadata.get("tin"));
		assertEquals("00007", (String) convertedMetadata.get("tinSuff"));
		assertEquals("000730063", (String) convertedMetadata.get("mpin"));
	}
	
	@Test
	public void testUNETError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNET");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(8, errors.size());

		assertNull(convertedMetadata.get("dateOfService"));
		assertEquals("CC", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Other", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testUNETError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNET");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(8, errors.size());
		
		assertEquals("C6", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Claim Reconsideration", (String) convertedMetadata.get("filePath"));
	}
	
	
	@Test
	public void testUNETEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNET");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
	}
	@Test
	public void testGetAndSetProviderName() {
		UNET unet = new UNET();
		unet.setProviderName("Dr. Smith");

		String providerName = unet.getProviderName();

		assertEquals("Dr. Smith", providerName);
	}
	@Test
	public void testGetAndSetPatientDOB() {
		UNET unet = new UNET();
		unet.setPatientDOB("01/01/1990");

		String patientDOB = unet.getPatientDOB();

		assertEquals("01/01/1990", patientDOB);
	}
	@Test
	public void testGetAndSetPolicyNumber() {
		UNET unet = new UNET();
		unet.setPolicyNumber("POL12345");

		String policyNumber = unet.getPolicyNumber();

		assertEquals("POL12345", policyNumber);
	}
	@Test
	public void testGetAndSetMemberAltID() {
		UNET unet = new UNET();
		unet.setMemberAltID("ALT12345");

		String memberAltID = unet.getMemberAltID();

		assertEquals("ALT12345", memberAltID);
	}
	@Test
	public void testGetAndSetPatientName() {
		UNET unet = new UNET();
		unet.setPatientName("John Doe");

		String patientName = unet.getPatientName();

		assertEquals("John Doe", patientName);
	}
	@Test
	public void testGetAndSetTinSuff() {
		UNET unet = new UNET();
		unet.setTinSuff("123");

		String tinSuff = unet.getTinSuff();

		assertEquals("123", tinSuff);
	}
	@Test
	public void testGetAndSetMemberId() {
		UNET unet = new UNET();
		unet.setMemberId("MEM12345");

		String memberId = unet.getMemberId();

		assertEquals("MEM12345", memberId);
	}
	@Test
	public void testGetAndSetMailToAddress1() {
		UNET unet = new UNET();
		unet.setMailToAddress1("123 Main St");

		String mailToAddress1 = unet.getMailToAddress1();

		assertEquals("123 Main St", mailToAddress1);
	}
	@Test
	public void testGetAndSetMailToAddress2() {
		UNET unet = new UNET();
		unet.setMailToAddress2("456 Elm St");

		String mailToAddress2 = unet.getMailToAddress2();

		assertEquals("456 Elm St", mailToAddress2);
	}
	@Test
	public void testGetAndSetMailToAddress3() {
		UNET unet = new UNET();
		unet.setMailToAddress3("789 Pine St");

		String mailToAddress3 = unet.getMailToAddress3();

		assertEquals("789 Pine St", mailToAddress3);
	}
	@Test
	public void testGetAndSetMailToAddress4() {
		UNET unet = new UNET();
		unet.setMailToAddress4("101 Oak St");

		String mailToAddress4 = unet.getMailToAddress4();

		assertEquals("101 Oak St", mailToAddress4);
	}
	@Test
	public void testGetAndSetMailToAddress5() {
		UNET unet = new UNET();
		unet.setMailToAddress5("202 Maple St");

		String mailToAddress5 = unet.getMailToAddress5();

		assertEquals("202 Maple St", mailToAddress5);
	}
	@Test
	public void testGetAndSetMailToAddress6() {
		UNET unet = new UNET();
		unet.setMailToAddress6("303 Birch St");

		String mailToAddress6 = unet.getMailToAddress6();

		assertEquals("303 Birch St", mailToAddress6);
	}
	@Test
	public void testGetAndSetOriginalPrintTrail() {
		UNET unet = new UNET();
		unet.setOriginalPrintTrail("Trail123");

		String originalPrintTrail = unet.getOriginalPrintTrail();

		assertEquals("Trail123", originalPrintTrail);
	}
	@Test
	public void testGetAndSetPassThruData() {
		UNET unet = new UNET();
		unet.setPassThruData("Data123");

		String passThruData = unet.getPassThruData();

		assertEquals("Data123", passThruData);
	}
	@Test
	public void testGetAndSetCONFIGKEY() {
		UNET unet = new UNET();
		unet.setCONFIGKEY("Config123");

		String configKey = unet.getCONFIGKEY();

		assertEquals("Config123", configKey);
	}
	@Test
	public void testGetAndSetELGSLETTERGENID() {
		UNET unet = new UNET();
		unet.setELGSLETTERGENID("GEN123");

		String elgsLetterGenId = unet.getELGSLETTERGENID();

		assertEquals("GEN123", elgsLetterGenId);
	}
	@Test
	public void testGetAndSetDefaultUsed() {
		UNET unet = new UNET();
		unet.setDefaultUsed("Default123");

		String defaultUsed = unet.getDefaultUsed();

		assertEquals("Default123", defaultUsed);
	}
	@Test
	public void testGetAndSetLetterHistoryID() {
		UNET unet = new UNET();
		unet.setLetterHistoryID("History123");

		String letterHistoryID = unet.getLetterHistoryID();

		assertEquals("History123", letterHistoryID);
	}
	@Test
	public void testGetAndSetTin() {
		UNET unet = new UNET();
		unet.setTin("123456789");

		String tin = unet.getTin();

		assertEquals("123456789", tin);
	}
	@Test
	public void testGetAndSetProviderId() {
		UNET unet = new UNET();
		unet.setProviderId("Provider123");

		String providerId = unet.getProviderId();

		assertEquals("Provider123", providerId);
	}
	@Test
	public void testGetAndSetSubCategory() {
		UNET unet = new UNET();
		unet.setSubCategory("C1");

		String subCategory = unet.getSubCategory();

		assertEquals("C1", subCategory);
	}

}
