package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

public class PECOSMOSPRAMetadataTest extends AbstractMetadataTestUtil {
    // emailAlertReq = Y, EFT_Ind = N
    protected static final String PATH_XML_FILE = "files/metadata/PECOSMOSPRA/PECOSMOSPRA.metadata";

    // emailAlertReq = null, EFT_Ind = N
    protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/PECOSMOSPRA/PECOSMOSPRAError12.metadata";

    protected static final String CLIENT_NAME = "PECOSMOSPRA";

    @Test
    public void testPECOSMOSPRAHappyPath() {
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<String, Object>();

        try {
            convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
        } catch (IOException | JSONException e) {
            System.out.println("Getting exception to process the PECOSMOSPRA HappyPath:"+ ExceptionUtils.getStackTrace(e));
        }

        System.out.println(convertedMetadata);
        System.out.println(errors);
        assertFalse(convertedMetadata.isEmpty());
        assertTrue(errors.isEmpty());

        assertEquals("P3", (String) convertedMetadata.get("subCategory"));
        assertEquals("Medicare PRAs/Detail PRA", (String) convertedMetadata.get("filePath"));
        assertEquals("2025-01-28T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));

    }


    @Test
    public void testPECOSMOSPRAError12() {
        // Load the metadata file for the test
        File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
        Set<String> errors = new HashSet<>();
        Map<String, Object> convertedMetadata = new HashMap<>();

        try {
            // Convert and validate the metadata
            convertedMetadata = convertAndValidateMetadata(file, errors, CLIENT_NAME);
        } catch (IOException | JSONException e) {
            // Log any exceptions that occur during processing
            System.out.println("Getting exception to process the PECOSMOSPRA Error12: " + ExceptionUtils.getStackTrace(e));
        }

        // Print the converted metadata and errors for debugging
        System.out.println(convertedMetadata);
        System.out.println(errors);

        // Assertions to validate the test case
        assertFalse("Converted metadata should not be empty", convertedMetadata.isEmpty());
        assertFalse("Errors should not be empty", errors.isEmpty());
        assertEquals("Expected 10 errors", 10, errors.size());

        // Ensure specific errors are present
        assertTrue("TIN error should be present", errors.contains("Missing or invalid data: TIN"));
        assertTrue("EFT_Ind error should be present", errors.contains("Missing or invalid data: EFT_Ind(SEVERE)"));
        assertTrue("ProviderMPIN error should be present", errors.contains("Missing or invalid data: ProviderMPIN"));
        assertTrue("isPrintSuppressed error should be present", errors.contains("Missing or invalid data: isPrintSuppressed"));
        //assertTrue("SubCategory error should be present", errors.contains("Missing or invalid data: SubCategory"));
        assertTrue("MailToAddress1 error should be present", errors.contains("Missing or invalid data: MailToAddress1(SEVERE)"));
        assertTrue("MailToAddress2 error should be present", errors.contains("Missing or invalid data: MailToAddress2(SEVERE)"));
        assertTrue("MailToAddress4 error should be present", errors.contains("Missing or invalid data: MailToAddress4(SEVERE)"));
        assertTrue("PassThruData error should be present", errors.contains("Missing or invalid data: PassThruData(SEVERE)"));
        assertTrue("originalPrintTrail error should be present", errors.contains("Missing or invalid data: originalPrintTrail(SEVERE)"));

        // Validate specific metadata fields
        assertEquals("createApplication should be 'CDC'", "CDC", convertedMetadata.get("createApplication"));
        assertEquals("subCategory should be 'InvalidValue'", "InvalidValue", convertedMetadata.get("subCategory"));
        assertEquals("filePath should be 'Other PRAs/Other'", "Other PRAs/Other", convertedMetadata.get("filePath"));
    }

    @Test
    public void testGetPatientAcountNumber() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setPatientAcountNumber("PAT12345");

        String patientAccountNumber = pecosmospra.getPatientAcountNumber();

        assertEquals("PAT12345", patientAccountNumber);
    }
    @Test
    public void testGetCheckTraceNumber() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setCheckTraceNumber("CHK12345");

        String checkTraceNumber = pecosmospra.getCheckTraceNumber();

        assertEquals("CHK12345", checkTraceNumber);
    }
    @Test
    public void testGetEFT_Ind() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setEFT_Ind("Y");

        String eftInd = pecosmospra.getEFT_Ind();

        assertEquals("Y", eftInd);
    }
    @Test
    public void testGetMailToAddress2() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setMailToAddress2("456 Oak St");

        String mailToAddress2 = pecosmospra.getMailToAddress2();

        assertEquals("456 Oak St", mailToAddress2);
    }
    @Test
    public void testGetMailToAddress3() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setMailToAddress3("789 Pine St");

        String mailToAddress3 = pecosmospra.getMailToAddress3();

        assertEquals("789 Pine St", mailToAddress3);
    }
    @Test
    public void testGetMailToAddress4() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setMailToAddress4("101 Birch St");

        String mailToAddress4 = pecosmospra.getMailToAddress4();

        assertEquals("101 Birch St", mailToAddress4);
    }
    @Test
    public void testGetMailToAddress5() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setMailToAddress5("202 Elm St");

        String mailToAddress5 = pecosmospra.getMailToAddress5();

        assertEquals("202 Elm St", mailToAddress5);
    }
    @Test
    public void testGetInd_835() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setInd_835("Y");

        String ind835 = pecosmospra.getInd_835();

        assertEquals("Y", ind835);
    }
    @Test
    public void testGetDIV() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setDIV("DIV123");

        String div = pecosmospra.getDIV();

        assertEquals("DIV123", div);
    }
    @Test
    public void testGetDefaultUsed() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setDefaultUsed("Yes");

        String defaultUsed = pecosmospra.getDefaultUsed();

        assertEquals("Yes", defaultUsed);
    }
    @Test
    public void testGetCheckAmt() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setCheckAmt("500.00");

        String checkAmt = pecosmospra.getCheckAmt();

        assertEquals("500.00", checkAmt);
    }
    @Test
    public void testGetMailToAddress6() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setMailToAddress6("303 Cedar St");

        String mailToAddress6 = pecosmospra.getMailToAddress6();

        assertEquals("303 Cedar St", mailToAddress6);
    }
    @Test
    public void testGetNpi() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setNpi("NPI12345");

        String npi = pecosmospra.getNpi();

        assertEquals("NPI12345", npi);
    }
    @Test
    public void testGetMultMemberId() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setMultMemberId("MEMBER123");

        String multMemberId = pecosmospra.getMultMemberId();

        assertEquals("MEMBER123", multMemberId);
    }
    @Test
    public void testGetMailToAddress1() {
        PECOSMOSPRA pecosmospra = new PECOSMOSPRA();
        pecosmospra.setMailToAddress1("123 Main St");

        String mailToAddress1 = pecosmospra.getMailToAddress1();

        assertEquals("123 Main St", mailToAddress1);
    }

}
