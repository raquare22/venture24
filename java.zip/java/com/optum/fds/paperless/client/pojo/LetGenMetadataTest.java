package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;

public class LetGenMetadataTest extends AbstractMetadataTestUtil {

	protected static final String PATH_XML_FILE = "files/metadata/LetGen/LetGen.metadata";
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/LetGen/LetGenError12.metadata";
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/LetGen/LetGenError22.metadata";
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/LetGen/LetGen_emailAlertReq_N.metadata";
	
	protected static final String PATH_XML_FILE_TEST = "files/metadata/LetGen/LetGenTest.metadata";
	protected static final String PATH_XML_FILE_AMP = "files/metadata/LetGen/LetGenAmp.metadata";
	
	@Test
	public void testLetGenHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		 String testDate = null;
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "LetGen");
			SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			 isoFormat.setTimeZone(TimeZone.getTimeZone("EST"));
			Date date = isoFormat.parse((String) convertedMetadata.get("dateOfService")); // 11292017
			testDate = isoFormat.format(date);
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("2018-05-17T00:00:00.000Z", (String) convertedMetadata.get("createdDate"));
		assertEquals(testDate, (String) convertedMetadata.get("dateOfService")); // "2017-11-28T19:00:00.000Z
		assertEquals("R1", (String) convertedMetadata.get("subCategory"));
//		assertEquals("Medicare/Action Required", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testLetGenError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "LetGen");
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(9, errors.size());

		assertEquals("RR", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Other", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testLetGenBlankSpaceMetadata() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_TEST).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "LetGen");
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(2, errors.size());

		assertEquals("R1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Action Required", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testLetGenAmp() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_AMP).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "LetGen");
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("R2", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Claim Reconsideration Upheld", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testLetGenError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "LetGen");
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(8, errors.size());

		assertEquals("RR", (String) convertedMetadata.get("subCategory"));
		assertEquals("Medicare/Other", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testLetGenEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "LetGen");
		} catch (IOException | JSONException e) {
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
	}

	@Test
	public void testLetGenSubcategories() {
		LetGen letGenObj = new LetGen();
		for (LetGen.Subcategory subcategory : LetGen.Subcategory.values()) {
			letGenObj.setSubCategory(subcategory.getSubCat());
			assertEquals(subcategory.getSubCat(), letGenObj.getSubCategory());
			assertEquals(subcategory.getFilePath(), letGenObj.getFilePath());
		}
	}

	@Test
	public void testLetGenSubcategoryFilePath() {
		LetGen letGenObj = new LetGen();
		String[] subCategories = {"R1", "R2", "R3", "R4", "R7", "R8", "R9", "R0", "RR"};
		for (String subCategory : subCategories) {
			letGenObj.setSubCategory(subCategory);
			String expectedFilePath = LetGen.Subcategory.valueOf(subCategory).getFilePath();
			assertEquals(expectedFilePath, letGenObj.getFilePath());
		}
	}

	@Test  
	public void testSetSubCategoryWithNull() {
		LetGen letGenObj = new LetGen();
		letGenObj.setSubCategory(null);
		assertEquals("RR", letGenObj.getSubCategory());
		assertEquals("Medicare/Other", letGenObj.getFilePath());
	}
	
	@Test  
	public void testSetSubCategoryWithEmptyString() {
		LetGen letGenObj = new LetGen();
		letGenObj.setSubCategory("");
		assertEquals("RR", letGenObj.getSubCategory());
		assertEquals("Medicare/Other", letGenObj.getFilePath());
	}

}
