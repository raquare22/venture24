package com.optum.fds.paperless.client.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UNETPRAMetadataTest extends AbstractMetadataTestUtil {
	
	// emailAlertReq Y, EFT_ind N
	protected static final String PATH_XML_FILE = "files/metadata/UNETPRA/UNETPRA.metadata";
	// emailAlertReq Y, EFT_ind N
	protected static final String PATH_XML_FILE_ERROR_12 = "files/metadata/UNETPRA/UNETPRAError12.metadata";
	// emailAlertReq Y, EFT_ind N
	protected static final String PATH_XML_FILE_ERROR_22 = "files/metadata/UNETPRA/UNETPRAError22.metadata";
	// emailAlertReq N, EFT_ind Y
	protected static final String PATH_XML_FILE_emailAlertReq_N = "files/metadata/UNETPRA/UNETPRA_emailAlertReq_N.metadata";
	// emailAlertReq N, EFT_ind Y
	protected static final String PATH_XML_FILE_emailAlertReq_N_EFT_ind_Y = "files/metadata/UNETPRA/UNETPRA_emailAlertReq_N_EFT_ind_Y.metadata";	
	// emailAlertReq Y, EFT_ind Y
	protected static final String PATH_XML_FILE_emailAlertReq_Y_EFT_ind_Y = "files/metadata/UNETPRA/UNETPRA_emailAlertReq_Y_EFT_ind_Y.metadata";
	// emailAlertReq N, EFT_ind N
	protected static final String PATH_XML_FILE_emailAlertReq_N_EFT_ind_N = "files/metadata/UNETPRA/UNETPRA_emailAlertReq_N_EFT_ind_N.metadata";
	// emailAlertReq N, EFT_ind null
	protected static final String PATH_XML_FILE_emailAlertReq_N_EFT_ind_null = "files/metadata/UNETPRA/UNETPRA_emailAlertReq_N_EFT_ind_null.metadata";
	// emailAlertReq Y, EFT_ind null
	protected static final String PATH_XML_FILE_emailAlertReq_Y_EFT_ind_null = "files/metadata/UNETPRA/UNETPRA_emailAlertReq_Y_EFT_ind_null.metadata";

	
	@Test
	public void testUNETPRAHappyPath() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNETPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("P1", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Detailed PRAs", (String) convertedMetadata.get("filePath"));
		assertEquals("2021-03-19T22:18:51.000Z", (String) convertedMetadata.get("createdDate"));
		assertEquals("1234567890", (String) convertedMetadata.get("NPI"));
		
	}
	
	@Test
	public void testUNETPRAError12() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_12).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNETPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(7, errors.size());

		assertTrue(errors.contains("Missing or invalid data: ProviderTAXID"));
		
		assertEquals("PR", (String) convertedMetadata.get("subCategory"));
		assertEquals("Other PRAs/Other", (String) convertedMetadata.get("filePath"));
		assertNull(convertedMetadata.get("NPI"));
	}	
	
	@Test
	public void testUNETPRAError22() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_ERROR_22).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNETPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(5, errors.size());
		
		assertEquals("P2", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Virtual Card Payments and Info Only PRAs", (String) convertedMetadata.get("filePath"));
	}
	
	
	@Test
	public void testUNETPRAEmailAlertReqN() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNETPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertTrue(errors.isEmpty());
		
		assertEquals("P2", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Virtual Card Payments and Info Only PRAs", (String) convertedMetadata.get("filePath"));
		assertEquals("1234567890", (String) convertedMetadata.get("NPI"));
	}
	
	@Test
	public void testUNETPRA_EmailAlertReqN_EFTInd_Y() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N_EFT_ind_Y).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNETPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());

		assertTrue(errors.contains("Missing or invalid data: ProviderTAXID"));
		
		assertEquals("P2", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Virtual Card Payments and Info Only PRAs", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testUNETPRA_EmailAlertReqN_EFTInd_N() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N_EFT_ind_N).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNETPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());

		assertTrue(errors.contains("Missing or invalid data: ProviderTAXID"));
		
		assertEquals("P2", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Virtual Card Payments and Info Only PRAs", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testUNETPRA_EmailAlertReqY_EFTInd_Y() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_Y_EFT_ind_Y).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNETPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(1, errors.size());

		assertTrue(errors.contains("Missing or invalid data: ProviderTAXID(SEVERE)"));
		
		assertEquals("P2", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Virtual Card Payments and Info Only PRAs", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testUNETPRA_EmailAlertReqY_EFTInd_null() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_Y_EFT_ind_null).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNETPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(2, errors.size());

		assertTrue(errors.contains("Missing or invalid data: ProviderTAXID"));
				
		assertEquals("P2", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Virtual Card Payments and Info Only PRAs", (String) convertedMetadata.get("filePath"));
	}
	
	@Test
	public void testUNETPRA_EmailAlertReqN_EFTInd_null() {
		File file = new File(getClass().getClassLoader().getResource(PATH_XML_FILE_emailAlertReq_N_EFT_ind_null).getFile());
		Set<String> errors = new HashSet<>();
		Map<String, Object> convertedMetadata = new HashMap<String, Object>();
		
		try {
			convertedMetadata = convertAndValidateMetadata(file, errors, "UNETPRA");
		} catch (IOException | JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(convertedMetadata);
		System.out.println(errors);
		assertFalse(convertedMetadata.isEmpty());
		assertFalse(errors.isEmpty());
		assertEquals(2, errors.size());

		assertTrue(errors.contains("Missing or invalid data: EFT_Ind(SEVERE)"));
		assertTrue(errors.contains("Missing or invalid data: ProviderTAXID"));
		assertNull(convertedMetadata.get("NPI"));
		assertEquals("P2", (String) convertedMetadata.get("subCategory"));
		assertEquals("Commercial/Virtual Card Payments and Info Only PRAs", (String) convertedMetadata.get("filePath"));
	}
	@Test
	public void testGetMpin() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setMpin("12345");

		String mpin = unetpra.getMpin();

		assertEquals("12345", mpin);
	}
	@Test
	public void testGetTin() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setTin("987654321");

		String tin = unetpra.getTin();

		assertEquals("987654321", tin);
	}
	@Test
	public void testGetEmailAlertReq() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setEmailAlertReq("N");

		String emailAlertReq = unetpra.getEmailAlertReq();

		assertEquals("N", emailAlertReq);
	}
	@Test
	public void testGetPhysicianName() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setPhysicianName("Dr. John Doe");

		String physicianName = unetpra.getPhysicianName();

		assertEquals("Dr. John Doe", physicianName);
	}
	@Test
	public void testGetCheckTraceNumber() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setCheckTraceNumber("TRACE12345");

		String checkTraceNumber = unetpra.getCheckTraceNumber();

		assertEquals("TRACE12345", checkTraceNumber);
	}
	@Test
	public void testGetMultClaimNumber() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setMultClaimNumber("ICN123456");

		String multClaimNumber = unetpra.getMultClaimNumber();

		assertEquals("ICN123456", multClaimNumber);
	}
	@Test
	public void testGetDefaultUsed() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setDefaultUsed("Yes");

		String defaultUsed = unetpra.getDefaultUsed();

		assertEquals("Yes", defaultUsed);
	}
	@Test
	public void testGetCONFIGKEY() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setCONFIGKEY("CONFIG123");

		String configKey = unetpra.getCONFIGKEY();

		assertEquals("CONFIG123", configKey);
	}
	@Test
	public void testGetOriginalPrintTrail() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setOriginalPrintTrail("Trail123");

		String originalPrintTrail = unetpra.getOriginalPrintTrail();

		assertEquals("Trail123", originalPrintTrail);
	}
	@Test
	public void testGetPassThruData() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setPassThruData("Data123");

		String passThruData = unetpra.getPassThruData();

		assertEquals("Data123", passThruData);
	}
	@Test
	public void testGetInd_835() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setInd_835("835_IND_VALUE");

		String ind835 = unetpra.getInd_835();

		assertEquals("835_IND_VALUE", ind835);
	}
	@Test
	public void testGetMailToAddress1() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setMailToAddress1("123 Main St");

		String mailToAddress1 = unetpra.getMailToAddress1();

		assertEquals("123 Main St", mailToAddress1);
	}
	@Test
	public void testGetMailToAddress2() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setMailToAddress2("456 Oak St");

		String mailToAddress2 = unetpra.getMailToAddress2();

		assertEquals("456 Oak St", mailToAddress2);
	}
	@Test
	public void testGetMailToAddress3() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setMailToAddress3("789 Pine St");

		String mailToAddress3 = unetpra.getMailToAddress3();

		assertEquals("789 Pine St", mailToAddress3);
	}
	@Test
	public void testGetMailToAddress4() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setMailToAddress4("404 Willow St");

		String mailToAddress4 = unetpra.getMailToAddress4();

		assertEquals("404 Willow St", mailToAddress4);
	}
	@Test
	public void testGetMailToAddress5() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setMailToAddress5("505 Maple St");

		String mailToAddress5 = unetpra.getMailToAddress5();

		assertEquals("505 Maple St", mailToAddress5);
	}
	@Test
	public void testGetMailToAddress6() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setMailToAddress6("606 Spruce St");

		String mailToAddress6 = unetpra.getMailToAddress6();

		assertEquals("606 Spruce St", mailToAddress6);
	}
	@Test
	public void testGetSubCategory() {
		UNETPRA unetpra = new UNETPRA();
		unetpra.setSubCategory("P1");

		String subCategory = unetpra.getSubCategory();

		assertEquals("P1", subCategory);
	}
	
	@Test
	public void shouldDeserializeVendorPayIdIntoPaymentNumber() throws Exception {
	    ObjectMapper mapper = new ObjectMapper();
	    String json = "{ \"vendor_pay_id\": \"V12345\" }";
	    UNETPRA pojo = mapper.readValue(json, UNETPRA.class);
	    assertEquals("V12345", pojo.getPaymentNumber());
	}

}
