package com.optum.fds.paperless.client;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class ClientJsonTest {

    @Test
    public void testGettersAndSetters() {
        ClientJson clientJson = new ClientJson();

        clientJson.ApplicationID = "App123";
        assertEquals("App123", clientJson.ApplicationID);

        clientJson.Datagroup = "Group1";
        assertEquals("Group1", clientJson.Datagroup);

        clientJson.DocumentClass = "ClassA";
        assertEquals("ClassA", clientJson.DocumentClass);

        clientJson.DocumentType = "TypeX";
        assertEquals("TypeX", clientJson.DocumentType);

        clientJson.FileFormat = "PDF";
        assertEquals("PDF", clientJson.FileFormat);

        Indices indices = new Indices();
        clientJson.Indices = indices;
        assertEquals(indices, clientJson.Indices);
    }
}