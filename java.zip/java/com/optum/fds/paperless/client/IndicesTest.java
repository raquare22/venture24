package com.optum.fds.paperless.client;

import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

public class IndicesTest {
	
	@Test
	public void testGetIndexField()
	{
		List<com.optum.fds.paperless.client.IndexField> list = new ArrayList<IndexField>();
		IndexField ind1 = new IndexField();
		list.add(ind1);
		IndexField ind2 = new IndexField();
		list.add(ind2);
		
		Indices indices = new Indices();
		indices.setIndexField(list);
		assertEquals(list, indices.getIndexField());
	}

}
