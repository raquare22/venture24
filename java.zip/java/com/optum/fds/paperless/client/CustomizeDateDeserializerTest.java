package com.optum.fds.paperless.client;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Date;
import java.util.TimeZone;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CustomizeDateDeserializerTest {

    @Test
    public void testDeserialize() {
        String customDateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'";
        CustomizeDateDeserializer deserializer = new CustomizeDateDeserializer(customDateFormat);

        String jsonDate = "\"2022-03-14T09:30:10Z\"";
        JsonFactory factory = new JsonFactory();
        try {
            JsonParser parser = factory.createParser(jsonDate);
            DeserializationContext ctxt = new ObjectMapper().getDeserializationContext();
            parser.nextToken(); // Need to call this to initialize the parser

            SimpleDateFormat formatter = new SimpleDateFormat(customDateFormat);
            formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date expectedDate = formatter.parse("2022-03-14T09:30:10Z");

            Date actualDate = deserializer.deserialize(parser, ctxt);
            assertEquals(expectedDate, actualDate);
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testDeserializeWithFallbackFormat() {
        String customDateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'";
        CustomizeDateDeserializer deserializer = new CustomizeDateDeserializer(customDateFormat);

        String jsonDate = "\"March 14, 2022\"";
        JsonFactory factory = new JsonFactory();
        try {
            JsonParser parser = factory.createParser(jsonDate);
            DeserializationContext ctxt = new ObjectMapper().getDeserializationContext();
            parser.nextToken(); // Need to call this to initialize the parser

            SimpleDateFormat formatter = new SimpleDateFormat("MMMM dd, yyyy");
            formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date expectedDate = formatter.parse("March 14, 2022");

            Date actualDate = deserializer.deserialize(parser, ctxt);
            assertEquals(expectedDate, actualDate);
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }
}  