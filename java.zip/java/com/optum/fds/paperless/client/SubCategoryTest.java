package com.optum.fds.paperless.client;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class SubCategoryTest {

    @Test
    public void testGetters() {
//        SubCategory subCategory = SubCategory.P3;
//        assertEquals("P3", subCategory.getSubCat());
//        assertEquals("Medicare PRAs/Detail PRA", subCategory.getFilePath());
//
//        subCategory = SubCategory.P4;
//        assertEquals("P4", subCategory.getSubCat());
//        assertEquals("Medicare PRAs/Info Only", subCategory.getFilePath());
//
//        subCategory = SubCategory.P5;
//        assertEquals("P5", subCategory.getSubCat());
//        assertEquals("UHC West Payment Packages/Detailed Pmt Docs", subCategory.getFilePath());
    }
}