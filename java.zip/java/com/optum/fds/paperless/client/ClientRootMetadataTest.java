package com.optum.fds.paperless.client;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class ClientRootMetadataTest {

    @Test
    public void testGettersAndSetters() {
        ClientRootMetadata clientRootMetadata = new ClientRootMetadata();

        ClientMetadata metadata = new ClientMetadata();
        clientRootMetadata.metadata = metadata;
        assertEquals(metadata, clientRootMetadata.metadata);

        clientRootMetadata.applicationID = "App123";
        assertEquals("App123", clientRootMetadata.applicationID);

        clientRootMetadata.datagroup = "Group1";
        assertEquals("Group1", clientRootMetadata.datagroup);

        clientRootMetadata.fileFormat = "PDF";
        assertEquals("PDF", clientRootMetadata.fileFormat);
    }
}