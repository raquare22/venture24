package com.optum.fds.paperless;

import com.optum.fds.paperless.domain.service.ServiceBase;
import com.optum.fds.paperless.util.DocumentUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import javax.sql.DataSource;

import static org.junit.Assert.*;

/**
 * Test class for DataSourceConfig.
 */
@RunWith(MockitoJUnitRunner.class)
public class DataSourceConfigTest {

    @Spy
    @InjectMocks
    private DataSourceConfig dataSourceConfig;

    @Before
    public void setUp() {
        // No setup required as there are no dependencies to mock in DataSourceConfig
    }

    /**
     * Test the getDataSource() method.
     */
    @Test
    public void testGetDataSource() {
        // Act
        DataSource dataSource = dataSourceConfig.getDataSource();

        // Assert
        assertNotNull("DataSource should not be null", dataSource);
        assertTrue("DataSource should be an instance of HikariDataSource",
                dataSource instanceof com.zaxxer.hikari.HikariDataSource);
    }

    /**
     * Test the httpHeaders() method.
     */
    @Test
    public void testHttpHeaders() {
        // Act
        HttpHeaders headers = dataSourceConfig.httpHeaders();

        // Assert
        assertNotNull("HttpHeaders should not be null", headers);
        assertTrue("HttpHeaders should be empty initially", headers.isEmpty());
    }

    /**
     * Test the serviceBase() method.
     */
    @Test
    public void testServiceBase() {
        // Act
        ServiceBase serviceBase = dataSourceConfig.serviceBase();

        // Assert
        assertNotNull("ServiceBase should not be null", serviceBase);
        assertTrue("ServiceBase should be an instance of ServiceBase", serviceBase instanceof ServiceBase);
    }

    /**
     * Test the javaMailSender() method.
     */
    @Test
    public void testJavaMailSender() {
        // Act
        JavaMailSender mailSender = dataSourceConfig.javaMailSender();

        // Assert
        assertNotNull("JavaMailSender should not be null", mailSender);
        assertTrue("JavaMailSender should be an instance of JavaMailSenderImpl",
                mailSender instanceof JavaMailSenderImpl);
    }

    /**
     * Test the getConfigData() method.
     */
    @Test
    public void testGetConfigData() {
        // Act
        ConfigData configData = dataSourceConfig.getConfigData();

        // Assert
        assertNotNull("ConfigData should not be null", configData);
        assertTrue("ConfigData should be an instance of ConfigData", configData instanceof ConfigData);
    }

    /**
     * Test the fdsHelper() method.
     */
    @Test
    public void testFdsHelper() {
        // Act
        FDSHelper fdsHelper = dataSourceConfig.fdsHelper();

        // Assert
        assertNotNull("FDSHelper should not be null", fdsHelper);
        assertTrue("FDSHelper should be an instance of FDSHelper", fdsHelper instanceof FDSHelper);
    }

    /**
     * Test the documentUtil() method.
     */
    @Test
    public void testDocumentUtil() {
        // Act
        DocumentUtil documentUtil = dataSourceConfig.documentUtil();

        // Assert
        assertNotNull("DocumentUtil should not be null", documentUtil);
        assertTrue("DocumentUtil should be an instance of DocumentUtil", documentUtil instanceof DocumentUtil);
    }
}