package com.optum.fds.paperless.domain.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;

import com.optum.fds.paperless.mongo.jobs.ProcessorJob;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;


import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)

public class ProcessorTransactionServiceTest {

	@Mock
    MongoTemplate mongoTemplate;
	
    @InjectMocks
    ProcessorTransactionServiceImpl processorTransactionServiceImpl;
    
    private List<String> findResult;

    
    @Test
    public void testDefaultConstructor() {
        new ProcessorTransactionServiceImpl(); //test default constructor
    }
    
    @UserStory(references = "US32799")
	@RallyTestCase(references = "TC32976")
	@Test
    public void testUpdateProcessorTransactionMetaData() {
        assertNotNull(processorTransactionServiceImpl.updateProcessorTransactionMetaData(new ProcessorTransactionMetadata()));
    }
    
    @UserStory(references = "US32799")
   	@RallyTestCase(references = "TC32976")
   	@Test
    public void testSaveProcessorTransactionMetaData() {
        assertNotNull(processorTransactionServiceImpl.saveProcessorTransactionMetaData(new ProcessorTransactionMetadata()));
    }
    
    @UserStory(references = "US32799")
   	@RallyTestCase(references = "TC32976")
   	@Test
    public void testfindProcessorTransactionMetadataByClientCompanionFileName() {
        ProcessorTransactionMetadata mockProcessorTransactionMetadata = new ProcessorTransactionMetadata();
        List<ProcessorTransactionMetadata> processorTransMetadata=new ArrayList<>();
        mockProcessorTransactionMetadata.setId("abc");
        processorTransMetadata.add(mockProcessorTransactionMetadata);

        Mockito.when(mongoTemplate.find(Mockito.any(Query.class),
                Mockito.eq(ProcessorTransactionMetadata.class),
                Mockito.anyString())).thenReturn( processorTransMetadata);

        ProcessorTransactionMetadata processorTransactionMetaData = processorTransactionServiceImpl.findProcessorTransactionMetadataByClientCompanionFileName("fileName.cmp", "appId33dd11");
        assertNotNull(processorTransactionMetaData);
    }
    
    @UserStory(references = "US32799")
   	@RallyTestCase(references = "TC32976")
   	@Test
	public void testUpdateProcessorExecutionRecordOfProcessorTransactionRecord() {
		ProcessorTransactionMetadata processorTransaction = new ProcessorTransactionMetadata();
		processorTransaction.setStatus(MetaDataStatus.ACTIVE);
		assertNotNull(processorTransactionServiceImpl.updateProcessorExecutionRecordOfProcessorTransactionRecord(processorTransaction, new HashMap<String, Object>(), new ProcessorJob()));
	}
	
    @UserStory(references = "US32799")
   	@RallyTestCase(references = "TC32976")
   	@Test
	public void testGetProcessorTransactionMetaData() throws InvalidExpressionException {
		List<ProcessorTransactionMetadata> mockListProcessorTransactionMetadata = new ArrayList<>();
		ProcessorTransactionMetadata processorTransactionMetadata = new ProcessorTransactionMetadata();
		processorTransactionMetadata.setAppIdentifier("testApp");
		processorTransactionMetadata.setTransactionId("1234");
		mockListProcessorTransactionMetadata.add(processorTransactionMetadata);
		String searchCriteriaJson = "{\"key\" : \"value\"}";
		Criteria searchFilter = new Criteria();

		Mockito.when(
				mongoTemplate.find(Mockito.any(Query.class), Mockito.eq(ProcessorTransactionMetadata.class), Mockito.anyString()))
				.thenReturn(mockListProcessorTransactionMetadata);

		List<ProcessorTransactionMetadata> listProcessorMetaData = processorTransactionServiceImpl
				.getProcessorTransactionMetaData(searchCriteriaJson,searchFilter);
		assertEquals("listProcessorMetaData size", 1, listProcessorMetaData.size());
	}

    @UserStory(references = "US32799")
   	@RallyTestCase(references = "TC32976")
   	@Test
	public void findProcessorTransactionByFileNameTest() { 
		ProcessorTransaction pt= new ProcessorTransaction();
		when(mongoTemplate.findOne(any(Query.class), eq(ProcessorTransaction.class), anyString())).thenReturn(pt);
		ProcessorTransaction result=processorTransactionServiceImpl.findProcessorTransactionByFileName("zipName", 4555);
		assertEquals(pt,result );
	}
    @UserStory(references = "US32799")
   	@RallyTestCase(references = "TC32976")
   	@Test
	public void getProcessorFileTasksForTransactionIdTest() { 
		List<ProcessorFileTask> pt= new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), anyString())).thenReturn(pt);
		List<ProcessorFileTask> result=processorTransactionServiceImpl.getProcessorFileTasksForTransactionId("zipName", "type");
		assertEquals(pt,result );
	}
    @UserStory(references = "US32799")
   	@RallyTestCase(references = "TC32976")
   	@Test 
	public void processorTransactionIdAndServerTypeQueryTest() { 
		Query result=processorTransactionServiceImpl.processorTransactionIdAndServerTypeQuery("test", "test");
		assertNotNull(result);
	}

    @Test
    public void getProcessorTransactionMetaData_shouldThrowInvalidExpressionException_whenFilterIsNull() throws Exception {
        String documentSearchCriteriaJson = "{\"appIdentifier\":\"app\"}";

        InvalidExpressionException exception = assertThrows(
                InvalidExpressionException.class,
                () -> processorTransactionServiceImpl.getProcessorTransactionMetaData(
                        documentSearchCriteriaJson,
                        null
                )
        );

        assertEquals("filter should be logical query expresssion", exception.getMessage());
        verifyNoInteractions(mongoTemplate);
    }

    @Test
    public void getProcessorTransactionMetaData_shouldRethrowException_whenMongoFindFails() throws Exception {
        String documentSearchCriteriaJson = "{\"appIdentifier\":\"app\"}";
        Criteria documentsFilter = Criteria.where("someField").is("someValue");

        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorTransactionMetadata.class), eq("processorTransaction")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                processorTransactionServiceImpl.getProcessorTransactionMetaData(
                        documentSearchCriteriaJson,
                        documentsFilter
                )
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorTransactionMetadata.class), eq("processorTransaction"));
    }

    @Test
    public void findProcessorTransactionMetadataByClientCompanionFileName_shouldRethrowException_whenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(
                any(Query.class),
                eq(ProcessorTransactionMetadata.class),
                eq("processorTransaction")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                processorTransactionServiceImpl.findProcessorTransactionMetadataByClientCompanionFileName(
                        "companion-file.csv",
                        "serverA")
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).find(
                any(Query.class),
                eq(ProcessorTransactionMetadata.class),
                eq("processorTransaction"));
    }

    @Test
    public void findProcessorTransactionByFileName_shouldRethrowException_whenFindOneFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findOne(
                any(Query.class),
                eq(ProcessorTransaction.class),
                eq("processorTransaction")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                processorTransactionServiceImpl.findProcessorTransactionByFileName("test.zip", 123)
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).findOne(
                any(Query.class),
                eq(ProcessorTransaction.class),
                eq("processorTransaction"));
    }

    @Test
    public void getProcessorFileTasksForTransactionId_shouldRethrowException_whenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(
                any(Query.class),
                eq(ProcessorFileTask.class),
                eq("processorTransaction")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                processorTransactionServiceImpl.getProcessorFileTasksForTransactionId("txn-123", "serverA")
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).find(
                any(Query.class),
                eq(ProcessorFileTask.class),
                eq("processorTransaction"));
    }

    @Test
    public void getProcessTransactionInfoByTransactionId_shouldReturnProcessorTransaction_whenFindOneSucceeds() {
        String transactionId = "507f191e810c19729de860ea";
        ProcessorTransaction expected = new ProcessorTransaction();

        when(mongoTemplate.findOne(
                any(Query.class),
                eq(ProcessorTransaction.class),
                eq("processorTransaction")))
                .thenReturn(expected);

        ProcessorTransaction result =
                processorTransactionServiceImpl.getProcessTransactionInfoByTransactionId(transactionId);

        assertNotNull(result);
        assertSame(expected, result);

        verify(mongoTemplate).findOne(
                any(Query.class),
                eq(ProcessorTransaction.class),
                eq("processorTransaction"));
    }

    @Test
    public void getProcessTransactionInfoByTransactionId_shouldRethrowException_whenFindOneFails() {
        String transactionId = "507f191e810c19729de860ea";
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findOne(
                any(Query.class),
                eq(ProcessorTransaction.class),
                eq("processorTransaction")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                processorTransactionServiceImpl.getProcessTransactionInfoByTransactionId(transactionId)
        );

        assertEquals("Simulated database error", actualException.getMessage());

        verify(mongoTemplate).findOne(
                any(Query.class),
                eq(ProcessorTransaction.class),
                eq("processorTransaction"));
    }
}
