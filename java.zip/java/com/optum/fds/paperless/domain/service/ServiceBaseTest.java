package com.optum.fds.paperless.domain.service;


import static org.mockito.Mockito.*;

import com.optum.fds.paperless.model.GenericResponse;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.*;

public class ServiceBaseTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private ServiceBase serviceBase;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testPostFDSRequest() throws Exception {
        String elgsPostUrl = "http://example.com";
        Map<String, String> params = new HashMap<>();
        params.put("key", "value");

        URI uri = new URI(elgsPostUrl);
        HttpEntity<?> requestEntity = new HttpEntity<>(new HttpHeaders());
        ResponseEntity<String> responseEntity = new ResponseEntity<>(HttpStatus.OK);

        when(restTemplate.exchange(any(), any(), any(HttpEntity.class), eq(String.class))).thenReturn(responseEntity);

        boolean result = serviceBase.postFDSRequest(elgsPostUrl, params);
        assertTrue(result);
    }

    @Test
    public void testGetFDSRequest() throws Exception {
        String fdsGetUrl = "http://example.com";
        Map<String, String> params = new HashMap<>();
        params.put("key", "value");

        URI uri = new URI(fdsGetUrl);
        HttpEntity<?> requestEntity = new HttpEntity<>(new HttpHeaders());
        String[] responseBody = {"response"};
        ResponseEntity<String[]> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);

        when(restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(), eq(String[].class))).thenReturn(responseEntity);

        List<String> result = serviceBase.getFDSRequest(fdsGetUrl, params);
        assertNotNull(result);
//        assertEquals(Arrays.asList(responseBody), result);
    }

    @Test
    public void testPostRequestToSvc() throws Exception {
        String apiUrl = "http://example.com";
        String postRequest = "{\"key\":\"value\"}";
        String pathVariable = "path";

        URI uri = new URI(apiUrl + "/" + pathVariable);
        HttpEntity<String> requestEntity = new HttpEntity<>(postRequest, new HttpHeaders());
        GenericResponse responseBody = new GenericResponse("200", "OK", "Success");
        ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);

        when(restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(), eq(GenericResponse.class))).thenReturn(responseEntity);

        ResponseEntity<GenericResponse> result = serviceBase.postRequestToSvc(apiUrl, postRequest, pathVariable);
        assertNotNull(result);
//        assertEquals(responseEntity, result);
    }

    @Test
    public void testPostRequestToSvcException() throws Exception {
        String apiUrl = "http://example.com";
        String postRequest = "{\"key\":\"value\"}";
        String pathVariable = "path";

        HttpClientErrorException exception = HttpClientErrorException.BadRequest.create(HttpStatus.INTERNAL_SERVER_ERROR, null, null, null, null);

        when(restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(), eq(GenericResponse.class))).thenThrow(exception);

        ResponseEntity<GenericResponse> result = serviceBase.postRequestToSvc(apiUrl, postRequest, pathVariable);
        assertNotNull(result);
//        assertEquals(responseEntity, result);
    }

    @Test
    public void testPostFDSRequest_ReturnsFalse_WhenExchangeThrowsException() {
        String elgsPostUrl = "http://example.com";
        Map<String, String> params = new HashMap<>();
        params.put("key", "value");

        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException("service down"));

        boolean result = serviceBase.postFDSRequest(elgsPostUrl, params);

        assertFalse(result);
    }

    @Test
    public void testPostFDSRequest_WithNullParams_UsesBaseUriAndReturnsTrue() {
        String elgsPostUrl = "http://example.com";

        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));

        boolean result = serviceBase.postFDSRequest(elgsPostUrl, null);

        assertTrue(result);
        verify(restTemplate, times(1))
                .exchange(eq(URI.create(elgsPostUrl)), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class));
    }

    @Test
    public void testGetFDSRequest_WithNullParams_UsesBaseUri() {
        String fdsGetUrl = "http://example.com";

        String[] responseBody = {"response"};
        ResponseEntity<String[]> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);

        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(HttpEntity.class), eq(String[].class)))
                .thenReturn(responseEntity);

        List<String> result = serviceBase.getFDSRequest(fdsGetUrl, null);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("response", result.get(0));

        verify(restTemplate, times(1))
                .exchange(eq(URI.create(fdsGetUrl)), eq(HttpMethod.GET), any(HttpEntity.class), eq(String[].class));
    }

    @Test
    public void testGetFDSRequest_WhenExchangeReturnsNull_ReturnsEmptyList() {
        String fdsGetUrl = "http://example.com";
        Map<String, String> params = new HashMap<>();
        params.put("key", "value");

        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(HttpEntity.class), eq(String[].class)))
                .thenReturn(null);

        List<String> result = serviceBase.getFDSRequest(fdsGetUrl, params);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(restTemplate, times(1))
                .exchange(any(URI.class), eq(HttpMethod.GET), any(HttpEntity.class), eq(String[].class));
    }

    @Test
    public void testGetFDSRequest_RetryThenSuccess_ReturnsBody() {
        String fdsGetUrl = "http://example.com";
        Map<String, String> params = new HashMap<>();
        params.put("id", "1");

        ResponseEntity<String[]> first = new ResponseEntity<>(new String[]{"pending"}, HttpStatus.ACCEPTED);
        ResponseEntity<String[]> second = new ResponseEntity<>(new String[]{"done"}, HttpStatus.OK);

        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(HttpEntity.class), eq(String[].class)))
                .thenReturn(first)
                .thenReturn(second);

        serviceBase.numRetries = 2;
        serviceBase.timeToWaitMS = 1L;

        List<String> result = serviceBase.getFDSRequest(fdsGetUrl, params);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("done", result.get(0));
        verify(restTemplate, times(2))
                .exchange(any(URI.class), eq(HttpMethod.GET), any(HttpEntity.class), eq(String[].class));
    }

    @Test
    public void testGetFDSRequest_RetryExhausted_ReturnsEmptyList() {
        String fdsGetUrl = "http://example.com";
        Map<String, String> params = new HashMap<>();
        params.put("id", "1");

        ResponseEntity<String[]> notOk = new ResponseEntity<>(new String[]{"pending"}, HttpStatus.ACCEPTED);

        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(HttpEntity.class), eq(String[].class)))
                .thenReturn(notOk);

        serviceBase.numRetries = 1;
        serviceBase.timeToWaitMS = 1L;

        List<String> result = serviceBase.getFDSRequest(fdsGetUrl, params);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(restTemplate, times(2))
                .exchange(any(URI.class), eq(HttpMethod.GET), any(HttpEntity.class), eq(String[].class));
    }

    @Test
    public void testGetFDSRequest_WhenExchangeThrowsException_ReturnsEmptyList() {
        String fdsGetUrl = "http://example.com";
        Map<String, String> params = new HashMap<>();
        params.put("id", "1");

        when(restTemplate.exchange(any(URI.class), eq(HttpMethod.GET), any(HttpEntity.class), eq(String[].class)))
                .thenThrow(new RuntimeException("service down"));

        List<String> result = serviceBase.getFDSRequest(fdsGetUrl, params);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(restTemplate, times(1))
                .exchange(any(URI.class), eq(HttpMethod.GET), any(HttpEntity.class), eq(String[].class));
    }

    @Test
    public void testGetFDSRequest_RetryInterrupted_ThenSuccess_ReturnsBodyAndClearsInterrupt() {
        String fdsGetUrl = "http://example.com";
        Map<String, String> params = new HashMap<>();
        params.put("id", "1");

        ServiceBase interruptedService = spy(serviceBase);
        interruptedService.numRetries = 1;
        interruptedService.timeToWaitMS = 1L;

        ResponseEntity<String[]> notOk = new ResponseEntity<>(new String[]{"pending"}, HttpStatus.ACCEPTED);
        ResponseEntity<String[]> ok = new ResponseEntity<>(new String[]{"done"}, HttpStatus.OK);

        doReturn(notOk).doReturn(ok).when(interruptedService).getExchange(any(URI.class), any(HttpEntity.class));

        Thread.currentThread().interrupt();
        List<String> result = interruptedService.getFDSRequest(fdsGetUrl, params);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("done", result.get(0));

        assertTrue(Thread.interrupted());

        verify(interruptedService, times(2)).getExchange(any(URI.class), any(HttpEntity.class));
    }

    @Test
    public void testGetStatusCode_WhenResponseEntityNotNull_ReturnsStatusCodeString() {
        ResponseEntity<String[]> responseEntity =
                new ResponseEntity<>(new String[]{"ok"}, HttpStatus.ACCEPTED);

        String result = serviceBase.getStatusCode(responseEntity);

        assertEquals(HttpStatus.ACCEPTED.toString(), result);
    }

    @Test
    public void testGetStatusCode_WhenResponseEntityNull_ReturnsNULL() {
        String result = serviceBase.getStatusCode(null);

        assertEquals("NULL", result);
    }

    @Test
    public void testPostRequestToSvcMultipartForm_PathVariableNull_SuccessReturnsResponse() {
        HttpHeaders testHeaders = new HttpHeaders();
        ReflectionTestUtils.setField(serviceBase, "headers", testHeaders);

        ServiceBase spyService = spy(serviceBase);
        String apiUrl = "http://example.com/upload";
        LinkedMultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
        requestMap.add("file", "data");

        GenericResponse body = new GenericResponse("200", "OK", "Success");
        ResponseEntity<GenericResponse> okResponse = new ResponseEntity<>(body, HttpStatus.OK);

        doReturn(okResponse).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result =
                spyService.postRequestToSvcMultipartForm(apiUrl, requestMap, null);

        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(MediaType.MULTIPART_FORM_DATA, testHeaders.getContentType());
        assertEquals("*/*", testHeaders.getFirst(ServiceBase.HEADER_ACCEPT));

        verify(spyService, times(1))
                .postExchangeGenericResponse(eq(URI.create(apiUrl)), any(HttpEntity.class));
    }

    @Test
    public void testPostRequestToSvcMultipartForm_PathVariableAppendedWithoutTrailingSlash() {
        HttpHeaders testHeaders = new HttpHeaders();
        ReflectionTestUtils.setField(serviceBase, "headers", testHeaders);

        ServiceBase spyService = spy(serviceBase);
        String apiUrl = "http://example.com/upload";
        String pathVariable = "doc123";
        LinkedMultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();

        ResponseEntity<GenericResponse> createdResponse =
                new ResponseEntity<>(new GenericResponse("201", "Created", "done"), HttpStatus.CREATED);

        doReturn(createdResponse).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result =
                spyService.postRequestToSvcMultipartForm(apiUrl, requestMap, pathVariable);

        assertNotNull(result);
        assertEquals(HttpStatus.CREATED, result.getStatusCode());

        verify(spyService, times(1))
                .postExchangeGenericResponse(eq(URI.create("http://example.com/upload/doc123")), any(HttpEntity.class));
    }

    @Test
    public void testPostRequestToSvcMultipartForm_ResponseNull_ReturnsProcessing() {
        HttpHeaders testHeaders = new HttpHeaders();
        ReflectionTestUtils.setField(serviceBase, "headers", testHeaders);

        ServiceBase spyService = spy(serviceBase);
        String apiUrl = "http://example.com/upload/";
        String pathVariable = "doc123";
        LinkedMultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();

        doReturn(null).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result =
                spyService.postRequestToSvcMultipartForm(apiUrl, requestMap, pathVariable);

        assertNotNull(result);
        assertEquals(HttpStatus.PROCESSING, result.getStatusCode());
        assertEquals("102", result.getBody().getStatusCode());
    }

    @Test
    public void testPostRequestToSvcMultipartForm_RetryThenSuccess_ReturnsCreated() {
        HttpHeaders testHeaders = new HttpHeaders();
        ReflectionTestUtils.setField(serviceBase, "headers", testHeaders);

        ServiceBase spyService = spy(serviceBase);
        spyService.numRetries = 2;
        spyService.timeToWaitMS = 1L;

        String apiUrl = "http://example.com/upload";
        LinkedMultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();

        ResponseEntity<GenericResponse> accepted =
                new ResponseEntity<>(new GenericResponse("202", "Accepted", "pending"), HttpStatus.ACCEPTED);
        ResponseEntity<GenericResponse> created =
                new ResponseEntity<>(new GenericResponse("201", "Created", "done"), HttpStatus.CREATED);

        doReturn(accepted).doReturn(created).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result =
                spyService.postRequestToSvcMultipartForm(apiUrl, requestMap, null);

        assertNotNull(result);
        assertEquals(HttpStatus.CREATED, result.getStatusCode());
        verify(spyService, times(2))
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));
    }

    @Test
    public void testPostRequestToSvcMultipartForm_RetryExhausted_ReturnsLastResponse() {
        HttpHeaders testHeaders = new HttpHeaders();
        ReflectionTestUtils.setField(serviceBase, "headers", testHeaders);

        ServiceBase spyService = spy(serviceBase);
        spyService.numRetries = 1;
        spyService.timeToWaitMS = 1L;

        String apiUrl = "http://example.com/upload";
        LinkedMultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();

        ResponseEntity<GenericResponse> accepted =
                new ResponseEntity<>(new GenericResponse("202", "Accepted", "still pending"), HttpStatus.ACCEPTED);

        doReturn(accepted).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result =
                spyService.postRequestToSvcMultipartForm(apiUrl, requestMap, null);

        assertNotNull(result);
        assertEquals(HttpStatus.ACCEPTED, result.getStatusCode());
        verify(spyService, times(2))
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));
    }

    @Test
    public void testPostRequestToSvcMultipartForm_InterruptedDuringRetry_ThenSuccess() {
        HttpHeaders testHeaders = new HttpHeaders();
        ReflectionTestUtils.setField(serviceBase, "headers", testHeaders);

        ServiceBase spyService = spy(serviceBase);
        spyService.numRetries = 1;
        spyService.timeToWaitMS = 1L;

        String apiUrl = "http://example.com/upload";
        LinkedMultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();

        ResponseEntity<GenericResponse> accepted =
                new ResponseEntity<>(new GenericResponse("202", "Accepted", "pending"), HttpStatus.ACCEPTED);
        ResponseEntity<GenericResponse> ok =
                new ResponseEntity<>(new GenericResponse("200", "OK", "done"), HttpStatus.OK);

        doReturn(accepted).doReturn(ok).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        Thread.currentThread().interrupt();
        ResponseEntity<GenericResponse> result =
                spyService.postRequestToSvcMultipartForm(apiUrl, requestMap, null);

        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertTrue(Thread.interrupted());

        verify(spyService, times(2))
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));
    }

    @Test
    public void testPostRequestToSvcMultipartForm_WhenExchangeThrowsException_ReturnsBadRequest() {
        HttpHeaders testHeaders = new HttpHeaders();
        ReflectionTestUtils.setField(serviceBase, "headers", testHeaders);

        ServiceBase spyService = spy(serviceBase);
        String apiUrl = "http://example.com/upload";
        LinkedMultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
        requestMap.add("k", "v");

        doThrow(new RuntimeException("service down")).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result =
                spyService.postRequestToSvcMultipartForm(apiUrl, requestMap, null);

        assertNotNull(result);
        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
        assertEquals("400", result.getBody().getStatusCode());
        assertEquals("Error during service call", result.getBody().getStatusMessage());
        assertEquals("service down", result.getBody().getResponse());
    }

    @Test
    public void testPostRequestToSvcMultipartForm_WhenResponseEntityNull_ReturnsProcessingWithExpectedBody() {
        HttpHeaders testHeaders = new HttpHeaders();
        ReflectionTestUtils.setField(serviceBase, "headers", testHeaders);

        ServiceBase spyService = spy(serviceBase);
        String apiUrl = "http://example.com/upload";
        LinkedMultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
        requestMap.add("file", "data");

        doReturn(null).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result =
                spyService.postRequestToSvcMultipartForm(apiUrl, requestMap, null);

        assertNotNull(result);
        assertEquals(HttpStatus.PROCESSING, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals("102", result.getBody().getStatusCode());
        assertEquals("Error during service call", result.getBody().getStatusMessage());
        assertEquals("responseEntity == null", result.getBody().getResponse());

        verify(spyService, times(1))
                .postExchangeGenericResponse(eq(URI.create(apiUrl)), any(HttpEntity.class));
    }

    @Test
    public void testPostRequestToSvc_RetryThenSuccess_ReturnsCreated() {
        ServiceBase spyService = spy(serviceBase);
        spyService.numRetries = 2;
        spyService.timeToWaitMS = 1L;

        String apiUrl = "http://example.com/resource";
        String postRequest = "{\"k\":\"v\"}";
        String pathVariable = "123";

        ResponseEntity<GenericResponse> accepted =
                new ResponseEntity<>(new GenericResponse("202", "Accepted", "pending"), HttpStatus.ACCEPTED);
        ResponseEntity<GenericResponse> created =
                new ResponseEntity<>(new GenericResponse("201", "Created", "done"), HttpStatus.CREATED);

        doReturn(accepted).doReturn(created).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result = spyService.postRequestToSvc(apiUrl, postRequest, pathVariable);

        assertNotNull(result);
        assertEquals(HttpStatus.CREATED, result.getStatusCode());
        verify(spyService, times(2)).postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));
    }

    @Test
    public void testPostRequestToSvc_RetryExhausted_ReturnsLastNonValidStatus() {
        ServiceBase spyService = spy(serviceBase);
        spyService.numRetries = 1;
        spyService.timeToWaitMS = 1L;

        String apiUrl = "http://example.com/resource";
        String postRequest = "{\"k\":\"v\"}";

        ResponseEntity<GenericResponse> accepted =
                new ResponseEntity<>(new GenericResponse("202", "Accepted", "still pending"), HttpStatus.ACCEPTED);

        doReturn(accepted).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result = spyService.postRequestToSvc(apiUrl, postRequest, null);

        assertNotNull(result);
        assertEquals(HttpStatus.ACCEPTED, result.getStatusCode());
        verify(spyService, times(2)).postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));
    }

    @Test
    public void testPostRequestToSvc_InterruptedDuringRetry_ThenSuccess() {
        ServiceBase spyService = spy(serviceBase);
        spyService.numRetries = 1;
        spyService.timeToWaitMS = 1L;

        String apiUrl = "http://example.com/resource";
        String postRequest = "{\"k\":\"v\"}";

        ResponseEntity<GenericResponse> accepted =
                new ResponseEntity<>(new GenericResponse("202", "Accepted", "pending"), HttpStatus.ACCEPTED);
        ResponseEntity<GenericResponse> ok =
                new ResponseEntity<>(new GenericResponse("200", "OK", "done"), HttpStatus.OK);

        doReturn(accepted).doReturn(ok).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        Thread.currentThread().interrupt();
        ResponseEntity<GenericResponse> result = spyService.postRequestToSvc(apiUrl, postRequest, null);

        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertTrue(Thread.interrupted());
        verify(spyService, times(2)).postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));
    }

    @Test
    public void testPostRequestToSvc_WhenExceptionContainsServiceUnavailable_Returns503() {
        ServiceBase spyService = spy(serviceBase);

        String apiUrl = "http://example.com/resource";
        String postRequest = "{\"k\":\"v\"}";

        doThrow(new RuntimeException("Service Unavailable from downstream")).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result = spyService.postRequestToSvc(apiUrl, postRequest, null);

        assertNotNull(result);
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, result.getStatusCode());
        assertEquals("503", result.getBody().getStatusCode());
    }

    @Test
    public void testPostRequestToSvc_WhenExceptionContainsConnectionRefused_Returns503() {
        ServiceBase spyService = spy(serviceBase);

        String apiUrl = "http://example.com/resource";
        String postRequest = "{\"k\":\"v\"}";

        doThrow(new RuntimeException("Connection refused: connect")).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result = spyService.postRequestToSvc(apiUrl, postRequest, null);

        assertNotNull(result);
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, result.getStatusCode());
        assertEquals("503", result.getBody().getStatusCode());
    }

    @Test
    public void testPostRequestToSvc_WhenExceptionContainsGatewayTimeout_Returns504() {
        ServiceBase spyService = spy(serviceBase);

        String apiUrl = "http://example.com/resource";
        String postRequest = "{\"k\":\"v\"}";

        doThrow(new RuntimeException("Gateway Timeout while calling downstream")).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result = spyService.postRequestToSvc(apiUrl, postRequest, null);

        assertNotNull(result);
        assertEquals(HttpStatus.GATEWAY_TIMEOUT, result.getStatusCode());
        assertEquals("504", result.getBody().getStatusCode());
    }

    @Test
    public void testPostRequestToSvc_WhenExceptionOther_Returns500() {
        ServiceBase spyService = spy(serviceBase);

        String apiUrl = "http://example.com/resource";
        String postRequest = "{\"k\":\"v\"}";

        doThrow(new RuntimeException("unexpected downstream error")).when(spyService)
                .postExchangeGenericResponse(any(URI.class), any(HttpEntity.class));

        ResponseEntity<GenericResponse> result = spyService.postRequestToSvc(apiUrl, postRequest, null);

        assertNotNull(result);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
        assertEquals("500", result.getBody().getStatusCode());
    }
}