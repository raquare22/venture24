package com.optum.fds.paperless.domain.service;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.*;

import com.mongodb.client.result.UpdateResult;
import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.model.MultiPutResponse;
import static org.springframework.data.mongodb.core.query.Query.query;
import static org.springframework.data.mongodb.core.query.Criteria.where;

import com.optum.fds.paperless.workflow.constants.Workflow;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.util.DocumentUtil;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.test.util.ReflectionTestUtils;

@RunWith(MockitoJUnitRunner.class)
public class DocumentMetaDataServiceImplTest {

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private DocumentUtil documentUtil;

    @InjectMocks
    private DocumentMetaDataServiceImpl documentMetaDataService;

    private DocumentMetaData doc;

    private final DocumentMetaDataServiceImpl service = new DocumentMetaDataServiceImpl();

    private static final String DOCUMENT_COLLECTION = "document";

    @Before
    public void setUp() {
        doc = new DocumentMetaData();
        doc.setId("testId");
        doc.setName("testName");
        doc.setAppIdentifier("app");
        doc.setClientId(0);
    }

    @Test
    public void testSaveDocumentMetaData() {
        when(mongoTemplate.insert(any(DocumentMetaData.class), anyString())).thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.saveDocumentMetaData(doc);
        assertNotNull(result);
        assertEquals("testId", result.getId());
    }

    @Test
    public void testSavePDODocumentMetaData() {
        when(mongoTemplate.insert(any(DocumentMetaData.class), anyString())).thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.savePDODocumentMetaData(doc);
        assertNotNull(result);
        assertEquals("testId", result.getId());
    }

//    @Tests
    public void testUpdatePDODocumentMetaData() {
        when(mongoTemplate.findOne(any(Query.class), any(), anyString())).thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.updatePDODocumentMetaData(doc, "testId");
        assertNotNull(result);
        assertEquals("testId", result.getId());
    }

    @Test
    public void testGetPDODocumentById() {
        when(mongoTemplate.findOne(any(Query.class), any(), anyString())).thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.getPDODocumentById("testId");
        assertNotNull(result);
        assertEquals("testId", result.getId());
    }

    @Test
    public void testGetPDODocuments() throws JsonProcessingException {
        List<DocumentMetaData> docList = new ArrayList<>();
        docList.add(doc);
        when(mongoTemplate.find(any(Query.class), any(), anyString())).thenReturn(Collections.singletonList(docList));
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("appIdentifier", "app");
        List<DocumentMetaData> result = documentMetaDataService.getPDODocuments(queryParams);
        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    public void testUpdateDocumentMetaDataStatus() {
        when(mongoTemplate.findOne(any(Query.class), any())).thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.updateDocumentMetaDataStatus("testId", MetaDataStatus.ACTIVE.toString());
        assertNotNull(result);
        assertEquals(MetaDataStatus.ACTIVE.toString(), result.getStatus().toString());
    }

    @Test
    public void testGetDocumentMetaDataByZipFileName_Success() throws Exception {
        String documentSearchCriteriaJson = "{\"key\":\"value\"}";
        Criteria documentsFilter = Criteria.where("someField").is("someValue");
        String zipFileName = "test.zip";
        int spaceId = 8896;

        List<DocumentMetaData> expectedDocs = new ArrayList<>();
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("testId123");
        doc.setSpaceId(spaceId);
        Document metadata = new Document();
        metadata.append("zipFileName", zipFileName);
        doc.setMetadata(metadata);
        expectedDocs.add(doc);

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(expectedDocs);

        List<DocumentMetaData> result = documentMetaDataService.getDocumentMetaDataByZipFileName(
                documentSearchCriteriaJson, documentsFilter, zipFileName, spaceId);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("testId123", result.get(0).getId());
        assertEquals(spaceId, result.get(0).getSpaceId());
        assertEquals(zipFileName, result.get(0).getMetadata().get("zipFileName"));

        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
        verify(mongoTemplate).find(queryCaptor.capture(), eq(DocumentMetaData.class), eq("document"));
        String query = queryCaptor.getValue().toString();
        assertTrue(query.contains("metadata.zipFileName"));
        assertTrue(query.contains("spaceId"));
    }

    @Test(expected = InvalidExpressionException.class)
    public void testGetDocumentMetaDataByZipFileName_NullFilter() throws Exception {
        String documentSearchCriteriaJson = "{\"key\":\"value\"}";
        String zipFileName = "test.zip";
        int spaceId = 8896;

        documentMetaDataService.getDocumentMetaDataByZipFileName(
                documentSearchCriteriaJson, null, zipFileName, spaceId);
    }

    @Test
    public void testGetDocumentMetaDataByZipFileName_ExceptionHandling() throws Exception {
        String documentSearchCriteriaJson = "{\"key\":\"value\"}";
        Criteria documentsFilter = Criteria.where("someField").is("someValue");
        String zipFileName = "test.zip";
        int spaceId = 8896;

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenThrow(new RuntimeException("Simulated database error"));

        try {
            documentMetaDataService.getDocumentMetaDataByZipFileName(
                    documentSearchCriteriaJson, documentsFilter, zipFileName, spaceId);
            fail("Expected exception was not thrown");
        } catch (Exception e) {
            assertEquals("Simulated database error", e.getMessage());
        }
    }

    @Test
    public void testGetDocumentMetaDataByZipFileName_EmptyResults() throws Exception {
        String documentSearchCriteriaJson = "{\"key\":\"value\"}";
        Criteria documentsFilter = Criteria.where("someField").is("someValue");
        String zipFileName = "nonexistent.zip";
        int spaceId = 8896;

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(Collections.emptyList());

        List<DocumentMetaData> result = documentMetaDataService.getDocumentMetaDataByZipFileName(
                documentSearchCriteriaJson, documentsFilter, zipFileName, spaceId);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testGetDocumentMetaData_ExceptionHandling() throws Exception {
        String documentSearchCriteriaJson = "{\"key\":\"value\"}";
        Criteria documentFilter = Criteria.where("someField").is("someValue");
        Integer countToReturn = 100;

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenThrow(new RuntimeException("Simulated database error"));

        try {
            documentMetaDataService.getDocumentMetaData(documentSearchCriteriaJson, documentFilter, countToReturn);
            fail("Expected exception was not thrown");
        } catch (Exception e) {
            assertEquals("Simulated database error", e.getMessage());
            assertTrue(e instanceof RuntimeException);
        }
    }

    @Test
    public void testGetDocumentMetaDataIds_ExceptionHandling() throws Exception {
        String documentSearchCriteriaJson = "{\"key\":\"value\"}";
        Criteria documentFilter = Criteria.where("someField").is("someValue");
        Criteria uniqueMetadataQuery = Criteria.where("metadataField").is("metadataValue");

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenThrow(new RuntimeException("Simulated database error"));

        try {
            documentMetaDataService.getDocumentMetaDataIds(documentSearchCriteriaJson, documentFilter, uniqueMetadataQuery);
            fail("Expected exception was not thrown");
        } catch (Exception e) {
            assertEquals("Simulated database error", e.getMessage());
            assertTrue(e instanceof RuntimeException);
        }
    }

    @Test
    public void testSaveDocumentMetaDataMulti_Success() {
        List<String> docIdList = Arrays.asList("id1", "id2", "id3");
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("status", MetaDataStatus.ACTIVE);
        updateMap.put("dateModified", new Date());

        UpdateResult mockResult = mock(UpdateResult.class);
        when(mockResult.getModifiedCount()).thenReturn(3L);

        when(mongoTemplate.updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document")))
                .thenReturn(mockResult);

        long result = documentMetaDataService.saveDocumentMetaDataMulti(docIdList, updateMap);

        assertEquals(3L, result);
        verify(mongoTemplate).updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testSaveDocumentMetaDataMulti_Exception() {
        List<String> docIdList = Arrays.asList("id1", "id2", "id3");
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("status", MetaDataStatus.ACTIVE);

        when(mongoTemplate.updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document")))
                .thenThrow(new RuntimeException("Simulated database error"));

        long result = documentMetaDataService.saveDocumentMetaDataMulti(docIdList, updateMap);

        assertEquals(0L, result); // Should return 0 on exception
        verify(mongoTemplate).updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testSaveDocumentMetaDataMulti_EmptyIdList() {
        List<String> docIdList = Collections.emptyList();
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("status", MetaDataStatus.ACTIVE);

        UpdateResult mockResult = mock(UpdateResult.class);
        when(mockResult.getModifiedCount()).thenReturn(0L);

        when(mongoTemplate.updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document")))
                .thenReturn(mockResult);

        long result = documentMetaDataService.saveDocumentMetaDataMulti(docIdList, updateMap);

        assertEquals(0L, result);
        verify(mongoTemplate).updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testSaveDocumentMetaDataMulti_EmptyUpdateMap() {
        List<String> docIdList = Arrays.asList("id1", "id2", "id3");
        Map<String, Object> updateMap = Collections.emptyMap();

        UpdateResult mockResult = mock(UpdateResult.class);
        when(mockResult.getModifiedCount()).thenReturn(0L);

        when(mongoTemplate.updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document")))
                .thenReturn(mockResult);

        long result = documentMetaDataService.saveDocumentMetaDataMulti(docIdList, updateMap);

        assertEquals(0L, result);
        verify(mongoTemplate).updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testSaveDocumentMetaDataMulti_ComplexUpdateMap() {
        List<String> docIdList = Arrays.asList("id1", "id2");
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("status", MetaDataStatus.ACTIVE);
        updateMap.put("dateModified", new Date());
        updateMap.put("metadata.field1", "value1");
        updateMap.put("metadata.nested.field2", 123);

        UpdateResult mockResult = mock(UpdateResult.class);
        when(mockResult.getModifiedCount()).thenReturn(2L);

        ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);
        when(mongoTemplate.updateMulti(any(Query.class), updateCaptor.capture(),
                eq(DocumentMetaData.class), eq("document")))
                .thenReturn(mockResult);

        long result = documentMetaDataService.saveDocumentMetaDataMulti(docIdList, updateMap);

        assertEquals(2L, result);
        Update capturedUpdate = updateCaptor.getValue();
        Document updateObject = capturedUpdate.getUpdateObject();
        assertEquals(4, updateMap.size());
    }

    @Test
    public void testGetDocumentMetaDataList() {
        List<String> ids = Arrays.asList("id1", "id2", "id3");
        List<DocumentMetaData> expectedDocs = new ArrayList<>();
        DocumentMetaData doc1 = new DocumentMetaData();
        doc1.setId("id1");
        DocumentMetaData doc2 = new DocumentMetaData();
        doc2.setId("id2");
        expectedDocs.add(doc1);
        expectedDocs.add(doc2);

        when(mongoTemplate.find(query(where("id").in(ids)), DocumentMetaData.class, "document"))
                .thenReturn(expectedDocs);

        List<DocumentMetaData> result = documentMetaDataService.getDocumentMetaDataList(ids);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("id1", result.get(0).getId());
        assertEquals("id2", result.get(1).getId());
        verify(mongoTemplate, times(1)).find(query(where("id").in(ids)), DocumentMetaData.class, "document");
    }

    @Test
    public void testConvertISOStringToDate_ValidDate() {
        String isoDate = "2023-10-01T12:30:45.123Z";
        Date result = service.convertISOStringToDate(isoDate);
        assertNotNull(result);
    }

    @Test
    public void testConvertISOStringToDate_InvalidDate() {
        String invalidDate = "invalid-date";
        Date result = service.convertISOStringToDate(invalidDate);
        assertNull(result);
    }

    @Test
    public void testConvertISOStringToDate_EmptyString() {
        String emptyDate = "";
        Date result = service.convertISOStringToDate(emptyDate);
        assertNull(result);
    }

    @Test
    public void testConvertISOStringToDate_NullInput() {
        String nullDate = null;
        Date result = service.convertISOStringToDate(nullDate);
        assertNull(result);
    }

    @Test
    public void testConvertISOStringToDate_AnotherValidFormat() {
        String isoDate = "2023-10-01 12:30:45.123Z";
        Date result = service.convertISOStringToDate(isoDate);
        assertNotNull(result);
    }

    @Test
    public void testAddDateConstraintsToQuery_ValidDates() {
        Query query = new Query();
        String startCreationDate = "2023-10-01T00:00:00.000Z";
        String endCreationDate = "2023-10-10T00:00:00.000Z";
        String startModifiedDate = "2023-10-05T00:00:00.000Z";
        String endModifiedDate = "2023-10-15T00:00:00.000Z";

        ReflectionTestUtils.invokeMethod(service, "addDateConstraintsToQuery",query,startCreationDate,endCreationDate,startModifiedDate,endModifiedDate);

        Object criteria = ReflectionTestUtils.invokeMethod(query, "getCriteria");

        System.out.println("Criteria: " + criteria);

        assertNotNull(criteria);
        assertTrue(criteria instanceof List);
        List<?> criteriaList = (List<?>) criteria;
        assertEquals(2, criteriaList.size());
//        assertTrue(criteriaList.get(0).toString().contains("dateCreated"));
//        assertTrue(criteriaList.get(1).toString().contains("dateModified"));
    }

    @Test
    public void testAddDateConstraintsToQuery_EmptyDates() {
        Query query = new Query();
        String startCreationDate = "";
        String endCreationDate = "";
        String startModifiedDate = "";
        String endModifiedDate = "";

        ReflectionTestUtils.invokeMethod(service, "addDateConstraintsToQuery", query, startCreationDate, endCreationDate, startModifiedDate,endModifiedDate);

        Object criteria = ReflectionTestUtils.invokeMethod(query, "getCriteria");

        assertNotNull(criteria);
        assertFalse(criteria.toString().contains("dateCreated"));
        assertFalse(criteria.toString().contains("dateModified"));
    }

    @Test
    public void testAddDateConstraintsToQuery_PartialDates() {
        Query query = new Query();
        String startCreationDate = "2023-10-01T00:00:00.000Z";
        String endCreationDate = null;
        String startModifiedDate = null;
        String endModifiedDate = "2023-10-15T00:00:00.000Z";

        ReflectionTestUtils.invokeMethod(
                service,
                "addDateConstraintsToQuery",
                query,
                startCreationDate,
                endCreationDate,
                startModifiedDate,
                endModifiedDate
        );


        Object criteria = ReflectionTestUtils.invokeMethod(query, "getCriteria");

        System.out.println("Criteria: " + criteria);

        assertNotNull(criteria);
        assertTrue(criteria instanceof List);
        List<?> criteriaList = (List<?>) criteria;
        assertEquals(2, criteriaList.size());
//        assertTrue(criteriaList.get(0).toString().contains("dateCreated"));
//        assertTrue(criteriaList.get(1).toString().contains("dateModified"));
    }

    @Test
    public void testGetGPSDocumentMetaData_Found() {
        DocumentMetaData expected = new DocumentMetaData();
        expected.setId("doc123");
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq(DOCUMENT_COLLECTION)))
                .thenReturn(Collections.singletonList(expected));

        List<DocumentMetaData> result = documentMetaDataService.getGPSDocumentMetaData("key123", 42, 2);

        assertNotNull(result);
    }

    @Test
    public void testGetGPSDocumentMetaData_NotFound() {
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq(DOCUMENT_COLLECTION)))
                .thenReturn(Collections.emptyList());

        List<DocumentMetaData> result = documentMetaDataService.getGPSDocumentMetaData("key123", 42, 2);

        assertEquals(0,result.size());
    }

    @Test
    public void testGetReferralDocumentMetaData_Found() {
        DocumentMetaData expected = new DocumentMetaData();
        expected.setId("doc456");
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class)))
                .thenReturn(Collections.singletonList(expected));

        DocumentMetaData result = documentMetaDataService.getReferralDocumentMetaData("req123", 99, "APPROVED", 7);

        assertNotNull(result);
        assertEquals("doc456", result.getId());
    }

    @Test
    public void testGetReferralDocumentMetaData_NotFound() {
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class)))
                .thenReturn(Collections.emptyList());

        DocumentMetaData result = documentMetaDataService.getReferralDocumentMetaData("req123", 99, "APPROVED", 7);

        assertNull(result);
    }

    @Test
    public void testSaveDocumentMetaData_WhenDocumentExists_SavesAndReturnsSameDocument() {
        DocumentMetaData existingDocument = new DocumentMetaData();
        existingDocument.setId("testId");

        DocumentMetaData inputDoc = new DocumentMetaData();
        inputDoc.setId("testId");
        inputDoc.setName("updatedName");

        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(existingDocument);

        DocumentMetaData result = documentMetaDataService.saveDocumentMetaData(inputDoc);

        assertNotNull(result);
        assertSame(inputDoc, result);

        verify(mongoTemplate).save(inputDoc, "document");
        verify(mongoTemplate, never()).insert(any(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testSavePDODocumentMetaData_WhenDocumentExists_SavesAndReturnsSameDocument() {
        DocumentMetaData existingDoc = new DocumentMetaData();
        existingDoc.setId("testId");

        DocumentMetaData inputDoc = new DocumentMetaData();
        inputDoc.setId("testId");
        inputDoc.setName("updatedName");

        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("PDOdocument")))
                .thenReturn(existingDoc);

        DocumentMetaData result = documentMetaDataService.savePDODocumentMetaData(inputDoc);

        assertNotNull(result);
        assertSame(inputDoc, result);

        verify(mongoTemplate).save(inputDoc, "PDOdocument");
        verify(mongoTemplate, never()).insert(any(DocumentMetaData.class), eq("PDOdocument"));
    }

    @Test
    public void testUpdatePDODocumentMetaData_WhenExistingMetadataIsNull_CopiesIncomingMetadataAndSaves() {
        DocumentMetaData existingDocument = new DocumentMetaData();
        existingDocument.setId("testId");
        existingDocument.setMetadata(null);

        Document incomingMetadata = new Document();
        incomingMetadata.append("key1", "value1");
        incomingMetadata.append("key2", "value2");

        DocumentMetaData inputDoc = new DocumentMetaData();
        inputDoc.setMetadata(incomingMetadata);

        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("PDOdocument")))
                .thenReturn(existingDocument);

        DocumentMetaData result = documentMetaDataService.updatePDODocumentMetaData(inputDoc, "testId");

        assertNotNull(result);
        assertNotNull(result.getMetadata());
        assertEquals("value1", result.getMetadata().get("key1"));
        assertEquals("value2", result.getMetadata().get("key2"));

        verify(mongoTemplate).save(existingDocument, "PDOdocument");
    }

    @Test
    public void testUpdateDocMetaData_WhenExistingMetadataIsNull_CopiesIncomingMetadataAndSaves() {
        DocumentMetaData existingDocument = new DocumentMetaData();
        existingDocument.setId("doc-1");
        existingDocument.setMetadata(null);

        Document incomingMetadata = new Document();
        incomingMetadata.append("field1", "value1");
        incomingMetadata.append("field2", 123);

        DocumentMetaData inputDoc = new DocumentMetaData();
        inputDoc.setMetadata(incomingMetadata);

        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(existingDocument);

        DocumentMetaData result = documentMetaDataService.updateDocMetaData(inputDoc, "doc-1");

        assertNotNull(result);
        assertNotNull(result.getMetadata());
        assertEquals("value1", result.getMetadata().get("field1"));
        assertEquals(123, result.getMetadata().get("field2"));

        verify(mongoTemplate).save(existingDocument, "document");
    }

    @Test
    public void testSaveDocMetaDataWithRevisions_WhenDocAndMetadataPresent_UpdatesAndSavesDocument() {
        DocumentMetaData existingDocument = new DocumentMetaData();
        existingDocument.setId("doc-1");
        existingDocument.setStatus(MetaDataStatus.NEW);

        Document newMetadata = new Document();
        newMetadata.append("key1", "value1");
        newMetadata.append("key2", "value2");

        DocumentMetaData inputDoc = new DocumentMetaData();
        inputDoc.setMetadata(newMetadata);
        inputDoc.setStatus(MetaDataStatus.COMPLETE);

        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(existingDocument);

        DocumentMetaData result = documentMetaDataService.saveDocMetaDataWithRevisions(inputDoc, "doc-1");

        assertNotNull(result);
        assertSame(existingDocument, result);
        assertEquals(newMetadata, result.getMetadata());
        assertEquals(MetaDataStatus.COMPLETE, result.getStatus());

        verify(mongoTemplate).save(existingDocument, "document");
    }

    @Test
    public void testInsertMultiPDODocuments_AppendsDefaultValuesAndInsertsDocuments() {
        List<DocumentMetaData> documentMetaDataList = new ArrayList<>();

        DocumentMetaData first = new DocumentMetaData();
        first.setId("id1");

        DocumentMetaData second = new DocumentMetaData();
        second.setId("id2");

        documentMetaDataList.add(first);
        documentMetaDataList.add(second);

        when(mongoTemplate.insert(documentMetaDataList, "PDOdocument"))
                .thenReturn(documentMetaDataList);

        List<DocumentMetaData> result = documentMetaDataService.insertMultiPDODocuments(documentMetaDataList);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertSame(documentMetaDataList, result);

        verify(documentUtil).appendDefaultValues(first);
        verify(documentUtil).appendDefaultValues(second);
        verify(mongoTemplate).insert(documentMetaDataList, "PDOdocument");
    }

    @Test
    public void testUpdateMultiPDODocuments_AddsIdToUpdatedList_WhenUpdateReturnsDocument() {
        DocumentMetaDataServiceImpl spyService = Mockito.spy(documentMetaDataService);

        DocumentMetaData requestDocument = new DocumentMetaData();

        DocumentMetaData updatedDoc = new DocumentMetaData();
        updatedDoc.setId("id1");

        doReturn(updatedDoc).when(spyService).updatePDODocumentMetaData(requestDocument, "id1");

        MultiPutResponse response = spyService.updateMultiPDODocuments(List.of("id1"), requestDocument);

        assertNotNull(response);
        assertEquals(1, response.getUpdated().size());
        assertEquals("id1", response.getUpdated().get(0));
        assertTrue(response.getNotUpdated().isEmpty());

        verify(spyService).updatePDODocumentMetaData(requestDocument, "id1");
    }

    @Test
    public void testUpdateMultiPDODocuments_AddsIdToNotUpdatedList_WhenUpdateReturnsNull() {
        DocumentMetaDataServiceImpl spyService = Mockito.spy(documentMetaDataService);

        DocumentMetaData requestDocument = new DocumentMetaData();

        doReturn(null).when(spyService).updatePDODocumentMetaData(requestDocument, "id1");

        MultiPutResponse response = spyService.updateMultiPDODocuments(List.of("id1"), requestDocument);

        assertNotNull(response);
        assertTrue(response.getUpdated().isEmpty());
        assertEquals(1, response.getNotUpdated().size());
        assertEquals("id1", response.getNotUpdated().get(0));

        verify(spyService).updatePDODocumentMetaData(requestDocument, "id1");
    }

    @Test
    public void updateReferralDocumentStatusShouldReturnNullWhenMetadataIsEmpty() {
        DocumentMetaDataServiceImpl service = new DocumentMetaDataServiceImpl();
        service.setMongoTemplate(mongoTemplate);

        Document emptyMetadata = new Document();

        DocumentMetaData result = service.updateReferralDocumentStatus("doc123", emptyMetadata);

        assertNull(result);
        verifyNoInteractions(mongoTemplate);
    }

    @Test
    public void updateReferralDocumentStatusShouldReturnNullWhenDocumentIsNotFound() {
        DocumentMetaDataServiceImpl service = new DocumentMetaDataServiceImpl();
        service.setMongoTemplate(mongoTemplate);

        Document metadata = new Document("referralStatus", "APPROVED");

        when(mongoTemplate.findOne(any(org.springframework.data.mongodb.core.query.Query.class),
                eq(DocumentMetaData.class)))
                .thenReturn(null);

        DocumentMetaData result = service.updateReferralDocumentStatus("doc123", metadata);

        assertNull(result);
        verify(mongoTemplate, times(1))
                .findOne(any(org.springframework.data.mongodb.core.query.Query.class), eq(DocumentMetaData.class));
        verify(mongoTemplate, never()).save(any(DocumentMetaData.class));
    }

    @Test
    public void updateReferralDocumentStatusShouldUpdateMetadataAndSaveWhenDocumentExists() {
        DocumentMetaDataServiceImpl service = new DocumentMetaDataServiceImpl();
        service.setMongoTemplate(mongoTemplate);

        String docId = "doc123";
        Document metadata = new Document("referralStatus", "APPROVED");

        DocumentMetaData existingDoc = new DocumentMetaData();
        existingDoc.setId(docId);

        when(mongoTemplate.findOne(any(org.springframework.data.mongodb.core.query.Query.class),
                eq(DocumentMetaData.class)))
                .thenReturn(existingDoc);

        DocumentMetaData result = service.updateReferralDocumentStatus(docId, metadata);

        assertNotNull(result);
        assertEquals(docId, result.getId());
        assertEquals(metadata, result.getMetadata());
        assertNotNull(result.getDateModified());

        verify(mongoTemplate, times(1))
                .findOne(any(org.springframework.data.mongodb.core.query.Query.class), eq(DocumentMetaData.class));
        verify(mongoTemplate, times(1)).save(existingDoc);
    }

    @Test
    public void getATSDocumentMetaDataShouldReturnFirstMatchingDocument() {
        String caseNum = "CASE-123";
        int spaceId = 10;
        int queryTimeWindow = -7;

        DocumentMetaData expected = new DocumentMetaData();
        expected.setId("doc-1");

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class)))
                .thenReturn(Collections.singletonList(expected));

        DocumentMetaData result =
                documentMetaDataService.getATSDocumentMetaData(caseNum, spaceId, queryTimeWindow);

        assertSame(expected, result);
        verify(mongoTemplate).find(any(Query.class), eq(DocumentMetaData.class));
    }

    @Test
    public void getATSDocumentMetaDataShouldReturnNullWhenNoDocumentExists() {
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class)))
                .thenReturn(Collections.emptyList());

        DocumentMetaData result =
                documentMetaDataService.getATSDocumentMetaData("CASE-123", 10, -7);

        assertNull(result);
        verify(mongoTemplate).find(any(Query.class), eq(DocumentMetaData.class));
    }

    @Test
    public void getDocumentMetaDataListWithPagingNewShouldRethrowExceptionWhenMongoFindFails() {
        DocumentMetaDataServiceImpl service = new DocumentMetaDataServiceImpl();

        MongoTemplate mongoTemplate = org.mockito.Mockito.mock(MongoTemplate.class);
        service.setMongoTemplate(mongoTemplate);

        RuntimeException expectedException = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class)))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                service.getDocumentMetaDataListWithPagingNew(
                        "NEW",
                        java.util.Arrays.asList(100),
                        Criteria.where("appIdentifier").is("test-app"),
                        0,
                        10
                )
        );

        assertEquals("mongo failure", actualException.getMessage());
    }

    @Test
    public void getPDODocumentsShouldRethrowExceptionWhenMongoFindFails() {
        Document criteriaDocument = new Document("providerId", "12345");

        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class),
                eq(com.optum.fds.paperless.workflow.beans.ProviderDocument.class),
                eq("PDOdocument")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                documentMetaDataService.getPDODocuments(criteriaDocument)
        );

        assertEquals("Simulated database error", actualException.getMessage());

        verify(mongoTemplate).find(any(Query.class),
                eq(com.optum.fds.paperless.workflow.beans.ProviderDocument.class),
                eq("PDOdocument"));
    }

    @Test
    public void testInsertMultiDocumentsWithSpaceId_AppendsDefaultsAndInsertsDocuments() {
        int spaceId = 123;

        List<DocumentMetaData> documentMetaDataList = new ArrayList<>();

        DocumentMetaData first = new DocumentMetaData();
        first.setId("id1");

        DocumentMetaData second = new DocumentMetaData();
        second.setId("id2");

        documentMetaDataList.add(first);
        documentMetaDataList.add(second);

        when(mongoTemplate.insert(documentMetaDataList, "document"))
                .thenReturn(documentMetaDataList);

        List<DocumentMetaData> result =
                documentMetaDataService.insertMultiDocumentsWithSpaceId(documentMetaDataList, spaceId);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertSame(documentMetaDataList, result);

        verify(documentUtil).appendDefaultValuesWithSpaceId(first, spaceId);
        verify(documentUtil).appendDefaultValuesWithSpaceId(second, spaceId);
        verify(mongoTemplate).insert(documentMetaDataList, "document");
    }

    @Test
    public void testUpdateMultiDocuments_AddsIdToUpdatedList_WhenUpdateReturnsDocument() {
        DocumentMetaDataServiceImpl spyService = Mockito.spy(documentMetaDataService);

        DocumentMetaData requestDocument = new DocumentMetaData();

        DocumentMetaData updatedDoc = new DocumentMetaData();
        updatedDoc.setId("id1");

        doReturn(updatedDoc).when(spyService).updateDocMetaData(requestDocument, "id1");

        MultiPutResponse response = spyService.updateMultiDocuments(List.of("id1"), requestDocument);

        assertNotNull(response);
        assertEquals(1, response.getUpdated().size());
        assertEquals("id1", response.getUpdated().get(0));
        assertTrue(response.getNotUpdated().isEmpty());

        verify(spyService).updateDocMetaData(requestDocument, "id1");
    }

    @Test
    public void testUpdateMultiDocuments_AddsIdToNotUpdatedList_WhenUpdateReturnsNull() {
        DocumentMetaDataServiceImpl spyService = Mockito.spy(documentMetaDataService);

        DocumentMetaData requestDocument = new DocumentMetaData();

        doReturn(null).when(spyService).updateDocMetaData(requestDocument, "id1");

        MultiPutResponse response = spyService.updateMultiDocuments(List.of("id1"), requestDocument);

        assertNotNull(response);
        assertTrue(response.getUpdated().isEmpty());
        assertEquals(1, response.getNotUpdated().size());
        assertEquals("id1", response.getNotUpdated().get(0));

        verify(spyService).updateDocMetaData(requestDocument, "id1");
    }

    @Test
    public void testUpdateMultiDocument_AddsIdToUpdatedList_WhenPutDocumentMetadataReturnsDocument() {
        DocumentMetaDataServiceImpl spyService = Mockito.spy(documentMetaDataService);

        DocumentMetaData requestDocument = new DocumentMetaData();

        DocumentMetaData updatedDoc = new DocumentMetaData();
        updatedDoc.setId("id1");

        doReturn(updatedDoc).when(spyService).putDocumentMetadata(requestDocument, "id1");

        MultiPutResponse response = spyService.updateMultiDocument(List.of("id1"), requestDocument);

        assertNotNull(response);
        assertEquals(1, response.getUpdated().size());
        assertEquals("id1", response.getUpdated().get(0));
        assertTrue(response.getNotUpdated().isEmpty());

        verify(spyService).putDocumentMetadata(requestDocument, "id1");
    }

    @Test
    public void testUpdateMultiDocument_AddsIdToNotUpdatedList_WhenPutDocumentMetadataReturnsNull() {
        DocumentMetaDataServiceImpl spyService = Mockito.spy(documentMetaDataService);

        DocumentMetaData requestDocument = new DocumentMetaData();

        doReturn(null).when(spyService).putDocumentMetadata(requestDocument, "id1");

        MultiPutResponse response = spyService.updateMultiDocument(List.of("id1"), requestDocument);

        assertNotNull(response);
        assertTrue(response.getUpdated().isEmpty());
        assertEquals(1, response.getNotUpdated().size());
        assertEquals("id1", response.getNotUpdated().get(0));

        verify(spyService).putDocumentMetadata(requestDocument, "id1");
    }

    @Test(expected = InvalidExpressionException.class)
    public void testGetDocumentMetaData_ShouldThrowInvalidExpressionException_WhenFilterIsNull() throws Exception {
        String documentSearchCriteriaJson = "{\"appIdentifier\":\"app\"}";

        documentMetaDataService.getDocumentMetaData(documentSearchCriteriaJson, null);
    }

    @Test
    public void testGetDocumentMetaData_ShouldRethrowException_WhenMongoFindFails() throws Exception {
        String documentSearchCriteriaJson = "{\"appIdentifier\":\"app\"}";
        Criteria documentFilter = Criteria.where("someField").is("someValue");

        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                documentMetaDataService.getDocumentMetaData(documentSearchCriteriaJson, documentFilter)
        );

        assertEquals("Simulated database error", actualException.getMessage());

        verify(mongoTemplate).find(any(Query.class), eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testGetCsvDocumentMetaData_ShouldThrowInvalidExpressionException_WhenFilterIsNull() {
        String documentSearchCriteriaJson = "{\"appIdentifier\":\"app\"}";

        InvalidExpressionException exception = assertThrows(
                InvalidExpressionException.class,
                () -> documentMetaDataService.getCsvDocumentMetaData(documentSearchCriteriaJson, null)
        );

        assertEquals("filter should be logical query expression", exception.getMessage());
    }

    @Test
    public void testGetCsvDocumentMetaData_ShouldRethrowException_WhenMongoFindFails() throws Exception {
        String documentSearchCriteriaJson = "{\"appIdentifier\":\"app\"}";
        Criteria documentFilter = Criteria.where("someField").is("someValue");

        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                documentMetaDataService.getCsvDocumentMetaData(documentSearchCriteriaJson, documentFilter)
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testGetDocumentMetaDataWithCount_ShouldThrowInvalidExpressionException_WhenFilterIsNull() {
        String documentSearchCriteriaJson = "{\"appIdentifier\":\"app\"}";
        Integer countToReturn = 10;

        InvalidExpressionException exception = assertThrows(
                InvalidExpressionException.class,
                () -> documentMetaDataService.getDocumentMetaData(
                        documentSearchCriteriaJson,
                        null,
                        countToReturn
                )
        );

        assertEquals("filter should be logical query expresssion", exception.getMessage());
    }

}