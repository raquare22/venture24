package com.optum.fds.paperless.domain.service;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyInt;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.jobs.ProcessorCoreJob;
import com.optum.fds.paperless.mongo.processors.*;
import com.optum.fds.paperless.util.FileUtil;
import jakarta.ws.rs.NotFoundException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.ProcessorUtil;
import com.optum.fds.paperless.mongo.jobs.RestApiJob;
import com.optum.fds.paperless.util.Parser;
import org.springframework.test.util.ReflectionTestUtils;


@RunWith(MockitoJUnitRunner.class)
public class ProcessorsServiceTest {

	   	@Mock
	    ProcessorFileTaskService processorFileTaskService;
	   	@Mock
	    ProcessorService processorService;
	   	@Mock
	    TransactionService transactionService;
	   	
	   	@Mock ProcessorUtil processorUtil;
	   		   	
	    @InjectMocks
	    ProcessorsServiceImpl processorsService;
	    
	    @InjectMocks
	    ProcessorMetaData processorMetaData; 
	    
	    @InjectMocks
	    ProcessorTransaction processTransaction;
	   
	    @InjectMocks
	    ProcessorMetaData processorMetaData1; 

	    @Mock
	    ProcessorFileTaskServiceImpl processorFileTaskServiceImpl;
	    
	    @Rule
	    public TemporaryFolder temporaryFolder = new TemporaryFolder(); // TemporaryFolder uses deleteOnExit

		@Before
	    public void setUp() throws URISyntaxException, IOException {
			 MockitoAnnotations.initMocks(this);



			 String jsonString = "{\n" +
			            "    \"id\" : \"58ebb69f3004953128f4be0f\",\n" +
			            "    \"end_date\" : \"2020-02-01T12:00:00.000Z\",\n" +
			            "    \"process\" : {\n" +
			            "        \"process_key\" : \"sftpProcess\",\n" +
			            "        \"config\" : {\n" +
			            "            \"auth_type\" : \"oauth2\",\n" +
			            "            \"space_id\" : \"3007\",\n" +
			            "            \"fds_url\" : \"fds_url\",\n" +
			            "            \"fds_client_id\" : \"fds_client_id\",\n" +
			            "            \"fds_client_secret\" : \"fds_client_secret\",\n" +
			            "            \"host_name\" : \"titan.is.covaleo.com\",\n" +
			            "            \"ftp_rootdir\" : \"/home/ecastellanos/fds\",\n" +
			            "            \"username\" : \"user\",\n" +
			            "            \"pw\" : \"password\",\n" +
			            "            \"interval\" : \"1\",\n" +
			            "            \"default_expiry_date\" : \"180\",\n" +
			            "            \"default_category\" : \"Claim\",\n" +
			            "            \"default_provider_id\" : \"ELGS\"\n" +
			            "        }\n" +
			            "    },\n" +
			            "    \"start_date\" : \"2017-02-01T12:00:00.000Z\",\n" +
			            "    \"appIdentifier\" : \"testapp\",\n" +
			            "    \"clientId\" : 1,\n" +
			            "    \"name\" : \"xQ3ytISGIve8uszVjbMXxJ9QxYiQNHGt\",\n" +
			            "    \"status\" : \"IN_PROCESS\",\n" +
			            "    \"version\" : \"1\"\n" +
			            "}";

			 		processorMetaData = Parser.parseJson(jsonString, ProcessorMetaData.class);
			        processorMetaData.setConfigSpaceId(3007);
			        processorMetaData.setPriority(200);

			        jsonString = "{\n" +
				            "    \"id\" : \"58ebb69f3004953128f4be0f\",\n" +
				            "    \"end_date\" : \"2020-02-01T12:00:00.000Z\",\n" +
				            "    \"lastRun\" : \"2017-05-17T12:00:00.000Z\",\n" +
				            "    \"process\" : {\n" +
				            "        \"process_key\" : \"sftpProcess\",\n" +
				            "        \"config\" : {\n" +
				            "            \"auth_type\" : \"oauth2\",\n" +
				            "            \"space_id\" : \"3007\",\n" +
				            "            \"fds_url\" : \"fds_url\",\n" +
				            "            \"fds_client_id\" : \"fds_client_id\",\n" +
				            "            \"fds_client_secret\" : \"fds_client_secret\",\n" +
				            "            \"host_name\" : \"titan.is.covaleo.com\",\n" +
				            "            \"ftp_rootdir\" : \"/home/ecastellanos/fds\",\n" +
				            "            \"username\" : \"user\",\n" +
				            "            \"pw\" : \"password\",\n" +
				            "            \"interval\" : \"1\",\n" +
				            "            \"default_expiry_date\" : \"180\",\n" +
				            "            \"default_category\" : \"Claim\",\n" +
				            "            \"default_provider_id\" : \"ELGS\"\n" +
				            "        }\n" +
				            "    },\n" +
				            "    \"start_date\" : \"2017-02-01T12:00:00.000Z\",\n" +
				            "    \"appIdentifier\" : \"testapp\",\n" +
				            "    \"clientId\" : 1,\n" +
				            "    \"name\" : \"xQ3ytISGIve8uszVjbMXxJ9QxYiQNHGt\",\n" +
				            "    \"status\" : \"IN_PROCESS\",\n" +
				            "    \"version\" : \"1\"\n" +
				            "}";

			        processorMetaData1 = Parser.parseJson(jsonString, ProcessorMetaData.class);
			        processorMetaData1.setConfigSpaceId(3007);

			 jsonString = "{\n" +
			                "    \"id\" : \"590cf39970d0cd004e0a4dd1\",\n" +
			                "    \"appIdentifier\" : \"" + "cleanup" + "\",\n" +
			                "    \"processorRecordType\" : \"processorMapping\",\n" +
			                "    \"mapping\" : [ \n" +
			                "        {\n" +
			                "            \"key\" : \"sftpProcess\",\n" +
			                "            \"newKey\" : \"cleanupFilesCreateACKProcess\",\n" +
			                "            \"required\" : false,\n" +
			                "            \"description\" : \"his is the link between sftpProcess and CleanupFileCreateAck workflows.\"\n" +
			                "        }\n" +
			                "    ]\n" +
			                "}";

			  ProcessorMapping processorMapping = Parser.parseJson(jsonString, ProcessorMapping.class);

			  when(processorService.getProcessorMapping(Mockito.eq("cleanup"), Mockito.anyInt())).thenReturn(processorMapping);
			  
			  try
			  {
				  File file = temporaryFolder.newFile("application.properties");
				  BufferedWriter output = new BufferedWriter(new FileWriter(file));
				  output.write("serverType=ose");
				  output.close();
				  System.setProperty("application.properties",file.getAbsolutePath());
			  }
			  catch (Exception e)
			  {
				  System.out.println(e.getMessage());
			  }
		}

		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testCreateProcessor() throws Exception {

			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			processorServiceImpl.createProcessor(processorMetaData);
		
			ProcessorTransaction processorTransaction = processorServiceImpl.createProcessorTransaction(processorMetaData, "test.zip", "/bconnected/ingest/testapp/3007/591a11aeef86c266481fde97", "591a11aeef86c266481fde97");
			JobMetaData jobMetaData = processorServiceImpl.createProcessorJobEntry(processorTransaction, "jobType", "wrkFlow");
			assertEquals ("jobType", jobMetaData.getJobType());
			assertEquals ("wrkFlow", jobMetaData.getWorkFlow());
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void findAllAvailableProcessorMetaDataTest() { 
			List<ProcessorMetaData> processorMetaData=new ArrayList();
			when(processorService.findAllAvailableProcessorMetaData(any(Date.class), any(Date.class))).thenReturn(processorMetaData);
			List<ProcessorMetaData> result=processorsService.findAllAvailableProcessorMetaData(new Date(), new Date());
			assertNotNull(result);
			assertNotNull(processorMetaData);
			assertEquals(result, processorMetaData);
		}
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void findAllAvailableProcessorMetaData2Test() { 
			List<ProcessorMetaData> processorMetaData=new ArrayList();
			when(processorService.findAllAvailableProcessorMetaData()).thenReturn(processorMetaData);
			List<ProcessorMetaData> result=processorsService.findAllAvailableProcessorMetaData();
			assertNotNull(result);
			assertNotNull(processorMetaData);
			assertEquals(result, processorMetaData);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void findProcessorMetaDataByFileNameTest() { 
			ProcessorMetaData processorMetaData=new ProcessorMetaData();
			when(processorService.findProcessorMetaDataByFileName(anyString(), anyString())).thenReturn(processorMetaData);
			ProcessorMetaData result=processorsService.findProcessorMetaDataByFileName("fileName", "appId");
			assertNotNull(result);
			assertNotNull(processorMetaData);
			assertEquals(result, processorMetaData);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void findProcessorMetaDataByIdTest() { 
			ProcessorMetaData processorMetaData=new ProcessorMetaData();
			when(processorService.findProcessorMetaDataById(anyString(), anyString())).thenReturn(processorMetaData);
			ProcessorMetaData result=processorsService.findProcessorMetaDataById("processorId", "appId");
			assertNotNull(result);
			assertNotNull(processorMetaData);
			assertEquals(result, processorMetaData);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void startProcessorTest() { 
			processorsService.startProcessor("id");
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void shutdownProcessorTest() { 
			processorsService.shutdownProcessor("id");
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void startMultipleProcessorsTest() { 
			ProcessorMetaData pd=new ProcessorMetaData();
			pd.setEndDate(new Date());
			List<ProcessorMetaData>  processorMetaData = new ArrayList();
			processorMetaData.add(pd);
			when(processorService.findAllAvailableProcessorsToStart()).thenReturn(processorMetaData);
			processorsService.startMultipleProcessors();
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void shutdownMultipleProcessorsTest() { 
			ProcessorMetaData pd=new ProcessorMetaData();
			pd.setEndDate(new Date());
			List<ProcessorMetaData>  processorMetaData = new ArrayList();
			processorMetaData.add(pd);
			when(processorService.findAllAvailableProcessorsForShutdown()).thenReturn(processorMetaData);
			processorsService.shutdownMultipleProcessors();
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void findProcessorJobByTransactionIdFromQueueTest() { 
			boolean result=processorsService.findProcessorJobByTransactionIdFromQueue("test");
			assertEquals(result, false);
		}
		
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void findTopOfRestApiJobQueueTest() { 
			JobMetaData jobMetaData=new JobMetaData();
			RestApiJob result=processorsService.findTopOfRestApiJobQueue("test");
			assertEquals(result.getAppIdentifier(), jobMetaData.getAppIdentifier());
		}

		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testGetCleanupworkflow() {
			when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString())).thenReturn(processorMetaData);
			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			processTransaction = processorServiceImpl.createProcessorTransaction(processorMetaData, "test.zip", "/bconnected/ingest/testapp/3007/591a11aeef86c266481fde97", "591a11aeef86c266481fde97");
			assertEquals("cleanupFilesCreateACKProcess", "cleanupFilesCreateACKProcess", processorServiceImpl.getCleanupWorkFlowForProcessorTransaction(processTransaction));
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testGetAllTransactionProcessorsFatalErrorAndReady() {
			List<ProcessorTransaction> lstProcessorTransactionError = new ArrayList<ProcessorTransaction>();
			ProcessorTransaction pr1 = new ProcessorTransaction();
			lstProcessorTransactionError.add(pr1);
			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			List<ProcessorTransaction>  lstTransactionReady = processorServiceImpl.getAllTransactionProcessorsFatalErrorAndReady();
			assertEquals("transaction ready", lstTransactionReady.size(), 0); //<- This is different for size = 0
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testGetAllTransactionProcessorsInProcessAndFatalError() {
			List<ProcessorTransaction> lstProcessorTransaction = new ArrayList<ProcessorTransaction>();
			List<String> MetaDataStatusList = new ArrayList<String>();
			MetaDataStatusList.add(MetaDataStatus.IN_PROCESS.toString());
			MetaDataStatusList.add(MetaDataStatus.FATAL_ERROR.toString());
			
			ProcessorTransaction pr1 = new ProcessorTransaction();
			pr1.setStatus(MetaDataStatus.IN_PROCESS);
			
			ProcessorTransaction pr2 = new ProcessorTransaction();
			pr2.setStatus(MetaDataStatus.FATAL_ERROR);
			
			lstProcessorTransaction.add(pr1);
			lstProcessorTransaction.add(pr2);
			
			when(processorService.getAllProcessorTransactionInStatus(Mockito.any(List.class), Mockito.anyString(), Mockito.anyInt())).thenReturn(lstProcessorTransaction);
			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			List<ProcessorTransaction>  lstTransactions = processorServiceImpl.getAllProcessorTransactionInStatus(MetaDataStatusList, "ose", 0);
			assertEquals("transaction returned", lstTransactions.size(), 2);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testGetAllPendingProcessorTransactions () {
			List<ProcessorTransaction> processorTransactionList = new ArrayList<ProcessorTransaction>();
			
			//when(processorService.getAllPendingProcessorTransactions(anyInt(), anyList(), anyString())).thenReturn(processorTransactionList);
			List<ProcessorTransaction> processorServiceImpl = processorsService.getAllPendingProcessorsTransactions(4);
			assertEquals ("list of processor transactions" , processorServiceImpl.size(), processorTransactionList.size() );
		}
		
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testGetAllPendingProcessorFileTask() {
			List<ProcessorFileTask> ProcessorFileTaskList = new ArrayList<ProcessorFileTask>();	
			int processorTransactionPendingTime = 7200;
			List<ProcessorFileTask> processorServiceImpl = processorsService.getPendingProcessorFileTaskForTransactionId("1", "xaas",processorTransactionPendingTime);
			assertEquals ("list of processor file tasks" , processorServiceImpl.size(), 0 );
		}
		
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testFindAllAvailableProcessorMetaData () {
			List<ProcessorMetaData> processorList = new ArrayList<ProcessorMetaData>();
			ProcessorMetaData processor1 = new ProcessorMetaData();
			processor1.setId("1");
			ProcessorMetaData processor2 = new ProcessorMetaData();
			processor2.setId("2");
			ProcessorMetaData processor3 = new ProcessorMetaData();
			processor3.setId("3");

			processorList.add(processor1);
			processorList.add(processor2);
			processorList.add(processor3);

			when(processorService.findAllAvailableProcessorMetaData(any(Date.class), any(Date.class))).thenReturn(processorList);

			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			List<ProcessorMetaData> prList = processorServiceImpl.findAllAvailableProcessorMetaData(new Date(),new Date ());
			assertEquals ("list of metadatadata" , prList.size(), processorList.size() );
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testUpdateProcessorMetaData() {
			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			 when(processorService.updateProcessorMetaData((ProcessorMetaData)  Mockito.any())).thenReturn(processorMetaData1);
			processorServiceImpl.updateProcessorMetaData(processorMetaData, processorMetaData, "1");
			assertNotNull(processorMetaData);
			assertNotNull(processorMetaData1);

		}

		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testFindProcessorMetaDataByFileName() {
			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			 //when(processorService.updateProcessorMetaData((ProcessorMetaData)  Mockito.any())).thenReturn(processorMetaData1);
			processorServiceImpl.findProcessorMetaDataByFileName("myFileName", "testapp");
			assertNotNull(processorMetaData1);
		}

		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void MultipleTests() {
			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			 when(processorService.updateProcessorMetaData((ProcessorMetaData)  Mockito.any())).thenReturn(processorMetaData1);

			processorServiceImpl.setLastCleanRun("123");
			processorServiceImpl.setLastRunAndStatus("123", MetaDataStatus.IN_PROCESS);
			processorServiceImpl.unlockProcessor(processorMetaData);
			processorServiceImpl.updateProcessorTransactionMetaData(processTransaction);
			processorServiceImpl.updateProcessorMetaData(processorMetaData, processorMetaData, null);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testFindTopOfProcessorJobQueueReturningRestApiJobType () {
			List<ProcessorMetaData> pmd=new ArrayList();
			processorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
			pmd.add(processorMetaData);
			List<String> processorIds = new ArrayList<String>();
			processorIds.add("1234567890");
			JobMetaData job = new JobMetaData();
			job.setId("1");
			job.setServerType("ose");
			job.setServerName("localhost");
			job.setProcessorJobType("processorRestApiJob");

			when(processorService.findTopOfRestApiJobQueueForProcessors(anyString(), anyList())).thenReturn(job);
			when(processorService.findAllAvailableProcessorMetaData()).thenReturn(pmd);
			RestApiJob result = processorsService.findTopOfRestApiJobQueue("localhost");
			assertEquals ("1", result.getJobId());
			assertEquals ("ose", result.getServerType());
			assertEquals ("localhost", result.getServerName());
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testfindTopOfProcessorJobQueueWithProcessJobType() {
			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			List<ProcessorMetaData> pmd=new ArrayList();
			processorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
			pmd.add(processorMetaData);
			List<String> processorIds = new ArrayList<String>();
			processorIds.add("1234567890");
			JobMetaData job = new JobMetaData();
			job.setId("1");
			job.setServerType("ose");
			job.setServerName("localhost");
			job.setProcessorJobType("processorJob");
			job.setTemplateDefinition("testTemplate");
			
			when(processorService.findTopOfProcessorJobQueueForProcessors(anyString(), anyList())).thenReturn(job);
			when(processorService.findAllAvailableProcessorMetaData()).thenReturn(pmd);
			ProcessorCoreJob processorJob = processorServiceImpl.findTopOfProcessorJobQueue("localhost");
			assertNotNull(processorJob);
			assertTrue(processorJob.getJobId().equals("1"));
		}

		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void getTransactionProcessorTest() { 
			ProcessorTransaction processorTransaction=new ProcessorTransaction();
			when(processorService.getProcessorTransaction(anyString(), anyString(), anyString())).thenReturn(processorTransaction);
			ProcessorTransaction result=processorsService.getTransactionProcessor("test", "test", "test");
			assertEquals(processorTransaction, result);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void getAllTransactionProcessorsShutdownTest() { 
			List<ProcessorTransaction> processorTransaction=new ArrayList();
			//when(processorService.getAllProcessorTransactionInStatus(anyString(), anyString())).thenReturn(processorTransaction);
			List<ProcessorTransaction> result=processorsService.getAllTransactionProcessorsShutdown();
			assertEquals(processorTransaction, result);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void getProcessorFileTasksForTransactionIdTest() { 
			List<ProcessorFileTask> processorFileTask=new ArrayList();
			//when(processorFileTaskService.getProcessorFileTasksForTransactionId(anyString(), anyString())).thenReturn(processorFileTask);
			List<ProcessorFileTask> result=processorsService.getProcessorFileTasksForTransactionId("test");
			assertEquals(processorFileTask, result);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void getLastProcessorFileTaskForTransactionIdTest() { 
			List<ProcessorFileTask> processorFileTask=new ArrayList();
			//when(processorFileTaskService.getLastProcessorFileTaskForTransactionId(anyString(), anyString())).thenReturn(processorFileTask);
			List<ProcessorFileTask> result=processorsService.getLastProcessorFileTaskForTransactionId("test");
			assertNotNull(processorFileTask);
			assertNotNull(result);
		}
		

		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testGetProcessor () {
			when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString())).thenReturn(processorMetaData);

			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			ProcessorMetaData pMetadata = processorServiceImpl.getProcessor("testApp", "1");

			assertEquals("get Processor", pMetadata.getId() , "58ebb69f3004953128f4be0f");

			assertEquals("is locked", false, processorServiceImpl.isProcessorLocked(pMetadata));

			processorServiceImpl.lockProcessor(pMetadata);
			pMetadata.setLocked(true);

			assertEquals("is locked", true, processorServiceImpl.isProcessorLocked(pMetadata));

			processorServiceImpl.unlockProcessor(pMetadata);
			pMetadata.setLocked(false);
			assertEquals("is unlocked", false, processorServiceImpl.isProcessorLocked(pMetadata));
			
			assertEquals("is locked", false, processorServiceImpl.isIncompleteProcessorFlagLocked(pMetadata));
			
			processorServiceImpl.lockIncompleteProcessorFlag(pMetadata);
			pMetadata.setResolveIncompleteProcessorTransactionLocked(true);
			assertEquals("is locked", true, processorServiceImpl.isIncompleteProcessorFlagLocked(pMetadata));
			
			processorServiceImpl.unlockIncompleteProcessorFlag(pMetadata);
			pMetadata.setResolveIncompleteProcessorTransactionLocked(false);
			assertEquals("is unlocked", false, processorServiceImpl.isIncompleteProcessorFlagLocked(pMetadata));

			
			pMetadata.setResolveIncompleteProcessorTransactionLastRun(new Date());
			processorServiceImpl.updateProcessorLastRun(pMetadata);
			assertNotNull("is last run null", pMetadata.getResolveIncompleteProcessorTransactionLastRun());

			processorServiceImpl.findAndUpdateJobsByStatusINProcess(MetaDataStatus.FATAL_ERROR.toString(), "csvProcessorJob");
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void getProcessorTransactionByIdTest() { 
			ProcessorTransaction processorTransaction=new ProcessorTransaction();
			when(processorService.getProcessorTransactionById(anyString())).thenReturn(processorTransaction);
			ProcessorTransaction result=processorsService.getProcessorTransactionById("test");
			assertNotNull(result);
			assertNotNull(processorTransaction);
		}

		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testAllProcessorFileTasksCompletedForTransactionId() {
			when(processorFileTaskService.areAllProcessorFileTasksCompletedForTransactionId(anyString())).thenReturn(true);
			assertTrue(processorsService.allProcessorFileTasksCompletedForTransactionId("12313"));
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testDeleteProcessorsMapping() {
			when(processorService.deleteProcessorMapping(Mockito.anyString(), Mockito.anyInt())).thenReturn(new ProcessorMapping());
			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			processorServiceImpl.deleteProcessorMapping("test", 12);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testGetProcessorsMapping() {
			when(processorService.getProcessorMapping(anyString(), Mockito.anyInt())).thenReturn(new ProcessorMapping());
			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			ProcessorMapping mapping = processorServiceImpl.getProcessorMapping("test", 12);
			assertNotNull(mapping);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testCreateProcessorMapping() {
			ProcessorMapping mapping = new ProcessorMapping();
			mapping.setId("1234");
			when(processorService.saveProcessorMapping(any())).thenReturn(mapping);
			ProcessorsServiceImpl processorServiceImpl = new ProcessorsServiceImpl (processorService);
			assertNotNull(processorServiceImpl.createProcessorMapping(mapping));
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testDeleteProcessor() {
			when(processorService.deleteProcessor(anyString(), anyString(), anyInt())).thenReturn(true);
			assertTrue(processorsService.deleteProcessor("processor", "TestProcessor", 2));
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void deleteProcessorMetaDataTest() {
			when(processorService.deleteProcessorMetaData(anyString(), anyString())).thenReturn(true);
			assertTrue(processorsService.deleteProcessorMetaData("processor", "TestProcessor"));
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void getProcessorFileTasksForTransactionIdByStatusTest() { 
			List<ProcessorFileTask> pft=new ArrayList<ProcessorFileTask>();
			ProcessorFileTask pft1=new ProcessorFileTask();
			pft1.setProcessorTransactionId("test");
			pft1.setStatus(MetaDataStatus.OK);
			pft.add(new ProcessorFileTask());
			//when(processorService.getProcessorFileTasksForTransactionIdByStatus(anyString(), anyString())).thenReturn(pft);
			List<ProcessorFileTask> result=new ArrayList();
			result=processorsService.getProcessorFileTasksForTransactionIdByStatus("test", "test");
			assertNotNull(pft);
			assertNotNull(result);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void testgetTransactionProcessorById() {
			String processorTransactionId = "5d28f6de4dca0f005516ab14";
			ProcessorTransaction processorTransaction = new ProcessorTransaction();
			processorTransaction.setId(processorTransactionId);
			when(processorService.getProcessorTransactionById(processorTransactionId)).thenReturn(processorTransaction);
			ProcessorTransaction result = processorsService.getTransactionProcessorById(processorTransactionId);
			assertEquals(processorTransactionId, result.getId());

		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void findAllAvailableProcessorIdsTest() { 
			List<String> hmds=new ArrayList();
			when(processorService.findAllAvailableProcessorIds(any(Date.class), any(Date.class))).thenReturn(hmds);
			List<String> result = processorsService.findAllAvailableProcessorIds(new Date(), new Date());
			assertNotNull(result);
			assertNotNull(hmds);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void retrieveJobIdListTest() { 
		List<String> hmds=new ArrayList();
		when(processorService.retrieveJobIdList(anyInt())).thenReturn(hmds);
		List<String> result = processorService.retrieveJobIdList(9);
		assertNotNull(result);
		assertNotNull(hmds);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void findProcessorTest() { 
			when(processorService.findProcessor(anyString())).thenReturn(processorMetaData);
			ProcessorMetaData result = processorsService.findProcessor("sample");
			assertNotNull(result);
			assertNotNull(processorMetaData);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void findRestApiJobTest() { 
			List<ProcessorMetaData> pmd=new ArrayList();
			processorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
			pmd.add(processorMetaData);
			List<String> processorIds = new ArrayList<String>();
			processorIds.add("1234567890");
			JobMetaData job = new JobMetaData();
			job.setId("1");
			job.setServerType("ose");
			job.setServerName("localhost");
			job.setProcessorJobType("processorRestApiJob");
			when(processorService.findAllAvailableProcessorMetaData()).thenReturn(pmd);
			when(processorService.findProcessorJob(anyString())).thenReturn(job);
			RestApiJob pcj=new RestApiJob();
			pcj=processorsService.findRestApiJob("test");
			assertEquals ("1", pcj.getJobId());
			assertEquals ("ose", pcj.getServerType());
			assertEquals ("localhost", pcj.getServerName());	
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32970")
		@Test
		public void findProcessorCoreJobTest() { 
			List<ProcessorMetaData> pmd=new ArrayList();
			processorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
			pmd.add(processorMetaData);
			List<String> processorIds = new ArrayList<String>();
			processorIds.add("1234567890");
			JobMetaData job = new JobMetaData();
			job.setId("1");
			job.setServerType("ose");
			job.setServerName("localhost");
			job.setProcessorJobType("processorJob");
			when(processorService.findAllAvailableProcessorMetaData()).thenReturn(pmd);
			when(processorService.findProcessorJob(anyString())).thenReturn(job);
			ProcessorCoreJob pcj=new ProcessorCoreJob();
			pcj=processorsService.findProcessorCoreJob("test");
			assertEquals ("1", pcj.getJobId());
			assertEquals ("ose", pcj.getServerType());
			assertEquals ("localhost", pcj.getServerName());	
		}

    @Test
    public void testCreateProcessorFileTaskEntries_ShouldCreateAndSaveProcessorFileTask() {
        ProcessorsServiceImpl spyService =
                Mockito.spy(new ProcessorsServiceImpl(processorService, transactionService, processorFileTaskService));

        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setAppIdentifier("app1");
        processorTransaction.setClientId(101);
        processorTransaction.setConfigSpaceId(202);
        processorTransaction.setProcessorId("processor-123");
        processorTransaction.setId("processor-txn-1");
        processorTransaction.setLocation("C:/input");
        String fileName = "test-file.pdf";

        Transaction transactionMetaData = new Transaction();
        transactionMetaData.setTransactionId("txn-123");

        ProcessorFileTask createdTask = new ProcessorFileTask();
        createdTask.setFileName(fileName);
        createdTask.setProcessorId("processor-123");
        createdTask.setTransactionId("txn-123");

        ProcessorFileTask savedTask = new ProcessorFileTask();
        savedTask.setId("file-task-1");
        savedTask.setFileName(fileName);
        savedTask.setProcessorId("processor-123");
        savedTask.setTransactionId("txn-123");

        doReturn(transactionMetaData).when(spyService).createTransactionRecord(any(ProcessorMetaData.class));
        doReturn(createdTask).when(spyService)
                .createProcessorFileTask(processorTransaction, fileName, transactionMetaData);
        when(processorFileTaskService.saveProcessorFileTask(createdTask)).thenReturn(savedTask);

        ProcessorFileTask result = spyService.createProcessorFileTaskEntries(processorTransaction, fileName);

        assertNotNull(result);
        assertSame(savedTask, result);
        assertEquals("file-task-1", result.getId());
        assertEquals("txn-123", result.getTransactionId());

        ArgumentCaptor<ProcessorMetaData> processorCaptor = ArgumentCaptor.forClass(ProcessorMetaData.class);
        verify(spyService).createTransactionRecord(processorCaptor.capture());

        ProcessorMetaData capturedProcessor = processorCaptor.getValue();
        assertEquals("app1", capturedProcessor.getAppIdentifier());
        assertEquals(101, capturedProcessor.getClientId());
        assertEquals(Integer.valueOf(202), capturedProcessor.getConfigSpaceId());

        verify(spyService).createProcessorFileTask(processorTransaction, fileName, transactionMetaData);
        verify(processorFileTaskService).saveProcessorFileTask(createdTask);
    }

    @Test
    public void testCreateProcessorFileTask_ShouldPopulateAllFields() {
        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setAppIdentifier("app1");
        processorTransaction.setClientId(10);
        processorTransaction.setLocation("/tmp/input");
        processorTransaction.setConfigSpaceId(123);
        processorTransaction.setProcessorId("processor-1");
        processorTransaction.setId("txn-1");

        Transaction transactionMetaData = new Transaction();
        transactionMetaData.setTransactionId("trans-123");

        ProcessorFileTask result = processorsService.createProcessorFileTask(
                processorTransaction,
                "file1.txt",
                transactionMetaData
        );

        assertNotNull(result);
        assertEquals("app1", result.getAppIdentifier());
        assertEquals(10, result.getClientId());
        assertEquals("file1.txt", result.getFileName());
        assertEquals("/tmp/input", result.getLocation());
        assertEquals(Integer.valueOf(123), result.getConfigSpaceId());
        assertEquals("trans-123", result.getTransactionId());
        assertEquals("1", result.getVersion());
        assertEquals("processor-1", result.getProcessorId());
        assertEquals(MetaDataStatus.NEW, result.getStatus());
        assertEquals("txn-1", result.getProcessorTransactionId());
        assertEquals(ProcessorRecordTypes.processorFileTask, result.getProcessorRecordType());
    }

    @Test
    public void testCreateProcessorJobEntry_ShouldPopulateAndSaveJobEntry_WhenPriorityPresent() {
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setId("processor-1");
        processor.setAppIdentifier("app1");
        processor.setClientId(20);
        processor.setConfigSpaceId(200);
        processor.setPriority(5);

        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setId("pt-1");
        processorTransaction.setFileName("input.csv");
        processorTransaction.setLocation("/data/input.csv");

        JobMetaData result = processorsService.createProcessorJobEntry(
                processor,
                processorTransaction,
                "processorJob",
                "workflow1"
        );

        assertNotNull(result);
        assertEquals("ACTIVE", result.getStatus());
        assertEquals("processorJob", result.getJobType());
        assertEquals(200, result.getSpaceId());
        assertEquals(20, result.getClientId());
        assertEquals("app1", result.getAppIdentifier());
        assertEquals("input.csv", result.getFileName());
        assertEquals("/data/input.csv", result.getFilePath());
        assertEquals("workflow1", result.getWorkFlow());
        assertEquals("processor-1", result.getProcessorId());
        assertEquals("pt-1", result.getProcessorTransactionId());
        assertEquals(Integer.valueOf(5), result.isPriority());
        assertNotNull(result.getDateCreated());
        assertNotNull(result.getDateModified());
        assertEquals(FileUtil.getInstance().getLocalHostName(), result.getServerName());

        ArgumentCaptor<JobMetaData> captor = ArgumentCaptor.forClass(JobMetaData.class);
        verify(processorService).saveProcessorJobRecord(captor.capture());

        JobMetaData savedJob = captor.getValue();
        assertEquals("processor-1", savedJob.getProcessorId());
        assertEquals(Integer.valueOf(5), savedJob.isPriority());
        assertEquals("input.csv", savedJob.getFileName());
    }

    @Test
    public void testCreateProcessorJobEntry_ShouldNotSetPriority_WhenPriorityIsNull() {
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setId("processor-2");
        processor.setAppIdentifier("app2");
        processor.setClientId(30);
        processor.setConfigSpaceId(300);
        processor.setPriority(null);

        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setId("pt-2");
        processorTransaction.setFileName("input2.csv");
        processorTransaction.setLocation("/data/input2.csv");

        JobMetaData result = processorsService.createProcessorJobEntry(
                processor,
                processorTransaction,
                "processorJob",
                "workflow2"
        );

        assertNotNull(result);
        assertNull(result.isPriority());
        assertEquals("processor-2", result.getProcessorId());
        assertEquals("pt-2", result.getProcessorTransactionId());

        ArgumentCaptor<JobMetaData> captor = ArgumentCaptor.forClass(JobMetaData.class);
        verify(processorService).saveProcessorJobRecord(captor.capture());
        assertNull(captor.getValue().isPriority());
    }

    @Test
    public void testCreateTransactionRecord_ShouldCreateAndPersistTransaction() {
        ProcessorService processorService = mock(ProcessorService.class);
        TransactionService transactionService = mock(TransactionService.class);

        ProcessorsServiceImpl service = new ProcessorsServiceImpl(processorService, transactionService);

        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setAppIdentifier("app1");
        processor.setClientId(100);
        processor.setConfigSpaceId(200);

        Transaction generatedTransaction = new Transaction();
        generatedTransaction.setTransactionId("txn-123");

        Transaction persistedTransaction = new Transaction();
        persistedTransaction.setTransactionId("txn-123");

        try (MockedStatic<com.optum.fds.paperless.mongo.ProcessorUtil> processorUtilMock =
                     Mockito.mockStatic(com.optum.fds.paperless.mongo.ProcessorUtil.class)) {

            processorUtilMock
                    .when(() -> com.optum.fds.paperless.mongo.ProcessorUtil.setTransactionRecord(processor))
                    .thenReturn(generatedTransaction);

            when(transactionService.insertTransactionMetaData(generatedTransaction))
                    .thenReturn(persistedTransaction);

            Transaction result = service.createTransactionRecord(processor);

            assertNotNull(result);
            assertSame(persistedTransaction, result);

            processorUtilMock.verify(() -> com.optum.fds.paperless.mongo.ProcessorUtil.setTransactionRecord(processor));
            verify(transactionService).insertTransactionMetaData(generatedTransaction);
        }
    }

    @Test
    public void getProcessorShouldThrowNotFoundExceptionWhenProcessorDoesNotExist() {
        String appIdentifier = "app1";
        String processorId = "processor-123";

        when(processorService.getProcessorMetaData(processorId, appIdentifier))
                .thenReturn(null);

        NotFoundException exception = assertThrows(
                NotFoundException.class,
                () -> processorsService.getProcessor(appIdentifier, processorId)
        );

        assertEquals("Processor with id of processor-123 not found", exception.getMessage());

        verify(processorService).getProcessorMetaData(processorId, appIdentifier);
    }

    @Test
    public void getProcessorFileTaskShouldReturnProcessorFileTaskWhenFound() {
        String appIdentifier = "app1";
        String processorId = "processor-123";
        String serverType = null;

        ProcessorFileTask processorFileTask = new ProcessorFileTask();
        processorFileTask.setId("pft-1");
        processorFileTask.setProcessorId(processorId);

        when(processorFileTaskService.getProcessorFileTask(processorId, appIdentifier, serverType))
                .thenReturn(processorFileTask);

        ProcessorFileTask result = processorsService.getProcessorFileTask(appIdentifier, processorId);

        assertNotNull(result);
        assertSame(processorFileTask, result);
        assertEquals("pft-1", result.getId());

        verify(processorFileTaskService).getProcessorFileTask(processorId, appIdentifier, serverType);
    }

    @Test
    public void getProcessorFileTaskShouldThrowNotFoundExceptionWhenProcessorFileTaskDoesNotExist() {
        String appIdentifier = "app1";
        String processorId = "processor-123";
        String serverType = null;

        when(processorFileTaskService.getProcessorFileTask(processorId, appIdentifier, serverType))
                .thenReturn(null);

        NotFoundException exception = assertThrows(
                NotFoundException.class,
                () -> processorsService.getProcessorFileTask(appIdentifier, processorId)
        );

        assertEquals("Processor with id of processor-123 not found", exception.getMessage());
    }

    @Test
    public void testGetProcessorFileTask_ShouldThrowNotFoundException_WhenProcessorFileTaskIsNull() {
        String appIdentifier = "app";
        String processorId = "processor-123";
        String serverType = "TEST_SERVER";

        ProcessorsServiceImpl service =
                new ProcessorsServiceImpl(processorService, transactionService, processorFileTaskService);
        ReflectionTestUtils.setField(service, "serverType", serverType);

        when(processorFileTaskService.getProcessorFileTask(processorId, appIdentifier, serverType))
                .thenReturn(null);

        try {
            service.getProcessorFileTask(appIdentifier, processorId);
            fail("Expected NotFoundException to be thrown");
        } catch (jakarta.ws.rs.NotFoundException ex) {
            assertEquals("Processor with id of processor-123 not found", ex.getMessage());
        }

        verify(processorFileTaskService).getProcessorFileTask(processorId, appIdentifier, serverType);
    }

    @Test
    public void testGetProcessorTransactionById_ShouldThrowNotFoundException_WhenTransactionIsNull() {
        String id = "txn-123";

        when(processorService.getProcessorTransactionById(id)).thenReturn(null);

        NotFoundException exception = assertThrows(
                NotFoundException.class,
                () -> processorsService.getProcessorTransactionById(id)
        );

        assertEquals("Processor transaction with id of txn-123 not found", exception.getMessage());
    }

    @Test
    public void testGetTransactionProcessorById_ShouldThrowNotFoundException_WhenTransactionNotFound() {
        String id = "txn-123";

        when(processorService.getProcessorTransactionById(id)).thenReturn(null);

        NotFoundException exception = assertThrows(
                NotFoundException.class,
                () -> processorsService.getTransactionProcessorById(id)
        );

        assertEquals("Processor transaction with id of txn-123 not found", exception.getMessage());
        verify(processorService).getProcessorTransactionById(id);
    }


}
