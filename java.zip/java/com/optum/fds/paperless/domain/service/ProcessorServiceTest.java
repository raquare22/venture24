package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.jobs.ProcessorCoreJob;
import com.optum.fds.paperless.util.ProcessorUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.mongodb.client.result.UpdateResult;
import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.jobs.RestApiJob;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorMapping;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.util.*;


@RunWith(MockitoJUnitRunner.class)
public class ProcessorServiceTest {
    @Mock
    MongoTemplate mongoTemplate;
	
    @InjectMocks
    ProcessorServiceImpl processorService;
    
    @Mock
    ProcessorServiceImpl processorService1;
    
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void deleteJobFromStackTest() { 
		List<ProcessorMapping> pm=new ArrayList();
		when(mongoTemplate.findAllAndRemove(any(Query.class),
    			eq(ProcessorMapping.class),
    			anyString())).thenReturn(pm);
		boolean hmdresult;
		if(pm.size()>0) { 
			hmdresult=false;
		}
		else {
			hmdresult=true;
		}
		boolean result=processorService.deleteProcessor("test", "test", 2);
		assertEquals(result, hmdresult);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void deleteProcessorJobFromStackTest() { 
		JobMetaData hmd=new JobMetaData();
		when(mongoTemplate.findAndRemove(any(Query.class),
    			eq(JobMetaData.class),
    			anyString())).thenReturn(hmd);
		JobMetaData result=processorService.deleteProcessorJobFromStack("test");
		assertNotNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void deleteProcessorMetaDataTest() { 
		ProcessorMetaData hmd=new ProcessorMetaData();
		when(mongoTemplate.findAndRemove(any(Query.class),
    			eq(ProcessorMetaData.class),
    			anyString())).thenReturn(hmd);
		boolean result=processorService.deleteProcessorMetaData("test", "test");
		//assertEquals(result.getAppIdentifier(), hmd.getAppIdentifier());
		assertTrue(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findAllAvailableProcessorMetaDataTest() { 
		List<ProcessorMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), anyString())).thenReturn(hmds);
		List<ProcessorMetaData> result = processorService.findAllAvailableProcessorMetaData(new Date(), new Date());
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findAllAvailableProcessorMetaData2Test() { 
		List<ProcessorMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), anyString())).thenReturn(hmds);
		List<ProcessorMetaData> result = processorService.findAllAvailableProcessorMetaData();
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findAllUnplannedProcessorLockMetaDataTest() { 
		List<ProcessorMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), anyString())).thenReturn(hmds);
		List<ProcessorMetaData> result = processorService.findAllUnplannedProcessorLockMetaData();
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void deleteProcessorMetaData2Test() { 
		ProcessorMetaData pmd=new ProcessorMetaData();
		when(mongoTemplate.findOne(any(Query.class),
    			eq(ProcessorMetaData.class),
    			anyString())).thenReturn(pmd);
		ProcessorMetaData result=processorService.findProcessorMetaDataByFileName("test", "test");
		//assertEquals(result.getAppIdentifier(), hmd.getAppIdentifier());
		assertNotNull(result);
		assertEquals(result, pmd);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findProcessorTransactionByFileNameTest() { 
		ProcessorTransaction pmd=new ProcessorTransaction();
		when(mongoTemplate.findOne(any(Query.class),
    			eq(ProcessorTransaction.class),
    			anyString())).thenReturn(pmd);
		ProcessorTransaction result=processorService.findProcessorTransactionByFileName("test", 2);
		assertNotNull(result);
		assertEquals(result, pmd);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findProcessorMetaDataByIdTest() { 
		ProcessorMetaData pmd=new ProcessorMetaData();
		when(mongoTemplate.findOne(any(Query.class),
    			eq(ProcessorMetaData.class),
    			anyString())).thenReturn(pmd);
		ProcessorMetaData result=processorService.findProcessorMetaDataById("test", "test");
		assertNotNull(result);
		assertEquals(result, pmd);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findTopOfProcessorJobQueueQueryTest() { 
		Query result=processorService.findTopOfProcessorJobQueueQuery();
		assertNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findTopOfRestApiJobQueueQueryTest() { 
		Query result=processorService.findTopOfRestApiJobQueueQuery();
		assertNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findProcessorJobByTransactionIdFromQueueTest() { 
		boolean hmd = false;
		when(mongoTemplate.exists(any(Query.class),
    			eq(ProcessorMetaData.class),
    			anyString())).thenReturn(hmd);
		boolean result=processorService.findProcessorJobByTransactionIdFromQueue("test", "test");
		//assertEquals(result.getAppIdentifier(), hmd.getAppIdentifier());
		assertFalse(result);
		assertEquals(hmd, result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findProcessorJobsByTransactionIdFromQueueTest() { 
		List<JobMetaData>  jmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(jmds);
		List<JobMetaData> result = processorService.findProcessorJobsByTransactionIdFromQueue("test", "test");
		assertNotNull(result);
		assertEquals(result, jmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getProcessorMappingTest() { 
		List<ProcessorMapping>  jmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorMapping.class), anyString())).thenReturn(jmds);
		ProcessorMapping result = processorService.getProcessorMapping("test", 3);
		assertNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getProcessorMetaDataTest() { 
		List<ProcessorMetaData>  pmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), anyString())).thenReturn(pmds);
		ProcessorMetaData result = processorService.getProcessorMetaData("test", "test");
		assertNull(result);
		assertNotNull(pmds);

	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getProcessorFileTaskTest() { 
		List<ProcessorFileTask>  hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), anyString())).thenReturn(hmds);
		ProcessorFileTask result = processorService.getProcessorFileTask("507f191e810c19729de860ea", "test", "Test");
		assertNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getProcessorFileTaskByProcessorTransactionIdRowNumberTest() { 
		List<ProcessorFileTask>  hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), anyString())).thenReturn(hmds);
		ProcessorFileTask result = processorService.getProcessorFileTaskByProcessorTransactionIdRowNumber("507f191e810c19729de860ea", 0);
		assertNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getProcessorFileTaskForTargetIdTest() { 
		List<ProcessorFileTask>  hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), anyString())).thenReturn(hmds);
		ProcessorFileTask result = processorService.getProcessorFileTaskForTargetId("1", "5", "test");
		assertNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getProcessorFileTasksForTransactionIdTest() { 
		List<ProcessorFileTask>  hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), anyString())).thenReturn(hmds);
		List<ProcessorFileTask> result = processorService.getProcessorFileTasksForTransactionId("1", "test");
		assertNotNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getPendingProcessorFileTaskForTransactionIdTest() { 
		List<ProcessorFileTask>  hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), anyString())).thenReturn(hmds);
		List<ProcessorFileTask> result = processorService.getPendingProcessorFileTaskForTransactionId("1", "test", "test", 4);
		assertNotNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getLastProcessorFileTaskForTransactionIdTest() { 
		List<ProcessorFileTask>  hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), anyString())).thenReturn(hmds);
		List<ProcessorFileTask> result = processorService.getLastProcessorFileTaskForTransactionId("1", "test");
		assertNotNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void pendingprocessorTransactionIdAndServerTypeQueryTest() { 
		Query result=processorService.pendingprocessorTransactionIdAndServerTypeQuery("test", "test", "test", 1);
		assertNotNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getProcessorTransactionTest() { 
		List<ProcessorTransaction>  hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), anyString())).thenReturn(hmds);
		ProcessorTransaction result = processorService.getProcessorTransaction("507f191e810c19729de860ea", "test", "test");
		assertNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getAllProcessorTransactionInStatusTest() { 
		List<ProcessorTransaction>  hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), anyString())).thenReturn(hmds);
		List<ProcessorTransaction> result = processorService.getAllProcessorTransactionInStatus("test", "test");
		assertNotNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void processorTransactionStatusListAndServerTypeQueryTest() { 
		List<String> statusList=new ArrayList();
		Query result=processorService.processorTransactionStatusListAndServerTypeQuery(statusList, "test", 7);
		assertNotNull(result);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void processorTransactionStatusAndServerTypeQueryTest() { 
		List<String> statusList=new ArrayList();
		Query result=processorService.processorTransactionStatusAndServerTypeQuery("status", "test");
		assertNotNull(result);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getAllProcessorTransactionInStatus2Test() { 
		List<ProcessorTransaction>  hmds=new ArrayList();
		List<String> statusList=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), anyString())).thenReturn(hmds);
		List<ProcessorTransaction> result = processorService.getAllProcessorTransactionInStatus(statusList, "test", 1);
		assertNotNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getAllProcessorTransactionInStatus3Test() { 
		List<ProcessorTransaction>  hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), anyString())).thenReturn(hmds);
		List<ProcessorTransaction> result = processorService.getAllProcessorTransactionInStatus("test", "test", 1);
		assertNotNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void processorTransactionStatusAndServerTypeQuery2Test() { 
		Query result=processorService.processorTransactionStatusAndServerTypeQuery("test", "test", 7);
		assertNotNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getAllPendingProcessorTransactionsTest() { 
		List<ProcessorTransaction>  hmds=new ArrayList();
		List<String> statusList=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), anyString())).thenReturn(hmds);
		List<ProcessorTransaction> result = processorService.getAllPendingProcessorTransactions(1, statusList, "test");
		assertNotNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void pendingProcessorTransactionsQueryTest() { 
		List<String> statusList=new ArrayList();
		Query result=processorService.pendingProcessorTransactionsQuery(1, statusList, "test");
		assertNotNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void lockProcessorTest() { 
		processorService.lockProcessor("test");
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void nameIsUniqueTest() { 
		boolean hmd = true;
		when(!mongoTemplate.exists(any(Query.class),
    			eq(ProcessorMetaData.class),
    			anyString())).thenReturn(hmd);
		boolean result=processorService.nameIsUnique("test", "test");
		assertFalse(result);
		assertTrue(hmd);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void saveProcessorFileTaskTest() { 
		ProcessorFileTask processorFileTask=new ProcessorFileTask();
		when(mongoTemplate.save(any(ProcessorFileTask.class), anyString())).thenReturn(processorFileTask);
		ProcessorFileTask result=processorService.saveProcessorFileTask(new ProcessorFileTask());
		assertNotNull(result);
		assertEquals(result.getAppIdentifier(), processorFileTask.getAppIdentifier());
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void saveProcessorJobRecordTest() { 
		JobMetaData jobMetaData=new JobMetaData();
		when(mongoTemplate.insert(any(JobMetaData.class), anyString())).thenReturn(jobMetaData);
		JobMetaData result=processorService.saveProcessorJobRecord(new JobMetaData());
		assertNotNull(result);
		assertEquals(result.getAppIdentifier(), jobMetaData.getAppIdentifier());
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void saveProcessorMetaDataTest() { 
		ProcessorMetaData processorMetaData=new ProcessorMetaData();
		when(mongoTemplate.save(any(ProcessorMetaData.class), anyString())).thenReturn(processorMetaData);
		ProcessorMetaData result=processorService.saveProcessorMetaData(new ProcessorMetaData());
		assertNotNull(result);
		assertEquals(result.getAppIdentifier(), processorMetaData.getAppIdentifier());
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void saveProcessorTransactionMetaDataTest() { 
		ProcessorTransaction processorMetaData=new ProcessorTransaction();
		when(mongoTemplate.save(any(ProcessorTransaction.class), anyString())).thenReturn(processorMetaData);
		ProcessorTransaction result=processorService.saveProcessorTransactionMetaData(new ProcessorTransaction());
		assertNotNull(result);
		assertEquals(result.getAppIdentifier(), processorMetaData.getAppIdentifier());
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void setLastCleanRunTest() { 
		processorService.setLastCleanRun("test");
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void updateOneProcessorTransactionFieldTest() { 
		processorService.updateOneProcessorTransactionField("test", "key", new Object());
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void setLastRunAndStatusTest() {
		UpdateResult updateResult=null;
		when(mongoTemplate.updateMulti(any(Query.class), any(Update.class), eq(ProcessorMetaData.class), anyString())).thenReturn(updateResult);
		processorService.setLastRunAndStatus("test", MetaDataStatus.OK);
		assertNull(updateResult);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void unlockProcessorTest() { 
		processorService.unlockProcessor("test");
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void startProcessorTest() { 
		processorService.startProcessor("test");
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void shutdownProcessorTest() { 
		processorService.shutdownProcessor("test");
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void updateJobStatusTest() { 
		processorService.updateJobStatus("test", "test");
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void updateProcessorFileTaskTest() { 
		ProcessorFileTask result=processorService.updateProcessorFileTask(new ProcessorFileTask());
		assertNotNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void updateProcessorExecutionRecordOfProcessorFileTaskRecordTest() { 
		Map<String, Object> resultMap=new HashMap();
		ProcessorCoreJob job=new ProcessorCoreJob();
		ProcessorFileTask result=processorService.updateProcessorExecutionRecordOfProcessorFileTaskRecord(new ProcessorFileTask(), resultMap, job);
		assertNotNull(result);
	}

	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void updateProcessorExecutionRecordOfProcessorFileTaskRecord2Test() { 
		Map<String, Object> resultMap=new HashMap();
		RestApiJob job=new RestApiJob();
		ProcessorFileTask result=processorService.updateProcessorExecutionRecordOfProcessorFileTaskRecord(new ProcessorFileTask(), resultMap, job);
		assertNotNull(result);
	}
	

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void updateProcessorMetaDataTest() { 
		ProcessorMetaData result=processorService.updateProcessorMetaData(new ProcessorMetaData());
		assertNotNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void updateProcessorTransactionMetaDataTest() { 
		ProcessorTransaction result=processorService.updateProcessorTransactionMetaData(new ProcessorTransaction());
		assertNotNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findJobByProcessorTransactionIdByWorkflowTest() { 
		JobMetaData pmd=new JobMetaData();
		when(mongoTemplate.findOne(any(Query.class),
    			eq(JobMetaData.class),
    			anyString())).thenReturn(pmd);
		JobMetaData result=processorService.findJobByProcessorTransactionIdByWorkflow("test", "test", "test");
		assertNotNull(result);
		assertEquals(result, pmd);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findJobByProcessorTransactionIdByWorkflowQueryTest() { 
		Query result=processorService.findJobByProcessorTransactionIdByWorkflowQuery("test", "test", "test");
		assertNotNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findAllAvailableProcessorsToStartTest() { 
		List<ProcessorMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), anyString())).thenReturn(hmds);
		List<ProcessorMetaData> result = processorService.findAllAvailableProcessorsToStart();
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findAllAvailableProcessorsForShutdownTest() { 
		List<ProcessorMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), anyString())).thenReturn(hmds);
		List<ProcessorMetaData> result = processorService.findAllAvailableProcessorsForShutdown();
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getProcessorFileTasksForTransactionIdByStatusTest() { 
		List<ProcessorFileTask> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), anyString())).thenReturn(hmds);
		List<ProcessorFileTask> result = processorService.getProcessorFileTasksForTransactionIdByStatus("test", "test");
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void updateProcessorTransactionFieldsTest() throws InvalidExpressionException { 
		Map<String, Object> updateMap=new HashMap();
		updateMap.put("_id", new Object());
		processorService.updateProcessorTransactionFields("test",updateMap);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void deleteProcessorMappingTest() { 
		ProcessorMapping hmd=new ProcessorMapping();
		when(mongoTemplate.findAndRemove(any(Query.class),
    			eq(ProcessorMapping.class),
    			anyString())).thenReturn(hmd);
		ProcessorMapping result=processorService.deleteProcessorMapping("test", 1);
		//assertEquals(result.getAppIdentifier(), hmd.getAppIdentifier());
		assertNotNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void saveProcessorMapping2Test() { 
		ProcessorMapping hmd=new ProcessorMapping();
		when(mongoTemplate.save(
    			any(ProcessorMapping.class),
    			anyString())).thenReturn(hmd);
		ProcessorMapping result=processorService.saveProcessorMapping(new ProcessorMapping());
		assertNotNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void lockIncompleteProcessorFlagsTest()  { 
		processorService.lockIncompleteProcessorFlag("test");
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void unlockIncompleteProcessorFlagTest()  { 
		processorService.unlockIncompleteProcessorFlag("test");
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void updateProcessorLastRunTest()  { 
		processorService.updateProcessorLastRun("test");
	}
	
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findAndUpdateJobsByStatusINProcessTest() {
		UpdateResult updateResult=null;
	//	when(mongoTemplate.updateMulti(any(Query.class), any(Update.class), anyString())).thenReturn(updateResult);
		processorService.findAndUpdateJobsByStatusINProcess("test", "job");
		assertNull(updateResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void getProcessorTransactionByIdTest() { 
		List<ProcessorTransaction>  hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), anyString())).thenReturn(hmds);
		ProcessorTransaction result = processorService.getProcessorTransactionById("507f191e810c19729de860ea");
		assertNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void setAckStatusTest() throws InvalidExpressionException { 
		List<ProcessorTransaction>  hmds=new ArrayList();
		UpdateResult updateResult=null;
	//	when(mongoTemplate.updateFirst(any(Query.class), any(Update.class), anyString())).thenReturn(updateResult);
		processorService.setAckStatus("507f191e810c19729de860ea", "ack");
		assertNotNull(hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findAllAvailableProcessorIdsTest() { 
		List<ProcessorMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), anyString())).thenReturn(hmds);
		List<String> result = processorService.findAllAvailableProcessorIds(new Date(), new Date());
		assertNotNull(result);
		assertNotNull(hmds);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findProcessorJob2Test() { 
		JobMetaData hmds=new JobMetaData();
		when(mongoTemplate.findById(anyString(), eq(JobMetaData.class), anyString())).thenReturn(hmds);
		JobMetaData result = processorService.findProcessorJob("sample");
		assertNotNull(result);
		assertNotNull(hmds);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32969")
	@Test
	public void findProcessorTest() { 
		ProcessorMetaData hmds=new ProcessorMetaData();
		when(mongoTemplate.findById(anyString(), eq(ProcessorMetaData.class), anyString())).thenReturn(hmds);
		ProcessorMetaData result = processorService.findProcessor("sample");
		assertNotNull(result);
		assertNotNull(hmds);
	}

    @Test
    public void deleteProcessor_shouldRethrowException_whenFindAllAndRemoveFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.findAllAndRemove(any(Query.class), eq(ProcessorMapping.class), anyString()))
                .thenThrow(expected);

        RuntimeException actual = org.junit.Assert.assertThrows(RuntimeException.class,
                () -> processorService.deleteProcessor("processor", "typeA", 2));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).findAllAndRemove(any(Query.class), eq(ProcessorMapping.class), anyString());
    }

    @Test
    public void deleteProcessorJobFromStack_shouldRethrowException_whenFindAndRemoveFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.findAndRemove(any(Query.class), eq(JobMetaData.class), anyString()))
                .thenThrow(expected);

        RuntimeException actual = org.junit.Assert.assertThrows(RuntimeException.class,
                () -> processorService.deleteProcessorJobFromStack("job-1"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).findAndRemove(any(Query.class), eq(JobMetaData.class), anyString());
    }

    @Test
    public void deleteProcessorMetaData_shouldRethrowException_whenFindAndRemoveFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.findAndRemove(any(Query.class), eq(ProcessorMetaData.class), anyString()))
                .thenThrow(expected);

        RuntimeException actual = org.junit.Assert.assertThrows(RuntimeException.class,
                () -> processorService.deleteProcessorMetaData("id-1", "app-1"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).findAndRemove(any(Query.class), eq(ProcessorMetaData.class), anyString());
    }

    @Test
    public void findAllAvailableProcessorMetaData_withDates_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), anyString()))
                .thenThrow(expected);

        RuntimeException actual = org.junit.Assert.assertThrows(RuntimeException.class,
                () -> processorService.findAllAvailableProcessorMetaData(new Date(), new Date()));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorMetaData.class), anyString());
    }

    @Test
    public void findAllAvailableProcessorMetaData_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), anyString()))
                .thenThrow(expected);

        RuntimeException actual = org.junit.Assert.assertThrows(RuntimeException.class,
                () -> processorService.findAllAvailableProcessorMetaData());

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorMetaData.class), anyString());
    }

    @Test
    public void findAllUnplannedProcessorLockMetaData_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), anyString()))
                .thenThrow(expected);

        RuntimeException actual = org.junit.Assert.assertThrows(RuntimeException.class,
                () -> processorService.findAllUnplannedProcessorLockMetaData());

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorMetaData.class), anyString());
    }

    @Test
    public void findProcessorMetaDataByFileName_shouldRethrowException_whenFindOneFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.findOne(any(Query.class), eq(ProcessorMetaData.class), anyString()))
                .thenThrow(expected);

        RuntimeException actual = org.junit.Assert.assertThrows(RuntimeException.class,
                () -> processorService.findProcessorMetaDataByFileName("file.zip", "app-1"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).findOne(any(Query.class), eq(ProcessorMetaData.class), anyString());
    }

    @Test
    public void findProcessorTransactionByFileName_shouldRethrowException_whenFindOneFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.findOne(any(Query.class), eq(ProcessorTransaction.class), anyString()))
                .thenThrow(expected);

        RuntimeException actual = org.junit.Assert.assertThrows(RuntimeException.class,
                () -> processorService.findProcessorTransactionByFileName("file.zip", 100));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).findOne(any(Query.class), eq(ProcessorTransaction.class), anyString());
    }

    @Test
    public void findProcessorMetaDataById_shouldRethrowException_whenFindOneFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.findOne(any(Query.class), eq(ProcessorMetaData.class), anyString()))
                .thenThrow(expected);

        RuntimeException actual = org.junit.Assert.assertThrows(RuntimeException.class,
                () -> processorService.findProcessorMetaDataById("processor-1", "app-1"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).findOne(any(Query.class), eq(ProcessorMetaData.class), anyString());
    }

    @Test
    public void findTopOfProcessorJobQueueForProcessors_TryBlockTest() {
        ProcessorServiceImpl spyService = spy(processorService);
        Query mockQuery = new Query();
        JobMetaData expectedJob = new JobMetaData();

        doReturn(mockQuery).when(spyService).findTopOfProcessorJobQueueQuery();
        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class),
                eq(JobMetaData.class), eq("job"))).thenReturn(expectedJob);

        JobMetaData result =
                spyService.findTopOfProcessorJobQueueForProcessors("testServer", new ArrayList<>());

        assertNotNull(result);
        assertEquals(expectedJob, result);
    }

    @Test
    public void findTopOfProcessorJobQueueForProcessors_CatchBlockTest() {
        ProcessorServiceImpl spyService = spy(processorService);
        Query mockQuery = new Query();

        doReturn(mockQuery).when(spyService).findTopOfProcessorJobQueueQuery();
        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class),
                eq(JobMetaData.class), eq("job")))
                .thenThrow(new RuntimeException("Simulated exception"));

        try {
            spyService.findTopOfProcessorJobQueueForProcessors("testServer", new ArrayList<>());
            fail("Expected exception was not thrown");
        } catch (Exception e) {
            assertEquals("Simulated exception", e.getMessage());
        }
    }

    @Test
    public void findTopOfRestApiJobQueueForProcessors_TryBlockTest() {
        ProcessorServiceImpl spyService = spy(processorService);
        Query mockQuery = new Query();
        JobMetaData expectedJob = new JobMetaData();

        doReturn(mockQuery).when(spyService).findTopOfRestApiJobQueueQuery();
        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class),
                eq(JobMetaData.class), eq("job"))).thenReturn(expectedJob);

        JobMetaData result =
                spyService.findTopOfRestApiJobQueueForProcessors("testServer", new ArrayList<>());

        assertNotNull(result);
        assertEquals(expectedJob, result);
    }

    @Test
    public void findTopOfRestApiJobQueueForProcessors_CatchBlockTest() {
        ProcessorServiceImpl spyService = spy(processorService);
        Query mockQuery = new Query();

        doReturn(mockQuery).when(spyService).findTopOfRestApiJobQueueQuery();
        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class),
                eq(JobMetaData.class), eq("job")))
                .thenThrow(new RuntimeException("Simulated exception"));

        try {
            spyService.findTopOfRestApiJobQueueForProcessors("testServer", new ArrayList<>());
            fail("Expected exception was not thrown");
        } catch (Exception e) {
            assertEquals("Simulated exception", e.getMessage());
        }
    }

    @Test
    public void findProcessorJobByTransactionIdFromQueue_shouldRethrowException_whenExistsFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.exists(any(Query.class), eq(ProcessorMetaData.class), eq("job")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.findProcessorJobByTransactionIdFromQueue("txn-123", "serverA"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).exists(any(Query.class), eq(ProcessorMetaData.class), eq("job"));
    }

    @Test
    public void findProcessorJobsByTransactionIdFromQueue_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), eq("job")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.findProcessorJobsByTransactionIdFromQueue("txn-123", "serverA"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(JobMetaData.class), eq("job"));
    }

    @Test
    public void getProcessorMapping_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMapping.class), eq("processorMapping")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.getProcessorMapping("app-1", 100));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorMapping.class), eq("processorMapping"));
    }

    @Test
    public void getProcessorMetaData_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), eq("processor")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.getProcessorMetaData("processor-1", "app-1"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorMetaData.class), eq("processor"));
    }

    @Test
    public void getProcessorFileTask_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.getProcessorFileTask("507f191e810c19729de860ea", "app-1", "serverA"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"));
    }

    @Test
    public void getProcessorFileTasksForTransactionId_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.getProcessorFileTasksForTransactionId("txn-123", "serverA"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"));
    }

    @Test
    public void getPendingProcessorFileTaskForTransactionId_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.getPendingProcessorFileTaskForTransactionId(
                        "txn-123", "serverA", "IN_PROCESS", 60));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"));
    }

    @Test
    public void getLastProcessorFileTaskForTransactionId_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.getLastProcessorFileTaskForTransactionId("txn-123", "serverA"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"));
    }

    @Test
    public void getProcessorTransaction_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");
        Query mockedQuery = new Query();

        try (MockedStatic<ProcessorUtil> processorUtilMock = mockStatic(ProcessorUtil.class)) {
            processorUtilMock
                    .when(() -> ProcessorUtil.getProcessorByServerTypeQuery("txn-123", "app-1", "serverA"))
                    .thenReturn(mockedQuery);

            when(mongoTemplate.find(
                    eq(mockedQuery),
                    eq(ProcessorTransaction.class),
                    eq("processorTransaction")))
                    .thenThrow(expected);

            RuntimeException actual = assertThrows(RuntimeException.class,
                    () -> processorService.getProcessorTransaction("txn-123", "app-1", "serverA"));

            assertEquals("mongo failure", actual.getMessage());

            processorUtilMock.verify(() ->
                    ProcessorUtil.getProcessorByServerTypeQuery("txn-123", "app-1", "serverA"));
            verify(mongoTemplate).find(
                    eq(mockedQuery),
                    eq(ProcessorTransaction.class),
                    eq("processorTransaction"));
        }
    }

    @Test
    public void getAllProcessorTransactionInStatus_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.getAllProcessorTransactionInStatus("IN_PROCESS", "serverA"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction"));
    }

    @Test
    public void getAllProcessorTransactionInStatus_withStatusListAndOffset_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");
        List<String> statuses = new ArrayList<>();
        statuses.add("NEW");
        statuses.add("IN_PROCESS");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.getAllProcessorTransactionInStatus(statuses, "serverA", 1));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction"));
    }

    @Test
    public void getAllProcessorTransactionInStatus_withStatusAndOffset_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.getAllProcessorTransactionInStatus("IN_PROCESS", "serverA", 1));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction"));
    }

    @Test
    public void getAllPendingProcessorTransactions_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");
        List<String> statuses = new ArrayList<>();
        statuses.add("NEW");
        statuses.add("IN_PROCESS");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.getAllPendingProcessorTransactions(60, statuses, "serverA"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction"));
    }

    @Test
    public void setLastRunAndStatus_shouldRethrowException_whenUpdateMultiFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.updateMulti(
                any(Query.class),
                any(Update.class),
                eq(ProcessorMetaData.class),
                eq("processor")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.setLastRunAndStatus("test-id", MetaDataStatus.IN_PROCESS));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).updateMulti(
                any(Query.class),
                any(Update.class),
                eq(ProcessorMetaData.class),
                eq("processor"));
    }

    @Test
    public void updateProcessorExecutionRecordOfProcessorTransactionRecord_shouldSetInProcess_whenStatusIsNotFatalError() {
        ProcessorServiceImpl spyService = Mockito.spy(processorService);

        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setStatus(MetaDataStatus.NEW);

        Map<String, Object> resultMap = new HashMap<>();
        ProcessorCoreJob job = new ProcessorCoreJob();

        doReturn(processorTransaction).when(spyService)
                .updateProcessorTransactionMetaData(processorTransaction);

        try (MockedStatic<ProcessorUtil> mockedStatic = Mockito.mockStatic(ProcessorUtil.class)) {
            mockedStatic.when(() ->
                    ProcessorUtil.setExecutionRecordForActiviti(processorTransaction, resultMap, job)
            ).thenAnswer(invocation -> null);

            ProcessorTransaction result = spyService
                    .updateProcessorExecutionRecordOfProcessorTransactionRecord(processorTransaction, resultMap, job);

            assertNotNull(result);
            assertSame(processorTransaction, result);
            assertEquals(MetaDataStatus.IN_PROCESS, result.getStatus());

            mockedStatic.verify(() ->
                    ProcessorUtil.setExecutionRecordForActiviti(processorTransaction, resultMap, job));
            verify(spyService).updateProcessorTransactionMetaData(processorTransaction);
        }
    }

    @Test
    public void updateProcessorExecutionRecordOfProcessorTransactionRecord_withRestApiJob_shouldSetStatusToInProcess() {
        ProcessorServiceImpl spyService = spy(processorService);

        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setStatus(MetaDataStatus.NEW);

        Map<String, Object> resultMap = new HashMap<>();
        RestApiJob job = new RestApiJob();

        ProcessorTransaction updatedTransaction = new ProcessorTransaction();
        updatedTransaction.setStatus(MetaDataStatus.IN_PROCESS);

        try (org.mockito.MockedStatic<ProcessorUtil> mockedProcessorUtil = mockStatic(ProcessorUtil.class)) {
            mockedProcessorUtil.when(() ->
                            ProcessorUtil.setExecutionRecordForActiviti(processorTransaction, resultMap, job))
                    .thenAnswer(invocation -> null);

            doReturn(updatedTransaction)
                    .when(spyService)
                    .updateProcessorTransactionMetaData(processorTransaction);

            ProcessorTransaction result =
                    spyService.updateProcessorExecutionRecordOfProcessorTransactionRecord(
                            processorTransaction, resultMap, job);

            assertNotNull(result);
            assertEquals(MetaDataStatus.IN_PROCESS, processorTransaction.getStatus());
            assertEquals(updatedTransaction, result);

            mockedProcessorUtil.verify(() ->
                    ProcessorUtil.setExecutionRecordForActiviti(processorTransaction, resultMap, job));
            verify(spyService).updateProcessorTransactionMetaData(processorTransaction);
        }
    }

    @Test
    public void findAllAvailableProcessorsToStart_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), eq("processor")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.findAllAvailableProcessorsToStart());

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorMetaData.class), eq("processor"));
    }

    @Test
    public void findAllAvailableProcessorsForShutdown_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), eq("processor")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.findAllAvailableProcessorsForShutdown());

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorMetaData.class), eq("processor"));
    }

    @Test
    public void getProcessorFileTasksForTransactionIdByStatus_shouldRethrowException_whenFindFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.getProcessorFileTasksForTransactionIdByStatus("txn-123", "IN_PROCESS"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"));
    }

    @Test
    public void setAckStatus_shouldThrowInvalidExpressionException_whenIdIsEmpty() {
        InvalidExpressionException actual = assertThrows(
                InvalidExpressionException.class,
                () -> processorService.setAckStatus("", "ack")
        );

        assertEquals("Given string id is not valid, Not updating ackStatus", actual.getMessage());
        verify(mongoTemplate, never()).updateFirst(
                any(Query.class),
                any(Update.class),
                eq(ProcessorMetaData.class),
                anyString()
        );
    }

    @Test
    public void setAckStatus_shouldRethrowException_whenUpdateFirstFails() {
        RuntimeException expected = new RuntimeException("mongo failure");

        when(mongoTemplate.updateFirst(
                any(Query.class),
                any(Update.class),
                eq(ProcessorMetaData.class),
                eq(Workflow.PROCESSOR_TRANSACTION)))
                .thenThrow(expected);

        RuntimeException actual = assertThrows(RuntimeException.class,
                () -> processorService.setAckStatus("507f191e810c19729de860ea", "ack"));

        assertEquals("mongo failure", actual.getMessage());
        verify(mongoTemplate).updateFirst(
                any(Query.class),
                any(Update.class),
                eq(ProcessorMetaData.class),
                eq(Workflow.PROCESSOR_TRANSACTION));
    }

    @Test
    public void retrieveJobIdList_shouldReturnJobIds_whenJobsAreFound() {
        ProcessorServiceImpl spyService = spy(processorService);
        Query mockQuery = new Query();

        JobMetaData job1 = new JobMetaData();
        job1.setId("job-1");
        JobMetaData job2 = new JobMetaData();
        job2.setId("job-2");

        doReturn(mockQuery).when(spyService).findTopOfProcessorJobQueueQuery();
        when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), eq("job")))
                .thenReturn(Arrays.asList(job1, job2));

        List<String> result = spyService.retrieveJobIdList(2);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(Arrays.asList("job-1", "job-2"), result);

        verify(mongoTemplate).find(any(Query.class), eq(JobMetaData.class), eq("job"));
    }

    @Test
    public void deleteProcessorMetaData_shouldReturnFalse_whenNothingIsRemoved() {
        when(mongoTemplate.findAndRemove(any(Query.class), eq(ProcessorMetaData.class), anyString()))
                .thenReturn(null);

        boolean result = processorService.deleteProcessorMetaData("id-1", "app-1");

        assertFalse(result);
        verify(mongoTemplate).findAndRemove(any(Query.class), eq(ProcessorMetaData.class), anyString());
    }

    @Test
    public void getProcessorMapping_shouldReturnFirstMapping_whenMappingsExist() {
        ProcessorMapping first = new ProcessorMapping();
        ProcessorMapping second = new ProcessorMapping();

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMapping.class), eq("processorMapping")))
                .thenReturn(Arrays.asList(first, second));

        ProcessorMapping result = processorService.getProcessorMapping("app-1", 100);

        assertNotNull(result);
        assertSame(first, result);
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorMapping.class), eq("processorMapping"));
    }

    @Test
    public void getProcessorMetaData_shouldReturnFirstProcessor_whenProcessorsExist() {
        ProcessorMetaData first = new ProcessorMetaData();
        first.setId("processor-1");
        ProcessorMetaData second = new ProcessorMetaData();
        second.setId("processor-2");

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), eq("processor")))
                .thenReturn(Arrays.asList(first, second));

        ProcessorMetaData result = processorService.getProcessorMetaData("processor-1", "app-1");

        assertNotNull(result);
        assertSame(first, result);
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorMetaData.class), eq("processor"));
    }

    @Test
    public void getProcessorFileTask_shouldReturnFirstTask_whenTasksExist() {
        Query mockedQuery = new Query();
        ProcessorFileTask first = new ProcessorFileTask();
        ProcessorFileTask second = new ProcessorFileTask();

        try (MockedStatic<ProcessorUtil> processorUtilMock = mockStatic(ProcessorUtil.class)) {
            processorUtilMock
                    .when(() -> ProcessorUtil.getProcessorByServerTypeQuery("txn-123", "app-1", "serverA"))
                    .thenReturn(mockedQuery);

            when(mongoTemplate.find(eq(mockedQuery), eq(ProcessorFileTask.class), eq("processorFileTask")))
                    .thenReturn(Arrays.asList(first, second));

            ProcessorFileTask result = processorService.getProcessorFileTask("txn-123", "app-1", "serverA");

            assertNotNull(result);
            assertSame(first, result);

            processorUtilMock.verify(() ->
                    ProcessorUtil.getProcessorByServerTypeQuery("txn-123", "app-1", "serverA"));
            verify(mongoTemplate).find(eq(mockedQuery), eq(ProcessorFileTask.class), eq("processorFileTask"));
        }
    }

    @Test
    public void getProcessorFileTaskByProcessorTransactionIdRowNumber_shouldReturnFirstTask_whenTasksExist() {
        ProcessorFileTask first = new ProcessorFileTask();
        ProcessorFileTask second = new ProcessorFileTask();

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenReturn(Arrays.asList(first, second));

        ProcessorFileTask result =
                processorService.getProcessorFileTaskByProcessorTransactionIdRowNumber("txn-123", 1);

        assertNotNull(result);
        assertSame(first, result);
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"));
    }

    @Test
    public void getProcessorFileTaskForTargetId_shouldReturnFirstTask_whenTasksExist() {
        ProcessorFileTask first = new ProcessorFileTask();
        ProcessorFileTask second = new ProcessorFileTask();

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenReturn(Arrays.asList(first, second));

        ProcessorFileTask result = processorService.getProcessorFileTaskForTargetId("target-1", "5", "app-1");

        assertNotNull(result);
        assertSame(first, result);
        verify(mongoTemplate).find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"));
    }

    @Test
    public void getProcessorTransaction_shouldReturnFirstTransaction_whenTransactionsExist() {
        Query mockedQuery = new Query();
        ProcessorTransaction first = new ProcessorTransaction();
        first.setId("txn-1");
        ProcessorTransaction second = new ProcessorTransaction();
        second.setId("txn-2");

        try (MockedStatic<ProcessorUtil> processorUtilMock = mockStatic(ProcessorUtil.class)) {
            processorUtilMock
                    .when(() -> ProcessorUtil.getProcessorByServerTypeQuery("txn-123", "app-1", "serverA"))
                    .thenReturn(mockedQuery);

            when(mongoTemplate.find(eq(mockedQuery), eq(ProcessorTransaction.class), eq("processorTransaction")))
                    .thenReturn(Arrays.asList(first, second));

            ProcessorTransaction result = processorService.getProcessorTransaction("txn-123", "app-1", "serverA");

            assertNotNull(result);
            assertSame(first, result);

            processorUtilMock.verify(() ->
                    ProcessorUtil.getProcessorByServerTypeQuery("txn-123", "app-1", "serverA"));
            verify(mongoTemplate).find(eq(mockedQuery), eq(ProcessorTransaction.class), eq("processorTransaction"));
        }
    }

    @Test
    public void getAllProcessorTransactionInStatus_withStatusListAndPositiveOffset_shouldUseDateModifiedCriteria() {
        List<String> statuses = Arrays.asList("NEW", "IN_PROCESS");
        List<ProcessorTransaction> expected = Collections.singletonList(new ProcessorTransaction());
        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);

        when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction")))
                .thenReturn(expected);

        List<ProcessorTransaction> result =
                processorService.getAllProcessorTransactionInStatus(statuses, "serverA", 2);

        assertSame(expected, result);
        verify(mongoTemplate).find(queryCaptor.capture(), eq(ProcessorTransaction.class), eq("processorTransaction"));
        assertTrue(queryCaptor.getValue().getQueryObject().toString().contains("dateModified"));
    }

    @Test
    public void getAllProcessorTransactionInStatus_withStatusListAndNonPositiveOffset_shouldNotUseDateModifiedCriteria() {
        List<String> statuses = Arrays.asList("NEW", "IN_PROCESS");
        List<ProcessorTransaction> expected = Collections.singletonList(new ProcessorTransaction());
        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);

        when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction")))
                .thenReturn(expected);

        List<ProcessorTransaction> result =
                processorService.getAllProcessorTransactionInStatus(statuses, "serverA", 0);

        assertSame(expected, result);
        verify(mongoTemplate).find(queryCaptor.capture(), eq(ProcessorTransaction.class), eq("processorTransaction"));
        assertFalse(queryCaptor.getValue().getQueryObject().toString().contains("dateModified"));
    }

    @Test
    public void getAllProcessorTransactionInStatus_withStatusAndPositiveOffset_shouldUseDateModifiedCriteria() {
        List<ProcessorTransaction> expected = Collections.singletonList(new ProcessorTransaction());
        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);

        when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction")))
                .thenReturn(expected);

        List<ProcessorTransaction> result =
                processorService.getAllProcessorTransactionInStatus("IN_PROCESS", "serverA", 3);

        assertSame(expected, result);
        verify(mongoTemplate).find(queryCaptor.capture(), eq(ProcessorTransaction.class), eq("processorTransaction"));
        assertTrue(queryCaptor.getValue().getQueryObject().toString().contains("dateModified"));
    }

    @Test
    public void getAllProcessorTransactionInStatus_withStatusAndNonPositiveOffset_shouldNotUseDateModifiedCriteria() {
        List<ProcessorTransaction> expected = Collections.singletonList(new ProcessorTransaction());
        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);

        when(mongoTemplate.find(any(Query.class), eq(ProcessorTransaction.class), eq("processorTransaction")))
                .thenReturn(expected);

        List<ProcessorTransaction> result =
                processorService.getAllProcessorTransactionInStatus("IN_PROCESS", "serverA", 0);

        assertSame(expected, result);
        verify(mongoTemplate).find(queryCaptor.capture(), eq(ProcessorTransaction.class), eq("processorTransaction"));
        assertFalse(queryCaptor.getValue().getQueryObject().toString().contains("dateModified"));
    }

    @Test
    public void updateProcessorExecutionRecordOfProcessorTransactionRecord_shouldKeepFatalErrorStatus_forProcessorCoreJob() {
        ProcessorServiceImpl spyService = spy(processorService);

        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);

        Map<String, Object> resultMap = new HashMap<>();
        ProcessorCoreJob job = new ProcessorCoreJob();

        doReturn(processorTransaction).when(spyService)
                .updateProcessorTransactionMetaData(processorTransaction);

        try (MockedStatic<ProcessorUtil> mockedStatic = mockStatic(ProcessorUtil.class)) {
            mockedStatic.when(() ->
                    ProcessorUtil.setExecutionRecordForActiviti(processorTransaction, resultMap, job)
            ).thenAnswer(invocation -> null);

            ProcessorTransaction result = spyService
                    .updateProcessorExecutionRecordOfProcessorTransactionRecord(processorTransaction, resultMap, job);

            assertNotNull(result);
            assertSame(processorTransaction, result);
            assertEquals(MetaDataStatus.FATAL_ERROR, processorTransaction.getStatus());

            mockedStatic.verify(() ->
                    ProcessorUtil.setExecutionRecordForActiviti(processorTransaction, resultMap, job));
            verify(spyService).updateProcessorTransactionMetaData(processorTransaction);
        }
    }

    @Test
    public void updateProcessorExecutionRecordOfProcessorTransactionRecord_shouldKeepFatalErrorStatus_forRestApiJob() {
        ProcessorServiceImpl spyService = spy(processorService);

        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);

        Map<String, Object> resultMap = new HashMap<>();
        RestApiJob job = new RestApiJob();

        doReturn(processorTransaction).when(spyService)
                .updateProcessorTransactionMetaData(processorTransaction);

        try (MockedStatic<ProcessorUtil> mockedStatic = mockStatic(ProcessorUtil.class)) {
            mockedStatic.when(() ->
                    ProcessorUtil.setExecutionRecordForActiviti(processorTransaction, resultMap, job)
            ).thenAnswer(invocation -> null);

            ProcessorTransaction result = spyService
                    .updateProcessorExecutionRecordOfProcessorTransactionRecord(processorTransaction, resultMap, job);

            assertNotNull(result);
            assertSame(processorTransaction, result);
            assertEquals(MetaDataStatus.FATAL_ERROR, processorTransaction.getStatus());

            mockedStatic.verify(() ->
                    ProcessorUtil.setExecutionRecordForActiviti(processorTransaction, resultMap, job));
            verify(spyService).updateProcessorTransactionMetaData(processorTransaction);
        }
    }

    @Test
    public void deleteProcessorMapping_shouldIncludeAppIdentifier_whenProvided() {
        ProcessorMapping expected = new ProcessorMapping();
        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);

        when(mongoTemplate.findAndRemove(any(Query.class), eq(ProcessorMapping.class), eq("processor")))
                .thenReturn(expected);

        ProcessorMapping result = processorService.deleteProcessorMapping("app-1", 10);

        assertSame(expected, result);
        verify(mongoTemplate).findAndRemove(queryCaptor.capture(), eq(ProcessorMapping.class), eq("processor"));
        String queryString = queryCaptor.getValue().getQueryObject().toString();
        assertTrue(queryString.contains("spaceId"));
        assertTrue(queryString.contains("appIdentifier"));
    }

    @Test
    public void deleteProcessorMapping_shouldNotIncludeAppIdentifier_whenBlank() {
        ProcessorMapping expected = new ProcessorMapping();
        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);

        when(mongoTemplate.findAndRemove(any(Query.class), eq(ProcessorMapping.class), eq("processor")))
                .thenReturn(expected);

        ProcessorMapping result = processorService.deleteProcessorMapping("", 10);

        assertSame(expected, result);
        verify(mongoTemplate).findAndRemove(queryCaptor.capture(), eq(ProcessorMapping.class), eq("processor"));
        String queryString = queryCaptor.getValue().getQueryObject().toString();
        assertTrue(queryString.contains("spaceId"));
        assertFalse(queryString.contains("appIdentifier"));
    }

    @Test
    public void getProcessorTransactionById_shouldReturnFirstTransaction_whenTransactionsExist() {
        Query mockedQuery = new Query();
        ProcessorTransaction first = new ProcessorTransaction();
        first.setId("txn-1");
        ProcessorTransaction second = new ProcessorTransaction();
        second.setId("txn-2");

        try (MockedStatic<ProcessorUtil> processorUtilMock = mockStatic(ProcessorUtil.class)) {
            processorUtilMock.when(() -> ProcessorUtil.getProcessorById("txn-123"))
                    .thenReturn(mockedQuery);

            when(mongoTemplate.find(eq(mockedQuery), eq(ProcessorTransaction.class), eq("processorTransaction")))
                    .thenReturn(Arrays.asList(first, second));

            ProcessorTransaction result = processorService.getProcessorTransactionById("txn-123");

            assertNotNull(result);
            assertSame(first, result);

            processorUtilMock.verify(() -> ProcessorUtil.getProcessorById("txn-123"));
            verify(mongoTemplate).find(eq(mockedQuery), eq(ProcessorTransaction.class), eq("processorTransaction"));
        }
    }

    @Test
    public void setAckStatus_shouldUpdateAckStatus_whenIdIsValid() throws InvalidExpressionException {
        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
        ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);

        when(mongoTemplate.updateFirst(
                any(Query.class),
                any(Update.class),
                eq(ProcessorMetaData.class),
                eq(Workflow.PROCESSOR_TRANSACTION)))
                .thenReturn(null);

        processorService.setAckStatus("507f191e810c19729de860ea", "ACKED");

        verify(mongoTemplate).updateFirst(
                queryCaptor.capture(),
                updateCaptor.capture(),
                eq(ProcessorMetaData.class),
                eq(Workflow.PROCESSOR_TRANSACTION));

        assertTrue(queryCaptor.getValue().getQueryObject().toString().contains("507f191e810c19729de860ea"));
        assertTrue(updateCaptor.getValue().getUpdateObject().toString().contains("ackStatus"));
        assertTrue(updateCaptor.getValue().getUpdateObject().toString().contains("ACKED"));
    }

}


