package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.DocvaultTransaction;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.Date;
import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DocvaultTransactionServiceImplTest {

    @Mock
    private MongoTemplate mongoTemplate;

    @InjectMocks
    private DocvaultTransactionServiceImpl docvaultTransactionService;

    private DocvaultTransaction testTransaction;

    @Before
    public void setUp() {
        testTransaction = new DocvaultTransaction();
        testTransaction.setDateSent(new Date());
        testTransaction.setDocumentId("temporaryDoc 1234");
        testTransaction.setFileName("temporary filename");
        testTransaction.setId("ID:1");
        testTransaction.setFsId("FSID:1");
        testTransaction.setPodName("PODName: pod1");
        testTransaction.setResponseCode(123);
        testTransaction.setSpaceId(1);
        testTransaction.setResponseMsg("DocVaultTransaction made");
        testTransaction.setErrorMap(new HashMap<>());
    }

    @Test
    public void testInsert() {
        when(mongoTemplate.insert(any(DocvaultTransaction.class))).thenReturn(testTransaction);
        String result = docvaultTransactionService.insert(testTransaction);
        assertNotNull(result);
        assertEquals("ID:1", result);
    }
}