package com.optum.fds.paperless.domain.service.exception;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class ServiceExceptionTest {

    @Test
    public void testDefaultConstructor() {
        ServiceException exception = new ServiceException();
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
        assertEquals(0, exception.getErrorCode());
    }

    @Test
    public void testConstructorWithErrorCodeAndMessageAndCause() {
        Throwable cause = new Throwable("Cause");
        ServiceException exception = new ServiceException(404, "Not Found", cause);
        assertEquals(404, exception.getErrorCode());
        assertEquals("Not Found", exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithErrorCodeAndCause() {
        Throwable cause = new Throwable("Cause");
        ServiceException exception = new ServiceException(500, cause);
        assertEquals(500, exception.getErrorCode());
        assertEquals(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithErrorCodeAndMessage() {
        ServiceException exception = new ServiceException(400, "Bad Request");
        assertEquals(400, exception.getErrorCode());
        assertEquals("Bad Request", exception.getMessage());
    }

    @Test
    public void testConstructorWithErrorCode() {
        ServiceException exception = new ServiceException(401);
        assertEquals(401, exception.getErrorCode());
        assertEquals("", exception.getMessage());
    }

    @Test
    public void testConstructorWithMessageAndCause() {
        Throwable cause = new Throwable("Cause");
        ServiceException exception = new ServiceException("Error occurred", cause);
        assertEquals("Error occurred", exception.getMessage());
        assertEquals(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithMessage() {
        ServiceException exception = new ServiceException("Error occurred");
        assertEquals("Error occurred", exception.getMessage());
    }

    @Test
    public void testConstructorWithCause() {
        Throwable cause = new Throwable("Cause");
        ServiceException exception = new ServiceException(cause);
        assertEquals(cause, exception.getCause());
    }
}