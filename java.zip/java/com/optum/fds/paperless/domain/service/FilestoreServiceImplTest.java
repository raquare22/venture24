package com.optum.fds.paperless.domain.service;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;

@RunWith(MockitoJUnitRunner.class)
public class FilestoreServiceImplTest {

    @InjectMocks
    private FilestoreServiceImpl filestoreService;

    @Mock
    private AmazonS3 amazonS3;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(filestoreService, "awsS3Bucket", "test-bucket");
        ReflectionTestUtils.setField(filestoreService, "awsS3Access", "access-key");
        ReflectionTestUtils.setField(filestoreService, "awsS3Secret", "secret-key");
        ReflectionTestUtils.setField(filestoreService, "awsS3Url", "http://localhost:9000");
        ReflectionTestUtils.setField(filestoreService, "awsS3Region", "us-east-1");
        ReflectionTestUtils.setField(filestoreService, "amazonS3", amazonS3);
    }

    @Test
    public void init_ShouldCreateAmazonS3Client() {
        ReflectionTestUtils.setField(filestoreService, "amazonS3", null);

        filestoreService.init();

        Object client = ReflectionTestUtils.getField(filestoreService, "amazonS3");
        assertNotNull(client);
        assertTrue(client instanceof AmazonS3);
    }

    @Test
    public void insertFile_ShouldReturnTrue_WhenPutObjectSucceeds() {
        String location = "/persistent/base/10502/ODAR_123";
        String fileName = "sample.csv";

        when(amazonS3.putObject(any(PutObjectRequest.class))).thenReturn(null);

        boolean result = filestoreService.insertFile(location, fileName);

        assertTrue(result);

        ArgumentCaptor<PutObjectRequest> captor = ArgumentCaptor.forClass(PutObjectRequest.class);
        org.mockito.Mockito.verify(amazonS3).putObject(captor.capture());
        PutObjectRequest request = captor.getValue();

        assertEquals("test-bucket/10502/ODAR_123", request.getBucketName());
        assertEquals(fileName, request.getKey());
        assertNotNull(request.getFile());
    }

    @Test
    public void insertFile_ShouldReturnFalse_WhenPutObjectThrowsException() {
        String location = "/persistent/base/10502/ODAR_123";
        String fileName = "sample.csv";

        when(amazonS3.putObject(any(PutObjectRequest.class)))
                .thenThrow(new RuntimeException("s3 failure"));

        boolean result = filestoreService.insertFile(location, fileName);

        assertFalse(result);
    }

    @Test
    public void downloadFile_ShouldReturnBytes_WhenGetObjectSucceeds() throws Exception {
        String filePath = "10502/ODAR_123/";
        String fileName = "sample.csv";
        byte[] expected = "hello".getBytes("UTF-8");

        S3Object s3Object = new S3Object();
        s3Object.setObjectContent(new com.amazonaws.util.StringInputStream("hello"));
        s3Object.setObjectMetadata(new ObjectMetadata());

        when(amazonS3.getObject(eq("test-bucket"), eq(filePath + fileName))).thenReturn(s3Object);

        byte[] result = filestoreService.downloadFile(filePath, fileName);

        assertNotNull(result);
        assertArrayEquals(expected, result);
    }

    @Test
    public void downloadFile_ShouldReturnNull_WhenGetObjectThrowsException() {
        String filePath = "10502/ODAR_123/";
        String fileName = "sample.csv";

        when(amazonS3.getObject(eq("test-bucket"), eq(filePath + fileName)))
                .thenThrow(new RuntimeException("download failure"));

        byte[] result = filestoreService.downloadFile(filePath, fileName);

        assertNull(result);
    }

    @Test
    public void deleteFile_ShouldReturnTrue_WhenDeleteSucceeds() {
        String bucket = "bucket-1";
        String key = "file.csv";

        boolean result = filestoreService.deleteFile(bucket, key);

        assertTrue(result);
        ArgumentCaptor<DeleteObjectRequest> captor = ArgumentCaptor.forClass(DeleteObjectRequest.class);
        org.mockito.Mockito.verify(amazonS3).deleteObject(captor.capture());
        assertEquals(bucket, captor.getValue().getBucketName());
        assertEquals(key, captor.getValue().getKey());
    }

    @Test
    public void deleteFile_ShouldReturnFalse_WhenDeleteThrowsException() {
        String bucket = "bucket-1";
        String key = "file.csv";

        org.mockito.Mockito.doThrow(new RuntimeException("delete failure"))
                .when(amazonS3).deleteObject(any(DeleteObjectRequest.class));

        boolean result = filestoreService.deleteFile(bucket, key);

        assertFalse(result);
    }

    @Test
    public void getBucketFilePathFromLocation_ShouldReturnExpectedPath() {
        String location = "/persistent/base/10502/ODAR_18804100_20220208090930_SMALLBOUNCETEST3";

        String result = filestoreService.getBucketFilePathFromLocation(location);

        assertEquals("10502/ODAR_18804100_20220208090930_SMALLBOUNCETEST3", result);
    }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void getBucketFilePathFromLocation_ShouldThrowException_WhenLocationIsInvalid() {
        filestoreService.getBucketFilePathFromLocation("/too/short");
    }
}