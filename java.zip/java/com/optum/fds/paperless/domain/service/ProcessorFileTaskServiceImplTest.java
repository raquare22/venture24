package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorTargetType;
import org.bson.types.ObjectId;
import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;

import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.jobs.RestApiJob;
import com.optum.fds.paperless.mongo.jobs.ProcessorCoreJob;

import org.springframework.dao.DataAccessException;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

public class ProcessorFileTaskServiceImplTest {

    @Mock
    private MongoTemplate mongoTemplate;

    private ProcessorFileTaskServiceImpl processorFileTaskService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        processorFileTaskService = new ProcessorFileTaskServiceImpl();
        ReflectionTestUtils.setField(processorFileTaskService, "mongoTemplate", mongoTemplate);
    }

    @Test
    public void getProcessorFileTaskById_ReturnsProcessorFileTaskWhenExists() {
        String processorFileTaskId = "123";
        String appIdentifier = "testApp";
        ProcessorFileTask expectedTask = new ProcessorFileTask();
        expectedTask.setId(processorFileTaskId);
        expectedTask.setAppIdentifier(appIdentifier);

        Query query = new Query();
        query.addCriteria(
                Criteria.where("id").is(processorFileTaskId)
                        .and("appIdentifier").is(appIdentifier)
        );

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(Collections.singletonList(expectedTask));

        ProcessorFileTask actualTask = processorFileTaskService.getProcessorFileTaskById(processorFileTaskId, appIdentifier);

        assertNotNull(actualTask);
        assertEquals(expectedTask.getId(), actualTask.getId());
        assertEquals(expectedTask.getAppIdentifier(), actualTask.getAppIdentifier());
    }

    @Test
    public void getProcessorFileTaskById_ReturnsNullWhenNotExists() {
        String processorFileTaskId = "123";
        String appIdentifier = "testApp";

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(Collections.emptyList());

        ProcessorFileTask actualTask = processorFileTaskService.getProcessorFileTaskById(processorFileTaskId, appIdentifier);

        assertNull(actualTask);
    }

    @Test
    public void updateProcessorExecutionRecordOfProcessorFileTaskRecord_WithProcessorCoreJob_ReturnsUpdatedTask() {
        ProcessorFileTask processorFileTask = new ProcessorFileTask();
        Map<String, Object> resultMap = new HashMap<>();
        ProcessorCoreJob job = new ProcessorCoreJob();

        when(mongoTemplate.save(any(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(processorFileTask);

        ProcessorFileTask updatedTask = processorFileTaskService.updateProcessorExecutionRecordOfProcessorFileTaskRecord(processorFileTask, resultMap, job);

        assertNotNull(updatedTask);
        verify(mongoTemplate, times(1)).save(any(ProcessorFileTask.class), eq("processorFileTask"));
    }

    @Test
    public void updateProcessorExecutionRecordOfProcessorFileTaskRecord_WithRestApiJob_ReturnsUpdatedTask() {
        ProcessorFileTask processorFileTask = new ProcessorFileTask();
        Map<String, Object> resultMap = new HashMap<>();
        RestApiJob job = new RestApiJob();

        when(mongoTemplate.save(any(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(processorFileTask);

        ProcessorFileTask updatedTask = processorFileTaskService.updateProcessorExecutionRecordOfProcessorFileTaskRecord(processorFileTask, resultMap, job);

        assertNotNull(updatedTask);
        verify(mongoTemplate, times(1)).save(any(ProcessorFileTask.class), eq("processorFileTask"));
    }

    @Test
    public void updateProcessorFileTask_ReturnsUpdatedTask() {
        ProcessorFileTask processorFileTask = new ProcessorFileTask();
        processorFileTask.setId("123");
        processorFileTask.setAppIdentifier("testApp");

        when(mongoTemplate.save(any(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(processorFileTask);

        ProcessorFileTask updatedTask = processorFileTaskService.updateProcessorFileTask(processorFileTask);

        assertNotNull(updatedTask);
        verify(mongoTemplate, times(1)).save(any(ProcessorFileTask.class), eq("processorFileTask"));
    }

    @Test
    public void updateProcessorFileTaskWithKeyValue_ReturnsUpdatedTask() {
        String id = "123";
        String appId = "testApp";
        String key = "status";
        String value = "COMPLETE";
        ProcessorFileTask expectedTask = new ProcessorFileTask();
        expectedTask.setId(id);
        expectedTask.setAppIdentifier(appId);
        expectedTask.setStatus(MetaDataStatus.COMPLETE);

        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(expectedTask);

        ProcessorFileTask updatedTask = processorFileTaskService.updateProcessorFileTask(id, appId, key, value);

        assertNotNull(updatedTask);
        assertEquals(expectedTask.getId(), updatedTask.getId());
        assertEquals(expectedTask.getAppIdentifier(), updatedTask.getAppIdentifier());
        assertEquals(expectedTask.getStatus(), updatedTask.getStatus());
        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
        verify(mongoTemplate, times(1)).findAndModify(queryCaptor.capture(), any(Update.class), eq(ProcessorFileTask.class), eq("processorFileTask"));
        Query query = queryCaptor.getValue();

        assertNotNull(query);
        assertEquals(id, query.getQueryObject().get("id"));
        assertEquals(appId, query.getQueryObject().get("appIdentifier"));
    }

    @Test
    public void getProcessorFileTask_ReturnsProcessorFileTask() {
        ObjectId id = new ObjectId();
        String appIdentifier = "testApp";
        String serverType = "testServer";
        ProcessorFileTask expectedTask = new ProcessorFileTask();
        expectedTask.setId(id.toString());
        expectedTask.setAppIdentifier(appIdentifier);
        expectedTask.setServerType(serverType);

        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id.toString())
                .and("appIdentifier").is(appIdentifier)
                .and("serverType").is(serverType));

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(Collections.singletonList(expectedTask));

        ProcessorFileTask actualTask = processorFileTaskService.getProcessorFileTask(id.toString(), appIdentifier, serverType);

        assertNotNull(actualTask);
        assertEquals(expectedTask.getId(), actualTask.getId());
        assertEquals(expectedTask.getAppIdentifier(), actualTask.getAppIdentifier());
        assertEquals(expectedTask.getServerType(), actualTask.getServerType());
    }

    @Test
    public void getProcessorFileTask_ReturnsNullWhenTaskNotFound() {
        String id = new ObjectId().toString();
        String appIdentifier = "testApp";
        String serverType = "testServer";

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(Collections.emptyList());

        ProcessorFileTask actualTask = processorFileTaskService.getProcessorFileTask(id, appIdentifier, serverType);

        assertNull(actualTask);
    }

    @Test
    public void getProcessorFileTaskForTargetId_ReturnsTaskWhenExists() {
        String targetId = "target123";
        String targetType = "attachments";
        String appIdentifier = "testApp";
        ProcessorFileTask expectedTask = new ProcessorFileTask();
        expectedTask.setTargetId(targetId);
        expectedTask.setTargetType(ProcessorTargetType.attachments);
        expectedTask.setAppIdentifier(appIdentifier);

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(Collections.singletonList(expectedTask));

        ProcessorFileTask actualTask = processorFileTaskService.getProcessorFileTaskForTargetId(targetId, targetType, appIdentifier);

        assertNotNull(actualTask);
        assertEquals(expectedTask.getTargetId(), actualTask.getTargetId());
        assertEquals(expectedTask.getTargetType(), actualTask.getTargetType());
        assertEquals(expectedTask.getAppIdentifier(), actualTask.getAppIdentifier());
    }

    @Test
    public void getProcessorFileTaskForTargetId_ReturnsNullWhenNotExists() {
        String targetId = "target123";
        String targetType = "attachments";
        String appIdentifier = "testApp";

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(Collections.emptyList());

        ProcessorFileTask actualTask = processorFileTaskService.getProcessorFileTaskForTargetId(targetId, targetType, appIdentifier);

        assertNull(actualTask);
    }

    @Test
    public void saveProcessorFileTask_ReturnsSavedTask() {
        ProcessorFileTask processorFileTask = new ProcessorFileTask();
        processorFileTask.setId("123");
        processorFileTask.setAppIdentifier("testApp");

        when(mongoTemplate.save(any(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(processorFileTask);

        ProcessorFileTask savedTask = processorFileTaskService.saveProcessorFileTask(processorFileTask);

        assertNotNull(savedTask);
        verify(mongoTemplate, times(1)).save(any(ProcessorFileTask.class), eq("processorFileTask"));
    }

    @Test
    public void getProcessorFileTasksForTransactionId_ReturnsTaskList() {
        String transactionId = "trans123";
        String serverType = "testServer";
        List<ProcessorFileTask> expectedTasks = Arrays.asList(new ProcessorFileTask(), new ProcessorFileTask());

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(expectedTasks);

        List<ProcessorFileTask> actualTasks = processorFileTaskService.getProcessorFileTasksForTransactionId(transactionId, serverType);

        assertNotNull(actualTasks);
        assertEquals(expectedTasks.size(), actualTasks.size());
    }

    @Test
    public void getProcessorFileTasksForTransactionIdByStatus_ReturnsTaskList() {
        String transactionId = "trans123";
        String status = "COMPLETE";
        List<ProcessorFileTask> expectedTasks = Arrays.asList(new ProcessorFileTask(), new ProcessorFileTask());

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(expectedTasks);

        List<ProcessorFileTask> actualTasks = processorFileTaskService.getProcessorFileTasksForTransactionIdByStatus(transactionId, status);

        assertNotNull(actualTasks);
        assertEquals(expectedTasks.size(), actualTasks.size());
    }

    @Test
    public void getLastProcessorFileTaskForTransactionId_ReturnsTaskList() {
        String transactionId = "trans123";
        String serverType = "testServer";
        List<ProcessorFileTask> expectedTasks = Arrays.asList(new ProcessorFileTask());

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(expectedTasks);

        List<ProcessorFileTask> actualTasks = processorFileTaskService.getLastProcessorFileTaskForTransactionId(transactionId, serverType);

        assertNotNull(actualTasks);
        assertEquals(expectedTasks.size(), actualTasks.size());
    }

    @Test
    public void getPendingProcessorFileTaskForTransactionId_ReturnsTaskList() {
        String transactionId = "trans123";
        String serverType = "testServer";
        String status = "NEW";
        int processorTransactionPendingTime = 60;
        List<ProcessorFileTask> expectedTasks = Arrays.asList(new ProcessorFileTask(), new ProcessorFileTask());

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(expectedTasks);

        List<ProcessorFileTask> actualTasks = processorFileTaskService.getPendingProcessorFileTaskForTransactionId(transactionId, serverType, status, processorTransactionPendingTime);

        assertNotNull(actualTasks);
        assertEquals(expectedTasks.size(), actualTasks.size());
    }

    @Test
    public void areAllProcessorFileTasksCompletedForTransactionId_ReturnsTrueWhenAllCompleted() {
        String transactionId = "trans123";

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(Collections.emptyList());

        boolean allCompleted = processorFileTaskService.areAllProcessorFileTasksCompletedForTransactionId(transactionId);

        assertTrue(allCompleted);
    }

    @Test
    public void areAllProcessorFileTasksCompletedForTransactionId_ReturnsFalseWhenNotCompleted() {
        String transactionId = "trans123";
        List<ProcessorFileTask> tasks = Collections.singletonList(new ProcessorFileTask());

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask"))).thenReturn(tasks);

        boolean allCompleted = processorFileTaskService.areAllProcessorFileTasksCompletedForTransactionId(transactionId);

        assertFalse(allCompleted);
    }

    @Test(expected = DataAccessException.class)
    public void getProcessorFileTaskById_ThrowsExceptionWhenMongoTemplateFails() {
        String processorFileTaskId = "123";
        String appIdentifier = "testApp";

        Query query = new Query();
        query.addCriteria(
                Criteria.where("id").is(processorFileTaskId)
                        .and("appIdentifier").is(appIdentifier)
        );

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(new DataAccessException("Simulated exception") {});

        processorFileTaskService.getProcessorFileTaskById(processorFileTaskId, appIdentifier);
    }

    @Test(expected = DataAccessException.class)
    public void updateProcessorFileTaskWithKeyValue_ThrowsExceptionWhenMongoTemplateFails() {
        String id = "123";
        String appId = "testApp";
        String key = "status";
        String value = "COMPLETE";

        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(new DataAccessException("Simulated exception") {});

        processorFileTaskService.updateProcessorFileTask(id, appId, key, value);
    }

    @Test(expected = DataAccessException.class)
    public void getProcessorFileTask_ThrowsExceptionWhenMongoTemplateFails() {
        String id = new ObjectId().toString();
        String appIdentifier = "testApp";
        String serverType = "testServer";

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(new DataAccessException("Simulated exception") {});

        processorFileTaskService.getProcessorFileTask(id, appIdentifier, serverType);
    }

    @Test(expected = DataAccessException.class)
    public void getProcessorFileTasksForTransactionId_ThrowsExceptionWhenMongoTemplateFails() {
        String transactionId = "trans123";
        String serverType = "testServer";

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(new DataAccessException("Simulated exception") {});

        processorFileTaskService.getProcessorFileTasksForTransactionId(transactionId, serverType);
    }

    @Test(expected = DataAccessException.class)
    public void getProcessorFileTasksForTransactionIdByStatus_ThrowsExceptionWhenMongoTemplateFails() {
        String transactionId = "trans123";
        String status = "COMPLETE";

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(new DataAccessException("Simulated exception") {});

        processorFileTaskService.getProcessorFileTasksForTransactionIdByStatus(transactionId, status);
    }

    @Test(expected = DataAccessException.class)
    public void getLastProcessorFileTaskForTransactionId_ThrowsExceptionWhenMongoTemplateFails() {
        String transactionId = "trans123";
        String serverType = "testServer";

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(new DataAccessException("Simulated exception") {});

        processorFileTaskService.getLastProcessorFileTaskForTransactionId(transactionId, serverType);
    }

    @Test(expected = DataAccessException.class)
    public void getPendingProcessorFileTaskForTransactionId_ThrowsExceptionWhenMongoTemplateFails() {
        String transactionId = "trans123";
        String serverType = "testServer";
        String status = "NEW";
        int processorTransactionPendingTime = 60;

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(new DataAccessException("Simulated exception") {});

        processorFileTaskService.getPendingProcessorFileTaskForTransactionId(transactionId, serverType, status, processorTransactionPendingTime);
    }

    @Test
    public void areAllProcessorFileTasksCompletedForTransactionId_HandlesException() {
        String transactionId = "trans123";

        when(mongoTemplate.find(any(Query.class), eq(ProcessorFileTask.class), eq("processorFileTask")))
                .thenThrow(new DataAccessException("Simulated exception") {});

        boolean allCompleted = processorFileTaskService.areAllProcessorFileTasksCompletedForTransactionId(transactionId);

        assertFalse(allCompleted);
    }
}