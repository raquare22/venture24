	package com.optum.fds.paperless.domain.service;
	
	import static org.junit.Assert.assertNotNull;
	
	import java.util.ArrayList;
	import java.util.List;
	
	import org.junit.Test;
	import org.junit.runner.RunWith;
	import org.mockito.InjectMocks;
	import org.mockito.Mock;
	import org.mockito.junit.MockitoJUnitRunner;
	import org.springframework.data.mongodb.core.MongoTemplate;

	import com.optum.fds.paperless.junit.references.RallyTestCase;
	import com.optum.fds.paperless.junit.references.UserStory;
	import com.optum.fds.paperless.mongo.AttachmentMetaData;
	import com.optum.fds.paperless.mongo.Transaction;
	import com.optum.fds.paperless.mongo.TransactionAttachmentInfo;
	import com.optum.fds.paperless.mongo.TransactionDocumentInfo;
	import com.optum.fds.paperless.mongo.TransactionDocumentListInfo;
	import com.optum.fds.paperless.mongo.TransactionHookInfo;
	import com.optum.fds.paperless.mongo.TransactionHookListInfo;
	import com.optum.fds.paperless.mongo.TransactionListAttachmentsInfo;
	import com.optum.fds.paperless.mongo.TransactionReportInfo;
	import com.optum.fds.paperless.mongo.TransactionReportListInfo;
	
	import static org.junit.Assert.assertNotNull;
	import static org.junit.Assert.assertNull;
	import static org.mockito.ArgumentMatchers.any;
	import static org.mockito.ArgumentMatchers.anyString;
	import static org.mockito.ArgumentMatchers.eq;
	import static org.mockito.Mockito.doNothing;
	import static org.mockito.Mockito.when;
	
	@RunWith(MockitoJUnitRunner.class)
	
	public class TransactionServiceTest {
		@Mock
		MongoTemplate mongoTemplate;
		
		@InjectMocks
		TransactionServiceImpl transactionService;
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testGetTransactionMetaData() {
			TransactionServiceImpl transactionServiceImpl=new TransactionServiceImpl();
			Transaction transaction=transactionServiceImpl.getTransactionMetaData("test");
			assertNotNull(transaction);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testsaveTransactionMetaData() {
			Transaction t=new Transaction();
			when(mongoTemplate.save(any(Transaction.class))).thenReturn(t);
			Transaction result=transactionService.saveTransactionMetaData(new Transaction());
			assertNotNull(result);
			assertNotNull(t);

		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testInsertTransactionMetaData() {
			TransactionServiceImpl transactionServiceImpl=new TransactionServiceImpl();
			Transaction transactionMetadata=new Transaction();
			transactionMetadata.setTransactionId("test");
			Transaction transaction=transactionServiceImpl.insertTransactionMetaData(transactionMetadata);
			assertNotNull(transaction);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testInsertTransactionMetaDataTransactionIdNull() {
			TransactionServiceImpl transactionServiceImpl=new TransactionServiceImpl();
			Transaction transactionMetadata=new Transaction();
			Transaction transaction=transactionServiceImpl.insertTransactionMetaData(transactionMetadata);
			assertNotNull(transaction);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testSaveTransactionMetaDataTransactionAttachmentInfo() {
			TransactionServiceImpl transactionServiceImpl=new TransactionServiceImpl();
			TransactionAttachmentInfo transactionAttachmentInfo=new TransactionAttachmentInfo();
			transactionAttachmentInfo.setExternalId("externalId");
			List<TransactionAttachmentInfo> list=new ArrayList<>();
			Transaction transaction=transactionServiceImpl.saveTransationMetaData("testTransactionId",list);
			assertNotNull(transaction);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testSaveTransactionMetaDataAttachmentMetadataInfo() {
			AttachmentMetaData attachmentMetaData=new AttachmentMetaData();
			attachmentMetaData.setClientId(0);
			attachmentMetaData.setSpaceId(0);
			List<AttachmentMetaData> attachmentMetaDataList=new ArrayList<>();
			TransactionServiceImpl transactionServiceImpl=new TransactionServiceImpl();
			TransactionAttachmentInfo transactionAttachmentInfo=new TransactionAttachmentInfo();
			transactionAttachmentInfo.setExternalId("externalId");
			List<TransactionAttachmentInfo> list=new ArrayList<>();
			list.add(transactionAttachmentInfo);
			attachmentMetaDataList.add(attachmentMetaData);
			Transaction transaction=transactionServiceImpl.saveTransationMetaData("testTransactionId",list,attachmentMetaDataList,true);
			assertNotNull(transaction);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testSaveTransactionAttachmentListNull() {
			AttachmentMetaData attachmentMetaData=new AttachmentMetaData();
			attachmentMetaData.setClientId(0);
			attachmentMetaData.setSpaceId(0);
			List<AttachmentMetaData> attachmentMetaDataList=new ArrayList<>();
			TransactionServiceImpl transactionServiceImpl=new TransactionServiceImpl();
			TransactionAttachmentInfo transactionAttachmentInfo=new TransactionAttachmentInfo();
			transactionAttachmentInfo.setExternalId("externalId");
			List<TransactionAttachmentInfo> list=new ArrayList<>();
			attachmentMetaDataList.add(attachmentMetaData);
			Transaction transaction=transactionServiceImpl.saveTransationMetaData("testTransactionId",list,attachmentMetaDataList,true);
			assertNotNull(transaction);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testSaveTransactionAttachmentList() {
			TransactionListAttachmentsInfo transactionListAttachmentsInfo=new TransactionListAttachmentsInfo();
			TransactionServiceImpl transactionServiceImpl=new TransactionServiceImpl();
			TransactionAttachmentInfo transactionAttachmentInfo=new TransactionAttachmentInfo();
			transactionAttachmentInfo.setExternalId("externalId");
			List<TransactionAttachmentInfo> list=new ArrayList<>();
			list.add(transactionAttachmentInfo);
			transactionListAttachmentsInfo.setAttachments(list);
			Transaction transaction=transactionServiceImpl.saveTransationMetaData("testTransactionId",transactionListAttachmentsInfo,1,"1");
			assertNotNull(transaction);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testSavetrnsctnDocListInfo() {
			TransactionDocumentListInfo transactionListAttachmentsInfo=new TransactionDocumentListInfo();
			TransactionServiceImpl transactionServiceImpl=new TransactionServiceImpl();
			TransactionDocumentInfo transactionAttachmentInfo=new TransactionDocumentInfo();
			transactionAttachmentInfo.setExternalId("externalId");
			transactionListAttachmentsInfo.add(transactionAttachmentInfo);
			Transaction transaction=transactionServiceImpl.saveTransationMetaData("testTransactionId",1,1,transactionListAttachmentsInfo);
			assertNotNull(transaction);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testSavetrnsctnHookListInfo() {
			TransactionHookListInfo transactionHookListInfo =new TransactionHookListInfo();
			TransactionServiceImpl transactionServiceImpl=new TransactionServiceImpl();
			TransactionHookInfo transactionHookInfo=new TransactionHookInfo();
			transactionHookInfo.setExternalId("externalId");
			transactionHookListInfo.add(transactionHookInfo);
			Transaction transaction=transactionServiceImpl.saveTransationMetaData("testTransactionId",1,1,transactionHookListInfo);
			assertNotNull(transaction);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testSavetrnsctnHookListInfoNullHook() {
			TransactionHookListInfo transactionHookListInfo =new TransactionHookListInfo();
			TransactionServiceImpl transactionServiceImpl=new TransactionServiceImpl();
			Transaction transaction=transactionServiceImpl.saveTransationMetaData("testTransactionId",1,1,transactionHookListInfo);
			assertNotNull(transaction);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testSavetrnsctnReportListInfo() {
			TransactionReportListInfo transactionReportListInfo=new TransactionReportListInfo();
			TransactionServiceImpl transactionServiceImpl=new TransactionServiceImpl();
			TransactionReportInfo transactionReportInfo =new TransactionReportInfo();
			transactionReportInfo.setExternalId("externalId");
			transactionReportListInfo.add(transactionReportInfo);
			Transaction transaction=transactionServiceImpl.saveTransationMetaData("testTransactionId",1,1,transactionReportListInfo);
			assertNotNull(transaction);
		}
		
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32977")
		@Test
		public void testSetMongoTemplate() {
			TransactionServiceImpl transactionServiceImpl=new TransactionServiceImpl();
			transactionServiceImpl.setMongoTemplate(mongoTemplate);
		}
		}
