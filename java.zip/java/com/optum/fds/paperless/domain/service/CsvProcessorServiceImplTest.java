package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorRowTask;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.jobs.ProcessorJob;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

public class CsvProcessorServiceImplTest {

    @Mock
    private MongoTemplate mongoTemplate;

    @InjectMocks
    private CsvProcessorServiceImpl csvProcessorService;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindProcessorMetaDataById() {
        String processorId = "testId";
        ProcessorMetaData pmd = new ProcessorMetaData();
        when(mongoTemplate.findOne(any(Query.class), eq(ProcessorMetaData.class), any(String.class))).thenReturn(pmd);

        ProcessorMetaData result = csvProcessorService.findProcessorMetaDataById(processorId);
        assertNotNull(result);
        assertEquals(pmd, result);
    }

    @Test
    public void testFindProcessorMetaDataByFileName() {
        String csvFilename = "testFile.csv";
        String appId = "testApp";
        ProcessorMetaData pmd = new ProcessorMetaData();
        when(mongoTemplate.findOne(any(Query.class), eq(ProcessorMetaData.class), any(String.class))).thenReturn(pmd);

        ProcessorMetaData result = csvProcessorService.findProcessorMetaDataByFileName(csvFilename, appId);
        assertNotNull(result);
        assertEquals(pmd, result);
    }

    @Test
    public void testGetCsvProcessorRowTaskByProcessorTransactionIdRowNumber() {
        String id = "testId";
        Integer rowNumber = 1;
        CsvProcessorRowTask task = new CsvProcessorRowTask();
        when(mongoTemplate.find(any(Query.class), eq(CsvProcessorRowTask.class), any(String.class))).thenReturn(Collections.singletonList(task));

        CsvProcessorRowTask result = csvProcessorService.getCsvProcessorRowTaskByProcessorTransactionIdRowNumber(id, rowNumber);
        assertNotNull(result);
        assertEquals(task, result);
    }

    @Test
    public void testSaveCsvProcessorTransactionMetaData() {
        CsvProcessorTransaction transaction = new CsvProcessorTransaction();
        when(mongoTemplate.save(transaction, "csvProcessorTransaction")).thenReturn(transaction);

        CsvProcessorTransaction result = csvProcessorService.saveCsvProcessorTransactionMetaData(transaction);
        assertNotNull(result);
        assertEquals(transaction, result);
    }

    @Test
    public void testUpdateProcessorExecutionRecordOfCsvProcessorTransactionRecord() {
        CsvProcessorTransaction transaction = new CsvProcessorTransaction();
        transaction.setStatus(MetaDataStatus.IN_PROCESS);
        Map<String, Object> resultMap = new HashMap<>();
        ProcessorJob job = new ProcessorJob();

        CsvProcessorTransaction result = csvProcessorService.updateProcessorExecutionRecordOfCsvProcessorTransactionRecord(transaction, resultMap, job);
        assertNotNull(result);
        assertEquals(MetaDataStatus.IN_PROCESS, result.getStatus());
    }

    @Test
    public void testGetAllCsvProcessorTransactionInStatus() {
        String status = "IN_PROCESS";
        List<CsvProcessorTransaction> transactions = new ArrayList<>();
        when(mongoTemplate.find(any(Query.class), eq(CsvProcessorTransaction.class), any(String.class))).thenReturn(transactions);

        List<CsvProcessorTransaction> result = csvProcessorService.getAllCsvProcessorTransactionInStatus(status, "serverType");
        assertNotNull(result);
        assertEquals(transactions, result);
    }

    @Test
    public void testSaveCsvRecord() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        when(mongoTemplate.insert(documentMetaData, "document")).thenReturn(documentMetaData);

        DocumentMetaData result = csvProcessorService.saveCsvRecord(documentMetaData);
        assertNotNull(result);
        assertEquals(documentMetaData, result);
    }

    @Test
    public void testSaveRestApiJobRecord() {
        JobMetaData jobMetaData = new JobMetaData();
        when(mongoTemplate.insert(jobMetaData, "job")).thenReturn(jobMetaData);

        JobMetaData result = csvProcessorService.saveRestApiJobRecord(jobMetaData);
        assertNotNull(result);
        assertEquals(jobMetaData, result);
    }

    @Test
    public void testSaveCsvProcessorJobRecord() {
        JobMetaData jobMetaData = new JobMetaData();
        when(mongoTemplate.insert(jobMetaData, "job")).thenReturn(jobMetaData);

        JobMetaData result = csvProcessorService.saveCsvProcessorJobRecord(jobMetaData);
        assertNotNull(result);
        assertEquals(jobMetaData, result);
    }

    @Test
    public void testSaveCSVProcessor() {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        when(mongoTemplate.insert(processorMetaData)).thenReturn(processorMetaData);

        ProcessorMetaData result = csvProcessorService.saveCSVProcessor(processorMetaData);

        assertNotNull(result);
        assertEquals(processorMetaData, result);
    }

    @Test
    public void testUpdateCSVProcessorSuccess() {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setId("p123");

        Map<String, Object> config = new HashMap<>();
        config.put("k1", "v1");

        Map<String, Object> action = new HashMap<>();
        action.put("config", config);

        Map<String, Object> csvProcessor = new HashMap<>();
        csvProcessor.put("action", action);

        Map<String, Object> map = new HashMap<>();
        map.put("csvProcessor", csvProcessor);

        csvProcessorService.updateCSVProcessor(processorMetaData, map);

        Mockito.verify(mongoTemplate, Mockito.times(1))
                .updateFirst(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class),
                        eq(ProcessorMetaData.class), eq(String.valueOf(processorMetaData)));
    }

    @Test(expected = RuntimeException.class)
    public void testUpdateCSVProcessorThrowsException() {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setId("p123");

        Map<String, Object> config = new HashMap<>();
        Map<String, Object> action = new HashMap<>();
        action.put("config", config);
        Map<String, Object> csvProcessor = new HashMap<>();
        csvProcessor.put("action", action);
        Map<String, Object> map = new HashMap<>();
        map.put("csvProcessor", csvProcessor);

        Mockito.doThrow(new RuntimeException("update failed"))
                .when(mongoTemplate)
                .updateFirst(any(Query.class), any(org.springframework.data.mongodb.core.query.Update.class),
                        eq(ProcessorMetaData.class), eq(String.valueOf(processorMetaData)));

        csvProcessorService.updateCSVProcessor(processorMetaData, map);
    }

    @Test
    public void testGetCSVProcessorByIdFound() {
        String id = "proc-1";
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setId(id);

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), eq("csvProcessor")))
                .thenReturn(Collections.singletonList(processorMetaData));

        ProcessorMetaData result = csvProcessorService.getCSVProcessorById(id);

        assertNotNull(result);
        assertEquals(id, result.getId());
    }

    @Test
    public void testGetCSVProcessorByIdNotFound() {
        String id = "missing";

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), eq("csvProcessor")))
                .thenReturn(Collections.emptyList());

        ProcessorMetaData result = csvProcessorService.getCSVProcessorById(id);

        assertNull(result);
    }

    @Test(expected = RuntimeException.class)
    public void testGetCSVProcessorByIdThrowsException() {
        String id = "proc-ex";

        when(mongoTemplate.find(any(Query.class), eq(ProcessorMetaData.class), eq("csvProcessor")))
                .thenThrow(new RuntimeException("find failed"));

        csvProcessorService.getCSVProcessorById(id);
    }

    @Test
    public void testDeleteCSVProcessor() {
        String id = "proc-del";
        ProcessorMetaData updated = new ProcessorMetaData();
        updated.setId(id);
        updated.setStatus(MetaDataStatus.DELETED);

        when(mongoTemplate.findAndModify(
                any(Query.class),
                any(org.springframework.data.mongodb.core.query.Update.class),
                any(FindAndModifyOptions.class),
                eq(ProcessorMetaData.class),
                eq("csvProcessor")))
                .thenReturn(updated);

        ProcessorMetaData result = csvProcessorService.deleteCSVProcessor(id);

        assertNotNull(result);
        assertEquals(id, result.getId());
        assertEquals(MetaDataStatus.DELETED, result.getStatus());
    }

    @Test
    public void testSaveCSVProcessorMetaData() {
        // arrange
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setId("p-meta-1");

        when(mongoTemplate.save(processorMetaData, "csvProcessor")).thenReturn(processorMetaData);

        // act
        ProcessorMetaData result = csvProcessorService.saveCSVProcessorMetaData(processorMetaData);

        // assert
        assertNotNull(result);
        assertEquals(processorMetaData, result);
        Mockito.verify(mongoTemplate, Mockito.times(1))
                .save(processorMetaData, "csvProcessor");
    }

    @Test(expected = RuntimeException.class)
    public void testFindProcessorMetaDataByIdThrowsException() {
        // arrange
        String processorId = "p-ex-1";
        when(mongoTemplate.findOne(any(Query.class), eq(ProcessorMetaData.class), eq("csvProcessor")))
                .thenThrow(new RuntimeException("findOne failed"));

        // act
        csvProcessorService.findProcessorMetaDataById(processorId);
    }

    @Test(expected = RuntimeException.class)
    public void testFindProcessorMetaDataByFileNameThrowsException() {
        // arrange
        String fileName = "sample.csv";
        String appId = "app-1";
        when(mongoTemplate.findOne(any(Query.class), eq(ProcessorMetaData.class), eq("csvProcessor")))
                .thenThrow(new RuntimeException("findOne failed"));

        // act
        csvProcessorService.findProcessorMetaDataByFileName(fileName, appId);
    }

    @Test(expected = RuntimeException.class)
    public void testGetCsvProcessorRowTaskByProcessorTransactionIdRowNumberThrowsException() {
        // arrange
        String transactionId = "tx-1";
        Integer rowNumber = 1;

        when(mongoTemplate.find(any(Query.class), eq(CsvProcessorRowTask.class), eq("csvProcessorRowTask")))
                .thenThrow(new RuntimeException("find failed"));

        // act
        csvProcessorService.getCsvProcessorRowTaskByProcessorTransactionIdRowNumber(transactionId, rowNumber);
    }

    @Test(expected = RuntimeException.class)
    public void testGetCsvProcessorRowTaskByIdThrowsException() {
        // arrange
        String rowTaskId = "row-1";
        when(mongoTemplate.find(any(Query.class), eq(CsvProcessorRowTask.class), eq("csvProcessorRowTask")))
                .thenThrow(new RuntimeException("find failed"));

        // act
        csvProcessorService.getCsvProcessorRowTaskById(rowTaskId);
    }

    @Test
    public void testGetCsvProcessorRowTaskByServerType() {
        // arrange
        String id = "proc-1";
        String appIdentifier = "app-1";
        String serverType = "xaas";

        Query mockedQuery = new Query();
        CsvProcessorRowTask rowTask = new CsvProcessorRowTask();

        try (org.mockito.MockedStatic<com.optum.fds.paperless.util.ProcessorUtil> processorUtilMock =
                     Mockito.mockStatic(com.optum.fds.paperless.util.ProcessorUtil.class)) {

            processorUtilMock.when(() ->
                            com.optum.fds.paperless.util.ProcessorUtil.getProcessorByServerTypeQuery(id, appIdentifier, serverType))
                    .thenReturn(mockedQuery);

            when(mongoTemplate.find(eq(mockedQuery), eq(CsvProcessorRowTask.class), eq("csvProcessorRowTask")))
                    .thenReturn(Collections.singletonList(rowTask));

            // act
            CsvProcessorRowTask result = csvProcessorService.getCsvProcessorRowTask(id, appIdentifier, serverType);

            // assert
            assertNotNull(result);
            assertEquals(rowTask, result);

            processorUtilMock.verify(() ->
                    com.optum.fds.paperless.util.ProcessorUtil.getProcessorByServerTypeQuery(id, appIdentifier, serverType),
                    Mockito.times(1));

            Mockito.verify(mongoTemplate, Mockito.times(1))
                    .find(eq(mockedQuery), eq(CsvProcessorRowTask.class), eq("csvProcessorRowTask"));
        }
    }

    @Test(expected = RuntimeException.class)
    public void testGetCsvProcessorTransactionListThrowsException() {
        // selected private method getCsvProcessorTransactionList(...) is exercised via
        // public getAllCsvProcessorTransactionInStatus(...)
        when(mongoTemplate.find(any(Query.class), eq(CsvProcessorTransaction.class), eq("csvProcessorTransaction")))
                .thenThrow(new RuntimeException("find failed"));

        csvProcessorService.getAllCsvProcessorTransactionInStatus("IN_PROCESS", "xaas");
    }

    @Test(expected = RuntimeException.class)
    public void testGetCsvProcessorTransactionThrowsException() {
        // selected private method getCsvProcessorTransaction(...) is exercised via
        // public getCsvProcessorTransactionById(...)
        when(mongoTemplate.find(any(Query.class), eq(CsvProcessorTransaction.class), eq("csvProcessorTransaction")))
                .thenThrow(new RuntimeException("find failed"));

        csvProcessorService.getCsvProcessorTransactionById("tx-1");
    }
}