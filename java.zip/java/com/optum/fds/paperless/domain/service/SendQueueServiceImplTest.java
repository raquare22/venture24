package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.FDSHelper;
import com.optum.fds.paperless.exception.HttpServerException;
import com.optum.fds.paperless.exception.ProcessException;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.util.Parser;
import org.apache.commons.lang3.exception.ExceptionUtils;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.*;

public class SendQueueServiceImplTest {

    @Mock
    private ServiceBase serviceBase;

    @InjectMocks
    private SendQueueServiceImpl sendQueueService;
    
    
    private MockedStatic<FDSHelper> fdsHelperMock;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        
    }

    @Test
    public void testSendRequestToQueue() throws ProcessException, HttpServerException {
//        Integer spaceId = 1;
//        String identifier = "testIdentifier";
//        String targetId = "testTargetId";
//        String delegate = "testDelegate";
//        String callbackMapJson = "{}";
//
//        ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(new GenericResponse("200", "OK", "Success"), HttpStatus.OK);
//        when(serviceBase.postRequestToSvc(any(String.class), any(String.class), any(String.class))).thenReturn(responseEntity);
//
//        sendQueueService.sendRequestToQueue(spaceId, identifier, targetId, delegate, new HashMap<>());
//        assertNotNull(responseEntity);
//        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }

    @Test
    public void testIsRetry() {
        GenericResponse response = new GenericResponse("400", "Bad Request", "ConnectException");
        ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

        boolean result = sendQueueService.isRetry(responseEntity);
        assertTrue(result);
    }

    @Test
    public void testIsRetryFalse() {
        GenericResponse response = new GenericResponse("200", "OK", "Success");
        ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);

        boolean result = sendQueueService.isRetry(responseEntity);
        assertFalse(result);
    }
    
    
    @Test
    public void testAddSendDocumentRequestToDoc360_success() throws Exception {
    	
    	  fdsHelperMock = mockStatic(FDSHelper.class);
          
    	 
    	  fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);
    	  
           Integer spaceId = 1;
           String identifier = "id";
           String targetId = "target";
           String delegate = "delegate";
           MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
           Map<String, Object> callbackMap = new HashMap<>();
           Map<String, Object> restApiMsgServiceCallbackMap = new HashMap<>();

           GenericResponse genericResponse = new GenericResponse("200", "OK", "Success");
           ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(genericResponse, HttpStatus.OK);

           when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(responseEntity);
           
           ReflectionTestUtils.setField(sendQueueService, "doc360DocumetsUrl", "http://dummy-url");
           ReflectionTestUtils.setField(sendQueueService, "maxRetryCnt", 0);
           

           boolean result = sendQueueService.addSendDocumentRequestToDoc360(
                   spaceId, identifier, targetId, delegate, requestMap, callbackMap, restApiMsgServiceCallbackMap,0);

           assertTrue(result);

    }

    @Test
    public void testHandleException() {
//        String spaceId = "1";
//        String identifier = "testIdentifier";
//        String targetId = "testTargetId";
//        String delegate = "testDelegate";
//        int retryCnt = 1;
//        int maxRetryCnt = 3;
//        Map<String, Object> callbackMap = new HashMap<>();
//        Exception e = new Exception("Test Exception");
//
//        ResponseEntity<GenericResponse> result = sendQueueService.handleException(spaceId, identifier, targetId, delegate, retryCnt, maxRetryCnt, callbackMap, e);
//        assertNotNull(result);
//        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
    }


    @After
    public void tearDown() {
        if (fdsHelperMock != null) {
            fdsHelperMock.close();
            fdsHelperMock = null;
        }
    }

    @Test
    public void testGetPriorityQueue_DefaultWhenMissing() {
        Map<Integer, String> map = new HashMap<>();
        map.put(1, "HighPriorityQueue");
        ReflectionTestUtils.setField(sendQueueService, "spaceIdToPriorityQueueMap", map);

        String queue = sendQueueService.getPriorityQueue(99);

        assertEquals("LowPriorityQueue", queue);
    }

    @Test
    public void testSendRequestToQueue_OK_NoException() throws Exception {
        SendQueueServiceImpl spySvc = spy(sendQueueService);

        ResponseEntity<GenericResponse> ok =
                new ResponseEntity<>(new GenericResponse("200", "OK", "done"), HttpStatus.OK);

        Mockito.doReturn("{\"k\":\"v\"}")
                .when(spySvc).getMultiValueMapToJson(eq("delegate"), anyMap());
        Mockito.doReturn(ok)
                .when(spySvc).sendRequestToQueue(eq(1), eq("id"), eq("target"), eq("delegate"), anyString());

        spySvc.sendRequestToQueue(1, "id", "target", "delegate", new HashMap<>());
    }

    @Test(expected = HttpServerException.class)
    public void testSendRequestToQueue_ServerError_ThrowsHttpServerException() throws Exception {
        SendQueueServiceImpl spySvc = spy(sendQueueService);

        ResponseEntity<GenericResponse> err =
                new ResponseEntity<>(new GenericResponse("500", "ISE", "boom"), HttpStatus.INTERNAL_SERVER_ERROR);

        Mockito.doReturn("{}")
                .when(spySvc).getMultiValueMapToJson(eq("delegate"), anyMap());
        Mockito.doReturn(err)
                .when(spySvc).sendRequestToQueue(eq(1), eq("id"), eq("target"), eq("delegate"), anyString());

        spySvc.sendRequestToQueue(1, "id", "target", "delegate", new HashMap<>());
    }

    @Test(expected = ProcessException.class)
    public void testSendRequestToQueue_ClientError_ThrowsProcessException() throws Exception {
        SendQueueServiceImpl spySvc = spy(sendQueueService);

        ResponseEntity<GenericResponse> err =
                new ResponseEntity<>(new GenericResponse("400", "Bad Request", "bad"), HttpStatus.BAD_REQUEST);

        Mockito.doReturn("{}")
                .when(spySvc).getMultiValueMapToJson(eq("delegate"), anyMap());
        Mockito.doReturn(err)
                .when(spySvc).sendRequestToQueue(eq(1), eq("id"), eq("target"), eq("delegate"), anyString());

        spySvc.sendRequestToQueue(1, "id", "target", "delegate", new HashMap<>());
    }

    @Test(expected = ProcessException.class)
    public void testGetMultiValueMapToJson_IOExceptionWrappedAsProcessException() throws Exception {
        SendQueueServiceImpl spySvc = spy(sendQueueService);
        doThrow(new ProcessException("delegate=del: io"))
                .when(spySvc).getMultiValueMapToJson(eq("del"), anyMap());

        spySvc.getMultiValueMapToJson("del", new HashMap<String, Object>());
    }

    @Test
    public void testAddSendDocumentRequestToDoc360_Created_ReturnsTrue() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);

        ReflectionTestUtils.setField(sendQueueService, "doc360DocumetsUrl", "http://doc360");
        ReflectionTestUtils.setField(sendQueueService, "maxRetryCnt", 2);

        ResponseEntity<GenericResponse> created =
                new ResponseEntity<>(new GenericResponse("201", "Created", "ok"), HttpStatus.CREATED);
        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(created);

        boolean result = sendQueueService.addSendDocumentRequestToDoc360(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertTrue(result);
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), anyMap(), any()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToDoc360_NotRetry_ReturnsFalse() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);

        ReflectionTestUtils.setField(sendQueueService, "doc360DocumetsUrl", "http://doc360");
        ReflectionTestUtils.setField(sendQueueService, "maxRetryCnt", 2);

        ResponseEntity<GenericResponse> bad =
                new ResponseEntity<>(new GenericResponse("422", "Unprocessable", "validation"), HttpStatus.UNPROCESSABLE_ENTITY);
        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(bad);

        boolean result = sendQueueService.addSendDocumentRequestToDoc360(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertFalse(result);
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), anyMap(), any()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToDoc360_RetryCntExceeded_ReturnsFalse() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);

        ReflectionTestUtils.setField(sendQueueService, "doc360DocumetsUrl", "http://doc360");
        ReflectionTestUtils.setField(sendQueueService, "maxRetryCnt", 0);

        ResponseEntity<GenericResponse> badReq =
                new ResponseEntity<>(new GenericResponse("400", "Bad Request", "ConnectException"), HttpStatus.BAD_REQUEST);
        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(badReq);

        boolean result = sendQueueService.addSendDocumentRequestToDoc360(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertFalse(result);
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), anyMap(), any()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToDoc360_RetryQueueOk_ReturnsFalse() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);

        SendQueueServiceImpl spySvc = spy(sendQueueService);
        ReflectionTestUtils.setField(spySvc, "doc360DocumetsUrl", "http://doc360");
        ReflectionTestUtils.setField(spySvc, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> firstFail =
                new ResponseEntity<>(new GenericResponse("400", "Bad Request", "ConnectException"), HttpStatus.BAD_REQUEST);
        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(firstFail);

        Mockito.doReturn("{\"x\":1}")
                .when(spySvc).getMultiValueMapToJson(eq("callRestApiWithMsgServiceOnErrorCallback"), anyMap());
        ResponseEntity<GenericResponse> queueOk =
                new ResponseEntity<>(new GenericResponse("200", "OK", "queued"), HttpStatus.OK);
        Mockito.doReturn(queueOk)
                .when(spySvc).sendRequestToQueue(eq(1), contains(":callRestApiWithMsgServiceOnErrorCallback"),
                        eq("target"), eq("callRestApiWithMsgServiceOnErrorCallback"), anyString());

        boolean result = spySvc.addSendDocumentRequestToDoc360(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertFalse(result);
    }

    @Test(expected = HttpServerException.class)
    public void testAddSendDocumentRequestToDoc360_RetryQueueServerError_Throws() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);

        SendQueueServiceImpl spySvc = spy(sendQueueService);
        ReflectionTestUtils.setField(spySvc, "doc360DocumetsUrl", "http://doc360");
        ReflectionTestUtils.setField(spySvc, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> firstFail =
                new ResponseEntity<>(new GenericResponse("400", "Bad Request", "ConnectException"), HttpStatus.BAD_REQUEST);
        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(firstFail);

        Mockito.doReturn("{}")
                .when(spySvc).getMultiValueMapToJson(eq("callRestApiWithMsgServiceOnErrorCallback"), anyMap());

        ResponseEntity<GenericResponse> queueErr =
                new ResponseEntity<>(new GenericResponse("500", "ISE", "queue failed"), HttpStatus.INTERNAL_SERVER_ERROR);
        Mockito.doReturn(queueErr)
                .when(spySvc).sendRequestToQueue(eq(1), contains(":callRestApiWithMsgServiceOnErrorCallback"),
                        eq("target"), eq("callRestApiWithMsgServiceOnErrorCallback"), anyString());

        spySvc.addSendDocumentRequestToDoc360(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);
    }

    @Test
    public void testAddSendDocumentRequestToDoc360_RetryQueueClientError_CallbackAndFalse() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), nullable(GenericResponse.class))).thenReturn(null);

        SendQueueServiceImpl spySvc = spy(sendQueueService);
        ReflectionTestUtils.setField(spySvc, "doc360DocumetsUrl", "http://doc360");
        ReflectionTestUtils.setField(spySvc, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> firstFail =
                new ResponseEntity<>(new GenericResponse("400", "Bad Request", "ConnectException"), HttpStatus.BAD_REQUEST);
        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(firstFail);

        Mockito.doReturn("{\"r\":1}")
                .when(spySvc).getMultiValueMapToJson(eq("callRestApiWithMsgServiceOnErrorCallback"), anyMap());

        ResponseEntity<GenericResponse> queueBad =
                new ResponseEntity<>(new GenericResponse("409", "Conflict", "no"), HttpStatus.CONFLICT);
        Mockito.doReturn(queueBad)
                .when(spySvc).sendRequestToQueue(eq(1), contains(":callRestApiWithMsgServiceOnErrorCallback"),
                        eq("target"), eq("callRestApiWithMsgServiceOnErrorCallback"), anyString());

        boolean result = spySvc.addSendDocumentRequestToDoc360(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertFalse(result);
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), anyMap(), any()), times(1));
    }

    @Test
    public void sendRequestToQueue_shouldThrowHttpServerException_whenQueueResponseEntityIsNull() throws Exception {
        SendQueueServiceImpl spyService = Mockito.spy(new SendQueueServiceImpl());

        Map<String, Object> callbackMap = new HashMap<>();
        callbackMap.put("key", "value");

        doReturn("{\"delegate\":\"testDelegate\"}")
                .when(spyService)
                .getMultiValueMapToJson("testDelegate", callbackMap);

        doReturn(null)
                .when(spyService)
                .sendRequestToQueue(10, "identifier-1", "target-1", "testDelegate", "{\"delegate\":\"testDelegate\"}");

        HttpServerException exception = assertThrows(
                HttpServerException.class,
                () -> spyService.sendRequestToQueue(10, "identifier-1", "target-1", "testDelegate", callbackMap)
        );

        assertTrue(exception.getMessage().contains("500:500:Internal Server Error"));
        assertTrue(exception.getMessage().contains("QUEUE responseEntity == null"));

        verify(spyService).getMultiValueMapToJson("testDelegate", callbackMap);
        verify(spyService).sendRequestToQueue(
                10,
                "identifier-1",
                "target-1",
                "testDelegate",
                "{\"delegate\":\"testDelegate\"}"
        );
    }

    @Test
    public void sendRequestToQueue_shouldThrowHttpServerException_whenInnerQueueCallThrowsException() throws Exception {
        SendQueueServiceImpl spyService = Mockito.spy(new SendQueueServiceImpl());

        Map<String, Object> callbackMap = new HashMap<>();
        callbackMap.put("key", "value");

        doReturn("callback-json")
                .when(spyService)
                .getMultiValueMapToJson("delegateA", callbackMap);

        doThrow(new RuntimeException("queue failure"))
                .when(spyService)
                .sendRequestToQueue(1, "identifier1", "target1", "delegateA", "callback-json");

        HttpServerException exception = assertThrows(
                HttpServerException.class,
                () -> spyService.sendRequestToQueue(1, "identifier1", "target1", "delegateA", callbackMap)
        );

        assertTrue(exception.getMessage().contains("500"));
        assertTrue(exception.getMessage().contains("QUEUE  Failure; queue failure"));

        verify(spyService).getMultiValueMapToJson("delegateA", callbackMap);
        verify(spyService).sendRequestToQueue(1, "identifier1", "target1", "delegateA", "callback-json");
    }

    @Test
    public void testAddSendDocumentRequestToFds_DelegatesToRetryZeroOverload() throws Exception {
        SendQueueServiceImpl spySvc = spy(sendQueueService);

        MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
        Map<String, Object> callbackMap = new HashMap<>();
        Map<String, Object> restApiMsgServiceCallbackMap = new HashMap<>();

        doReturn(true).when(spySvc).addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                requestMap, callbackMap, restApiMsgServiceCallbackMap, 0);

        boolean result = spySvc.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                requestMap, callbackMap, restApiMsgServiceCallbackMap);

        assertTrue(result);
        verify(spySvc).addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                requestMap, callbackMap, restApiMsgServiceCallbackMap, 0);
    }

    @Test
    public void testAddSendDocumentRequestToFds_OK_ReturnsTrue() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);

        ReflectionTestUtils.setField(sendQueueService, "fDSDocumentsUrl", "http://fds");
        ReflectionTestUtils.setField(sendQueueService, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> ok =
                new ResponseEntity<>(new GenericResponse("200", "OK", "success"), HttpStatus.OK);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(ok);

        boolean result = sendQueueService.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertTrue(result);
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), anyMap(), any()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToFds_Created_ReturnsTrue() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);

        ReflectionTestUtils.setField(sendQueueService, "fDSDocumentsUrl", "http://fds");
        ReflectionTestUtils.setField(sendQueueService, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> created =
                new ResponseEntity<>(new GenericResponse("201", "Created", "created"), HttpStatus.CREATED);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(created);

        boolean result = sendQueueService.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertTrue(result);
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), anyMap(), any()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToFds_ResponseEntityNull_ReturnsFalse() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);

        ReflectionTestUtils.setField(sendQueueService, "fDSDocumentsUrl", "http://fds");
        ReflectionTestUtils.setField(sendQueueService, "maxRetryCnt", 3);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(null);

        boolean result = sendQueueService.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertFalse(result);
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), anyMap(), any()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToFds_PostRequestThrowsException_ReturnsFalse() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);

        ReflectionTestUtils.setField(sendQueueService, "fDSDocumentsUrl", "http://fds");
        ReflectionTestUtils.setField(sendQueueService, "maxRetryCnt", 3);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString()))
                .thenThrow(new RuntimeException("post failure"));

        boolean result = sendQueueService.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertFalse(result);
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), anyMap(), any()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToFds_NotRetryableResponse_ReturnsFalse() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);

        ReflectionTestUtils.setField(sendQueueService, "fDSDocumentsUrl", "http://fds");
        ReflectionTestUtils.setField(sendQueueService, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> bad =
                new ResponseEntity<>(new GenericResponse("422", "Unprocessable", "validation"), HttpStatus.UNPROCESSABLE_ENTITY);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(bad);

        boolean result = sendQueueService.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertFalse(result);
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), anyMap(), any()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToFds_RetryCntExceeded_ReturnsFalse() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);

        ReflectionTestUtils.setField(sendQueueService, "fDSDocumentsUrl", "http://fds");
        ReflectionTestUtils.setField(sendQueueService, "maxRetryCnt", 0);

        ResponseEntity<GenericResponse> retryable =
                new ResponseEntity<>(new GenericResponse("400", "Bad Request", "ConnectException"), HttpStatus.BAD_REQUEST);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(retryable);

        boolean result = sendQueueService.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertFalse(result);
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), anyMap(), any()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToFds_RetryQueueOk_ReturnsFalse() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any())).thenReturn(null);

        SendQueueServiceImpl spySvc = spy(sendQueueService);

        ReflectionTestUtils.setField(spySvc, "fDSDocumentsUrl", "http://fds");
        ReflectionTestUtils.setField(spySvc, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> firstFail =
                new ResponseEntity<>(new GenericResponse("400", "Bad Request", "ConnectException"), HttpStatus.BAD_REQUEST);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(firstFail);

        doReturn("{\"retry\":1}")
                .when(spySvc)
                .getMultiValueMapToJson(eq("callRestApiWithMsgServiceOnErrorCallback"), anyMap());

        ResponseEntity<GenericResponse> queueOk =
                new ResponseEntity<>(new GenericResponse("200", "OK", "queued"), HttpStatus.OK);

        doReturn(queueOk)
                .when(spySvc)
                .sendRequestToQueue(eq(1), contains(":callRestApiWithMsgServiceOnErrorCallback"),
                        eq("target"), eq("callRestApiWithMsgServiceOnErrorCallback"), anyString());

        boolean result = spySvc.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertFalse(result);
    }

    @Test(expected = HttpServerException.class)
    public void testAddSendDocumentRequestToFds_RetryQueueNull_ThrowsHttpServerException() throws Exception {
        SendQueueServiceImpl spySvc = spy(sendQueueService);

        ReflectionTestUtils.setField(spySvc, "fDSDocumentsUrl", "http://fds");
        ReflectionTestUtils.setField(spySvc, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> firstFail =
                new ResponseEntity<>(new GenericResponse("400", "Bad Request", "ConnectException"), HttpStatus.BAD_REQUEST);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(firstFail);

        doReturn("{\"retry\":1}")
                .when(spySvc)
                .getMultiValueMapToJson(eq("callRestApiWithMsgServiceOnErrorCallback"), anyMap());

        doReturn(null)
                .when(spySvc)
                .sendRequestToQueue(eq(1), contains(":callRestApiWithMsgServiceOnErrorCallback"),
                        eq("target"), eq("callRestApiWithMsgServiceOnErrorCallback"), anyString());

        spySvc.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);
    }

    @Test(expected = HttpServerException.class)
    public void testAddSendDocumentRequestToFds_RetryQueueThrowsException_ThrowsHttpServerException() throws Exception {
        SendQueueServiceImpl spySvc = spy(sendQueueService);

        ReflectionTestUtils.setField(spySvc, "fDSDocumentsUrl", "http://fds");
        ReflectionTestUtils.setField(spySvc, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> firstFail =
                new ResponseEntity<>(new GenericResponse("400", "Bad Request", "ConnectException"), HttpStatus.BAD_REQUEST);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(firstFail);

        doReturn("{\"retry\":1}")
                .when(spySvc)
                .getMultiValueMapToJson(eq("callRestApiWithMsgServiceOnErrorCallback"), anyMap());

        doThrow(new RuntimeException("queue failed"))
                .when(spySvc)
                .sendRequestToQueue(eq(1), contains(":callRestApiWithMsgServiceOnErrorCallback"),
                        eq("target"), eq("callRestApiWithMsgServiceOnErrorCallback"), anyString());

        spySvc.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);
    }

    @Test(expected = HttpServerException.class)
    public void testAddSendDocumentRequestToFds_RetryQueueServerError_ThrowsHttpServerException() throws Exception {
        SendQueueServiceImpl spySvc = spy(sendQueueService);

        ReflectionTestUtils.setField(spySvc, "fDSDocumentsUrl", "http://fds");
        ReflectionTestUtils.setField(spySvc, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> firstFail =
                new ResponseEntity<>(new GenericResponse("400", "Bad Request", "ConnectException"), HttpStatus.BAD_REQUEST);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(firstFail);

        doReturn("{\"retry\":1}")
                .when(spySvc)
                .getMultiValueMapToJson(eq("callRestApiWithMsgServiceOnErrorCallback"), anyMap());

        ResponseEntity<GenericResponse> queueErr =
                new ResponseEntity<>(new GenericResponse("500", "ISE", "queue failed"), HttpStatus.INTERNAL_SERVER_ERROR);

        doReturn(queueErr)
                .when(spySvc)
                .sendRequestToQueue(eq(1), contains(":callRestApiWithMsgServiceOnErrorCallback"),
                        eq("target"), eq("callRestApiWithMsgServiceOnErrorCallback"), anyString());

        spySvc.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);
    }

    @Test
    public void testAddSendDocumentRequestToFds_RetryQueueClientError_ReturnsFalseAndRunsCallback() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), nullable(GenericResponse.class))).thenReturn(null);

        SendQueueServiceImpl spySvc = spy(sendQueueService);

        ReflectionTestUtils.setField(spySvc, "fDSDocumentsUrl", "http://fds");
        ReflectionTestUtils.setField(spySvc, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> firstFail =
                new ResponseEntity<>(new GenericResponse("400", "Bad Request", "ConnectException"), HttpStatus.BAD_REQUEST);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(firstFail);

        doReturn("{\"retry\":1}")
                .when(spySvc)
                .getMultiValueMapToJson(eq("callRestApiWithMsgServiceOnErrorCallback"), anyMap());

        ResponseEntity<GenericResponse> queueBad =
                new ResponseEntity<>(new GenericResponse("409", "Conflict", "no"), HttpStatus.CONFLICT);

        doReturn(queueBad)
                .when(spySvc)
                .sendRequestToQueue(eq(1), contains(":callRestApiWithMsgServiceOnErrorCallback"),
                        eq("target"), eq("callRestApiWithMsgServiceOnErrorCallback"), anyString());

        boolean result = spySvc.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertFalse(result);
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), anyMap(), any()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToFds_RetryQueueClientErrorWithNoBody_ReturnsFalseAndRunsCallback() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), nullable(GenericResponse.class))).thenReturn(null);

        SendQueueServiceImpl spySvc = spy(sendQueueService);

        ReflectionTestUtils.setField(spySvc, "fDSDocumentsUrl", "http://fds");
        ReflectionTestUtils.setField(spySvc, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> firstFail =
                new ResponseEntity<>(new GenericResponse("400", "Bad Request", "ConnectException"), HttpStatus.BAD_REQUEST);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString())).thenReturn(firstFail);

        doReturn("{\"retry\":1}")
                .when(spySvc)
                .getMultiValueMapToJson(eq("callRestApiWithMsgServiceOnErrorCallback"), anyMap());

        ResponseEntity<GenericResponse> queueBadNoBody =
                new ResponseEntity<>((HttpHeaders) null, HttpStatus.CONFLICT);

        doReturn(queueBadNoBody)
                .when(spySvc)
                .sendRequestToQueue(eq(1), contains(":callRestApiWithMsgServiceOnErrorCallback"),
                        eq("target"), eq("callRestApiWithMsgServiceOnErrorCallback"), anyString());

        boolean result = spySvc.addSendDocumentRequestToFds(
                1, "id", "target", "delegate",
                new LinkedMultiValueMap<String, Object>(),
                new HashMap<String, Object>(),
                new HashMap<String, Object>(),
                0);

        assertFalse(result);
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), anyMap(), isNull()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToDoc360_WhenPostReturnsNull_Builds500ResponseAndReturnsFalse() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);

        GenericResponse[] callbackResponse = new GenericResponse[1];
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any()))
                .thenAnswer(invocation -> {
                    callbackResponse[0] = invocation.getArgument(2);
                    return null;
                });

        ReflectionTestUtils.setField(sendQueueService, "doc360DocumetsUrl", "http://doc360-url");
        ReflectionTestUtils.setField(sendQueueService, "fDSDocumentsUrl", "http://fds-url");

        MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
        Map<String, Object> callbackMap = new HashMap<>();
        Map<String, Object> restApiMsgServiceCallbackMap = new HashMap<>();

        when(serviceBase.postRequestToSvcMultipartForm(eq("http://doc360-url"), eq(requestMap), eq("1")))
                .thenReturn(null);

        boolean result = sendQueueService.addSendDocumentRequestToDoc360(
                1,
                "identifier",
                "target",
                "delegate",
                requestMap,
                callbackMap,
                restApiMsgServiceCallbackMap,
                0
        );

        assertFalse(result);
        assertNotNull(callbackResponse[0]);
        assertEquals("500", callbackResponse[0].getStatusCode());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), callbackResponse[0].getStatusMessage());
        assertTrue(callbackResponse[0].getResponse().toString().contains("http://fds-url"));
        assertTrue(callbackResponse[0].getResponse().toString().contains("responseEntity == null"));

        verify(serviceBase).postRequestToSvcMultipartForm(eq("http://doc360-url"), eq(requestMap), eq("1"));
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), eq(callbackMap), any()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToDoc360_WhenPostThrowsException_Builds500ResponseAndReturnsFalse() throws Exception {
        fdsHelperMock = mockStatic(FDSHelper.class);

        GenericResponse[] callbackResponse = new GenericResponse[1];
        fdsHelperMock.when(() -> FDSHelper.runProcess(anyString(), anyMap(), any()))
                .thenAnswer(invocation -> {
                    callbackResponse[0] = invocation.getArgument(2);
                    return null;
                });

        ReflectionTestUtils.setField(sendQueueService, "doc360DocumetsUrl", "http://doc360-url");
        ReflectionTestUtils.setField(sendQueueService, "fDSDocumentsUrl", "http://fds-url");

        MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
        Map<String, Object> callbackMap = new HashMap<>();
        Map<String, Object> restApiMsgServiceCallbackMap = new HashMap<>();

        when(serviceBase.postRequestToSvcMultipartForm(eq("http://doc360-url"), eq(requestMap), eq("1")))
                .thenThrow(new RuntimeException("simulated post failure"));

        boolean result = sendQueueService.addSendDocumentRequestToDoc360(
                1,
                "identifier",
                "target",
                "delegate",
                requestMap,
                callbackMap,
                restApiMsgServiceCallbackMap,
                0
        );

        assertFalse(result);
        assertNotNull(callbackResponse[0]);
        assertEquals("500", callbackResponse[0].getStatusCode());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), callbackResponse[0].getStatusMessage());
        assertTrue(callbackResponse[0].getResponse().toString().contains("http://fds-url"));
        assertTrue(callbackResponse[0].getResponse().toString().contains("simulated post failure"));

        verify(serviceBase).postRequestToSvcMultipartForm(eq("http://doc360-url"), eq(requestMap), eq("1"));
        fdsHelperMock.verify(() -> FDSHelper.runProcess(eq("delegate"), eq(callbackMap), any()), times(1));
    }

    @Test
    public void testAddSendDocumentRequestToDoc360_WhenRetryQueueReturnsNull_ThrowsHttpServerException() throws Exception {
        SendQueueServiceImpl spySvc = spy(sendQueueService);

        ReflectionTestUtils.setField(spySvc, "doc360DocumetsUrl", "http://doc360");
        ReflectionTestUtils.setField(spySvc, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> firstFail =
                new ResponseEntity<>(
                        new GenericResponse("400", "Bad Request", "ConnectException"),
                        HttpStatus.BAD_REQUEST);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString()))
                .thenReturn(firstFail);

        doReturn("{\"retry\":1}")
                .when(spySvc)
                .getMultiValueMapToJson(eq("callRestApiWithMsgServiceOnErrorCallback"), anyMap());

        doReturn(null)
                .when(spySvc)
                .sendRequestToQueue(
                        eq(1),
                        contains(":callRestApiWithMsgServiceOnErrorCallback"),
                        eq("target"),
                        eq("callRestApiWithMsgServiceOnErrorCallback"),
                        anyString());

        HttpServerException exception = assertThrows(
                HttpServerException.class,
                () -> spySvc.addSendDocumentRequestToDoc360(
                        1,
                        "id",
                        "target",
                        "delegate",
                        new LinkedMultiValueMap<String, Object>(),
                        new HashMap<String, Object>(),
                        new HashMap<String, Object>(),
                        0)
        );

        assertTrue(exception.getMessage().contains("500"));
        assertTrue(exception.getMessage().contains("QUEUE responseEntity == null"));
    }

    @Test
    public void testAddSendDocumentRequestToDoc360_WhenRetryQueueThrowsException_ThrowsHttpServerException() throws Exception {
        SendQueueServiceImpl spySvc = spy(sendQueueService);

        ReflectionTestUtils.setField(spySvc, "doc360DocumetsUrl", "http://doc360");
        ReflectionTestUtils.setField(spySvc, "maxRetryCnt", 3);

        ResponseEntity<GenericResponse> firstFail =
                new ResponseEntity<>(
                        new GenericResponse("400", "Bad Request", "ConnectException"),
                        HttpStatus.BAD_REQUEST);

        when(serviceBase.postRequestToSvcMultipartForm(anyString(), any(), anyString()))
                .thenReturn(firstFail);

        doReturn("{\"retry\":1}")
                .when(spySvc)
                .getMultiValueMapToJson(eq("callRestApiWithMsgServiceOnErrorCallback"), anyMap());

        doThrow(new RuntimeException("queue failed"))
                .when(spySvc)
                .sendRequestToQueue(
                        eq(1),
                        contains(":callRestApiWithMsgServiceOnErrorCallback"),
                        eq("target"),
                        eq("callRestApiWithMsgServiceOnErrorCallback"),
                        anyString());

        HttpServerException exception = assertThrows(
                HttpServerException.class,
                () -> spySvc.addSendDocumentRequestToDoc360(
                        1,
                        "id",
                        "target",
                        "delegate",
                        new LinkedMultiValueMap<String, Object>(),
                        new HashMap<String, Object>(),
                        new HashMap<String, Object>(),
                        0)
        );

        assertTrue(exception.getMessage().contains("500"));
        assertTrue(exception.getMessage().contains("QUEUE  Failure; queue failed"));
    }

    @Test
    public void testProtectedSendRequestToQueue_UsesMappedQueueAndReturnsResponse() {
        ReflectionTestUtils.setField(sendQueueService, "messageServiceUrl", "http://msg-service");
        ReflectionTestUtils.setField(sendQueueService, "engineDelegateUrl", "engineDelegate");

        Map<Integer, String> queueMap = new HashMap<>();
        queueMap.put(1, "HighPriorityQueue");
        ReflectionTestUtils.setField(sendQueueService, "spaceIdToPriorityQueueMap", queueMap);

        ResponseEntity<GenericResponse> expectedResponse =
                new ResponseEntity<>(new GenericResponse("200", "OK", "queued"), HttpStatus.OK);

        when(serviceBase.postRequestToSvc(
                eq("http://msg-service"),
                eq("{\"a\":1}"),
                eq("HighPriorityQueue/engineDelegate/id-1/target-1/1")))
                .thenReturn(expectedResponse);

        ResponseEntity<GenericResponse> actualResponse =
                sendQueueService.sendRequestToQueue(1, "id-1", "target-1", "delegateA", "{\"a\":1}");

        assertNotNull(actualResponse);
        assertSame(expectedResponse, actualResponse);
        verify(serviceBase).postRequestToSvc(
                eq("http://msg-service"),
                eq("{\"a\":1}"),
                eq("HighPriorityQueue/engineDelegate/id-1/target-1/1"));
    }

    @Test
    public void testProtectedSendRequestToQueue_UsesLowPriorityQueueWhenMappingMissing() {
        ReflectionTestUtils.setField(sendQueueService, "messageServiceUrl", "http://msg-service");
        ReflectionTestUtils.setField(sendQueueService, "engineDelegateUrl", "engineDelegate");
        ReflectionTestUtils.setField(sendQueueService, "spaceIdToPriorityQueueMap", new HashMap<Integer, String>());

        ResponseEntity<GenericResponse> expectedResponse =
                new ResponseEntity<>(new GenericResponse("200", "OK", "queued"), HttpStatus.OK);

        when(serviceBase.postRequestToSvc(
                eq("http://msg-service"),
                eq("{\"b\":2}"),
                eq("LowPriorityQueue/engineDelegate/id-2/target-2/99")))
                .thenReturn(expectedResponse);

        ResponseEntity<GenericResponse> actualResponse =
                sendQueueService.sendRequestToQueue(99, "id-2", "target-2", "delegateB", "{\"b\":2}");

        assertNotNull(actualResponse);
        assertSame(expectedResponse, actualResponse);
        verify(serviceBase).postRequestToSvc(
                eq("http://msg-service"),
                eq("{\"b\":2}"),
                eq("LowPriorityQueue/engineDelegate/id-2/target-2/99"));
    }

    @Test
    public void testGetMultiValueMapToJson_ReturnsJsonWhenParserSucceeds() throws Exception {
        Map<String, Object> callbackMap = new HashMap<>();
        callbackMap.put("key", "value");

        try (MockedStatic<Parser> parserMock = mockStatic(Parser.class)) {
            parserMock.when(() -> Parser.toJson(any(MultiValueMap.class)))
                    .thenReturn("{\"delegate\":\"delegateA\",\"callbackMap\":{\"key\":\"value\"}}");

            String result = sendQueueService.getMultiValueMapToJson("delegateA", callbackMap);

            assertNotNull(result);
            assertEquals("{\"delegate\":\"delegateA\",\"callbackMap\":{\"key\":\"value\"}}", result);

            parserMock.verify(() -> Parser.toJson(any(MultiValueMap.class)), times(1));
        }
    }

}