package com.optum.fds.paperless.domain.service;

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.bson.json.JsonParseException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.ExecutableInsertOperation.ExecutableInsert;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;

import com.optum.fds.paperless.constants.ProcessKeys;
import com.optum.fds.paperless.exception.ErrorCode;
import com.optum.fds.paperless.java.delegate.DelegateExecutionImpl;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.workflow.constants.Workflow;

@RunWith(MockitoJUnitRunner.class)
public class ErrorMetaDataServiceTest {
	
	@Mock
	MongoTemplate mongoTemplate;
	
	@Mock
	MongoOperations mongoOps;
	
	@InjectMocks
	ErrorMetaDataServiceImpl errorMetaDataService;
	
	
	@UserStory(references = "US32826")
	@RallyTestCase(references = "TC32911")
	@Test
	public void testSaveErrorMetaData() {
		Mockito.when(mongoTemplate.findOne(Mockito.any(),Mockito.any())).thenReturn(getErrorMetaData());
		ErrorMetaData emd = getErrorMetaData();
		ErrorMetaData testResult = errorMetaDataService.saveErrorMetaData(emd);
		assertNotNull(testResult);
		assertEquals(testResult.getTargetId(), emd.getTargetId());
	}

	@UserStory(references = "US32826")
    @Test
    public void testGetErrorMetaData() {
    	List<Object> list = new ArrayList<>();
    	list.add(getErrorMetaData());
    	Mockito.when(mongoTemplate.find(Mockito.any(), Mockito.any())).thenReturn(list);
    	ErrorMetaData testResult = errorMetaDataService.getErrorMetaData("test id");
    	assertNotNull(testResult);
    }
    
	@UserStory(references = "US32826")
    @Test
    public void testGetErrorMetaDataByTargetId() {
    	List<Object> list = new ArrayList<>();
    	list.add(getErrorMetaData());
    	Mockito.when(mongoTemplate.find(Mockito.any(), Mockito.any())).thenReturn(list);
    	ErrorMetaData testResult = errorMetaDataService.getErrorMetaDataByTargetId("test id");
    	assertNotNull(testResult);
    }
	
	@UserStory(references = "US32826")
    @Test
    public void testUpdateErrorMetaDataStatus() {
    	Mockito.when(mongoTemplate.findOne(Mockito.any(), Mockito.any())).thenReturn(getErrorMetaData());
    	ErrorMetaData testResult = errorMetaDataService.updateErrorMetaDataStatus("1111", "COMPLETE");
    	assertNotNull(testResult);
    	assertNotNull(testResult.getDateModified());
    	assertEquals(MetaDataStatus.COMPLETE, testResult.getStatus());
    }
    
	@UserStory(references = "US32826")
    @Test
    public void testGetErrorListById() {
    	List<Object> list = new ArrayList<>();
    	list.add(getErrorMetaData());
    	Mockito.when(mongoTemplate.find(Mockito.any(), Mockito.any())).thenReturn(list);
    	List<ErrorMetaData> testResult = errorMetaDataService.getErrorListById("test id");
    	assertNotNull(testResult);
    }
    
	@UserStory(references = "US32826")
    @Test
    public void testGetErrorListByIdentifier() {
    	List<Object> list = new ArrayList<>();
    	list.add(getErrorMetaData());
    	Mockito.when(mongoTemplate.find(Mockito.any(), Mockito.any())).thenReturn(list);
    	List<ErrorMetaData> testResult = errorMetaDataService.getErrorListByIdentifier("test identifier");
    	assertNotNull(testResult);
    }
	
	@UserStory(references = "US32826")
    @Test
    public void testUpdateErrorMetaData() {
    	Mockito.when(mongoTemplate.findOne(Mockito.any(), Mockito.any())).thenReturn(getErrorMetaData());
    	ErrorMetaData testResult = errorMetaDataService.updateErrorMetaData(getErrorMetaData());
    	assertNotNull(testResult);
    }

	@UserStory(references = "US32826")
	@Test
	public void testPutErrorMetadataNull() {
//		Mockito.when(mongoTemplate.findOne(Mockito.any(), Mockito.any())).thenReturn(getErrorMetaData());
		ErrorMetaData testResult = errorMetaDataService.putErrorMetadata(getErrorMetaData());
		assertNull(testResult);
	}
	
	@UserStory(references = "US32826")
    @Test
    public void testWriteToErrorCollection() {
    	Mockito.when(mongoTemplate.insert(Mockito.any(ErrorMetaData.class), Mockito.any())).thenReturn(getErrorMetaData1());
    	DelegateExecution execution = createDelegateExecution();
    	ErrorMetaData testResult = errorMetaDataService.writeToErrorCollection(execution, "exception stacktrace");
    	assertNotNull(testResult);
    	assertEquals("exception stacktrace", testResult.getErrorMessage());
    	assertEquals(ErrorCode.BOUNCE_EMAIL_ERROR, testResult.getErrorCode());
    }
	
	public ErrorMetaData getErrorMetaData() {
		ErrorMetaData emd = new ErrorMetaData();
		emd.setId("1111");
		emd.setTargetId("1234");
		emd.setStatus(MetaDataStatus.COMPLETE_WITH_ERRORS);
		return emd;
	}
	
	public ErrorMetaData getErrorMetaData1() {
		ErrorMetaData emd = new ErrorMetaData();
		emd.setId("1111");
		emd.setTargetId("1234");
		emd.setIdentifier("WORKFLOW");
		emd.setErrorMessage("exception stacktrace");
		emd.setErrorCode(ErrorCode.BOUNCE_EMAIL_ERROR);
		
		Document metadata = new Document();
		emd.setMetadata(metadata);
		return emd;
	}
	
	public DelegateExecution createDelegateExecution() {
		DelegateExecution execution = new DelegateExecutionImpl();
		execution.setVariable(Workflow.PROCESS_KEY, ProcessKeys.BOUNCE_PROCESS_KEY);
		execution.setVariable(Workflow.HOOK_ID, "123456");
		return execution;
	}
	

}
