package com.optum.fds.paperless.domain.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;

import static org.mockito.Mockito.when;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorRowTask;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.jobs.ProcessorJob;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;

@RunWith(MockitoJUnitRunner.class)
public class CsvProcessorServiceTest {

	@Mock
	MongoTemplate mongoTemplate;
	
	@Mock
	MongoOperations mongoOps;
	
	@InjectMocks
	CsvProcessorServiceImpl csvProcessorService;
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void findProcessorMetaDataByIdTest() {
		String processorId="test";
		ProcessorMetaData pmd=new ProcessorMetaData();
		when(mongoTemplate.findOne(any(), eq(ProcessorMetaData.class), anyString())).thenReturn(pmd);
		ProcessorMetaData testResult = csvProcessorService.findProcessorMetaDataById(processorId);
		assertNotNull(testResult);
		assertEquals(testResult, pmd);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void findProcessorMetaDataByFileNameTest() {
		String processorId="test";
		ProcessorMetaData pmd=new ProcessorMetaData();
		when(mongoTemplate.findOne(any(), eq(ProcessorMetaData.class), anyString())).thenReturn(pmd);
		ProcessorMetaData testResult = csvProcessorService.findProcessorMetaDataByFileName(processorId, processorId);
		assertNotNull(testResult);
		assertEquals(testResult, pmd);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void  getCsvProcessorRowTaskByProcessorTransactionIdRowNumberTest() {
		String id="id"; 
		Integer i=0;
		CsvProcessorRowTask testResult=new CsvProcessorRowTask();
		testResult = csvProcessorService.getCsvProcessorRowTaskByProcessorTransactionIdRowNumber(id,i);
		assertNull(testResult);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void getCsvProcessorRowTaskByIdTest() {
		String id="id"; 
		CsvProcessorRowTask testResult=new CsvProcessorRowTask();
		testResult = csvProcessorService.getCsvProcessorRowTaskById(id);
		assertNull(testResult);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void getCsvProcessorTransactionTest() {
		String id="id"; 
		CsvProcessorTransaction testResult=new CsvProcessorTransaction();
		testResult = csvProcessorService.getCsvProcessorTransaction(id, id, id);
		assertNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void getCsvProcessorTransactionWithFileNameTest() {
		String id="id"; 
		CsvProcessorTransaction testResult=new CsvProcessorTransaction();
		testResult = csvProcessorService.getCsvProcessorTransactionWithFileName(id, id, id, id);
		assertNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void getCsvProcessorTransactionByTransIdTest() {
		String id="id"; 
		Query testResult=new Query();
		testResult = CsvProcessorServiceImpl.getCsvProcessorTransactionByTransId(id);
		assertNotNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void getCsvProcessorTransactionByProcessorIdTest() {
		String id="id"; 
		Query testResult=new Query();
		testResult = CsvProcessorServiceImpl.getCsvProcessorTransactionByProcessorId(id, id, id);
		assertNotNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void getCsvProcessorTransactionByProcessorIdAndFileNameTest() {
		String id="id"; 
		Query testResult=new Query();
		testResult = CsvProcessorServiceImpl.getCsvProcessorTransactionByProcessorIdAndFileName(id, id, id, id);
		assertNotNull(testResult);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void saveCsvProcessorTransactionMetaDataTest() {
		CsvProcessorTransaction testResult=new CsvProcessorTransaction();
		testResult = csvProcessorService.saveCsvProcessorTransactionMetaData(testResult);
		assertNotNull(testResult);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void updateProcessorExecutionRecordOfCsvProcessorTransactionRecordTest() {
		CsvProcessorTransaction testResult=new CsvProcessorTransaction();
		Map<String, Object> resultMap=new HashMap<String, Object>();
		ProcessorJob job=new ProcessorJob();
		CsvProcessorTransaction csvProcessorTransaction=new CsvProcessorTransaction();
		csvProcessorTransaction.setStatus(MetaDataStatus.IN_PROCESS);
		testResult = csvProcessorService.updateProcessorExecutionRecordOfCsvProcessorTransactionRecord(csvProcessorTransaction,resultMap, job);
		assertNotNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void updateCsvProcessorTransactionMetaDataTest() {
		CsvProcessorTransaction testResult=new CsvProcessorTransaction();
		testResult = csvProcessorService.updateCsvProcessorTransactionMetaData(testResult);
		assertNotNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void getAllCsvProcessorTransactionInStatusTest() {
		String id="id"; 
		List<CsvProcessorTransaction> testResult=new ArrayList();
		testResult = csvProcessorService.getAllCsvProcessorTransactionInStatus(id,id);
		assertNotNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void getAllCsvProcessorTransactionInStatus2Test() {
		String id="id"; 
		List<CsvProcessorTransaction> testResult=new ArrayList();
		List<String> statusList=new ArrayList();
		int processorTransactionSearchTimeWindow=0;
		testResult = csvProcessorService.getAllCsvProcessorTransactionInStatus(statusList,id,processorTransactionSearchTimeWindow );
		assertNotNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void getAllPendingCsvProcessorTransactionsest() {
		String id="id"; 
		List<CsvProcessorTransaction> testResult=new ArrayList();
		List<String> statusList=new ArrayList<String>();
		int csvProcessorTransactionPendingTime=0;
		testResult = csvProcessorService.getAllPendingCsvProcessorTransactions(csvProcessorTransactionPendingTime, statusList,id );
		assertNotNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void saveCsvRecordTest() {
		//String processorId="test";
		Class<DocumentMetaData> dmd = null;
		DocumentMetaData doc=new DocumentMetaData();
		DocumentMetaData testResult = csvProcessorService.saveCsvRecord(doc);
		assertNotNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void saveRestApiJobRecordTest() {
		//String processorId="test";
		//Class<DocumentMetaData> dmd = null;
		Class<JobMetaData> dmd = null;
		JobMetaData doc=new JobMetaData();
		JobMetaData testResult = csvProcessorService.saveRestApiJobRecord(doc);
		assertNotNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void saveCsvProcessorJobRecordTest() {
		//String processorId="test";
		//Class<DocumentMetaData> dmd = null;
		Class<JobMetaData> dmd = null;
		JobMetaData doc=new JobMetaData();
		JobMetaData testResult = csvProcessorService.saveCsvProcessorJobRecord(doc);
		assertNotNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void getAllCsvProcessorRowTaskInStatusTest() {
		String id="id"; 
		List<String> statusList=new ArrayList<String>();
		List<CsvProcessorRowTask> testResult=new ArrayList();
		Query result=new Query();
		testResult = csvProcessorService.getAllCsvProcessorRowTaskInStatus(statusList, id,id);
		assertNotNull(testResult);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void getCsvProcessorTransactionByIdTest() {
		String id="id"; 
		CsvProcessorTransaction testResult= new CsvProcessorTransaction();
		Query result=new Query();
		testResult = csvProcessorService.getCsvProcessorTransactionById(id);
		assertNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
	@Test
	public void getCsvProcessorTransWithFileNameTest() {
		String id="id"; 
		List<String> statusList=new ArrayList<String>();
		Query testResult= new Query();
		Query result=new Query();
		testResult = csvProcessorService.getCsvProcessorTransWithFileName(id);
		assertNotNull(testResult);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
    @Test
    public void testGetCsvProcessorTransactionWithFileNameAndServerType() {
        String serverType = "xaas";
        String fileName="csvProcessorTest20180529034648_f5ec877a-1bd3-4da6-8aa6-514585cbaf04.csv"; 
        
        List<CsvProcessorTransaction> mockListProcessorTransaction = new ArrayList<CsvProcessorTransaction>();
        CsvProcessorTransaction mockProcessorFileTransaction = new CsvProcessorTransaction();

        mockListProcessorTransaction.add(mockProcessorFileTransaction);

        when(mongoTemplate.find(any(Query.class),
                eq(CsvProcessorTransaction.class),
                anyString())).thenReturn(mockListProcessorTransaction);

        assertNotNull(csvProcessorService.getCsvProcessorTransactionWithFileName(fileName));
    }
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32964")
    @Test
    public void testSaveCsvProcessorRowTask() {
        CsvProcessorRowTask testSaveCsvProcessorRowTask = new CsvProcessorRowTask();
        CsvProcessorRowTask result = csvProcessorService.saveCsvProcessorRowTask(testSaveCsvProcessorRowTask, false);
        assertEquals(testSaveCsvProcessorRowTask, result);
    }

}


