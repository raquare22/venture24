package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorRowTask;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;

import java.net.URI;
import java.util.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class CsvProcessorsServiceImplTest {

    @Mock
    private CsvProcessorService csvProcessorService;

    @Mock
    private TransactionService transactionService;

    @Mock
    private MongoTemplate mongoTemplate;

    @InjectMocks
    private CsvProcessorsServiceImpl csvProcessorsService;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateCsvProcessorRowTask() {
        CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();
        Transaction transactionMetaData = new Transaction();
        CsvProcessorRowTask result = csvProcessorsService.createCsvProcessorRowTask(processorTransaction, "csvFileName", "csvJsonFileName", transactionMetaData);
        assertNotNull(result);
        assertEquals("csvFileName", result.getCsvFileName());
        assertEquals("csvJsonFileName", result.getJsonFileName());
    }

    @Test
    public void testCreateCsvProcessorTransaction() {
        ProcessorMetaData processor = new ProcessorMetaData();
        CsvProcessorTransaction result = csvProcessorsService.createCsvProcessorTransaction(processor, "fileName", "fileLocation", "transactionID");
        assertNotNull(result);
        assertEquals("fileName", result.getFileName());
        assertEquals("fileLocation", result.getLocation());
    }

    @Test
    public void testGetCsvTransactionProcessor() {
        CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();
        when(csvProcessorService.getCsvProcessorTransaction(anyString(), anyString(), anyString())).thenReturn(processorTransaction);
        CsvProcessorTransaction result = csvProcessorsService.getCsvTransactionProcessor("appIdentifier", "processorId");
        assertNotNull(result);
    }

    @Test
    public void testGetCsvProcessorTransactionWithFileName() {
        CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();
        when(csvProcessorService.getCsvProcessorTransactionWithFileName(anyString(), anyString(), anyString(), anyString())).thenReturn(processorTransaction);
        CsvProcessorTransaction result = csvProcessorsService.getCsvProcessorTransactionWithFileName("appIdentifier", "processorId", "fileName");
        assertNotNull(result);
    }

    @Test
    public void testFindProcessorMetaDataByFileName() {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        when(csvProcessorService.findProcessorMetaDataByFileName(anyString(), anyString())).thenReturn(processorMetaData);
        ProcessorMetaData result = csvProcessorsService.findProcessorMetaDataByFileName("csvFilename", "appId");
        assertNotNull(result);
    }

    @Test
    public void testFindProcessorMetaDataById() {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        when(csvProcessorService.findProcessorMetaDataById(anyString())).thenReturn(processorMetaData);
        ProcessorMetaData result = csvProcessorsService.findProcessorMetaDataById("id");
        assertNotNull(result);
    }

    @Test
    public void testUpdateCsvProcessorTransactionMetaData() {
        CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();
        when(csvProcessorService.updateCsvProcessorTransactionMetaData(any(CsvProcessorTransaction.class))).thenReturn(processorTransaction);
        CsvProcessorTransaction result = csvProcessorsService.updateCsvProcessorTransactionMetaData(processorTransaction);
        assertNotNull(result);
    }

    @Test
    public void testGetAllTransactionProcessorsShutdown() {
        List<CsvProcessorTransaction> transactions = new ArrayList<>();
        when(csvProcessorService.getAllCsvProcessorTransactionInStatus(anyString(), anyString())).thenReturn(transactions);
        List<CsvProcessorTransaction> result = csvProcessorsService.getAllTransactionProcessorsShutdown();
        assertNotNull(result);
    }

    @Test
    public void testGetAllPendingCsvProcessorsTransactions() {
        List<CsvProcessorTransaction> transactions = new ArrayList<>();
        when(csvProcessorService.getAllPendingCsvProcessorTransactions(any(Integer.class), any(List.class), anyString())).thenReturn(transactions);
        List<CsvProcessorTransaction> result = csvProcessorsService.getAllPendingCsvProcessorsTransactions(7200);
        assertNotNull(result);
    }

    @Test
    public void testCreateCsvRecord() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        when(csvProcessorService.saveCsvRecord(any(DocumentMetaData.class))).thenReturn(documentMetaData);
        DocumentMetaData result = csvProcessorsService.createCsvRecord(234, "appIdentifier", MetaDataStatus.NEW, Map.of("test", "one"));
        assertNotNull(result);
    }

    @Test
    public void testCreateCsvRecordWithDetails() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        when(csvProcessorService.saveCsvRecord(any(DocumentMetaData.class))).thenReturn(documentMetaData);
        DocumentMetaData result = csvProcessorsService.createCsvRecord(234, "appIdentifier", "tin", "mpin", "fileName", "fileType", "providerEmailId", "frequency", "deliveryMethod", "okToChangePdoInd", "autoEdelUpdateInd", MetaDataStatus.NEW);
        assertNotNull(result);
    }

//    @Test
//    public void testCreateRestApiJobEntry() {
//        ProcessorMetaData processor = new ProcessorMetaData();
//        CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
//        JobMetaData jobMetaData = new JobMetaData();
//        when(csvProcessorService.saveRestApiJobRecord(any(JobMetaData.class))).thenReturn(jobMetaData);
//        JobMetaData result = csvProcessorsService.createRestApiJobEntry(processor, csvProcessorTransaction, "csvProcessorRowTaskId", "jobType", "wrkFlow", HttpMethod.POST, new HttpEntity<>(null), null, URI.create("http://localhost"));
//        assertNotNull(result);
//    }

//    @Test
//    public void testCreateCsvProcessorJobEntry() {
//        ProcessorMetaData processor = new ProcessorMetaData();
//        CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
//        JobMetaData jobMetaData = new JobMetaData();
//        when(csvProcessorService.saveCsvProcessorJobRecord(any(JobMetaData.class))).thenReturn(jobMetaData);
//        JobMetaData result = csvProcessorsService.createCsvProcessorJobEntry(processor, csvProcessorTransaction, "jobType", "wrkFlow");
//        assertNotNull(result);
//    }

    @Test
    public void testCreateCsvProcessorRowTaskWithDetails() {
        CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();
        CsvProcessorRowTask rowTask = new CsvProcessorRowTask();
        when(csvProcessorService.saveCsvProcessorRowTask(any(CsvProcessorRowTask.class), anyBoolean())).thenReturn(rowTask);
        CsvProcessorRowTask result = csvProcessorsService.createCsvProcessorRowTask(processorTransaction, "csvFileName", "csvJsonFileName", 123, "request", "targetType");
        assertNotNull(result);
    }

    @Test
    public void testCreateCsvProcessorRowTaskWithStatus() {
        CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();
        CsvProcessorRowTask rowTask = new CsvProcessorRowTask();
        when(csvProcessorService.saveCsvProcessorRowTask(any(CsvProcessorRowTask.class), anyBoolean())).thenReturn(rowTask);
        CsvProcessorRowTask result = csvProcessorsService.createCsvProcessorRowTask(processorTransaction, 123, "csvFileName", "csvJsonFileName", 123, "request", MetaDataStatus.NEW);
        assertNotNull(result);
    }

    @Test
    public void testCreateCsvProcessorRowTaskWithTargetId() {
        CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();
        CsvProcessorRowTask rowTask = new CsvProcessorRowTask();
        when(csvProcessorService.saveCsvProcessorRowTask(any(CsvProcessorRowTask.class), anyBoolean())).thenReturn(rowTask);
        CsvProcessorRowTask result = csvProcessorsService.createCsvProcessorRowTask(processorTransaction, 123, "csvFileName", "csvJsonFileName", 123, "request", "targetId", MetaDataStatus.NEW);
        assertNotNull(result);
    }

    @Test
    public void testCreateCsvProcessorRowTaskFromExisting() {
        CsvProcessorRowTask rowTask = new CsvProcessorRowTask();
        when(csvProcessorService.saveCsvProcessorRowTask(any(CsvProcessorRowTask.class), anyBoolean())).thenReturn(rowTask);
        CsvProcessorRowTask result = csvProcessorsService.createCsvProcessorRowTask(rowTask);
        assertNotNull(result);
    }

    @Test
    public void testUpdateCsvProcessorRowTask() {
        CsvProcessorRowTask rowTask = new CsvProcessorRowTask();
        when(csvProcessorService.saveCsvProcessorRowTask(any(CsvProcessorRowTask.class), anyBoolean())).thenReturn(rowTask);
        CsvProcessorRowTask result = csvProcessorsService.updateCsvProcessorRowTask(rowTask);
        assertNotNull(result);
    }

    @Test
    public void testGetAllCsvProcessorsTransactions() {
        List<CsvProcessorTransaction> transactions = new ArrayList<>();
        when(csvProcessorService.getAllCsvProcessorTransactionInStatus(any(List.class), anyString(), anyInt())).thenReturn(transactions);
        List<CsvProcessorTransaction> result = csvProcessorsService.getAllCsvProcessorsTransactions(new ArrayList<>(), 0);
        assertNotNull(result);
    }

    @Test
    public void testGetCsvProcessorTransactionWithFileNameSimple() {
        CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();
        when(csvProcessorService.getCsvProcessorTransactionWithFileName(anyString())).thenReturn(processorTransaction);
        CsvProcessorTransaction result = csvProcessorsService.getCsvProcessorTransactionWithFileName("fileName");
        assertNotNull(result);
    }

    @Test
    public void testGetAllCompleteWithErrorsCsvProcessorsRowTasks() {
        List<CsvProcessorRowTask> rowTasks = new ArrayList<>();
        when(csvProcessorService.getAllCsvProcessorRowTaskInStatus(any(List.class), anyString(), anyString())).thenReturn(rowTasks);
        List<CsvProcessorRowTask> result = csvProcessorsService.getAllCompleteWithErrorsCsvProcessorsRowTasks("csvProcessorTransactionId");
        assertNotNull(result);
    }

    @Test
    public void testIsAllCsvProcessorRowTasksWithCsvProcessorTransactionIdComplete() {
        List<CsvProcessorRowTask> rowTasks = new ArrayList<>();
        when(csvProcessorService.getAllCsvProcessorRowTaskInStatus(any(List.class), anyString(), anyString())).thenReturn(rowTasks);
        Boolean result = csvProcessorsService.isAllCsvProcessorRowTasksWithCsvProcessorTransactionIdComplete("csvProcessorTransactionId");
        assertNotNull(result);
    }

    @Test
    public void testIsAllCsvProcessorRowTasksProcessed() {
        CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();
        processorTransaction.setRowCount(1);
        List<CsvProcessorRowTask> rowTasks = new ArrayList<>();
        when(csvProcessorService.getAllCsvProcessorRowTaskInStatus(any(List.class), anyString(), anyString())).thenReturn(rowTasks);
        Boolean result = csvProcessorsService.isAllCsvProcessorRowTasksProcessed(processorTransaction);
        assertNotNull(result);
    }

    @Test
    public void testGetCsvProcessorTransactionWithFileNameDetailed() {
        CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();
        when(csvProcessorService.getCsvProcessorTransactionWithFileName(anyString(), anyString(), anyString(), anyString())).thenReturn(processorTransaction);
        CsvProcessorTransaction result = csvProcessorsService.getCsvProcessorTransactionWithFileName("appIdentifier", "processorId", "fileName", "serverType");
        assertNotNull(result);
    }

    @Test
    public void testGetCsvTransactionProcessor_whenProcessorNotFound_throwsNotFoundException() {
        when(csvProcessorService.getCsvProcessorTransaction("processorId", "appIdentifier", "ose-batch"))
                .thenReturn(null);

        try {
            csvProcessorsService.getCsvTransactionProcessor("appIdentifier", "processorId");
            fail("Expected NotFoundException to be thrown");
        } catch (jakarta.ws.rs.NotFoundException ex) {
            assertEquals("Processor with id of processorId not found", ex.getMessage());
        }
    }

    @Test
    public void testGetCsvProcessorTransactionWithFileName_shouldThrowNotFoundExceptionWhenProcessorTransactionIsNull() {
        when(csvProcessorService.getCsvProcessorTransactionWithFileName(
                anyString(), anyString(), anyString(), anyString()))
                .thenReturn(null);

        try {
            csvProcessorsService.getCsvProcessorTransactionWithFileName("appIdentifier", "processorId", "fileName");
            fail("Expected NotFoundException to be thrown");
        } catch (jakarta.ws.rs.NotFoundException ex) {
            assertEquals("Processor with id of processorId not found", ex.getMessage());
        }
    }

    @Test
    public void testCreateCsvProcessorJobEntry_setsConfigPriorityAndSavesJobRecord() {
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setId("proc-1");
        processor.setConfigSpaceId(123);
        processor.setClientId(456);
        processor.setAppIdentifier("app-1");
        processor.setPriority(7);

        java.util.Map<String, Object> config = new java.util.HashMap<>();
        config.put("template_definition", "template-def");
        config.put("templateId", "template-1");
        config.put("delimit", ",");
        config.put("companionTRL", Boolean.TRUE);

        java.util.Map<String, Object> process = new java.util.HashMap<>();
        process.put("config", config);
        processor.setProcess(process);

        CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
        csvProcessorTransaction.setId("txn-1");
        csvProcessorTransaction.setFileName("input.csv");
        csvProcessorTransaction.setLocation("C:/input");

        com.optum.fds.paperless.util.FileUtil fileUtil =
                org.mockito.Mockito.mock(com.optum.fds.paperless.util.FileUtil.class);
        org.mockito.Mockito.when(fileUtil.getLocalHostName()).thenReturn("host-1");

        try (org.mockito.MockedStatic<com.optum.fds.paperless.util.FileUtil> mockedFileUtil =
                     org.mockito.Mockito.mockStatic(com.optum.fds.paperless.util.FileUtil.class)) {

            mockedFileUtil.when(com.optum.fds.paperless.util.FileUtil::getInstance).thenReturn(fileUtil);

            JobMetaData result = csvProcessorsService.createCsvProcessorJobEntry(
                    processor, csvProcessorTransaction, "CSV_JOB", "csvWorkflow");

            assertNotNull(result);

            org.mockito.ArgumentCaptor<JobMetaData> captor =
                    org.mockito.ArgumentCaptor.forClass(JobMetaData.class);
            org.mockito.Mockito.verify(csvProcessorService).saveCsvProcessorJobRecord(captor.capture());

            JobMetaData savedJob = captor.getValue();
            assertSame(result, savedJob);

            assertEquals("CSV_JOB", savedJob.getJobType());
            assertEquals("csvWorkflow", savedJob.getWorkFlow());
            assertEquals("proc-1", savedJob.getProcessorId());
            assertEquals("txn-1", savedJob.getCsvProcessorTransactionId());
            assertEquals("input.csv", savedJob.getFileName());
            assertEquals("C:/input", savedJob.getFilePath());

            assertEquals("template-def",
                    org.springframework.test.util.ReflectionTestUtils.getField(savedJob, "templateDefinition"));
            assertEquals("template-1",
                    org.springframework.test.util.ReflectionTestUtils.getField(savedJob, "templateId"));
            assertEquals(",",
                    org.springframework.test.util.ReflectionTestUtils.getField(savedJob, "delimit"));
            assertEquals(Boolean.TRUE,
                    org.springframework.test.util.ReflectionTestUtils.getField(savedJob, "companionTRL"));
            assertEquals(7,
                    org.springframework.test.util.ReflectionTestUtils.getField(savedJob, "priority"));
            assertEquals("host-1",
                    org.springframework.test.util.ReflectionTestUtils.getField(savedJob, "serverName"));
        }
    }

    @Test
    public void testGetCsvProcessorTransactionWithFileNameDetailed_whenProcessorTransactionIsNull_throwsNotFoundException() {
        when(csvProcessorService.getCsvProcessorTransactionWithFileName(
                "processorId", "appIdentifier", "fileName", "serverType"))
                .thenReturn(null);

        try {
            csvProcessorsService.getCsvProcessorTransactionWithFileName(
                    "appIdentifier", "processorId", "fileName", "serverType");
            fail("Expected NotFoundException to be thrown");
        } catch (jakarta.ws.rs.NotFoundException ex) {
            assertEquals("Processor with id of processorId not found", ex.getMessage());
        }
    }

}