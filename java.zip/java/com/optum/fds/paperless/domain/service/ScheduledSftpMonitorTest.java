package com.optum.fds.paperless.domain.service;

import com.jcraft.jsch.*;
import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.SftpMonitorUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ScheduledSftpMonitorTest {

    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Mock
    private ChannelSftp channelSftp;

    @Mock
    private ProcessorService processorService;

    @Mock
    private ProcessorsService processorsService;

    @Mock
    private SftpMonitorUtil sftpMonitorUtil;

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @InjectMocks
    private ScheduledSftpMonitor scheduledSftpMonitor;

    private ProcessorMetaData processorMetaData;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        processorMetaData = new ProcessorMetaData();
        processorMetaData.setId("1234");
        processorMetaData.setAppIdentifier("testapp");
        processorMetaData.setName("TestOne");
        processorMetaData.setProcess(new HashMap<>());
        processorMetaData.setProcessorRecordType(ProcessorRecordTypes.processor);
        processorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
        processorMetaData.setConfigSpaceId(10102);

//        when(processorsService.getProcessor(anyString(), anyString())).thenReturn(processorMetaData);
    }

    @Test
    public void testRunSFTPMonitor() throws IOException, SftpException, FSDataException {
//        Map<String, Object> processConfig = new HashMap<>();
//        Map<String, Object> config = new HashMap<>();
//        config.put("host_name_source", "sftpHost");
//        config.put("username_source", "sftpUser");
//        config.put("pw_source", "sftpPass");
//        config.put("ftp_rootdir", "/root/dir");
//        config.put("ftp_archivedir", "/archive/dir");
//        config.put("zipFilePattern", ".*\\.zip");
//        processConfig.put("config", config);
//        processorMetaData.getProcess().put("process", processConfig);
//
//        Map<String, Object> sftpResults = new HashMap<>();
//        sftpResults.put("directoryListing", new ArrayList<ChannelSftp.LsEntry>() {{
//            add(mock(ChannelSftp.LsEntry.class));
//        }});
//        sftpResults.put("channelSftp", mock(ChannelSftp.class));
//        sftpResults.put("sftpSession", mock(Session.class));
//        sftpResults.put("channel", mock(Channel.class));
//
//        when(sftpMonitorUtil.hasValidStatus(any(ProcessorMetaData.class))).thenReturn(true);
//        try {
//            when(sftpMonitorUtil.proccessSFTPDirectory(anyString(), anyString(), anyString(), anyString())).thenReturn(sftpResults);
//        } catch (JSchException e) {
//            throw new RuntimeException(e);
//        }
//        when(processorsService.findProcessorMetaDataByFileName(anyString(), anyString())).thenReturn(null);
//        when(processorsService.createTransactionRecord(any(ProcessorMetaData.class))).thenReturn(new Transaction());
//        when(sftpMonitorUtil.createFileOutputDirectoryPath(anyMap(), any(ProcessorMetaData.class), anyString())).thenReturn("/output/dir");
//        when(processorsService.createProcessorTransaction(any(ProcessorMetaData.class), anyString(), anyString(), anyString())).thenReturn(new ProcessorTransaction());
//
//        List<String> result = scheduledSftpMonitor.runSFTPMonitor(processorMetaData);
//
//        assertNotNull(result);
//        verify(sftpMonitorUtil, times(1)).closeSFTPChannel(any(ChannelSftp.class), any(Session.class), any(Channel.class));
    }

    @Test
    public void testCheckAndCreateSftpLockFile() throws IOException {
        String filePath = tempFolder.getRoot().getAbsolutePath();
        boolean result = scheduledSftpMonitor.checkAndCreateSftpLockFile(filePath);

        assertFalse(result);
        assertTrue(new File(filePath, "sftp_locked.txt").exists());
    }

    @Test
    public void testCreateLockFile() throws IOException {
        String filePath = tempFolder.getRoot().getAbsolutePath();
        boolean result = scheduledSftpMonitor.createLockFile(filePath);

        assertTrue(result);
        assertTrue(new File(filePath, "sftp_locked.txt").exists());
    }

    @Test
    public void testTouch() throws IOException {
        File file = new File(tempFolder.getRoot(), "testFile.txt");
        boolean result = scheduledSftpMonitor.touch(file);

        assertTrue(result);
        assertTrue(file.exists());
    }

    @Test
    public void testCreateProcessorTransaction() {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        String entryFileName = "testFile.zip";
        String filePath = "/test/path";
        String transactionId = "12345";

        ProcessorTransaction mockProcessorTransaction = new ProcessorTransaction();
        mockProcessorTransaction.setId("mockTransactionId");

        when(processorsService.createProcessorTransaction(any(), anyString(), anyString(), anyString()))
                .thenReturn(mockProcessorTransaction);

        String result = scheduledSftpMonitor.createProcessorTransaction(processorMetaData, entryFileName, filePath, transactionId);

        assertNotNull(result);
        assertEquals("mockTransactionId", result);
    }

    @Test
    public void testArchiveZipFile() throws IOException, SftpException {
        String sftpWorkingDir = "/root/dir";
        String sftpArchiveDir = "/archive/dir";
        String fileName = "testFile.zip";
        ChannelSftp channelSftp = mock(ChannelSftp.class);

        scheduledSftpMonitor.archiveZipFile(sftpWorkingDir, sftpArchiveDir, fileName, channelSftp);

        verify(channelSftp, times(1)).rename(eq(sftpWorkingDir + "/" + fileName), eq(sftpArchiveDir + "/" + fileName));
    }

    @Test
    public void testLogWithCorrelationId() {
        Exception ex = new Exception("Test Exception");
        String cFileName = "testFile.zip";
        String cProcessorId = "1234";
        String cProcessorTransactionId = "5678";

        scheduledSftpMonitor.logWithCorrelationId(ex, cFileName, cProcessorId, cProcessorTransactionId);

        assertNotNull(ex.getMessage());
    }

    @Test
    public void testRunSFTPMonitor_HappyPath_AddsTransactionId_AndClosesChannel() throws Exception {
        ScheduledSftpMonitor spyMonitor = Mockito.spy(scheduledSftpMonitor);

        ProcessorMetaData in = new ProcessorMetaData();
        Map<String, Object> processRoot = new HashMap<>();
        processRoot.put("appIdentifier", "testapp");
        processRoot.put("id", "pid-1");

        Map<String, Object> config = new HashMap<>();
        config.put("host_name_source", "host");
        config.put("username_source", "user");
        config.put("pw_source", "pass");
        config.put("ftp_rootdir", "/drop");
        config.put("ftp_archivedir", "/archive");
        config.put("zipFilePattern", ".*\\.zip");

        Map<String, Object> processNode = new HashMap<>();
        processNode.put("config", config);
        processRoot.put("process", processNode);
        in.setProcess(processRoot);

        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setId("proc-1");
        processor.setAppIdentifier("testapp");
        processor.setConfigSpaceId(101);

        ChannelSftp.LsEntry zipEntry = mock(ChannelSftp.LsEntry.class);
        when(zipEntry.getFilename()).thenReturn("a.zip").thenReturn("a.zip");
        when(zipEntry.getAttrs()).thenReturn(mock(SftpATTRS.class));

        ArrayList<ChannelSftp.LsEntry> listing = new ArrayList<>();
        listing.add(zipEntry);

        ChannelSftp channelSftp = mock(ChannelSftp.class);
        Session session = mock(Session.class);
        Channel channel = mock(Channel.class);

        Map<String, Object> sftpResults = new HashMap<>();
        sftpResults.put("directoryListing", listing);
        sftpResults.put("channelSftp", channelSftp);
        sftpResults.put("sftpSession", session);
        sftpResults.put("channel", channel);

        when(sftpMonitorUtil.exceptionForMissingLoginCredential(anyString(), anyString(), anyString(), anyString())).thenReturn(true);
        when(processorsService.getProcessor(eq("testapp"), eq("pid-1"))).thenReturn(processor);
        when(sftpMonitorUtil.hasValidStatus(processor)).thenReturn(true);
        when(sftpMonitorUtil.proccessSFTPDirectory(eq("user"), eq("pass"), eq("host"), eq("/drop"))).thenReturn(sftpResults);
        when(processorsService.findProcessorMetaDataByFileName("a.zip", "testapp")).thenReturn(null);

        doReturn(true).when(spyMonitor).validateZipFileName("a.zip", ".*\\.zip");
        doReturn("ptx-1").when(spyMonitor).processFromCurrentDir(eq(processor), anyMap(), eq(sftpResults), eq("a.zip"), anyLong());

        List<String> result = spyMonitor.runSFTPMonitor(in);

        assertEquals(1, result.size());
        assertEquals("ptx-1", result.get(0));
        verify(sftpMonitorUtil, times(1)).closeSFTPChannel(channelSftp, session, channel);
        verify(processorsService, times(1)).setLastRunAndStatus("proc-1", MetaDataStatus.IN_PROCESS);
    }

    @Test
    public void testRunSFTPMonitor_StatusInvalid_ElseBranch() throws Exception {
        ProcessorMetaData in = new ProcessorMetaData();
        Map<String, Object> processRoot = new HashMap<>();
        processRoot.put("appIdentifier", "testapp");
        processRoot.put("id", "pid-2");

        Map<String, Object> config = new HashMap<>();
        config.put("host_name_source", "host");
        config.put("username_source", "user");
        config.put("pw_source", "pass");
        config.put("ftp_rootdir", "/drop");
        config.put("ftp_archivedir", "/archive");
        config.put("zipFilePattern", ".*\\.zip");

        Map<String, Object> processNode = new HashMap<>();
        processNode.put("config", config);
        processRoot.put("process", processNode);
        in.setProcess(processRoot);

        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setId("proc-2");
        processor.setAppIdentifier("testapp");
        processor.setConfigSpaceId(202);

        when(sftpMonitorUtil.exceptionForMissingLoginCredential(anyString(), anyString(), anyString(), anyString())).thenReturn(true);
        when(processorsService.getProcessor(eq("testapp"), eq("pid-2"))).thenReturn(processor);
        when(sftpMonitorUtil.hasValidStatus(processor)).thenReturn(false);

        List<String> result = scheduledSftpMonitor.runSFTPMonitor(in);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(sftpMonitorUtil, never()).proccessSFTPDirectory(anyString(), anyString(), anyString(), anyString());
        verify(processorsService, never()).setLastRunAndStatus(anyString(), any());
    }

    @Test
    public void testRunSFTPMonitor_CatchAndFinally_WhenSftpProcessingThrows() throws Exception {
        ScheduledSftpMonitor spyMonitor = Mockito.spy(scheduledSftpMonitor);

        ProcessorMetaData in = new ProcessorMetaData();
        Map<String, Object> processRoot = new HashMap<>();
        processRoot.put("appIdentifier", "testapp");
        processRoot.put("id", "pid-3");

        Map<String, Object> config = new HashMap<>();
        config.put("host_name_source", "host");
        config.put("username_source", "user");
        config.put("pw_source", "pass");
        config.put("ftp_rootdir", "/drop");
        config.put("ftp_archivedir", "/archive");
        config.put("zipFilePattern", ".*\\.zip");

        Map<String, Object> processNode = new HashMap<>();
        processNode.put("config", config);
        processRoot.put("process", processNode);
        in.setProcess(processRoot);

        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setId("proc-3");
        processor.setAppIdentifier("testapp");
        processor.setConfigSpaceId(303);

        when(sftpMonitorUtil.exceptionForMissingLoginCredential(anyString(), anyString(), anyString(), anyString())).thenReturn(true);
        when(processorsService.getProcessor(eq("testapp"), eq("pid-3"))).thenReturn(processor);
        when(sftpMonitorUtil.hasValidStatus(processor)).thenReturn(true);
        when(sftpMonitorUtil.proccessSFTPDirectory(anyString(), anyString(), anyString(), anyString()))
                .thenThrow(new RuntimeException("boom"));

        doNothing().when(spyMonitor).logWithCorrelationId(any(Exception.class), anyString(), anyString(), anyString());

        List<String> result = spyMonitor.runSFTPMonitor(in);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(spyMonitor, times(1)).logWithCorrelationId(any(Exception.class), anyString(), eq("proc-3"), anyString());
        verify(processorsService, times(1)).setLastRunAndStatus("proc-3", MetaDataStatus.IN_PROCESS);
        verify(sftpMonitorUtil, never()).closeSFTPChannel(any(ChannelSftp.class), any(Session.class), any(Channel.class));
    }

    @Test
    public void testRunSFTPMonitor_Filters_NonZip_Ack_Existing_InvalidRegex_AndEmptyTransaction() throws Exception {
        ScheduledSftpMonitor spyMonitor = Mockito.spy(scheduledSftpMonitor);

        ProcessorMetaData in = new ProcessorMetaData();
        Map<String, Object> processRoot = new HashMap<>();
        processRoot.put("appIdentifier", "testapp");
        processRoot.put("id", "pid-4");

        Map<String, Object> config = new HashMap<>();
        config.put("host_name_source", "host");
        config.put("username_source", "user");
        config.put("pw_source", "pass");
        config.put("ftp_rootdir", "/drop");
        config.put("ftp_archivedir", "/archive");
        config.put("zipFilePattern", ".*\\.zip");

        Map<String, Object> processNode = new HashMap<>();
        processNode.put("config", config);
        processRoot.put("process", processNode);
        in.setProcess(processRoot);

        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setId("proc-4");
        processor.setAppIdentifier("testapp");
        processor.setConfigSpaceId(404);

        ChannelSftp.LsEntry csv = mock(ChannelSftp.LsEntry.class);
        when(csv.getFilename()).thenReturn("a.csv");
        ChannelSftp.LsEntry ack = mock(ChannelSftp.LsEntry.class);
        when(ack.getFilename()).thenReturn("a_ack.zip");
        ChannelSftp.LsEntry existing = mock(ChannelSftp.LsEntry.class);
        when(existing.getFilename()).thenReturn("b.zip");
        ChannelSftp.LsEntry invalid = mock(ChannelSftp.LsEntry.class);
        when(invalid.getFilename()).thenReturn("c.zip");
        ChannelSftp.LsEntry emptyTx = mock(ChannelSftp.LsEntry.class);
        when(emptyTx.getFilename()).thenReturn("d.zip");

        ArrayList<ChannelSftp.LsEntry> listing = new ArrayList<>(Arrays.asList(csv, ack, existing, invalid, emptyTx));

        Map<String, Object> sftpResults = new HashMap<>();
        sftpResults.put("directoryListing", listing);
        sftpResults.put("channelSftp", mock(ChannelSftp.class));
        sftpResults.put("sftpSession", mock(Session.class));
        sftpResults.put("channel", mock(Channel.class));

        when(sftpMonitorUtil.exceptionForMissingLoginCredential(anyString(), anyString(), anyString(), anyString())).thenReturn(true);
        when(processorsService.getProcessor(eq("testapp"), eq("pid-4"))).thenReturn(processor);
        when(sftpMonitorUtil.hasValidStatus(processor)).thenReturn(true);
        when(sftpMonitorUtil.proccessSFTPDirectory(anyString(), anyString(), anyString(), anyString())).thenReturn(sftpResults);

        when(processorsService.findProcessorMetaDataByFileName("b.zip", "testapp")).thenReturn(new ProcessorMetaData());
        when(processorsService.findProcessorMetaDataByFileName("c.zip", "testapp")).thenReturn(null);
        when(processorsService.findProcessorMetaDataByFileName("d.zip", "testapp")).thenReturn(null);

        doReturn(false).when(spyMonitor).validateZipFileName("c.zip", ".*\\.zip");
        doReturn(true).when(spyMonitor).validateZipFileName("d.zip", ".*\\.zip");

        List<String> result = spyMonitor.runSFTPMonitor(in);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(spyMonitor, never()).processFromCurrentDir(eq(processor), anyMap(), eq(sftpResults), eq("c.zip"), anyLong());
        verify(processorsService, times(1)).setLastRunAndStatus("proc-4", MetaDataStatus.IN_PROCESS);
    }

    @Test
    public void testValidateZipFileName_ShouldReturnTrue_WhenRegexMatches() {
        boolean result = scheduledSftpMonitor.validateZipFileName(
                "sample_20240610.zip",
                ".*\\.zip"
        );

        assertTrue(result);
    }

    @Test
    public void testProcessFromCurrentDir_ShouldCreateProcessorTransaction_WhenExistingFileSizeMatches() throws Exception {
        ScheduledSftpMonitor spyMonitor = Mockito.spy(scheduledSftpMonitor);

        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setId("proc-1");

        Transaction transaction = new Transaction();
        transaction.setTransactionId("txn-1");

        File ingestDir = temporaryFolder.newFolder("ingest-dir");
        File ingestZip = new File(ingestDir, "sample.zip");
        Files.write(ingestZip.toPath(), "12345".getBytes(StandardCharsets.UTF_8));
        long expectedSize = ingestZip.length();

        Map<String, Object> processSftpResults = new HashMap<>();
        processSftpResults.put("channelSftp", channelSftp);

        when(processorsService.createTransactionRecord(processor)).thenReturn(transaction);
        when(sftpMonitorUtil.createFileOutputDirectoryPath(anyMap(), eq(processor), eq("sample.zip")))
                .thenReturn(ingestDir.getAbsolutePath());

        doReturn("pt-123")
                .when(spyMonitor)
                .createProcessorTransaction(
                        eq(processor),
                        eq("sample.zip"),
                        eq(ingestDir.getAbsolutePath()),
                        eq("txn-1")
                );

        String result = spyMonitor.processFromCurrentDir(
                processor,
                new HashMap(),
                processSftpResults,
                "sample.zip",
                expectedSize
        );

        assertEquals("pt-123", result);
        verify(spyMonitor).createProcessorTransaction(
                processor,
                "sample.zip",
                ingestDir.getAbsolutePath(),
                "txn-1"
        );
        verify(channelSftp, never()).get(anyString(), anyString());
    }

    @Test
    public void testProcessFromCurrentDir_ShouldReturnEmpty_WhenLockFileAlreadyExists() throws Exception {
        ScheduledSftpMonitor spyMonitor = Mockito.spy(scheduledSftpMonitor);

        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setId("proc-1");

        Transaction transaction = new Transaction();
        transaction.setTransactionId("txn-1");

        File ingestDir = temporaryFolder.newFolder("ingest-lock-dir");

        Map<String, Object> processSftpResults = new HashMap<>();
        processSftpResults.put("channelSftp", channelSftp);

        when(processorsService.createTransactionRecord(processor)).thenReturn(transaction);
        when(sftpMonitorUtil.createFileOutputDirectoryPath(anyMap(), eq(processor), eq("sample.zip")))
                .thenReturn(ingestDir.getAbsolutePath());

        doReturn(true)
                .when(spyMonitor)
                .checkAndCreateSftpLockFile(ingestDir.getAbsolutePath());

        String result = spyMonitor.processFromCurrentDir(
                processor,
                new HashMap(),
                processSftpResults,
                "sample.zip",
                999L
        );

        assertEquals("", result);
        verify(channelSftp, never()).get(anyString(), anyString());
    }

    @Test
    public void testTouchShouldReturnFalseWhenFileAlreadyExists() throws IOException {
        ScheduledSftpMonitor scheduledSftpMonitor = new ScheduledSftpMonitor();
        Path tempFile = Files.createTempFile("sftp-lock", ".txt");

        boolean result = scheduledSftpMonitor.touch(tempFile.toFile());

        assertFalse(result);

        Files.deleteIfExists(tempFile);
    }
}