package com.optum.fds.paperless.domain.service;


import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

import java.util.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.mongodb.client.result.UpdateResult;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.AttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.HookEventType;
import com.optum.fds.paperless.mongo.HookMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.util.DocumentUtil;
import org.springframework.test.util.ReflectionTestUtils;

@RunWith(MockitoJUnitRunner.class)

public class HookServiceImplTest {

	@Mock
	MongoTemplate mongoTemplate;
	
	@Mock
	DocumentUtil documentUtil;
	
	@Mock
	MongoOperations mongoOperations;
	
	@Mock MetaDataStatus metadata;
	
	@InjectMocks
	HookServiceImpl hookService;

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void testSaveHook() {
		HookMetaData hookMetaData=new HookMetaData();
		when(mongoTemplate.insert(any(HookMetaData.class))).thenReturn(hookMetaData);
		HookMetaData result = hookService.saveHook(hookMetaData);
		assertNotNull(result);
    }
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findAllAvailableHookMetaData() {
		List<HookMetaData> list=new ArrayList();
		HookMetaData hookMetaData=new HookMetaData();
		when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class))).thenReturn(list);
		List<HookMetaData> result = hookService.findAllAvailableHookMetaData();
		assertNotNull(result);
    }
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void registerEventOfInterestTest() { 
		HookEventType hookEventType=new HookEventType();
		//doNothing().when(mongoTemplate.insert(eq(HookEventType.class), anyString()));
		hookService.registerEventOfInterest(hookEventType);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findTopOfStackNewHookEventTest() { 
		HookEventType event=new HookEventType();
		HookEventType result=new HookEventType();
		when(mongoTemplate.findAndModify(any(Query.class),
    			any(Update.class),
    			eq(HookEventType.class),
    			anyString())).thenReturn(event);
		event= hookService.findTopOfStackNewHookEvent();
		assertNotNull(event);
		assertNotNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findTopOfStackNewJobTest() { 
		JobMetaData event=new JobMetaData();
		JobMetaData result=new JobMetaData();
		when(mongoTemplate.findAndModify(any(Query.class),
    			any(Update.class),
    			eq(JobMetaData.class),
    			anyString())).thenReturn(event);
		result= hookService.findTopOfStackNewJob();
		assertNotNull(event);
		assertNotNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void updatePDODocumentMetaDataTest() { 
		DocumentMetaData doc = new DocumentMetaData();
		org.bson.Document  metaData=new org.bson.Document();
		doc.setMetadata(metaData);
		when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), anyString())).thenReturn(doc);
		DocumentMetaData result = hookService.findDocumentByTransactionId("test");
		assertNotNull(result);
		assertEquals(result, doc);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findAttachmentsByTransactionIdTest() { 
		List<AttachmentMetaData> doc = new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(AttachmentMetaData.class), anyString())).thenReturn(doc);
		List<AttachmentMetaData> result = hookService.findAttachmentsByTransactionId("test");
		assertNotNull(result);
		assertEquals(result, doc);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findAttachmentByFsIdTest() { 
		AttachmentMetaData doc = new AttachmentMetaData();
		when(mongoTemplate.findOne(any(Query.class), eq(AttachmentMetaData.class), anyString())).thenReturn(doc);
		AttachmentMetaData result = hookService.findAttachmentByFsId("test");
		assertNotNull(result);
		assertEquals(result, doc);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findAllHooksThatMatchTopLevelCriteriaTest() { 
		List<HookMetaData> doc = new ArrayList();
		HookEventType hookEvent=new HookEventType();
		when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class), anyString())).thenReturn(doc);
		List<HookMetaData> result = hookService.findAllHooksThatMatchTopLevelCriteria(hookEvent);
		assertNotNull(result);
		assertEquals(result, doc);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findIfHookTransactionExistsForDocTest() { 
		List<HookTransactionMetaData> doc = new ArrayList();
		DocumentMetaData docMetdata=new DocumentMetaData();
		when(mongoTemplate.find(any(Query.class), eq(HookTransactionMetaData.class), anyString())).thenReturn(doc);
		List<HookTransactionMetaData> result = hookService.findIfHookTransactionExistsForDoc(docMetdata);
		assertNotNull(result);
		assertEquals(result, doc);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findHookTransactionMetaDataForDocAndHookTest() { 
		List<HookTransactionMetaData> doc = new ArrayList();
		DocumentMetaData docMetdata=new DocumentMetaData();
		when(mongoTemplate.find(any(Query.class), eq(HookTransactionMetaData.class), anyString())).thenReturn(doc);
		List<HookTransactionMetaData> result = hookService.findHookTransactionMetaDataForDocAndHook(docMetdata, "test");
		assertNotNull(result);
		assertEquals(result, doc);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void getHookByIdTest() { 
		HookMetaData doc = new HookMetaData();
		List<HookMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class))).thenReturn(hmds);
		HookMetaData result = hookService.getHookById("test", 0, "3");
		assertNull(result);
		assertNotNull(hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void getHookById2Test() { 
		List<HookMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class))).thenReturn(hmds);
		HookMetaData result = hookService.getHookById("test", "3");
		assertNull(result);
		assertNotNull(hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void getHooksByNameTest() { 
		List<HookMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class))).thenReturn(hmds);
		List<HookMetaData> result = hookService.getHooksByName("test", 0, "3");
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void getHooksTest() { 
		List<HookMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class))).thenReturn(hmds);
		List<HookMetaData> result = hookService.getHooks("test", 0, "3");
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void putHookMetaDataTest() { 
		HookMetaData doc = new HookMetaData();
		doc.setAppIdentifier("appId");
		doc.setHook(new org.bson.Document());
		doc.setErrorMessage("error");
		when(mongoTemplate.findAndModify(any(Query.class),
    			any(Update.class),
    			any(FindAndModifyOptions.class),
    			eq(HookMetaData.class))).thenReturn(doc);
		HookMetaData result = hookService.putHookMetaData(new HookMetaData());
		assertNotNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void deleteHookTest() { 
		HookMetaData doc = new HookMetaData();
		when(mongoTemplate.findAndModify(any(Query.class),
    			any(Update.class),
    			any(FindAndModifyOptions.class),
    			eq(HookMetaData.class)
    			)).thenReturn(doc);
		HookMetaData result = hookService.deleteHook("appId", 0, "id");
		assertNotNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void saveJobRecordTest() { 
		JobMetaData jmd=new JobMetaData();
		when(mongoTemplate.insert(any(JobMetaData.class), anyString())).thenReturn(jmd);
		JobMetaData result=hookService.saveJobRecord(new JobMetaData());
		assertEquals(result.getAppIdentifier(), jmd.getAppIdentifier());
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void saveHookTransactionTest() { 
		HookTransactionMetaData hmd=new HookTransactionMetaData();
		when(mongoTemplate.insert(any(HookTransactionMetaData.class), anyString())).thenReturn(hmd);
		HookTransactionMetaData result=hookService.saveHookTransaction(new HookTransactionMetaData());
		assertEquals(result.getAppIdentifier(), hmd.getAppIdentifier());
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void updateHookTransactionTest() { 
		HookTransactionMetaData hmd=new HookTransactionMetaData();
		when(mongoTemplate.findAndModify(any(Query.class),
    			any(Update.class),
    			eq(HookTransactionMetaData.class),
    			anyString())).thenReturn(hmd);
		HookTransactionMetaData result=hookService.updateHookTransaction(new HookTransactionMetaData());
		assertNotNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void deleteHookEventFromStackTest() { 
		HookEventType hmd=new HookEventType();
		when(mongoTemplate.findAndRemove(any(Query.class),
    			eq(HookEventType.class),
    			anyString())).thenReturn(hmd);
		HookEventType result=hookService.deleteHookEventFromStack("test");
		assertNotNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void deleteJobFromStackTest() { 
		JobMetaData hmd=new JobMetaData();
		when(mongoTemplate.findAndRemove(any(Query.class),
    			eq(JobMetaData.class),
    			anyString())).thenReturn(hmd);
		JobMetaData result=hookService.deleteJobFromStack("test");
		//assertEquals(result.getAppIdentifier(), hmd.getAppIdentifier());
		assertNotNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void deleteJobsTest() { 
		JobMetaData hmd=new JobMetaData();
		List<JobMetaData> jobIdList=new ArrayList();
		hookService.deleteJobs(jobIdList);
		assertNotNull(hmd);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void searchAllJobsTest() { 
		List<JobMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(hmds);
		List<JobMetaData> result = hookService.searchAllJobs(0);
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void searchStandardJobsTest() { 
		List<JobMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(hmds);
		List<JobMetaData> result = hookService.searchStandardJobs(0);
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void searchCronJobsTest() { 
		List<JobMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(hmds);
		List<JobMetaData> result = hookService.searchCronJobs(0);
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void searchAllJobsBySpaceIdHookIdsTest() { 
		List<JobMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(hmds);
		List<JobMetaData> result = hookService.searchAllJobsBySpaceIdHookId(0, "test");
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void searchDocumentsBySpaceIdAndDateFieldTest() { 
		List<DocumentMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), anyString())).thenReturn(hmds);
		List<DocumentMetaData> result = hookService.searchDocumentsBySpaceIdAndDateField(0, "test", "test");
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void searchForJobsTest() { 
		List<JobMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(hmds);
		List<JobMetaData> result = hookService.searchForJobs("test");
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void searchForJobs2Test() { 
		List<JobMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(hmds);
		List<JobMetaData> result = hookService.searchForJobs("test", "test");
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void searchForAllJobsTest() { 
		List<JobMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(hmds);
		List<JobMetaData> result = hookService.searchForAllJobs("test", "test");
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void searchForAllJobTypesTest() { 
		List<JobMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(hmds);
		List<JobMetaData> result = hookService.searchForAllJobTypes("test", "test");
		assertNotNull(result);
		assertEquals(result, hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void retrieveHookJobIdListTest() { 
		List<JobMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(hmds);
		List<String> result = hookService.retrieveHookJobIdList(4);
		assertNotNull(result);
		assertNotNull(hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findJobsByStatusTest() { 
		List<JobMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(hmds);
		List<JobMetaData> result = hookService.findJobsByStatus(MetaDataStatus.OK);
		assertNotNull(result);
		assertNotNull(hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findHookJobTest() { 
		JobMetaData hmds=new JobMetaData();
		when(mongoTemplate.findById(anyString(), eq(JobMetaData.class))).thenReturn(hmds);
		JobMetaData result = hookService.findHookJob("test");
		assertNotNull(result);
		assertNotNull(hmds);	
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findTopOfStackNewCronJobTest() { 
		JobMetaData hmds=new JobMetaData();
		when(mongoTemplate.findAndModify(any(Query.class),
    			any(Update.class),
    			eq(JobMetaData.class),
    			anyString())).thenReturn(hmds);
		JobMetaData result = hookService.findTopOfStackNewCronJob();
		assertNotNull(result);
		assertNotNull(hmds);	
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void retrieveNewCronJobIdListTest() { 
		List<JobMetaData> hmds=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(hmds);
		List<String> result = hookService.retrieveNewCronJobIdList(4);
		assertNotNull(result);
		assertNotNull(hmds);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void markHookInvalidTest() { 
		HookMetaData hmds=new HookMetaData();
		when(mongoTemplate.findAndModify(any(Query.class),
    			any(Update.class),
    			eq(HookMetaData.class),
    			anyString())).thenReturn(hmds);
		hookService.markHookInvalid("test");
		assertNotNull(hmds);	
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void updateHookExecutionRecordOfHookTransactionRecordTest() {
		HookTransactionMetaData hookTransactionMetaData=new HookTransactionMetaData();
		Map<String, Object> resultMap=new HashMap();
		when(mongoTemplate.findAndModify(any(Query.class),
    			any(Update.class),
    			eq(HookTransactionMetaData.class),
    			anyString())).thenReturn(hookTransactionMetaData);
		HookTransactionMetaData res=hookService.updateHookExecutionRecordOfHookTransactionRecord("test", "test", "test", resultMap);
		assertNotNull(res);	
		assertNotNull(hookTransactionMetaData);	

	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findHookTransactionByTargetIdHookIdHookExecutionIdTest() {
		HookTransactionMetaData hookTransactionMetaData=new HookTransactionMetaData();
		Map<String, Object> resultMap=new HashMap();
		when(mongoTemplate.findOne(any(Query.class), eq(HookTransactionMetaData.class), anyString())).thenReturn(hookTransactionMetaData);
		HookTransactionMetaData res=hookService.findHookTransactionByTargetIdHookIdHookExecutionId("test", "test", "test");
		assertNotNull(res);	
		assertNotNull(hookTransactionMetaData);	
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findModifiedDocumentTest() {
		DocumentMetaData documentMetaData=new DocumentMetaData();
		when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), anyString())).thenReturn(documentMetaData);
		DocumentMetaData res=hookService.findModifiedDocument("test", new Date());
		assertNotNull(res);	
		assertNotNull(documentMetaData);	
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void searchAllActiveJobsBySpaceIdHookIdTest() {
		List<JobMetaData> jobMetaData=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), anyString())).thenReturn(jobMetaData);
		List<JobMetaData> res=hookService.searchAllActiveJobsBySpaceIdHookId(0, "test");
		assertNotNull(res);	
		assertNotNull(jobMetaData);	
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void updateJobStatusTest() {
		List<JobMetaData> jobMetaData=new ArrayList();
		hookService.updateJobStatus("test", "test");
		assertNotNull(jobMetaData);	
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void saveCronExpressionHookTransactionTest() {
		HookTransactionMetaData hookTransactionMetaData=new HookTransactionMetaData();
		when(mongoTemplate.insert(any(HookTransactionMetaData.class), anyString())).thenReturn(hookTransactionMetaData);
		HookTransactionMetaData res=hookService.saveCronExpressionHookTransaction(hookTransactionMetaData);
		assertNotNull(res);	
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void updateHookExecutionRecordOfCronExpressionHookTransactionRecordTest() {
		HookTransactionMetaData hookTransactionMetaData=new HookTransactionMetaData();
		Map<String, Object> resultMap=new HashMap();
		when(mongoTemplate.findAndModify(any(Query.class),
    			any(Update.class),
    			eq(HookTransactionMetaData.class),
    			anyString())).thenReturn(hookTransactionMetaData);
		HookTransactionMetaData res=hookService.updateHookExecutionRecordOfCronExpressionHookTransactionRecord("test", "test", "test", "test", resultMap);
		assertNotNull(res);	
		assertNotNull(hookTransactionMetaData);	

	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void lockHookTest() { 
		hookService.lockHook("test");
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void unlockHookTest() { 
		hookService.unlockHook("test");
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void updateHookTest() {
		HookMetaData hookMetaData=new HookMetaData();
		UpdateResult updateResult=null;
		
		Map<String, Object> resultMap=new HashMap<String, Object>();
		resultMap.put("hook", resultMap);
		resultMap.put("action", resultMap);
	resultMap.put("config", resultMap);
		hookMetaData.setId("test");
		when(mongoTemplate.updateFirst(any(Query.class),
    			any(Update.class),
    			eq(HookMetaData.class),
    			anyString())).thenReturn(updateResult);
		hookService.updateHook(hookMetaData, resultMap);
		assertNull(updateResult);	
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void getHookById3Test() {
		List<HookMetaData> jobMetaData=new ArrayList();
		when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class))).thenReturn(jobMetaData);
		HookMetaData res=hookService.getHookById("test");
		assertNull(res);	
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void deleteHook2Test() { 
		HookMetaData hmd=new HookMetaData();
		when(mongoTemplate.findAndRemove(any(Query.class),
    			eq(HookMetaData.class),
    			anyString())).thenReturn(hmd);
		HookMetaData result=hookService.deleteHook("test");
		assertNotNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void findHookTransactionByTargetIdHookIdTest() {
		HookTransactionMetaData documentMetaData=new HookTransactionMetaData();
		when(mongoTemplate.findOne(any(Query.class), eq(HookTransactionMetaData.class), anyString())).thenReturn(documentMetaData);
		HookTransactionMetaData res=hookService.findHookTransactionByTargetIdHookId("test","test");
		assertNotNull(res);	
		assertNotNull(documentMetaData);	
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32968")
	@Test
	public void getHookTransactionByIdTest() {
		HookTransactionMetaData documentMetaData=new HookTransactionMetaData();
		documentMetaData.setId("test");
		HookTransactionMetaData res=hookService.getHookTransactionById("test");
		assertNull(res);	
	}

    @Test
    public void findAllAvailableHookMetaData_shouldRethrowException_whenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class)))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.findAllAvailableHookMetaData()
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void findTopOfStackNewHookEvent_shouldRethrowException_whenFindAndModifyFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findAndModify(
                any(Query.class),
                any(Update.class),
                eq(HookEventType.class),
                eq("hookEvent")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.findTopOfStackNewHookEvent()
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void findDocumentByTransactionId_shouldRethrowException_whenMongoFindOneFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findOne(
                any(Query.class),
                eq(DocumentMetaData.class),
                eq("document")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.findDocumentByTransactionId("trx-123")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void findAttachmentsByTransactionId_shouldRethrowException_whenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(
                any(Query.class),
                eq(AttachmentMetaData.class),
                eq("attachment")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.findAttachmentsByTransactionId("trx-123")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void findAttachmentByFsId_shouldRethrowException_whenMongoFindOneFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findOne(
                any(Query.class),
                eq(AttachmentMetaData.class),
                eq("attachment")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.findAttachmentByFsId("fs-123")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void findAllHooksThatMatchTopLevelCriteria_shouldRethrowException_whenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");
        HookEventType hookEvent = new HookEventType();

        when(mongoTemplate.find(
                any(Query.class),
                eq(HookMetaData.class),
                eq("hook")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.findAllHooksThatMatchTopLevelCriteria(hookEvent)
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void findIfHookTransactionExistsForDoc_shouldRethrowException_whenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");
        DocumentMetaData document = new DocumentMetaData();
        document.setId("doc-123");
        document.setSpaceId(100);

        when(mongoTemplate.find(
                any(Query.class),
                eq(HookTransactionMetaData.class),
                eq("hook")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.findIfHookTransactionExistsForDoc(document)
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void findHookTransactionMetaDataForDocAndHook_shouldRethrowException_whenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");
        DocumentMetaData document = new DocumentMetaData();
        document.setId("doc-123");
        document.setSpaceId(100);

        when(mongoTemplate.find(
                any(Query.class),
                eq(HookTransactionMetaData.class),
                eq("hook")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.findHookTransactionMetaDataForDocAndHook(document, "hook-123")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void getHookById_withAppIdAndSpaceId_shouldRethrowException_whenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class)))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.getHookById("app1", 10, "hook-123")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void getHookById_withAppId_shouldRethrowException_whenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class)))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.getHookById("app1", "hook-123")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void getHooksByName_shouldRethrowException_whenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class)))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.getHooksByName("app1", 10, "hook-name")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testGetHookByNameAndSpaceId_ShouldReturnHooks_WhenMongoFindSucceeds() {
        HookServiceImpl hookService = new HookServiceImpl();
        ReflectionTestUtils.setField(hookService, "mongoTemplate", mongoTemplate);

        String appId = "app";
        int spaceId = 123;
        String name = "testHook";

        HookMetaData hookMetaData = new HookMetaData();
        hookMetaData.setId("hook-1");
        List<HookMetaData> expectedHooks = Collections.singletonList(hookMetaData);

        when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class)))
                .thenReturn(expectedHooks);

        List<HookMetaData> result = hookService.getHookByNameAndSpaceId(appId, spaceId, name);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("hook-1", result.get(0).getId());

        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
        verify(mongoTemplate).find(queryCaptor.capture(), eq(HookMetaData.class));

        String queryString = queryCaptor.getValue().toString();
        assertTrue(queryString.contains("appIdentifier"));
        assertTrue(queryString.contains("spaceId"));
        assertTrue(queryString.contains("hook.name"));
        assertTrue(queryString.contains("AVAILABLE"));
    }

    @Test
    public void testGetHookByNameAndSpaceId_ShouldRethrowException_WhenMongoFindFails() {
        HookServiceImpl hookService = new HookServiceImpl();
        ReflectionTestUtils.setField(hookService, "mongoTemplate", mongoTemplate);

        String appId = "app";
        int spaceId = 123;
        String name = "testHook";

        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class)))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.getHookByNameAndSpaceId(appId, spaceId, name)
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(HookMetaData.class));
    }

    @Test
    public void testGetHooks_ShouldRethrowException_WhenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class)))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.getHooks("app", 100, "AVAILABLE")
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(HookMetaData.class));
    }

    @Test
    public void testPutHookMetaData_ShouldRethrowException_WhenFindAndModifyFails() {
        HookMetaData hookMetaData = new HookMetaData();
        hookMetaData.setId("hook-1");

        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findAndModify(
                any(Query.class),
                any(Update.class),
                any(FindAndModifyOptions.class),
                eq(HookMetaData.class)))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.putHookMetaData(hookMetaData)
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).findAndModify(
                any(Query.class),
                any(Update.class),
                any(FindAndModifyOptions.class),
                eq(HookMetaData.class));
    }

    @Test
    public void testDeleteHook_ShouldRethrowException_WhenFindAndModifyFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findAndModify(
                any(Query.class),
                any(Update.class),
                any(FindAndModifyOptions.class),
                eq(HookMetaData.class)))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.deleteHook("app", 100, "hook-1")
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).findAndModify(
                any(Query.class),
                any(Update.class),
                any(FindAndModifyOptions.class),
                eq(HookMetaData.class));
    }

    @Test
    public void testUpdateHookTransaction_ShouldRethrowException_WhenFindAndModifyFails() {
        HookTransactionMetaData hookTransactionMetaData = new HookTransactionMetaData();
        hookTransactionMetaData.setId("hook-tx-1");

        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findAndModify(
                any(Query.class),
                any(Update.class),
                eq(HookTransactionMetaData.class),
                eq("hookTransaction")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.updateHookTransaction(hookTransactionMetaData)
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testDeleteHookEventFromStack_ShouldRethrowException_WhenFindAndRemoveFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findAndRemove(
                any(Query.class),
                eq(HookEventType.class),
                eq("hookEvent")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.deleteHookEventFromStack("hook-event-1")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testDeleteJobFromStack_ShouldRethrowException_WhenFindAndRemoveFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findAndRemove(
                any(Query.class),
                eq(JobMetaData.class),
                eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.deleteJobFromStack("job-1")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testSearchAllJobs_ShouldRethrowException_WhenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), eq("jobs")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.searchAllJobs(100)
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testSearchStandardJobs_ShouldRethrowException_WhenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.searchStandardJobs(100)
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testSearchCronJobs_ShouldRethrowException_WhenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.searchCronJobs(100)
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testSearchAllJobsBySpaceIdHookId_ShouldRethrowException_WhenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.searchAllJobsBySpaceIdHookId(100, "hook-1")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testSearchDocumentsBySpaceIdAndDateField_ShouldRethrowException_WhenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.searchDocumentsBySpaceIdAndDateField(100, "dateCreated", "2024-01-01")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testSearchForJobsByHookId_ShouldRethrowException_WhenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.searchForJobs("hook-1")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testSearchForJobsByTargetTypeAndTargetId_ShouldRethrowException_WhenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.searchForJobs("DOCUMENT", "target-1")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testSearchForAllJobs_ShouldRethrowException_WhenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.searchForAllJobs("DOCUMENT", "target-1")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testSearchForAllJobTypes_ShouldRethrowException_WhenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.searchForAllJobTypes("DOCUMENT", "target-1")
        );

        assertEquals("Simulated database error", actualException.getMessage());
    }

    @Test
    public void testFindTopOfStackNewJob_ShouldRethrowException_WhenFindAndModifyFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findAndModify(
                any(Query.class),
                any(Update.class),
                eq(JobMetaData.class),
                eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class, () ->
                hookService.findTopOfStackNewJob()
        );

        assertEquals("Simulated database error", actualException.getMessage());

        verify(mongoTemplate).findAndModify(
                any(Query.class),
                any(Update.class),
                eq(JobMetaData.class),
                eq("job"));
    }

    @Test
    public void testFindJobsByStatus_ShouldRethrowException_WhenMongoFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class,
                () -> hookService.findJobsByStatus(MetaDataStatus.ACTIVE));

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(JobMetaData.class), eq("job"));
    }

    @Test
    public void testFindTopOfStackNewCronJob_ShouldRethrowException_WhenFindAndModifyFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class),
                eq(JobMetaData.class), eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class,
                () -> hookService.findTopOfStackNewCronJob());

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).findAndModify(any(Query.class), any(Update.class),
                eq(JobMetaData.class), eq("job"));
    }

    @Test
    public void testMarkHookInvalid_ShouldRethrowException_WhenFindAndModifyFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class),
                eq(HookMetaData.class), eq("hook")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class,
                () -> hookService.markHookInvalid("hook-id-1"));

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).findAndModify(any(Query.class), any(Update.class),
                eq(HookMetaData.class), eq("hook"));
    }

    @Test
    public void testUpdateHookExecutionRecordOfHookTransactionRecord_ShouldRethrowException_WhenFindAndModifyFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("activitiJobStatus", "COMPLETED");
        resultMap.put("activitiProcessKey", "process-key");
        resultMap.put("messageList", Collections.singletonList("message"));
        resultMap.put("activitiJobId", "job-123");

        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class),
                eq(HookTransactionMetaData.class), eq("hook")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class,
                () -> hookService.updateHookExecutionRecordOfHookTransactionRecord(
                        "exec-1", "target-1", "hook-1", resultMap));

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).findAndModify(any(Query.class), any(Update.class),
                eq(HookTransactionMetaData.class), eq("hook"));
    }

    @Test
    public void testFindHookTransactionByTargetIdHookIdHookExecutionId_ShouldRethrowException_WhenFindOneFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findOne(any(Query.class), eq(HookTransactionMetaData.class), eq("hook")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class,
                () -> hookService.findHookTransactionByTargetIdHookIdHookExecutionId(
                        "exec-1", "target-1", "hook-1"));

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).findOne(any(Query.class), eq(HookTransactionMetaData.class), eq("hook"));
    }

    @Test
    public void testFindModifiedDocument_ShouldRethrowException_WhenFindOneFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class,
                () -> hookService.findModifiedDocument("doc-1", new Date()));

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).findOne(any(Query.class), eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testSearchAllActiveJobsBySpaceIdHookId_ShouldRethrowException_WhenFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(JobMetaData.class), eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class,
                () -> hookService.searchAllActiveJobsBySpaceIdHookId(100, "hook-1"));

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(JobMetaData.class), eq("job"));
    }

    @Test
    public void testUpdateJobStatus_ShouldRethrowException_WhenUpdateFirstFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.updateFirst(any(Query.class), any(Update.class),
                eq(JobMetaData.class), eq("job")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(RuntimeException.class,
                () -> hookService.updateJobStatus("job-1", "FAILED"));

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).updateFirst(any(Query.class), any(Update.class),
                eq(JobMetaData.class), eq("job"));
    }

    @Test
    public void testUpdateHookExecutionRecordOfCronExpressionHookTransactionRecord_ShouldRethrowException_WhenFindAndModifyFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("activitiJobStatus", "COMPLETED");
        resultMap.put("activitiProcessKey", "process-key");
        resultMap.put("messageList", Collections.singletonList("message"));
        resultMap.put("activitiJobId", "job-123");

        when(mongoTemplate.findAndModify(
                any(Query.class),
                any(Update.class),
                eq(HookTransactionMetaData.class),
                eq("cronExpressionHook")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.updateHookExecutionRecordOfCronExpressionHookTransactionRecord(
                        "exec-1", "target-1", "hook-1", "job-1", resultMap)
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).findAndModify(
                any(Query.class),
                any(Update.class),
                eq(HookTransactionMetaData.class),
                eq("cronExpressionHook"));
    }

    @Test
    public void testUpdateHook_ShouldRethrowException_WhenUpdateFirstFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        HookMetaData hookMetaData = new HookMetaData();
        hookMetaData.setId("hook-1");

        Map<String, Object> config = new HashMap<>();
        config.put("url", "http://test");

        Map<String, Object> action = new HashMap<>();
        action.put("config", config);

        Map<String, Object> hook = new HashMap<>();
        hook.put("action", action);

        Map<String, Object> payload = new HashMap<>();
        payload.put("hook", hook);

        when(mongoTemplate.updateFirst(
                any(Query.class),
                any(Update.class),
                eq(HookMetaData.class),
                eq("hook")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.updateHook(hookMetaData, payload)
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).updateFirst(
                any(Query.class),
                any(Update.class),
                eq(HookMetaData.class),
                eq("hook"));
    }

    @Test
    public void testGetHookById_WithOnlyId_ShouldRethrowException_WhenFindFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.find(any(Query.class), eq(HookMetaData.class)))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.getHookById("hook-1")
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).find(any(Query.class), eq(HookMetaData.class));
    }

    @Test
    public void testDeleteHook_WithOnlyId_ShouldRethrowException_WhenFindAndRemoveFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findAndRemove(
                any(Query.class),
                eq(HookMetaData.class),
                eq("hook")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.deleteHook("hook-1")
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).findAndRemove(
                any(Query.class),
                eq(HookMetaData.class),
                eq("hook"));
    }

    @Test
    public void testFindHookTransactionByTargetIdHookId_ShouldRethrowException_WhenFindOneFails() {
        RuntimeException expectedException = new RuntimeException("Simulated database error");

        when(mongoTemplate.findOne(
                any(Query.class),
                eq(HookTransactionMetaData.class),
                eq("hookTransaction")))
                .thenThrow(expectedException);

        RuntimeException actualException = assertThrows(
                RuntimeException.class,
                () -> hookService.findHookTransactionByTargetIdHookId("target-1", "hook-1")
        );

        assertEquals("Simulated database error", actualException.getMessage());
        verify(mongoTemplate).findOne(
                any(Query.class),
                eq(HookTransactionMetaData.class),
                eq("hookTransaction"));
    }
}
	

