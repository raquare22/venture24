package com.optum.fds.paperless.domain.service;

import static org.mockito.Mockito.when;

import java.net.URI;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.anyList;

import org.bson.Document;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorRowTask;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import com.optum.fds.paperless.util.FileUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;

@RunWith(MockitoJUnitRunner.class)

public class CsvProcessorsServiceTest {

	@Mock
	CsvProcessorService csvProcessorService;

	@Mock
	TransactionService transactionService;

	@InjectMocks
	CsvProcessorsServiceImpl csvProcessorsService;
	@Mock
	MetaDataStatus metaDataStatus;
	private CsvProcessorTransaction testCsvProcessorTransaction = new CsvProcessorTransaction();

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void getCsvTransactionProcessorTest() {
		CsvProcessorTransaction result = new CsvProcessorTransaction();
		String test = "fileName";
		when(csvProcessorService.getCsvProcessorTransaction(anyString(), anyString(), anyString())).thenReturn(result);
		CsvProcessorTransaction processorTransaction = csvProcessorsService.getCsvTransactionProcessor(test, test);
		assertEquals(result, processorTransaction);
	}
	

	@Test
	public void createCsvProcessorRowTaskTest() { 
		CsvProcessorTransaction result=new CsvProcessorTransaction();
		Transaction transaction=new Transaction();
		CsvProcessorRowTask createCsvProcessoResult = csvProcessorsService.createCsvProcessorRowTask(result,"csvFileName","csvJsonFileName",transaction);
		assertNotNull(createCsvProcessoResult);
	}
	
	@Test
	public void createCsvProcessorTransactionTestNotNull() { 
		ProcessorMetaData processorMetaData=new ProcessorMetaData();
		CsvProcessorTransaction createCsvResult = csvProcessorsService.createCsvProcessorTransaction(processorMetaData,"csvFileName","csvJsonFileName","transactionID");
		assertNotNull(createCsvResult);
	}
	@Test
	public void createCsvProcessorRowTaskTestTwo() { 
		CsvProcessorTransaction csvProcessorTransaction=new CsvProcessorTransaction();
		CsvProcessorRowTask createCsvProcessorRowTask = csvProcessorsService.createCsvProcessorRowTask(csvProcessorTransaction,"csvFileName","csvJsonFileName",123,"transactionID","csvProcessorTransaction");
		//assertNotNull(createCsvProcessorRowTask);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void createCsvProcessorRowTaskTest1() {
		CsvProcessorTransaction result = new CsvProcessorTransaction();
		Transaction transaction = new Transaction();
		CsvProcessorRowTask createCsvProcessoResult = csvProcessorsService.createCsvProcessorRowTask(result,
				"csvFileName", "csvJsonFileName", transaction);
		assertNotNull(createCsvProcessoResult);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void createCsvProcessorTransactionTest() {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		CsvProcessorTransaction createCsvResult = csvProcessorsService.createCsvProcessorTransaction(processorMetaData,
				"csvFileName", "csvJsonFileName", "transactionID");
		assertNotNull(createCsvResult);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void createCsvProcessorRowTaskTestTwo2() {
		CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
		CsvProcessorRowTask createCsvProcessorRowTask = csvProcessorsService.createCsvProcessorRowTask(
				csvProcessorTransaction, "csvFileName", "csvJsonFileName", 123, "transactionID",
				"csvProcessorTransaction");
		assertNull(createCsvProcessorRowTask);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void getCsvProcessorTransactionWithFileNameTest() {
		CsvProcessorTransaction result = new CsvProcessorTransaction();
		String test = "fileName";
		when(csvProcessorService.getCsvProcessorTransactionWithFileName(anyString(), anyString(), anyString(),
				anyString())).thenReturn(result);
		CsvProcessorTransaction processorTransaction = csvProcessorsService.getCsvProcessorTransactionWithFileName(test,
				test, test);
		assertEquals(result, processorTransaction);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void findProcessorMetaDataByFileNameTest() {
		ProcessorMetaData result = new ProcessorMetaData();
		String test = "fileName";
		when(csvProcessorService.findProcessorMetaDataByFileName(anyString(), anyString())).thenReturn(result);
		ProcessorMetaData processorTransaction = csvProcessorsService.findProcessorMetaDataByFileName(test, test);
		assertEquals(result, processorTransaction);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void findProcessorMetaDataByIdTest() {
		ProcessorMetaData result = new ProcessorMetaData();
		String test = "fileName";
		when(csvProcessorService.findProcessorMetaDataById(anyString())).thenReturn(result);
		ProcessorMetaData processorTransaction = csvProcessorsService.findProcessorMetaDataById(test);
		assertEquals(result, processorTransaction);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void updateCsvProcessorTransactionMetaDataTest() {
		CsvProcessorTransaction result = new CsvProcessorTransaction();
		// String test="fileName";
		CsvProcessorTransaction processorTransaction = csvProcessorsService
				.updateCsvProcessorTransactionMetaData(result);
		assertNotNull(result);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void getAllTransactionProcessorsShutdownTest() {
		CsvProcessorTransaction result = new CsvProcessorTransaction();
		List<CsvProcessorTransaction> list = new ArrayList<CsvProcessorTransaction>();
		// String test="fileName";
		when(csvProcessorService.getAllCsvProcessorTransactionInStatus(anyString(), anyString())).thenReturn(list);
		List<CsvProcessorTransaction> processorTransaction = csvProcessorsService.getAllTransactionProcessorsShutdown();
		assertEquals(list, processorTransaction);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void getAllPendingCsvProcessorsTransactionsTest() {
		List<CsvProcessorTransaction> list = new ArrayList<CsvProcessorTransaction>();
		// String test="fileName";
		// when(csvProcessorService.getAllPendingCsvProcessorTransactions(anyInt(),
		// anyList(), anyString())).thenReturn(list);
		List<CsvProcessorTransaction> processorTransaction = csvProcessorsService.getAllTransactionProcessorsShutdown();
		// assertEquals(list, processorTransaction);
		assertNotNull(processorTransaction);

	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void createCsvProcessorRowTask2Test() {
		CsvProcessorRowTask testResult = new CsvProcessorRowTask();
		CsvProcessorRowTask result = new CsvProcessorRowTask();
		testResult = csvProcessorsService.createCsvProcessorRowTask(result);
		assertNotNull(result);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void updateCsvProcessorRowTask2Test() {
		CsvProcessorRowTask testResult = new CsvProcessorRowTask();
		CsvProcessorRowTask result = new CsvProcessorRowTask();
		testResult = csvProcessorsService.updateCsvProcessorRowTask(result);
		assertNull(testResult);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void getAllCsvProcessorsTransactionsTest() {
		List<String> statusList = new ArrayList<>();
		List<CsvProcessorTransaction> testResult = new ArrayList<>();
		List<CsvProcessorTransaction> result = new ArrayList<>();
		when(csvProcessorService.getAllCsvProcessorTransactionInStatus(anyList(), anyString(), anyInt()))
				.thenReturn(result);
		testResult = csvProcessorsService.getAllCsvProcessorsTransactions(statusList, 0);
		assertEquals(result, testResult);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void getCsvProcessorTransactionWithFileName2Test() {
		CsvProcessorTransaction testResult = new CsvProcessorTransaction();
		CsvProcessorTransaction result = new CsvProcessorTransaction();
		when(csvProcessorService.getCsvProcessorTransactionWithFileName(anyString())).thenReturn(result);
		testResult = csvProcessorsService.getCsvProcessorTransactionWithFileName("test");
		assertEquals(result, testResult);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void isAllCsvProcessorRowTasksWithCsvProcessorTransactionIdCompleteTest() {
		Boolean testResult;
		List<CsvProcessorRowTask> result = new ArrayList<>();
		when(csvProcessorService.getAllCsvProcessorRowTaskInStatus(anyList(), anyString(), anyString()))
				.thenReturn(result);
		testResult = csvProcessorsService.isAllCsvProcessorRowTasksWithCsvProcessorTransactionIdComplete("test");
		assertNotNull(testResult);
		assertNotNull(result);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void getCsvProcessorTransactionWithFileName3Test() {
		CsvProcessorTransaction testResult = new CsvProcessorTransaction();
		CsvProcessorTransaction result = new CsvProcessorTransaction();
		when(csvProcessorService.getCsvProcessorTransactionWithFileName(anyString(), anyString(), anyString(),
				anyString())).thenReturn(result);
		testResult = csvProcessorsService.getCsvProcessorTransactionWithFileName("test", "test", "test", "test");
		assertEquals(result, testResult);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void testGetAllPendingCsvProcessorTransactions() {
		List<CsvProcessorTransaction> csvProcessorTransactionList = new ArrayList<CsvProcessorTransaction>();
		int processorTransactionPendingTime = 7200;
		CsvProcessorTransaction processorTransaction1 = new CsvProcessorTransaction();
		processorTransaction1.setId("1");
		processorTransaction1.setProcessorRecordType(ProcessorRecordTypes.csvProcessorTransaction);
		processorTransaction1.setServerType("server");
		processorTransaction1.setStatus(MetaDataStatus.OK);
		csvProcessorTransactionList.add(processorTransaction1);

		List<String> statusList = new ArrayList<>();
		statusList.add("NEW");
		statusList.add("IN_PROCESS");

		when(csvProcessorService.getAllPendingCsvProcessorTransactions(anyInt(), anyList(), anyString()))
				.thenReturn(csvProcessorTransactionList);
		List<CsvProcessorTransaction> result = csvProcessorsService
				.getAllPendingCsvProcessorsTransactions(processorTransactionPendingTime);
		Assert.assertEquals("list of processor transactions", csvProcessorTransactionList.size(), result.size());
	}

	@Test
	@UserStory(references = "US26667")
	@RallyTestCase(references = "TC30430")
	public void testgetAllCompleteWithErrorsCsvProcessorsRowTasks() {
		CsvProcessorRowTask csvProcessorRowTask = new CsvProcessorRowTask();
		csvProcessorRowTask.setStatus(MetaDataStatus.COMPLETE_WITH_ERRORS.toString());
		List<CsvProcessorRowTask> csvProcessorRowTasks = new ArrayList<>();
		csvProcessorRowTasks.add(csvProcessorRowTask);
		when(csvProcessorService.getAllCsvProcessorRowTaskInStatus(Mockito.anyList(), Mockito.any(), Mockito.any()))
				.thenReturn(csvProcessorRowTasks);
		List<CsvProcessorRowTask> result = csvProcessorsService
				.getAllCompleteWithErrorsCsvProcessorsRowTasks("591a11aeef86c266481fde97");
		Assert.assertTrue(
				result.get(0).getStatus().toString().equalsIgnoreCase(MetaDataStatus.COMPLETE_WITH_ERRORS.toString()));
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void testIsAllCsvProcessorRowTasksProcessed() {
		CsvProcessorRowTask csvProcessorRowTask = new CsvProcessorRowTask();
		csvProcessorRowTask.setStatus(MetaDataStatus.COMPLETE_WITH_ERRORS.toString());
		csvProcessorRowTask.setId("id");
		List<CsvProcessorRowTask> csvProcessorRowTasks = new ArrayList<>();
		csvProcessorRowTasks.add(csvProcessorRowTask);
		testCsvProcessorTransaction.setRowCount(1);
		when(csvProcessorService.getAllCsvProcessorRowTaskInStatus(Mockito.anyList(), Mockito.any(), Mockito.any()))
				.thenReturn(csvProcessorRowTasks);
		Boolean result = csvProcessorsService.isAllCsvProcessorRowTasksProcessed(testCsvProcessorTransaction);
		Assert.assertTrue(result);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void createCsvRecordTest() {
		DocumentMetaData createCsvRecordResult = csvProcessorsService.createCsvRecord(234, "appIdentifier",
				metaDataStatus, Map.of("test", "one"));
		assertNull(createCsvRecordResult);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void createCsvRecordTestTwo() {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		DocumentMetaData createCsvRecord = csvProcessorsService.createCsvRecord(234, "appIdentifier", "tin", "mpin",
				"fileName", "fileType", "providerEmailId", "frequency", "frequency", "frequency", "frequency",
				metaDataStatus);
		assertNull(createCsvRecord);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void testIsAllCsvProcessorRowTasksProcessedFalse() {
		CsvProcessorRowTask csvProcessorRowTask = new CsvProcessorRowTask();
		csvProcessorRowTask.setStatus(MetaDataStatus.COMPLETE_WITH_ERRORS.toString());
		csvProcessorRowTask.setId("id");
		List<CsvProcessorRowTask> csvProcessorRowTasks = new ArrayList<>();
		csvProcessorRowTasks.add(csvProcessorRowTask);
		testCsvProcessorTransaction.setRowCount(0);
		when(csvProcessorService.getAllCsvProcessorRowTaskInStatus(Mockito.anyList(), Mockito.any(), Mockito.any()))
				.thenReturn(csvProcessorRowTasks);
		Boolean result = csvProcessorsService.isAllCsvProcessorRowTasksProcessed(testCsvProcessorTransaction);
		Assert.assertFalse(result);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void testCreateRestApiJobEntry() {
		ProcessorMetaData processor = new ProcessorMetaData();
		processor.setPriority(1);
		processor.setConfigSpaceId(1234);
		processor.setClientId(234);

		CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
		String csvProcessorRowTaskId = "345";
		String jobType = "test";
		String wrkFlow = "";
		org.springframework.http.HttpMethod method = HttpMethod.POST;
		HttpEntity<Object> request = null;
		ProcessorRecordTypes sourceType = null;
		URI uri = null;

		JobMetaData metadata = csvProcessorsService.createRestApiJobEntry(processor, csvProcessorTransaction,
				csvProcessorRowTaskId, jobType, wrkFlow, method, request, sourceType, uri);
		assertNotNull(metadata);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32965")
	@Test
	public void testCreateCsvProcessorRowTask() {

		CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();

		processorTransaction.setId("test");
		processorTransaction.setAppIdentifier("test identifier");
		processorTransaction.setClientId(1234);

		Integer configSpaceId = 4532;

		String csvFileName = " ";
		String csvJsonFileName = " ";
		Integer rowNumber = 23;
		String request = "";
		MetaDataStatus enums = null;
		MetaDataStatus status = enums.COMPLETE;

		CsvProcessorRowTask csvprocessorRowTask = csvProcessorsService.createCsvProcessorRowTask(processorTransaction,
				configSpaceId, csvFileName, csvJsonFileName, rowNumber, request, status.COMPLETE);
		assertNull(csvprocessorRowTask);

	}
}
