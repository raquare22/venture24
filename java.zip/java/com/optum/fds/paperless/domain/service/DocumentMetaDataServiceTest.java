package com.optum.fds.paperless.domain.service;

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bson.Document;
import org.mockito.ArgumentCaptor;
import org.springframework.data.mongodb.core.query.Criteria;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.model.MultiPutResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.DocumentsQueryNew;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.util.DocumentUtil;
import com.optum.fds.paperless.workflow.beans.ProviderDocument;


@RunWith(MockitoJUnitRunner.class)

public class DocumentMetaDataServiceTest {

	@Mock
	MongoTemplate mongoTemplate;
	
	@Mock
	DocumentUtil documentUtil;
	
	@Mock
	MongoOperations mongoOperations;
	
	@Mock MetaDataStatus metadata;
	
	@InjectMocks
	DocumentMetaDataServiceImpl documentMetaDataService;
	
	@Before
	public void setUp() {
		documentMetaDataService.setMongoQueryMaxMillis("30000");
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void saveDocumentMetaDataTest() { 
		DocumentMetaData doc = new DocumentMetaData();

		doc.setName("test");
		doc.setId("testId");
		doc.setAppIdentifier("app");
		doc.setClientId(0);
		when(mongoTemplate.insert(any(DocumentMetaData.class), anyString())).thenReturn(doc);
		DocumentMetaData result = documentMetaDataService.saveDocumentMetaData(doc);
		assertNotNull(doc);
		assertNotNull(result);
	}
	
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void saveDocumentMetaDataNullTest() { 
		DocumentMetaData doc = new DocumentMetaData();
		doc.setName("test");
		DocumentMetaData result = documentMetaDataService.saveDocumentMetaData(doc);
		assertNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void saveDocumentMetaDataPDOTest() { 
		DocumentMetaData doc = new DocumentMetaData();

		doc.setName("test");
		doc.setId("testId");
		doc.setAppIdentifier("app");
		doc.setClientId(0);
		when(mongoTemplate.insert(any(DocumentMetaData.class), anyString())).thenReturn(doc);
		DocumentMetaData result = documentMetaDataService.savePDODocumentMetaData(doc);
		assertNotNull(doc);
		assertNotNull(result);
	}
	
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void saveDocumentMetaDataPDONullTest() { 
		DocumentMetaData doc = new DocumentMetaData();
		doc.setName("test");
		DocumentMetaData result = documentMetaDataService.savePDODocumentMetaData(doc);
		assertNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void updatePDODocumentMetaDataTest() { 
		DocumentMetaData doc = new DocumentMetaData();
		org.bson.Document  metaData=new org.bson.Document();
		doc.setMetadata(metaData);
		when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), anyString())).thenReturn(doc);
		DocumentMetaData result = documentMetaDataService.updatePDODocumentMetaData(doc, "test");
		assertNotNull(result);
		assertEquals(result, doc);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void updateDocMetaDataTest() { 
		DocumentMetaData doc = new DocumentMetaData();
		org.bson.Document  metaData=new org.bson.Document();
		doc.setMetadata(metaData);
		when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), anyString())).thenReturn(doc);
		DocumentMetaData result = documentMetaDataService.updateDocMetaData(doc, "test");
		assertNotNull(result);
		assertEquals(result, doc);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void updateMultiPDODocumentsTest() {
		DocumentMetaData doc = new DocumentMetaData();
		List<String> updated = new ArrayList<>();
		List<String> notUpdated = new ArrayList<>();
		//when(documentMetaDataService.updatePDODocumentMetaData(any(DocumentMetaData.class), anyString())).thenReturn(doc);
		MultiPutResponse mr=documentMetaDataService.updateMultiPDODocuments(updated, doc);
		assertNotNull(mr);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getPDODocumentByIdTest() {
		DocumentMetaData doc = new DocumentMetaData();
		when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), anyString())).thenReturn(doc);
		DocumentMetaData result = documentMetaDataService.getPDODocumentById("test");
		assertNotNull(result);
		assertEquals(result, doc);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getPDODocumentsTest() throws JsonProcessingException {
		DocumentMetaData doc = new DocumentMetaData();
		List<DocumentMetaData> docList = new ArrayList<>();
		Map<String, String> queryParams=new HashMap<String, String>();
		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), anyString())).thenReturn(docList);
		List<DocumentMetaData> result=documentMetaDataService.getPDODocuments(queryParams);
		assertNotNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getDocumentMetaDataTest() {
		List<DocumentMetaData> docList = new ArrayList<>();
		DocumentMetaData doc = new DocumentMetaData();
		DocumentMetaData result = documentMetaDataService.getDocumentMetaData("test");
		assertNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getCsvDocumentMetaDataTest() throws InvalidExpressionException {
		List<DocumentMetaData> docList = new ArrayList<>();
		DocumentMetaData doc = new DocumentMetaData();
		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), anyString())).thenReturn(docList);
		List<DocumentMetaData> result = documentMetaDataService.getCsvDocumentMetaData("{\"name\":\"John\", \"age\":30, \"car\":null}", new Criteria());
		assertNotNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void updateDocumentMetaDataStatusTest() { 
		DocumentMetaData doc = new DocumentMetaData();
		when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class))).thenReturn(doc);
		DocumentMetaData result=documentMetaDataService.updateDocumentMetaDataStatus("test", MetaDataStatus.ACTIVE.toString());
		assertNotNull(result);
		assertEquals(result, doc);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void updateDocumentMetaDataStatus2Test() { 
		DocumentMetaData doc = new DocumentMetaData();
		DocumentMetaData result=documentMetaDataService.updateDocumentMetaDataStatus("test", "test", "test");
		assertNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void updateDocumentMetaDataStatus3Test() { 
		DocumentMetaData doc = new DocumentMetaData();
		when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class))).thenReturn(doc);
		DocumentMetaData result=documentMetaDataService.updateDocumentMetaDataStatus("test", MetaDataStatus.ACTIVE.toString(), "test", "test");
		assertEquals(result, doc);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getDocumentListByIdTest() { 
		List<DocumentMetaData> docList=new ArrayList<DocumentMetaData>();
		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(docList);
		List<DocumentMetaData> result=documentMetaDataService.getDocumentListById("test");
		assertNotNull(result);
		assertEquals(result, docList);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getDocumentListByExternalIdTest() { 
		List<DocumentMetaData> docList=new ArrayList<DocumentMetaData>();
		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(docList);
		List<DocumentMetaData> result=documentMetaDataService.getDocumentListByExternalId("test", "test");
		assertNotNull(result);
		assertEquals(result, docList);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getDocumentListByExternalIdAndSpaceIdTest() { 
		List<DocumentMetaData> docList=new ArrayList<DocumentMetaData>();
		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(docList);
		List<DocumentMetaData> result=documentMetaDataService.getDocumentListByExternalIdAndSpaceId("test", 0);
		assertNotNull(result);
		assertEquals(result, docList);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getDocumentListMetadataTest() { 
		List<DocumentMetaData> docList=new ArrayList<DocumentMetaData>();
		Map<String, String> metadataMap=new HashMap();
		metadataMap.put("string", "string");
		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(docList);
		List<DocumentMetaData> result=documentMetaDataService.getDocumentListMetadata("test", metadataMap);
		assertNotNull(result);
		assertEquals(result, docList);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getDocumentListAppIdTest() { 
		List<DocumentMetaData> docList=new ArrayList<DocumentMetaData>();
		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(docList);
		List<DocumentMetaData> result=documentMetaDataService.getDocumentListAppId("test");
		assertNotNull(result);
		assertEquals(result, docList);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getDocumentMetaDataListWithPagingNewTest() { 
		List<DocumentMetaData> docList=new ArrayList<DocumentMetaData>();
		List<Integer> spaceIdList=new ArrayList();
		Criteria documentsQry= new Criteria();
		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(docList);
		List<DocumentMetaData> result=documentMetaDataService.getDocumentMetaDataListWithPagingNew("test", spaceIdList, documentsQry, 0, 4);
		assertNotNull(result);
		assertEquals(result, docList);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getPDODocuments2Test() { 
		org.bson.Document  doc=new org.bson.Document();
		List<ProviderDocument> docList=new ArrayList<ProviderDocument>();
		when(mongoTemplate.find(any(Query.class), eq(ProviderDocument.class), anyString())).thenReturn(docList);
		List<ProviderDocument> result=documentMetaDataService.getPDODocuments(doc);
		assertNotNull(result);
		assertEquals(result, docList);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void insertMultiDocumentsTest() { 
		org.bson.Document  doc=new org.bson.Document();
		List<DocumentMetaData> docList=new ArrayList<DocumentMetaData>();
		List<DocumentMetaData> list2=new ArrayList<DocumentMetaData>();
		when(mongoTemplate.insert(any(List.class), anyString())).thenReturn(docList);
		List<DocumentMetaData> result=documentMetaDataService.insertMultiDocuments(list2);
		assertNotNull(result);
		assertEquals(result, docList);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void updateMultiDocumentsTest() {
		DocumentMetaData doc = new DocumentMetaData();
		List<String> updated = new ArrayList<>();
		MultiPutResponse mr=documentMetaDataService.updateMultiDocuments(updated, doc);
		assertNotNull(mr);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void updateMultiDocumentTest() {
		DocumentMetaData doc = new DocumentMetaData();
		List<String> updated = new ArrayList<>();
		MultiPutResponse mr=documentMetaDataService.updateMultiDocument(updated, doc);
		assertNotNull(mr);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getDocumentsTest() throws JsonProcessingException { 
		Map<String, String> queryParams= new HashMap<>();
		List<DocumentMetaData> docList=new ArrayList<DocumentMetaData>();
		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), anyString())).thenReturn(docList);
		List<DocumentMetaData> result=documentMetaDataService.getDocuments(queryParams);
		assertNotNull(result);
		assertEquals(result, docList);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void updateDocumentMetaDataTest() { 
		DocumentMetaData doc = new DocumentMetaData();
		doc.setStatus(MetaDataStatus.OK);
		doc.setId("test");
		doc.setErrorMessage("error");
		doc.setTransactionId("test");
		when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class))).thenReturn(doc);
		DocumentMetaData result=documentMetaDataService.updateDocumentMetaData(doc, "test");
		assertEquals(result, doc);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void putDocumentMetadataTest() { 
		DocumentMetaData doc = new DocumentMetaData();
		doc.setStatus(MetaDataStatus.OK);
		doc.setId("test");
		doc.setErrorMessage("error");
		doc.setTransactionId("test");
		DocumentMetaData result=documentMetaDataService.putDocumentMetadata(doc);
		assertNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void putDocumentMetadatawithIdTest() { 
		DocumentMetaData doc = new DocumentMetaData();
		doc.setStatus(MetaDataStatus.OK);
		doc.setId("test");
		doc.setErrorMessage("error");
		doc.setTransactionId("test");
		DocumentMetaData result=documentMetaDataService.putDocumentMetadata(doc, "test");
		assertNull(result);
	}
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getDocumentMetaData2Test() { 
		List<DocumentMetaData> docList=new ArrayList<DocumentMetaData>();
		DocumentMetaData result=documentMetaDataService.getDocumentMetaData("{\"name\":\"John\", \"age\":30, \"car\":null}");
		assertNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getCsvDocumentMetaData2Test() { 
		List<DocumentMetaData> docList=new ArrayList<DocumentMetaData>();
		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), anyString())).thenReturn(docList);
		DocumentMetaData result=documentMetaDataService.getCsvDocumentMetaData("{\"name\":\"John\", \"age\":30, \"car\":null}");
		assertNull(result);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getDocumentMetaData3Test() throws InvalidExpressionException { 
		List<DocumentMetaData> docList=new ArrayList<DocumentMetaData>();
		Criteria documentFilte=new  Criteria();
		
		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), anyString())).thenReturn(docList);
		List<DocumentMetaData> result=documentMetaDataService.getDocumentMetaData("{\"name\":\"John\", \"age\":30, \"car\":null}",documentFilte , 0);
		assertNotNull(result);
		assertEquals(result, docList);
	}
	
	@Test
	public void getDocumentMetaDataIdsTest() throws InvalidExpressionException { 
		List<DocumentMetaData> docList = new ArrayList<DocumentMetaData>();
		DocumentMetaData doc = new DocumentMetaData();
		doc.setId("123");
		docList.add(doc);
		Criteria documentFilter = Criteria.where("tin").is("123");
		List<String> result = documentMetaDataService.getDocumentMetaDataIds("{\"name\":\"John\", \"age\":30, \"car\":null}",
				documentFilter, documentFilter);
		
//		when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), anyString())).thenReturn(docList);
		assertNotNull(result);
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
//	@Test
	public void convertISOStringToDateTest1() {	
		String isoDate = "2018-11-14T04:27:42.001Z";
		Date result = documentMetaDataService.convertISOStringToDate(isoDate);
		assertEquals(result.toString(), ("Wed Nov 14 04:27:42 EST 2018"));
	}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void getDocumentMetaDataTest2() {
		
		HashMap<String, String> metadataMap = new HashMap<>();
		metadataMap.put("key1", "value1");
		metadataMap.put("key2", "value2");
		
		SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		Date date1 = null;
		Date date2 = null;
		Date date3 = null;
		try {
			date1 = isoDateFormat.parse("2018-11-14T04:27:42.001Z");
			date2 = isoDateFormat.parse("2018-11-14T04:27:42.002Z");
			date3 = isoDateFormat.parse("2018-11-14T04:27:42.003Z");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		DocumentMetaData docMD = new DocumentMetaData();
		docMD.setName("docName");
		docMD.setDateCreated(date1);
		docMD.setDateModified(date2);
		
		List<Object> docMDList = new ArrayList<>();
		docMDList.add(docMD);
		
		List<Integer> spaceIdList = new ArrayList<>();
		spaceIdList.add(1111);
		

		
		String documentSearchCriteriaJson = "{\"key\" : \"value\"}";
		Criteria documentFilter = new Criteria();
		
		Mockito.when(mongoTemplate.find(Mockito.any(), Mockito.any(), Mockito.anyString())).thenReturn(docMDList);
		
		List<DocumentMetaData> result = new ArrayList<>();

		try {
			result = documentMetaDataService
					.getDocumentMetaData(documentSearchCriteriaJson, documentFilter);
		} catch (InvalidExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		assertNotNull(result);
		assertEquals("docName", result.get(0).getName());
		assertEquals(date1, result.get(0).getDateCreated());
		assertEquals(date2, result.get(0).getDateModified());
	}
		@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32966")
	  	@Test
	    public void putDocumentMetadataUpdateFieldsTest() {
	        
	        HashMap<String, Object> metadataMap = new HashMap<>();
	        metadataMap.put("key1", "value1");
	        metadataMap.put("key2", "value2");
	        
	        SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	        Date date1 = null;
	        Date date2 = null;
	        try {
	            date1 = isoDateFormat.parse("2018-11-14T04:27:42.001Z");
	            date2 = isoDateFormat.parse("2018-11-14T04:27:42.002Z");
	        } catch (ParseException e) {
	            e.printStackTrace();
	        }
	        
	        org.bson.Document metadata = new org.bson.Document();
	        metadata.put("id", "001");
	        
	        
	        DocumentMetaData docMD = new DocumentMetaData();
	        docMD.setName("docName");
	        docMD.setDateCreated(date1);
	        docMD.setDateModified(date2);
	        docMD.setTransactionId("id");
	        docMD.setStatus(MetaDataStatus.ACTIVE);
	        docMD.setId("docId");
	        docMD.setMetadata(metadata);
	        docMD.setExternalId("extid");
	        docMD.setErrorMessage("error");
	        
	        List<Object> docMDList = new ArrayList<>();
	        docMDList.add(docMD);
	        
	        List<Integer> spaceIdList = new ArrayList<>();
	        spaceIdList.add(123);
	        

	        
	        Mockito.doReturn(docMD).when(mongoTemplate).findAndModify(Mockito.any(), Mockito.any(),
	                Mockito.any(FindAndModifyOptions.class), Mockito.any());
	        

	        DocumentMetaData result = documentMetaDataService.updateDocumentMetadataFields(metadataMap, "docId");
	        
	        assertNotNull(result);
	        assertEquals("docName", result.getName());
	        assertEquals(date1, result.getDateCreated());
	        assertEquals("id", result.getTransactionId());
	    }
	  
	  	@UserStory(references = "US32799")
		@RallyTestCase(references = "TC32966")
		@Test
		public void getDocumentMetaDataTestWithMaxDocuments() {
			HashMap<String, String> metadataMap = new HashMap<>();
			metadataMap.put("key1", "value1");
			metadataMap.put("key2", "value2");
			SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			Date date1 = null;
			Date date2 = null;
			try {
				date1 = isoDateFormat.parse("2018-11-14T04:27:42.001Z");
				date2 = isoDateFormat.parse("2018-11-14T04:27:42.002Z");
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DocumentMetaData docMD = new DocumentMetaData();
			docMD.setName("docName");
			docMD.setDateCreated(date1);
			docMD.setDateModified(date2);
			
			List<Object> docList = new ArrayList<>();
			for (int i = 0; i < 300; i++) {
				docList.add(docMD);
			}		
			
			String documentSearchCriteriaJson = "{\"key\" : \"value\"}";
			Criteria documentFilter = new Criteria();
			
			Mockito.when(mongoTemplate.find(Mockito.any(), Mockito.any(), Mockito.anyString())).thenReturn(docList);
			
			List<DocumentMetaData> result = null;

			try {
				result = documentMetaDataService
						.getDocumentMetaData(documentSearchCriteriaJson, documentFilter, 300);
			} catch (InvalidExpressionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			assertNotNull(result);
			assertEquals(300, result.size());
			assertEquals("docName", result.get(0).getName());
			assertEquals(date1, result.get(0).getDateCreated());
			assertEquals(date2, result.get(0).getDateModified());
		}
	
	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void deleteDocumentTest() { 
		DocumentMetaData doc = new DocumentMetaData();
		doc.setStatus(MetaDataStatus.DELETED);
		doc.setId("test");
		doc.setErrorMessage("error");
		doc.setTransactionId("test");
		DocumentMetaData result=documentMetaDataService.deleteDocument("test");
		assertNull(result);
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void updateDocumentMetadataFields2args_shouldSetProvidedFields_andReturnUpdatedDoc() {
		Map<String, Object> fieldsToUpdate = new HashMap<>();
		fieldsToUpdate.put("metadata.key1", "value1");
		fieldsToUpdate.put("externalId", "ext-123");

		DocumentMetaData expected = new DocumentMetaData();
		expected.setId("docId");

		Mockito.when(mongoTemplate.findAndModify(Mockito.any(Query.class), Mockito.any(Update.class),
				Mockito.any(FindAndModifyOptions.class), Mockito.eq(DocumentMetaData.class)))
				.thenReturn(expected);

		DocumentMetaData result = documentMetaDataService.updateDocumentMetadataFields(fieldsToUpdate, "docId");
		assertNotNull(result);
		assertEquals(expected, result);

		ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
		ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);

		verify(mongoTemplate).findAndModify(queryCaptor.capture(), updateCaptor.capture(),
				Mockito.any(FindAndModifyOptions.class), Mockito.eq(DocumentMetaData.class));

		// Query should target the id
		assertEquals("docId", queryCaptor.getValue().getQueryObject().get("id"));

		// Update should contain only the provided fields, and dateModified should be set, but transactionId should not be set by this overload
		Document updateDoc = updateCaptor.getValue().getUpdateObject();
		assertNotNull(updateDoc.get("$set"));
		Document setDoc = (Document) updateDoc.get("$set");
		assertEquals("value1", setDoc.get("metadata.key1"));
		assertEquals("ext-123", setDoc.get("externalId"));
		assertNull("2-arg overload should not set transactionId", setDoc.get("transactionId"));
		assertNotNull("2-arg overload should not set dateModified", setDoc.get("dateModified"));
	}

	@UserStory(references = "US32799")
	@RallyTestCase(references = "TC32966")
	@Test
	public void updateDocumentMetadataFields2args_shouldAllowEmptyFieldsMap_andStillCallFindAndModify() {
		Map<String, Object> fieldsToUpdate = new HashMap<>();

		DocumentMetaData expected = new DocumentMetaData();
		expected.setId("docId");

		Mockito.when(mongoTemplate.findAndModify(Mockito.any(Query.class), Mockito.any(Update.class),
				Mockito.any(FindAndModifyOptions.class), Mockito.eq(DocumentMetaData.class)))
				.thenReturn(expected);

		DocumentMetaData result = documentMetaDataService.updateDocumentMetadataFields(fieldsToUpdate, "docId");
		assertEquals(expected, result);

		ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);
		verify(mongoTemplate).findAndModify(Mockito.any(Query.class), updateCaptor.capture(),
				Mockito.any(FindAndModifyOptions.class), Mockito.eq(DocumentMetaData.class));

		Document updateDoc = updateCaptor.getValue().getUpdateObject();
		// With empty map, Mongo Update might be empty. Just assert it doesn't include trxId, but dateModified should still be set
		Document setDoc = (Document) updateDoc.get("$set");
		if (setDoc != null) {
			assertNull(setDoc.get("transactionId"));
			assertNotNull(setDoc.get("dateModified"));
		}
	}

	@Test(expected = NullPointerException.class)
	public void updateDocumentMetadataFields2args_shouldThrowNpe_whenFieldsMapIsNull() {
		documentMetaDataService.updateDocumentMetadataFields(null, "docId");
	}
}

