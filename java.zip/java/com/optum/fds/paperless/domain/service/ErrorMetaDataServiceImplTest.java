package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.constants.CommonConstants;
import com.optum.fds.paperless.exception.ErrorCode;
import com.optum.fds.paperless.exception.ProcessException;
import com.optum.fds.paperless.exception.ValidationException;
import com.optum.fds.paperless.java.delegate.DelegateExecutionImpl;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.util.Parser;
import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.util.LinkedMultiValueMap;

import java.io.IOException;
import java.util.*;

import static org.junit.Assert.*;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class ErrorMetaDataServiceImplTest {

    @Mock
    private MongoTemplate mongoTemplate;

    @InjectMocks
    private ErrorMetaDataServiceImpl errorMetaDataService;

    @Captor
    private ArgumentCaptor<ErrorMetaData> errorMetaDataCaptor;

    private DelegateExecution execution;
    private ErrorMetaData errorMetaData;

    @Before
    public void setUp() {
        execution = new DelegateExecutionImpl();
        execution.setVariable("processKey", "testProcess");
        execution.setVariable("hookId", "testHookId");
        execution.setVariable("docId", "testDocId");

        errorMetaData = new ErrorMetaData();
        errorMetaData.setId("testId");
        errorMetaData.setTargetId("testTargetId");
        errorMetaData.setStatus(MetaDataStatus.COMPLETE_WITH_ERRORS);
    }

    @Test
    public void testWriteToErrorCollection() {
        when(mongoTemplate.insert(any(ErrorMetaData.class), any(String.class))).thenAnswer(invocation -> {
            ErrorMetaData insertedErrorMetaData = invocation.getArgument(0);
            insertedErrorMetaData.setErrorMessage("testException");
            insertedErrorMetaData.setTargetId("testTargetId"); // Ensure targetId is set correctly
            insertedErrorMetaData.setErrorCode(ErrorCode.BOUNCE_EMAIL_ERROR); // Ensure errorCode is set correctly
            return insertedErrorMetaData;
        });
        ErrorMetaData result = errorMetaDataService.writeToErrorCollection(execution, "testException");

        assertNotNull(result);
        assertEquals("testTargetId", result.getTargetId());
        assertEquals("testException", result.getErrorMessage());
        assertEquals(ErrorCode.BOUNCE_EMAIL_ERROR, result.getErrorCode());
    }

    @Test
    public void testPutErrorMetadata_WithAllFields() {
        ErrorMetaData errorMetaData = new ErrorMetaData();
        errorMetaData.setId("testId");
        errorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
        List<String> revisions = new ArrayList<>();
        revisions.add("rev1");
        errorMetaData.setRevisions(revisions);

        Document metadata = new Document();
        metadata.put("key1", "value1");
        errorMetaData.setMetadata(metadata);

        errorMetaData.setIdentifier("testIdentifier");
        errorMetaData.setErrorMessage("Test error message");

        ErrorMetaData updatedMetaData = new ErrorMetaData();
        updatedMetaData.setId("testId");
        updatedMetaData.setStatus(MetaDataStatus.IN_PROCESS);

        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
        ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);
        ArgumentCaptor<FindAndModifyOptions> optionsCaptor = ArgumentCaptor.forClass(FindAndModifyOptions.class);

        when(mongoTemplate.findAndModify(
                queryCaptor.capture(),
                updateCaptor.capture(),
                optionsCaptor.capture(),
                eq(ErrorMetaData.class)
        )).thenReturn(updatedMetaData);

        ErrorMetaData result = errorMetaDataService.putErrorMetadata(errorMetaData);

        assertNotNull(result);
        assertEquals(updatedMetaData, result);

        Query capturedQuery = queryCaptor.getValue();
        assertTrue(capturedQuery.toString().contains("id"));

        Update capturedUpdate = updateCaptor.getValue();
        Document updateDoc = capturedUpdate.getUpdateObject();
        Document setDoc = (Document) updateDoc.get("$set");

        assertNotNull(setDoc);
        assertEquals(MetaDataStatus.IN_PROCESS.toString(), setDoc.get("status").toString());
        assertTrue(setDoc.containsKey("dateModified"));
        assertEquals(revisions, setDoc.get("revisions"));
        assertEquals(metadata, setDoc.get("metadata"));
        assertEquals("testIdentifier", setDoc.get("identifier"));
        assertEquals("Test error message", setDoc.get("errorMessage"));

        FindAndModifyOptions capturedOptions = optionsCaptor.getValue();
        assertTrue(capturedOptions.isReturnNew());
    }

    @Test
    public void testPutErrorMetadata_EmptyMetadata() {
        ErrorMetaData errorMetaData = new ErrorMetaData();
        errorMetaData.setId("testId");
        errorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
        errorMetaData.setMetadata(new Document());

        ErrorMetaData updatedMetaData = new ErrorMetaData();
        updatedMetaData.setId("testId");

        ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);

        when(mongoTemplate.findAndModify(
                any(Query.class),
                updateCaptor.capture(),
                any(FindAndModifyOptions.class),
                eq(ErrorMetaData.class)
        )).thenReturn(updatedMetaData);

        ErrorMetaData result = errorMetaDataService.putErrorMetadata(errorMetaData);

        assertNotNull(result);

        Update capturedUpdate = updateCaptor.getValue();
        Document updateDoc = capturedUpdate.getUpdateObject();

        // Should have $unset for metadata
        assertTrue(updateDoc.containsKey("$unset"));
        Document unsetDoc = (Document) updateDoc.get("$unset");
        assertTrue(unsetDoc.containsKey("metadata"));
    }

    @Test
    public void testPutErrorMetadata_NullMetadata() {
        ErrorMetaData errorMetaData = new ErrorMetaData();
        errorMetaData.setId("testId");
        errorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
        errorMetaData.setMetadata(null);

        ErrorMetaData updatedMetaData = new ErrorMetaData();
        updatedMetaData.setId("testId");

        ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);

        when(mongoTemplate.findAndModify(
                any(Query.class),
                updateCaptor.capture(),
                any(FindAndModifyOptions.class),
                eq(ErrorMetaData.class)
        )).thenReturn(updatedMetaData);

        ErrorMetaData result = errorMetaDataService.putErrorMetadata(errorMetaData);

        assertNotNull(result);

        Update capturedUpdate = updateCaptor.getValue();
        Document updateDoc = capturedUpdate.getUpdateObject();
        Document setDoc = (Document) updateDoc.get("$set");

        // Should not have metadata field
        assertFalse(setDoc.containsKey("metadata"));
        assertFalse(updateDoc.containsKey("$unset") && ((Document)updateDoc.get("$unset")).containsKey("metadata"));
    }

    @Test
    public void testPutErrorMetadata_EmptyIdentifierAndErrorMessage() {
        ErrorMetaData errorMetaData = new ErrorMetaData();
        errorMetaData.setId("testId");
        errorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
        errorMetaData.setIdentifier("");
        errorMetaData.setErrorMessage("");

        ErrorMetaData updatedMetaData = new ErrorMetaData();
        updatedMetaData.setId("testId");

        ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);

        when(mongoTemplate.findAndModify(
                any(Query.class),
                updateCaptor.capture(),
                any(FindAndModifyOptions.class),
                eq(ErrorMetaData.class)
        )).thenReturn(updatedMetaData);

        ErrorMetaData result = errorMetaDataService.putErrorMetadata(errorMetaData);

        assertNotNull(result);

        Update capturedUpdate = updateCaptor.getValue();
        Document updateDoc = capturedUpdate.getUpdateObject();

        assertTrue(updateDoc.containsKey("$unset"));
        Document unsetDoc = (Document) updateDoc.get("$unset");
        assertTrue(unsetDoc.containsKey("identifier"));
        assertTrue(unsetDoc.containsKey("errorMessage"));
    }

    @Test
    public void testPutErrorMetadata_DocumentNotFound() {
        ErrorMetaData errorMetaData = new ErrorMetaData();
        errorMetaData.setId("nonExistentId");
        errorMetaData.setStatus(MetaDataStatus.IN_PROCESS);

        when(mongoTemplate.findAndModify(
                any(Query.class),
                any(Update.class),
                any(FindAndModifyOptions.class),
                eq(ErrorMetaData.class)
        )).thenReturn(null);

        ErrorMetaData result = errorMetaDataService.putErrorMetadata(errorMetaData);

        assertNull(result);
        verify(mongoTemplate).findAndModify(
                any(Query.class),
                any(Update.class),
                any(FindAndModifyOptions.class),
                eq(ErrorMetaData.class)
        );
    }

    @Test(expected = ValidationException.class)
    public void testGetErrorMetaData_NullFilter() throws ValidationException {
        String documentSearchCriteriaJson = "{}";
        Criteria documentFilter = null;

        errorMetaDataService.getErrorMetaData(documentSearchCriteriaJson, documentFilter);
    }

    @Test
    public void testGetErrorMetaData_EmptyResult() throws ValidationException {
        String documentSearchCriteriaJson = "{\"identifier\":\"test\"}";
        Criteria documentFilter = Criteria.where("status").is(MetaDataStatus.COMPLETE);

        when(mongoTemplate.find(any(BasicQuery.class), eq(ErrorMetaData.class), eq("appError")))
                .thenReturn(new ArrayList<>());

        List<ErrorMetaData> result = errorMetaDataService.getErrorMetaData(documentSearchCriteriaJson, documentFilter);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testGetErrorMetaData_ComplexQuery() throws ValidationException {
        String documentSearchCriteriaJson = "{\"targetId\":\"12345\",\"spaceId\":100}";
        Criteria documentFilter = Criteria.where("status").in(MetaDataStatus.NEW, MetaDataStatus.IN_PROCESS)
                .and("retryCount").lt(3);

        List<ErrorMetaData> expectedList = Arrays.asList(
                createErrorMetaData("1", "12345", MetaDataStatus.NEW),
                createErrorMetaData("2", "12345", MetaDataStatus.IN_PROCESS)
        );

        ArgumentCaptor<BasicQuery> queryCaptor = ArgumentCaptor.forClass(BasicQuery.class);

        when(mongoTemplate.find(queryCaptor.capture(), eq(ErrorMetaData.class), eq("appError")))
                .thenReturn(expectedList);

        List<ErrorMetaData> result = errorMetaDataService.getErrorMetaData(documentSearchCriteriaJson, documentFilter);

        assertNotNull(result);
        assertEquals(2, result.size());

        BasicQuery capturedQuery = queryCaptor.getValue();
        String queryString = capturedQuery.toString();
        assertTrue(queryString.contains("targetId"));
        assertTrue(queryString.contains("spaceId"));
        assertTrue(queryString.contains("status"));
        assertTrue(queryString.contains("retryCount"));
    }

    @Test(expected = RuntimeException.class)
    public void testGetErrorMetaData_MongoException() throws ValidationException {
        String documentSearchCriteriaJson = "{}";
        Criteria documentFilter = Criteria.where("status").is(MetaDataStatus.NEW);

        when(mongoTemplate.find(any(BasicQuery.class), eq(ErrorMetaData.class), eq("appError")))
                .thenThrow(new RuntimeException("MongoDB connection failed"));

        errorMetaDataService.getErrorMetaData(documentSearchCriteriaJson, documentFilter);
    }

    private ErrorMetaData createErrorMetaData(String id, String targetId, MetaDataStatus status) {
        ErrorMetaData metadata = new ErrorMetaData();
        metadata.setId(id);
        metadata.setTargetId(targetId);
        metadata.setStatus(status);
        metadata.setRetryCount(0);
        return metadata;
    }

    @Test
    public void testUpdateErrorMetadataFields_MultipleFields() {
        String documentId = "doc123";
        Map<String, Object> fieldsToUpdate = new HashMap<>();
        fieldsToUpdate.put("errorMessage", "Updated error message");
        fieldsToUpdate.put("retryCount", 5);
        fieldsToUpdate.put("status", MetaDataStatus.IN_PROCESS);

        ErrorMetaData existingMetaData = new ErrorMetaData();
        existingMetaData.setId(documentId);
        existingMetaData.setErrorMessage("Original error");
        existingMetaData.setRetryCount(0);
        existingMetaData.setStatus(MetaDataStatus.NEW);

        ErrorMetaData updatedMetaData = new ErrorMetaData();
        updatedMetaData.setId(documentId);
        updatedMetaData.setErrorMessage("Updated error message");
        updatedMetaData.setRetryCount(5);
        updatedMetaData.setStatus(MetaDataStatus.IN_PROCESS);

        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class),
                any(FindAndModifyOptions.class), eq(ErrorMetaData.class)))
                .thenReturn(updatedMetaData);

        ErrorMetaData result = errorMetaDataService.updateErrorMetadataFields(fieldsToUpdate, documentId);

        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
        ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);
        ArgumentCaptor<FindAndModifyOptions> optionsCaptor = ArgumentCaptor.forClass(FindAndModifyOptions.class);

        verify(mongoTemplate).findAndModify(queryCaptor.capture(), updateCaptor.capture(),
                optionsCaptor.capture(), eq(ErrorMetaData.class));

        Query capturedQuery = queryCaptor.getValue();
        assertTrue(capturedQuery.toString().contains("id"));
        assertTrue(capturedQuery.toString().contains(documentId));

        Update capturedUpdate = updateCaptor.getValue();
        Document updateDoc = capturedUpdate.getUpdateObject();
        assertTrue(updateDoc.containsKey("$set"));
        Document setDoc = (Document) updateDoc.get("$set");
        assertEquals("Updated error message", setDoc.get("errorMessage"));
        assertEquals(5, setDoc.get("retryCount"));
        assertEquals(MetaDataStatus.IN_PROCESS, setDoc.get("status"));
        assertTrue(setDoc.containsKey("dateModified"));

        FindAndModifyOptions capturedOptions = optionsCaptor.getValue();
        assertTrue(capturedOptions.isReturnNew());

        assertEquals(updatedMetaData, result);
    }

    @Test
    public void testUpdateErrorMetadataFields_EmptyMap() {
        String documentId = "doc123";
        Map<String, Object> fieldsToUpdate = new HashMap<>();

        ErrorMetaData updatedMetaData = new ErrorMetaData();
        updatedMetaData.setId(documentId);
        updatedMetaData.setDateModified(new Date());

        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class),
                any(FindAndModifyOptions.class), eq(ErrorMetaData.class)))
                .thenReturn(updatedMetaData);

        ErrorMetaData result = errorMetaDataService.updateErrorMetadataFields(fieldsToUpdate, documentId);

        ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);
        verify(mongoTemplate).findAndModify(any(Query.class), updateCaptor.capture(),
                any(FindAndModifyOptions.class), eq(ErrorMetaData.class));

        Update capturedUpdate = updateCaptor.getValue();
        Document updateDoc = capturedUpdate.getUpdateObject();
        Document setDoc = (Document) updateDoc.get("$set");

        // Should only contain dateModified
        assertEquals(1, setDoc.size());
        assertTrue(setDoc.containsKey("dateModified"));

        assertEquals(updatedMetaData, result);
    }

    @Test
    public void testUpdateErrorMetadataFields_NullValues() {
        String documentId = "doc123";
        Map<String, Object> fieldsToUpdate = new HashMap<>();
        fieldsToUpdate.put("errorMessage", null);
        fieldsToUpdate.put("targetId", null);

        ErrorMetaData updatedMetaData = new ErrorMetaData();
        updatedMetaData.setId(documentId);
        updatedMetaData.setErrorMessage(null);
        updatedMetaData.setTargetId(null);

        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class),
                any(FindAndModifyOptions.class), eq(ErrorMetaData.class)))
                .thenReturn(updatedMetaData);

        ErrorMetaData result = errorMetaDataService.updateErrorMetadataFields(fieldsToUpdate, documentId);

        ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);
        verify(mongoTemplate).findAndModify(any(Query.class), updateCaptor.capture(),
                any(FindAndModifyOptions.class), eq(ErrorMetaData.class));

        Update capturedUpdate = updateCaptor.getValue();
        Document updateDoc = capturedUpdate.getUpdateObject();
        Document setDoc = (Document) updateDoc.get("$set");

        assertTrue(setDoc.containsKey("errorMessage"));
        assertNull(setDoc.get("errorMessage"));
        assertTrue(setDoc.containsKey("targetId"));
        assertNull(setDoc.get("targetId"));

        assertEquals(updatedMetaData, result);
    }

    @Test
    public void testUpdateErrorMetadataFields_ComplexTypes() {
        String documentId = "doc123";
        Map<String, Object> fieldsToUpdate = new HashMap<>();

        Document metadata = new Document();
        metadata.put("key1", "value1");
        metadata.put("nested", new Document("nestedKey", "nestedValue"));

        List<String> tags = Arrays.asList("tag1", "tag2", "tag3");

        fieldsToUpdate.put("metadata", metadata);
        fieldsToUpdate.put("tags", tags);

        ErrorMetaData updatedMetaData = new ErrorMetaData();
        updatedMetaData.setId(documentId);
        updatedMetaData.setMetadata(metadata);

        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class),
                any(FindAndModifyOptions.class), eq(ErrorMetaData.class)))
                .thenReturn(updatedMetaData);

        ErrorMetaData result = errorMetaDataService.updateErrorMetadataFields(fieldsToUpdate, documentId);

        ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);
        verify(mongoTemplate).findAndModify(any(Query.class), updateCaptor.capture(),
                any(FindAndModifyOptions.class), eq(ErrorMetaData.class));

        Update capturedUpdate = updateCaptor.getValue();
        Document updateDoc = capturedUpdate.getUpdateObject();
        Document setDoc = (Document) updateDoc.get("$set");

        assertTrue(setDoc.containsKey("metadata"));
        assertTrue(setDoc.containsKey("tags"));

        Document capturedMetadata = (Document) setDoc.get("metadata");
        assertEquals("value1", capturedMetadata.get("key1"));

        assertEquals(updatedMetaData, result);
    }

    @Test
    public void testUpdateErrorMetadataFields_DocumentNotFound() {
        String documentId = "nonExistentId";
        Map<String, Object> fieldsToUpdate = new HashMap<>();
        fieldsToUpdate.put("errorMessage", "Updated error message");

        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class),
                any(FindAndModifyOptions.class), eq(ErrorMetaData.class)))
                .thenReturn(null);

        ErrorMetaData result = errorMetaDataService.updateErrorMetadataFields(fieldsToUpdate, documentId);

        verify(mongoTemplate).findAndModify(any(Query.class), any(Update.class),
                any(FindAndModifyOptions.class), eq(ErrorMetaData.class));

        assertNull(result);
    }

    @Test
    public void testWriteToMessageServiceErrorCollection_WithVariables_Success() throws Exception {
        String queue = "testQueue";
        String identifier = "testIdentifier";
        String targetId = "testTargetId";
        Integer spaceId = 123;
        Map<String, Object> variables = new HashMap<>();
        variables.put("key1", "value1");
        String errorMsg = "Test error message";
        MetaDataStatus status = MetaDataStatus.COMPLETE_WITH_ERRORS;

        String jsonString = "{\"delegate\":[\"testIdentifier\"],\"callbackMap\":[{\"key1\":\"value1\"}]}";
        errorMetaDataService.supportedDelegatesIndex = "testDelegateIndex";

        ErrorMetaData expectedErrorMetaData = new ErrorMetaData();
        expectedErrorMetaData.setId("generatedId");

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.toJson(any(LinkedMultiValueMap.class)))
                    .thenReturn(jsonString);

            when(mongoTemplate.insert(any(ErrorMetaData.class), eq("appError"))).thenReturn(expectedErrorMetaData);

            ErrorMetaData result = errorMetaDataService.writeToMessageServiceErrorCollection(
                    queue, identifier, targetId, spaceId, variables, errorMsg, status);

            assertNotNull(result);
            assertEquals(expectedErrorMetaData, result);

            verify(mongoTemplate).insert(errorMetaDataCaptor.capture(), eq("appError"));
            ErrorMetaData capturedErrorMetaData = errorMetaDataCaptor.getValue();

            assertEquals(identifier, capturedErrorMetaData.getIdentifier());
            assertEquals(targetId, capturedErrorMetaData.getTargetId());
            assertEquals(spaceId, capturedErrorMetaData.getSpaceId());
            assertEquals(queue, capturedErrorMetaData.getQueue());
            assertEquals(0, capturedErrorMetaData.getRetryCount().intValue());
            assertEquals(CommonConstants.ENGINE_DELIGATE_URL, capturedErrorMetaData.getReplyTo());
            assertEquals("testDelegateIndex", capturedErrorMetaData.getReplyToIndex());
            assertEquals(errorMsg, capturedErrorMetaData.getErrorMessage());
            assertEquals(ErrorCode.REST_API_ERROR, capturedErrorMetaData.getErrorCode());
            assertEquals(status, capturedErrorMetaData.getStatus());
        }
    }

    @Test
    public void testWriteToMessageServiceErrorCollection_WithVariables_Exception() throws Exception {
        String queue = "testQueue";
        String identifier = "testIdentifier";
        String targetId = "testTargetId";
        Integer spaceId = 123;
        Map<String, Object> variables = new HashMap<>();
        variables.put("key1", "value1");
        String errorMsg = "Test error message";
        MetaDataStatus status = MetaDataStatus.COMPLETE_WITH_ERRORS;

        errorMetaDataService.supportedDelegatesIndex = "testDelegateIndex";

        ErrorMetaData expectedErrorMetaData = new ErrorMetaData();
        expectedErrorMetaData.setId("generatedId");

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.toJson(any(LinkedMultiValueMap.class)))
                    .thenThrow(new IOException("Test exception"));

            when(mongoTemplate.insert(any(ErrorMetaData.class), eq("appError"))).thenReturn(expectedErrorMetaData);

            ErrorMetaData result = errorMetaDataService.writeToMessageServiceErrorCollection(
                    queue, identifier, targetId, spaceId, variables, errorMsg, status);

            assertNotNull(result);
            assertEquals(expectedErrorMetaData, result);

            verify(mongoTemplate).insert(errorMetaDataCaptor.capture(), eq("appError"));
            ErrorMetaData capturedErrorMetaData = errorMetaDataCaptor.getValue();

            assertEquals(identifier, capturedErrorMetaData.getIdentifier());
            assertEquals(targetId, capturedErrorMetaData.getTargetId());
            assertEquals(spaceId, capturedErrorMetaData.getSpaceId());
            assertEquals(queue, capturedErrorMetaData.getQueue());
            assertEquals(MetaDataStatus.MANUAL, capturedErrorMetaData.getStatus());
            assertTrue(capturedErrorMetaData.getErrorMessage().contains(errorMsg));
            assertTrue(capturedErrorMetaData.getErrorMessage().contains("Test exception"));
        }
    }

    @Test
    public void testWriteToMessageServiceErrorCollection_WithJsonString() {
        String queue = "testQueue";
        String identifier = "testIdentifier";
        String targetId = "testTargetId";
        Integer spaceId = 123;
        String errorMsg = "Test error message";
        String jsonStr = "{\"test\":\"value\"}";
        MetaDataStatus status = MetaDataStatus.NEW;

        errorMetaDataService.supportedDelegatesIndex = "testDelegateIndex";

        ErrorMetaData expectedErrorMetaData = new ErrorMetaData();
        expectedErrorMetaData.setId("generatedId");

        when(mongoTemplate.insert(any(ErrorMetaData.class), eq("appError"))).thenReturn(expectedErrorMetaData);

        ErrorMetaData result = errorMetaDataService.writeToMessageServiceErrorCollection(
                queue, identifier, targetId, spaceId, errorMsg, jsonStr, status);

        assertNotNull(result);
        assertEquals(expectedErrorMetaData, result);

        verify(mongoTemplate).insert(errorMetaDataCaptor.capture(), eq("appError"));
        ErrorMetaData capturedErrorMetaData = errorMetaDataCaptor.getValue();

        assertEquals(identifier, capturedErrorMetaData.getIdentifier());
        assertEquals(targetId, capturedErrorMetaData.getTargetId());
        assertEquals(spaceId, capturedErrorMetaData.getSpaceId());
        assertEquals(queue, capturedErrorMetaData.getQueue());
        assertEquals(0, capturedErrorMetaData.getRetryCount().intValue());
        assertEquals(CommonConstants.ENGINE_DELIGATE_URL, capturedErrorMetaData.getReplyTo());
        assertEquals("testDelegateIndex", capturedErrorMetaData.getReplyToIndex());
        assertEquals(errorMsg, capturedErrorMetaData.getErrorMessage());
        assertEquals(ErrorCode.REST_API_ERROR, capturedErrorMetaData.getErrorCode());
        assertEquals(status, capturedErrorMetaData.getStatus());

        Document expectedDoc = Document.parse(jsonStr);
        assertEquals(expectedDoc.toString(), capturedErrorMetaData.getMetadata().toString());
    }

    @Test
    public void testWriteToMessageServiceErrorCollection_WithNullValues() {
        String queue = null;
        String identifier = null;
        String targetId = null;
        Integer spaceId = null;
        String errorMsg = null;
        String jsonStr = "{}";
        MetaDataStatus status = null;

        errorMetaDataService.supportedDelegatesIndex = "testDelegateIndex";

        ErrorMetaData expectedErrorMetaData = new ErrorMetaData();
        expectedErrorMetaData.setId("generatedId");

        when(mongoTemplate.insert(any(ErrorMetaData.class), eq("appError"))).thenReturn(expectedErrorMetaData);

        ErrorMetaData result = errorMetaDataService.writeToMessageServiceErrorCollection(
                queue, identifier, targetId, spaceId, errorMsg, jsonStr, status);

        assertNotNull(result);

        verify(mongoTemplate).insert(errorMetaDataCaptor.capture(), eq("appError"));
        ErrorMetaData capturedErrorMetaData = errorMetaDataCaptor.getValue();

        assertNull(capturedErrorMetaData.getIdentifier());
        assertNull(capturedErrorMetaData.getTargetId());
        assertNull(capturedErrorMetaData.getSpaceId());
        assertNull(capturedErrorMetaData.getQueue());
        assertEquals(0, capturedErrorMetaData.getRetryCount().intValue());
        assertEquals(CommonConstants.ENGINE_DELIGATE_URL, capturedErrorMetaData.getReplyTo());
        assertEquals("testDelegateIndex", capturedErrorMetaData.getReplyToIndex());
        assertNull(capturedErrorMetaData.getErrorMessage());
        assertEquals(ErrorCode.REST_API_ERROR, capturedErrorMetaData.getErrorCode());
        assertNull(capturedErrorMetaData.getStatus());
    }

    @Test
    public void testWriteToMessageServiceErrorCollection_WithInvalidJson() {
        String queue = "testQueue";
        String identifier = "testIdentifier";
        String targetId = "testTargetId";
        Integer spaceId = 123;
        String errorMsg = "Test error message";
        String jsonStr = "invalid json";
        MetaDataStatus status = MetaDataStatus.NEW;

        errorMetaDataService.supportedDelegatesIndex = "testDelegateIndex";

        try {
            errorMetaDataService.writeToMessageServiceErrorCollection(
                    queue, identifier, targetId, spaceId, errorMsg, jsonStr, status);
            fail("Expected exception was not thrown");
        } catch (Exception e) {
            assertTrue(e instanceof org.bson.json.JsonParseException);
        }
    }

    @Test
    public void testGetMultiValueMapToJson_Success() throws Exception {
        String delegate = "testDelegate";
        Map<String, Object> delegateParams = new HashMap<>();
        delegateParams.put("param1", "value1");
        delegateParams.put("param2", 123);

        String expectedJson = "{\"delegate\":[\"testDelegate\"],\"callbackMap\":[{\"param1\":\"value1\",\"param2\":123}]}";

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.toJson(any(LinkedMultiValueMap.class)))
                    .thenReturn(expectedJson);

            String result = errorMetaDataService.getMultiValueMapToJson(delegate, delegateParams);

            assertEquals(expectedJson, result);
            mockedParser.verify(() -> Parser.toJson(any(LinkedMultiValueMap.class)));
        }
    }

    @Test
    public void testGetMultiValueMapToJson_EmptyMap() throws Exception {
        String delegate = "testDelegate";
        Map<String, Object> delegateParams = new HashMap<>();

        String expectedJson = "{\"delegate\":[\"testDelegate\"],\"callbackMap\":[{}]}";

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.toJson(any(LinkedMultiValueMap.class)))
                    .thenReturn(expectedJson);

            String result = errorMetaDataService.getMultiValueMapToJson(delegate, delegateParams);

            assertEquals(expectedJson, result);
        }
    }

    @Test
    public void testGetMultiValueMapToJson_NullMap() throws Exception {
        String delegate = "testDelegate";
        Map<String, Object> delegateParams = null;

        String expectedJson = "{\"delegate\":[\"testDelegate\"],\"callbackMap\":[null]}";

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.toJson(any(LinkedMultiValueMap.class)))
                    .thenReturn(expectedJson);

            String result = errorMetaDataService.getMultiValueMapToJson(delegate, delegateParams);

            assertEquals(expectedJson, result);
        }
    }

    @Test
    public void testGetMultiValueMapToJson_ComplexMap() throws Exception {
        String delegate = "testDelegate";
        Map<String, Object> nestedMap = new HashMap<>();
        nestedMap.put("nestedKey", "nestedValue");

        Map<String, Object> delegateParams = new HashMap<>();
        delegateParams.put("param1", "value1");
        delegateParams.put("nestedMap", nestedMap);
        delegateParams.put("numberArray", new Integer[]{1, 2, 3});

        String expectedJson = "{\"complex\":\"json\"}";

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.toJson(any(LinkedMultiValueMap.class)))
                    .thenReturn(expectedJson);

            String result = errorMetaDataService.getMultiValueMapToJson(delegate, delegateParams);

            assertEquals(expectedJson, result);
        }
    }

    @Test(expected = ProcessException.class)
    public void testGetMultiValueMapToJson_IOException() throws Exception {
        String delegate = "testDelegate";
        Map<String, Object> delegateParams = new HashMap<>();
        delegateParams.put("param1", "value1");

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.toJson(any(LinkedMultiValueMap.class)))
                    .thenThrow(new IOException("Simulated IO error"));

            // Act - should throw ProcessException
            errorMetaDataService.getMultiValueMapToJson(delegate, delegateParams);
            // Assert - handled by expected exception
        }
    }

    @Test
    public void testGetMultiValueMapToJson_ExceptionMessage() {
        String delegate = "testDelegate";
        Map<String, Object> delegateParams = new HashMap<>();
        delegateParams.put("param1", "value1");

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            IOException ioException = new IOException("Simulated IO error");
            mockedParser.when(() -> Parser.toJson(any(LinkedMultiValueMap.class)))
                    .thenThrow(ioException);

            try {
                errorMetaDataService.getMultiValueMapToJson(delegate, delegateParams);
                fail("Expected ProcessException was not thrown");
            } catch (ProcessException e) {
                assertTrue(e.getMessage().contains("Failure getMultiValueMapToJson"));
                assertTrue(e.getMessage().contains("delegate=testDelegate"));
                assertTrue(e.getMessage().contains("Simulated IO error"));
            }
        }
    }
}