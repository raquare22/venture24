package com.optum.fds.paperless.domain.service;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.test.util.ReflectionTestUtils;

import com.amazonaws.services.s3.AmazonS3;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.JobMetaData;

@RunWith(MockitoJUnitRunner.class)
public class FilestoreServiceTest {
	
    @Mock
    FilestoreServiceImpl filestoreService;
    
    @Mock
    AmazonS3 amazonS3;
    
	@Before
	public void setUp() {
//	    ReflectionTestUtils.setField(filestoreService, "AWSS3Secret",  "test");
//	    ReflectionTestUtils.setField(filestoreService, "AWSS3Access", "test");
//	    ReflectionTestUtils.setField(filestoreService, "AWSS3Url", "test");
//	    ReflectionTestUtils.setField(filestoreService, "AWSS3Region", "test");
//	    ReflectionTestUtils.setField(filestoreService, "AWSS3Bucket", "test");
//	    filestoreService.init();
//	    Mockito.when(filestoreService.init()).thenReturn(null);
	}
	
	
	@Test
	public void insertFileTest() { 
		Mockito.when(filestoreService.insertFile(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
		
		boolean result = filestoreService.insertFile("test", "test");
		assertTrue(result);
	}
	
	@Test
	public void getBucketFilePathFromLocationTest() {
		
		Mockito.when(filestoreService.getBucketFilePathFromLocation(Mockito.anyString())).thenReturn("10502/ODAR_18804100_20220208090930_SMALLBOUNCETEST3");
		
		String location = "/persistent/vgqgr06m3gde1xgxqdu6whbm8rfddd26/10502/ODAR_18804100_20220208090930_SMALLBOUNCETEST3";
		String result = filestoreService.getBucketFilePathFromLocation(location);
		assertEquals("10502/ODAR_18804100_20220208090930_SMALLBOUNCETEST3", result);
		
	}


}
