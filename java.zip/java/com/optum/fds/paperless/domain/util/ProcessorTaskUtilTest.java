package com.optum.fds.paperless.domain.util;
import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.*;

import java.io.File;
import java.util.*;

import com.optum.fds.paperless.domain.service.*;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.FileUtil;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mvel2.MVEL;
import org.mvel2.PropertyAccessException;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;
import com.optum.fds.paperless.mongo.ProcessorTransactionCore;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.executions.UnprocessedRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;

public class ProcessorTaskUtilTest {

	@Mock
	ProcessorFileTaskService processorFileTaskService;
	@Mock
	ProcessorsService processorsService;
	@Mock
	MongoTemplate mongoTemplate;
	@InjectMocks
	ProcessorTaskUtil processorTaskUtil;
	@Mock
	UnprocessedRecord unprocessedRecord;

	@Mock
	CsvProcessorService csssvProcessorService;

	@SuppressWarnings("static-access")
	@Test
	public void addMessageToProcessorExecutionRecordToProcessorTransactionTest() throws Exception {
		ProcessorTransactionCore processorTransactionCore = new ProcessorTransactionCore();
		ProcessorExecutionRecord ProcessorExecutionRecord = new ProcessorExecutionRecord();
		processorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransactionCore,
				ProcessorExecutionRecord, Map.of("test", "one"));
	}

	@SuppressWarnings("static-access")
	@Test
	public void addMessageToProcessorExecutionRecordToProcessorTransactionMetadataTest() throws Exception {
		ProcessorTransactionMetadata processorTransactionMetadata = new ProcessorTransactionMetadata();
		ProcessorExecutionRecord ProcessorExecutionRecord = new ProcessorExecutionRecord();
		processorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransactionMetadata(
				processorTransactionMetadata, ProcessorExecutionRecord, Map.of("test", "one"));
	}

	@SuppressWarnings("static-access")
	@Test
	public void addMessageToProcessorExecutionRecordTest() throws Exception {
		ProcessorExecutionRecord ProcessorExecutionRecord = new ProcessorExecutionRecord();
		ProcessorExecutionRecord Result = processorTaskUtil
				.addMessageToProcessorExecutionRecord(ProcessorExecutionRecord, Map.of("test", "one"));
		ProcessorExecutionRecord.getDateModified();
		ProcessorExecutionRecord.addMessage(null);
		assertNotNull(Result);
	}

	@SuppressWarnings("static-access")
	@Test
	public void createProcessorExecutionRecordTest() throws Exception {
		ProcessorExecutionRecord result = processorTaskUtil.createProcessorExecutionRecord("description");
		assertNotNull(result);
	}

	@SuppressWarnings("static-access")
	@Test
	public void validateCriteriaMatchTest() throws Exception {
		boolean result = processorTaskUtil.validateCriteriaMatch("expression", Map.of("test", "one"));
		assertNotNull(result);
	}

	@SuppressWarnings("static-access")
	@Test
	public void findDuplicateErrorTest() throws Exception {
		boolean result = processorTaskUtil.findDuplicateError("errormsg", Set.of("test"));
		assertNotNull(result);
	}

	@SuppressWarnings("static-access")
	@Test
	public void createProcessorExecutionRecordTestTwo() throws Exception {
		ProcessorTransactionCore ProcessorTransactionCore = new ProcessorTransactionCore();
		ProcessorTransactionCore.setClientId(4563);
		ProcessorTransactionCore.setConfigSpaceId(3456);
		ProcessorExecutionRecord result = processorTaskUtil.createProcessorExecutionRecord("description",
				ProcessorTransactionCore);
		assertNotNull(result);
	}

	@SuppressWarnings("static-access")
	@Test
	public void updateProcessTransactionWithExecutionRecordtest() throws Exception {
		ProcessorTransactionCore processorTransactionCore = new ProcessorTransactionCore();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		CsvProcessorService csvProcessorService = new CsvProcessorServiceImpl(mongoTemplate);
		processorTaskUtil.updateProcessTransactionWithExecutionRecord(csvProcessorService, processorTransactionCore,
				processorExecutionRecord, Map.of("test", "one"));
	}

	@SuppressWarnings("static-access")
	@Test
	public void createProcessorExecutionRecordTestWithMap() throws Exception {
		HashMap<String, String> Mapmessage = new HashMap<String, String>();
		Mapmessage.put("test", "test");
		ProcessorExecutionRecord result = processorTaskUtil.createProcessorExecutionRecord("description", Mapmessage);
		assertNotNull(result);
	}

    @SuppressWarnings("static-access")
    @Test
    public void updateFileMetricsTest() throws Exception {
        CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
        File file = new File("sample.json");
        CsvProcessorService csvProcessorService = mock(CsvProcessorService.class);

        processorTaskUtil.updateFileMetrics(csvProcessorTransaction, file, csvProcessorService);

        assertEquals("sample.json", csvProcessorTransaction.getJsonFileName());
        verify(csvProcessorService).updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
    }

    @SuppressWarnings("static-access")
    @Test
    public void updateServerMetricsTest() throws Exception {
        CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
        CsvProcessorService csvProcessorService = mock(CsvProcessorService.class);

        processorTaskUtil.updateServerMetrics(csvProcessorTransaction, csvProcessorService);

        verify(csvProcessorService).updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
    }
	@SuppressWarnings("static-access")
	@Test
	public void addMiscellaneousToProcessorExecutionRecordTest() throws Exception {
		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		processorFileTask.setClientId(2345);
		processorFileTask.setConfigSpaceId(3456767);
		ProcessorExecutionRecord ProcessorExecutionRecord = new ProcessorExecutionRecord();
		com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord result = processorTaskUtil
				.addMiscellaneousToProcessorExecutionRecord(processorFileTask, ProcessorExecutionRecord);
		assertNotNull(result);
	}

	@SuppressWarnings("static-access")
	@Test
	public void updateFileMetricsTestTwo() throws Exception {
		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		File file = new File("C:\\Users\\spratap8\\FDSPaperLessProject_new\\PRUN_Workspace\\fds-paperless-activiti");
		ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskServiceImpl.class);
		processorTaskUtil.updateFileMetrics(processorFileTask, file, processorFileTaskService);
	}

	@SuppressWarnings("static-access")
	@Test
	public void updateServerMetricsTestTwo() throws Exception {
		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskServiceImpl.class);
		processorTaskUtil.updateServerMetrics(processorFileTask, processorFileTaskService);
	}

	@SuppressWarnings("static-access")
	@Test
	public void updateProcessFileTaskWithExecutionRecordTest() throws Exception {
		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskServiceImpl.class);
		processorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask,
				processorExecutionRecord);
	}

	@SuppressWarnings("static-access")
	@Test
	public void updateProcessFileTaskWithExecutionRecordTestTwo() throws Exception {
		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		processorFileTask.setConfigSpaceId(3456);
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskServiceImpl.class);
		HashMap<String, String> Mapmessage = new HashMap<String, String>();
		Mapmessage.put("test", "test");
		processorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask,
				processorExecutionRecord, Mapmessage);
	}

	@SuppressWarnings("static-access")
	@Test
	public void getFileNameTest() throws Exception {
		ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskServiceImpl.class);
		ProcessorsService processorsService = new ProcessorsServiceImpl();
		String fileNameResult = processorTaskUtil.getFileName("test", "test", processorFileTaskService,
				processorsService);
		assertNotNull(fileNameResult);
	}

    @Test
    public void getFileName_returnsEmpty_whenProcessorFileTaskIsNull() {
        ProcessorFileTaskService fileTaskService = mock(ProcessorFileTaskService.class);
        ProcessorsService processorsService = mock(ProcessorsService.class);

        when(fileTaskService.getProcessorFileTaskForTargetId("doc1", "documents", "app1")).thenReturn(null);

        String result = ProcessorTaskUtil.getFileName("doc1", "app1", fileTaskService, processorsService);

        assertEquals("", result);
        verify(fileTaskService, times(1))
                .getProcessorFileTaskForTargetId("doc1", "documents", "app1");
        verifyNoInteractions(processorsService);
    }

    @Test
    public void getFileName_returnsFileName_whenProcessorFileTaskExists() {
        ProcessorFileTaskService fileTaskService = mock(ProcessorFileTaskService.class);
        ProcessorsService processorsService = mock(ProcessorsService.class);

        ProcessorFileTask task = new ProcessorFileTask();
        task.setProcessorTransactionId("tx-1");

        ProcessorTransaction tx = new ProcessorTransaction();
        tx.setFileName("sample.zip");

        when(fileTaskService.getProcessorFileTaskForTargetId("doc2", "documents", "app2")).thenReturn(task);
        when(processorsService.getTransactionProcessorById("tx-1")).thenReturn(tx);

        String result = ProcessorTaskUtil.getFileName("doc2", "app2", fileTaskService, processorsService);

        assertEquals("sample.zip", result);
        verify(fileTaskService).getProcessorFileTaskForTargetId("doc2", "documents", "app2");
        verify(processorsService).getTransactionProcessorById("tx-1");
    }

    @Test
    public void addMiscellaneousToProcessorExecutionRecord_setsClientAndSpace() {
        ProcessorFileTask task = new ProcessorFileTask();
        task.setClientId(101);
        task.setConfigSpaceId(202);

        ProcessorExecutionRecord rec = new ProcessorExecutionRecord();

        ProcessorExecutionRecord result = ProcessorTaskUtil.addMiscellaneousToProcessorExecutionRecord(task, rec);

        assertNotNull(result);
        assertEquals(101, result.getClientId());
        assertEquals(202, result.getSpaceId());
    }

    @Test
    public void findDuplicateError_returnsTrue_whenAnyContainsError() {
        boolean result = ProcessorTaskUtil.findDuplicateError("error", new HashSet<>(Arrays.asList("abc", "my-error")));

        assertTrue(result);
    }

    @Test
    public void findDuplicateError_returnsFalse_whenNoneContainsError() {
        boolean result = ProcessorTaskUtil.findDuplicateError("error", new HashSet<>(Arrays.asList("abc", "xyz")));

        assertFalse(result);
    }

    @Test
    public void createProcessorExecutionRecord_withDescriptionAndTransaction_setsFields() {
        ProcessorTransactionCore core = new ProcessorTransactionCore();
        core.setClientId(1234);
        core.setConfigSpaceId(5678);

        ProcessorExecutionRecord result = ProcessorTaskUtil.createProcessorExecutionRecord("desc", core);

        assertNotNull(result);
        assertEquals("desc", result.getDescription());
        assertEquals(1234, result.getClientId());
        assertEquals(5678, result.getSpaceId());
        assertNotNull(result.getDateCreated());
        assertNotNull(result.getDateModified());
    }

    @Test
    public void updateFileMetrics_processorFileTask_updatesAndCallsService() {
        ProcessorFileTaskService fileTaskService = mock(ProcessorFileTaskService.class);
        ProcessorFileTask task = new ProcessorFileTask();
        File file = new File("README.md");

        ProcessorTaskUtil.updateFileMetrics(task, file, fileTaskService);

        verify(fileTaskService, times(1)).updateProcessorFileTask(task);
        assertNotNull(task.getFileType());
    }

    @Test
    public void updateFileMetrics_csvProcessorTransaction_setsJsonFileNameAndCallsService() {
        CsvProcessorService csvService = mock(CsvProcessorService.class);
        CsvProcessorTransaction tx = new CsvProcessorTransaction();
        File file = new File("data.json");

        ProcessorTaskUtil.updateFileMetrics(tx, file, csvService);

        assertEquals("data.json", tx.getJsonFileName());
        verify(csvService, times(1)).updateCsvProcessorTransactionMetaData(tx);
    }

    @Test
    public void updateServerMetrics_processorFileTask_callsService() {
        ProcessorFileTaskService fileTaskService = mock(ProcessorFileTaskService.class);
        ProcessorFileTask task = new ProcessorFileTask();

        ProcessorTaskUtil.updateServerMetrics(task, fileTaskService);

        verify(fileTaskService, times(1)).updateProcessorFileTask(task);
        assertNotNull(task.getProcessedByHost());
    }

    @Test
    public void updateServerMetrics_csvProcessorTransaction_callsService() {
        CsvProcessorService csvService = mock(CsvProcessorService.class);
        CsvProcessorTransaction tx = new CsvProcessorTransaction();

        ProcessorTaskUtil.updateServerMetrics(tx, csvService);

        verify(csvService, times(1)).updateCsvProcessorTransactionMetaData(tx);
    }

    @Test
    public void updateProcessFileTaskWithExecutionRecord_withoutMessage_addsExecutionRecordAndUpdates() {
        ProcessorFileTaskService fileTaskService = mock(ProcessorFileTaskService.class);
        ProcessorFileTask task = new ProcessorFileTask();
        ProcessorExecutionRecord rec = new ProcessorExecutionRecord();

        ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(fileTaskService, task, rec);

        verify(fileTaskService, times(1)).updateProcessorFileTask(task);
        assertNotNull(task.getProcessorExecutionRecordList());
        assertFalse(task.getProcessorExecutionRecordList().isEmpty());
    }

    @Test
    public void updateProcessFileTaskWithExecutionRecord_withMessage_addsAndUpdates() {
        ProcessorFileTaskService fileTaskService = mock(ProcessorFileTaskService.class);
        ProcessorFileTask task = new ProcessorFileTask();
        task.setClientId(11);
        task.setConfigSpaceId(22);
        ProcessorExecutionRecord rec = new ProcessorExecutionRecord();
        Map<String, String> msg = Map.of("k", "v");

        ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(fileTaskService, task, rec, msg);

        verify(fileTaskService, times(1)).updateProcessorFileTask(task);
        assertEquals(11, rec.getClientId());
        assertEquals(22, rec.getSpaceId());
        assertNotNull(rec.getMessageList());
        assertFalse(rec.getMessageList().isEmpty());
    }

    @Test
    public void updateProcessTransactionWithExecutionRecord_processorService_withoutMessage_updates() {
        ProcessorService processorService = mock(ProcessorService.class);
        ProcessorTransaction tx = new ProcessorTransaction();
        ProcessorExecutionRecord rec = new ProcessorExecutionRecord();

        ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(processorService, tx, rec);

        verify(processorService, times(1)).updateProcessorTransactionMetaData(tx);
        assertNotNull(tx.getProcessorExecutionRecordList());
        assertFalse(tx.getProcessorExecutionRecordList().isEmpty());
    }

    @Test
    public void updateProcessTransactionWithExecutionRecord_processorService_withMessage_updates() {
        ProcessorService processorService = mock(ProcessorService.class);
        ProcessorTransaction tx = new ProcessorTransaction();
        ProcessorExecutionRecord rec = new ProcessorExecutionRecord();
        Map<String, String> msg = Map.of("key", "value");

        ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(processorService, tx, rec, msg);

        verify(processorService, times(1)).updateProcessorTransactionMetaData(tx);
        assertNotNull(rec.getMessageList());
        assertFalse(rec.getMessageList().isEmpty());
    }

    @Test
    public void updateProcessTransactionWithExecutionRecord_csvService_withoutMessage_updatesWhenCsvType() {
        CsvProcessorService csvService = mock(CsvProcessorService.class);
        CsvProcessorTransaction tx = new CsvProcessorTransaction();
        ProcessorExecutionRecord rec = new ProcessorExecutionRecord();

        ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(csvService, tx, rec);

        verify(csvService, times(1)).updateCsvProcessorTransactionMetaData(tx);
        assertNotNull(tx.getProcessorExecutionRecordList());
        assertFalse(tx.getProcessorExecutionRecordList().isEmpty());
    }

    @Test
    public void updateProcessTransactionWithExecutionRecord_csvService_withMessage_updatesWhenCsvType() {
        CsvProcessorService csvService = mock(CsvProcessorService.class);
        CsvProcessorTransaction tx = new CsvProcessorTransaction();
        ProcessorExecutionRecord rec = new ProcessorExecutionRecord();

        ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(csvService, tx, rec, Map.of("m", "n"));

        verify(csvService, times(1)).updateCsvProcessorTransactionMetaData(tx);
        assertNotNull(rec.getMessageList());
        assertFalse(rec.getMessageList().isEmpty());
    }

    @Test
    public void updateProcessTransactionWithUnprocessedRecord_updatesWhenCsvType() {
        CsvProcessorService csvService = mock(CsvProcessorService.class);
        CsvProcessorTransaction tx = new CsvProcessorTransaction();
        List<UnprocessedRecord> records = Collections.singletonList(new UnprocessedRecord("abc", 1));

        ProcessorTaskUtil.updateProcessTransactionWithUnprocessedRecord(csvService, tx, records);

        assertEquals(records, tx.getUnprocessedRecordList());
        verify(csvService, times(1)).updateCsvProcessorTransactionMetaData(tx);
    }

    @Test
    public void getFileName_shouldReturnZipFileName_whenProcessorFileTaskExists() {
        ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskService.class);
        ProcessorsService processorsService = mock(ProcessorsService.class);
        ProcessorFileTask processorFileTask = mock(ProcessorFileTask.class);
        ProcessorTransaction processorTransaction = mock(ProcessorTransaction.class);

        when(processorFileTaskService.getProcessorFileTaskForTargetId("doc-123", "documents", "app-1"))
                .thenReturn(processorFileTask);
        when(processorFileTask.getProcessorTransactionId()).thenReturn("txn-123");
        when(processorsService.getTransactionProcessorById("txn-123")).thenReturn(processorTransaction);
        when(processorTransaction.getFileName()).thenReturn("sample.zip");

        String result = ProcessorTaskUtil.getFileName("doc-123", "app-1", processorFileTaskService, processorsService);

        assertEquals("sample.zip", result);
        verify(processorFileTaskService).getProcessorFileTaskForTargetId("doc-123", "documents", "app-1");
        verify(processorFileTask).getProcessorTransactionId();
        verify(processorsService).getTransactionProcessorById("txn-123");
        verify(processorTransaction).getFileName();
    }

    @Test
    public void getFileName_shouldReturnEmptyString_whenProcessorFileTaskDoesNotExist() {
        ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskService.class);
        ProcessorsService processorsService = mock(ProcessorsService.class);

        when(processorFileTaskService.getProcessorFileTaskForTargetId("doc-123", "documents", "app-1"))
                .thenReturn(null);

        String result = ProcessorTaskUtil.getFileName("doc-123", "app-1", processorFileTaskService, processorsService);

        assertEquals("", result);
        verify(processorFileTaskService).getProcessorFileTaskForTargetId("doc-123", "documents", "app-1");
        verifyNoInteractions(processorsService);
    }

    @Test
    public void addMiscellaneousToProcessorExecutionRecord_shouldCopyClientIdAndSpaceId() {
        ProcessorFileTask processorFileTask = new ProcessorFileTask();
        processorFileTask.setClientId(123);
        processorFileTask.setConfigSpaceId(456);

        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();

        ProcessorExecutionRecord result =
                ProcessorTaskUtil.addMiscellaneousToProcessorExecutionRecord(processorFileTask, executionRecord);

        assertNotNull(result);
        assertSame(executionRecord, result);
        assertEquals(123, result.getClientId());
        assertEquals(456, result.getSpaceId());
    }

    @Test
    public void validateCriteriaMatch_shouldReturnTrue_whenMvelEvaluationSucceeds() {
        Map<String, Object> rootNodeMap = new HashMap<>();
        rootNodeMap.put("status", "ACTIVE");

        try (MockedStatic<MVEL> mvelMock = mockStatic(MVEL.class)) {
            mvelMock.when(() -> MVEL.eval("status == 'ACTIVE'", rootNodeMap))
                    .thenReturn(Boolean.TRUE);

            boolean result = ProcessorTaskUtil.validateCriteriaMatch("status == 'ACTIVE'", rootNodeMap);

            assertTrue(result);
            mvelMock.verify(() -> MVEL.eval("status == 'ACTIVE'", rootNodeMap), times(1));
        }
    }

    @Test
    public void validateCriteriaMatch_shouldReturnFalse_whenPropertyAccessExceptionIsThrown() {
        Map<String, Object> rootNodeMap = new HashMap<>();

        try (MockedStatic<MVEL> mvelMock = mockStatic(MVEL.class)) {
            mvelMock.when(() -> MVEL.eval("missingField == 'X'", rootNodeMap))
                    .thenThrow(new PropertyAccessException("missingField", null, 0, null));

            boolean result = ProcessorTaskUtil.validateCriteriaMatch("missingField == 'X'", rootNodeMap);

            assertFalse(result);
            mvelMock.verify(() -> MVEL.eval("missingField == 'X'", rootNodeMap), times(1));
        }
    }

    @Test
    public void findDuplicateError_shouldReturnFalse_whenNoErrorContainsGivenMessage() {
        Set<String> errorList = new HashSet<>();
        errorList.add("File processing failed due to invalid header");
        errorList.add("Document upload timeout");

        boolean result = ProcessorTaskUtil.findDuplicateError("missing metadata", errorList);

        assertFalse(result);
    }

    @Test
    public void createProcessorExecutionRecord_withMessage_shouldCreateRecordAndAddMessage() {
        HashMap<String, String> message = new HashMap<>();
        message.put("status", "processed");

        FileUtil fileUtil = mock(FileUtil.class);
        when(fileUtil.getLocalHostName()).thenReturn("test-host");
        when(fileUtil.getLocalHostIP()).thenReturn("127.0.0.1");

        try (MockedStatic<FileUtil> fileUtilMock = mockStatic(FileUtil.class)) {
            fileUtilMock.when(FileUtil::getInstance).thenReturn(fileUtil);

            ProcessorExecutionRecord result =
                    ProcessorTaskUtil.createProcessorExecutionRecord("test description", message);

            assertNotNull(result);
            assertEquals("test description", result.getDescription());
            assertEquals("test-host", result.getServerName());
            assertEquals("127.0.0.1", result.getServerIp());
            assertNotNull(result.getDateCreated());
            assertNotNull(result.getDateModified());
            assertNotNull(result.getMessageList());
            assertEquals(1, result.getMessageList().size());
            assertEquals("processed", result.getMessageList().get(0).get("status"));
        }
    }

    @Test
    public void updateFileMetrics_shouldSetFileSizeAndTypeAndUpdateProcessorFileTask() throws Exception {
        ProcessorFileTask processorFileTask = new ProcessorFileTask();
        ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskService.class);

        File tempFile = File.createTempFile("processorTaskUtilTest", ".txt");
        tempFile.deleteOnExit();

        java.nio.file.Files.write(tempFile.toPath(), "sample-data".getBytes(java.nio.charset.StandardCharsets.UTF_8));

        ProcessorTaskUtil.updateFileMetrics(processorFileTask, tempFile, processorFileTaskService);

        assertEquals(Long.valueOf(tempFile.length()), processorFileTask.getFileSize());
        assertEquals("txt", processorFileTask.getFileType());
        verify(processorFileTaskService).updateProcessorFileTask(processorFileTask);
    }

    @Test
    public void updateServerMetrics_shouldSetProcessedByHostAndUpdateProcessorFileTask() {
        ProcessorFileTask processorFileTask = new ProcessorFileTask();
        ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskService.class);
        FileUtil fileUtil = mock(FileUtil.class);

        when(fileUtil.getLocalHostName()).thenReturn("test-host");

        try (MockedStatic<FileUtil> fileUtilMock = mockStatic(FileUtil.class)) {
            fileUtilMock.when(FileUtil::getInstance).thenReturn(fileUtil);

            ProcessorTaskUtil.updateServerMetrics(processorFileTask, processorFileTaskService);

            assertEquals("test-host", processorFileTask.getProcessedByHost());
            verify(processorFileTaskService).updateProcessorFileTask(processorFileTask);
        }
    }

    @Test
    public void updateServerMetrics_shouldUpdateCsvProcessorTransactionMetadata() {
        CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
        CsvProcessorService csvProcessorService = mock(CsvProcessorService.class);

        ProcessorTaskUtil.updateServerMetrics(csvProcessorTransaction, csvProcessorService);

        verify(csvProcessorService).updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
    }

    @Test
    public void updateProcessFileTaskWithExecutionRecord_shouldAddExecutionRecordAndUpdateTask() {
        ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskService.class);
        ProcessorFileTask processorFileTask = new ProcessorFileTask();
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();

        ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(
                processorFileTaskService, processorFileTask, executionRecord);

        assertNotNull(processorFileTask.getProcessorExecutionRecordList());
        assertEquals(1, processorFileTask.getProcessorExecutionRecordList().size());
        assertSame(executionRecord, processorFileTask.getProcessorExecutionRecordList().get(0));
        verify(processorFileTaskService).updateProcessorFileTask(processorFileTask);
    }

    @Test
    public void updateProcessFileTaskWithExecutionRecord_withMessage_shouldAddMessageMiscellaneousAndUpdateTask() {
        ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskService.class);
        ProcessorFileTask processorFileTask = new ProcessorFileTask();
        processorFileTask.setClientId(123);
        processorFileTask.setConfigSpaceId(456);

        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();
        Map<String, String> message = new HashMap<>();
        message.put("status", "done");

        ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(
                processorFileTaskService, processorFileTask, executionRecord, message);

        assertNotNull(executionRecord.getDateModified());
        assertEquals(123, executionRecord.getClientId());
        assertEquals(456, executionRecord.getSpaceId());
        assertNotNull(executionRecord.getMessageList());
        assertEquals(1, executionRecord.getMessageList().size());
        assertEquals("done", executionRecord.getMessageList().get(0).get("status"));

        assertNotNull(processorFileTask.getProcessorExecutionRecordList());
        assertEquals(1, processorFileTask.getProcessorExecutionRecordList().size());
        assertSame(executionRecord, processorFileTask.getProcessorExecutionRecordList().get(0));

        verify(processorFileTaskService).updateProcessorFileTask(processorFileTask);
    }

    @Test
    public void updateProcessTransactionWithExecutionRecord_shouldAddExecutionRecordAndUpdateTransaction() {
        ProcessorService processorService = mock(ProcessorService.class);
        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();

        ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(
                processorService, processorTransaction, executionRecord);

        assertNotNull(processorTransaction.getProcessorExecutionRecordList());
        assertEquals(1, processorTransaction.getProcessorExecutionRecordList().size());
        assertSame(executionRecord, processorTransaction.getProcessorExecutionRecordList().get(0));
        verify(processorService).updateProcessorTransactionMetaData(processorTransaction);
    }

    @Test
    public void updateProcessTransactionWithExecutionRecord_withMessage_shouldAddMessageAndUpdateTransaction() {
        ProcessorService processorService = mock(ProcessorService.class);
        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();
        Map<String, String> message = new HashMap<>();
        message.put("result", "success");

        ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(
                processorService, processorTransaction, executionRecord, message);

        assertNotNull(executionRecord.getDateModified());
        assertNotNull(executionRecord.getMessageList());
        assertEquals(1, executionRecord.getMessageList().size());
        assertEquals("success", executionRecord.getMessageList().get(0).get("result"));

        assertNotNull(processorTransaction.getProcessorExecutionRecordList());
        assertEquals(1, processorTransaction.getProcessorExecutionRecordList().size());
        assertSame(executionRecord, processorTransaction.getProcessorExecutionRecordList().get(0));

        verify(processorService).updateProcessorTransactionMetaData(processorTransaction);
    }

    @Test
    public void updateProcessTransactionWithUnprocessedRecord_shouldUpdateCsvTransaction_whenTransactionIsCsvProcessorTransaction() {
        CsvProcessorService csvProcessorService = mock(CsvProcessorService.class);
        CsvProcessorTransaction processorTransaction = new CsvProcessorTransaction();
        List<UnprocessedRecord> unprocessedRecords = Arrays.asList(new UnprocessedRecord("", 0), new UnprocessedRecord("", 1));

        ProcessorTaskUtil.updateProcessTransactionWithUnprocessedRecord(
                csvProcessorService,
                processorTransaction,
                unprocessedRecords
        );

        assertSame(unprocessedRecords, processorTransaction.getUnprocessedRecordList());
        verify(csvProcessorService).updateCsvProcessorTransactionMetaData(processorTransaction);
    }

    @Test
    public void updateProcessTransactionWithUnprocessedRecord_shouldNotUpdateCsvService_whenTransactionIsNotCsvProcessorTransaction() {
        CsvProcessorService csvProcessorService = mock(CsvProcessorService.class);
        ProcessorTransactionCore processorTransaction = new ProcessorTransactionCore();
        List<UnprocessedRecord> unprocessedRecords = Arrays.asList(new UnprocessedRecord("", 0));

        ProcessorTaskUtil.updateProcessTransactionWithUnprocessedRecord(
                csvProcessorService,
                processorTransaction,
                unprocessedRecords
        );

        assertSame(unprocessedRecords, processorTransaction.getUnprocessedRecordList());
        verify(csvProcessorService, never()).updateCsvProcessorTransactionMetaData(org.mockito.ArgumentMatchers.any());
    }

}
