package com.optum.fds.paperless.domain.revision;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;

public class DocumentRevisionTest {

    private DocumentRevision documentRevision;

    @Before
    public void setUp() {
        documentRevision = new DocumentRevision();
    }

    @Test
    public void testGetAndSetExternalId() {
        assertNull(documentRevision.getExternalId());
        documentRevision.setExternalId("External123");
        assertEquals("External123", documentRevision.getExternalId());
    }

    @Test
    public void testGetAndSetDateAttachmentUpdated() {
        assertNull(documentRevision.getDateAttachmentUpdated());
        Date date = new Date();
        documentRevision.setDateAttachmentUpdated(date);
        assertEquals(date, documentRevision.getDateAttachmentUpdated());
    }

    @Test
    public void testGetAndSetMetadata() {
        assertNull(documentRevision.getMetadata());
        Document metadata = new Document("key", "value");
        documentRevision.setMetadata(metadata);
        assertEquals(metadata, documentRevision.getMetadata());
    }

    @Test
    public void testGetAndSetDocumentAttachments() {
        assertNull(documentRevision.getDocumentAttachments());
        List<DocumentAttachmentMetaData> attachments = new ArrayList<>();
        DocumentAttachmentMetaData attachment = new DocumentAttachmentMetaData();
        attachments.add(attachment);
        documentRevision.setDocumentAttachments(attachments);
        assertEquals(attachments, documentRevision.getDocumentAttachments());
    }

    @Test
    public void testGetAndSetErrorMessage() {
        assertNull(documentRevision.getErrorMessage());
        documentRevision.setErrorMessage("Error occurred");
        assertEquals("Error occurred", documentRevision.getErrorMessage());
    }
}
