package com.optum.fds.paperless.domain.revision;

import java.util.Date;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class AttachmentRevisionTest {

    private AttachmentRevision attachmentRevision;

    @Before
    public void setUp() {
        attachmentRevision = new AttachmentRevision();
    }

    @Test
    public void testGetAndSetAdapterId() {
        assertNull(attachmentRevision.getAdapterId());
        attachmentRevision.setAdapterId("Adapter123");
        assertEquals("Adapter123", attachmentRevision.getAdapterId());
    }

    @Test
    public void testGetAndSetAdapterName() {
        assertNull(attachmentRevision.getAdapterName());
        attachmentRevision.setAdapterName("AdapterName");
        assertEquals("AdapterName", attachmentRevision.getAdapterName());
    }

    @Test
    public void testGetAndSetAdapterTypeId() {
        assertNull(attachmentRevision.getAdapterTypeId());
        attachmentRevision.setAdapterTypeId("Type123");
        assertEquals("Type123", attachmentRevision.getAdapterTypeId());
    }

    @Test
    public void testGetAndSetContentType() {
        assertNull(attachmentRevision.getContentType());
        attachmentRevision.setContentType("application/pdf");
        assertEquals("application/pdf", attachmentRevision.getContentType());
    }

    @Test
    public void testGetAndSetDateAttachmentUpdated() {
        assertNull(attachmentRevision.getDateAttachmentUpdated());
        Date date = new Date();
        attachmentRevision.setDateAttachmentUpdated(date);
        assertEquals(date, attachmentRevision.getDateAttachmentUpdated());
    }

    @Test
    public void testGetAndSetExpires() {
        assertNull(attachmentRevision.getExpires());
        Date date = new Date();
        attachmentRevision.setExpires(date);
        assertEquals(date, attachmentRevision.getExpires());
    }

    @Test
    public void testGetAndSetExternalId() {
        assertNull(attachmentRevision.getExternalId());
        attachmentRevision.setExternalId("External123");
        assertEquals("External123", attachmentRevision.getExternalId());
    }

    @Test
    public void testGetAndSetFilename() {
        assertNull(attachmentRevision.getFilename());
        attachmentRevision.setFilename("file.pdf");
        assertEquals("file.pdf", attachmentRevision.getFilename());
    }

    @Test
    public void testGetAndSetFileSize() {
        assertEquals(0, attachmentRevision.getFileSize());
        attachmentRevision.setFileSize(1024);
        assertEquals(1024, attachmentRevision.getFileSize());
    }

    @Test
    public void testGetAndSetFsId() {
        assertNull(attachmentRevision.getFsId());
        attachmentRevision.setFsId("Fs123");
        assertEquals("Fs123", attachmentRevision.getFsId());
    }

    @Test
    public void testGetAndSetOriginalStorageDate() {
        assertNull(attachmentRevision.getOriginalStorageDate());
        Date date = new Date();
        attachmentRevision.setOriginalStorageDate(date);
        assertEquals(date, attachmentRevision.getOriginalStorageDate());
    }

    @Test
    public void testGetAndSetSourceSystemDateCreated() {
        assertNull(attachmentRevision.getSourceSystemDateCreated());
        Date date = new Date();
        attachmentRevision.setSourceSystemDateCreated(date);
        assertEquals(date, attachmentRevision.getSourceSystemDateCreated());
    }

    @Test
    public void testGetAndSetSourceSystemName() {
        assertNull(attachmentRevision.getSourceSystemName());
        attachmentRevision.setSourceSystemName("SystemName");
        assertEquals("SystemName", attachmentRevision.getSourceSystemName());
    }

    @Test
    public void testGetAndSetStAdapterDocId() {
        assertNull(attachmentRevision.getStAdapterDocId());
        attachmentRevision.setStAdapterDocId("Doc123");
        assertEquals("Doc123", attachmentRevision.getStAdapterDocId());
    }
}