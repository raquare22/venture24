package com.optum.fds.paperless.domain.revision;

import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

public class RevisionTest {

    private Revision revision;

    @Before
    public void setUp() {
        revision = new Revision();
    }

    @Test
    public void testGetAndSetAppIdentifier() {
        assertNull(revision.getAppIdentifier());
        revision.setAppIdentifier("App123");
        assertEquals("App123", revision.getAppIdentifier());
    }

    @Test
    public void testGetAndSetClientId() {
        assertEquals(0, revision.getClientId());
        revision.setClientId(123);
        assertEquals(123, revision.getClientId());
    }

    @Test
    public void testGetAndSetDateCreated() {
        assertNull(revision.getDateCreated());
        Date date = new Date();
        revision.setDateCreated(date);
        assertEquals(date, revision.getDateCreated());
    }

    @Test
    public void testGetAndSetDateModified() {
        assertNull(revision.getDateModified());
        Date date = new Date();
        revision.setDateModified(date);
        assertEquals(date, revision.getDateModified());
    }

    @Test
    public void testGetAndSetName() {
        assertNull(revision.getName());
        revision.setName("RevisionName");
        assertEquals("RevisionName", revision.getName());
    }

    @Test
    public void testGetAndSetSpaceId() {
        assertEquals(0, revision.getSpaceId());
        revision.setSpaceId(8001);
        assertEquals(8001, revision.getSpaceId());
    }

    @Test
    public void testGetAndSetStatus() {
        assertNull(revision.getStatus());
        revision.setStatus(MetaDataStatus.ACTIVE);
        assertEquals(MetaDataStatus.ACTIVE, revision.getStatus());
    }

    @Test
    public void testGetAndSetTransactionId() {
        assertNull(revision.getTransactionId());
        revision.setTransactionId("TX123");
        assertEquals("TX123", revision.getTransactionId());
    }

    @Test
    public void testGetAndSetVersion() {
        assertNull(revision.getVersion());
        revision.setVersion("1.0");
        assertEquals("1.0", revision.getVersion());
    }
}