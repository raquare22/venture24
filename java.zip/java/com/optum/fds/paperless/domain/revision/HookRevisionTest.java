package com.optum.fds.paperless.domain.revision;

import org.bson.Document;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class HookRevisionTest {

    private HookRevision hookRevision;

    @Before
    public void setUp() {
        hookRevision = new HookRevision();
    }

    @Test
    public void testGetAndSetErrorMessage() {
        assertNull(hookRevision.getErrorMessage());
        hookRevision.setErrorMessage("Error occurred");
        assertEquals("Error occurred", hookRevision.getErrorMessage());
    }

    @Test
    public void testGetAndSetHook() {
        assertNull(hookRevision.getHook());
        Document hook = new Document("key", "value");
        hookRevision.setHook(hook);
        assertEquals(hook, hookRevision.getHook());
    }
}