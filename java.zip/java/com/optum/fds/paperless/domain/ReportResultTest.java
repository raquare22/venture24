package com.optum.fds.paperless.domain;

import org.junit.Test;
import static org.junit.Assert.*;

public class ReportResultTest {

    @Test
    public void testGettersAndSetters() {
        ReportResult reportResult = new ReportResult();

        reportResult.setId("testId");
        assertEquals("testId", reportResult.getId());

        reportResult.setCount(100L);
        assertEquals(Long.valueOf(100), reportResult.getCount());
    }
}