package com.optum.fds.paperless.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.bson.Document;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.FDSHelper;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.util.DocumentUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;

@SpringBootTest(webEnvironment = WebEnvironment.MOCK)
@RunWith(MockitoJUnitRunner.class)
@AutoConfigureMockMvc
public class DocumentControllerTest {
	@Autowired
	MockMvc mockMvc;
	@Mock
	DocumentMetaDataService documentMetaDataService;
	@Mock
	DocumentUtil documentUtil;
	@InjectMocks
	DocumentController documentController;
	String test = "test";
	String processMetadata = "string";
	String id = "stringId";
	String jsonString = "{\n" + "\t\"id\": \"60db1bef05d1ba0052bea1ea\",\n" + "\t\"space_id\": 8896,\n"
			+ "\t\"status\": \"AVAILABLE\",\n" + "\t\"metadata\": {\n"
			+ "\t\t\"providerEmailId\": \"lane_k_mooney@uhc.com\",\n"
			+ "\t\t\"original_email_from\": \"paperless_letters@uhc.com\",\n"
			+ "\t\t\"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" + "\t}\n" + "}";
	String jsonStringTwo = "{\n" + "\t\"id\": \"\",\n" + "\t\"space_id\": 8896,\n" + "\t\"status\": \"AVAILABLE\",\n"
			+ "\t\"metadata\": {\n" + "\t\t\"providerEmailId\": \"lane_k_mooney@uhc.com\",\n"
			+ "\t\t\"original_email_from\": \"paperless_letters@uhc.com\",\n"
			+ "\t\t\"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" + "\t}\n" + "}";

	private DocumentMetaData documentMetaData;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
		ObjectMapper mapper = new ObjectMapper();
		ReflectionTestUtils.setField(documentController, "mapper", mapper);
		// FDSHelper fdsHelper = new FDSHelper();
		// ReflectionTestUtils.setField(documentController, "FDSHelper", fdsHelper);
	}

	@org.junit.Test
	public void postDocumentTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		ResponseEntity<GenericResponse> response = documentController.postDocument(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void postDocumentTestwithTry() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		ResponseEntity<GenericResponse> response = documentController.postDocument(jsonString);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@org.junit.Test
	public void postDocumentTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = documentController.postDocument("");
		assertNotNull(response);
	}

//	@org.junit.Test
	public void updateDocumentTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		ResponseEntity<GenericResponse> response = documentController.updateDocument(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void updateDocumentTestwithTry() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		ResponseEntity<GenericResponse> response = documentController.updateDocument(jsonString);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void updateDocumentTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = documentController.updateDocument("");
		assertNotNull(response);
	}

	@org.junit.Test
	public void updateDocumentTestWithIf() throws Exception {
		ResponseEntity<GenericResponse> response = documentController.updateDocument(jsonStringTwo);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@org.junit.Test
	public void postMultiDocumentTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		ResponseEntity<GenericResponse> response = documentController.postMultiDocument(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void postMultiDocumentTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = documentController.postMultiDocument("");
		assertNotNull(response);
	}

	@org.junit.Test
	public void putMultiDocumentTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		ResponseEntity<GenericResponse> response = documentController.putMultiDocument(Map.of("test", "one"));
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@org.junit.Test
	public void puttMultiDocumentTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = documentController.putMultiDocument(Map.of("", ""));
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@org.junit.Test
	public void getDocumentByIdTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		ResponseEntity<GenericResponse> response = documentController.getDocumentById(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@org.junit.Test
	public void getDocumentByIdTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = documentController.getDocumentById("");
		assertNotNull(response);
	}

	@org.junit.Test
	public void getDocumentsTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		ResponseEntity<GenericResponse> response = documentController.getDocuments(Map.of("test", "one"));
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@org.junit.Test
	public void getDocumentsTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = documentController.getDocuments((Map.of("", "")));
		assertNotNull(response);
	}

	@org.junit.Test
	public void deleteDocumentTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		ResponseEntity<GenericResponse> response = documentController.deleteDocument(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@org.junit.Test
	public void deleteDocumentTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = documentController.deleteDocument("");
		assertNotNull(response);
	}

	@org.junit.Test
	public void updateDocumentTestWithValidInput() throws Exception {
		String validJson = "{\n" +
				"\t\"id\": \"someId\",\n" +
				"\t\"space_id\": 8896,\n" +
				"\t\"status\": \"AVAILABLE\",\n" +
				"\t\"metadata\": {\n" +
				"\t\t\"providerEmailId\": \"lane_k_mooney@uhc.com\",\n" +
				"\t\t\"original_email_from\": \"paperless_letters@uhc.com\",\n" +
				"\t\t\"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" +
				"\t}\n" +
				"}";
		DocumentMetaData documentMetaData = new DocumentMetaData();
		documentMetaData.setId("someId");
		Mockito.when(documentMetaDataService.updateDocMetaData(Mockito.any(), Mockito.anyString())).thenReturn(documentMetaData);
		ResponseEntity<GenericResponse> response = documentController.updateDocument(validJson);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@org.junit.Test
	public void updateDocumentTestWithNoDocumentFound() throws Exception {
		String validJson = "{\n" +
				"\t\"id\": \"nonExistingId\",\n" +
				"\t\"space_id\": 8896,\n" +
				"\t\"status\": \"AVAILABLE\",\n" +
				"\t\"metadata\": {\n" +
				"\t\t\"providerEmailId\": \"lane_k_mooney@uhc.com\",\n" +
				"\t\t\"original_email_from\": \"paperless_letters@uhc.com\",\n" +
				"\t\t\"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" +
				"\t}\n" +
				"}";
		Mockito.when(documentMetaDataService.updateDocMetaData(Mockito.any(), Mockito.anyString())).thenReturn(null);
		ResponseEntity<GenericResponse> response = documentController.updateDocument(validJson);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void postMultiDocumentTestWithValidInput() throws Exception {
		String validJson = "[\n" +
				" {\n" +
				"  \"space_id\": 8896,\n" +
				"  \"status\": \"AVAILABLE\",\n" +
				"  \"metadata\": {\n" +
				"   \"providerEmailId\": \"lane_k_mooney@uhc.com\",\n" +
				"   \"original_email_from\": \"paperless_letters@uhc.com\",\n" +
				"   \"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" +
				"  }\n" +
				" }\n" +
				"]";
		List<DocumentMetaData> documentMetaDataList = List.of(new DocumentMetaData());
		Mockito.when(documentMetaDataService.insertMultiDocuments(Mockito.anyList())).thenReturn(documentMetaDataList);
		ResponseEntity<GenericResponse> response = documentController.postMultiDocument(validJson);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@org.junit.Test
	public void putMultiDocumentTestWithException() throws Exception {
		Mockito.when(documentMetaDataService.updateMultiDocuments(Mockito.anyList(), Mockito.any())).thenThrow(new RuntimeException("Test Exception"));
		ResponseEntity<GenericResponse> response = documentController.putMultiDocument(Map.of("documentIds", List.of("id1", "id2"), "document", new Document()));
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void getDocumentsTestWithException() throws Exception {
		Mockito.when(documentMetaDataService.getDocuments(Mockito.anyMap())).thenThrow(new RuntimeException("Test Exception"));
		ResponseEntity<GenericResponse> response = documentController.getDocuments(Map.of("key", "value"));
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void deleteDocumentTestWithDocumentFound() throws Exception {
		DocumentMetaData documentMetaData = new DocumentMetaData();
		documentMetaData.setId("testId");
		Mockito.when(documentMetaDataService.deleteDocument(Mockito.anyString())).thenReturn(documentMetaData);
		ResponseEntity<GenericResponse> response = documentController.deleteDocument("testId");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@org.junit.Test
	public void deleteDocumentTestWithDocumentNotFound() throws Exception {
		Mockito.when(documentMetaDataService.deleteDocument(Mockito.anyString())).thenReturn(null);
		ResponseEntity<GenericResponse> response = documentController.deleteDocument("testId");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
		assertEquals(Objects.requireNonNull(response.getBody()).getStatusMessage(), "OK");
	}

	@org.junit.Test
	public void updateDocumentTestWithJSONException() throws Exception {
		String invalidJson = "{\n" +
				" \"id\": \"someId\",\n" +
				" \"space_id\": 8896,\n" +
				" \"status\": \"AVAILABLE\",\n" +
				" \"metadata\": {\n" +
				"  \"providerEmailId\": \"lane_k_mooney@uhc.com\",\n" +
				"  \"original_email_from\": \"paperless_letters@uhc.com\",\n" +
				"  \"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" +
				" }\n" +
				"}";
		ResponseEntity<GenericResponse> response = documentController.updateDocument(invalidJson);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
		assertEquals(Objects.requireNonNull(response.getBody()).getStatusMessage(), "Error during updateDocument: INTERNAL_SERVER_ERROR");
	}

    @org.junit.Test
    public void updateDocumentTest_whenServiceThrowsException_returns500WithExceptionMessage() throws Exception {
        String validJson = "{\n" +
                "\t\"id\": \"someId\",\n" +
                "\t\"space_id\": 8896,\n" +
                "\t\"status\": \"AVAILABLE\",\n" +
                "\t\"metadata\": {\n" +
                "\t\t\"providerEmailId\": \"lane_k_mooney@uhc.com\",\n" +
                "\t\t\"original_email_from\": \"paperless_letters@uhc.com\",\n" +
                "\t\t\"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" +
                "\t}\n" +
                "}";

        Mockito.when(documentMetaDataService.updateDocMetaData(Mockito.any(), Mockito.anyString()))
                .thenThrow(new RuntimeException("forced-service-failure"));

        ResponseEntity<GenericResponse> response = documentController.updateDocument(validJson);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Error during updateDocument: INTERNAL_SERVER_ERROR",
                Objects.requireNonNull(response.getBody()).getStatusMessage());
        assertEquals("forced-service-failure", response.getBody().getResponse());
    }

    @org.junit.Test
    public void putMultiDocumentTest_whenRequestMapIsEmpty_returnsBadRequest() throws Exception {
        ResponseEntity<GenericResponse> response = documentController.putMultiDocument(Map.of());

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals(
                "Error during putMultiDocument: Invalid request",
                Objects.requireNonNull(response.getBody()).getStatusMessage()
        );
        assertEquals("Null or empty request body", response.getBody().getResponse());
    }

    @org.junit.Test
    public void getDocumentByIdTest_whenServiceThrowsException_returns500() throws Exception {
        Mockito.when(documentMetaDataService.getDocumentMetaData(Mockito.anyString()))
                .thenThrow(new RuntimeException("forced-get-failure"));

        ResponseEntity<GenericResponse> response = documentController.getDocumentById("doc-123");

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals(
                "Error during getDocumentById: INTERNAL_SERVER_ERROR",
                Objects.requireNonNull(response.getBody()).getStatusMessage()
        );
        assertEquals("forced-get-failure", response.getBody().getResponse());
    }

    @org.junit.Test
    public void getDocumentsTest_whenQueryParamsEmpty_returnsBadRequest() throws Exception {
        ResponseEntity<GenericResponse> response = documentController.getDocuments(Map.of());

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals(
                "Error during getDocuments: Invalid request",
                Objects.requireNonNull(response.getBody()).getStatusMessage()
        );
        assertEquals("Null or empty request body", response.getBody().getResponse());
    }

    @org.junit.Test
    public void deleteDocumentTest_whenServiceThrowsException_returns500() throws Exception {
        Mockito.when(documentMetaDataService.deleteDocument(Mockito.anyString()))
                .thenThrow(new RuntimeException("forced-delete-failure"));

        ResponseEntity<GenericResponse> response = documentController.deleteDocument("doc-123");

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals(
                "Error during deleteDocument: INTERNAL_SERVER_ERROR",
                Objects.requireNonNull(response.getBody()).getStatusMessage()
        );
        assertEquals("forced-delete-failure", response.getBody().getResponse());
    }
}
