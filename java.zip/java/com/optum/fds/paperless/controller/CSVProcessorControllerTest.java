package com.optum.fds.paperless.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;

import static org.apache.commons.lang.exception.ExceptionUtils.getMessage;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest(webEnvironment = WebEnvironment.MOCK)
@RunWith(MockitoJUnitRunner.class)
@AutoConfigureMockMvc
public class CSVProcessorControllerTest {
    @Autowired
    MockMvc mockMvc;
    @Mock
    CsvProcessorService csvProcessorService;
    @InjectMocks
    CSVProcessorController cSVProcessorController;
    ObjectMapper mapper = new ObjectMapper();
    String test = "test";
    String processMetadata = "string";
    String jsonString = "{\n" + "\t\"id\": \"60db1bef05d1ba0052bea1ea\",\n" + "\t\"space_id\": 8896,\n"
            + "\t\"status\": \"AVAILABLE\",\n" + "\t\"metadata\": {\n"
            + "\t\t\"providerEmailId\": \"lane_k_mooney@uhc.com\",\n"
            + "\t\t\"original_email_from\": \"paperless_letters@uhc.com\",\n"
            + "\t\t\"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" + "\t}\n" + "}";
    String jsonStringTwo = "{\n" + "\t\"cleanupWorkflow\": \"60db1bef05d1ba0052bea1ea\",\n" + "\t\"endDate\": \"2018-08-21T06:06:01+00:00\"\n\""
            + "\t\"lastRun\": \"AVAILABLE\",\n" + "\t\"lastCleanUpRun\": {\n"
            + "\t\t\"resolveIncompleteProcessorTransactionLastRun\": \"lane_k_mooney@uhc.com\",\n"
            + "\t\t\"startDate\": \"paperless_letters@uhc.com\",\n"
            + "\t\t\"processorType\": \"2018-08-21T06:06:01+00:00\"\n" + "\t}\n" + "}";
    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        ObjectMapper mapper = new ObjectMapper();
        ReflectionTestUtils.setField(cSVProcessorController, "mapper", mapper);
    }

    //@Test
    public void postCSVProcessorTest() {
        // Setup
        CSVProcessorController cSVProcessorController = new CSVProcessorController();
        String jsonStr = null; // Set jsonStr to null to trigger an exception

        // Call the method and capture the exception
        Throwable exception = assertThrows(Throwable.class, () -> cSVProcessorController.postCSVProcessor(jsonStr));

        // Validate the exception message
        assertEquals("Error during postCSVProcessor: INTERNAL_SERVER_ERROR", exception.getMessage());
    }

    //	@org.junit.Test
    public void postCSVProcessorTestWithEmpty() throws Exception {
        ResponseEntity<GenericResponse> response = cSVProcessorController.postCSVProcessor("");
        assertNotNull(response);
    }

    @Test
    public void updateCSVProcessorTest2() throws Exception {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setName("test");
        ResponseEntity<GenericResponse> response = cSVProcessorController.updateCSVProcessor("{\"id\": \"12345\"}");
        try {
            response = cSVProcessorController.updateCSVProcessor("{\"id\": \"12345\"}");
        } catch (Exception ex) {
            assertNotNull(response);
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
        }
    }

    //	@org.junit.Test
    public void updateCSVProcessorTestWithEmpty() throws Exception {
        ResponseEntity<GenericResponse> response = cSVProcessorController.updateCSVProcessor("");
        assertNotNull(response);
    }
    /*
     * @Test public void updateCSVProcessorWithTryTest() throws Exception {
     * ProcessorMetaData ProcessorMetaDataresult=new ProcessorMetaData();
     * ObjectMapper mapper = new ObjectMapper(); ProcessorMetaData readValue =
     * mapper.readValue(jsonStringTwo, ProcessorMetaData.class); var
     * insertedCSVProcessor =
     * csvProcessorService.saveCSVProcessorMetaData(readValue);
     * ResponseEntity<GenericResponse> response =
     * cSVProcessorController.updateCSVProcessor(test); assertNotNull(response);
     * assertEquals(HttpStatus.valueOf(500), response.getStatusCode()); }
     */


    @Test
    public void getCSVProcessorByIdTest() throws Exception {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setName("test");
        // when(csvProcessorService.saveCSVProcessorMetaData(processorMetaData).getName()).thenReturn("test");
        ResponseEntity<GenericResponse> response = cSVProcessorController.getCSVProcessorById(test);
        assertNotNull(response);
        assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
    }

    @org.junit.Test
    public void getCSVProcessorByIdTestWithEmpty() throws Exception {
        ResponseEntity<GenericResponse> response = cSVProcessorController.getCSVProcessorById("");
        assertNotNull(response);
    }

    @Test
    public void deleteCSVProcessorTest() throws Exception {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setName("test");
        // when(csvProcessorService.saveCSVProcessorMetaData(processorMetaData).getName()).thenReturn("test");
        ResponseEntity<GenericResponse> response = cSVProcessorController.deleteCSVProcessor(test);
        assertNotNull(response);
        assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
    }

    @org.junit.Test
    public void deleteCSVProcessorTestWithEmpty() throws Exception {
        ResponseEntity<GenericResponse> response = cSVProcessorController.deleteCSVProcessor("");
        assertNotNull(response);
    }

    @Test
    public void updateCSVProcessorTest() throws Exception {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setName("test");
        // when(csvProcessorService.saveCSVProcessorMetaData(processorMetaData).getName()).thenReturn("test");
        ResponseEntity<GenericResponse> response = cSVProcessorController.updateCSVProcessor("{\"id\": \"12345\"}");
        assertNotNull(response);
        assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
    }

    @Test
    public void postCSVProcessorHappyPathTest() throws Exception {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setName("test");
        ResponseEntity<GenericResponse> response = cSVProcessorController.updateCSVProcessor("{\"id\": \"12345\"}");
        assertNotNull(response);
        assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
    }

    @Test
    public void postCSVProcessorTestException() throws Exception {
        CSVProcessorController csvProcessorController = new CSVProcessorController();
        String id = "12345";
        ResponseEntity<GenericResponse> response = csvProcessorController.postCSVProcessor("{\"id\": \"" + id + "\"}");
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals(HttpStatus.valueOf(500), response.getStatusCode());

    }

    @Test
    public void deleteCSVProcessorTestException() throws Exception {
        CSVProcessorController csvProcessorController = new CSVProcessorController();
        String id = "12345";
        ResponseEntity<GenericResponse> response = csvProcessorController.deleteCSVProcessor("{\"id\": \"" + id + "\"}");
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals(HttpStatus.valueOf(500), response.getStatusCode());

    }

    @Test
    public void updateCSVProcessorTestException() throws Exception {
        CSVProcessorController csvProcessorController = new CSVProcessorController();
        String id = "12345";
        ResponseEntity<GenericResponse> response = csvProcessorController.updateCSVProcessor("{\"id\": \"" + id + "\"}");
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals(HttpStatus.valueOf(500), response.getStatusCode());

    }

    @Test
    public void getCSVProcessorByIdTestException() throws Exception {
        CSVProcessorController csvProcessorController = new CSVProcessorController();
        String id = "12345";
        ResponseEntity<GenericResponse> response = csvProcessorController.getCSVProcessorById("{\"id\": \"" + id + "\"}");
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals(HttpStatus.valueOf(500), response.getStatusCode());

    }

    @Test
    public void getProcessorIdTest() throws Exception {
        String jsonStr = "{\"id\": \"12345\"}";
        String expected = "12345";
        String result = cSVProcessorController.getProcessorId(jsonStr);
        assertEquals(expected,result);
    }

    @Test
    public void postCSVProcessorTestWithNullBody() throws Exception {
        ResponseEntity<GenericResponse> response = cSVProcessorController.postCSVProcessor(null);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
    }

    @Test
    public void postCSVProcessorShouldReturnOkWhenProcessorIsSavedSuccessfully() throws Exception {
        String jsonStr = "{\"id\":\"12345\",\"name\":\"csv-processor\"}";

        ProcessorMetaData savedProcessor = new ProcessorMetaData();
        savedProcessor.setId("12345");
        savedProcessor.setName("csv-processor");

        when(csvProcessorService.saveCSVProcessorMetaData(any(ProcessorMetaData.class)))
                .thenReturn(savedProcessor);

        ResponseEntity<GenericResponse> response = cSVProcessorController.postCSVProcessor(jsonStr);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals(HttpStatus.OK.getReasonPhrase(), response.getBody().getStatusMessage());
        assertSame(savedProcessor, response.getBody().getResponse());

        verify(csvProcessorService, times(1))
                .saveCSVProcessorMetaData(any(ProcessorMetaData.class));
    }

    @Test
    public void updateCSVProcessorShouldReturnBadRequestWhenProcessorIdIsEmpty() throws Exception {
        String jsonStr = "{\"id\":\"\"}";

        ResponseEntity<GenericResponse> response = cSVProcessorController.updateCSVProcessor(jsonStr);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("400", response.getBody().getStatusCode());
        assertEquals("Invalid request", response.getBody().getStatusMessage());
        assertEquals("Null or empty CSV processor id", response.getBody().getResponse());

        verifyNoInteractions(csvProcessorService);
    }

    @Test
    public void getCSVProcessorByIdShouldReturnOkWithProcessorMetaDataWhenFound() throws Exception {
        String id = "12345";

        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setId(id);
        processorMetaData.setName("csv-processor");

        when(csvProcessorService.getCSVProcessorById(id)).thenReturn(processorMetaData);

        ResponseEntity<GenericResponse> response = cSVProcessorController.getCSVProcessorById(id);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals(HttpStatus.OK.getReasonPhrase(), response.getBody().getStatusMessage());
        assertSame(processorMetaData, response.getBody().getResponse());

        verify(csvProcessorService, times(1)).getCSVProcessorById(id);
    }

    @Test
    public void deleteCSVProcessorShouldReturnOkWithProcessorMetaDataWhenFound() throws Exception {
        String id = "12345";

        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setId(id);
        processorMetaData.setName("csv-processor");

        when(csvProcessorService.deleteCSVProcessor(id)).thenReturn(processorMetaData);

        ResponseEntity<GenericResponse> response = cSVProcessorController.deleteCSVProcessor(id);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals(HttpStatus.OK.getReasonPhrase(), response.getBody().getStatusMessage());
        assertSame(processorMetaData, response.getBody().getResponse());

        verify(csvProcessorService, times(1)).deleteCSVProcessor(id);
    }

}