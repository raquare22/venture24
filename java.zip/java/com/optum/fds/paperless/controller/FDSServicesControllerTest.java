package com.optum.fds.paperless.controller;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.gson.Gson;
import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.constants.ProcessKeys;
import com.optum.fds.paperless.domain.service.*;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import org.flowable.engine.ProcessEngines;
import org.flowable.engine.RuntimeService;
import org.bson.Document;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.FDSHelper;
import com.optum.fds.paperless.FDSPaperlessMain;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.springframework.web.client.HttpServerErrorException;

@SpringBootTest(webEnvironment = WebEnvironment.MOCK)
@RunWith(MockitoJUnitRunner.class)
@AutoConfigureMockMvc
public class FDSServicesControllerTest {

	@Autowired
	MockMvc mockMvc;

	@InjectMocks
	private FDSServicesController fDSServicesController;

	@Mock
	private SendQueueService sendQueueService;

	@Mock
	private CsvProcessorsService csvProcessorsService;

	@Mock
	private ObjectMapper objectMapper;

	@Mock
	private RuntimeService runtimeService;

	@Mock
	private DocumentMetaDataService documentMetaDataService;

	@Mock
	private FDSHelper fdsHelper;

	@Mock
	private ProcessEngines processEngine;

	private DocumentMetaData documentMetaData;

	private ProcessorsService processorsService;

    @Mock
	private FilestoreService fileStoreService;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
		documentMetaData = new DocumentMetaData();
		var document = new Document().append(Workflow.PROVIDER_EMAIL_ID, "lane_k_mooney@uhc.com")
				.append("original_email_from", "paperless_letters@uhc.com")
				.append("original_email_datetime", "2018-08-21T06:06:01+00:00");
		documentMetaData.setId("60db1bef05d1ba0052bea1ea");
		documentMetaData.setSpaceId(8896);
		documentMetaData.setStatus(MetaDataStatus.AVAILABLE.toString());
		documentMetaData.setMetadata(document);
		ObjectMapper mapper = new ObjectMapper();
		ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mapper);
		ReflectionTestUtils.setField(fDSServicesController, "fileStoreService", fileStoreService);

		FDSHelper fdsHelper = new FDSHelper();
//		ReflectionTestUtils.setField(fDSServicesController, "FDSHelper", fdsHelper);
	}

	@Test
	public void testExecution() throws Exception {
		Map<String, Object> variables = new HashMap<>();
		variables.put("processorTransactionId", "60703bf37fc43c0050839e7e");
		variables.put("appIdentifier", "cd0a030ccb2d47e786b521e2d7830f9c");
		Map<String, String> params = new HashMap<>();
		params.put("processorTransactionId", "60703bf37fc43c0050839e7e");
		params.put("appIdentifier", "cd0a030ccb2d47e786b521e2d7830f9c");
		String requestJson = new ObjectMapper().writeValueAsString(params);
		// Using try-with-resources to ensure the mock is closed
		//This ensures that the static mock is automatically closed after the test execution,
		// preventing the "static mocking is already registered" error in subsequent tests
		try (MockedStatic<FDSPaperlessMain> mockedStatic = Mockito.mockStatic(FDSPaperlessMain.class)) {
			// mockedStatic.when(() -> FDSHelper.processCleanUp(anyString(), anyString(),
			// anyString())).thenAnswer(Answers.RETURNS_DEFAULTS);
			ResponseEntity<GenericResponse> response = fDSServicesController.runCleanUp(requestJson);
			assertNotNull(response);
		}
	}

	@Test
	public void testBounceEmailEndPoint() throws Exception {
		String jsonString = "{\n" + "\t\"id\": \"60db1bef05d1ba0052bea1ea\",\n" + "\t\"space_id\": 8896,\n"
				+ "\t\"status\": \"AVAILABLE\",\n" + "\t\"metadata\": {\n"
				+ "\t\t\"providerEmailId\": \"lane_k_mooney@uhc.com\",\n"
				+ "\t\t\"original_email_from\": \"paperless_letters@uhc.com\",\n"
				+ "\t\t\"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" + "\t}\n" + "}";
		//when(objectMapper.readValue(anyString(), Mockito.eq(DocumentMAetaData.claAdss))).thenReturn(documentMetaData);
		var response = fDSServicesController.insertDocumentForBouncedEmail(jsonString);
		assertNotNull(response);
		assertNotNull(response.getBody());
		assertEquals("500", response.getBody().getStatusCode());
	}

	@org.junit.Test
	public void insertDocumentForBouncedEmailWithNull() throws Exception {
		ResponseEntity<GenericResponse> result = fDSServicesController.insertDocumentForBouncedEmail("");
		assertNotNull(result);
		assertEquals(HttpStatus.valueOf(400), result.getStatusCode());
	}
	
	
	
	
	 
	@org.junit.Test
	public void invokeWorkflowTestWithIDNull() throws Exception {
		var id = "NONE";
		ResponseEntity<GenericResponse> response = fDSServicesController.invokeWorkflow("", null, null, Map.of("", ""));
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	/*
	 * @Test public void prePostTest() throws Exception { ProcessorMetaData
	 * processorMetaData = new ProcessorMetaData();
	 * processorMetaData.setName("test"); ResponseEntity<GenericResponse> response =
	 * fDSServicesController.prePost("test","test"); assertNotNull(response);
	 * assertEquals(HttpStatus.valueOf(500), response.getStatusCode()); }
	 */
	@org.junit.Test
	public void prePostTestWithNull() throws Exception {
		ResponseEntity<GenericResponse> response = fDSServicesController.prePost("", null);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}
	/*
	 * @Test public void testSendRequestToQueue()
	 * 
	 * { fDSServicesController.sendRequestToQueue(new
	 * ResponseEntity(HttpStatus.OK)); }
	 */

	@Test
	public void prePostTestWithMap() throws Exception {
		Map<String, Object> variables = new HashMap<>();
		String APP_IDENTIFIER = "{appIdentifier" + "\\t\\t\\\"providerEmailId\\\": \\\"lane_k_mooney@uhc.com\\";
		String jsonString = "{\n" + "\t\"id\": \"60db1bef05d1ba0052bea1ea\",\n" + "\t\"space_id\": 8896,\n"
				+ "\t\"status\": \"AVAILABLE\",\n" + "\t\"metadata\": {\n"
				+ "\t\t\"providerEmailId\": \"lane_k_mooney@uhc.com\",\n"
				+ "\t\t\"original_email_from\": \"paperless_letters@uhc.com\",\n"
				+ "\t\t\"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" + "\t}\n" + "}";
		variables.put("id", "test2");
		variables.put("test2", "test3");
		variables.put("test4", "test5");
		String stringIdentifire = variables.get("id").toString();
		ResponseEntity<GenericResponse> response = fDSServicesController.prePost(stringIdentifire, jsonString);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void postDocumentDocLibForELGSProcessTest() throws Exception {
		ResponseEntity<GenericResponse> response = fDSServicesController.postDocumentDocLibForELGSProcess("");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}


	@Test
	public void testGetGenericResponseThrowsException() {
		Map<String, Object> requestMap = new HashMap<String, Object>();
		Map<String, Object> mapValues = new HashMap<String, Object>();
		mapValues.put("statusCode", 200);
		mapValues.put("statusMessage", "success");
		mapValues.put("responseMsg", "test");
		requestMap.put("response", mapValues);
		GenericResponse response = fDSServicesController.getGenericResponse(requestMap);
		assertEquals("200", response.getStatusCode());
	}

	@org.junit.Test
	public void runDequeueTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		GenericResponse response = fDSServicesController.runDequeue("test");
		assertNotNull(response);
	}

	@org.junit.Test
	public void runDelegateTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = fDSServicesController.runDelegate("");
		assertNotNull(response);
	}

	@org.junit.Test
	public void runCleanUpTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = fDSServicesController.runCleanUp("");
		assertNotNull(response);
	}

	@Test
	public void testGetGenericResponse() {
		Map<String, Object> requestMap = new HashMap<String, Object>();
		Map<String, Object> mapValues = new HashMap<String, Object>();
		mapValues.put("statusCode", "200");
		mapValues.put("statusMessage", "success");
		mapValues.put("responseMsg", "test");
		requestMap.put("response", mapValues);
		GenericResponse response = fDSServicesController.getGenericResponse(requestMap);
		assertEquals("200", response.getStatusCode());
	}

	@Test
	public void testRunEmailProcessorTransactionMetadataWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.runEmailProcessorTransactionMetadata("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}
	
	@Test
	public void testRunProcessTextFileWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.processTextFile("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}
	
	@Test
	public void testRunProcessTextFileWithInvalidJson() {
		String jsonString = "{\n" + "\t\"id\": \"60db1bef05d1ba0052bea1ea\",\n" + "\t\"space_id\": 8896,\n"
				+ "\t\"status\": \"AVAILABLE\",\n" + "\t\"metadata\": {\n"
				+ "\t\t\"providerEmailId\": \"lane_k_mooney@uhc.com\",\n"
				+ "\t\t\"original_email_from\": \"paperless_letters@uhc.com\",\n"
				+ "\t\t\"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" + "\t}\n" + "}";
		ResponseEntity<GenericResponse> response = fDSServicesController.processTextFile(jsonString);
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@SuppressWarnings("static-access")
	@Test
	public void testRunEmailProcessorTransactionMetadataWithStatusCode500() throws JsonProcessingException {
//		when(processEngines.getDefaultProcessEngine()).thenReturn(new ProcessEngineImpl());
//		when(( processEngines).getRuntimeService()).thenReturn(new RuntimeServiceImpl());
//		when(fdsHelper.runProcess(Mockito.anyString(), Mockito.anyMap())).thenReturn((ProcessInstance) new ProcessInstanceImpl());
//		
		ResponseEntity<GenericResponse> response = fDSServicesController
				.runEmailProcessorTransactionMetadata(getHookData());

		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void testProviderEmailNotificationWithStatusCode500() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.providerEmailNotification(getHookData());
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void testProviderEmailNotificationWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.providerEmailNotification("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testRunMatchAndMergenWithStatusCode500() throws JsonProcessingException {
//		HashMap<String,Object> payload = new HashMap<String,Object>();
//		payload.put("id","46g4646gt");
//		when(objectMapper.readValue(Mockito.anyString(), Mockito.any(Class.class))).thenReturn(getHookData());
		ResponseEntity<GenericResponse> response = fDSServicesController.runMatchAndMerge(getHookData());

		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void testRunMatchAndMergeWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.runMatchAndMerge("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void testRunBounceProvEmailWithStatusCode500() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.runBounceProvEmail(getHookData());
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void testRunBounceProvEmailWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.runBounceProvEmail("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void testRunShutterflyWithStatusCode500() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.runShutterfly(getHookData());
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void testRunShutterflyWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.runShutterfly("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void testRunResponseFileWithStatusCode500() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.runResponseFile(getHookData());
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void testRunResponseFileWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.runResponseFile("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void testRunStatusFileWithStatusCode500() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.runStatusFile(getHookData());
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void testRunStatusFileWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.runStatusFile("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void testRunWorkflowWithStatusCode500() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.runWorkflow(getHookData());
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void testRunWorkflowWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.runWorkflow("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void testRetrieveCorporateMPINv2WithStatusCode500() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.retrieveCorporateMPINv2(getHookData());
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void testRetrieveCorporateMPINv2WithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.retrieveCorporateMPINv2("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void testRunCreateMetadataFilesTestWithStatusCode500() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.runCreateMetadataFiles(getFdsJsonData());
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void testRunCreateMetadataFilesTestWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.runCreateMetadataFiles("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void testrunStorageErrorShutterflyTestWithStatusCode500() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.runStorageErrorShutterfly(getFdsJsonData());
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void testRrunStorageErrorShutterflyTestWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.runStorageErrorShutterfly("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void runResponseFileUSPClaimsTestWithStatusCode500() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.runResponseFileUSPClaims(getFdsJsonData());
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void runResponseFileUSPClaimsTestWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.runResponseFileUSPClaims("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void sendBatchDynamicEmailRequestToPENTestWithStatusCode200() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.sendBatchDynamicEmailRequestToPEN(getFdsJsonData());
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@Test
	public void sendBatchDynamicEmailRequestToPENTestWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.sendBatchDynamicEmailRequestToPEN("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}
	@Test
	public void sendBatchDynamicEmailRequestToPENTest() throws Exception {
		String jsonString = "{\n" + "\t\"id\": \"60db1bef05d1ba0052bea1ea\",\n" + "\t\"space_id\": 8896,\n"
				+ "\t\"status\": \"AVAILABLE\",\n" + "\t\"metadata\": {\n"
				+ "\t\t\"providerEmailId\": \"lane_k_mooney@uhc.com\",\n"
				+ "\t\t\"original_email_from\": \"paperless_letters@uhc.com\",\n"
				+ "\t\t\"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" + "\t}\n" + "}";
		var response = fDSServicesController.sendBatchDynamicEmailRequestToPEN(jsonString);
		assertNotNull(response);
		assertNotNull(response.getBody());
		assertEquals("200", response.getBody().getStatusCode());
	}
	@Test
	public void testsendBatchDynamicEmailRequestToPEN() throws JsonMappingException, JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.sendBatchDynamicEmailRequestToPEN(getProcessorData());
	}

	@Test
	public void retrieveAndSendEmailProcessTestWithStatusCode200() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.retrieveAndSendEmailProcess(getFdsJsonData());
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@Test
	public void retrieveAndSendEmailProcessTestWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.retrieveAndSendEmailProcess("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void realTimeAPISendEmailProcessTestWithStatusCode400() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.realTimeAPISendEmailProcess(getFdsJsonData());
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void realTimeAPISendEmailProcessTestWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.realTimeAPISendEmailProcess("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void sftpSendEmailProcessTestWithStatusCode400() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.sftpSendEmailProcess(getFdsJsonData());
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void sftpSendEmailProcessTestWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.sftpSendEmailProcess("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void prePostRealTimeTestWithStatusCode500() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.prePostRealTime(getFdsJsonData());
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void prePostRealTimeTestWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.prePostRealTime("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void prePostTestWithStatusCode500() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.prePost(getFdsJsonData());
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void prePostTestWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.prePost("{\"id\": \"12345\"}");
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void runDelegateTestWithStatusCode400() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.runDelegate(getFdsJsonData());
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void runDelegateTestWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.runDelegate("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void sftpConvertFileToDocumentTestWithStatusCode400() throws JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.sftpConvertFileToDocument(getFdsJsonData());
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void sftpConvertFileToDocumentTestWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.sftpConvertFileToDocument("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}
//	@Test
//	public void testSendRequestToQueue()
//	{
//		ResponseEntity<GenericResponse> response = new ResponseEntity<GenericResponse>( HttpStatus.OK);
//		fDSServicesController.sendRequestToQueue(response);
//	}

	@Test
	public void testRunProcessorWithNull() {
		ResponseEntity<GenericResponse> response = fDSServicesController.runProcessor("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void testRunProcessorWithNonNullJsonString() throws JsonMappingException, JsonProcessingException {
//		FDSHelper.sftpRunProcess(Workflow.SFTP_PROCESS_KEY,
//                jsonProcessConfigStr);

//		when(fdsHelper.sftpRunProcess(Mockito.anyString(), Mockito.anyString())).thenReturn((ProcessInstance) new ProcessInstanceImpl());
		ResponseEntity<GenericResponse> response = fDSServicesController.runProcessor(getProcessorData());
//		assertEquals(HttpStatus.valueOf(400), response.getStatusCode()); 
	}

	@Test
	public void testProcessZipFileWithNull() {
		ResponseEntity<GenericResponse> response = fDSServicesController.processZipFile("");
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void testProcessZipFilehNonNullJsonString() throws JsonMappingException, JsonProcessingException {
		ResponseEntity<GenericResponse> response = fDSServicesController.processZipFile(getProcessorData());
	}

	@Test
	public void runCleanUpTestWithProcessorTransactionIdAndAppIdentifier() throws Exception {
		String jsonStr = getProcessorData();
		HashMap<String, Object> jsonMap = new ObjectMapper().readValue(jsonStr, HashMap.class);
//      Mockito.when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(HashMap.class))).thenReturn(jsonMap);
		ResponseEntity<GenericResponse> response = fDSServicesController.runCleanUp(jsonStr);
		assertNotNull(response.getStatusCode());
	}

	@Test
	public void runCleanUpTestWithException() throws Exception {
		String jsonStr = getHookData();
		HashMap<String, Object> jsonMap = new ObjectMapper().readValue(jsonStr, HashMap.class);
//      Mockito.when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(HashMap.class))).thenReturn(jsonMap);
		ResponseEntity<GenericResponse> response = fDSServicesController.runCleanUp(jsonStr);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@Test
	public void runFileUnzipTestWithException() throws Exception {
		String jsonStr = getHookData();
		HashMap<String, Object> jsonMap = new ObjectMapper().readValue(jsonStr, HashMap.class);
//      Mockito.when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(HashMap.class))).thenReturn(jsonMap);
		ResponseEntity<GenericResponse> response = fDSServicesController.runFileUnzip(jsonStr);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@Test
	public void prePostWithIdTestWithAppIdentifierNotEmpty() throws Exception {
		String id = "testId";
		String jsonConfigStr = getHookData();
		HashMap<String, Object> jsonMap = new ObjectMapper().readValue(jsonConfigStr, HashMap.class);
//      Mockito.when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(HashMap.class))).thenReturn(jsonMap);
		ResponseEntity<GenericResponse> response = fDSServicesController.prePost(id, jsonConfigStr);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void prePostTestWithAppIdentifierNotEmpty() throws Exception {
		String jsonConfigStr = getHookData();
		HashMap<String, Object> jsonMap = new ObjectMapper().readValue(jsonConfigStr, HashMap.class);
//      Mockito.when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(HashMap.class))).thenReturn(jsonMap);
		ResponseEntity<GenericResponse> response = fDSServicesController.prePost(jsonConfigStr);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void prePostRealTimeTestWithAppIdentifierNotEmpty() throws Exception {
		String jsonConfigStr = getHookData();
		HashMap<String, Object> jsonMap = new ObjectMapper().readValue(jsonConfigStr, HashMap.class);
//      Mockito.when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(HashMap.class))).thenReturn(jsonMap);
		ResponseEntity<GenericResponse> response = fDSServicesController.prePostRealTime(jsonConfigStr);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void retrieveAndSendEmailProcessTestWithValidInput() throws Exception {
		String jsonStr = getHookData();
		ResponseEntity<GenericResponse> response = fDSServicesController.retrieveAndSendEmailProcess(jsonStr);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void sendBatchDynamicEmailRequestToPENTestWithValidInput() throws Exception {
		String jsonStr = getHookData();
		ResponseEntity<GenericResponse> response = fDSServicesController.sendBatchDynamicEmailRequestToPEN(jsonStr);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void processZipFileTestWithNullJson() {
		ResponseEntity<GenericResponse> response = fDSServicesController.processZipFile("");
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	public void runDelegateWithInvalidJsonShouldReturnInternalServerError() throws Exception {
		FDSServicesController controller = new FDSServicesController();

		ReflectionTestUtils.setField(controller, "objectMapper", new ObjectMapper());

		String invalidJson = "{\"url\": [\"someUrl\"], \"delegate\": [\"someDelegate\"], \"callbackMap\": [malformed json}";

		ResponseEntity<GenericResponse> response = controller.runDelegate(invalidJson);

		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertEquals("500", response.getBody().getStatusCode());
		assertEquals("INTERNAL_SERVER_ERROR", response.getBody().getStatusMessage());
		assertNotNull(response.getBody().getResponse());
	}

	@Test
	public void testSendRequestToQueue() {
		GenericResponse genericResponse = GenericResponse.from("200", "OK", "Test response");
		ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(genericResponse, HttpStatus.OK);

		ServiceBase mockServiceBase = Mockito.mock(ServiceBase.class);
		ReflectionTestUtils.setField(fDSServicesController, "serviceBase", mockServiceBase);
		ReflectionTestUtils.setField(fDSServicesController, "messageServiceResponseUrl", "http://test-url");

		fDSServicesController.sendRequestToQueue(responseEntity);

		String expectedJson = new Gson().toJson(genericResponse);
		Mockito.verify(mockServiceBase).postRequestToSvc("http://test-url", expectedJson, null);
	}

    @Test
    public void testConvertMetadataProcess() throws IOException, IOException {
        // Prepare config map
        Map<String, Object> config = new HashMap<>();
        config.put(Workflow.SEARCH_CRITERIA, "criteria");
        config.put(Workflow.SEARCH_WINDOW, "window");
        config.put(Workflow.CLIENT_NAME, "client");
        config.put(Workflow.MAX_DOCUMENTS_OCCURS, 5);
        Map<String, Object> action = new HashMap<>();
        action.put("config", config);
        Map<String, Object> hook = new HashMap<>();
        hook.put("action", action);
        Map<String, Object> variables = new HashMap<>();
        variables.put("hook", hook);
        variables.put("id", "testId");

        String jsonString = new ObjectMapper().writeValueAsString(variables);

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class, Mockito.CALLS_REAL_METHODS)) {
            mocked.when(() -> FDSHelper.runProcess(eq(ProcessKeys.PROCESS_CONVERT_METADATA), Mockito.any(Document.class)))
                    .thenReturn(null);

            ResponseEntity<GenericResponse> response = fDSServicesController.processConvertMetadata(jsonString);

            mocked.verify(() -> FDSHelper.convertMetadataProcess(
                Mockito.argThat(doc -> doc != null)
                )
        );

            assertEquals(HttpStatus.OK, response.getStatusCode());
        }
    }


	@Test
	public void testSanitiseStringWithValidJsonObject() {
		String jsonInput = "{\"key\":\"value\",\"number\":123}";

		String result = (String) ReflectionTestUtils.invokeMethod(
				fDSServicesController,
				"sanitiseString",
				jsonInput
		);

		assertNotNull(result);
		assertTrue(result.contains("\"key\""));
		assertTrue(result.contains("\"value\""));
		assertTrue(result.contains("\"number\""));
		assertTrue(result.contains("123"));
	}

	@Test
	public void testSanitiseStringWithJsonArray() {
		String jsonInput = "[{\"key\":\"value1\"},{\"key\":\"value2\"}]";

		String result = (String) ReflectionTestUtils.invokeMethod(
				fDSServicesController,
				"sanitiseString",
				jsonInput
		);

		assertNotNull(result);
		assertTrue(result.startsWith("["));
		assertTrue(result.endsWith("]"));
		assertTrue(result.contains("\"value1\""));
		assertTrue(result.contains("\"value2\""));
	}

	@Test
	public void testSanitiseStringWithComplexJson() {
		String jsonInput = "{\"data\":{\"nested\":[1,2,3],\"bool\":true},\"message\":\"success\"}";

		String result = (String) ReflectionTestUtils.invokeMethod(
				fDSServicesController,
				"sanitiseString",
				jsonInput
		);

		assertNotNull(result);
		assertTrue(result.contains("\"nested\""));
		assertTrue(result.contains("[1,2,3]"));
		assertTrue(result.contains("\"bool\":true"));
		assertTrue(result.contains("\"message\":\"success\""));
	}

	@Test
	public void testSanitiseStringWithInvalidJson() {
		String jsonInput = "{malformed json}";

		try {
			ReflectionTestUtils.invokeMethod(
					fDSServicesController,
					"sanitiseString",
					jsonInput
			);

			Assert.fail("Expected an exception for malformed JSON but none was thrown");
		} catch (Exception e) {
			assertNotNull(e);
		}
	}

	@Test
	public void testRunResponseMessageProcess_EmptyInput() {
		String jsonStr = "";

		ResponseEntity<GenericResponse> response = fDSServicesController.runResponseMessageProcess(jsonStr);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertEquals("400", response.getBody().getStatusCode());
		assertEquals("Invalid request", response.getBody().getStatusMessage());
		assertEquals("Null or empty request body", response.getBody().getResponse());
	}

	@Test
	public void testRunResponseMessageProcess_NullInput() {
		String jsonStr = null;

		ResponseEntity<GenericResponse> response = fDSServicesController.runResponseMessageProcess(jsonStr);

		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertEquals("400", response.getBody().getStatusCode());
		assertEquals("Invalid request", response.getBody().getStatusMessage());
		assertEquals("Null or empty request body", response.getBody().getResponse());
	}

	@Test
	public void testRunResponseMessageProcess_ValidInput() throws Exception {
		String jsonStr = getHookData();

		ObjectMapper realObjectMapper = new ObjectMapper();
		Map<String, Object> parsedMap = realObjectMapper.readValue(jsonStr, new TypeReference<>() {});

		ObjectMapper mockObjectMapper = Mockito.mock(ObjectMapper.class);
		Mockito.when(mockObjectMapper.readValue(Mockito.anyString(), Mockito.any(TypeReference.class)))
				.thenReturn(parsedMap);
		ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockObjectMapper);

		// Mock the static FDSHelper method using doNothing() since it's a void method
		try (MockedStatic<FDSHelper> mockedFDSHelper = Mockito.mockStatic(FDSHelper.class)) {
			// For void methods, use doNothing approach
			mockedFDSHelper.when(() -> FDSHelper.responseMessageProcess(Mockito.anyMap()))
					.thenAnswer(invocation -> null); // This is the MockedStatic way for void methods

			ResponseEntity<GenericResponse> response = fDSServicesController.runResponseMessageProcess(jsonStr);

			assertEquals(HttpStatus.OK, response.getStatusCode());
			assertEquals("200", response.getBody().getStatusCode());
			assertEquals(HttpStatus.OK.getReasonPhrase(), response.getBody().getStatusMessage());
			assertEquals(HttpStatus.OK.getReasonPhrase(), response.getBody().getResponse());
		}
	}

	@Test
	public void testRunResponseMessageProcess_JsonProcessingException() throws Exception {
		String jsonStr = "{invalid json}";

		JsonProcessingException jsonException = new JsonProcessingException("Invalid JSON") {};

		ObjectMapper mockObjectMapper = Mockito.mock(ObjectMapper.class);
		Mockito.when(mockObjectMapper.readValue(Mockito.anyString(), Mockito.any(TypeReference.class)))
				.thenThrow(jsonException);
		ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockObjectMapper);

		ResponseEntity<GenericResponse> response = fDSServicesController.runResponseMessageProcess(jsonStr);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertEquals("500", response.getBody().getStatusCode());
		assertEquals("INTERNAL_SERVER_ERROR", response.getBody().getStatusMessage());
		assertTrue(response.getBody().getResponse().toString().contains("Invalid JSON"));
	}

	@Test
	public void testRunResponseMessageProcess_RuntimeException() throws Exception {
		String jsonStr = "{\"key\":\"value\"}";

		ObjectMapper mockObjectMapper = Mockito.mock(ObjectMapper.class);
		Mockito.when(mockObjectMapper.readValue(Mockito.anyString(), Mockito.any(TypeReference.class)))
				.thenThrow(new RuntimeException("General error"));
		ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockObjectMapper);

		ResponseEntity<GenericResponse> response = fDSServicesController.runResponseMessageProcess(jsonStr);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertEquals("500", response.getBody().getStatusCode());
		assertEquals("INTERNAL_SERVER_ERROR", response.getBody().getStatusMessage());
		assertEquals("General error", response.getBody().getResponse());
	}

	@Test
	public void testAppendDefaultValues_ZeroSpaceId() {
		// Setup
		DocumentMetaData documentMetaData = new DocumentMetaData();
		documentMetaData.setSpaceId(0);

		try {
			ReflectionTestUtils.invokeMethod(fDSServicesController, "appendDefaultValues", documentMetaData);
			Assert.fail("Expected a NullPointerException but no exception was thrown");
		} catch (NullPointerException e) {
			assertEquals("spaceId cannot be null", e.getMessage());
		}
	}

	public String getFdsJsonData() throws JsonProcessingException {
		HashMap<String, Object> payload = new HashMap<String, Object>();
		payload.put("id", "46g4646gt");
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(payload);

	}
	public String getHookData() {
		String json = "{\n" + "    \"id\" : \"60dd34dd0f9a1400508bbf5c\",\n" + "    \"hook\" : {\n"
				+ "        \"name\" : \"hookDocvaultRestApi_post_10059\",\n" + "        \"executionOrder\" : \"0\",\n"
				+ "        \"eval_time\" : \"POST_PROCESS\",\n" + "        \"hook_type\" : \"standard\",\n"
				+ "        \"hook_object\" : \"objectOne\",\n" + "        \"action\" : {\n"
				+ "            \"type\" : \"workflow\",\n" + "            \"config\" : {\n"
				+ "                \"search_criteria\" : \"{\\\"status\\\" : \\\"AVAILABLE\\\", \\\"spaceId\\\" : 10059, \\\"metadata.sendToDocVault\\\":true, \\\"metadata.prepostEnded\\\": {$exists: true}, \\\"metadata.docLibAPIResponse\\\": {$exists: false}}\",\n"
				+ "                \"search_window\" : \"{\\\"start_date_offset\\\":{\\\"time_window\\\":\\\"6\\\",\\\"format\\\":\\\"Hours\\\"},\\\"end_date_offset\\\":{\\\"time_window\\\":\\\"0\\\",\\\"format\\\":\\\"Hours\\\"}}\",\n"
				+ "                \"process_key\" : \"postDocumentDocvaultForElgsProcess\",\n"
				+ "                \"clientId\" : \"federated-data\",\n"
				+ "                \"clientSecret\" : \"6ea70261-fe0c-4a08-b176-e11347d3f0ce\",\n"
				+ "                \"docvaultOauthUrl\" : \"https://api-gateway.linkhealth.com/oauth/token\",\n"
				+ "                \"uri\" : \"https://api-gateway.linkhealth.com/docvault-api-stage/v1/document\",\n"
				+ "                \"docLibOauthUrl\" : \"https://gateway-stage.optum.com/auth/oauth2/token\",\n"
				+ "                \"docLibClientId\" : \"neUlmovjH6xAE9GJtOiWvPLklS2b9Sqx\",\n"
				+ "                \"docLibClientSecret\" : \"Hqa1EukT2I2ZTdIL1agjrslau5cS7hw7\",\n"
				+ "                \"docLibRestUrl\" : \"https://gateway-stage.optum.com/api/stage/pdr/uhcpdoclib/v2/metadata\",\n"
				+ "                \"template_id\" : \"5ea5195f934e6ee9694a511f\",\n"
				+ "                \"PENAPIUrl\" : \"http://fds-paperless-pen-api-fds-pen-stage.origin-ctc-core.optum.com/Pen/emailRecord\",\n"
				+ "                \"appId\" : \"jg00aijptyt6rokvkumdnnjhaa6ywxj4\",\n"
				+ "                \"appSecret\" : \"vnwzz7wazvfdjr3aaddxfcfbk59y82hq\",\n"
				+ "                \"pen_template_id\" : \"5e95abe91abb65a70f5a3d0c\",\n"
				+ "                \"template_name\" : \"filterReqFieldForDocvault\",\n"
				+ "                \"maxRetries\" : 2,\n" + "                \"primary\" : \"docLib\",\n"
				+ "                \"retrySleepTime\" : 500,\n" + "                \"turnPEN\" : false,\n"
				+ "                \"maxDocumentsOccurs\" : 100,\n"
				+ "                \"fdsDocumentsUrl\" : \"https://fs2-stagedmz-ose3.optum.com/v2/documents\"\n"
				+ "            }\n" + "        },\n" + "        \"trigger\" : {\n"
				+ "            \"criteria\" : \"metadata.sendToDocVault==true && metadata.sendPENAPIRequest==false && metadata.sendEmailNotifications==false && metadata.stopProcessing!=true\",\n"
				+ "            \"on_event\" : {\n" + "                \"method\" : \"post\",\n"
				+ "                \"target\" : \"documents\"\n" + "            },\n"
				+ "            \"days_offset\" : 0\n" + "        }\n" + "    },\n"
				+ "    \"hookRecordType\" : \"hook\",\n" + "    \"method\" : \"post\",\n" + "    \"spaceId\" : 10059,\n"
				+ "    \"target\" : \"documents\",\n" + "    \"executionOrder\" : 0,\n" + "    \"locked\" : false,\n"
				+ "    \"appIdentifier\" : \"jg00aijptyt6rokvkumdnnjhaa6ywxj4\",\n" + "    \"clientId\" : 685,\n"
				+ "    \"dateCreated\" : \"2021-07-01T03:22:05.820Z\",\n"
				+ "    \"dateModified\" : \"2021-07-01T03:22:05.820Z\",\n"
				+ "    \"name\" : \"hookDocvaultRestApi_post_10059\",\n" + "    \"status\" : \"AVAILABLE\",\n"
				+ "    \"transactionId\" : \"bc2c1175-b2f6-4b0d-8f8d-03066b84e267\",\n"
				+ "    \"_class\" : \"com.optum.fs.mongo.HookMetaData\"\n" + "}";

		return json;
	}

	public String getJsonData() {
		String json = "{\n" + "    \"id\" : ObjectId(\"61e9a0fe7ee7323ee4199f86\"),\n"
				+ "    \"documentAttachments\" : [ \n" + "        {\n"
				+ "            \"attachmentId\" : \"920861c9-673f-41af-b836-429a2e6f8528\",\n"
				+ "            \"index\" : 0,\n" + "            \"fileName\" : \"1412142121_1412143823.pdf\",\n"
				+ "            \"fileSize\" : NumberLong(150867),\n"
				+ "            \"contentType\" : \"application/pdf\",\n"
				+ "            \"createdOn\" : ISODate(\"2022-01-20T17:50:55.040Z\"),\n"
				+ "            \"modifiedOn\" : ISODate(\"2022-01-20T17:50:55.040Z\"),\n"
				+ "            \"virusScanStatus\" : \"SKIPPED\",\n"
				+ "            \"cloudStorageProvider\" : \"AWS\",\n"
				+ "            \"spaceId\" : \"098e6a28-80aa-4151-b2cb-f8d21f56033e\",\n"
				+ "            \"url\" : \"https://fds-document-bucket-stage-630019648646-70.s3.amazonaws.com/3f45/098e6a28-80aa-4151-b2cb-f8d21f56033e/0df1b9b4-8e1f-479f-8e6c-09c65df2d1ff/920861c9-673f-41af-b836-429a2e6f8528/1412142121_1412143823.pdf?response-content-disposition=attachment%3B%20filename%3D1412142121_1412143823.pdf&X-Amz-Security-Token=FwoGZXIvYXdzEAIaDNRWXPJ4bWckDWnguSKPBKXK6pam%2BvXRTAS4RjONU6hx6lSKKvjkdS6f6VIgTIHeelSf91yGfmJQV6DHNQ5Govye2TB%2BKTDmhvuWB%2BzjgJOYqzcys%2BtPzRACmFU%2Bplbep6jJ4aIonRbVEIJJXO6q2fwsqizdyBY8C%2FiwlYSYRJn1PgBPZzEiqAVR2Ibnj35QTEz1OA4hPGtNvKRGs6KEHtJ15gCLslwYlBRp3EZ3fObOnXbQCnv0xQBr7jYr11CQQ59jOi3Cb0EfCkumzgvUBbrE9bob4n0DTgKQOX%2B8FtGESuL4MWPvFvBM%2FUPNh6GR9lvSn9BVS%2FBdBQGp2dGC6X%2FxlisYaACat9Y0QBCdf1VyxQ5euiYYKPYGM9AK%2Bz6j8KEdlJpdzL%2FDTQn0uFKZ6Qj63ylGI32NSBsFmYldeC%2B2qgP36F5sU7H0ov%2Bp79EKQnKGbKMcPorTowWHSQAFnOWpDSp2iEGqhNslfEZBeS0j4Onya%2BAhT3fbg45hrYhnFB7%2B3ofKyN5kcyyQLOX1Ol%2B1EpTTGOhlfivvGwrXPtDNZ05udTj2rr9CyslOj0PCM5sLoFYgO7FOaAAiPWx0AYsdZLycQsuMURuBDfk8KSV8iBMVoXcPm68BMZFra%2BOrNbkRLZasV75Phiuu8YBFfKhlScsTN2Ki1QtqYLze8tZni5A%2BXsm3aWA7lRMjNdnRhnjZj2PBhQ%2F7pG898eE4KPGrpo8GMirnGzph1ekZ807aljYb%2FWfBCB183Q24d8XzsxlaqxO8GYiWA5urtGYsLTg%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20220120T175055Z&X-Amz-SignedHeaders=host&X-Amz-Expires=600&X-Amz-Credential=ASIAZFMAY5SDCESKW6Y7%2F20220120%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=cb1b17633704f87220b539beadce2334ae34d371a1ea0a546cfe916df8912ced\",\n"
				+ "            \"sentToDocVault\" : false\n" + "        }\n" + "    ],\n" + "    \"metadata\" : {\n"
				+ "        \"subCategory\" : \"A4\",\n" + "        \"fileName\" : \"1412142121_1412143823.pdf\",\n"
				+ "        \"originalPrintTrail\" : \"3612\",\n" + "        \"postCardInd\" : true,\n"
				+ "        \"tagLine\" : \"20220126160615091775204\",\n" + "        \"policyNumber\" : \"0915276\",\n"
				+ "        \"corporateMpin\" : \"002056499\",\n"
				+ "        \"processorFileTaskId\" : \"61e99ffd7ee7323ee4198bf6\",\n"
				+ "        \"tin\" : \"020695721\",\n" + "        \"CONFIGKEY\" : \"FDSELR3612\",\n"
				+ "        \"DMSecurityClass\" : \"CCS_COMPLIANCE\",\n"
				+ "        \"notificationNumber\" : \"A143843033\",\n"
				+ "        \"providerName\" : \"ORTHOFIX US \",\n" + "        \"tenant\" : \"Link\",\n"
				+ "        \"memberId\" : \"922172031\",\n" + "        \"DefaultUsed\" : \"N\",\n"
				+ "        \"MailToAddress1\" : \"ORTHOFIX US \",\n"
				+ "        \"docLibUploadDate\" : \"2022-01-20T18:12:19.965Z\",\n" + "        \"HHKey\" : \"\",\n"
				+ "        \"DUPLEXSIMPLEX\" : \"D\",\n" + "        \"sendEmailNotifications\" : true,\n"
				+ "        \"docLibAPIResponse\" : true,\n"
				+ "        \"dateEmailSent\" : \"2022-01-20T18:15:00.000Z\",\n" + "        \"rprntSentToSF\" : true,\n"
				+ "        \"LetterHistoryID\" : \"1412143823\",\n"
				+ "        \"PassThruData\" : \"1412142121_1412143823\",\n"
				+ "        \"MailToAddress6\" : \"75056\",\n" + "        \"mpin\" : \"002056402\",\n"
				+ "        \"dateOfService\" : \"2021-12-22T00:00:00.000Z\",\n"
				+ "        \"MailToAddress4\" : \"LEWISVILLE\",\n" + "        \"MailToAddress5\" : \"TX\",\n"
				+ "        \"MailToAddress2\" : \"3451 PLANO PKWY\",\n" + "        \"MailToAddress3\" : \"\",\n"
				+ "        \"emailAlertReq\" : \"Y\",\n" + "        \"docSentTo\" : \"DocLib\",\n"
				+ "        \"ELGSLETTERGENID\" : \"1412143823\",\n" + "        \"memberName\" : \"WILSON, DENNIS P\",\n"
				+ "        \"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\n"
				+ "        \"prepostEnded\" : true,\n" + "        \"expiryDate\" : \"2024-01-20T17:50:54.301Z\",\n"
				+ "        \"absolutePath\" : \"/ingest/jg00aijptyt6rokvkumdnnjhaa6ywxj4/10059/2022012616060690072936812-ba2c-4137-a8a3-2e38e6b0f2b9/61e99fce7ee7323ee4198ab9/61e9a0fe7ee7323ee4199f86/new/\",\n"
				+ "        \"sendToDocVault\" : true,\n" + "        \"filePath\" : \"Medicare Prior Auth/Approved\",\n"
				+ "        \"ELGSREQUESTID\" : \"1412142121\",\n"
				+ "        \"providerEmailId\" : \"saravanan.nedunchezhiyan@optum.com\",\n"
				+ "        \"sendPENAPIRequest\" : true,\n"
				+ "        \"eDeliveryError\" : \"Missing or invalid data: email bounced\",\n"
				+ "        \"createdDate\" : \"2022-01-05T01:29:12.000Z\",\n"
				+ "        \"createApplication\" : \"CCSManual\",\n" + "        \"prepostStarted\" : true,\n"
				+ "        \"category\" : \"Prior Auth Notification\",\n" + "        \"fileType\" : \"Letter\",\n"
				+ "        \"sendToShutterfly\" : true,\n" + "        \"addedToResponseFile\" : true\n" + "    },\n"
				+ "    \"spaceId\" : 10059,\n" + "    \"fsId\" : \"920861c9-673f-41af-b836-429a2e6f8528\",\n"
				+ "    \"fdsAttachmentId\" : \"920861c9-673f-41af-b836-429a2e6f8528\",\n"
				+ "    \"fdsDocumentId\" : \"0df1b9b4-8e1f-479f-8e6c-09c65df2d1ff\",\n" + "    \"revisions\" : [ \n"
				+ "        {\n" + "            \"spaceId\" : 10059,\n" + "            \"metadata\" : {\n"
				+ "                \"subCategory\" : \"A4\",\n"
				+ "                \"fileName\" : \"1412142121_1412143823.pdf\",\n"
				+ "                \"originalPrintTrail\" : \"3612\",\n" + "                \"postCardInd\" : true,\n"
				+ "                \"tagLine\" : \"20220120210233509711422\",\n"
				+ "                \"policyNumber\" : \"0915276\",\n"
				+ "                \"corporateMpin\" : \"002056499\",\n"
				+ "                \"processorFileTaskId\" : \"61e99ffd7ee7323ee4198bf6\",\n"
				+ "                \"tin\" : \"020695721\",\n" + "                \"CONFIGKEY\" : \"FDSELR3612\",\n"
				+ "                \"DMSecurityClass\" : \"CCS_COMPLIANCE\",\n"
				+ "                \"notificationNumber\" : \"A143843033\",\n"
				+ "                \"providerName\" : \"ORTHOFIX US \",\n" + "                \"tenant\" : \"Link\",\n"
				+ "                \"memberId\" : \"922172031\",\n" + "                \"DefaultUsed\" : \"N\",\n"
				+ "                \"MailToAddress1\" : \"ORTHOFIX US \",\n"
				+ "                \"docLibUploadDate\" : \"2022-01-20T18:12:19.965Z\",\n"
				+ "                \"HHKey\" : \"\",\n" + "                \"DUPLEXSIMPLEX\" : \"D\",\n"
				+ "                \"sendEmailNotifications\" : true,\n"
				+ "                \"docLibAPIResponse\" : true,\n"
				+ "                \"dateEmailSent\" : \"2022-01-20 18:26:45.295Z\",\n"
				+ "                \"rprntSentToSF\" : true,\n"
				+ "                \"LetterHistoryID\" : \"1412143823\",\n"
				+ "                \"PassThruData\" : \"1412142121_1412143823\",\n"
				+ "                \"MailToAddress6\" : \"75056\",\n" + "                \"mpin\" : \"002056402\",\n"
				+ "                \"dateOfService\" : \"2021-12-22T00:00:00.000Z\",\n"
				+ "                \"MailToAddress4\" : \"LEWISVILLE\",\n"
				+ "                \"MailToAddress5\" : \"TX\",\n"
				+ "                \"MailToAddress2\" : \"3451 PLANO PKWY\",\n"
				+ "                \"MailToAddress3\" : \"\",\n" + "                \"emailAlertReq\" : \"Y\",\n"
				+ "                \"docSentTo\" : \"DocLib\",\n"
				+ "                \"ELGSLETTERGENID\" : \"1412143823\",\n"
				+ "                \"memberName\" : \"WILSON, DENNIS P\",\n"
				+ "                \"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\n"
				+ "                \"prepostEnded\" : true,\n"
				+ "                \"expiryDate\" : \"2024-01-20T17:50:54.301Z\",\n"
				+ "                \"absolutePath\" : \"/ingest/jg00aijptyt6rokvkumdnnjhaa6ywxj4/10059/2022012021022293989984501-83e0-44b2-8356-106d17135750/61e99fce7ee7323ee4198ab9/61e9a0fe7ee7323ee4199f86/new/\",\n"
				+ "                \"sendToDocVault\" : true,\n"
				+ "                \"filePath\" : \"Medicare Prior Auth/Approved\",\n"
				+ "                \"ELGSREQUESTID\" : \"1412142121\",\n"
				+ "                \"providerEmailId\" : \"saravanan.nedunchezhiyan@optum.com\",\n"
				+ "                \"sendPENAPIRequest\" : true,\n"
				+ "                \"eDeliveryError\" : \"Missing or invalid data: email bounced\",\n"
				+ "                \"createdDate\" : \"2022-01-05T01:29:12.000Z\",\n"
				+ "                \"createApplication\" : \"CCSManual\",\n"
				+ "                \"prepostStarted\" : true,\n"
				+ "                \"category\" : \"Prior Auth Notification\",\n"
				+ "                \"fileType\" : \"Letter\",\n" + "                \"sendToShutterfly\" : true\n"
				+ "            },\n" + "            \"clientId\" : 685,\n"
				+ "            \"dateCreated\" : NumberLong(1642701054302),\n" + "            \"attachments\" : [ \n"
				+ "                {\n" + "                    \"cloudStorageProvider\" : \"AWS\",\n"
				+ "                    \"spaceId\" : \"098e6a28-80aa-4151-b2cb-f8d21f56033e\",\n"
				+ "                    \"modifiedOn\" : NumberLong(1642701055040),\n"
				+ "                    \"fileName\" : \"1412142121_1412143823.pdf\",\n"
				+ "                    \"virusScanStatus\" : \"SKIPPED\",\n"
				+ "                    \"fileSize\" : 150867,\n" + "                    \"sentToDocVault\" : false,\n"
				+ "                    \"name\" : \"1412142121_1412143823.pdf\",\n"
				+ "                    \"attachmentId\" : \"920861c9-673f-41af-b836-429a2e6f8528\",\n"
				+ "                    \"createdOn\" : NumberLong(1642701055040),\n"
				+ "                    \"contentType\" : \"application/pdf\",\n"
				+ "                    \"url\" : \"https://fds-document-bucket-stage-630019648646-70.s3.amazonaws.com/3f45/098e6a28-80aa-4151-b2cb-f8d21f56033e/0df1b9b4-8e1f-479f-8e6c-09c65df2d1ff/920861c9-673f-41af-b836-429a2e6f8528/1412142121_1412143823.pdf?response-content-disposition=attachment%3B%20filename%3D1412142121_1412143823.pdf&X-Amz-Security-Token=FwoGZXIvYXdzEAIaDNRWXPJ4bWckDWnguSKPBKXK6pam%2BvXRTAS4RjONU6hx6lSKKvjkdS6f6VIgTIHeelSf91yGfmJQV6DHNQ5Govye2TB%2BKTDmhvuWB%2BzjgJOYqzcys%2BtPzRACmFU%2Bplbep6jJ4aIonRbVEIJJXO6q2fwsqizdyBY8C%2FiwlYSYRJn1PgBPZzEiqAVR2Ibnj35QTEz1OA4hPGtNvKRGs6KEHtJ15gCLslwYlBRp3EZ3fObOnXbQCnv0xQBr7jYr11CQQ59jOi3Cb0EfCkumzgvUBbrE9bob4n0DTgKQOX%2B8FtGESuL4MWPvFvBM%2FUPNh6GR9lvSn9BVS%2FBdBQGp2dGC6X%2FxlisYaACat9Y0QBCdf1VyxQ5euiYYKPYGM9AK%2Bz6j8KEdlJpdzL%2FDTQn0uFKZ6Qj63ylGI32NSBsFmYldeC%2B2qgP36F5sU7H0ov%2Bp79EKQnKGbKMcPorTowWHSQAFnOWpDSp2iEGqhNslfEZBeS0j4Onya%2BAhT3fbg45hrYhnFB7%2B3ofKyN5kcyyQLOX1Ol%2B1EpTTGOhlfivvGwrXPtDNZ05udTj2rr9CyslOj0PCM5sLoFYgO7FOaAAiPWx0AYsdZLycQsuMURuBDfk8KSV8iBMVoXcPm68BMZFra%2BOrNbkRLZasV75Phiuu8YBFfKhlScsTN2Ki1QtqYLze8tZni5A%2BXsm3aWA7lRMjNdnRhnjZj2PBhQ%2F7pG898eE4KPGrpo8GMirnGzph1ekZ807aljYb%2FWfBCB183Q24d8XzsxlaqxO8GYiWA5urtGYsLTg%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20220120T175055Z&X-Amz-SignedHeaders=host&X-Amz-Expires=600&X-Amz-Credential=ASIAZFMAY5SDCESKW6Y7%2F20220120%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=cb1b17633704f87220b539beadce2334ae34d371a1ea0a546cfe916df8912ced\"\n"
				+ "                }\n" + "            ],\n"
				+ "            \"dateModified\" : NumberLong(1642701054302),\n"
				+ "            \"appIdentifier\" : \"jg00aijptyt6rokvkumdnnjhaa6ywxj4\"\n" + "        }\n" + "    ],\n"
				+ "    \"appIdentifier\" : \"jg00aijptyt6rokvkumdnnjhaa6ywxj4\",\n" + "    \"clientId\" : 685,\n"
				+ "    \"dateCreated\" : ISODate(\"2022-01-20T17:50:54.302Z\"),\n"
				+ "    \"dateModified\" : ISODate(\"2022-01-21T02:38:05.454Z\"),\n"
				+ "    \"status\" : \"AVAILABLE\",\n" + "    \"version\" : \"1\",\n"
				+ "    \"_class\" : \"com.optum.fds.paperless.mongo.DocumentMetaData\"\n" + "}";
		return json;
	}

	public String getProcessorData() {
		String json = "{\n" + "    \"id\" : \"61e88d7f67c5e50f62681af3\",\n"
				+ "    \"cleanupWorkflow\" : \"cleanupFilesCreateACKProcess\",\n"
				+ "    \"endDate\" : \"2025-02-01T12:00:00.000Z\",\n" + "    \"locked\" : false,\n"
				+ "    \"resolveIncompleteProcessorTransactionLocked\" : false,\n" + "    \"process\" : {\n"
				+ "        \"process_key\" : \"sftpUnzipProcess\",\n" + "        \"config\" : {\n"
				+ "            \"space_id\" : \"10056\",\n"
				+ "            \"host_name_source\" : \"ecgpe.healthtechnologygroup.com\",\n"
				+ "            \"host_name_destination\" : \"ecgpe.healthtechnologygroup.com\",\n"
				+ "            \"ftp_rootdir\" : \"/batch/priorauth_1click_bravo\",\n"
				+ "            \"ftp_ackdir\" : \"/batch/priorauth_1click_bravo_archive\",\n"
				+ "            \"ftp_archivedir\" : \"/batch/priorauth_1click_bravo_archive\",\n"
				+ "            \"username_destination\" : \"is00amf\",\n"
				+ "            \"username_source\" : \"is00amf\",\n" + "            \"pw_source\" : \"YW03eGag\",\n"
				+ "            \"pw_destination\" : \"YW03eGag\",\n" + "            \"interval\" : \"1\",\n"
				+ "            \"cleanup_interval\" : \"2\",\n"
				+ "            \"templateId\" : \"5b439f193082be0e318a06d1\",\n"
				+ "            \"templateRecordType\" : \"PriorAuth1Click\",\n"
				+ "            \"clientName\" : \"PriorAuth1Click\",\n"
				+ "            \"requiredFieldProcessing\" : true,\n"
				+ "            \"generateSingleAckSummaryFile\" : false,\n"
				+ "            \"resolveIncompleteProcessorTransactionInterval\" : 120,\n"
				+ "            \"ackWithErrorsOnlyFile\" : false,\n"
				+ "            \"addProcessorTransactionMetadata\" : false,\n"
				+ "            \"zipFilePattern\" : \"(DMS_ICUE_[0-9]+_PRD)(_[A-Za-z0-9]+)?(.zip)\"\n" + "        }\n"
				+ "    },\n" + "    \"startDate\" : \"2017-02-01T12:00:00.000Z\",\n" + "    \"retryCount\" : 0,\n"
				+ "    \"priority\" : 50,\n" + "    \"configSpaceId\" : 10056,\n"
				+ "    \"processorRecordType\" : \"processor\",\n"
				+ "    \"appIdentifier\" : \"9f9mdrpsnx0zs50ds5f98m95bpvbgwuz\",\n" + "    \"clientId\" : 685,\n"
				+ "    \"dateCreated\" : \"2020-06-23T21:39:02.664Z\",\n"
				+ "    \"dateModified\" : \"2022-02-01T22:11:42.604Z\",\n"
				+ "    \"name\" : \"ceZtU2FIbp7PrNl62H7cozK87IL6G3VI\",\n" + "    \"status\" : \"SHUTDOWN\",\n"
				+ "    \"transactionId\" : \"75ae9c8b-f83b-4047-b793-c225ad298c0c\",\n" + "    \"version\" : \"1\",\n"
				+ "    \"_class\" : \"com.optum.fs.mongo.processors.ProcessorMetaData\",\n"
				+ "    \"lastRun\" : \"2022-02-01T22:11:42.604Z\"\n" + "}";
		return json;
	}

    @Test
    public void shouldCallRetrieveProviderEmailAddress_whenNotSkipRetrieveEmail() throws Exception {
        String requestMap = "{\"id\": \"61e884d2f3a898ae2b35e5ba\", \"appIdentifier\": \"7cfaef08bf644ad486f244083060c6e7\"}";

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            mocked.when(() -> FDSHelper.retrieveProviderEmailAddress(anyMap()))
                    .thenAnswer(invocation -> null);

            ReflectionTestUtils.invokeMethod(
                    fDSServicesController,
                    "prePost", // replace with actual method name
                    requestMap                         // replace with actual args
            );
            mocked.verify(() -> FDSHelper.retrieveProviderEmailAddress(Mockito.anyMap()), Mockito.times(1));
        }
    }

    @Test
    public void shouldNotCallRetrieveProviderEmailAddress_whenSkipRetrieveEmail() throws Exception {
        String requestMap = "{\"id\": \"61e884d2f3a898ae2b35e5ba\", \"appIdentifier\": \"7cfaef08bf644ad486f244083060c6e7\", \"skipRetrieveEmail\": true}";

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            mocked.when(() -> FDSHelper.retrieveProviderEmailAddress(anyMap()))
                    .thenAnswer(invocation -> null);

            ReflectionTestUtils.invokeMethod(
                    fDSServicesController,
                    "prePost", // replace with actual method name
                    requestMap                         // replace with actual args
            );
            mocked.verify(() -> FDSHelper.retrieveProviderEmailAddress(Mockito.anyMap()), Mockito.never());
        }
    }

    @Test
    public void testTestEndpoint_ShouldDownloadFileAndReturnMessage() {
        // Arrange
        Map<String, Object> request = new HashMap<>();
        request.put("fileName", "sample.pdf");
        request.put("filePath", "/tmp/files");

        byte[] mockBytes = "data".getBytes();
        Mockito.when(fileStoreService.downloadFile("/tmp/files", "sample.pdf")).thenReturn(mockBytes);

        // Act
        String response = fDSServicesController.test(request);

        // Assert
        assertNotNull(response);
        assertEquals("Hello file is downloading", response);
        Mockito.verify(fileStoreService, Mockito.times(1))
                .downloadFile("/tmp/files", "sample.pdf");
    }

    @Test
    public void invokeWorkflow_nullCallbackOrMap_returnsBadRequest() {
        ResponseEntity<GenericResponse> response = fDSServicesController.invokeWorkflow(
                "{}", null, null, new HashMap<String, Object>());

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("400", response.getBody().getStatusCode());
    }

    @Test
    public void invokeWorkflow_success_withSvcMsgId_sendsToQueue_andReturns200() {
        ServiceBase mockServiceBase = Mockito.mock(ServiceBase.class);
        ReflectionTestUtils.setField(fDSServicesController, "serviceBase", mockServiceBase);
        ReflectionTestUtils.setField(fDSServicesController, "messageServiceResponseUrl", "http://test-url");
        FDSServicesController spyController = Mockito.spy(fDSServicesController);

        Map<String, Object> requestMap = buildRequestMapWithResponse("SVC_MSG:12345");
        Map<String, Object> delegateParams = new HashMap<String, Object>();
        delegateParams.put("k", "v");

        try (MockedStatic<FDSHelper> fdsHelperMock = Mockito.mockStatic(FDSHelper.class)) {
            fdsHelperMock.when(() -> FDSHelper.runProcess(eq("delegateA"), eq(delegateParams), any(GenericResponse.class)))
                    .thenAnswer(inv -> null);

            ResponseEntity<GenericResponse> response = spyController.invokeWorkflow(
                    "json", "delegateA", delegateParams, requestMap);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());
            assertEquals("12345", response.getBody().getResponse());

            // queue should be called because id != NONE
            Mockito.verify(spyController, Mockito.times(1))
                    .sendRequestToQueue(any(ResponseEntity.class));
        }
    }

    @Test
    public void invokeWorkflow_success_withoutSvcMsgPrefix_doesNotSendQueue_andReturnsNone() {
        FDSServicesController spyController = Mockito.spy(fDSServicesController);

        Map<String, Object> requestMap = buildRequestMapWithResponse("OK:12345");
        Map<String, Object> delegateParams = new HashMap<String, Object>();

        try (MockedStatic<FDSHelper> fdsHelperMock = Mockito.mockStatic(FDSHelper.class)) {
            fdsHelperMock.when(() -> FDSHelper.runProcess(eq("delegateA"), eq(delegateParams), any(GenericResponse.class)))
                    .thenAnswer(inv -> null);

            ResponseEntity<GenericResponse> response = spyController.invokeWorkflow(
                    "json", "delegateA", delegateParams, requestMap);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("NONE", response.getBody().getResponse());

            Mockito.verify(spyController, Mockito.never())
                    .sendRequestToQueue(any(ResponseEntity.class));
        }
    }

    @Test
    public void invokeWorkflow_success_whenResponseEntityNull_doesNotSendQueue_andReturnsNone() {
        FDSServicesController spyController = Mockito.spy(fDSServicesController);
        Map<String, Object> delegateParams = new HashMap<String, Object>();

        // Force responseEntity == null branch
        Mockito.doReturn(null).when(spyController).getGenericResponse(anyMap());

        try (MockedStatic<FDSHelper> fdsHelperMock = Mockito.mockStatic(FDSHelper.class)) {
            fdsHelperMock.when(() -> FDSHelper.runProcess(eq("delegateA"), eq(delegateParams), isNull()))
                    .thenAnswer(inv -> null);

            ResponseEntity<GenericResponse> response = spyController.invokeWorkflow(
                    "json", "delegateA", delegateParams, new HashMap<String, Object>());

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("NONE", response.getBody().getResponse());
            Mockito.verify(spyController, Mockito.never())
                    .sendRequestToQueue(any(ResponseEntity.class));
        }
    }

    @Test
    public void invokeWorkflow_httpServerError_withSvcMsgId_sendsQueue_andReturns500() {
        ServiceBase mockServiceBase = Mockito.mock(ServiceBase.class);
        ReflectionTestUtils.setField(fDSServicesController, "serviceBase", mockServiceBase);
        ReflectionTestUtils.setField(fDSServicesController, "messageServiceResponseUrl", "http://test-url");
        FDSServicesController spyController = Mockito.spy(fDSServicesController);

        Map<String, Object> requestMap = buildRequestMapWithResponse("SVC_MSG:ABC");
        Map<String, Object> delegateParams = new HashMap<String, Object>();

        try (MockedStatic<FDSHelper> fdsHelperMock = Mockito.mockStatic(FDSHelper.class)) {
            fdsHelperMock.when(() -> FDSHelper.runProcess(eq("delegateA"), eq(delegateParams), any(GenericResponse.class)))
                    .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "svc down"));

            ResponseEntity<GenericResponse> response = spyController.invokeWorkflow(
                    "json", "delegateA", delegateParams, requestMap);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertEquals("500", response.getBody().getStatusCode());
            assertTrue(response.getBody().getResponse().toString().contains("ABC:"));

            Mockito.verify(spyController, Mockito.times(1))
                    .sendRequestToQueue(any(ResponseEntity.class));
        }
    }

    @Test
    public void invokeWorkflow_httpServerError_withNoneId_doesNotSendQueue_andReturns500() {
        FDSServicesController spyController = Mockito.spy(fDSServicesController);

        Map<String, Object> requestMap = buildRequestMapWithResponse("NO_PREFIX");
        Map<String, Object> delegateParams = new HashMap<String, Object>();

        try (MockedStatic<FDSHelper> fdsHelperMock = Mockito.mockStatic(FDSHelper.class)) {
            fdsHelperMock.when(() -> FDSHelper.runProcess(eq("delegateA"), eq(delegateParams), any(GenericResponse.class)))
                    .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "svc down"));

            ResponseEntity<GenericResponse> response = spyController.invokeWorkflow(
                    "json", "delegateA", delegateParams, requestMap);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertEquals("500", response.getBody().getStatusCode());
            assertTrue(response.getBody().getResponse().toString().startsWith("NONE:"));

            Mockito.verify(spyController, Mockito.never())
                    .sendRequestToQueue(any(ResponseEntity.class));
        }
    }

    @Test
    public void invokeWorkflow_genericException_withSvcMsgId_sendsQueue_andReturns500() {
        ServiceBase mockServiceBase = Mockito.mock(ServiceBase.class);
        ReflectionTestUtils.setField(fDSServicesController, "serviceBase", mockServiceBase);
        ReflectionTestUtils.setField(fDSServicesController, "messageServiceResponseUrl", "http://test-url");
        FDSServicesController spyController = Mockito.spy(fDSServicesController);

        Map<String, Object> requestMap = buildRequestMapWithResponse("SVC_MSG:XYZ");
        Map<String, Object> delegateParams = new HashMap<String, Object>();

        try (MockedStatic<FDSHelper> fdsHelperMock = Mockito.mockStatic(FDSHelper.class)) {
            fdsHelperMock.when(() -> FDSHelper.runProcess(eq("delegateA"), eq(delegateParams), any(GenericResponse.class)))
                    .thenThrow(new RuntimeException("boom"));

            ResponseEntity<GenericResponse> response = spyController.invokeWorkflow(
                    "json", "delegateA", delegateParams, requestMap);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertEquals("500", response.getBody().getStatusCode());
            assertTrue(response.getBody().getResponse().toString().contains("XYZ:boom"));

            Mockito.verify(spyController, Mockito.times(1))
                    .sendRequestToQueue(any(ResponseEntity.class));
        }
    }

    @Test
    public void invokeWorkflow_genericException_withNoneId_doesNotSendQueue_andReturns500() {
        FDSServicesController spyController = Mockito.spy(fDSServicesController);

        Map<String, Object> requestMap = buildRequestMapWithResponse("OK");
        Map<String, Object> delegateParams = new HashMap<String, Object>();

        try (MockedStatic<FDSHelper> fdsHelperMock = Mockito.mockStatic(FDSHelper.class)) {
            fdsHelperMock.when(() -> FDSHelper.runProcess(eq("delegateA"), eq(delegateParams), any(GenericResponse.class)))
                    .thenThrow(new RuntimeException("boom"));

            ResponseEntity<GenericResponse> response = spyController.invokeWorkflow(
                    "json", "delegateA", delegateParams, requestMap);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertEquals("500", response.getBody().getStatusCode());
            assertTrue(response.getBody().getResponse().toString().startsWith("NONE:boom"));

            Mockito.verify(spyController, Mockito.never())
                    .sendRequestToQueue(any(ResponseEntity.class));
        }
    }

    private Map<String, Object> buildRequestMapWithResponse(String responseMsg) {
        Map<String, Object> response = new HashMap<String, Object>();
        response.put("statusCode", "200");
        response.put("statusMessage", "OK");
        response.put("responseMsg", responseMsg);

        Map<String, Object> requestMap = new HashMap<String, Object>();
        requestMap.put("response", response);
        return requestMap;
    }

    @Test
    public void runWorkflow_whenProcessKeyAndCallbackMapPresent_callsFDSHelperRunProcess_andReturnsOk() throws Exception {
        String jsonStr = "{\"processKey\":\"value\",\"callbackMap\":{\"key\":\"value\"}}";

        Map<String, Object> callbackMap = new HashMap<>();
        callbackMap.put("k", "v");

        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put("url", new ArrayList<String>());
        requestMap.put("processKey", "myProcessKey");
        requestMap.put("callbackMap", callbackMap);

        FDSServicesController spyController = Mockito.spy(fDSServicesController);
        GenericResponse fixedResponse = GenericResponse.from("200", "OK", "SVC_MSG:123");

        try (MockedStatic<FDSHelper> fdsHelperMock = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> result = spyController.runWorkflow(jsonStr);

            assertEquals(HttpStatus.OK, result.getStatusCode());
            assertEquals("200", result.getBody().getStatusCode());
        }
    }

    @Test
    public void runWorkflow_whenJsonProcessingException_returns500WithExpectedBody() throws Exception {
        String jsonStr = "{\"bad\":\"json\"}";

        ObjectMapper mockMapper = Mockito.mock(ObjectMapper.class);
        JsonProcessingException ex = new JsonProcessingException("Invalid JSON in request") {};
        Mockito.when(mockMapper.readValue(Mockito.eq(jsonStr), Mockito.<TypeReference<Map<String, Object>>>any()))
                .thenThrow(ex);

        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockMapper);

        ResponseEntity<GenericResponse> response = fDSServicesController.runWorkflow(jsonStr);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("500", response.getBody().getStatusCode());
        assertEquals("Error processing json string", response.getBody().getStatusMessage());
        assertEquals("Invalid JSON in request", response.getBody().getResponse());
    }

    @Test
    public void runCsvProcessId_shouldFetchProcessorMetaData_andInvokeCsvSftpProcess() {
        // Arrange
        String id = "processor-123";
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        Mockito.when(csvProcessorsService.findProcessorMetaDataById(id)).thenReturn(processorMetaData);

        try (MockedStatic<FDSHelper> mockedFdsHelper = Mockito.mockStatic(FDSHelper.class)) {
            // Act
            GenericResponse response = fDSServicesController.runCsvProcessId(id);

            // Assert
            assertNotNull(response);
            assertEquals("200", response.getStatusCode());
            assertEquals(HttpStatus.OK.getReasonPhrase(), response.getStatusMessage());

            Mockito.verify(csvProcessorsService, Mockito.times(1)).findProcessorMetaDataById(id);
            mockedFdsHelper.verify(() -> FDSHelper.runProcess("csvSftpProcess", processorMetaData), Mockito.times(1));
        }
    }

    @Test
    public void runCsvProcessId_whenProcessorMetaDataExists_callsRunProcessAndReturnsOk() {
        String id = "processor-123";
        ProcessorMetaData processorMetaData = new ProcessorMetaData();

        Mockito.when(csvProcessorsService.findProcessorMetaDataById(id)).thenReturn(processorMetaData);

        try (MockedStatic<FDSHelper> helperMock = Mockito.mockStatic(FDSHelper.class)) {
            GenericResponse response = fDSServicesController.runCsvProcessId(id);

            assertNotNull(response);
            assertEquals("200", response.getStatusCode());
            assertEquals(HttpStatus.OK.getReasonPhrase(), response.getStatusMessage());
            assertEquals(HttpStatus.OK.getReasonPhrase(), response.getResponse());

            Mockito.verify(csvProcessorsService, Mockito.times(1)).findProcessorMetaDataById(id);
            helperMock.verify(() -> FDSHelper.runProcess("csvSftpProcess", processorMetaData), Mockito.times(1));
        }
    }

    @Test
    public void runCsvProcessId_whenProcessorMetaDataIsNull_stillCallsRunProcessAndReturnsOk() {
        String id = "processor-null";

        Mockito.when(csvProcessorsService.findProcessorMetaDataById(id)).thenReturn(null);

        try (MockedStatic<FDSHelper> helperMock = Mockito.mockStatic(FDSHelper.class)) {
            GenericResponse response = fDSServicesController.runCsvProcessId(id);

            assertNotNull(response);
            assertEquals("200", response.getStatusCode());

            Mockito.verify(csvProcessorsService, Mockito.times(1)).findProcessorMetaDataById(id);
            helperMock.verify(() -> FDSHelper.runProcess("csvSftpProcess", (ProcessorMetaData) null), Mockito.times(1));
        }
    }

    @Test
    public void postDocumentDocLibForELGSProcess_whenExceptionThrown_returns500() throws Exception {
        String jsonStr = "{\"id\":\"123\"}";

        ObjectMapper mockMapper = Mockito.mock(ObjectMapper.class);
        Mockito.when(mockMapper.readValue(
                Mockito.eq(jsonStr),
                Mockito.<TypeReference<Map<String, Object>>>any()
        )).thenThrow(new RuntimeException("boom in mapper"));

        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockMapper);

        ResponseEntity<GenericResponse> response =
                fDSServicesController.postDocumentDocLibForELGSProcess(jsonStr);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("500", response.getBody().getStatusCode());
        assertEquals("INTERNAL_SERVER_ERROR", response.getBody().getStatusMessage());
        assertEquals("boom in mapper", response.getBody().getResponse());
    }

    @Test
    public void processConvertMetadata_whenJsonStrIsEmpty_returnsBadRequest() {
        ResponseEntity<GenericResponse> response = fDSServicesController.processConvertMetadata("");

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("400", response.getBody().getStatusCode());
        assertEquals("Invalid request", response.getBody().getStatusMessage());
        assertEquals("Null or empty request body", response.getBody().getResponse());
    }

    @Test
    public void processConvertMetadata_whenReadValueThrowsException_returns500() throws Exception {
        // Arrange
        String jsonStr = "{\"id\":\"123\"}";
        ObjectMapper mapperMock = Mockito.mock(ObjectMapper.class);

        Mockito.when(mapperMock.readValue(
                Mockito.eq(jsonStr),
                Mockito.<TypeReference<Map<String, Object>>>any()
        )).thenThrow(new RuntimeException("mapper failed"));

        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mapperMock);

        // Act
        ResponseEntity<GenericResponse> response = fDSServicesController.processConvertMetadata(jsonStr);

        // Assert
        Assert.assertNotNull(response);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        Assert.assertNotNull(response.getBody());
        Assert.assertEquals("500", response.getBody().getStatusCode());
        Assert.assertEquals("INTERNAL_SERVER_ERROR", response.getBody().getStatusMessage());
        Assert.assertEquals("mapper failed", response.getBody().getResponse());
    }

    @Test
    public void runCsvProcessConfig_shouldInvokeRunProcessConfig_andReturnOk() {
        // Arrange
        String documents = "{\"key\":\"value\"}";
        DocumentRecord documentRecord = Mockito.mock(DocumentRecord.class);
        Mockito.when(documentRecord.getDocuments()).thenReturn(documents);

        try (MockedStatic<FDSHelper> mockedHelper = Mockito.mockStatic(FDSHelper.class)) {
            // Act
            GenericResponse response = fDSServicesController.runCsvProcessConfig(documentRecord);

            // Assert
            assertNotNull(response);
            assertEquals("200", response.getStatusCode());
            assertEquals(HttpStatus.OK.getReasonPhrase(), response.getStatusMessage());
            assertEquals(HttpStatus.OK.getReasonPhrase(), response.getResponse());

            mockedHelper.verify(() -> FDSHelper.runProcessConfig("csvSftpProcess", documents), Mockito.times(1));
        }
    }

    @Test
    public void runCleanUp_whenProcessorTransactionIdAndAppIdentifierPresent_returns200() throws Exception {
        String jsonStr = "{\"processorTransactionId\":\"txn-1\",\"appIdentifier\":\"app-1\"}";

        ObjectMapper mapperMock = Mockito.mock(ObjectMapper.class);
        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put(Workflow.PROCESSOR_TRANSACTION_ID, "txn-1");
        requestMap.put(Workflow.APP_IDENTIFIER, "app-1");

        Mockito.when(mapperMock.readValue(Mockito.eq(jsonStr), Mockito.eq(HashMap.class))).thenReturn((HashMap) requestMap);
        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mapperMock);

        try (MockedStatic<FDSHelper> helperMock = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.runCleanUp(jsonStr);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("200", response.getBody().getStatusCode());

            helperMock.verify(() ->
                            FDSHelper.processCleanUp(Workflow.CLEANUP_PROCESS_KEY, "txn-1", "app-1"),
                    Mockito.times(1));
        }
    }

    @Test
    public void runCleanUp_whenProcessorTransactionIdOrAppIdentifierEmpty_returns400() throws Exception {
        String jsonStr = "{\"processorTransactionId\":\"\",\"appIdentifier\":\"app-1\"}";

        ObjectMapper mapperMock = Mockito.mock(ObjectMapper.class);
        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put(Workflow.PROCESSOR_TRANSACTION_ID, ""); // empty -> else branch
        requestMap.put(Workflow.APP_IDENTIFIER, "app-1");

        Mockito.when(mapperMock.readValue(Mockito.eq(jsonStr), Mockito.eq(HashMap.class))).thenReturn((HashMap) requestMap);
        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mapperMock);

        try (MockedStatic<FDSHelper> helperMock = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.runCleanUp(jsonStr);

            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("400", response.getBody().getStatusCode());
            assertEquals("processorTransactionId or appIdentifier is empty in request body", response.getBody().getResponse());

            helperMock.verifyNoInteractions();
        }
    }

    @Test
    public void runFileUnzip_whenLockedFileExists_deletesLockedFile_andReturnsOk() throws Exception {
        // Arrange
        ProcessorsService mockProcessorsService = Mockito.mock(ProcessorsService.class);
        ReflectionTestUtils.setField(fDSServicesController, "processorsService", mockProcessorsService);

        ProcessorTransaction processorTransaction = Mockito.mock(ProcessorTransaction.class);

        java.nio.file.Path tempDir = java.nio.file.Files.createTempDirectory("runFileUnzipTest");
        java.nio.file.Path lockedFile = tempDir.resolve("locked.txt");
        java.nio.file.Files.write(lockedFile, "lock".getBytes()); // ensure exists() == true

        Mockito.when(processorTransaction.getLocation()).thenReturn(tempDir.toString());
        Mockito.when(mockProcessorsService.getTransactionProcessorById("tx-1")).thenReturn(processorTransaction);

        String json = "{\"processorTransactionIds\":[\"tx-1\"]}";

        try (MockedStatic<FDSHelper> mockedFdsHelper = Mockito.mockStatic(FDSHelper.class)) {
            // Act
            ResponseEntity<GenericResponse> response = fDSServicesController.runFileUnzip(json);

            // Assert
            Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
            Assert.assertFalse("locked.txt should be deleted", java.nio.file.Files.exists(lockedFile));
            Mockito.verify(mockProcessorsService, Mockito.times(1)).getTransactionProcessorById("tx-1");
        }
    }

    @Test
    public void runProcessor_whenAppIdentifierPresent_executesIfBranch_andReturns200() throws Exception {
        String jsonProcessConfigStr = "{\"id\":\"proc-1\",\"appIdentifier\":\"app-1\"}";

        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put("id", "proc-1");
        requestMap.put(Workflow.APP_IDENTIFIER, "app-1");

        ObjectMapper mapperMock = Mockito.mock(ObjectMapper.class);
        Mockito.when(mapperMock.readValue(Mockito.eq(jsonProcessConfigStr), Mockito.<TypeReference<Map<String, Object>>>any()))
                .thenReturn(requestMap);
        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mapperMock);

        org.flowable.engine.ProcessEngine processEngineMock = Mockito.mock(org.flowable.engine.ProcessEngine.class);
        org.flowable.engine.RuntimeService runtimeServiceMock = Mockito.mock(org.flowable.engine.RuntimeService.class);
        org.flowable.engine.runtime.ProcessInstance processInstanceMock = Mockito.mock(org.flowable.engine.runtime.ProcessInstance.class);

        Mockito.when(processInstanceMock.getId()).thenReturn("pi-1");
        Mockito.when(processEngineMock.getRuntimeService()).thenReturn(runtimeServiceMock);

        com.fasterxml.jackson.databind.node.ArrayNode proTranList = new ObjectMapper().createArrayNode();
        proTranList.add("tx-1");
        proTranList.add("tx-2");

        Mockito.when(runtimeServiceMock.getVariable("pi-1", Workflow.PROCESSOR_TRANSACTION_LIST_ID))
                .thenReturn(proTranList);

        try (MockedStatic<FDSHelper> fdsHelperMock = Mockito.mockStatic(FDSHelper.class);
             MockedStatic<ProcessEngines> enginesMock = Mockito.mockStatic(ProcessEngines.class)) {

            fdsHelperMock.when(() -> FDSHelper.sftpRunProcess(Workflow.SFTP_PROCESS_KEY, jsonProcessConfigStr))
                    .thenReturn(processInstanceMock);
            enginesMock.when(ProcessEngines::getDefaultProcessEngine).thenReturn(processEngineMock);

            ResponseEntity<GenericResponse> response = fDSServicesController.runProcessor(jsonProcessConfigStr);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("200", response.getBody().getStatusCode());

            fdsHelperMock.verify(() -> FDSHelper.sftpRunProcess(Workflow.SFTP_PROCESS_KEY, jsonProcessConfigStr), Mockito.times(1));
        }
    }

    @Test
    public void runProcessor_whenAppIdentifierEmpty_executesElseBranch_andReturns400() throws Exception {
        String jsonProcessConfigStr = "{\"id\":\"proc-1\",\"appIdentifier\":\"\"}";

        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put("id", "proc-1");
        requestMap.put(Workflow.APP_IDENTIFIER, ""); // triggers else branch

        ObjectMapper mapperMock = Mockito.mock(ObjectMapper.class);
        Mockito.when(mapperMock.readValue(Mockito.eq(jsonProcessConfigStr), Mockito.<TypeReference<Map<String, Object>>>any()))
                .thenReturn(requestMap);
        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mapperMock);

        ResponseEntity<GenericResponse> response = fDSServicesController.runProcessor(jsonProcessConfigStr);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("400", response.getBody().getStatusCode());
        assertEquals("processorTransactionId or appIdentifier is empty in request body", response.getBody().getResponse());
    }

    @Test
    public void processZipFile_whenAppIdentifierPresent_returnsOkAndCallsZipProcess() throws Exception {
        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", new ObjectMapper());

        String jsonProcessConfigStr = "{"
                + "\"id\":\"processor-123\","
                + "\"appIdentifier\":\"app-123\""
                + "}";

        try (MockedStatic<FDSHelper> mockedStatic = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.processZipFile(jsonProcessConfigStr);

            assertNotNull(response);
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("200", response.getBody().getStatusCode());

            mockedStatic.verify(() ->
                            FDSHelper.zipFileRunProcess(
                                    Workflow.SFTP_ZIP_FILE_PROCESS_KEY,
                                    jsonProcessConfigStr,
                                    "app-123",
                                    "processor-123"
                            ),
                    Mockito.times(1)
            );
        }
    }

    @Test
    public void processZipFile_whenAppIdentifierEmpty_returnsBadRequestAndDoesNotCallZipProcess() throws Exception {
        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", new ObjectMapper());

        String jsonProcessConfigStr = "{"
                + "\"id\":\"processor-123\","
                + "\"appIdentifier\":\"\""
                + "}";

        try (MockedStatic<FDSHelper> mockedStatic = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.processZipFile(jsonProcessConfigStr);

            assertNotNull(response);
            assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("400", response.getBody().getStatusCode());
            assertEquals("Invalid request", response.getBody().getStatusMessage());
            assertEquals("processorTransactionId or appIdentifier is empty in request body", response.getBody().getResponse());

            mockedStatic.verifyNoInteractions();
        }
    }

    @Test
    public void processTextFile_whenProcessorPresent_callsHelper_andReturnsOk() throws Exception {
        String jsonStr = "{\"processor\":{\"id\":\"proc-1\"}}";

        Map<String, Object> requestMap = new HashMap<>();
        Map<String, Object> processorMap = new HashMap<>();
        processorMap.put("id", "proc-1");
        requestMap.put(Workflow.PROCESSOR, processorMap);

        ProcessorMetaData pmd = new ProcessorMetaData();
        pmd.setId("proc-1");

        ObjectMapper mockMapper = Mockito.mock(ObjectMapper.class);
        Mockito.when(mockMapper.readValue(
                Mockito.eq(jsonStr),
                Mockito.<TypeReference<Map<String, Object>>>any()
        )).thenReturn(requestMap);
        Mockito.when(mockMapper.convertValue(
                Mockito.eq(processorMap),
                Mockito.eq(ProcessorMetaData.class)
        )).thenReturn(pmd);

        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockMapper);

        try (MockedStatic<FDSHelper> mockedStatic = Mockito.mockStatic(FDSHelper.class)) {
            mockedStatic.when(() -> FDSHelper.processTextFile(Mockito.eq(pmd)))
                    .thenAnswer(invocation -> null);

            ResponseEntity<GenericResponse> response = fDSServicesController.processTextFile(jsonStr);

            assertNotNull(response);
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("200", response.getBody().getStatusCode());

            mockedStatic.verify(() -> FDSHelper.processTextFile(Mockito.eq(pmd)), Mockito.times(1));
        }
    }

    @Test
    public void processTextFile_whenHelperThrows_returnsInternalServerError() throws Exception {
        String jsonStr = "{\"processor\":{\"id\":\"proc-1\"}}";

        Map<String, Object> requestMap = new HashMap<>();
        Map<String, Object> processorMap = new HashMap<>();
        processorMap.put("id", "proc-1");
        requestMap.put(Workflow.PROCESSOR, processorMap);

        ProcessorMetaData pmd = new ProcessorMetaData();
        pmd.setId("proc-1");

        ObjectMapper mockMapper = Mockito.mock(ObjectMapper.class);
        Mockito.when(mockMapper.readValue(
                Mockito.eq(jsonStr),
                Mockito.<TypeReference<Map<String, Object>>>any()
        )).thenReturn(requestMap);
        Mockito.when(mockMapper.convertValue(
                Mockito.eq(processorMap),
                Mockito.eq(ProcessorMetaData.class)
        )).thenReturn(pmd);

        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockMapper);

        try (MockedStatic<FDSHelper> mockedStatic = Mockito.mockStatic(FDSHelper.class)) {
            mockedStatic.when(() -> FDSHelper.processTextFile(Mockito.eq(pmd)))
                    .thenThrow(new RuntimeException("boom"));

            ResponseEntity<GenericResponse> response = fDSServicesController.processTextFile(jsonStr);

            assertNotNull(response);
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("500", response.getBody().getStatusCode());
            assertEquals("INTERNAL_SERVER_ERROR", response.getBody().getStatusMessage());
            assertEquals("boom", response.getBody().getResponse());

            mockedStatic.verify(() -> FDSHelper.processTextFile(Mockito.eq(pmd)), Mockito.times(1));
        }
    }

    @Test
    public void sftpSendEmailProcess_withValidProcessor_returnsOk() throws Exception {
        String jsonStr = "{\"processor\":{\"name\":\"testProcessor\"}}";

        ObjectMapper mockMapper = Mockito.mock(ObjectMapper.class);
        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put(Workflow.PROCESSOR, new HashMap<String, Object>());

        ProcessorMetaData pmd = new ProcessorMetaData();
        pmd.setName("testProcessor");

        Mockito.when(mockMapper.readValue(Mockito.eq(jsonStr), Mockito.<TypeReference<Map<String, Object>>>any()))
                .thenReturn(requestMap);
        Mockito.when(mockMapper.convertValue(requestMap.get(Workflow.PROCESSOR), ProcessorMetaData.class))
                .thenReturn(pmd);

        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockMapper);

        try (MockedStatic<FDSHelper> mockedHelper = Mockito.mockStatic(FDSHelper.class)) {
            mockedHelper.when(() -> FDSHelper.sftpSendEmailProcess(pmd)).thenAnswer(invocation -> null);

            ResponseEntity<GenericResponse> response = fDSServicesController.sftpSendEmailProcess(jsonStr);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());

            mockedHelper.verify(() -> FDSHelper.sftpSendEmailProcess(pmd), Mockito.times(1));
        }
    }

    @Test
    public void sftpSendEmailProcess_whenHelperThrows_returnsInternalServerError() throws Exception {
        String jsonStr = "{\"processor\":{\"name\":\"testProcessor\"}}";

        ObjectMapper mockMapper = Mockito.mock(ObjectMapper.class);
        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put(Workflow.PROCESSOR, new HashMap<String, Object>());

        ProcessorMetaData pmd = new ProcessorMetaData();
        pmd.setName("testProcessor");

        Mockito.when(mockMapper.readValue(Mockito.eq(jsonStr), Mockito.<TypeReference<Map<String, Object>>>any()))
                .thenReturn(requestMap);
        Mockito.when(mockMapper.convertValue(requestMap.get(Workflow.PROCESSOR), ProcessorMetaData.class))
                .thenReturn(pmd);

        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockMapper);

        try (MockedStatic<FDSHelper> mockedHelper = Mockito.mockStatic(FDSHelper.class)) {
            mockedHelper.when(() -> FDSHelper.sftpSendEmailProcess(pmd))
                    .thenThrow(new RuntimeException("helper failure"));

            ResponseEntity<GenericResponse> response = fDSServicesController.sftpSendEmailProcess(jsonStr);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertEquals("500", response.getBody().getStatusCode());
            assertEquals("helper failure", response.getBody().getResponse());
        }
    }

    @Test
    public void realTimeAPISendEmailProcess_validInput_returnsOk() throws Exception {
        String jsonStr = "{\"dummy\":\"value\"}";

        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put(Workflow.PROCESSOR, Map.of("name", "processor"));
        requestMap.put(Workflow.PROCCESSOR_TRANSACTION, Map.of("id", "txn-1"));

        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        Map<String, Object> processorTransaction = new HashMap<>();
        processorTransaction.put("id", "txn-1");

        ObjectMapper mockObjectMapper = Mockito.mock(ObjectMapper.class);
        Mockito.when(mockObjectMapper.readValue(Mockito.eq(jsonStr), Mockito.any(TypeReference.class)))
                .thenReturn(requestMap);
        Mockito.when(mockObjectMapper.convertValue(requestMap.get(Workflow.PROCESSOR), ProcessorMetaData.class))
                .thenReturn(processorMetaData);
        Mockito.when(mockObjectMapper.convertValue(requestMap.get(Workflow.PROCCESSOR_TRANSACTION), Map.class))
                .thenReturn(processorTransaction);

        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockObjectMapper);

        try (MockedStatic<FDSHelper> mockedFDSHelper = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response =
                    fDSServicesController.realTimeAPISendEmailProcess(jsonStr);

            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());

            mockedFDSHelper.verify(
                    () -> FDSHelper.realTimeAPISendEmailProcess(processorMetaData, processorTransaction),
                    Mockito.times(1)
            );
        }
    }

    @Test
    public void realTimeAPISendEmailProcess_whenHelperThrows_returnsInternalServerError() throws Exception {
        String jsonStr = "{\"dummy\":\"value\"}";

        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put(Workflow.PROCESSOR, Map.of("name", "processor"));
        requestMap.put(Workflow.PROCCESSOR_TRANSACTION, Map.of("id", "txn-1"));

        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        Map<String, Object> processorTransaction = new HashMap<>();
        processorTransaction.put("id", "txn-1");

        ObjectMapper mockObjectMapper = Mockito.mock(ObjectMapper.class);
        Mockito.when(mockObjectMapper.readValue(Mockito.eq(jsonStr), Mockito.any(TypeReference.class)))
                .thenReturn(requestMap);
        Mockito.when(mockObjectMapper.convertValue(requestMap.get(Workflow.PROCESSOR), ProcessorMetaData.class))
                .thenReturn(processorMetaData);
        Mockito.when(mockObjectMapper.convertValue(requestMap.get(Workflow.PROCCESSOR_TRANSACTION), Map.class))
                .thenReturn(processorTransaction);

        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockObjectMapper);

        try (MockedStatic<FDSHelper> mockedFDSHelper = Mockito.mockStatic(FDSHelper.class)) {
            mockedFDSHelper.when(
                    () -> FDSHelper.realTimeAPISendEmailProcess(processorMetaData, processorTransaction)
            ).thenThrow(new RuntimeException("boom"));

            ResponseEntity<GenericResponse> response =
                    fDSServicesController.realTimeAPISendEmailProcess(jsonStr);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertEquals("500", response.getBody().getStatusCode());
            assertEquals("boom", response.getBody().getResponse());
        }
    }

    @Test
    public void retrieveAndSendEmailProcess_whenHelperThrows_returnsInternalServerError() throws Exception {
        String jsonStr = "{\"id\":\"hook-123\"}";
        Map<String, Object> requestMap = new ObjectMapper().readValue(jsonStr, HashMap.class);

        try (MockedStatic<FDSHelper> mockedStatic = Mockito.mockStatic(FDSHelper.class)) {
            mockedStatic.when(() -> FDSHelper.retrieveAndSendEmailProcess(requestMap))
                    .thenThrow(new RuntimeException("retrieve failed"));

            ResponseEntity<GenericResponse> response = fDSServicesController.retrieveAndSendEmailProcess(jsonStr);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("500", response.getBody().getStatusCode());
            assertEquals("retrieve failed", response.getBody().getResponse());
        }
    }

    @Test
    public void sendBatchDynamicEmailRequestToPEN_whenHelperThrows_returnsInternalServerError() throws Exception {
        String jsonStr = "{\"id\":\"hook-456\"}";
        Map<String, Object> requestMap = new ObjectMapper().readValue(jsonStr, HashMap.class);

        try (MockedStatic<FDSHelper> mockedStatic = Mockito.mockStatic(FDSHelper.class)) {
            mockedStatic.when(() -> FDSHelper.sendBatchDynamicEmailRequestToPEN(requestMap))
                    .thenThrow(new RuntimeException("pen request failed"));

            ResponseEntity<GenericResponse> response = fDSServicesController.sendBatchDynamicEmailRequestToPEN(jsonStr);

            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("500", response.getBody().getStatusCode());
            assertEquals("pen request failed", response.getBody().getResponse());
        }
    }

    @Test
    public void runStatusFileShouldReturn200WhenHelperSucceeds() throws Exception {
        String jsonStr = getFdsJsonData();

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.runStatusFile(jsonStr);

            mocked.verify(() -> FDSHelper.createStatusFileAndAckProcess(Mockito.anyMap()));
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());
        }
    }

    @Test
    public void runResponseFileShouldReturn200WhenHelperSucceeds() throws Exception {
        String jsonStr = getFdsJsonData();

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.runResponseFile(jsonStr);

            mocked.verify(() -> FDSHelper.responseFileProcess(Mockito.anyMap()));
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());
        }
    }

    @Test
    public void runResponseFileUSPClaimsShouldReturn200WhenHelperSucceeds() throws Exception {
        String jsonStr = getFdsJsonData();

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.runResponseFileUSPClaims(jsonStr);

            mocked.verify(() -> FDSHelper.responseFileProcessUSPClaims(Mockito.anyMap()));
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());
        }
    }

    @Test
    public void runShutterflyShouldReturn200WhenHelperSucceeds() throws Exception {
        String jsonStr = getFdsJsonData();

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.runShutterfly(jsonStr);

            mocked.verify(() -> FDSHelper.shutterflyWorkflow(Mockito.anyMap()));
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());
        }
    }

    @Test
    public void runStorageErrorShutterflyShouldReturn200WhenHelperSucceeds() throws Exception {
        String jsonStr = getFdsJsonData();

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.runStorageErrorShutterfly(jsonStr);

            mocked.verify(() -> FDSHelper.storageErrorShutterflyWorkflow(Mockito.anyMap()));
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());
        }
    }

    @Test
    public void insertDocumentForBouncedEmailShouldReturn200WhenDocumentIsSaved() throws Exception {
        String jsonString = "{\n" +
                "  \"id\": \"60db1bef05d1ba0052bea1ea\",\n" +
                "  \"space_id\": 8896,\n" +
                "  \"status\": \"AVAILABLE\",\n" +
                "  \"metadata\": {\n" +
                "    \"providerEmailId\": \"lane_k_mooney@uhc.com\",\n" +
                "    \"original_email_from\": \"paperless_letters@uhc.com\",\n" +
                "    \"original_email_datetime\": \"2018-08-21T06:06:01+00:00\"\n" +
                "  }\n" +
                "}";

        ConfigData configMock = Mockito.mock(ConfigData.class);
        Map<String, Object> credentials = new HashMap<>();
        credentials.put("clientId", "685");
        credentials.put("appIdentifier", "test-app");

        when(configMock.getCredentials(8896)).thenReturn(credentials);
        ReflectionTestUtils.setField(fDSServicesController, "config", configMock);

        ResponseEntity<GenericResponse> response = fDSServicesController.insertDocumentForBouncedEmail(jsonString);

        Mockito.verify(documentMetaDataService).saveDocumentMetaData(Mockito.any(DocumentMetaData.class));
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("200", response.getBody().getStatusCode());
    }

    @Test
    public void runBounceProvEmailShouldReturn200WhenHelperSucceeds() {
        String jsonStr = "{\n" +
                "  \"hook\": {\n" +
                "    \"id\": \"hook-123\",\n" +
                "    \"name\": \"bounce-hook\"\n" +
                "  }\n" +
                "}";

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.runBounceProvEmail(jsonStr);

            mocked.verify(() -> FDSHelper.bounceEmailWorkflow(Mockito.anyMap()));
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("200", response.getBody().getStatusCode());
        }
    }

    @Test
    public void runMatchAndMergeShouldReturn200WhenHelperSucceeds() throws Exception {
        String jsonStr = getFdsJsonData();

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.runMatchAndMerge(jsonStr);

            mocked.verify(() -> FDSHelper.matchAndMergeWorkflow(Mockito.anyMap()));
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());
        }
    }

    @Test
    public void runEmailProcessorTransactionMetadataShouldReturn200WhenHelperSucceeds() throws Exception {
        String jsonStr = getFdsJsonData();

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.runEmailProcessorTransactionMetadata(jsonStr);

            mocked.verify(() -> FDSHelper.emailProcessorTransactionMetadataWorkflow(Mockito.anyMap()));
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());
        }
    }

    @Test
    public void providerEmailNotificationShouldReturn200WhenHelperSucceeds() throws Exception {
        String jsonStr = getFdsJsonData();

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.providerEmailNotification(jsonStr);

            mocked.verify(() -> FDSHelper.providerEmailNotificationProcess(Mockito.anyMap()));
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());
        }
    }

    @Test
    public void retrieveCorporateMPINv2ShouldReturn200WhenHelperSucceeds() throws Exception {
        String jsonStr = getFdsJsonData();

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.retrieveCorporateMPINv2(jsonStr);

            mocked.verify(() -> FDSHelper.retrieveCorporateMPINv2Process(Mockito.anyMap()));
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());
        }
    }

    @Test
    public void runCreateMetadataFilesShouldReturn200WhenHelperSucceeds() throws Exception {
        String jsonStr = getFdsJsonData();

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.runCreateMetadataFiles(jsonStr);

            mocked.verify(() -> FDSHelper.retrieveAndCreateMetadataFilesProcess(Mockito.anyMap()));
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals("200", response.getBody().getStatusCode());
        }
    }

    @Test
    public void sftpConvertFileToDocument_withValidProcessor_returnsOk() throws Exception {
        String jsonStr = "{\"processor\":{\"name\":\"testProcessor\"}}";

        ObjectMapper mockMapper = Mockito.mock(ObjectMapper.class);
        Map<String, Object> requestMap = new HashMap<>();
        Map<String, Object> processorMap = new HashMap<>();
        processorMap.put("name", "testProcessor");
        requestMap.put(Workflow.PROCESSOR, processorMap);

        ProcessorMetaData pmd = new ProcessorMetaData();
        pmd.setName("testProcessor");

        Mockito.when(mockMapper.readValue(
                Mockito.eq(jsonStr),
                Mockito.<TypeReference<Map<String, Object>>>any()
        )).thenReturn(requestMap);
        Mockito.when(mockMapper.convertValue(
                Mockito.eq(processorMap),
                Mockito.eq(ProcessorMetaData.class)
        )).thenReturn(pmd);

        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockMapper);

        try (MockedStatic<FDSHelper> mockedHelper = Mockito.mockStatic(FDSHelper.class)) {
            mockedHelper.when(() -> FDSHelper.sftpConvertFileToDocument(pmd))
                    .thenAnswer(invocation -> null);

            ResponseEntity<GenericResponse> response =
                    fDSServicesController.sftpConvertFileToDocument(jsonStr);

            assertNotNull(response);
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("200", response.getBody().getStatusCode());

            mockedHelper.verify(() -> FDSHelper.sftpConvertFileToDocument(pmd), Mockito.times(1));
        }
    }

    @Test
    public void sftpConvertFileToDocument_whenHelperThrows_returnsInternalServerError() throws Exception {
        String jsonStr = "{\"processor\":{\"name\":\"testProcessor\"}}";

        ObjectMapper mockMapper = Mockito.mock(ObjectMapper.class);
        Map<String, Object> requestMap = new HashMap<>();
        Map<String, Object> processorMap = new HashMap<>();
        processorMap.put("name", "testProcessor");
        requestMap.put(Workflow.PROCESSOR, processorMap);

        ProcessorMetaData pmd = new ProcessorMetaData();
        pmd.setName("testProcessor");

        Mockito.when(mockMapper.readValue(
                Mockito.eq(jsonStr),
                Mockito.<TypeReference<Map<String, Object>>>any()
        )).thenReturn(requestMap);
        Mockito.when(mockMapper.convertValue(
                Mockito.eq(processorMap),
                Mockito.eq(ProcessorMetaData.class)
        )).thenReturn(pmd);

        ReflectionTestUtils.setField(fDSServicesController, "objectMapper", mockMapper);

        try (MockedStatic<FDSHelper> mockedHelper = Mockito.mockStatic(FDSHelper.class)) {
            mockedHelper.when(() -> FDSHelper.sftpConvertFileToDocument(pmd))
                    .thenThrow(new RuntimeException("helper failure"));

            ResponseEntity<GenericResponse> response =
                    fDSServicesController.sftpConvertFileToDocument(jsonStr);

            assertNotNull(response);
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("500", response.getBody().getStatusCode());
            assertEquals("helper failure", response.getBody().getResponse());

            mockedHelper.verify(() -> FDSHelper.sftpConvertFileToDocument(pmd), Mockito.times(1));
        }
    }

    @Test
    public void runUpdateDocsWithSecondaryEmailShouldReturn200WhenHelperSucceeds() throws Exception {
        String jsonStr = getFdsJsonData();

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            ResponseEntity<GenericResponse> response = fDSServicesController.runUpdateDocsWithSecondaryEmail(jsonStr);

            mocked.verify(() -> FDSHelper.updateDocsWithSecondaryEmailWorkflow(Mockito.anyMap()));
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("200", response.getBody().getStatusCode());
        }
    }

    @Test
    public void runUpdateDocsWithSecondaryEmailShouldReturn400WhenRequestBodyIsEmpty() {
        ResponseEntity<GenericResponse> response = fDSServicesController.runUpdateDocsWithSecondaryEmail("");

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("400", response.getBody().getStatusCode());
        assertEquals("Invalid request", response.getBody().getStatusMessage());
        assertEquals("Null or empty request body", response.getBody().getResponse());
    }

    @Test
    public void runUpdateDocsWithSecondaryEmailShouldReturn500WhenHelperThrowsException() throws Exception {
        String jsonStr = getFdsJsonData();

        try (MockedStatic<FDSHelper> mocked = Mockito.mockStatic(FDSHelper.class)) {
            mocked.when(() -> FDSHelper.updateDocsWithSecondaryEmailWorkflow(Mockito.anyMap()))
                    .thenThrow(new RuntimeException("workflow failure"));

            ResponseEntity<GenericResponse> response = fDSServicesController.runUpdateDocsWithSecondaryEmail(jsonStr);

            mocked.verify(() -> FDSHelper.updateDocsWithSecondaryEmailWorkflow(Mockito.anyMap()));
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
            assertNotNull(response.getBody());
            assertEquals("500", response.getBody().getStatusCode());
            assertEquals("workflow failure", response.getBody().getResponse());
        }
    }
}

