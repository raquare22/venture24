package com.optum.fds.paperless.controller;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.util.DocumentUtil;

@SpringBootTest(webEnvironment = WebEnvironment.MOCK)
@RunWith(MockitoJUnitRunner.class)
@AutoConfigureMockMvc
public class PDODocumentsControllerTest {

	@Autowired
	MockMvc mockMvc;
	@Mock
	DocumentMetaDataService documentMetaDataService;
	@Mock
	DocumentUtil documentUtil;
	@InjectMocks
	PDODocumentsController pDODocumentsController;
	ObjectMapper mapper = new ObjectMapper();
	String test = "test";
	String processMetadata = "string";
	String id="stringId";


	  @Before
	  public void setUp() throws Exception {
	  MockitoAnnotations.openMocks(this);
	  ObjectMapper mapper = new ObjectMapper();
	  ReflectionTestUtils.setField(pDODocumentsController, "mapper", mapper);
	  }
	  
	@org.junit.Test
	public void postPDODocumentTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		ResponseEntity<GenericResponse> response = pDODocumentsController.postPDODocument(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void postPDODocumentTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = pDODocumentsController.postPDODocument("");
		assertNotNull(response);
	}
	@org.junit.Test
	public void updatePDODocumentTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		// when(csvProcessorService.saveCSVProcessorMetaData(processorMetaData).getName()).thenReturn("test");
		ResponseEntity<GenericResponse> response = pDODocumentsController.updatePDODocument(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void updatePDODocumentTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = pDODocumentsController.updatePDODocument("");
		assertNotNull(response);
	}
	
	@org.junit.Test
	public void postMultiPDODocumentTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		// when(csvProcessorService.saveCSVProcessorMetaData(processorMetaData).getName()).thenReturn("test");
		ResponseEntity<GenericResponse> response = pDODocumentsController.postMultiPDODocument(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void postMultiPDODocumentTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = pDODocumentsController.postMultiPDODocument("");
		assertNotNull(response);
	}
	
	@org.junit.Test
	public void putMultiPDODocumentTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		// when(csvProcessorService.saveCSVProcessorMetaData(processorMetaData).getName()).thenReturn("test");
		ResponseEntity<GenericResponse> response = pDODocumentsController.putMultiPDODocument(Map.of("test", "one"));
		assertNotNull(response);
		//assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void putMultiPDODocumentTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = pDODocumentsController.putMultiPDODocument(Map.of("", ""));
		assertNotNull(response);
	}
	@org.junit.Test
	public void getPDODocumentByIdTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		// when(csvProcessorService.saveCSVProcessorMetaData(processorMetaData).getName()).thenReturn("test");
		ResponseEntity<GenericResponse> response = pDODocumentsController.getPDODocumentById(id);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@org.junit.Test
	public void getPDODocumentByIdWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = pDODocumentsController.getPDODocumentById("");
		assertNotNull(response);
	}
	@org.junit.Test
	public void getPDODocumentsTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		// when(csvProcessorService.saveCSVProcessorMetaData(processorMetaData).getName()).thenReturn("test");
		ResponseEntity<GenericResponse> response = pDODocumentsController.getPDODocuments(Map.of("test", "one"));
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@org.junit.Test
	public void getPDODocumentsWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = pDODocumentsController.getPDODocuments(Map.of("", ""));
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@org.junit.Test
	public void postPDODocumentTestNullString() throws Exception {
		ResponseEntity<GenericResponse> response = pDODocumentsController.postPDODocument(null);
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@org.junit.Test
	public void updatePDODocumentTestMissingIdField() throws Exception {
		ResponseEntity<GenericResponse> response = pDODocumentsController.updatePDODocument("{\"someField\":\"testValue\"}");
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@org.junit.Test
	public void getPDODocumentByIdTestNonExistentId() throws Exception {
		org.mockito.Mockito.when(documentMetaDataService.getPDODocumentById("invalidId"))
				.thenThrow(new RuntimeException("Not found"));
		ResponseEntity<GenericResponse> response = pDODocumentsController.getPDODocumentById("invalidId");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@org.junit.Test
	public void putMultiPDODocumentTestNullMap() throws Exception {
		ResponseEntity<GenericResponse> response = pDODocumentsController.putMultiPDODocument(null);
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@org.junit.Test
	public void updatePDODocumentWithNullIdReturnsBadRequest() throws Exception {
		ResponseEntity<GenericResponse> response = pDODocumentsController.updatePDODocument("{\"id\":null}");
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@org.junit.Test
	public void updatePDODocumentWithEmptyIdReturnsBadRequest() throws Exception {
		ResponseEntity<GenericResponse> response = pDODocumentsController.updatePDODocument("{\"id\":\"\"}");
		assertNotNull(response);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@org.junit.Test
	public void updatePDODocumentWhenNoDocumentFoundThrowsNullPointerException() throws Exception {
		org.mockito.Mockito.when(documentMetaDataService.updatePDODocumentMetaData(
						org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.anyString()))
				.thenReturn(null);

		try {
			pDODocumentsController.updatePDODocument("{\"id\":\"abc22499\"}");
		} catch (NullPointerException ex) {
			assertEquals("No document found with id: abc22499", ex.getMessage());
		}
	}

	@org.junit.Test
	public void updatePDODocumentWithValidIdReturnsOk() throws Exception {
		org.mockito.Mockito.when(documentMetaDataService.updatePDODocumentMetaData(
						org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.anyString()))
				.thenReturn(new com.optum.fds.paperless.mongo.DocumentMetaData());

		ResponseEntity<GenericResponse> response = pDODocumentsController.updatePDODocument("{\"id\":\"validId\"}");
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@org.junit.Test
	public void putMultiPDODocumentTestException() throws Exception {
		Map<String, Object> requestMap = new HashMap<>();
		requestMap.put("documentIds", Arrays.asList("id1", "id2"));
		requestMap.put("document", new com.optum.fds.paperless.mongo.DocumentMetaData());

		ResponseEntity<GenericResponse> response = pDODocumentsController.putMultiPDODocument(requestMap);
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertEquals("INTERNAL_SERVER_ERROR", response.getBody().getStatusMessage());
	}

	@org.junit.Test
	public void getPDODocumentsWhenExceptionThrownReturnsInternalServerError() throws Exception {
		org.mockito.Mockito.when(documentMetaDataService.getPDODocuments(
						org.mockito.ArgumentMatchers.anyMap()))
				.thenThrow(new RuntimeException("Test exception"));

		Map<String, String> queryParams = Map.of("someKey", "someValue");
		ResponseEntity<GenericResponse> response = pDODocumentsController.getPDODocuments(queryParams);

		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertEquals("INTERNAL_SERVER_ERROR", response.getBody().getStatusMessage());
	}

    @org.junit.Test
    public void postPDODocumentShouldAppendDefaultsSaveDocumentAndReturnOk() throws Exception {
        String jsonStr = "{\"id\":\"doc-123\"}";

        com.optum.fds.paperless.mongo.DocumentMetaData insertedDocument =
                new com.optum.fds.paperless.mongo.DocumentMetaData();
        insertedDocument.setId("doc-123");

        org.mockito.Mockito.when(documentMetaDataService.savePDODocumentMetaData(
                        org.mockito.ArgumentMatchers.any(com.optum.fds.paperless.mongo.DocumentMetaData.class)))
                .thenReturn(insertedDocument);

        ResponseEntity<GenericResponse> response = pDODocumentsController.postPDODocument(jsonStr);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals(HttpStatus.OK.getReasonPhrase(), response.getBody().getStatusMessage());
        org.junit.Assert.assertSame(insertedDocument, response.getBody().getResponse());

        org.mockito.Mockito.verify(documentUtil)
                .appendDefaultValues(org.mockito.ArgumentMatchers.any(com.optum.fds.paperless.mongo.DocumentMetaData.class));
        org.mockito.Mockito.verify(documentMetaDataService)
                .savePDODocumentMetaData(org.mockito.ArgumentMatchers.any(com.optum.fds.paperless.mongo.DocumentMetaData.class));
    }

    @org.junit.Test
    public void postMultiPDODocumentShouldReturnOkWithInsertedDocumentIds() throws Exception {
        String jsonStr = "[{\"id\":\"doc-1\"},{\"id\":\"doc-2\"}]";

        com.optum.fds.paperless.mongo.DocumentMetaData first =
                new com.optum.fds.paperless.mongo.DocumentMetaData();
        first.setId("doc-1");

        com.optum.fds.paperless.mongo.DocumentMetaData second =
                new com.optum.fds.paperless.mongo.DocumentMetaData();
        second.setId("doc-2");

        java.util.List<com.optum.fds.paperless.mongo.DocumentMetaData> insertedDocList =
                java.util.Arrays.asList(first, second);

        org.mockito.Mockito.when(
                        documentMetaDataService.insertMultiPDODocuments(
                                org.mockito.ArgumentMatchers.anyList()))
                .thenReturn(insertedDocList);

        ResponseEntity<GenericResponse> response = pDODocumentsController.postMultiPDODocument(jsonStr);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals(HttpStatus.OK.getReasonPhrase(), response.getBody().getStatusMessage());
        assertNotNull(response.getBody().getResponse());
        org.junit.Assert.assertTrue(
                response.getBody().getResponse() instanceof com.optum.fds.paperless.model.MultiPostResponse);

        com.optum.fds.paperless.model.MultiPostResponse multiPostResponse =
                (com.optum.fds.paperless.model.MultiPostResponse) response.getBody().getResponse();

        assertEquals(java.util.Arrays.asList("doc-1", "doc-2"), multiPostResponse.getInsertedDocIds());

        org.mockito.Mockito.verify(documentMetaDataService)
                .insertMultiPDODocuments(org.mockito.ArgumentMatchers.anyList());
    }

    @org.junit.Test
    public void getPDODocumentsShouldReturnBadRequestWhenQueryParamsAreEmpty() throws Exception {
        ResponseEntity<GenericResponse> response =
                pDODocumentsController.getPDODocuments(new java.util.HashMap<String, String>());

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("400", response.getBody().getStatusCode());
        assertEquals("Invalid request", response.getBody().getStatusMessage());
        assertEquals("Null or empty request body", response.getBody().getResponse());

        org.mockito.Mockito.verifyNoInteractions(documentMetaDataService);
    }

}
