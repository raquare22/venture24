package com.optum.fds.paperless.controller;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
@SpringBootTest(webEnvironment = WebEnvironment.MOCK)
@RunWith(MockitoJUnitRunner.class)
@AutoConfigureMockMvc
public class DocumentRecordTest {

	@InjectMocks
	DocumentRecord documentRecord;
	@org.junit.Test
	public void getDocumentsTest() {
		DocumentRecord documentRecord = new DocumentRecord();
		assertEquals(null, documentRecord.getDocuments());
	}
	
	@org.junit.Test
	public void toStringTest() {
		DocumentRecord documentRecord = new DocumentRecord();
		assertEquals(null, documentRecord.toString());
	}
}
