package com.optum.fds.paperless.controller;

import static org.junit.Assert.assertSame;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.HookMetaData;

@SpringBootTest(webEnvironment = WebEnvironment.MOCK)
@RunWith(MockitoJUnitRunner.class)
@AutoConfigureMockMvc
public class HooksControllerTest {

	@InjectMocks
	HooksController hooksController;
	@Mock
	HookService hookService;
	@Autowired
	MockMvc mockMvc;
	ObjectMapper mapper = new ObjectMapper();
	String test = "test";
	String processMetadata = "string";

	String INVALID_REQUEST = "Invalid request";
	String EMPTY_REQUEST_BODY = "Null or empty request body";
	String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
	String NO_HOOK_FOUND = "No hook found for this HookId";

	  @Before
	  public void setUp() throws Exception {
	  MockitoAnnotations.openMocks(this);
	  ObjectMapper mapper = new ObjectMapper();
	  ReflectionTestUtils.setField(hooksController, "mapper", mapper);
	  }
	
	@Test
	public void postHookTestHappyPath() throws Exception {
		HookMetaData HookMetaData = new HookMetaData();
		HookMetaData.setName("test");
		ResponseEntity<GenericResponse> response = hooksController.postHook("{\"id\": \"12345\"}" );
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@Test
	public void postHookTestEmptyString() throws Exception {
		HookMetaData HookMetaData = new HookMetaData();
		HookMetaData.setName("test");
		ResponseEntity<GenericResponse> response = hooksController.postHook("");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void postHookTestEcxeptionError() throws Exception {
		HooksController hooksController = new HooksController();
		ResponseEntity<GenericResponse> response = null;
		try {
			response = hooksController.postHook("{\"id\": \"12345\"}");
		} catch (Exception ex) {
			assertNotNull(response);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
			assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
			assertEquals("Internal Server Error: " + ex.getMessage(), response.getStatusCode());
		}
	}

//	@Test
	public void updateHookTest() throws Exception {
		HookMetaData HookMetaData = new HookMetaData();
		HookMetaData.setName("test");
		// when(hookService.deleteHook("test").getName()).thenReturn("test");
		ResponseEntity<GenericResponse> response = hooksController.updateHook(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

//	@Test
	public void updateHookTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = hooksController.updateHook("");
		assertNotNull(response);
	}
	@Test
	public void updateHookTest400Error() throws Exception {
		HookMetaData HookMetaData = new HookMetaData();
		HookMetaData.setName("test");
		ResponseEntity<GenericResponse> response = hooksController.updateHook("{\"id\": \"12345\"}");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@Test
	public void getHookByNameTest() throws Exception {
		HookMetaData HookMetaData = new HookMetaData();
		HookMetaData.setName("test");
		// when(hookService.deleteHook("test").getName()).thenReturn("test");
		ResponseEntity<GenericResponse> hookByName = hooksController.getHookByName(Map.of("test", "one"));
		assertNotNull(hookByName);
		assertEquals(HttpStatus.valueOf(500), hookByName.getStatusCode());
	}

	@Test
	public void getHookByNameTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = hooksController.getHookByName((Map.of("", "")));
		assertNotNull(response);
	}

	@Test
	public void getHookByNameTest400Error() throws Exception {
		HookMetaData HookMetaData = new HookMetaData();
		HookMetaData.setName("test");
		Map<String, String> queryParams = new HashMap<>();
		queryParams.put("name", "Test Hook");
		queryParams.put("appIdentifier", "12345");
		queryParams.put("spaceId", "0");
		ResponseEntity<GenericResponse> response = hooksController.getHookByName(queryParams);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void getHookByNameTestEmptyError() throws Exception {
		HooksController hooksController = new HooksController();
		Map<String, String> emptyQueryParams = new HashMap<>();
		ResponseEntity<GenericResponse> response = hooksController.getHookByName(emptyQueryParams);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(400), response.getStatusCode());
	}

	@Test
	public void getHookByIdTest() throws Exception {
		HookMetaData HookMetaData = new HookMetaData();
		HookMetaData.setName("test");
		// when(hookService.deleteHook("test").getName()).thenReturn("test");
		ResponseEntity<GenericResponse> response = hooksController.getHookById("test");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@Test
	public void getHookByIdTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = hooksController.getHookById("");
		assertNotNull(response);
	}

	@Test
	public void getHookByIdTestHookException() throws Exception {
		HooksController hooksController = new HooksController();
		ResponseEntity<GenericResponse> response = null;
		try {
			response = hooksController.getHookById("{\"id\": \"12345\"}");
		} catch (Exception ex) {
			assertNotNull(response);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
			assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
			assertEquals("Internal Server Error: " + ex.getMessage(), response.getStatusCode());
		}
	}

	@Test
	public void deleteHookByIdTest() throws Exception {
		HookMetaData HookMetaData = new HookMetaData();
		HookMetaData.setName("test");
		// when(hookService.deleteHook("test").getName()).thenReturn("test");
		ResponseEntity<GenericResponse> response = hooksController.deleteHookById("test");
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@Test
	public void deleteHookByIdTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = hooksController.deleteHookById("");
		assertNotNull(response);
	}

	@Test
	public void deleteHookByIdTestHookException() throws Exception {
		HooksController hooksController = new HooksController();
		ResponseEntity<GenericResponse> response = null;
		try {
			response = hooksController.deleteHookById("{\"id\": \"12345\"}");
		} catch (Exception ex) {
			assertNotNull(response);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
			assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
			assertEquals("Internal Server Error: " + ex.getMessage(), response.getStatusCode());
		}
	}

	@Test
	public void gethookIdTest() throws Exception {
		String jsonStr = "{\"id\": \"12345\"}";
		String expected = "12345";
		String result = hooksController.gethookId(jsonStr);
		assertEquals(expected,result);
	}

	@Test
	public void updateHookWhenExceptionThrownReturnsInternalServerError() throws Exception {
		HooksController localHooksController = new HooksController();
		ReflectionTestUtils.setField(localHooksController, "mapper", new ObjectMapper());
		ResponseEntity<GenericResponse> response = null;
		try {
			response = localHooksController.updateHook("{\"id\": \"12345\"}");
		} catch (Exception ex) {
			assertNotNull(response);
			assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
			assertEquals("INTERNAL_SERVER_ERROR", response.getBody().getStatusMessage());
		}
	}

	@Test
	public void updateHookWithNullOrEmptyIdShouldReturnBadRequest() throws Exception {
		// Create a spy of the controller to override gethookId
		HooksController spyController = org.mockito.Mockito.spy(hooksController);

		// For missing id field, return null (which should trigger validation)
		String jsonWithNoId = "{\"someField\": \"someValue\"}";
		org.mockito.Mockito.doReturn(null)
				.when(spyController).gethookId(jsonWithNoId);

		// For empty id field, return empty string (which should trigger validation)
		String jsonWithEmptyId = "{\"id\": \"\"}";
		org.mockito.Mockito.doReturn("")
				.when(spyController).gethookId(jsonWithEmptyId);

		// Test with missing id
		ResponseEntity<GenericResponse> responseNoId = spyController.updateHook(jsonWithNoId);
		assertNotNull(responseNoId);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseNoId.getStatusCode());
		assertEquals("500", responseNoId.getBody().getStatusCode());

		// Test with empty id
		ResponseEntity<GenericResponse> responseEmptyId = spyController.updateHook(jsonWithEmptyId);
		assertNotNull(responseEmptyId);
		assertEquals(HttpStatus.BAD_REQUEST, responseEmptyId.getStatusCode());
		assertEquals("400", responseEmptyId.getBody().getStatusCode());
	}

    @Test
    public void postHookShouldReturnBadRequestWhenRequestBodyIsEmpty() throws Exception {
        ResponseEntity<GenericResponse> response = hooksController.postHook("");

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("400", response.getBody().getStatusCode());
        assertEquals("Invalid request", response.getBody().getStatusMessage());
        assertEquals("Null or empty request body", response.getBody().getResponse());

        org.mockito.Mockito.verifyNoInteractions(hookService);
    }

    @Test
    public void getHookByNameShouldReturnOkWithHooksListWhenRequestIsValid() throws Exception {
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("name", "Test Hook");
        queryParams.put("appIdentifier", "app-1");
        queryParams.put("spaceId", "10");

        java.util.List<HookMetaData> hookMetaData = new java.util.ArrayList<>();
        HookMetaData hook = new HookMetaData();
        hook.setId("hook-1");
        hook.setName("Test Hook");
        hookMetaData.add(hook);

        when(hookService.getHooksByName("app-1", 10, "Test Hook")).thenReturn(hookMetaData);

        ResponseEntity<GenericResponse> response = hooksController.getHookByName(queryParams);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals(HttpStatus.OK.getReasonPhrase(), response.getBody().getStatusMessage());
        assertEquals(hookMetaData, response.getBody().getResponse());

        org.mockito.Mockito.verify(hookService).getHooksByName("app-1", 10, "Test Hook");
    }

    @Test
    public void getHookByIdShouldReturnOkWithHookMetaDataWhenFound() throws Exception {
        String id = "hook-123";

        HookMetaData hookMetaData = new HookMetaData();
        hookMetaData.setId(id);
        hookMetaData.setName("sample-hook");

        when(hookService.getHookById(id)).thenReturn(hookMetaData);

        ResponseEntity<GenericResponse> response = hooksController.getHookById(id);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals(HttpStatus.OK.getReasonPhrase(), response.getBody().getStatusMessage());
        assertSame(hookMetaData, response.getBody().getResponse());

        org.mockito.Mockito.verify(hookService).getHookById(id);
    }

    @Test
    public void deleteHookByIdShouldReturnOkWithHookMetaDataWhenFound() throws Exception {
        String id = "hook-123";

        HookMetaData hookMetaData = new HookMetaData();
        hookMetaData.setId(id);
        hookMetaData.setName("sample-hook");

        when(hookService.deleteHook(id)).thenReturn(hookMetaData);

        ResponseEntity<GenericResponse> response = hooksController.deleteHookById(id);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals(HttpStatus.OK.getReasonPhrase(), response.getBody().getStatusMessage());
        assertSame(hookMetaData, response.getBody().getResponse());

        org.mockito.Mockito.verify(hookService).deleteHook(id);
    }
}
