package com.optum.fds.paperless.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;

@SpringBootTest(webEnvironment = WebEnvironment.MOCK)
@RunWith(MockitoJUnitRunner.class)
@AutoConfigureMockMvc
public class ProcessorControllerTest {

	@InjectMocks
	ProcessorController processorController;
	@Mock
	ProcessorService processorService;
	@Autowired
	MockMvc mockMvc;
	ObjectMapper mapper = new ObjectMapper();
	String test = "test";
	String processMetadata = "string";

	String INVALID_REQUEST = "Invalid request";
	String EMPTY_REQUEST_BODY = "Null or empty request body";
	String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
	String NO_PROCESSOR_FOUND = "No processor found for this ProcessorId";

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
		ObjectMapper mapper = new ObjectMapper();
		ReflectionTestUtils.setField(processorController, "mapper", mapper);
	}

	@Test
	public void postProcessorTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		// when(processorService.saveProcessor(processorMetaData).getName()).thenReturn("test");
		ResponseEntity<GenericResponse> response = processorController.postProcessor(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void postProcessorTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = processorController.postProcessor("");
		assertNotNull(response);
	}

	@Test
	public void updateProcessorTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		// when(processorService.saveProcessor(processorMetaData).getName()).thenReturn("test");
		ResponseEntity<GenericResponse> response = processorController.updateProcessor(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(500), response.getStatusCode());
	}

	@Test
	public void updateProcessorTesttWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = processorController.updateProcessor("");
		assertNotNull(response);
	}

	@Test
	public void getProcessorByIdTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		// when(processorService.saveProcessor(processorMetaData).getName()).thenReturn("test");
		ResponseEntity<GenericResponse> response = processorController.getProcessorById(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@Test
	public void getProcessorByIdTesttWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = processorController.getProcessorById("");
		assertNotNull(response);
	}

	@Test
	public void deleteProcessorTest() throws Exception {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setName("test");
		// when(processorService.saveProcessor(processorMetaData).getName()).thenReturn("test");
		ResponseEntity<GenericResponse> response = processorController.deleteProcessor(test);
		assertNotNull(response);
		assertEquals(HttpStatus.valueOf(200), response.getStatusCode());
	}

	@Test
	public void deleteProcessorTestWithEmpty() throws Exception {
		ResponseEntity<GenericResponse> response = processorController.deleteProcessor("");
		assertNotNull(response);
	}

	@Test
	public void deleteProcessorTestWitNotNull() throws Exception {
		// when(processorService.deleteProcessor(Mockito.anyString())).thenReturn(new
		// ProcessorMetaData());
		ResponseEntity<GenericResponse> response = processorController.deleteProcessor("");
		assertNotNull(response);
	}

	@Test
	public void deleteProcessorWhenExceptionThrownReturnsInternalServerError() throws Exception {
		Mockito.when(processorService.deleteProcessor(Mockito.anyString()))
				.thenThrow(new RuntimeException("Test exception"));

		ResponseEntity<GenericResponse> response = processorController.deleteProcessor("someId");
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertEquals("INTERNAL_SERVER_ERROR", response.getBody().getStatusMessage());
	}

	@Test
	public void getProcessorByIdWhenExceptionThrownReturnsInternalServerError() throws Exception {
		Mockito.when(processorService.getProcessorById(Mockito.anyString()))
				.thenThrow(new RuntimeException("Test exception"));

		ResponseEntity<GenericResponse> response = processorController.getProcessorById("someId");
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertEquals("INTERNAL_SERVER_ERROR", response.getBody().getStatusMessage());
	}

    @Test
    public void postProcessorShouldReturnOkAndInsertedProcessorWhenJsonIsValid() throws Exception {
        // arrange
        ObjectMapper realMapper = new ObjectMapper();
        ReflectionTestUtils.setField(processorController, "mapper", realMapper);

        ProcessorMetaData savedMeta = new ProcessorMetaData();
        savedMeta.setName("saved-processor");

        when(processorService.saveProcessorMetaData(Mockito.any(ProcessorMetaData.class))).thenReturn(savedMeta);

        String json = "{\"name\":\"input-processor\"}";

        // act
        ResponseEntity<GenericResponse> response = processorController.postProcessor(json);

        // assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals("OK", response.getBody().getStatusMessage());
        assertNotNull(response.getBody().getResponse());

        Mockito.verify(processorService, Mockito.times(1))
                .saveProcessorMetaData(Mockito.any(ProcessorMetaData.class));
    }

    @Test
    public void updateProcessorShouldReturnBadRequestWhenProcessorIdIsNullOrEmpty() throws Exception {
        // arrange
        ObjectMapper realMapper = new ObjectMapper();
        ReflectionTestUtils.setField(processorController, "mapper", realMapper);

        String jsonWithoutId = "{\"name\":\"proc-name\"}";

        // act
        ResponseEntity<GenericResponse> response = processorController.updateProcessor(jsonWithoutId);

        // assert
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("400", response.getBody().getStatusCode());
        assertEquals("Invalid request", response.getBody().getStatusMessage());
        assertEquals("Null or empty processor id", response.getBody().getResponse());

        Mockito.verify(processorService, Mockito.never())
                .updateProcessor(Mockito.any(ProcessorMetaData.class), Mockito.anyMap());
    }

    @Test
    public void updateProcessorShouldReturnOkAndCallServiceWhenProcessorIdIsPresent() throws Exception {
        // arrange
        ObjectMapper realMapper = new ObjectMapper();
        ReflectionTestUtils.setField(processorController, "mapper", realMapper);

        String jsonWithId = "{\"id\":\"p123\",\"name\":\"proc-name\"}";

        // act
        ResponseEntity<GenericResponse> response = processorController.updateProcessor(jsonWithId);

        // assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals("OK", response.getBody().getStatusMessage());
        assertEquals("Updated successfully", response.getBody().getResponse());

        Mockito.verify(processorService, Mockito.times(1))
                .updateProcessor(Mockito.any(ProcessorMetaData.class), Mockito.anyMap());
    }

    @Test
    public void getProcessorByIdShouldReturnOkWithProcessorMetaDataWhenFound() throws Exception {
        // arrange
        String id = "proc-123";
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setId(id);
        processorMetaData.setName("processor-name");

        Mockito.when(processorService.getProcessorById(id)).thenReturn(processorMetaData);

        // act
        ResponseEntity<GenericResponse> response = processorController.getProcessorById(id);

        // assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals("OK", response.getBody().getStatusMessage());
        assertNotNull(response.getBody().getResponse());

        ProcessorMetaData bodyMeta = (ProcessorMetaData) response.getBody().getResponse();
        assertEquals(id, bodyMeta.getId());
        assertEquals("processor-name", bodyMeta.getName());

        Mockito.verify(processorService, Mockito.times(1)).getProcessorById(id);
    }

    @Test
    public void getProcessorByIdShouldReturnOkWhenProcessorExists() throws Exception {
        // arrange
        String id = "proc-200";
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setId(id);
        processorMetaData.setName("processor-name");

        Mockito.when(processorService.getProcessorById(id)).thenReturn(processorMetaData);

        // act
        ResponseEntity<GenericResponse> response = processorController.getProcessorById(id);

        // assert
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals("OK", response.getBody().getStatusMessage());

        ProcessorMetaData result = (ProcessorMetaData) response.getBody().getResponse();
        assertNotNull(result);
        assertEquals(id, result.getId());
        assertEquals("processor-name", result.getName());

        Mockito.verify(processorService, Mockito.times(1)).getProcessorById(id);
    }
}
