package com.optum.fds.paperless;

import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import org.ehcache.Cache;
import org.ehcache.CacheManager;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class EhCacheTest {

    private EhCache ehCache;
    private CacheManager cacheManagerMock;
    private Cache<String, String> corpMpinCacheMock;
    private Cache<String, OauthTokenExtended> oauthTokenCacheMock;

    @Before
    public void setUp() {
        cacheManagerMock = mock(CacheManager.class);
        corpMpinCacheMock = mock(Cache.class);
        oauthTokenCacheMock = mock(Cache.class);

        ehCache = new EhCache() {
            {
                this.cacheManager = cacheManagerMock;
            }
            @Override
            public Cache<String, String> getProviderCorpMpinCacheFromCacheManager() {
                return corpMpinCacheMock;
            }
            @Override
            public Cache<String, OauthTokenExtended> getOauthTokenCacheFromCacheManager() {
                return oauthTokenCacheMock;
            }
        };
    }

    @Test
    public void testGetCorpMpinCache_ValuePresent() {
        when(corpMpinCacheMock.containsKey("TIN123")).thenReturn(true);
        when(corpMpinCacheMock.get("TIN123")).thenReturn("MPIN_VALUE");
        String result = ehCache.getCorpMpinCache("TIN123");
        assertEquals("MPIN_VALUE", result);
    }

    @Test
    public void testGetCorpMpinCache_ValueAbsent() {
        when(corpMpinCacheMock.containsKey("TIN123")).thenReturn(false);
        String result = ehCache.getCorpMpinCache("TIN123");
        assertEquals("", result);
    }

    @Test
    public void testPutCorpMpinCache_Valid() {
        ehCache.putCorpMpinCache("TIN123", "MPIN_VALUE");
        verify(corpMpinCacheMock, times(1)).put("TIN123", "MPIN_VALUE");
    }

    @Test
    public void testPutCorpMpinCache_EmptyValue() {
        ehCache.putCorpMpinCache("TIN123", "");
        verify(corpMpinCacheMock, never()).put(anyString(), anyString());
    }

    @Test
    public void testGetOauthTokenCache_ValuePresent() {
        when(oauthTokenCacheMock.containsKey("TOKEN123")).thenReturn(true);
        when(oauthTokenCacheMock.get("TOKEN123")).thenReturn(getOauthToken());
        String result = ehCache.getOauthTokenCache("TOKEN123");
        assertEquals("OAUTH_VALUE", result);
    }

    @Test
    public void testGetOauthTokenCache_ValueAbsent() {
        when(oauthTokenCacheMock.containsKey("TOKEN123")).thenReturn(false);
        String result = ehCache.getOauthTokenCache("TOKEN123");
        assertNull(result);
    }

    @Test
    public void testPutOauthTokenWithExpiry_Valid() {
        ehCache.putOauthTokenWithExpiry("TOKEN123", "OAUTH_VALUE", 2);
        verify(oauthTokenCacheMock, times(1)).put(anyString(), any());
    }

    @Test
    public void testPutOauthTokenWithExpiry_EmptyValue() {
        ehCache.putOauthTokenWithExpiry("TOKEN123", "", 2);
        verify(oauthTokenCacheMock, never()).put(anyString(), any());
    }


    private OauthTokenExtended getOauthToken() {
        return new OauthTokenExtended("OAUTH_VALUE", 3540);
    }

    @Test
    public void testGetCorpMpinCache_whenCacheGetThrowsException_shouldReturnEmptyString() {
        when(corpMpinCacheMock.containsKey("TIN123")).thenReturn(true);
        when(corpMpinCacheMock.get("TIN123")).thenThrow(new RuntimeException("cache get failure"));

        String result = ehCache.getCorpMpinCache("TIN123");

        assertEquals("", result);
    }

    @Test
    public void testPutCorpMpinCache_whenCachePutThrowsException_shouldNotThrow() {
        doThrow(new RuntimeException("cache put failure"))
                .when(corpMpinCacheMock).put("TIN123", "MPIN_VALUE");

        try {
            ehCache.putCorpMpinCache("TIN123", "MPIN_VALUE");
        } catch (Exception e) {
            fail("Exception should have been caught inside putCorpMpinCache, but got: " + e.getMessage());
        }

        verify(corpMpinCacheMock).put("TIN123", "MPIN_VALUE");
    }

    @Test
    public void testGetOauthTokenCache_whenCacheGetThrowsException_shouldReturnNull() {
        when(oauthTokenCacheMock.containsKey("TOKEN123")).thenReturn(true);
        when(oauthTokenCacheMock.get("TOKEN123")).thenThrow(new RuntimeException("oauth cache get failure"));

        String result = ehCache.getOauthTokenCache("TOKEN123");

        assertNull(result);
    }

    @Test
    public void testPutOauthTokenWithExpiry_whenCachePutThrowsException_shouldNotThrow() {
        doThrow(new RuntimeException("oauth cache put failure"))
                .when(oauthTokenCacheMock).put(eq("TOKEN123"), any(OauthTokenExtended.class));

        try {
            ehCache.putOauthTokenWithExpiry("TOKEN123", "OAUTH_VALUE", 3540);
        } catch (Exception e) {
            fail("Exception should have been caught inside putOauthTokenWithExpiry, but got: " + e.getMessage());
        }

        verify(oauthTokenCacheMock).put(eq("TOKEN123"), any(OauthTokenExtended.class));
    }

    @Test
    public void testGetProviderCorpMpinCacheFromCacheManager_shouldReturnProviderCorpMpinCache() {
        EhCache realEhCache = new EhCache();
        realEhCache.cacheManager = cacheManagerMock;

        when(cacheManagerMock.getCache("providerCorpMpin", String.class, String.class))
                .thenReturn(corpMpinCacheMock);

        Cache<String, String> result = realEhCache.getProviderCorpMpinCacheFromCacheManager();

        assertSame(corpMpinCacheMock, result);
        verify(cacheManagerMock).getCache("providerCorpMpin", String.class, String.class);
    }

    @Test
    public void testGetOauthTokenCacheFromCacheManager_shouldReturnOauthTokenCache() {
        EhCache realEhCache = new EhCache();
        realEhCache.cacheManager = cacheManagerMock;

        when(cacheManagerMock.getCache("oauthToken", String.class, OauthTokenExtended.class))
                .thenReturn(oauthTokenCacheMock);

        Cache<String, OauthTokenExtended> result = realEhCache.getOauthTokenCacheFromCacheManager();

        assertSame(oauthTokenCacheMock, result);
        verify(cacheManagerMock).getCache("oauthToken", String.class, OauthTokenExtended.class);
    }
}
