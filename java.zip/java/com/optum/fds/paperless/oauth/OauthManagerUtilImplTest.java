package com.optum.fds.paperless.oauth;

import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.java.delegate.oauth.AuthorizationOauthProvider;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.java.delegate.oauth.bean.Token;
import com.optum.fds.paperless.java.delegate.oauth.impl.OauthManagerUtilImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;


@RunWith(MockitoJUnitRunner.class)
public class OauthManagerUtilImplTest {
	private static final String APP_ID_TEST_1 = "testapp";
	private static final String APP_ID_TEST_2 = "testapp2";
	private static final String APP_ID_TEST_3 = "testapp3";
	private static final String APP_ID_TEST_4 = "testapp4";
	private static final String CLIENT_SECRET_TEST1 = "testapp";
	private static final String CLIENT_SECRET_TEST2 = "testapp2";
	private static final String CLIENT_SECRET_TEST3 = "testapp3";
	private static final String ACCESS_TOKEN_TEST1 = "abc123";
	private static final String REFRESH_TOKEN_TEST = "123ABC";
	private static final String GRANT_TYPE = "authorization";
	private static final Integer EXPIRES_IN = 1800;
	private static final String TOKEN_TYPE = "bearer";
    private static final String SCOPE = "testscope";
	private static final String OAUTH_FDS_HOST = "FDS_HOST";
	private static final String OAUTH_FDS_PORT = "FDS_PORT";
	private static final String OAUTH_FDS_PROTOCOL = "FDS_PROTOCOL";
	private static final String URL = "http://foo.optum.com.none";
	
	@InjectMocks
	OauthManagerUtilImpl oauthManagerUtilImpl;


	@Mock
	AuthorizationOauthProvider authorizationProvider;

	@Before
	public void setup() throws FSDataException, IOException, InterruptedException{
		when(authorizationProvider.getOauth2Token(anyString(), any())).thenReturn(getValidToken());
	}

	
	@Test
	public void testGetToken() throws FSDataException, InterruptedException {
		OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1, URL, GRANT_TYPE, SCOPE);
		oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
		assertEquals(ACCESS_TOKEN_TEST1, oauthTokenExtended.getAccessToken());
		assertEquals(EXPIRES_IN, oauthTokenExtended.getExpiresIn());
		assertEquals(TOKEN_TYPE, oauthTokenExtended.getTokenType());
		var optToken = getValidToken();
		assertTrue(optToken.isPresent());
		var token = optToken.get();
		assertEquals(APP_ID_TEST_1, token.getClientId());
		assertEquals(CLIENT_SECRET_TEST1, token.getClientSecret());
		assertEquals(REFRESH_TOKEN_TEST, token.getRefreshToken());
		assertEquals(GRANT_TYPE, token.getGrantType());

	}
	
	@Test
	public void testGetTokenCustomURL() throws FSDataException, InterruptedException {
		OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_4, CLIENT_SECRET_TEST1, URL, GRANT_TYPE,SCOPE);
		oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
		assertEquals(ACCESS_TOKEN_TEST1, oauthTokenExtended.getAccessToken());
		assertEquals(EXPIRES_IN, oauthTokenExtended.getExpiresIn());
		assertEquals(TOKEN_TYPE, oauthTokenExtended.getTokenType());
        assertEquals(SCOPE, oauthTokenExtended.getScope());
		var optToken = getValidToken();
		assertTrue(optToken.isPresent());
		var token = optToken.get();
		assertEquals(APP_ID_TEST_1, token.getClientId());
		assertEquals(CLIENT_SECRET_TEST1, token.getClientSecret());
		assertEquals(REFRESH_TOKEN_TEST, token.getRefreshToken());
		assertEquals(GRANT_TYPE, token.getGrantType());
	}

	
	@Test
	public void testGetTokenExpired() throws InterruptedException {
		OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1, URL, GRANT_TYPE,SCOPE);
		oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
		Date obtainedDate =  oauthTokenExtended.getObtainedOn();
		obtainedDate.setTime(obtainedDate.getTime() - TimeUnit.SECONDS.toMillis(1600));
		oauthTokenExtended.setObtainedOn(obtainedDate);
		oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
		assertEquals(ACCESS_TOKEN_TEST1, oauthTokenExtended.getAccessToken());
	}
	
	@Test
	public void testGetTokenNullDateObtained() throws InterruptedException {
		OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1, URL, GRANT_TYPE,SCOPE);
		oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
		oauthTokenExtended.setObtainedOn(null);
		oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
		assertEquals(ACCESS_TOKEN_TEST1, oauthTokenExtended.getAccessToken());
	}
	
	@Test
	public void testGetTokenInvalid() throws InterruptedException {
		OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_2, CLIENT_SECRET_TEST2);
		oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
		assertNull(oauthTokenExtended.getAccessToken());
	}


	@Test(expected=InterruptedException.class)
	public void testGetTokenThrowsIOException() throws InterruptedException {
			when(authorizationProvider.getOauth2Token(anyString(), any())).thenThrow(new InterruptedException());
			OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_3, CLIENT_SECRET_TEST3, URL, GRANT_TYPE,SCOPE);
			oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
	}

	private Optional<Token> getValidToken(){
		Token token = new Token();
		token.setAccessToken(ACCESS_TOKEN_TEST1);
		token.setRefreshToken(REFRESH_TOKEN_TEST);
		token.setClientId(APP_ID_TEST_1);
		token.setClientSecret(CLIENT_SECRET_TEST1);
		token.setExpiresIn(EXPIRES_IN);
		token.setTokenType(TOKEN_TYPE);
		token.setGrantType(GRANT_TYPE);
		return Optional.of(token);
	}

    @Test
    public void testGetOauthToken_whenTokenExistsInCacheAndGetNewTokenFalse_shouldReturnCachedToken() {
        EhCache ehCache = mock(EhCache.class);
        OauthManagerUtilImpl spyUtil = spy(new OauthManagerUtilImpl());

        ReflectionTestUtils.setField(spyUtil, "ehCache", ehCache);
        ReflectionTestUtils.setField(spyUtil, "token_expiry_in_seconds", 60);

        when(ehCache.getOauthTokenCache("DOC")).thenReturn("cached-token");

        String token = spyUtil.getOauthToken("DOC", "clientId", "clientSecret", "grant", "url", false, "scope");

        assertEquals("cached-token", token);
        verify(ehCache).getOauthTokenCache("DOC");
        verify(ehCache, never()).putOauthTokenWithExpiry(anyString(), any(), anyInt());
    }

    @Test
    public void testGetOauthToken_whenCacheMiss_shouldFetchAndCacheTokenWithReducedExpiry() {
        EhCache ehCache = mock(EhCache.class);
        OauthManagerUtilImpl spyUtil = spy(new OauthManagerUtilImpl());

        ReflectionTestUtils.setField(spyUtil, "ehCache", ehCache);
        ReflectionTestUtils.setField(spyUtil, "token_expiry_in_seconds", 60);

        OauthTokenExtended oauthTokenExtended =
                new OauthTokenExtended("clientId", "clientSecret", "url", "grant", "scope");
        oauthTokenExtended.setAccessToken("fresh-token");
        oauthTokenExtended.setExpiresIn(1800);

        when(ehCache.getOauthTokenCache("DOC")).thenReturn(null);
        doReturn(Optional.of(oauthTokenExtended)).when(spyUtil)
                .getOauthTokenExtended("clientId", "clientSecret", "url", "grant", "scope");

        String token = spyUtil.getOauthToken("DOC", "clientId", "clientSecret", "grant", "url", false, "scope");

        assertEquals("fresh-token", token);
        verify(ehCache).putOauthTokenWithExpiry("DOC", "fresh-token", 1740);
    }

    @Test
    public void testGetOauthToken_whenGetNewTokenTrue_shouldIgnoreCacheAndFetchNewToken() {
        EhCache ehCache = mock(EhCache.class);
        OauthManagerUtilImpl spyUtil = spy(new OauthManagerUtilImpl());

        ReflectionTestUtils.setField(spyUtil, "ehCache", ehCache);
        ReflectionTestUtils.setField(spyUtil, "token_expiry_in_seconds", 60);

        OauthTokenExtended oauthTokenExtended =
                new OauthTokenExtended("clientId", "clientSecret", "url", "grant", "scope");
        oauthTokenExtended.setAccessToken("new-token");
        oauthTokenExtended.setExpiresIn(90);

        when(ehCache.getOauthTokenCache("DOC")).thenReturn("old-cached-token");
        doReturn(Optional.of(oauthTokenExtended)).when(spyUtil)
                .getOauthTokenExtended("clientId", "clientSecret", "url", "grant", "scope");

        String token = spyUtil.getOauthToken("DOC", "clientId", "clientSecret", "grant", "url", true, "scope");

        assertEquals("new-token", token);
        verify(ehCache).putOauthTokenWithExpiry("DOC", "new-token", 30);
    }

    @Test
    public void testGetOauthToken_whenOauthTokenExtendedIsEmpty_shouldReturnNullAndUseDefaultExpiry() {
        EhCache ehCache = mock(EhCache.class);
        OauthManagerUtilImpl spyUtil = spy(new OauthManagerUtilImpl());

        ReflectionTestUtils.setField(spyUtil, "ehCache", ehCache);
        ReflectionTestUtils.setField(spyUtil, "token_expiry_in_seconds", 60);

        when(ehCache.getOauthTokenCache("DOC")).thenReturn(null);
        doReturn(Optional.empty()).when(spyUtil)
                .getOauthTokenExtended("clientId", "clientSecret", "url", "grant", "scope");

        String token = spyUtil.getOauthToken("DOC", "clientId", "clientSecret", "grant", "url", false, "scope");

        assertNull(token);
        verify(ehCache).putOauthTokenWithExpiry("DOC", null, 3540);
    }

    @Test
    public void testGetOauthToken_whenExpiresInIsNotGreaterThanThreshold_shouldNotReduceExpiry() {
        EhCache ehCache = mock(EhCache.class);
        OauthManagerUtilImpl spyUtil = spy(new OauthManagerUtilImpl());

        ReflectionTestUtils.setField(spyUtil, "ehCache", ehCache);
        ReflectionTestUtils.setField(spyUtil, "token_expiry_in_seconds", 60);

        OauthTokenExtended oauthTokenExtended =
                new OauthTokenExtended("clientId", "clientSecret", "url", "grant", "scope");
        oauthTokenExtended.setAccessToken("fresh-token");
        oauthTokenExtended.setExpiresIn(60);

        when(ehCache.getOauthTokenCache("DOC")).thenReturn(null);
        doReturn(Optional.of(oauthTokenExtended)).when(spyUtil)
                .getOauthTokenExtended("clientId", "clientSecret", "url", "grant", "scope");

        String token = spyUtil.getOauthToken("DOC", "clientId", "clientSecret", "grant", "url", false, "scope");

        assertEquals("fresh-token", token);
        verify(ehCache).putOauthTokenWithExpiry("DOC", "fresh-token", 60);
    }

    @Test
    public void testGetOauthTokenExtended_whenScopePresent_shouldSetScopeAndReturnOptional() throws InterruptedException {
        OauthManagerUtilImpl spyUtil = spy(new OauthManagerUtilImpl());

        OauthTokenExtended refreshed =
                new OauthTokenExtended("clientId", "clientSecret", "url", "grant", "scope-value");
        refreshed.setAccessToken("abc123");
        refreshed.setExpiresIn(1800);

        doReturn(refreshed).when(spyUtil).refreshToken(any(OauthTokenExtended.class));

        Optional<OauthTokenExtended> result =
                spyUtil.getOauthTokenExtended("clientId", "clientSecret", "url", "grant", "scope-value");

        assertTrue(result.isPresent());
        assertEquals("scope-value", result.get().getScope());
        assertEquals("abc123", result.get().getAccessToken());
    }

    @Test
    public void testGetOauthTokenExtended_whenScopeIsNull_shouldReturnOptionalWithoutSettingScopeAgain() throws InterruptedException {
        OauthManagerUtilImpl spyUtil = spy(new OauthManagerUtilImpl());

        OauthTokenExtended refreshed =
                new OauthTokenExtended("clientId", "clientSecret", "url", "grant", null);
        refreshed.setAccessToken("abc123");

        doReturn(refreshed).when(spyUtil).refreshToken(any(OauthTokenExtended.class));

        Optional<OauthTokenExtended> result =
                spyUtil.getOauthTokenExtended("clientId", "clientSecret", "url", "grant", null);

        assertTrue(result.isPresent());
        assertNull(result.get().getScope());
        assertEquals("abc123", result.get().getAccessToken());
    }

    @Test
    public void testGetOauthTokenExtended_whenRefreshTokenThrowsInterruptedException_shouldReturnEmpty() throws InterruptedException {
        OauthManagerUtilImpl spyUtil = spy(new OauthManagerUtilImpl());

        doThrow(new InterruptedException("interrupted")).when(spyUtil)
                .refreshToken(any(OauthTokenExtended.class));

        Optional<OauthTokenExtended> result =
                spyUtil.getOauthTokenExtended("clientId", "clientSecret", "url", "grant", "scope");

        assertTrue(result.isEmpty());
    }

}
