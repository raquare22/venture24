package com.optum.fds.paperless.oauth;


import com.optum.fds.paperless.java.delegate.oauth.AuthorizationOauthProvider;
import com.optum.fds.paperless.java.delegate.oauth.bean.HttpConstants;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.java.delegate.oauth.bean.Token;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Date;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AuthorizationOauthProviderTest {
    private static final String URL = "http://foo.optum.com.none";
    private static final String APP_ID_TEST_1 = "testapp";
    private static final String CLIENT_SECRET_TEST1 = "testapp";
    private static final String ACCESS_TOKEN_TEST1 = "abc123";
    private static final String REFRESH_TOKEN_TEST = "123ABC";
    private static final String GRANT_TYPE = "authorization";
    private static final Integer EXPIRES_IN = 1800;
    private static final String TOKEN_TYPE = "bearer";
    private static final String OAUTH_FDS_HOST = "dummy.optum.com";
    private static final Integer OAUTH_FDS_PORT = 443;
    private static final String OAUTH_FDS_PROTOCOL = "https";
    private static final int POST_RETRIES = 3;
    private static final long POST_RETRIES_SLEEP = 3000;

	@Value("${OAUTH_POST_RETRIES}")
	private static String oauthPostRetries;

	@Value("${OAUTH_POST_RETRIES_SLEEP_TIME}")
	private static String oauthPostRetriesSleepTime;
    @Mock
    RestTemplate restTemplate;

    @InjectMocks
    @Spy
    AuthorizationOauthProvider authorizationOauthProvider;

    private String getDefaultUrl(OauthTokenExtended oauthTokenExtended) {
        String url = null;
        if (StringUtils.isEmpty(oauthTokenExtended.getUrl())) {
            url = createDefaultUrl(OAUTH_FDS_PORT.toString());
        } else {
            url = oauthTokenExtended.getUrl();
        }
        return url;
    }

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);

        ResponseEntity<Token> response = new ResponseEntity<Token>(generateValidToken(),
                HttpStatus.OK);

        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(),
                ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<Token>>any())).thenReturn(response);
    }

    @Test
    public void testGetOauth2TokenExceptionMySqlVariables() throws InterruptedException, SecurityException, IllegalArgumentException {

        var oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1);
        var url = getDefaultUrl(oauthTokenExtended);
        var optToken = authorizationOauthProvider.getOauth2Token(url, oauthTokenExtended);
        if (optToken.isPresent()) {
            Token Token = optToken.get();
            assertEquals(APP_ID_TEST_1, Token.getClientId());
            assertEquals(CLIENT_SECRET_TEST1, Token.getClientSecret());
            assertEquals(REFRESH_TOKEN_TEST, Token.getRefreshToken());
            assertEquals(GRANT_TYPE, Token.getGrantType());
        }
    }

//    @Test
//    public void testGetOauth2TokenNullMySqlVariables() throws InterruptedException, SecurityException, IllegalArgumentException {
//
//       //when(ConfigData.getOrDefaultStringWithActiveProfile(OAUTH_POST_RETRIES)).thenReturn(null);
//    	when((oauthPostRetries)).thenReturn(null);
//    	// when(ConfigData.getOrDefaultStringWithActiveProfile(OAUTH_POST_RETRIES_SLEEP_TIME)).thenReturn(null);
//    	when((oauthPostRetriesSleepTime)).thenReturn(null);
//
//
//    	var oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1);
//        var url = getDefaultUrl(oauthTokenExtended);
//
//        var optToken = authorizationOauthProvider.getOauth2Token(url, oauthTokenExtended);
//        assertTrue(optToken.isPresent());
//        Token Token = optToken.get();
//        assertEquals(APP_ID_TEST_1, Token.getClientId());
//        assertEquals(CLIENT_SECRET_TEST1, Token.getClientSecret());
//        assertEquals(REFRESH_TOKEN_TEST, Token.getRefreshToken());
//        assertEquals(GRANT_TYPE, Token.getGrantType());
//    }

    @Test
    public void testGetOauth2TokenRetry() throws InterruptedException {
        ResponseEntity<Token> response = new ResponseEntity<Token>(generateValidToken(),
                HttpStatus.INTERNAL_SERVER_ERROR);
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<Token>>any())).thenReturn(response);
        Date startRequestDate = new Date();

        var oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1);
        var url = getDefaultUrl(oauthTokenExtended);

        var optToken = authorizationOauthProvider.getOauth2Token(url, oauthTokenExtended);
        assertTrue(optToken.isEmpty());
        Date endRequestDate = new Date();
        assertTrue((endRequestDate.getTime() - startRequestDate.getTime()) >= (POST_RETRIES_SLEEP * POST_RETRIES));
        ResponseEntity<Token> response2 = new ResponseEntity<>(generateValidToken(),
                HttpStatus.OK);
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<Token>>any())).thenReturn(response2);

        oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1);
        url = getDefaultUrl(oauthTokenExtended);

        optToken = authorizationOauthProvider.getOauth2Token(url, oauthTokenExtended);
        assertTrue(optToken.isPresent());
        var token = optToken.get();
        assertEquals(APP_ID_TEST_1, token.getClientId());
        assertEquals(CLIENT_SECRET_TEST1, token.getClientSecret());
        assertEquals(REFRESH_TOKEN_TEST, token.getRefreshToken());
        assertEquals(GRANT_TYPE, token.getGrantType());
    }

//    @Test
//    public void testGetOauth2TokenNoMySqlVariables() throws InterruptedException {
//        //when(ConfigData.getOrDefaultStringWithActiveProfile(OAUTH_POST_RETRIES)).thenReturn(null);
//        //when(ConfigData.getOrDefaultStringWithActiveProfile(OAUTH_POST_RETRIES_SLEEP_TIME)).thenReturn(null);
//
//    	when((oauthPostRetries)).thenReturn(null);
//    	when((oauthPostRetriesSleepTime)).thenReturn(null);
//
//        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1);
//        var url = getDefaultUrl(oauthTokenExtended);
//
//        var optToken = authorizationOauthProvider.getOauth2Token(url, oauthTokenExtended);
//        assertTrue(optToken.isPresent());
//        var Token = optToken.get();
//        assertEquals(APP_ID_TEST_1, Token.getClientId());
//        assertEquals(CLIENT_SECRET_TEST1, Token.getClientSecret());
//        assertEquals(REFRESH_TOKEN_TEST, Token.getRefreshToken());
//        assertEquals(GRANT_TYPE, Token.getGrantType());
//    }


    @Test
    @UserStory(references = "US22102")
    @RallyTestCase(references = "TC26813")
    public void testGetOauth2TokenSuccess() throws InterruptedException {
        ResponseEntity<Token> response = new ResponseEntity<Token>(generateValidToken(), HttpStatus.OK);
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<Token>>any())).thenReturn(response);
        var oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1, URL, GRANT_TYPE, null);
        var url = getDefaultUrl(oauthTokenExtended);

        var optToken = authorizationOauthProvider.getOauth2Token(url, oauthTokenExtended);
        assertTrue(optToken.isPresent());
        var token = optToken.get();
        assertNotNull(oauthTokenExtended.getUrl());
        assertNotNull(oauthTokenExtended.getGrantType());
        assertEquals(APP_ID_TEST_1, token.getClientId());
        assertEquals(CLIENT_SECRET_TEST1, token.getClientSecret());
        assertEquals(REFRESH_TOKEN_TEST, token.getRefreshToken());
        assertEquals(GRANT_TYPE, token.getGrantType());
    }

    @Test
    public void testGetOauth2TokenNoRestTemplate() throws InterruptedException {
        ResponseEntity<Token> response = new ResponseEntity<Token>(generateValidToken(),
                HttpStatus.OK);
        when(restTemplate.exchange(anyString(), ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<Token>>any())).thenReturn(response);
        var oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1, URL, GRANT_TYPE, null);
        var url = getDefaultUrl(oauthTokenExtended);

        var optToken = authorizationOauthProvider.getOauth2Token(url, oauthTokenExtended);
        assertTrue(optToken.isPresent());
        var token = optToken.get();
    }

    private Token generateValidToken() {
        Token token = new Token();
        token.setAccessToken(ACCESS_TOKEN_TEST1);
        token.setRefreshToken(REFRESH_TOKEN_TEST);
        token.setClientId(APP_ID_TEST_1);
        token.setClientSecret(CLIENT_SECRET_TEST1);
        token.setExpiresIn(EXPIRES_IN);
        token.setTokenType(TOKEN_TYPE);
        token.setGrantType(GRANT_TYPE);
        return token;
    }

    private String createDefaultUrl(String port) {
        var url = new StringBuilder();
        url.append(AuthorizationOauthProviderTest.OAUTH_FDS_PROTOCOL);
        url.append("://");
        url.append(AuthorizationOauthProviderTest.OAUTH_FDS_HOST);

        if (StringUtils.isNotEmpty(port)) {
            var portInt = Integer.parseInt(port);
            url.append(":");
            url.append(portInt);
        }
        url.append(HttpConstants.PATH);

        return url.toString();
    }
}
