package com.optum.fds.paperless.oauth.bean;

import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.isNull;

@RunWith(MockitoJUnitRunner.class)
public class OauthTokenExtendedTest {

    @Test
    public void test() {
        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended("username", "password");
        oauthTokenExtended.getAccessToken();
        oauthTokenExtended.getApplicationId();
        oauthTokenExtended.setAccessToken(StringUtils.EMPTY);
        oauthTokenExtended.getTokenType();
        oauthTokenExtended.setTokenType(StringUtils.EMPTY);
        oauthTokenExtended.getGrantType();
        oauthTokenExtended.setGrantType("grantType");
        oauthTokenExtended.setExpiresIn(3000);
        oauthTokenExtended.getExpiresIn();
        oauthTokenExtended.setUrl("url");
        oauthTokenExtended.getUrl();
        oauthTokenExtended.setObtainedOn(new DateTime().toDate());
        oauthTokenExtended.getObtainedOn();
        oauthTokenExtended.isTokenGoingToExpire();
    }
    
    @Test
    public void testConstructorTwo() {
        OauthTokenExtended obj = new OauthTokenExtended("username", "password", "fdsHost","grantType", "scope");
        assertNotNull(obj);
        obj.getPassword();
        obj.setObtainedOn(null);
        obj.isTokenGoingToExpire();
    }
}
