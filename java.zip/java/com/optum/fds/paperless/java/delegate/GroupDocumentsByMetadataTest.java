package com.optum.fds.paperless.java.delegate;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.MockedStatic;

import java.io.IOException;
import org.json.JSONException;
import java.util.*;

public class GroupDocumentsByMetadataTest {

    @InjectMocks
    private GroupDocumentsByMetadata groupDocumentsByMetadata;

    private DelegateExecution execution = new DelegateExecutionImpl();

    private final String PATH_JSON_FILE = "InputJson/GroupDocumentsByMetadataTest.json";

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        groupDocumentsByMetadata = new GroupDocumentsByMetadata();
    }

    @Test
    public void testDoExecute() throws Exception {
        // Mock input variables

        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile);

        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "tin");

        groupDocumentsByMetadata.doExecute(execution);

        Map<String, Object> uniqueFieldMap = execution.getVariable("uniqueFieldMap", Map.class);
        List<DocumentMetaData> uniqueFieldDocumentList = execution.getVariable("uniqueFieldDocumentList", List.class);

        assertNotNull(uniqueFieldMap);
        assertNotNull(uniqueFieldDocumentList);
        assertEquals(2, uniqueFieldDocumentList.size());
    }

    @Test
    public void testDoExecute_EmptyDocumentList() throws Exception {
        // Mock input variables

        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile);

        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "metadata.tin");

        // Use try-with-resources to mock WorkFlowUtil
        try (MockedStatic<WorkFlowUtil> mockedStatic = mockStatic(WorkFlowUtil.class)) {
            mockedStatic.when(() -> WorkFlowUtil.readDocumentsFromJsonFile(anyString(), anyString()))
                    .thenReturn(Collections.emptyList());

            // Execute the method
            groupDocumentsByMetadata.doExecute(execution);

            Map<String, Object> uniqueFieldMap = execution.getVariable("uniqueFieldMap", Map.class);
            List<DocumentMetaData> uniqueFieldDocumentList = execution.getVariable("uniqueFieldDocumentList", List.class);

            assertTrue(uniqueFieldMap.isEmpty());
            assertTrue(uniqueFieldDocumentList.isEmpty());
        }
    }

    @Test
    public void testDoExecute_NullDocumentList() throws Exception {
        // Mock input variables
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "metadata.tin");

        // Use try-with-resources to mock WorkFlowUtil
        try (MockedStatic<WorkFlowUtil> mockedStatic = mockStatic(WorkFlowUtil.class)) {
            mockedStatic.when(() -> WorkFlowUtil.readDocumentsFromJsonFile(anyString(), anyString()))
                    .thenReturn(null);

            // Execute the method
            groupDocumentsByMetadata.doExecute(execution);

            Map<String, Object> uniqueFieldMap = execution.getVariable("uniqueFieldMap", Map.class);
            List<DocumentMetaData> uniqueFieldDocumentList = execution.getVariable("uniqueFieldDocumentList", List.class);

            assertTrue(uniqueFieldMap.isEmpty());
            assertTrue(uniqueFieldDocumentList.isEmpty());
        }
    }
}