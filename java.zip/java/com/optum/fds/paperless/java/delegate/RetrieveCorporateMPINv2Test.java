package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;


import org.flowable.engine.delegate.DelegateExecution;
import org.assertj.core.util.Arrays;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.google.common.util.concurrent.RateLimiter;
import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.domain.service.HookServiceImpl;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.provider.pojo.PhysicianFacility;
import com.optum.fds.paperless.provider.pojo.PhysicianFacilityInformation;
import com.optum.fds.paperless.provider.pojo.SvcResponse;
import com.optum.fds.paperless.provider.pojo.TaxId;
import com.optum.fds.paperless.provider.pojo.TaxIdType;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.beans.FDSCloudGetDocumentsResponse;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.HookTransactionUtil;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.never;


public class RetrieveCorporateMPINv2Test {

	@InjectMocks
	RetrieveCorporateMPINv2 retrieveCorporateMpinV2;

	@Mock
	private RestTemplate restTemplate;

	@Mock
	private EhCache ehcache;

	@Mock
	private HookService hookService;

	@Mock
	private DocumentMetaDataService documentMetaDataService;

	@Mock
	private OauthManagerUtil oauthManagerUtil;
	
	@Value("${TRACKIT_SPACEID}")
	private static String trackitSpaceId = "11702";
	
	@Value("${MPIN_PES_TPS:60}")
	private static int mpinPesTps = 60;

	DelegateExecution execution;
	
	Optional<OauthTokenExtended> optionalToken;
	
	private static final String APP_ID = "testapp";
	private static final String APP_SECRET = "testapp";
	private static final String ACCESS_TOKEN = "abc123";
	private static final String URL = "http://test.com";
	private static final Integer EXPIRES_IN = 1800;

	@SuppressWarnings("deprecation")
	@Before
	public void init() {
		MockitoAnnotations.openMocks(this);
        execution = new DelegateExecutionImpl();
		
		execution.setVariable(Workflow.PES_APP_ID,APP_ID);
		execution.setVariable(Workflow.PES_OAUTH_URL, URL);
		execution.setVariable(Workflow.PES_APP_SECRET, APP_SECRET);
		execution.setVariable(Workflow.PES_GRANT_TYPE, "grant type");
		execution.setVariable(Workflow.PROV_APP_NAME, "test");
		execution.setVariable(Workflow.PROV_ATTRIBUTE_SET, "set");
		execution.setVariable(Workflow.PROV_COUNT, "1");
		execution.setVariable(Workflow.DOCID, "id123");
		execution.setVariable(Workflow.PROV_SEARCH_URL, "http://url.com");
		execution.setVariable(Workflow.SPACE_ID, "1234");	
		
		execution.setVariable(Workflow.HOOK_ID, "123456");
		
		OauthTokenExtended oauthTokenExtended = new OauthTokenExtended("testapp", "testapp");
		oauthTokenExtended.setAccessToken("abc1123");
		oauthTokenExtended.setExpiresIn(1800);
		oauthTokenExtended.setObtainedOn(new Date());
		
		when(hookService.getHookTransactionById(Mockito.anyString())).thenReturn(createHookTransaction());
        when(hookService.saveHookTransaction(Mockito.any())).thenReturn(createHookTransaction());

		List<String> spaceIdList = new ArrayList<>();
		spaceIdList.add("11702");
		spaceIdList.add("20302");

		ReflectionTestUtils.setField(retrieveCorporateMpinV2, "ssbciSpaceId", "20402");
		ReflectionTestUtils.setField(retrieveCorporateMpinV2, "alinkSpaceId", "20302");
		ReflectionTestUtils.setField(retrieveCorporateMpinV2, "trackitSpaceId", trackitSpaceId);
		ReflectionTestUtils.setField(retrieveCorporateMpinV2, "mpinPesTps", mpinPesTps);
		ReflectionTestUtils.setField(retrieveCorporateMpinV2, "trackItAndMnrSpaceIds", spaceIdList);
		ReflectionTestUtils.setField(retrieveCorporateMpinV2, "emailWorkflowSpaceIds", spaceIdList);

		optionalToken = Optional.of(oauthTokenExtended);
		
		when(oauthManagerUtil.getOauthTokenExtended(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), isNull()))
			.thenReturn(optionalToken);
		
		
	}

	@Test
	public void testDoExecuteException() throws Exception {
		HttpClientErrorException exception = HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST, null, null, null, null);

		when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class),
				ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<String>>any())).thenThrow(exception);

		List<DocumentMetaData> docList = new ArrayList<>();
		docList.add(getDocumentMetaDataWithCorporateMpinNull());
		when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);

		when(ehcache.getCorpMpinCache(Mockito.anyString())).thenReturn(null);

		retrieveCorporateMpinV2.execute(execution);

		Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
		assertNotNull(errorMap);

	}
	
	@Test
	public void testDoExecuteIsSuccessFromAPI() throws Exception {

		String responseBodyStr = getPhysicianFacilityResponseBody();

		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML_VALUE);

		ResponseEntity<String> response = new ResponseEntity<String>(responseBodyStr,
				headers,
				HttpStatus.OK);
		when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class),
				ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<String>>any())).thenReturn(response);

		List<DocumentMetaData> docList = new ArrayList<>();
		docList.add(getDocumentMetaDataWithCorporateMpinNull());
		when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);

		when(ehcache.getCorpMpinCache(Mockito.anyString())).thenReturn(null);

		retrieveCorporateMpinV2.execute(execution);

		Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
		assertNotNull(errorMap);

	}


	@SuppressWarnings({ "unchecked" })
	@Test
	public void testDoExecuteIsSuccessFromCache() {
		List<DocumentMetaData> docList = new ArrayList<>();
		docList.add(getDocumentMetaDataWithCorporateMpinNull());
		when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);

		when(ehcache.getCorpMpinCache(Mockito.anyString())).thenReturn("corpmpin123");
		retrieveCorporateMpinV2.execute(execution);

		Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
		assertNotNull(errorMap);
	}

	@Test
	public void testDoExecuteCorpMpinExists() {
		hookService = new HookServiceImpl();
		DocumentMetaData documentMetaData = getDocumentMetaDataWithCorporateMpinNull();
		documentMetaData.getMetadata().put("corporateMpin",  "1234");
		when(documentMetaDataService.getDocumentMetaData(Mockito.anyString())).thenReturn(documentMetaData);

		retrieveCorporateMpinV2.execute(execution);
		Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
		assertNotNull(errorMap);

	}

	@SuppressWarnings({ "unchecked" })
	@Test
	public void testDoExecuteADT() throws IOException {
		execution.setVariable(Workflow.SPACE_ID, "11702");
		
		
		List<DocumentMetaData> docList = new ArrayList<>();
		
		docList.add(getDocumentMetaDataEmptyTin());
		
		Map<String, List<String>> map = new HashMap<>();
		List<String> idList = new ArrayList<>();
		idList.add("id123");
		map.put("dfere444", idList);
		
    	execution.setVariable("uniqueFieldDocumentList", docList);
    	execution.setVariable("uniqueFieldMap", map);
		
		hookService = new HookServiceImpl();
		DocumentMetaData documentMetaData = getDocumentMetaDataWithCorporateMpinNull();
		when(documentMetaDataService.getDocumentMetaData(Mockito.anyString())).thenReturn(documentMetaData);
		
		
		String responseBodyStr = getPhysicianFacilityResponseBody();
				
		HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML_VALUE);

		ResponseEntity<String> response = new ResponseEntity<String>(responseBodyStr,
				headers,
				HttpStatus.OK);

		execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID_V2,"3007");
		when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class),
				ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<String>>any())).thenReturn(response);
		

		retrieveCorporateMpinV2.execute(execution);

		Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
	    assertNotNull(errorMap);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testDoExecuteWhenCorporateMpinBlank() {
		hookService = new HookServiceImpl();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		execution.setVariable(Workflow.DOCUMENT_METADATA, documentMetaData);
		when(documentMetaDataService.getDocumentMetaData(Mockito.anyString())).thenReturn(documentMetaData);
		retrieveCorporateMpinV2.execute(execution);
		Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
		assertNotNull(errorMap);
	}

	
	@Test
	public void testformatTin()
	{
		String actual = "236589658";
		String trimmedTin = "23658965878474".trim();
		String expected = trimmedTin.length() == 14 ? trimmedTin.substring(0, 9) : trimmedTin;
		retrieveCorporateMpinV2.formatTin(actual);
		assertEquals(actual, expected);
	}

	private DocumentMetaData getDocumentMetaData() {
		DocumentMetaData documentMetaData = new DocumentMetaData();
		documentMetaData.setId("id123");
		documentMetaData.setStatus(MetaDataStatus.ACTIVE);
		documentMetaData.setSpaceId(2804);
		documentMetaData.setExternalId("external1234");
		Document metadata = new Document();
		metadata.append("dateEmailSent", new Date()); //corporateMpin, tin
		metadata.append("corporateMpin", "dfere444");
		metadata.append("tin", "dfere444");
		documentMetaData.setMetadata(metadata);
		return documentMetaData;
	}
	
	private DocumentMetaData getDocumentMetaDataEmptyTin() {
		DocumentMetaData documentMetaData = new DocumentMetaData();
		documentMetaData.setId("id123");
		documentMetaData.setStatus(MetaDataStatus.ACTIVE);
		documentMetaData.setSpaceId(2804);
		documentMetaData.setExternalId("external1234");
		Document metadata = new Document();
		metadata.append("tin", "");
		documentMetaData.setMetadata(metadata);
		return documentMetaData;
	}
	
	private DocumentMetaData getDocumentMetaDataWithCorporateMpinNull() {
		DocumentMetaData documentMetaData = new DocumentMetaData();
		documentMetaData.setId("id123");
		documentMetaData.setStatus(MetaDataStatus.ACTIVE);
		documentMetaData.setSpaceId(2804);
		documentMetaData.setExternalId("external1234");
		Document metadata = new Document();
		metadata.append("dateEmailSent", new Date()); //corporateMpin, tin
		metadata.append("tin", "dfere444");
		documentMetaData.setMetadata(metadata);
		return documentMetaData;
	}
	
	private String getPhysicianFacilityResponseBody() throws IOException {
		PhysicianFacility physicianFacility = new PhysicianFacility();
		SvcResponse svc = new SvcResponse();
		PhysicianFacilityInformation pfi = new PhysicianFacilityInformation();
		TaxIdType taxId = new TaxIdType();
		taxId.setcorpMPIN("12345");
		List<TaxIdType> taxIdList = new ArrayList<>();
		taxIdList.add(taxId);
		pfi.setTaxId(taxIdList);
		physicianFacility.setSvcResponse(svc);
		svc.setPhysicianFacilityInformation(pfi);
		pfi.setFirstName("VIVIAN");
		pfi.setMiddleName("ELIZABETH \"LISA\"");
		pfi.setLastName("HUDDLESTON");

		return Parser.toXML(physicianFacility);
	}
	
	private HookTransactionMetaData createHookTransaction() {
    	HookTransactionMetaData hook = new HookTransactionMetaData();
    	hook.setSpaceId(3006);
    	hook.setId("12345");
    	hook.setClientId(123);
    	hook.setAppIdentifier("1234556677");
    	hook.setHookExecutionList(new ArrayList<>());
    	return hook;
    }

	@Test
	public void testDoExecuteWithMissingTIN() {
		execution.setVariable(Workflow.SPACE_ID, "ssbciSpaceId");
		execution.setVariable(Workflow.TIN, "");

		List<DocumentMetaData> docList = new ArrayList<>();
		docList.add(getDocumentMetaDataEmptyTin());
		when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);

		retrieveCorporateMpinV2.execute(execution);

		Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
		assertNotNull(errorMap);
		verify(hookService, times(2)).saveHookTransaction(Mockito.any());
	}

	@Test
	public void testDoExecuteWithMissingCorporateMpin() throws IOException {
		execution = new DelegateExecutionImpl();

		execution.setVariable(Workflow.PES_APP_ID,APP_ID);
		execution.setVariable(Workflow.PES_OAUTH_URL, URL);
		execution.setVariable(Workflow.PES_APP_SECRET, APP_SECRET);
		execution.setVariable(Workflow.PES_GRANT_TYPE, "grant type");
		execution.setVariable(Workflow.PROV_APP_NAME, "test");
		execution.setVariable(Workflow.PROV_ATTRIBUTE_SET, "set");
		execution.setVariable(Workflow.PROV_COUNT, "1");
		execution.setVariable(Workflow.DOCID, "id123");
		execution.setVariable(Workflow.PROV_SEARCH_URL, "http://url.com");
		execution.setVariable(Workflow.SPACE_ID, "10602");

		execution.setVariable(Workflow.TIN, "123456789");
		execution.setVariable(Workflow.HOOK_ID, "123456");

		List<DocumentMetaData> docList = new ArrayList<>();
		docList.add(getDocumentMetaDataWithCorporateMpinNull());
		when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);
		when(ehcache.getCorpMpinCache(Mockito.anyString())).thenReturn(null);

//		when(retrieveCorporateMpinV2.getMpinFromSvcs(Mockito.any(), Mockito.anyString(), Mockito.any()))
//				.thenReturn("987654321");

		String responseBodyStr = getPhysicianFacilityResponseBody();
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML_VALUE);
		ResponseEntity<String> response = new ResponseEntity<String>(responseBodyStr,
				headers,
				HttpStatus.OK);
		execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID_V2,"3007");
		when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class),
				ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<String>>any())).thenReturn(response);


		retrieveCorporateMpinV2.doExecute(execution);

		verify(ehcache, times(1)).putCorpMpinCache(Mockito.anyString(), Mockito.anyString());
		verify(documentMetaDataService, times(1)).saveDocumentMetaData(Mockito.any());
	}

	@Test
	public void testDoExecuteWithExistingCorporateMpin() {
		execution.setVariable(Workflow.SPACE_ID, "ssbciSpaceId");
		execution.setVariable(Workflow.TIN, "123456789");

		List<DocumentMetaData> docList = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		documentMetaData.getMetadata().put(Workflow.PROV_CORP_MPIN, "123456789");
		docList.add(documentMetaData);

		when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);

		retrieveCorporateMpinV2.execute(execution);

		verify(ehcache, never()).putCorpMpinCache(Mockito.anyString(), Mockito.anyString());
		verify(documentMetaDataService, never()).saveDocumentMetaData(Mockito.any());
	}
}
