package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.jcraft.jsch.JSchException;
import com.optum.fds.paperless.domain.service.DocumentMetaDataServiceImpl;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.java.delegate.SendFileToSFTP.Params;

import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.util.SftpUtil;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;

@RunWith(MockitoJUnitRunner.class)
public class SendFileToSFTPTest {

    private final String TEST = "test";

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Mock
    DocumentMetaDataServiceImpl documentMetaDataService;

    @Mock
    EmailService emailService;
    
    @Mock
    ErrorMetaDataService errorMetaDataService;

    DelegateExecution execution = new DelegateExecutionImpl();

    @InjectMocks
    SendFileToSFTP sendFileToSFTP;

    @Mock
    SftpUtil sftpUtil;
    
    @Mock
    Params params;


    private static final Integer MAX_SFTP_TRIES = 2;
    private static final Long RETRY_TIME_SECS = 2L;

    @Before
    public void setUp() throws Exception {

        execution.setVariable(Workflow.SFTP_HOSTNAME,"rn000019322.uhc.com");
        execution.setVariable(Workflow.SFTP_USERNAME, "pren");
        execution.setVariable(Workflow.SFTP_USERNAME_ARC, "pren");
        execution.setVariable(Workflow.SFTP_PW,"uaHs7pvA");
        execution.setVariable(Workflow.SFTP_PW_ARC,"uaHs7pvA");
        execution.setVariable(Workflow.SFTP_DIRECTORY,"/dropzone/integration/");

        ArrayList<String> fileList = new ArrayList<String>();
        fileList.add(Utilities.getInstance().getResourceFile("zippedfile1.zip").getAbsolutePath());
        fileList.add(Utilities.getInstance().getResourceFile("good.zip").getAbsolutePath());

        execution.setVariable(Workflow.SFTP_FILE_LIST, fileList);
        execution.setVariable(Workflow.EMAIL_RECEIVER, TEST);
        execution.setVariable(Workflow.ENVIRONMENT, TEST);
        execution.setVariable(Workflow.MAX_SFTP_TRIES, MAX_SFTP_TRIES);
        execution.setVariable(Workflow.RETRY_TIME_SECS, RETRY_TIME_SECS);

        when(emailService.sendEmail(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
//        when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());

    }

    @UserStory(references = "US24817")
    @RallyTestCase(references = "TC29296")
    @Test
    public void testExecutionWithNoArchiveDirectory() throws Exception {
        sendFileToSFTP.execute(execution);
        assertNotNull(sendFileToSFTP.errorMap);
        assertEquals(0, sendFileToSFTP.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US24817")
    @RallyTestCase(references = "TC29297")
    @Test
    public void testExecutionWithArchiveDirectory() throws Exception {
        execution.setVariable(Workflow.SFTP_ARCHIVE_DIRECTORY,"/dropzone/integration/");
        sendFileToSFTP.execute(execution);
        assertNotNull(sendFileToSFTP.errorMap);
        assertEquals(0, sendFileToSFTP.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US24817")
    @RallyTestCase(references = "TC29298")
    @Test
    public void testExecutionWithInvalidArchiveDirectory() throws Exception {
        execution.setVariable(Workflow.SFTP_ARCHIVE_DIRECTORY,"/dropzone/integration/123/");
        sendFileToSFTP.execute(execution);
        assertNotNull(sendFileToSFTP.errorMap);
        assertEquals(0, sendFileToSFTP.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US24817")
    @RallyTestCase(references = "TC29299")
    @Test
    public void testExecutionWithNullSFTPTargetDir() throws Exception {
        execution.setVariable(Workflow.SFTP_DIRECTORY,null);
        sendFileToSFTP.execute(execution);
        assertNotNull(sendFileToSFTP.errorMap);
        assertEquals(1, sendFileToSFTP.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US24817")
    @RallyTestCase(references = "TC29300")
    @Test
    public void testExecutionWithNullSFTPPassword() throws Exception {
        execution.setVariable(Workflow.SFTP_PW,null);
        sendFileToSFTP.execute(execution);
        assertNotNull(sendFileToSFTP.errorMap);
        assertEquals(1, sendFileToSFTP.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US24817")
    @RallyTestCase(references = "TC29301")
    @Test
    public void testExecutionWithNullSFTPFileList() throws Exception {
        execution.setVariable(Workflow.SFTP_FILE_LIST, null);
        sendFileToSFTP.execute(execution);
        assertNotNull(sendFileToSFTP.errorMap);
        assertEquals(1, sendFileToSFTP.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US24817")
    @RallyTestCase(references = "TC29302")
    @Test
    public void testExecutionWithBlankSFTPFileList() throws Exception {
        execution.setVariable(Workflow.SFTP_FILE_LIST, new ArrayList<String>());
        sendFileToSFTP.execute(execution);
        assertNotNull(sendFileToSFTP.errorMap);
        assertEquals(1, sendFileToSFTP.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US24817")
    @RallyTestCase(references = "TC29303")
    @Test
    public void testExecutionWithSFTPFileListWithInvalidFilePath() throws Exception {
        ArrayList<String> fileList = new ArrayList<String>();
        fileList.add("zippedfile2.zip");
        execution.setVariable(Workflow.MAX_SFTP_TRIES, null);
        execution.setVariable(Workflow.RETRY_TIME_SECS, null);
        execution.setVariable(Workflow.SFTP_FILE_LIST, new ArrayList<String>());
        sendFileToSFTP.execute(execution);
        assertNotNull(sendFileToSFTP.errorMap);
        assertEquals(1, sendFileToSFTP.errorMap.get(Workflow.NEW_ERRORS));
    }

//    @UserStory(references = "")
//    @RallyTestCase(references = "")
//    @Test
//    public void testExecutionWithException() throws Exception {
////        new Expectations() {{
////            sftpUtil.moveFileFromLocalToSFTPLocation(anyString, anyString, anyString, anyInt, anyString, anyString, anyInt, anyLong ); result = new JSchException();
////        }};
//        sendFileToSFTP.execute(execution);
//        assertTrue(sendFileToSFTP.errorMap.size()>1);
//    }
       

}

