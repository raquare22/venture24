package com.optum.fds.paperless.java.delegate.docvault;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.java.delegate.DelegateExecutionImpl;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;



public class UpdateDocumentListDocvaultTest {
    
    @Mock
    DocumentMetaDataService documentMetaDataService;
    
    @Spy
    UpdateDocumentListDocvault updateSpy;
	
    @InjectMocks
	UpdateDocumentListDocvault updateDocumentListDocvault;
    
    @Mock
    ErrorMetaDataService errorMetaDataService;
	
    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
    }
    
//    @Test
//    public void testEmptyList() throws IOException {
//       DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
//       List<DocumentMetaData> dataList = new ArrayList<>();
//       execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, dataList);
//       updateDocumentListDocvault.getDocumentListFromExecutionBus(execution);
//    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void testExecuteNoData() throws Exception {
       DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
       updateDocumentListDocvault.execute(execution);
       Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
       assertThat("There is data", (String) errorMap.get("NoData"), containsString("is empty"));
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void testExecuteNotEmptyList() throws Exception {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        when(documentMetaDataService.saveDocumentMetaData(Mockito.any())).thenReturn(documentMetaData);
       DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
       
       List<DocumentMetaData> dataList = new ArrayList<>();
       dataList.add(documentMetaData);
       execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, dataList);
       updateDocumentListDocvault.execute(execution);
       Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
       assertThat("There are errors", errorMap.get("newErrors"), equalTo(0));
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void testExecuteFlag() throws Exception {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setMetadata(new Document());
        when(documentMetaDataService.saveDocumentMetaData(Mockito.any())).thenReturn(documentMetaData);
       DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
       List<DocumentMetaData> dataList = new ArrayList<>();
       dataList.add(documentMetaData);
       execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, dataList);
       execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, true);
       execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "metadata");
       updateDocumentListDocvault.execute(execution);
       Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
       assertThat("There are errors", errorMap.get("newErrors"), equalTo(0));
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void testExecuteFlagFalse() throws Exception {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setMetadata(new Document());
        documentMetaData.setId(null);
        when(documentMetaDataService.saveDocumentMetaData(Mockito.any())).thenReturn(documentMetaData);
       DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
       List<DocumentMetaData> dataList = new ArrayList<>();
       dataList.add(documentMetaData);
       execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, dataList);
       execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, false);
       execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "metadata");
       updateDocumentListDocvault.execute(execution);
       Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
       assertThat("There are errors", errorMap.get("newErrors"), equalTo(0));
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void testExecuteFlagFalse2() throws Exception {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setMetadata(new Document());
        documentMetaData.setId("id1234");
       when(documentMetaDataService.saveDocumentMetaData(Mockito.any())).thenReturn(documentMetaData);
       DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
       List<DocumentMetaData> dataList = new ArrayList<>();
       dataList.add(documentMetaData);
       execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, dataList);
       execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, false);
       execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "metadata");
       updateDocumentListDocvault.execute(execution);
       Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
       assertThat("There are errors", errorMap.get("newErrors"), equalTo(0));
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void testExecuteFlagFalseNull() throws Exception {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setMetadata(new Document());
        documentMetaData.setId("id1234");
        when(documentMetaDataService.saveDocumentMetaData(Mockito.any())).thenReturn(null);
       DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
       List<DocumentMetaData> dataList = new ArrayList<>();
       dataList.add(documentMetaData);
       execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, dataList);
       execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "metadata");
       updateDocumentListDocvault.execute(execution);
       Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
       assertThat("There are errors", errorMap.get("newErrors"), equalTo(1));
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void testExecuteCorrelationIds() throws Exception {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setMetadata(new Document());
        documentMetaData.setId("id1234");
        when(documentMetaDataService.saveDocumentMetaData(Mockito.any())).thenReturn(null);
       DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
       List<DocumentMetaData> dataList = new ArrayList<>();
       dataList.add(documentMetaData);
       execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, dataList);
       Map<String, String> correlationIds = new HashMap<>();
       correlationIds.put("aKey", "aValue");
       execution.setVariable(Workflow.CORRELATION_IDS, correlationIds);
       execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "metadata");
       updateDocumentListDocvault.execute(execution);
       Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
       assertThat("There are errors", errorMap.get("newErrors"), equalTo(1));
    }
    
    @Test
    public void testSetSentToDocvault() {
        DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setMetadata(new Document());
        documentMetaData.setId("id1234");
        
        List<DocumentAttachmentMetaData> documentAttachmentList = new ArrayList<>();
        DocumentAttachmentMetaData docAtt = new DocumentAttachmentMetaData();
        docAtt.setFsId("1234-5678");
        docAtt.setName("test.pdf");
        docAtt.setIndex(1);
        documentAttachmentList.add(docAtt);
        
        documentMetaData.setDocumentAttachments(documentAttachmentList);
        
        List<DocumentMetaData> documentMetaDataList = new ArrayList<>();
        documentMetaDataList.add(documentMetaData);
        when(documentMetaDataService.saveDocumentMetaData(Mockito.any())).thenReturn(documentMetaData);
        updateDocumentListDocvault.updateDocumentsWithService(execution, documentMetaDataList);
    }

}
