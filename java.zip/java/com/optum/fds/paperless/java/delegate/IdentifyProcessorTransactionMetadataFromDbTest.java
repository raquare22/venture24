package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.io.FileUtils;
import org.bson.Document;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.constants.ProcessKeys;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import com.optum.fds.paperless.processing.service.ProcessorTransactionsService;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;

@RunWith(MockitoJUnitRunner.class)
public class IdentifyProcessorTransactionMetadataFromDbTest {

	@Rule
	public TemporaryFolder folder = new TemporaryFolder();

	@Mock
	ProcessorTransactionsService processorTransactionsService;

	@Mock
	ErrorMetaDataService errorMetaDataService;

	@Mock
	EmailService emailService;

	ConfigData configData;

	DelegateExecution execution;

	@InjectMocks
	IdentifyProcessorTransactionMetadataFromDb ref;

	Document execVars = new Document();

	@Before
	public void setUp() throws FSDataException {
		execution = new DelegateExecutionImpl();
		execution.setVariable(Workflow.PROCESS_KEY, ProcessKeys.EMAIL_PROCESSOR_TRANSACTION_METADATA_PROCESS_KEY);

		when(emailService.sendEmail(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
	}

	//@Test
	public void testGetProcessorTransactionFromDB() throws Exception {

		List<ProcessorTransactionMetadata> list = new ArrayList<>();
		list.add(getProcessorTransactionMetadata());
		list.add(getProcessorTransactionMetadata());

		when(processorTransactionsService.getProcessorTransactionMetaData(Mockito.anyString(), Mockito.any()))
				.thenReturn(list);
		ref.execute(execution);
		File fileList[] = folder.getRoot().listFiles();
		assertTrue(fileList.length != 0);
		assertNotNull(execution.getVariable(Workflow.JSON_FILE));
		assertNotNull(execution.getVariable(Workflow.OUTPUT_FILE_DIR));
	}

	
	@Test
	public void testInvalidVarialbleDataSearchCriteriaInExecutionBus() throws Exception {
		
		execution.setVariable(Workflow.SEARCH_CRITERIA, "{\"$configSpaceId\": 10068 }");
		execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"2\",\"format\":\"Days\"}}");
		execution.setVariable(Workflow.EMAIL_RECEIVER, "test@test.com");
		execution.setVariable(Workflow.ENVIRONMENT, "test");
		
		ref.execute(execution);
		assertTrue(ref.errorMap.size() > 1);
	}

	
	@Test
	public void testInvalidVarialbleDataSearchWindowInExecutionBus() throws Exception {
		execution.setVariable(Workflow.SEARCH_CRITERIA, "{\"configSpaceId\": 10068 }");
		execution.setVariable(Workflow.SEARCH_WINDOW,  "{\"start_date_offset\":{\"$time_window\":\"2\",\"format\":\"Hours\"}}");
		execution.setVariable(Workflow.EMAIL_RECEIVER, "test@test.com");
		execution.setVariable(Workflow.ENVIRONMENT, "test");
		
		ref.execute(execution);
		assertTrue(ref.errorMap.size() > 1);
	}

	
	@Test
	public void testInvalidVarialbleDataSearchCriteriaWithoutConfigSpaceIdInExecutionBus() throws Exception {
		execution.setVariable(Workflow.SEARCH_CRITERIA, "{ }");
		execution.setVariable(Workflow.SEARCH_WINDOW,  "{\"start_date_offset\":{\"$time_window\":\"2\",\"format\":\"Hours\"}}");
		execution.setVariable(Workflow.EMAIL_RECEIVER, "test@test.com");
		execution.setVariable(Workflow.ENVIRONMENT, "test");

		ref.execute(execution);
		assertTrue(ref.errorMap.size() > 1);
	}
	
	@Test
	public void testInvalidVarialbleDataSearchCriteriaWithoutEmailRecieverInExecutionBus() throws Exception {
		execution.setVariable(Workflow.SEARCH_CRITERIA, "{\\\"configSpaceId\\\": 10068 }");
		execution.setVariable(Workflow.SEARCH_WINDOW,  "{\"start_date_offset\":{\"$time_window\":\"2\",\"format\":\"Hours\"}}");
		execution.setVariable(Workflow.EMAIL_RECEIVER, "");
		execution.setVariable(Workflow.ENVIRONMENT, "test");

		ref.execute(execution);
		assertTrue(ref.errorMap.size() > 1); 
	}

	
	@Test
	public void testInvalidVarialbleDataSearchWindowWithoutRequiredAttributesInExecutionBus() throws Exception {
		execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"format\":\"Hours\"}}");
		execution.setVariable(Workflow.SEARCH_CRITERIA, "{ }");
		execution.setVariable(Workflow.EMAIL_RECEIVER, "test@test.com");
		execution.setVariable(Workflow.ENVIRONMENT, "test");

		ref.execute(execution);
		assertTrue(ref.errorMap.size() > 1);
	}

	
	@Test
	public void testEmptyDataForInputFields() throws Exception {
		
		execution.setVariable(Workflow.SEARCH_CRITERIA, "{\"configSpaceId\": 10068 }");
		execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"2\",\"format\":\"Days\"}}");
		execution.setVariable(Workflow.EMAIL_RECEIVER, "test@test.com");
		execution.setVariable(Workflow.ENVIRONMENT, "test");
		
		ArrayList<ProcessorTransactionMetadata> list = new ArrayList<>();
		when(processorTransactionsService.getProcessorTransactionMetaData(Mockito.anyString(), Mockito.any()))
				.thenReturn(list);
		ref.execute(execution);
		assertTrue(ref.errorMap.size() <= 1);
	}

	//@Test
	public void testGetProcessorTransactionFromDBJsonFileFormat() throws Exception {
		ArrayList<ProcessorTransactionMetadata> list = new ArrayList<>();
		list.add(getProcessorTransactionMetadata());
		list.add(getProcessorTransactionMetadata());
		when(processorTransactionsService.getProcessorTransactionMetaData(Mockito.anyString(), Mockito.any()))
				.thenReturn(list);
		ref.execute(execution);
		File folderList[] = folder.getRoot().listFiles();
		assertTrue(folderList.length != 0);
		assertTrue(execution.getVariable(Workflow.JSON_FILE) != null);
		System.out.println(FileUtils.readFileToString(new File((String) execution.getVariable(Workflow.JSON_FILE))));
	}

	
	@Test
	public void testGetProcessorTransactionFromDBWithException() throws Exception {
		
		execution.setVariable(Workflow.SEARCH_CRITERIA, "{\"configSpaceId\": 10068 }");
		execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"2\",\"format\":\"Days\"}}");
		execution.setVariable(Workflow.EMAIL_RECEIVER, "test@test.com");
		execution.setVariable(Workflow.ENVIRONMENT, "test");
		
		Mockito.doThrow(new InvalidExpressionException("filter should be logical query expresssion"))
				.when(processorTransactionsService).getProcessorTransactionMetaData(Mockito.anyString(), Mockito.any());
		ref.execute(execution);
		assertTrue(ref.errorMap.size() > 1);
	}
	
	@Test
	public void testGetProcessorTransactionFromDBWithIoException() throws Exception {
		
		execution.setVariable(Workflow.SEARCH_CRITERIA, "{\"configSpaceId\": 10068 }");
		execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"2\",\"format\":\"Days\"}}");
		execution.setVariable(Workflow.EMAIL_RECEIVER, "test@test.com");
		execution.setVariable(Workflow.ENVIRONMENT, "test");
		
		Mockito.doThrow(new NullPointerException("An Exception occured"))
				.when(processorTransactionsService).getProcessorTransactionMetaData(Mockito.anyString(), Mockito.any());
		ref.execute(execution);
		assertTrue(ref.errorMap.size() > 1);
	}

	
	@Test
	public void testGetProcessorTransactionFromDBWithNullSearchWindow() throws Exception {
		
		execution.setVariable(Workflow.SEARCH_CRITERIA, null);
		execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"2\",\"format\":\"Days\"}}");
		execution.setVariable(Workflow.EMAIL_RECEIVER, "test@test.com");
		execution.setVariable(Workflow.ENVIRONMENT, "test");

		ref.execute(execution);
		Assert.assertTrue(ref.errorMap.size() > 1);
	}
	
	@Test
	public void testGetProcessorTransactionFromDBWithNullEmailReciever() throws Exception {
		
		execution.setVariable(Workflow.SEARCH_CRITERIA, "{\"configSpaceId\": 10068 }");
		execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"2\",\"format\":\"Days\"}}");
		execution.setVariable(Workflow.EMAIL_RECEIVER, null);
		execution.setVariable(Workflow.ENVIRONMENT, "test");

		ref.execute(execution);
		Assert.assertTrue(ref.errorMap.size() <= 1); 
	}
	
	@Test
	public void testGetProcessorTransactionFromDBWithNullEmailRecieverAndSearchCriteria() throws Exception {
		
		execution.setVariable(Workflow.SEARCH_CRITERIA, null);
		execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"2\",\"format\":\"Days\"}}");
		execution.setVariable(Workflow.EMAIL_RECEIVER, null);
		execution.setVariable(Workflow.ENVIRONMENT, "test");

		ref.execute(execution);
		Assert.assertTrue(ref.errorMap.size() > 1);
	}
	
	@Test
	public void testGetProcessorTransactionFromDBWithNullEmailRecieverSearchCriteriaAndSearchWindow() throws Exception {
		
		execution.setVariable(Workflow.SEARCH_CRITERIA, null);
		execution.setVariable(Workflow.SEARCH_WINDOW, null);
		execution.setVariable(Workflow.EMAIL_RECEIVER, null);
		execution.setVariable(Workflow.ENVIRONMENT, "test");

		ref.execute(execution);
		Assert.assertTrue(ref.errorMap.size() > 1);
	}
	
	@Test
	public void testGetProcessorTransactionFromDBWithAllNullVariables() throws Exception {
		
		execution.setVariable(Workflow.SEARCH_CRITERIA, null);
		execution.setVariable(Workflow.SEARCH_WINDOW, null);
		execution.setVariable(Workflow.EMAIL_RECEIVER, null);
		execution.setVariable(Workflow.ENVIRONMENT, null);

		ref.execute(execution);
		Assert.assertTrue(ref.errorMap.size() > 1);
	}
	
	@Test
	public void testGetProcessorTransactionFromDBWithEmailRecieverMissing() throws Exception {
		
		execution.setVariable(Workflow.SEARCH_CRITERIA, null);
		execution.setVariable(Workflow.SEARCH_WINDOW, null);
//		execution.setVariable(Workflow.EMAIL_RECEIVER, null);
		execution.setVariable(Workflow.ENVIRONMENT, null);

		ref.execute(execution);
		Assert.assertTrue(ref.errorMap.size() > 1);
	}
	
	@Test
	public void testGetProcessorTransactionFromDBWithNoVariable() throws Exception {

		ref.execute(execution);
		Assert.assertTrue(ref.errorMap.size() > 1);
	}


	ProcessorTransactionMetadata getProcessorTransactionMetadata() {
		ProcessorTransactionMetadata processorTransactionMetadata = new ProcessorTransactionMetadata();
		processorTransactionMetadata.setProcessorRecordType(ProcessorRecordTypes.processorTransactionMetadata);
		processorTransactionMetadata.setAppIdentifier("testapp");
		processorTransactionMetadata.setTransactionId("1234");
		processorTransactionMetadata.getSummary();
		processorTransactionMetadata.setStartTime();
		processorTransactionMetadata.setId("123");
		processorTransactionMetadata.setStatus("IN_PROCESS");
		return processorTransactionMetadata;
	}

}