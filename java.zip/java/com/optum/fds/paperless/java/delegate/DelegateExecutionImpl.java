package com.optum.fds.paperless.java.delegate;

import org.flowable.bpmn.model.FlowableListener;
import org.flowable.bpmn.model.FlowElement;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.ReadOnlyDelegateExecution;
import org.flowable.variable.api.persistence.entity.VariableInstance;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DelegateExecutionImpl implements DelegateExecution {

    Map<String, Object> delegateMap;

    public DelegateExecutionImpl(Map<String, Object> delegateMap) {
        this.delegateMap = delegateMap;
    }

    public DelegateExecutionImpl() {
        this(new HashMap<>());
    }

    @Override
    public String getId() {
        return null;
    }
    @Override
    public String getProcessInstanceId() {
        return null;
    }
    @Override
    public String getRootProcessInstanceId() {
        return null;
    }
    @Override
    public String getEventName() {
        return null;
    }
    @Override
    public void setEventName(String eventName) {

    }
    @Override
    public String getProcessInstanceBusinessKey() {
        return null;
    }
    @Override
    public String getProcessDefinitionId() {
        return null;
    }


    @Override
    public String getPropagatedStageInstanceId() {
        return null;
    }

    @Override
    public String getParentId() {
        return null;
    }
    @Override
    public String getSuperExecutionId() {
        return null;
    }
    @Override
    public String getCurrentActivityId() {
        return null;
    }

    @Override
    public String getCurrentActivityName() {
        return null;
    }

    @Override
    public String getTenantId() {
        return null;
    }
    @Override
    public FlowElement getCurrentFlowElement() {
        return null;
    }
    @Override
    public void setCurrentFlowElement(FlowElement flowElement) {

    }

    @Override
    public FlowableListener getCurrentFlowableListener() {
        return null;
    }

    @Override
    public String getProcessInstanceBusinessStatus() {
        return null;
    }

    @Override
    public void setCurrentFlowableListener(FlowableListener currentListener) { }

    @Override
    public ReadOnlyDelegateExecution snapshotReadOnly() {
        return null;
    }

    @Override
    public DelegateExecution getParent() {
        return null;
    }
    @Override
    public List<? extends DelegateExecution> getExecutions() {
        return null;
    }
    @Override
    public void setActive(boolean isActive) {

    }
    @Override
    public boolean isActive() {
        return false;
    }
    @Override
    public boolean isEnded() {
        return false;
    }
    @Override
    public void setConcurrent(boolean isConcurrent) {

    }
    @Override
    public boolean isConcurrent() {
        return false;
    }
    @Override
    public boolean isProcessInstanceType() {
        return false;
    }
    @Override
    public void inactivate() {

    }
    @Override
    public boolean isScope() {
        return false;
    }
    @Override
    public void setScope(boolean isScope) {

    }
    @Override
    public boolean isMultiInstanceRoot() {
        return false;
    }
    @Override
    public void setMultiInstanceRoot(boolean isMultiInstanceRoot) {

    }

    @Override
    public Map<String, Object> getVariables() {
        return delegateMap;
    }

    @Override
    public Map<String, VariableInstance> getVariableInstances() {
        return null;
    }
    @Override
    public Map<String, Object> getVariables(Collection<String> variableNames) {
        return null;
    }
    @Override
    public Map<String, VariableInstance> getVariableInstances(Collection<String> variableNames) {
        return null;
    }

    @Override
    public Map<String, Object> getVariables(Collection<String> variableNames, boolean fetchAllVariables) {
        return delegateMap;
    }

    @Override
    public Map<String, VariableInstance> getVariableInstances(Collection<String> variableNames, boolean fetchAllVariables) {
        return null;
    }
    @Override
    public Map<String, Object> getVariablesLocal() {
        return null;
    }
    @Override
    public Map<String, VariableInstance> getVariableInstancesLocal() {
        return null;
    }
    @Override
    public Map<String, Object> getVariablesLocal(Collection<String> variableNames) {
        return null;
    }
    @Override
    public Map<String, VariableInstance> getVariableInstancesLocal(Collection<String> variableNames) {
        return null;
    }
    @Override
    public Map<String, Object> getVariablesLocal(Collection<String> variableNames, boolean fetchAllVariables) {
        return null;
    }
    @Override
    public Map<String, VariableInstance> getVariableInstancesLocal(Collection<String> variableNames, boolean fetchAllVariables) {
        return null;
    }

    @Override
    public Object getVariable(String variableName) {
        return delegateMap.get(variableName);
    }

    @Override
    public VariableInstance getVariableInstance(String variableName) {
        return null;
    }
    @Override
    public Object getVariable(String variableName, boolean fetchAllVariables) {
        return null;
    }
    @Override
    public VariableInstance getVariableInstance(String variableName, boolean fetchAllVariables) {
        return null;
    }
    @Override
    public Object getVariableLocal(String variableName) {
        return null;
    }
    @Override
    public VariableInstance getVariableInstanceLocal(String variableName) {
        return null;
    }
    @Override
    public Object getVariableLocal(String variableName, boolean fetchAllVariables) {
        return null;
    }
    @Override
    public VariableInstance getVariableInstanceLocal(String variableName, boolean fetchAllVariables) {
        return null;
    }

    @Override
    public <T> T getVariable(String variableName, Class<T> variableClass) {
        return variableClass.cast(delegateMap.get(variableName));
    }

    @Override
    public <T> T getVariableLocal(String variableName, Class<T> variableClass) {
        return null;
    }
    @Override
    public Set<String> getVariableNames() {
        return new HashSet<>();
    }
    @Override
    public Set<String> getVariableNamesLocal() {
        return null;
    }
    @Override
    public void setVariable(String variableName, Object value) {
        delegateMap.put(variableName, value);
    }
    @Override
    public void setVariable(String variableName, Object value, boolean fetchAllVariables) {

    }
    @Override
    public Object setVariableLocal(String variableName, Object value) {
        return null;
    }
    @Override
    public Object setVariableLocal(String variableName, Object value, boolean fetchAllVariables) {
        return null;
    }
    @Override
    public void setVariables(Map<String, ?> variables) {

    }
    @Override
    public void setVariablesLocal(Map<String, ?> variables) {

    }
    @Override
    public boolean hasVariables() {
        return false;
    }
    @Override
    public boolean hasVariablesLocal() {
        return false;
    }
    @Override
    public boolean hasVariable(String variableName) {
        return false;
    }
    @Override
    public boolean hasVariableLocal(String variableName) {
        return false;
    }
    @Override
    public void removeVariable(String variableName) {

    }
    @Override
    public void removeVariableLocal(String variableName) {

    }
    @Override
    public void removeVariables(Collection<String> variableNames) {

    }
    @Override
    public void removeVariablesLocal(Collection<String> variableNames) {

    }
    @Override
    public void removeVariables() {

    }
    @Override
    public void removeVariablesLocal() {

    }
    @Override
    public void setTransientVariable(String variableName, Object variableValue) {
    	delegateMap.put(variableName, variableValue);
    }
    @Override
    public void setTransientVariableLocal(String variableName, Object variableValue) {

    }
    @Override
    public void setTransientVariables(Map<String, Object> transientVariables) {

    }
    @Override
    public Object getTransientVariable(String variableName) {
    	return delegateMap.get(variableName);
    }
    @Override
    public Map<String, Object> getTransientVariables() {
        return delegateMap;
    }
    @Override
    public void setTransientVariablesLocal(Map<String, Object> transientVariables) {

    }
    @Override
    public Object getTransientVariableLocal(String variableName) {
        return null;
    }
    @Override
    public Map<String, Object> getTransientVariablesLocal() {
        return null;
    }
    @Override
    public void removeTransientVariableLocal(String variableName) {

    }
    @Override
    public void removeTransientVariable(String variableName) {

    }
    @Override
    public void removeTransientVariables() {

    }
    @Override
    public void removeTransientVariablesLocal() {

    }
}
