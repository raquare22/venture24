package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.util.concurrent.RateLimiter;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import org.springframework.web.client.RestTemplate;


@RunWith(MockitoJUnitRunner.class)
public class SendDocumentToPENRealTimeTest {

    @InjectMocks
    private SendDocumentToPENRealTime sendDocumentToPENRealTime;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private RestTemplate restTemplate;
    
	@Mock
	private OauthManagerUtil oauthManagerUtil;
	
	Optional<OauthTokenExtended> optionalToken;

    private DelegateExecution execution = new DelegateExecutionImpl();

    private static final String DOC_CRITERIA = "{\"metadata.merged\":true}";
    private static final String SEARCH_WINDOW = "{\"start_date_offset\":{\"time_window\":\"72\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"0\",\"format\":\"Hours\"}}";


    // Define @Value fields manually in the test setup
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        List<String> spaceIds = new ArrayList<>();
        spaceIds.add("11702");
        spaceIds.add("20702");
        spaceIds.add("11902");
        spaceIds.add( "20302");
        spaceIds.add( "20402");
        spaceIds.add( "20502");

        // Set @Value fields using ReflectionTestUtils
        ReflectionTestUtils.setField(sendDocumentToPENRealTime, "PEN_TPS", 5);
        ReflectionTestUtils.setField(sendDocumentToPENRealTime, "penBatchUrl", "http://pen-batch-url");
        ReflectionTestUtils.setField(sendDocumentToPENRealTime, "penBatchDynamicTemplateUrl", "http://pen-batch-template-url");
        ReflectionTestUtils.setField(sendDocumentToPENRealTime, "penMultiCloudEnv", "stage");
        ReflectionTestUtils.setField(sendDocumentToPENRealTime, "oauthEnabled", "true");
        ReflectionTestUtils.setField(sendDocumentToPENRealTime, "penBatchMultiCloudUrl", "http://pen-batch-multi-cloud-url");
        ReflectionTestUtils.setField(sendDocumentToPENRealTime, "penBatchMultiCloudDynamicTemplateUrl", "http://pen-batch-multi-cloud-template-url");
        ReflectionTestUtils.setField(sendDocumentToPENRealTime, "dynamicMetadataSpaceIdList", spaceIds);

        execution.setVariable(Workflow.SEARCH_CRITERIA, DOC_CRITERIA);
        execution.setVariable(Workflow.SEARCH_WINDOW, SEARCH_WINDOW);
        execution.setVariable(Workflow.PEN_OAUTH_URL, "http://oauth");
        execution.setVariable(Workflow.PEN_APP_ID, "appid");
        execution.setVariable(Workflow.PEN_APP_SECRET, "secret");
        execution.setVariable(Workflow.PEN_GRANT_TYPE, "granttype");
    }
    /**
     * Test the doExecute method when the document list is non-empty.
     * It should process the documents accordingly.
     */
    @Test
    public void testDoExecuteADTCNS() throws Exception {
        execution.setVariable(Workflow.SPACE_ID, 11702);
        execution.setVariable(Workflow.TEMPLATE_NAME, "ADTCNSEmailRequestToPEN");
        execution.setVariable(Workflow.CLIENT_NAME, "TRACKITADT");

        DocumentMetaData doc1 = new DocumentMetaData();
        doc1.setId("doc1");
        doc1.setSpaceId(11702);
        Document metadata1 = new Document();
        Map<String, Object> recordInfoMap = new HashMap<>();
        recordInfoMap.put("recordType", "EMERGENCY");
        metadata1.put("tin", "tin1");
        metadata1.put("corporateMpin", "12345");
        metadata1.put("providerName", "provider name");
        metadata1.put("providerEmailId", "test@email.com");
        metadata1.put("recordInfo", recordInfoMap);
        doc1.setMetadata(metadata1);
        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "tin");

        List<DocumentMetaData> documentList = Collections.singletonList(doc1);

        execution.setVariable("uniqueFieldDocumentList", documentList);
        List<String> list = Collections.singletonList("doc1");
        Map<String, List<String>> uniqueMap = new HashMap<>();
        uniqueMap.put("tin1", list);
        execution.setVariable("uniqueFieldMap", uniqueMap);
        String response = "{\n" +
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"OK\",\n" +
                "    \"responseMessage\": \"{\\\"templateName\\\":\\\"TrackIt\\\",\\\"messageId\\\":\\\"<11702-933670129.1210.1747072943015@fds-pen-batch-stage-f5cfdc67-68fnh>\\\"}\"\n" +
                "}";
        ResponseEntity<String> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);

//        when(restTemplate.postForEntity(anyString(), any(), eq(String.class))).thenReturn(responseEntity);
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), Mockito.eq(String.class)))
                .thenReturn(responseEntity);
        when(documentMetaDataService.getDocumentMetaDataIds(anyString(), any(), any())).thenReturn(list);
        sendDocumentToPENRealTime.execute(execution);

        System.out.println(doc1.getMetadata());
        assertNotNull(sendDocumentToPENRealTime.errorMap);
        assertEquals(0, sendDocumentToPENRealTime.errorMap.get("newErrors"));

    }

    @Test
    public void testDoExecuteTrackIt() throws Exception {
        execution.setVariable(Workflow.SPACE_ID, 20702);
        execution.setVariable(Workflow.TEMPLATE_NAME, "TrackItEmailRequestToPEN");
        execution.setVariable(Workflow.CLIENT_NAME, "TRACKIT");
        execution.setVariable(Workflow.SKIP_DOCUMENT_GROUPING, "true");

        DocumentMetaData doc1 = new DocumentMetaData();
        doc1.setId("doc1");
        doc1.setSpaceId(20702);
        Document metadata1 = new Document();
        List<Map<String, Object>> recordCountList = new ArrayList<>();
        Map<String, Object> recordInfoMap = new HashMap<>();
        recordInfoMap.put("recordType", "type");
        recordInfoMap.put("tin", "tin1");
        recordInfoMap.put("corpMpin", "12345");
        recordInfoMap.put("providerName", "provider name");
        recordInfoMap.put("dailyRejectedClaimsActionRequiredCount", "0");

        recordCountList.add(recordInfoMap);
        metadata1.put("recordID", "123");
        metadata1.put("providerEmailId", "test@email.com");
        metadata1.put("recordsCountList", recordCountList);
        doc1.setMetadata(metadata1);

        List<DocumentMetaData> documentList = Collections.singletonList(doc1);

        execution.setVariable("uniqueFieldDocumentList", documentList);
        List<String> list = Collections.singletonList("doc1");
        Map<String, List<String>> uniqueMap = new HashMap<>();
        uniqueMap.put("tin1", list);
        execution.setVariable("uniqueFieldMap", uniqueMap);
        String response = "{\n" +
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"OK\",\n" +
                "    \"responseMessage\": \"{\\\"templateName\\\":\\\"TrackIt\\\",\\\"messageId\\\":\\\"<11702-933670129.1210.1747072943015@fds-pen-batch-stage-f5cfdc67-68fnh>\\\"}\"\n" +
                "}";
        ResponseEntity<String> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), Mockito.eq(String.class)))
                .thenReturn(responseEntity);
        sendDocumentToPENRealTime.execute(execution);

        System.out.println(doc1.getMetadata());
        assertNotNull(sendDocumentToPENRealTime.errorMap);
        assertEquals(0, sendDocumentToPENRealTime.errorMap.get("newErrors"));

    }

    @Test
    public void testDoExecuteSSBCI() throws Exception {
        execution.setVariable(Workflow.SPACE_ID, 20402);
        execution.setVariable(Workflow.TEMPLATE_NAME, "ADTCNSEmailRequestToPEN");
        execution.setVariable(Workflow.CLIENT_NAME, "SSBCI");
        execution.setVariable(Workflow.NO_OF_BUSINESS_DAYS, 2);
        execution.setVariable(Workflow.EMAIL_TERMINATION_WINDOW, 60);

        LocalDateTime date = LocalDateTime.of(
                LocalDate.now().minusDays(10),
                LocalTime.of(12, 0)
        );

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:SS.SSS'Z'");
        String dateEmailSent = formatter.format(date);

        List<String> lastDateEmailSentList = new ArrayList<>();
        lastDateEmailSentList.add(dateEmailSent);

        DocumentMetaData doc1 = new DocumentMetaData();
        doc1.setId("doc1");
        doc1.setSpaceId(11702);
        Document metadata1 = new Document();
        Map<String, Object> recordInfoMap = new HashMap<>();
        recordInfoMap.put("recordType", "ADMITs");
        metadata1.put("tin", "tin1");
        metadata1.put("corporateMpin", "12345");
        metadata1.put("providerName", "provider name");
        metadata1.put("providerEmailId", "test@email.com");
        metadata1.put("dateEmailSent", dateEmailSent);
        metadata1.put(Workflow.LAST_DATE_EMAIL_SENT_LIST, lastDateEmailSentList);
        metadata1.put("recordInfo", recordInfoMap);
        doc1.setMetadata(metadata1);
        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "tin");

        List<DocumentMetaData> documentList = Collections.singletonList(doc1);

        execution.setVariable("uniqueFieldDocumentList", documentList);
        List<String> list = Collections.singletonList("doc1");
        Map<String, List<String>> uniqueMap = new HashMap<>();
        uniqueMap.put("tin1", list);
        execution.setVariable("uniqueFieldMap", uniqueMap);
        String response = "{\n" +
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"OK\",\n" +
                "    \"responseMessage\": \"{\\\"templateName\\\":\\\"TrackIt\\\",\\\"messageId\\\":\\\"<11702-933670129.1210.1747072943015@fds-pen-batch-stage-f5cfdc67-68fnh>\\\"}\"\n" +
                "}";
        ResponseEntity<String> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);

//        when(restTemplate.postForEntity(anyString(), any(), eq(String.class))).thenReturn(responseEntity);
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), Mockito.eq(String.class)))
                .thenReturn(responseEntity);
        when(documentMetaDataService.getDocumentMetaDataIds(anyString(), any(), any())).thenReturn(list);
        sendDocumentToPENRealTime.execute(execution);

        assertNotNull(sendDocumentToPENRealTime.errorMap);
        assertEquals(0, sendDocumentToPENRealTime.errorMap.get("newErrors"));

    }

    @Test
    public void testDoExecuteSSBCIAfterTerminationWindow() throws Exception {
        execution.setVariable(Workflow.SPACE_ID, 20402);
        execution.setVariable(Workflow.TEMPLATE_NAME, "ADTCNSEmailRequestToPEN");
        execution.setVariable(Workflow.CLIENT_NAME, "SSBCI");
        execution.setVariable(Workflow.NO_OF_BUSINESS_DAYS, 2);
        execution.setVariable(Workflow.EMAIL_TERMINATION_WINDOW, 60);

        LocalDateTime date = LocalDateTime.of(
                LocalDate.now().minusDays(80),
                LocalTime.of(12, 0)
        );

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:SS.SSS'Z'");
        String dateEmailSent = formatter.format(date);

        List<String> lastDateEmailSentList = new ArrayList<>();
        lastDateEmailSentList.add(dateEmailSent);

        DocumentMetaData doc1 = new DocumentMetaData();
        doc1.setId("doc1");
        doc1.setSpaceId(11702);
        Document metadata1 = new Document();
        Map<String, Object> recordInfoMap = new HashMap<>();
        recordInfoMap.put("recordType", "ADMITs");
        metadata1.put("tin", "tin1");
        metadata1.put("corporateMpin", "12345");
        metadata1.put("providerName", "provider name");
        metadata1.put("providerEmailId", "test@email.com");
        metadata1.put("dateEmailSent", dateEmailSent);
        metadata1.put(Workflow.LAST_DATE_EMAIL_SENT_LIST, lastDateEmailSentList);
        metadata1.put("recordInfo", recordInfoMap);
        doc1.setMetadata(metadata1);
        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "tin");

        List<DocumentMetaData> documentList = Collections.singletonList(doc1);

        execution.setVariable("uniqueFieldDocumentList", documentList);
        List<String> list = Collections.singletonList("doc1");
        Map<String, List<String>> uniqueMap = new HashMap<>();
        uniqueMap.put("tin1", list);
        execution.setVariable("uniqueFieldMap", uniqueMap);

        sendDocumentToPENRealTime.execute(execution);

        assertNotNull(sendDocumentToPENRealTime.errorMap);
        assertEquals(0, sendDocumentToPENRealTime.errorMap.get("newErrors"));

    }


    /**
     * Test the doExecute method when the spaceId does not match trackitSpaceId
     * and document list is non-empty. It should retrieve updatedDocumentMetadataList.
     */
    @Test
    public void testDoExecute_WithNonTrackitSpaceId() {
        execution.setVariable(Workflow.SPACE_ID, 11302);
        execution.setVariable(Workflow.TEMPLATE_NAME, "IHRDocumentTemplate");
        execution.setVariable(Workflow.CLIENT_NAME, "TRACKIT");

        DocumentMetaData doc1 = new DocumentMetaData();
        doc1.setId("doc1");
        doc1.setSpaceId(11302);
        Document metadata1 = new Document();
        metadata1.put("tin", "tin1");
        metadata1.put("corporateMpin", "12345");
        metadata1.put("providerName", "provider name");
        List<String> emailList = new ArrayList<>();
        emailList.add("test@email.com");
        emailList.add("test@email.com");
        emailList.add("test123@test.com");
        metadata1.put(Workflow.PROVIDER_EMAIL_ID_LIST, emailList);
        metadata1.put("providerEmailId", "test@email.com");
        doc1.setMetadata(metadata1);
        List<DocumentMetaData> documentList = Collections.singletonList(doc1);

        execution.setVariable("updatedDocumentMetadataList", documentList);
        List<String> list = Collections.singletonList("doc1");

        String response = "{\n" +
                "    \"statusCode\": \"200\",\n" +
                "    \"statusMessage\": \"OK\",\n" +
                "    \"responseMessage\": {\n" +
                "        \"documentId\": \"6509efb1c5326e657614e004\",\n" +
                "        \"appId\": \"11402\",\n" +
                "        \"category\": \"CC1\",\n" +
                "        \"frequency\": null,\n" +
                "        \"emailSent\": true,\n" +
                "        \"providerEmailIdList\": [\n" +
                "            \"jenny.j.wang@optum.com\",\n" +
                "            \"jennytest@optumtest.com\"\n" +
                "        ],\n" +
                "        \"messageIdList\": {\n" +
                "            \"jenny.j.wang@optum.com\": \"11402-586012433.1206.1747072911561@fds-pen-batch-stage-f5cfdc67-68fnh\",\n" +
                "            \"jennytest@optumtest.com\": \"11402-1478492087.1208.1747072911574@fds-pen-batch-stage-f5cfdc67-68fnh\"\n" +
                "        }\n" +
                "    }\n" +
                "}";
        ResponseEntity<String> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);

//        when(restTemplate.postForEntity(anyString(), any(), eq(String.class))).thenReturn(responseEntity);
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), Mockito.eq(String.class)))
                .thenReturn(responseEntity);
        sendDocumentToPENRealTime.execute(execution);

        assertNotNull(sendDocumentToPENRealTime.errorMap);
        assertEquals(0, sendDocumentToPENRealTime.errorMap.get("newErrors"));
    }

    
    @Test
    public void testPostDocument() {

        
        ReflectionTestUtils.setField(sendDocumentToPENRealTime, "oauthEnabled", "true");


        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), Mockito.eq(String.class)))
                .thenReturn(new ResponseEntity<>("created", new HttpHeaders(), HttpStatus.CREATED));

        ResponseEntity<String> response = sendDocumentToPENRealTime.postDocument(execution, "http://penmulticloud", createDocumentMetaData().toString());
        assertNotNull(response);
    }

    @Test
    public void testProcessDocumentList_WithEmptyProviderEmailId() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc1");
        doc.setSpaceId(11702);
        Document metadata = new Document();
        metadata.put("tin", "tin1");
        metadata.put("providerEmailId", ""); // Empty email ID
        doc.setMetadata(metadata);

        List<DocumentMetaData> documentList = Collections.singletonList(doc);
        execution.setVariable("uniqueFieldDocumentList", documentList);
        execution.setVariable(Workflow.CLIENT_NAME, "TRACKIT");

        List<String> result = sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                new HashMap<>(),
                RateLimiter.create(5),
                false,  // skipDocumentGrouping
                false);

        assertTrue(result.isEmpty());
        verifyNoInteractions(restTemplate);
    }

    @Test
    public void testPreparePayload() throws JsonProcessingException {
        DocumentMetaData document = new DocumentMetaData();
        document.setId("doc1");
        document.setSpaceId(1234);
        Document metadata = new Document();
        metadata.put("category", "TestCategory");
        document.setMetadata(metadata);

        Set<String> providerEmailList = new HashSet<>(Arrays.asList("email1@test.com", "email2@test.com"));
        DelegateExecution execution = mock(DelegateExecution.class);

        String result = sendDocumentToPENRealTime.preparePayload(document, providerEmailList, execution);

        assertTrue(result.contains("\"documentId\":\"doc1\""));
        assertTrue(result.contains("\"appId\":\"1234\""));
        assertTrue(result.contains("\"category\":\"TestCategory\""));
    }

    @Test
    public void testCheckBusinessDaysPassed() {
        LocalDateTime lastEmailSentDate = LocalDateTime.of(2023, 9, 25, 0, 0); // Monday
        int noOfBusinessDays = 5;

        boolean result = sendDocumentToPENRealTime.checkbusinessDaysPassed(lastEmailSentDate, noOfBusinessDays);

        assertTrue(result); // Assuming the current date is after 5 business days
    }


    @Test
    public void testCheckDuplicateEmails_UsingReflection() throws Exception {
        // Arrange
        SendDocumentToPENRealTime sendDocumentToPENRealTime = new SendDocumentToPENRealTime();
        Set<String> providerEmailsSent = new HashSet<>(Arrays.asList("email1@test.com", "email2@test.com"));
        List<String> providerEmailList = Arrays.asList("email2@test.com", "email3@test.com", "email4@test.com");

        // Access the private method using reflection
        Method method = SendDocumentToPENRealTime.class.getDeclaredMethod("checkDuplicateEmails", Set.class, List.class);
        method.setAccessible(true);

        // Act
        @SuppressWarnings("unchecked")
        Set<String> result = (Set<String>) method.invoke(sendDocumentToPENRealTime, providerEmailsSent, providerEmailList);

        // Assert
        assertEquals(2, result.size());
        assertTrue(result.contains("email3@test.com"));
        assertTrue(result.contains("email4@test.com"));
    }



    @Test
    public void testProcessDocumentList_TryBlockExecution() throws Exception {
        // Arrange
        DelegateExecution execution = mock(DelegateExecution.class);
        DocumentMetaData document = new DocumentMetaData();
        document.setId("doc1");
        document.setSpaceId(1234);
        Document metadata = new Document();
        metadata.put(Workflow.DATE_EMAIL_SENT, "2023-09-25T00:00:00.000Z");
        metadata.put(Workflow.LAST_DATE_EMAIL_SENT_LIST, List.of("2023-09-20T00:00:00.000Z"));
        document.setMetadata(metadata);

        List<DocumentMetaData> documentList = Collections.singletonList(document);
        Map<String, List<String>> uniqueFieldMap = new HashMap<>();
        uniqueFieldMap.put("uniqueFieldValue", List.of("doc1"));

        // Act
        List<String> result = sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                uniqueFieldMap,
                RateLimiter.create(5),
                false,
                false);

        // Assert
        assertNotNull(result);
    }

    @Test
    public void testProcessDocumentList_UniqueFieldMapContainsKey() {
        // Arrange
        DelegateExecution execution = mock(DelegateExecution.class);
        DocumentMetaData document = new DocumentMetaData();
        document.setId("doc1");
        document.setSpaceId(1234);
        Document metadata = new Document();
        metadata.put("uniqueField", "fieldValue");
        document.setMetadata(metadata);

        List<DocumentMetaData> documentList = Collections.singletonList(document);
        Map<String, List<String>> uniqueFieldMap = new HashMap<>();
        uniqueFieldMap.put("fieldValue", Arrays.asList("doc1", "doc2"));

        when(execution.getVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, String.class)).thenReturn("uniqueField");

        List<String> result = sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                uniqueFieldMap,
                RateLimiter.create(5),
                false,
                false);

        assertNotNull(result);
    }


    /**
     * Helper method to create a sample DocumentMetaData object.
     */
    private DocumentMetaData createDocumentMetaData() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setId("doc1");
        documentMetaData.setSpaceId(1234);
        Document metadata = new Document();
        metadata.put("field1", "value1");
        documentMetaData.setMetadata(metadata);
        return documentMetaData;
    }

    @Test
    public void testProcessDocumentList_PCPMemberReferralSkipNonInProcess() {
        execution.setVariable(Workflow.CLIENT_NAME, "PCPMEMBERREFERRAL");
        execution.setVariable(Workflow.SPACE_ID, "20402");

        DocumentMetaData document = new DocumentMetaData();
        document.setId("doc1");
        document.setSpaceId(20402);
        Document metadata = new Document();
        metadata.put("tin", "tin1");
        metadata.put("corporateMpin", "12345");
        metadata.put("requestId", "ref123");
        metadata.put("referralStatus", "APPROVED");
        document.setMetadata(metadata);

        List<DocumentMetaData> documentList = Collections.singletonList(document);
        execution.setVariable("uniqueFieldDocumentList", documentList);

        List<String> result = sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                new HashMap<>(),
                RateLimiter.create(5),
                false,
                false);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testProcessDocumentList_PCPMemberReferralNoReminderEmail() {
        execution.setVariable(Workflow.CLIENT_NAME, "PCPMEMBERREFERRAL");
        execution.setVariable(Workflow.SPACE_ID, "20402");
        execution.setVariable(Workflow.NO_OF_DAYS, 7); // Reminder window

        LocalDateTime lastEmailSentDate = LocalDateTime.now().minusDays(5); // Reminder window not elapsed
        String dateEmailSent = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
                .format(lastEmailSentDate);

        DocumentMetaData document = new DocumentMetaData();
        document.setId("doc1");
        document.setSpaceId(20402);
        Document metadata = new Document();
        metadata.put("tin", "tin1");
        metadata.put("corporateMpin", "12345");
        metadata.put("requestId", "ref123");
        metadata.put("referralStatus", "IN_PROCESS");
        metadata.put(Workflow.DATE_EMAIL_SENT, dateEmailSent);
        document.setMetadata(metadata);

        List<DocumentMetaData> documentList = Collections.singletonList(document);
        execution.setVariable("uniqueFieldDocumentList", documentList);

        List<String> result = sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                new HashMap<>(),
                RateLimiter.create(5),
                false,
                false);

        assertNotNull(result);
        assertTrue(result.isEmpty()); // No reminder email should be sent
    }

    @Test
    public void testProcessDocumentList_PCPMemberReferralTerminationWindowExceeded() {
        execution.setVariable(Workflow.CLIENT_NAME, "PCPMEMBERREFERRAL");
        execution.setVariable(Workflow.SPACE_ID, "20402");
        execution.setVariable(Workflow.EMAIL_TERMINATION_WINDOW, 30); // Termination window

        LocalDateTime firstEmailSentDate = LocalDateTime.now().minusDays(40); // Termination window exceeded
        String dateEmailSent = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
                .format(firstEmailSentDate);

        DocumentMetaData document = new DocumentMetaData();
        document.setId("doc1");
        document.setSpaceId(20402);
        Document metadata = new Document();
        metadata.put("tin", "tin1");
        metadata.put("corporateMpin", "12345");
        metadata.put("requestId", "ref123");
        metadata.put("referralStatus", "IN_PROCESS");
        metadata.put(Workflow.DATE_EMAIL_SENT, dateEmailSent);
        document.setMetadata(metadata);

        List<DocumentMetaData> documentList = Collections.singletonList(document);
        execution.setVariable("uniqueFieldDocumentList", documentList);

        List<String> result = sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                new HashMap<>(),
                RateLimiter.create(5),
                false,
                false);

        assertNotNull(result);
        assertTrue(result.isEmpty()); // No email should be sent
    }

    @Test
    public void testEmailValidationFiltersInvalidEmailsAndUpdatesMetadata() {
        execution.setVariable(Workflow.SPACE_ID, 20702);
        execution.setVariable(Workflow.CLIENT_NAME, "TRACKIT");
        execution.setVariable(Workflow.SKIP_DOCUMENT_GROUPING, "true");
        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "tin");
        execution.setVariable(Workflow.TEMPLATE_NAME, "TrackItEmailRequestToPEN");

        // Mix of valid and invalid emails joined by "|"
        String rawEmailIds = "valid@email.com|WWW.NEABAPTISTCLINIC.COM|INVALID_EMAIL|another@valid.org";

        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc-email-filter-test");
        doc.setSpaceId(20702);

        Document metadata = new Document();
        metadata.put("tin", "tin-test");
        metadata.put(Workflow.PROVIDER_EMAIL_ID, rawEmailIds);
        doc.setMetadata(metadata);

        System.out.println("[BEFORE] providerEmailId: " + doc.getMetadata().getString(Workflow.PROVIDER_EMAIL_ID));

        List<DocumentMetaData> documentList = Collections.singletonList(doc);
        execution.setVariable("uniqueFieldDocumentList", documentList);

        Map<String, List<String>> uniqueMap = new HashMap<>();
        uniqueMap.put("tin-test", Collections.singletonList("doc-email-filter-test"));
        execution.setVariable("uniqueFieldMap", uniqueMap);

        sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                uniqueMap,
                RateLimiter.create(5),
                true,
                false
        );

        String updatedEmailId = doc.getMetadata().getString(Workflow.PROVIDER_EMAIL_ID);
        System.out.println("[AFTER]  providerEmailId: " + updatedEmailId);

        // Only valid emails should remain
        assertNotNull("providerEmailId should not be null after filtering", updatedEmailId);
        assertTrue("Should contain valid@email.com", updatedEmailId.contains("valid@email.com"));
        assertTrue("Should contain another@valid.org", updatedEmailId.contains("another@valid.org"));
        assertFalse("Should NOT contain WWW.NEABAPTISTCLINIC.COM", updatedEmailId.contains("WWW.NEABAPTISTCLINIC.COM"));
        assertFalse("Should NOT contain INVALID_EMAIL", updatedEmailId.contains("INVALID_EMAIL"));
    }

    @Test
    public void testEmailValidationAllInvalidEmailsSkipsDocAndUpdatesErrorMetadata() {
        execution.setVariable(Workflow.SPACE_ID, 20702);
        execution.setVariable(Workflow.CLIENT_NAME, "TRACKIT");
        execution.setVariable(Workflow.SKIP_DOCUMENT_GROUPING, "true");
        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "tin");
        execution.setVariable(Workflow.TEMPLATE_NAME, "TrackItEmailRequestToPEN");

        // Only invalid emails
        String rawEmailIds = "WWW.NEABAPTISTCLINIC.COM|INVALID_EMAIL|NOT_AN_EMAIL";

        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc-all-invalid-email-test");
        doc.setSpaceId(20702);

        Document metadata = new Document();
        metadata.put("tin", "tin-test2");
        metadata.put(Workflow.PROVIDER_EMAIL_ID, rawEmailIds);
        doc.setMetadata(metadata);

        System.out.println("[BEFORE] providerEmailId: " + doc.getMetadata().getString(Workflow.PROVIDER_EMAIL_ID));

        List<DocumentMetaData> documentList = Collections.singletonList(doc);
        execution.setVariable("uniqueFieldDocumentList", documentList);

        Map<String, List<String>> uniqueMap = new HashMap<>();
        uniqueMap.put("tin-test2", Collections.singletonList("doc-all-invalid-email-test"));
        execution.setVariable("uniqueFieldMap", uniqueMap);

        List<String> result = sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                uniqueMap,
                RateLimiter.create(5),
                true,
                false
        );

        String updatedEmailId = doc.getMetadata().getString(Workflow.PROVIDER_EMAIL_ID);
        System.out.println("[AFTER]  providerEmailId (unchanged, eDelivery error set): " + updatedEmailId);

        String eDeliveryError = doc.getMetadata().getString("eDeliveryError");
        System.out.println("[AFTER]  eDeliveryError: " + eDeliveryError);

        System.out.println("[RESULT] documentUpdateList: " + result);

        assertEquals("providerEmailId should remain unchanged", rawEmailIds, updatedEmailId);

        // Document should be skipped — not in the update list
        assertTrue("documentUpdateList should be empty when all emails are invalid", result.isEmpty());

        // documentMetaDataService.updateDocMetaData should have been called (eDelivery error update)
        verify(documentMetaDataService, times(1)).updateDocMetaData(any(DocumentMetaData.class), anyString());

        // No PEN API call should be made
        verifyNoInteractions(restTemplate);
    }

    @Test
    public void testEmailValidationAppealsStatus_FiltersInvalidEmailsAndUpdatesMetadata() {
        execution.setVariable(Workflow.SPACE_ID, 20702);
        execution.setVariable(Workflow.CLIENT_NAME, "AppealsStatus");
        execution.setVariable(Workflow.SKIP_DOCUMENT_GROUPING, "true");
        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "tin");
        execution.setVariable(Workflow.TEMPLATE_NAME, "AppealsStatusEmailRequestToPEN");

        // Mix of valid and invalid emails joined by "|"
        String rawEmailIds = "valid@email.com|WWW.NEABAPTISTCLINIC.COM|INVALID_EMAIL|another@valid.org";

        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc-appeals-filter-test");
        doc.setSpaceId(20702);

        Document metadata = new Document();
        metadata.put("tin", "tin-appeals");
        metadata.put(Workflow.PROVIDER_EMAIL_ID, rawEmailIds);
        doc.setMetadata(metadata);

        System.out.println("[BEFORE] providerEmailId: " + doc.getMetadata().getString(Workflow.PROVIDER_EMAIL_ID));

        List<DocumentMetaData> documentList = Collections.singletonList(doc);
        execution.setVariable("uniqueFieldDocumentList", documentList);

        Map<String, List<String>> uniqueMap = new HashMap<>();
        uniqueMap.put("tin-appeals", Collections.singletonList("doc-appeals-filter-test"));
        execution.setVariable("uniqueFieldMap", uniqueMap);

        // Mock documentMetaDataService.getDocumentMetaDataList — required by AppealsStatus block
        when(documentMetaDataService.getDocumentMetaDataList(anyList())).thenReturn(Collections.singletonList(doc));

        sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                uniqueMap,
                RateLimiter.create(5),
                true,
                false
        );

        String updatedEmailId = doc.getMetadata().getString(Workflow.PROVIDER_EMAIL_ID);
        System.out.println("[AFTER]  providerEmailId: " + updatedEmailId);

        // Only valid emails should remain
        assertNotNull("providerEmailId should not be null after filtering", updatedEmailId);
        assertTrue("Should contain valid@email.com", updatedEmailId.contains("valid@email.com"));
        assertTrue("Should contain another@valid.org", updatedEmailId.contains("another@valid.org"));
        assertFalse("Should NOT contain WWW.NEABAPTISTCLINIC.COM", updatedEmailId.contains("WWW.NEABAPTISTCLINIC.COM"));
        assertFalse("Should NOT contain INVALID_EMAIL", updatedEmailId.contains("INVALID_EMAIL"));
    }

    @Test
    public void testEmailValidationAppealsStatus_AllInvalidEmailsSkipsDocAndUpdatesErrorMetadata() {
        execution.setVariable(Workflow.SPACE_ID, 20702);
        execution.setVariable(Workflow.CLIENT_NAME, "AppealsStatus");
        execution.setVariable(Workflow.SKIP_DOCUMENT_GROUPING, "true");
        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "tin");
        execution.setVariable(Workflow.TEMPLATE_NAME, "AppealsStatusEmailRequestToPEN");

        // Only invalid emails
        String rawEmailIds = "WWW.NEABAPTISTCLINIC.COM|INVALID_EMAIL|NOT_AN_EMAIL";

        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc-appeals-all-invalid-test");
        doc.setSpaceId(20702);

        Document metadata = new Document();
        metadata.put("tin", "tin-appeals2");
        metadata.put(Workflow.PROVIDER_EMAIL_ID, rawEmailIds);
        doc.setMetadata(metadata);

        System.out.println("[BEFORE] providerEmailId: " + doc.getMetadata().getString(Workflow.PROVIDER_EMAIL_ID));

        List<DocumentMetaData> documentList = Collections.singletonList(doc);
        execution.setVariable("uniqueFieldDocumentList", documentList);

        Map<String, List<String>> uniqueMap = new HashMap<>();
        uniqueMap.put("tin-appeals2", Collections.singletonList("doc-appeals-all-invalid-test"));
        execution.setVariable("uniqueFieldMap", uniqueMap);

        // Mock documentMetaDataService.getDocumentMetaDataList — required by AppealsStatus block
        when(documentMetaDataService.getDocumentMetaDataList(anyList())).thenReturn(Collections.singletonList(doc));

        List<String> result = sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                uniqueMap,
                RateLimiter.create(5),
                true,
                false
        );

        String updatedEmailId = doc.getMetadata().getString(Workflow.PROVIDER_EMAIL_ID);
        String eDeliveryError = doc.getMetadata().getString("eDeliveryError");
        System.out.println("[AFTER]  providerEmailId (unchanged, eDelivery error set): " + updatedEmailId);
        System.out.println("[AFTER]  eDeliveryError: " + eDeliveryError);
        System.out.println("[RESULT] documentUpdateList: " + result);

        // providerEmailId should remain unchanged — eDelivery error was set instead
        assertEquals("providerEmailId should remain unchanged", rawEmailIds, updatedEmailId);

        // Document should be skipped — not in the update list
        assertTrue("documentUpdateList should be empty when all emails are invalid", result.isEmpty());

        // documentMetaDataService.updateDocMetaData should have been called (eDelivery error update)
        verify(documentMetaDataService, times(1)).updateDocMetaData(any(DocumentMetaData.class), anyString());

        // No PEN API call should be made
        verifyNoInteractions(restTemplate);
    }

    @Test
    public void testProcessDocumentList_NullProviderEmailId() {
        execution.setVariable(Workflow.SPACE_ID, 20702);
        execution.setVariable(Workflow.CLIENT_NAME, "TRACKIT");
        execution.setVariable(Workflow.SKIP_DOCUMENT_GROUPING, "true");
        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "tin");
        execution.setVariable(Workflow.TEMPLATE_NAME, "TrackItEmailRequestToPEN");

        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc-null-email-test");
        doc.setSpaceId(20702);

        Document metadata = new Document();
        metadata.put("tin", "tin-null");
        // providerEmailId intentionally NOT set — getString() will return null
        doc.setMetadata(metadata);

        System.out.println("[NULL EMAIL] providerEmailId: " + doc.getMetadata().getString(Workflow.PROVIDER_EMAIL_ID));

        List<DocumentMetaData> documentList = Collections.singletonList(doc);
        execution.setVariable("uniqueFieldDocumentList", documentList);

        Map<String, List<String>> uniqueMap = new HashMap<>();
        uniqueMap.put("tin-null", Collections.singletonList("doc-null-email-test"));

        List<String> result = sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                uniqueMap,
                RateLimiter.create(5),
                true,
                false
        );

        System.out.println("[RESULT] documentUpdateList: " + result);

        // Doc should be silently skipped — null providerEmailId logged as warn, no PEN call, no DB update
        assertTrue("documentUpdateList should be empty for null providerEmailId", result.isEmpty());
        verifyNoInteractions(restTemplate);
        verify(documentMetaDataService, never()).updateDocMetaData(any(DocumentMetaData.class), anyString());
    }

    @Test
    public void testProcessDocumentList_EmptyProviderEmailId() {
        execution.setVariable(Workflow.SPACE_ID, 20702);
        execution.setVariable(Workflow.CLIENT_NAME, "TRACKIT");
        execution.setVariable(Workflow.SKIP_DOCUMENT_GROUPING, "true");
        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "tin");
        execution.setVariable(Workflow.TEMPLATE_NAME, "TrackItEmailRequestToPEN");

        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc-empty-email-test");
        doc.setSpaceId(20702);

        Document metadata = new Document();
        metadata.put("tin", "tin-empty");
        metadata.put(Workflow.PROVIDER_EMAIL_ID, ""); // explicitly empty string
        doc.setMetadata(metadata);

        System.out.println("[EMPTY EMAIL] providerEmailId: '" + doc.getMetadata().getString(Workflow.PROVIDER_EMAIL_ID) + "'");

        List<DocumentMetaData> documentList = Collections.singletonList(doc);
        execution.setVariable("uniqueFieldDocumentList", documentList);

        Map<String, List<String>> uniqueMap = new HashMap<>();
        uniqueMap.put("tin-empty", Collections.singletonList("doc-empty-email-test"));

        List<String> result = sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                uniqueMap,
                RateLimiter.create(5),
                true,
                false
        );

        System.out.println("[RESULT] documentUpdateList: " + result);

        // Doc should be silently skipped — empty providerEmailId logged as warn, no PEN call, no DB update
        assertTrue("documentUpdateList should be empty for empty providerEmailId", result.isEmpty());
        verifyNoInteractions(restTemplate);
        verify(documentMetaDataService, never()).updateDocMetaData(any(DocumentMetaData.class), anyString());
    }

    @Test
    public void testProcessDocumentList_MalformedMetadata() {
        execution.setVariable(Workflow.SPACE_ID, 20702);
        execution.setVariable(Workflow.CLIENT_NAME, "TRACKIT");
        execution.setVariable(Workflow.SKIP_DOCUMENT_GROUPING, "true");
        execution.setVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, "tin");
        execution.setVariable(Workflow.TEMPLATE_NAME, "TrackItEmailRequestToPEN");

        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc-malformed-email-test");
        doc.setSpaceId(20702);

        Document metadata = new Document();
        metadata.put("tin", "tin-malformed");
        // Store providerEmailId as an Integer instead of String — getString() will throw ClassCastException
        metadata.put(Workflow.PROVIDER_EMAIL_ID, 12345);
        doc.setMetadata(metadata);

        System.out.println("[MALFORMED] providerEmailId raw value: " + doc.getMetadata().get(Workflow.PROVIDER_EMAIL_ID)
                + " (type: " + doc.getMetadata().get(Workflow.PROVIDER_EMAIL_ID).getClass().getSimpleName() + ")");

        List<DocumentMetaData> documentList = Collections.singletonList(doc);
        execution.setVariable("uniqueFieldDocumentList", documentList);

        Map<String, List<String>> uniqueMap = new HashMap<>();
        uniqueMap.put("tin-malformed", Collections.singletonList("doc-malformed-email-test"));

        List<String> result = sendDocumentToPENRealTime.processDocumentList(
                execution,
                documentList,
                "emailRequestToPEN",
                uniqueMap,
                RateLimiter.create(5),
                true,
                false
        );

        System.out.println("[RESULT] documentUpdateList: " + result);

        // Doc should be skipped gracefully — exception caught in validateAndFilterEmails try-catch,
        // error logged, returns null, caller continues to next doc
        assertTrue("documentUpdateList should be empty for malformed metadata", result.isEmpty());
        verifyNoInteractions(restTemplate);
        verify(documentMetaDataService, never()).updateDocMetaData(any(DocumentMetaData.class), anyString());
    }
}
