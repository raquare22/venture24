package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class CSVDeleteWorkingDirectoryTest {
	
	@InjectMocks
	CSVDeleteWorkingDirectory cSVDeleteWorkingDirectory;

	@Mock
	CsvProcessorService csvProcessorService;
	
	@Mock
	ErrorMetaDataService errorMetaDataService;
	
	@Mock
	CsvProcessorTransaction csvProcessorTransaction;
	
	DelegateExecution execution;

	@SuppressWarnings("deprecation")
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);
		
		Document execVars = new Document().append(Workflow.CSV_PROCESSOR_TRANSACTION, csvProcessorTransaction);

		when(execution.getVariables()).thenReturn(execVars);
		when(execution.getVariable(Workflow.CSV_PROCESSOR_TRANSACTION, CsvProcessorTransaction.class))
				.thenReturn(execVars.get(Workflow.CSV_PROCESSOR_TRANSACTION, CsvProcessorTransaction.class));
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testDoExecuteWithNoOutputDirectory() {
		when(csvProcessorTransaction.getId()).thenReturn("sdghsdhshd");
		when(csvProcessorTransaction.getLocation()).thenReturn("sdghsdhshd");
		cSVDeleteWorkingDirectory.doExecute(execution);
		Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
		assertTrue(errorMap == null);
	}
	
	@Test
	public void testDoExecuteWithNullId() throws Exception {
		
		when(csvProcessorTransaction.getId()).thenReturn(null);
		when(csvProcessorTransaction.getLocation()).thenReturn(null);
		cSVDeleteWorkingDirectory.doExecute(execution);

		assertNull(cSVDeleteWorkingDirectory.errorMap);
		
//		assertEquals(false, execution.getVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE));
//        assertEquals(false, execution.getVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE));
//        assertEquals(false, documentMetaData.getMetadata().getBoolean(Workflow.SEND_TO_DOCVAULT));
//        assertEquals(false, documentMetaData.getMetadata().getBoolean(Workflow.SEND_TO_SHUTTERFLY));
		
	}
}
