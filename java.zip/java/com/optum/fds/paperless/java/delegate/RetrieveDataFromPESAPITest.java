package com.optum.fds.paperless.java.delegate;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import com.google.common.util.concurrent.RateLimiter;
import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.provider.pojo.PhysicianFacility;
import com.optum.fds.paperless.provider.pojo.PhysicianFacilityInformation;
import com.optum.fds.paperless.provider.pojo.SvcResponse;
import com.optum.fds.paperless.provider.pojo.TaxIdType;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.*;
import org.mockito.stubbing.Answer;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Element;

import java.io.IOException;
import java.util.*;

public class RetrieveDataFromPESAPITest {

    @InjectMocks
    private RetrieveDataFromPESAPI retrieveDataFromPESAPI;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private OauthManagerUtil oauthManagerUtil;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private EhCache ehCache;

    RateLimiter rateLimiter = mock(RateLimiter.class);

    private DelegateExecution execution = new DelegateExecutionImpl();

    private final String PATH_JSON_FILE = "InputJson/RetrieveDataFromPESAPIInputJson.json";

    private static final String APP_ID = "testapp";
    private static final String APP_SECRET = "testapp";
    private static final String ACCESS_TOKEN = "abc123";
    private static final String URL = "http://test.com";
    private static final Integer EXPIRES_IN = 1800;

    @Before
    public void setUp() {
        // Set up mocks
        MockitoAnnotations.initMocks(this);


        ReflectionTestUtils.setField(retrieveDataFromPESAPI, "PES_TPS",  5);

        execution.setVariable(Workflow.PROV_SEARCH_URL, "https://mockurl.com");
        execution.setVariable(Workflow.JSON_FILE, "");

        execution.setVariable(Workflow.PES_APP_ID, APP_ID);
        execution.setVariable(Workflow.PES_APP_SECRET, APP_SECRET);
        execution.setVariable(Workflow.PES_OAUTH_URL, ACCESS_TOKEN);
        execution.setVariable(Workflow.PES_GRANT_TYPE, "client_credentials");

        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID, APP_SECRET);
        oauthTokenExtended.setUrl(URL);
        oauthTokenExtended.setAccessToken(ACCESS_TOKEN);
        oauthTokenExtended.setExpiresIn(EXPIRES_IN);
        oauthTokenExtended.setObtainedOn(new Date());
        Optional<OauthTokenExtended> optionalToken = Optional.of(oauthTokenExtended);
        when(oauthManagerUtil.getOauthTokenExtended(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), isNull())).thenReturn(optionalToken);

        // Mock rate limiter behavior
        when(rateLimiter.tryAcquire()).thenReturn(true);

    }

    @Test
    public void testGetProviderDataPES() throws Exception {
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile);

        String responseBodyStr = getPhysicianFacilityResponseBody();
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML_VALUE);
        ResponseEntity<String> response = new ResponseEntity<String>(responseBodyStr,
                headers,
                HttpStatus.OK);
        when(restTemplate.exchange(ArgumentMatchers.anyString(), ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<String>>any())).thenReturn(response);


        DocumentMetaData documentMetaData = getDocumentMetaData();
        when(documentMetaDataService.getDocumentMetaData(Mockito.anyString())).thenReturn(documentMetaData);

        // Execute the method, mocking the ehcache
        try (MockedStatic<EhCache> cacheMock = Mockito.mockStatic(EhCache.class)) {
            cacheMock.when(() -> ehCache.getOauthTokenCache(Mockito.anyString())).thenReturn("test");
            cacheMock.when(() -> ehCache.putOauthTokenWithExpiry(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenAnswer((Answer<Void>) invocation -> null);
            retrieveDataFromPESAPI.doExecute(execution);
        }

        List<DocumentMetaData> updatedList = execution.getVariable("updatedDocumentMetadataList", List.class);
        Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
        assertNull(errorMap);
//        assertFalse(updatedList.isEmpty());

    }


    private DocumentMetaData getDocumentMetaData() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setId("id123");
        documentMetaData.setStatus(MetaDataStatus.ACTIVE);
        documentMetaData.setSpaceId(2804);
        documentMetaData.setExternalId("external1234");
        Document metadata = new Document();
        metadata.append("dateEmailSent", new Date()); //corporateMpin, tin
        metadata.append("tin", "dfere444");
        documentMetaData.setMetadata(metadata);
        return documentMetaData;
    }

    private String getPhysicianFacilityResponseBody() throws IOException {
        String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
                "<PhysicianFacilitySummary0002Response>\n" +
                "    <metadata>\n" +
                "        <versionNumber>4.3</versionNumber>\n" +
                "        <releaseType>Major</releaseType>\n" +
                "        <releaseDate>December 12, 2019</releaseDate>\n" +
                "        <supportContact>PES_SSMO - BDPaaS_SSMO_DL@ds.uhc.com</supportContact>\n" +
                "        <wildCardResp> </wildCardResp>\n" +
                "        <offset>0</offset>\n" +
                "        <psize>10</psize>\n" +
                "        <total>84</total>\n" +
                "        <elapsedPODMTime> </elapsedPODMTime>\n" +
                "        <elasticTime>57 MilliSeconds</elasticTime>\n" +
                "        <elapsedTime>73 MilliSeconds</elapsedTime>\n" +
                "    </metadata>\n" +
                "    <svcResponse>\n" +
                "        <physicianFacilityInformation>\n" +
                "            <providerId>000923666</providerId>\n" +
                "            <firstName></firstName>\n" +
                "            <lastName> </lastName>\n" +
                "            <middleName> </middleName>\n" +
                "            <suffix> </suffix>\n" +
                "            <facilityName>CARDIOLOGY CLINIC OF SAN ANTONIO</facilityName>\n" +
                "            <gender> </gender>\n" +
                "            <providerType>O</providerType>\n" +
                "            <providerClassification> </providerClassification>\n" +
                "            <contrBilTypCd>H</contrBilTypCd>\n" +
                "            <taxId>\n" +
                "                <taxIdType>T</taxIdType>\n" +
                "                <taxId>12345</taxId>\n" +
                "                <corpMPIN>12345</corpMPIN>\n" +
                "                <corporateOwnerFirstName>First</corporateOwnerFirstName>\n" +
                "                <corporateOwnerMiddleName>Last</corporateOwnerMiddleName>\n" +
                "                <corporateOwnerLastName>CARDIOLOGY CLINIC OF SAN ANTONIO</corporateOwnerLastName>\n" +
                "                <payeeProviderId>12345</payeeProviderId>\n" +
                "                <payeeFirstName> </payeeFirstName>\n" +
                "                <payeeMiddleName> </payeeMiddleName>\n" +
                "                <payeeLastName>CARDIOLOGY CLINIC OF SAN ANTONIO</payeeLastName>\n" +
                "                <provTierCode>1</provTierCode>\n" +
                "                <ptiIndicator>G</ptiIndicator>\n" +
                "                <topsTinPrefix></topsTinPrefix>\n" +
                "                <topsTinSuffix>00000</topsTinSuffix>\n" +
                "                <tpsm>\n" +
                "                    <tpsmInd>99Z</tpsmInd>\n" +
                "                    <tpsmDescription>DEFAULT VALUE</tpsmDescription>\n" +
                "                    <tpsmEffectiveDate>2016-04-22</tpsmEffectiveDate>\n" +
                "                    <tpsmCancelDate>9999-12-31</tpsmCancelDate>\n" +
                "                </tpsm>\n" +
                "                <preferredLabNetwork>N</preferredLabNetwork>\n" +
                "                <effectiveDate>2010-09-01</effectiveDate>\n" +
                "                <cancelDate>9999-12-31</cancelDate>\n" +
                "                <epsTypeCode>D</epsTypeCode>\n" +
                "                <epsTypeDescription>Direct Deposit</epsTypeDescription>\n" +
                "                <epsDate>2019-02-07</epsDate>\n" +
                "                <additionalPayTypeCode>N</additionalPayTypeCode>\n" +
                "            </taxId>\n" +
                "            <address>\n" +
                "                <addressId>001189875</addressId>\n" +
                "                <epdAddressSequenceId>000000031</epdAddressSequenceId>\n" +
                "                <primaryAddressIndicator>S</primaryAddressIndicator>\n" +
                "                <adrCareName></adrCareName>\n" +
                "                <addressTypeCode>L</addressTypeCode>\n" +
                "                <addressTypeDescription>PLACE OF SERVICE</addressTypeDescription>\n" +
                "                <postalAddress>\n" +
                "                    <addressLine1>8026 FLOYD CURL</addressLine1>\n" +
                "                    <addressLine2></addressLine2>\n" +
                "                    <city>SAN ANTONIO</city>\n" +
                "                    <county>BEXAR</county>\n" +
                "                    <state>TX</state>\n" +
                "                    <zip>78229</zip>\n" +
                "                    <zip4>3915</zip4>\n" +
                "                </postalAddress>\n" +
                "                <distance>0.00</distance>\n" +
                "                <addressContractOrg>\n" +
                "                    <contractOrgCode>BSAR</contractOrgCode>\n" +
                "                    <primaryCode>S</primaryCode>\n" +
                "                    <contrOrgEffDate>2015-10-09</contrOrgEffDate>\n" +
                "                    <contrOrgCancDate>9999-12-31</contrOrgCancDate>\n" +
                "                    <acceptingPatientsCode></acceptingPatientsCode>\n" +
                "                </addressContractOrg>\n" +
                "                <addressContractOrg>\n" +
                "                    <contractOrgCode>UHN</contractOrgCode>\n" +
                "                    <primaryCode>S</primaryCode>\n" +
                "                    <contrOrgEffDate>2015-10-09</contrOrgEffDate>\n" +
                "                    <contrOrgCancDate>9999-12-31</contrOrgCancDate>\n" +
                "                    <acceptingPatientsCode></acceptingPatientsCode>\n" +
                "                </addressContractOrg>\n" +
                "                <radiologyAreaCode>\n" +
                "                    <radiologyAreaCode> </radiologyAreaCode>\n" +
                "                    <zipCodeFrom> </zipCodeFrom>\n" +
                "                    <zipCodeTo> </zipCodeTo>\n" +
                "                </radiologyAreaCode>\n" +
                "                <extAddressLine1></extAddressLine1>\n" +
                "                <extAddressLine2></extAddressLine2>\n" +
                "                <vanityCity></vanityCity>\n" +
                "                <externalDisplayAddress>\n" +
                "                    <addressLine1>8026 FLOYD CURL</addressLine1>\n" +
                "                    <addressLine2></addressLine2>\n" +
                "                    <city>SAN ANTONIO</city>\n" +
                "                    <county>BEXAR</county>\n" +
                "                    <state>TX</state>\n" +
                "                    <zip>78229</zip>\n" +
                "                    <zip4>3915</zip4>\n" +
                "                </externalDisplayAddress>\n" +
                "                <billingAddressId>2293703</billingAddressId>\n" +
                "                <billingAddressTypeCode>H</billingAddressTypeCode>\n" +
                "                <effectiveDate>2015-10-09</effectiveDate>\n" +
                "                <cancelDate>9999-12-31</cancelDate>\n" +
                "            </address>\n" +
                "            <phone>\n" +
                "                <active>A</active>\n" +
                "                <primaryPhoneIndicator>P</primaryPhoneIndicator>\n" +
                "                <phoneUseTypeCode>P</phoneUseTypeCode>\n" +
                "                <phoneUseTypeDescription>PLSV</phoneUseTypeDescription>\n" +
                "                <areaCode>210</areaCode>\n" +
                "                <phoneNumber>5938053</phoneNumber>\n" +
                "                <phoneExtension>0000000000</phoneExtension>\n" +
                "            </phone>\n" +
                "            <npi>\n" +
                "                <npiLevelCode>M</npiLevelCode>\n" +
                "                <npi>1487965000</npi>\n" +
                "                <effectiveDate>2010-06-29</effectiveDate>\n" +
                "                <cancelDate>9999-12-31</cancelDate>\n" +
                "            </npi>\n" +
                "            <npi>\n" +
                "                <npiLevelCode>M</npiLevelCode>\n" +
                "                <npi>1326073206</npi>\n" +
                "                <effectiveDate>2006-07-11</effectiveDate>\n" +
                "                <cancelDate>9999-12-31</cancelDate>\n" +
                "            </npi>\n" +
                "            <npiAuthExemptionStatus>\n" +
                "                <npi>1487965000</npi>\n" +
                "                <authExemptionStatusInd>N</authExemptionStatusInd>\n" +
                "                <authExemptionStateCd>TX</authExemptionStateCd>\n" +
                "            </npiAuthExemptionStatus>\n" +
                "            <specialty>\n" +
                "                <specialty>\n" +
                "                    <name>006</name>\n" +
                "                    <value>CARDIOVASC</value>\n" +
                "                </specialty>\n" +
                "                <specialtySmallDesc>CD</specialtySmallDesc>\n" +
                "                <specialtyFullDesc>CARDIOVASCULAR DISEASE</specialtyFullDesc>\n" +
                "                <specialtyContractOrg>\n" +
                "                    <primaryCode>P</primaryCode>\n" +
                "                    <contractOrgCode>UHN</contractOrgCode>\n" +
                "                    <contrOrgEffDate>1992-01-20</contrOrgEffDate>\n" +
                "                    <contrOrgCancDate>9999-12-31</contrOrgCancDate>\n" +
                "                </specialtyContractOrg>\n" +
                "            </specialty>\n" +
                "            <contractInformation>\n" +
                "                <contractId> </contractId>\n" +
                "                <incentiveDisincentiveId> </incentiveDisincentiveId>\n" +
                "                <preferredNetworkIndicator> </preferredNetworkIndicator>\n" +
                "                <tierIndicator> </tierIndicator>\n" +
                "                <contractRoleCode> </contractRoleCode>\n" +
                "                <demoteIndicator> </demoteIndicator>\n" +
                "                <acoId> </acoId>\n" +
                "                <acoName> </acoName>\n" +
                "                <rulesPackageKey> </rulesPackageKey>\n" +
                "                <topsUhpdInd> </topsUhpdInd>\n" +
                "                <tier> </tier>\n" +
                "                <tierType> </tierType>\n" +
                "                <acoEntityId> </acoEntityId>\n" +
                "                <acoEntityType> </acoEntityType>\n" +
                "                <acoEntityName> </acoEntityName>\n" +
                "                <podmPDStatusInd> </podmPDStatusInd>\n" +
                "                <podmUhpdOption> </podmUhpdOption>\n" +
                "                <podmStatusCode> </podmStatusCode>\n" +
                "                <podmStatusDesc> </podmStatusDesc>\n" +
                "                <layer7ErrorCode> </layer7ErrorCode>\n" +
                "                <layer7ErrorDesc> </layer7ErrorDesc>\n" +
                "                <pesErrorCode> </pesErrorCode>\n" +
                "                <pesErrorDesc> </pesErrorDesc>\n" +
                "            </contractInformation>\n" +
                "            <ddp>\n" +
                "                <plnDdpCd>NN</plnDdpCd>\n" +
                "                <plnDdpEffDt>2010-09-01</plnDdpEffDt>\n" +
                "                <plnDdpCancDt>9999-12-31</plnDdpCancDt>\n" +
                "            </ddp>\n" +
                "            <docasapInd> </docasapInd>\n" +
                "            <providerPcpIndicator> </providerPcpIndicator>\n" +
                "            <topsProviderTypeCode>MD</topsProviderTypeCode>\n" +
                "            <organizationClassTypeCode>A</organizationClassTypeCode>\n" +
                "            <taxIdAuthExemptionStatus>\n" +
                "                <authExemptionStateCd> </authExemptionStateCd>\n" +
                "                <authExemptionStatusInd> </authExemptionStatusInd>\n" +
                "                <taxId> </taxId>\n" +
                "            </taxIdAuthExemptionStatus>\n" +
                "            <addressAffiliations>\n" +
                "                <limitationActvCd> </limitationActvCd>\n" +
                "                <affiliationInd> </affiliationInd>\n" +
                "                <affiliationDesc> </affiliationDesc>\n" +
                "                <addressSupressionInd> </addressSupressionInd>\n" +
                "            </addressAffiliations>\n" +
                "        </physicianFacilityInformation>\n" +
                "    </svcResponse>\n" +
                "</PhysicianFacilitySummary0002Response>";

        return xmlString;
    }

}