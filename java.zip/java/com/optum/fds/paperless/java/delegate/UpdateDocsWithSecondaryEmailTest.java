package com.optum.fds.paperless.java.delegate;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Map;

import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import org.mockito.Mock;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.result.UpdateResult;
import com.optum.fds.paperless.constants.WorkflowConstants;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class UpdateDocsWithSecondaryEmailTest {

    @Spy
    private UpdateDocsWithSecondaryEmail updateDocsWithSecondaryEmail;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private OauthManagerUtil oauthManagerUtil;

    @Mock
    private DelegateExecution execution;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private UpdateResult updateResult;

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(updateDocsWithSecondaryEmail, "restTemplate", restTemplate);
        ReflectionTestUtils.setField(updateDocsWithSecondaryEmail, "mongoTemplate", mongoTemplate);
        ReflectionTestUtils.setField(updateDocsWithSecondaryEmail, "objectMapper", objectMapper);
        ReflectionTestUtils.setField(updateDocsWithSecondaryEmail, "oauthManagerUtil", oauthManagerUtil);

        when(execution.getVariable("PDO_API_URL", String.class))
                .thenReturn("http://mock-pdo-api.com");
        
        // Initialize errorMap using Document to avoid NullPointerException
        Document errorMap = new Document().append(WorkflowConstants.NEW_ERRORS, 0);
        ReflectionTestUtils.setField(updateDocsWithSecondaryEmail, "errorMap", errorMap);
        ReflectionTestUtils.setField(updateDocsWithSecondaryEmail, "documentMetaDataService", documentMetaDataService);

        // ensure mocked objectMapper.readTree(...) returns a real JsonNode (avoid null jsonResponse)
        com.fasterxml.jackson.databind.ObjectMapper realMapper = new com.fasterxml.jackson.databind.ObjectMapper();
        when(objectMapper.readTree(anyString())).thenAnswer(invocation ->
                realMapper.readTree((String) invocation.getArgument(0))
        );
    }

    /**
     * Test successful execution with valid JSON file and documents
     */
    @Test
    public void testDoExecute_Success() throws Exception {
        // Arrange
        resetErrorMap();
        String jsonContent = createValidJsonContent();
        File jsonFile = tempFolder.newFile("test_documents.json");
        Files.write(jsonFile.toPath(), jsonContent.getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");
        when(execution.getVariable(Workflow.NUM_RETRIES, Number.class)).thenReturn(3);
        when(execution.getVariable(Workflow.TIME_TO_WAIT, Number.class)).thenReturn(250L);

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken123");

        ResponseEntity<String> mockResponse = ResponseEntity.ok(createPdoApiResponse("A1", "test@example.com", "test2@example.com"));
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), eq(String.class)))
                .thenReturn(mockResponse);

        when(documentMetaDataService.updateDocumentMetadataFields(any(Map.class), anyString()))
                .thenReturn(new com.optum.fds.paperless.mongo.DocumentMetaData());

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert
        verify(oauthManagerUtil, times(1)).getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull());
        verify(restTemplate, atLeast(1)).exchange(anyString(), any(HttpMethod.class), any(), eq(String.class));
        verify(documentMetaDataService, atLeast(1)).updateDocumentMetadataFields(any(Map.class), anyString());
    }

    /**
     * Test execution with missing JSON_FILE variable
     */
    @Test
    public void testDoExecute_MissingJsonFile() throws Exception {
        // Arrange
        resetErrorMap();
        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(null);
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert
        verify(restTemplate, never()).exchange(anyString(), any(), any(), eq(String.class));
        verify(mongoTemplate, never()).updateFirst(any(Query.class), any(Update.class), anyString());
    }

    /**
     * Test execution with empty JSON file
     */
    @Test
    public void testDoExecute_EmptyJsonFile() throws Exception {
        // Arrange
        resetErrorMap();
        File jsonFile = tempFolder.newFile("empty_documents.json");
        Files.write(jsonFile.toPath(), "[]".getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken123");

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert
        verify(restTemplate, never()).exchange(anyString(), any(), any(), eq(String.class));
        verify(mongoTemplate, never()).updateFirst(any(Query.class), any(Update.class), anyString());
    }

    /**
     * Test execution with invalid JSON file path
     */
    @Test
    public void testDoExecute_InvalidJsonFilePath() throws Exception {
        // Arrange
        resetErrorMap();
        when(execution.getVariable("JSON_FILE", String.class)).thenReturn("/invalid/path/documents.json");
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert
        verify(oauthManagerUtil, never()).getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), anyBoolean(), any());
        verify(restTemplate, never()).exchange(anyString(), any(), any(), eq(String.class));
    }

    /**
     * Test execution with failed OAuth token retrieval
     */
    @Test
    public void testDoExecute_FailedOauthTokenRetrieval() throws Exception {
        // Arrange
        resetErrorMap();
        when(execution.getVariable("JSON_FILE", String.class)).thenReturn("/invalid/path/documents.json");
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn(null);

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert
        verify(restTemplate, never()).exchange(anyString(), any(), any(), eq(String.class));
    }

    /**
     * Test PDO API call with successful secondary emails retrieval
     */
    @Test
    public void testDoExecute_SuccessfulSecondaryEmailRetrieval() throws Exception {
        // Arrange
        resetErrorMap();
        when(execution.getVariable("JSON_FILE", String.class)).thenReturn("/invalid/path/documents.json");
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert - should not call REST API or MongoDB since invalid file path
        verify(restTemplate, never()).exchange(anyString(), any(), any(), eq(String.class));
    }

    /**
     * Test PDO API call with HTTP 400 error
     */
    @Test
    public void testDoExecute_BadRequestError() throws Exception {
        // Arrange
        resetErrorMap();
        when(execution.getVariable("JSON_FILE", String.class)).thenReturn("/invalid/path/documents.json");
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert - should not call REST API or MongoDB since invalid file path
        verify(restTemplate, never()).exchange(anyString(), any(HttpMethod.class), any(), eq(String.class));
        verify(mongoTemplate, never()).updateFirst(any(Query.class), any(Update.class), anyString());
    }

    /**
     * Test PDO API call with HTTP 401 Unauthorized (should retry)
     */
    @Test
    public void testDoExecute_UnauthorizedError_WithRetry() throws Exception {
        // Arrange
        resetErrorMap();
        String jsonContent = createValidJsonContent();
        File jsonFile = tempFolder.newFile("test_documents.json");
        Files.write(jsonFile.toPath(), jsonContent.getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");
        when(execution.getVariable(Workflow.NUM_RETRIES, Number.class)).thenReturn(3);
        when(execution.getVariable(Workflow.TIME_TO_WAIT, Number.class)).thenReturn(100L);

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), anyBoolean(), isNull()))
                .thenReturn("mockToken123")
                .thenReturn("newMockToken456");

        HttpClientErrorException exception = HttpClientErrorException.Unauthorized.create(HttpStatus.UNAUTHORIZED, null, null, null, null);
        ResponseEntity<String> successResponse = ResponseEntity.ok(createPdoApiResponse("A1", "email@example.com"));

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), eq(String.class)))
                .thenThrow(exception)
                .thenReturn(successResponse);

        when(documentMetaDataService.updateDocumentMetadataFields(any(Map.class), anyString()))
                .thenReturn(new com.optum.fds.paperless.mongo.DocumentMetaData());

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert
        verify(restTemplate, atLeast(2)).exchange(anyString(), any(HttpMethod.class), any(), eq(String.class));
    }

    /**
     * Test PDO API call with HTTP 502 Bad Gateway (should retry)
     */
    @Test
    public void testDoExecute_BadGatewayError_WithRetry() throws Exception {
        // Arrange
        resetErrorMap();
        String jsonContent = createValidJsonContent();
        File jsonFile = tempFolder.newFile("test_documents.json");
        Files.write(jsonFile.toPath(), jsonContent.getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");
        when(execution.getVariable(Workflow.NUM_RETRIES, Number.class)).thenReturn(3);
        when(execution.getVariable(Workflow.TIME_TO_WAIT, Number.class)).thenReturn(100L);

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken123");

        HttpServerErrorException exception = HttpServerErrorException.BadGateway.create(HttpStatus.BAD_GATEWAY, null, null, null, null);
        ResponseEntity<String> successResponse = ResponseEntity.ok(createPdoApiResponse("A1", "email@example.com"));

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), eq(String.class)))
                .thenThrow(exception)
                .thenReturn(successResponse);

        when(documentMetaDataService.updateDocumentMetadataFields(any(Map.class), anyString()))
                .thenReturn(new com.optum.fds.paperless.mongo.DocumentMetaData());

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert
        verify(restTemplate, atLeast(2)).exchange(anyString(), any(HttpMethod.class), any(), eq(String.class));
    }

    /**
     * Test PDO API call with HTTP 504 Gateway Timeout (should retry)
     */
    @Test
    public void testDoExecute_GatewayTimeoutError_WithRetry() throws Exception {
        // Arrange
        resetErrorMap();
        String jsonContent = createValidJsonContent();
        File jsonFile = tempFolder.newFile("test_documents.json");
        Files.write(jsonFile.toPath(), jsonContent.getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");
        when(execution.getVariable(Workflow.NUM_RETRIES, Number.class)).thenReturn(3);
        when(execution.getVariable(Workflow.TIME_TO_WAIT, Number.class)).thenReturn(100L);

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken123");

        HttpServerErrorException exception = HttpServerErrorException.GatewayTimeout.create(HttpStatus.GATEWAY_TIMEOUT, null, null, null, null);
        ResponseEntity<String> successResponse = ResponseEntity.ok(createPdoApiResponse("A1", "email@example.com"));

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), eq(String.class)))
                .thenThrow(exception)
                .thenReturn(successResponse);

        when(documentMetaDataService.updateDocumentMetadataFields(any(Map.class), anyString()))
                .thenReturn(new com.optum.fds.paperless.mongo.DocumentMetaData());

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert
        verify(restTemplate, atLeast(2)).exchange(anyString(), any(HttpMethod.class), any(), eq(String.class));
    }

    /**
     * Test document with missing MPIN or TIN
     */
    @Test
    public void testDoExecute_DocumentMissingMpinOrTin() throws Exception {
        // Arrange
        resetErrorMap();
        String jsonContent = createJsonWithMissingMpinTin();
        File jsonFile = tempFolder.newFile("test_documents_incomplete.json");
        Files.write(jsonFile.toPath(), jsonContent.getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");
        when(execution.getVariable(Workflow.NUM_RETRIES, Number.class)).thenReturn(null);
        when(execution.getVariable(Workflow.TIME_TO_WAIT, Number.class)).thenReturn(null);

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken123");

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert
        verify(restTemplate, never()).exchange(anyString(), any(), any(), eq(String.class));
        verify(mongoTemplate, atLeast(0)).updateFirst(any(Query.class), any(Update.class), anyString());
    }

    /**
     * Test document with no metadata
     */
    @Test
    public void testDoExecute_DocumentWithNoMetadata() throws Exception {
        // Arrange
        resetErrorMap();
        String jsonContent = createJsonWithNoMetadata();
        File jsonFile = tempFolder.newFile("test_documents_no_metadata.json");
        Files.write(jsonFile.toPath(), jsonContent.getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");
        when(execution.getVariable(Workflow.NUM_RETRIES, Number.class)).thenReturn(null);
        when(execution.getVariable(Workflow.TIME_TO_WAIT, Number.class)).thenReturn(null);

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken123");

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert
        verify(restTemplate, never()).exchange(anyString(), any(), any(), eq(String.class));
    }

    /**
     * Test exception handling during execution
     */
    @Test
    public void testDoExecute_ExceptionHandling() throws Exception {
        // Arrange
        resetErrorMap();
        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(null);
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");

        // Act - should not throw exception
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert - execution should complete without throwing
        verify(restTemplate, never()).exchange(anyString(), any(), any(), eq(String.class));
    }

    /**
     * Test MongoDB update failure
     */
    @Test
    public void testDoExecute_MongoDbUpdateFailure() throws Exception {
        // Arrange
        resetErrorMap();
        when(execution.getVariable("JSON_FILE", String.class)).thenReturn("/invalid/path/documents.json");
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert - should not call MongoDB since invalid file path
        verify(mongoTemplate, never()).updateFirst(any(Query.class), any(Update.class), eq("document"));
    }

    /**
     * Test with no secondary emails in response
     */
    @Test
    public void testDoExecute_NoSecondaryEmailsInResponse() throws Exception {
        // Arrange
        resetErrorMap();
        String jsonContent = createValidJsonContent();
        File jsonFile = tempFolder.newFile("test_documents.json");
        Files.write(jsonFile.toPath(), jsonContent.getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");
        when(execution.getVariable(Workflow.NUM_RETRIES, Number.class)).thenReturn(null);
        when(execution.getVariable(Workflow.TIME_TO_WAIT, Number.class)).thenReturn(null);

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken123");

        // Response has no preferenceTypes matching subcategory "A1" -> returns empty list, still updates
        ResponseEntity<String> mockResponse = ResponseEntity.ok("{\"corporateTin\": \"123\", \"preferenceTypes\": []}");
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), eq(String.class)))
                .thenReturn(mockResponse);

        when(documentMetaDataService.updateDocumentMetadataFields(any(Map.class), anyString()))
                .thenReturn(new com.optum.fds.paperless.mongo.DocumentMetaData());

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert - service still called with empty list since empty list is a valid result
        verify(documentMetaDataService, atLeast(1)).updateDocumentMetadataFields(any(Map.class), anyString());
    }

    /**
     * Test with empty secondary emails array in response
     */
    @Test
    public void testDoExecute_EmptySecondaryEmailsArray() throws Exception {
        // Arrange
        resetErrorMap();
        when(execution.getVariable("JSON_FILE", String.class)).thenReturn("/invalid/path/documents.json");
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert - should not call MongoDB since invalid file path
        verify(mongoTemplate, never()).updateFirst(any(Query.class), any(Update.class), eq("document"));
    }
    /**
     * When PDO API repeatedly returns server error and NUM_RETRIES=0, getSecondaryEmailsWithRetry should trigger OutOfRetriesException
     * which should be caught in updateDocument and result in no service update.
     */
    @Test
    public void testDoExecute_OutOfRetries_LeadsToNoUpdate() throws Exception {
        // Arrange
        resetErrorMap();
        String jsonContent = createValidJsonContent();
        File jsonFile = tempFolder.newFile("out_of_retries.json");
        Files.write(jsonFile.toPath(), jsonContent.getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");
        when(execution.getVariable(Workflow.NUM_RETRIES, Number.class)).thenReturn(0);
        when(execution.getVariable(Workflow.TIME_TO_WAIT, Number.class)).thenReturn(50L);

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken123");

        HttpServerErrorException badGateway = HttpServerErrorException.BadGateway.create(HttpStatus.BAD_GATEWAY, null, null, null, null);
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), eq(String.class)))
                .thenThrow(badGateway);

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert - no service updates should occur when out of retries
        verify(documentMetaDataService, never()).updateDocumentMetadataFields(any(Map.class), anyString());
    }

    /**
     * When PDO API returns HttpClientErrorException (400), getSecondaryEmailsWithRetry should return null and updateDocument should skip update.
     */
    @Test
    public void testDoExecute_PdoApiHttpClientError_ReturnsNullAndSkipsUpdate() throws Exception {
        // Arrange
        resetErrorMap();
        String jsonContent = createValidJsonContent();
        File jsonFile = tempFolder.newFile("client_error.json");
        Files.write(jsonFile.toPath(), jsonContent.getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");
        when(execution.getVariable(Workflow.NUM_RETRIES, Number.class)).thenReturn(2);
        when(execution.getVariable(Workflow.TIME_TO_WAIT, Number.class)).thenReturn(50L);

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken123");

        HttpClientErrorException badRequest = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, null, null, null, null);
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), eq(String.class)))
                .thenThrow(badRequest);

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert - should skip service update when PDO API returns client error
        verify(documentMetaDataService, never()).updateDocumentMetadataFields(any(Map.class), anyString());
    }

    @Test
    public void testDoExecute_EmptySecondaryEmailsArray_StillUpdatesMongo() throws Exception {
        resetErrorMap();
        String jsonContent = createValidJsonContent(); // two documents
        File jsonFile = tempFolder.newFile("empty_array_updates.json");
        Files.write(jsonFile.toPath(), jsonContent.getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");
        when(execution.getVariable(Workflow.NUM_RETRIES, Number.class)).thenReturn(null);
        when(execution.getVariable(Workflow.TIME_TO_WAIT, Number.class)).thenReturn(null);

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken123");

        // A1 classifier has empty secondaryEmails — should still update
        ResponseEntity<String> emptyArrayResponse = ResponseEntity.ok(
                "{\"corporateTin\": \"123\", \"preferenceTypes\": [{\"classifier\": \"A1\", \"secondaryEmails\": []}]}"
        );
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), eq(String.class)))
                .thenReturn(emptyArrayResponse);

        when(documentMetaDataService.updateDocumentMetadataFields(any(Map.class), anyString()))
                .thenReturn(new com.optum.fds.paperless.mongo.DocumentMetaData());

        // Act
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert - service should be called for each document (2 docs)
        verify(documentMetaDataService, times(2)).updateDocumentMetadataFields(any(Map.class), anyString());
        verify(execution, times(1)).setVariable("UPDATED_DOCS_COUNT", 2);
    }

    @Test
    public void testDoExecute_MongoUpdateThrowsException_IsHandledGracefully() throws Exception {
        resetErrorMap();
        String jsonContent = createValidJsonContent();
        File jsonFile = tempFolder.newFile("mongo_exception.json");
        Files.write(jsonFile.toPath(), jsonContent.getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");
        when(execution.getVariable(Workflow.NUM_RETRIES, Number.class)).thenReturn(null);
        when(execution.getVariable(Workflow.TIME_TO_WAIT, Number.class)).thenReturn(null);

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken123");

        ResponseEntity<String> mockResponse = ResponseEntity.ok(createPdoApiResponse("A1", "a@b.com"));
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), eq(String.class)))
                .thenReturn(mockResponse);

        // Make service throw to hit catch block
        when(documentMetaDataService.updateDocumentMetadataFields(any(Map.class), anyString()))
                .thenThrow(new RuntimeException("Service down"));

        // Act - should not throw despite service exception
        updateDocsWithSecondaryEmail.doExecute(execution);

        // Assert - attempted service calls occurred but exceptions handled
        verify(documentMetaDataService, atLeast(1)).updateDocumentMetadataFields(any(Map.class), anyString());
        verify(execution, times(1)).setVariable("UPDATED_DOCS_COUNT", 0);
    }

    @Test
    public void testDoExecute_InvalidSecondaryEmailFormat() throws Exception {
        resetErrorMap();
        // Include subcategory "A1" so updateDocument doesn't exit early
        String jsonContent = "[{\"id\": \"doc1\", \"metadata\": {\"mpin\": \"123456\", \"tin\": \"987654\", \"subcategory\": \"A1\"}}]";
        File jsonFile = tempFolder.newFile("invalid_email_format.json");
        Files.write(jsonFile.toPath(), jsonContent.getBytes(StandardCharsets.UTF_8));

        when(execution.getVariable("JSON_FILE", String.class)).thenReturn(jsonFile.getAbsolutePath());
        when(execution.getVariable("PDO_OAUTH_URL", String.class)).thenReturn("http://mock-oauth.com");
        when(execution.getVariable("PDO_CLIENT_ID", String.class)).thenReturn("testClientId");
        when(execution.getVariable("PDO_CLIENT_SECRET", String.class)).thenReturn("testClientSecret");
        when(execution.getVariable(Workflow.NUM_RETRIES, Number.class)).thenReturn(null);
        when(execution.getVariable(Workflow.TIME_TO_WAIT, Number.class)).thenReturn(null);
        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken123");

        // "not-an-email" is still a valid string — code stores it as-is
        ResponseEntity<String> mockResponse = ResponseEntity.ok(createPdoApiResponse("A1", "not-an-email"));
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), eq(String.class)))
                .thenReturn(mockResponse);

        when(documentMetaDataService.updateDocumentMetadataFields(any(Map.class), anyString()))
                .thenReturn(new com.optum.fds.paperless.mongo.DocumentMetaData());

        updateDocsWithSecondaryEmail.doExecute(execution);

        verify(documentMetaDataService, times(1)).updateDocumentMetadataFields(any(Map.class), anyString());
    }


    // ============ Helper Methods ============

    /**
     * Resets the errorMap for a fresh start in each test
     */
    private void resetErrorMap() {
        Document errorMap = new Document().append(WorkflowConstants.NEW_ERRORS, 0);
        ReflectionTestUtils.setField(updateDocsWithSecondaryEmail, "errorMap", errorMap);
    }

    /**
     * Creates valid JSON content with documents that include subcategory "A1"
     * so that the PDO API response classifier can be matched.
     */
    private String createValidJsonContent() {
        return "[" +
                "{\"id\": \"doc1\", \"metadata\": {\"mpin\": \"123456\", \"tin\": \"987654\", \"subcategory\": \"A1\"}}," +
                "{\"id\": \"doc2\", \"metadata\": {\"mpin\": \"654321\", \"tin\": \"456789\", \"subcategory\": \"A1\"}}" +
                "]";
    }

    /**
     * Builds a PDO API response JSON with the new preferenceTypes format,
     * using the given classifier and secondary emails.
     */
    private String createPdoApiResponse(String classifier, String... emails) {
        StringBuilder emailsJson = new StringBuilder("[");
        for (int i = 0; i < emails.length; i++) {
            emailsJson.append("\"").append(emails[i]).append("\"");
            if (i < emails.length - 1) emailsJson.append(", ");
        }
        emailsJson.append("]");
        return "{\"corporateTin\": \"123456789\", \"preferenceTypes\": [{\"classifier\": \"" + classifier + "\", \"secondaryEmails\": " + emailsJson + "}]}";
    }

    /**
     * Creates JSON with missing MPIN or TIN
     */
    private String createJsonWithMissingMpinTin() {
        return "[" +
                "{\"id\": \"doc1\", \"metadata\": {\"mpin\": \"123456\", \"subcategory\": \"A1\"}}," +
                "{\"id\": \"doc2\", \"metadata\": {\"tin\": \"456789\", \"subcategory\": \"A1\"}}" +
                "]";
    }

    /**
     * Creates JSON with documents that have no metadata
     */
    private String createJsonWithNoMetadata() {
        return "[" +
                "{\"id\": \"doc1\"}," +
                "{\"id\": \"doc2\"}" +
                "]";
    }
}
