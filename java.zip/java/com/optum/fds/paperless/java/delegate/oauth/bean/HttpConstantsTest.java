package com.optum.fds.paperless.java.delegate.oauth.bean;


import org.junit.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class HttpConstantsTest {

    @Test
    public void testHttpConstants() throws NoSuchMethodException, InstantiationException,IllegalAccessException, InvocationTargetException {
    Constructor<HttpConstants> cons= HttpConstants.class.getDeclaredConstructor();
    assertTrue(Modifier.isPrivate(cons.getModifiers()));
    cons.setAccessible(true);
    cons.newInstance();
    assertNotNull(cons);
    }

}