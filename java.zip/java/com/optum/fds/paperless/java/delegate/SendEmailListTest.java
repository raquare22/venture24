package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.processing.service.ProcessorTransactionsService;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;




public class SendEmailListTest {
	private final String PATH_JSON_FILE = "SendEmailList/InputJsonExample.json";

	DelegateExecution execution;

	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();

	@Mock
	ProcessorTransactionsService processorTransactionsService;

	@Mock
	EmailService emailService;
	
	@Mock
	ErrorMetaDataService errorMetaDataService;

	@InjectMocks
	SendEmailList sendEmailList;

	Document execVars = new Document();
	
	Document execVarsEmail = new Document();

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);
		String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
	
		execVars.append(Workflow.JSON_FILE, jsonFile)
				.append(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath())
				.append(Workflow.EMAIL_SUBJECT, "Companion File Alert").append(Workflow.ENVIRONMENT, "prod")
				.append(Workflow.EMAIL_SENDER, "do_not_reply@optum.com").append(Workflow.EMAIL_RECEIVER,
						"SystemOperatingControls_DL@uhc.com; CosmosBatch_DL@ds.uhc.com; hsupport@optum.com; william.nierenhausen@optum.com");

		when(execution.getVariables()).thenReturn(execVars);
		when(execution.getVariable(Workflow.JSON_FILE, String.class))
				.thenReturn(execVars.get(Workflow.JSON_FILE, String.class));
		when(execution.getVariable(Workflow.OUTPUT_FILE_DIR, String.class))
				.thenReturn(execVars.get(Workflow.OUTPUT_FILE_DIR, String.class));
		when(execution.getVariable(Workflow.EMAIL_SUBJECT, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_SUBJECT, String.class));
		when(execution.getVariable(Workflow.ENVIRONMENT, String.class))
				.thenReturn(execVars.get(Workflow.ENVIRONMENT, String.class));
		when(execution.getVariable(Workflow.EMAIL_SENDER, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_SENDER, String.class));
		when(execution.getVariable(Workflow.EMAIL_RECEIVER, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_RECEIVER, String.class));
	
        when(emailService.sendEmail(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
        
        when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());

	}

	@UserStory(references = "US25132")
	@RallyTestCase(references = "TC30661")
	@Test
	public void testDoExecute() throws Exception {
		sendEmailList.execute(execution);
		assertNotNull(sendEmailList.errorMap);
		assertEquals(2, sendEmailList.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US25132")
	@RallyTestCase(references = "TC30662")
	public void testDoExecuteWithMissingRequiredVariables() throws Exception {
		execVars.append(Workflow.JSON_FILE, null)
		.append(Workflow.OUTPUT_FILE_DIR, null)
		.append(Workflow.EMAIL_SUBJECT,null).append(Workflow.ENVIRONMENT, null)
		.append(Workflow.EMAIL_SENDER, null).append(Workflow.EMAIL_RECEIVER,
				null);
		
		sendEmailList.execute(execution);
		assertNotNull(sendEmailList.errorMap);
		assertEquals(6, sendEmailList.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US25132")
	@RallyTestCase(references = "TC30663")
	public void testDoExecuteWithInvalidJsonFile() throws Exception {
		String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
		execVars.append(Workflow.JSON_FILE, jsonFile+ "1");
		when(execution.getVariable(Workflow.JSON_FILE, String.class))
				.thenReturn(execVars.get(Workflow.JSON_FILE, String.class));
		sendEmailList.execute(execution);
		assertNotNull(sendEmailList.errorMap);
		assertEquals(1, sendEmailList.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US25132")
	@RallyTestCase(references = "TC30664")
	public void testEmailMessageMissingInProcessorTransactionMetadata() throws Exception {
		String JSON_FILE = "SendEmailList/InputJsonWithoutEmailMessage.json";
		String jsonFile = Utilities.getInstance().getResourceFile(JSON_FILE).getAbsolutePath();
		execVars.append(Workflow.JSON_FILE, jsonFile);
		when(execution.getVariable(Workflow.JSON_FILE, String.class))
				.thenReturn(execVars.get(Workflow.JSON_FILE, String.class));
		sendEmailList.execute(execution);
		assertNotNull(sendEmailList.errorMap);
		assertEquals(0, sendEmailList.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US25132")
	@RallyTestCase(references = "TC30674")
	public void testEmailMessageEmptyInProcessorTransactionMetadata() throws Exception {
		String JSON_FILE = "SendEmailList/InputJsonEmptyEmailMessage.json";
		String jsonFile = Utilities.getInstance().getResourceFile(JSON_FILE).getAbsolutePath();
		execVars.append(Workflow.JSON_FILE, jsonFile);
		when(execution.getVariable(Workflow.JSON_FILE, String.class))
				.thenReturn(execVars.get(Workflow.JSON_FILE, String.class));
		sendEmailList.execute(execution);
		assertNotNull(sendEmailList.errorMap);
		assertEquals(0, sendEmailList.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US25132")
	@RallyTestCase(references = "TC30676")
	public void testCompanionFileProcessedSuccessfully() throws Exception {
		String JSON_FILE = "SendEmailList/InputJsonSuccessfullCompanionFileProcess.json";
		String jsonFile = Utilities.getInstance().getResourceFile(JSON_FILE).getAbsolutePath();
		execVars.append(Workflow.JSON_FILE, jsonFile);
		when(execution.getVariable(Workflow.JSON_FILE, String.class))
				.thenReturn(execVars.get(Workflow.JSON_FILE, String.class));
		sendEmailList.execute(execution);
		assertNotNull(sendEmailList.errorMap);
		assertEquals(0, sendEmailList.errorMap.get(Workflow.NEW_ERRORS));
	}

}