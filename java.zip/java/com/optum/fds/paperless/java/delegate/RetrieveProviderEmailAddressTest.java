package com.optum.fds.paperless.java.delegate;


import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.domain.service.HookServiceImpl;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.model.PreferenceType;
import com.optum.fds.paperless.model.ProviderPreference;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.beans.FDSCloudGetDocumentsResponse;
import com.optum.fds.paperless.workflow.beans.ProviderDocument;
import com.optum.fds.paperless.workflow.beans.ProviderDocumentMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;

import junit.framework.Assert;
import org.flowable.engine.delegate.DelegateExecution;

import org.assertj.core.util.Arrays;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class) 
public class RetrieveProviderEmailAddressTest {

    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

    @InjectMocks
    RetrieveProviderEmailAddress retrieveProviderEmailAddress;

    @Mock
    RestTemplate restTemplate;

    DelegateExecution execution;

    @Mock
    UriComponentsBuilder builder;

    @Mock
    UriComponents uriComponent;

    Document metaDataObject;
    
    DocumentMetaData doc;

    @Mock
    HookServiceImpl hookServiceImpl;

    @Mock
    DocumentMetaDataService documentMetaDataService;
    
    @Mock
    ErrorMetaDataService errorMetaDataService;
    
    @Mock
    HookService hookService;
    
    @Mock
    OauthManagerUtil oauthManagerUtil;

    @Mock
    EhCache ehCache;

    @Before
    public void setup() throws IOException {
        MockitoAnnotations.initMocks(this);
        
        Integer[] spaceIds = {10074, 10075, 10403, 10803};
        String[] categories = {"P8", "P9", "P0", "E1"};
        Integer[] spaceIdsInd835 = {10403};
        
        ReflectionTestUtils.setField(retrieveProviderEmailAddress, "skipEFT_spaceIds", Arrays.asList(spaceIds));
        ReflectionTestUtils.setField(retrieveProviderEmailAddress, "skipEFT_categories", Arrays.asList(categories));
        ReflectionTestUtils.setField(retrieveProviderEmailAddress, "checkInd_835_spaceIds", Arrays.asList(spaceIdsInd835));
        
        execution = new DelegateExecutionImpl();
        execution.setVariable(Workflow.DOCID, "123456,123456,123456");
        execution.setVariable(Workflow.HOOK_ID, "123456");
        execution.setVariable(Workflow.DOCUMENT, getDocumentMetaData());
        execution.setVariable(Workflow.EFT_IND, null);
        execution.setVariable(Workflow.HOOK_TRANSACTION_METADATA_ID, "12345");
        
        doc = getDocumentMetaData();
        
        List<DocumentMetaData> docList = new ArrayList<>();
        docList.add(doc);
        
        when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);
        
        when(documentMetaDataService.getDocumentMetaData(anyString())).thenReturn(doc);
        
        when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
        
        when(hookService.getHookTransactionById(anyString())).thenReturn(createHookTransaction());
        when(hookService.saveHookTransaction(Mockito.any())).thenReturn(createHookTransaction());
        
        try (MockedStatic<EhCache> cacheMock = Mockito.mockStatic(EhCache.class)) {
			cacheMock.when(() -> ehCache.putOauthTokenWithExpiry(anyString(), anyString(), Mockito.any())).thenAnswer((Answer<Void>) invocation -> null);
        }
        
    }
     
    
    @Test
    public void testFDSCloud() throws InterruptedException {
    	execution.setVariable("useFDSCloud", true);
		execution.setVariable(Workflow.FDS_CLOUD_GET_DOCUMENT_URL, "https://test");
		execution.setVariable(Workflow.FDS_CLOUD_AUTH_URL, "https://test");
		execution.setVariable(Workflow.CLOUD_CLIENT_ID, "testapp");
		execution.setVariable(Workflow.CLOUD_CLIENT_SECRET, "testapp");
		execution.setVariable(Workflow.CLOUD_GRANT_TYPE, "client_credentials");

		ReflectionTestUtils.setField(retrieveProviderEmailAddress, "cloudSpaceId", "1234-5678s");

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(),
                anyString(), anyString(),Mockito.anyBoolean(),isNull()))
                .thenReturn("token");

        FDSCloudGetDocumentsResponse responseBody = new FDSCloudGetDocumentsResponse();

		List<ProviderDocument> documentList = new ArrayList<ProviderDocument>();
		ProviderDocument document = new ProviderDocument();
		ProviderDocumentMetaData documentMetaData = new ProviderDocumentMetaData();
		documentMetaData.setFrequency("D");
		documentMetaData.setProviderEmailId("foo@optum.com");
		documentMetaData.setWeekday("Monday");
		document.setMetadata(documentMetaData);
		documentList.add(document);
		responseBody.setDocuments(documentList);
		responseBody.setCount("1");

		ResponseEntity<FDSCloudGetDocumentsResponse> response = new ResponseEntity<FDSCloudGetDocumentsResponse>(responseBody,
				HttpStatus.ACCEPTED);

		execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID_V2,"3007");
		when(restTemplate.exchange(ArgumentMatchers.any(URI.class), ArgumentMatchers.any(HttpMethod.class),
				ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<FDSCloudGetDocumentsResponse>>any())).thenReturn(response);

		retrieveProviderEmailAddress.execute(execution);
		assertNotNull(retrieveProviderEmailAddress.errorMap);
		assertEquals("foo@optum.com", doc.getMetadata().getString("providerEmailId"));
		assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
    }

    @Test
    public void testFDSCloudOptOut() throws InterruptedException {
        execution.setVariable("useFDSCloud", true);
        execution.setVariable(Workflow.FDS_CLOUD_GET_DOCUMENT_URL, "https://test");
        execution.setVariable(Workflow.FDS_CLOUD_AUTH_URL, "https://test");
        execution.setVariable(Workflow.CLOUD_CLIENT_ID, "testapp");
        execution.setVariable(Workflow.CLOUD_CLIENT_SECRET, "testapp");
        execution.setVariable(Workflow.CLOUD_GRANT_TYPE, "client_credentials");

        ReflectionTestUtils.setField(retrieveProviderEmailAddress, "cloudSpaceId", "1234-5678s");


        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(),
                anyString(), anyString(),Mockito.anyBoolean(), isNull()))
                .thenReturn("token");


        FDSCloudGetDocumentsResponse responseBody = new FDSCloudGetDocumentsResponse();

        List<ProviderDocument> documentList = new ArrayList<ProviderDocument>();
        ProviderDocument document = new ProviderDocument();
        ProviderDocumentMetaData providerDocumentMetaData = new ProviderDocumentMetaData();
        providerDocumentMetaData.setFrequency("D");
        providerDocumentMetaData.setSubsribeToEmail("Y");
        providerDocumentMetaData.setProviderEmailId("Opt out");
        providerDocumentMetaData.setWeekday("Monday");
        document.setMetadata(providerDocumentMetaData);
        documentList.add(document);
        responseBody.setDocuments(documentList);
        responseBody.setCount("1");

        ResponseEntity<FDSCloudGetDocumentsResponse> response = new ResponseEntity<FDSCloudGetDocumentsResponse>(responseBody,
                HttpStatus.ACCEPTED);

        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID_V2,"3007");
        when(restTemplate.exchange(ArgumentMatchers.any(URI.class), ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<FDSCloudGetDocumentsResponse>>any())).thenReturn(response);

        retrieveProviderEmailAddress.execute(execution);
        assertNotNull(retrieveProviderEmailAddress.errorMap);
		assertEquals("Opt out", doc.getMetadata().getString("providerEmailId"));
		assertEquals("N", doc.getMetadata().getString("subscribeToEmail"));
		assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
    }
    
    @Test
    public void testGetProviderEmailRetryForInternalServerError() {
        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
        execution.setVariable("useFDSCloud", true);
		execution.setVariable(Workflow.FDS_CLOUD_GET_DOCUMENT_URL, "https://test");
		execution.setVariable(Workflow.FDS_CLOUD_AUTH_URL, "https://test");
		execution.setVariable(Workflow.CLOUD_CLIENT_ID, "testapp");
		execution.setVariable(Workflow.CLOUD_CLIENT_SECRET, "testapp");
		execution.setVariable(Workflow.CLOUD_GRANT_TYPE, "client_credentials");

		ReflectionTestUtils.setField(retrieveProviderEmailAddress, "cloudSpaceId", "1234-5678s");
		
		OauthTokenExtended oauthTokenExtended = new OauthTokenExtended("testapp", "testapp");
		oauthTokenExtended.setAccessToken("abc1123");
		oauthTokenExtended.setExpiresIn(1800);
		oauthTokenExtended.setObtainedOn(new Date());
		Optional<OauthTokenExtended> optionalToken = Optional.of(oauthTokenExtended);
		
		when(oauthManagerUtil.getOauthTokenExtended(anyString(), anyString(), anyString(), anyString(), isNull()))
			.thenReturn(optionalToken);


        when(restTemplate.exchange(ArgumentMatchers.any(URI.class), ArgumentMatchers.any(HttpMethod.class),
        		ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<Object>>any())).thenThrow(exception);

		retrieveProviderEmailAddress.execute(execution);
		
		assertNotNull(retrieveProviderEmailAddress.errorMap);
		assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
		
    }

    @Test
    public void testGetProviderEmailRetryForUnauthorized() throws Exception{
        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.UNAUTHORIZED);
        execution.setVariable("useFDSCloud", true);
		execution.setVariable(Workflow.FDS_CLOUD_GET_DOCUMENT_URL, "https://test");
		execution.setVariable(Workflow.FDS_CLOUD_AUTH_URL, "https://test");
		execution.setVariable(Workflow.CLOUD_CLIENT_ID, "testapp");
		execution.setVariable(Workflow.CLOUD_CLIENT_SECRET, "testapp");
		execution.setVariable(Workflow.CLOUD_GRANT_TYPE, "client_credentials");
		
		ReflectionTestUtils.setField(retrieveProviderEmailAddress, "cloudSpaceId", "1234-5678s");
		
		OauthTokenExtended oauthTokenExtended = new OauthTokenExtended("testapp", "testapp");
		oauthTokenExtended.setAccessToken("abc1123");
		oauthTokenExtended.setExpiresIn(1800);
		oauthTokenExtended.setObtainedOn(new Date());
		Optional<OauthTokenExtended> optionalToken = Optional.of(oauthTokenExtended);
		
		when(oauthManagerUtil.getOauthTokenExtended(anyString(), anyString(), anyString(), anyString(), isNull()))
			.thenReturn(optionalToken);


        when(restTemplate.exchange(ArgumentMatchers.any(URI.class), ArgumentMatchers.any(HttpMethod.class),
        		ArgumentMatchers.<HttpEntity<?>>any(), ArgumentMatchers.<Class<Object>>any())).thenThrow(exception);

        retrieveProviderEmailAddress.execute(execution);
        
        assertNotNull(retrieveProviderEmailAddress.errorMap);
		assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32427")
    @Test
    public void testExecution() {
        var documentMetaData = new ProviderDocumentMetaData()
                .setFrequency("D")
                .setSubsribeToEmail("N")
                .setProviderEmailId("foo@optum.com")
                .setWeekday("Monday");

        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(new ProviderDocument().setMetadata(documentMetaData)));

        retrieveProviderEmailAddress.execute(execution);
        assertNotNull(retrieveProviderEmailAddress.errorMap);
        assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));

    }


    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32428")
    @Test
    public void testExecutionFrequencyNull() {
        var documentMetaData = new ProviderDocumentMetaData()
                .setProviderEmailId("foo@optum.com")
                .setSubsribeToEmail("Y");

        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(new ProviderDocument().setMetadata(documentMetaData)));

        retrieveProviderEmailAddress.execute(execution);
        assertNotNull(retrieveProviderEmailAddress.errorMap);
        assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32429")
    @Test
    public void testExecutionWithValidProviderMpin() {
        var documentMetaData = new ProviderDocumentMetaData()
                .setFrequency("D")
                .setProviderEmailId("foo@optum.com")
                .setSubsribeToEmail("Y")
                .setWeekday("Monday")
                .setMpin("12345");


        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID_V2, "3006");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(new ProviderDocument().setMetadata(documentMetaData)));

        retrieveProviderEmailAddress.execute(execution);
        assertNotNull(retrieveProviderEmailAddress.errorMap);
        assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
    }


    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32430")
//    @Test
    public void testExecutionInvalidProviderMpin() {

    	execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID_V2, "3006");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenThrow(new NullPointerException());

        retrieveProviderEmailAddress.execute(execution);
        assertNotNull(retrieveProviderEmailAddress.errorMap);
        assertEquals(1, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32431")
//    @Test
    public void testExecutionWithNoDocumentsFound() {
    	execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID_V2, "3006");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of());

        retrieveProviderEmailAddress.execute(execution);
        assertEquals("Missing or invalid data: providerEmailId", doc.getMetadata().getString(Workflow.E_DELIVERY_ERROR));
        assertNotNull(retrieveProviderEmailAddress.errorMap);
        assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32432")
    @Test
    public void testExecutionWithNoProviderEmail() {
        var documentMetaData = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("")
                .setSubsribeToEmail("Y")
                .setWeekday("Monday");

        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(new ProviderDocument().setMetadata(documentMetaData)));

        retrieveProviderEmailAddress.execute(execution);
        assertEquals("Missing or invalid data: providerEmailId", doc.getMetadata().getString(Workflow.E_DELIVERY_ERROR));

    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32435")
    @Test
    public void testExecutionWithEmailAlertN() throws Exception {
    	
    	DocumentMetaData doc = getDocumentMetaDataemailAlertReqN();
    	doc.setSpaceId(10803);
    	doc.getMetadata().put("subCategory", "P8");
    	doc.getMetadata().put("emailAlertReq", "Y");
    	doc.getMetadata().put("EFT_Ind", "Y");
    	doc.getMetadata().put("Ind_835", "");
    	
    	
    	List<DocumentMetaData> docList = new ArrayList<>();
        docList.add(doc);
        
        when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);
    	
    	execution.setVariable(Workflow.DOCUMENT, getDocumentMetaDataemailAlertReqN());
        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        retrieveProviderEmailAddress.execute(execution);
        assertNotNull(retrieveProviderEmailAddress.errorMap);
        assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32436")
    @Test
    public void testExecutionWithPRAEFTIdentifierAstrue() throws Exception {
        var documentMetaData = getDocumentMetaData();
        documentMetaData.setSpaceId(10075);
        documentMetaData.getMetadata().put(Workflow.EFT_IND, "Y");
        
        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        
        List<DocumentMetaData> docList = new ArrayList<>();
        docList.add(documentMetaData);
        
        when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);
        
        when(documentMetaDataService.getDocumentMetaData(anyString())).thenReturn(documentMetaData);
        execution.setVariable(Workflow.DOCUMENT, documentMetaData);
        retrieveProviderEmailAddress.execute(execution);
        assertNotNull(retrieveProviderEmailAddress.errorMap);
        assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32437")
    @Test
    public void testExecutionWithPRAEFTIdentifierAsFalse() throws Exception {
        var providerDocumentMetaData = new ProviderDocumentMetaData()
                .setProviderEmailId("foo@optum.com")
                .setSubsribeToEmail("N");

        var documentMetaData = getDocumentMetaData();
        documentMetaData.getMetadata().put(Workflow.EFT_IND, "N");

        execution.setVariable(Workflow.DOCUMENT, documentMetaData);
        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(new ProviderDocument().setMetadata(providerDocumentMetaData)));

        retrieveProviderEmailAddress.execute(execution);
        assertNotNull(retrieveProviderEmailAddress.errorMap);
        assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32438")
    @Test
    public void testSkipEFTIND() throws Exception {
        var providerDocumentMetaData = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("")
                .setSubsribeToEmail("N")
                .setWeekday("Monday");

        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(new ProviderDocument().setMetadata(providerDocumentMetaData)));

        var documentMetaData = getDocumentMetaData();
        documentMetaData.getMetadata().put(Workflow.EFT_IND, "Y");

        execution.setVariable(Workflow.DOCUMENT, documentMetaData);

//		Skip EFTIND as true
        execution.setVariable(Workflow.SKIP_EFT_IND, "true");
        retrieveProviderEmailAddress.execute(execution);
        assertNotNull(retrieveProviderEmailAddress.errorMap);
        assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));

//		Skip EFTIND as false
        execution.setVariable(Workflow.SKIP_EFT_IND, "false");
        retrieveProviderEmailAddress.execute(execution);
        assertNotNull(retrieveProviderEmailAddress.errorMap);
        assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
    }
    
    
    @Test 
    public void testCheckConditions() throws Exception {
    	
    	org.bson.Document metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "Y");
    	metadata.put(Workflow.EFT_IND, "Y");
    	metadata.put(Workflow.SUBCATEGORY, "P2");
    	
    	Assert.assertEquals(true, retrieveProviderEmailAddress.checkConditions(10075, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "Y");
    	metadata.put(Workflow.EFT_IND, "N");
    	metadata.put(Workflow.SUBCATEGORY, "P2");
    	
    	Assert.assertEquals(false, retrieveProviderEmailAddress.checkConditions(10075, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "Y");
    	metadata.put(Workflow.EFT_IND, "N");
    	metadata.put(Workflow.SUBCATEGORY, "P8");
    	
    	Assert.assertEquals(false, retrieveProviderEmailAddress.checkConditions(10075, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "Y");
    	metadata.put(Workflow.EFT_IND, "Y");
    	metadata.put(Workflow.SUBCATEGORY, "P8");
    	
    	Assert.assertEquals(false, retrieveProviderEmailAddress.checkConditions(10075, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "Y");
    	metadata.put(Workflow.SUBCATEGORY, "A1");
    	
    	Assert.assertEquals(false, retrieveProviderEmailAddress.checkConditions(8889, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "Y");
    	metadata.put(Workflow.EFT_IND, "Y");
    	metadata.put(Workflow.SUBCATEGORY, "P8");
    	
    	Assert.assertEquals(false, retrieveProviderEmailAddress.checkConditions(10803, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "Y");
    	metadata.put(Workflow.EFT_IND, "Y");
    	metadata.put(Workflow.SUBCATEGORY, "P2");
    	
    	Assert.assertEquals(true, retrieveProviderEmailAddress.checkConditions(10803, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "N");
    	metadata.put(Workflow.EFT_IND, "Y");
    	metadata.put(Workflow.SUBCATEGORY, "P2");
    	
    	Assert.assertEquals(true, retrieveProviderEmailAddress.checkConditions(10803, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "Y");
    	metadata.put(Workflow.IND_835, "Y");
    	metadata.put(Workflow.SUBCATEGORY, "P2");
    	
    	Assert.assertEquals(true, retrieveProviderEmailAddress.checkConditions(10403, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "Y");
    	metadata.put(Workflow.IND_835, "N");
    	metadata.put(Workflow.SUBCATEGORY, "P2");
    	
    	Assert.assertEquals(false, retrieveProviderEmailAddress.checkConditions(10403, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "Y");
    	metadata.put(Workflow.IND_835, "Y");
    	metadata.put(Workflow.SUBCATEGORY, "P0");
    	
    	Assert.assertEquals(false, retrieveProviderEmailAddress.checkConditions(10403, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "Y");
    	metadata.put(Workflow.IND_835, "N");
    	metadata.put(Workflow.SUBCATEGORY, "P0");
    	
    	Assert.assertEquals(false, retrieveProviderEmailAddress.checkConditions(10403, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "N");
    	metadata.put(Workflow.SUBCATEGORY, "A2");
    	
    	Assert.assertEquals(true, retrieveProviderEmailAddress.checkConditions(10603, metadata, execution));
    	
    	metadata = new org.bson.Document();
    	metadata.put(Workflow.EMAIL_ALERT_REQUEST, "N");
    	metadata.put(Workflow.IND_835, "N");
    	metadata.put(Workflow.SUBCATEGORY, "P0");
    	
    	Assert.assertEquals(true, retrieveProviderEmailAddress.checkConditions(10403, metadata, execution));
    	
    }
    
    @Test
    public void testCSPPRAInd_835() throws Exception {
    	
    	var providerDocumentMetaData = new ProviderDocumentMetaData()
        .setFrequency("W")
        .setProviderEmailId("")
        .setSubsribeToEmail("N")
        .setWeekday("Monday");

		execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
		when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(new ProviderDocument().setMetadata(providerDocumentMetaData)));
		
		var documentMetaData = getDocumentMetaDataCSPPRA();
		
		execution.setVariable(Workflow.DOCUMENT, documentMetaData);
		
		retrieveProviderEmailAddress.execute(execution);
		assertNotNull(retrieveProviderEmailAddress.errorMap);
		assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
		
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32439")
//    @Test
    public void testExecutionWithAutoEnrollmentBadActiveDateIndex0() throws Exception {
        var documentMetaDataAutoEnrollment = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("autoenrollmentbaddate@optum.com")
                .setSubsribeToEmail("Y")
                .setWeekday("")
                .setActiveDate("2020:1:1:")
                .setDeliveryMethod("E");

        var documentAutoEnrollment = new ProviderDocument()
                .setMetadata(documentMetaDataAutoEnrollment);

        var documentMetaData = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("nonautoenrollment@optum.com")
                .setSubsribeToEmail("Y")
                .setWeekday("")
                .setDeliveryMethod("P");
        var document = new ProviderDocument()
                .setMetadata(documentMetaData);

        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(documentAutoEnrollment, document));

        retrieveProviderEmailAddress.execute(execution);
        assertEquals("nonautoenrollment@optum.com", this.metaDataObject.getString("providerEmailId"));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32440")
//    @Test
    public void testExecutionWithAutoEnrollmentBadActiveDateIndex1() throws Exception {
        var documentMetaDataAutoEnrollment = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("autoenrollmentbaddate@optum.com")
                .setWeekday("")
                .setActiveDate("2020:1:1:")
                .setDeliveryMethod("E");

        var documentAutoEnrollment = new ProviderDocument()
                .setMetadata(documentMetaDataAutoEnrollment);

        var documentMetaData = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("nonautoenrollment@optum.com")
                .setSubsribeToEmail("Y")
                .setWeekday("")
                .setDeliveryMethod("P");

        var document = new ProviderDocument()
                .setMetadata(documentMetaData);

        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(documentAutoEnrollment, document));

        retrieveProviderEmailAddress.execute(execution);
        assertEquals("nonautoenrollment@optum.com", this.metaDataObject.getString("providerEmailId"));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32441")
//    @Test
    public void testExecutionWithAutoEnrollmentInFutureIndex0() throws Exception {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.MINUTE, 10);
        Date activeDate = calendar.getTime();

        TimeZone tz = TimeZone.getTimeZone("UTC");
        sdf.setTimeZone(tz);
        String activeDateAsISO = sdf.format(activeDate);
        System.out.println("activeDateAsISO=" + activeDateAsISO);


        var documentMetaDataAutoEnrollment = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("autoenrollmentbaddate@optum.com")
                .setWeekday("")
                .setActiveDate(activeDateAsISO)
                .setDeliveryMethod("E");
        var documentAutoEnrollment = new ProviderDocument()
                .setMetadata(documentMetaDataAutoEnrollment);

        var documentMetaData = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("nonautoenrollment@optum.com")
                .setSubsribeToEmail("Y")
                .setWeekday("")
                .setDeliveryMethod("P");

        var document = new ProviderDocument()
                .setMetadata(documentMetaData);

        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(documentAutoEnrollment, document));

        retrieveProviderEmailAddress.execute(execution);
        assertEquals("nonautoenrollment@optum.com", this.metaDataObject.getString("providerEmailId"));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32442")
//    @Test
    public void testExecutionWithAutoEnrollmentInFutureIndex1() throws Exception {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.MINUTE, 10);
        Date activeDate = calendar.getTime();

        TimeZone tz = TimeZone.getTimeZone("UTC");
        sdf.setTimeZone(tz);
        String activeDateAsISO = sdf.format(activeDate);
        System.out.println("activeDateAsISO=" + activeDateAsISO);

        var documentMetaDataAutoEnrollment = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("autoenrollmentbaddate@optum.com")
                .setWeekday("")
                .setActiveDate(activeDateAsISO)
                .setDeliveryMethod("E");
        var documentAutoEnrollment = new ProviderDocument()
                .setMetadata(documentMetaDataAutoEnrollment);

        var documentMetaData = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("nonautoenrollment@optum.com")
                .setSubsribeToEmail("Y")
                .setWeekday("")
                .setDeliveryMethod("P");

        var document = new ProviderDocument()
                .setMetadata(documentMetaData);

        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(documentAutoEnrollment, document));

        retrieveProviderEmailAddress.execute(execution);
        assertEquals("nonautoenrollment@optum.com", this.metaDataObject.getString("providerEmailId"));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32443")
//    @Test
    public void testExecutionWithAutoEnrollmentInPastIndex0() throws Exception {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.MINUTE, -10);
        Date activeDate = calendar.getTime();

        TimeZone tz = TimeZone.getTimeZone("UTC");
        sdf.setTimeZone(tz);
        String activeDateAsISO = sdf.format(activeDate);
        System.out.println("activeDateAsISO=" + activeDateAsISO);

        var documentMetaDataAutoEnrollment = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("autoenrollment@optum.com")
                .setSubsribeToEmail("Y")
                .setWeekday("")
                .setActiveDate(activeDateAsISO)
                .setDeliveryMethod("E");
        var documentAutoEnrollment = new ProviderDocument()
                .setMetadata(documentMetaDataAutoEnrollment);

        var documentMetaData = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("nonautoenrollment@optum.com")
                .setSubsribeToEmail("Y")
                .setWeekday("")
                .setDeliveryMethod("P");

        var document = new ProviderDocument()
                .setMetadata(documentMetaData);
        
        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(documentAutoEnrollment, document));

        retrieveProviderEmailAddress.execute(execution);
        assertEquals("autoenrollment@optum.com", this.metaDataObject.getString("providerEmailId"));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32444")
//    @Test
    public void testExecutionWithAutoEnrollmentInPastIndex1() throws Exception {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.MINUTE, -10);
        Date activeDate = calendar.getTime();

        TimeZone tz = TimeZone.getTimeZone("UTC");
        sdf.setTimeZone(tz);
        String activeDateAsISO = sdf.format(activeDate);
        System.out.println("activeDateAsISO=" + activeDateAsISO);

        var documentMetaDataAutoEnrollment = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("autoenrollment@optum.com")
                .setSubsribeToEmail("Y")
                .setWeekday("")
                .setActiveDate(activeDateAsISO)
                .setDeliveryMethod("E");
        var documentAutoEnrollment = new ProviderDocument()
                .setMetadata(documentMetaDataAutoEnrollment);

        var documentMetaData = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("nonautoenrollment@optum.com")
                .setSubsribeToEmail("Y")
                .setWeekday("")
                .setDeliveryMethod("P");

        var document = new ProviderDocument()
                .setMetadata(documentMetaData);

        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(documentAutoEnrollment, document));

        retrieveProviderEmailAddress.execute(execution);
        assertEquals("autoenrollment@optum.com", this.metaDataObject.getString("providerEmailId"));
    }

    //9 digits test
    @Test
    public void testTinAndMpinArePaddedToNineDigitsBeforeFDSCloudCall() throws Exception {
        execution.setVariable("useFDSCloud", true);
        execution.setVariable(Workflow.FDS_CLOUD_GET_DOCUMENT_URL, "https://test");
        execution.setVariable(Workflow.FDS_CLOUD_AUTH_URL, "https://test");
        execution.setVariable(Workflow.CLOUD_CLIENT_ID, "testapp");
        execution.setVariable(Workflow.CLOUD_CLIENT_SECRET, "testapp");
        execution.setVariable(Workflow.CLOUD_GRANT_TYPE, "client_credentials");
        ReflectionTestUtils.setField(retrieveProviderEmailAddress, "cloudSpaceId", "1234-5678s");

        // Set up metadata with short tin and mpin
        DocumentMetaData docMetaData = getDocumentMetaData();
        docMetaData.getMetadata().put("tin", "12345");
        docMetaData.getMetadata().put("mpin", "678");
        List<DocumentMetaData> docList = new ArrayList<>();
        docList.add(docMetaData);
        when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(),
                anyString(), anyString(), Mockito.anyBoolean(),isNull()))
                .thenReturn("token");

        FDSCloudGetDocumentsResponse responseBody = new FDSCloudGetDocumentsResponse();
        List<ProviderDocument> documentList = new ArrayList<>();
        ProviderDocument document = new ProviderDocument();
        ProviderDocumentMetaData documentMetaData = new ProviderDocumentMetaData();
        documentMetaData.setFrequency("D");
        documentMetaData.setProviderEmailId("foo@optum.com");
        documentMetaData.setWeekday("Monday");
        document.setMetadata(documentMetaData);
        documentList.add(document);
        responseBody.setDocuments(documentList);
        responseBody.setCount("1");

        ResponseEntity<FDSCloudGetDocumentsResponse> response = new ResponseEntity<>(responseBody, HttpStatus.ACCEPTED);

        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID_V2, "3007");

        // Capture the URI to verify the query string
        Mockito.when(restTemplate.exchange(Mockito.any(URI.class), Mockito.any(HttpMethod.class),
                        Mockito.<HttpEntity<?>>any(), Mockito.<Class<FDSCloudGetDocumentsResponse>>any()))
                .thenAnswer(invocation -> {
                    URI uri = invocation.getArgument(0);
                    String uriStr = uri.toString();
                    // tin and mpin should be left-padded to 9 digits
                    assertTrue(uriStr.contains("(tin%3D000012345)"));
                    assertTrue(uriStr.contains("(mpin%3D000000678)"));
                    return response;
                });

        retrieveProviderEmailAddress.execute(execution);
        assertNotNull(retrieveProviderEmailAddress.errorMap);
        assertEquals("foo@optum.com", docMetaData.getMetadata().getString("providerEmailId"));
        assertEquals(0, retrieveProviderEmailAddress.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "US31539")
    @RallyTestCase(references = "TC32445")
//    @Test
    public void testExecutionWithoutAutoEnrollmentTwoIndexes() throws Exception {

        var documentMetaData = new ProviderDocumentMetaData()
                .setFrequency("W")
                .setProviderEmailId("nonautoenrollment0@optum.com")
                .setSubsribeToEmail("Y")
                .setWeekday("")
                .setDeliveryMethod("P");

        var document = new ProviderDocument()
                .setMetadata(documentMetaData);

        var documentMetaData2 = new ProviderDocumentMetaData()
                .setFrequency("D")
                .setProviderEmailId("nonautoenrollment1@optum.com")
                .setSubsribeToEmail("Y")
                .setWeekday("")
                .setDeliveryMethod("P");

        var document2 = new ProviderDocument()
                .setMetadata(documentMetaData2);

        execution.setVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, "3007");
        when(documentMetaDataService.getPDODocuments(any(Document.class))).thenReturn(List.of(document, document2));

        retrieveProviderEmailAddress.execute(execution);
        assertEquals("nonautoenrollment0@optum.com", this.metaDataObject.getString("providerEmailId"));
    }

    private DocumentMetaData getDocumentMetaData() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr = "{" + "\"id\" : \"5b64d7ca78f80f005bdecba1\"," + "\"clientId\" : 1," + "\"spaceId\" : 3007,"
                + "\"appIdentifier\" : \"testapp\"," + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\"," + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\"," + "\"documentAttachments\" : [" + "{"
                + "\"id\" : \"398d8127-18d0-44b8-baba-de2d1e516088\"," + "\"index\" : 1,"
                + "\"file_name\" : \"228156_342361.pdf\"" + "}" + "]" + "}";

        String metaData = "{" + "\"providerId\" : \"sample_provider\"," + "\"fileName\" : \"228156_342361.pdf\","
                + "\"fileDescription\" : \"Commercial Prior Auth/Approved\"," + "\"createdDate\" : \"06/11/2017\","
                + "\"createApplication\" : \"sample application\"," + "\"expiryDate\" : \"05/30/2050\","
                + "\"filePath\" : \"reports/FEB2017\"," + "\"dateOfService\" : \"01/30/2017\","
                + "\"fileType\" : \"reports/FEB2017\"," + "\"tenant\" : \"suhcbo\"," + "\"claimNumber\" : \"12345678\","
                + "\"category\" : \"Benefits\"," + "\"subCategory\" : \"A1\"," + "\"policyNumber\" : \"78601\"," + "\"DMSecurityClass\" : \"CCS_HEALTH_SERVICES\"," + "\"ID\" : \"927043688\"," + "\"tenant\" : \"Link\","
                + "\"notificationNumber\" : \"A002488796\"," + "\"providerName\" : \"SHAHEEN AHMED\"," + "\"DefaultUsed\" : \"N\"," + "\"ReturnAddress6\" : \"85040\","
                + "\"MailToAddress1\" : \"SHAHEEN AHMED\"," + "\"ReturnAddress5\" : \"AZ\"," + "\"ReturnAddress4\" : \"Phoenix\"," + "\"DUPLEXSIMPLEX\" : \"D\"," + "\"PTX_ID\" : \"133757370\","
                + "\"LetterHistoryID\" : \"566857981\"," + "\"PassThruData\" : \"228156_342361\"," + "\"MailToAddress6\" : \"27216\"," + "\"MailToAddress4\" : \"BURLINGTON\"," + "\"ReturnAddress2\" : \"4425 E Cotton Center Blvd Suite 200E\","
                + "\"MailToAddress5\" : \"NC\"," + "\"ReturnAddress1\" : \"UnitedHealthcare Services, Inc. on behalf of UnitedHealthcare Insurance Company\"," + "\"MailToAddress2\" : \"PO BOX 2240\","
                + "\"SubFullNme\" : \"BERNARDA BURKS\"," + "\"docSentTo\" : \"PrintServices\"," + "\"ELGSLETTERGENID\" : \"342361\"," + "\"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\","
                + "\"expiryDate\" : \"01/30/2019\"," + "\"filePath\" : \"Commercial Prior Auth/Approved\"," + "\"ELGSREQUESTID\" : \"228156\"," + "\"createApplication\" : \"CCS Manual\","
                + "\"category\" : \"Prior Auth Notification\"," + "\"fileType\" : \"Letter\"," + "\"absolutePath\" : \"/bconnected/ingest/89de2aa36a3b43f49395116255be8c0a/10059/201808032231386585b64d7ca78f80f005bdecba1/new/\","
                + "\"tagLine\" : \"20180803223138807774411\"," + "\"ELGSREQUESTID\" : \"228156\"," + "\"ELGSREQUESTID\" : \"228156\","
                + "\"organization\" : \"Optum Technologies\","
                + "\"privilege\" : \"Electronic Payments and Statements\"," + "\"corporateMpin\" : \"001146342\","
                + "\"tin\" : \"133757370\"," + "\"mpin\" : \"002329063\"," + "\"memberId\" : \"927043688\","
                + "\"physicianName\" : \"Paramesh,Korrakuti\"," + "\"employeeName\" : \"Murthy, Sriram\","
                + "\"dateOfService\" : \"08/01/2018\"," + "\"memberName\" : \"BERNARDA BURKS\","
                + "\"emailAlertReq\" : \"Y\"" + "}" + "}";

        metaDataObject = Document.parse(metaData);
        documentMetaData = Parser.parseJson(docStr, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
        return documentMetaData;
    }
    
    private DocumentMetaData getDocumentMetaDataCSPPRA() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr = "{" + "\"id\" : \"5b64d7ca78f80f005bdecba1\"," + "\"clientId\" : 1," + "\"spaceId\" : 10403,"
                + "\"appIdentifier\" : \"testapp\"," + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\"," + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\"," + "\"documentAttachments\" : [" + "{"
                + "\"id\" : \"398d8127-18d0-44b8-baba-de2d1e516088\"," + "\"index\" : 1,"
                + "\"file_name\" : \"228156_342361.pdf\"" + "}" + "]" + "}";

        String metaData = "{" + "\"providerId\" : \"sample_provider\"," + "\"fileName\" : \"228156_342361.pdf\","
                + "\"fileDescription\" : \"Commercial Prior Auth/Approved\"," + "\"createdDate\" : \"06/11/2017\","
                + "\"createApplication\" : \"sample application\"," + "\"expiryDate\" : \"05/30/2050\","
                + "\"filePath\" : \"reports/FEB2017\"," + "\"dateOfService\" : \"01/30/2017\","
                + "\"fileType\" : \"reports/FEB2017\"," + "\"tenant\" : \"suhcbo\"," + "\"claimNumber\" : \"12345678\","
                + "\"category\" : \"Benefits\"," + "\"subCategory\" : \"P0\"," + "\"policyNumber\" : \"78601\"," + "\"DMSecurityClass\" : \"CCS_HEALTH_SERVICES\"," + "\"ID\" : \"927043688\"," + "\"tenant\" : \"Link\","
                + "\"notificationNumber\" : \"A002488796\"," + "\"providerName\" : \"SHAHEEN AHMED\"," + "\"DefaultUsed\" : \"N\"," + "\"ReturnAddress6\" : \"85040\","
                + "\"MailToAddress1\" : \"SHAHEEN AHMED\"," + "\"ReturnAddress5\" : \"AZ\"," + "\"ReturnAddress4\" : \"Phoenix\"," + "\"DUPLEXSIMPLEX\" : \"D\"," + "\"PTX_ID\" : \"133757370\","
                + "\"LetterHistoryID\" : \"566857981\"," + "\"PassThruData\" : \"228156_342361\"," + "\"MailToAddress6\" : \"27216\"," + "\"MailToAddress4\" : \"BURLINGTON\"," + "\"ReturnAddress2\" : \"4425 E Cotton Center Blvd Suite 200E\","
                + "\"MailToAddress5\" : \"NC\"," + "\"ReturnAddress1\" : \"UnitedHealthcare Services, Inc. on behalf of UnitedHealthcare Insurance Company\"," + "\"MailToAddress2\" : \"PO BOX 2240\","
                + "\"SubFullNme\" : \"BERNARDA BURKS\"," + "\"docSentTo\" : \"PrintServices\"," + "\"ELGSLETTERGENID\" : \"342361\"," + "\"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\","
                + "\"expiryDate\" : \"01/30/2019\"," + "\"filePath\" : \"Commercial Prior Auth/Approved\"," + "\"ELGSREQUESTID\" : \"228156\"," + "\"createApplication\" : \"CCS Manual\","
                + "\"category\" : \"Prior Auth Notification\"," + "\"fileType\" : \"Letter\"," + "\"absolutePath\" : \"/bconnected/ingest/89de2aa36a3b43f49395116255be8c0a/10059/201808032231386585b64d7ca78f80f005bdecba1/new/\","
                + "\"tagLine\" : \"20180803223138807774411\"," + "\"ELGSREQUESTID\" : \"228156\"," + "\"ELGSREQUESTID\" : \"228156\","
                + "\"organization\" : \"Optum Technologies\","
                + "\"privilege\" : \"Electronic Payments and Statements\"," + "\"corporateMpin\" : \"001146342\","
                + "\"tin\" : \"133757370\"," + "\"mpin\" : \"002329063\"," + "\"memberId\" : \"927043688\","
                + "\"physicianName\" : \"Paramesh,Korrakuti\"," + "\"employeeName\" : \"Murthy, Sriram\","
                + "\"dateOfService\" : \"08/01/2018\"," + "\"memberName\" : \"BERNARDA BURKS\","
                + "\"Ind_835\" : \"N\","
                + "\"emailAlertReq\" : \"N\"" + "}" + "}";

        metaDataObject = Document.parse(metaData);
        documentMetaData = Parser.parseJson(docStr, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
        return documentMetaData;
    }

    private DocumentMetaData getDocumentMetaDataemailAlertReqN() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr = "{" + "\"id\" : \"5b64d7ca78f80f005bdecba1\"," + "\"clientId\" : 1," + "\"spaceId\" : 3007,"
                + "\"appIdentifier\" : \"testapp\"," + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\"," + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\"," + "\"documentAttachments\" : [" + "{"
                + "\"id\" : \"398d8127-18d0-44b8-baba-de2d1e516088\"," + "\"index\" : 1,"
                + "\"file_name\" : \"228156_342361.pdf\"" + "}" + "]" + "}";

        String metaData = "{" + "\"providerId\" : \"sample_provider\"," + "\"fileName\" : \"228156_342361.pdf\","
                + "\"fileDescription\" : \"Commercial Prior Auth/Approved\"," + "\"createdDate\" : \"06/11/2017\","
                + "\"createApplication\" : \"sample application\"," + "\"expiryDate\" : \"05/30/2050\","
                + "\"filePath\" : \"reports/FEB2017\"," + "\"dateOfService\" : \"01/30/2017\","
                + "\"fileType\" : \"reports/FEB2017\"," + "\"tenant\" : \"suhcbo\"," + "\"claimNumber\" : \"12345678\","
                + "\"category\" : \"Benefits\"," + "\"subCategory\" : \"A1\"," + "\"policyNumber\" : \"78601\"," + "\"DMSecurityClass\" : \"CCS_HEALTH_SERVICES\"," + "\"ID\" : \"927043688\"," + "\"tenant\" : \"Link\","
                + "\"notificationNumber\" : \"A002488796\"," + "\"providerName\" : \"SHAHEEN AHMED\"," + "\"DefaultUsed\" : \"N\"," + "\"ReturnAddress6\" : \"85040\","
                + "\"MailToAddress1\" : \"SHAHEEN AHMED\"," + "\"ReturnAddress5\" : \"AZ\"," + "\"ReturnAddress4\" : \"Phoenix\"," + "\"DUPLEXSIMPLEX\" : \"D\"," + "\"PTX_ID\" : \"133757370\","
                + "\"LetterHistoryID\" : \"566857981\"," + "\"PassThruData\" : \"228156_342361\"," + "\"MailToAddress6\" : \"27216\"," + "\"MailToAddress4\" : \"BURLINGTON\"," + "\"ReturnAddress2\" : \"4425 E Cotton Center Blvd Suite 200E\","
                + "\"MailToAddress5\" : \"NC\"," + "\"ReturnAddress1\" : \"UnitedHealthcare Services, Inc. on behalf of UnitedHealthcare Insurance Company\"," + "\"MailToAddress2\" : \"PO BOX 2240\","
                + "\"SubFullNme\" : \"BERNARDA BURKS\"," + "\"docSentTo\" : \"PrintServices\"," + "\"ELGSLETTERGENID\" : \"342361\"," + "\"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\","
                + "\"expiryDate\" : \"01/30/2019\"," + "\"filePath\" : \"Commercial Prior Auth/Approved\"," + "\"ELGSREQUESTID\" : \"228156\"," + "\"createApplication\" : \"CCS Manual\","
                + "\"category\" : \"Prior Auth Notification\"," + "\"fileType\" : \"Letter\"," + "\"absolutePath\" : \"/bconnected/ingest/89de2aa36a3b43f49395116255be8c0a/10059/201808032231386585b64d7ca78f80f005bdecba1/new/\","
                + "\"tagLine\" : \"20180803223138807774411\"," + "\"ELGSREQUESTID\" : \"228156\"," + "\"ELGSREQUESTID\" : \"228156\","
                + "\"organization\" : \"Optum Technologies\","
                + "\"privilege\" : \"Electronic Payments and Statements\"," + "\"corporateMpin\" : \"001146342\","
                + "\"tin\" : \"133757370\"," + "\"mpin\" : \"002329063\"," + "\"memberId\" : \"927043688\","
                + "\"physicianName\" : \"Paramesh,Korrakuti\"," + "\"employeeName\" : \"Murthy, Sriram\","
                + "\"dateOfService\" : \"08/01/2018\"," + "\"memberName\" : \"BERNARDA BURKS\","
                + "\"emailAlertReq\" : \"N\"" + "}" + "}";

        metaDataObject = Document.parse(metaData);
        documentMetaData = Parser.parseJson(docStr, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
        return documentMetaData;
    }
    
    private HookTransactionMetaData createHookTransaction() {
    	HookTransactionMetaData hook = new HookTransactionMetaData();
    	hook.setSpaceId(3006);
    	hook.setId("12345");
    	hook.setClientId(123);
    	hook.setAppIdentifier("1234556677");
    	hook.setHookExecutionList(new ArrayList<>());
    	return hook;
    }

    @Test
    public void testFetchEmailIdFromPreferences_AccessTokenNull() throws Exception {
        // Arrange
        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), anyBoolean(), isNull()))
                .thenReturn(null);

        Method method = RetrieveProviderEmailAddress.class.getDeclaredMethod("fetchEmailIdFromPreferences", DelegateExecution.class, String.class, String.class);
        method.setAccessible(true);
        List<ProviderPreference> result = (List<ProviderPreference>) method.invoke(retrieveProviderEmailAddress, execution, "tin", "mpin");

        assertNull(result);
    }

    @Test
    public void testFetchEmailIdFromPreferences_ValidTokenButNullResponse() throws Exception {

        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), anyBoolean(), isNull()))
                .thenReturn("sometoken");
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(ProviderPreference.class)))
                .thenReturn(null);
        Method method = RetrieveProviderEmailAddress.class.getDeclaredMethod("fetchEmailIdFromPreferences", DelegateExecution.class, String.class, String.class);
        method.setAccessible(true);
        List<ProviderPreference> result = (List<ProviderPreference>) method.invoke(retrieveProviderEmailAddress, execution, "tin", "mpin");
        assertNull(result);
    }



    
}
