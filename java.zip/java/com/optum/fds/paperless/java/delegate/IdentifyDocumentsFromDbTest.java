package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.*;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.constants.ProcessKeys;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.domain.service.ProcessorService;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.io.FileUtils;
import org.bson.Document;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import static org.mockito.Mockito.when;

import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.util.Parser;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Criteria;
import com.optum.fds.paperless.workflow.service.EmailService;

@RunWith(MockitoJUnitRunner.class)
public class IdentifyDocumentsFromDbTest {

	@Value("${INGEST_ROOT}")
	private static String ingestRoot;
	
    Map<String, Object> delegateMap = new HashMap<>();

    @Rule
    public TemporaryFolder folder = new TemporaryFolder();
    
    
	@InjectMocks
	IdentifyDocumentsFromDb identifyDocumentsFromDb;

	@Mock
	DocumentMetaDataService documentMetaDataService;

	@Mock
	ProcessorService processorService;

    @Mock
    EmailService emailService;
    
    @Mock
    ErrorMetaDataService errorMetaDataService;
    
    @Mock
    HookService hookService;

    
    DelegateExecution execution;

    @Before
    public void setUp() throws Exception {
    	execution = new DelegateExecutionImpl();
        execution.setVariable(Workflow.EMAIL_RECEIVER, "test@test.com");
        execution.setVariable(Workflow.ENVIRONMENT, "test");
        execution.setVariable(Workflow.SEARCH_CRITERIA, "{\"spaceId\": 10602,\"status\" : \"AVAILABLE\", \"metadata.emailAlertReq\" : \"Y\", \"metadata.addedToResponseFile\" : { \"$exists\" : false }, $or : [{\"metadata.providerEmailId\":{$ne : \"\"}, \"metadata.sendEmailNotifications\":true, \"metadata.docVaultAPIResponse\" : true}, {\"metadata.providerEmailId\":{$eq : \"\"},\"metadata.docVaultAPIResponse\" : true}, {\"metadata.corporateMpin\" : { \"$exists\" : false }}]}");
        execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"24\",\"format\":\"Hours\"}}");
        execution.setVariable(Workflow.TEMPLATE_ID, "123456789");
        execution.setVariable(Workflow.CLIENT_ID, 123);
        execution.setVariable(Workflow.SPACE_ID, 123);
        execution.setVariable(Workflow.HOOK_ID, "123245");
        execution.setVariable(Workflow.APP_IDENTIFIER, "12345");
        execution.setVariable(Workflow.DOCUMENT_FORMAT_FIELD, "dateEmailSent");
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "addedToResponseFile");
        execution.setVariable(Workflow.SFTP_HOSTNAME, "rn000019322.uhc.com");
        execution.setVariable(Workflow.SFTP_USERNAME, "pren");
        execution.setVariable(Workflow.SFTP_PW, "uaHs7pvA");
        execution.setVariable(Workflow.SFTP_DIRECTORY, "/batch/mr_appeals_test/resp");
        execution.setVariable(Workflow.PROCESS_KEY, ProcessKeys.RESPONSEFILE_PROCESS_KEY);
        
//        when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
        
//        when(hookService.saveHookTransaction(Mockito.any())).thenReturn(new HookTransactionMetaData());
    }


    @UserStory(references = "US24352")
    @RallyTestCase(references = "TC28935")
    @Test
    public void testGetDocumentsFromDB() throws Exception {
        ArrayList<DocumentMetaData> list = new ArrayList<>();
        list.add(getDocumentMetaData());
        list.add(getDocumentMetaData2());        
        when(documentMetaDataService.getDocumentMetaData(Mockito.any(), Mockito.any())).thenReturn(list);
        identifyDocumentsFromDb.execute(execution);

//        assertNotNull(execution.getVariable(Workflow.OUTPUT_FILE_DIR));
//        File f = new File((String) execution.getVariable(Workflow.OUTPUT_FILE_DIR));
//        File fileList[] = f.listFiles();
//        assertTrue(fileList.length > 0);
//        assertNotNull(execution.getVariable(Workflow.JSON_FILE));
//        assertNotNull(execution.getVariable(Workflow.DOCUMENT_IDS_MESSAGE));
        assertNotNull(identifyDocumentsFromDb.errorMap);
    }

    @UserStory(references = "US24078")
    @RallyTestCase(references = "TC28936")
    @Test
    public void testInvalidVariableDataSearchCriteriaInExecutionBus() throws Exception {
        execution.setVariable(Workflow.SEARCH_CRITERIA, "\"metadata.docSentTo\": $eq: \"PrintServices’\"}, \"metadata.sentResponseFile\": { $exists: false}, \"spaceId\" : 8932 }");
        identifyDocumentsFromDb.execute(execution);
        assertTrue(identifyDocumentsFromDb.errorMap.size()>0);
    }

    @UserStory(references = "US24573")
    @RallyTestCase(references = "TC29084")
    @Test
    public void testInvalidVariableDataSearchWindowInExecutionBus() throws Exception {
        execution.setVariable(Workflow.SEARCH_WINDOW,"{\"start_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"24\",\"format\":\"Hours\"}");
        identifyDocumentsFromDb.execute(execution);
        assertTrue(identifyDocumentsFromDb.errorMap.size()>1);
    }

    @UserStory(references = "US24573")
    @RallyTestCase(references = "TC29086")
    @Test
    public void testInvalidVariableDataSearchWindowWithoutRequiredAttributesInExecutionBus() throws Exception {
        execution.setVariable(Workflow.SEARCH_WINDOW,"{\"start_date_offset\":{\"format\":\"Hours\"},\"end_date_offset\":{\"format\":\"Hours\"}}");
        identifyDocumentsFromDb.execute(execution);
        assertTrue(identifyDocumentsFromDb.errorMap.size()>1);
    }

//    @UserStory(references = "US24352")
//    @RallyTestCase(references = "TC28937")
//    @Test
//    public void testEmptyDataForInputFields() throws Exception {
//        ArrayList<DocumentMetaData> list = new ArrayList<>();
//        identifyDocuments.execute(execution);
//        assertTrue(execution.getVariable("exitNow", Boolean.class));
//    }

    @UserStory(references = "US24352")
    @RallyTestCase(references = "TC28938")
    @Test
    public void testGetDocumentsFromDBJsonFileFormat() throws Exception {

        ArrayList<DocumentMetaData> list = new ArrayList<>();
        list.add(getDocumentMetaData());
        list.add(getDocumentMetaData2());

        when(documentMetaDataService.getDocumentMetaData(Mockito.any(), Mockito.any())).thenReturn(list);
        identifyDocumentsFromDb.execute(execution);
        assertNotNull(identifyDocumentsFromDb.errorMap);
//        assertNotNull(execution.getVariable(Workflow.OUTPUT_FILE_DIR));
//        File f = new File((String) execution.getVariable(Workflow.OUTPUT_FILE_DIR));
//        File fileList[] = f.listFiles();
//        assertTrue(fileList.length>0);
//        assertTrue(execution.getVariable(Workflow.JSON_FILE)!=null);
//        System.out.println(FileUtils.readFileToString(new File((String)execution.getVariable(Workflow.JSON_FILE))));
    }

    @UserStory(references = "US24352")
    @RallyTestCase(references = "TC28939")
    @Test
    public void testGetDocumentsFromDBWithException() throws Exception {
        ArrayList<DocumentMetaData> list = new ArrayList<>();
        list.add(getDocumentMetaData());
        when(documentMetaDataService.getDocumentMetaData(Mockito.any(), Mockito.any())).thenReturn(list);
        identifyDocumentsFromDb.execute(execution);
        assertNotNull(identifyDocumentsFromDb.errorMap);
    }

    @UserStory(references = "US24352")
    @RallyTestCase(references = "TC29023")
    @Test
    public void testGetDocumentsFromDBWithNullSearchWindow() throws Exception {
        execution.setVariable(Workflow.SEARCH_CRITERIA, null);
        identifyDocumentsFromDb.execute(execution);
        assertTrue(identifyDocumentsFromDb.errorMap.size()>1);
    }

    private DocumentMetaData getDocumentMetaData() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr = "{"
                + "\"id\" : \"593e9fadef8654760f6b464c\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 3007,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\","
                + "\"documentAttachments\" : ["
                + "{"
                + "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
                + "\"index\" : 1,"
                + "\"file_name\" : \"balloon.jpg\","
                + "\"status\" : \"AVAILABLE\""
                + "}"
                + "]"
                + "}";

        String metaData =     "{"
                + "\"providerId\" : \"sample_provider\","
                + "\"fileName\" : \"birds3\","
                + "\"fileDescription\" : \"very simple file\","
                + "\"createdDate\" : \"06/11/2017\","
                + "\"createApplication\" : \"sample application\","
                + "\"expiryDate\" : \"05/30/2050\","
                + "\"filePath\" : \"reports/FEB2017\","
                + "\"dateOfService\" : \"01/30/2017\","
                + "\"fileType\" : \"reports/FEB2017\","
                + "\"tenant\" : \"suhcbo\","
                + "\"claimNumber\" : \"12345678\","
                + "\"category\" : \"Benefits\","
                + "\"subCategory\" : \"Transactions\","
                + "\"organization\" : \"Optum Technologies\","
                + "\"privilege\" : \"Electronic Payments and Statements\","
                + "\"corporateMpin\" : \"002535119\","
                + "\"tin\" : \"201459415\","
                + "\"mpin\" : \"12345\","
                + "\"memberId\" : \"45678123\","
                + "\"physicianName\" : \"Paramesh,Korrakuti\","
                + "\"employeeName\" : \"Murthy, Sriram\","
                + "\"dateOfService\" : \"05/30/2017\","
                + "\"memberName\" : \"Balaji, Ramalingam\","
                + "\"emailAlertReq\" : \"Y\""
                + "}"
                + "}";
        Document metaDataObject = Document.parse(metaData);
        documentMetaData = Parser.parseJson(docStr, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);

        System.out.println(documentMetaData);
        return documentMetaData;
    }

    private DocumentMetaData getDocumentMetaData2() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr2 = "{"
                + "\"id\" : \"593e9fadef8654760f6b464c\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 3007,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\","
                + "\"documentAttachments\" : ["
                + "{"
                + "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
                + "\"index\" : 1,"
                + "\"file_name\" : \"balloon.jpg\","
                + "\"status\" : \"AVAILABLE\""
                + "}"
                + "]"
                + "}";

        String metaData2 =     "{"
                + "\"providerId\" : \"sample_provider\","
                + "\"fileName\" : \"birds3\","
                + "\"fileDescription\" : \"very simple file\","
                + "\"createdDate\" : \"06/11/2017\","
                + "\"createApplication\" : \"sample application\","
                + "\"expiryDate\" : \"05/30/2050\","
                + "\"filePath\" : \"reports/FEB2017\","
                + "\"dateOfService\" : \"01/30/2017\","
                + "\"fileType\" : \"reports/FEB2017\","
                + "\"tenant\" : \"suhcbo\","
                + "\"claimNumber\" : \"12345678\","
                + "\"category\" : \"Benefits\","
                + "\"subCategory\" : \"Transactions\","
                + "\"organization\" : \"Optum Technologies\","
                + "\"privilege\" : \"Electronic Payments and Statements\","
                + "\"corporateMpin\" : \"002535119\","
                + "\"tin\" : \"201459415\","
                + "\"mpin\" : \"12345\","
                + "\"memberId\" : \"45678123\","
                + "\"physicianName\" : \"Paramesh,Korrakuti\","
                + "\"employeeName\" : \"Murthy, Sriram\","
                + "\"dateOfService\" : \"05/30/2017\","
                + "\"memberName\" : \"Balaji, Ramalingam\","
                + "\"emailAlertReq\" : \"Y\""
                + "}"
                + "}";
        Document metaDataObject = Document.parse(metaData2);
        documentMetaData = Parser.parseJson(docStr2, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);

        System.out.println(documentMetaData);
        return documentMetaData;


    }
}
