package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.constants.WorkflowConstants;
import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.File;
import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TransformJsonAndGenerateFileTest {

    @InjectMocks
    private TransformJsonAndGenerateFile transformJsonAndGenerateFile;

    @Mock
    private ProcessorFileTaskService processorFileTaskService;

    @Mock
    private ProcessorsService processorsService;

    @Mock
    private EmailService emailService;

    @Rule
    public TemporaryFolder folder = new TemporaryFolder();

    private DelegateExecution execution = new DelegateExecutionImpl();

    private final String PATH_JSON_FILE = "InputJson/TransformJsonAndGenerateFileTest.json";


    @Before
    public void setUp() {
        // No stubbing is required for this test
    }

    @Test
    public void testDoExecute() throws Exception {
        execution.setVariable("addOriginalZipFileName", true);
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "addedToResponseFile");
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, true);
        execution.setVariable(Workflow.ACK_FILE_DATA,true);
        execution.setVariable(Workflow.TEMPLATE_NAME, "NGSResponse");
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, folder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.SFTP_FILENAME, "FDS_NGS_Response");

        transformJsonAndGenerateFile.execute(execution);

        assertTrue(execution.getVariable(Workflow.RESPONSE_FILE_NAME_MESSAGE, String.class).contains("FDS_NGS_Response"));

    }

    @Test
    public void testDoExecuteInvalidFile() throws Exception {
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "addedToResponseFile");
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, true);
        execution.setVariable(Workflow.TEMPLATE_NAME, "NGSResponse");
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile + "invalid");
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, folder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.SFTP_FILENAME, "FDS_NGS_Response");

        transformJsonAndGenerateFile.execute(execution);
        assertNotNull(transformJsonAndGenerateFile.errorMap);
        assertFalse(transformJsonAndGenerateFile.errorMap.isEmpty());
    }

    @Test
    public void testDoExecuteCosmosPRA() throws Exception {
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "addedToResponseFile");
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, true);
        execution.setVariable(Workflow.TEMPLATE_NAME, "NGSResponse");
        execution.setVariable(Workflow.ACK_FILE_DATA,false);
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, folder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.SFTP_FILENAME, "PRA_COSMOS_FDS");

        transformJsonAndGenerateFile.execute(execution);

        assertTrue(execution.getVariable(Workflow.RESPONSE_FILE_NAME_MESSAGE, String.class).contains("PRA_COSMOS_FDS"));

    }

    @Test
    public void testGetSecureRandomNumber() throws Exception {
        // Use reflection to access the private method
        java.lang.reflect.Method method = TransformJsonAndGenerateFile.class.getDeclaredMethod("getSecureRandomNumber");
        method.setAccessible(true);

        // Invoke the private method
        String result = (String) method.invoke(transformJsonAndGenerateFile);

        // Assert that the result is a non-null string of 8 digits
        assertNotNull(result);
        assertEquals(8, result.length());
        assertTrue(result.matches("\\d{8}"));
    }

    @Test
    public void testGetFilePathForCsvFormat() throws Exception {
        // Use reflection to access the private method
        java.lang.reflect.Method method = TransformJsonAndGenerateFile.class.getDeclaredMethod("getFilePath", String.class, String.class, String.class);
        method.setAccessible(true);

        // Define test inputs
        String tempWorkingPath = "/tmp";
        String sftpFileName = "testFile";
        String format = "csv";

        // Invoke the private method
        String result = (String) method.invoke(transformJsonAndGenerateFile, tempWorkingPath, sftpFileName, format);

        // Assert that the result contains the expected file path and extension
        assertNotNull(result);
        assertTrue(result.startsWith(tempWorkingPath + "/testFile_"));
        assertTrue(result.endsWith(".csv"));
    }

    @Test
    public void testGetFilePathForJsonFormat() throws Exception {
        // Use reflection to access the private method
        java.lang.reflect.Method method = TransformJsonAndGenerateFile.class.getDeclaredMethod("getFilePath", String.class, String.class, String.class);
        method.setAccessible(true);

        // Define test inputs
        String tempWorkingPath = "/tmp";
        String sftpFileName = "testFile";
        String format = "json";

        // Invoke the private method
        String result = (String) method.invoke(transformJsonAndGenerateFile, tempWorkingPath, sftpFileName, format);

        // Assert that the result contains the expected file path and extension
        assertNotNull(result);
        assertTrue(result.startsWith(tempWorkingPath + "/testFile_"));
        assertTrue(result.endsWith(".json"));
    }

    @Test
    public void testDateCasting() {
        Long timestamp = 1672531200000L; // Example timestamp
        String result = transformJsonAndGenerateFile.dateCasting(timestamp);
        assertNotNull(result);
        assertTrue(result.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z"));
    }

    @Test
    public void testIsDataFieldLong() {
        assertTrue(transformJsonAndGenerateFile.isDataFieldLong(123456789L));
        assertFalse(transformJsonAndGenerateFile.isDataFieldLong(123.45));
        assertFalse(transformJsonAndGenerateFile.isDataFieldLong("123456789"));
    }

    @Test
    public void testIsDataFieldDouble() {
        assertTrue(transformJsonAndGenerateFile.isDataFieldDouble(123.45));
        assertFalse(transformJsonAndGenerateFile.isDataFieldDouble(123456789L));
        assertFalse(transformJsonAndGenerateFile.isDataFieldDouble("123.45"));
    }

    @Test
    public void testGetFilePathForTxtFormat() throws Exception {
        java.lang.reflect.Method method = TransformJsonAndGenerateFile.class.getDeclaredMethod("getFilePath", String.class, String.class, String.class);
        method.setAccessible(true);

        String tempWorkingPath = "/tmp";
        String sftpFileName = "testFile";
        String format = "txt";

        String result = (String) method.invoke(transformJsonAndGenerateFile, tempWorkingPath, sftpFileName, format);

        assertNotNull(result);
        assertTrue(result.startsWith(tempWorkingPath + "/testFile_"));
        assertTrue(result.endsWith(".txt"));
    }

    @Test
    public void testProcessDocumentMetadataAddsDetails() {
        DocumentMetaData doc = new DocumentMetaData();
        Map<String, Object> metadata = new HashMap<>();
        List<Map<String, Object>> errorList = List.of(
                Map.of("detail", "Error 1"),
                Map.of("detail", "Error 2")
        );
        metadata.put("errorList", errorList);
        doc.setMetadata(new Document(metadata));

        List<DocumentMetaData> documentList = List.of(doc);
        List<String> documentIdsList = new ArrayList<>();
        DelegateExecution execution = Mockito.mock(DelegateExecution.class);
        Mockito.when(execution.getVariable("ackFileData", Boolean.class)).thenReturn(true);

        TransformJsonAndGenerateFile delegate = new TransformJsonAndGenerateFile();
        delegate.processDocumentMetadata(execution, documentList, documentIdsList);
        List<String> details = (List<String>) doc.getMetadata().get("details");
        assertNotNull(details);
        assertEquals(2, details.size());
        assertEquals("Error 1", details.get(0));
        assertEquals("Error 2", details.get(1));
    }


}