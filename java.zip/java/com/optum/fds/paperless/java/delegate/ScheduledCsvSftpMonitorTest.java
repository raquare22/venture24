package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.*;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.Session;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorRowTask;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.CsvProcessorServiceImpl;
import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.domain.service.SendQueueService;
import com.optum.fds.paperless.exception.ValidationException;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.processors.CsvProcessorsMonitor;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.SftpMonitorUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class ScheduledCsvSftpMonitorTest {

	@Mock
	ProcessorService processorService;

	@Mock
	ProcessorsService processorsService;

	@Mock
	SftpMonitorUtil sftpMonitorUtil;

	@Mock
	CsvToJsonFile csvToJsonFile;

	@Mock
	CsvProcessorsService csvProcessorsService;

	@Mock(name = "CsvProcessorService")
	CsvProcessorService csvProcessorService;

	@Mock
	CsvProcessorsMonitor csvProcessorsMonitor;

	@Mock
	SendQueueService sendQueueService;

	@Mock
	CsvCleanupFilesProcess csvCleanupFilesProcess;

	@Mock
	ProcessorMetaData processorMetaData;

	@Mock
	DocumentMetaData documentMetaData;

	@Mock
	CsvProcessorTransaction csvProcessorTransaction;

	@Mock
	CsvProcessorRowTask csvProcessorRowTask;

	@InjectMocks
	ScheduledCsvSftpMonitor scheduledCsvSftpMonitor;

	DelegateExecution execution;

	@SuppressWarnings("deprecation")
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);

	}

	@SuppressWarnings("static-access")
	@Test
	public void testValidateFileExtnIsSuccess() {
		String includeRegEx = "[0-9]+";
		String fileName = "362.zip";
		String excludeRegEx = "^[a-zA-Z]*$";
		var valid1 = false;
		var valid2 = false;
		if (StringUtils.isEmpty(includeRegEx)) {
			includeRegEx = "([^\\s]+(\\.(?i)(csv))$)";
		}
		var fileExtnPtrn = Pattern.compile(includeRegEx);
		var mtch = fileExtnPtrn.matcher(fileName);
		if (mtch.matches())
			valid1 = true;

		if (!StringUtils.isEmpty(excludeRegEx)) {
			var fileExtnPtrn2 = Pattern.compile(excludeRegEx);
			var mtch2 = fileExtnPtrn2.matcher(fileName);
			if (!mtch2.matches())
				valid2 = true;
		} else {
			valid2 = true;
		}
		boolean expected = (valid1 && valid2);

		assertEquals(expected, scheduledCsvSftpMonitor.validateFileExtn(fileName, includeRegEx, excludeRegEx));
	}

	@SuppressWarnings({ "null", "rawtypes" })
	@Test
	public void testRunCsvSFTPMonitorThrowsNullException() throws IOException {

		Map<String, Map<String, String>> config = new HashMap<>();
		Map<String, String> testMap = new HashMap<String, String>();
		testMap.put("space_id", "21369");
		testMap.put("appIdentifier", "sdsdsd233rrt45y");
		testMap.put("host_name_source", "namwe");
		testMap.put("username_source", "source");
		testMap.put("pw_source", "ssdds.sddsd");
		testMap.put("includeFileNameRegExPattern", "[0-9]+");
		testMap.put("excludeFileNameRegExPattern", "^[a-zA-Z]*$");
		testMap.put("ftp_rootdir", "/root");
		testMap.put("ftp_archivedir", "/arch");

		config.put("config", testMap);

//		when(sftpMonitorUtil.isMissingLoginCredential("sftpHost", "sftpUSER", "sftpPASS", "/sftpWorkingDir")).thenReturn(true);
		when(processorMetaData.getProcess().get("config")).thenReturn(config);
		when(sftpMonitorUtil.hasValidStatus(processorMetaData)).thenReturn(true);

		// *** to be done
//		(ArrayList<ChannelSftp.LsEntry>) processSftpResults.get(DIRECTORY_LISTING)
//		
//		ArrayList<ChannelSftp.LsEntry> chL = new ArrayList<ChannelSftp.LsEntry>();
//		LsEntry ls1 = new LsEntry("filename.zip", "longname", null);
//		Map processSftpResults = Mockito.mock(Map.class);
//		Map<String, Object> processSftpResults = null;
//		when(processSftpResults.get("directoryListing")).thenReturn(true);
		scheduledCsvSftpMonitor.runCsvSFTPMonitor(execution, processorMetaData);
	}

	@Test(expected = NullPointerException.class)
	public void testCreatePdoRecordThrowsNullException() throws IOException {

		DocumentMetaData dMd = new DocumentMetaData();
		when(csvProcessorsService.createCsvRecord(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(dMd);

		Map<String, Object> requestMap = new HashMap<String, Object>();
		requestMap.put(Workflow.TIN, "822349655");
		requestMap.put(Workflow.MPIN, "007759433");
		requestMap.put(Workflow.FILE_NAME, "1412148208_1412148211.pdf");
		requestMap.put(Workflow.FILE_TYPE, "pdf");
		requestMap.put(Workflow.PROVIDER_EMAIL_ID, "test@test.com");
		requestMap.put(Workflow.FREQUENCY, "5");
		requestMap.put(Workflow.DELIVERY_METHOD, "eDelivery");
		requestMap.put(Workflow.OK_TO_CHANGE_PDO_IND, "");
		requestMap.put(Workflow.AUTO_EDEL_UPDATE_IND, "");

		Gson gson = new GsonBuilder().create();
		String jsonString = gson.toJson(requestMap);
		scheduledCsvSftpMonitor.createPdoRecord(jsonString);
//		csvProcessorsService.createCsvRecord(PDOSpaceId, PDOAppId, tin, mpin, fileName, fileType, providerEmailId, frequency, deliveryMethod,
//				okToChangePdoInd, autoEdelUpdateInd, MetaDataStatus.AVAILABLE)
//		Mockito.verify(scheduledCsvSftpMonitor, Mockito.times(1)).createPdoRecord(jsonString);

	}

	@Test
	public void testCreatePdoRecordException() throws IOException {

//		 csvProcessorsService.createCsvRecord(PDOSpaceId, PDOAppId, tin, mpin, fileName, fileType, providerEmailId, frequency, deliveryMethod,
//					okToChangePdoInd, autoEdelUpdateInd, MetaDataStatus.AVAILABLE)
		DocumentMetaData dMd = new DocumentMetaData();
		when(csvProcessorsService.createCsvRecord(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(dMd);
		scheduledCsvSftpMonitor.createPdoRecord("");
//		doThrow(new Exception()).when(scheduledCsvSftpMonitor).createPdoRecord("");
//		Mockito.verify(scheduledCsvSftpMonitor, Mockito.times(1)).createPdoRecord("");
	}

//	@Test(expected = NullPointerException.class)
////	@Test
//	public void testFlushRecordWithRestApiTrueException() throws IOException, ValidationException {
//		Map<String, Object> requestMap = new HashMap<String, Object>();
//		requestMap.put(Workflow.TIN, "822349655");
//		requestMap.put(Workflow.MPIN, "007759433");
//		requestMap.put(Workflow.FILE_NAME, "1412148208_1412148211.pdf");
//		requestMap.put(Workflow.FILE_TYPE, "pdf");
//		requestMap.put(Workflow.PROVIDER_EMAIL_ID, "test@test.com");
//		requestMap.put(Workflow.FREQUENCY, "5");
//		requestMap.put(Workflow.DELIVERY_METHOD, "eDelivery");
//		requestMap.put(Workflow.OK_TO_CHANGE_PDO_IND, "");
//		requestMap.put(Workflow.AUTO_EDEL_UPDATE_IND, "");
//
//		Gson gson = new GsonBuilder().create();
//		String jsonString = gson.toJson(requestMap);
//		StringBuilder sb = new StringBuilder(jsonString);
//
//		CsvProcessorRowTask rt = new CsvProcessorRowTask();
//		when(csvProcessorService.getCsvProcessorRowTaskByProcessorTransactionIdRowNumber(Mockito.anyString(),
//				Mockito.anyInt())).thenReturn(rt);
//
//		scheduledCsvSftpMonitor.flushRecord(sb.toString(), csvProcessorTransaction, 236595, "1412148208_1412148211.pdf",
//				"test.json", 1, Map.of("one", "valueOne"), false, true, "appid7567576");
//
//	}

//	@Test(expected = NullPointerException.class)
////	@Test
//	public void testFlushRecordWithRestApiFalseException() throws IOException, ValidationException {
//		Map<String, Object> requestMap = new HashMap<String, Object>();
//		requestMap.put(Workflow.TIN, "822349655");
//		requestMap.put(Workflow.MPIN, "007759433");
//		requestMap.put(Workflow.FILE_NAME, "1412148208_1412148211.pdf");
//		requestMap.put(Workflow.FILE_TYPE, "pdf");
//		requestMap.put(Workflow.PROVIDER_EMAIL_ID, "test@test.com");
//		requestMap.put(Workflow.FREQUENCY, "5");
//		requestMap.put(Workflow.DELIVERY_METHOD, "eDelivery");
//		requestMap.put(Workflow.OK_TO_CHANGE_PDO_IND, "");
//		requestMap.put(Workflow.AUTO_EDEL_UPDATE_IND, "");
//
//		Gson gson = new GsonBuilder().create();
//		String jsonString = gson.toJson(requestMap);
//		StringBuilder sb = new StringBuilder(jsonString);
//
//		CsvProcessorRowTask rt = new CsvProcessorRowTask();
//		when(csvProcessorService.getCsvProcessorRowTaskByProcessorTransactionIdRowNumber(Mockito.anyString(),
//				Mockito.anyInt())).thenReturn(rt);
//
//		scheduledCsvSftpMonitor.flushRecord(sb.toString(), csvProcessorTransaction, 236595, "1412148208_1412148211.pdf",
//				"test.json", 1, Map.of("one", "valueOne"), false, false, "appid7567576");
//
//	}

//	@Test
//	public void testTraverseCsvFile() {
////		CsvProcessorTransaction csvProcessorTransaction, Integer configSpaceId, String fileName, String jsonFileName, File jsonFileToProcess,
////		Map<String, Object> restApiJobAttrs, boolean restApi
//		CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
//		Integer configSpaceId = 362555;
//		String fileName = "testfile";
//		String jsonFileName = "src/test/resources/TransformJsonAndGenerateFile/UpdateProcessorTransactionMetadataJsonExample.json";
//		File jsonFileToProcess = new File(jsonFileName);
//
//		Map<String, Object> restApiJobAttrs = new HashMap<String, Object>();
//		scheduledCsvSftpMonitor.traverseCsvFile(csvProcessorTransaction, configSpaceId, fileName, jsonFileName,
//				jsonFileToProcess, restApiJobAttrs, false, "apid74747");
//
//	}

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void testRunCsvSFTPMonitor_invalidFileName_branchElse() throws Exception {
        DelegateExecution execution = Mockito.mock(DelegateExecution.class);
        ProcessorMetaData processor = Mockito.mock(ProcessorMetaData.class);

        Map<String, String> cfg = new HashMap<>();
        cfg.put("space_id", "21369");
        cfg.put("appIdentifier", "app1");
        cfg.put("host_name_source", "host");
        cfg.put("username_source", "user");
        cfg.put("pw_source", "pass");
        cfg.put("includeFileNameRegExPattern", "[0-9]+");
        cfg.put("excludeFileNameRegExPattern", "^[a-zA-Z]*$");
        cfg.put("ftp_rootdir", "/root");
        cfg.put("ftp_archivedir", "/arch");

        Map<String, Object> process = new HashMap<>();
        process.put("config", cfg);

        when(processor.getProcess()).thenReturn(process);
        when(processor.getId()).thenReturn("p1");
        when(processor.getAppIdentifier()).thenReturn("app1");

        when(sftpMonitorUtil.isMissingLoginCredential(anyString(), anyString(), anyString(), anyString())).thenReturn(false);
        when(sftpMonitorUtil.hasValidStatus(processor)).thenReturn(true);

        ChannelSftp.LsEntry badEntry = Mockito.mock(ChannelSftp.LsEntry.class);
        when(badEntry.getFilename()).thenReturn("abc.zip"); // fails include [0-9]+

        ArrayList<ChannelSftp.LsEntry> listing = new ArrayList<>();
        listing.add(badEntry);

        Map<String, Object> sftpResults = new HashMap<>();
        sftpResults.put("directoryListing", listing);
        sftpResults.put("channelSftp", Mockito.mock(ChannelSftp.class));
        sftpResults.put("sftpSession", Mockito.mock(Session.class));
        sftpResults.put("channel", Mockito.mock(Channel.class));

        when(sftpMonitorUtil.proccessSFTPDirectory(anyString(), anyString(), anyString(), anyString())).thenReturn(sftpResults);

        scheduledCsvSftpMonitor.runCsvSFTPMonitor(execution, processor);

        verify(processorsService, never()).createTransactionRecord(any());
        verify(csvCleanupFilesProcess, never()).doExecute(any());
        verify(processorsService, times(1)).setLastRunAndStatus(eq("p1"), any());
    }

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void testRunCsvSFTPMonitor_duplicateFile_branchElse() throws Exception {
        DelegateExecution execution = Mockito.mock(DelegateExecution.class);
        ProcessorMetaData processor = Mockito.mock(ProcessorMetaData.class);

        Map<String, String> cfg = new HashMap<>();
        cfg.put("space_id", "21369");
        cfg.put("appIdentifier", "app1");
        cfg.put("host_name_source", "host");
        cfg.put("username_source", "user");
        cfg.put("pw_source", "pass");
        cfg.put("includeFileNameRegExPattern", "[0-9]+");
        cfg.put("excludeFileNameRegExPattern", "^[a-zA-Z]*$");
        cfg.put("ftp_rootdir", "/root");
        cfg.put("ftp_archivedir", "/arch");

        Map<String, Object> process = new HashMap<>();
        process.put("config", cfg);

        when(processor.getProcess()).thenReturn(process);
        when(processor.getId()).thenReturn("p2");
        when(processor.getAppIdentifier()).thenReturn("app1");

        when(sftpMonitorUtil.isMissingLoginCredential(anyString(), anyString(), anyString(), anyString())).thenReturn(false);
        when(sftpMonitorUtil.hasValidStatus(processor)).thenReturn(true);

        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        when(entry.getFilename()).thenReturn("362"); // valid include [0-9]+

        ArrayList<ChannelSftp.LsEntry> listing = new ArrayList<>();
        listing.add(entry);

        Map<String, Object> sftpResults = new HashMap<>();
        sftpResults.put("directoryListing", listing);
        sftpResults.put("channelSftp", Mockito.mock(ChannelSftp.class));
        sftpResults.put("sftpSession", Mockito.mock(Session.class));
        sftpResults.put("channel", Mockito.mock(Channel.class));

        when(sftpMonitorUtil.proccessSFTPDirectory(anyString(), anyString(), anyString(), anyString())).thenReturn(sftpResults);
        when(csvProcessorsService.findProcessorMetaDataByFileName(eq("362"), eq("app1"))).thenReturn(Mockito.mock(ProcessorMetaData.class));

        scheduledCsvSftpMonitor.runCsvSFTPMonitor(execution, processor);

        verify(processorsService, never()).createTransactionRecord(any());
        verify(csvCleanupFilesProcess, never()).doExecute(any());
        verify(processorsService, times(1)).setLastRunAndStatus(eq("p2"), any());
    }

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void testRunCsvSFTPMonitor_validAndNotDuplicate_directoryExists_branch() throws Exception {
        DelegateExecution execution = Mockito.mock(DelegateExecution.class);
        ProcessorMetaData processor = Mockito.mock(ProcessorMetaData.class);

        Map<String, String> cfg = new HashMap<>();
        cfg.put("space_id", "21369");
        cfg.put("appIdentifier", "app1");
        cfg.put("host_name_source", "host");
        cfg.put("username_source", "user");
        cfg.put("pw_source", "pass");
        cfg.put("includeFileNameRegExPattern", "[0-9]+");
        cfg.put("excludeFileNameRegExPattern", "^[a-zA-Z]*$");
        cfg.put("ftp_rootdir", "/root");
        cfg.put("ftp_archivedir", "/arch");

        Map<String, Object> process = new HashMap<>();
        process.put("config", cfg);

        when(processor.getProcess()).thenReturn(process);
        when(processor.getId()).thenReturn("p3");
        when(processor.getAppIdentifier()).thenReturn("app1");

        when(sftpMonitorUtil.isMissingLoginCredential(anyString(), anyString(), anyString(), anyString())).thenReturn(false);
        when(sftpMonitorUtil.hasValidStatus(processor)).thenReturn(true);

        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        when(entry.getFilename()).thenReturn("362");

        ArrayList<ChannelSftp.LsEntry> listing = new ArrayList<>();
        listing.add(entry);

        Map<String, Object> sftpResults = new HashMap<>();
        sftpResults.put("directoryListing", listing);
        sftpResults.put("channelSftp", Mockito.mock(ChannelSftp.class));
        sftpResults.put("sftpSession", Mockito.mock(Session.class));
        sftpResults.put("channel", Mockito.mock(Channel.class));

        when(sftpMonitorUtil.proccessSFTPDirectory(anyString(), anyString(), anyString(), anyString())).thenReturn(sftpResults);
        when(csvProcessorsService.findProcessorMetaDataByFileName(eq("362"), eq("app1"))).thenReturn(null);

        String existingDir = System.getProperty("java.io.tmpdir") + File.separator + "csv-existing-dir";
        new File(existingDir).mkdirs();
        when(sftpMonitorUtil.createFileOutputDirectoryPath(any(), eq(processor), eq("362"))).thenReturn(existingDir);

        when(processorsService.createTransactionRecord(processor)).thenReturn(new Transaction());

        scheduledCsvSftpMonitor.runCsvSFTPMonitor(execution, processor);

        verify(processorsService, times(1)).createTransactionRecord(processor);
        verify(csvProcessorsService, never()).createCsvProcessorTransaction(any(), anyString(), anyString(), anyString());
        verify(csvCleanupFilesProcess, never()).doExecute(any());
        verify(processorsService, times(1)).setLastRunAndStatus(eq("p3"), any());
    }

    @Test
    public void testTraverseCsvFile_returnsTrue_twoRows_firstAndLastBranches() throws Exception {
        CsvProcessorTransaction txn = Mockito.mock(CsvProcessorTransaction.class);

        ScheduledCsvSftpMonitor spyMonitor = Mockito.spy(scheduledCsvSftpMonitor);
        doReturn(true).when(spyMonitor).flushRecord(anyMap(), eq(txn), eq(21369), eq("f.csv"), eq("rows.json"), anyInt(), anyBoolean(), eq("app1"));

        File tempJson = File.createTempFile("rows-", ".json");
        Files.writeString(tempJson.toPath(), "[{\"a\":\"1\"},{\"b\":\"2\"}]", StandardCharsets.UTF_8);

        boolean result = spyMonitor.traverseCsvFile(txn, 21369, "f.csv", "rows.json", tempJson, "app1");

        assertTrue(result);
        verify(spyMonitor, times(1)).flushRecord(anyMap(), eq(txn), eq(21369), eq("f.csv"), eq("rows.json"), eq(1), eq(false), eq("app1"));
        verify(spyMonitor, times(1)).flushRecord(anyMap(), eq(txn), eq(21369), eq("f.csv"), eq("rows.json"), eq(2), eq(true), eq("app1"));
    }

    @Test
    public void testTraverseCsvFile_returnsFalse_onIOException_branch() throws Exception {
        CsvProcessorTransaction txn = Mockito.mock(CsvProcessorTransaction.class);
        File missing = new File(System.getProperty("java.io.tmpdir"), "does-not-exist-" + System.nanoTime() + ".json");

        ScheduledCsvSftpMonitor spyMonitor = Mockito.spy(scheduledCsvSftpMonitor);
        boolean result = spyMonitor.traverseCsvFile(txn, 21369, "f.csv", "missing.json", missing, "app1");

        assertFalse(result);
        verify(spyMonitor, never()).flushRecord(anyMap(), any(), anyInt(), anyString(), anyString(), anyInt(), anyBoolean(), anyString());
    }

    @Test
    public void testFlushRecord_emptyMap_returnsFalse_branch() {
        CsvProcessorTransaction txn = Mockito.mock(CsvProcessorTransaction.class);
        Map<String, Object> request = new HashMap<>();

        boolean result = scheduledCsvSftpMonitor.flushRecord(request, txn, 1, "f.csv", "j.json", 1, false, "app1");

        assertFalse(result);
        verify(csvProcessorsService, never()).createCsvProcessorRowTask(any(), anyInt(), anyString(), anyString(), anyInt(), anyString(), anyString(), any());
    }

    @Test
    public void testFlushRecord_firstRecordNotLast_branch() {
        CsvProcessorTransaction txn = Mockito.mock(CsvProcessorTransaction.class);
        DocumentMetaData dmd = Mockito.mock(DocumentMetaData.class);
        when(dmd.getId()).thenReturn("doc1");
        when(csvProcessorsService.createCsvRecord(eq(21369), eq("app1"), eq(MetaDataStatus.AVAILABLE), anyMap()))
                .thenReturn(dmd);

        Map<String, Object> request = new HashMap<>();
        request.put("k", "v");

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            ProcessorExecutionRecord execRecord = Mockito.mock(ProcessorExecutionRecord.class);

            util.when(() -> ProcessorTaskUtil.createProcessorExecutionRecord(anyString(), eq(txn)))
                    .thenReturn(execRecord);

            boolean result = scheduledCsvSftpMonitor.flushRecord(
                    request, txn, 21369, "f.csv", "j.json", 1, false, "app1"
            );

            assertTrue(result);
            verify(csvProcessorsService, times(1)).createCsvProcessorRowTask(
                    eq(txn), eq(21369), eq("f.csv"), eq("j.json"), eq(1), anyString(), eq("doc1"), eq(MetaDataStatus.COMPLETE)
            );
            util.verify(() -> ProcessorTaskUtil.createProcessorExecutionRecord(
                    eq("Posted first CSV documents to PRUN"), eq(txn)
            ), times(1));
        }
    }

    @Test
    public void testFlushRecord_lastRecord_branch() {
        CsvProcessorTransaction txn = Mockito.mock(CsvProcessorTransaction.class);
        DocumentMetaData dmd = Mockito.mock(DocumentMetaData.class);
        when(dmd.getId()).thenReturn("doc2");
        when(csvProcessorsService.createCsvRecord(eq(21369), eq("app1"), eq(MetaDataStatus.AVAILABLE), anyMap()))
                .thenReturn(dmd);

        Map<String, Object> request = new HashMap<>();
        request.put("k", "v");

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            ProcessorExecutionRecord execRecord = Mockito.mock(ProcessorExecutionRecord.class);

            util.when(() -> ProcessorTaskUtil.createProcessorExecutionRecord(anyString(), eq(txn)))
                    .thenReturn(execRecord);

            boolean result = scheduledCsvSftpMonitor.flushRecord(
                    request, txn, 21369, "f.csv", "j.json", 3, true, "app1"
            );

            assertTrue(result);

            util.verify(() -> ProcessorTaskUtil.createProcessorExecutionRecord(
                    "Posted 3 CSV documents to PRUN", txn
            ), times(1));

            // arg0 is null in actual invocation based on failure output
            util.verify(() -> ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(
                    null, txn, execRecord
            ), times(1));
        }
    }

    @Test
    public void testCreateCsvRecord_removesBlankStrings_keepsNonBlankAndNonString() {
        DocumentMetaData dmd = Mockito.mock(DocumentMetaData.class);
        when(dmd.getId()).thenReturn("doc3");
        when(csvProcessorsService.createCsvRecord(eq(100), eq("appX"), eq(MetaDataStatus.AVAILABLE), anyMap())).thenReturn(dmd);

        Map<String, Object> request = new HashMap<>();
        request.put("blank1", "");
        request.put("blank2", "   ");
        request.put("ok", "value");
        request.put("num", 5);

        DocumentMetaData out = scheduledCsvSftpMonitor.createCsvRecord(request, 100, "appX");

        assertNotNull(out);
        verify(csvProcessorsService, times(1)).createCsvRecord(eq(100), eq("appX"), eq(MetaDataStatus.AVAILABLE), argThat(map ->
                map.size() == 2 &&
                        "value".equals(map.get("ok")) &&
                        Integer.valueOf(5).equals(map.get("num")) &&
                        !map.containsKey("blank1") &&
                        !map.containsKey("blank2")
        ));
    }
}
