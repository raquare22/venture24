package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.optum.fds.paperless.domain.service.*;
import com.optum.fds.paperless.exception.HttpServerException;
import com.optum.fds.paperless.exception.ProcessException;
import com.optum.fds.paperless.mongo.processors.*;
import com.optum.fds.paperless.util.SftpUtil;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;

import org.apache.commons.io.FileUtils;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.fds.paperless.file.summary.ProcessSummary;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import com.optum.fds.paperless.processing.service.ProcessorTransactionsService;
import com.optum.fds.paperless.util.Parser;

@RunWith(MockitoJUnitRunner.Silent.class) 
public class ProcessFileUnzipTest {

	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder(); // TemporaryFolder uses deleteOnExit

	@Rule
	public TemporaryFolder temporaryLockFolder = new TemporaryFolder();

	@Mock
	private ProcessorServiceImpl processorService;

	@Mock
	private TransactionService transactionService;

	@Mock
	private ProcessorsService processorsService;

	@Mock
	private ProcessSummary processSumaryService;

	@Mock
	private ProcessorFileTaskService processorFileTaskService;

	@Mock
	private ProcessorTransactionsService processorTransactionsService;

	@Mock
	private MongoTemplate mongoTemplate;

	@Mock
	private ProcessorMetaData processorMetaData;

	@Mock
	ProcessorTransaction processorTransaction;

	@Mock
	SendQueueService sendQueueService;

	@Mock
	SftpUtil sftpUtil;

    @Mock
    ErrorMetaDataService errorMetaDataService;

	@InjectMocks
	ProcessFileUnzip injectedProcessFileUnzip;

	@Rule
	public ExpectedException thrown = ExpectedException.none();

	DelegateExecution execution = new DelegateExecutionImpl();

	@Before
	public void setUp() throws URISyntaxException, IOException, Exception {

		MockitoAnnotations.initMocks(this);

		ReflectionTestUtils.setField(injectedProcessFileUnzip, "engineDelegateUrl", "http://url.com");
		ReflectionTestUtils.setField(injectedProcessFileUnzip, "fileUnzipQueueSize", 2);
		ReflectionTestUtils.setField(injectedProcessFileUnzip, "serverType", "server");

		Mockito.when(
				processorService.getProcessorTransaction(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getTrans1());
		Mockito.when(processorsService.getTransactionProcessor(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(getTrans1());
		Mockito.when(processorFileTaskService.saveProcessorFileTask(Mockito.any(ProcessorFileTask.class)))
				.thenReturn(getProcessorFileTask());
		Mockito.when(mongoTemplate.save(Mockito.any(ProcessorFileTask.class), Mockito.anyString()))
				.thenReturn(getProcessorFileTask());
		Mockito.when(processorTransactionsService.createProcessorTransactionMetadata(any(), anyString(), anyInt(),
				anyString())).thenReturn(getProcessorTransactionMetadata());

		doNothing().when(processSumaryService).processSummaryFile(getTrans1());

		Mockito.when(processorService.saveProcessorFileTask(Mockito.any(ProcessorFileTask.class)))
				.thenReturn(getProcessorFileTask());

		Mockito.when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getProcessorMetaData());

		Mockito.when(processorsService.getProcessor(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getProcessorMetaData());

		Mockito.when(transactionService.insertTransactionMetaData(Mockito.any(Transaction.class)))
				.thenReturn(getTransactionRecord(getProcessorMetaData()));

		ClassLoader classLoader = getClass().getClassLoader();
		File f1 = new File(classLoader.getResource("good.zip").getFile());

		Files.copy(f1.toPath(), Paths.get(tempFolder.getRoot().getAbsolutePath()).resolve(f1.toPath().getFileName()));

	}


	@Test
	public void testDoExecuteIsSuccess() throws Exception {

		List<String> list = new ArrayList<String>();
		list.add("sdsdsdd");
		execution.setVariable("processorTransactionIds", list);
		execution.setVariable("appIdentifier", "dhdhdh7dgbdg");
		execution.setVariable("processorId", "dhdhdh7dgbdg");

		ProcessorTransaction process = new ProcessorTransaction();
		process.setFileCount(10);
		process.setStatus(MetaDataStatus.IN_PROCESS);

		Mockito.when(processorsService.getProcessor(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(getProcessorMetaDataWithaddProcessorTransactionMetadata());

		Mockito.when(processorsService.createProcessorFileTaskEntries(any(), any())).thenReturn(getProcessorFileTask());

		Mockito.doNothing().when(sftpUtil).moveFileFromLocalToSFTPLocation(any(), any(), any(), anyInt(), any(), any(),
				anyInt(), anyLong());

//		Map<String, String> configValues = new HashMap<String, String>();
//		configValues.put(Workflow.HOST_NAME_DESTINATION, "host");
//		configValues.put(Workflow.USER_NAME_DESTINATION, "user");
//		configValues.put(Workflow.FTP_ARCHIVE_DIR, "archivedir/");
////		configValues.put(Workflow.MAX_SFTP_TRIES, 2);
////		configValues.put(Workflow.RETRY_TIME_SECS, 1);
//		configValues.put(Workflow.USER_CREDENTIALS_DESTINATION, "test");
//		configValues.put("addProcessorTransactionMetadata", "true");
//
//		Mockito.when(processorMetaData.getProcessConfig()).thenReturn(configValues);
	}

	@Test
	public void testTrySendRequestToQueueArrProcessorFileTaskIds() throws IOException {
		String[] arrProcessorFileTaskIds = { "sdsdsdsd", "454rer", "dfdfdf5" };
		ReflectionTestUtils.invokeMethod(injectedProcessFileUnzip, "trySendRequestToQueueArrProcessorFileTaskIds",
				263596, arrProcessorFileTaskIds, "aapapapp33", "trtrtrt334");
		assertNull(injectedProcessFileUnzip.errorMap);
	}

	@Test//(expected = NullPointerException.class)
	public void testTrySendRequestToQueueArrProcessorFileTaskIdsThrowsException() throws IOException {
		String[] arrProcessorFileTaskIds = null;
		ReflectionTestUtils.invokeMethod(injectedProcessFileUnzip, "trySendRequestToQueueArrProcessorFileTaskIds",
				263596, arrProcessorFileTaskIds, null, null);
		assertNull(injectedProcessFileUnzip.errorMap);
	}

	@Test
	public void testTrySendRequestToQueueProcessorFileTaskIds() {
		Set<String> processorFileTaskIds = new HashSet<String>();
		processorFileTaskIds.add("4555");
		processorFileTaskIds.add("454554");
		ReflectionTestUtils.invokeMethod(injectedProcessFileUnzip, "trySendRequestToQueueProcessorFileTaskIds",
				365968, processorFileTaskIds, "aapapapp33", "trtrtrt334");
		assertNull(injectedProcessFileUnzip.errorMap);
	}

	@UserStory(references = "US31690")
	@RallyTestCase(references = "TC32447")
	@Test
	public void testFileunzipForCompanionFileTest() throws IOException {

		try {
			execution.setVariable("processorId", "5e445578a3fda637f6bbf43f");
			execution.setVariable("appIdentifier", "pb8vuebx8gxbjthf2qb1zyk8tn2q8hyv");

			Mockito.when(processorTransactionsService.getProcessorTransactionMetadataWithFileName(anyString()))
					.thenReturn(getProcessorTransactionMetadata());
			injectedProcessFileUnzip.execute(execution);

			assertTrue("The workflow execution should be finished", true);

		} catch (Exception ex) {
			System.out.println("Error:" + ex.getMessage());
			assertTrue("The workflow execution should be finished", true);
		}
	}

	@UserStory(references = "US31690")
	@RallyTestCase(references = "TC32448")
	@Test
	public void testFileunzipForCompanionFileWithNoProcessorTransactionMetadata() throws IOException {

		try {
			execution.setVariable("processorId", "5e445578a3fda637f6bbf43f");
			execution.setVariable("appIdentifier", "pb8vuebx8gxbjthf2qb1zyk8tn2q8hyv");

			Mockito.when(processorsService.getTransactionProcessor(Mockito.anyString(), Mockito.anyString(),
					Mockito.anyString())).thenReturn(getTrans1());

			Mockito.when(processorTransactionsService.getProcessorTransactionMetadataWithFileName(anyString()))
					.thenReturn(null);
			Mockito.when(processorTransactionsService.createProcessorTransactionMetadata(any(), anyString(),
					anyInt(), anyString())).thenReturn(getProcessorTransactionMetadata());

			injectedProcessFileUnzip.execute(execution);

			assertTrue("The workflow execution should be finished", true);

		} catch (Exception ex) {
			System.out.println("Error:" + ex.getMessage());
			assertTrue("The workflow execution should be finished", true);
		}
	}

	@UserStory(references = "US31690")
	@RallyTestCase(references = "TC32449")
	@Test
	public void testFileunzipForCompanionFileWithFalseProcessorTransactionMetadata() throws IOException {

		try {

			execution.setVariable("processorId", "5e445578a3fda637f6bbf43f");
			execution.setVariable("appIdentifier", "pb8vuebx8gxbjthf2qb1zyk8tn2q8hyv");

			Mockito.when(processorsService.getTransactionProcessor(Mockito.anyString(), Mockito.anyString(),
					Mockito.anyString())).thenReturn(getTrans1());

			Mockito.when(processorsService.getProcessor(Mockito.anyString(), Mockito.anyString()))
					.thenReturn(getProcessorMetaDatawithFalseAddProcessorTransactionMetadata());

			injectedProcessFileUnzip.execute(execution);

			assertTrue("The workflow execution should be finished", true);

		} catch (Exception ex) {
			System.out.println("Error:" + ex.getMessage());
			assertTrue("The workflow execution should be finished", true);
		}
	}

	@UserStory(references = "US31690")
	@RallyTestCase(references = "TC32450")
	@Test
	public void testFileunzipForCompanionFileWithoutAddProcessorTransactionMetadataFlag() throws IOException {

		try {
			execution.setVariable("processorId", "5e445578a3fda637f6bbf43f");
			execution.setVariable("appIdentifier", "pb8vuebx8gxbjthf2qb1zyk8tn2q8hyv");

			Mockito.when(processorsService.getTransactionProcessor(Mockito.anyString(), Mockito.anyString(),
					Mockito.anyString())).thenReturn(getTrans1());

			Mockito.when(processorsService.getProcessor(Mockito.anyString(), Mockito.anyString()))
					.thenReturn(getProcessorMetaDataWithOutAddProcessorTransactionMetadata());

			injectedProcessFileUnzip.execute(execution);

			assertTrue("The workflow execution should be finished", true);

		} catch (Exception ex) {
			System.out.println("Error:" + ex.getMessage());
			assertTrue("The workflow execution should be finished", true);
		}
	}

	private ProcessorTransaction getTrans1() throws IOException {

		ProcessorTransaction processorTransaction1;

		String processTrans1 = "{" + "\"id\" : \"5900ec4b30043ae97bb5cbf7\","
				+ "\"processorId\" : \"58cab698c2e6f7ff1c8e8c44\"," + "\"configSpaceId\" : 3007,"
				+ "\"fileName\" : \"good.zip\","
				+ "\"location\" : \"/bconnected/ingest/testapp/3007/5900ec4a30043ae97bb5cbf6\","
				+ "\"processorRecordType\" : \"processorTransaction\"," + "\"fileToProcessList\" : ["
				+ "\"53760302_72269907.pdf\", " + "\"empty.pdf\"" + "]," + "\"summary\" : {"
				+ "\"processingMetrics\" : {" + "\"totalBytes\" : 12300" + "}," + "\"errorList\" : [ " + "{"
				+ "\"errorMessage\" : \"There was a mismatch between count and files to be processed. Count is at 1 and there are 2 files listed.\","
				+ "\"errorCode\" : 7" + "}" + "]," + "\"runTime\" : 3051,"
				+ "\"startTime\" : \"2017-04-26T18:51:55.184Z\"," + "\"endTime\" : \"2017-04-26T18:51:58.235Z\","
				+ "\"xmlObject\" : {" + "\"batchId\" : \"2017031_104410_ELGS_Customer_Care_A\","
				+ "\"dataGroup\" : \"NASC\"," + "\"count\" : 1," + "\"files\" : {" + "\"fileList\" : [ " + "{"
				+ "\"fileName\" : \"empty.pdf\"" + "}, " + "{" + "\"fileName\" : \"53760302_72269907.pdf\"" + "}" + "]"
				+ "}" + "}" + "}," + "\"status\" : \"READY\"," + "\"appIdentifier\" : \"testapp\"" + "}";

		processorTransaction1 = Parser.parseJson(processTrans1, ProcessorTransaction.class);
		processorTransaction1.setLocation(getZipFileLocation());
		return processorTransaction1;

	}

	private ProcessorFileTask getProcessorFileTask() throws IOException {
		ProcessorFileTask processorFileTask = null;
		String fileTask = "{" + "\"id\" : \"5900ec4b30043ae97bb5cbfb\"," + "\"fileSize\" : 12098,"
				+ "\"configSpaceId\" : 3007," + "\"fileName\" : \"53760302_72269907.pdf\","
				+ "\"targetId\" : \"5900ec4e30043ae97bb5cc04\"," + "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
				+ "\"processorRecordType\" : \"processorFileTask\","
				+ "\"processorTransactionId\" : \"591c73bb3004a9fe597967c9\"," + "\"status\" : \"COMPLETE\","
				+ "\"appIdentifier\" : \"testapp\"," + "\"summary\" : {" + "\"runTime\" : 2791,"
				+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\"," + "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {" + "\"applicationID\" : \"ELGS\"," + "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\"" + "}" + "}" + "}";
		processorFileTask = Parser.parseJson(fileTask, ProcessorFileTask.class);
		return processorFileTask;
	}

	private ProcessorFileTask getProcessorFileTaskSecond() throws IOException {
		ProcessorFileTask processorFileTask = null;
		String fileTask = "{" + "\"id\" : \"5900ec4b30043ae97bb5cbbb\"," + "\"fileSize\" : 12098,"
				+ "\"configSpaceId\" : 3007," + "\"fileName\" : \"empty.pdf\","
				+ "\"targetId\" : \"5900ec4e30043ae97bb5cc04\"," + "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
				+ "\"processorRecordType\" : \"processorFileTask\","
				+ "\"processorTransactionId\" : \"591c73bb3004a9fe597967c9\"," + "\"status\" : \"COMPLETE\","
				+ "\"appIdentifier\" : \"testapp\"," + "\"summary\" : {" + "\"runTime\" : 2791,"
				+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\"," + "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {" + "\"applicationID\" : \"ELGS\"," + "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\"" + "}" + "}" + "}";
		processorFileTask = Parser.parseJson(fileTask, ProcessorFileTask.class);
		return processorFileTask;
	}

	private Transaction getTransactionRecord(ProcessorMetaData processor) {
		Transaction transactionMetaData = new Transaction();
		transactionMetaData.setAppIdentifier(processor.getAppIdentifier());
		transactionMetaData.setClientId(processor.getClientId());
		transactionMetaData.setDateCreated(new Date());
		transactionMetaData.setDateModified(new Date());
		transactionMetaData.setSpaceId(processor.getConfigSpaceId());
		return transactionMetaData;
	}

	private ProcessorMetaData getProcessorMetaData() throws IOException {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		String processor = "{" + "\"id\" : \"58cab698c2e6f7ff1c8e8c44\"," + "\"configSpaceId\" : \"3007\","
				+ "\"process\" : {" + "\"process_key\" : \"sftpProcess\"," + "\"config\" : {"
				+ "\"auth_type\" : \"oauth2\"," + "\"space_id\" : \"3007\"," + "\"fds_url\" : \"fds_url\","
				+ "\"fds_client_id\" : \"testapp\"," + "\"fds_client_secret\" : \"testapp\","
				+ "\"host_name_destination\" : \"rn000019322.uhc.com\"," + "\"username_destination\" : \"pren\","
				+ "\"pw_destination\" : \"uaHs7pvA\"," + "\"host_name\" : \"rn000019322.uhc.com\","
				+ "\"ftp_rootdir\" : \"/dropzone/charlie\"," + "\"ftp_ackdir\" : \"/dropzone/charlie/ack\","
				+ "\"ftp_archivedir\" : \"/dropzone/charlie/archive\"," + "\"username\" : \"pren\","
				+ "\"pw\" : \"uaHs7pvA\"," + "\"addProcessorTransactionMetadata\" : true," + "\"interval\" : \"30\""
				+ "}" + "}" + "}";
		processorMetaData = Parser.parseJson(processor, ProcessorMetaData.class);
		processorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
		processorMetaData.setCleanupWorkflow("myFlow");
		return processorMetaData;
	}

	private ProcessorMetaData getProcessorMetaDataWithaddProcessorTransactionMetadata() throws IOException {
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		String processor = "{" + "\"id\" : \"58cab698c2e6f7ff1c8e8c44\"," + "\"configSpaceId\" : \"3007\","
				+ "\"process\" : {" + "\"process_key\" : \"sftpProcess\"," + "\"config\" : {"
				+ "\"addProcessorTransactionMetadata\" : \"true\"," + "\"auth_type\" : \"oauth2\","
				+ "\"space_id\" : \"3007\"," + "\"fds_url\" : \"fds_url\"," + "\"fds_client_id\" : \"testapp\","
				+ "\"fds_client_secret\" : \"testapp\"," + "\"host_name_destination\" : \"rn000019322.uhc.com\","
				+ "\"username_destination\" : \"pren\"," + "\"pw_destination\" : \"uaHs7pvA\","
				+ "\"host_name\" : \"rn000019322.uhc.com\"," + "\"ftp_rootdir\" : \"/dropzone/charlie\","
				+ "\"ftp_ackdir\" : \"/dropzone/charlie/ack\"," + "\"ftp_archivedir\" : \"/dropzone/charlie/archive\","
				+ "\"username\" : \"pren\"," + "\"pw\" : \"uaHs7pvA\"," + "\"addProcessorTransactionMetadata\" : true,"
				+ "\"interval\" : \"30\"" + "}" + "}" + "}";
		processorMetaData = Parser.parseJson(processor, ProcessorMetaData.class);
		processorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
		processorMetaData.setCleanupWorkflow("myFlow");
		return processorMetaData;
	}

	private ProcessorMetaData getProcessorMetaDataWithOutAddProcessorTransactionMetadata() throws IOException {
		ProcessorMetaData processorMetaData = null;
		String processor = "{" + "\"id\" : \"58cab698c2e6f7ff1c8e8c44\"," + "\"configSpaceId\" : \"3007\","
				+ "\"process\" : {" + "\"process_key\" : \"sftpProcess\"," + "\"config\" : {"
				+ "\"auth_type\" : \"oauth2\"," + "\"space_id\" : \"3007\"," + "\"fds_url\" : \"fds_url\","
				+ "\"fds_client_id\" : \"testapp\"," + "\"fds_client_secret\" : \"testapp\","
				+ "\"host_name_destination\" : \"rn000019322.uhc.com\"," + "\"username_destination\" : \"pren\","
				+ "\"pw_destination\" : \"uaHs7pvA\"," + "\"host_name\" : \"rn000019322.uhc.com\","
				+ "\"ftp_rootdir\" : \"/dropzone/charlie\"," + "\"ftp_ackdir\" : \"/dropzone/charlie/ack\","
				+ "\"ftp_archivedir\" : \"/dropzone/charlie/archive\"," + "\"username\" : \"pren\","
				+ "\"pw\" : \"uaHs7pvA\"," + "\"interval\" : \"30\"" + "}" + "}" + "}";
		processorMetaData = Parser.parseJson(processor, ProcessorMetaData.class);
		processorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
		processorMetaData.setCleanupWorkflow("myFlow");
		return processorMetaData;
	}

	private ProcessorMetaData getProcessorMetaDatawithFalseAddProcessorTransactionMetadata() throws IOException {
		ProcessorMetaData processorMetaData = null;
		String processor = "{" + "\"id\" : \"58cab698c2e6f7ff1c8e8c44\"," + "\"configSpaceId\" : \"3007\","
				+ "\"process\" : {" + "\"process_key\" : \"sftpProcess\"," + "\"config\" : {"
				+ "\"auth_type\" : \"oauth2\"," + "\"space_id\" : \"3007\"," + "\"fds_url\" : \"fds_url\","
				+ "\"fds_client_id\" : \"testapp\"," + "\"fds_client_secret\" : \"testapp\","
				+ "\"host_name_destination\" : \"rn000019322.uhc.com\"," + "\"username_destination\" : \"pren\","
				+ "\"pw_destination\" : \"uaHs7pvA\"," + "\"host_name\" : \"rn000019322.uhc.com\","
				+ "\"ftp_rootdir\" : \"/dropzone/charlie\"," + "\"ftp_ackdir\" : \"/dropzone/charlie/ack\","
				+ "\"ftp_archivedir\" : \"/dropzone/charlie/archive\"," + "\"username\" : \"pren\","
				+ "\"pw\" : \"uaHs7pvA\"," + "\"addProcessorTransactionMetadata\" : false," + "\"interval\" : \"30\""
				+ "}" + "}" + "}";
		processorMetaData = Parser.parseJson(processor, ProcessorMetaData.class);
		processorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
		processorMetaData.setCleanupWorkflow("myFlow");
		return processorMetaData;
	}

	private ProcessorTransactionMetadata getProcessorTransactionMetadata() {
		ProcessorTransactionMetadata pmd = new ProcessorTransactionMetadata();
		pmd.setFileName("test.cmp");
		return pmd;
	}

	private String getZipFileLocation() {
		return "/private" + tempFolder.getRoot().getAbsolutePath() + File.separator;
//		File zip = null;
//
//		try {
//			URL resource = getClass().getClassLoader().getResource("good.zip");
//			zip = Paths.get(resource.toURI()).toFile();
//		} catch (Exception ex) {
//		}
//
//		String filePath = zip.getParent();
//		return filePath;
	}

    @Test
    public void doExecute_skipsWhenProcessorTransactionIdIsNull() {
        execution.setVariable("processorTransactionIds", Arrays.asList((String) null));
        execution.setVariable("appIdentifier", "testApp");
        execution.setVariable("processorId", "testProcessor");

        ProcessorMetaData processor = processorWithStatusAndAddMD(MetaDataStatus.ACTIVE, null);
        when(processorsService.getProcessor(anyString(), anyString())).thenReturn(processor);

        injectedProcessFileUnzip.doExecute(execution);

        verify(processorsService, never()).getTransactionProcessor(anyString(), anyString(), anyString());
        verifyNoInteractions(processSumaryService);
        assertTrue(true);
    }

    @Test
    public void doExecute_setsShutdownWhenProcessorNotInAllowedStatus() {
        execution.setVariable("processorTransactionIds", Arrays.asList("tx1"));
        execution.setVariable("appIdentifier", "testApp");
        execution.setVariable("processorId", "testProcessor");

        ProcessorMetaData processor = processorWithStatusAndAddMD(MetaDataStatus.SHUTDOWN, null);
        when(processorsService.getProcessor(anyString(), anyString())).thenReturn(processor);

        ProcessorTransaction tx = txWithFiles("tx1", Arrays.asList("a.pdf"));
        when(processorsService.getTransactionProcessor(anyString(), anyString(), anyString())).thenReturn(tx);

        injectedProcessFileUnzip.doExecute(execution);

        verify(tx).setStatus(MetaDataStatus.SHUTDOWN);
        verify(processorsService).updateProcessorTransactionMetaData(tx);
        verifyNoInteractions(processSumaryService);
    }

    @Test
    public void doExecute_continuesWhenZipLockExists_expandFileReturnsTrue() throws Exception {
        execution.setVariable("processorTransactionIds", Arrays.asList("tx1"));
        execution.setVariable("appIdentifier", "testApp");
        execution.setVariable("processorId", "testProcessor");

        ProcessorMetaData processor = processorWithStatusAndAddMD(MetaDataStatus.ACTIVE, null);
        when(processorsService.getProcessor(anyString(), anyString())).thenReturn(processor);

        ProcessorTransaction tx = txWithFiles("tx1", Arrays.asList("a.pdf"));
        when(processorsService.getTransactionProcessor(anyString(), anyString(), anyString())).thenReturn(tx);

        try (MockedStatic<Utilities> util = Mockito.mockStatic(Utilities.class)) {
            util.when(() -> Utilities.expandFile(ArgumentMatchers.any(Path.class), ArgumentMatchers.any(Path.class))).thenReturn(true);

            injectedProcessFileUnzip.doExecute(execution);
        }

        verifyNoInteractions(processSumaryService);
        verify(processorsService, never()).createProcessorFileTaskEntries(any(), anyString());
        verify(sendQueueService, never()).sendRequestToQueue(anyInt(), anyString(), anyString(), anyString(), anyMap());
    }

    @Test
    public void doExecute_marksFatalOnExpandIOException_andWritesErrorMetadata() throws Exception {
        execution.setVariable("processorTransactionIds", Arrays.asList("tx1"));
        execution.setVariable("fileName", "good.zip");
        execution.setVariable("appIdentifier", "testApp");
        execution.setVariable("processorId", "testProcessor");

        when(processorsService.createProcessorFileTaskEntries(any(), any())).thenReturn(getProcessorFileTask());

        ProcessorTransaction tx = txWithFiles("tx1", Arrays.asList("a.pdf"));
        when(processorsService.getTransactionProcessor(anyString(), anyString(), anyString())).thenReturn(tx);

        try (MockedStatic<Utilities> util = Mockito.mockStatic(Utilities.class)) {
            util.when(() -> Utilities.expandFile(ArgumentMatchers.any(Path.class), ArgumentMatchers.any(Path.class))).thenThrow(new IOException("boom"));

            injectedProcessFileUnzip.doExecute(execution);
        }

        verify(tx).setStatus(MetaDataStatus.FATAL_ERROR);
        verify(processorsService).updateProcessorTransactionMetaData(tx);
        verify(errorMetaDataService).writeToErrorCollection(eq(execution), contains("ProcessFileUnzip --> doExecute"));
        // It still calls summary after the unzip try/catch in the selected code
        verify(processSumaryService).processSummaryFile(tx);
    }

    @Test
    public void doExecute_batchesQueueSends_andFinalSend_forFileTasks() throws Exception {
        execution.setVariable("processorTransactionIds", Arrays.asList("tx1"));
        execution.setVariable("appIdentifier", "testApp");
        execution.setVariable("processorId", "testProcessor");

        ProcessorMetaData processor = processorWithStatusAndAddMD(MetaDataStatus.ACTIVE, null);
        when(processorsService.getProcessor(anyString(), anyString())).thenReturn(processor);

        List<String> files = Arrays.asList("f1.pdf", "f2.pdf", "f3.pdf");
        ProcessorTransaction tx = txWithFiles("tx1", files);
        when(processorsService.getTransactionProcessor(anyString(), anyString(), anyString())).thenReturn(tx);

        ProcessorFileTask task1 = mock(ProcessorFileTask.class);
        ProcessorFileTask task2 = mock(ProcessorFileTask.class);
        ProcessorFileTask task3 = mock(ProcessorFileTask.class);
        when(task1.getId()).thenReturn("t1");
        when(task2.getId()).thenReturn("t2");
        when(task3.getId()).thenReturn("t3");
        when(task1.getStatus()).thenReturn(MetaDataStatus.COMPLETE);
        when(task2.getStatus()).thenReturn(MetaDataStatus.COMPLETE);
        when(task3.getStatus()).thenReturn(MetaDataStatus.COMPLETE);

        when(processorsService.createProcessorFileTaskEntries(eq(tx), eq("f1.pdf"))).thenReturn(task1);
        when(processorsService.createProcessorFileTaskEntries(eq(tx), eq("f2.pdf"))).thenReturn(task2);
        when(processorsService.createProcessorFileTaskEntries(eq(tx), eq("f3.pdf"))).thenReturn(task3);

        try (MockedStatic<Utilities> util = Mockito.mockStatic(Utilities.class)) {
            util.when(() -> Utilities.expandFile(ArgumentMatchers.any(Path.class), ArgumentMatchers.any(Path.class))).thenReturn(false);

            injectedProcessFileUnzip.doExecute(execution);
        }

        verify(processSumaryService).processSummaryFile(tx);

        // queueSize = 2: one send for {t1,t2} and one final send for {t3}
        verify(sendQueueService, times(2)).sendRequestToQueue(
                eq(3007),
                eq("ProcessFileUnzip"),
                eq("tx1"),
                eq("processMetadataFiles"),
                anyMap()
        );
    }

    @Test
    public void doExecute_whenAddProcessorTransactionMetadataTrue_createsMetadataIfMissing() throws Exception {
        execution.setVariable("processorTransactionIds", Arrays.asList("tx1"));
        execution.setVariable("appIdentifier", "testApp");
        execution.setVariable("processorId", "testProcessor");

        ProcessorMetaData processor = processorWithStatusAndAddMD(MetaDataStatus.ACTIVE, true);
        when(processorsService.getProcessor(anyString(), anyString())).thenReturn(processor);

        ProcessorTransaction tx = txWithFiles("tx1", Arrays.asList("f1.pdf"));
        when(processorsService.getTransactionProcessor(anyString(), anyString(), anyString())).thenReturn(tx);

        ProcessorFileTask task1 = mock(ProcessorFileTask.class);
        when(task1.getId()).thenReturn("t1");
        when(task1.getStatus()).thenReturn(MetaDataStatus.COMPLETE);
        when(processorsService.createProcessorFileTaskEntries(eq(tx), eq("f1.pdf"))).thenReturn(task1);

        when(processorTransactionsService.getProcessorTransactionMetadataWithFileName(anyString())).thenReturn(null);
        when(processorTransactionsService.createProcessorTransactionMetadataClientHashmap(anyBoolean(), anyBoolean(), anyString(), any()))
                .thenReturn(new HashMap<>());

        ProcessorTransactionMetadata created = new ProcessorTransactionMetadata();
        created.setFileName("good.cmp");
        when(processorTransactionsService.createProcessorTransactionMetadata(anyMap(), anyString(), anyInt(), anyString()))
                .thenReturn(created);

        try (MockedStatic<Utilities> util = Mockito.mockStatic(Utilities.class)) {
            util.when(() -> Utilities.expandFile(ArgumentMatchers.any(Path.class), ArgumentMatchers.any(Path.class))).thenReturn(false);
            util.when(() -> Utilities.stripFileExtension(anyString())).thenReturn("good");

            injectedProcessFileUnzip.doExecute(execution);
        }

        verify(processorTransactionsService).getProcessorTransactionMetadataWithFileName(anyString());
        verify(processorTransactionsService).createProcessorTransactionMetadata(
                anyMap(),
                eq("proc1"),
                eq(3007),
                anyString()
        );
    }

    @Test
    public void trySendRequestToQueueArrProcessorFileTaskIds_processException_writesManualError() throws Exception {
        ReflectionTestUtils.setField(injectedProcessFileUnzip, "sendQueueService", sendQueueService);

        when(sendQueueService.getPriorityQueue(3007)).thenReturn("q1");
        doThrow(new ProcessException("fail")).when(sendQueueService)
                .sendRequestToQueue(eq(3007), anyString(), anyString(), anyString(), anyMap());

        ReflectionTestUtils.invokeMethod(
                injectedProcessFileUnzip,
                "trySendRequestToQueueArrProcessorFileTaskIds",
                3007,
                new String[] { "t1", "t2" },
                "testapp",
                "tx1"
        );

        verify(errorMetaDataService).writeToMessageServiceErrorCollection(
                eq("q1"),
                eq("processMetadataFiles"),
                eq("tx1"),
                eq(3007),
                anyMap(),
                contains("fail"),
                eq(MetaDataStatus.MANUAL)
        );
    }

    @Test
    public void trySendRequestToQueueProcessorFileTaskIds_httpServerException_writesAutomaticError() throws Exception {
        ReflectionTestUtils.setField(injectedProcessFileUnzip, "sendQueueService", sendQueueService);
        ReflectionTestUtils.setField(injectedProcessFileUnzip, "errorMetaDataService", errorMetaDataService);

        when(sendQueueService.getPriorityQueue(3007)).thenReturn("q1");
        doThrow(new HttpServerException("down")).when(sendQueueService)
                .sendRequestToQueue(eq(3007), anyString(), anyString(), anyString(), anyMap());

        Set<String> ids = new HashSet<>(Arrays.asList("t1"));
        ReflectionTestUtils.invokeMethod(
                injectedProcessFileUnzip,
                "trySendRequestToQueueProcessorFileTaskIds",
                3007,
                ids,
                "testapp",
                "tx1"
        );

        verify(errorMetaDataService).writeToMessageServiceErrorCollection(
                eq("q1"),
                eq("processMetadataFiles"),
                eq("tx1"),
                eq(3007),
                anyMap(),
                contains("down"),
                eq(MetaDataStatus.AUTOMATIC)
        );
    }

    private ProcessorMetaData processorWithStatusAndAddMD(MetaDataStatus status, Object addFlag) {
        ProcessorMetaData p = mock(ProcessorMetaData.class);
        when(p.getStatus()).thenReturn(status);
        when(p.getId()).thenReturn("proc1");
        when(p.getConfigSpaceId()).thenReturn(3007);

        Map<String, Object> cfg = new HashMap<>();
        if (addFlag != null) cfg.put("addProcessorTransactionMetadata", addFlag);
        when(p.getProcessConfig()).thenReturn(cfg);

        Map<String, Object> procMap = new HashMap<>();
        Map<String, Object> config = new HashMap<>();
        config.put(Workflow.HOST_NAME_DESTINATION, "host");
        config.put(Workflow.USER_NAME_DESTINATION, "user");
        config.put(Workflow.USER_CREDENTIALS_DESTINATION, "pass");
        config.put(Workflow.FTP_ARCHIVE_DIR, "/archive");
        procMap.put("config", config);
        when(p.getProcess()).thenReturn(procMap);

        return p;
    }

    private ProcessorTransaction txWithFiles(String id, List<String> files) {
        ProcessorTransaction tx = mock(ProcessorTransaction.class);
        when(tx.getId()).thenReturn(id);
        when(tx.getFileName()).thenReturn("good.zip");
        when(tx.getLocation()).thenReturn("C:\\temp\\ingest");
        when(tx.getFileToProcessList()).thenReturn(files);

        ProcessorSummary summary = new ProcessorSummary();
        when(tx.getSummary()).thenReturn(summary);

        return tx;
    }

    private ProcessorMetaData processorWithArchiveConfig(
            Integer maxSftpTries,
            Long retryTimeSecs
    ) {
        ProcessorMetaData p = mock(ProcessorMetaData.class);
        when(p.getStatus()).thenReturn(MetaDataStatus.ACTIVE);
        when(p.getId()).thenReturn("proc1");
        when(p.getConfigSpaceId()).thenReturn(3007);

        // Keep addProcessorTransactionMetadata absent to avoid extra unrelated paths
        when(p.getProcessConfig()).thenReturn(new HashMap<>());

        Map<String, Object> config = new HashMap<>();
        config.put(Workflow.HOST_NAME_DESTINATION, "host");
        config.put(Workflow.USER_NAME_DESTINATION, "user");
        config.put(Workflow.USER_CREDENTIALS_DESTINATION, "pass");
        config.put(Workflow.FTP_ARCHIVE_DIR, "/archive");
        config.put(Workflow.MAX_SFTP_TRIES, maxSftpTries);
        config.put(Workflow.RETRY_TIME_SECS, retryTimeSecs);

        Map<String, Object> process = new HashMap<>();
        process.put("config", config);
        when(p.getProcess()).thenReturn(process);
        return p;
    }

    private ProcessorTransaction txForZip(Path folder, String zipName) {
        ProcessorTransaction tx = mock(ProcessorTransaction.class);
        when(tx.getId()).thenReturn("tx1");
        when(tx.getFileName()).thenReturn(zipName);
        when(tx.getLocation()).thenReturn(folder.toString());
        when(tx.getFileToProcessList()).thenReturn(Collections.singletonList("f1.pdf"));
        // Ensure summary call doesn’t NPE if reached
        com.optum.fds.paperless.mongo.processors.ProcessorSummary summary =
                new com.optum.fds.paperless.mongo.processors.ProcessorSummary();
        when(tx.getSummary()).thenReturn(summary);
        return tx;
    }

    @Test
    public void doExecute_archivesAndDeletesZip_whenZipExists() throws Exception {
        // Arrange
        ProcessFileUnzip sut = this.injectedProcessFileUnzip;

        DelegateExecution exec = this.execution;
        exec.setVariable("processorTransactionIds", Collections.singletonList("tx1"));
        exec.setVariable("appIdentifier", "testApp");
        exec.setVariable("processorId", "testProcessor");

        Path folder = tempFolder.newFolder("ingest").toPath();
        Path zipPath = folder.resolve("good.zip");
        Files.write(zipPath, "zip".getBytes());

        ProcessorMetaData processor = processorWithArchiveConfig(null, null); // defaults: 10 and 360
        when(processorsService.getProcessor(anyString(), anyString())).thenReturn(processor);

        ProcessorTransaction tx = txForZip(folder, "good.zip");
        when(processorsService.getTransactionProcessor(anyString(), anyString(), anyString())).thenReturn(tx);

        // keep unzip path harmless
        try (MockedStatic<Utilities> util = Mockito.mockStatic(Utilities.class);
             MockedStatic<FileUtils> fileUtils = Mockito.mockStatic(FileUtils.class)) {

            util.when(() -> Utilities.expandFile(any(java.nio.file.Path.class), any(java.nio.file.Path.class)))
                    .thenReturn(false);

            doNothing().when(sftpUtil).moveFileFromLocalToSFTPLocation(
                    anyString(), anyString(), anyString(), anyInt(), anyString(),
                    anyString(), anyInt(), anyLong()
            );
            fileUtils.when(() -> FileUtils.forceDelete(any(File.class))).thenAnswer(inv -> null);

            // Act
            sut.doExecute(exec);

            // Assert: SFTP called with defaults
            verify(sftpUtil).moveFileFromLocalToSFTPLocation(
                    eq("user"),
                    eq("pass"),
                    eq("host"),
                    eq(22),
                    eq("/archive"),
                    eq(zipPath.toAbsolutePath().toString()),
                    eq(10),
                    eq(360L)
            );

            // Assert: deletion attempted
            fileUtils.verify(() -> FileUtils.forceDelete(argThat(f -> f.getAbsolutePath().equals(zipPath.toFile().getAbsolutePath()))), times(1));
        }
    }

    @Test
    public void doExecute_archivesButDoesNotDelete_whenZipDoesNotExist() throws Exception {
        // Arrange
        ProcessFileUnzip sut = this.injectedProcessFileUnzip;

        DelegateExecution exec = this.execution;
        exec.setVariable("processorTransactionIds", Collections.singletonList("tx1"));
        exec.setVariable("appIdentifier", "testApp");
        exec.setVariable("processorId", "testProcessor");

        Path folder = tempFolder.newFolder("ingest2").toPath();
        Path zipPath = folder.resolve("missing.zip");
        assertFalse(Files.exists(zipPath));

        ProcessorMetaData processor = processorWithArchiveConfig(5, 12L);
        when(processorsService.getProcessor(anyString(), anyString())).thenReturn(processor);

        ProcessorTransaction tx = txForZip(folder, "missing.zip");
        when(processorsService.getTransactionProcessor(anyString(), anyString(), anyString())).thenReturn(tx);

        try (MockedStatic<Utilities> util = Mockito.mockStatic(Utilities.class);
             MockedStatic<FileUtils> fileUtils = Mockito.mockStatic(FileUtils.class)) {

            util.when(() -> Utilities.expandFile(any(java.nio.file.Path.class), any(java.nio.file.Path.class)))
                    .thenReturn(false);

            doNothing().when(sftpUtil).moveFileFromLocalToSFTPLocation(
                    anyString(), anyString(), anyString(), anyInt(), anyString(),
                    anyString(), anyInt(), anyLong()
            );

            // Act
            sut.doExecute(exec);

            // Assert: SFTP called with provided overrides
            verify(sftpUtil).moveFileFromLocalToSFTPLocation(
                    eq("user"),
                    eq("pass"),
                    eq("host"),
                    eq(22),
                    eq("/archive"),
                    eq(zipPath.toAbsolutePath().toString()),
                    eq(5),
                    eq(12L)
            );

            // Assert: no deletion
            fileUtils.verifyNoInteractions();
        }
    }

    @Test
    public void doExecute_whenSftpThrows_doesNotDeleteZip_andIsCaughtByDoExecute() throws Exception {
        // Arrange
        ProcessFileUnzip sut = this.injectedProcessFileUnzip;

        DelegateExecution exec = this.execution;
        exec.setVariable("processorTransactionIds", Collections.singletonList("tx1"));
        exec.setVariable("appIdentifier", "testApp");
        exec.setVariable("processorId", "testProcessor");

        Path folder = tempFolder.newFolder("ingest3").toPath();
        Path zipPath = folder.resolve("good.zip");
        Files.write(zipPath, "zip".getBytes());

        ProcessorMetaData processor = processorWithArchiveConfig(null, null);
        when(processorsService.getProcessor(anyString(), anyString())).thenReturn(processor);

        ProcessorTransaction tx = txForZip(folder, "good.zip");
        when(processorsService.getTransactionProcessor(anyString(), anyString(), anyString())).thenReturn(tx);

        try (MockedStatic<Utilities> util = Mockito.mockStatic(Utilities.class);
             MockedStatic<FileUtils> fileUtils = Mockito.mockStatic(FileUtils.class)) {

            util.when(() -> Utilities.expandFile(any(java.nio.file.Path.class), any(java.nio.file.Path.class)))
                    .thenReturn(false);

            doThrow(new SftpException(4, "down")).when(sftpUtil).moveFileFromLocalToSFTPLocation(
                    anyString(), anyString(), anyString(), anyInt(), anyString(),
                    anyString(), anyInt(), anyLong()
            );

            // Act (should not throw because doExecute wraps the archive call in try/catch)
            sut.doExecute(exec);

            // Assert: deletion not attempted due to exception before delete block
            fileUtils.verifyNoInteractions();
        }
    }

    @Test
    public void doExecute_whenJschThrows_doesNotDeleteZip_andIsCaughtByDoExecute() throws Exception {
        // Arrange
        ProcessFileUnzip sut = this.injectedProcessFileUnzip;

        DelegateExecution exec = this.execution;
        exec.setVariable("processorTransactionIds", Collections.singletonList("tx1"));
        exec.setVariable("appIdentifier", "testApp");
        exec.setVariable("processorId", "testProcessor");

        Path folder = tempFolder.newFolder("ingest4").toPath();
        Path zipPath = folder.resolve("good.zip");
        Files.write(zipPath, "zip".getBytes());

        ProcessorMetaData processor = processorWithArchiveConfig(null, null);
        when(processorsService.getProcessor(anyString(), anyString())).thenReturn(processor);

        ProcessorTransaction tx = txForZip(folder, "good.zip");
        when(processorsService.getTransactionProcessor(anyString(), anyString(), anyString())).thenReturn(tx);

        try (MockedStatic<Utilities> util = Mockito.mockStatic(Utilities.class);
             MockedStatic<FileUtils> fileUtils = Mockito.mockStatic(FileUtils.class)) {

            util.when(() -> Utilities.expandFile(any(java.nio.file.Path.class), any(java.nio.file.Path.class)))
                    .thenReturn(false);

            doThrow(new JSchException("auth")).when(sftpUtil).moveFileFromLocalToSFTPLocation(
                    anyString(), anyString(), anyString(), anyInt(), anyString(),
                    anyString(), anyInt(), anyLong()
            );

            // Act
            sut.doExecute(exec);

            // Assert
            fileUtils.verifyNoInteractions();
        }
    }

}
