package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.bson.Document;

public class JsonFileToRestApiTest {

	@Mock
	CsvProcessorsService csvProcessorsService;

	@Mock
	CsvProcessorService csvProcessorService;

	@Mock
	ProcessorsService processorsService;

	@Mock
	CsvProcessorTransaction csvProcessorTransaction;

	@Mock
	ProcessorMetaData processorMetaData;

	@InjectMocks
	JsonFileToRestApi jsonFileToRestApi;

	DelegateExecution execution;

	@SuppressWarnings("deprecation")
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);
	}

	@Test
	public void testDoExecuteIsSuccess() {
		when(execution.getVariable(Workflow.CSV_PROCESSOR_TRANSACTION, CsvProcessorTransaction.class))
				.thenReturn(csvProcessorTransaction);
		when(execution.getVariable(Workflow.APP_ID_V1, String.class)).thenReturn("appId1255");
		when(processorsService.findProcessorMetaDataById("processorId232", "appId1255")).thenReturn(processorMetaData);
		jsonFileToRestApi.execute(execution);
		assertEquals(0, jsonFileToRestApi.errorMap.get(Workflow.NEW_ERRORS));

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testConstructRequestIsSuccess() {
		Document metadata = new Document();
		Document formData = new Document();
		Document confirmation = new Document();
		confirmation.append("transactionID", "tr74747474");
		formData.append("confirmation", confirmation);

		metadata.append("formData", formData);
		ReflectionTestUtils.invokeMethod(jsonFileToRestApi, "constructRequest", metadata, "Bearer jdjdjfjdf", 23659);
		
		Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
	    assertTrue(errorMap == null);
	}
	
	@Test
	public void testcsvFileRowToRestApiJobIsSuccess() throws FileNotFoundException {

		BufferedReader reader = 
				  new BufferedReader(new FileReader("src/test/resources/input.txt"));
		ReflectionTestUtils.invokeMethod(jsonFileToRestApi, "csvFileRowToRestApiJob", execution, processorMetaData, csvProcessorTransaction, reader);
	

	}
}
