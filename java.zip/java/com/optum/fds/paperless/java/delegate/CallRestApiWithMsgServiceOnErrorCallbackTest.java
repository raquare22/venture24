package com.optum.fds.paperless.java.delegate;

import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.SendQueueService;
import com.optum.fds.paperless.exception.HttpServerException;
import com.optum.fds.paperless.mongo.ErrorMetaData;

public class CallRestApiWithMsgServiceOnErrorCallbackTest {

    @Mock
    private ErrorMetaDataService errorMetaDataService;

    @Mock
    private SendQueueService sendQueueService;

    @Mock
    private DelegateExecution execution;

    @InjectMocks
    private CallRestApiWithMsgServiceOnErrorCallback callback;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testDoExecute_Success() throws Exception {
        when(execution.getVariable("restApiId")).thenReturn("addSendDocumentRequestToFds");
        when(execution.getVariable("spaceId")).thenReturn(1);
        when(execution.getVariable("identifier")).thenReturn("identifier");
        when(execution.getVariable("targetId")).thenReturn("targetId");
        when(execution.getVariable("delegate")).thenReturn("delegate");
        when(execution.getVariable("retryCnt")).thenReturn(0);
        when(execution.getVariable("processorFileTaskId")).thenReturn("processorFileTaskId");
        when(execution.getVariable("prunDocumentId")).thenReturn("prunDocumentId");
        when(execution.getVariable("appIdentifier")).thenReturn("appIdentifier");
        when(execution.getVariable("filePath")).thenReturn("filePath");
        when(execution.getVariable("documents")).thenReturn("documents");
        when(execution.getVariable("searchTerms")).thenReturn("searchTerms");

        when(sendQueueService.addSendDocumentRequestToFds(anyInt(), anyString(), anyString(), anyString(), any(MultiValueMap.class), anyMap(), anyMap(), anyInt())).thenReturn(true);

        callback.doExecute(execution);

        verify(sendQueueService).addSendDocumentRequestToFds(anyInt(), anyString(), anyString(), anyString(), any(MultiValueMap.class), anyMap(), anyMap(), anyInt());
    }

    @Test
    public void testDoExecute_SuccessDoc360() throws Exception {
        when(execution.getVariable("restApiId")).thenReturn("addSendDocumentRequestToDoc360");
        when(execution.getVariable("spaceId")).thenReturn(1);
        when(execution.getVariable("identifier")).thenReturn("identifier");
        when(execution.getVariable("targetId")).thenReturn("targetId");
        when(execution.getVariable("delegate")).thenReturn("delegate");
        when(execution.getVariable("retryCnt")).thenReturn(0);
        when(execution.getVariable("processorFileTaskId")).thenReturn("processorFileTaskId");
        when(execution.getVariable("prunDocumentId")).thenReturn("prunDocumentId");
        when(execution.getVariable("appIdentifier")).thenReturn("appIdentifier");
        when(execution.getVariable("filePath")).thenReturn("filePath");
        when(execution.getVariable("documents")).thenReturn("documents");
        when(execution.getVariable("docClass")).thenReturn("docClass");

        when(sendQueueService.addSendDocumentRequestToDoc360(anyInt(), anyString(), anyString(), anyString(), any(MultiValueMap.class), anyMap(), anyMap(), anyInt())).thenReturn(true);

        callback.doExecute(execution);

        verify(sendQueueService).addSendDocumentRequestToDoc360(anyInt(), anyString(), anyString(), anyString(), any(MultiValueMap.class), anyMap(), anyMap(), anyInt());
    }

    @Test
    public void testDoExecute_HttpServerException() throws Exception {
        when(execution.getVariable("restApiId")).thenReturn("addSendDocumentRequestToFds");
        when(execution.getVariable("spaceId")).thenReturn(1);
        when(execution.getVariable("identifier")).thenReturn("identifier");
        when(execution.getVariable("targetId")).thenReturn("targetId");
        when(execution.getVariable("delegate")).thenReturn("delegate");
        when(execution.getVariable("retryCnt")).thenReturn(0);
        when(execution.getVariable("processorFileTaskId")).thenReturn("processorFileTaskId");
        when(execution.getVariable("prunDocumentId")).thenReturn("prunDocumentId");
        when(execution.getVariable("appIdentifier")).thenReturn("appIdentifier");
        when(execution.getVariable("filePath")).thenReturn("filePath");
        when(execution.getVariable("documents")).thenReturn("documents");
        when(execution.getVariable("searchTerms")).thenReturn("searchTerms");

        when(sendQueueService.addSendDocumentRequestToFds(anyInt(), anyString(), anyString(), anyString(), any(MultiValueMap.class), anyMap(), anyMap(), anyInt())).thenThrow(new HttpServerException("Error"));

        when(sendQueueService.getPriorityQueue(anyInt())).thenReturn("queue");
        when(errorMetaDataService.writeToMessageServiceErrorCollection(anyString(), anyString(), anyString(), anyInt(), anyMap(), anyString(), any())).thenReturn(new ErrorMetaData());

        callback.doExecute(execution);

        verify(sendQueueService).addSendDocumentRequestToFds(anyInt(), anyString(), anyString(), anyString(), any(MultiValueMap.class), anyMap(), anyMap(), anyInt());
        verify(errorMetaDataService).writeToMessageServiceErrorCollection(anyString(), anyString(), anyString(), anyInt(), anyMap(), anyString(), any());
    }
}