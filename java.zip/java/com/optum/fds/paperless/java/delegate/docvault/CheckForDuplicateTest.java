package com.optum.fds.paperless.java.delegate.docvault;

import static org.hamcrest.Matchers.equalToIgnoringCase;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.java.delegate.DelegateExecutionImpl;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;



public class CheckForDuplicateTest {
    
    private static final String EMAIL_HOST_PROPERTY_NAME = "ELR_SMTP_RELAY_HOST";
    
    @Mock
    JavaMailSenderImpl javaMailSender;
    
    @InjectMocks
    CheckForDuplicate checkForDuplicate;
    
    ConfigData configData;
    
    @Before
    public void setup()  {
        MockitoAnnotations.initMocks(this);
       
    }

    @Test
    public void test1PassInVar() throws Exception {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        DocumentAttachmentMetaData attachMetaData = new DocumentAttachmentMetaData();
        attachMetaData.setFsId("ade-345-eir-345-4494949ae");
        List<DocumentAttachmentMetaData> documentAttachments = new ArrayList<>();
        documentAttachments.add(attachMetaData);
        documentMetaData.setDocumentAttachments(documentAttachments);
        Document bsonDocMetadata = new Document();
        bsonDocMetadata.append("fsId", "ade-345-eir-345");
        documentMetaData.setMetadata(bsonDocMetadata);   
        documentMetaData.setId("0548uedhdyyd");
        DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
        execution.setVariable("testTwo", "test two variable");
        execution.setVariable("Document", documentMetaData);
        checkForDuplicate.execute(execution);
        String resultVar = (String) execution.getVariable("testTwo");
        System.out.println("testTwo: " + resultVar);
        assertThat("Wrong variable returned", resultVar, equalToIgnoringCase("test two variable"));
    }
    
    @Test
    public void test2PassInVar() throws Exception {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        DocumentAttachmentMetaData attachMetaData = new DocumentAttachmentMetaData();
        attachMetaData.setFsId("ade-345-eir-345-4494949ae");
        List<DocumentAttachmentMetaData> documentAttachments = new ArrayList<>();
        documentAttachments.add(attachMetaData);
        documentMetaData.setDocumentAttachments(documentAttachments);
        Document bsonDocMetadata = new Document();
        bsonDocMetadata.append("fsId", "ade-345-eir-345");
        documentMetaData.setMetadata(bsonDocMetadata);
        documentMetaData.setId("048fyf7f7");
        DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
        execution.setVariable("testTwo", "test two variable");
        execution.setVariable("Document", documentMetaData);
        checkForDuplicate.execute(execution);
        String resultVar = (String) execution.getVariable("testTwo");
        System.out.println("testTwo: " + resultVar);
        assertThat("Wrong variable returned", resultVar, equalToIgnoringCase("test two variable"));
    }
    
    @Test
    public void test3RecipientCollection() throws Exception {
        List<String> recipientList = new ArrayList<>();
        recipientList.add("larry.lewandowski@optum.com");
        DocumentMetaData documentMetaData = new DocumentMetaData();
        DocumentAttachmentMetaData attachMetaData = new DocumentAttachmentMetaData(); 
        attachMetaData.setFsId("ade-345-eir-345-4494949ae");
        List<DocumentAttachmentMetaData> documentAttachments = new ArrayList<>();
        documentAttachments.add(attachMetaData);
        documentMetaData.setDocumentAttachments(documentAttachments);
        Document bsonDocMetadata = new Document();
        bsonDocMetadata.append("fsId", "ade-345-eir-345");
        documentMetaData.setMetadata(bsonDocMetadata);
        documentMetaData.setId("45454ddfd");
        DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
        execution.setVariable("testTwo", "test two variable");
        execution.setVariable("Document", documentMetaData);
        execution.setVariable("recipient", recipientList);
        checkForDuplicate.execute(execution);
        String resultVar = (String) execution.getVariable("testTwo");
        System.out.println("testTwo: " + resultVar);
        assertThat("Wrong variable returned", resultVar, equalToIgnoringCase("test two variable"));
    }
    
    @Test
    public void test4NoRecipient() throws Exception {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        DocumentAttachmentMetaData attachMetaData = new DocumentAttachmentMetaData();
        attachMetaData.setFsId("ade-345-eir-345-4494949ae");
        List<DocumentAttachmentMetaData> documentAttachments = new ArrayList<>();
        documentAttachments.add(attachMetaData);
        documentMetaData.setDocumentAttachments(documentAttachments);
        Document bsonDocMetadata = new Document();
        bsonDocMetadata.append("fsId", "ade-345-eir-345");
        documentMetaData.setMetadata(bsonDocMetadata);
        documentMetaData.setId("6ididididi");
        DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
        execution.setVariable("testTwo", "test two variable");
        execution.setVariable("Document", documentMetaData);
        execution.setVariable("recipient", 1234L);
        checkForDuplicate.execute(execution);
        String resultVar = (String) execution.getVariable("testTwo");
        System.out.println("testTwo: " + resultVar);
        assertThat("Wrong variable returned", resultVar, equalToIgnoringCase("test two variable"));
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void test5FdsDataException() throws Exception {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setId("12365");
        DocumentAttachmentMetaData attachMetaData = new DocumentAttachmentMetaData();
        attachMetaData.setFsId("ade-345-eir-345-4494949ae");
        List<DocumentAttachmentMetaData> documentAttachments = new ArrayList<>();
        documentAttachments.add(attachMetaData);
        documentMetaData.setDocumentAttachments(documentAttachments);
        Document bsonDocMetadata = new Document();
        bsonDocMetadata.append("fsId", "ade-345-eir-345");
        documentMetaData.setMetadata(bsonDocMetadata);
        documentMetaData.setId("95975757");
        DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
        execution.setVariable("testTwo", "test two variable");
        execution.setVariable("Document", documentMetaData);
        checkForDuplicate.execute(execution);
        String resultVar = (String) execution.getVariable("testTwo");
        System.out.println("testTwo: " + resultVar);
        assertThat("Wrong variable returned", resultVar, equalToIgnoringCase("test two variable"));
    }
    
    @Test
    public void test6MailException() throws Exception {
        doThrow(new MailSendException("mailException")).when(javaMailSender).send(any(SimpleMailMessage.class));
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setId("12365");
        DocumentAttachmentMetaData attachMetaData = new DocumentAttachmentMetaData();
        attachMetaData.setFsId("ade-345-eir-345-4494949ae");
        List<DocumentAttachmentMetaData> documentAttachments = new ArrayList<>();
        documentAttachments.add(attachMetaData);
        documentMetaData.setDocumentAttachments(documentAttachments);
        Document bsonDocMetadata = new Document();
        bsonDocMetadata.append("fsId", "ade-345-eir-345");
        documentMetaData.setMetadata(bsonDocMetadata);
        DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
        execution.setVariable("testTwo", "test two variable");
        execution.setVariable("Document", documentMetaData);
        checkForDuplicate.execute(execution);
        String resultVar = (String) execution.getVariable("testTwo");
        System.out.println("testTwo: " + resultVar);
        assertThat("Wrong variable returned", resultVar, equalToIgnoringCase("test two variable"));
    }
    
    @Test
    public void test7PassInVar() throws Exception {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setId("12365");
        DocumentAttachmentMetaData attachMetaData = new DocumentAttachmentMetaData();
        attachMetaData.setFsId("ade-345-eir-345-4494949ae");
        attachMetaData.setSentToDocVault(true);
        List<DocumentAttachmentMetaData> documentAttachments = new ArrayList<>();
        documentAttachments.add(attachMetaData);
        documentMetaData.setDocumentAttachments(documentAttachments);
        Document bsonDocMetadata = new Document();
        bsonDocMetadata.append("fsId", "ade-345-eir-345");
        documentMetaData.setMetadata(bsonDocMetadata);
        DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
        execution.setVariable("testTwo", "test two variable");
        execution.setVariable("Document", documentMetaData);
        checkForDuplicate.execute(execution);
        String resultVar = (String) execution.getVariable("testTwo");
        System.out.println("testTwo: " + resultVar);
        assertThat("Wrong variable returned", resultVar, equalToIgnoringCase("test two variable"));
    }
    
    @Test
    public void test7UnknownHost() throws Exception {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setId("12365");
        DocumentAttachmentMetaData attachMetaData = new DocumentAttachmentMetaData();
        attachMetaData.setFsId("ade-345-eir-345-4494949ae");
        List<DocumentAttachmentMetaData> documentAttachments = new ArrayList<>();
        documentAttachments.add(attachMetaData);
        documentMetaData.setDocumentAttachments(documentAttachments);
        Document bsonDocMetadata = new Document();
        bsonDocMetadata.append("fsId", "ade-345-eir-345");
        documentMetaData.setMetadata(bsonDocMetadata);
        DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
        execution.setVariable("testTwo", "test two variable");
        execution.setVariable("Document", documentMetaData);
        checkForDuplicate.execute(execution);
        String resultVar = (String) execution.getVariable("testTwo");
        System.out.println("testTwo: " + resultVar);
        assertThat("Wrong variable returned", resultVar, equalToIgnoringCase("test two variable"));
    }
    

}
