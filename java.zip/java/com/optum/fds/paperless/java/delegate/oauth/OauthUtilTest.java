package com.optum.fds.paperless.java.delegate.oauth;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.nio.charset.StandardCharsets;

import org.apache.commons.codec.binary.Base64;
import org.junit.Test;

public class OauthUtilTest {
	
	@Test
	public void testAreateAuthHeaderIsSuccess()
	{
		String userName = "testUserName";
		String password = "testPassword";
		String auth = userName + ":" + password;
	        byte[] encodedAuth = Base64.encodeBase64( 
	           auth.getBytes(StandardCharsets.US_ASCII));
	    assertEquals("Basic " + new String( encodedAuth ), OauthUtil.createAuthHeader(userName, password));
	}

}
