package com.optum.fds.paperless.java.delegate;

import static com.optum.fds.paperless.workflow.constants.Workflow.CLOUD_CLIENT_ID;
import static com.optum.fds.paperless.workflow.constants.Workflow.CLOUD_CLIENT_SECRET;
import static com.optum.fds.paperless.workflow.constants.Workflow.CLOUD_GRANT_TYPE;
import static com.optum.fds.paperless.workflow.constants.Workflow.FDS_CLOUD_AUTH_URL;
import static com.optum.fds.paperless.workflow.constants.Workflow.FDS_CLOUD_GET_ATTACHMENT_URL;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;


import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.Arrays;

import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.mongo.*;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.bson.Document;
import org.eclipse.collections.impl.list.Interval;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.google.common.collect.Lists;
import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.constants.ProcessKeys;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.exception.MongoDBApiException;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.OauthToken;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.workflow.constants.Workflow;

@RunWith(MockitoJUnitRunner.Silent.class) 
public class IdentifyDocumentsTest {
	private static final String TEST_DUMMY_SPACE_ID = "10102";
	private static final String TEST_DUMMY_TRANSACTION_ID = "abcdefg";
	private static final String TEST_DUMMY_IDENTIFIER = "dummy_identifier";
	private static final String TEST_DUMMY_CLIENT_ID = "88888888";
	private static final String TEST_DUMMY_DOCUMENT_ID = "testAnyDocumentId";
	private static final String DOC_CRITERIA = "{\"metadata.merged\":true}";
	private static final String SEARCH_WINDOW = "{\"start_date_offset\":{\"time_window\":\"72\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"0\",\"format\":\"Hours\"}}";

	@InjectMocks
	IdentifyDocuments identifyDocuments;

	@Mock
	DocumentMetaDataService documentMetaDataService;

	@Mock
	ProcessorService processorService;
	
	@Mock
	ConfigData config;

	@Mock
	HookService hookService;
	
	@Mock
	OauthManagerUtil oauthManagerUtil;

	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();

	DelegateExecution execution;

	@Mock
	RestTemplate restTemplate;

	@Mock
	private EhCache ehCache;

	private DocumentMetaData documentMetaData;
	
	
	@Before
	public void setup() throws IOException, InvalidExpressionException, MongoDBApiException, InterruptedException {
		execution = new DelegateExecutionImpl();
		execution.setVariable(Workflow.PROCESS_KEY, ProcessKeys.BOUNCE_PROCESS_KEY);
		execution.setVariable(Workflow.SPACE_ID, "10102");
		execution.setVariable(Workflow.APP_ID, "testapp");
		execution.setVariable(Workflow.CLIENT_ID, 1);
		execution.setVariable(Workflow.START_DATE_IN_DAYS, -1);
		execution.setVariable(Workflow.MAX_DOCUMENTS_OCCURS,500);
		execution.setVariable(Workflow.PROVIDER_EMAIL_ID, "andre@optum.com");
		execution.setVariable(Workflow.DOCUMENT, getDocumentMetaData());
		execution.setVariable(Workflow.HOOK_ID, "12345");

		execution.setVariable(Workflow.FDS_CLOUD_GET_ATTACHMENT_URL, "http://127.0.0.1:8080/v2/attachments");
		
		execution.setVariable(Workflow.FDS_CLOUD_AUTH_URL, "http://127.0.0.1:8080/oauth");
		execution.setVariable(Workflow.CLOUD_CLIENT_ID, "12345");
		execution.setVariable(Workflow.CLOUD_CLIENT_SECRET, "12345");
		execution.setVariable(Workflow.CLOUD_GRANT_TYPE, "client_credentials");

		execution.setVariable(Workflow.USE_DOC360, false);
		execution.setVariable(Workflow.MAX_DOCUMENTS_OCCURS, 300);

		execution.setVariable(Workflow.SKIP_SEND_TO_SHUTTERFLY, false);

		documentMetaData = getDocumentMetaData();
		List<DocumentMetaData> listDocumentMetaData = Interval.fromTo(1, 4).collect(x -> documentMetaData).toList();

		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");

		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		message2.put("providerEmailId", "none@optum.com");

		var processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		processorExecutionRecord.addMessage(message1);
		processorExecutionRecord.addMessage(message2);

		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		processorExecutionRecordList.add(processorExecutionRecord);

		var processorFileTask = new ProcessorFileTask();
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");


		Map<String, Object> credsMap = new HashMap<>();
		credsMap.put("10102", "{\"fdsCloudSpaceId\": \"1234\"}");
		credsMap.put("10068", "{\"fdsCloudSpaceId\": \"1234\"}");
		when(config.getCredentials(any())).thenReturn(credsMap);

		List<String> spaceIdList = new ArrayList<>();
		spaceIdList.add("11302");
		spaceIdList.add("11402");
		ReflectionTestUtils.setField(identifyDocuments, "ihrSpaceIdList", spaceIdList);
		
		OauthTokenExtended oauthTokenExtended = new OauthTokenExtended("testapp", "testapp");
		oauthTokenExtended.setAccessToken("abc1123");
		oauthTokenExtended.setExpiresIn(1800);
		oauthTokenExtended.setObtainedOn(new Date());
		
		Optional<OauthTokenExtended> optionalToken = Optional.of(oauthTokenExtended);
		
		when(oauthManagerUtil.getOauthTokenExtended(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), isNull()))
			.thenReturn(optionalToken);

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);

		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);

		try (MockedStatic<EhCache> cacheMock = Mockito.mockStatic(EhCache.class)) {
			cacheMock.when(() -> ehCache.putOauthTokenWithExpiry(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenAnswer((Answer<Void>) invocation -> null);
        }
		
		DocumentAttachmentMetaData attachment = new DocumentAttachmentMetaData();
		attachment.setUrl("http://test");
		attachment.setAttachmentId("123456");
		ResponseEntity<DocumentAttachmentMetaData> attachmentResponse = new ResponseEntity<>(attachment, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.any(URI.class), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(DocumentAttachmentMetaData.class))).thenReturn(attachmentResponse);

		ClassLoader classLoader = getClass().getClassLoader();
		File f1 = new File(classLoader.getResource("sendmail/sendemail.pdf").getFile());
		ResponseEntity<byte[]> response = new ResponseEntity<>(Files.readAllBytes (f1.toPath()), HttpStatus.OK);
		when(restTemplate.exchange(Mockito.any(URI.class), Mockito.eq(HttpMethod.GET), Mockito.any(),Mockito.eq(byte[].class))).thenReturn(response);

		when(hookService.getHookTransactionById(Mockito.anyString())).thenReturn(createHookTransaction());
		when(hookService.saveHookTransaction(Mockito.any())).thenReturn(createHookTransaction());
	}

	@UserStory(references = "US21376")
	@RallyTestCase(references = "TC26310")
	@Test
	public void testExecute() throws Exception {

		execution.setVariable(Workflow.SEARCH_WINDOW, SEARCH_WINDOW);

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		assertTrue((boolean) documentMetaData.getMetadata().get(Workflow.REPRNT_SENT_TO_SHUTTERFLY));
	}

	@Test
	public void testExecuteSkipSendToShutterfly() throws Exception {

		execution.setVariable(Workflow.SKIP_SEND_TO_SHUTTERFLY, true);
		execution.setVariable(Workflow.SEARCH_WINDOW, SEARCH_WINDOW);

		identifyDocuments.execute(execution);
		assertNotNull(documentMetaData.getMetadata().get(Workflow.E_DELIVERY_ERROR));
		assertTrue(documentMetaData.getMetadata().get(Workflow.E_DELIVERY_ERROR, String.class).contains("bounced"));
	}

	@Test
	public void testExecuteEmptyList() throws Exception {

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(new ArrayList<>());
		execution.setVariable(Workflow.SEARCH_WINDOW, SEARCH_WINDOW);

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
	}

	@Test
	public void testExecuteWithHttpStatusCodeExceptionFirstRequest() throws Exception {
		execution.setVariable(Workflow.SEARCH_WINDOW, SEARCH_WINDOW);

		HttpClientErrorException exception = HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST, null, null, null, null);
		when(restTemplate.exchange(Mockito.any(URI.class), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(DocumentAttachmentMetaData.class)))
				.thenThrow(exception);


		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
	}

	@Test
	public void testExecuteWithHttpStatusCodeExceptionSecondRequest() throws Exception {
		execution.setVariable(Workflow.SEARCH_WINDOW, SEARCH_WINDOW);

		HttpClientErrorException exception = HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST, null, null, null, null);
		when(restTemplate.exchange(Mockito.any(URI.class), Mockito.eq(HttpMethod.GET), Mockito.any(),Mockito.eq(byte[].class)))
				.thenThrow(exception);

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
	}

	@UserStory(references = "US19131")
	@RallyTestCase(references = "TC27933")
	@Test
	public void testExecuteWithRestClientException() throws Exception {
		ClassLoader classLoader = getClass().getClassLoader();
		File f1 = new File(classLoader.getResource("sendmail/sendemail.pdf").getFile());
		ResponseEntity<byte[]> response = new ResponseEntity<>(Files.readAllBytes (f1.toPath()), HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.eq(byte[].class))).thenThrow(new RestClientException("cannot find the service"));
		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		assertEquals(1, identifyDocuments.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testExecuteNoDocument() throws Exception {
		execution.setVariable(Workflow.DOCUMENT, null);
		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		assertEquals(1, identifyDocuments.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testExecuteWithDocumentSentToPrintServies() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		listDocumentMetaData.add(documentMetaData);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();

		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		message2.put("providerEmailId", "andre@optum.com");
		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		assertNull(documentMetaData.getMetadata().get(Workflow.REPRNT_SENT_TO_SHUTTERFLY));
		assertNull(documentMetaData.getMetadata().get(Workflow.SEND_TO_SHUTTERFLY));
	}

	@UserStory(references = "US27349")
	@RallyTestCase(references = "TC30629")
	@Test
	public void testExecuteWithDocumentSentToPrintServiesBounceEmailFlage() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaDataWithEFT_IND(true, "N");
		listDocumentMetaData.add(documentMetaData);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();

		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);


//		when(cleverSafeStorageAdapterMock.getAttachment(Mockito.anyString())).thenReturn(new ByteArrayInputStream("Test data from AmazonS3".getBytes()));
		execution.setVariable(Workflow.BOUNCE_EMAIL_CHECK_EFT_IND,true);
		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		
	
	}

	@Test
	public void testExecuteInvalidActivitiProcessKey() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		listDocumentMetaData.add(documentMetaData);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();

		processorExecutionRecord.setActivitiProcessKey("none");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		message2.put("providerEmailId", "andre@optum.com");
		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");


		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);

//		when(cleverSafeStorageAdapterMock.getAttachment(Mockito.anyString())).thenReturn(new ByteArrayInputStream("Test data from AmazonS3".getBytes()));

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
	}

	@RallyTestCase(references = "TC26311")
	@Test
	public void testExecuteWithInvalidMessage() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		listDocumentMetaData.add(documentMetaData);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("none", "none");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("invalid", "invalid");
		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);

//		when(cleverSafeStorageAdapterMock.getAttachment(Mockito.anyString())).thenReturn(new ByteArrayInputStream("Test data from AmazonS3".getBytes()));

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
	}

	@RallyTestCase(references = "TC29290")
	@Test
	public void testCheckEmailAlertReq() throws Exception{
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		Document docMetaData  = documentMetaData.getMetadata();
		docMetaData.append("docSentTo", "docVault");
//		docMetaData.append("emailAlertReq", "Y");
		listDocumentMetaData.add(documentMetaData);
		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);
		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		processorExecutionRecord.addMessage(message2);
		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");
		execution.setVariable(Workflow.DOCUMENT, documentMetaData);
		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);
		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
//		assertEquals(1, identifyDocuments.errorMap.get(Workflow.NEW_ERRORS));
		assertNull(documentMetaData.getMetadata().get(Workflow.SEND_TO_SHUTTERFLY));
	}


	@UserStory(references = "US24962")
	@RallyTestCase(references = "TC29654")
	@Test
	public void testCheckEFTIND() throws Exception{
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		Document docMetaData  = documentMetaData.getMetadata();
		docMetaData.append("docSentTo", "docVault");
		docMetaData.append("emailAlertReq", "Y");
		docMetaData.append("EFT_Ind", "N");
		listDocumentMetaData.add(documentMetaData);
		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);
		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		processorExecutionRecord.addMessage(message2);
		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		execution.setVariable(Workflow.DOCUMENT, documentMetaData);
		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);
//		when(cleverSafeStorageAdapterMock.getAttachment(Mockito.anyString())).thenReturn(new ByteArrayInputStream("Test data from AmazonS3".getBytes()));
		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		assertNull(documentMetaData.getMetadata().get(Workflow.SEND_TO_SHUTTERFLY));
	}

	@UserStory(references = "US27094")
	@RallyTestCase(references = "TC30056")
	@Test
	public void testCheckEFTIND_N() throws Exception{
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		Document docMetaData  = documentMetaData.getMetadata();
		docMetaData.append("docSentTo", "docVault");
		docMetaData.append("emailAlertReq", "Y");
		docMetaData.append("EFT_Ind", "N");
		docMetaData.append("stopProcessing", true);
		listDocumentMetaData.add(documentMetaData);
		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);
		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		processorExecutionRecord.addMessage(message2);
		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");
		execution.setVariable(Workflow.DOCUMENT, documentMetaData);
		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);
//		when(cleverSafeStorageAdapterMock.getAttachment(Mockito.anyString())).thenReturn(new ByteArrayInputStream("Test data from AmazonS3".getBytes()));
		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		assertEquals("docVault", docMetaData.get("docSentTo"));
	}

	public void testExecuteWithNullMessage() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		listDocumentMetaData.add(documentMetaData);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		processorExecutionRecord.addMessage(null);
		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);


		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		assertEquals(0, identifyDocuments.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testExecuteWithNullMessageList() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		listDocumentMetaData.add(documentMetaData);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);


//		when(cleverSafeStorageAdapterMock.getAttachment(Mockito.anyString())).thenReturn(new ByteArrayInputStream("Test data from AmazonS3".getBytes()));

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
	}

	@Test
	public void testExecuteWithInvalidActivityProcessKey() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		listDocumentMetaData.add(documentMetaData);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("none", "none");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("invalid", "invalid");
		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setId("1");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);

//		when(cleverSafeStorageAdapterMock.getAttachment(Mockito.anyString())).thenReturn(new ByteArrayInputStream("Test data from AmazonS3".getBytes()));

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
	}

	@UserStory(references = "US25181")
	@RallyTestCase(references = "TC29690")
	@Test
	public void testExecutetoCheckEDeliveryErrorinMetadata() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		listDocumentMetaData.add(documentMetaData);
		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		message2.put("providerEmailId", "none@optum.com");
		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);

//		when(cleverSafeStorageAdapterMock.getAttachment(Mockito.anyString())).thenReturn(new ByteArrayInputStream("Test data from AmazonS3".getBytes()));

		identifyDocuments.execute(execution);

		assertNull(documentMetaData.getMetadata().get(Workflow.SEND_TO_SHUTTERFLY));

	}

	@Test
	public void testExecuteWithNullAttachment() throws Exception {
		DocumentMetaData documentMetaData = getDocumentMetaData();
		documentMetaData.setDocumentAttachments(List.of());

		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		listDocumentMetaData.add(documentMetaData);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		message2.put("providerEmailId", "none@optum.com");
		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);

		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		
	}

	@Test
	public void testExecuteWithNullProcessorFileTask() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		listDocumentMetaData.add(documentMetaData);

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(null);

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
	}

	@Test
	public void testExecuteWithNullListMetaData() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		listDocumentMetaData.add(documentMetaData);
		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(null);

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
	}

	@Test
	public void testExecuteWithEmptyListMetaData() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
	}

	@Test
	public void testExecutionWithNullProviderEmailId() throws Exception {
		DocumentMetaData documentMetaData = getDocumentMetaData();
		documentMetaData.getMetadata().put("providerEmailId", null);
		execution.setVariable(Workflow.DOCUMENT, documentMetaData);
		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		assertEquals(1, identifyDocuments.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testExecutionWithEmptyProviderEmailId() throws Exception {
		DocumentMetaData documentMetaData = getDocumentMetaData();
		documentMetaData.getMetadata().put("providerEmailId", "");
		execution.setVariable(Workflow.DOCUMENT, documentMetaData);
		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		assertEquals(1, identifyDocuments.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	@UserStory(references = "US31438")
	@RallyTestCase(references = "TC32405")
	@Test
	public void testExecuteWithDocumentWithSendEmailNotificationsFalse() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaDataWithSendEmailNotifications(false);
		listDocumentMetaData.add(documentMetaData);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		message2.put("providerEmailId", "none@optum.com");
		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		AttachmentMetaData attachmentMetaData = new AttachmentMetaData();
		attachmentMetaData.setAdapterId("5638dc0d-ee56-4e3e-b587-d52100546da8");
		attachmentMetaData.setAdapterTypeId("20");
		attachmentMetaData.setFileName("test.txt");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);

//		when(cleverSafeStorageAdapterMock.getAttachment(Mockito.anyString())).thenReturn(new ByteArrayInputStream("Test data from AmazonS3".getBytes()));

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		
	}
	
	
	@UserStory(references = "US31438")
	@RallyTestCase(references = "TC32404")
	@Test
	public void testExecuteWithDocumentWithSendEmailNotificationsTrue() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaDataWithSendEmailNotifications(true);
		documentMetaData.getMetadata().put(Workflow.DATE_EMAIL_SENT, new Date());
		listDocumentMetaData.add(documentMetaData);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		message2.put("providerEmailId", "none@optum.com");
		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
	
	}
	
	@UserStory(references = "US31438")
	@RallyTestCase(references = "TC32408")
	@Test
	public void testExecuteWithDocumentWithSendPENAPIRequestFalse() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaDataWithSendEmailNotifications(false);
		documentMetaData.getMetadata().put(Workflow.METADATA_SEND_PEN_API_REQUEST, false);
		listDocumentMetaData.add(documentMetaData);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		message2.put("providerEmailId", "none@optum.com");
		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
//		assertEquals(0, identifyDocuments.errorMap.get(Workflow.NEW_ERRORS));
		
		
	}
	
	
	@UserStory(references = "US31438")
	@RallyTestCase(references = "TC32406")
	@Test
	public void testExecuteWithDocumentWithSendEmailNotifications() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaDataWithSendEmailNotifications(false);
		DocumentMetaData documentMetaData1 = getDocumentMetaDataWithSendEmailNotifications(false);
		DocumentMetaData documentMetaData2 = getDocumentMetaDataWithSendEmailNotifications(false);
		
		documentMetaData1.getMetadata().remove(Workflow.DATE_EMAIL_SENT);
		documentMetaData2.getMetadata().remove(Workflow.SEND_EMAIL_NOTIFICATIONS);
		
		listDocumentMetaData.add(documentMetaData);
		listDocumentMetaData.add(documentMetaData1);
		listDocumentMetaData.add(documentMetaData2);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		message2.put("providerEmailId", "none@optum.com");
		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);


//		when(cleverSafeStorageAdapterMock.getAttachment(Mockito.anyString())).thenReturn(new ByteArrayInputStream("Test data from AmazonS3".getBytes()));

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		List<DocumentMetaData> executionList = (List<DocumentMetaData>) execution.getVariable(Workflow.LIST_DOCUMENT_METADATA);
//		assertNotNull(executionList);
//		assertTrue(executionList.size() > 0);
//				
//		for (DocumentMetaData doc : executionList) {
//			assertEquals(true, doc.getMetadata().getBoolean(Workflow.SEND_EMAIL_NOTIFICATIONS));
//			assertNotNull(doc.getMetadata().get(Workflow.DATE_EMAIL_SENT));
//		}
	}
	
	

	@UserStory(references = "US25583")
	@RallyTestCase(references = "TC29811")
	@Test
	public void testExecuteWithDocumentWithSendToShutterfly() throws Exception {
		List<DocumentMetaData> listDocumentMetaData = new ArrayList<>();
		DocumentMetaData documentMetaData = getDocumentMetaDataWithSendToShutterfly();
		listDocumentMetaData.add(documentMetaData);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		List<ProcessorExecutionRecord> processorExecutionRecordList = new ArrayList<>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		message2.put("providerEmailId", "none@optum.com");
		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		processorFileTask.setId("1");

		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);


//		when(cleverSafeStorageAdapterMock.getAttachment(Mockito.anyString())).thenReturn(new ByteArrayInputStream("Test data from AmazonS3".getBytes()));

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
//		assertEquals(0, identifyDocuments.errorMap.get(Workflow.NEW_ERRORS));
		//((boolean) documentMetaData.getMetadata().get(Workflow.REPRNT_SENT_TO_SHUTTERFLY));
	}

	@UserStory(references = "US31237")
	@RallyTestCase(references = "TC32308")
	@Test
	public void testExecuteWithDocumentCriteria() throws Exception {
	    execution.setVariable(Workflow.CHECK_DOCUMENT_CRITERIA, true);
		execution.setVariable(Workflow.SEARCH_CRITERIA, DOC_CRITERIA);
		execution.setVariable(Workflow.SEARCH_WINDOW, SEARCH_WINDOW);
		DocumentMetaData documentMetaData = getDocumentMetaData();
		List<DocumentMetaData> listDocumentMetaData = Lists.newArrayList(documentMetaData, documentMetaData, documentMetaData, documentMetaData).stream()
				.peek(x -> x.getMetadata().put("merged", true)).collect(Collectors.toList());

		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("CreateOneZipfilePrintServices");
		Map<String, String> message1 = new HashMap<>();
		message1.put("outcome", "Files needed are present.");
		processorExecutionRecord.addMessage(message1);

		Map<String, String> message2 = new HashMap<>();
		message2.put("fsId", "abc123");
		message2.put("providerEmailId", "none@optum.com");
		processorExecutionRecord.addMessage(message2);

		List<ProcessorExecutionRecord> processorExecutionRecordList = Lists.newArrayList(processorExecutionRecord);

		ProcessorFileTask processorFileTask = new ProcessorFileTask();
		processorFileTask.setId("1");
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");


		when(documentMetaDataService.getDocumentMetaDataListWithPagingNew(Mockito.any(),
				Mockito.any(),
				Mockito.any(),
				Mockito.anyInt(),
				Mockito.anyInt())).thenReturn(listDocumentMetaData);
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);

//		when(cleverSafeStorageAdapterMock.getAttachment(Mockito.anyString())).thenReturn(new ByteArrayInputStream("Test data from AmazonS3".getBytes()));

		identifyDocuments.execute(execution);
		assertNotNull(identifyDocuments.errorMap);
		assertNull(documentMetaData.getMetadata().get(Workflow.SEND_TO_SHUTTERFLY));
	}

	@UserStory(references = "US6647566")
	@RallyTestCase(references = "TC4082835")
	@Test
	public void testDoesDocSatisfiesConditionSkipEFT() throws Exception {
		Configurator.setAllLevels("", Level.INFO);
		identifyDocuments.skipEFT_spaceIds = new ArrayList<Integer> (Arrays.asList(Integer.valueOf(TEST_DUMMY_SPACE_ID)));
		identifyDocuments.skipEFT_categories = Arrays.asList("C8");

		boolean doesDocSatisfiesConditionFlag = identifyDocuments.doesDocSatisfiesCondition(getDocumentMetaDataWithEFT_IND_Y(true));
		System.out.println("emailAlertReq = Y, EFT_IND=Y, doesDocSatisfiesConditionFlag=" + doesDocSatisfiesConditionFlag);
		assertFalse(doesDocSatisfiesConditionFlag);
		doesDocSatisfiesConditionFlag = identifyDocuments.doesDocSatisfiesCondition(getDocumentMetaDataWithEFT_IND_Y(false));
		System.out.println("emailAlertReq = N, EFT_IND=Y, doesDocSatisfiesConditionFlag=" + doesDocSatisfiesConditionFlag);
		assertFalse(doesDocSatisfiesConditionFlag);
	}

	@UserStory(references = "US6701793")
	@RallyTestCase(references = "TC4106006")
	@Test
	public void testDoesDocSatisfiesConditionCheckInd_835() throws Exception {
		Configurator.setAllLevels("", Level.INFO);
		identifyDocuments.checkInd_835_spaceIds = new ArrayList<Integer> (Arrays.asList(Integer.valueOf(TEST_DUMMY_SPACE_ID)));
		identifyDocuments.checkInd_835_ExcludedCategories = Arrays.asList("P8", "P9", "P0", "E1");

		//document has sub category=C8 for all

		// For CSP PRA non zero pay sub categories don't fetch the email if Ind_835 is true
		// checkInd_835_NotInCategories contains the zero pay categories

		boolean doesDocSatisfiesConditionFlag = identifyDocuments.doesDocSatisfiesCondition(getDocumentMetaDataWithEFT_IND(true, "Y"));
		System.out.println("EFT_IND=true, NotInCategories=not includes, doesDocSatisfiesConditionFlag=" + doesDocSatisfiesConditionFlag);
		assertFalse(doesDocSatisfiesConditionFlag);

		doesDocSatisfiesConditionFlag = identifyDocuments.doesDocSatisfiesCondition(getDocumentMetaDataWithEFT_IND(false, "Y"));
		System.out.println("EFT_IND=true, NotInCategories=not includes, doesDocSatisfiesConditionFlag=" + doesDocSatisfiesConditionFlag);
		assertFalse(doesDocSatisfiesConditionFlag);

		doesDocSatisfiesConditionFlag = identifyDocuments.doesDocSatisfiesCondition(getDocumentMetaDataWithEFT_IND(true, "N"));

		System.out.println("EFT_IND=false, NotInCategories=not includes, doesDocSatisfiesConditionFlag=" + doesDocSatisfiesConditionFlag);
		assertTrue(doesDocSatisfiesConditionFlag);

		// Sub category is in checkInd_835_NotInCategories, i.e zero pay categories thus true
		identifyDocuments.checkInd_835_ExcludedCategories = Arrays.asList("P8", "P9", "P0", "E1", "C8");

		doesDocSatisfiesConditionFlag = identifyDocuments.doesDocSatisfiesCondition(getDocumentMetaDataWithEFT_IND(false, "N"));
		System.out.println("EFT_IND=false, NotInCategories=includes, doesDocSatisfiesConditionFlag=" + doesDocSatisfiesConditionFlag);
		assertFalse(doesDocSatisfiesConditionFlag);


		doesDocSatisfiesConditionFlag = identifyDocuments.doesDocSatisfiesCondition(getDocumentMetaDataWithEFT_IND(true, "N"));
		System.out.println("EFT_IND=false, NotInCategories=includes, doesDocSatisfiesConditionFlag=" + doesDocSatisfiesConditionFlag);
		assertTrue(doesDocSatisfiesConditionFlag);

		doesDocSatisfiesConditionFlag = identifyDocuments.doesDocSatisfiesCondition(getDocumentMetaDataWithEFT_IND(true, "N"));

		System.out.println("EFT_IND=true, NotInCategories=includes, doesDocSatisfiesConditionFlag=" + doesDocSatisfiesConditionFlag);
		assertTrue(doesDocSatisfiesConditionFlag);
	}

	private DocumentMetaData getDocumentMetaData() {
		DocumentMetaData dmd = new DocumentMetaData();
		dmd.setId(TEST_DUMMY_DOCUMENT_ID);
		dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID) );
		dmd.setStatus("AVAILABLE");
		dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
		dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
		dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
		Document metadataObj = Document.parse("{ " +
				"\"fileDescription\" : \"Claim information request     \", " +
				"\"employeeName\" : \"PAMELA FERNANDO              \", " +
				"\"subCategory\" : \"C8\", " +
				"\"policyNumber\" : \"744530 \", " +
				"\"memberName\" : \"PAMELA FERNANDO               \", " +
				"\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
				"\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
				"\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
				"\"tin\" : \"03047636000002                \", " +
				"\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
				"\"category\" : \"Claim\", " +
				"\"claimNumber\" : \"1043126449\", " +
				"\"memberId\" : \"887543999\", " +
				"\"emailAlertReq\" : \"Y\", "+
				"\"providerEmailId\" : \"andre@optum.com\" " +
				"\"docSentTo\": \"docVault\" "+
				"}");
		metadataObj.put("message_id", "12345");
		List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
		DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
		documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
		documentAttachmentMetaData.setIndex(1);
		documentAttachmentMetaData.setName("53381514_71830516.pdf");
		listDocumentAttachmentMetaData.add(documentAttachmentMetaData);

		dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
		dmd.setMetadata(metadataObj);

		return dmd;
	}


	private DocumentMetaData getDocumentMetaDataWithEFT_IND_Y(Boolean emailAltrReq) {
		DocumentMetaData dmd = new DocumentMetaData();
		dmd.setId(TEST_DUMMY_DOCUMENT_ID);
		dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID) );
		dmd.setStatus("AVAILABLE");
		dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
		dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
		dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
		Document metadataObj = Document.parse("{ " +
				"\"fileDescription\" : \"Claim information request     \", " +
				"\"employeeName\" : \"PAMELA FERNANDO              \", " +
				"\"subCategory\" : \"C8\", " +
				"\"policyNumber\" : \"744530 \", " +
				"\"memberName\" : \"PAMELA FERNANDO               \", " +
				"\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
				"\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
				"\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
				"\"tin\" : \"03047636000002                \", " +
				"\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
				"\"category\" : \"Claim\", " +
				"\"claimNumber\" : \"1043126449\", " +
				"\"EFT_Ind\" : \"Y\", " +
				"\"memberId\" : \"887543999\", " +
				"\"emailAlertReq\" : \"Y\", "+
				((emailAltrReq) ? "\"emailAlertReq\" : \"Y\", " : "\"emailAlertReq\" : \"N\", ") +
				"\"providerEmailId\" : \"andre@optum.com\" " +
				"\"docSentTo\": \"docVault\" "+
				"}");
		List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
		DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
		documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
		documentAttachmentMetaData.setIndex(1);
		documentAttachmentMetaData.setName("53381514_71830516.pdf");
		listDocumentAttachmentMetaData.add(documentAttachmentMetaData);

		dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
		dmd.setMetadata(metadataObj);
		return dmd;
	}

	
	private DocumentMetaData getDocumentMetaDataWithEFT_IND(Boolean emailAltrReq, String ind_835) {
		DocumentMetaData dmd = new DocumentMetaData();
		dmd.setId(TEST_DUMMY_DOCUMENT_ID);
		dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID) );
		dmd.setStatus("AVAILABLE");
		dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
		dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
		dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
		Document metadataObj = Document.parse("{ " +
				"\"fileDescription\" : \"Claim information request     \", " +
				"\"employeeName\" : \"PAMELA FERNANDO              \", " +
				"\"subCategory\" : \"C8\", " +
				"\"policyNumber\" : \"744530 \", " +
				"\"memberName\" : \"PAMELA FERNANDO               \", " +
				"\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
				"\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
				"\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
				"\"tin\" : \"03047636000002                \", " +
				"\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
				"\"category\" : \"Claim\", " +
				"\"claimNumber\" : \"1043126449\", " +
				"\"EFT_Ind\" : \"Y\", " +
				"\"memberId\" : \"887543999\", " +
				"\"emailAlertReq\" : \"Y\", "+
				((emailAltrReq) ? "\"emailAlertReq\" : \"Y\", " : "\"emailAlertReq\" : \"N\", ") +
				"\"providerEmailId\" : \"andre@optum.com\" " +
				"\"docSentTo\": \"docVault\" "+
				"}");

		metadataObj.append("Ind_835", ind_835);
		List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
		DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
		documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
		documentAttachmentMetaData.setIndex(1);
		documentAttachmentMetaData.setName("53381514_71830516.pdf");
		listDocumentAttachmentMetaData.add(documentAttachmentMetaData);

		dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
		dmd.setMetadata(metadataObj);
		return dmd;
	}

	private DocumentMetaData getDocumentMetaDataWithSendToShutterfly() {
		DocumentMetaData dmd = new DocumentMetaData();
		dmd.setId(TEST_DUMMY_DOCUMENT_ID);
		dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID) );
		dmd.setStatus("AVAILABLE");
		dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
		dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
		dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
		Document metadataObj = Document.parse("{ " +
				"\"fileDescription\" : \"Claim information request     \", " +
				"\"employeeName\" : \"PAMELA FERNANDO              \", " +
				"\"subCategory\" : \"C8\", " +
				"\"policyNumber\" : \"744530 \", " +
				"\"memberName\" : \"PAMELA FERNANDO               \", " +
				"\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
				"\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
				"\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
				"\"tin\" : \"03047636000002                \", " +
				"\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
				"\"category\" : \"Claim\", " +
				"\"claimNumber\" : \"1043126449\", " +
				"\"memberId\" : \"887543999\", " +
				"\"emailAlertReq\" : \"Y\", "+
				"\"providerEmailId\" : \"andre@optum.com\" " +
				"\"sendToDocVault\": true, "+
				"\"sendToShutterfly\": false, "+
				"\"docSentTo\": \"docVault\" "+
				"}");
		List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
		DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
		documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
		documentAttachmentMetaData.setIndex(1);
		documentAttachmentMetaData.setName("53381514_71830516.pdf");
		listDocumentAttachmentMetaData.add(documentAttachmentMetaData);

		dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
		dmd.setMetadata(metadataObj);

		return dmd;
	}
	
	private DocumentMetaData getDocumentMetaDataWithSendEmailNotifications(boolean sendEmailNotifications) {
		DocumentMetaData dmd = new DocumentMetaData();
		dmd.setId(TEST_DUMMY_DOCUMENT_ID);
		dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID) );
		dmd.setStatus("AVAILABLE");
		dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
		dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
		dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
		
		Document metadataObj = null;
		
		if (sendEmailNotifications) {
			metadataObj = Document.parse("{ " +
					"\"fileDescription\" : \"Claim information request     \", " +
					"\"employeeName\" : \"PAMELA FERNANDO              \", " +
					"\"subCategory\" : \"C8\", " +
					"\"policyNumber\" : \"744530 \", " +
					"\"memberName\" : \"PAMELA FERNANDO               \", " +
					"\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
					"\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
					"\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
					"\"tin\" : \"03047636000002                \", " +
					"\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
					"\"category\" : \"Claim\", " +
					"\"claimNumber\" : \"1043126449\", " +
					"\"memberId\" : \"887543999\", " +
					"\"emailAlertReq\" : \"Y\", "+
					"\"providerEmailId\" : \"andre@optum.com\" " +
					"\"sendToDocVault\": true, "+
					"\"sendToShutterfly\": false, "+
					"\"docSentTo\": \"docVault\", "+
					"\"sendPENAPIRequest\": true, "+
					"\"sendEmailNotifications\": true, "+
					"\"dateEmailSent\": \"2021-03-11 16:45:00.000Z\" "+
					"}");
		} else {
			metadataObj = Document.parse("{ " +
					"\"fileDescription\" : \"Claim information request     \", " +
					"\"employeeName\" : \"PAMELA FERNANDO              \", " +
					"\"subCategory\" : \"C8\", " +
					"\"policyNumber\" : \"744530 \", " +
					"\"memberName\" : \"PAMELA FERNANDO               \", " +
					"\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
					"\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
					"\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
					"\"tin\" : \"03047636000002                \", " +
					"\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
					"\"category\" : \"Claim\", " +
					"\"claimNumber\" : \"1043126449\", " +
					"\"memberId\" : \"887543999\", " +
					"\"emailAlertReq\" : \"Y\", "+
					"\"providerEmailId\" : \"andre@optum.com\" " +
					"\"sendToDocVault\": true, "+
					"\"sendToShutterfly\": false, "+
					"\"docSentTo\": \"docVault\", "+
					"\"sendPENAPIRequest\": true, "+
					"\"sendEmailNotifications\": false, "+
					"\"dateEmailSent\": null "+
					"}");
		}
		
		List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
		DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
		documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
		documentAttachmentMetaData.setIndex(1);
		documentAttachmentMetaData.setName("53381514_71830516.pdf");
		listDocumentAttachmentMetaData.add(documentAttachmentMetaData);

		dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
		dmd.setMetadata(metadataObj);

		return dmd;
	}

	private HookTransactionMetaData createHookTransaction() {
		HookTransactionMetaData hook = new HookTransactionMetaData();
		hook.setSpaceId(10102);
		hook.setId("12345");
		hook.setClientId(123);
		hook.setAppIdentifier("1234556677");
		hook.setHookExecutionList(new ArrayList<>());
		return hook;
	}

}
