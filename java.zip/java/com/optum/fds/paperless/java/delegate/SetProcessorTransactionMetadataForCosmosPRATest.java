package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.collections.CollectionUtils;
import org.bson.Document;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
//import org.springframework.test.util.ReflectionTestUtils;

import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import com.optum.fds.paperless.processing.service.ProcessorTransactionsService;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;


public class SetProcessorTransactionMetadataForCosmosPRATest {

	@Rule
	public TemporaryFolder folder = new TemporaryFolder();

	@Mock
	DocumentMetaDataService documentMetaDataService;

	@Mock
	ErrorMetaDataService errorMetaDataService;

	@Mock
	CsvProcessorsService csvProcessorsService;

	@Mock
	ProcessorService processorService;
	
	@Mock
	ProcessorTransactionsService processorTransactionsService;
	
	@Mock
    ProcessorFileTaskService processorFileTaskService;

	DelegateExecution execution;

	Document execVars = new Document();

	@InjectMocks
	SetProcessorTransactionMetadataForCosmosPRA setProcessorTransactionMetadataForCosmosPra;

	private final String PATH_JSON_FILE = "SetProcessorTransactionMetadataForCosmosPra/InputJsonExample.json";
	private final String PATH_JSON_EMPTY_FILE = "SetProcessorTransactionMetadataForCosmosPra/EmptyInputJsonExample.json";

	@Before
	public void setUp() throws FSDataException, IOException, URISyntaxException {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);
		String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();

		execVars.append(Workflow.JSON_FILE, jsonFile).append(Workflow.OUTPUT_FILE_DIR, "/dropzone")
				.append(Workflow.ENVIRONMENT, "prod").append(Workflow.TEMPLATE_NAME, "checkWritePRAEmailAlert");

		when(execution.getVariables()).thenReturn(execVars);
		when(execution.getVariable(Workflow.JSON_FILE, String.class))
				.thenReturn(execVars.get(Workflow.JSON_FILE, String.class));
		
		when(execution.getVariable(Workflow.TEMPLATE_NAME, String.class))
			.thenReturn(execVars.get(Workflow.TEMPLATE_NAME, String.class));
		
		when(execution.getVariable(Workflow.OUTPUT_FILE_DIR, String.class))
				.thenReturn(execVars.get(Workflow.OUTPUT_FILE_DIR, String.class));
		when(execution.getVariable(Workflow.ENVIRONMENT, String.class))
				.thenReturn(execVars.get(Workflow.ENVIRONMENT, String.class));
		when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
	}

	private CsvProcessorTransaction getCsvProcessorTransaction(MetaDataStatus status) {
		CsvProcessorTransaction csvProcTransaction = new CsvProcessorTransaction();
		csvProcTransaction.setAppIdentifier("testApp");
		csvProcTransaction.setClientId(1234);
		csvProcTransaction.setLocation("/location");
		csvProcTransaction.setConfigSpaceId(10068);
		csvProcTransaction.setProcessorId("1234567");
		csvProcTransaction.setId("12345678");
		csvProcTransaction.setStatus(status);
		return csvProcTransaction;
	}

	private ProcessorTransaction getProcessorTransaction() {
		ProcessorTransaction processorTransaction = new ProcessorTransaction();
		processorTransaction.setServerType("ose");
		processorTransaction.setId("123456789");
		return processorTransaction;
	}

	private List<ProcessorFileTask> getProcessorFileTaskList() {
		List<ProcessorFileTask> list = new ArrayList<ProcessorFileTask>();
		ProcessorFileTask p1 = new ProcessorFileTask();
		ProcessorFileTask p2 = new ProcessorFileTask();
		Map<String, String> metadata = new HashMap<String, String>();
		metadata.put("createApplication", "CDC");
		p1.setMetadata(metadata);
		p2.setMetadata(metadata);
		list.add(p1);
		list.add(p2);
		return list;
	}
	
	private List<ProcessorFileTask> getProcessorFileTaskListNonCDC() {
		List<ProcessorFileTask> list = new ArrayList<ProcessorFileTask>();
		ProcessorFileTask p1 = new ProcessorFileTask();
		ProcessorFileTask p2 = new ProcessorFileTask();
		Map<String, String> metadata = new HashMap<String, String>();
		metadata.put("createApplication", "TEST");
		p1.setMetadata(metadata);
		p2.setMetadata(metadata);
		list.add(p1);
		list.add(p2);
		return list;
	}

	private List<ProcessorFileTask> getProcessorFileTaskListNull() {
		List<ProcessorFileTask> list = new ArrayList<ProcessorFileTask>();
		ProcessorFileTask p1 = new ProcessorFileTask();
		ProcessorFileTask p2 = new ProcessorFileTask();
		list.add(p1);
		list.add(p2);
		return list;
	}

	@Test
	public void testRequiredVariableJsonFileNotfound() throws Exception {
		execVars.append(Workflow.JSON_FILE, null);
		setProcessorTransactionMetadataForCosmosPra.execute(execution);
		assertNotNull(setProcessorTransactionMetadataForCosmosPra.errorMap);
		assertEquals(1, setProcessorTransactionMetadataForCosmosPra.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testRequiredVariableOutputDirNotfound() throws Exception {
		execution.setVariable(Workflow.OUTPUT_FILE_DIR, null);
		execVars.append(Workflow.OUTPUT_FILE_DIR, null);
		setProcessorTransactionMetadataForCosmosPra.execute(execution);
		assertNotNull(setProcessorTransactionMetadataForCosmosPra.errorMap);
		assertEquals(1, setProcessorTransactionMetadataForCosmosPra.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	@Test
	public void testRequiredVariableTemplateNameNotfound() throws Exception {
		execution.setVariable(Workflow.TEMPLATE_NAME, null);
		setProcessorTransactionMetadataForCosmosPra.execute(execution);
		assertNotNull(setProcessorTransactionMetadataForCosmosPra.errorMap);
		assertEquals(0, setProcessorTransactionMetadataForCosmosPra.errorMap.get(Workflow.NEW_ERRORS));
	}

//	@Test
	public void testDoExecute() throws Exception {
		when(csvProcessorsService.getCsvProcessorTransactionWithFileName(Mockito.any()))
				.thenReturn(getCsvProcessorTransaction(MetaDataStatus.FATAL_ERROR));
		when(processorTransactionsService.findProcessorTransactionByFileName(Mockito.any(), Mockito.any()))
		.thenReturn(getProcessorTransaction());
		when(processorFileTaskService.getProcessorFileTasksForTransactionId(Mockito.any(), Mockito.any()))
		.thenReturn(getProcessorFileTaskListNonCDC());
		setProcessorTransactionMetadataForCosmosPra.execute(execution);
		assertNotNull(setProcessorTransactionMetadataForCosmosPra.errorMap);
		assertEquals(0, setProcessorTransactionMetadataForCosmosPra.errorMap.get(Workflow.NEW_ERRORS));
	}

	 @Test
	public void testDoExecuteCDC() throws Exception {
		when(csvProcessorsService.getCsvProcessorTransactionWithFileName(Mockito.any()))
				.thenReturn(getCsvProcessorTransaction(MetaDataStatus.FATAL_ERROR));
		when(processorTransactionsService.findProcessorTransactionByFileName(Mockito.any(), Mockito.any()))
				.thenReturn(getProcessorTransaction());
		when(processorFileTaskService.getProcessorFileTasksForTransactionId(Mockito.any(), Mockito.any()))
				.thenReturn(getProcessorFileTaskList());
		setProcessorTransactionMetadataForCosmosPra.execute(execution);

		String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
		List<ProcessorTransactionMetadata> processorTransactionMetadataList = WorkFlowUtil
				.readProcessorTransactionMetadataFromJsonFile(jsonFile);
		for (ProcessorTransactionMetadata processorTransactionMetadata : processorTransactionMetadataList) {
			Map<String, Object> clientHashmap = processorTransactionMetadata.getClient();
			//assertEquals(false, clientHashmap.get("sendCompanionFileMissingEmail"));
		}
		assertNotNull(setProcessorTransactionMetadataForCosmosPra.errorMap);
		assertEquals(0, setProcessorTransactionMetadataForCosmosPra.errorMap.get(Workflow.NEW_ERRORS));
	}

//	@Test
	public void testDoExecuteCDCNullCreateApplicationNullCsvProcessor() throws Exception {
		when(csvProcessorsService.getCsvProcessorTransactionWithFileName(Mockito.any())).thenReturn(null);
		when(processorTransactionsService.findProcessorTransactionByFileName(Mockito.any(), Mockito.any()))
				.thenReturn(getProcessorTransaction());
		when(processorFileTaskService.getProcessorFileTasksForTransactionId(Mockito.any(), Mockito.any()))
				.thenReturn(getProcessorFileTaskListNull());
		setProcessorTransactionMetadataForCosmosPra.execute(execution);

		String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
		List<ProcessorTransactionMetadata> processorTransactionMetadataList = WorkFlowUtil
				.readProcessorTransactionMetadataFromJsonFile(jsonFile);
		for (ProcessorTransactionMetadata processorTransactionMetadata : processorTransactionMetadataList) {
			Map<String, Object> clientHashmap = processorTransactionMetadata.getClient();
			//assertEquals(true, clientHashmap.get("sendCompanionFileMissingEmail"));
		}
		assertNotNull(setProcessorTransactionMetadataForCosmosPra.errorMap);
		assertEquals(0, setProcessorTransactionMetadataForCosmosPra.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testDoExecuteCDCNullCreateApplication() throws Exception {
		when(csvProcessorsService.getCsvProcessorTransactionWithFileName(Mockito.any()))
				.thenReturn(getCsvProcessorTransaction(MetaDataStatus.FATAL_ERROR));
		when(processorTransactionsService.findProcessorTransactionByFileName(Mockito.any(), Mockito.any()))
				.thenReturn(getProcessorTransaction());
		when(processorFileTaskService.getProcessorFileTasksForTransactionId(Mockito.any(), Mockito.any()))
				.thenReturn(getProcessorFileTaskListNull());
		setProcessorTransactionMetadataForCosmosPra.execute(execution);

		String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
		List<ProcessorTransactionMetadata> processorTransactionMetadataList = WorkFlowUtil
				.readProcessorTransactionMetadataFromJsonFile(jsonFile);
		for (ProcessorTransactionMetadata processorTransactionMetadata : processorTransactionMetadataList) {
			Map<String, Object> clientHashmap = processorTransactionMetadata.getClient();
			//assertEquals(false, clientHashmap.get("sendCompanionFileMissingEmail"));
		//	assertEquals(true, clientHashmap.get("sendCompanionFileUnreadableEmail"));
		}
		assertNotNull(setProcessorTransactionMetadataForCosmosPra.errorMap);
		assertEquals(0, setProcessorTransactionMetadataForCosmosPra.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testEmptyJsonFile() throws Exception {
		ArrayList<ProcessorTransactionMetadata> list = new ArrayList<>();
		String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_EMPTY_FILE).getAbsolutePath();
		execution.setVariable(Workflow.JSON_FILE, jsonFile);
		setProcessorTransactionMetadataForCosmosPra.execute(execution);
		assertNotNull(setProcessorTransactionMetadataForCosmosPra.errorMap);
		assertEquals(0, setProcessorTransactionMetadataForCosmosPra.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testCsvProcessorTransactionWithCompleteStatus() throws Exception {
		when(csvProcessorsService.getCsvProcessorTransactionWithFileName(Mockito.any()))
				.thenReturn(getCsvProcessorTransaction(MetaDataStatus.COMPLETE));
		setProcessorTransactionMetadataForCosmosPra.execute(execution);
		assertNotNull(setProcessorTransactionMetadataForCosmosPra.errorMap);
		assertEquals(0, setProcessorTransactionMetadataForCosmosPra.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	@Test
	public void testCsvProcessorTransactionWithCompleteWithErrorsStatus() throws Exception {
		when(csvProcessorsService.getCsvProcessorTransactionWithFileName(Mockito.any()))
				.thenReturn(getCsvProcessorTransaction(MetaDataStatus.COMPLETE_WITH_ERRORS));
		setProcessorTransactionMetadataForCosmosPra.execute(execution);
		assertNotNull(setProcessorTransactionMetadataForCosmosPra.errorMap);
		assertEquals(0, setProcessorTransactionMetadataForCosmosPra.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	@Test
	public void testCsvProcessorTransactionWithFatalStatus() throws Exception {
		when(csvProcessorsService.getCsvProcessorTransactionWithFileName(Mockito.any()))
				.thenReturn(getCsvProcessorTransaction(MetaDataStatus.FATAL_ERROR));
		setProcessorTransactionMetadataForCosmosPra.execute(execution);
		assertNotNull(setProcessorTransactionMetadataForCosmosPra.errorMap);
		assertEquals(0, setProcessorTransactionMetadataForCosmosPra.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	
	@Test
	public void testNoCsvProcessorTransactions() throws Exception {
		when(csvProcessorsService.getCsvProcessorTransactionWithFileName(Mockito.any())).thenReturn(null);
		setProcessorTransactionMetadataForCosmosPra.execute(execution);
		assertNotNull(setProcessorTransactionMetadataForCosmosPra.errorMap);
		assertEquals(0, setProcessorTransactionMetadataForCosmosPra.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	@Test
	public void testProcessorTransactionMetadataListEmpty() throws IOException, JSONException
	{
//		  LOGGER.warn("SetProcessorTransactionMetadataForCosmosPra-->doExecute-->processorTransactionMetadataList is null or empty");
		String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
        List<ProcessorTransactionMetadata> processorTransactionMetadataList = WorkFlowUtil.readProcessorTransactionMetadataFromJsonFile(jsonFile);
        String messgeKey = (String) execution.getVariable(Workflow.PROCESS_KEY) + "_message";
        if(CollectionUtils.isEmpty(processorTransactionMetadataList))
        {
             execution.setTransientVariable(messgeKey, "processorTransactionMetadataList is null or empty");
             assertNotNull(execution.getVariable(messgeKey));
        }else {
        	assertNull(execution.getVariable(messgeKey));
        }     
	}
	
	

}
