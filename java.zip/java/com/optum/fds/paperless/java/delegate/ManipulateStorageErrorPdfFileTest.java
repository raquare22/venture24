package com.optum.fds.paperless.java.delegate;

import static com.optum.fds.paperless.workflow.constants.Workflow.*;
import static org.junit.Assert.*;

import java.io.File;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ManipulateStorageErrorPdfFileTest {

    @InjectMocks
    ManipulateStorageErrorPdfFile manipulateStorageErrorPdfFile;

    DelegateExecution execution = new DelegateExecutionImpl();

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    private static final String TEST_DUMMY_SPACE_ID = "99999999";
    private static final String TEST_DUMMY_TRANSACTION_ID = "abcdefg";
    private static final String TEST_DUMMY_IDENTIFIER = "dummy_identifier";
    private static final String TEST_DUMMY_CLIENT_ID = "88888888";
    private static final String TEST_DUMMY_DOCUMENT_ID = "TEST-DOC-1";

    @Before
    public void setup() throws Exception {
        execution.setVariable(Workflow.SKIP_MANIPULATE_PDF_FILE, false);
        execution.setVariable(Workflow.ADDRESS_BLOCK_X, 1.00);
        execution.setVariable(Workflow.ADDRESS_BLOCK_Y, 1.84);
        execution.setVariable(Workflow.RECEIVER_IDENTIFIER, "DPS$$$PKG");
        execution.setVariable(Workflow.IDENTIFIER_FONT_SIZE, 8.0);
        execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, List.of(getDocumentMetaData()));
    }

    @Test
    public void testDoExecute() throws Exception {
        ClassLoader classLoader = getClass().getClassLoader();
        File pdfInput = new File(classLoader.getResource("temp/pdfInput.pdf").getFile());
        Files.copy(pdfInput.toPath(), Paths.get(tempFolder.getRoot().getAbsolutePath()).resolve(pdfInput.toPath().getFileName()));

        manipulateStorageErrorPdfFile.execute(execution);

        List<DocumentMetaData> list = execution.getVariable(LIST_DOCUMENT_METADATA, List.class);
        assertFalse(list.isEmpty());
        DocumentMetaData doc = list.get(0);
        Document metadata = doc.getMetadata();
        String tagLine = metadata.get(TAG_LINE, "");
        assertFalse(tagLine.isEmpty());
    }

    @Test
    public void testDoExecuteSkipManipulatePDFFile() throws Exception {
        execution.setVariable(Workflow.SKIP_MANIPULATE_PDF_FILE, true);
        manipulateStorageErrorPdfFile.execute(execution);

        assertNotNull(manipulateStorageErrorPdfFile.errorMap);
        assertEquals(0, manipulateStorageErrorPdfFile.errorMap.get(Workflow.NEW_ERRORS));
    }

    @Test
    public void testGenerateTagLine() throws Exception {
        // Use reflection to access the private method
        Method method = ManipulateStorageErrorPdfFile.class.getDeclaredMethod("generateTagLine");
        method.setAccessible(true);

        String tagLine = (String) method.invoke(manipulateStorageErrorPdfFile);

        assertNotNull("Tag line should not be null", tagLine);
        assertTrue("Tag line should have a length greater than 0", tagLine.length() > 0);
    }

    @Test
    public void testGetSecureRandomNumber() throws Exception {
        // Use reflection to access the private method
        Method method = ManipulateStorageErrorPdfFile.class.getDeclaredMethod("getSecureRandomNumber");
        method.setAccessible(true);

        String randomNumber = (String) method.invoke(manipulateStorageErrorPdfFile);

        assertNotNull("Random number should not be null", randomNumber);
        assertEquals("Random number should have a length of 6", 6, randomNumber.length());
        assertTrue("Random number should only contain digits", randomNumber.matches("\\d+"));
    }


    private DocumentMetaData getDocumentMetaData() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID) );
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        String junitDir = tempFolder.getRoot().getAbsolutePath() + File.separator;
        junitDir = junitDir.replace("\\", "\\\\");
        Document metadataObj = Document.parse("{" +
                "\"fileDescription\" : \"Claim information request\"," +
                "\"employeeName\" : \"PAMELA FERNANDO\"," +
                "\"subCategory\" : \"C8\"," +
                "\"policyNumber\" : \"744530\"," +
                "\"memberName\" : \"PAMELA FERNANDO\"," +
                "\"expiryDate\" : \"2017-12-03T04:06:31Z\"," +
                "\"createdDate\" : \"2017-01-24T00:05:00.000Z\"," +
                "\"physicianName\" : \"MOHAMED A ZINEDDIN MD\"," +
                "\"tin\" : \"03047636000002\"," +
                "\"dateOfService\" : \"0017-01-21T00:04:00.000Z\"," +
                "\"category\" : \"Claim\"," +
                "\"claimNumber\" : \"1043126449\"," +
                "\"memberId\" : \"887543999\"," +
                "\"providerEmailId\" : \"andre@optum.com\"," +
                "\"absolutePath\" : \"" + junitDir + "\"," +
                "\"processorFileTaskId\" : \"59362a436ea628b7dcd52396\""+
                "}");

        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("pdfInput.pdf");
        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
//        DocumentAttachmentMetaData documentAttachmentMetaData2 = new DocumentAttachmentMetaData();
//        documentAttachmentMetaData2.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
//        documentAttachmentMetaData2.setIndex(1);
//        documentAttachmentMetaData2.setName("pdfInput2.pdf");
//        listDocumentAttachmentMetaData.add(documentAttachmentMetaData2);

        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        dmd.setFileName("pdfInput.pdf");
        return dmd;
    }
}