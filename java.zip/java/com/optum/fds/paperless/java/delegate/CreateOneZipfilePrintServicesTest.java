package com.optum.fds.paperless.java.delegate;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.HookServiceImpl;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.workflow.service.ZipUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang.StringUtils;
import org.bson.Document;
import org.eclipse.collections.api.multimap.Multimap;
import org.eclipse.collections.api.tuple.Pair;
import org.eclipse.collections.impl.factory.Maps;
import org.eclipse.collections.impl.factory.Sets;
import org.eclipse.collections.impl.tuple.Tuples;
import org.eclipse.collections.impl.utility.LazyIterate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.optum.fds.paperless.java.delegate.CreateShutterflyDocumentsTest.*;
import static com.optum.fds.paperless.workflow.constants.Workflow.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CreateOneZipfilePrintServicesTest {

	private static final String ORIGINAL_PRINT_TRAIL = "1905";

	@InjectMocks
	CreateOneZipfilePrintServices createOneZipfilePrintServices;

	DelegateExecution execution;

	@Mock
	ZipUtil zipUtil;

	@Mock
	ProcessorService processorService;

	@Mock
	HookServiceImpl hookServiceImpl;

	@Before
	public void setup() throws Exception {
		DocumentMetaData documentMetaData = getDocumentMetaData();
		documentMetaData.setId("1234");
		var listDocumentMetaData = List.of(
				getDocumentMetaDataOriginalCompanionRecord(),
				getDocumentMetaDataOriginalCompanionRecordSecond(),
				getDocumentMetaData(),
				getDocumentMetaDataPriorAuthLetters(),
				getDocumentMetaDataCorporateMpinMissing(),
				documentMetaData,
				getDocumentMetaDataWithEmptyCorporateMpin(),
				getDocumentMetaDataPriorAuthLetters2(),
				getDocumentMetaDataWithMissingMailAddressOne(),
				getDocumentMetaDataWithMissingMailAddressOneAndProviderName(),
				getDocumentMetaDataOriginalCompanionRecordReal()

		);
		var listDocumentMultiMap = getMultiMapDocumentMetadata(listDocumentMetaData);
		var correlationIds = LazyIterate.adapt(listDocumentMetaData)
				.collect(x -> x == null? Tuples.pair(StringUtils.EMPTY, StringUtils.EMPTY) :
						Tuples.pair(x.getId(), String.valueOf(x.getSpaceId())))
				.toMap(Pair::getOne, x -> x.getOne() + "_" + x.getTwo());

		var manifestFileList = listDocumentMultiMap.keySet().toList();

		List<String> fileList = new ArrayList<String>();
		fileList.add("testone.pdf");
		fileList.add("testtwo.pdf");

		execution = new DelegateExecutionImpl();
		execution.setVariable(OUTPUT_FILE_DIR, "/test/");
		execution.setVariable(PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP, listDocumentMultiMap);
		execution.setVariable(PRINT_SERVICES_MANIFEST, manifestFileList);
		execution.setVariable(CORRELATION_IDS, correlationIds);
		execution.setVariable(SFTP_FILE_LIST, fileList);

		var processorFileTask = new ProcessorFileTask();
		var processorExecutionRecordList = new ArrayList<ProcessorExecutionRecord>();
		ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("IntegratePrintServices");
		processorExecutionRecord.addMessage(Maps.mutable.of("outcome", "Files needed are present."));
		processorExecutionRecord.addMessage(Maps.mutable.of("fsId", "abc123", "providerEmailId", "max@optum.com"));

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(processorFileTask);
		Mockito.lenient().when(processorService.updateProcessorFileTask(Mockito.any())).thenReturn(null);
		when(zipUtil.zipFiles(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(true);
	}

	@Test
	public void testExecution() throws Exception {
		createOneZipfilePrintServices.execute(execution);
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(0, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testExecutionWithException() throws Exception {

		DocumentMetaData documentMetaData = getDocumentMetaData();
		documentMetaData.setId("1234");

		DocumentMetaData documentMetaData1 = getDocumentMetaData();
		documentMetaData1.setId("5678");
		List<DocumentMetaData> listDocumentMetaData = ImmutableList.of(documentMetaData1, documentMetaData);

		execution.setVariable(PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP, getMultiMapDocumentMetadata(listDocumentMetaData));
		execution.setVariable(PRINT_SERVICES_MANIFEST, ImmutableList.of(FDS_RPRNT_APPLICATION_NAME, FDS_RPRNT_APPLICATION_NAME));
		execution.setVariable(CORRELATION_IDS, ImmutableMap.of(documentMetaData.getId(), documentMetaData.getId() + "_" + documentMetaData.getSpaceId(),
				documentMetaData1.getId(), documentMetaData1.getId() + "_" + documentMetaData1.getSpaceId()
		));

		when(zipUtil.zipFiles(Mockito.any(),Mockito.any(),Mockito.any())).thenThrow(IOException.class);
		createOneZipfilePrintServices.execute(execution);
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(1, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}

	@Test
	public void testExecutionWithMultiMetadataWithSamePdf() throws Exception {
		var listDocumentMetaData = new ArrayList<DocumentMetaData>();
		var documentMetaData = getDocumentMetaDataFirst();
		documentMetaData.setId("1234");
		listDocumentMetaData.add(documentMetaData);
		DocumentMetaData documentMetaDataSecond = getDocumentMetaDataSecond();
		documentMetaData.setId("12345");
		listDocumentMetaData.add(documentMetaDataSecond);
		execution.setVariable(PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP, getMultiMapDocumentMetadata(listDocumentMetaData));
		createOneZipfilePrintServices.execute(execution);
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(0, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}

	@UserStory(references = "DE6780")
	@RallyTestCase(references = "TC32307")
	@Test
	public void testExecutionWithMultiMetadataWithSamePdfWithDifferentFiletask() throws Exception {
		var listDocumentMetaData = new ArrayList<DocumentMetaData>();
		var documentMetaData = getDocumentMetaDataFirst();
		documentMetaData.setId("1234");
		listDocumentMetaData.add(documentMetaData);
		DocumentMetaData documentMetaDataSecond = getDocumentMetaDataSecond();
		documentMetaData.setId("12345");
		listDocumentMetaData.add(documentMetaDataSecond);
		execution.setVariable(PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP, getMultiMapDocumentMetadata(listDocumentMetaData));
		Mockito.lenient().when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(getFirstProcessorFileTask(), getSecondProcessorFileTask());
		createOneZipfilePrintServices.execute(execution);
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(0, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}


	@UserStory(references = "US24816")
	@RallyTestCase(references = "TC29485")
	@Test
	public void testExecutionWithMissingRequiredVariables() throws Exception {
		execution = new DelegateExecutionImpl();
		createOneZipfilePrintServices.execute(execution);
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(2, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}

	@UserStory(references = "US26198")
	@RallyTestCase(references = "TC30279")
	@Test
	public void testExecutionWithAdditionalVariables() throws Exception {
		execution.setVariable(ORIGINAL_COMPANION_FILENAME, "originalCompanionFileName");
		createOneZipfilePrintServices.execute(execution);
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(0, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}

	@UserStory(references = "DE6700")
	@RallyTestCase(references = "TC31212")
	@Test
	public void testExecutionWithFileNameFDS_NO_RPRNT() throws Exception {
		var docMeta = getDocumentMetaData();
		execution.setVariable(PRINT_SERVICES_MANIFEST, Collections.singletonList(FDS_NO_RPRNT_APPLICATION_NAME));
		var listDocumentMetaData = new ArrayList<DocumentMetaData>();
		docMeta.setId("1234");
		listDocumentMetaData.add(docMeta);
		execution.setVariable(PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP, getMultiMapDocumentMetadata(listDocumentMetaData));
		createOneZipfilePrintServices.execute(execution);
		var zipFileList = (List<String>)execution.getVariable(SFTP_FILE_LIST);
		var txtFile = zipFileList.get(0);
		assertEquals(true, txtFile.endsWith("txt"));
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(0, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}

	@UserStory(references = "DE6700")
	@RallyTestCase(references = "TC31212")
	@Test
	public void testExecutionWithFileNameFDS_RPRNT() throws Exception {
		var docMeta = getDocumentMetaData();
		var listDocumentMetaData = new ArrayList<DocumentMetaData>();
		docMeta.setId("1234");
		listDocumentMetaData.add(docMeta);
		execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
		execution.setVariable(PRINT_SERVICES_MANIFEST, Collections.singletonList(FDS_RPRNT_APPLICATION_NAME));
		execution.setVariable(PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP, getMultiMapDocumentMetadata(listDocumentMetaData));
		createOneZipfilePrintServices.execute(execution);
		var zipFileList = (List<String>)execution.getVariable(SFTP_FILE_LIST);
		String txtFile = zipFileList.get(0);
		assertEquals(true, txtFile.endsWith("zip"));
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(0, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}

	@UserStory(references = "DE6700")
	@RallyTestCase(references = "TC31213")
	@Test
	public void testExecutionWithNOPostCardInd() throws Exception {
		var docMeta = getDocumentMetaData();
		var listDocumentMetaData = new ArrayList<DocumentMetaData>();
		docMeta.setId("1234");
		listDocumentMetaData.add(docMeta);
		execution.setVariable(PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP, getMultiMapDocumentMetadata(listDocumentMetaData));
		createOneZipfilePrintServices.execute(execution);
		var zipFileList = (List<String>)execution.getVariable(SFTP_FILE_LIST);
		String zipFile = zipFileList.get(0);
		assertEquals(true, zipFile.endsWith("zip"));
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(0, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}

	@Test
	public void testExecutionWithZipFileException() throws Exception {
		when(zipUtil.zipFiles(Mockito.any(), Mockito.any(), Mockito.any())).thenThrow(IOException.class);
		createOneZipfilePrintServices.execute(execution);
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(1, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}
	@Test
	public void testExecutionWithMissingTargetManifestWorkingDir() throws Exception {
		execution.setVariable(OUTPUT_FILE_DIR_SHUTTERFLY, null);
		execution.setVariable(OUTPUT_FILE_DIR_BOUNCE, null);
		createOneZipfilePrintServices.execute(execution);
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(0, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}
	@Test
	public void testExecutionWithFileToBeAdded() throws Exception {
		execution.setVariable(OUTPUT_FILE_DIR_SHUTTERFLY, null);
		execution.setVariable(OUTPUT_FILE_DIR_BOUNCE, "/bounceDir/");
		createOneZipfilePrintServices.execute(execution);
		assertEquals("FDS_RPRNT.zip", execution.getVariable("bouncedEmailFileName"));
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(0, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}
	@Test
	public void testExecutionWithCreatePdfZipForFdsReprint() throws Exception {
		var documentMetaData = getDocumentMetaData();
		documentMetaData.setAppIdentifier(FDS_RPRNT_APPLICATION_NAME);
		execution.setVariable(PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP, getMultiMapDocumentMetadata(List.of(documentMetaData)));
		execution.setVariable(PRINT_SERVICES_MANIFEST, List.of(FDS_RPRNT_APPLICATION_NAME));
		createOneZipfilePrintServices.execute(execution);
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(0, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}
	@Test
	public void testExecutionWithNullCorrelationIDs() throws Exception {
		execution.setVariable(CORRELATION_IDS, null);
		createOneZipfilePrintServices.execute(execution);
		assertNotNull(createOneZipfilePrintServices.errorMap);
		assertEquals(0, createOneZipfilePrintServices.errorMap.get(NEW_ERRORS));
	}

	private DocumentMetaData getDocumentMetaData() {
		var dmd = new DocumentMetaData();
		dmd.setId("testAnyDocumentId");
		dmd.setSpaceId(Integer.parseInt("99900999"));
		dmd.setStatus("AVAILABLE");
		dmd.setClientId(Integer.parseInt("88877888"));
		dmd.setAppIdentifier("testapp");
		dmd.setTransactionId("zxy8888");
		Document metadataObj = Document.parse("{ " +
				"\"fileDescription\" : \"Claim information request     \", " +
				"\"employeeName\" : \"PAMELA FERNANDO              \", " +
				"\"subCategory\" : \"C8\", " +
				"\"policyNumber\" : \"744530 \", " +
				"\"memberName\" : \"PAMELA FERNANDO               \", " +
				"\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
				"\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
				"\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
				"\"tin\" : \"03047636000002                \", " +
				"\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
				"\"category\" : \"Claim\", " +
				"\"claimNumber\" : \"1043126449\", " +
				"\"memberId\" : \"887543999\", " +
				"\"providerEmailId\" : \"andre@optum.com\", " +
				"\"absolutePath\" : \"/test/\", " +
				"}");
		var listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
		var documentAttachmentMetaData = new DocumentAttachmentMetaData();
		documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
		documentAttachmentMetaData.setIndex(1);
		documentAttachmentMetaData.setName("documentfile1.txt");
		listDocumentAttachmentMetaData.add(documentAttachmentMetaData);


		documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da9");
		documentAttachmentMetaData.setIndex(1);
		documentAttachmentMetaData.setName("documentfile2.txt");
		listDocumentAttachmentMetaData.add(documentAttachmentMetaData);

		dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
		dmd.setMetadata(metadataObj);

		return dmd;
	}

	private DocumentMetaData getDocumentMetaDataFirst() {
		var dmd = new DocumentMetaData();
		dmd.setId("testAnyDocumentId");
		dmd.setSpaceId(Integer.parseInt("99900999"));
		dmd.setStatus("AVAILABLE");
		dmd.setClientId(Integer.parseInt("88877888"));
		dmd.setAppIdentifier("testapp");
		dmd.setTransactionId("zxy8888");
		Document metadataObj = Document.parse("{ " +
				"\"fileDescription\" : \"Claim information request     \", " +
				"\"employeeName\" : \"PAMELA FERNANDO              \", " +
				"\"subCategory\" : \"C8\", " +
				"\"policyNumber\" : \"744530 \", " +
				"\"memberName\" : \"PAMELA FERNANDO               \", " +
				"\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
				"\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
				"\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
				"\"tin\" : \"03047636000002                \", " +
				"\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
				"\"category\" : \"Claim\", " +
				"\"claimNumber\" : \"1043126449\", " +
				"\"memberId\" : \"887543999\", " +
				"\"providerEmailId\" : \"andre@optum.com\", " +
				"\"absolutePath\" : \"/test/\", " +
				"}");
		var listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
		var documentAttachmentMetaData = new DocumentAttachmentMetaData();
		documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
		documentAttachmentMetaData.setIndex(1);
		documentAttachmentMetaData.setName("documentfile1.pdf");
		listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
		dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
		dmd.setMetadata(metadataObj);

		return dmd;
	}

	private DocumentMetaData getDocumentMetaDataSecond() {
		DocumentMetaData dmd = new DocumentMetaData();
		dmd.setId("testAnyDocumentId");
		dmd.setSpaceId(Integer.parseInt("99900999"));
		dmd.setStatus("AVAILABLE");
		dmd.setClientId(Integer.parseInt("88877888"));
		dmd.setAppIdentifier("testapp");
		dmd.setTransactionId("zxy8888");
		Document metadataObj = Document.parse("{ " +
				"\"fileDescription\" : \"Claim information request     \", " +
				"\"employeeName\" : \"PAMELA FERNANDO              \", " +
				"\"subCategory\" : \"C8\", " +
				"\"policyNumber\" : \"744530 \", " +
				"\"memberName\" : \"PAMELA FERNANDO               \", " +
				"\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
				"\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
				"\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
				"\"tin\" : \"03047636000002                \", " +
				"\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
				"\"category\" : \"Claim\", " +
				"\"claimNumber\" : \"1043126449\", " +
				"\"memberId\" : \"887543999\", " +
				"\"providerEmailId\" : \"andre@optum.com\", " +
				"\"absolutePath\" : \"/test/\", " +
				"}");
		List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
		DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
		documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
		documentAttachmentMetaData.setIndex(1);
		documentAttachmentMetaData.setName("documentfile1.pdf");
		listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
		dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
		dmd.setMetadata(metadataObj);

		return dmd;
	}

	private ProcessorFileTask getFirstProcessorFileTask() {
		var processorFileTask = new ProcessorFileTask();
		var processorExecutionRecordList = new ArrayList<ProcessorExecutionRecord>();
		var processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("IntegratePrintServices");
		processorExecutionRecord.addMessage(Maps.mutable.of("outcome", "Files needed are present."));
		processorExecutionRecord.addMessage(Maps.mutable.of("fsId", "abc123", "providerEmailId", "max@optum.com"));

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
		return processorFileTask;
	}

	private ProcessorFileTask getSecondProcessorFileTask() {
		var processorFileTask = new ProcessorFileTask();
		var processorExecutionRecordList = new ArrayList<ProcessorExecutionRecord>();
		var processorExecutionRecord = new ProcessorExecutionRecord();
		processorExecutionRecord.setActivitiProcessKey("IntegratePrintServices2");
//		var message1 = new HashMap<String, Object>();
//		message1.put("outcome", "Files needed are present.");
//		processorExecutionRecord.addMessage(message1);
//		Map<String, Object> message2 = new HashMap<String, Object>();
//		message2.put("fsId", "abc1234");
//		message2.put("providerEmailId", "max@optum.com");
//		processorExecutionRecord.addMessage(message2);

		processorExecutionRecordList.add(processorExecutionRecord);
		processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
		processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a787");
		return processorFileTask;
	}

	private Multimap<String, DocumentMetaData> getMultiMapDocumentMetadata(List<DocumentMetaData> listDocumentMetaData) {
		var fileSet = Sets.mutable.<String>empty();
		return LazyIterate.adapt(listDocumentMetaData)
				.select(x -> fileSet.add(x.getMetadata().getString(FILE_NAME)))
				.groupBy(this::getFileName);
	}

	private String getFileName(DocumentMetaData documentMetaData) {
		var x = documentMetaData.getMetadata();
		var postCardInd = (boolean) x.getOrDefault(POST_CARD_IND, false);
		var providerEmailId = x.getString(PROVIDER_EMAIL_ID);
		var originalPrintTrail = (String) x.getOrDefault(ORIGINAL_PRINT_TRAIL, CreateOneZipfilePrintServicesTest.ORIGINAL_PRINT_TRAIL);
		String fileName;
		if (postCardInd && (Strings.isNullOrEmpty(x.getString(TIN)) || Strings.isNullOrEmpty(x.getString(PROV_CORP_MPIN)))) {
			fileName = FDS_RPRNT_APPLICATION_NAME;
		} else if (postCardInd && Strings.isNullOrEmpty(providerEmailId)) {
			fileName = FDS_NO_RPRNT_APPLICATION_NAME + "_" + originalPrintTrail;
		} else {
			fileName = (postCardInd) ? FDS_NO_RPRNT_APPLICATION_NAME + "_" + originalPrintTrail : FDS_RPRNT_APPLICATION_NAME;
		}
		return fileName;
	}


}