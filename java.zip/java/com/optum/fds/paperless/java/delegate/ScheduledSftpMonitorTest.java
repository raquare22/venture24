package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.AdditionalAnswers.returnsFirstArg;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.domain.service.ScheduledSftpMonitor;
import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.SftpMonitorUtil;
import org.bson.Document;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoExceptionTranslator;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.springframework.test.util.ReflectionTestUtils;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

@RunWith(MockitoJUnitRunner.class)
public class ScheduledSftpMonitorTest {

    MongoTemplate template;

    private static final String DIRECTORY_LISTING = "directoryListing";
    private static final String CHANNEL_SFTP = "channelSftp";

    @Mock
    ProcessorService processorService;
    @Mock
    ProcessorsService processorsService;
    @Mock
    SftpMonitorUtil sftpMonitorUtil;

    ProcessorMetaData processor;
    
    @InjectMocks
    ScheduledSftpMonitor scheduledSftpMonitor;

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();


    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        
        ReflectionTestUtils.setField(sftpMonitorUtil, "ingestRoot",  "/ingest");
        
        String processObj = "{\n" + 
        		"    \"id\" : \"12345abcde\",\n" + 
        		"    \"cleanupWorkflow\" : \"cleanupFilesCreateACKProcess\",\n" + 
        		"    \"locked\" : false,\n" + 
        		"    \"resolveIncompleteProcessorTransactionLocked\" : false,\n" + 
        		"    \"process\" : {\n" + 
        		"        \"process_key\" : \"sftpProcess\",\n" + 
        		"        \"config\" : {\n" + 
        		"            \"space_id\" : \"10059\",\n" + 
        		"            \"host_name_source\" : \"ecgpi.healthtechnologygroup.com\",\n" + 
        		"            \"host_name_destination\" : \"ecgpi.healthtechnologygroup.com\",\n" + 
        		"            \"ftp_rootdir\" : \"/dropzone\",\n" + 
        		"            \"ftp_ackdir\" : \"/batch/priorauth_ccs_bravo_archive\",\n" + 
        		"            \"ftp_archivedir\" : \"/batch/priorauth_ccs_bravo_archive\",\n" + 
        		"            \"username_destination\" : \"is00amf\",\n" + 
        		"            \"username_source\" : \"is00amf\",\n" + 
        		"            \"pw_source\" : \"YW03eGag\",\n" + 
        		"            \"pw_destination\" : \"YW03eGag\",\n" + 
        		"            \"interval\" : \"1\",\n" + 
        		"            \"cleanup_interval\" : \"2\",\n" + 
        		"            \"templateId\" : \"5b439f193082be0e318a06d1\",\n" + 
        		"            \"templateRecordType\" : \"CCSPriorAuth\",\n" + 
        		"            \"clientName\" : \"PriorAuthCCSManual\",\n" + 
        		"			 \"zipFilePattern\" : \"([A-Za-z+])+(.zip)\",\n" + 
        		"            \"requiredFieldProcessing\" : true,\n" + 
        		"            \"generateSingleAckSummaryFile\" : false,\n" + 
        		"            \"resolveIncompleteProcessorTransactionInterval\" : 120,\n" + 
        		"            \"ackWithErrorsOnlyFile\" : false,\n" + 
        		"            \"addProcessorTransactionMetadata\" : false\n" + 
        		"        }\n" + 
        		"    },\n" + 
        		"    \"retryCount\" : 0,\n" + 
        		"    \"priority\" : 50,\n" + 
        		"    \"configSpaceId\" : 10059,\n" + 
        		"    \"processorRecordType\" : \"processor\",\n" + 
        		"    \"appIdentifier\" : \"testapp\",\n" + 
        		"    \"clientId\" : 685,\n" + 
        		"    \"name\" : \"ceZtU2FIbp7PrNl62H7cozK87IL6G3VI\",\n" + 
        		"    \"status\" : \"IN_PROCESS\",\n" + 
        		"    \"transactionId\" : \"75ae9c8b-f83b-4047-b793-c225ad298c0c\",\n" + 
        		"    \"version\" : \"1\",\n" + 
        		"    \"_class\" : \"com.optum.fs.mongo.processors.ProcessorMetaData\"\n" + 
        		"}";
        
        org.bson.Document obj = org.bson.Document.parse(processObj);
        processor = createProcessor(obj);
        when(processorsService.getProcessor(anyString(), anyString())).thenReturn(processor);

    }

    private ProcessorTransaction getProcessorTransaction() {
        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setAppIdentifier("testApp");
        processorTransaction.setTransactionId("a088f60b");
        processorTransaction.getSummary();
        processorTransaction.setStartTime();
        processorTransaction.setId("123");
        processorTransaction.setStatus("NEW");
        return processorTransaction;
    }

    @Test
    public void testSFTPoll() throws IOException, SftpException, JSchException, FSDataException {
        Map<String, Object> result = getSftpResults();
        when(sftpMonitorUtil.hasValidStatus(any())).thenReturn(true);
        when(sftpMonitorUtil.proccessSFTPDirectory(any(), any(), any(), any())).thenReturn(result);
        String tempFolderStr = tempFolder.getRoot().getAbsolutePath();
        Mockito.lenient().when(processorsService.findProcessorMetaDataByFileName (anyString(), anyString())).thenReturn(null);
        Mockito.lenient().when(processorsService.createTransactionRecord(any(ProcessorMetaData.class))).thenReturn(getTransaction());
        Mockito.lenient().when(sftpMonitorUtil.createFileOutputDirectoryPath(anyMap(), any(ProcessorMetaData.class), anyString())).thenReturn(tempFolderStr + "/test1");
        Mockito.lenient().when(processorsService.createProcessorTransaction(any(ProcessorMetaData.class), anyString(), anyString(), anyString())).thenReturn(new ProcessorTransaction());
        scheduledSftpMonitor.runSFTPMonitor(processor);
        assertTrue(true);
    }

    @Test
    public void testSFTPollNeedToCreateWorkingDir() throws IOException, SftpException, JSchException, FSDataException {
        Map<String, Object> result = getSftpResults();
        when(sftpMonitorUtil.hasValidStatus(any())).thenReturn(true);
        when(sftpMonitorUtil.proccessSFTPDirectory(any(), any(), any(), any())).thenReturn(result);
        Mockito.lenient().when(processorsService.findProcessorMetaDataByFileName (anyString(), anyString())).thenReturn(null);
        Mockito.lenient().when(processorsService.createTransactionRecord(any(ProcessorMetaData.class))).thenReturn(getTransaction());
        String tempFolderStr = tempFolder.getRoot().getAbsolutePath();
        Mockito.lenient().when(sftpMonitorUtil.createFileOutputDirectoryPath(anyMap(), any(ProcessorMetaData.class), anyString())).thenReturn(tempFolderStr + "/noyet1");
        Mockito.lenient().when(processorsService.createProcessorTransaction(any(ProcessorMetaData.class), anyString(), anyString(), anyString())).thenReturn(new ProcessorTransaction());
        scheduledSftpMonitor.runSFTPMonitor(processor);
        assertTrue(true);
    }

    @Test
    public void testSFTPollNeedToCreateWorkingDirWithException() throws IOException, SftpException, JSchException, FSDataException {
    	Map<String, Object> result = getSftpResults();
        when(sftpMonitorUtil.hasValidStatus(any())).thenReturn(true);
        when(sftpMonitorUtil.proccessSFTPDirectory(any(), any(), any(), any())).thenReturn(result);
        Mockito.lenient().when(processorsService.findProcessorMetaDataByFileName (anyString(), anyString())).thenReturn(null);
        Mockito.lenient().when(processorsService.createTransactionRecord(any(ProcessorMetaData.class))).thenReturn(getTransaction());
        String tempFolderStr = tempFolder.getRoot().getAbsolutePath();
        Mockito.lenient().when(sftpMonitorUtil.createFileOutputDirectoryPath(anyMap(), any(ProcessorMetaData.class), anyString())).thenReturn(tempFolderStr + "/notyet2");
        Mockito.lenient().when(processorsService.createProcessorTransaction(any(ProcessorMetaData.class), anyString(), anyString(), anyString())).thenReturn(new ProcessorTransaction());
        scheduledSftpMonitor.runSFTPMonitor(processor);
        assertTrue(true);
    }

    @Test
    public void testSFTPollNotNullFileMetadata() throws IOException, SftpException, JSchException, FSDataException {
        Map<String, Object> result = getSftpResults();
        when(sftpMonitorUtil.hasValidStatus(any())).thenReturn(true);
        when(sftpMonitorUtil.proccessSFTPDirectory(any(), any(), any(), any())).thenReturn(result);
        when(processorsService.findProcessorMetaDataByFileName (anyString(), anyString())).thenReturn(processor);
        scheduledSftpMonitor.runSFTPMonitor(processor);
        assertTrue(true);
    }

    @Test
    public void testSFTPollException() throws IOException, SftpException, JSchException, FSDataException {
        Map<String, Object> result = getSftpResults();
        when(sftpMonitorUtil.hasValidStatus(any())).thenReturn(true);
        when(sftpMonitorUtil.proccessSFTPDirectory(any(), any(), any(), any())).thenReturn(result);
        Mockito.lenient().when(processorsService.findProcessorMetaDataByFileName (anyString(), anyString())).thenReturn(null);
        Mockito.lenient().when(processorsService.createTransactionRecord(any(ProcessorMetaData.class))).thenReturn(getTransaction());
        String tempFolderStr = tempFolder.getRoot().getAbsolutePath();
        Mockito.lenient().when(sftpMonitorUtil.createFileOutputDirectoryPath(anyMap(), any(ProcessorMetaData.class), anyString())).thenReturn(tempFolderStr + "/test1");
        Mockito.lenient().when(processorsService.createProcessorTransaction(any(ProcessorMetaData.class), anyString(), anyString(), anyString())).thenThrow(new NullPointerException());
        scheduledSftpMonitor.runSFTPMonitor(processor);
        assertTrue(true);
    }

    @Test
    public void testSFTPollJobException() throws IOException, SftpException, JSchException, FSDataException {
        Map<String, Object> result = getSftpResults();
        when(sftpMonitorUtil.hasValidStatus(any())).thenReturn(true);
        when(sftpMonitorUtil.proccessSFTPDirectory(any(), any(), any(), any())).thenReturn(result);
        Mockito.lenient().when(processorsService.findProcessorMetaDataByFileName (anyString(), anyString())).thenReturn(null);
        Mockito.lenient().when(processorsService.createTransactionRecord(any(ProcessorMetaData.class))).thenReturn(getTransaction());
        Mockito.lenient().when(processorsService.createProcessorTransaction(any(ProcessorMetaData.class), anyString(), anyString(), anyString())).thenReturn(getProcessorTransaction());
        String tempFolderStr = tempFolder.getRoot().getAbsolutePath();
        Mockito.lenient().when(sftpMonitorUtil.createFileOutputDirectoryPath(anyMap(), any(ProcessorMetaData.class), anyString())).thenReturn(tempFolderStr + "/test3");
        scheduledSftpMonitor.runSFTPMonitor(processor);
        assertTrue(true);
    }

    private Transaction getTransaction() {
        Transaction transaction = new Transaction();
        transaction.setTransactionId("1");
        return transaction;
    }

    private final Map<String, Object> getSftpResults() {
        Map<String, Object> result = new HashMap<>();
        result.put(DIRECTORY_LISTING, getDirectoryListing());
        result.put(CHANNEL_SFTP, getChannelSftp());
        return result;
    }
    
    private final Map<String, Object> getSftpResults1() {
        Map<String, Object> result = new HashMap<>();
        result.put(DIRECTORY_LISTING, getDirectoryListing1());
        result.put(CHANNEL_SFTP, getChannelSftp());
        return result;
    }

    private Object getChannelSftp() {
        return mock(ChannelSftp.class);
    }
    
    @Test
    public void testSFTPollInvalidZipFileName() throws IOException, SftpException, JSchException, FSDataException {
        Map<String, Object> result = getSftpResults1();
        when(sftpMonitorUtil.hasValidStatus(any())).thenReturn(true);
        when(sftpMonitorUtil.proccessSFTPDirectory(any(), any(), any(), any())).thenReturn(result);
        when(processorsService.findProcessorMetaDataByFileName (anyString(), anyString())).thenReturn(null);
        scheduledSftpMonitor.runSFTPMonitor(processor);
        assertTrue(true);
    }
    
    private ArrayList<ChannelSftp.LsEntry> getDirectoryListing1() {
        ArrayList<ChannelSftp.LsEntry> directoryListing = new ArrayList<>();
        
        ChannelSftp.LsEntry lsEntry4 = mock(ChannelSftp.LsEntry.class);
        when(lsEntry4.getFilename()).thenReturn("1234-invalid-zip-file-name.zip");

        directoryListing.add(lsEntry4);
        return directoryListing;
    }


    private ArrayList<ChannelSftp.LsEntry> getDirectoryListing() {
        ArrayList<ChannelSftp.LsEntry> directoryListing = new ArrayList<>();
        
        ChannelSftp.LsEntry lsEntry = mock(ChannelSftp.LsEntry.class);
        when(lsEntry.getFilename()).thenReturn("test.csv");

        ChannelSftp.LsEntry lsEntry1 = mock(ChannelSftp.LsEntry.class);
        when(lsEntry1.getFilename()).thenReturn("test.zip");

        ChannelSftp.LsEntry lsEntry2 = mock(ChannelSftp.LsEntry.class);
        when(lsEntry2.getFilename()).thenReturn("test_ack.zip");

        ChannelSftp.LsEntry lsEntry3 = mock(ChannelSftp.LsEntry.class);
        when(lsEntry3.getFilename()).thenReturn("test.txt");

        ChannelSftp.LsEntry lsEntry4 = mock(ChannelSftp.LsEntry.class);
        when(lsEntry4.getFilename()).thenReturn("1234-invalid-zip-file-name.zip");

        directoryListing.add(lsEntry);
        directoryListing.add(lsEntry1);
        directoryListing.add(lsEntry2);
        directoryListing.add(lsEntry3);
        directoryListing.add(lsEntry4);
        return directoryListing;
    }


    private ProcessorMetaData createProcessor(org.bson.Document obj) {
        ProcessorMetaData processorMetaData;
        processorMetaData = new ProcessorMetaData();
        processorMetaData.setId("1234");
        processorMetaData.setAppIdentifier("testapp");
        processorMetaData.setName("TestOne");
        processorMetaData.setProcess(obj);
        processorMetaData.setProcessorRecordType(ProcessorRecordTypes.processor);
        processorMetaData.setStatus(MetaDataStatus.IN_PROCESS);
        processorMetaData.setConfigSpaceId(10102);
        return processorMetaData;
    }

    @Test
    public void testSFTPollwithBadCredentials() throws Exception {
    	String processObj = "{\n" + 
        		"    \"id\" : \"12345abcde\",\n" + 
        		"    \"cleanupWorkflow\" : \"cleanupFilesCreateACKProcess\",\n" + 
        		"    \"locked\" : false,\n" + 
        		"    \"resolveIncompleteProcessorTransactionLocked\" : false,\n" + 
        		"    \"process\" : {\n" + 
        		"        \"process_key\" : \"sftpProcess\",\n" + 
        		"        \"config\" : {\n" + 
        		"            \"space_id\" : \"10059\",\n" + 
        		"            \"host_name_destination\" : \"ecgpi.healthtechnologygroup.com\",\n" + 
        		"            \"ftp_rootdir\" : \"\",\n" + 
        		"            \"ftp_ackdir\" : \"/batch/priorauth_ccs_bravo_archive\",\n" + 
        		"            \"ftp_archivedir\" : \"/batch/priorauth_ccs_bravo_archive\",\n" + 
        		"            \"username_destination\" : \"is00amf\",\n" + 
        		"            \"pw_source\" : \"YW03eGag\",\n" + 
        		"            \"pw_destination\" : \"YW03eGag\",\n" + 
        		"            \"interval\" : \"1\",\n" + 
        		"            \"cleanup_interval\" : \"2\",\n" + 
        		"            \"templateId\" : \"5b439f193082be0e318a06d1\",\n" + 
        		"            \"templateRecordType\" : \"CCSPriorAuth\",\n" + 
        		"            \"clientName\" : \"PriorAuthCCSManual\",\n" + 
        		"			 \"zipFilePattern\" : \"([A-Za-z0-9+])+(.zip)\",\n" + 
        		"            \"requiredFieldProcessing\" : true,\n" + 
        		"            \"generateSingleAckSummaryFile\" : false,\n" + 
        		"            \"resolveIncompleteProcessorTransactionInterval\" : 120,\n" + 
        		"            \"ackWithErrorsOnlyFile\" : false,\n" + 
        		"            \"addProcessorTransactionMetadata\" : false\n" + 
        		"        }\n" + 
        		"    },\n" + 
        		"    \"retryCount\" : 0,\n" + 
        		"    \"priority\" : 50,\n" + 
        		"    \"configSpaceId\" : 10059,\n" + 
        		"    \"processorRecordType\" : \"processor\",\n" + 
        		"    \"appIdentifier\" : \"jg00aijptyt6rokvkumdnnjhaa6ywxj4\",\n" + 
        		"    \"clientId\" : 685,\n" + 
        		"    \"name\" : \"ceZtU2FIbp7PrNl62H7cozK87IL6G3VI\",\n" + 
        		"    \"status\" : \"IN_PROCESS\",\n" + 
        		"    \"transactionId\" : \"75ae9c8b-f83b-4047-b793-c225ad298c0c\",\n" + 
        		"    \"version\" : \"1\",\n" + 
        		"    \"_class\" : \"com.optum.fs.mongo.processors.ProcessorMetaData\"\n" + 
        		"}";
        org.bson.Document obj = org.bson.Document.parse(processObj);

        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        processorMetaData.setId("1234");
        processorMetaData.setAppIdentifier("testapp");
        processorMetaData.setName("TestOne");
        processorMetaData.setProcess(obj);
        processorMetaData.setProcessorRecordType(ProcessorRecordTypes.processor);
        
        scheduledSftpMonitor.runSFTPMonitor(processorMetaData);
        assertTrue(true);
    }

    @Test
    public void testRunSftpInvalidStatus() throws IOException {
        when(sftpMonitorUtil.hasValidStatus(any(ProcessorMetaData.class))).thenReturn(false);
        scheduledSftpMonitor.runSFTPMonitor(processor);
        assertTrue(true);
    }
    
    @Test
    public void testValidateZipFileName() throws Exception {
    	// CDC Cosmos (CheckWrite) PRA
    	assertTrue(scheduledSftpMonitor.validateZipFileName(
    			"ProvPRA_prnt_COSMOS_1001-1_PayOnly_20211129-153344.zip", 
    			"([A-Za-z]+_)+(COSMOS_)([0-9]+-[0-9]+_)([A-Za-z]+_)+([0-9]+-[0-9]+)(.zip)"));
    	assertFalse(scheduledSftpMonitor.validateZipFileName(
    			"ProvPRA_prnt_COSMOS_1001-1_PayOnly_20211129-153344_ack.zip", 
    			"([A-Za-z]+_)+(COSMOS_)([0-9]+-[0-9]+_)([A-Za-z]+_)+([0-9]+-[0-9]+)(.zip)"));
    	
    	// Cosmos (CheckWrite) PRA
    	assertTrue(scheduledSftpMonitor.validateZipFileName(
    			"2021329ZCCPAS0.zip", 
    			"([0-9]+[A-Z]+[0-9]?)(.zip)"));
    	assertTrue(scheduledSftpMonitor.validateZipFileName(
    			"2021329ZCCPAUD.zip", 
    			"([0-9]+[A-Z]+[0-9]?)(.zip)"));
    	assertFalse(scheduledSftpMonitor.validateZipFileName(
    			"2021329ZCCPAS0_ack.zip", 
    			"([0-9]+[A-Z]+[0-9]?)(.zip)"));
    	
    	// COSMOS
    	assertTrue(scheduledSftpMonitor.validateZipFileName(
    			"FDSMANUAL_PDF_Y_20213011_735.zip", 
    			"(FDSMANUAL_PDF_[A-Z])(_[0-9]+)+(.zip)"));
    	assertFalse(scheduledSftpMonitor.validateZipFileName(
    			"FDSMANUAL_PDF_Y_20213011_735_ack.zip", 
    			"([0-9]+[A-Z]+[0-9]?)(.zip)"));
    }

}