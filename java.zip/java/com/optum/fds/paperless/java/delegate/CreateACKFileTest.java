package com.optum.fds.paperless.java.delegate;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CreateACKFileTest {

	@Mock
	private ProcessorsService processorsService;

	@Mock
	private ProcessorService processorService;

	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();

	private DelegateExecution execution = new DelegateExecutionImpl();

	@InjectMocks
	private CreateACKFile createACKFile;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);

		execution.setVariable(Workflow.ACK_FLAG, true);
		execution.setVariable(Workflow.GENERATE_SINGLE_ACK_SUMMARY_FILE_FLAG, false);

		execution.setVariable(Workflow.ACK_WITH_ERRORS_ONLY, false);
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION, getProcessorTransaction());

		ClassLoader classLoader = getClass().getClassLoader();
		File f1 = new File(classLoader.getResource("good.zip").getFile());

		Files.copy(f1.toPath(), Paths.get(tempFolder.getRoot().getAbsolutePath()).resolve(f1.toPath().getFileName()));

	}

	@Test
	public void testDoExecute_Success() throws Exception {
		when(processorsService.getProcessorFileTasksForTransactionId(anyString())).thenReturn(getProcessorFileTaskList());

		createACKFile.execute(execution);

		assertNotNull(createACKFile.errorMap);

		ProcessorTransaction result = execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class);

		assertNotNull(result);
		assertFalse(result.getProcessorExecutionRecordList().isEmpty());

	}

	@Test
	public void testExecuteAckWithErrorsOnly() throws Exception {
		execution.setVariable(Workflow.ACK_WITH_ERRORS_ONLY, true);
		when(processorsService.getProcessorFileTasksForTransactionId(anyString())).thenReturn(getProcessorFileTaskList());

		createACKFile.execute(execution);

		assertNotNull(createACKFile.errorMap);

		ProcessorTransaction result = execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class);

		assertNotNull(result);
		assertFalse(result.getProcessorExecutionRecordList().isEmpty());
	}

	@Test
	public void testExecuteSingleAckSummaryFile() throws Exception {
		execution.setVariable(Workflow.GENERATE_SINGLE_ACK_SUMMARY_FILE_FLAG, true);
		when(processorsService.getProcessorFileTasksForTransactionId(anyString())).thenReturn(getProcessorFileTaskList());

		createACKFile.execute(execution);

		assertNotNull(createACKFile.errorMap);
		ProcessorTransaction result = execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class);

		assertNotNull(result);
		assertFalse(result.getProcessorExecutionRecordList().isEmpty());
	}


	private List<ProcessorFileTask> getProcessorFileTaskList() throws Exception {
		List<ProcessorFileTask> list = new ArrayList<>();

		ProcessorFileTask pft;
		ProcessorFileTask pft1;
		ProcessorFileTask pft2;

		String pftString = "{ \"id\" : \"64584c9e56e0051ea434311b\", \"targetId\" : \"64584ca657c4c6349c6dce05\", \"targetType\" : \"documents\", \"fileSize\" : 61342, \"fileType\" : \"pdf\", \"metadata\" : { \"emailAlertReq\" : \"Y\", \"fileDescription\" : \"Appeals and Disputes\", \"docSentTo\" : \"\", \"patientAccountNumber\" : \"\", \"subCategory\" : \"X2\", \"fileName\" : \"162430228.pdf\", \"originalPrintTrail\" : \"3256\", \"postCardInd\" : true, \"privilege\" : \"Claim Status\", \"expiryDate\" : \"2025-05-07T01:13:10.264Z\", \"historyId\" : \"162430228\", \"caseId\" : \"U1251158020\", \"tin\" : \"760564528\", \"CONFIGKEY\" : \"FDSPP3256\", \"sendToDocVault\" : false, \"tenant\" : \"Link\", \"memberId\" : \"119854969\", \"MailToAddress1\" : \"Appeals Department\", \"filePath\" : \"Community Plan Appeals and Disputes / Acknowledgement, Notification, and Response\", \"sendEmailNotifications\" : false, \"providerEmailId\" : \"\", \"sendPENAPIRequest\" : false, \"createdDate\" : \"2023-05-07T19:30:05.000Z\", \"physicianName\" : \"Sheila Devaugh\", \"createApplication\" : \"ETS\", \"PassThruData\" : \"U1251158020|162430228|20230507201002_ETS_PDF_FDS.zip\", \"MailToAddress6\" : \"772104356\", \"mpin\" : \"002688446\", \"MailToAddress4\" : \"Houston\", \"category\" : \"Appeals and Disputes\", \"MailToAddress5\" : \"TX\", \"MailToAddress2\" : \"ADVANCE CARDOVASCULAR SPEC\", \"fileType\" : \"Letter\", \"MailToAddress3\" : \"Po Box 4356 Dept 2251\", \"sendToShutterfly\" : false }, \"processorTransactionId\" : \"64584c9d56e0051ea434311a\", \"fdsDocumentId\" : \"2e006251-d51b-465c-85c0-f98c6db20250\", \"postFDSResponse\" : true, \"fsId\" : \"a8088c78-8d29-4b3c-9fe1-3c436cc16048\", \"processorId\" : \"620d7b17f3a898ae2b3dc20c\", \"fileName\" : \"162430228.pdf\", \"location\" : \"/ingest/cd0a030ccb2d47e786b521e2d7830f9c/10703/20230507201002_ETS_PDF_FDS\", \"processedByHost\" : \"fds-paperless-activiti-7f6b6bd4f4-gzgrm\", \"processorExecutionRecordList\" : [ { \"description\" : \"Initializing File Task variables\", \"clientId\" : 685, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"outcome\" : \"Files needed are present.\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-gzgrm\", \"serverIp\" : \"192.168.51.49\", \"spaceId\" : 10703 }, { \"description\" : \"Parsing metadata file\", \"clientId\" : 685, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"outcome\" : \"Parse metadata file successfull.\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-gzgrm\", \"serverIp\" : \"192.168.51.49\", \"spaceId\" : 10703 }, { \"description\" : \"Validating metadata file\", \"clientId\" : 685, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"outcome\" : \"Metadata Validated sucessfully.\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-gzgrm\", \"serverIp\" : \"192.168.51.49\", \"spaceId\" : 10703 }, { \"description\" : \"Posting document to prun mongo\", \"clientId\" : 685, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"prunDocumentId\" : \"64584ca657c4c6349c6dce05\", \"outcome\" : \"Document posted to prun mongo successfully\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-gzgrm\", \"serverIp\" : \"192.168.51.49\", \"spaceId\" : 10703 }, { \"description\" : \"Updating processorFileTask from callback\", \"clientId\" : 685, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"outcome\" : \"FDS response 200, document updated successfully\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-gzgrm\", \"serverIp\" : \"192.168.51.49\", \"spaceId\" : 10703 } ], \"configSpaceId\" : 10703, \"processorRecordType\" : \"processorFileTask\", \"summary\" : { \"xmlObject\" : { \"ApplicationID\" : \"ETS\", \"Datagroup\" : \"mult\", \"FileFormat\" : \"PDF\", \"Indices\" : { \"IndexField\" : [ { \"idxName\" : \"AltId\", \"idxValue\" : \"119854969\" }, { \"idxName\" : \"caseId\", \"idxValue\" : \"U1251158020\" }, { \"idxName\" : \"CONFIGKEY\", \"idxValue\" : \"FDSPP3256\" }, { \"idxName\" : \"createdDate\", \"idxValue\" : \"5/7/2023 7:30:05 PM\" }, { \"idxName\" : \"historyId\", \"idxValue\" : \"162430228\" }, { \"idxName\" : \"isPrintSuppressed\", \"idxValue\" : \"Y\" }, { \"idxName\" : \"MailToAddress1\", \"idxValue\" : \"Appeals Department\" }, { \"idxName\" : \"MailToAddress2\", \"idxValue\" : \"ADVANCE CARDOVASCULAR SPEC\" }, { \"idxName\" : \"MailToAddress3\", \"idxValue\" : \"Po Box 4356 Dept 2251\" }, { \"idxName\" : \"MailToAddress4\", \"idxValue\" : \"Houston\" }, { \"idxName\" : \"MailToAddress5\", \"idxValue\" : \"TX\" }, { \"idxName\" : \"MailToAddress6\", \"idxValue\" : \"772104356\" }, { \"idxName\" : \"mpin\", \"idxValue\" : \"002688446\" }, { \"idxName\" : \"originalPrintTrail\", \"idxValue\" : \"3256\" }, { \"idxName\" : \"PassThroughData\", \"idxValue\" : \"U1251158020|162430228|20230507201002_ETS_PDF_FDS.zip\" }, { \"idxName\" : \"PatientAccountNumber\", \"idxValue\" : \"\" }, { \"idxName\" : \"physicianName\", \"idxValue\" : \"Sheila Devaugh\" }, { \"idxName\" : \"privilege\", \"idxValue\" : \"Claim Status\" }, { \"idxName\" : \"subCategory\", \"idxValue\" : \"X2\" }, { \"idxName\" : \"tin\", \"idxValue\" : \"760564528\" } ] } }, \"runTime\" : 43, \"startTime\" :\"2023-05-08T01:13:10.251+0000\", \"endTime\" : \"2023-05-08T01:13:10.251+0000\" }, \"appIdentifier\" : \"cd0a030ccb2d47e786b521e2d7830f9c\", \"clientId\" : 685, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"status\" : \"COMPLETE\", \"transactionId\" : \"6806c16e-ab06-4b8a-8913-b3d132ad50ef\", \"version\" : \"1\"}";
		String pftString1 = "{ \"id\" : \"64584c9e56e0051ea434311b\", \"targetId\" : \"645880bc1dc333025f058cc4\", \"targetType\" : \"documents\", \"fileSize\" : 157558, \"fileType\" : \"pdf\", \"metadata\" : { \"emailAlertReq\" : \"N\", \"docSentTo\" : \"\", \"subCategory\" : \"A2\", \"fileName\" : \"1706910603_1706911399.pdf\", \"originalPrintTrail\" : \"3612\", \"ELGSLETTERGENID\" : \"1706911399\", \"postCardInd\" : true, \"policyNumber\" : \"0708697\", \"memberName\" : \"COOK, ANNA N\", \"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\", \"expiryDate\" : \"2025-05-07T04:55:23.999Z\", \"tin\" : \"\", \"CONFIGKEY\" : \"FDSELR3612\", \"DMSecurityClass\" : \"CCS_COMPLIANCE\", \"sendToDocVault\" : false, \"notificationNumber\" : \"A197149580\", \"providerName\" : \"Roohi Jeelani \", \"tenant\" : \"Link\", \"memberId\" : \"933721874\", \"DefaultUsed\" : \"Y\", \"MailToAddress1\" : \"Roohi Jeelani \", \"HHKey\" : \"\", \"DUPLEXSIMPLEX\" : \"D\", \"filePath\" : \"Commercial Prior Auth/Denied\", \"sendEmailNotifications\" : false, \"ELGSREQUESTID\" : \"1706910603\", \"providerEmailId\" : \"\", \"sendPENAPIRequest\" : false, \"createdDate\" : \"2023-05-07T21:11:29.000Z\", \"LetterHistoryID\" : \"1706911399\", \"createApplication\" : \"CCSManual\", \"PassThruData\" : \"1706910603_1706911399\", \"MailToAddress6\" : \"60169\", \"mpin\" : \"\", \"dateOfService\" : \"2023-05-04T00:00:00.000Z\", \"MailToAddress4\" : \"HOFFMAN ESTATES\", \"category\" : \"Prior Auth Notification\", \"MailToAddress5\" : \"IL\", \"MailToAddress2\" : \"1585 BARRINGTON RD STE 401\", \"fileType\" : \"Letter\", \"MailToAddress3\" : \"\", \"sendToShutterfly\" : false }, \"processorTransactionId\" : \"645880a8646d9947c08528c1\", \"fdsDocumentId\" : \"a3e1bcd1-9cac-4e9b-b248-01fb80ea3eb7\", \"postFDSResponse\" : true, \"fsId\" : \"75fd4380-7a3f-4091-a0b3-0f66b9543af0\", \"processorId\" : \"61e670e5f3a898ae2bf08817\", \"fileName\" : \"1706910603_1706911399.pdf\", \"location\" : \"/ingest/20314ba966f14ef4b78db90d48f52d61/8938/DMS_CCS_20230507235302_PRD\", \"processedByHost\" : \"fds-paperless-activiti-7f6b6bd4f4-l4f8f\", \"processorExecutionRecordList\" : [ { \"description\" : \"Initializing File Task variables\", \"clientId\" : 697, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"outcome\" : \"Files needed are present.\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-l4f8f\", \"serverIp\" : \"192.168.83.114\", \"spaceId\" : 8938 }, { \"description\" : \"Parsing metadata file\", \"clientId\" : 697, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"outcome\" : \"Parse metadata file successfull.\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-l4f8f\", \"serverIp\" : \"192.168.83.114\", \"spaceId\" : 8938 }, { \"description\" : \"Validating metadata file\", \"clientId\" : 697, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"error\" : \"Required metadata fields are missing or invalid.\", \"outcome\" : \"Metadata validation failed.\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-l4f8f\", \"serverIp\" : \"192.168.83.114\", \"spaceId\" : 8938 }, { \"description\" : \"Posting document to prun mongo\", \"clientId\" : 697, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"prunDocumentId\" : \"645880bc1dc333025f058cc4\", \"outcome\" : \"Document posted to prun mongo successfully\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-l4f8f\", \"serverIp\" : \"192.168.83.114\", \"spaceId\" : 8938 }, { \"description\" : \"Updating processorFileTask from callback\", \"clientId\" : 697, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"outcome\" : \"FDS response 200, document updated successfully\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-l4f8f\", \"serverIp\" : \"192.168.83.114\", \"spaceId\" : 8938 } ], \"configSpaceId\" : 8938, \"processorRecordType\" : \"processorFileTask\", \"summary\" : { \"xmlObject\" : { \"ApplicationID\" : \"ELGS\", \"DocumentClass\" : \"CCS_COMPLIANCE\", \"DocumentType\" : \"LTRS\", \"FileFormat\" : \"PDF\", \"Indices\" : { \"IndexField\" : [ { \"idxName\" : \"ServiceReferenceNum\", \"idxValue\" : \"A197149580\" }, { \"idxName\" : \"HISTORYID\", \"idxValue\" : \"1706911399\" }, { \"idxName\" : \"SubFullNme\", \"idxValue\" : \"ANNA COOK\" }, { \"idxName\" : \"ID\", \"idxValue\" : \"933721874\" }, { \"idxName\" : \"Process\", \"idxValue\" : \"5/7/2023 9:11:29 PM\" }, { \"idxName\" : \"ELGSREQUESTID\", \"idxValue\" : \"1706910603\" }, { \"idxName\" : \"ELGSLETTERGENID\", \"idxValue\" : \"1706911399\" }, { \"idxName\" : \"PTX_ID\", \"idxValue\" : \"811392426\" }, { \"idxName\" : \"Policy\", \"idxValue\" : \"0708697\" }, { \"idxName\" : \"Subjct\", \"idxValue\" : \"Mixed Decision\" }, { \"idxName\" : \"EMRecipientType\", \"idxValue\" : \"ManualCC\" }, { \"idxName\" : \"PTName\", \"idxValue\" : \"ANNA COOK\" }, { \"idxName\" : \"LType\", \"idxValue\" : \"\" }, { \"idxName\" : \"ProvTIN\", \"idxValue\" : \"\" }, { \"idxName\" : \"ProvMPIN\", \"idxValue\" : \"\" }, { \"idxName\" : \"ProvName\", \"idxValue\" : \"Roohi Jeelani \" }, { \"idxName\" : \"PatFullNme\", \"idxValue\" : \"COOK, ANNA N\" }, { \"idxName\" : \"MembAltID\", \"idxValue\" : \"933721874\" }, { \"idxName\" : \"ExpectedServiceStartDte\", \"idxValue\" : \"05/04/2023\" }, { \"idxName\" : \"LetterCategory\", \"idxValue\" : \"A2\" }, { \"idxName\" : \"IsPrintSuppressed\", \"idxValue\" : \"N\" }, { \"idxName\" : \"DefaultUsed\", \"idxValue\" : \"Y\" }, { \"idxName\" : \"PassThruData\", \"idxValue\" : \"1706910603_1706911399\" }, { \"idxName\" : \"HHKey\", \"idxValue\" : \"\" }, { \"idxName\" : \"DUPLEXSIMPLEX\", \"idxValue\" : \"D\" }, { \"idxName\" : \"CONFIGKEY\", \"idxValue\" : \"FDSELR3612\" }, { \"idxName\" : \"ReturnAddress1\", \"idxValue\" : \"01\" }, { \"idxName\" : \"ReturnAddress2\", \"idxValue\" : \"5701 Katella Avenue\" }, { \"idxName\" : \"ReturnAddress3\", \"idxValue\" : \"CA120-0300\" }, { \"idxName\" : \"ReturnAddress4\", \"idxValue\" : \"Cypress\" }, { \"idxName\" : \"ReturnAddress5\", \"idxValue\" : \"CA\" }, { \"idxName\" : \"ReturnAddress6\", \"idxValue\" : \"90630\" }, { \"idxName\" : \"MailToAddress1\", \"idxValue\" : \"Roohi Jeelani \" }, { \"idxName\" : \"MailToAddress2\", \"idxValue\" : \"1585 BARRINGTON RD STE 401\" }, { \"idxName\" : \"MailToAddress3\", \"idxValue\" : \"\" }, { \"idxName\" : \"MailToAddress4\", \"idxValue\" : \"HOFFMAN ESTATES\" }, { \"idxName\" : \"MailToAddress5\", \"idxValue\" : \"IL\" }, { \"idxName\" : \"MailToAddress6\", \"idxValue\" : \"60169\" }, { \"idxName\" : \"DMSecurityClass\", \"idxValue\" : \"CCS_COMPLIANCE\" }, { \"idxName\" : \"OriginPrintTrail\", \"idxValue\" : \"3612\" } ] } }, \"errorList\" : [ { \"errorMessage\" : \"Missing or invalid data: ProvTIN\", \"errorCode\" : 12 } ], \"runTime\" : 50.0, \"startTime\" : \"2023-05-08T01:13:10.251+0000\", \"endTime\" : \"2023-05-08T02:13:10.251+0000\" }, \"appIdentifier\" : \"20314ba966f14ef4b78db90d48f52d61\", \"clientId\" : 697, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"status\" : \"COMPLETE_WITH_ERRORS\", \"transactionId\" : \"ded709ad-35d3-40d2-8520-43df1967d639\", \"version\" : \"1\" }";
		String pftString2 = "{ \"id\" : \"64584c9e56e0051ea434311b\", \"targetId\" : \"6458fd87707d887d0d5fd269\", \"targetType\" : \"documents\", \"fileSize\" : 13724, \"fileType\" : \"pdf\", \"metadata\" : { \"emailAlertReq\" : \"Y\", \"fileDescription\" : \"Claim status update\", \"docSentTo\" : \"\", \"patientAccountNumber\" : \"1080207643\", \"subCategory\" : \"C2\", \"fileName\" : \"1706972210_1706972210.pdf\", \"originalPrintTrail\" : \"3610\", \"ELGSLETTERGENID\" : \"17069722101706972210\", \"postCardInd\" : true, \"policyNumber\" : \"4W7171\", \"memberName\" : \"ERJON CANI\", \"privilege\" : \"Claim Status\", \"expiryDate\" : \"2025-05-07T13:47:51.851Z\", \"patientDOB\" : \"06/23/19\", \"MemberAltID\" : \"952329415\", \"providerId\" : \"ELGS\", \"tin\" : \"731703319\", \"CONFIGKEY\" : \"CETPUH_Duplex_Std-NoBox\", \"sendToDocVault\" : false, \"claimNumber\" : \"DW03491253\", \"providerName\" : \"BEHAVIORAL CONSULTING OF TAMP\", \"tenant\" : \"Link\", \"memberId\" : \"781033778\", \"DefaultUsed\" : \"N\", \"MailToAddress1\" : \"\", \"stopProcessing\" : true, \"filePath\" : \"Commercial Claim Letters/Acknowledgements\", \"sendEmailNotifications\" : false, \"providerEmailId\" : \"\", \"PatientName\" : \"ARIA CANI\", \"sendPENAPIRequest\" : false, \"tinSuff\" : \"00059\", \"createdDate\" : \"2023-05-08T00:00:00.000Z\", \"LetterHistoryID\" : \"1706972210\", \"createApplication\" : \"ELGS\", \"PassThruData\" : \"1706972210_1706972210\", \"MailToAddress6\" : \"33618-2047\", \"dateOfService\" : \"2023-04-22T00:00:00.000Z\", \"mpin\" : \"007021908\", \"MailToAddress4\" : \"TAMPA\", \"category\" : \"Claim\", \"MailToAddress5\" : \"FL\", \"MailToAddress2\" : \"14497 N DALE MABRY HWY\", \"fileType\" : \"Letter\", \"MailToAddress3\" : \"\", \"sendToShutterfly\" : false }, \"processorTransactionId\" : \"6458fce156e0051ea4345569\", \"fdsDocumentId\" : \"f850aaad-9352-4019-a50f-f92e2c751c37\", \"postFDSResponse\" : true, \"fsId\" : \"11a0c568-a17c-4224-94a5-58f1fc322df6\", \"processorId\" : \"621e474af3a898ae2b6c7ac0\", \"fileName\" : \"1706972210_1706972210.pdf\", \"location\" : \"/ingest/d653203a04d34241a27b25107670442c/8889/DMS_TOPS_UH_20230508083425_PRD\", \"processedByHost\" : \"fds-paperless-activiti-7f6b6bd4f4-htqpv\", \"processorExecutionRecordList\" : [ { \"description\" : \"Initializing File Task variables\", \"clientId\" : 685, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"outcome\" : \"Files needed are present.\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-htqpv\", \"serverIp\" : \"192.168.67.98\", \"spaceId\" : 8889 }, { \"description\" : \"Parsing metadata file\", \"clientId\" : 685, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"outcome\" : \"Parse metadata file successfull.\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-htqpv\", \"serverIp\" : \"192.168.67.98\", \"spaceId\" : 8889 }, { \"description\" : \"Validating metadata file\", \"clientId\" : 685, \"dateCreated\" :\"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"error\" : \"Required metadata fields are missing or invalid.\", \"outcome\" : \"Metadata validation failed.\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-htqpv\", \"serverIp\" : \"192.168.67.98\", \"spaceId\" : 8889 }, { \"description\" : \"Posting document to prun mongo\", \"clientId\" : 685, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"prunDocumentId\" : \"6458fd87707d887d0d5fd269\", \"outcome\" : \"Document posted to prun mongo successfully\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-htqpv\", \"serverIp\" : \"192.168.67.98\", \"spaceId\" : 8889 }, { \"description\" : \"Updating processorFileTask from callback\", \"clientId\" : 685, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"messageList\" : [ { \"outcome\" : \"FDS response 200, document updated successfully\" } ], \"serverName\" : \"fds-paperless-activiti-7f6b6bd4f4-htqpv\", \"serverIp\" : \"192.168.67.98\", \"spaceId\" : 8889 } ], \"configSpaceId\" : 8889, \"processorRecordType\" : \"processorFileTask\", \"summary\" : { \"xmlObject\" : { \"ApplicationID\" : \"ELGS\", \"Datagroup\" : \"mult\", \"FileFormat\" : \"PDF\", \"Indices\" : { \"IndexField\" : [ { \"idxName\" : \"ICNNUMBER\", \"idxValue\" : \"DW03491253\" }, { \"idxName\" : \"EMPLOYEENAME\", \"idxValue\" : \"ERJON CANI\" }, { \"idxName\" : \"EMPLOYEEID\", \"idxValue\" : \"781033778\" }, { \"idxName\" : \"PROCESSDATE\", \"idxValue\" : \"05/08/2023\" }, { \"idxName\" : \"ELGSLETTERGENID\", \"idxValue\" : \"17069722101706972210\" }, { \"idxName\" : \"PROVIDERTAXID\", \"idxValue\" : \"73170331900059\" }, { \"idxName\" : \"POLICYNBR\", \"idxValue\" : \"4W7171\" }, { \"idxName\" : \"SUBJECT\", \"idxValue\" : \"Claim status update\" }, { \"idxName\" : \"MAILCODE\", \"idxValue\" : \"PA\" }, { \"idxName\" : \"PHYSICIANNAME\", \"idxValue\" : \"BEHAVIORAL CONSULTING OF TAMP\" }, { \"idxName\" : \"PATIENTNAME\", \"idxValue\" : \"ARIA CANI\" }, { \"idxName\" : \"LETTERTYPE\", \"idxValue\" : \"C2\" }, { \"idxName\" : \"DATEOFSERVICE\", \"idxValue\" : \"04/22/2023\" }, { \"idxName\" : \"ConfigKey\", \"idxValue\" : \"CETPUH_Duplex_Std-NoBox\" }, { \"idxName\" : \"DUPLEXSIMPLEX\", \"idxValue\" : \"D\" }, { \"idxName\" : \"PassThruData\", \"idxValue\" : \"1706972210_1706972210\" }, { \"idxName\" : \"ReturnAddress1\", \"idxValue\" : \" \" }, { \"idxName\" : \"ReturnAddress2\", \"idxValue\" : \" \" }, { \"idxName\" : \"ReturnAddress3\", \"idxValue\" : \" \" }, { \"idxName\" : \"ReturnAddress4\", \"idxValue\" : \" \" }, { \"idxName\" : \"ReturnAddress5\", \"idxValue\" : \" \" }, { \"idxName\" : \"ReturnAddress6\", \"idxValue\" : \" \" }, { \"idxName\" : \"MailToAddress1\", \"idxValue\" : \"\" }, { \"idxName\" : \"MailToAddress2\", \"idxValue\" : \"14497 N DALE MABRY HWY\" }, { \"idxName\" : \"MailToAddress3\", \"idxValue\" : \"\" }, { \"idxName\" : \"MailToAddress4\", \"idxValue\" : \"TAMPA\" }, { \"idxName\" : \"MailToAddress5\", \"idxValue\" : \"FL\" }, { \"idxName\" : \"MailToAddress6\", \"idxValue\" : \"33618-2047\" }, { \"idxName\" : \"HHKey\", \"idxValue\" : \"273170331900051\" }, { \"idxName\" : \"isPrintSuppressed\", \"idxValue\" : \"Y\" }, { \"idxName\" : \"DefaultUsed\", \"idxValue\" : \"N\" }, { \"idxName\" : \"PATDOB\", \"idxValue\" : \"06/23/19\" }, { \"idxName\" : \"DepAddrInd\", \"idxValue\" : \"N\" }, { \"idxName\" : \"PrivacyInd\", \"idxValue\" : \"\" }, { \"idxName\" : \"PatFirstNme\", \"idxValue\" : \"ARIA\" }, { \"idxName\" : \"PatLastNme\", \"idxValue\" : \"CANI\" }, { \"idxName\" : \"EmplAltId\", \"idxValue\" : \"952329415\" }, { \"idxName\" : \"IndivProvMPIN\", \"idxValue\" : \"007021908\" }, { \"idxName\" : \"OriginPrintTrail\", \"idxValue\" : \"3610\" }, { \"idxName\" : \"HistoryID\", \"idxValue\" : \"1706972210\" }, { \"idxName\" : \"BarcodeText\", \"idxValue\" : \"\" }, { \"idxName\" : \"PatNbr\", \"idxValue\" : \"1080207643\" } ] } }, \"errorList\" : [ { \"errorMessage\" : \"Missing or invalid data: MailToAddress1(SEVERE)\", \"errorCode\" : 22 } ], \"runTime\" : 67.0, \"startTime\" : \"2023-05-08T01:13:10.251+0000\", \"endTime\" : \"2023-05-08T01:13:10.251+0000\" }, \"appIdentifier\" : \"d653203a04d34241a27b25107670442c\", \"clientId\" : 685, \"dateCreated\" : \"2023-05-08T01:13:10.251+0000\", \"dateModified\" : \"2023-05-08T01:13:10.251+0000\", \"status\" : \"SEVERE_ERROR\", \"transactionId\" : \"f9f2863e-33c6-4063-97ba-4ce641c5e160\", \"version\" : \"1\" }";
		pft = Parser.parseJson(pftString, ProcessorFileTask.class);
		pft1 = Parser.parseJson(pftString1, ProcessorFileTask.class);
		pft2 = Parser.parseJson(pftString2, ProcessorFileTask.class);
		list.add(pft);
		list.add(pft1);
		list.add(pft2);
		return list;
	}

	private ProcessorTransaction getProcessorTransaction() throws IOException {

		ProcessorTransaction processorTransaction1;

		String processTrans1 = "{" + "\"id\" : \"5900ec4b30043ae97bb5cbf7\","
				+ "\"processorId\" : \"58cab698c2e6f7ff1c8e8c44\"," + "\"configSpaceId\" : 3007,"
				+ "\"fileName\" : \"good.zip\","
				+ "\"location\" : \"/bconnected/ingest/testapp/3007/5900ec4a30043ae97bb5cbf6\","
				+ "\"processorRecordType\" : \"processorTransaction\"," + "\"fileToProcessList\" : ["
				+ "\"53760302_72269907.pdf\", " + "\"empty.pdf\"" + "]," + "\"summary\" : {"
				+ "\"processingMetrics\" : {" + "\"totalBytes\" : 12300" + "}," + "\"errorList\" : [ " + "{"
				+ "\"errorMessage\" : \"There was a mismatch between count and files to be processed. Count is at 1 and there are 2 files listed.\","
				+ "\"errorCode\" : 7" + "}" + "]," + "\"runTime\" : 3051,"
				+ "\"startTime\" : \"2017-04-26T18:51:55.184Z\"," + "\"endTime\" : \"2017-04-26T18:51:58.235Z\","
				+ "\"xmlObject\" : {" + "\"batchId\" : \"2017031_104410_ELGS_Customer_Care_A\","
				+ "\"dataGroup\" : \"NASC\"," + "\"count\" : 1," + "\"files\" : {" + "\"fileList\" : [ " + "{"
				+ "\"fileName\" : \"empty.pdf\"" + "}, " + "{" + "\"fileName\" : \"53760302_72269907.pdf\"" + "}" + "]"
				+ "}" + "}" + "}," + "\"status\" : \"IN_PROCESS\"," + "\"appIdentifier\" : \"testapp\"" + "}";

		processorTransaction1 = Parser.parseJson(processTrans1, ProcessorTransaction.class);
		processorTransaction1.setLocation(getZipFileLocation());
		return processorTransaction1;

	}

	private String getZipFileLocation() {
		return tempFolder.getRoot().getAbsolutePath() + File.separator;
	}
}