package com.optum.fds.paperless.java.delegate.oauth.impl;

import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.java.delegate.oauth.AuthorizationOauthProvider;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.java.delegate.oauth.bean.Token;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class OauthManagerUtilImplTest {
    private static final String APP_ID_TEST_1 = "testapp";
    private static final String APP_ID_TEST_2 = "testapp2";
    private static final String APP_ID_TEST_3 = "testapp3";
    private static final String APP_ID_TEST_4 = "testapp4";
    private static final String CLIENT_SECRET_TEST1 = "testapp";
    private static final String CLIENT_SECRET_TEST2 = "testapp2";
    private static final String CLIENT_SECRET_TEST3 = "testapp3";
    private static final String ACCESS_TOKEN_TEST1 = "abc123";
    private static final String REFRESH_TOKEN_TEST = "123ABC";
    private static final String GRANT_TYPE = "authorization";
    private static final Integer EXPIRES_IN = 1800;
    private static final String SCOPE = "testscope";
    private static final String TOKEN_TYPE = "bearer";
    private static final String URL = "http://foo.optum.com.none";

    @InjectMocks
    OauthManagerUtilImpl oauthManagerUtilImpl;


    @Mock
    AuthorizationOauthProvider authorizationProvider;

    @Before
    public void setup() throws FSDataException, IOException, InterruptedException{
        when(authorizationProvider.getOauth2Token(anyString(), any())).thenReturn(getValidToken());
    }

    @Test
    public void testGetTokenNoMySqlPortVariables() throws InterruptedException {
        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1, URL, GRANT_TYPE, SCOPE);
        oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
        assertEquals(ACCESS_TOKEN_TEST1, oauthTokenExtended.getAccessToken());
    }

    @Test
    public void testGetToken() throws InterruptedException {
        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1, URL, GRANT_TYPE, SCOPE);
        oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
        assertEquals(ACCESS_TOKEN_TEST1, oauthTokenExtended.getAccessToken());
        assertEquals(EXPIRES_IN, oauthTokenExtended.getExpiresIn());
        assertEquals(TOKEN_TYPE, oauthTokenExtended.getTokenType());
        var optToken = getValidToken();
        assertTrue(optToken.isPresent());
        var token = optToken.get();
        assertEquals(APP_ID_TEST_1, token.getClientId());
        assertEquals(CLIENT_SECRET_TEST1, token.getClientSecret());
        assertEquals(REFRESH_TOKEN_TEST, token.getRefreshToken());
        assertEquals(GRANT_TYPE, token.getGrantType());

    }

    @Test
    public void testGetTokenCustomURL() throws FSDataException, InterruptedException {
        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_4, CLIENT_SECRET_TEST1, URL, GRANT_TYPE, SCOPE);
        oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
        assertEquals(ACCESS_TOKEN_TEST1, oauthTokenExtended.getAccessToken());
        assertEquals(EXPIRES_IN, oauthTokenExtended.getExpiresIn());
        assertEquals(TOKEN_TYPE, oauthTokenExtended.getTokenType());
        assertEquals(SCOPE, oauthTokenExtended.getScope());

        var optToken = getValidToken();
        assertTrue(optToken.isPresent());
        var token = optToken.get();
        assertEquals(APP_ID_TEST_1, token.getClientId());
        assertEquals(CLIENT_SECRET_TEST1, token.getClientSecret());
        assertEquals(REFRESH_TOKEN_TEST, token.getRefreshToken());
        assertEquals(GRANT_TYPE, token.getGrantType());
    }

    @Test
    public void testGetTokenFromCache() throws InterruptedException {
        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1, URL, GRANT_TYPE, SCOPE);
        oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
        assertEquals(ACCESS_TOKEN_TEST1, oauthTokenExtended.getAccessToken());
    }

    @Test
    public void testGetTokenExpired() throws InterruptedException {
        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1, URL, GRANT_TYPE, SCOPE);
        oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
        Date obtainedDate =  oauthTokenExtended.getObtainedOn();
        obtainedDate.setTime(obtainedDate.getTime() - TimeUnit.SECONDS.toMillis(1600));
        oauthTokenExtended.setObtainedOn(obtainedDate);
        oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
        assertEquals(ACCESS_TOKEN_TEST1, oauthTokenExtended.getAccessToken());
    }

    @Test
    public void testGetTokenNullDateObtained() throws InterruptedException {
        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_1, CLIENT_SECRET_TEST1, URL, GRANT_TYPE, SCOPE);
        oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
        oauthTokenExtended.setObtainedOn(null);
        oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
        assertEquals(ACCESS_TOKEN_TEST1, oauthTokenExtended.getAccessToken());
    }

    @Test
    public void testGetTokenInvalid() throws InterruptedException {
        when(authorizationProvider.getOauth2Token(anyString(), any())).thenReturn(Optional.empty());
        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_2, CLIENT_SECRET_TEST2, URL, GRANT_TYPE, SCOPE);
        oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
        assertNull(oauthTokenExtended.getAccessToken());
    }


    @Test(expected=InterruptedException.class)
    public void testGetTokenThrowsIOException() throws InterruptedException {
        when(authorizationProvider.getOauth2Token(anyString(), any())).thenThrow(new InterruptedException());
        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID_TEST_3, CLIENT_SECRET_TEST3, URL, GRANT_TYPE, SCOPE);
        oauthTokenExtended = oauthManagerUtilImpl.refreshToken(oauthTokenExtended);
    }

    private Optional<Token> getValidToken(){
        Token token = new Token();
        token.setAccessToken(ACCESS_TOKEN_TEST1);
        token.setRefreshToken(REFRESH_TOKEN_TEST);
        token.setClientId(APP_ID_TEST_1);
        token.setClientSecret(CLIENT_SECRET_TEST1);
        token.setExpiresIn(EXPIRES_IN);
        token.setTokenType(TOKEN_TYPE);
        token.setGrantType(GRANT_TYPE);

        return Optional.of(token);
    }

}
