package com.optum.fds.paperless.java.delegate;

import com.google.common.collect.ImmutableList;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ManipulatePdfFileTest {

	private static final String TEST_DUMMY_SPACE_ID = "99999999";
	private static final String TEST_DUMMY_TRANSACTION_ID = "abcdefg";
	private static final String TEST_DUMMY_IDENTIFIER = "dummy_identifier";
	private static final String TEST_DUMMY_CLIENT_ID = "88888888";
	private static final String TEST_DUMMY_DOCUMENT_ID = "TEST-DOC-1";

	@InjectMocks
	ManipulatePdfFile manipulatePdfFile;

	DelegateExecution execution;
	
	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();

	@Before
	public void setup() throws IOException{
		execution = new DelegateExecutionImpl(new HashMap<>());
		execution.setVariable(Workflow.SKIP_MANIPULATE_PDF_FILE, false);
		execution.setVariable(Workflow.ADDRESS_BLOCK_X, 1.00);
		execution.setVariable(Workflow.ADDRESS_BLOCK_Y, 1.84);
		execution.setVariable(Workflow.RECEIVER_IDENTIFIER, "DPS$$$PKG");
		execution.setVariable(Workflow.IDENTIFIER_FONT_SIZE, 8.0);
		execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, List.of(getDocumentMetaData()));
		ClassLoader classLoader = getClass().getClassLoader();
        File pdfInput = new File(classLoader.getResource("temp/pdfInput.pdf").getFile());
        Files.copy(pdfInput.toPath(), Paths.get(tempFolder.getRoot().getAbsolutePath()).resolve(pdfInput.toPath().getFileName()));
        File pdfInput2 = new File(classLoader.getResource("temp/pdfInput2.pdf").getFile());
        Files.copy(pdfInput2.toPath(), Paths.get(tempFolder.getRoot().getAbsolutePath()).resolve(pdfInput2.toPath().getFileName()));
    }

	@Test
	public void testExecute() throws Exception {
		manipulatePdfFile.execute(execution);
		assertNotNull(manipulatePdfFile.errorMap);
		assertEquals(0, manipulatePdfFile.errorMap.get(Workflow.NEW_ERRORS));
	}


	@Test
	public void testExecuteWithSkipManipulatePdf() throws Exception {
		List<DocumentMetaData> listOfDocumentsMetaData = ImmutableList.of(getDocumentMetaData());
		listOfDocumentsMetaData.forEach(x -> x.getMetadata().putIfAbsent(Workflow.SKIP_MANIPULATE_PDF_FILE, true));
		execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, listOfDocumentsMetaData);
		manipulatePdfFile.execute(execution);
		assertNotNull(manipulatePdfFile.errorMap);
		assertEquals(0, manipulatePdfFile.errorMap.get(Workflow.NEW_ERRORS));
		assertTrue(listOfDocumentsMetaData.stream().allMatch(x -> x.getMetadata().getString("tagLine") == null));
	}

	@Test
	public void testExecuteException() throws Exception {
		List<DocumentMetaData> listOfDocumentsMetaData = new ArrayList<DocumentMetaData>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		documentMetaData.getMetadata().put("absolutePath", tempFolder.getRoot().getAbsolutePath());
		listOfDocumentsMetaData.add(documentMetaData);
		execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, listOfDocumentsMetaData);
		manipulatePdfFile.execute(execution);
		assertNotNull(manipulatePdfFile.errorMap);
		assertEquals(2, manipulatePdfFile.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testExecuteInvalidPath() throws Exception {
		List<DocumentMetaData> listOfDocumentsMetaData = new ArrayList<DocumentMetaData>();
		DocumentMetaData documentMetaData = getDocumentMetaData();
		documentMetaData.getMetadata().put("absolutePath", tempFolder.getRoot().getAbsolutePath() + File.separator + "junk" + File.separator);
		listOfDocumentsMetaData.add(documentMetaData);
		execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, listOfDocumentsMetaData);
		manipulatePdfFile.execute(execution);
		assertNotNull(manipulatePdfFile.errorMap);
		assertEquals(2, manipulatePdfFile.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testExecuteWithInvalidDocumentMetaDataList() throws Exception {
		execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, null);
		manipulatePdfFile.execute(execution);
		assertNotNull(manipulatePdfFile.errorMap);
		assertEquals(1, manipulatePdfFile.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	@Test
	@UserStory(references = "US26020")
	@RallyTestCase(references = "TC30069")
	public void testExecuteWithskipManipulatePdfFileTrue() throws Exception {
		execution.setVariable(Workflow.SKIP_MANIPULATE_PDF_FILE, true);
		manipulatePdfFile.execute(execution);
		assertNotNull(manipulatePdfFile.errorMap);
		assertEquals(0, manipulatePdfFile.errorMap.get(Workflow.NEW_ERRORS));
	}
	
//	@Test
//	@UserStory(references = "US27402")
//	@RallyTestCase(references = "TC30689")
//	public void testExecutewriteEncryptedPDFTrue() throws Exception {
//		ClassLoader classLoader = getClass().getClassLoader();
//		File pdfInput1 = new File(classLoader.getResource("temp/encryptPDF.pdf").getFile());
//        Files.copy(pdfInput1.toPath(), Paths.get(tempFolder.getRoot().getAbsolutePath()).resolve(pdfInput1.toPath().getFileName()));
//        String rootDir =  Paths.get(tempFolder.getRoot().getAbsolutePath()).toString();
//        PdfReader pdfReader = new PdfReader(rootDir+"/encryptPDF.pdf");
//        boolean isEncrypted = pdfReader.isEncrypted();// true
//        pdfReader.close();
//		assertTrue(isEncrypted);
//    	DocumentMetaData documentMetaData = getEncrptedDocumentMetaData();
//		List<DocumentMetaData> listOfDocumentsMetaData = new ArrayList<>();
//		listOfDocumentsMetaData.add(documentMetaData);
//		execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, listOfDocumentsMetaData);
//		execution.setVariable(Workflow.WRITE_ENCRYPTED_PDF, true);
//		manipulatePdfFile.execute(execution);
//		assertEquals(true, execution.getVariable(Workflow.WRITE_ENCRYPTED_PDF));
//		PdfReader pdfReader2 = new PdfReader(rootDir+"/encryptPDF.pdf");
//		boolean isEncryptedNow = pdfReader2.isEncrypted();// false
//		pdfReader2.close();
//		assertFalse(isEncryptedNow);
//		assertEquals(0, manipulatePdfFile.errorMap.get(Workflow.NEW_ERRORS));
//	}
	
//	@Test
//	@UserStory(references = "US27402")
//	@RallyTestCase(references = "TC30690")
//	public void testExecutewriteEncryptedPDFFalse() throws Exception {
//        String rootDir =  Paths.get(tempFolder.getRoot().getAbsolutePath()).toString();
//        PdfReader pdfReader = new PdfReader(rootDir+"/pdfInput.pdf");
//        boolean isEncrypted = pdfReader.isEncrypted();// false
//        pdfReader.close();
//		assertFalse(isEncrypted);
//    	DocumentMetaData documentMetaData = getDocumentMetaData();
//		List<DocumentMetaData> listOfDocumentsMetaData = new ArrayList<>();
//		listOfDocumentsMetaData.add(documentMetaData);
//		execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, listOfDocumentsMetaData);
//		execution.setVariable(Workflow.WRITE_ENCRYPTED_PDF, false);
//		manipulatePdfFile.execute(execution);
//		assertEquals(false, execution.getVariable(Workflow.WRITE_ENCRYPTED_PDF));
//		assertEquals(0, manipulatePdfFile.errorMap.get(Workflow.NEW_ERRORS));
//	}


	private DocumentMetaData getDocumentMetaData() {
		DocumentMetaData dmd = new DocumentMetaData();
		dmd.setId(TEST_DUMMY_DOCUMENT_ID);
		dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID) );
		dmd.setStatus("AVAILABLE");
		dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
		dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
		dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
		String junitDir = tempFolder.getRoot().getAbsolutePath() + File.separator;
		junitDir = junitDir.replace("\\", "\\\\");
		Document metadataObj = Document.parse("{" +
				"\"fileDescription\" : \"Claim information request\"," + 
				"\"employeeName\" : \"PAMELA FERNANDO\"," +
				"\"subCategory\" : \"C8\"," +
				"\"policyNumber\" : \"744530\"," +
				"\"memberName\" : \"PAMELA FERNANDO\"," +
				"\"expiryDate\" : \"2017-12-03T04:06:31Z\"," +
				"\"createdDate\" : \"2017-01-24T00:05:00.000Z\"," +
				"\"physicianName\" : \"MOHAMED A ZINEDDIN MD\"," +
				"\"tin\" : \"03047636000002\"," +
				"\"dateOfService\" : \"0017-01-21T00:04:00.000Z\"," +
				"\"category\" : \"Claim\"," +
				"\"claimNumber\" : \"1043126449\"," +
				"\"memberId\" : \"887543999\"," +
				"\"providerEmailId\" : \"andre@optum.com\"," +
				"\"absolutePath\" : \"" + junitDir + "\"," +
				"\"processorFileTaskId\" : \"59362a436ea628b7dcd52396\""+
				"}");
		
		List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
		DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
		documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
		documentAttachmentMetaData.setIndex(1);
		documentAttachmentMetaData.setName("pdfInput.pdf"); 
		listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
		DocumentAttachmentMetaData documentAttachmentMetaData2 = new DocumentAttachmentMetaData();
		documentAttachmentMetaData2.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
		documentAttachmentMetaData2.setIndex(1);
		documentAttachmentMetaData2.setName("pdfInput2.pdf"); 
		listDocumentAttachmentMetaData.add(documentAttachmentMetaData2);

		dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
		dmd.setMetadata(metadataObj);

		return dmd;
	}
	
	private DocumentMetaData getEncrptedDocumentMetaData() {
		DocumentMetaData dmd = new DocumentMetaData();
		dmd.setId(TEST_DUMMY_DOCUMENT_ID);
		dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID) );
		dmd.setStatus("AVAILABLE");
		dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
		dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
		dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
		String junitDir = tempFolder.getRoot().getAbsolutePath() + File.separator;
		junitDir = junitDir.replace("\\", "\\\\");
		Document metadataObj = Document.parse("{ " +
				"\"fileDescription\" : \"Claim information request     \", " + 
				"\"employeeName\" : \"PAMELA FERNANDO              \", " +
				"\"subCategory\" : \"C8\", " +
				"\"policyNumber\" : \"744530 \", " +
				"\"memberName\" : \"PAMELA FERNANDO               \", " +
				"\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
				"\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
				"\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
				"\"tin\" : \"03047636000002                \", " +
				"\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
				"\"category\" : \"Claim\", " +
				"\"claimNumber\" : \"1043126449\", " +
				"\"memberId\" : \"887543999\", " +
				"\"providerEmailId\" : \"andre@optum.com\", " +
				"\"absolutePath\" : \"" + junitDir + "\", " +
				"\"processorFileTaskId\" : \"59362a436ea628b7dcd52396\"  " +
				"}");
		List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
		DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
		documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
		documentAttachmentMetaData.setIndex(1);
		documentAttachmentMetaData.setName("encryptPDF.pdf"); 
		listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
		dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
		dmd.setMetadata(metadataObj);

		return dmd;
	}

}
