package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.when;

public class RequiredVarsForProviderEmailNotificationTest {

    private final String TEST = "test";

    DelegateExecution execution;

    Document execVars = new Document();

    @Before
    public void setUp() throws Exception {
        execution = Mockito.mock(DelegateExecution.class);
        execution.setVariable(Workflow.PEN_API_URL, TEST);
        execution.setVariable(Workflow.APP_ID, TEST);
        execution.setVariable(Workflow.APP_SECRET, TEST);
        execution.setVariable(Workflow.TEMPLATE_ID, TEST);
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, TEST);
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, TEST);
        execution.setVariable(Workflow.MAX_RETRIES, TEST);
        execution.setVariable(Workflow.RETRY_SLEEP_TIME, TEST);
        execution.setVariable(Workflow.FDS_DOCUMENTS_URL, TEST);
    }

    @UserStory(references = "")
    @RallyTestCase(references = "")
//    @Test
    public void testSuccess() {

        execVars.append(Workflow.PEN_API_URL, TEST).append(Workflow.APP_ID, TEST)
                .append(Workflow.APP_SECRET, TEST).append(Workflow.TEMPLATE_ID, TEST)
                .append(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, TEST).append(Workflow.DOCUMENT_UPDATE_FLAG_PATH, TEST)
                .append(Workflow.MAX_RETRIES, TEST).append(Workflow.RETRY_SLEEP_TIME, TEST)
                .append(Workflow.FDS_DOCUMENTS_URL, TEST);

        when(execution.getVariables()).thenReturn(execVars);
        when(execution.getVariable(Workflow.PEN_API_URL, String.class))
                .thenReturn(execVars.get(Workflow.PEN_API_URL, String.class));
        when(execution.getVariable(Workflow.APP_ID, String.class))
                .thenReturn(execVars.get(Workflow.APP_ID, String.class));
        when(execution.getVariable(Workflow.APP_SECRET, String.class))
                .thenReturn(execVars.get(Workflow.APP_SECRET, String.class));
        when(execution.getVariable(Workflow.TEMPLATE_ID, String.class))
                .thenReturn(execVars.get(Workflow.TEMPLATE_ID, String.class));
        when(execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, String.class))
                .thenReturn(execVars.get(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, String.class));
        when(execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, String.class))
                .thenReturn(execVars.get(Workflow.DOCUMENT_UPDATE_FLAG_PATH, String.class));
        when(execution.getVariable(Workflow.MAX_RETRIES, String.class))
                .thenReturn(execVars.get(Workflow.MAX_RETRIES, String.class));
        when(execution.getVariable(Workflow.RETRY_SLEEP_TIME, String.class))
                .thenReturn(execVars.get(Workflow.RETRY_SLEEP_TIME, String.class));
        when(execution.getVariable(Workflow.FDS_DOCUMENTS_URL, String.class))
                .thenReturn(execVars.get(Workflow.FDS_DOCUMENTS_URL, String.class));

        RequiredVarsForProviderEmailNotification verifyRequiredVars = new RequiredVarsForProviderEmailNotification();

        verifyRequiredVars.execute(execution);
        Assert.assertNotNull(verifyRequiredVars.errorMap);
        Assert.assertEquals(0, verifyRequiredVars.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "")
    @RallyTestCase(references = "")
    @Test
    public void testMissingPENAPIUrl() {
        execution.setVariable(Workflow.PEN_API_URL, "");

        execVars.append(Workflow.APP_ID, TEST)
                .append(Workflow.APP_SECRET, TEST).append(Workflow.TEMPLATE_ID, TEST)
                .append(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, TEST).append(Workflow.DOCUMENT_UPDATE_FLAG_PATH, TEST)
                .append(Workflow.MAX_RETRIES, TEST).append(Workflow.RETRY_SLEEP_TIME, TEST)
                .append(Workflow.FDS_DOCUMENTS_URL, TEST);

        when(execution.getVariables()).thenReturn(execVars);
        when(execution.getVariable(Workflow.APP_ID, String.class))
                .thenReturn(execVars.get(Workflow.APP_ID, String.class));
        when(execution.getVariable(Workflow.APP_SECRET, String.class))
                .thenReturn(execVars.get(Workflow.APP_SECRET, String.class));
        when(execution.getVariable(Workflow.TEMPLATE_ID, String.class))
                .thenReturn(execVars.get(Workflow.TEMPLATE_ID, String.class));
        when(execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, String.class))
                .thenReturn(execVars.get(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, String.class));
        when(execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, String.class))
                .thenReturn(execVars.get(Workflow.DOCUMENT_UPDATE_FLAG_PATH, String.class));
        when(execution.getVariable(Workflow.MAX_RETRIES, String.class))
                .thenReturn(execVars.get(Workflow.MAX_RETRIES, String.class));
        when(execution.getVariable(Workflow.RETRY_SLEEP_TIME, String.class))
                .thenReturn(execVars.get(Workflow.RETRY_SLEEP_TIME, String.class));
        when(execution.getVariable(Workflow.FDS_DOCUMENTS_URL, String.class))
                .thenReturn(execVars.get(Workflow.FDS_DOCUMENTS_URL, String.class));

        RequiredVarsForProviderEmailNotification verifyRequiredVars = new RequiredVarsForProviderEmailNotification();
        verifyRequiredVars.execute(execution);
        Assert.assertNotNull(verifyRequiredVars.errorMap);
        Assert.assertEquals(2, verifyRequiredVars.errorMap.get(Workflow.NEW_ERRORS));
    }

    @UserStory(references = "")
    @RallyTestCase(references = "")
    @Test
    public void testGetExecutionIdNull() {
        RequiredVarsForProviderEmailNotification verifyRequiredVars = new RequiredVarsForProviderEmailNotification();
        Assert.assertEquals("NULL",verifyRequiredVars.getExecutionId(null));
    }
}
