package com.optum.fds.paperless.java.delegate;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

public class GenerateDataFileForELGSTest {

    private GenerateDataFileForELGS generateDataFileForELGS;

    @Mock
    private DelegateExecution execution;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        generateDataFileForELGS = new GenerateDataFileForELGS();
    }

    @Test
    public void testDoExecute_Success() {
        // Mock input variables
        String templateName = "testTemplate";
        String tempWorkingPath = "/tmp";
        List<DocumentMetaData> documentMetaDataList = new ArrayList<>();
        DocumentMetaData doc1 = new DocumentMetaData();
        doc1.setId("doc1");
        documentMetaDataList.add(doc1);

        DocumentMetaData doc2 = new DocumentMetaData();
        doc2.setId("doc2");
        documentMetaDataList.add(doc2);

        when(execution.getVariable(Workflow.TEMPLATE_NAME, String.class)).thenReturn(templateName);
        when(execution.getVariable(Workflow.OUTPUT_FILE_DIR, String.class)).thenReturn(tempWorkingPath);
        when(execution.getVariable("updatedDocumentMetadataList", List.class)).thenReturn(documentMetaDataList);

        // Execute the method
        generateDataFileForELGS.doExecute(execution);

        // Verify the results
        verify(execution).setTransientVariable(eq("successDocumentList"), anyList());
        verify(execution).setTransientVariable(eq("successUpdateMap"), anyMap());
        verify(execution).setVariable(eq("elgsFileList"), anyList());
        verify(execution).setVariable(eq("documentMetaDataListStr"), anyList());
        verify(execution).setTransientVariable(eq(Workflow.SFTP_FILE_LIST), anyList());
    }
}