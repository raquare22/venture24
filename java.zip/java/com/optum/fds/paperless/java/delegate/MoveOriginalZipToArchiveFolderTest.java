package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.never;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import com.jcraft.jsch.JSchException;
import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import com.jcraft.jsch.SftpException;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.executions.ExecutionRecord;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class MoveOriginalZipToArchiveFolderTest {

	@Mock
	ProcessorService processorService;

	@Mock
	ErrorMetaDataService errorMetaDataService;

	@Mock
	ProcessorTransaction processorTransaction;

	@Mock
	ProcessorTaskUtil processorTaskUtil;

	@Mock
	ProcessorExecutionRecord processorExecutionRecord;

	@InjectMocks
	MoveOriginalZipToArchiveFolder moveOriginalZipToArchiveFolder;

	DelegateExecution execution;

	@SuppressWarnings({ "deprecation", "static-access" })
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);

		Document execVars = new Document().append(Workflow.PROCESSOR_TRANSACTION, processorTransaction);

		when(execution.getVariables()).thenReturn(execVars);

		when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class))
				.thenReturn(execVars.get(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class));

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testDoExecuteIsSuccess() {
		moveOriginalZipToArchiveFolder.execute(execution);
		Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
		assertTrue(errorMap == null);
	}

	@Test(expected = NullPointerException.class)
	public void testDoExecuteThrowsException() {

//		when(processorTaskUtil.createProcessorExecutionRecord("sdsdsdd"))
//		.thenReturn(processorExecutionRecord);

		when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class))
				.thenThrow(NullPointerException.class);
		moveOriginalZipToArchiveFolder.execute(execution);
	}

	@Test
	public void testGetDelegateExecutionId() {
		String actualId = "testId";
		when(execution.getId()).thenReturn(actualId);
		assertEquals(actualId, moveOriginalZipToArchiveFolder.getDelegateExecutionId(execution));
	}

	@Test
	public void testGetDelegateExecutionIdWithNull() {
		String actualId = null;
		when(execution.getId()).thenReturn(actualId);
		assertEquals(null, moveOriginalZipToArchiveFolder.getDelegateExecutionId(execution));
	}

	@Test(expected = Exception.class)
	public void testUpdateDocumentThrowsException() throws IOException {

//		processorTransaction.setLocation("/test");
		processorTransaction.setFileName("test.zip");
//		
		when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class))
		.thenThrow(new Exception());

//		DelegateExecution execution2 = new DelegateExecutionImpl();
		ReflectionTestUtils.invokeMethod(moveOriginalZipToArchiveFolder, "archiveZipFile",
				execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class), "test.zip",execution, Map.of("one", "test"));
	}

    @Test
    public void testArchiveZipFile_success_putsSuccessOutcomeMessage() throws Exception {
        MoveOriginalZipToArchiveFolder delegateSpy = spy(moveOriginalZipToArchiveFolder);

        String baseDir = System.getProperty("java.io.tmpdir") + File.separator + "zip-test-" + System.nanoTime();
        String fileName = "in.zip";
        File dir = new File(baseDir);
        dir.mkdirs();
        File zip = new File(dir, fileName);
        zip.createNewFile();

        when(processorTransaction.getLocation()).thenReturn(baseDir);
        when(processorTransaction.getFileName()).thenReturn(fileName);

        when(execution.getVariable(Workflow.SFTP_HOSTNAME, String.class)).thenReturn("host");
        when(execution.getVariable(Workflow.SFTP_USERNAME, String.class)).thenReturn("user");
        when(execution.getVariable(Workflow.SFTP_PW, String.class)).thenReturn("pw");
        when(execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, String.class)).thenReturn("/archive");
        when(execution.getVariable(Workflow.MAX_SFTP_TRIES, Integer.class)).thenReturn(3);
        when(execution.getVariable(Workflow.RETRY_TIME_SECS, Long.class)).thenReturn(10L);

        doNothing().when(delegateSpy).moveFileFromLocalToSFTPLocation(
                anyString(), anyString(), anyString(), anyString(), anyString(), anyInt(), anyLong());

        ProcessorExecutionRecord rec = mock(ProcessorExecutionRecord.class);

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            util.when(() -> ProcessorTaskUtil.createProcessorExecutionRecord("Moving source zip file to archive folder"))
                    .thenReturn(rec);

            delegateSpy.doExecute(execution);

            util.verify(() -> ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(
                    processorTransaction, rec,
                    Map.of(Workflow.OUTCOME_KEY, String.format("File %s archive correctly", fileName))
            ), times(1));
        }

        verify(delegateSpy, times(1)).moveFileFromLocalToSFTPLocation(
                eq("user"),
                eq("pw"),
                eq("host"),
                eq("/archive"),
                argThat(p -> p != null && p.endsWith(File.separator + fileName)),
                eq(3),
                eq(10L));
    }

    @Test
    public void testArchiveZipFile_fileMissing_doesNotMoveAndSetsMissingMessage() throws Exception {
        MoveOriginalZipToArchiveFolder delegateSpy = spy(moveOriginalZipToArchiveFolder);

        String baseDir = System.getProperty("java.io.tmpdir") + File.separator + "zip-test-" + System.nanoTime();
        String fileName = "missing.zip";
        File dir = new File(baseDir);
        dir.mkdirs();

        when(processorTransaction.getLocation()).thenReturn(baseDir);
        when(processorTransaction.getFileName()).thenReturn(fileName);

        when(execution.getVariable(Workflow.SFTP_HOSTNAME, String.class)).thenReturn("host");
        when(execution.getVariable(Workflow.SFTP_USERNAME, String.class)).thenReturn("user");
        when(execution.getVariable(Workflow.SFTP_PW, String.class)).thenReturn("pw");
        when(execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, String.class)).thenReturn("/archive");
        when(execution.getVariable(Workflow.MAX_SFTP_TRIES, Integer.class)).thenReturn(3);
        when(execution.getVariable(Workflow.RETRY_TIME_SECS, Long.class)).thenReturn(10L);

        ProcessorExecutionRecord rec = Mockito.mock(ProcessorExecutionRecord.class);

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            util.when(() -> ProcessorTaskUtil.createProcessorExecutionRecord("Moving source zip file to archive folder"))
                    .thenReturn(rec);

            delegateSpy.doExecute(execution);

            util.verify(() -> ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(
                    processorTransaction, rec, Map.of(Workflow.OUTCOME_KEY, String.format("File %s is not present in ingest folder", fileName))
            ), times(1));
        }

        verify(delegateSpy, never()).moveFileFromLocalToSFTPLocation(
                anyString(), anyString(), anyString(), anyString(), anyString(), any(int.class), any(long.class));
    }

    @Test
    public void testArchiveZipFile_sftpException_setsOutcomeAndWritesError() throws Exception {
        MoveOriginalZipToArchiveFolder delegateSpy = spy(moveOriginalZipToArchiveFolder);

        String baseDir = System.getProperty("java.io.tmpdir") + File.separator + "zip-test-" + System.nanoTime();
        String fileName = "in.zip";
        File dir = new File(baseDir);
        dir.mkdirs();
        File zip = new File(dir, fileName);
        zip.createNewFile();

        when(processorTransaction.getLocation()).thenReturn(baseDir);
        when(processorTransaction.getFileName()).thenReturn(fileName);

        when(execution.getVariable(Workflow.SFTP_HOSTNAME, String.class)).thenReturn("host");
        when(execution.getVariable(Workflow.SFTP_USERNAME, String.class)).thenReturn("user");
        when(execution.getVariable(Workflow.SFTP_PW, String.class)).thenReturn("pw");
        when(execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, String.class)).thenReturn("/archive");
        when(execution.getVariable(Workflow.MAX_SFTP_TRIES, Integer.class)).thenReturn(3);
        when(execution.getVariable(Workflow.RETRY_TIME_SECS, Long.class)).thenReturn(10L);

        doThrow(new SftpException(4, "sftp fail")).when(delegateSpy).moveFileFromLocalToSFTPLocation(
                anyString(), anyString(), anyString(), anyString(), anyString(), anyInt(), anyLong());

        ProcessorExecutionRecord rec = mock(ProcessorExecutionRecord.class);

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            util.when(() -> ProcessorTaskUtil.createProcessorExecutionRecord("Moving source zip file to archive folder"))
                    .thenReturn(rec);

            delegateSpy.doExecute(execution);

            String expectedPath = baseDir + File.separator + fileName;
            util.verify(() -> ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(
                    processorTransaction,
                    rec,
                    Map.of(Workflow.OUTCOME_KEY, "File did not archived correctly: fileName=" + expectedPath)
            ), times(1));
        }

        verify(errorMetaDataService, times(1)).writeToErrorCollection(
                same(execution),
                contains("MoveOriginalZipToArchiveFolder --> doExecute: sftp fail"));
    }

    @Test
    public void testArchiveZipFile_jschException_setsOutcomeAndWritesError() throws Exception {
        MoveOriginalZipToArchiveFolder delegateSpy = spy(moveOriginalZipToArchiveFolder);

        String baseDir = System.getProperty("java.io.tmpdir") + File.separator + "zip-test-" + System.nanoTime();
        String fileName = "in.zip";
        File dir = new File(baseDir);
        dir.mkdirs();
        File zip = new File(dir, fileName);
        zip.createNewFile();

        when(processorTransaction.getLocation()).thenReturn(baseDir);
        when(processorTransaction.getFileName()).thenReturn(fileName);

        when(execution.getVariable(Workflow.SFTP_HOSTNAME, String.class)).thenReturn("host");
        when(execution.getVariable(Workflow.SFTP_USERNAME, String.class)).thenReturn("user");
        when(execution.getVariable(Workflow.SFTP_PW, String.class)).thenReturn("pw");
        when(execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, String.class)).thenReturn("/archive");
        when(execution.getVariable(Workflow.MAX_SFTP_TRIES, Integer.class)).thenReturn(3);
        when(execution.getVariable(Workflow.RETRY_TIME_SECS, Long.class)).thenReturn(10L);

        doThrow(new JSchException("jsch fail")).when(delegateSpy).moveFileFromLocalToSFTPLocation(
                anyString(), anyString(), anyString(), anyString(), anyString(), anyInt(), anyLong());

        ProcessorExecutionRecord rec = mock(ProcessorExecutionRecord.class);

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            util.when(() -> ProcessorTaskUtil.createProcessorExecutionRecord("Moving source zip file to archive folder"))
                    .thenReturn(rec);

            delegateSpy.doExecute(execution);

            String expectedPath = baseDir + File.separator + fileName;
            util.verify(() -> ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(
                    processorTransaction,
                    rec,
                    Map.of(Workflow.OUTCOME_KEY, "File did not archived correctly: fileName=" + expectedPath)
            ), times(1));
        }

        verify(errorMetaDataService, times(1)).writeToErrorCollection(
                same(execution),
                contains("MoveOriginalZipToArchiveFolder --> doExecute: jsch fail"));
    }

}

