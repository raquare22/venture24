package com.optum.fds.paperless.java.delegate;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import java.io.File;
import java.nio.file.Path;
import java.util.Collections;
import java.util.List;

import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ScheduledSftpMonitor;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.util.SftpUtil;
import java.lang.reflect.Field;

public class SftpPPLTest {

    @InjectMocks
    private SftpPPL sftpPPL;

    @Mock
    private ScheduledSftpMonitor scheduledSftpMonitor;

    @Mock
    private ErrorMetaDataService errorMetaDataService;

    @Mock
    private SftpUtil sftpUtil;

    @Mock
    private DelegateExecution execution;

    @Mock
    private ProcessorMetaData processorMetaData;

    private static final String INGEST_ROOT = "/mock/ingest/root";

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        // Use reflection to set the private field 'ingestRoot'
        Field ingestRootField = SftpPPL.class.getDeclaredField("ingestRoot");
        ingestRootField.setAccessible(true);
        ingestRootField.set(sftpPPL, INGEST_ROOT);

        // Ensure the mocked dependencies are injected
        sftpPPL.sftpUtil = sftpUtil;
    }

    @Test
    public void testDoExecuteWithSufficientFreeSpace() throws Exception {
        when(execution.getVariable("processorMetaData")).thenReturn(processorMetaData);
        when(sftpUtil.isEnoughFreeSpace(any(Path.class), eq(false))).thenReturn(true);
        when(scheduledSftpMonitor.runSFTPMonitor(processorMetaData)).thenReturn(Collections.singletonList("transactionId"));

        sftpPPL.doExecute(execution);

        verify(execution).setTransientVariable("processorMetaData", processorMetaData);
        verify(execution).setTransientVariable("processorTransactionIds", Collections.singletonList("transactionId"));
        verify(execution).setTransientVariable("Monitor_Message", "SUCCESS");
    }

    @Test
    public void testDoExecuteWithInsufficientFreeSpace() {
        when(sftpUtil.isEnoughFreeSpace(any(Path.class), eq(false))).thenReturn(false);

        sftpPPL.doExecute(execution);

        verify(execution).setTransientVariable("exitNow", true);
        verify(execution, never()).setTransientVariable(eq("processorTransactionIds"), any());
    }
}