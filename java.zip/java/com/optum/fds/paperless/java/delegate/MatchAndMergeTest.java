package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class MatchAndMergeTest {
	
    @InjectMocks
    MatchAndMerge matchAndMerge;
	
	@Mock
    DocumentMetaDataService documentMetaDataService;

    @Mock
    ErrorMetaDataService errorMetaDataService;
    
	DelegateExecution execution; 
    
    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
        
        execution = new DelegateExecutionImpl();
        
        List<String> listDocIds = new ArrayList<>();
        listDocIds.add("1234");        
        execution.setVariable(Workflow.DOCUMENT_IDS, listDocIds);
        execution.setVariable(Workflow.MATCH_CRITERIA, "{ \"metadata.tin\" : ${$.metadata.providerTin}, \"spaceId\" : 10200 }");
        execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"24\",\"format\":\"Hours\"}}");

        // matchedDocumentMetaDataList
        ArrayList<DocumentMetaData> list1 = new ArrayList<>();
        list1.add(getDocumentMetaData());
        when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(list1);
        
        ArrayList<DocumentMetaData> list2 = new ArrayList<>();
        list2.add(getDocumentMetaDataPRA());
        when(documentMetaDataService.getDocumentMetaData(Mockito.anyString(), Mockito.any())).thenReturn(list2);

        
        when(documentMetaDataService.saveDocumentMetaData(Mockito.any())).thenReturn(getDocumentMetaDataPRA());
        
        when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
    }
    
    @Test
    public void testDoExecute() throws Exception {
    	matchAndMerge.execute(execution);
    	assertNotNull(matchAndMerge.errorMap);
        List<String> updatedDocIds = execution.getVariable(Workflow.DOCLIB_PUT_DOCUMENT_IDS, List.class);
        assertNotNull(updatedDocIds);
        assertEquals("62744049d2fa8e44dab4bcb3", updatedDocIds.get(0));

    }
    
    @Test
    public void testDoExecuteWithException() throws Exception {
    	List<String> listDocIds = new ArrayList<>();
        listDocIds.add("1234");        
        execution.setVariable(Workflow.DOCUMENT_IDS, listDocIds);
        execution.setVariable(Workflow.MATCH_CRITERIA, "{ \"metadata.tin\" : ${$.metadata.testingInvalid}, \"spaceId\" : 10200 }");
        execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"24\",\"format\":\"Hours\"}}");

    	matchAndMerge.execute(execution);
    	assertNotNull(matchAndMerge.errorMap);
    	assertEquals(1, matchAndMerge.errorMap.get(Workflow.NEW_ERRORS));
    }
    
    private DocumentMetaData getDocumentMetaDataPRA() throws IOException {
    	DocumentMetaData documentMetaData = null;
        String docStr = "{"
                + "\"id\" : \"62744049d2fa8e44dab4bcb3\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 10070,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\""
                + "}";

        String metaData = "{\n"
        		+ "        \"emailAlertReq\" : \"Y\",\n"
        		+ "        \"fileDescription\" : \"Payment Document\",\n"
        		+ "        \"docSentTo\" : \"DocLib\",\n"
        		+ "        \"subCategory\" : \"P3\",\n"
        		+ "        \"fileName\" : \"2022110ZCCPAU0_000389.pdf\",\n"
        		+ "        \"originalPrintTrail\" : \"3206\",\n"
        		+ "        \"postCardInd\" : true,\n"
        		+ "        \"privilege\" : \"Claim Status\",\n"
        		+ "        \"expiryDate\" : \"2024-05-04T21:23:21.290Z\",\n"
        		+ "        \"tin\" : \"47486160\",\n"
        		+ "        \"CONFIGKEY\" : \"FDSPP3206\",\n"
        		+ "        \"PTRS_FIFTEEN\" : \"110ZCCPAU000397\",\n"
        		+ "        \"sendToDocVault\" : true,\n"
        		+ "        \"EFT_Ind\" : \"Y\",\n"
        		+ "        \"tenant\" : \"Link\",\n"
        		+ "        \"PTRS\" : \"110ZCCPAU00039702\",\n"
        		+ "        \"DefaultUsed\" : \"\",\n"
        		+ "        \"multClaimNumber\" : \"|69090927-00|69090927-01|69205162-00|69205162-00|69205162-01|69160784-00|69160784-01|\",\n"
        		+ "        \"MailToAddress1\" : \"HOPE MILLS FAMILY \",\n"
        		+ "        \"filePath\" : \"Medicare/Detailed PRAs\",\n"
        		+ "        \"sendEmailNotifications\" : false,\n"
        		+ "        \"merged\" : false,\n"
        		+ "        \"providerEmailId\" : \"\",\n"
        		+ "        \"ind_835\" : \"\",\n"
        		+ "        \"sendPENAPIRequest\" : false,\n"
        		+ "        \"DIV\" : \"|GSO|GSO|GSO|GSO|GSO|GSO|GSO|\",\n"
        		+ "        \"createdDate\" : \"2203-08-25T00:00:00.000Z\",\n"
        		+ "        \"physicianName\" : \"HOPE MILLS FAMILY \",\n"
        		+ "        \"createApplication\" : \"CheckWrite\",\n"
        		+ "        \"CheckTraceNumber\" : \"F0952230 \",\n"
        		+ "        \"addedToCosmosPraResponseFile\" : false,\n"
        		+ "        \"PassThruData\" : \"110ZCCPAU00039702\",\n"
        		+ "        \"MailToAddress6\" : \"28289-6263\",\n"
        		+ "        \"mpin\" : \"000000000\",\n"
        		+ "        \"MailToAddress4\" : \"CHARLOTTE \",\n"
        		+ "        \"category\" : \"Payment Document\",\n"
        		+ "        \"MailToAddress5\" : \"NC\",\n"
        		+ "        \"MailToAddress2\" : \"PO BOX 896263 \",\n"
        		+ "        \"fileType\" : \"Letter\",\n"
        		+ "        \"MailToAddress3\" : \"\",\n"
        		+ "        \"sendToShutterfly\" : false,\n"
        		+ "        \"prepostStarted\" : true,\n"
        		+ "        \"corporateMpin\" : \"002149262\",\n"
        		+ "        \"prepostEnded\" : true,\n"
        		+ "        \"docLibAPIResponse\" : true,\n"
        		+ "        \"docLibUploadDate\" : \"2022-05-05T21:25:00.786Z\"\n"
        		+ "    }";
        Document metaDataObject = Document.parse(metaData);
        documentMetaData = Parser.parseJson(docStr, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
        return documentMetaData;
    }
    
    private DocumentMetaData getDocumentMetaData() throws IOException {
    	// return optum pay document
        DocumentMetaData documentMetaData = null;
        String docStr = "{"
                + "\"id\" : \"593e9fadef8654760f6b464c\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 10070,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\""
                + "}";

        String metaData = "{\n"
        		+ "			\"payerId\": \"00008772)\",\n"
        		+ "			\"payerAdditionalId\": \"80560000\",\n"
        		+ "			\"npi\": \"165974949\",\n"
        		+ "			\"providerTin\": \"47486160\",\n"
        		+ "			\"unconsolidatedPaymentNumber\": \"2022120310900092\",\n"
        		+ "			\"unconsolidatedPaymentAmt\": \"000000517\",\n"
        		+ "			\"consolidatedPaymentNumber\": \"1844299396\",\n"
        		+ "			\"consolidatedPaymentAmt\": \"000000517\",\n"
        		+ "			\"origPaymentMethod\": \"AC\",\n"
        		+ "			\"payeeName\": \"Walnut Psychotherapy Center LLC\",\n"
        		+ "			\"origPaymentDate\": \"2022120\",\n"
        		+ "			\"checkNumber\": \"\",\n"
        		+ "			\"revisedPaymentMethod\": \"\",\n"
        		+ "			\"norCode\": \"\",\n"
        		+ "			\"vcpStatus\": \"\",\n"
        		+ "			\"reOriginatedDate\": \"\"\n"
        		+ "		}";
        Document metaDataObject = Document.parse(metaData);
        documentMetaData = Parser.parseJson(docStr, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
        return documentMetaData;
    }

}
