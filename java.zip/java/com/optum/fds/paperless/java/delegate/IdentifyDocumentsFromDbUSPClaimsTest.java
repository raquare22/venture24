package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

public class IdentifyDocumentsFromDbUSPClaimsTest {

    @InjectMocks
    private IdentifyDocumentsFromDbUSPClaims identifyDocumentsFromDbUSPClaims;

    @Mock
    DocumentMetaDataService documentMetadataService;

    @Mock
    EmailService emailService;

    @Mock
    HookService hookService;

    private DelegateExecution execution = new DelegateExecutionImpl();

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        // Initialize the errorMap field using reflection
        Field errorMapField = OptumJavaDelegateBase.class.getDeclaredField("errorMap");
        errorMapField.setAccessible(true);
        errorMapField.set(identifyDocumentsFromDbUSPClaims, new Document());
    }

    @Test
    public void testDoExecute() throws Exception {

        execution.setVariable(Workflow.CLIENT_ID, 0);
        execution.setVariable(Workflow.HOOK_ID, "12345");
        execution.setVariable(Workflow.PROCESS_KEY, "processKey");
        execution.setVariable(Workflow.SPACE_ID, 10902);

        execution.setVariable(Workflow.SEARCH_CRITERIA, "{\"spaceId\": 10902,\"status\" : \"AVAILABLE\", \"metadata.emailAlertReq\" : \"Y\", \"metadata.addedToResponseFile\" : { \"$exists\" : false }, $or : [{\"metadata.providerEmailId\":{$ne : \"\"}, \"metadata.sendEmailNotifications\":true, \"metadata.docVaultAPIResponse\" : true}, {\"metadata.providerEmailId\":{$eq : \"\"},\"metadata.docVaultAPIResponse\" : true}, {\"metadata.corporateMpin\" : { \"$exists\" : false }}]}");
        execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"24\",\"format\":\"Hours\"}}");
        execution.setVariable(Workflow.MAX_DOCUMENTS_OCCURS, 100);

        when(documentMetadataService.getDocumentMetaData(Mockito.any(), Mockito.any(), Mockito.anyInt())).thenReturn(getDocumentMetaDataList());
        when(documentMetadataService.getDocumentMetaDataByZipFileName(Mockito.anyString(), Mockito.any(), Mockito.anyString(), Mockito.anyInt())).thenReturn(getDocumentMetaDataListZipFile());

        identifyDocumentsFromDbUSPClaims.execute(execution);

        Set<String> set = execution.getVariable("setofZipFile", Set.class);
        assertFalse(set.isEmpty());


    }

    @Test
    public void testDoExecuteEmptyList() throws Exception {

        execution.setVariable(Workflow.CLIENT_ID, 0);
        execution.setVariable(Workflow.HOOK_ID, "12345");
        execution.setVariable(Workflow.PROCESS_KEY, "processKey");
        execution.setVariable(Workflow.SPACE_ID, 10902);

        execution.setVariable(Workflow.SEARCH_CRITERIA, "{\"spaceId\": 10902,\"status\" : \"AVAILABLE\", \"metadata.emailAlertReq\" : \"Y\", \"metadata.addedToResponseFile\" : { \"$exists\" : false }, $or : [{\"metadata.providerEmailId\":{$ne : \"\"}, \"metadata.sendEmailNotifications\":true, \"metadata.docVaultAPIResponse\" : true}, {\"metadata.providerEmailId\":{$eq : \"\"},\"metadata.docVaultAPIResponse\" : true}, {\"metadata.corporateMpin\" : { \"$exists\" : false }}]}");
        execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"24\",\"format\":\"Hours\"}}");
        execution.setVariable(Workflow.MAX_DOCUMENTS_OCCURS, null);

        when(documentMetadataService.getDocumentMetaData(Mockito.any(), Mockito.any(), Mockito.anyInt())).thenReturn(null);
        when(documentMetadataService.getDocumentMetaDataByZipFileName(Mockito.anyString(), Mockito.any(), Mockito.anyString(), Mockito.anyInt())).thenReturn(null);

        identifyDocumentsFromDbUSPClaims.execute(execution);

        assertNotNull(identifyDocumentsFromDbUSPClaims.errorMap);


    }

    private List<DocumentMetaData> getDocumentMetaDataList() {
        List<DocumentMetaData> list = new ArrayList<>();

        DocumentMetaData doc = new DocumentMetaData();
        org.bson.Document metadata = new org.bson.Document();
        metadata.put("zipFileName", "zipfile1.zip");
        doc.setId("1234");
        doc.setMetadata(metadata);
        doc.setStatus("AVAILABLE");

        DocumentMetaData doc2 = new DocumentMetaData();
        org.bson.Document metadata2 = new org.bson.Document();
        metadata2.put("zipFileName", "zipfile2.zip");
        doc2.setId("5678");
        doc2.setMetadata(metadata2);
        doc2.setStatus("AVAILABLE");

        list.add(doc);
        list.add(doc2);
        return list;

    }

    private List<DocumentMetaData> getDocumentMetaDataListZipFile() {
        List<DocumentMetaData> list = new ArrayList<>();

        DocumentMetaData doc = new DocumentMetaData();
        org.bson.Document metadata = new org.bson.Document();
        metadata.put("zipFileName", "zipfile1.zip");
        doc.setId("1234");
        doc.setMetadata(metadata);
        doc.setStatus("AVAILABLE");

        DocumentMetaData doc2 = new DocumentMetaData();
        org.bson.Document metadata2 = new org.bson.Document();
        metadata2.put("zipFileName", "zipfile1.zip");
        doc2.setId("9012334");
        doc2.setMetadata(metadata2);
        doc2.setStatus("AVAILABLE");

        list.add(doc);
        list.add(doc2);
        return list;

    }


    @Test
    public void testValidateInput_NullInput() throws Exception {
        // Act
        Method method = IdentifyDocumentsFromDbUSPClaims.class.getDeclaredMethod("validateInput", String.class, DelegateExecution.class);
        method.setAccessible(true);
        Optional<Document> result = (Optional<Document>) method.invoke(identifyDocumentsFromDbUSPClaims, null, execution);

        // Assert
        assertFalse(result.isPresent());
    }

    @Test
    public void testValidateInput_ValidJson() throws Exception {
        // Arrange
        String validJson = "{\"key\":\"value\"}";

        // Act
        Method method = IdentifyDocumentsFromDbUSPClaims.class.getDeclaredMethod("validateInput", String.class, DelegateExecution.class);
        method.setAccessible(true);
        Optional<Document> result = (Optional<Document>) method.invoke(identifyDocumentsFromDbUSPClaims, validJson, execution);

        // Assert
        assertTrue(result.isPresent());
        assertEquals("value", result.get().getString("key"));
    }
}