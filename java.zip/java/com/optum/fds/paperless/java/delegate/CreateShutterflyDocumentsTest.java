package com.optum.fds.paperless.java.delegate;


import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.model.FixedLengthMetadata;
import com.optum.fds.paperless.model.FixedLengthMetadataOCM;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.io.FileUtils;
import org.beanio.StreamFactory;
import org.beanio.Unmarshaller;
import org.beanio.builder.FixedLengthParserBuilder;
import org.beanio.builder.StreamBuilder;
import org.bson.Document;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import static com.optum.fds.paperless.workflow.constants.Workflow.*;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.eq;

@RunWith(MockitoJUnitRunner.class)
public class CreateShutterflyDocumentsTest {

    private static final String CONFIGKEY_FIRST = "CONFIGKEY";
    private static final String CONFIGKEY_SECOND = "ConfigKey";
    private static final String TEST_DUMMY_SPACE_ID = "99999999";
    private static final String TEST_DUMMY_TRANSACTION_ID = "abcdefg";
    private static final String TEST_DUMMY_IDENTIFIER = "dummy_identifier";
    private static final String TEST_DUMMY_CLIENT_ID = "88888888";
    private static final String TEST_DUMMY_DOCUMENT_ID = "TEST-DOC-1";
    private static final String TEST_DUMMY_DOCUMENT_ID_2 = "TEST-DOC-2";
    private static final String ORIGINAL_PRINT_TRAIL = "1905";

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @InjectMocks
    CreateShutterflyDocuments createShutterflyDocuments;

    DelegateExecution execution;
    
    @Mock
    ErrorMetaDataService errorMetaDataService;

    @Before
    public void setUp() throws Exception {
        execution = new DelegateExecutionImpl();
        execution.setVariable(OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsoluteFile().toString() + File.separator);
        execution.setVariable(Workflow.ORIGINAL_PRINT_TRAIL, ORIGINAL_PRINT_TRAIL);

        execution.setVariable(TEMPLATE_NAME, Templates.CHECK_WRITE_PRA_COMPANION.getTemplate());
        
//        when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());

    }

    @UserStory(references = "US24247")
    @RallyTestCase(references = "TC28785")
    @Test
    public void testExecute() throws Exception {
        Boolean originalPrintTrailSet = true;
        verifySuccess(originalPrintTrailSet);
    }


    @UserStory(references = "US24713")
    @RallyTestCase(references = "TC29238")
    @Test
    public void testReprintFilenameWithOriginalPrintTrail() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataWithOriginalPrintTrail());
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
        File[] fileList = tempFolder.getRoot().listFiles();
        for (File file : Objects.requireNonNull(fileList)) {
            assertTrue("originalPrintTrail incorrect", file.getName().contains("FDS_NO_RPRNT_1905"));
        }
    }

    @UserStory(references = "US24713")
    @RallyTestCase(references = "TC29238")
    @Test
    public void testComapanionFileForPriorAuthLetters() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataPriorAuthLetters());
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
        File[] fileList = tempFolder.getRoot().listFiles();
        for (File file : Objects.requireNonNull(fileList)) {
            verifyCompanionFileContentsPriorAuth(file);
        }
    }
    
    @UserStory(references = "US24713")
    @RallyTestCase(references = "TC29238")
    @Test
    public void testComapanionFileForRealTime() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataRealTime());
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
        File[] fileList = tempFolder.getRoot().listFiles();
        for (File file : Objects.requireNonNull(fileList)) {
            verifyCompanionFileContentsPriorAuth(file);
        }
    }

    @UserStory(references = "US24713")
    @RallyTestCase(references = "TC29238")
    @Test
    public void testComapanionFileForPostCardIndTrueCorporateMpinMissing() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataCorporateMpinMissing());
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
        File[] fileList = tempFolder.getRoot().listFiles();
        for (File file : Objects.requireNonNull(fileList)) {
            verifyCompanionFileContentsPriorAuth(file);
        }
    }

    @UserStory(references = "US24713")
    @RallyTestCase(references = "TC29238")
    @Test
    public void testComapanionFileForPostCardIndTrueWithCorporateMpin() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataWithCorporateMpin());
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
        File[] fileList = tempFolder.getRoot().listFiles();
        for (File file : Objects.requireNonNull(fileList)) {
            verifyCompanionFileContentsPriorAuth(file);
        }
    }

    @UserStory(references = "US24713")
    @RallyTestCase(references = "TC29238")
    @Test
    public void testComapanionFileForPostCardIndTrueWithEmptyCorporateMpin() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataWithEmptyCorporateMpin());
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
        File[] fileList = tempFolder.getRoot().listFiles();
		for (File file : Objects.requireNonNull(fileList)) {
			verifyCompanionFileContentsPriorAuth(file);
        }
    }

    @UserStory(references = "US24713")
    @RallyTestCase(references = "TC29238")
    @Test
    public void testComapanionFileForPostCardIndTrueWithEmptyproviderEmailId() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataWithEmptyProviderEmailId());
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
        File[] fileList = tempFolder.getRoot().listFiles();
		for (File file : Objects.requireNonNull(fileList)) {
            verifyCompanionFileContentsPriorAuth(file);
        }
    }

    @Test
    public void testCompanionFileForPriorAuthLetters() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataPriorAuthLetters2());
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
        File[] fileList = tempFolder.getRoot().listFiles();
		for (File file : Objects.requireNonNull(fileList)) {
            verifyCompanionFileContentsPriorAuth2(file);
        }

    }

    @UserStory(references = "US24247")
    @RallyTestCase(references = "TC28786")
    @Test
    public void testExecuteWithEmptyListDocuments() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
        List<String> compFile = (List<String>) execution.getVariable(PRINT_SERVICES_MANIFEST);
        assertNull(compFile);
    }

    @UserStory(references = "US24247")
    @RallyTestCase(references = "TC28786")
    @Test
    public void testExecuteWithNullListDocuments() throws Exception {
        execution.setVariable(LIST_DOCUMENT_METADATA, null);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(1, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
    }

    @UserStory(references = "US24247")
    @RallyTestCase(references = "TC28862")
    @Test
    public void testWithNullOriginalPrintTrail() throws Exception {
        execution.setVariable(ORIGINAL_PRINT_TRAIL, null);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(1, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
    }


    @UserStory(references = "US26197")
    @RallyTestCase(references = "TC30328,TC31180")
//    @Test
    public void testWithOriginalCompanionFileRecord() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataOriginalCompanionRecord());
        execution.setVariable(CREATE_ORIGINAL_COMPANION_FILE, true);
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        Object compFile = execution.getVariable(ORIGINAL_COMPANION_FILENAME);
        assertNotNull(compFile);
        assertTrue(compFile.toString().startsWith("FDS_RPRNT"));
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
    }

    @UserStory(references = "DE6700")
    @RallyTestCase(references = "TC31206")
    @Test
    public void testWithPostCardTrueAndProviderEmailIdMissing() throws Exception {
        DocumentMetaData documentMetadata = getDocumentMetaDataOriginalCompanionRecordReal();
        documentMetadata.getMetadata().remove(PROVIDER_EMAIL_ID);
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(documentMetadata);
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        List<String> compFile = (List<String>) execution.getVariable(PRINT_SERVICES_MANIFEST);
        assertNotNull(compFile);
        assertTrue(compFile.get(0).startsWith(FDS_NO_RPRNT_APPLICATION_NAME));
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
    }

    @UserStory(references = "DE6700")
    @RallyTestCase(references = "TC31207")
    @Test
    public void testWithPostCardTruetinMissingtin() throws Exception {
        DocumentMetaData documentMetadata = getDocumentMetaDataOriginalCompanionRecordReal();
        documentMetadata.getMetadata().remove(TIN);
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(documentMetadata);
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        List<String> compFile = (List<String>) execution.getVariable(PRINT_SERVICES_MANIFEST);
        assertNotNull(compFile);
        assertTrue(compFile.get(0).startsWith(FDS_RPRNT_APPLICATION_NAME));
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
    }

    @UserStory(references = "DE6700")
    @RallyTestCase(references = "TC31208")
    @Test
    public void testWithPostCardTruetinMissingCorporateMpin() throws Exception {
        DocumentMetaData documentMetadata = getDocumentMetaDataOriginalCompanionRecordReal();
        documentMetadata.getMetadata().remove(PROV_CORP_MPIN);
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(documentMetadata);
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        List<String> compFile = (List<String>) execution.getVariable(PRINT_SERVICES_MANIFEST);
        assertNotNull(compFile);
        assertTrue(compFile.get(0).startsWith(FDS_RPRNT_APPLICATION_NAME));
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
    }

    @UserStory(references = "DE6700")
    @RallyTestCase(references = "TC31209")
    @Test
    public void testWithPostCardTrue() throws Exception {
        DocumentMetaData documentMetadata = getDocumentMetaDataOriginalCompanionRecordReal();
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(documentMetadata);
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        List<String> compFile = (List<String>) execution.getVariable(PRINT_SERVICES_MANIFEST);
        assertNotNull(compFile);
        assertTrue(compFile.get(0).startsWith(FDS_NO_RPRNT_APPLICATION_NAME));
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
    }

    @UserStory(references = "DE6700")
    @RallyTestCase(references = "TC31210")
    @Test
    public void testWithPostCardFalse() throws Exception {
        DocumentMetaData documentMetadata = getDocumentMetaDataOriginalCompanionRecordReal();
        documentMetadata.getMetadata().put(POST_CARD_IND, false);
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(documentMetadata);
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        List<String> compFile = (List<String>) execution.getVariable(PRINT_SERVICES_MANIFEST);
        assertNotNull(compFile);
        assertTrue(compFile.get(0).startsWith(FDS_RPRNT_APPLICATION_NAME));
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
    }

    @UserStory(references = "DE6700")
    @RallyTestCase(references = "TC31211")
    @Test
    public void testWithNoPostCardInd() throws Exception {
        DocumentMetaData documentMetadata = getDocumentMetaDataOriginalCompanionRecordReal();
        documentMetadata.getMetadata().remove(POST_CARD_IND);
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(documentMetadata);
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        List<String> compFile = (List<String>) execution.getVariable(PRINT_SERVICES_MANIFEST);
        assertNotNull(compFile);
        assertTrue(compFile.get(0).startsWith(FDS_RPRNT_APPLICATION_NAME));
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
    }

    @UserStory(references = "US26403")
    @RallyTestCase(references = "TC30353")
    @Test
    public void testComapanionFileForMissingMailAddress1() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataWithMissingMailAddressOne());
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
        File[] fileList = tempFolder.getRoot().listFiles();
        for (File file : Objects.requireNonNull(fileList)) {
            verifyCompanionFileContentsMissingEmailAddressOne(file, getDocumentMetaDataWithMissingMailAddressOne());
        }
    }

    @UserStory(references = "US26403")
    @RallyTestCase(references = "TC30354")
    @Test
    public void testComapanionFileForMissingMailAddress1AndPhysicanName() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataWithMissingMailAddressOneAndProviderName());
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
        File[] fileList = tempFolder.getRoot().listFiles();
        for (File file : Objects.requireNonNull(fileList)) {
            verifyCompanionFileContentsMissingEmailAddressOne(file, getDocumentMetaDataWithMissingMailAddressOneAndProviderName());
        }
    }

    @UserStory(references = "US28204")
    @RallyTestCase(references = "TC31216")
//    @Test
    public void testWithConvertJsonWithTemplateException() throws Exception {
        execution = new DelegateExecutionImpl(new HashMap<>());
        execution.setVariable(OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsoluteFile() + File.separator);
        execution.setVariable(ORIGINAL_PRINT_TRAIL, ORIGINAL_PRINT_TRAIL);
        List<DocumentMetaData> listDocumentMetaData = List.of(getDocumentMetaDataOriginalCompanionRecord());
        execution.setVariable(CREATE_ORIGINAL_COMPANION_FILE, true);
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        execution.setVariable(TEMPLATE_ID, null);
        createShutterflyDocuments.execute(execution);
        assertNotNull(execution.getVariable(PRINT_SERVICES_MANIFEST));
    }

    @UserStory(references = "US28204")
    @RallyTestCase(references = "TC31216")
//    @Test
    public void testWithDoExecuteException() throws Exception {
        execution = new DelegateExecutionImpl();
        execution.setVariable(OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsoluteFile() + File.separator);
        execution.setVariable(ORIGINAL_PRINT_TRAIL, ORIGINAL_PRINT_TRAIL);
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataOriginalCompanionRecord());
        execution.setVariable(CREATE_ORIGINAL_COMPANION_FILE, true);
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        execution.setVariable(OUTPUT_FILE_DIR, "/junk/junk");
        createShutterflyDocuments.execute(execution);
    }

    @UserStory(references = "US28204")
    @RallyTestCase(references = "TC31216")
    @Test
    public void testGetDelegateExecutionId() throws Exception {
        String value = createShutterflyDocuments.getDelegateExecutionId(null);
        assertEquals("NULL", value);
    }

    @UserStory(references = "DE6698")
    @RallyTestCase(references = "TC31182")
    @Test
    public void testWithConfigKeyForUnet() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaConfigKeyForUnetRecord());
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
    }

    @UserStory(references = "DE6782")
    @RallyTestCase(references = "TC32302")
//    @Test
    public void testWithOriginalCompanionFileRecordWithRemoveDuplicate() throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaDataOriginalCompanionRecord());
        listDocumentMetaData.add(getDocumentMetaDataOriginalCompanionRecordSecond());
        execution.setVariable(CREATE_ORIGINAL_COMPANION_FILE, true);
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        Object compFile = execution.getVariable(ORIGINAL_COMPANION_FILENAME);
        assertNotNull(compFile);
        assertTrue(compFile.toString().startsWith("FDS_RPRNT"));
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
    }

    @UserStory(references = "DE6782")
    @RallyTestCase(references = "TC32302")
//    @Test
    public void testWithMultipleDocumentMetaData() throws Exception {
        DocumentMetaData doc = getDocumentMetaDataWithCorporateMpin();
        doc.getMetadata().put("originalPrintTrail", "1234");

        DocumentMetaData doc2 = getDocumentMetaDataWithEmptyProviderEmailId();
        doc2.getMetadata().put("originalPrintTrail", "1234");
        List<DocumentMetaData> listDocumentMetaData = List.of(
                getDocumentMetaDataOriginalCompanionRecord(),
                getDocumentMetaDataOriginalCompanionRecordSecond(),
                getDocumentMetaData(),
                getDocumentMetaDataPriorAuthLetters(),
                getDocumentMetaDataCorporateMpinMissing(),
                doc,
                getDocumentMetaDataWithEmptyCorporateMpin(),
                doc2,
                getDocumentMetaDataPriorAuthLetters2(),
                getDocumentMetaDataWithMissingMailAddressOne(),
                getDocumentMetaDataWithMissingMailAddressOneAndProviderName(),
                getDocumentMetaDataOriginalCompanionRecordReal()

        );
        execution.setVariable(CREATE_ORIGINAL_COMPANION_FILE, true);
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        List<String> compFile = (List<String>) execution.getVariable(PRINT_SERVICES_MANIFEST);
        assertNotNull(compFile);
        assertEquals(2, compFile.size());
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
    }


    public static DocumentMetaData getDocumentMetaData() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{ " +
                "\"tagLine\" : \"tagLine value\", " +
                "\"providerId\" : \"providerId\", " +
                "\"tin\" : \"200094270\", " +
                "\"mpin\" : \"000006294\", " +
                "\"patientFirstName\" : \"PAMELA\", " +
                "\"patientLastName\" : \"FERNANDO\", " +
                "\"patientDateOfBirth\" : \"03/12/1996\", " +
                "\"recipientFirstName\" : \"SAM\", " +
                "\"recipientLastName\" : \"SNOW\", " +
                "\"PassThruData\" : \"223315_335888\", " +
                "\"CheckAmt\" : \"checkAmtValue\",\n" +
                "\"CheckTraceNumber\" : \"checkNumValue\",\n" +
                "\"templateNameOrId\" : \"templateNameOrId\", " +
                "\"documentIdentifier\" : \"docIdValue\",\n" +
                "\"recipientDob\" : \"03\12\1996\", " +
                "\"privacyIndicator\" : \"1\", " +
                "\"MailToAddress1\" : \"ALLINA HEALTH UNITED WOMENS HEALTH\", " +
                "\"MailToAddress2\" : \"347 SMITH AVE N STE 203\", " +
                "\"MailToAddress3\" : \"USA\", " +
                "\"MailToAddress4\" : \"SAINT PAUL\", " +
                "\"MailToAddress5\" : \"MN\", " +
                "\"MailToAddress6\" : \"55102\", " +
                "\"CONFIGKEY\" : \"configKey value\", " +
                "\"eDeliveryError\":\"Missing or invalid data: email address\"," +
                "\"createApplication\":\"elgs\"" +
                "\"category\" : \"Prior Auth Notification\", " +
                "\"fileName\" : \"PriorAuth1ClickTestDocument.pdf\", " +
                "}");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("FixedLenght.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }

    public static DocumentMetaData getDocumentMetaDataWithOriginalPrintTrail() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{ " +
                "\"tagLine\" : \"tagLine value\", " +
                "\"providerId\" : \"providerId\", " +
                "\"tin\" : \"200094270\", " +
                "\"corporateMpin\" : \"133757370\",\n" +
                "\"mpin\" : \"000006294\", " +
                "\"patientFirstName\" : \"PAMELA\", " +
                "\"patientLastName\" : \"FERNANDO\", " +
                "\"patientDateOfBirth\" : \"03/12/1996\", " +
                "\"recipientFirstName\" : \"SAM\", " +
                "\"recipientLastName\" : \"SNOW\", " +
                "\"PassThruData\" : \"223315_335888\", " +
                "\"CheckAmt\" : \"checkAmtValue\",\n" +
                "\"CheckTraceNumber\" : \"checkNumValue\",\n" +
                "\"templateNameOrId\" : \"templateNameOrId\", " +
                "\"documentIdentifier\" : \"docIdValue\",\n" +
                "\"recipientDob\" : \"03/12/1996\", " +
                "\"privacyIndicator\" : \"1\", " +
                "\"MailToAddress1\" : \"ALLINA HEALTH UNITED WOMENS HEALTH\", " +
                "\"MailToAddress2\" : \"347 SMITH AVE N STE 203\", " +
                "\"MailToAddress3\" : \"USA\", " +
                "\"MailToAddress4\" : \"SAINT PAUL\", " +
                "\"MailToAddress5\" : \"MN\", " +
                "\"MailToAddress6\" : \"55102\", " +
                "\"CONFIGKEY\" : \"configKey value\", " +
                "\"eDeliveryError\":\"Missing or invalid data: email address\"," +
                "\"originalPrintTrail\":\"" + ORIGINAL_PRINT_TRAIL + "\"," +
                "\"createApplication\":\"elgs\"" +
                "\"category\" : \"Prior Auth Notification\", " +
                "\"postCardInd\" : true,\n" +
                "\"fileName\" : \"PriorAuth1ClickTestDocument.pdf\", " +
                "}");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("FixedLenght.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }

    public static DocumentMetaData getDocumentMetaDataPriorAuthLetters() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{\n" +
                "        \"fileDescription\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"fileName\" : \"PriorAuth1ClickTestDocument.pdf\",\n" +
                "        \"subCategory\" : \"A4\",\n" +
                "        \"policyNumber\" : \"10793\",\n" +
                "        \"MemberSourceSystem\" : \"COSMOS\",\n" +
                "        \"tin\" : \"200094270\",\n" +
                "        \"CONFIGKEY\" : \"\",\n" +
                "        \"DMSecurityClass\" : \"MR_CLIN_APRV\",\n" +
                "        \"tenant\" : \"Link\",\n" +
                "        \"notificationNumber\" : \"A000350240\",\n" +
                "        \"providerName\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"memberId\" : \"911822123\",\n" +
                "        \"DefaultUsed\" : \"N\",\n" +
                "        \"ReturnAddress6\" : \"71913\",\n" +
                "        \"MailToAddress1\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"ReturnAddress5\" : \"AR\",\n" +
                "        \"ReturnAddress4\" : \"Hot Springs\",\n" +
                "        \"HHKey\" : \"\",\n" +
                "        \"DUPLEXSIMPLEX\" : \"D\",\n" +
                "        \"ProviderCOSMOSID\" : \"\",\n" +
                "        \"NotificationLetterId\" : \"0000003531672\",\n" +
                "        \"State\" : \"OH\",\n" +
                "        \"NotificationType\" : \"OP\",\n" +
                "        \"PassThruData\" : \"223315_335888\",\n" +
                "        \"MailToAddress6\" : \"55102\",\n" +
                "        \"mpin\" : \"000006294\",\n" +
                "        \"dateOfService\" : \"2018-06-14T00:00:00.000-06:00\",\n" +
                "        \"ReturnAddress3\" : \"\",\n" +
                "        \"MailToAddress4\" : \"SAINT PAUL\",\n" +
                "        \"ReturnAddress2\" : \"P.O. Box 29300\",\n" +
                "        \"MailToAddress5\" : \"MN\",\n" +
                "        \"ReturnAddress1\" : \"UnitedHealthcare\",\n" +
                "        \"MailToAddress2\" : \"347 SMITH AVE N STE 203\",\n" +
                "        \"MailToAddress3\" : \"Basking Ridge\",\n" +
                "        \"docSentTo\" : \"DocVault\",\n" +
                "        \"emailAlertReq\" : \"Y\",\n" +
                "        \"ELGSLETTERGENID\" : \"335888\",\n" +
                "        \"RELATEDID\" : \"566835528\",\n" +
                "        \"memberName\" : \"WEIR RONALD\",\n" +
                "        \"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\n" +
                "        \"Segment\" : \"Medicare and Retirement\",\n" +
                "        \"expiryDate\" : \"2019-01-27T14:47:58.854Z\",\n" +
                "        \"MemberAltID\" : \"911822123\",\n" +
                "        \"filePath\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"ELGSREQUESTID\" : \"223315\",\n" +
                "        \"providerEmailId\" : \"temp@gmail.com\",\n" +
                "        \"GenerationType\" : \"LTR\",\n" +
                "        \"WORKGROUP_NME\" : \"MR_CLIN_APRV\",\n" +
                "        \"createdDate\" : \"2018-06-19T12:54:57.000-06:00\",\n" +
                "        \"LetterPriority\" : \"Standard\",\n" +
                "        \"createApplication\" : \"1Click\",\n" +
                "        \"category\" : \"Prior Auth Notification\",\n" +
                "        \"fileType\" : \"Letter\",\n" +
                "        \"LetterHistoryID\" : \"566835531\",\n" +
                "        \"OUSERID\" : \"elgsys\",\n" +
                "		 \"eDeliveryError\":\"Missing or invalid data: email address\"" +
                "    }");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("FixedLenght.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }
    
    public static DocumentMetaData getDocumentMetaDataRealTime() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{\n" +
                "        \"fileDescription\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"fileName\" : \"PriorAuth1ClickTestDocument.pdf\",\n" +
                "        \"subCategory\" : \"A4\",\n" +
                "        \"policyNumber\" : \"10793\",\n" +
                "        \"MemberSourceSystem\" : \"COSMOS\",\n" +
                "        \"tin\" : \"200094270\",\n" +
                "        \"CONFIGKEY\" : \"\",\n" +
                "        \"DMSecurityClass\" : \"MR_CLIN_APRV\",\n" +
                "        \"tenant\" : \"Link\",\n" +
                "        \"notificationNumber\" : \"A000350240\",\n" +
                "        \"providerName\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"memberId\" : \"911822123\",\n" +
                "        \"DefaultUsed\" : \"N\",\n" +
                "        \"ReturnAddress6\" : \"71913\",\n" +
                "        \"MailToAddress1\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"ReturnAddress5\" : \"AR\",\n" +
                "        \"ReturnAddress4\" : \"Hot Springs\",\n" +
                "        \"HHKey\" : \"\",\n" +
                "        \"DUPLEXSIMPLEX\" : \"D\",\n" +
                "        \"ProviderCOSMOSID\" : \"\",\n" +
                "        \"NotificationLetterId\" : \"0000003531672\",\n" +
                "        \"State\" : \"OH\",\n" +
                "        \"NotificationType\" : \"OP\",\n" +
                "        \"PassThruData\" : \"223315_335888\",\n" +
                "        \"MailToAddress6\" : \"55102\",\n" +
                "        \"mpin\" : \"000006294\",\n" +
                "        \"dateOfService\" : \"2018-06-14T00:00:00.000-06:00\",\n" +
                "        \"ReturnAddress3\" : \"\",\n" +
                "        \"NotificationLetterID\" : \"abcdefghijkl\",\n" +
                "        \"MailToAddress4\" : \"SAINT PAUL\",\n" +
                "        \"ReturnAddress2\" : \"P.O. Box 29300\",\n" +
                "        \"MailToAddress5\" : \"MN\",\n" +
                "        \"ReturnAddress1\" : \"UnitedHealthcare\",\n" +
                "        \"MailToAddress2\" : \"347 SMITH AVE N STE 203\",\n" +
                "        \"MailToAddress3\" : \"Basking Ridge\",\n" +
                "        \"docSentTo\" : \"DocVault\",\n" +
                "        \"emailAlertReq\" : \"Y\",\n" +
                "        \"ELGSLETTERGENID\" : \"335888\",\n" +
                "        \"RELATEDID\" : \"566835528\",\n" +
                "        \"memberName\" : \"WEIR RONALD\",\n" +
                "        \"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\n" +
                "        \"Segment\" : \"Medicare and Retirement\",\n" +
                "        \"expiryDate\" : \"2019-01-27T14:47:58.854Z\",\n" +
                "        \"MemberAltID\" : \"911822123\",\n" +
                "        \"filePath\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"ELGSREQUESTID\" : \"223315\",\n" +
                "        \"providerEmailId\" : \"temp@gmail.com\",\n" +
                "        \"GenerationType\" : \"LTR\",\n" +
                "        \"WORKGROUP_NME\" : \"MR_CLIN_APRV\",\n" +
                "        \"createdDate\" : \"2018-06-19T12:54:57.000-06:00\",\n" +
                "        \"LetterPriority\" : \"Standard\",\n" +
                "        \"createApplication\" : \"OCM\",\n" +
                "        \"category\" : \"Prior Auth Notification\",\n" +
                "        \"fileType\" : \"Letter\",\n" +
                "        \"LetterHistoryID\" : \"566835531\",\n" +
                "        \"OUSERID\" : \"elgsys\",\n" +
                "		 \"eDeliveryError\":\"Missing or invalid data: email address\"" +
                "    }");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("FixedLenght.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }

    public static DocumentMetaData getDocumentMetaDataCorporateMpinMissing() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{\n" +
                "        \"fileDescription\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"fileName\" : \"PriorAuth1ClickTestDocument.pdf\",\n" +
                "        \"subCategory\" : \"A4\",\n" +
                "        \"policyNumber\" : \"10793\",\n" +
                "        \"MemberSourceSystem\" : \"COSMOS\",\n" +
                "        \"tin\" : \"200094270\",\n" +
                "        \"CONFIGKEY\" : \"\",\n" +
                "        \"DMSecurityClass\" : \"MR_CLIN_APRV\",\n" +
                "        \"postCardInd\" : true,\n" +
                "        \"tenant\" : \"Link\",\n" +
                "        \"notificationNumber\" : \"A000350240\",\n" +
                "        \"providerName\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"memberId\" : \"911822123\",\n" +
                "        \"DefaultUsed\" : \"N\",\n" +
                "        \"ReturnAddress6\" : \"71913\",\n" +
                "        \"MailToAddress1\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"ReturnAddress5\" : \"AR\",\n" +
                "        \"ReturnAddress4\" : \"Hot Springs\",\n" +
                "        \"HHKey\" : \"\",\n" +
                "        \"DUPLEXSIMPLEX\" : \"D\",\n" +
                "        \"ProviderCOSMOSID\" : \"\",\n" +
                "        \"NotificationLetterId\" : \"0000003531672\",\n" +
                "        \"State\" : \"OH\",\n" +
                "        \"NotificationType\" : \"OP\",\n" +
                "        \"PassThruData\" : \"223315_335888\",\n" +
                "        \"MailToAddress6\" : \"55102\",\n" +
                "        \"mpin\" : \"000006294\",\n" +
                "        \"dateOfService\" : \"2018-06-14T00:00:00.000-06:00\",\n" +
                "        \"ReturnAddress3\" : \"\",\n" +
                "        \"MailToAddress4\" : \"SAINT PAUL\",\n" +
                "        \"ReturnAddress2\" : \"P.O. Box 29300\",\n" +
                "        \"MailToAddress5\" : \"MN\",\n" +
                "        \"ReturnAddress1\" : \"UnitedHealthcare\",\n" +
                "        \"MailToAddress2\" : \"347 SMITH AVE N STE 203\",\n" +
                "        \"MailToAddress3\" : \"Basking Ridge\",\n" +
                "        \"docSentTo\" : \"DocVault\",\n" +
                "        \"emailAlertReq\" : \"Y\",\n" +
                "        \"ELGSLETTERGENID\" : \"335888\",\n" +
                "        \"RELATEDID\" : \"566835528\",\n" +
                "        \"memberName\" : \"WEIR RONALD\",\n" +
                "        \"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\n" +
                "        \"Segment\" : \"Medicare and Retirement\",\n" +
                "        \"expiryDate\" : \"2019-01-27T14:47:58.854Z\",\n" +
                "        \"MemberAltID\" : \"911822123\",\n" +
                "        \"filePath\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"ELGSREQUESTID\" : \"223315\",\n" +
                "        \"providerEmailId\" : \"temp@gmail.com\",\n" +
                "        \"GenerationType\" : \"LTR\",\n" +
                "        \"WORKGROUP_NME\" : \"MR_CLIN_APRV\",\n" +
                "        \"createdDate\" : \"2018-06-19T12:54:57.000-06:00\",\n" +
                "        \"LetterPriority\" : \"Standard\",\n" +
                "        \"createApplication\" : \"1Click\",\n" +
                "        \"category\" : \"Prior Auth Notification\",\n" +
                "        \"fileType\" : \"Letter\",\n" +
                "        \"LetterHistoryID\" : \"566835531\",\n" +
                "        \"OUSERID\" : \"elgsys\",\n" +
                "		 \"eDeliveryError\":\"Missing or invalid data: email address\"" +
                "    }");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("FixedLenght.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }

    public static DocumentMetaData getDocumentMetaDataWithCorporateMpin() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{\n" +
                "        \"fileDescription\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"fileName\" : \"PriorAuth1ClickTestDocument.pdf\",\n" +
                "        \"subCategory\" : \"A4\",\n" +
                "        \"policyNumber\" : \"10793\",\n" +
                "        \"corporateMpin\" : \"133757370\",\n" +
                "        \"MemberSourceSystem\" : \"COSMOS\",\n" +
                "        \"tin\" : \"200094270\",\n" +
                "        \"CONFIGKEY\" : \"\",\n" +
                "        \"DMSecurityClass\" : \"MR_CLIN_APRV\",\n" +
                "        \"postCardInd\" : true,\n" +
                "        \"tenant\" : \"Link\",\n" +
                "        \"notificationNumber\" : \"A000350240\",\n" +
                "        \"providerName\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"memberId\" : \"911822123\",\n" +
                "        \"DefaultUsed\" : \"N\",\n" +
                "        \"ReturnAddress6\" : \"71913\",\n" +
                "        \"MailToAddress1\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"ReturnAddress5\" : \"AR\",\n" +
                "        \"ReturnAddress4\" : \"Hot Springs\",\n" +
                "        \"HHKey\" : \"\",\n" +
                "        \"DUPLEXSIMPLEX\" : \"D\",\n" +
                "        \"ProviderCOSMOSID\" : \"\",\n" +
                "        \"NotificationLetterId\" : \"0000003531672\",\n" +
                "        \"State\" : \"OH\",\n" +
                "        \"NotificationType\" : \"OP\",\n" +
                "        \"PassThruData\" : \"223315_335888\",\n" +
                "        \"MailToAddress6\" : \"55102\",\n" +
                "        \"mpin\" : \"000006294\",\n" +
                "        \"dateOfService\" : \"2018-06-14T00:00:00.000-06:00\",\n" +
                "        \"ReturnAddress3\" : \"\",\n" +
                "        \"MailToAddress4\" : \"SAINT PAUL\",\n" +
                "        \"ReturnAddress2\" : \"P.O. Box 29300\",\n" +
                "        \"MailToAddress5\" : \"MN\",\n" +
                "        \"ReturnAddress1\" : \"UnitedHealthcare\",\n" +
                "        \"MailToAddress2\" : \"347 SMITH AVE N STE 203\",\n" +
                "        \"MailToAddress3\" : \"Basking Ridge\",\n" +
                "        \"docSentTo\" : \"DocVault\",\n" +
                "        \"emailAlertReq\" : \"Y\",\n" +
                "        \"ELGSLETTERGENID\" : \"335888\",\n" +
                "        \"RELATEDID\" : \"566835528\",\n" +
                "        \"memberName\" : \"WEIR RONALD\",\n" +
                "        \"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\n" +
                "        \"Segment\" : \"Medicare and Retirement\",\n" +
                "        \"expiryDate\" : \"2019-01-27T14:47:58.854Z\",\n" +
                "        \"MemberAltID\" : \"911822123\",\n" +
                "        \"filePath\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"ELGSREQUESTID\" : \"223315\",\n" +
                "        \"providerEmailId\" : \"temp@gmail.com\",\n" +
                "        \"GenerationType\" : \"LTR\",\n" +
                "        \"WORKGROUP_NME\" : \"MR_CLIN_APRV\",\n" +
                "        \"createdDate\" : \"2018-06-19T12:54:57.000-06:00\",\n" +
                "        \"LetterPriority\" : \"Standard\",\n" +
                "        \"createApplication\" : \"1Click\",\n" +
                "        \"category\" : \"Prior Auth Notification\",\n" +
                "        \"fileType\" : \"Letter\",\n" +
                "        \"LetterHistoryID\" : \"566835531\",\n" +
                "        \"OUSERID\" : \"elgsys\",\n" +
                "		 \"eDeliveryError\":\"Missing or invalid data: email address\"" +
                "    }");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("FixedLenght.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }

    public static DocumentMetaData getDocumentMetaDataWithEmptyCorporateMpin() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{\n" +
                "        \"fileDescription\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"fileName\" : \"PriorAuth1ClickTestDocument.pdf\",\n" +
                "        \"subCategory\" : \"A4\",\n" +
                "        \"policyNumber\" : \"10793\",\n" +
                "        \"corporateMpin\" : \"\",\n" +
                "        \"MemberSourceSystem\" : \"COSMOS\",\n" +
                "        \"tin\" : \"200094270\",\n" +
                "        \"CONFIGKEY\" : \"\",\n" +
                "        \"DMSecurityClass\" : \"MR_CLIN_APRV\",\n" +
                "        \"postCardInd\" : true,\n" +
                "        \"tenant\" : \"Link\",\n" +
                "        \"notificationNumber\" : \"A000350240\",\n" +
                "        \"providerName\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"memberId\" : \"911822123\",\n" +
                "        \"DefaultUsed\" : \"N\",\n" +
                "        \"ReturnAddress6\" : \"71913\",\n" +
                "        \"MailToAddress1\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"ReturnAddress5\" : \"AR\",\n" +
                "        \"ReturnAddress4\" : \"Hot Springs\",\n" +
                "        \"HHKey\" : \"\",\n" +
                "        \"DUPLEXSIMPLEX\" : \"D\",\n" +
                "        \"ProviderCOSMOSID\" : \"\",\n" +
                "        \"NotificationLetterId\" : \"0000003531672\",\n" +
                "        \"State\" : \"OH\",\n" +
                "        \"NotificationType\" : \"OP\",\n" +
                "        \"PassThruData\" : \"223315_335888\",\n" +
                "        \"MailToAddress6\" : \"55102\",\n" +
                "        \"mpin\" : \"000006294\",\n" +
                "        \"dateOfService\" : \"2018-06-14T00:00:00.000-06:00\",\n" +
                "        \"ReturnAddress3\" : \"\",\n" +
                "        \"MailToAddress4\" : \"SAINT PAUL\",\n" +
                "        \"ReturnAddress2\" : \"P.O. Box 29300\",\n" +
                "        \"MailToAddress5\" : \"MN\",\n" +
                "        \"ReturnAddress1\" : \"UnitedHealthcare\",\n" +
                "        \"MailToAddress2\" : \"347 SMITH AVE N STE 203\",\n" +
                "        \"MailToAddress3\" : \"Basking Ridge\",\n" +
                "        \"docSentTo\" : \"DocVault\",\n" +
                "        \"emailAlertReq\" : \"Y\",\n" +
                "        \"ELGSLETTERGENID\" : \"335888\",\n" +
                "        \"RELATEDID\" : \"566835528\",\n" +
                "        \"memberName\" : \"WEIR RONALD\",\n" +
                "        \"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\n" +
                "        \"Segment\" : \"Medicare and Retirement\",\n" +
                "        \"expiryDate\" : \"2019-01-27T14:47:58.854Z\",\n" +
                "        \"MemberAltID\" : \"911822123\",\n" +
                "        \"filePath\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"ELGSREQUESTID\" : \"223315\",\n" +
                "        \"providerEmailId\" : \"temp@gmail.com\",\n" +
                "        \"GenerationType\" : \"LTR\",\n" +
                "        \"WORKGROUP_NME\" : \"MR_CLIN_APRV\",\n" +
                "        \"createdDate\" : \"2018-06-19T12:54:57.000-06:00\",\n" +
                "        \"LetterPriority\" : \"Standard\",\n" +
                "        \"createApplication\" : \"1Click\",\n" +
                "        \"category\" : \"Prior Auth Notification\",\n" +
                "        \"fileType\" : \"Letter\",\n" +
                "        \"LetterHistoryID\" : \"566835531\",\n" +
                "        \"OUSERID\" : \"elgsys\",\n" +
                "		 \"eDeliveryError\":\"Missing or invalid data: email address\"" +
                "    }");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("FixedLenght.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }

    public static DocumentMetaData getDocumentMetaDataWithEmptyProviderEmailId() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{\n" +
                "        \"fileDescription\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"fileName\" : \"PriorAuth1ClickTestDocument.pdf\",\n" +
                "        \"subCategory\" : \"A4\",\n" +
                "        \"policyNumber\" : \"10793\",\n" +
                "        \"corporateMpin\" : \"133757370\",\n" +
                "        \"MemberSourceSystem\" : \"COSMOS\",\n" +
                "        \"tin\" : \"200094270\",\n" +
                "        \"CONFIGKEY\" : \"\",\n" +
                "        \"DMSecurityClass\" : \"MR_CLIN_APRV\",\n" +
                "        \"postCardInd\" : true,\n" +
                "        \"tenant\" : \"Link\",\n" +
                "        \"notificationNumber\" : \"A000350240\",\n" +
                "        \"providerName\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"memberId\" : \"911822123\",\n" +
                "        \"DefaultUsed\" : \"N\",\n" +
                "        \"ReturnAddress6\" : \"71913\",\n" +
                "        \"MailToAddress1\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"ReturnAddress5\" : \"AR\",\n" +
                "        \"ReturnAddress4\" : \"Hot Springs\",\n" +
                "        \"HHKey\" : \"\",\n" +
                "        \"DUPLEXSIMPLEX\" : \"D\",\n" +
                "        \"ProviderCOSMOSID\" : \"\",\n" +
                "        \"NotificationLetterId\" : \"0000003531672\",\n" +
                "        \"State\" : \"OH\",\n" +
                "        \"NotificationType\" : \"OP\",\n" +
                "        \"PassThruData\" : \"223315_335888\",\n" +
                "        \"MailToAddress6\" : \"55102\",\n" +
                "        \"mpin\" : \"000006294\",\n" +
                "        \"dateOfService\" : \"2018-06-14T00:00:00.000-06:00\",\n" +
                "        \"ReturnAddress3\" : \"\",\n" +
                "        \"MailToAddress4\" : \"SAINT PAUL\",\n" +
                "        \"ReturnAddress2\" : \"P.O. Box 29300\",\n" +
                "        \"MailToAddress5\" : \"MN\",\n" +
                "        \"ReturnAddress1\" : \"UnitedHealthcare\",\n" +
                "        \"MailToAddress2\" : \"347 SMITH AVE N STE 203\",\n" +
                "        \"MailToAddress3\" : \"Basking Ridge\",\n" +
                "        \"docSentTo\" : \"DocVault\",\n" +
                "        \"emailAlertReq\" : \"Y\",\n" +
                "        \"ELGSLETTERGENID\" : \"335888\",\n" +
                "        \"RELATEDID\" : \"566835528\",\n" +
                "        \"memberName\" : \"WEIR RONALD\",\n" +
                "        \"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\n" +
                "        \"Segment\" : \"Medicare and Retirement\",\n" +
                "        \"expiryDate\" : \"2019-01-27T14:47:58.854Z\",\n" +
                "        \"MemberAltID\" : \"911822123\",\n" +
                "        \"filePath\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"ELGSREQUESTID\" : \"223315\",\n" +
                "        \"providerEmailId\" : \"\",\n" +
                "        \"GenerationType\" : \"LTR\",\n" +
                "        \"WORKGROUP_NME\" : \"MR_CLIN_APRV\",\n" +
                "        \"createdDate\" : \"2018-06-19T12:54:57.000-06:00\",\n" +
                "        \"LetterPriority\" : \"Standard\",\n" +
                "        \"createApplication\" : \"1Click\",\n" +
                "        \"category\" : \"Prior Auth Notification\",\n" +
                "        \"fileType\" : \"Letter\",\n" +
                "        \"LetterHistoryID\" : \"566835531\",\n" +
                "        \"OUSERID\" : \"elgsys\",\n" +
                "		 \"eDeliveryError\":\"Missing or invalid data: email address\"" +
                "    }");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("FixedLenght.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }

    public static DocumentMetaData getDocumentMetaDataPriorAuthLetters2() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID_2);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{\n" +
                "        \"fileDescription\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"fileName\" : \"000106_20190613_0720686500.pdf\",\n" +            // changed
                "        \"subCategory\" : \"A1\",\n" +                                    // changed
                "        \"policyNumber\" : \"10793\",\n" +
                "        \"MemberSourceSystem\" : \"COSMOS\",\n" +
                "        \"tin\" : \"200094270\",\n" +                                        // changed
                "        \"CONFIGKEY\" : \"FDSELR3264\",\n" +                                // changed
                "        \"DMSecurityClass\" : \"MR_CLIN_APRV\",\n" +
                "        \"tenant\" : \"Link\",\n" +
                "        \"notificationNumber\" : \"A000350240\",\n" +
                "        \"providerName\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI\",\n" +
                "        \"memberId\" : \"911822123\",\n" +
                "        \"DefaultUsed\" : \"N\",\n" +
                "        \"ReturnAddress6\" : \"71913\",\n" +
                "        \"MailToAddress1\" : \"Cape Medical Supply\",\n" +                // changed
                "        \"ReturnAddress5\" : \"AR\",\n" +
                "        \"ReturnAddress4\" : \"Hot Springs\",\n" +
                "        \"HHKey\" : \"\",\n" +
                "        \"DUPLEXSIMPLEX\" : \"D\",\n" +
                "        \"ProviderCOSMOSID\" : \"\",\n" +
                "        \"NotificationLetterId\" : \"0000003531672\",\n" +
                "        \"State\" : \"OH\",\n" +
                "        \"NotificationType\" : \"OP\",\n" +
                "        \"PassThruData\" : \"179143930_253605534_1044989466\",\n" +        // changed
                "        \"MailToAddress6\" : \"55102\",\n" +                                // changed
                "        \"mpin\" : \"668785\",\n" +                                        // changed
                "        \"dateOfService\" : \"2018-06-14T00:00:00.000-06:00\",\n" +
                "        \"ReturnAddress3\" : \"\",\n" +
                "        \"MailToAddress4\" : \"MA\",\n" +                                    // changed
                "        \"ReturnAddress2\" : \"P.O. Box 29300\",\n" +
                "        \"MailToAddress5\" : \"2563\",\n" +                                // changed
                "        \"ReturnAddress1\" : \"UnitedHealthcare\",\n" +
                "        \"MailToAddress2\" : \"28 JAN SEBASTIAN DR\",\n" +                // changed
                "        \"MailToAddress3\" : \"SANDWICH\",\n" +                            // changed
                "        \"docSentTo\" : \"DocVault\",\n" +
                "        \"emailAlertReq\" : \"Y\",\n" +
                "        \"ELGSLETTERGENID\" : \"335888\",\n" +
                "        \"RELATEDID\" : \"566835528\",\n" +
                "        \"memberName\" : \"WEIR RONALD\",\n" +
                "        \"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\n" +
                "        \"Segment\" : \"Medicare and Retirement\",\n" +
                "        \"expiryDate\" : \"2019-01-27T14:47:58.854Z\",\n" +
                "        \"MemberAltID\" : \"911822123\",\n" +
                "        \"filePath\" : \"Medicare Prior Auth/Approved\",\n" +
                "        \"ELGSREQUESTID\" : \"223315\",\n" +
                "        \"providerEmailId\" : \"temp@gmail.com\",\n" +
                "        \"GenerationType\" : \"LTR\",\n" +
                "        \"WORKGROUP_NME\" : \"MR_CLIN_APRV\",\n" +
                "        \"createdDate\" : \"2018-06-19T12:54:57.000-06:00\",\n" +
                "        \"LetterPriority\" : \"Standard\",\n" +
                "        \"createApplication\" : \"1Click\",\n" +
                "        \"fileType\" : \"Letter\",\n" +
                "        \"LetterHistoryID\" : \"566835531\",\n" +
                "        \"OUSERID\" : \"elgsys\",\n" +
                "		 \"eDeliveryError\":\"Missing or invalid data: email bounced\",\n" +// changed
                "        \"patientFirstName\" : \"PAMELA\",\n" +                            // changed
                "        \"patientLastName\" : \"FERNANDO\",\n" +
                "        \"patientDateOfBirth\" : \"03/12/1996\",\n" +                        // changed
                "        \"recipientFirstName\" : \"SAM\",\n" +
                "        \"CheckAmt\" : \"156\",\n" +                                        // changed
                "        \"CheckTraceNumber\" : \"TV05366055\",\n" +                        // changed
                "        \"category\" : \"Claim\",\n" +                                    // changed
                "        \"originalPrintTrail\":\"" + ORIGINAL_PRINT_TRAIL + "\",\n" +            // changed
                "        \"EmailAddress\"   : \"coke@yahoo.com\"\n" +                        // changed
                "        \"tagLine\" : \"20190523061022853857219\",\n" +                    // changed
                "        \"providerId\" : \"providerId\",\n" +                                // changed
                "    }");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("FixedLenght.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }

    public static DocumentMetaData getDocumentMetaDataWithMissingMailAddressOne() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{ " +
                "\"tagLine\" : \"tagLine value\", " +
                "\"providerId\" : \"providerId\", " +
                "\"tin\" : \"200094270\",\n" +
                "\"mpin\" : \"000006294\", " +
                "\"patientFirstName\" : \"PAMELA\", " +
                "\"patientLastName\" : \"FERNANDO\", " +
                "\"patientDateOfBirth\" : \"03/12/1996\", " +
                "\"providerName\" : \"PARAMESH,KORRAKUTI\", " +
                "\"physicianName\" : \"\", " +
                "\"PassThruData\" : \"223315_335888\", " +
                "\"CheckAmt\" : \"checkAmtValue\",\n" +
                "\"CheckTraceNumber\" : \"checkNumValue\",\n" +
                "\"subCategory\" : \"C8\", " +
                "\"templateNameOrId\" : \"templateNameOrId\", " +
                "\"documentIdentifier\" : \"docIdValue\",\n" +
                "\"category\" : \"Prior Auth Notification\", " +
                "\"MailToAddress1\" : \"\",\n" +
                "\"MailToAddress2\" : \"347 SMITH AVE N STE 203\", " +
                "\"MailToAddress3\" : \"USA\", " +
                "\"MailToAddress4\" : \"SAINT PAUL\", " +
                "\"MailToAddress5\" : \"MN\", " +
                "\"MailToAddress6\" : \"55102\", " +
                "\"EmailAddress\"   : \"mandal@optum.com\", " +
                "\"CONFIGKEY\" : \"configKey value\", " +
                "\"eDeliveryError\":\"Missing or invalid data: email address\"," +
                "\"originalPrintTrail\":\"" + ORIGINAL_PRINT_TRAIL + "\"," +
                "\"createApplication\":\"elgs\"" +
                "\"fileName\" : \"PriorAuth1ClickTestDocument.pdf\", " +
                "}");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("FixedLenght.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }


    public static DocumentMetaData getDocumentMetaDataWithMissingMailAddressOneAndProviderName() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{ " +
                "\"tagLine\" : \"tagLine value\", " +
                "\"providerId\" : \"providerId\", " +
                "\"tin\" : \"200094270\",\n" +
                "\"mpin\" : \"000006294\", " +
                "\"patientFirstName\" : \"PAMELA\", " +
                "\"patientLastName\" : \"FERNANDO\", " +
                "\"patientDateOfBirth\" : \"03/12/1996\", " +
                "\"providerName\" : \"\", " +
                "\"physicianName\" : \"PARAMESH,KORRAKUTI\", " +
                "\"PassThruData\" : \"223315_335888\", " +
                "\"CheckAmt\" : \"checkAmtValue\",\n" +
                "\"CheckTraceNumber\" : \"checkNumValue\",\n" +
                "\"subCategory\" : \"C8\", " +
                "\"templateNameOrId\" : \"templateNameOrId\", " +
                "\"documentIdentifier\" : \"docIdValue\",\n" +
                "\"MailToAddress1\" : \"\",\n" +
                "\"MailToAddress2\" : \"347 SMITH AVE N STE 203\", " +
                "\"MailToAddress3\" : \"USA\", " +
                "\"MailToAddress4\" : \"SAINT PAUL\", " +
                "\"MailToAddress5\" : \"MN\", " +
                "\"MailToAddress6\" : \"55102\", " +
                "\"EmailAddress\"   : \"mandal@optum.com\", " +
                "\"category\" : \"Prior Auth Notification\", " +
                "\"CONFIGKEY\" : \"configKey value\", " +
                "\"eDeliveryError\":\"Missing or invalid data: email address\"," +
                "\"originalPrintTrail\":\"" + ORIGINAL_PRINT_TRAIL + "\"," +
                "\"createApplication\":\"elgs\"" +
                "\"fileName\" : \"PriorAuth1ClickTestDocument.pdf\", " +
                "}");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("FixedLenght.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }

    public static DocumentMetaData getDocumentMetaDataOriginalCompanionRecordReal() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{\"fileDescription\" : \"Payment Document\",\n        \"emailAlertReq\" : \"Y\",\n        \"docSentTo\" : \"DocVault\",\n        \"fileName\" : \"2019220ZDDPIS0_000003.pdf\",\n        \"subCategory\" : \"P3\",\n        \"originalPrintTrail\" : \"3206\",\n        \"privilege\" : \"Claim Status\",\n        \"corporateMpin\" : \"001815880\",\n        \"originalCompanionFileRecords\" : [ \n            \"220ZDDPIS00000402|EVC|00425-908210741-00|AONO, LUTHER                  |80474835-00|PRA|COSMOS\"\n        ],\n        \"frequency\" : \"D\",\n        \"expiryDate\" : \"2020-02-05T00:19:00.496Z\",\n        \"tin\" : \"391678306\",\n        \"CONFIGKEY\" : \"FDSPP3206\",\n        \"sendToDocVault\" : true,\n        \"tenant\" : \"Link\",\n        \"EFT_Ind\" : \"N\",\n        \"claimNumber\" : \"|80474835-00|\",\n        \"PTRS\" : \"220ZDDPIS00000402\",\n        \"DefaultUsed\" : \"N\",\n        \"835_Ind\" : \"\",\n        \"filePath\" : \"Medicare PRAs/Detail PRA\",\n        \"merged\" : true,\n        \"providerEmailId\" : \"lane_k_mooney@uhc.com\",\n        \"DIV\" : \"|EVC|\",\n        \"createdDate\" : \"2019-08-08T18:19:00.495Z\",\n        \"physicianName\" : \"EVEN, D.O., LORAS R.\",\n        \"CheckAmt\" : \"\",\n        \"createApplication\" : \"CheckWrite\",\n        \"CheckTraceNumber\" : \"48199240\",\n        \"addedToCosmosPraResponseFile\" : true,\n        \"PassThruData\" : \"220ZDDPIS00000402\",\n        \"mpin\" : \"005637824\",\n        \"category\" : \"Payment Document\",\n        \"fileType\" : \"Letter\",\n        \"sendToShutterfly\" : false,\n	\"postCardInd\" : true}");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("companionSample.txt");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }


    public static DocumentMetaData getDocumentMetaDataOriginalCompanionRecord() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{ " +
                "\"tagLine\" : \"tagLine value\", " +
                "\"providerId\" : \"providerId value\", " +
                "\"mpin\" : \"000006294\", " +
                "\"tin\" : \"200094270\",\n" +
                "\"patientFirstName\" : \"PAMELA\", " +
                "\"patientLastName\" : \"FERNANDO\", " +
                "\"patientDateOfBirth\" : \"2000-12-03T04:06:31Z\", " +
                "\"recipientFirstName\" : \"SAM\", " +
                "\"recipientLastName\" : \"SNOW\", " +
                "\"PassThruData\" : \"223315_335888\", " +
                "\"CheckAmt\" : \"checkAmtValue\",\n" +
                "\"CheckTraceNumber\" : \"checkNumValue\",\n" +
                "\"templateNameOrId\" : \"templateNameOrId value\", " +
                "\"documentIdentifier\" : \"docIdValue\",\n" +
                "\"recipientDob\" : \"1999-12-03T04:06:31Z\", " +
                "\"privacyIndicator\" : \"1\", " +
                "\"MailToAddress1\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI    \", " +
                "\"MailToAddress2\" : \"347 SMITH AVE N STE 203\", " +
                "\"MailToAddress3\" : \"USA\", " +
                "\"MailToAddress4\" : \"SAINT PAUL\", " +
                "\"MailToAddress5\" : \"MN\", " +
                "\"MailToAddress6\" : \"55102\", " +
                "\"CONFIGKEY\" : \"configKey value\", " +
                "\"fileName\" : \"companionSample.pdf\", " +
                "\"eDeliveryError\":\"Missing or invalid data: email address\"," +
                "\"createApplication\":\"elgs\"" +
                "\"originalCompanionFileRecords\" : [ \"\n\"\"145ZAAPIU00000901|MSP|70219-916698066-00|DOE2, JOHN K.                 |42069144-01|PRA|COSMOS \" ,\" \n\"\"145ZAAPIU00000303|MSP|80270-937666557-00|DOE4, JOHN J.                 |42069149-01|PRA|COSMOS \" " +
                "]" +
                "}");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("companionSample.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }

    public static DocumentMetaData getDocumentMetaDataOriginalCompanionRecordSecond() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{ " +
                "\"tagLine\" : \"tagLine value\", " +
                "\"providerId\" : \"providerId value\", " +
                "\"mpin\" : \"000006294\", " +
                "\"tin\" : \"200094270\",\n" +
                "\"patientFirstName\" : \"PAMELA\", " +
                "\"patientLastName\" : \"FERNANDO\", " +
                "\"patientDateOfBirth\" : \"2000-12-03T04:06:31Z\", " +
                "\"recipientFirstName\" : \"SAM\", " +
                "\"recipientLastName\" : \"SNOW\", " +
                "\"PassThruData\" : \"223315_335888\", " +
                "\"CheckAmt\" : \"checkAmtValue\",\n" +
                "\"CheckTraceNumber\" : \"checkNumValue\",\n" +
                "\"templateNameOrId\" : \"templateNameOrId value\", " +
                "\"documentIdentifier\" : \"docIdValue\",\n" +
                "\"recipientDob\" : \"1999-12-03T04:06:31Z\", " +
                "\"privacyIndicator\" : \"1\", " +
                "\"MailToAddress1\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI    \", " +
                "\"MailToAddress2\" : \"347 SMITH AVE N STE 203\", " +
                "\"MailToAddress3\" : \"USA\", " +
                "\"MailToAddress4\" : \"SAINT PAUL\", " +
                "\"MailToAddress5\" : \"MN\", " +
                "\"MailToAddress6\" : \"55102\", " +
                "\"CONFIGKEY\" : \"configKey value\", " +
                "\"fileName\" : \"companionSample.pdf\", " +
                "\"eDeliveryError\":\"Missing or invalid data: email address\"," +
                "\"createApplication\":\"elgs\"" +
                "\"originalCompanionFileRecords\" : [ \"\n\"\"145ZAAPIU00000901|MSP|70219-916698066-00|DOE2, JOHN K.                 |42069144-01|PRA|COSMOS \" ,\" \n\"\"145ZAAPIU00000303|MSP|80270-937666557-00|DOE4, JOHN J.                 |42069149-01|PRA|COSMOS \" " +
                "]" +
                "}");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("companionSample.pdf");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }


    void verifySuccess(Boolean originalPrintTrailSet) throws Exception {
        List<DocumentMetaData> listDocumentMetaData = new ArrayList<DocumentMetaData>();
        listDocumentMetaData.add(getDocumentMetaData());
        listDocumentMetaData.add(getDocumentMetaDataWithOriginalPrintTrail());
        execution.setVariable(LIST_DOCUMENT_METADATA, listDocumentMetaData);
        createShutterflyDocuments.execute(execution);
        assertNotNull(createShutterflyDocuments.errorMap);
        assertEquals(0, createShutterflyDocuments.errorMap.get(NEW_ERRORS));
        File[] fileList = tempFolder.getRoot().listFiles();
        for (File file : fileList) {
            readContents(file, originalPrintTrailSet);
        }
    }

    private void readContents(File file, Boolean originalPrintTrailSet) throws IOException {
        List<FixedLengthMetadata> beanIoObjectList = unmarshellFile(file);
        for (FixedLengthMetadata obj : beanIoObjectList) {
            assertTrue(compareObjectContent(obj, getDocumentMetaData()));
            if (originalPrintTrailSet) {
                assertTrue("originalPrintTrail incorrect", obj.getOriginalPrintTrail().equals(ORIGINAL_PRINT_TRAIL));
            } else {
                assertTrue("originalPrintTrail incorrect", obj.getOriginalPrintTrail().equals(""));
            }

        }
    }

    private List<FixedLengthMetadata> unmarshellFile(File file) throws IOException {
        List<FixedLengthMetadata> fixedMetaDataList = new ArrayList<FixedLengthMetadata>();
        String fileContents = FileUtils.readFileToString(file);
        String[] recordArray = fileContents.split("\r\n");
        StreamFactory factory = StreamFactory.newInstance();
        FixedLengthParserBuilder fixedLengthParserBuilder = new FixedLengthParserBuilder();
        fixedLengthParserBuilder.recordTerminator("");
        StreamBuilder builderTXT = new StreamBuilder("textBuilder")
                .format("fixedlength")
                .parser(fixedLengthParserBuilder)
                .addRecord(FixedLengthMetadata.class);
        factory.define(builderTXT);
        Unmarshaller unmarshaller = factory.createUnmarshaller("textBuilder");
        for (String record : recordArray) {
            record = record + "nl";// this is added in content because the unmarshller was need at least some data to parse to field here nextline is /r/n which is not present as data.so added
            FixedLengthMetadata obj = (FixedLengthMetadata) unmarshaller.unmarshal(record);
            fixedMetaDataList.add(obj);
        }
        return fixedMetaDataList;
    }
    
    private List<FixedLengthMetadataOCM> unmarshellFileRealTime(File file) throws IOException {
        List<FixedLengthMetadataOCM> fixedMetaDataList = new ArrayList<FixedLengthMetadataOCM>();
        String fileContents = FileUtils.readFileToString(file);
        String[] recordArray = fileContents.split("\r\n");
        StreamFactory factory = StreamFactory.newInstance();
        FixedLengthParserBuilder fixedLengthParserBuilder = new FixedLengthParserBuilder();
        fixedLengthParserBuilder.recordTerminator("");
        StreamBuilder builderTXT = new StreamBuilder("textBuilder")
                .format("fixedlength")
                .parser(fixedLengthParserBuilder)
                .addRecord(FixedLengthMetadataOCM.class);
        factory.define(builderTXT);
        Unmarshaller unmarshaller = factory.createUnmarshaller("textBuilder");
        for (String record : recordArray) {
            record = record + "nl";// this is added in content because the unmarshller was need at least some data to parse to field here nextline is /r/n which is not present as data.so added
            FixedLengthMetadataOCM obj = (FixedLengthMetadataOCM) unmarshaller.unmarshal(record);
            fixedMetaDataList.add(obj);
        }
        return fixedMetaDataList;
    }

    private boolean compareObjectContent(FixedLengthMetadata fixedMetadataObj, DocumentMetaData documentMetaData) {

        String tagLine = (String) documentMetaData.getMetadata().get(TAG_LINE);
        String providerId = (String) documentMetaData.getMetadata().get(TIN);
        String mpin = (String) documentMetaData.getMetadata().get(MPIN);
        String patientFirstName = (String) documentMetaData.getMetadata().get(PATIENT_FIRST_NAME);
        String patientLastName = (String) documentMetaData.getMetadata().get(PATIENT_LAST_NAME);
        String patientName = patientFirstName != null ? (patientFirstName + " " + patientLastName) : patientLastName;
        String patientDateOfBirth = (String) documentMetaData.getMetadata().get(PATIENT_DATE_OF_BIRTH);
        String recipientName = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSONE);
        String passThruData = (String) documentMetaData.getMetadata().get(PASS_THRU_DATA);
        String checkAmount = (String) documentMetaData.getMetadata().get(CHECK_AMT);
        String checkNumber = (String) documentMetaData.getMetadata().get(CHECK_TRACE_NUMBER);
        String category = (String) documentMetaData.getMetadata().get(CATEGORY);
        String recipientAddressLine1 = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSTWO);
        String recipientAddressLine2 = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSTHREE);
        String recipientCity = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSFOUR);
        String recipientState = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSFIVE);
        String recipientZip = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSSIX);
        String configKeyFirst = (String) documentMetaData.getMetadata().get(CONFIGKEY_FIRST);
        String configKeySecond = (String) documentMetaData.getMetadata().get(CONFIGKEY_SECOND);
        String configKey = configKeyFirst != null ? configKeyFirst : configKeySecond;
        String edeliveryError = (String) documentMetaData.getMetadata().get(EDELIVERY_ERROR);
        String fileName = (String) documentMetaData.getMetadata().get(FILE_NAME);

        if (fixedMetadataObj.getTagLine().equals(tagLine.trim())
                && fixedMetadataObj.getProviderId().equals(providerId.trim())
                && fixedMetadataObj.getMpin().equals(mpin.trim())
                && fixedMetadataObj.getPatientName().equals(patientName.trim())
                && fixedMetadataObj.getPatientDateOfBirth().equals(patientDateOfBirth.trim())
                && fixedMetadataObj.getRecipientName().equals(recipientName.trim())
                && fixedMetadataObj.getApplicationPassThru().equals(passThruData.trim())
                && fixedMetadataObj.getCheckAmount().equals(checkAmount.trim())
                && fixedMetadataObj.getCheckNumber().equals(checkNumber.trim())
                && fixedMetadataObj.getCategory().equals(category.trim())
                && fixedMetadataObj.getRecipientAddressLine1().equals(recipientAddressLine1.trim())
                && fixedMetadataObj.getRecipientAddressLine2().equals(recipientAddressLine2.trim())
                && fixedMetadataObj.getRecipientAddressLine3().equals(recipientCity.trim())
                && fixedMetadataObj.getRecipientAddressLine4().equals(recipientState.trim())
                && fixedMetadataObj.getRecipientAddressLine5().equals(recipientZip.trim())
                && fixedMetadataObj.getConfigKey().equals(configKey.trim())
                && fixedMetadataObj.getEdeliveryError().equals(edeliveryError.trim())
                && fixedMetadataObj.getOriginalPrintTrail().equals(ORIGINAL_PRINT_TRAIL.trim())
                && fixedMetadataObj.getFileName().equals(fileName.trim())) {
            return true;
        }

        return false;
    }

    private boolean compareObjectContent1(FixedLengthMetadata fixedMetadataObj, DocumentMetaData documentMetaData) {

        String tagLine = (String) documentMetaData.getMetadata().get(TAG_LINE);
        String providerId = (String) documentMetaData.getMetadata().get(TIN);
        String mpin = (String) documentMetaData.getMetadata().get(MPIN);
        String patientFirstName = (String) documentMetaData.getMetadata().get(PATIENT_FIRST_NAME);
        String patientLastName = (String) documentMetaData.getMetadata().get(PATIENT_LAST_NAME);
        String patientName = patientFirstName != null ? (patientFirstName + " " + patientLastName) : patientLastName;
        String createApp = (String) documentMetaData.getMetadata().get(CREATE_APPLICATION);
        String patientDateOfBirth = (String) documentMetaData.getMetadata().get(PATIENT_DATE_OF_BIRTH);
        String recipientName = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSONE);
        String passThruData = (String) documentMetaData.getMetadata().get(PASS_THRU_DATA);
        String historyId = (String) documentMetaData.getMetadata().get(LETTER_HISTORY_ID);
        if (createApp.equals("1Click") || createApp.equals("CCS Manual") || createApp.equals("NextGen"))
            passThruData += "_" + historyId;
        String checkAmount = (String) documentMetaData.getMetadata().get(CHECK_AMT);
        String checkNumber = (String) documentMetaData.getMetadata().get(CHECK_TRACE_NUMBER);
        String category = (String) documentMetaData.getMetadata().get(CATEGORY);
        String recipientAddressLine1 = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSTWO);
        String recipientAddressLine2 = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSTHREE);
        String recipientCity = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSFOUR);
        String recipientState = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSFIVE);
        String recipientZip = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSSIX);
        String configKeyFirst = (String) documentMetaData.getMetadata().get(CONFIGKEY_FIRST);
        String configKeySecond = (String) documentMetaData.getMetadata().get(CONFIGKEY_SECOND);
        String configKey = configKeyFirst != null ? configKeyFirst : configKeySecond;
        String edeliveryError = (String) documentMetaData.getMetadata().get(EDELIVERY_ERROR);
        String fileName = (String) documentMetaData.getMetadata().get(FILE_NAME);
        String emailAddress = (String) documentMetaData.getMetadata().get(EMAIL_ADDRESS);
        String subCategory = (String) documentMetaData.getMetadata().get(SUBCATEGORY);

        return fixedMetadataObj.getTagLine().equals(tagLine.trim())
                && fixedMetadataObj.getRecipientName().equals(recipientName.trim())
                && fixedMetadataObj.getProviderId().equals(providerId.trim())
                && fixedMetadataObj.getMpin().equals(mpin.trim())
                && fixedMetadataObj.getPatientName().equals(patientName.trim())
                && fixedMetadataObj.getPatientDateOfBirth().equals(patientDateOfBirth.trim())
                && fixedMetadataObj.getApplicationPassThru().equals(passThruData.trim())
                && fixedMetadataObj.getCheckAmount().equals(checkAmount.trim())
                && fixedMetadataObj.getCheckNumber().equals(checkNumber.trim())
                && fixedMetadataObj.getCategory().equals(category.trim())
                && fixedMetadataObj.getRecipientAddressLine1().equals(recipientAddressLine1.trim())
                && fixedMetadataObj.getRecipientAddressLine2().equals(recipientAddressLine2.trim())
                && fixedMetadataObj.getRecipientAddressLine3().equals(recipientCity.trim())
                && fixedMetadataObj.getRecipientAddressLine4().equals(recipientState.trim())
                && fixedMetadataObj.getRecipientAddressLine5().equals(recipientZip.trim())
                && fixedMetadataObj.getConfigKey().equals(configKey.trim())
                && fixedMetadataObj.getEdeliveryError().equals(edeliveryError.trim())
                && fixedMetadataObj.getOriginalPrintTrail().equals(ORIGINAL_PRINT_TRAIL.trim())
                && fixedMetadataObj.getSubCategory().equals(subCategory.trim())
                && fixedMetadataObj.getEmailAddress().equals(emailAddress.trim())
                && fixedMetadataObj.getFileName().equals(fileName.trim());
    }

    private void verifyCompanionFileContentsPriorAuth(File file) throws IOException {
        List<FixedLengthMetadata> beanIoObjectList = unmarshellFile(file);
        for (FixedLengthMetadata obj : beanIoObjectList) {
            assertTrue(comparePriorAuthContent(obj, getDocumentMetaDataPriorAuthLetters()));
        }
    }
    
    private void verifyCompanionFileContentsRealTime(File file) throws IOException {
        List<FixedLengthMetadataOCM> beanIoObjectList = unmarshellFileRealTime(file);
        for (FixedLengthMetadataOCM obj : beanIoObjectList) {
            assertTrue(compareRealTimeContent(obj, getDocumentMetaDataRealTime()));
        }
    }

    private void verifyCompanionFileContentsPriorAuth2(File file) throws IOException {
        List<FixedLengthMetadata> beanIoObjectList = unmarshellFile(file);
        for (FixedLengthMetadata obj : beanIoObjectList) {
            assertTrue(compareObjectContent1(obj, getDocumentMetaDataPriorAuthLetters2()));
        }
    }


    private boolean comparePriorAuthContent(FixedLengthMetadata fixedMetadataObj, DocumentMetaData documentMetaData) {
        String mpin = (String) documentMetaData.getMetadata().get(MPIN);
        String passThruData = (String) documentMetaData.getMetadata().get(PASS_THRU_DATA) + "_" + (String) documentMetaData.getMetadata().get(LETTER_HISTORY_ID);
        String recipientAddressLine1 = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSTWO);
        String recipientAddressLine2 = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSTHREE);
        String recipientCity = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSFOUR);
        String recipientState = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSFIVE);
        String recipientZip = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSSIX);
        String edeliveryError = (String) documentMetaData.getMetadata().get(EDELIVERY_ERROR);
        String fileName = (String) documentMetaData.getMetadata().get(FILE_NAME);
        if (fixedMetadataObj.getMpin().equals(mpin.trim())
                && fixedMetadataObj.getApplicationPassThru().equals(passThruData.trim())
                && fixedMetadataObj.getRecipientAddressLine1().equals(recipientAddressLine1.trim())
                && fixedMetadataObj.getRecipientAddressLine2().equals(recipientAddressLine2.trim())
                && fixedMetadataObj.getRecipientAddressLine3().equals(recipientCity.trim())
                && fixedMetadataObj.getRecipientAddressLine4().equals(recipientState.trim())
                && fixedMetadataObj.getRecipientAddressLine5().equals(recipientZip.trim())
                && fixedMetadataObj.getOriginalPrintTrail().equals(ORIGINAL_PRINT_TRAIL.trim())
                && fixedMetadataObj.getEdeliveryError().equals(edeliveryError.trim())
                && fixedMetadataObj.getFileName().equals(fileName.trim())) {
            return true;
        }
        return false;
    }
    
    private boolean compareRealTimeContent(FixedLengthMetadataOCM fixedMetadataObj, DocumentMetaData documentMetaData) {
        String mpin = (String) documentMetaData.getMetadata().get(MPIN);
        String passThruData = (String) documentMetaData.getMetadata().get(PASS_THRU_DATA) + "_" + (String) documentMetaData.getMetadata().get(LETTER_HISTORY_ID);
        String recipientAddressLine1 = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSTWO);
        String recipientAddressLine2 = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSTHREE);
        String recipientCity = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSFOUR);
        String recipientState = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSFIVE);
        String recipientZip = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSSIX);
        String edeliveryError = (String) documentMetaData.getMetadata().get(EDELIVERY_ERROR);
        String fileName = (String) documentMetaData.getMetadata().get(FILE_NAME);
        if (fixedMetadataObj.getMpin().equals(mpin.trim())
                && fixedMetadataObj.getApplicationPassThru().equals(passThruData.trim())
                && fixedMetadataObj.getRecipientAddressLine1().equals(recipientAddressLine1.trim())
                && fixedMetadataObj.getRecipientAddressLine2().equals(recipientAddressLine2.trim())
                && fixedMetadataObj.getRecipientAddressLine3().equals(recipientCity.trim())
                && fixedMetadataObj.getRecipientAddressLine4().equals(recipientState.trim())
                && fixedMetadataObj.getRecipientAddressLine5().equals(recipientZip.trim())
                && fixedMetadataObj.getOriginalPrintTrail().equals(ORIGINAL_PRINT_TRAIL.trim())
                && fixedMetadataObj.getEdeliveryError().equals(edeliveryError.trim())
                && fixedMetadataObj.getFileName().equals(fileName.trim())) {
            return true;
        }
        return false;
    }


    private void verifyCompanionFileContentsMissingEmailAddressOne(File file, DocumentMetaData documentMetaData) throws IOException {
        List<FixedLengthMetadata> beanIoObjectList = unmarshellFile(file);
        for (FixedLengthMetadata obj : beanIoObjectList) {
            assertTrue(compareMissingMailAddressOneContent(obj, documentMetaData));
        }
    }

    private boolean compareMissingMailAddressOneContent(FixedLengthMetadata fixedMetadataObj, DocumentMetaData documentMetaData) {
        String tagLine = (String) documentMetaData.getMetadata().get(TAG_LINE);
        String providerId = (String) documentMetaData.getMetadata().get(TIN);
        String mpin = (String) documentMetaData.getMetadata().get(MPIN);
        String patientFirstName = (String) documentMetaData.getMetadata().get(PATIENT_FIRST_NAME);
        String patientLastName = (String) documentMetaData.getMetadata().get(PATIENT_LAST_NAME);
        String patientName = patientFirstName != null ? (patientFirstName + " " + patientLastName) : patientLastName;
        String patientDateOfBirth = (String) documentMetaData.getMetadata().get(PATIENT_DATE_OF_BIRTH);
        String providerName = (String) documentMetaData.getMetadata().get(PROVIDER_NAME);
        String physicianName = (String) documentMetaData.getMetadata().get(PHYSICIAN_NAME);
        String mailToAddress1 = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSONE);
        String recipientName = mailToAddress1;
        if (mailToAddress1 != null && !mailToAddress1.trim().isEmpty()) {
            recipientName = "";
        } else if (providerName != null && !providerName.trim().isEmpty()) {
            recipientName = providerName;
        } else if (physicianName != null && !physicianName.trim().isEmpty()) {
            recipientName = physicianName;
        }
        String passThruData = (String) documentMetaData.getMetadata().get(PASS_THRU_DATA);
        String checkAmount = (String) documentMetaData.getMetadata().get(CHECK_AMT);
        String checkNumber = (String) documentMetaData.getMetadata().get(CHECK_TRACE_NUMBER);
        String subCategory = (String) documentMetaData.getMetadata().get(SUBCATEGORY);
        String category = (String) documentMetaData.getMetadata().get(CATEGORY);
        String recipientAddressLine1 = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSTWO);
        String recipientAddressLine2 = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSTHREE);
        String recipientCity = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSFOUR);
        String recipientState = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSFIVE);
        String recipientZip = (String) documentMetaData.getMetadata().get(MAIL_TO_ADDRESSSIX);
        String configKeyFirst = (String) documentMetaData.getMetadata().get(CONFIGKEY_FIRST);
        String configKeySecond = (String) documentMetaData.getMetadata().get(CONFIGKEY_SECOND);
        String configKey = configKeyFirst != null ? configKeyFirst : configKeySecond;
        String emailAddress = (String) documentMetaData.getMetadata().get(EMAIL_ADDRESS);
        String edeliveryError = (String) documentMetaData.getMetadata().get(EDELIVERY_ERROR);
        String fileName = (String) documentMetaData.getMetadata().get(FILE_NAME);

        if (fixedMetadataObj.getTagLine().equals(tagLine.trim())
                && fixedMetadataObj.getProviderId().equals(providerId.trim())
                && fixedMetadataObj.getMpin().equals(mpin.trim())
                && fixedMetadataObj.getPatientName().equals(patientName.trim())
                && fixedMetadataObj.getPatientDateOfBirth().equals(patientDateOfBirth.trim())
                && fixedMetadataObj.getRecipientName().equals(recipientName.trim())
                && fixedMetadataObj.getApplicationPassThru().equals(passThruData.trim())
                && fixedMetadataObj.getCheckAmount().equals(checkAmount.trim())
                && fixedMetadataObj.getCheckNumber().equals(checkNumber.trim())
                && fixedMetadataObj.getSubCategory().equals(subCategory.trim())
                && fixedMetadataObj.getCategory().equals(category.trim())
                && fixedMetadataObj.getRecipientAddressLine1().equals(recipientAddressLine1.trim())
                && fixedMetadataObj.getRecipientAddressLine2().equals(recipientAddressLine2.trim())
                && fixedMetadataObj.getRecipientAddressLine3().equals(recipientCity.trim())
                && fixedMetadataObj.getRecipientAddressLine4().equals(recipientState.trim())
                && fixedMetadataObj.getRecipientAddressLine5().equals(recipientZip.trim())
                && fixedMetadataObj.getConfigKey().equals(configKey.trim())
                && fixedMetadataObj.getEmailAddress().equals(emailAddress.trim())
                && fixedMetadataObj.getEdeliveryError().equals(edeliveryError.trim())
                && fixedMetadataObj.getOriginalPrintTrail().equals(ORIGINAL_PRINT_TRAIL.trim())
                && fixedMetadataObj.getFileName().equals(fileName.trim())) {
            return true;
        }
        return false;
    }

    public static DocumentMetaData getDocumentMetaConfigKeyForUnetRecord() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId(TEST_DUMMY_DOCUMENT_ID);
        dmd.setSpaceId(Integer.parseInt(TEST_DUMMY_SPACE_ID));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt(TEST_DUMMY_CLIENT_ID));
        dmd.setAppIdentifier(TEST_DUMMY_IDENTIFIER);
        dmd.setTransactionId(TEST_DUMMY_TRANSACTION_ID);
        Document metadataObj = Document.parse("{ " +
                "\"tagLine\" : \"tagLine value\", " +
                "\"providerId\" : \"providerId value\", " +
                "\"mpin\" : \"000006294\", " +
                "\"tin\" : \"200094270\",\n" +
                "\"patientFirstName\" : \"PAMELA\", " +
                "\"patientLastName\" : \"FERNANDO\", " +
                "\"patientDateOfBirth\" : \"2000-12-03T04:06:31Z\", " +
                "\"recipientFirstName\" : \"SAM\", " +
                "\"recipientLastName\" : \"SNOW\", " +
                "\"PassThruData\" : \"223315_335888\", " +
                "\"CheckAmt\" : \"checkAmtValue\",\n" +
                "\"CheckTraceNumber\" : \"checkNumValue\",\n" +
                "\"templateNameOrId\" : \"templateNameOrId value\", " +
                "\"documentIdentifier\" : \"docIdValue\",\n" +
                "\"recipientDob\" : \"1999-12-03T04:06:31Z\", " +
                "\"privacyIndicator\" : \"1\", " +
                "\"MailToAddress1\" : \"ALLINA HEALTH UNITED WOMENS HEALTH CLINI    \", " +
                "\"MailToAddress2\" : \"347 SMITH AVE N STE 203\", " +
                "\"MailToAddress3\" : \"USA\", " +
                "\"MailToAddress4\" : \"SAINT PAUL\", " +
                "\"MailToAddress5\" : \"MN\", " +
                "\"MailToAddress6\" : \"55102\", " +
                "\"ConfigKey\" : \"ConfigKey unet\", " +
                "\"eDeliveryError\":\"Missing or invalid data: email address\"," +
                "\"createApplication\":\"elgs\"" +
                "\"originalCompanionFileRecords\" : [ \"\n\"\"145ZAAPIU00000901|MSP|70219-916698066-00|DOE2, JOHN K.                 |42069144-01|PRA|COSMOS \" ,\" \n\"\"145ZAAPIU00000303|MSP|80270-937666557-00|DOE4, JOHN J.                 |42069149-01|PRA|COSMOS \" " +
                "]" +
                "}");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("companionSample.txt");

        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);
        return dmd;
    }


}