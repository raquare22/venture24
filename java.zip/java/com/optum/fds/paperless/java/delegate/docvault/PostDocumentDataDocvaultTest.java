package com.optum.fds.paperless.java.delegate.docvault;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.startsWith;
import static org.hamcrest.collection.IsMapContaining.hasKey;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Map.Entry;

import com.optum.fds.paperless.util.HookTransaction;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.Answer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.document.response.util.DocumentResponseService;
import com.optum.fds.paperless.document.response.util.DocumentResponseUtil;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.DocvaultTransactionService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.java.delegate.DelegateExecutionImpl;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.mongo.AttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.DocvaultTransaction;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.HookTransactionUtil;


public class PostDocumentDataDocvaultTest {
	
	private final String PATH_JSON_FILE = "PostDocumentDataDocvault/InputExampleJson.json";
	private final String PATH_JSON_FILE_WITHOUT_ATTACHMENT = "PostDocumentDataDocvault/InputExampleJsonWithoutAttachment.json";
    private final String PATH_JSON_FILE_DOC360 = "PostDocumentDataDocvault/InputExampleJsonDoc360.json";


    @Mock
    RestTemplate restTemplate;
    
    @Mock
    HookService hookService;

    @Mock
    HookTransaction hookTransactionMock;
    
    @Mock
    OauthManagerUtil oauthManagerUtil;
    
    @Mock
	private DocumentMetaDataService documentMetaDataService;

    @Mock
    private EhCache ehCache;

    @InjectMocks
    PostDocumentDataDocvault postDocumentDataDocvault;


    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    DelegateExecution execution = new DelegateExecutionImpl();
    
    private static final String APP_ID = "testapp";
	private static final String APP_SECRET = "testapp";
	private static final String ACCESS_TOKEN = "abc123";
	private static final String URL = "http://test.com";
	private static final Integer EXPIRES_IN = 1800;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        HookTransaction hookTransaction = new HookTransaction();
        execution.setVariable(Workflow.BATCH_SIZE, 100);

        ReflectionTestUtils.setField(postDocumentDataDocvault, "hookTransaction", hookTransaction);
        ReflectionTestUtils.setField(postDocumentDataDocvault, "DOCLIB_TPS", 20);

        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID, APP_SECRET);
		oauthTokenExtended.setUrl(URL);
		oauthTokenExtended.setAccessToken(ACCESS_TOKEN);
		oauthTokenExtended.setExpiresIn(EXPIRES_IN);
		oauthTokenExtended.setObtainedOn(new Date());
		Optional<OauthTokenExtended> optionalToken = Optional.of(oauthTokenExtended);
		when(oauthManagerUtil.getOauthTokenExtended(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), isNull())).thenReturn(optionalToken);


        when(hookService.updateHookTransaction(Mockito.any())).thenReturn(new HookTransactionMetaData());

        doNothing().when(hookTransactionMock).updateHookTransaction(Mockito.any(), Mockito.any(), Mockito.any());

		try (MockedStatic<EhCache> cacheMock = Mockito.mockStatic(EhCache.class)) {
			cacheMock.when(() -> ehCache.putOauthTokenWithExpiry(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenAnswer((Answer<Void>) invocation -> null);
        }
	
		
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testDocumentMissing() throws Exception {
        ResponseEntity<Object> response = new ResponseEntity<>("trial", new HttpHeaders(), HttpStatus.OK);
        when(restTemplate.postForEntity(anyString(), any(), any()))
            .thenReturn(response);
        execution.setVariable(Workflow.DOCLIB_OAUTH_URL, "https://api-gateway.linkhealth.com/oauth/token%22");
		execution.setVariable(Workflow.DOCLIB_CLIENT_ID, "doclib-fds-prod");
		execution.setVariable(Workflow.DOCLIB_CLIENT_SECRET, "efbc8525-bd34-43e9-8f13-0bdf86feea0a");
        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate());
        execution.setVariable(Workflow.SLA_TIME, 2);
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");

        postDocumentDataDocvault.execute(execution);
        Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
        System.out.println(errorMap);
        assertTrue(errorMap.size() > 0);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testWithDocument() throws Exception {
    	ResponseEntity<Object> response = new ResponseEntity<>("{\n" + 
    			"    \"metadata\": {\n" + 
    			"        \"total\": \"1\",\n" + 
    			"        \"success\": \"1\",\n" + 
    			"        \"failure\": \"0\"\n" + 
    			"    }\n" + 
    			"}", new HttpHeaders(), HttpStatus.OK);
        when(restTemplate.postForEntity(anyString(), any(), any()))
            .thenReturn(response);
        
        when (documentMetaDataService.saveDocumentMetaDataMulti(Mockito.any(), Mockito.any())).thenReturn(0L);
        DelegateExecution execution = new DelegateExecutionImpl();	
        
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.HOOK_TRANSACTION_METADATA, getHookTransactionMetaData());
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.DOCLIB_OAUTH_URL, "https://api-gateway.linkhealth.com/oauth/token%22");
		execution.setVariable(Workflow.DOCLIB_CLIENT_ID, "doclib-fds-prod");
		execution.setVariable(Workflow.DOCLIB_CLIENT_SECRET, "efbc8525-bd34-43e9-8f13-0bdf86feea0a");
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        execution.setVariable(Workflow.SLA_TIME, 2);
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.DOCUMENT_IDS_MESSAGE, "test");
        execution.setVariable(Workflow.DOCLIB_REST_URL, "http://testHost/path");
        
        
        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate());
        
        postDocumentDataDocvault.execute(execution);
		
		List<DocumentMetaData> successDocumentList = (List<DocumentMetaData>)
		execution.getVariable("successDocumentList");
		Assert.assertNotNull(successDocumentList);
		 
    }

    @Test
    public void testWithDocumentDoc360() throws Exception {
        ResponseEntity<Object> response = new ResponseEntity<>("{\n" +
                "    \"metadata\": {\n" +
                "        \"total\": \"1\",\n" +
                "        \"success\": \"1\",\n" +
                "        \"failure\": \"0\"\n" +
                "    }\n" +
                "}", new HttpHeaders(), HttpStatus.OK);
        when(restTemplate.postForEntity(anyString(), any(), any()))
                .thenReturn(response);

        when (documentMetaDataService.saveDocumentMetaDataMulti(Mockito.any(), Mockito.any())).thenReturn(0L);
        DelegateExecution execution = new DelegateExecutionImpl();

        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE_DOC360).getAbsolutePath();
        execution.setVariable(Workflow.HOOK_TRANSACTION_METADATA, getHookTransactionMetaData());
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.DOCLIB_OAUTH_URL, "https://api-gateway.linkhealth.com/oauth/token%22");
        execution.setVariable(Workflow.DOCLIB_CLIENT_ID, "doclib-fds-prod");
        execution.setVariable(Workflow.DOCLIB_CLIENT_SECRET, "efbc8525-bd34-43e9-8f13-0bdf86feea0a");
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        execution.setVariable(Workflow.SLA_TIME, 2);
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.DOCUMENT_IDS_MESSAGE, "test");
        execution.setVariable(Workflow.DOCLIB_REST_URL, "http://testHost/path");


        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate());

        postDocumentDataDocvault.execute(execution);

        List<DocumentMetaData> successDocumentList = (List<DocumentMetaData>)
                execution.getVariable("successDocumentList");
        Assert.assertNotNull(successDocumentList);

    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void testWithoutAttachments() throws Exception {
    	ResponseEntity<Object> response = new ResponseEntity<>("{\n" + 
    			"    \"metadata\": {\n" + 
    			"        \"total\": \"1\",\n" + 
    			"        \"success\": \"1\",\n" + 
    			"        \"failure\": \"0\"\n" + 
    			"    }\n" + 
    			"}", new HttpHeaders(), HttpStatus.OK);
        when(restTemplate.postForEntity(anyString(), any(), any()))
            .thenReturn(response);
        DelegateExecution execution = new DelegateExecutionImpl();	
        
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE_WITHOUT_ATTACHMENT).getAbsolutePath();
        execution.setVariable(Workflow.HOOK_TRANSACTION_METADATA, getHookTransactionMetaData());
        execution.setVariable(Workflow.DOCLIB_OAUTH_URL, "https://api-gateway.linkhealth.com/oauth/token%22");
		execution.setVariable(Workflow.DOCLIB_CLIENT_ID, "doclib-fds-prod");
		execution.setVariable(Workflow.DOCLIB_CLIENT_SECRET, "efbc8525-bd34-43e9-8f13-0bdf86feea0a");
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        execution.setVariable(Workflow.SLA_TIME, 2);
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.DOCUMENT_IDS_MESSAGE, "test");
        execution.setVariable(Workflow.DOCLIB_REST_URL, "http://testHost/path");
        
        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate());
        
        postDocumentDataDocvault.execute(execution);
		
		  List<DocumentMetaData> failureDocumentList = (List<DocumentMetaData>)
		  execution.getVariable("failureDocumentList");
		  Assert.assertNotNull(failureDocumentList);
		 
    }

    @Test
    public void testWithDocumentWith400Response() throws Exception {
        ResponseEntity<Object> response = new ResponseEntity<>("Error response", new HttpHeaders(), HttpStatus.BAD_REQUEST);
        when(restTemplate.postForEntity(anyString(), any(), any()))
            .thenReturn(response);
        
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        execution.setVariable(Workflow.DOCLIB_OAUTH_URL, "https://api-gateway.linkhealth.com/oauth/token%22");
		execution.setVariable(Workflow.DOCLIB_CLIENT_ID, "doclib-fds-prod");
		execution.setVariable(Workflow.DOCLIB_CLIENT_SECRET, "efbc8525-bd34-43e9-8f13-0bdf86feea0a");
        execution.setVariable(Workflow.SLA_TIME, 2);
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.DOCUMENT_IDS_MESSAGE, "test");
        execution.setVariable(Workflow.DOCLIB_REST_URL, "http://testHost/path");
        
        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate());
        postDocumentDataDocvault.execute(execution);

        List<DocumentMetaData> docList = (List<DocumentMetaData>)
                execution.getVariable("failureDocumentList");
        Assert.assertNotNull(docList);

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testWithRestClientException() throws Exception {
        doThrow(RestClientException.class).when(restTemplate).postForEntity(anyString(), any(), any());
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.DOCUMENT_IDS_MESSAGE, "test");
        execution.setVariable(Workflow.DOCLIB_REST_URL, "http://testHost/path");
        execution.setVariable(Workflow.SLA_TIME, 2);
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.DOCLIB_OAUTH_URL, "https://api-gateway.linkhealth.com/oauth/token%22");
		execution.setVariable(Workflow.DOCLIB_CLIENT_ID, "doclib-fds-prod");
		execution.setVariable(Workflow.DOCLIB_CLIENT_SECRET, "efbc8525-bd34-43e9-8f13-0bdf86feea0a");
        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate());
        execution.setVariable(Workflow.DOCUMENT, buildDocumentMetaDataToPost());
        execution.setVariable(Workflow.REST_URI, "http://testHost/path");
        postDocumentDataDocvault.execute(execution);
        Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
//        assertThat("RestClientException not Logged", errorMap, hasKey("RestClientException"));

        List<DocumentMetaData> docList = (List<DocumentMetaData>)
                execution.getVariable("failureDocumentList");
        Assert.assertNotNull(docList);
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void testWith401UnauthorizedException() throws Exception {
    	
    	HttpClientErrorException http = HttpClientErrorException.Unauthorized.create(HttpStatus.UNAUTHORIZED, null, null, null, null);
    	
        doThrow(http).when(restTemplate).postForEntity(anyString(), any(), any());

        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.DOCUMENT_IDS_MESSAGE, "test");
        execution.setVariable(Workflow.DOCLIB_REST_URL, "http://testHost/path");
        execution.setVariable(Workflow.SLA_TIME, 2);
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.DOCLIB_OAUTH_URL, "https://api-gateway.linkhealth.com/oauth/token%22");
		execution.setVariable(Workflow.DOCLIB_CLIENT_ID, "doclib-fds-prod");
		execution.setVariable(Workflow.DOCLIB_CLIENT_SECRET, "efbc8525-bd34-43e9-8f13-0bdf86feea0a");
        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate());
        execution.setVariable(Workflow.DOCUMENT, buildDocumentMetaDataToPost());
        execution.setVariable(Workflow.REST_URI, "http://testHost/path");
        postDocumentDataDocvault.execute(execution);
        Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
//        assertThat("RestClientException not Logged", errorMap, hasKey("RestClientException"));
        List<DocumentMetaData> docList = (List<DocumentMetaData>)
                execution.getVariable("failureDocumentList");
        Assert.assertNotNull(docList);
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void testWithBadRequestException() throws Exception {
    	
    	HttpClientErrorException http = HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST, null, null, null, null);
    	
        doThrow(http).when(restTemplate).postForEntity(anyString(), any(), any());

        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.DOCUMENT_IDS_MESSAGE, "test");
        execution.setVariable(Workflow.DOCLIB_REST_URL, "http://testHost/path");
        execution.setVariable(Workflow.SLA_TIME, 2);
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.DOCLIB_OAUTH_URL, "https://api-gateway.linkhealth.com/oauth/token%22");
		execution.setVariable(Workflow.DOCLIB_CLIENT_ID, "doclib-fds-prod");
		execution.setVariable(Workflow.DOCLIB_CLIENT_SECRET, "efbc8525-bd34-43e9-8f13-0bdf86feea0a");
        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate());
        execution.setVariable(Workflow.DOCUMENT, buildDocumentMetaDataToPost());
        execution.setVariable(Workflow.REST_URI, "http://testHost/path");
        postDocumentDataDocvault.execute(execution);
        Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
        assertEquals(1, errorMap.size());

        List<DocumentMetaData> docList = (List<DocumentMetaData>)
                execution.getVariable("failureDocumentList");
        Assert.assertNotNull(docList);
    }

    @SuppressWarnings("unchecked")
//	    @Test
    public void testWithRestIOException() throws Exception {
        when(DocumentResponseUtil.buildDocumentResponseInJson(any() ,any())).thenThrow(IOException.class);
        DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
        
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.DOCUMENT_IDS_MESSAGE, "test");
        execution.setVariable(Workflow.DOCLIB_REST_URL, "http://testHost/path");
        execution.setVariable(Workflow.DOCLIB_OAUTH_URL, "https://api-gateway.linkhealth.com/oauth/token%22");
		execution.setVariable(Workflow.DOCLIB_CLIENT_ID, "doclib-fds-prod");
		execution.setVariable(Workflow.DOCLIB_CLIENT_SECRET, "efbc8525-bd34-43e9-8f13-0bdf86feea0a");
        execution.setVariable(Workflow.SLA_TIME, 2);
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate());
        execution.setVariable(Workflow.DOCUMENT, buildDocumentMetaDataToPost());
        execution.setVariable(Workflow.REST_URI, "http://testHost/path");
        postDocumentDataDocvault.execute(execution);
        Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
        for (Entry<String, Object> entry : errorMap.entrySet()) {
            System.out.println(entry.getKey() + " -- " + entry.getValue());
        }
        assertThat("IOException not Logged", errorMap, hasKey("IOException"));
    }

    @SuppressWarnings("unchecked")
//	    @Test
    public void testWithServiceException() throws Exception {
        DelegateExecution execution = new DelegateExecutionImpl(new HashMap());
        
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.DOCUMENT_IDS_MESSAGE, "test");
        execution.setVariable(Workflow.DOCLIB_REST_URL, "http://testHost/path");
        execution.setVariable(Workflow.DOCLIB_OAUTH_URL, "https://api-gateway.linkhealth.com/oauth/token%22");
		execution.setVariable(Workflow.DOCLIB_CLIENT_ID, "doclib-fds-prod");
		execution.setVariable(Workflow.DOCLIB_CLIENT_SECRET, "efbc8525-bd34-43e9-8f13-0bdf86feea0a");
        execution.setVariable(Workflow.SLA_TIME, 2);
        execution.setVariable(Workflow.REST_ACCESS_TOKEN, "12345");
        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate());
        execution.setVariable(Workflow.DOCUMENT, buildDocumentMetaDataToPost());
        execution.setVariable(Workflow.REST_URI, "http://testHost/path");
        postDocumentDataDocvault.execute(execution);
        Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
  //      assertThat("ServiceException not Logged", errorMap, hasKey("ServiceException"));
    }

    @Test
    public void testCheckShutterflyCriteria() {
    	
    	DocumentMetaData doc1 = getDocumentMetaData();
    	DocumentMetaData doc2 = getDocumentMetaData();
    	doc2.getMetadata().put("emailAlertReq", "N");
    	
    	assertTrue(postDocumentDataDocvault.checkShutterflyCriteria(buildDocumentMetaDataToPost(), 2));
    	assertTrue(postDocumentDataDocvault.checkShutterflyCriteria(doc1, 2));
    	assertFalse(postDocumentDataDocvault.checkShutterflyCriteria(doc2, 2));
    }
    
    private HookTransactionMetaData getHookTransactionMetaData() {
    	var hookExecutionRecord = new HashMap<>(Map.of(
                Workflow.SPACE_ID, "123",
                Workflow.HOOK_ID, "123",
                Workflow.APP_IDENTIFIER, "123",
                Workflow.CLIENTID, "123"
        ));
    	var hookExecutionMessage = new HashMap<>(Map.of(
				"test", "test"
        ));
		var hookExecutionRecordMetaData = HookTransactionUtil
				.getHookExecutionRecord(hookExecutionRecord, hookExecutionMessage, "process_key");
		return HookTransactionUtil.createCronHookTransaction(hookExecutionRecordMetaData);
    }

    private DocumentMetaData buildDocumentMetaDataToPost() {
        DocumentMetaData docMetaData = new DocumentMetaData();
        docMetaData.setId("1234");
        docMetaData.setParentId("1");
        docMetaData.setClientId(684);
        docMetaData.setSpaceId(2804);
        docMetaData.setAppIdentifier("testApp");
        docMetaData.setStatus("ACTIVE");
        docMetaData.setDateCreated(new Date(1642662046076L));

        String TransId =docMetaData.getTransactionId();
        org.bson.Document metadataJson = new org.bson.Document();
        metadataJson.put("fileName","abc");
        metadataJson.put("category", "Claim");
        metadataJson.put("corporateMpin", "001322130");
        metadataJson.put("createApplication", "ELGS");
        metadataJson.put("createdDate", "2019-01-08T08:57:05.000-05:00");
        metadataJson.put("expiryDate", "2019-11-13T08:57:05.000-05:00");
        metadataJson.put("fileDescription", "Sample report");
        metadataJson.put("filePath", "Claim Reports/Universal Letters");
        metadataJson.put("fileType", "Report");
        metadataJson.put("privilege", "Claim Adjustment");
        metadataJson.put("subCategory", "Reports");
        metadataJson.put("tenant", "Link");
        metadataJson.put("tin", "99123312");
        metadataJson.put("mpin", "1234");
        metadataJson.put("memberId", "12389");
        metadataJson.put("claimNumber", "Ad123");
        metadataJson.put("organization", "optum");
        metadataJson.put("emailAlertReq", "Y");
        metadataJson.put("frequency", "3");
        metadataJson.put("weekDay", "M");
        metadataJson.put("notificationNumber","76");
        metadataJson.put("CheckTraceNumber", "56");
        metadataJson.put("physicianName", "Brooke Fisher");
        DocumentAttachmentMetaData documentAttachment = new DocumentAttachmentMetaData();
        documentAttachment.setFsId("3934-afdk-e083420j");
        documentAttachment.setIndex(1);
        documentAttachment.setName("my_report.pdf");


        List<DocumentAttachmentMetaData> attachments = new ArrayList<>();
        attachments.add(documentAttachment);

        docMetaData.setDocumentAttachments(attachments);
        docMetaData.setMetadata(metadataJson);
        docMetaData.setTransactionId("0bc09b5f-a2f6-4ef0-9139-c039e75aa269");
        return docMetaData;
    }
    
    
    private DocumentMetaData getDocumentMetaData() {
        DocumentMetaData docMetaData = new DocumentMetaData();
        docMetaData.setId("1234");
        docMetaData.setParentId("1");
        docMetaData.setClientId(684);
        docMetaData.setSpaceId(2804);
        docMetaData.setAppIdentifier("testApp");
        docMetaData.setStatus("ACTIVE");
        docMetaData.setDateCreated(new Date(1662662046076L));

        String TransId =docMetaData.getTransactionId();
        org.bson.Document metadataJson = new org.bson.Document();
        metadataJson.put("fileName","abc");
        metadataJson.put("category", "Claim");
        metadataJson.put("emailAlertReq", "Y");
        metadataJson.put("physicianName", "Brooke Fisher");
        DocumentAttachmentMetaData documentAttachment = new DocumentAttachmentMetaData();
        documentAttachment.setFsId("3934-afdk-e083420j");
        documentAttachment.setIndex(1);
        documentAttachment.setName("my_report.pdf");


        List<DocumentAttachmentMetaData> attachments = new ArrayList<>();
        attachments.add(documentAttachment);

        docMetaData.setDocumentAttachments(attachments);
        docMetaData.setMetadata(metadataJson);
        docMetaData.setTransactionId("0bc09b5f-a2f6-4ef0-9139-c039e75aa269");
        return docMetaData;
    }

}
