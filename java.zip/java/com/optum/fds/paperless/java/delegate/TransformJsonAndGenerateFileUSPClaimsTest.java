package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.*;

import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.service.EmailService;
import org.mockito.stubbing.Answer;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.lang.reflect.Method;
import java.util.*;

public class TransformJsonAndGenerateFileUSPClaimsTest {

    @InjectMocks
    private TransformJsonAndGenerateFileUSPClaims transformJsonAndGenerateFileUSPClaims;

    @Mock
    private ProcessorService processorService;

    @Mock
    private ProcessorFileTaskService processorFileTaskService;

    @Mock
    private ProcessorsService processorsService;

    @Mock
    private EmailService emailService;

    @Rule
    public TemporaryFolder folder = new TemporaryFolder();

    private DelegateExecution execution = new DelegateExecutionImpl();
    private final String PATH_JSON_FILE = "InputJson/TransformJsonAndGenerateFileUSPClaimsTest.json";

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testDoExecute() throws Exception {
        Set<String> zipFiles = new HashSet<>();

        zipFiles.add("zipfile1.zip");
        zipFiles.add("zipfile2.zip");

        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "addedToResponseFile");
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, true);
        execution.setVariable(Workflow.TEMPLATE_NAME, "USPClaimsResponse");
        execution.setVariable("setofZipFile", zipFiles);
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, folder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.SFTP_FILENAME, "FDS_Response");

        transformJsonAndGenerateFileUSPClaims.execute(execution);

        List<DocumentMetaData> updatedList = execution.getVariable("updatedDocumentMetadataList", List.class);
        Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
        assertNotNull(errorMap);

        List<String> successDocumentList = execution.getVariable("successDocumentList", List.class);
        assertTrue(successDocumentList.size() > 0);

        assertFalse(execution.getVariable("responseFileNameUSPClaims", Map.class).isEmpty());

    }

    @Test
    public void testDoExecuteInvalidJsonFile() throws Exception {
        Set<String> zipFiles = new HashSet<>();

        zipFiles.add("zipfile1.zip");
        zipFiles.add("zipfile2.zip");

        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "addedToResponseFile");
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, true);
        execution.setVariable(Workflow.TEMPLATE_NAME, "USPClaimsResponse");
        execution.setVariable("setofZipFile", zipFiles);
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile + "invalid");
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, folder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.SFTP_FILENAME, "FDS_Response");

        transformJsonAndGenerateFileUSPClaims.execute(execution);

        Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
        assertNotNull(errorMap);
        assertEquals(1, errorMap.get("newErrors"));

    }

    @Test
    public void testDateCasting() {
        Long timestamp = 1672531200000L; // Example timestamp
        String result = transformJsonAndGenerateFileUSPClaims.dateCasting(timestamp);
        assertNotNull(result);
        assertTrue(result.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z"));
    }

    @Test
    public void testIsDataFieldLong() {
        assertTrue(transformJsonAndGenerateFileUSPClaims.isDataFieldLong(123456789L));
        assertFalse(transformJsonAndGenerateFileUSPClaims.isDataFieldLong(123.45));
        assertFalse(transformJsonAndGenerateFileUSPClaims.isDataFieldLong("123456789"));
    }

    @Test
    public void testIsDataFieldDouble() {
        assertTrue(transformJsonAndGenerateFileUSPClaims.isDataFieldDouble(123.45));
        assertFalse(transformJsonAndGenerateFileUSPClaims.isDataFieldDouble(123456789L));
        assertFalse(transformJsonAndGenerateFileUSPClaims.isDataFieldDouble("123.45"));
    }

    @Test
    public void testGetFilePathUsingReflection() throws Exception {
        Method method = TransformJsonAndGenerateFileUSPClaims.class.getDeclaredMethod(
                "getFilePath", String.class, String.class, String.class
        );
        method.setAccessible(true);

        String tempWorkingPath = "/tmp";
        String sftpFileName = "testFile";
        String zipFile = "testZip.zip";

        String result = (String) method.invoke(transformJsonAndGenerateFileUSPClaims, tempWorkingPath, sftpFileName, zipFile);
        assertNotNull(result);
        assertTrue(result.startsWith(tempWorkingPath));
        assertTrue(result.endsWith(".xml"));
    }

}