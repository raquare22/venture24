package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;

import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import java.text.SimpleDateFormat;
import java.util.*;

import static org.junit.Assert.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class UpdateDocumentListInMongoTest {

    private final String PATH_JSON_FILE = "TransformJsonAndGenerateFile/InputJsonExample.json";

    @Mock
    EmailService emailService;

    @InjectMocks
    UpdateDocumentListInMongo updateDocumentListInMongo;

    DelegateExecution execution;

    @Mock
    DocumentMetaDataService documentMetaDataService;
    
    @Mock
    ErrorMetaDataService errorMetaDataService;

    @Mock
    WorkFlowUtil workFlowUtil;

    @Before
    public void init() {
        MockitoAnnotations.openMocks(this);

        execution = new DelegateExecutionImpl();

        when(documentMetaDataService.saveDocumentMetaData(any())).thenReturn(new DocumentMetaData());
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "addedToResponseFile");
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, true);
        execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, getDocumentMetaDataList(new Date()));

        when(errorMetaDataService.writeToErrorCollection(any(), any())).thenReturn(new ErrorMetaData());
    }

    @Test
    public void testDoExecute() {
        updateDocumentListInMongo.execute(execution);
        assertNotNull(updateDocumentListInMongo.errorMap);
        assertEquals(0, updateDocumentListInMongo.errorMap.get(Workflow.NEW_ERRORS));

        var list = (List<DocumentMetaData>) execution.getVariable(Workflow.LIST_DOCUMENT_METADATA);
        assertNotNull(list);
        for (DocumentMetaData doc : list) {
            assertNotNull(doc.getMetadata().get("addedToResponseFile"));
        }
    }

    @Test
    public void testDocumentFormatFieldDouble() {
        execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, getDocumentMetaDataList(1604011500000.0));
        execution.setVariable(Workflow.DOCUMENT_FORMAT_FIELD, "dateEmailSent");

        updateDocumentListInMongo.execute(execution);
        assertNotNull(updateDocumentListInMongo.errorMap);
        assertEquals(0, updateDocumentListInMongo.errorMap.get(Workflow.NEW_ERRORS));

        var list = (List<DocumentMetaData>) execution.getVariable(Workflow.LIST_DOCUMENT_METADATA);
        assertNotNull(list);
        for (DocumentMetaData doc : list) {
            assertNotNull(doc.getMetadata().get("addedToResponseFile"));
//            assertEquals("2020-10-30T04:15:00.000Z", doc.getMetadata().get("dateEmailSent"));
        }
    }

    @Test
    public void testDocumentFormatFieldLong() {
        execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, getDocumentMetaDataList(1604011500000L));
        execution.setVariable(Workflow.DOCUMENT_FORMAT_FIELD, "dateEmailSent");

        updateDocumentListInMongo.execute(execution);
        assertNotNull(updateDocumentListInMongo.errorMap);
        assertEquals(0, updateDocumentListInMongo.errorMap.get(Workflow.NEW_ERRORS));

        var list = (List<DocumentMetaData>) execution.getVariable(Workflow.LIST_DOCUMENT_METADATA);
        assertNotNull(list);
        for (DocumentMetaData doc : list) {
            assertNotNull(doc.getMetadata().get("addedToResponseFile"));
//            assertEquals("2020-10-30T04:15:00.000Z", doc.getMetadata().get("dateEmailSent"));
        }
    }

    @Test
    public void testDocumentFormatFieldNull() {
        execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, getDocumentMetaDataList(null));
        execution.setVariable(Workflow.DOCUMENT_FORMAT_FIELD, "dateEmailSent");

        updateDocumentListInMongo.execute(execution);
        assertNotNull(updateDocumentListInMongo.errorMap);
        assertEquals(0, updateDocumentListInMongo.errorMap.get(Workflow.NEW_ERRORS));


        var list = (List<DocumentMetaData>) execution.getVariable(Workflow.LIST_DOCUMENT_METADATA);
        assertNotNull(list);
        for (DocumentMetaData doc : list) {
            assertNotNull(doc.getMetadata().get("addedToResponseFile"));
            assertNull(doc.getMetadata().get("dateEmailSent"));
        }
    }

    @Test
    public void testDocumentFormatFieldString() {

        execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, getDocumentMetaDataList("2020-09-01T13:30:07.990Z"));
        execution.setVariable(Workflow.DOCUMENT_FORMAT_FIELD, "dateEmailSent");

        updateDocumentListInMongo.execute(execution);
        assertNotNull(updateDocumentListInMongo.errorMap);
        assertEquals(0, updateDocumentListInMongo.errorMap.get(Workflow.NEW_ERRORS));

        var list = (List<DocumentMetaData>) execution.getVariable(Workflow.LIST_DOCUMENT_METADATA);
        assertNotNull(list);
        for (DocumentMetaData doc : list) {
            assertNotNull(doc.getMetadata().get("addedToResponseFile"));
            assertEquals("2020-09-01T13:30:07.990Z", doc.getMetadata().get("dateEmailSent"));
        }
    }

    @Test
    public void testMultiDocumentUpdate() {
        Map<String, Object> updateMap = new HashMap<String, Object>();
        updateMap.put("metadata.docLibAPIResponse", true);

        List<String> docList = new ArrayList<String>();
        docList.add("123456");
        docList.add("1234567");

        execution.setVariable("successDocumentList", docList);
        execution.setVariable("successUpdateMap", updateMap);
        execution.setVariable("failureDocumentList", docList);
        execution.setVariable("failureUpdateMap", updateMap);
        execution.setVariable("responseFileName", "responseFileName.txt");
        execution.setVariable(Workflow.DOCUMENT_FORMAT_FIELD, "dateEmailSent");

        long count = 2L;
        when(documentMetaDataService.saveDocumentMetaDataMulti(any(), any())).thenReturn(count);

        updateDocumentListInMongo.execute(execution);
        assertNotNull(updateDocumentListInMongo.errorMap);
        assertEquals(0, updateDocumentListInMongo.errorMap.get(Workflow.NEW_ERRORS));

    }

    @Test
    public void testNullDocList() {
        execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, null);
        updateDocumentListInMongo.execute(execution);
        assertNotNull(updateDocumentListInMongo.errorMap);
        assertEquals(1, updateDocumentListInMongo.errorMap.get(Workflow.NEW_ERRORS));
    }

    @Test
    public void testEmptyDocList() {
    	 execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, null);
        updateDocumentListInMongo.execute(execution);
        assertNotNull(updateDocumentListInMongo.errorMap);
        assertEquals(1, updateDocumentListInMongo.errorMap.get(Workflow.NEW_ERRORS));
    }
    
    @Test
    public void testUpdateDocumentsInDocumentMetaDataList()
    {
    	List<DocumentMetaData> docList = new ArrayList<>();
    	DocumentMetaData docOne = new DocumentMetaData();
    	docList.add(docOne);
    	ReflectionTestUtils.invokeMethod(updateDocumentListInMongo,"updateDocumentsInDocumentMetaDataList", docList);
    }
    
    @Test
    public void testDoExecuteThrowsException() {
    	ExpectedException thrown = ExpectedException.none();
        thrown.expect(Exception.class);
        thrown.expectMessage("An exception occured");
        thrown.isAnyExceptionExpected();
        execution.setVariable(Workflow.LIST_DOCUMENT_METADATA, null);
        execution.setVariable(Workflow.HOOK_TRANSACTION_METADATA, "26535");
        updateDocumentListInMongo.execute(execution);
    }
    
    @Test
    public void testExtractDataFieldWithDateType() {
    	Date date = new Date();
    	String field = "dateEmailSent";
    	SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
    	DocumentMetaData docmentMetadata = getDocumentMetaData(date);
    	ReflectionTestUtils.invokeMethod(updateDocumentListInMongo,"extractDataField", field, formatter, docmentMetadata, execution);
    }
    
    @Test
    public void testExtractDataFieldWithDateTypeAndException() {
    	Date date = new Date();
    	String field = "dateEmailSent";
    	SimpleDateFormat formatter = null;
    	DocumentMetaData docmentMetadata = getDocumentMetaData(date);
    	ReflectionTestUtils.invokeMethod(updateDocumentListInMongo,"extractDataField", field, formatter, docmentMetadata, execution);
    }


    private List<DocumentMetaData> getDocumentMetaDataList(Object date) {
        List<DocumentMetaData> list = new ArrayList<>();
        DocumentMetaData doc1 = getDocumentMetaData(date);
        DocumentMetaData doc2 = getDocumentMetaData(date);
        list.add(doc1);
        list.add(doc2);
        return list;

    }

    private DocumentMetaData getDocumentMetaData(Object date) {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setId("id123");
        documentMetaData.setStatus(MetaDataStatus.ACTIVE);
        documentMetaData.setSpaceId(2804);
        documentMetaData.setExternalId("external1234");
        Document metadata = new Document();
        metadata.append("dateEmailSent", date);
        documentMetaData.setMetadata(metadata);
        return documentMetaData;
    }
}
