package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.FileSystemException;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang.StringUtils;
import org.bson.Document;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.Utilities;

@RunWith(MockitoJUnitRunner.class)

public class IdentifyShutterflyDocumentsTest {

	private static final int maxDocOccur = 100;
	private static final String fdsUrl = "https://testurl";
	private static final int clientId = 704;
	private static final String spaceId = "10102";
	private static final String appId = "d0g767pzqpkznfryzetenrcpt8ql2uxu";
	private static final String searchWindow = "{\"start_date_offset\":{\"time_window\":\"72\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"2\",\"format\":\"Hours\"}}";
	private static final String searchCriteria = "{\"spaceId\" : 20102, \"status\" : \"AVAILABLE\", \"metadata.rprntSentToSF\" : { \"$exists\" : false }, \"metadata.sendToShutterfly\" : true}";
	
	DelegateExecution execution;

	@InjectMocks
	IdentifyShutterflyDocuments identifyShutterflyDocuments;

	@Mock
	DocumentMetaDataService documentMetaDataService;
	
	@Mock
	private ConfigData config;

	@Mock
	RestTemplate restTemplate;

	@Mock
	OauthManagerUtil oauthManagerUtil;
	
	@Mock
    HookService hookService;
	
	@Mock
	private List<DocumentMetaData> listDocMetadata = new ArrayList<>();

	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();
	
	private int testSpaceId = 8897;
	
	private static final String APP_ID = "testapp";
	private static final String APP_SECRET = "testapp";
	private static final String ACCESS_TOKEN = "abc123";
	private static final String URL = "http://test.com";
	private static final Integer EXPIRES_IN = 1800;

	@SuppressWarnings("deprecation")
	@org.junit.Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		
		execution = new DelegateExecutionImpl(new HashMap());

		ReflectionTestUtils.setField(identifyShutterflyDocuments, "ingestRoot",  tempFolder.getRoot().getAbsolutePath());
		
		ReflectionTestUtils.setField(identifyShutterflyDocuments, "postCardOnlyClientList", "11502");

		execution.setVariable(Workflow.SEARCH_CRITERIA, searchCriteria);
		execution.setVariable(Workflow.SEARCH_WINDOW, searchWindow);			
		execution.setVariable(Workflow.MAX_DOCUMENTS_OCCURS, maxDocOccur);
		execution.setVariable(Workflow.APP_ID, appId);
		execution.setVariable(Workflow.SPACE_ID, spaceId);
		execution.setVariable(Workflow.CLIENT_ID, clientId);
		execution.setVariable(Workflow.FDS_CLOUD_GET_ATTACHMENT_URL, fdsUrl);
		execution.setVariable(Workflow.HOOK_ID, "1234");

		Map<String, Object> credsMap = new HashMap<>();
		credsMap.put("10102", "{\"fdsCloudSpaceId\": \"1234\"}");
		when(config.getCredentials(any())).thenReturn(credsMap);
		
	}

	// post card ind is false and the corpmpin is blank, should be true
	@Test
	public void checkLoadPDFTest() throws IOException {
		Document metadata = new Document();
		metadata.put(Workflow.POST_CARD_IND, false);
		metadata.put(Workflow.PROV_CORP_MPIN, "");
		boolean result = identifyShutterflyDocuments.checkLoadPDF(metadata, testSpaceId);
		assertTrue(result);
	}

	@Test
	public void checkLoadPDF2Test() throws IOException {
		Document metadata = new Document();
		metadata.put(Workflow.POST_CARD_IND, false);
		metadata.put(Workflow.PROVIDER_EMAIL_ID, "");
		boolean result = identifyShutterflyDocuments.checkLoadPDF(metadata, testSpaceId);
		assertTrue(result);
	}

	// post card is false but the emailid and corp mpin are present
	@Test
	public void checkLoadPDF3Test() throws IOException {
		Document metadata = new Document();
		metadata.put(Workflow.POST_CARD_IND, false);
		metadata.put(Workflow.PROVIDER_EMAIL_ID, "test@gmail.com");
		metadata.put(Workflow.PROV_CORP_MPIN, "test");
		metadata.put(Workflow.SUBCATEGORY, "X1");
		metadata.put(Workflow.MPIN, "test");
		metadata.put(Workflow.TIN, "test");
		boolean result = identifyShutterflyDocuments.checkLoadPDF(metadata, testSpaceId);
		assertFalse(result);
	}

	// post card ind is true and the corpmpin is blank, should be true
	@Test
	public void checkLoadPDFPostCardEmptyTest() throws IOException {

		Document metadata = new Document();
		metadata.put(Workflow.POST_CARD_IND, true);
		metadata.put(Workflow.PROV_CORP_MPIN, "");
		boolean result = identifyShutterflyDocuments.checkLoadPDF(metadata, testSpaceId);
		assertTrue(result);
	}

	// post card indicator is true and corpmpin is there, dont send doc should be
	// false
	@Test
	public void checkLoadPDFPostCardTest() throws IOException {
		Document metadata = new Document();
		metadata.put(Workflow.POST_CARD_IND, true);
		metadata.put(Workflow.PROV_CORP_MPIN, "present");
		metadata.put(Workflow.SUBCATEGORY, "X1");
		metadata.put(Workflow.MPIN, "test");
		metadata.put(Workflow.TIN, "test");
		boolean result = identifyShutterflyDocuments.checkLoadPDF(metadata, testSpaceId);
		assertFalse(result);
	}

	// post card indicator is true and corpmpin is not there, dont send doc should
	// be false
	@Test
	public void checkLoadPDFPostCard2Test() throws IOException {
		Document metadata = new Document();
		metadata.put(Workflow.POST_CARD_IND, true);
		metadata.put(Workflow.PROVIDER_EMAIL_ID, "present");
		boolean result = identifyShutterflyDocuments.checkLoadPDF(metadata, testSpaceId);
		assertTrue(result);
	}
	
	// if subCategory is missing, loadPDF = true
		@Test
		public void checkLoadPDFPostCardTest3() throws IOException {
			Document metadata = new Document();
			metadata.put(Workflow.POST_CARD_IND, true);
			metadata.put(Workflow.PROV_CORP_MPIN, "present");
			metadata.put(Workflow.SUBCATEGORY, "XX");
			metadata.put(Workflow.MPIN, "test");
			metadata.put(Workflow.TIN, "test");
			metadata.put(Workflow.PROVIDER_EMAIL_ID, "present");
			boolean result = identifyShutterflyDocuments.checkLoadPDF(metadata, testSpaceId);
			assertTrue(result);
		}

	@Test
	public void testDoExecute() throws Exception {
//		OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID, APP_SECRET);
//		oauthTokenExtended.setUrl(URL);
//		oauthTokenExtended.setAccessToken(ACCESS_TOKEN);
//		oauthTokenExtended.setExpiresIn(EXPIRES_IN);
//		oauthTokenExtended.setObtainedOn(new Date());
//		Optional<OauthTokenExtended> optionalToken = Optional.of(oauthTokenExtended);
//		when(oauthManagerUtil.getOauthTokenExtended(anyString(), anyString(), anyString(), anyString()))
//			.thenReturn(optionalToken);

		ArrayList<DocumentMetaData> list = new ArrayList<>();
        list.add(getDocumentMetaData());
        list.add(getDocumentMetaData2());  
		
		when(documentMetaDataService.getDocumentMetaData(anyString(), any(), anyInt())).thenReturn(list);

		DocumentAttachmentMetaData responseData = new DocumentAttachmentMetaData();
		responseData.setUrl("http:url.com");
		responseData.setUrlToken("12345");
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML_VALUE);
		ResponseEntity<DocumentAttachmentMetaData> response = new ResponseEntity<DocumentAttachmentMetaData>(responseData,
				headers,
				HttpStatus.OK);
		when(restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(), eq(DocumentAttachmentMetaData.class) )).thenReturn(response);

		ResponseEntity<byte[]> response2 = new ResponseEntity<>(getByteArray(), headers, HttpStatus.OK);
		when(restTemplate.exchange(any(URI.class), any(HttpMethod.class), any(), eq(byte[].class) )).thenReturn(response2);

		identifyShutterflyDocuments.execute(execution);

		List<DocumentMetaData> resultList = execution.getVariable(Workflow.LIST_DOCUMENT_METADATA, List.class);
		assertNotNull(resultList);
		assertFalse(resultList.isEmpty());
		DocumentMetaData resultDoc = resultList.get(0);
		Document metadata = resultDoc.getMetadata();
		System.out.println(metadata);
		assertFalse(metadata.getBoolean(Workflow.IS_POST_CARD));
		assertFalse(metadata.getString(Workflow.DOCUMENT_ABSOLUTE_PATH).isEmpty());

	}

	@Test
	public void testDoExecuteEmptyList() throws Exception {
		when(documentMetaDataService.getDocumentMetaData(any(), any(), anyInt())).thenReturn(null);

		identifyShutterflyDocuments.execute(execution);
		assertTrue(execution.getVariable("exitNow", Boolean.class));
	}
		
//	@Test
	public void testDoExecuteThrowsException() throws InvalidExpressionException {
//		System.out.println("before" + identifyShutterflyDocuments.errorMap.get(Workflow.NEW_ERRORS));
	
//		when(documentMetaDataService.getDocumentMetaData(Mockito.anyString(), Mockito.anyObject())).thenReturn(list);
		identifyShutterflyDocuments.execute(execution);
//		identifyShutterflyDocuments.doExecute(execution);

//		System.out.println("after" + identifyShutterflyDocuments.errorMap.get(Workflow.NEW_ERRORS));
	}
	
//	@Test(expected = NullPointerException.class)
	public void testDoExecuteWithNullSearchWindows() throws InvalidExpressionException {
		
		
		when(execution.getVariable(Workflow.SEARCH_WINDOW, String.class))
		.thenReturn(null);
		List<DocumentMetaData> list = new ArrayList<DocumentMetaData>();
		DocumentMetaData doc1 = new DocumentMetaData();
		doc1.setAppIdentifier("aasassa");
		doc1.setClientId(569899);
		doc1.setFdsDocumentId("sdsdsd34343");
		doc1.setFsId("7d7d7d7");
		list.add(doc1);
		DocumentMetaData doc2 = new DocumentMetaData();
		doc2.setAppIdentifier("aasassa");
		doc2.setClientId(569899);
		doc2.setFdsDocumentId("sdsdsd34343");
		doc2.setFsId("7d7d7d7");

		list.add(doc2);
		
//		when(documentMetaDataService
//				.getDocumentMetaData(Mockito.anyString(), Mockito.anyObject(), 
//						Mockito.anyInt())).thenReturn(list);
		
		identifyShutterflyDocuments.doExecute(execution);
	}
	
	@Test(expected = FileSystemException.class)
	public void testUpdateDocumentMetaDataAndDownloadAttachMentsIsSuccess() throws IOException {
		DocumentMetaData documentMetaData1 = new DocumentMetaData();
		documentMetaData1.setAppIdentifier("app1");
		documentMetaData1.setId("id1");
		documentMetaData1.setSpaceId(90365);;
		Document doc = new Document();
		doc.append("oododop", "sdhshdh");
		documentMetaData1.setMetadata(doc);
		
		var now = LocalDateTime.now();
		var formatter = DateTimeFormatter.ofPattern("dd-mm-yyyy");
		 String date = now.format(formatter);
		
		var tempWorkingPath = Utilities.createWorkingDirectoryWithParams(Workflow.DEFAULT_FILE_SEPARATOR,
				"/", appId, spaceId, date, StringUtils.EMPTY);
		

		ReflectionTestUtils.invokeMethod(identifyShutterflyDocuments, "updateDocumentMetaDataAndDownloadAttachMents",
				documentMetaData1, "toke34344", "https://test.com", tempWorkingPath, execution);
		assertEquals(null, identifyShutterflyDocuments.errorMap.get(Workflow.ERROR_MAP));
	}



	@Test
	public void testGetCurrentDateFormatted()
	{
		var now = LocalDateTime.now();
		var formatter = DateTimeFormatter.ofPattern("dd-mm-yyyy");
		 String expected = now.format(formatter);
		 assertEquals(expected, ReflectionTestUtils.invokeMethod(identifyShutterflyDocuments, "getCurrentDateFormatted", "dd-mm-yyyy"));
	}
	
	@Test(expected = NullPointerException.class)
	public void testvalidateInputWithException()
	{
		assertThrows(NullPointerException.class, ReflectionTestUtils.invokeMethod(identifyShutterflyDocuments, "validateInput", "", execution));
	}
	
//	@Test(expected = NullPointerException.class)
	public void testGetAttachmentWithNullPointer()
	{
//		ResponseEntity<DocumentAttachmentMetaData> response = null;
//		when(restTemplate.exchange(Mockito.anyObject(),  Mockito.anyObject(), Mockito.anyObject(), DocumentAttachmentMetaData.class))
//		.thenReturn((ResponseEntity<DocumentAttachmentMetaData>) response.ok());
//		restTemplate.exchange(uri, HttpMethod.GET, entity, DocumentAttachmentMetaData.class)
	
		
		assertThrows(NullPointerException.class, 
				ReflectionTestUtils.invokeMethod(identifyShutterflyDocuments, "getAttachment", "token", "https://test.com", "id8d8d", "attts788s8", 3007, "http://oauthurl.com", "clientId", "client", "grantType"));
	}

	private byte[] getByteArray() throws Exception {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("temp/pdfInput.pdf").getFile());
		return Files.readAllBytes(file.toPath());
	}
	
	private DocumentMetaData getDocumentMetaData() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr = "{"
                + "\"id\" : \"593e9fadef8654760f6b464c\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 10102,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\","
                + "\"documentAttachments\" : ["
                + "{"
                + "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
				+ "\"attachmentId\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
                + "\"index\" : 1,"
                + "\"file_name\" : \"balloon.jpg\","
                + "\"status\" : \"AVAILABLE\""
                + "}"
                + "]"
                + "}";

        String metaData =     "{"
                + "\"providerId\" : \"sample_provider\","
                + "\"fileName\" : \"birds1.pdf\","
                + "\"fileDescription\" : \"very simple file\","
                + "\"createdDate\" : \"06/11/2017\","
                + "\"createApplication\" : \"sample application\","
                + "\"expiryDate\" : \"05/30/2050\","
                + "\"filePath\" : \"reports/FEB2017\","
                + "\"dateOfService\" : \"01/30/2017\","
                + "\"fileType\" : \"reports/FEB2017\","
                + "\"tenant\" : \"suhcbo\","
                + "\"claimNumber\" : \"12345678\","
                + "\"category\" : \"Benefits\","
                + "\"subCategory\" : \"Transactions\","
                + "\"organization\" : \"Optum Technologies\","
                + "\"privilege\" : \"Electronic Payments and Statements\","
                + "\"corporateMpin\" : \"\","
                + "\"tin\" : \"201459415\","
                + "\"mpin\" : \"\","
                + "\"memberId\" : \"45678123\","
                + "\"physicianName\" : \"Paramesh,Korrakuti\","
                + "\"employeeName\" : \"Murthy, Sriram\","
                + "\"dateOfService\" : \"05/30/2017\","
                + "\"memberName\" : \"Balaji, Ramalingam\","
                + "\"emailAlertReq\" : \"Y\""
                + "}"
                + "}";
        Document metaDataObject = Document.parse(metaData);
        documentMetaData = Parser.parseJson(docStr, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
		documentMetaData.setFsId("1234");
		documentMetaData.setFdsDocumentId("12345");
		documentMetaData.setFdsAttachmentId("12345");
        return documentMetaData;
    }

    private DocumentMetaData getDocumentMetaData2() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr2 = "{"
                + "\"id\" : \"593e9fadef8654760f6b464c\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 10102,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\","
                + "\"documentAttachments\" : ["
                + "{"
                + "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
				+ "\"attachmentId\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
                + "\"index\" : 1,"
                + "\"file_name\" : \"balloon.jpg\","
                + "\"status\" : \"AVAILABLE\""
                + "}"
                + "]"
                + "}";

        String metaData2 =     "{"
                + "\"providerId\" : \"sample_provider\","
                + "\"fileName\" : \"birds3.pdf\","
                + "\"fileDescription\" : \"very simple file\","
                + "\"createdDate\" : \"06/11/2017\","
                + "\"createApplication\" : \"sample application\","
                + "\"expiryDate\" : \"05/30/2050\","
                + "\"filePath\" : \"reports/FEB2017\","
                + "\"dateOfService\" : \"01/30/2017\","
                + "\"fileType\" : \"reports/FEB2017\","
                + "\"tenant\" : \"suhcbo\","
                + "\"claimNumber\" : \"12345678\","
                + "\"category\" : \"Benefits\","
                + "\"subCategory\" : \"Transactions\","
                + "\"organization\" : \"Optum Technologies\","
                + "\"privilege\" : \"Electronic Payments and Statements\","
                + "\"corporateMpin\" : \"002535119\","
                + "\"tin\" : \"201459415\","
                + "\"mpin\" : \"12345\","
                + "\"memberId\" : \"45678123\","
                + "\"physicianName\" : \"Paramesh,Korrakuti\","
                + "\"employeeName\" : \"Murthy, Sriram\","
                + "\"dateOfService\" : \"05/30/2017\","
                + "\"memberName\" : \"Balaji, Ramalingam\","
                + "\"emailAlertReq\" : \"Y\""
                + "}"
                + "}";
        Document metaDataObject = Document.parse(metaData2);
        documentMetaData = Parser.parseJson(docStr2, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
		documentMetaData.setFsId("1234");
		documentMetaData.setFdsDocumentId("12345");
		documentMetaData.setFdsAttachmentId("12345");
        return documentMetaData;


    }

}
