package com.optum.fds.paperless.java.delegate;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.endsWith;
import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.util.SftpMonitorUtil;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;


public class SftpMonitorUtilTest {

    @InjectMocks
    SftpMonitorUtil sftpMonitorUtil;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testCreateDir() throws FSDataException {
        Map<String, Object> processConfig = new HashMap<>();
        processConfig.put("space_id", "2804");
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setAppIdentifier("685");
        processor.setConfigSpaceId(10802);
        String dirFromFileName = "abcZipFile.zip";
        String outputDir = sftpMonitorUtil.createFileOutputDirectoryPath(processConfig, processor, dirFromFileName);
        assertThat(outputDir, endsWith("abcZipFile"));
    }

    @Test
    public void testMissingTrue1() {
        assertThat(sftpMonitorUtil.isMissingLoginCredential("", "user", "pass", "dir"), equalTo(true));
    }

    @Test
    public void testMissingTrue2() {
        assertThat(sftpMonitorUtil.isMissingLoginCredential("host", "", "pass", "dir"), equalTo(true));
    }

    @Test
    public void testMissingTrue3() {
        assertThat(sftpMonitorUtil.isMissingLoginCredential("host", "user", "", "dir"), equalTo(true));
    }

    @Test
    public void testMissingTrue4() {
        assertThat(sftpMonitorUtil.isMissingLoginCredential("host", "user", "pass", ""), equalTo(true));
    }

    @Test
    public void testMissingFalse() {
        assertThat(sftpMonitorUtil.isMissingLoginCredential("host", "user", "pass", "dir"), equalTo(false));
    }

    @Test
    public void testValidStatusActive()  {
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setStatus(MetaDataStatus.ACTIVE);
        assertThat(sftpMonitorUtil.hasValidStatus(processor), equalTo(true));
    }

    @Test
    public void testValidStatusInProcess()  {
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setStatus(MetaDataStatus.IN_PROCESS);
        assertThat(sftpMonitorUtil.hasValidStatus(processor), equalTo(true));
    }

    @Test
    public void testValidStatusNew()  {
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setStatus(MetaDataStatus.NEW);
        assertThat(sftpMonitorUtil.hasValidStatus(processor), equalTo(true));
    }

    @Test
    public void testValidStatusOther()  {
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setStatus(MetaDataStatus.AVAILABLE);
        assertThat(sftpMonitorUtil.hasValidStatus(processor), equalTo(false));
    }

    @Test
    public void testValidNoProcessor()  {
        assertThat(sftpMonitorUtil.hasValidStatus(null), equalTo(false));
    }

}