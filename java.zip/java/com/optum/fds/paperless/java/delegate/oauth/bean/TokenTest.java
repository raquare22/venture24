package com.optum.fds.paperless.java.delegate.oauth.bean;



import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class TokenTest {
    @Test
    public void test() {
        com.optum.fds.paperless.java.delegate.oauth.bean.Token token = new com.optum.fds.paperless.java.delegate.oauth.bean.Token();
        token.getGrantType();
        token.setGrantType(new String());
        token.getAccessToken();
        token.setAccessToken(new String());
        token.getRefreshToken();
        token.setRefreshToken(new String());
        token.getTokenType();
        token.setTokenType(new String());
        token.getExpiresIn();
        token.setExpiresIn(0);
        token.getClientId();
        token.setClientId(new String());
        token.getClientSecret();
        token.setClientSecret(new String());

    }
}
