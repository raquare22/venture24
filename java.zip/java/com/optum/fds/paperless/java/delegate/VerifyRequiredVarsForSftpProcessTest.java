package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.JavaDelegate;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.Answer;
import org.mockito.stubbing.Stubber;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doAnswer;

public class VerifyRequiredVarsForSftpProcessTest {

    @Mock
    DelegateExecutionImpl delegateExecution;

    private Map<String, Object> delegateMap;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        delegateMap = new HashMap<>();
        MockitoAnnotations.initMocks(this);
        Stubber getDelegateMap = doAnswer(invocation -> {
            Object[] args = invocation.getArguments();
            return delegateMap.get(args[0]);
        });
        getDelegateMap.when(delegateExecution).getVariable(Mockito.anyString());

        Stubber setDelegateMap = doAnswer((Answer<Void>) invocation -> {
            Object[] args = invocation.getArguments();
            delegateMap.put((String) args[0], args[1]);
            return null;
        });
        setDelegateMap.when(delegateExecution).setVariable(Mockito.anyString(), Mockito.any());

        Stubber getVariablesMap = doAnswer((Answer<Map<String, Object>>) invocation -> delegateMap);
        getVariablesMap.when(delegateExecution).getVariables();

        DocumentMetaData documentMetadata = new DocumentMetaData();

        delegateMap.put(Workflow.DOCUMENT, documentMetadata);

        delegateMap.put(Workflow.GRANT_TYPE, "authorization_code");

        delegateMap.put(Workflow.OAUTH_URL,"http://optum.sample.com");

        delegateMap.put(Workflow.FDS_DOCUMENT_URL, "http://www.optum.com/search");
        delegateMap.put(Workflow.APP_ID, "testappId");
        delegateMap.put(Workflow.APP_SECRET, "testappId");
        delegateMap.put(Workflow.CLIENT_ID, "testclientId");
        delegateMap.put(Workflow.CLIENT_SECRET, "testclientSecret");

        delegateMap.put(Workflow.FDS_ATTACHMENT_URL, "http://www.optum.com/search/attachments");
        delegateMap.put(Workflow.FDS_TRANSFORM_URL, "http://www.optum.com/search/transforms");

        delegateMap.put(Workflow.SFTP_URL, "http://www.optum.com/search/sftp");
        delegateMap.put(Workflow.SFTP_USER, "testUser");
        delegateMap.put(Workflow.SFTP_PASS, "testPassword");
        delegateMap.put(Workflow.SFTP_ROOT, "testDir");


        delegateMap.put(Workflow.EMAIL_RECEIVER, "test@test.com");
        delegateMap.put(Workflow.EMAIL_SUBJECT, "test subject");

    }


    @SuppressWarnings("unchecked")
    @Test
    public void testSuccess() throws Exception {
        JavaDelegate verifyRequiredVars = new VerifyRequiredVarsForSftpProcess();
        verifyRequiredVars.execute(delegateExecution);
        Map<String, Object> errorMap = (Map<String, Object>) delegateMap.get("errorMap");
        assertEquals("No errors found", 0, errorMap.get("newErrors"));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testNewErrors() throws Exception {
        delegateMap.remove(Workflow.DOCUMENT);
        VerifyRequiredVarsForSftpProcess verifyRequiredVars = new VerifyRequiredVarsForSftpProcess();
        verifyRequiredVars.execute(delegateExecution);
        Map<String, Object> errorMap = (Map<String, Object>) delegateMap.get("errorMap");
        assertEquals("One errors found", 1, errorMap.get("newErrors"));
    }
}
