package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang.StringUtils;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RequiredVarsForMatchAndMergeDocumentsFromDbTest {

	private final String TEST = "test";

	DelegateExecution execution;
	
	@InjectMocks
	RequiredVarsForMatchAndMergeDocumentsFromDb requiredVarsForMatchAndMergeDocumentsFromDb;

	private Document execVars;

	@Before
	public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        execution = Mockito.mock(DelegateExecution.class);

        execVars = List.of(
                Workflow.SEARCH_CRITERIA,
                Workflow.SEARCH_WINDOW,
                Workflow.MATCH_CRITERIA,
                Workflow.TEMPLATE_ID,
                Workflow.FDS_DOCUMENTS_URL,
                Workflow.DOCUMENT_UPDATE_FLAG_PATH,
                Workflow.DOCUMENT_UPDATE_FLAG_VALUE)
                .stream()
                .collect(Collectors.collectingAndThen(Collectors.toMap(x -> x, y -> (Object)TEST), Document::new));

        when(execution.getVariables()).thenReturn(execVars);
//        execVars.forEach((key, value) -> when(execution.getVariable(key, String.class)).thenReturn(String.valueOf(value)));
	}
    
    @UserStory(references = "25124")
    @RallyTestCase(references = "TC30143")
    @Test
    public void testSuccess() throws Exception {
        requiredVarsForMatchAndMergeDocumentsFromDb.execute(execution);
        assertNotNull(requiredVarsForMatchAndMergeDocumentsFromDb.errorMap);
		assertEquals(1, requiredVarsForMatchAndMergeDocumentsFromDb.errorMap.get(Workflow.NEW_ERRORS));
    }
    
    /**
     * Missing Search Criteria and Search Window
     * @throws Exception
     */
    @UserStory(references = "25124")
    @RallyTestCase(references = "TC30144")
    @Test
    public void testErrors() throws Exception {
        execVars.put(Workflow.SEARCH_WINDOW, StringUtils.EMPTY);
        execVars.put(Workflow.SEARCH_CRITERIA, StringUtils.EMPTY);

        requiredVarsForMatchAndMergeDocumentsFromDb.execute(execution);
        assertNotNull(requiredVarsForMatchAndMergeDocumentsFromDb.errorMap);
		assertEquals(3, requiredVarsForMatchAndMergeDocumentsFromDb.errorMap.get(Workflow.NEW_ERRORS));
    }
    
    /**
     * Missing Match Criteria
     * @throws Exception
     */
    @UserStory(references = "25124")
    @RallyTestCase(references = "TC30145")
    @Test
    public void testErrorsMatchCriteria () throws Exception {
        execVars.put(Workflow.MATCH_CRITERIA, StringUtils.EMPTY);
        requiredVarsForMatchAndMergeDocumentsFromDb.execute(execution);
        assertNotNull(requiredVarsForMatchAndMergeDocumentsFromDb.errorMap);
		assertEquals(2, requiredVarsForMatchAndMergeDocumentsFromDb.errorMap.get(Workflow.NEW_ERRORS));
    }
    
}
