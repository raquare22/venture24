package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.kafka.KafkaProducer;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.TimeZone;

public class SendKafkaMessageTest {

    private final String PATH_JSON_FILE = "InputJson/SendKafkaMessage.json";

    @InjectMocks
    private SendKafkaMessage sendKafkaMessage;

    @Mock
    DocumentMetaDataService documentMetaDataService;

    @Mock
    KafkaProducer kafkaProducer;

    DelegateExecution execution = new DelegateExecutionImpl();

    @Before
    public void setUp() {
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        MockitoAnnotations.initMocks(this);

    }

    @Test
    public void testExecute() throws Exception {
        execution.setVariable(Workflow.TEMPLATE_NAME, "CNSJSONResponse");
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        execution.setVariable(Workflow.KAFKA_TOPIC_NAME, "testTopic");

        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "addedToResponseFile");
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, true);

        when(documentMetaDataService.getDocumentMetaData(anyString())).thenReturn(getDocument());

        doNothing().when(kafkaProducer).send(any(), any());

        sendKafkaMessage.execute(execution);
        assertNotNull(sendKafkaMessage.errorMap);

    }

    @Test
    public void testExecuteBounceEmail() throws Exception {
        execution.setVariable(Workflow.TEMPLATE_NAME, "CNSJSONResponse");
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        execution.setVariable(Workflow.KAFKA_TOPIC_NAME, "testTopic");

        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, "addedToResponseFile");
        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, true);

        when(documentMetaDataService.getDocumentMetaData(anyString())).thenReturn(getDocument1());

        doNothing().when(kafkaProducer).send(any(), any());

        sendKafkaMessage.execute(execution);
        assertNotNull(sendKafkaMessage.errorMap);

    }

    @Test
    public void testExecuteInvalidFile() throws Exception {
        execution.setVariable(Workflow.TEMPLATE_NAME, "CNSJSONResponse");
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile + "1");
        execution.setVariable(Workflow.KAFKA_TOPIC_NAME, "testTopic");
        sendKafkaMessage.execute(execution);

        assertNotNull(sendKafkaMessage.errorMap);

    }

    @Test
    public void testExecuteMissingKafkaTopic() throws Exception {
        execution.setVariable(Workflow.TEMPLATE_NAME, "CNSJSONResponse");
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile + "1");
        sendKafkaMessage.execute(execution);

        assertNotNull(sendKafkaMessage.errorMap);

    }


    private DocumentMetaData getDocument() {
        DocumentMetaData document = new DocumentMetaData();
        document.setId("doc2");

        String metadataStr = "{\n" +
                "        \"encounterDetails\" : {\n" +
                "          \"isAdmitAcknowledged\" : \"\",\n" +
                "          \"isDischargeAcknowledged\" : \"\",\n" +
                "          \"dischargeDate\" : \"\",\n" +
                "          \"emergencyDate\" : \"\",\n" +
                "          \"admitDate\" : \"2024-02-23 08:20:05\",\n" +
                "          \"chiefComplaintList\" : \"\",\n" +
                "          \"dischargeDisposition\" : \"NULL\",\n" +
                "          \"isEmergencyAcknowledged\" : \"\"\n" +
                "        },\n" +
                "        \"createApplication\" : \"TrackIt\",\n" +
                "        \"recordInfo\" : {\n" +
                "          \"recordID\" : \"591404594-1227654317-1708676405000\",\n" +
                "          \"recordType\" : \"ADMIT\",\n" +
                "          \"recordLastUpdateDate\" : \"\",\n" +
                "          \"encounterID\" : \"a085943d811d9910b99560a39d377c18\"\n" +
                "        },\n" +
                "        \"providerDetails\" : {\n" +
                "          \"admittingProviderName\" : \"RAUL B TALLO\",\n" +
                "          \"facilityProvider\" : \"LAKELAND REGIONAL HEALTH SYSTEMS\",\n" +
                "          \"providerNpi\" : \"1942212592\",\n" +
                "          \"providerTin\" : \"150559686\",\n" +
                "          \"providerName\" : \"NELSON-JAMES, CARA R.\"\n" +
                "        },\n" +
                "        \"tin\" : \"150559686\",\n" +
                "        \"memberDetails\" : {\n" +
                "          \"patientFirstName\" : \"EDWARD\",\n" +
                "          \"patientDateOfBirth\" : \"08/23/1954\",\n" +
                "          \"state\" : \"FL\",\n" +
                "          \"lob\" : \"C&S\",\n" +
                "          \"patientLastName\" : \"JAMES\"\n" +
                "        },\n" +
                "        \"transactionId\" : \"21836e97-2e4a-4b7c-a73c-af134b8198f9\",\n" +
                "        \"corporateMpin\" : \"000205066\",\n" +
                "        \"providerEmailId\" : \"jenny.j.wang@optum.com\",\n" +
                "        \"messageId\" : \"<11702-1065333319.62.1715354221075.JavaMail.?@fds-pen-batch-79b4fff7f-k6j2g>\",\n" +
                "        \"sendEmailNotifications\" : true,\n" +
                "        \"sendPENAPIRequest\" : true,\n" +
                "        \"dateEmailSent\" : \"2024-05-10T15:17:01.103Z\",\n" +
                "        \"isBHProvider\" : true\n" +
                "      }";
        Document metadata = Document.parse(metadataStr);
        document.setMetadata(metadata);

        return document;
    }

    private DocumentMetaData getDocument1() {
        DocumentMetaData document = new DocumentMetaData();
        document.setId("doc2");

        String metadataStr = "{\n" +
                "        \"encounterDetails\" : {\n" +
                "          \"isAdmitAcknowledged\" : \"\",\n" +
                "          \"isDischargeAcknowledged\" : \"\",\n" +
                "          \"dischargeDate\" : \"\",\n" +
                "          \"emergencyDate\" : \"\",\n" +
                "          \"admitDate\" : \"2024-02-23 08:20:05\",\n" +
                "          \"chiefComplaintList\" : \"\",\n" +
                "          \"dischargeDisposition\" : \"NULL\",\n" +
                "          \"isEmergencyAcknowledged\" : \"\"\n" +
                "        },\n" +
                "        \"createApplication\" : \"TrackItCnS\",\n" +
                "        \"recordInfo\" : {\n" +
                "          \"recordID\" : \"591404594-1227654317-1708676405000\",\n" +
                "          \"recordType\" : \"ADMIT\",\n" +
                "          \"recordLastUpdateDate\" : \"\",\n" +
                "          \"encounterID\" : \"a085943d811d9910b99560a39d377c18\"\n" +
                "        },\n" +
                "        \"providerDetails\" : {\n" +
                "          \"admittingProviderName\" : \"RAUL B TALLO\",\n" +
                "          \"facilityProvider\" : \"LAKELAND REGIONAL HEALTH SYSTEMS\",\n" +
                "          \"providerNpi\" : \"1942212592\",\n" +
                "          \"providerTin\" : \"150559686\",\n" +
                "          \"providerName\" : \"NELSON-JAMES, CARA R.\"\n" +
                "        },\n" +
                "        \"tin\" : \"150559686\",\n" +
                "        \"memberDetails\" : {\n" +
                "          \"patientFirstName\" : \"EDWARD\",\n" +
                "          \"patientDateOfBirth\" : \"08/23/1954\",\n" +
                "          \"state\" : \"FL\",\n" +
                "          \"lob\" : \"C&S\",\n" +
                "          \"patientLastName\" : \"JAMES\"\n" +
                "        },\n" +
                "        \"transactionId\" : \"21836e97-2e4a-4b7c-a73c-af134b8198f9\",\n" +
                "        \"corporateMpin\" : \"000205066\",\n" +
                "        \"providerEmailId\" : \"jenny.j.wang@optum.com\",\n" +
                "        \"messageId\" : \"<11702-1065333319.62.1715354221075.JavaMail.?@fds-pen-batch-79b4fff7f-k6j2g>\",\n" +
                "        \"sendEmailNotifications\" : true,\n" +
                "        \"sendPENAPIRequest\" : true,\n" +
                "        \"isBHProvider\" : true,\n" +
                "        \"eDeliveryError\": \"Missing or invalid data: email bounced\"\n" +
                "      }";
        Document metadata = Document.parse(metadataStr);
        metadata.append("dateEmailSent", 1697040000000L);
        document.setMetadata(metadata);

        return document;
    }
}