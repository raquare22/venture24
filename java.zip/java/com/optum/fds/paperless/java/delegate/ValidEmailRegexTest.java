package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.util.Utilities;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class ValidEmailRegexTest {

	DelegateExecution execution;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);
	}

	@Test
	public void validateProviderEmailTrue(){
		String validProviderEmail = "JOHN_DOE@DAG.HEALTHCARE";
		Assert.assertEquals(true, Utilities.validateProviderEmail(validProviderEmail));
	}

	@Test
	public void validateProviderEmailFalse(){
		String invalidProviderEmail = "JOHN_DOE@DAG.COM-";
		Assert.assertEquals(false,Utilities.validateProviderEmail(invalidProviderEmail));
	}

	@Test
	public void validateProviderEmailFalse2(){
		String invalidProviderEmail = "JOH^N_DOE@DAG.COM";
		Assert.assertEquals(false,Utilities.validateProviderEmail(invalidProviderEmail));
	}
	
}


