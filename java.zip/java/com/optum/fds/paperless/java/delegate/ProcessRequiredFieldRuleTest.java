package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ProcessRequiredFieldRuleTest {

	DocumentMetaData documentMetaData = null;

	DelegateExecution execution;
	Map<String, Object> map = new HashMap<>();

	@InjectMocks
	ProcessRequiredFieldRule processRequiredFieldRule;

	@Mock
	DocumentMetaDataService documentMetaDataService;

	@Mock
	HookService hookService;


	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = new DelegateExecutionImpl();

		List<Integer> skipEFT_spaceIds= new ArrayList<>();
		skipEFT_spaceIds.add(10074);
		skipEFT_spaceIds.add(10075);
		skipEFT_spaceIds.add(10803);

		List<Integer> checkInd_835_spaceIds= new ArrayList<>();
		checkInd_835_spaceIds.add(10403);

		List<String> skipEFT_categories=new ArrayList<>();
		skipEFT_categories.add("P0");
		skipEFT_categories.add("P8");
		skipEFT_categories.add("P9");
		skipEFT_categories.add("E1");

		ReflectionTestUtils.setField(processRequiredFieldRule,"skipEFT_spaceIds",skipEFT_spaceIds);
		ReflectionTestUtils.setField(processRequiredFieldRule,"checkInd_835_spaceIds",checkInd_835_spaceIds);
		ReflectionTestUtils.setField(processRequiredFieldRule,"skipEFT_categories",skipEFT_categories);


		when(hookService.getHookTransactionById(Mockito.anyString())).thenReturn(createHookTransaction());
		when(hookService.saveHookTransaction(Mockito.any())).thenReturn(createHookTransaction());
	}


	@Test
	public void testExecute() throws Exception {
		execution.setVariable(Workflow.DOCID, "123,12345,987");
		execution.setVariable(Workflow.HOOK_ID,"id1234");

		execution.setVariable(Workflow.RULES, getRules());

		when(documentMetaDataService.getDocumentMetaDataList(any())).thenReturn(getDocumentList());

		processRequiredFieldRule.execute(execution);

		assertNotNull(execution.getVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE, Boolean.class));
		assertTrue(execution.getVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE, Boolean.class));
		assertNotNull(execution.getVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE, Boolean.class));
		assertFalse(execution.getVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE, Boolean.class));

	}

	@Test
	public void testExecuteCAPMissingCorpMpin() throws Exception {
		execution.setVariable(Workflow.DOCID, "123,12345,987");
		execution.setVariable(Workflow.HOOK_ID,"id1234");

		execution.setVariable(Workflow.RULES, getRulesCAP());

		DocumentMetaData doc = getDocumentMetaDataCAPMissingCorpMpin();

		List<DocumentMetaData> list = new ArrayList<>();
		list.add(doc);
		when(documentMetaDataService.getDocumentMetaDataList(any())).thenReturn(list);

		processRequiredFieldRule.execute(execution);

		System.out.println(doc);

		assertNotNull(execution.getVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE, Boolean.class));
		assertFalse(execution.getVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE, Boolean.class));
		assertNotNull(execution.getVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE, Boolean.class));
		assertFalse(execution.getVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE, Boolean.class));

	}

	@Test
	public void testExecuteCAP() throws Exception {
		execution.setVariable(Workflow.DOCID, "123,12345,987");
		execution.setVariable(Workflow.HOOK_ID,"id1234");

		execution.setVariable(Workflow.RULES, getRulesCAP());

		DocumentMetaData doc = getDocumentMetaDataCAP();
		List<DocumentMetaData> list = new ArrayList<>();
		list.add(doc);
		when(documentMetaDataService.getDocumentMetaDataList(any())).thenReturn(list);

		processRequiredFieldRule.execute(execution);

		System.out.println(doc);

		assertNotNull(execution.getVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE, Boolean.class));
		assertTrue(execution.getVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE, Boolean.class));
		assertNotNull(execution.getVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE, Boolean.class));
		assertTrue(execution.getVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE, Boolean.class));

	}

	@Test
	public void testEmailAlertReqN() throws Exception {
		execution.setVariable(Workflow.DOCID, "123,12345,987");
		execution.setVariable(Workflow.HOOK_ID,"id1234");

		execution.setVariable(Workflow.RULES, getRules());

		DocumentMetaData doc = getDocumentMetaDataEmailAlertN();
		List<DocumentMetaData> list = new ArrayList<>();
		list.add(doc);
		when(documentMetaDataService.getDocumentMetaDataList(any())).thenReturn(list);

		processRequiredFieldRule.execute(execution);

		System.out.println(doc);

		assertNotNull(execution.getVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE, Boolean.class));
		assertTrue(execution.getVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE, Boolean.class));
		assertNotNull(execution.getVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE, Boolean.class));
		assertFalse(execution.getVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE, Boolean.class));
	}


	@Test
	public void testExecuteOptOutEmail() throws Exception {
		execution.setVariable(Workflow.DOCID, "123,12345,987");
		execution.setVariable(Workflow.HOOK_ID,"id1234");

		execution.setVariable(Workflow.RULES, getRules());

		DocumentMetaData doc = getDocumentMetaDataOptout();
		List<DocumentMetaData> list = new ArrayList<>();
		list.add(doc);
		when(documentMetaDataService.getDocumentMetaDataList(any())).thenReturn(list);

		processRequiredFieldRule.execute(execution);

		assertNotNull(execution.getVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE, Boolean.class));
		assertTrue(execution.getVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE, Boolean.class));
		assertNotNull(execution.getVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE, Boolean.class));
		assertFalse(execution.getVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE, Boolean.class));

	}

	@UserStory(references = "US6647566")
	@RallyTestCase(references = "TC4082835")
	@Test
	public void testCheckRequiredFields() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		Document metadataObj = Document.parse("{ " +
				"\"EFT_Ind\" : \"N\","+
				"\"tin\" : \"123\"" +
				"}");
		metadataObj.append("Ind_835", "Y");
		ArrayList<String> requiredFieldsList = new ArrayList<>();
		requiredFieldsList.add("EFT_Ind");
		requiredFieldsList.add("Ind_835");

		processRequiredFieldRule.checkRequiredFields(requiredFieldsList, metadataObj);
		System.out.println("metaData=" + metadataObj);
		assertEquals(null, metadataObj.getBoolean(Workflow.SEND_TO_DOCVAULT));

		metadataObj = Document.parse("{ " +
				"\"tin\" : \"123\"" +
				"}");
		requiredFieldsList = new ArrayList<>();
		requiredFieldsList.add("EFT_Ind");
		requiredFieldsList.add("Ind_835");
		processRequiredFieldRule.checkRequiredFields(requiredFieldsList, metadataObj);
		System.out.println("metaData=" + metadataObj);
		assertEquals(false, metadataObj.getBoolean(Workflow.SEND_TO_DOCVAULT));

		metadataObj = Document.parse("{ " +
				"\"tin\" : \"123\"" +
				"}");
		requiredFieldsList = new ArrayList<>();
		requiredFieldsList.add("EFT_Ind");
		processRequiredFieldRule.checkRequiredFields(requiredFieldsList, metadataObj);
		System.out.println("metaData=" + metadataObj);
		assertEquals(false, metadataObj.getBoolean(Workflow.SEND_TO_DOCVAULT));

		metadataObj = Document.parse("{ " +
				"\"tin\" : \"123\"" +
				"}");
		requiredFieldsList = new ArrayList<>();
		requiredFieldsList.add("Ind_835");
		processRequiredFieldRule.checkRequiredFields(requiredFieldsList, metadataObj);
		System.out.println("metaData=" + metadataObj);
		assertEquals(false, metadataObj.getBoolean(Workflow.SEND_TO_DOCVAULT));
	}

	@Test
	public void testExecuteZeroPayPraRulesWithInvalidEmailCorpmpinAndTinInd835TrueCSPPRA()
	{


		Document metadataObj1 = Document.parse("{ " +
				"\"EFT_Ind\" : \"Y\","+
				"\"tin\" : \"123\"," +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"\","+
				"\"Ind_835\" : \"Y\","+
				"\"providerEmailId\" : \"dummyemail@gmail.com\","+
				"\"subCategory\" : \"P0\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj1, 10403);
		assertEquals(false, metadataObj1.getBoolean(Workflow.SEND_TO_SHUTTERFLY));


		Document metadataObj2 = Document.parse("{ " +
				"\"EFT_Ind\" : \"Y\","+
				"\"tin\" : \"\"," +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"Ind_835\" : \"Y\","+
				"\"providerEmailId\" : \"dummyemail@gmail.com\","+
				"\"subCategory\" : \"P0\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj2, 10403);
		assertEquals(false, metadataObj2.getBoolean(Workflow.SEND_TO_SHUTTERFLY));

		Document metadataObj3 = Document.parse("{ " +
				"\"EFT_Ind\" : \"Y\","+
				"\"tin\" : \"123\"" +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"Ind_835\" : \"Y\","+
				"\"providerEmailId\" : \"dummyemail@gmail.com\","+
				"\"subCategory\" : \"E1\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj3, 10403);
		assertEquals(false, metadataObj3.getBoolean(Workflow.SEND_TO_SHUTTERFLY));
	}

	@Test
	public void testExecuteZeroPayPraRulesWithInvalidEmailCorpmpinAndTinIndFalse()
	{
		DocumentMetaData documentMetaDataObject= new DocumentMetaData();
		documentMetaDataObject.setSpaceId(10403);
		Document metadataObj = Document.parse("{ " +
				"\"EFT_Ind\" : \"Y\","+
				"\"tin\" : \"123\"" +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"Ind_835\" : \"N\","+
				"\"providerEmailId\" : \"\","+
				"\"subCategory\" : \"P0\""+
				"}");

		List<Integer> skipEFT_spaceIds= new ArrayList<>();
		skipEFT_spaceIds.add(10074);
		skipEFT_spaceIds.add(10075);
		skipEFT_spaceIds.add(10803);

		List<Integer> checkInd_835_spaceIds= new ArrayList<>();
		checkInd_835_spaceIds.add(10403);

		List<String> skipEFT_categories=new ArrayList<>();
		skipEFT_categories.add("P0");
		skipEFT_categories.add("P8");
		skipEFT_categories.add("P9");
		skipEFT_categories.add("E1");


		ReflectionTestUtils.setField(processRequiredFieldRule,"skipEFT_spaceIds",skipEFT_spaceIds);
		ReflectionTestUtils.setField(processRequiredFieldRule,"checkInd_835_spaceIds",checkInd_835_spaceIds);
		ReflectionTestUtils.setField(processRequiredFieldRule,"skipEFT_categories",skipEFT_categories);

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj, 10403);
		assertEquals(true, metadataObj.getBoolean(Workflow.SEND_TO_SHUTTERFLY));


		Document metadataObj1 = Document.parse("{ " +
				"\"EFT_Ind\" : \"Y\","+
				"\"tin\" : \"123\"" +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"\","+
				"\"Ind_835\" : \"N\","+
				"\"providerEmailId\" : \"dummyemail@gmail.com\","+
				"\"subCategory\" : \"P0\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj1, 10403);
		assertEquals(true, metadataObj1.getBoolean(Workflow.SEND_TO_SHUTTERFLY));


		Document metadataObj2 = Document.parse("{ " +
				"\"EFT_Ind\" : \"Y\","+
				"\"tin\" : \"\"" +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"Ind_835\" : \"N\","+
				"\"providerEmailId\" : \"dummyemail@gmail.com\","+
				"\"subCategory\" : \"P0\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj2, 10403);
		assertEquals(true, metadataObj2.getBoolean(Workflow.SEND_TO_SHUTTERFLY));

		Document metadataObj3 = Document.parse("{ " +
				"\"EFT_Ind\" : \"Y\","+
				"\"tin\" : \"123\"" +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"Ind_835\" : \"N\","+
				"\"providerEmailId\" : \"dummyemail@gmail\","+
				"\"eDeliveryError\" : \"Missing or invalid data: providerEmailId\","+
				"\"subCategory\" : \"P0\""+
				"}");
		processRequiredFieldRule.executeZeroPayPraRules(metadataObj3, 10403);
		assertEquals(true, metadataObj3.getBoolean(Workflow.SEND_TO_SHUTTERFLY));

		Document metadataObj4 = Document.parse("{ " +
				"\"EFT_Ind\" : \"Y\","+
				"\"tin\" : \"123\"" +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"Ind_835\" : \"N\","+
				"\"providerEmailId\" : \"dummyemail@gmail.com\","+
				"\"sendToShutterfly\" : false,"+
				"\"subCategory\" : \"P8\""+
				"}");
		processRequiredFieldRule.executeZeroPayPraRules(metadataObj4, 10403);
		assertEquals(false, metadataObj4.getBoolean(Workflow.SEND_TO_SHUTTERFLY));
	}


	@Test
	public void testExecuteZeroPayPraRulesWithInvalidEmailCorpmpinAndTinEftY()
	{
		DocumentMetaData documentMetaDataObject= new DocumentMetaData();
		documentMetaDataObject.setSpaceId(10074);
		Document metadataObj = Document.parse("{ " +
				"\"EFT_Ind\" : \"Y\","+
				"\"tin\" : \"123\"," +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"providerEmailId\" : \"\","+
				"\"sendToShutterfly\" : false,"+
				"\"subCategory\" : \"P0\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj, 10074);
		assertEquals(false, metadataObj.getBoolean(Workflow.SEND_TO_SHUTTERFLY));


		Document metadataObj1 = Document.parse("{ " +
				"\"EFT_Ind\" : \"Y\","+
				"\"tin\" : \"123\"," +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"\","+
				"\"providerEmailId\" : \"dummyemail@gmail.com\","+
				"\"subCategory\" : \"P0\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj1, 10074);
		assertEquals(false, metadataObj1.getBoolean(Workflow.SEND_TO_SHUTTERFLY));


		Document metadataObj2 = Document.parse("{ " +
				"\"EFT_Ind\" : \"Y\","+
				"\"tin\" : \"\"," +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"providerEmailId\" : \"dummyemail@gmail.com\","+
				"\"subCategory\" : \"P0\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj2, 10074);
		assertEquals(false, metadataObj2.getBoolean(Workflow.SEND_TO_SHUTTERFLY));

		Document metadataObj3 = Document.parse("{ " +
				"\"EFT_Ind\" : \"Y\","+
				"\"tin\" : \"123\"," +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"providerEmailId\" : \"dummyemail@gmail.com\","+
				"\"subCategory\" : \"E1\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj3, 10074);
		assertEquals(false, metadataObj3.getBoolean(Workflow.SEND_TO_SHUTTERFLY));
	}

	@Test
	public void testExecuteZeroPayPraRulesWithInvalidEmailCorpmpinAndTinEftN()
	{
		DocumentMetaData documentMetaDataObject= new DocumentMetaData();
		documentMetaDataObject.setSpaceId(10075);
		Document metadataObj = Document.parse("{ " +
				"\"EFT_Ind\" : \"N\","+
				"\"tin\" : \"123\"," +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"providerEmailId\" : \"\","+
				"\"subCategory\" : \"P9\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj, 10075);
		assertEquals(true, metadataObj.getBoolean(Workflow.SEND_TO_SHUTTERFLY));


		Document metadataObj1 = Document.parse("{ " +
				"\"EFT_Ind\" : \"N\","+
				"\"tin\" : \"123\"," +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"\","+
				"\"providerEmailId\" : \"dummyemail@gmail.com\","+
				"\"subCategory\" : \"P0\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj1, 10075);
		assertEquals(true, metadataObj1.getBoolean(Workflow.SEND_TO_SHUTTERFLY));


		Document metadataObj2 = Document.parse("{ " +
				"\"EFT_Ind\" : \"N\","+
				"\"tin\" : \"\"," +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"providerEmailId\" : \"dummyemail@gmail.com\","+
				"\"subCategory\" : \"P8\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj2, 10075);
		assertEquals(true, metadataObj2.getBoolean(Workflow.SEND_TO_SHUTTERFLY));

		Document metadataObj3 = Document.parse("{ " +
				"\"EFT_Ind\" : \"N\","+
				"\"tin\" : \"123\"," +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"providerEmailId\" : \"dummyemail@gmail\","+
				"\"eDeliveryError\" : \"Missing or invalid data: providerEmailId\","+
				"\"subCategory\" : \"P0\""+
				"}");
		processRequiredFieldRule.executeZeroPayPraRules(metadataObj3, 10075);
		assertEquals(true, metadataObj3.getBoolean(Workflow.SEND_TO_SHUTTERFLY));

		Document metadataObj4 = Document.parse("{ " +
				"\"EFT_Ind\" : \"N\","+
				"\"tin\" : \"123\"," +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"providerEmailId\" : \"dummyemail@gmail.com\","+
				"\"sendToShutterfly\" : false,"+
				"\"subCategory\" : \"P8\""+
				"}");
		processRequiredFieldRule.executeZeroPayPraRules(metadataObj4, 10075);
		assertEquals(false, metadataObj4.getBoolean(Workflow.SEND_TO_SHUTTERFLY));
	}

	@Test
	public void testExecuteZeroPayPraRulesWithNonPRAMetadata()
	{
		DocumentMetaData documentMetaDataObject= new DocumentMetaData();
		documentMetaDataObject.setSpaceId(8936);
		Document metadataObj = Document.parse("{ " +
				"\"tin\" : \"123\"," +
				"\"emailAlertReq\" : \"Y\","+
				"\"corporateMpin\" : \"000123456\","+
				"\"providerEmailId\" : \"\","+
				"\"subCategory\" : \"P9\""+
				"}");

		processRequiredFieldRule.executeZeroPayPraRules(metadataObj, 8936);
		assertEquals(null, metadataObj.getBoolean(Workflow.SEND_TO_SHUTTERFLY));

	}
	
	@Test
	public void testCapMetadata() throws Exception {
		
		DocumentMetaData documentMetaDataObject= new DocumentMetaData();
		documentMetaDataObject.setSpaceId(11503);
		String metadata = """
	     {
        "tin" : "922193137",
        "mpin" : "8552051",
        "emailAlertReq" : "Y",
        "physicianName" : "HOSPITAL MEDICINE SERVICES OF TN LLC",
        "multMemberId" : "987422914",
        "multClaimNumber" : "STL070086035",
        "CONFIGKEY" : "9999",
        "originalPrintTrail" : "CAP",
        "PassThruData" : "9999",
        "MailToAddress1" : "HOSPITAL MEDICINE SERVICES OF TN LLC",
        "MailToAddress2" : "111 HIGHWAY 70 E",
        "MailToAddress3" : "",
        "MailToAddress4" : "DICKSON",
        "MailToAddress5" : "TN",
        "MailToAddress6" : "370552080",
        "subCategory" : "O6",
        "letterId" : "6985532ca2daf48caafb8a7b",
        "category" : "Claim",
        "createApplication" : "CAP",
        "fileDescription" : "Claim status update",
        "filePath" : "Medicare/Review Decision",
        "fileType" : "Letter",
        "providerEmailId" : "ppsc922193137@hcahealthcare.com",
        "tenant" : "Link",
        "privilege" : "Claim Status",
        "postCardInd" : true,
        "docSentTo" : "",
        "sendToDocVault" : false,
        "sendToShutterfly" : false,
        "sendEmailNotifications" : false,
        "sendPENAPIRequest" : false,
        "fileName" : "20254F1YWIUGRRISCO_XXUVQKE3.pdf",
        "createdDate" : "2026-02-06T02:34:56.871Z",
        "expiryDate" : "2028-02-06T02:34:56.871Z",
        "prepostStarted" : true,
        "subscribeToEmail" : "Y",
        
       }

				""";
		Document metadataObj = Document.parse(metadata);
		
		
		processRequiredFieldRule.sendToDocumentVaultIfPresentOrShutterflyIfMissing(metadataObj, new ArrayList<>(getRulesCAP()));
		
		processRequiredFieldRule.sendToShutterflyIfInvalidProviderEmail(metadataObj);
		
		
	}

	private Document getMetadataCSPPRA() {
		return Document.parse("{\n"
				+ "    \"emailAlertReq\" : \"Y\",\n"
				+ "    \"fileDescription\" : \"Post Assessment Letter\",\n"
				+ "    \"docSentTo\" : \"\",\n"
				+ "    \"subCategory\" : \"H1\",\n"
				+ "    \"fileName\" : \"PPA_110344922_18749222_02262025_03012025_0741.pdf\",\n"
				+ "    \"originalPrintTrail\" : \"House Call\",\n"
				+ "    \"postCardInd\" : true,\n"
				+ "    \"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\n"
				+ "    \"subscribeToEmail\" : \"Y\",\n"
				+ "    \"expiryDate\" : \"2027-03-05T05:59:29.000Z\",\n"
				+ "    \"tin\" : \"043657892\",\n"
				+ "    \"sendToDocVault\" : false,\n"
				+ "    \"tenant\" : \"Link\",\n"
				+ "    \"multClaimNumber\" : \"|24R871857900|24R876236500|24R870271100|\",\n"
				+ "    \"MailToAddress1\" : \"2ND HOME NEWARK OPERATIONS\",\n"
				+ "    \"filePath\" : \"Community Plan/Zero-Dollar PRAs\",\n"
				+ "    \"sendEmailNotifications\" : false,\n"
				+ "    \"providerEmailId\" : \"\",\n"
				+ "    \"sendPENAPIRequest\" : false,\n"
				+ "    \"multMemberId\" : \"|077053116701|237125115401|072082836501|\",\n"
				+ "    \"createdDate\" : \"2024-11-09T00:00:00.000Z\",\n"
				+ "    \"physicianName\" : \"2ND HOME NEWARK OPERATIONS\",\n"
				+ "    \"createApplication\" : \"CSP-PRA\",\n"
				+ "    \"CheckTraceNumber\" : \"24314B1000356183\",\n"
				+ "    \"PassThruData\" : \"Y 5200000000190835143274169991           \",\n"
				+ "    \"checkAmt\" : \"0.00\",\n"
				+ "    \"MailToAddress6\" : \"\",\n"
				+ "    \"mpin\" : \"003329900\",\n"
				+ "    \"MailToAddress4\" : \"ORANGE NJ 07050-3608\",\n"
				+ "    \"category\" : \"Payment Document\",\n"
				+ "    \"MailToAddress5\" : \"\",\n"
				+ "    \"MailToAddress2\" : \"37 N DAY ST\",\n"
				+ "    \"fileType\" : \"Advice\",\n"
				+ "    \"MailToAddress3\" : \"\",\n"
				+ "    \"sendToShutterfly\" : false,\n"
				+ "    \"prepostStarted\" : true,\n"
				+ "    \"prepostEnded\" : true\n"
				+ "}");
	}

	private Document getMetadataHouseCalls() {
		return Document.parse("{\n"
				+ "    \"emailAlertReq\" : \"Y\",\n"
				+ "    \"fileDescription\" : \"Payment Document\",\n"
				+ "    \"docSentTo\" : \"\",\n"
				+ "    \"subCategory\" : \"P0\",\n"
				+ "    \"fileName\" : \"0040231802_00000121.pdf\",\n"
				+ "    \"originalPrintTrail\" : \"3234\",\n"
				+ "    \"postCardInd\" : false,\n"
				+ "    \"tagLine\" : \"20241109033948642960436\",\n"
				+ "    \"privilege\" : \"Claim Status\",\n"
				+ "    \"subscribeToEmail\" : \"Y\",\n"
				+ "    \"expiryDate\" : \"2026-11-09T03:28:02.163Z\",\n"
				+ "    \"Ind_835\" : \"Y\",\n"
				+ "    \"isPostCard\" : false,\n"
				+ "    \"tin\" : \"274169991\",\n"
				+ "    \"CONFIGKEY\" : \"FDSPP3234\",\n"
				+ "    \"absolutePath\" : \"/ingest/shutterfly/2b489bb4aa784f198aaeaba1e763a06f/10403/20241109033735518/new/\",\n"
				+ "    \"multSubscriberId\" : \"|127893515|130936688|102065216|\",\n"
				+ "    \"sendToDocVault\" : true,\n"
				+ "    \"EFT_Ind\" : \"N\",\n"
				+ "    \"tenant\" : \"Link\",\n"
				+ "    \"memberId\" : \"987205686\",\n"
				+ "    \"filePath\" : \"HouseCalls Documentation/Post Assessment Letter\",\n"
				+ "    \"sendEmailNotifications\" : false,\n"
				+ "    \"providerEmailId\" : \"familycarebn@comcast.net\",\n"
				+ "    \"sendPENAPIRequest\" : false,\n"
				+ "    \"eDeliveryError\" : \"Missing or invalid data: corporateMpin\",\n"
				+ "    \"createdDate\" : \"2025-03-05T05:59:29.000Z\",\n"
				+ "    \"physicianName\" : \"JAMES C SHEPPARD\",\n"
				+ "    \"createApplication\" : \"Schedular\",\n"
				+ "    \"mpin\" : \"002180773\",\n"
				+ "    \"category\" : \"House Call\",\n"
				+ "    \"fileType\" : \"Letter\",\n"
				+ "    \"sendToShutterfly\" : false,\n"
				+ "    \"prepostStarted\" : true,\n"
				+ "    \"prepostEnded\" : true\n"
				+ "}");
	}

	private DocumentMetaData getDocumentMetaDataEmailAlertN() {
		Document metadata =  Document.parse("{\n"
				+ "    \"emailAlertReq\" : \"N\",\n"
				+ "    \"fileDescription\" : \"Claims Document\",\n"
				+ "    \"subCategory\" : \"C1\",\n"
				+ "    \"fileName\" : \"0040231802_00000121.pdf\",\n"
				+ "    \"originalPrintTrail\" : \"3234\",\n"
				+ "    \"postCardInd\" : false,\n"
				+ "    \"expiryDate\" : \"2026-11-09T03:28:02.163Z\",\n"
				+ "    \"tin\" : \"274169991\",\n"
				+ "    \"CONFIGKEY\" : \"FDSPP3234\",\n"
				+ "    \"multSubscriberId\" : \"|127893515|130936688|102065216|\",\n"
				+ "    \"sendToDocVault\" : false,\n"
				+ "    \"providerEmailId\" : \"\",\n"
				+ "    \"mpin\" : \"002180773\",\n"
				+ "    \"corporateMpin\" : \"12345\",\n"
				+ "    \"fileType\" : \"Letter\",\n"
				+ "    \"prepostStarted\" : true\n"
				+ "}");

		DocumentMetaData doc = new DocumentMetaData();
		doc.setId("123");
		doc.setSpaceId(8936);
		doc.setMetadata(metadata);

		return doc;
	}

	private DocumentMetaData getDocumentMetaData() {
		Document metadata =  Document.parse("{\n"
				+ "    \"emailAlertReq\" : \"Y\",\n"
				+ "    \"fileDescription\" : \"Claims Document\",\n"
				+ "    \"subCategory\" : \"C1\",\n"
				+ "    \"fileName\" : \"0040231802_00000121.pdf\",\n"
				+ "    \"originalPrintTrail\" : \"3234\",\n"
				+ "    \"postCardInd\" : false,\n"
				+ "    \"subscribeToEmail\" : \"Y\",\n"
				+ "    \"expiryDate\" : \"2026-11-09T03:28:02.163Z\",\n"
				+ "    \"tin\" : \"274169991\",\n"
				+ "    \"CONFIGKEY\" : \"FDSPP3234\",\n"
				+ "    \"multSubscriberId\" : \"|127893515|130936688|102065216|\",\n"
				+ "    \"sendToDocVault\" : false,\n"
				+ "    \"providerEmailId\" : \"familycarebn@comcast.net\",\n"
				+ "    \"mpin\" : \"002180773\",\n"
				+ "    \"corporateMpin\" : \"12345\",\n"
				+ "    \"fileType\" : \"Letter\",\n"
				+ "    \"prepostStarted\" : true\n"
				+ "}");

		DocumentMetaData doc = new DocumentMetaData();
		doc.setId("123");
		doc.setSpaceId(8888);
		doc.setMetadata(metadata);

		return doc;
	}

	private DocumentMetaData getDocumentMetaDataCAP() {
		Document metadata =  Document.parse("{ \"tin\" : \"000999111\", \"mpin\" : \"000999111\", \"emailAlertReq\" : \"Y\", \"physicianName\" : \"PRUETT, CHRISTOPHER S.\", \"multMemberId\" : \"120242200\", \"multClaimNumber\" : \"RB0484811500\", \"CONFIGKEY\" : \"9999\", \"originalPrintTrail\" : \"CAP\", \"PassThruData\" : \"9999\", \"MailToAddress1\" : \"PRUETT, CHRISTOPHER S.\", \"MailToAddress2\" : \"3009 N BALLAS RD STE 132A\", \"MailToAddress3\" : \" \", \"MailToAddress4\" : \"SAINT LOUIS\", \"MailToAddress5\" : \"MO\", \"MailToAddress6\" : \"631312342\", \"subCategory\" : \"S1\", \"letterId\" : \"68aaa7458415ee51f0af9bbb\", \"category\" : \"Claim\", \"createApplication\" : \"CAP\", \"fileDescription\" : \"Claim status update\", \"filePath\" : \"Community Plan/Action Required\", \"fileType\" : \"Letter\", \"providerEmailId\" : \"\", \"tenant\" : \"Link\", \"privilege\" : \"Claim Status\", \"postCardInd\" : true, \"docSentTo\" : \"\", \"sendToDocVault\" : false, \"sendToShutterfly\" : false, \"sendEmailNotifications\" : false, \"sendPENAPIRequest\" : false, \"fileName\" : \"2025JAF853HMXMBGCS_LBLWDAAN.pdf\", \"createdDate\" : \"2025-08-24T05:46:51.087Z\", \"expiryDate\" : \"2027-08-24T05:46:51.087Z\", \"prepostStarted\" : true, \"corporateMpin\" : \"000111000\", \"eDeliveryError\" : \"Missing or invalid data: providerEmailId\", \"prepostEnded\" : true, \"docLibAPIResponse\" : true, \"docLibUploadDate\" : \"2025-08-24T06:00:07.985Z\" }");

		DocumentMetaData doc = new DocumentMetaData();
		doc.setId("123");
		doc.setSpaceId(11502);
		doc.setMetadata(metadata);

		return doc;
	}

	private DocumentMetaData getDocumentMetaDataCAPMissingCorpMpin() {
		Document metadata =  Document.parse("{\n" +
				"        \"tin\" : \"912151670\",\n" +
				"        \"mpin\" : \"003331989\",\n" +
				"        \"emailAlertReq\" : \"Y\",\n" +
				"        \"physicianName\" : \"CRAWFORD, SCOTT N.\",\n" +
				"        \"multMemberId\" : \"111166320\",\n" +
				"        \"multClaimNumber\" : \"25O015891300\",\n" +
				"        \"CONFIGKEY\" : \"9999\",\n" +
				"        \"originalPrintTrail\" : \"CAP\",\n" +
				"        \"PassThruData\" : \"9999\",\n" +
				"        \"MailToAddress1\" : \"CRAWFORD, SCOTT N.\",\n" +
				"        \"MailToAddress2\" : \"888 S KING ST\",\n" +
				"        \"MailToAddress3\" : \" \",\n" +
				"        \"MailToAddress4\" : \"HONOLULU\",\n" +
				"        \"MailToAddress5\" : \"HI\",\n" +
				"        \"MailToAddress6\" : \"968133097\",\n" +
				"        \"subCategory\" : \"S1\",\n" +
				"        \"letterId\" : \"689c2d8e41e0ab5cda176971\",\n" +
				"        \"category\" : \"Claim\",\n" +
				"        \"createApplication\" : \"CAP\",\n" +
				"        \"fileDescription\" : \"Claim status update\",\n" +
				"        \"filePath\" : \"Community Plan/Action Required\",\n" +
				"        \"fileType\" : \"Letter\",\n" +
				"        \"providerEmailId\" : \"Opt out\",\n" +
				"        \"tenant\" : \"Link\",\n" +
				"        \"privilege\" : \"Claim Status\",\n" +
				"        \"postCardInd\" : true,\n" +
				"        \"docSentTo\" : \"\",\n" +
				"        \"sendToDocVault\" : false,\n" +
				"        \"sendToShutterfly\" : false,\n" +
				"        \"sendEmailNotifications\" : false,\n" +
				"        \"sendPENAPIRequest\" : false,\n" +
				"        \"fileName\" : \"2025KUZS3SYZFP5ACS_EI6HIACS.pdf\",\n" +
				"        \"createdDate\" : \"2025-08-14T06:16:40.374Z\",\n" +
				"        \"expiryDate\" : \"2027-08-14T06:16:40.374Z\",\n" +
				"        \"prepostStarted\" : true,\n" +
				"        \"subscribeToEmail\" : \"N\",\n" +
				"        \"eDeliveryError\" : \"Missing or invalid data: corporateMpin\"\n" +
				"    }");

		DocumentMetaData doc = new DocumentMetaData();
		doc.setId("123");
		doc.setSpaceId(11502);
		doc.setMetadata(metadata);

		return doc;
	}

	private DocumentMetaData getDocumentMetaDataOptout() {
		Document metadata =  Document.parse("{\n"
				+ "    \"emailAlertReq\" : \"Y\",\n"
				+ "    \"fileDescription\" : \"Claims Document\",\n"
				+ "    \"subCategory\" : \"C1\",\n"
				+ "    \"fileName\" : \"0040231802_00000121.pdf\",\n"
				+ "    \"originalPrintTrail\" : \"3234\",\n"
				+ "    \"postCardInd\" : false,\n"
				+ "    \"subscribeToEmail\" : \"Y\",\n"
				+ "    \"expiryDate\" : \"2026-11-09T03:28:02.163Z\",\n"
				+ "    \"tin\" : \"274169991\",\n"
				+ "    \"CONFIGKEY\" : \"FDSPP3234\",\n"
				+ "    \"multSubscriberId\" : \"|127893515|130936688|102065216|\",\n"
				+ "    \"sendToDocVault\" : false,\n"
				+ "    \"providerEmailId\" : \"Opt out\",\n"
				+ "    \"mpin\" : \"002180773\",\n"
				+ "    \"corporateMpin\" : \"12345\",\n"
				+ "    \"fileType\" : \"Letter\",\n"
				+ "    \"prepostStarted\" : true\n"
				+ "}");

		DocumentMetaData doc = new DocumentMetaData();
		doc.setId("123");
		doc.setSpaceId(8888);
		doc.setMetadata(metadata);

		return doc;
	}

	private List<DocumentMetaData> getDocumentList() throws Exception {
		List<DocumentMetaData> list = new ArrayList<>();

		list.add(getDocumentMetaData());

		return list;
	}

	private HookTransactionMetaData createHookTransaction() {
		HookTransactionMetaData hook = new HookTransactionMetaData();
		hook.setSpaceId(3006);
		hook.setId("12345");
		hook.setClientId(123);
		hook.setAppIdentifier("1234556677");
		hook.setHookExecutionList(new ArrayList<>());
		return hook;
	}

	private List<Document> getRulesCAP() throws Exception {
		// order of the rules matters for CAP
		Document rule3 = Parser.parseJson("{\n" +
				"                            \"sendToShutterfly\" : true,\n" +
				"                            \"criteria\" : \"emailAlertReq!=\\\"N\\\"\",\n" +
				"                            \"requiredFields\" : [\n" +
				"                                \"providerEmailId\"\n" +
				"                            ]\n" +
				"                        }", Document.class);
		Document rule1 = Parser.parseJson("{\n" +
				"                            \"sendToShutterfly\" : false,\n" +
				"                            \"criteria\" : \"emailAlertReq==\\\"N\\\"\",\n" +
				"                            \"requiredFields\" : [\n" +
				"                                \"tin\",\n" +
				"                                \"corporateMpin\"\n" +
				"                            ]\n" +
				"                        }", Document.class);

		Document rule2 = Parser.parseJson("{\n" +
				"                            \"sendToShutterfly\" : false,\n" +
				"                            \"criteria\" : \"emailAlertReq!=\\\"N\\\"\",\n" +
				"                            \"requiredFields\" : [\n" +
				"                                \"tin\",\n" +
				"                                \"corporateMpin\",\n" +
				"                                \"mpin\",\n" +
				"                                \"subCategory\"\n" +
				"                            ]\n" +
				"                        }", Document.class);

		ArrayList<Document> rulesList = new ArrayList<>();
		rulesList.add(rule1);
		rulesList.add(rule2);
		rulesList.add(rule3);
		return rulesList;
	}

	private List<Document> getRules() throws Exception {
		Document rule1 = Parser.parseJson("{\n" +
				"        \"sendToShutterfly\" : false,\n" +
				"        \"criteria\" : \"emailAlertReq==\\\"N\\\"\",\n" +
				"        \"requiredFields\" : [\n" +
				"            \"tin\",\n" +
				"            \"corporateMpin\"\n" +
				"        ]\n" +
				"    }", Document.class);
		Document rule2 = Parser.parseJson("{\n" +
				"        \"sendToShutterfly\" : true,\n" +
				"        \"criteria\" : \"emailAlertReq!=\\\"N\\\"\",\n" +
				"        \"requiredFields\" : [\n" +
				"            \"tin\",\n" +
				"            \"corporateMpin\",\n" +
				"            \"mpin\",\n" +
				"            \"providerEmailId\"\n" +
				"        ]\n" +
				"    }", Document.class);

		ArrayList<Document> rulesList = new ArrayList<>();
		rulesList.add(rule1);
		rulesList.add(rule2);

		return rulesList;
	}
}