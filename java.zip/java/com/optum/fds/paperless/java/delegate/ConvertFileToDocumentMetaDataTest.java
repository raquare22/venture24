package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.bson.Document;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.impl.OptumPayNumberDocumentTemplate;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class ConvertFileToDocumentMetaDataTest {
	private final String PATH_TXT_FILE = "InputTxtFile/AccountsPayableFileTest.txt";
	private static final Logger LOGGER = LoggerFactory.getLogger(ConvertFileToDocumentMetaDataTest.class);
	
	@InjectMocks
    ConvertFileToDocumentMetaData convertFileToDocMetaData;

    @Mock
    DocumentMetaDataService documentMetaDataService;
    
    @Mock
	ProcessorsService processorsService;
    
    @Mock
    ProcessorService processorService;
    
    DelegateExecution execution;
    
    @Before
    public void setUp() throws Exception {
    	MockitoAnnotations.initMocks(this);

    	execution = new DelegateExecutionImpl();

        String jsonFile = Utilities.getInstance().getResourceFile(PATH_TXT_FILE).getAbsolutePath();
        
        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.OPTUM_PAY_NUMBER_DOCUMENT.getTemplate());
        execution.setVariable(Workflow.SPACE_ID, 123);
        execution.setVariable(Workflow.FILE_NAME, "filename");
        execution.setVariable("appIdentifier", "123456");
        execution.setVariable("processorTransactionId", "1234567");
        execution.setVariable(Workflow.FILE_PATH, jsonFile);        
        when(processorsService.getTransactionProcessor(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(getProcessorTransaction());
        when(processorService.updateProcessorTransactionMetaData(Mockito.any())).thenReturn(getProcessorTransaction());
    }
    
    @Test
    public void testDoExecute() throws Exception {
        List<DocumentMetaData> docMetaDataInsertedList = new ArrayList<>();
        docMetaDataInsertedList.add(getDocumentMetaData());
        docMetaDataInsertedList.add(getDocumentMetaData2());
        
        when(documentMetaDataService.insertMultiDocumentsWithSpaceId(Mockito.any(), Mockito.anyInt())).thenReturn(docMetaDataInsertedList);
    	convertFileToDocMetaData.execute(execution);
        assertNotNull( convertFileToDocMetaData.errorMap);
        assertEquals(0,  convertFileToDocMetaData.errorMap.get(Workflow.NEW_ERRORS));
        List<String> docIds = (List<String>) execution.getVariable("documentIds");
        System.out.println(docIds);
    }

    @Test
    public void testDoExecuteInvalidDocList() throws Exception {
        List<DocumentMetaData> docMetaDataInsertedList = new ArrayList<>();
        docMetaDataInsertedList.add(getDocumentMetaData());
        docMetaDataInsertedList.add(getDocumentMetaData2());

        String jsonFile = Utilities.getInstance().getResourceFile(PATH_TXT_FILE).getAbsolutePath();
        execution.setVariable(Workflow.FILE_PATH, jsonFile + "invalid");

        when(documentMetaDataService.insertMultiDocumentsWithSpaceId(Mockito.any(), Mockito.anyInt())).thenReturn(docMetaDataInsertedList);
        convertFileToDocMetaData.execute(execution);
        assertNotNull( convertFileToDocMetaData.errorMap);
        assertEquals(0,  convertFileToDocMetaData.errorMap.get(Workflow.NEW_ERRORS));
        List<String> docIds = (List<String>) execution.getVariable("documentIds");
        System.out.println(docIds);
    }

    @Test
    public void testDoExecuteInvalidTemplate() throws Exception {
        List<DocumentMetaData> docMetaDataInsertedList = new ArrayList<>();
        docMetaDataInsertedList.add(getDocumentMetaData());
        docMetaDataInsertedList.add(getDocumentMetaData2());

        execution.setVariable(Workflow.TEMPLATE_NAME, "invalid template");

        when(documentMetaDataService.insertMultiDocumentsWithSpaceId(Mockito.any(), Mockito.anyInt())).thenReturn(docMetaDataInsertedList);
        convertFileToDocMetaData.execute(execution);
        assertNotNull( convertFileToDocMetaData.errorMap);
        assertEquals(0,  convertFileToDocMetaData.errorMap.get(Workflow.NEW_ERRORS));
        List<String> docIds = (List<String>) execution.getVariable("documentIds");
        System.out.println(docIds);
    }


    private ProcessorTransaction getProcessorTransaction() {
    	ProcessorTransaction val = new ProcessorTransaction();
    	val.setConfigSpaceId(1234);
    	val.setClientId(123);
    	return val;
    }
    
    private DocumentMetaData getDocumentMetaData() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr = "{"
                + "\"id\" : \"593e9fadef8654760f6b464c\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 3007,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\","
                + "\"documentAttachments\" : ["
                + "{"
                + "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
                + "\"index\" : 1,"
                + "\"file_name\" : \"balloon.jpg\","
                + "\"status\" : \"AVAILABLE\""
                + "}"
                + "]"
                + "}";

        String metaData =     "{"
                + "\"providerId\" : \"sample_provider\","
                + "\"fileName\" : \"birds3\","
                + "\"fileDescription\" : \"very simple file\","
                + "\"createdDate\" : \"06/11/2017\","
                + "\"createApplication\" : \"sample application\","
                + "\"expiryDate\" : \"05/30/2050\","
                + "\"filePath\" : \"reports/FEB2017\","
                + "\"dateOfService\" : \"01/30/2017\","
                + "\"fileType\" : \"reports/FEB2017\","
                + "\"tenant\" : \"suhcbo\","
                + "\"claimNumber\" : \"12345678\","
                + "\"category\" : \"Benefits\","
                + "\"subCategory\" : \"Transactions\","
                + "\"organization\" : \"Optum Technologies\","
                + "\"privilege\" : \"Electronic Payments and Statements\","
                + "\"corporateMpin\" : \"002535119\","
                + "\"tin\" : \"201459415\","
                + "\"mpin\" : \"12345\","
                + "\"memberId\" : \"45678123\","
                + "\"physicianName\" : \"Paramesh,Korrakuti\","
                + "\"employeeName\" : \"Murthy, Sriram\","
                + "\"dateOfService\" : \"05/30/2017\","
                + "\"memberName\" : \"Balaji, Ramalingam\","
                + "\"emailAlertReq\" : \"Y\""
                + "}"
                + "}";
        Document metaDataObject = Document.parse(metaData);
        documentMetaData = Parser.parseJson(docStr, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
        return documentMetaData;
    }

    private DocumentMetaData getDocumentMetaData2() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr2 = "{"
                + "\"id\" : \"593e9fadef8654760f6b464c\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 3007,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\","
                + "\"documentAttachments\" : ["
                + "{"
                + "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
                + "\"index\" : 1,"
                + "\"file_name\" : \"balloon.jpg\","
                + "\"status\" : \"AVAILABLE\""
                + "}"
                + "]"
                + "}";

        String metaData2 =     "{"
                + "\"providerId\" : \"sample_provider\","
                + "\"fileName\" : \"birds3\","
                + "\"fileDescription\" : \"very simple file\","
                + "\"createdDate\" : \"06/11/2017\","
                + "\"createApplication\" : \"sample application\","
                + "\"expiryDate\" : \"05/30/2050\","
                + "\"filePath\" : \"reports/FEB2017\","
                + "\"dateOfService\" : \"01/30/2017\","
                + "\"fileType\" : \"reports/FEB2017\","
                + "\"tenant\" : \"suhcbo\","
                + "\"claimNumber\" : \"12345678\","
                + "\"category\" : \"Benefits\","
                + "\"subCategory\" : \"Transactions\","
                + "\"organization\" : \"Optum Technologies\","
                + "\"privilege\" : \"Electronic Payments and Statements\","
                + "\"corporateMpin\" : \"002535119\","
                + "\"tin\" : \"201459415\","
                + "\"mpin\" : \"12345\","
                + "\"memberId\" : \"45678123\","
                + "\"physicianName\" : \"Paramesh,Korrakuti\","
                + "\"employeeName\" : \"Murthy, Sriram\","
                + "\"dateOfService\" : \"05/30/2017\","
                + "\"memberName\" : \"Balaji, Ramalingam\","
                + "\"emailAlertReq\" : \"Y\""
                + "}"
                + "}";
        Document metaDataObject = Document.parse(metaData2);
        documentMetaData = Parser.parseJson(docStr2, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
        return documentMetaData;


    }

    @UserStory(references = "US6701787")
	@RallyTestCase(references = "TC4103992")
    @Test
    public void testDoExecuteOptumPaySplitSmall() throws Exception {
        Configurator.setAllLevels("", Level.INFO);
        String jsonFile = "src/test/resources/csv/UHC4_AP20231120005124_v4_small.txt";
        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.OPTUM_PAY_NUMBER_DOCUMENT.getTemplate());
        execution.setVariable(Workflow.SPACE_ID, 123);
        execution.setVariable(Workflow.FILE_NAME, "filename");
        execution.setVariable("appIdentifier", "123456");
        execution.setVariable("processorTransactionId", "1234567");
        execution.setVariable(Workflow.FILE_PATH, jsonFile);
        when(processorsService.getTransactionProcessor(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(getProcessorTransaction());
        when(processorService.updateProcessorTransactionMetaData(Mockito.any())).thenReturn(getProcessorTransaction());

        List<DocumentMetaData> docMetaDataInsertedList = new ArrayList<>();
        docMetaDataInsertedList.add(getDocumentMetaData());
        docMetaDataInsertedList.add(getDocumentMetaData2());
        when(documentMetaDataService.insertMultiDocumentsWithSpaceId(Mockito.any(), Mockito.anyInt())).thenReturn(docMetaDataInsertedList);

        LOGGER.info("Running SPLIT");
        convertFileToDocMetaData.splitPerMbSize = 1;
        convertFileToDocMetaData.splitFileMaxBytesNewLineWithin = 1024;
        convertFileToDocMetaData.execute(execution);
        assertNotNull(convertFileToDocMetaData.errorMap);
        assertEquals(0, convertFileToDocMetaData.errorMap.get(Workflow.NEW_ERRORS));
        assertNotNull(convertFileToDocMetaData.errorMap);

        LOGGER.info("Running NON SPLIT");
        convertFileToDocMetaData.splitPerMbSize = 4;
        convertFileToDocMetaData.splitFileMaxBytesNewLineWithin = 1024;
        convertFileToDocMetaData.execute(execution);
        assertNotNull(convertFileToDocMetaData.errorMap);
        assertEquals(0, convertFileToDocMetaData.errorMap.get(Workflow.NEW_ERRORS));
        assertNotNull(convertFileToDocMetaData.errorMap);
    }
}
