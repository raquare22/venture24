package com.optum.fds.paperless.java.delegate.common;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.*;

import com.google.gson.Gson;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.java.delegate.DelegateExecutionImpl;
import org.flowable.engine.delegate.DelegateExecution;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;

@RunWith(MockitoJUnitRunner.class)
public class DelegateUtilsTest {

    @Mock
    private EmailService emailService;

    @Mock
    private ProcessorService processorService;

    @Mock
    private DelegateExecution execution;

    @InjectMocks
    private DelegateUtils delegateUtils;

    @Test
    public void testAddDocumentIdInErrors() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setId("Test");
        when(execution.getVariable(Workflow.DOCUMENT, DocumentMetaData.class)).thenReturn(documentMetaData);

        String result = DelegateUtils.addDocumentIdInErrors(execution);
        assertEquals("Error while processing for Document Id:Test", result);
    }

    @Test
    public void testGenerateMessageforCronExpressionHookWorkflow() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setId("Test");
        when(execution.getVariable(Workflow.DOCUMENT, DocumentMetaData.class)).thenReturn(documentMetaData);
        when(execution.getVariable(Workflow.HOOK_EXECUTION_ID, String.class)).thenReturn("TestHook");

        String result = DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution);
        String expected = "Error while executing hook with Id Test at " + new Date() + ". \n" +
                "Hook Execution Id for the execution is TestHook. \n" +
                "Please check hook transaction in cronExpressionHook collection in Mongo DB for more details.";
        assertEquals(expected, result);
    }

    @Test
    public void testGenerateErrorMessageforCronExpressionHookWorkflow() {
        Map<String, Object> errorMap = new HashMap<>();
        errorMap.put("Error1", "Description1");

        Map<String, String> result = DelegateUtils.generateErrorMessageforCronExpressionHookWorkflow(errorMap);
        assertEquals("Error1: Description1", result.get(Workflow.ERROR_MESSAGE));
    }

    @Test
    public void testSendErrorNotification() {
        when(execution.getVariable(Workflow.EMAIL_RECEIVER, String.class)).thenReturn("test@example.com");
        when(execution.getVariable(Workflow.ENVIRONMENT, String.class)).thenReturn("TestEnv");
        when(emailService.sendEmail(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);

        Map<String, Object> errorMap = new HashMap<>();
        DelegateUtils.sendErrorNotification(execution, errorMap, "Test message", emailService);

        Mockito.verify(emailService).sendEmail(execution, errorMap, "Test message");
    }

    @Test
    public void testUpdateProcessorTransactionListSuccess() throws Exception {
        DelegateExecution execution1 = new DelegateExecutionImpl();
        List<Map<String, Object>> list = new ArrayList<>();
        HashMap<String, Object> map = new HashMap<>();
        map.put("_id", "123");
        map.put("ackStatus", "COMPLETE");
        list.add(map);
        var gson = new Gson();
        String listStr = gson.toJson(list);
        execution1.setVariable(Workflow.PROCESSOR_TRANSACTION_UPDATE, listStr);

        DelegateUtils.updateProcessorTransactionList(execution1, processorService);
        Mockito.verify(processorService).setAckStatus(any(), any());
    }

    @Test
    public void testUpdateProcessorTransactionListFailure() throws Exception {
        DelegateExecution execution1 = new DelegateExecutionImpl();
        String listStr = "";
        execution1.setVariable(Workflow.PROCESSOR_TRANSACTION_UPDATE, listStr);

        DelegateUtils.updateProcessorTransactionList(execution1, processorService);

    }
}