package com.optum.fds.paperless.java.delegate;

import com.amazonaws.services.sagemaker.model.AthenaResultCompressionType;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.java.delegate.CleanupFilesCreateACK;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.mockito.stubbing.Stubber;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class CleanupFilesCreateACKTest {

	@InjectMocks
	private CleanupFilesCreateACK cleanupFilesCreateACK;

	@Mock
	private ProcessorService processorService;

	@Mock
	ProcessorFileTaskService processorFileTaskService;

	DelegateExecution execution;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		execution = new DelegateExecutionImpl();

		execution.setVariable(Workflow.PROCESSOR_TRANSACTION_ID, "test123");
		execution.setVariable(Workflow.APP_IDENTIFIER, "test");
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION, getTrans1());

		ReflectionTestUtils.setField(cleanupFilesCreateACK, "serverType", "ose");

		when(processorFileTaskService.areAllProcessorFileTasksCompletedForTransactionId(anyString())).thenReturn(true);

	}

	@Test
	public void testDoExecute() throws Exception {
		when(processorService.getProcessorTransaction(anyString(), anyString(), anyString())).thenReturn(getTrans1());
		when(processorService.getProcessorMetaData(anyString(), anyString())).thenReturn(getProcessorMetaData());

		cleanupFilesCreateACK.execute(execution);
		assertNotNull(cleanupFilesCreateACK.errorMap);
		assertNotNull(execution.getVariable(Workflow.SFTP_ROOT_DIRECTORY));
	}

	@Test
	public void testProcessorFileTasksNotComplete() throws Exception {
		when(processorService.getProcessorTransaction(anyString(), anyString(), anyString())).thenReturn(getTrans1());
		when(processorFileTaskService.areAllProcessorFileTasksCompletedForTransactionId(anyString())).thenReturn(false);

		cleanupFilesCreateACK.execute(execution);
		assertNotNull(cleanupFilesCreateACK.errorMap);

	}

	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29590")
	public void testExecutionWithNoProcessorTransaction() throws Exception {
		when(processorService.getProcessorTransaction(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(null);
		cleanupFilesCreateACK.execute(execution);
		assertNotNull(cleanupFilesCreateACK.errorMap);
		assertEquals(1, cleanupFilesCreateACK.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29591")
	public void testExecutionWithProcessorTransactionWithWrongServerType() throws Exception {
		ProcessorTransaction processorTransaction = new ProcessorTransaction();
		processorTransaction.setServerType("ose");
		when(processorService.getProcessorTransaction(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(processorTransaction);
		cleanupFilesCreateACK.execute(execution);
		assertNotNull(cleanupFilesCreateACK.errorMap);
		assertEquals(1, cleanupFilesCreateACK.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29592")
	public void testExecutionWithNoProcessorMetaData() throws Exception {
		Mockito.lenient().when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		cleanupFilesCreateACK.execute(execution);
		assertNotNull(cleanupFilesCreateACK.errorMap);
		assertEquals(1, cleanupFilesCreateACK.errorMap.get(Workflow.NEW_ERRORS));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29593")
	public void testExecutionWithNoProcessConfig() throws Exception {
		ProcessorMetaData processorMetaData = getProcessorMetaData();
		Map process = processorMetaData.getProcess();
		process.put("config", null);
		Mockito.lenient().when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString())).thenReturn(processorMetaData);
		cleanupFilesCreateACK.execute(execution);
		assertNotNull(cleanupFilesCreateACK.errorMap);
		assertEquals(1, cleanupFilesCreateACK.errorMap.get(Workflow.NEW_ERRORS));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29594")
	public void testExecutionWithNoSftpHost() throws Exception {
		ProcessorMetaData processorMetaData = getProcessorMetaData();
		Map processConfig = processorMetaData.getProcessConfig();
		processConfig.put("host_name_destination", "");
		Mockito.lenient().when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString())).thenReturn(processorMetaData);
		cleanupFilesCreateACK.execute(execution);
		assertNotNull(cleanupFilesCreateACK.errorMap);
		assertEquals(1, cleanupFilesCreateACK.errorMap.get(Workflow.NEW_ERRORS));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29595")
	public void testExecutionWithNoSftpUser() throws Exception {
		ProcessorMetaData processorMetaData = getProcessorMetaData();
		Map processConfig = processorMetaData.getProcessConfig();
		processConfig.put("username_destination", "");
		Mockito.lenient().when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString())).thenReturn(processorMetaData);
		cleanupFilesCreateACK.execute(execution);
		assertNotNull(cleanupFilesCreateACK.errorMap);
		assertEquals(1, cleanupFilesCreateACK.errorMap.get(Workflow.NEW_ERRORS));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29596")
	public void testExecutionWithNoSftpPassword() throws Exception {
		ProcessorMetaData processorMetaData = getProcessorMetaData();
		Map processConfig = processorMetaData.getProcessConfig();
		processConfig.put("pw_destination", "");
		Mockito.lenient().when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString())).thenReturn(processorMetaData);
		cleanupFilesCreateACK.execute(execution);
		assertNotNull(cleanupFilesCreateACK.errorMap);
		assertEquals(1, cleanupFilesCreateACK.errorMap.get(Workflow.NEW_ERRORS));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29597")
	public void testExecutionWithNoSftpRootDir() throws Exception {
		ProcessorMetaData processorMetaData = getProcessorMetaData();
		Map processConfig = processorMetaData.getProcessConfig();
		processConfig.put("ftp_rootdir", "");
		Mockito.lenient().when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString())).thenReturn(processorMetaData);
		cleanupFilesCreateACK.execute(execution);
		assertNotNull(cleanupFilesCreateACK.errorMap);
		assertEquals(1, cleanupFilesCreateACK.errorMap.get(Workflow.NEW_ERRORS));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29598")
	public void testExecutionWithNoSftpAckDir() throws Exception {
		ProcessorMetaData processorMetaData = getProcessorMetaData();
		Map processConfig = processorMetaData.getProcessConfig();
		processConfig.put("ftp_ackdir", "");
		Mockito.lenient().when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString())).thenReturn(processorMetaData);
		cleanupFilesCreateACK.execute(execution);
		assertNotNull(cleanupFilesCreateACK.errorMap);
		assertEquals(1, cleanupFilesCreateACK.errorMap.get(Workflow.NEW_ERRORS));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29599")
	public void testExecutionWithNoSftpArchiveDir() throws Exception {
		ProcessorMetaData processorMetaData = getProcessorMetaData();
		Map processConfig = processorMetaData.getProcessConfig();
		processConfig.put("ftp_archivedir", "");
		Mockito.lenient().when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString())).thenReturn(processorMetaData);
		cleanupFilesCreateACK.execute(execution);
		assertNotNull(cleanupFilesCreateACK.errorMap);
		assertEquals(1, cleanupFilesCreateACK.errorMap.get(Workflow.NEW_ERRORS));
	}

	private ProcessorMetaData getProcessorMetaData() throws IOException {
		ProcessorMetaData processorMetaData = null;
		String processor = "{"
				+ "\"id\" : \"58cab698c2e6f7ff1c8e8c44\","
				+ "\"process\" : {"
				+ "\"config\" : {"
				+ "\"auth_type\" : \"oauth2\","
				+ "\"space_id\" : \"3007\","
				+ "\"fds_url\" : \"fds_url\","
				+ "\"fds_client_id\" : \"testapp\","
				+ "\"fds_client_secret\" : \"testapp\","
				+ "\"host_name_destination\" : \"rn000019322.uhc.com\","
				+ "\"username_destination\" : \"pren\","
				+ "\"pw_destination\" : \"uaHs7pvA\","
				+ "\"host_name\" : \"rn000019322.uhc.com\","
				+ "\"ftp_rootdir\" : \"/dropzone/charlie\","
				+ "\"ftp_ackdir\" : \"/dropzone/charlie/ack\","
				+ "\"ftp_archivedir\" : \"/dropzone/charlie/archive\","
				+ "\"username\" : \"pren\","
				+ "\"pw\" : \"uaHs7pvA\","
				+ "\"interval\" : \"30\""
				+ "}"
				+ "}"
				+ "}";
		processorMetaData = Parser.parseJson(processor, ProcessorMetaData.class);
		return processorMetaData;
	}

	private ProcessorTransaction getTrans1() throws IOException {

		ProcessorTransaction processorTransaction1;

		String processTrans1 = "{" + "\"id\" : \"5900ec4b30043ae97bb5cbf7\","
				+ "\"processorId\" : \"58cab698c2e6f7ff1c8e8c44\"," + "\"configSpaceId\" : 3007,"
				+ "\"fileName\" : \"good.zip\","
				+ "\"location\" : \"/bconnected/ingest/testapp/3007/5900ec4a30043ae97bb5cbf6\","
				+ "\"processorRecordType\" : \"processorTransaction\"," + "\"fileToProcessList\" : ["
				+ "\"53760302_72269907.pdf\", " + "\"empty.pdf\"" + "]," + "\"summary\" : {"
				+ "\"processingMetrics\" : {" + "\"totalBytes\" : 12300" + "}," + "\"errorList\" : [ " + "{"
				+ "\"errorMessage\" : \"There was a mismatch between count and files to be processed. Count is at 1 and there are 2 files listed.\","
				+ "\"errorCode\" : 7" + "}" + "]," + "\"runTime\" : 3051,"
				+ "\"startTime\" : \"2017-04-26T18:51:55.184Z\"," + "\"endTime\" : \"2017-04-26T18:51:58.235Z\","
				+ "\"xmlObject\" : {" + "\"batchId\" : \"2017031_104410_ELGS_Customer_Care_A\","
				+ "\"dataGroup\" : \"NASC\"," + "\"count\" : 1," + "\"files\" : {" + "\"fileList\" : [ " + "{"
				+ "\"fileName\" : \"empty.pdf\"" + "}, " + "{" + "\"fileName\" : \"53760302_72269907.pdf\"" + "}" + "]"
				+ "}" + "}" + "}," + "\"status\" : \"READY\"," + "\"appIdentifier\" : \"testapp\"" + "}";

		processorTransaction1 = Parser.parseJson(processTrans1, ProcessorTransaction.class);
		processorTransaction1.setLocation(getZipFileLocation());
		return processorTransaction1;

	}

	private String getZipFileLocation() {
		File zip = null;

		try {
			URL resource = getClass().getClassLoader().getResource("good.zip");
			zip = Paths.get(resource.toURI()).toFile();
		} catch (Exception ex) {
		}

		String filePath = zip.getParent();
		return filePath;
	}

}
