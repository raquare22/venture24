package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MatchAndMergeDocumentsFromDBTest {

    private final String PATH_JSON_FILE = "MatchAndMergeDocumentsFromDB/InputJsonExample.json";
    private final String PATH_JSON_FILE_WITHOUT_PTRS = "MatchAndMergeDocumentsFromDB/InputJsonWithoutPTRSExample.json";

    Map<String, Object> delegateMap = new HashMap<>();
    DelegateExecution execution = new DelegateExecutionImpl(delegateMap);

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @Mock
    DocumentMetaDataService documentMetaDataService;

    @Mock
    EmailService emailService;

    @Mock
    CsvProcessorsService csvProcessorsService;

    @Mock
    ProcessorsService processorsService;

    @Mock
    ProcessorService processorService;

    @InjectMocks
    MatchAndMergeDocumentsFromDB matchAndMergeDocumentsFromDB;

    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);

        File file = new File(getClass().getClassLoader().getResource(PATH_JSON_FILE).getFile());

        execution.setVariable(Workflow.JSON_FILE, file.getAbsolutePath());
        execution.setVariable(Workflow.MATCH_CRITERIA, "{ \"metadata.BARCODE\" : ${$.metadata.PTRS}, \"spaceId\" : 10200 }");
        execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"24\",\"format\":\"Hours\"}}");
        execution.setVariable(Workflow.TEMPLATE_ID, "5ac2a033a7c8d625d5e73164");
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath());
        execution.setVariable(Workflow.TEMPLATE_NAME, Templates.MATCH_AND_MERGE.getTemplate());

        CsvProcessorTransaction transaction = new CsvProcessorTransaction();
        transaction.setStatus(MetaDataStatus.COMPLETE);
        when(csvProcessorsService.getCsvProcessorTransactionWithFileName(Mockito.any())).thenReturn(transaction);

        ArrayList<DocumentMetaData> list1 = new ArrayList<>();
        list1.add(getDocumentMetaData());
//        when(documentMetaDataService.getDocumentMetaData(eq("{ \"metadata.BARCODE\" : \"145ZAAPIU00000301\", \"spaceId\" : 10200 }"),Mockito.any())).thenReturn(list1);

        ArrayList<DocumentMetaData> list2 = new ArrayList<>();
        list2.add(getDocumentMetaData2());
//        when(documentMetaDataService.getDocumentMetaData(eq("{ \"metadata.BARCODE\" : \"145ZAAPIU00000302\", \"spaceId\" : 10200 }"),Mockito.any())).thenReturn(list2);

//        when(emailService.sendEmail(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);

        Mockito.when(processorService.getProcessorFileTaskForTargetId(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
                .thenReturn(getProcessorFileTask());
//        Mockito.when(processorsService.getTransactionProcessor(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getTrans1());
        Mockito.when(processorsService.getTransactionProcessorById(Mockito.any())).thenReturn(getTrans1());

    }
    
    
//    @Test
    public void testUpdateDocumentIfMatched() throws Exception {
    	List<DocumentMetaData> matchedDocumentList = getDocList();
    	DocumentMetaData doc = new DocumentMetaData();
    	doc.setMetadata(new Document());
    	matchAndMergeDocumentsFromDB.updateDocumentIfMatched(matchedDocumentList, doc, "companionFileName", new ArrayList<>(), "checkWritePRAMatchAndMerge");
    	
    }

    @Test
    @UserStory(references = "US25126")
    @RallyTestCase(references = "TC30175")
    public void testDoExecute() throws Exception {
        matchAndMergeDocumentsFromDB.execute(execution);
        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
        //assertEquals(0, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS)); //ASSERT
    }

    @Test
    @UserStory(references = "US25126")
    @RallyTestCase(references = "TC30176")
    public void testDoExecuteWithMissingRequiredVariables() throws Exception {
        execution.setVariable(Workflow.JSON_FILE, null);
        execution.setVariable(Workflow.MATCH_CRITERIA, StringUtils.EMPTY);
        execution.setVariable(Workflow.SEARCH_WINDOW, StringUtils.EMPTY);
        execution.setVariable(Workflow.TEMPLATE_ID, StringUtils.EMPTY);
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, null);

        matchAndMergeDocumentsFromDB.execute(execution);
        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
        assertEquals(4, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS));
    }

    @Test
    @UserStory(references = "US25126")
    @RallyTestCase(references = "TC30177")
    public void testDoExecuteWithInvalidJsonFile() throws Exception {
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile + 1);
        matchAndMergeDocumentsFromDB.execute(execution);
        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
        assertEquals(1, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS));
    }

    @Test
    @UserStory(references = "US25126")
    @RallyTestCase(references = "TC30178")
    public void testDoExecuteWithInvalidSearchWindowJson() throws Exception {
        execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"24\",\"format\":\"Hours\"}");
        matchAndMergeDocumentsFromDB.execute(execution);
        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
        assertEquals(2, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS));
    }

    @Test
    @UserStory(references = "US25126")
    @RallyTestCase(references = "TC30179")
    public void testDoExecuteWithInvalidSearchWindow() throws Exception {
        execution.setVariable(Workflow.SEARCH_WINDOW, "{\"start_date_offset1\":{\"time_window\":\"48\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"24\",\"format\":\"Hours\"}}");
        matchAndMergeDocumentsFromDB.execute(execution);
        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
        assertEquals(1, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS));
    }

//    @Test
//    @UserStory(references = "US25126")
//    @RallyTestCase(references = "TC30180")
//    public void testDoExecuteWithInvalidMergedMetadataTemplateId() throws Exception {
//        execution.setVariable(Workflow.TEMPLATE_ID, "5ac2a033a7c8d625d5e73166");
//        matchAndMergeDocumentsFromDB.execute(execution);
//        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
//        assertEquals(1, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS));
//    }

//    @Test
//    @UserStory(references = "US25126")
//    @RallyTestCase(references = "TC30182")
//    public void testDoExecuteWithInvalidMergedMetadataTemplateDefinition() throws Exception {
//        Template mergedMetadataTemplate = new Template();
//        mergedMetadataTemplate.setId("5ac2a033a7c8d625d5e73164");
//        mergedMetadataTemplate.setTemplateRecordType("CheckWritePRAMergedMetadata");
//        mergedMetadataTemplate.setDefinition(MERGED_METADATA_INVALID_TEMPLATE_DEFINITION);
//        when(templatesService.getTemplateById("5ac2a033a7c8d625d5e73164")).thenReturn(mergedMetadataTemplate);
//        CsvProcessorTransaction csvTransaction = new CsvProcessorTransaction();
//        csvTransaction.setStatus(MetaDataStatus.COMPLETE);
//        when(csvProcessorsService.getCsvProcessorTransactionWithFileName(Mockito.any())).thenReturn(csvTransaction);
//        matchAndMergeDocumentsFromDB.execute(execution);
//        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
//        assertEquals(1, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS));
//    }

    @Test
    @UserStory(references = "US25126")
    @RallyTestCase(references = "TC30183")
    public void testDoExecuteWithOriginalDocumentListWithoutPTRS() throws Exception {
        String jsonFile= Utilities.getInstance().getResourceFile(PATH_JSON_FILE_WITHOUT_PTRS).getAbsolutePath();
        execution.setVariable(Workflow.JSON_FILE, jsonFile);
        matchAndMergeDocumentsFromDB.execute(execution);
        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
        assertEquals(1, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS));
    }

//    @Test
    @UserStory(references = "US25126")
    @RallyTestCase(references = "TC30184")
    public void testDoExecuteWithInvalidMatchCriteriaJson() throws Exception {
        execution.setVariable(Workflow.MATCH_CRITERIA, "{ \"metadata.BARCODE\" : ${$.metadata.PTRS}, \"spaceId\" : 10200");
        matchAndMergeDocumentsFromDB.execute(execution);
        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
        assertEquals(2, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS));
    }

    @Test
    @UserStory(references = "US25126")
    @RallyTestCase(references = "TC30186")
    public void testDoExecuteWithNoMatchedDocuments() throws Exception {
//        when(documentMetaDataService.getDocumentMetaData(eq("{ \"metadata.BARCODE\" : \"145ZAAPIU00000301\", \"spaceId\" : 10200 }"),Mockito.any())).thenReturn(null);
//        when(documentMetaDataService.getDocumentMetaData(eq("{ \"metadata.BARCODE\" : \"145ZAAPIU00000302\", \"spaceId\" : 10200 }"),Mockito.any())).thenReturn(new ArrayList<DocumentMetaData>());
        Mockito.when(processorService.getProcessorFileTaskForTargetId(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(getProcessorFileTask());
//        Mockito.when(processorsService.getTransactionProcessor(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getTrans1());

        matchAndMergeDocumentsFromDB.execute(execution);
        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
        //assertEquals(0, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS)); //ASSERT
        //assertNotNull(execution.getVariable("exitNow", Boolean.class));
        //assertTrue(execution.getVariable("exitNow", Boolean.class));
    }

    @Test
    @UserStory(references = "US26549")
    @RallyTestCase(references = "TC30489")
    public void testDoExecuteWithNoCsvProcessorTransaction() throws Exception{
//        when(csvProcessorsService.getCsvProcessorTransactionWithFileName("223796_336607.cmp")).thenReturn(null);
        matchAndMergeDocumentsFromDB.execute(execution);
        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
        //assertEquals(0, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS)); //ASSERT
    }

    @Test
    @UserStory(references = "US26549")
    @RallyTestCase(references = "TC30488")
    public void testDoExecuteWithCsvProcessorTransactionStatusCompleteWithErrors() throws Exception{
        CsvProcessorTransaction csvTransaction = new CsvProcessorTransaction();
        csvTransaction.setStatus(MetaDataStatus.COMPLETE_WITH_ERRORS);
//        when(csvProcessorsService.getCsvProcessorTransactionWithFileName("223796_336607.cmp")).thenReturn(csvTransaction);
        matchAndMergeDocumentsFromDB.execute(execution);
        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
        //assertEquals(0, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS)); //ASSERT
    }

//    @Test
    @UserStory(references = "US25126")
    @RallyTestCase(references = "TC30187")
    public void testDoExecuteWithException() throws Exception {
    	when(documentMetaDataService.getCsvDocumentMetaData(Mockito.any(), Mockito.any())).thenThrow(new RuntimeException("test"));
        matchAndMergeDocumentsFromDB.execute(execution);
        assertNotNull(matchAndMergeDocumentsFromDB.errorMap);
        assertEquals(1, matchAndMergeDocumentsFromDB.errorMap.get(Workflow.NEW_ERRORS));
    }

    private ProcessorTransaction getTrans1() throws IOException {

        ProcessorTransaction processorTransaction1;

        String processTrans1 = "{" + "\"id\" : \"5900ec4b30043ae97bb5cbf7\","
                + "\"processorId\" : \"58cab698c2e6f7ff1c8e8c44\","
                + "\"configSpaceId\" : 3007,"
                + "\"fileName\" : \"223796_336607.zip\","
                + "\"location\" : \"/bconnected/ingest/testapp/3007/5900ec4a30043ae97bb5cbf6\","
                + "\"processorRecordType\" : \"processorTransaction\"," + "\"fileToProcessList\" : ["
                + "\"53760302_72269907.pdf\", " + "\"empty.pdf\"" + "]," + "\"summary\" : {"
                + "\"processingMetrics\" : {" + "\"totalBytes\" : 12300" + "}," + "\"errorList\" : [ " + "{"
                + "\"errorMessage\" : \"There was a mismatch between count and files to be processed. Count is at 1 and there are 2 files listed.\","
                + "\"errorCode\" : 7" + "}" + "]," + "\"runTime\" : 3051,"
                + "\"startTime\" : \"2017-04-26T18:51:55.184Z\"," + "\"endTime\" : \"2017-04-26T18:51:58.235Z\","
                + "\"xmlObject\" : {" + "\"batchId\" : \"2017031_104410_ELGS_Customer_Care_A\","
                + "\"dataGroup\" : \"NASC\"," + "\"count\" : 1," + "\"files\" : {" + "\"fileList\" : [ " + "{"
                + "\"fileName\" : \"empty.pdf\"" + "}, " + "{" + "\"fileName\" : \"53760302_72269907.pdf\"" + "}" + "]"
                + "}" + "}" + "}," + "\"status\" : \"READY\"," + "\"appIdentifier\" : \"testapp\"" + "}";

        processorTransaction1 = Parser.parseJson(processTrans1, ProcessorTransaction.class);

        return processorTransaction1;

    }

    private ProcessorFileTask getProcessorFileTask() throws IOException {
        ProcessorFileTask processorFileTask = null;
        String fileTask = "{" + "\"id\" : \"5900ec4b30043ae97bb5cbfb\","
                + "\"fileSize\" : 12098,"
                + "\"configSpaceId\" : 3007,"
                + "\"fileName\" : \"53760302_72269907.pdf\"," + "\"targetId\" : \"5900ec4e30043ae97bb5cc04\","
                + "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
                + "\"processorRecordType\" : \"processorFileTask\","
                + "\"processorTransactionId\" : \"591c73bb3004a9fe597967c9\"," + "\"status\" : \"COMPLETE\","
                + "\"appIdentifier\" : \"testapp\"," + "\"summary\" : {" + "\"runTime\" : 2791,"
                + "\"startTime\" : \"2017-04-26T18:51:55.431Z\"," + "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
                + "\"xmlObject\" : {" + "\"applicationID\" : \"ELGS\"," + "\"datagroup\" : \"NASC\","
                + "\"fileFormat\" : \"PDF\"" + "}" + "}" + "}";
        processorFileTask = Parser.parseJson(fileTask, ProcessorFileTask.class);
        return processorFileTask;
    }


    private DocumentMetaData getDocumentMetaData() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr = "{"
                + "\"id\" : \"593e9fadef8654760f6b464c\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 10200,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\""
                + "}";

        String metaData =     "{"
                + "\"BARCODE\" : \"145ZAAPIU00000301\","
                + "\"DIV\" : \"MSP\","
                + "\"MEMBER NUMBER\" : \"70219-916698066-00\","
                + "\"MEMBER NAME\" : \"DOE2, JOHN K.\","
                + "\"CLAIM NUMBER\" : \"42069144-01\","
                + "\"MEDIA TYPE\" : \"PRA\","
                + "\"CLAIM SYSTEM\" : \"COSMOS\""
                + "}"
                + "}";
        Document metaDataObject = Document.parse(metaData);
        documentMetaData = Parser.parseJson(docStr, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
        return documentMetaData;
    }

    private DocumentMetaData getDocumentMetaData2() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr2 = "{"
                + "\"id\" : \"593e9fadef8654760f6b464d\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 10200,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\""
                + "}";

        String metaData2 =     "{"
                + "\"BARCODE\" : \"145ZAAPIU00000302\","
                + "\"DIV\" : \"MSP\","
                + "\"MEMBER NUMBER\" : \"70219-916698066-00\","
                + "\"MEMBER NAME\" : \"DOE2, JOHN K.\","
                + "\"CLAIM NUMBER\" : \"42069146-01\","
                + "\"MEDIA TYPE\" : \"PRA\","
                + "\"CLAIM SYSTEM\" : \"COSMOS\""
                + "}"
                + "}";
        Document metaDataObject = Document.parse(metaData2);
        documentMetaData = Parser.parseJson(docStr2, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
        return documentMetaData;
    }
    
    private List<DocumentMetaData> getDocList() throws Exception {
    	String docStr = "{"
                + "\"id\" : \"593e9fadef8654760f6b464c\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 10200,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\""
                + "}";

        String metaData = "{\n" + 
        		"				\"BARCODE\": \"145ZAAPIU00000301\",\n" + 
        		"				\"DIV\": \"MSP\",\n" + 
        		"				\"memberNumber\": \"70270-937666579-00\",\n" + 
        		"				\"memberName\": \"DOE3, JOHN J.\",\n" + 
        		"				\"claimNumber\": \"42069146-01\",\n" + 
        		"				\"mediaType\": \"PRA\",\n" + 
        		"				\"claimSystem\": \"COSMOS\"\n" + 
        		"			}";
    	
    	String docStr2 = "{"
                + "\"id\" : \"593e9fadef8654760f6b464d\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 10200,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\""
                + "}";

        String metaData2 = "{\n" + 
        		"				\"BARCODE\": \"145ZAAPIU00000301\",\n" + 
        		"				\"DIV\": \"MSP\",\n" + 
        		"				\"memberNumber\": \"70219-916698066-00\",\n" + 
        		"				\"memberName\": \"DOE2, JOHN K.\",\n" + 
        		"				\"claimNumber\": \"42069144-01\",\n" + 
        		"				\"mediaType\": \"PRA\",\n" + 
        		"				\"claimSystem\": \"COSMOS\"\n" + 
        		"			}";
        
        List<DocumentMetaData> docList = new ArrayList<>();
        
        Document metaDataObject2 = Document.parse(metaData2);
        DocumentMetaData doc2 = Parser.parseJson(docStr2, DocumentMetaData.class);
        doc2.setMetadata(metaDataObject2);
        
        Document metaDataObject1 = Document.parse(metaData);
        DocumentMetaData doc1 = Parser.parseJson(docStr, DocumentMetaData.class);
        doc1.setMetadata(metaDataObject1);
        
        docList.add(doc1);
        docList.add(doc2);
        
        return docList;
    }
    
}
