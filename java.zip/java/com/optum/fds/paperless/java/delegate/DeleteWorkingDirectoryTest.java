package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.mockito.stubbing.Stubber;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.ProcessorTransactions;
import com.optum.fds.paperless.workflow.constants.Workflow;

@RunWith(MockitoJUnitRunner.class)
public class DeleteWorkingDirectoryTest {
	
	String tempFolderStr;
	
	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();
	
	Path tempWorkingPath = null;

//	@Mock
	DelegateExecution execution = new DelegateExecutionImpl();
	
	@Mock
	ProcessorService processorService;
	
	@Mock
	ErrorMetaDataService errorMetaDataService;
	
//	Map<String,Object> delegateMap;

	//@Spy
	@InjectMocks
	DeleteWorkingDirectory deleteWorkingDirectory;

	@Before
	public void setUp() throws IOException, URISyntaxException  { 
	    MockitoAnnotations.initMocks(this);
	    
	    tempFolderStr = tempFolder.getRoot().getAbsolutePath();

	    
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION, new ProcessorTransactions());
	    
        tempWorkingPath = Utilities.createWorkingDirectory(tempFolder.getRoot().getAbsolutePath() + Workflow.DEFAULT_FILE_SEPARATOR + UUID.randomUUID().toString());
        Files.copy(Utilities.getInstance().getResourceFile("zippedfile1.zip").toPath(), Paths.get(tempWorkingPath + Workflow.DEFAULT_FILE_SEPARATOR + "test.zip"), StandardCopyOption.REPLACE_EXISTING);
        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setLocation(tempWorkingPath.toString());
        execution.setVariable(Workflow.PROCESSOR_TRANSACTION, processorTransaction);
     //   when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class)).thenReturn(getTrans1());
        when(processorService.updateProcessorTransactionMetaData(Mockito.any())).thenReturn(new ProcessorTransaction());
		Mockito.lenient().when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
	}
	
	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29600")
	public void testExecution() throws Exception {
	//	execution = mock(DelegateExecution.class);
	//	ProcessorTransaction processorTransaction = new ProcessorTransaction();
    //    processorTransaction.setLocation(tempWorkingPath.toString());
   //     execution.setVariable(Workflow.PROCESSOR_TRANSACTION, processorTransaction);
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION, getTrans1());
		deleteWorkingDirectory.execute(execution);
		assertNotNull(deleteWorkingDirectory.errorMap);
		assertEquals(0, deleteWorkingDirectory.errorMap.get(Workflow.NEW_ERRORS));
	}

	/*
	 * @Test
	 * 
	 * @UserStory(references = "US25077")
	 * 
	 * @RallyTestCase(references = "TC29601") public void
	 * testExecutionWithIOException() throws Exception { doAnswer(new Answer() {
	 * 
	 * @Override public Object answer(InvocationOnMock invocation) throws Throwable
	 * { return doThrow(new IOException()); }
	 * }).when(deleteWorkingDirectory).deleteDirectory(Mockito.any());
	 * 
	 * //doThrow(new
	 * IOException()).when(deleteWorkingDirectory).deleteDirectory(Mockito.any());
	 * when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION,
	 * ProcessorTransaction.class)).thenReturn(getTrans1());
	 * deleteWorkingDirectory.execute(execution);
	 * assertNotNull(deleteWorkingDirectory.errorMap); assertEquals(0,
	 * deleteWorkingDirectory.errorMap.get(Workflow.NEW_ERRORS)); }
	 */

	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29602")
	public void testExecutionWithInvalidDirectory() throws Exception {
        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        
        execution.setVariable(Workflow.PROCESSOR_TRANSACTION, getTrans1());
        processorTransaction.setLocation(tempWorkingPath.toString() + "junk");
        execution.setVariable(Workflow.PROCESSOR_TRANSACTION, processorTransaction);
		deleteWorkingDirectory.execute(execution);
		assertNotNull(deleteWorkingDirectory.errorMap);
		assertEquals(0, deleteWorkingDirectory.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29603")
	public void testExecutionWithNoProcessorTransaction() throws Exception {
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION, null);
		deleteWorkingDirectory.execute(execution);
		assertNotNull(deleteWorkingDirectory.errorMap);
		assertEquals(0, deleteWorkingDirectory.errorMap.get(Workflow.NEW_ERRORS));
	}

	private ProcessorTransaction getTrans1() throws IOException {

		ProcessorTransaction processorTransaction1 =new ProcessorTransaction();

		String processTrans1 = "{"
				+ "\"id\" : \"5900ec4b30043ae97bb5cbf7\","
				+ "\"processorId\" : \"58cab698c2e6f7ff1c8e8c44\","
				+ "\"fileName\" : \"good.zip\","
				+ "\"location\" : \"" + tempFolderStr + "\","
				+ "\"processorRecordType\" : \"processorTransaction\","
				+ "\"fileToProcessList\" : ["
				+ "\"53760302_72269907.pdf\", "
				+ "\"empty.pdf\""
				+ "],"
				+ "\"summary\" : {"
				+ "\"processingMetrics\" : {"
				+ "\"totalBytes\" : 12300"
				+ "},"
				+ "\"errorList\" : [ "

	    		+ "],"
	    		+ "\"runTime\" : 3051,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.184Z\","
	    		+ "\"endTime\" : \"2017-04-26T18:51:58.235Z\","
	    		+ "\"xmlObject\" : {"
	    		+ "\"batchId\" : \"2017031_104410_ELGS_Customer_Care_A\","
	    		+ "\"dataGroup\" : \"NASC\","
	    		+ "\"count\" : 1,"
	    		+ "\"files\" : {"
	    		+ "\"fileList\" : [ "
	    		+ "{"
	    		+ "\"fileName\" : \"53760302_72269907.pdf\""
	    		+ "},"
	    		+ "{"
	    		+ "\"fileName\" : \"53760302_72269907.pdf\""
	    		+ "}"
	    		+ "]"
	    		+ "}"
	    		+ "}"
	    		+ "},"
	    		+ "\"status\" : \"READY\","
	    		+ "\"appIdentifier\" : \"testapp\""
	    		+ "}";

		processorTransaction1 = Parser.parseJson(processTrans1, ProcessorTransaction.class);

		return processorTransaction1;

	}
}
