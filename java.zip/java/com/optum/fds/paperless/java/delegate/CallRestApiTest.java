package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorRowTask;
import com.optum.fds.paperless.mongo.jobs.RestApiJob;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class CallRestApiTest {

	@Mock
	CsvProcessorsService csvProcessorsSvc;

	@Mock
	CsvProcessorService csvProcessorSvc;
	
	@Mock
	CsvProcessorRowTask csvProcessorRowTask;

	@InjectMocks
	CallRestApi callRestApi;

	@Mock
	private RestTemplate restTemplate;

	@Mock
	HttpEntity<CallRestApiTest> request;

	@Mock
	HttpMethod method;

	DelegateExecution execution;

	@SuppressWarnings({ "deprecation" })
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);

		Document execVars = new Document().append(Workflow.JOB, List.of("testOne", "testTwo"))
				.append(Workflow.OAUTH_TOKEN_V1, "Bearer sdsdsd");

		when(execution.getVariable(Workflow.JOB, List.class)).thenReturn(execVars.get(Workflow.JOB, List.class));
		when(execution.getVariable(Workflow.OAUTH_TOKEN_V1, String.class))
				.thenReturn(execVars.get(Workflow.OAUTH_TOKEN_V1, String.class));

	}

	@SuppressWarnings({ "unchecked", "rawtypes", "static-access" })
	@Test
	public void testDoExecuteWithPostMethod() throws URISyntaxException {
		RestApiJob oJob = new RestApiJob();
		URI uri = new URI("http://test.com/");
		oJob.setUri(uri);
		oJob.setSourceType("ssdsd");
		oJob.setTransactionId("tr53535");
		oJob.setSpaceId(1255);
		oJob.setClientId(525555);
		oJob.setAppIdentifier("app34343");
		oJob.setCsvFileName("test.csv");
		oJob.setJsonFileName("test.json");
		oJob.setTargetType("target");
		oJob.setDbStatusObjectId("445fgf45da56i");
		Map<String, Object> varsMap = new HashMap<String, Object>();
		varsMap.put(Workflow.REST_METHOD, method.POST);
		varsMap.put(Workflow.REST_REQUEST, request);
		varsMap.put(Workflow.REST_URI, uri);
		varsMap.put(Workflow.REST_SERVER_TYPE, "local");
		varsMap.put(Workflow.REST_DB_STATUS_OBJ_ID, "obj444");
		varsMap.put(Workflow.REST_APP_IDENTIFIER, "app34343");
		
		

		when(execution.getVariable(Arrays.asList(Workflow.JOB, Workflow.OAUTH_TOKEN_V1).get(0))).thenReturn(oJob);

		when(execution.getVariable(Workflow.REST_API_JOB_ATTRS)).thenReturn(varsMap); 
		
		CsvProcessorRowTask cRt = new CsvProcessorRowTask();
		cRt.setAppIdentifier("app34343");
		cRt.setId("id333");
		cRt.setServerType("local");
		cRt.setClientId(5555);
		cRt.setConfigSpaceId(1255);
		System.out.println("llll" + cRt);
		
		when(csvProcessorSvc.getCsvProcessorRowTask(
				Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(cRt);
	
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, "application/json; charset=UTF-8");
		headers.add(Workflow.REST_X_TRX_HEADER, "d4540djd7rbh");
//		headers.addAll(Workflow.REST_X_TRX_HEADER, List.of("sdsdsds", "sdsds"));
		ResponseEntity<String> res = new ResponseEntity<>("test", headers,HttpStatus.CREATED);
		
		when(restTemplate.exchange(uri, method.POST, request, String.class)).thenReturn(ResponseEntity.ok()
	            .headers(headers)
	            .body("test"));
		when(execution.getVariable(Workflow.REST_HTTP_REQUEST_EXECUTION_ERROR)).thenReturn("Rest error occured");
//		when(execution.getVariable(Workflow.REST_SERVER_TYPE)).thenReturn("local");
		
		
		callRestApi.doExecute(execution);
	}
	
	@SuppressWarnings("static-access")
	@Test
	public void testDoExecuteWithPutMethod() throws URISyntaxException {
		RestApiJob oJob = new RestApiJob();
		URI uri = new URI("http://test.com/");
		oJob.setUri(uri);
		oJob.setSourceType("ssdsd");
		oJob.setTransactionId("tr53535");
		oJob.setSpaceId(1255);
		oJob.setClientId(525555);
		oJob.setAppIdentifier("app34343");
		oJob.setCsvFileName("test.csv");
		oJob.setJsonFileName("test.json");
		oJob.setTargetType("target");
		oJob.setDbStatusObjectId("445fgf45da56i");
		Map<String, Object> varsMap = new HashMap<String, Object>();
		varsMap.put(Workflow.REST_METHOD, method.PUT);
		varsMap.put(Workflow.REST_REQUEST, request);
		varsMap.put(Workflow.REST_URI, uri);
		varsMap.put(Workflow.REST_SERVER_TYPE, "local");
		varsMap.put(Workflow.REST_DB_STATUS_OBJ_ID, "obj444");
		varsMap.put(Workflow.REST_APP_IDENTIFIER, "app34343");
		
		

		when(execution.getVariable(Arrays.asList(Workflow.JOB, Workflow.OAUTH_TOKEN_V1).get(0))).thenReturn(oJob);

		when(execution.getVariable(Workflow.REST_API_JOB_ATTRS)).thenReturn(varsMap); 
		
		CsvProcessorRowTask cRt = new CsvProcessorRowTask();
		cRt.setAppIdentifier("app34343");
		cRt.setId("id333");
		cRt.setServerType("local");
		cRt.setClientId(5555);
		cRt.setConfigSpaceId(1255);
		System.out.println("llll" + cRt);
		
		when(csvProcessorSvc.getCsvProcessorRowTask(
				Mockito.anyString(),
				Mockito.anyString(),
				Mockito.anyString())).thenReturn(cRt);

		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, "application/json; charset=UTF-8");
		headers.add(Workflow.REST_X_TRX_HEADER, "d4540djd7rbh");
//		headers.addAll(Workflow.REST_X_TRX_HEADER, List.of("sdsdsds", "sdsds"));
		ResponseEntity<String> res = new ResponseEntity<>("test", headers,HttpStatus.CREATED);
		
		when(restTemplate.exchange(uri, method.PUT, request, String.class)).thenReturn(ResponseEntity.ok()
	            .headers(headers)
	            .body("test"));
		when(execution.getVariable(Workflow.REST_HTTP_REQUEST_EXECUTION_ERROR)).thenReturn("Rest error occured");
//		when(execution.getVariable(Workflow.REST_SERVER_TYPE)).thenReturn("local");
	
		
		callRestApi.doExecute(execution);
	}
	
	@Test
	public void testGetTargetIdFromResponseBody() throws JSONException
	{
		Document doc = new Document();
		doc.append("id", "test");
		
		JSONObject json = new JSONObject();
		json.put("id", "test");
		assertEquals("test", ReflectionTestUtils.invokeMethod(callRestApi, "getTargetIdFromResponseBody", json.toString()));
	}
	
	@SuppressWarnings("static-access")
	@Test
	public void testConvertRestRequestForDbSerialzation() throws JSONException, URISyntaxException
	{
		URI uri = new URI("http://test.com/");
		Map<String, Object> varsMap = new HashMap<String, Object>();
		varsMap.put(Workflow.REST_METHOD, method.PUT);
		varsMap.put(Workflow.REST_REQUEST, request);
		varsMap.put(Workflow.REST_URI, uri);
		varsMap.put(Workflow.REST_SERVER_TYPE, "local");
		varsMap.put(Workflow.REST_DB_STATUS_OBJ_ID, "obj444");
		varsMap.put(Workflow.REST_APP_IDENTIFIER, "app34343");
		

		when(execution.getVariable(Workflow.REST_API_JOB_ATTRS)).thenReturn(varsMap); 
		ReflectionTestUtils.invokeMethod(callRestApi, "convertRestRequestForDbSerialzation", execution);
		assertNull(callRestApi.errorMap);
	}
	
	@Test
	public void testReconstructRequestWithNullRequestObject() throws URISyntaxException
	{
		
		RestApiJob oJob = new RestApiJob();
		URI uri = new URI("http://test.com/");
		oJob.setUri(uri);
		oJob.setSourceType("ssdsd");
		oJob.setTransactionId("tr53535");
		oJob.setSpaceId(1255);
		oJob.setClientId(525555);
		oJob.setAppIdentifier("app34343");
		oJob.setCsvFileName("test.csv");
		oJob.setJsonFileName("test.json");
		oJob.setTargetType("target");
		oJob.setDbStatusObjectId("445fgf45da56i");
	
		ReflectionTestUtils.invokeMethod(callRestApi, "reconstructRequest", oJob, "Bearer sdsdsd");
		assertNull(callRestApi.errorMap);
	}
}
