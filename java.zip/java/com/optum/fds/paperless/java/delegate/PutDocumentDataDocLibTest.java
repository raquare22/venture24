package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.Answer;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class PutDocumentDataDocLibTest {
	
	@InjectMocks
	PutDocumentDataDocLib putDocumentDataDocLib;

    @Mock
    DocumentMetaDataService documentMetaDataService;
    
    @Mock
	RestTemplate restTemplate;

    @Mock
    private EhCache ehCache;
	
    @Mock
	private OauthManagerUtil oauthManagerUtil;
    
    DelegateExecution execution;
    
    private static final String APP_ID = "testapp";
	private static final String APP_SECRET = "testapp";
	private static final String ACCESS_TOKEN = "abc123";
	private static final String URL = "http://test.com";
	private static final Integer EXPIRES_IN = 1800;
    
    
    @Before
    public void setUp() throws Exception {
    	MockitoAnnotations.initMocks(this);

    	execution = new DelegateExecutionImpl();

        List<String> docIdsList = new ArrayList<String>();
    	docIdsList.add("123");
    	docIdsList.add("456");
        execution.setVariable(Workflow.NUM_RETRIES, 2);
        execution.setVariable(Workflow.TIME_TO_WAIT, 30);
        execution.setVariable(Workflow.DOCLIB_PUT_DOCUMENT_IDS, docIdsList);
        execution.setVariable(Workflow.DOCLIB_PUT_URL, "https://api-gateway.linkhealth.com/oauth/token%22");
	    execution.setVariable(Workflow.DOCLIB_OAUTH_URL, "https://api-gateway.linkhealth.com/oauth/token%22");
		execution.setVariable(Workflow.DOCLIB_CLIENT_ID, "doclib-fds-prod");
		execution.setVariable(Workflow.DOCLIB_CLIENT_SECRET, "efbc8525-bd34-43e9-8f13-0bdf86feea0a");
	    execution.setVariable(Workflow.DOCLIB_TEMPLATE_NAME, Templates.DOCLIB_PUT_REQUEST.getTemplate());
        
        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended(APP_ID, APP_SECRET);
		oauthTokenExtended.setUrl(URL);
		oauthTokenExtended.setAccessToken(ACCESS_TOKEN);
		oauthTokenExtended.setExpiresIn(EXPIRES_IN);
		oauthTokenExtended.setObtainedOn(new Date());
		Optional<OauthTokenExtended> optionalToken = Optional.of(oauthTokenExtended);
		when(oauthManagerUtil.getOauthTokenExtended(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), isNull())).thenReturn(optionalToken);
		


    }
    
    @Test
    public void testDoExecute() throws Exception {
    	ResponseEntity<String> response = new ResponseEntity<>("response", HttpStatus.OK);
	    
	    when(restTemplate.exchange(Mockito.any(String.class), Mockito.eq(HttpMethod.PUT), Mockito.any(), Mockito.eq(String.class))).thenReturn(response);
    	
        List<DocumentMetaData> docList = new ArrayList<>();
        docList.add(getDocumentMetaData());
        docList.add(getDocumentMetaData());
        
        when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);

        try (MockedStatic<EhCache> cacheMock = Mockito.mockStatic(EhCache.class)) {
            cacheMock.when(() -> ehCache.putOauthTokenWithExpiry(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenAnswer((Answer<Void>) invocation -> null);
            cacheMock.when(() -> ehCache.getOauthTokenCache(Mockito.anyString())).thenReturn("token123");
            putDocumentDataDocLib.execute(execution);
        }

        
        assertNotNull( putDocumentDataDocLib.errorMap);
    }
    
    @Test
    public void testDoExecuteEmptyList() throws Exception {
    	execution.setVariable(Workflow.DOCLIB_PUT_DOCUMENT_IDS, new ArrayList<>());
	    ResponseEntity<String> response = new ResponseEntity<>("response", HttpStatus.OK);
	    
	    when(restTemplate.exchange(Mockito.any(String.class), Mockito.eq(HttpMethod.PUT), Mockito.any(), Mockito.eq(String.class))).thenReturn(response);
    	
        List<DocumentMetaData> docList = new ArrayList<>();
        docList.add(getDocumentMetaData());
        docList.add(getDocumentMetaData());
        
        when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);
        putDocumentDataDocLib.execute(execution);
        
        assertNotNull( putDocumentDataDocLib.errorMap);
        assertEquals(0,  putDocumentDataDocLib.errorMap.get(Workflow.NEW_ERRORS));
    }
    
    @Test
    public void testHttpClientException() throws Exception {

    	  HttpClientErrorException httpBadRequest = HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST, null, null, null, null);
        HttpClientErrorException httpUnauthorized = HttpClientErrorException.Unauthorized.create(HttpStatus.UNAUTHORIZED, null, null, null, null);

        doThrow(httpBadRequest).when(restTemplate).exchange(Mockito.any(String.class), Mockito.eq(HttpMethod.PUT), Mockito.any(), Mockito.eq(String.class));
        doThrow(httpUnauthorized).when(restTemplate).exchange(Mockito.any(String.class), Mockito.eq(HttpMethod.PUT), Mockito.any(), Mockito.eq(String.class));

        List<DocumentMetaData> docList = new ArrayList<>();
        docList.add(getDocumentMetaData());
        docList.add(getDocumentMetaData());
        
        when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);
        try (MockedStatic<EhCache> cacheMock = Mockito.mockStatic(EhCache.class)) {
            cacheMock.when(() -> ehCache.putOauthTokenWithExpiry(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenAnswer((Answer<Void>) invocation -> null);
            cacheMock.when(() -> ehCache.getOauthTokenCache(Mockito.anyString())).thenReturn("token123");
            putDocumentDataDocLib.execute(execution);
        }
        
        assertNotNull( putDocumentDataDocLib.errorMap);
        assertEquals(2,  putDocumentDataDocLib.errorMap.get(Workflow.NEW_ERRORS));
    }

    @Test
    public void testHttpServerException() throws Exception {

        HttpServerErrorException httpBadGateway = HttpServerErrorException.BadGateway.create(HttpStatus.BAD_REQUEST, null, null, null, null);
        HttpServerErrorException httpTimeout = HttpServerErrorException.GatewayTimeout.create(HttpStatus.UNAUTHORIZED, null, null, null, null);

        doThrow(httpBadGateway).when(restTemplate).exchange(Mockito.any(String.class), Mockito.eq(HttpMethod.PUT), Mockito.any(), Mockito.eq(String.class));
        doThrow(httpTimeout).when(restTemplate).exchange(Mockito.any(String.class), Mockito.eq(HttpMethod.PUT), Mockito.any(), Mockito.eq(String.class));

        List<DocumentMetaData> docList = new ArrayList<>();
        docList.add(getDocumentMetaData());
        docList.add(getDocumentMetaData());

        when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);
        try (MockedStatic<EhCache> cacheMock = Mockito.mockStatic(EhCache.class)) {
            cacheMock.when(() -> ehCache.putOauthTokenWithExpiry(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenAnswer((Answer<Void>) invocation -> null);
            cacheMock.when(() -> ehCache.getOauthTokenCache(Mockito.anyString())).thenReturn("token123");
            putDocumentDataDocLib.execute(execution);
        }

        assertNotNull( putDocumentDataDocLib.errorMap);
    }
    
    @Test
    public void testRestClientException() throws Exception {
    	
        doThrow(RestClientException.class).when(restTemplate).exchange(Mockito.any(String.class), Mockito.eq(HttpMethod.PUT), Mockito.any(), Mockito.eq(String.class));
    	    	
        List<DocumentMetaData> docList = new ArrayList<>();
        docList.add(getDocumentMetaData());
        docList.add(getDocumentMetaData());
        
        when(documentMetaDataService.getDocumentMetaDataList(Mockito.any())).thenReturn(docList);
        try (MockedStatic<EhCache> cacheMock = Mockito.mockStatic(EhCache.class)) {
            cacheMock.when(() -> ehCache.putOauthTokenWithExpiry(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenAnswer((Answer<Void>) invocation -> null);
            cacheMock.when(() -> ehCache.getOauthTokenCache(Mockito.anyString())).thenReturn("token123");
            putDocumentDataDocLib.execute(execution);
        }
        
        assertNotNull( putDocumentDataDocLib.errorMap);
        assertEquals(2,  putDocumentDataDocLib.errorMap.get(Workflow.NEW_ERRORS));
    }
    
    private DocumentMetaData getDocumentMetaData() {
    	DocumentMetaData doc = new DocumentMetaData();
    	doc.setFdsAttachmentId("1234567");
    	doc.setDateCreated(new Date());
    	org.bson.Document metadata = new org.bson.Document();
    	metadata.put("paymentNumber", "12345");
    	doc.setMetadata(metadata);
    	
    	return doc;
    }
    

}
