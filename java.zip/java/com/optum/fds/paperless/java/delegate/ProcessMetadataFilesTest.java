package com.optum.fds.paperless.java.delegate;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;

import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.file.metadata.ProcessFileTask;

public class ProcessMetadataFilesTest {

	@Mock
	ProcessorsService processorsService;

	@Mock
	ProcessFileTask processFileTask;

	@Mock
	ProcessorFileTaskService processorFileTaskService;

	@InjectMocks
	ProcessMetadataFiles processMetadataFiles;

	DelegateExecution execution;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);
	}

	@Test
	public void testDoExecuteIsSuccess() {
		DelegateExecution exe = new DelegateExecutionImpl();
		ArrayList<String> processorFileTaskIds = new ArrayList<String>();
		processorFileTaskIds.add("p0df90df");
		processorFileTaskIds.add("09f9f9f");
		exe.setVariable("appIdentifier", "sdsdsd");
		exe.setVariable("processorTransactionId", "proro333");
		exe.setVariable("processorFileTaskIds", processorFileTaskIds);
		processMetadataFiles.doExecute(exe);
		assertEquals(null, processMetadataFiles.errorMap);
	}

}
