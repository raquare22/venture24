package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fs.workflow.java.delegate.bean.DelegateExecutionImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.mockito.stubbing.Stubber;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doAnswer;

public class RequiredVarsCleanUpAndACkTemplateTest {

	@Mock
    DelegateExecutionImpl delegateExecution;
	
	
    private Map<String, Object> delegateMap;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);


        delegateMap = new HashMap<String, Object>();
        MockitoAnnotations.initMocks(this);
        Stubber getDelegateMap = doAnswer(new Answer<Object>() {
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                return delegateMap.get(args[0]);
            }
        });
        getDelegateMap.when(delegateExecution).getVariable(Mockito.anyString(),Mockito.any());

        Stubber getVariablesMap = doAnswer(new Answer<Map<String, Object>>() {
            public Map<String, Object> answer(InvocationOnMock invocation) {
                return delegateMap;
            }
        });
        getVariablesMap.when(delegateExecution).getVariables();
        
        delegateMap.put(Workflow.SEARCH_CRITERIA, "temp");
        delegateMap.put(Workflow.SEARCH_WINDOW, "temp");
        delegateMap.put(Workflow.TEMPLATE_ID, "temp");
        delegateMap.put(Workflow.SFTP_HOSTNAME, "temp");
        delegateMap.put(Workflow.SFTP_USERNAME, "temp");
        delegateMap.put(Workflow.SFTP_PW,"temp");
        delegateMap.put(Workflow.SFTP_DIRECTORY,"temp");
    }
    
    @UserStory(references = "US24298")
    @RallyTestCase(references = "TC28799")
    @Test
    public void testSuccess() throws Exception {
    	RequiredVarsCleanUpAndACkTemplate verifyRequiredVars = new RequiredVarsCleanUpAndACkTemplate();
        verifyRequiredVars.execute(delegateExecution);
        assertTrue(verifyRequiredVars.errorMap.get("newErrors").equals(new Integer(0))); 
    }
    
    /**
     * Wrong json 
     * @throws Exception
     */
    @UserStory(references = "US24298")
    @RallyTestCase(references = "TC28800")
    @Test
    public void testErrors() throws Exception {
    	delegateMap.put(Workflow.SEARCH_CRITERIA, "");
        delegateMap.put(Workflow.SEARCH_WINDOW,"");
        RequiredVarsCleanUpAndACkTemplate verifyRequiredVars = new RequiredVarsCleanUpAndACkTemplate();
        verifyRequiredVars.execute(delegateExecution);
        assertTrue(verifyRequiredVars.errorMap.size()>1);
    }
}
