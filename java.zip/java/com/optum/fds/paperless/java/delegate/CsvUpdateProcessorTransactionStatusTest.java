package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import java.util.Map;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.jobs.CsvProcessorJob;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class CsvUpdateProcessorTransactionStatusTest {
	
	@Mock
	CsvProcessorsService csvProcessorsService;
	
    @Mock
	ProcessorService processorService;
    
//    @Mock
//    CsvProcessorJob csvProcessorJob;
    
    
    @InjectMocks
    CsvUpdateProcessorTransactionStatus csvUpdateProcessorTransactionStatus;
    
    DelegateExecution execution;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);
	}
	
	@Test
	public void testDoExecuteWithProcessorMetaDataNull()
	{
		CsvProcessorJob csvProcessorJob= new CsvProcessorJob();
		csvProcessorJob.setAppIdentifier("sdsdsd");
		csvProcessorJob.setProcessorId("prod2343");
		DelegateExecution exe = new DelegateExecutionImpl();
		exe.setVariable(Workflow.APP_IDENTIFIER, "sdsdsd");
		exe.setVariable(Workflow.JOB, csvProcessorJob);

		csvUpdateProcessorTransactionStatus.doExecute(exe);
		assertEquals(null, csvUpdateProcessorTransactionStatus.errorMap);
	}
	
	@Test
	public void testDExecuteWithMetaDataNotNull()
	{
		CsvProcessorJob csvProcessorJob= new CsvProcessorJob();
		csvProcessorJob.setAppIdentifier("sdsdsd");
		csvProcessorJob.setProcessorId("prod2343");
		DelegateExecution exe = new DelegateExecutionImpl();
		exe.setVariable(Workflow.APP_IDENTIFIER, "sdsdsd");
		exe.setVariable(Workflow.JOB, csvProcessorJob);
		
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setId("sdsdsd");
		processorMetaData.setProcess(Map.of("config", Map.of("test", "one")));
		
		when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString())).thenReturn(processorMetaData);
		csvUpdateProcessorTransactionStatus.doExecute(exe);
		assertEquals(null, csvUpdateProcessorTransactionStatus.errorMap);
		
	}
	
	@Test
	public void testDExecuteWithCsvProcessorTransactionNotNull()
	{
		CsvProcessorJob csvProcessorJob= new CsvProcessorJob();
		csvProcessorJob.setAppIdentifier("sdsdsd");
		csvProcessorJob.setProcessorId("prod2343");
		csvProcessorJob.setFileName("mytete.pdf");
		csvProcessorJob.setServerType("local");
		DelegateExecution exe = new DelegateExecutionImpl();
		exe.setVariable(Workflow.APP_IDENTIFIER, "sdsdsd");
		exe.setVariable(Workflow.JOB, csvProcessorJob);
		
		CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
		csvProcessorTransaction.setId("assasds");
		csvProcessorTransaction.setAppIdentifier("eireireir");
		
		when(csvProcessorsService.getCsvProcessorTransactionWithFileName(Mockito.anyString(), Mockito.anyString(), 
				Mockito.anyString(), Mockito.anyString())).thenReturn(csvProcessorTransaction);
		
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		processorMetaData.setId("sdsdsd");
		processorMetaData.setProcess(Map.of("config", Map.of("test", "one")));
		
		when(processorService.getProcessorMetaData(Mockito.anyString(), Mockito.anyString())).thenReturn(processorMetaData);
		csvUpdateProcessorTransactionStatus.doExecute(exe);
		assertEquals(null, csvUpdateProcessorTransactionStatus.errorMap);
		
	}
}
