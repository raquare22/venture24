package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.optum.fds.paperless.java.delegate.oauth.Oauth;
import com.optum.fds.paperless.java.delegate.oauth.OauthToken;

import com.optum.fds.paperless.workflow.constants.Workflow;

public class OauthTest {

	private static final String oauthUrl = "https://test-oauth-url";
	private static final String clientCredentials = "client_credentials";
	private static final String clientSecret = "hrknbqii1nc6267dtvjkk8gq6agelmb8j7thko36uug";
	private static final String clientId = "685";

	@InjectMocks
	Oauth oauth = new Oauth();

	@Mock
	RestTemplate sslCheckRestTemplate;

	@SuppressWarnings("unchecked")
	DelegateExecution execution = new DelegateExecutionImpl(new HashMap());

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);
		
		Document execVars = new Document().append(Workflow.CLIENT_ID, clientId)
				.append(Workflow.CLIENT_SECRET, clientSecret)
				.append(Workflow.GRANT_TYPE, clientCredentials)
				.append(Workflow.OAUTH_URL, oauthUrl);

		when(execution.getVariables()).thenReturn(execVars);
		
		when(execution.getVariable(Workflow.CLIENT_ID, String.class))
				.thenReturn(execVars.get(Workflow.CLIENT_ID, String.class));
		
		when(execution.getVariable(Workflow.CLIENT_SECRET, String.class))
		.thenReturn(execVars.get(Workflow.CLIENT_SECRET, String.class));
		
		when(execution.getVariable(Workflow.GRANT_TYPE, String.class))
		.thenReturn(execVars.get(Workflow.GRANT_TYPE, String.class));
		
		when(execution.getVariable(Workflow.CSV_PROCESSOR_TRANSACTION, String.class))
		.thenReturn(execVars.get(Workflow.OAUTH_URL, String.class));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testDoExecuteWithNullClientId() {
		when(execution.getVariable(Workflow.CLIENT_ID, String.class))
		.thenReturn(null);
		oauth.execute(execution);
		Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
		assertTrue(errorMap == null);

	}
	
	@Test
	public void testGetTokenIsSuccess()
	{
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("client_id", (String) execution.getVariable(Workflow.CLIENT_ID));
        params.add("client_secret", (String) execution.getVariable(Workflow.CLIENT_SECRET));
        params.add("grant_type", (String) execution.getVariable(Workflow.GRANT_TYPE));

        var headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(params,headers);
		
		 String url = oauthUrl;
         var builder = UriComponentsBuilder.fromUriString(url);

		OauthToken token = sslCheckRestTemplate.postForObject(builder.build().encode().toUri(), request, OauthToken.class);
		ReflectionTestUtils.invokeMethod(oauth, "getToken", token, execution);
	}
	
}
