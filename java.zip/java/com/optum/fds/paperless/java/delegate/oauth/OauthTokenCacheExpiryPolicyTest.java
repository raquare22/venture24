package com.optum.fds.paperless.java.delegate.oauth;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.time.Duration;
import java.util.function.Supplier;

import org.junit.Before;
import org.junit.Test;

import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;

public class OauthTokenCacheExpiryPolicyTest {

    private OauthTokenCacheExpiryPolicy policy;

    @Before
    public void setUp() {
        policy = new OauthTokenCacheExpiryPolicy();
    }

    @Test
    public void testGetExpiryForCreation_whenExpiresInIsPositive_returnsDurationInMillis() {
        OauthTokenExtended oauthToken = new OauthTokenExtended("access-token", 5);

        Duration duration = policy.getExpiryForCreation("oauth-key", oauthToken);

        assertEquals(Duration.ofMillis(5000), duration);
    }

    @Test
    public void testGetExpiryForCreation_whenExpiresInIsZero_returnsDurationZero() {
        OauthTokenExtended oauthToken = new OauthTokenExtended("access-token", 0);

        Duration duration = policy.getExpiryForCreation("oauth-key", oauthToken);

        assertEquals(Duration.ZERO, duration);
    }

    @Test
    public void testGetExpiryForAccess_returnsNull() {
        Supplier<OauthTokenExtended> supplier = () -> new OauthTokenExtended("access-token", 10);

        Duration duration = policy.getExpiryForAccess("oauth-key", supplier);

        assertNull(duration);
    }

    @Test
    public void testGetExpiryForUpdate_returnsCreationExpiryForNewValue() {
        Supplier<OauthTokenExtended> oldValueSupplier = () -> new OauthTokenExtended("old-token", 1);
        OauthTokenExtended newValue = new OauthTokenExtended("new-token", 7);

        Duration duration = policy.getExpiryForUpdate("oauth-key", oldValueSupplier, newValue);

        assertEquals(Duration.ofMillis(7000), duration);
    }
}

