package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.domain.service.ProcessorTransactionService;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;

public class UpdateProcessorTransactionMetadataTest {

	private final String PATH_JSON_FILE = "InputJson/UpdateProcessorTransactionMetadataJson.json";

	DelegateExecution execution = new DelegateExecutionImpl();

	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();

	@Mock
	ProcessorTransactionService processorTransactionService;

	@Mock
	EmailService emailService;

	@InjectMocks
	UpdateProcessorTransactionMetadata updateProcessorTransactionMetadata;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		when(emailService.sendEmail(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
	}

	@Test
	public void testDoExecute() throws Exception {
		String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
		execution.setVariable(Workflow.JSON_FILE, jsonFile);
		execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath());
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, "addedToCosmosPraResponseFile");
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, "true");

		when(processorTransactionService.updateProcessorTransactionMetaData(Mockito.any())).thenReturn(null);
		updateProcessorTransactionMetadata.execute(execution);
		assertNotNull(updateProcessorTransactionMetadata.errorMap);
		assertEquals(0, updateProcessorTransactionMetadata.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testDoExecuteWithMissingRequiredVariables() throws Exception {

		execution.setVariable(Workflow.JSON_FILE, null);
		execution.setVariable(Workflow.OUTPUT_FILE_DIR, null);
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, null);
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, null);

		updateProcessorTransactionMetadata.execute(execution);
		assertNotNull(updateProcessorTransactionMetadata.errorMap);
		assertEquals(4, updateProcessorTransactionMetadata.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testDoExecuteWithInvalidJsonFile() throws Exception {
		String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();

		execution.setVariable(Workflow.JSON_FILE, jsonFile + "1");
		execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempFolder.getRoot().getAbsolutePath());
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, "addedToCosmosPraResponseFile");
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, "true");

		updateProcessorTransactionMetadata.execute(execution);
		assertNotNull(updateProcessorTransactionMetadata.errorMap);
		assertEquals(1, updateProcessorTransactionMetadata.errorMap.get(Workflow.NEW_ERRORS));
	}

}
