package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.util.concurrent.RateLimiter;
import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.java.delegate.docvault.OutOfRetriesException;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.model.ActiveUser;
import com.optum.fds.paperless.model.User;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.mockito.MockedStatic;


public class RetrieveEmailFromDigiSecTest {
	
	@InjectMocks
	RetrieveEmailFromDigiSec retrieveEmailFromDigiSec;
	
	@Mock
	private RateLimiter rateLimiter;

	@Mock
	EhCache ehCache;
	
	@Mock
	private OauthManagerUtil oauthManagerUtil;
    
	@Mock
    private DocumentMetaDataService documentMetaDataService;
	
	@Mock
	RestTemplate restTemplate;
	
	DelegateExecution execution = new DelegateExecutionImpl();
	
	Optional<OauthTokenExtended> optionalToken;
	
	private static final String APP_ID = "testapp";
	private static final String APP_SECRET = "testapp";
	private static final String URL = "http://test.com";
	
	@Before
	public void init() throws OutOfRetriesException  {
		MockitoAnnotations.openMocks(this);
        
        execution.setVariable(Workflow.PES_APP_ID,APP_ID);
		execution.setVariable(Workflow.PES_OAUTH_URL, URL);
		execution.setVariable(Workflow.PES_APP_SECRET, APP_SECRET);
		execution.setVariable(Workflow.PES_GRANT_TYPE, "client_credentials");
		execution.setVariable(Workflow.SPACE_ID, "1234");

		List<String> spaceIdList = new ArrayList<>();
		spaceIdList.add("11702");
		spaceIdList.add("20302");

		ReflectionTestUtils.setField(retrieveEmailFromDigiSec, "emailWorkflowSpaceIds", spaceIdList);
		
		ReflectionTestUtils.setField(retrieveEmailFromDigiSec, "useDigiSecPAA", false);
		ReflectionTestUtils.setField(retrieveEmailFromDigiSec, "DIGISEC_TPS", 5);

		ReflectionTestUtils.setField(retrieveEmailFromDigiSec, "DigiSecPAAURL", "url");
		ReflectionTestUtils.setField(retrieveEmailFromDigiSec, "DigiSecUserURL", "url");
		ReflectionTestUtils.setField(retrieveEmailFromDigiSec, "DIGISEC_JWT_TOKEN_SECRET_KEY", "123");
		ReflectionTestUtils.setField(retrieveEmailFromDigiSec, "DIGISEC_JWT_TOKEN_ISS", "123");
		ReflectionTestUtils.setField(retrieveEmailFromDigiSec, "DIGISEC_JWT_TOKEN_SUB", "123");
        ReflectionTestUtils.setField(retrieveEmailFromDigiSec, "digisecMultipleEmailsClientList", "IHR");
        ReflectionTestUtils.setField(retrieveEmailFromDigiSec, "digisecPAAEmailClientList", "CC,TRACKIT");
        
    	OauthTokenExtended oauthTokenExtended = new OauthTokenExtended("testapp", "testapp");
		oauthTokenExtended.setAccessToken("abc1123");
		oauthTokenExtended.setExpiresIn(1800);
		oauthTokenExtended.setObtainedOn(new Date());
		
		optionalToken = Optional.of(oauthTokenExtended);
        
        when(oauthManagerUtil.getOauthTokenExtended(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), isNull()))
		.thenReturn(optionalToken); 
        
        
        when(documentMetaDataService.getDocumentMetaData(Mockito.anyString())).thenReturn(getDocument());  
        
        
        
	}
	
	@Test
	public void testPartialMockedEhCache() throws Exception {
		
        try (MockedStatic<EhCache> ehCacheStatic = mockStatic(EhCache.class)) {
        	
        	ehCacheStatic.when(() -> ehCache.getOauthTokenCache(Mockito.anyString())).thenReturn("mocked_token");
        	
        	String returnValue = ehCache.getOauthTokenCache("val");
    		assertEquals("mocked_token", returnValue);
        }
		
	}
	
	@Test
	public void testGetEmailsByCorporateIHR() throws Exception
	{
		
		try (MockedStatic<EhCache> ehCacheStatic = mockStatic(EhCache.class)) {
			
			ehCacheStatic.when(() -> ehCache.getOauthTokenCache(Mockito.anyString())).thenReturn("mocked_token");
			
			List<DocumentMetaData> docList =new ArrayList<>();
			docList.add(getDocument());
			
			execution.setVariable("documentMetaDataList", docList);

	        execution.setVariable(Workflow.CLIENT_NAME, "IHR");

	        when(documentMetaDataService.getDocumentMetaData(Mockito.anyString())).thenReturn(getDocument());  
	        when(restTemplate.exchange(Mockito.any(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<String>>any()))
        	.thenReturn(response());
	        
	        retrieveEmailFromDigiSec.execute(execution);
	        
	        Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
	        
	        assertTrue((Integer) errorMap.get("newErrors") == 0);
		}
		
	}
	
	@Test
	public void getEmailsByCorporateADTTest() throws Exception
	{
		
		try (MockedStatic<EhCache> ehCacheStatic = mockStatic(EhCache.class)) {
			ehCacheStatic.when(() -> ehCache.getOauthTokenCache(Mockito.anyString())).thenReturn("mocked_token");
			when(restTemplate.exchange(Mockito.any(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<String>>any()))
        	.thenReturn(response());

			execution.setVariable(Workflow.CLIENT_NAME, "TRACKIT");
			execution.setVariable(Workflow.SPACE_ID, "11702");
			
			List<DocumentMetaData> docList = new ArrayList<>();
			

			docList.add(getDocument());
			
			Map<String, List<String>> map = new HashMap<>();
			List<String> idList = new ArrayList<>();
			idList.add("id123");
			map.put("dfere444", idList);
			
	    	execution.setVariable("uniqueFieldDocumentList", docList);
	    	execution.setVariable("uniqueFieldMap", map);
			
			retrieveEmailFromDigiSec.execute(execution);
			
			Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
			assertTrue((Integer) errorMap.get("newErrors") == 0);
		}
		
		
	}
	
	@Test
	public void getEmailsByCorporateTestTrackItNullEmail() throws Exception {
		
		try (MockedStatic<EhCache> ehCacheStatic = mockStatic(EhCache.class)) {
			
			ehCacheStatic.when(() -> ehCache.getOauthTokenCache(Mockito.anyString())).thenReturn("mocked_token");
			 
			execution.setVariable(Workflow.CLIENT_NAME, "TRACKIT");
			execution.setVariable(Workflow.SPACE_ID, "11702");
		 
			List<DocumentMetaData> docList = new ArrayList<>();
			
	
			docList.add(getDocument());
			
			Map<String, List<String>> map = new HashMap<>();
			List<String> idList = new ArrayList<>();
			idList.add("id123");
			map.put("dfere444", idList);
			
	    	execution.setVariable("uniqueFieldDocumentList", docList);
	    	execution.setVariable("uniqueFieldMap", map);
			
	    	when(restTemplate.exchange(Mockito.any(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<String>>any()))
        	.thenReturn(getNullEmailResponse());
	    	
			retrieveEmailFromDigiSec.execute(execution);
			
			Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
			assertTrue((Integer) errorMap.get("newErrors") == 0);
		}
	}

    @Test
    public void getEmailsByCorporateTestTrackItDigiSecPAAURL() throws Exception {

        try (MockedStatic<EhCache> ehCacheStatic = mockStatic(EhCache.class)) {

            ehCacheStatic.when(() -> ehCache.getOauthTokenCache(Mockito.anyString())).thenReturn("mocked_token");


            ReflectionTestUtils.setField(retrieveEmailFromDigiSec, "useDigiSecPAA", true);
            execution.setVariable(Workflow.CLIENT_NAME, "TRACKIT");
            execution.setVariable(Workflow.SPACE_ID, "11702");

            List<DocumentMetaData> docList = new ArrayList<>();


            docList.add(getDocument());

            Map<String, List<String>> map = new HashMap<>();
            List<String> idList = new ArrayList<>();
            idList.add("id123");
            map.put("dfere444", idList);

            execution.setVariable("uniqueFieldDocumentList", docList);
            execution.setVariable("uniqueFieldMap", map);

            when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<String>>any()))
                    .thenReturn(getPAAEmailResponse());

            retrieveEmailFromDigiSec.execute(execution);

            Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
            assertTrue((Integer) errorMap.get("newErrors") == 0);
        }
    }
	
	
	@Test
	public void getEmailsByCorporateTestIHRBadRequest() throws Exception {
		
		try (MockedStatic<EhCache> ehCacheStatic = mockStatic(EhCache.class)) {
			
			ehCacheStatic.when(() -> ehCache.getOauthTokenCache(Mockito.anyString())).thenReturn("mocked_token");
			
			List<DocumentMetaData> docList =new ArrayList<>();
			docList.add(getDocument());
			
			execution.setVariable("documentMetaDataList", docList);
	    	
	    	execution.setVariable(Workflow.CLIENT_NAME, "IHR");
			execution.setVariable(Workflow.SPACE_ID, "11302");
			
			HttpClientErrorException badRequestException = HttpClientErrorException.BadRequest
					.create(HttpStatus.BAD_REQUEST, null, null, null, null);	        
			
			when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<String>>any()))
        	.thenThrow(badRequestException);

			retrieveEmailFromDigiSec.execute(execution);
			
			Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
			assertTrue((Integer) errorMap.get("newErrors") == 0);
		}
	}
	
	@Test
	public void getEmailsByCorporateTestIHRBadGateway() throws Exception {
		
		try (MockedStatic<EhCache> ehCacheStatic = mockStatic(EhCache.class)) {
			
			ehCacheStatic.when(() -> ehCache.getOauthTokenCache(Mockito.anyString())).thenReturn("mocked_token");
			
			List<DocumentMetaData> docList =new ArrayList<>();
			docList.add(getDocument());
			
			execution.setVariable("documentMetaDataList", docList);
	    	
	    	execution.setVariable(Workflow.CLIENT_NAME, "IHR");
			execution.setVariable(Workflow.SPACE_ID, "11302");
			
			HttpServerErrorException badGatewayException = HttpServerErrorException.BadGateway
					.create(HttpStatus.BAD_GATEWAY, null, null, null, null);	        
			
			when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<String>>any()))
        	.thenThrow(badGatewayException);

			retrieveEmailFromDigiSec.execute(execution);
			
			Map<String, Object> errorMap = execution.getVariable(Workflow.ERROR_MAP, Map.class);
			assertEquals(1, errorMap.get("newErrors"));
		}
	}
	
	@Test
	public void testGetEmailList()
	{
		List<User> users=new ArrayList<>();
		
		User user1=new User();
		user1.setFirstName("EMILY");
		user1.setLastName("KUHN");
		user1.setEmail("emily.kuhn@optum.com");
		user1.setUserType("PA");
		
		User user2=new User();
		
		user2.setFirstName("Jennifer");
		user2.setLastName("Rodrigue");
		user2.setEmail("Jennifer_L_Rodrigue@uhc.com");
		user2.setUserType("SU");
		
		users.add(user1);
		users.add(user2);
		
		List<String> expected=new ArrayList<>();
		expected.add("emily.kuhn@optum.com");
		expected.add("Jennifer_L_Rodrigue@uhc.com");
		
		List<String> result=ReflectionTestUtils.invokeMethod(retrieveEmailFromDigiSec,"getEmailList",users);
		
		assertEquals(expected,result);
		
	}
	
	@Test
	public void testGetPAAEmail() throws JsonProcessingException {
        List<User> users=new ArrayList<>();

        User user1=new User();
        user1.setFirstName("EMILY");
        user1.setLastName("KUHN");
        user1.setEmail("test@optum.com");
        user1.setUserType("PA");

        User user2=new User();

        user2.setFirstName("Jennifer");
        user2.setLastName("Rodrigue");
        user2.setEmail("Jennifer_L_Rodrigue@uhc.com");
        user2.setUserType("SU");
        users.add(user1);
        users.add(user2);
        ActiveUser responseBody= new ActiveUser();
        responseBody.setCorpMpin("002345673");
        responseBody.setTin("004567893");
        responseBody.setUsers(users);

        ReflectionTestUtils.setField(retrieveEmailFromDigiSec, "useDigiSecPAA", false);

        ObjectMapper mapper = new ObjectMapper();
        String responseStr = mapper.writeValueAsString(responseBody);
        List<String> result=ReflectionTestUtils.invokeMethod(retrieveEmailFromDigiSec,"getPAAEmail",responseStr);

		List<String> expected=new ArrayList<>();
		expected.add("test@optum.com");
		
		assertEquals(expected,result);
		
	}
	
	@Test
	public void testGetNullPAAEmail() throws JsonProcessingException {
        List<User> users=new ArrayList<>();

        User user1=new User();
        user1.setFirstName("EMILY");
        user1.setLastName("KUHN");
        user1.setEmail(null);
        user1.setUserType("PA");

        User user2=new User();

        user2.setFirstName("Jennifer");
        user2.setLastName("Rodrigue");
        user2.setEmail("Jennifer_L_Rodrigue@uhc.com");
        user2.setUserType("SU");

        users.add(user1);
        users.add(user2);

        ActiveUser responseBody= new ActiveUser();

        responseBody.setCorpMpin("002345673");
        responseBody.setTin("004567893");
        responseBody.setUsers(users);

        ObjectMapper mapper = new ObjectMapper();
        String responseStr = mapper.writeValueAsString(responseBody);
		List<String> result=ReflectionTestUtils.invokeMethod(retrieveEmailFromDigiSec,"getPAAEmail",responseStr);

        List<String> expected=new ArrayList<>();
		
		assertEquals(expected,result);
	}
	
	
	private DocumentMetaData getDocument() {
		DocumentMetaData doc = new DocumentMetaData();
		
		doc.setId("123");
		org.bson.Document metadata = new org.bson.Document();
		metadata.put("tin", "123");
		metadata.put("corporateMpin", "123");
		
		doc.setMetadata(metadata);
		return doc;
	}
	
	private ResponseEntity<String> response() throws JsonProcessingException
	{
		
	    List<User> users=new ArrayList<>();
		
		User user1=new User();
		user1.setFirstName("EMILY");
		user1.setLastName("KUHN");
		user1.setEmail("emily.kuhn@optum.com");
		user1.setUserType("PA");
		
		User user2=new User();
		
		user2.setFirstName("Jennifer");
		user2.setLastName("Rodrigue");
		user2.setEmail("Jennifer_L_Rodrigue@uhc.com");
		user2.setUserType("SU");
		
		users.add(user1);
		users.add(user2);
        
        ActiveUser responseBody= new ActiveUser();
        
        responseBody.setCorpMpin("002345673"); 
        responseBody.setTin("004567893"); 
        responseBody.setUsers(users);  
        
        ObjectMapper mapper = new ObjectMapper();
        String responseStr = mapper.writeValueAsString(responseBody);
        
        ResponseEntity<String> response = new ResponseEntity<String>(responseStr,
				HttpStatus.OK);
        
        return response;
		
	}
	
	private ResponseEntity<String> getNullEmailResponse() throws JsonProcessingException
	{
		
	    List<User> users=new ArrayList<>();
		
		User user1=new User();
		user1.setFirstName("EMILY");
		user1.setLastName("KUHN");
		user1.setUserType("PA");

		
		users.add(user1);
        
        ActiveUser responseBody= new ActiveUser();
        
        responseBody.setCorpMpin("002345673"); 
        responseBody.setTin("004567893"); 
        responseBody.setUsers(users);  
        
        ObjectMapper mapper = new ObjectMapper();
        String responseStr = mapper.writeValueAsString(responseBody);
        
        ResponseEntity<String> response = new ResponseEntity<String>(responseBody.toString(),
				HttpStatus.OK);
        
        return response;
		
	}

    private ResponseEntity<String> getPAAEmailResponse() throws JsonProcessingException
    {

        String responseBody = "{\n" +
                "\t\"uuid\": \"8851a46f-e755-49b0-8429-da04b0943ed8\",\n" +
                "\t\"oneHealthId\": \"test\",\n" +
                "\t\"firstName\": \"Test\",\n" +
                "\t\"lastName\": \"Test\",\n" +
                "\t\"email\": \"test@test.com\",\n" +
                "\t\"userType\": \"PA\",\n" +
                "\t\"phone\": \"(123) 456-7890\"\n" +
                "}";

        ResponseEntity<String> response = new ResponseEntity<String>(responseBody,
                HttpStatus.OK);

        return response;

    }
	
}