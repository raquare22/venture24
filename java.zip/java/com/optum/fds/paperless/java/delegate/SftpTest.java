package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.domain.service.ScheduledSftpMonitor;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.SftpMonitorUtil;
import com.optum.fds.paperless.util.SftpUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class SftpTest {
	
	@InjectMocks
	Sftp sftp;
	
	@Mock
    ScheduledSftpMonitor scheduledSftpMonitor;
    
	@Mock
    ErrorMetaDataService errorMetaDataService;
    
	@Mock
    SftpUtil sftpUtil;
    
	@Mock
    SftpMonitorUtil sftpMonitorUtil;
    
	@Mock
    ProcessorService processorService;
    
	@Mock
    ProcessorsService processorsService;
	
	@Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();
	
	DelegateExecution execution;
	
	private static final String sftpUSER = "test";
	private static final String sftpPASS = "test";
	private static final String sftpHost = "localhost";

    
    private static final String HOST_NAME_SOURCE = "host_name_source";
    private static final String USER_NAME_SOURCE = "username_source";
    private static final String USER_CREDENTIALS_SOURCE = "pw_source";
    private static final String FTP_ROOT_DIR = "ftp_rootdir";
    private static final String FTP_ARCHIVE_DIR = "ftp_archivedir";
    public static final String INGEST_PATH_PROPERTY_NAME = "INGEST_ROOT";
    private static final int SFTP_PORT = 22;
    private static final String FILE_TYPE = "fileType";
    private static final String DIRECTORY_LISTING = "directoryListing";
    private static final String CHANNEL_SFTP = "channelSftp";
	
	@Before
    public void setUp() {
		MockitoAnnotations.initMocks(this);
		
		
		ReflectionTestUtils.setField(sftp, "ingestRoot", "/ingest");
		
    	execution = new DelegateExecutionImpl();
    	execution.setVariable(Workflow.PROCESSOR_METADATA, getProcessor());
		when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
		when(sftpUtil.isEnoughFreeSpace(Mockito.any(), Mockito.anyBoolean())).thenReturn(true);
	}
	
	@Test
    public void testCleanIngestTest() throws IOException, JSchException, SftpException {
		when(sftpMonitorUtil.exceptionForMissingLoginCredential(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
			.thenReturn(false);
        when(sftpMonitorUtil.hasValidStatus(Mockito.any())).thenReturn(true);
        
        Map<String, Object> result = getProcessSftpResults();
		when(sftpMonitorUtil.proccessSFTPDirectory(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any()))
			.thenReturn(result);
		
		String tempFolderStr = tempFolder.getRoot().getAbsolutePath();
		
		when(sftpMonitorUtil.createFileOutputDirectoryPath(anyMap(), any(ProcessorMetaData.class), anyString()))
			.thenReturn(tempFolderStr + "/test1");
		
		when(processorsService.createTransactionRecord(Mockito.any())).thenReturn(getTransactionRecord());
        when(processorsService.createProcessorTransaction(any(ProcessorMetaData.class), anyString(), anyString(), anyString()))
        	.thenReturn(getProcessorTransaction());
        when(processorsService.findProcessorMetaDataByFileName(Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		
		sftp.execute(execution);
        assertNotNull( sftp.errorMap);
        assertEquals(0,  sftp.errorMap.get(Workflow.NEW_ERRORS));
        assertNotNull(execution.getVariable(Workflow.FILE_PATH, String.class));
        assertEquals(tempFolderStr + "/test1/test.txt", execution.getVariable(Workflow.FILE_PATH, String.class));
    }
    
    
//    @Test(expected = IOException.class)
    public void testIOException() {
    	execution = new DelegateExecutionImpl();
    	execution.setVariable(Workflow.PROCESSOR_METADATA, getProcessor1());
    	sftp.execute(execution);
    	assertNotNull( sftp.errorMap);
        assertEquals(0,  sftp.errorMap.get(Workflow.NEW_ERRORS));
    }
    
    private Transaction getTransactionRecord() {
    	Transaction t = new Transaction();
    	t.setTransactionId("1234");
    	return t;
    }
    
    private Object getChannelSftp() {
        return mock(ChannelSftp.class);
    }
    
    private ArrayList<ChannelSftp.LsEntry> getDirectoryListing1() {
        ArrayList<ChannelSftp.LsEntry> directoryListing = new ArrayList<>();
        
        ChannelSftp.LsEntry lsEntry4 = mock(ChannelSftp.LsEntry.class);
        when(lsEntry4.getFilename()).thenReturn("test.txt");
        
        ChannelSftp.LsEntry lsEntry3 = mock(ChannelSftp.LsEntry.class);
        when(lsEntry3.getFilename()).thenReturn("invalid_file.zip");

        directoryListing.add(lsEntry4);
        directoryListing.add(lsEntry3);
        return directoryListing;
    }
    
    private Map<String,Object> getProcessSftpResults() {
    	Map<String, Object> processSftpResults = new HashMap<>();
    	processSftpResults.put("channelSftp", getChannelSftp());
    	processSftpResults.put("directoryListing", getDirectoryListing1());
    	return processSftpResults;
    }
    
    private ProcessorTransaction getProcessorTransaction() {
    	ProcessorTransaction p = new ProcessorTransaction();
    	p.setId("12345");
    	return p;
    }
    
    private ProcessorMetaData getProcessor() {
    	ProcessorMetaData pmd = new ProcessorMetaData();
    	pmd.setConfigSpaceId(123);
    	pmd.setAppIdentifier("123456");
    	
    	Map<String, Object> process = new HashMap<>();
    	Map<String, Object> config = new HashMap<>();
    	
    	config.put("fileType", ".txt");
    	config.put(HOST_NAME_SOURCE, "localhost");
    	config.put(USER_NAME_SOURCE, sftpUSER);
    	config.put(USER_CREDENTIALS_SOURCE, sftpPASS);
    	config.put(FTP_ROOT_DIR, "/Users/bconnect/dropzone/letgen");
    	config.put(FTP_ARCHIVE_DIR, "/Users/bconnect/dropzone/letgen/archive");
    	
    	
    	process.put("config", config);
    	pmd.setProcess(process);
    	pmd.setStatus(MetaDataStatus.IN_PROCESS);
    	
    	return pmd;
    }
    
    private ProcessorMetaData getProcessor1() {
    	ProcessorMetaData pmd = new ProcessorMetaData();
    	pmd.setConfigSpaceId(123);
    	
    	Map<String, Object> process = new HashMap<>();
    	Map<String, Object> config = new HashMap<>();

    	process.put("config", config);
    	pmd.setProcess(process);
    	
    	return pmd;
    }

}
