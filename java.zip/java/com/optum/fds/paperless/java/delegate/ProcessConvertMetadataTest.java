package com.optum.fds.paperless.java.delegate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.client.pojo.UNET;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.file.metadata.PostCardInd;
import com.optum.fds.paperless.mongo.file.metadata.ProcessFileTask;
import com.optum.fds.paperless.util.Utilities;
import org.flowable.engine.delegate.DelegateExecution;
import org.json.JSONTokener;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.*;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ProcessConvertMetadataTest {

    @Mock
    DocumentMetaDataService documentMetaDataService;

//    @Mock
    ObjectMapper mapper;

    @Mock
    PostCardInd postCardInd;

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    @InjectMocks
    ProcessConvertMetadata processConvertMetadata;

    DelegateExecution execution = new DelegateExecutionImpl();

    private final String PATH_JSON_FILE = "ProcessConvertMetadata/InputExampleJson.json";
    protected String schemaFileBasePath = File.separator + "schemas" + File.separator;

    @Before
    public void setup() {
        mapper = new ObjectMapper();
        ReflectionTestUtils.setField(processConvertMetadata, "mapper", mapper);
        when(documentMetaDataService.updateDocMetaData(any(), any())).thenReturn(getDocumentMetaData());
        when(postCardInd.getPostCardInd(any())).thenReturn(true);

    }

    @Test
    public void testDoExecuteUNET() throws Exception {
        // Setup
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable("jsonFile", jsonFile);
        execution.setVariable("clientName", "UNET");
        execution.setVariable("spaceId", 8888);

        ReflectionTestUtils.setField(processConvertMetadata, "schemaFileBasePath", Utilities.getInstance().getResourceFile("schemas").getAbsolutePath() + "/");

        String resourceFile = getResourceFileAsString(schemaFileBasePath + "UNET_client_schema.json");
        JSONTokener tokener = new JSONTokener(resourceFile);
        ProcessConvertMetadata spyProcessConvertMetadata = Mockito.spy(processConvertMetadata);
        Mockito.doReturn(tokener).when(spyProcessConvertMetadata).getClientSchema(any());
        Mockito.doReturn(UNET.class).when(spyProcessConvertMetadata).getClassFromClientName(any());

        spyProcessConvertMetadata.execute(execution);

        List<String> result = execution.getVariable("convertedDocs", List.class);
        System.out.println(result);
        assertNotNull(result);
        assertEquals(2, result.size());

    }

    @Test
    public void testDoExecuteInvalidClientName() throws Exception {
        // Setup
        String jsonFile = Utilities.getInstance().getResourceFile(PATH_JSON_FILE).getAbsolutePath();
        execution.setVariable("jsonFile", jsonFile);
        execution.setVariable("clientName", "test123");
        execution.setVariable("spaceId", 8888);
        ReflectionTestUtils.setField(processConvertMetadata, "schemaFileBasePath", Utilities.getInstance().getResourceFile("schemas").getAbsolutePath() + "/");
        ProcessConvertMetadata spyProcessConvertMetadata = Mockito.spy(processConvertMetadata);
        spyProcessConvertMetadata.execute(execution);
        Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
        System.out.println(errorMap);
        assertNotNull(errorMap);
        assertEquals(2, errorMap.size());

    }


    private DocumentMetaData getDocumentMetaData() {
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setMetadata(new org.bson.Document());
        documentMetaData.setId("12345");
        documentMetaData.setSpaceId(8888);
        return documentMetaData;
    }

    public static String getResourceFileAsString(String fileName) throws IOException {
        ClassLoader classLoader = ClassLoader.getSystemClassLoader();
        try (InputStream is = ProcessFileTask.class.getResourceAsStream(fileName);) {
            if (is == null) return null;
            try (InputStreamReader isr = new InputStreamReader(is);
                 BufferedReader reader = new BufferedReader(isr)) {
                return reader.lines().collect(Collectors.joining(System.lineSeparator()));
            }
        }
    }

    public JSONTokener getClientSchema(String clientName) throws IOException {
        return new JSONTokener(getResourceFileAsString(schemaFileBasePath + clientName + "_client_schema.json"));
    }

    public String inputStreamToString(InputStream is) throws IOException {
        StringBuilder sb = new StringBuilder();
        String line;
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        br.close();
        return sb.toString();
    }
}
