package com.optum.fds.paperless.java.delegate.oauth.bean;

import org.joda.time.DateTime;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class OauthTokenExtendedTest {

    @Test
    public void test() {
        OauthTokenExtended oauthTokenExtended = new OauthTokenExtended("username", "password");
        oauthTokenExtended.getAccessToken();
        oauthTokenExtended.getApplicationId();
        oauthTokenExtended.setAccessToken(new String());
        oauthTokenExtended.getTokenType();
        oauthTokenExtended.setTokenType(new String());
        oauthTokenExtended.getGrantType();
        oauthTokenExtended.setGrantType("grantType");
        oauthTokenExtended.setExpiresIn(new Integer(3000));
        oauthTokenExtended.getExpiresIn();
        oauthTokenExtended.setUrl("url");
        oauthTokenExtended.getUrl();
        oauthTokenExtended.setObtainedOn(new DateTime().toDate());
        oauthTokenExtended.getObtainedOn();
        oauthTokenExtended.isTokenGoingToExpire();
        oauthTokenExtended.setScope(new String());
        oauthTokenExtended.getScope();
    }

    @Test
    public void testConstructorTwo() {
        OauthTokenExtended obj = new OauthTokenExtended("username", "password", "fdsHost","grantType","scope");
        assertNotNull(obj);
        obj.getPassword();
        obj.getScope();
        obj.setObtainedOn(null);
        obj.isTokenGoingToExpire();
    }

    @Test
    public void testConstructorT() {
        OauthTokenExtended obj = new OauthTokenExtended(new OauthTokenExtended("username", "password", "fdsHost","grantType","scope"));
        assertNotNull(obj);
        obj.getPassword();
        obj.setObtainedOn(null);
        obj.isTokenGoingToExpire();
    }

}
