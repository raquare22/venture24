package com.optum.fds.paperless.java.delegate.oauth;

import static org.junit.Assert.*;
import org.junit.Test;

public class OauthTokenTest {

	@Test
	public void testSetAccessToken()
	{
		OauthToken oauthToken = new OauthToken();
		oauthToken.setAccessToken("testAccessToken");
		assertEquals("testAccessToken", oauthToken.getAccessToken());
	}
	
	@Test
	public void testSetTokenType()
	{
		OauthToken oauthToken = new OauthToken();
		oauthToken.setTokenType("testTokenType");
		assertEquals("testTokenType", oauthToken.getTokenType());
	}
	
//	@Test
//	public void testSetExpiresIn()
//	{
//		OauthToken oauthToken = new OauthToken();
//		oauthToken.setExpiresIn(35);
//		assertEquals(35, oauthToken.getExpiresIn());
//	}
	
	@Test
	public void testSetRefreshToken()
	{
		OauthToken oauthToken = new OauthToken();
		oauthToken.setRefresh_token("testRefreshToken");
		assertEquals("testRefreshToken", oauthToken.getRefresh_token());
	}
}
