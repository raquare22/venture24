package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.FilestoreService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;

public class IdentifyStorageErrorDocumentsTest {

    @InjectMocks
    private IdentifyStorageErrorDocuments identifyStorageErrorDocuments;

    @Mock
    DocumentMetaDataService documentMetaDataService;

    @Mock
    HookService hookService;

    @Mock
    private FilestoreService fileStoreService;

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    private DelegateExecution execution = new DelegateExecutionImpl();

    private static final int maxDocOccur = 100;
    private static final String fdsUrl = "https://testurl";
    private static final int clientId = 704;
    private static final String spaceId = "10102";
    private static final String appId = "d0g767pzqpkznfryzetenrcpt8ql2uxu";
    private static final String searchWindow = "{\"start_date_offset\":{\"time_window\":\"72\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"2\",\"format\":\"Hours\"}}";
    private static final String searchCriteria = "{\"spaceId\" : 20102, \"status\" : \"AVAILABLE\", \"metadata.rprntSentToSF\" : { \"$exists\" : false }, \"metadata.sendToShutterfly\" : true}";



    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(identifyStorageErrorDocuments, "ingestRoot",  tempFolder.getRoot().getAbsolutePath());

        execution.setVariable(Workflow.SEARCH_CRITERIA, searchCriteria);
        execution.setVariable(Workflow.SEARCH_WINDOW, searchWindow);
        execution.setVariable(Workflow.MAX_DOCUMENTS_OCCURS, maxDocOccur);
        execution.setVariable(Workflow.APP_ID, appId);
        execution.setVariable(Workflow.SPACE_ID, spaceId);
        execution.setVariable(Workflow.CLIENT_ID, clientId);
        execution.setVariable(Workflow.FDS_CLOUD_GET_ATTACHMENT_URL, fdsUrl);
        execution.setVariable(Workflow.HOOK_ID, "1234");

    }

    @Test
    public void testDoExecute() throws Exception {
        when(documentMetaDataService.getDocumentMetaData(anyString(), any(), anyInt())).thenReturn(getDocList());

        when(fileStoreService.downloadFile(anyString(), anyString())).thenReturn(getByteArray());
        identifyStorageErrorDocuments.doExecute(execution);

        List<DocumentMetaData> resultList = execution.getVariable(Workflow.LIST_DOCUMENT_METADATA, List.class);
        assertNotNull(resultList);
        assertFalse(resultList.isEmpty());
        DocumentMetaData resultDoc = resultList.get(0);
        Document metadata = resultDoc.getMetadata();
        assertFalse(metadata.getBoolean(Workflow.IS_POST_CARD));
        assertFalse(metadata.getString(Workflow.DOCUMENT_ABSOLUTE_PATH).isEmpty());
    }

    @Test
    public void testDoExecuteEmptyList() throws Exception {
        when(documentMetaDataService.getDocumentMetaData(anyString(), any(), anyInt())).thenReturn(null);
        identifyStorageErrorDocuments.doExecute(execution);
        assertTrue(execution.getVariable("exitNow", Boolean.class));
    }

    @Test
    public void testGetCurrentDateFormatted() throws Exception {
        String format = "yyyyMMdd";

        // Use reflection to access the private method
        Method method = IdentifyStorageErrorDocuments.class.getDeclaredMethod("getCurrentDateFormatted", String.class);
        method.setAccessible(true);

        String result = (String) method.invoke(identifyStorageErrorDocuments, format);
        assertNotNull("The formatted date should not be null", result);
        assertEquals("The formatted date should match the expected length", 8, result.length());
    }

    @Test
    public void testValidateInputWithValidData() throws Exception {
        String validJson = "{\"key\":\"value\"}";
        execution.setVariable("executionBusData", validJson);

        // Use reflection to access the private method
        Method method = IdentifyStorageErrorDocuments.class.getDeclaredMethod("validateInput", String.class, DelegateExecution.class);
        method.setAccessible(true);

        HashMap<String, Object> result = (HashMap<String, Object>) method.invoke(identifyStorageErrorDocuments, validJson, execution);
        assertNotNull("The result should not be null for valid JSON", result);
        assertEquals("The result should contain the expected key-value pair", "value", result.get("key"));
    }

    private byte[] getByteArray() throws Exception {
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("temp/pdfInput.pdf").getFile());
        return Files.readAllBytes(file.toPath());
    }

    private List<DocumentMetaData> getDocList() throws Exception {
        List<DocumentMetaData> list = new ArrayList<>();
        list.add(getDocumentMetaData());
        list.add(getDocumentMetaData2());

        return list;
    }

    private DocumentMetaData getDocumentMetaData() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr = "{"
                + "\"id\" : \"593e9fadef8654760f6b464c\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 3007,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\","
                + "\"documentAttachments\" : ["
                + "{"
                + "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
                + "\"index\" : 1,"
                + "\"file_name\" : \"balloon.jpg\","
                + "\"status\" : \"AVAILABLE\""
                + "}"
                + "]"
                + "}";

        String metaData =     "{"
                + "\"providerId\" : \"sample_provider\","
                + "\"fileName\" : \"birds3\","
                + "\"fileDescription\" : \"very simple file\","
                + "\"createdDate\" : \"06/11/2017\","
                + "\"createApplication\" : \"sample application\","
                + "\"expiryDate\" : \"05/30/2050\","
                + "\"filePath\" : \"reports/FEB2017\","
                + "\"dateOfService\" : \"01/30/2017\","
                + "\"fileType\" : \"reports/FEB2017\","
                + "\"tenant\" : \"suhcbo\","
                + "\"claimNumber\" : \"12345678\","
                + "\"category\" : \"Benefits\","
                + "\"subCategory\" : \"Transactions\","
                + "\"organization\" : \"Optum Technologies\","
                + "\"privilege\" : \"Electronic Payments and Statements\","
                + "\"corporateMpin\" : \"002535119\","
                + "\"tin\" : \"201459415\","
                + "\"mpin\" : \"12345\","
                + "\"memberId\" : \"45678123\","
                + "\"physicianName\" : \"Paramesh,Korrakuti\","
                + "\"employeeName\" : \"Murthy, Sriram\","
                + "\"dateOfService\" : \"05/30/2017\","
                + "\"memberName\" : \"Balaji, Ramalingam\","
                + "\"emailAlertReq\" : \"Y\""
                + "}"
                + "}";
        Document metaDataObject = Document.parse(metaData);
        documentMetaData = Parser.parseJson(docStr, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
        documentMetaData.setFileName("123.pdf");
        documentMetaData.setS3FilePath("file/path");

        return documentMetaData;
    }

    private DocumentMetaData getDocumentMetaData2() throws IOException {
        DocumentMetaData documentMetaData = null;
        String docStr2 = "{"
                + "\"id\" : \"593e9fadef8654760f6b464c\","
                + "\"clientId\" : 1,"
                + "\"spaceId\" : 3007,"
                + "\"appIdentifier\" : \"testapp\","
                + "\"status\" : \"AVAILABLE\","
                + "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
                + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
                + "\"transactionId\" : \"593e9fadef8654760f6b464b\","
                + "\"documentAttachments\" : ["
                + "{"
                + "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
                + "\"index\" : 1,"
                + "\"file_name\" : \"balloon.jpg\","
                + "\"status\" : \"AVAILABLE\""
                + "}"
                + "]"
                + "}";

        String metaData2 =     "{"
                + "\"providerId\" : \"sample_provider\","
                + "\"fileName\" : \"birds3\","
                + "\"fileDescription\" : \"very simple file\","
                + "\"createdDate\" : \"06/11/2017\","
                + "\"createApplication\" : \"sample application\","
                + "\"expiryDate\" : \"05/30/2050\","
                + "\"filePath\" : \"reports/FEB2017\","
                + "\"dateOfService\" : \"01/30/2017\","
                + "\"fileType\" : \"reports/FEB2017\","
                + "\"tenant\" : \"suhcbo\","
                + "\"claimNumber\" : \"12345678\","
                + "\"category\" : \"Benefits\","
                + "\"subCategory\" : \"Transactions\","
                + "\"organization\" : \"Optum Technologies\","
                + "\"privilege\" : \"Electronic Payments and Statements\","
                + "\"corporateMpin\" : \"002535119\","
                + "\"tin\" : \"201459415\","
                + "\"mpin\" : \"12345\","
                + "\"memberId\" : \"45678123\","
                + "\"physicianName\" : \"Paramesh,Korrakuti\","
                + "\"employeeName\" : \"Murthy, Sriram\","
                + "\"dateOfService\" : \"05/30/2017\","
                + "\"memberName\" : \"Balaji, Ramalingam\","
                + "\"emailAlertReq\" : \"Y\""
                + "}"
                + "}";
        Document metaDataObject = Document.parse(metaData2);
        documentMetaData = Parser.parseJson(docStr2, DocumentMetaData.class);
        documentMetaData.setMetadata(metaDataObject);
        documentMetaData.setFileName("123.pdf");
        documentMetaData.setS3FilePath("file/path");
        return documentMetaData;


    }
}