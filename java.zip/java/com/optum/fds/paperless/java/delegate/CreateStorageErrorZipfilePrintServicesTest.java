package com.optum.fds.paperless.java.delegate;

import com.google.common.base.Strings;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.ZipUtil;
import org.apache.commons.lang.StringUtils;
import org.bson.Document;
import org.eclipse.collections.api.multimap.Multimap;
import org.eclipse.collections.api.tuple.Pair;
import org.eclipse.collections.impl.factory.Maps;
import org.eclipse.collections.impl.factory.Sets;
import org.eclipse.collections.impl.tuple.Tuples;
import org.eclipse.collections.impl.utility.LazyIterate;
import org.flowable.engine.delegate.DelegateExecution;

import static com.optum.fds.paperless.java.delegate.CreateShutterflyDocumentsTest.*;
import static com.optum.fds.paperless.workflow.constants.Workflow.*;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

public class CreateStorageErrorZipfilePrintServicesTest {

    private DelegateExecution execution = new DelegateExecutionImpl();

    @InjectMocks
    private CreateStorageErrorZipfilePrintServices createStorageErrorZipfilePrintServices;

    @Mock
    ZipUtil zipUtil;

    private static final String ORIGINAL_PRINT_TRAIL = "1905";

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        DocumentMetaData documentMetaData = getDocumentMetaData();
        documentMetaData.setId("1234");
        var listDocumentMetaData = List.of(
                getDocumentMetaDataOriginalCompanionRecord(),
                getDocumentMetaDataOriginalCompanionRecordSecond(),
                getDocumentMetaData(),
                getDocumentMetaDataPriorAuthLetters(),
                getDocumentMetaDataCorporateMpinMissing(),
                documentMetaData,
                getDocumentMetaDataWithEmptyCorporateMpin(),
                getDocumentMetaDataPriorAuthLetters2(),
                getDocumentMetaDataWithMissingMailAddressOne(),
                getDocumentMetaDataWithMissingMailAddressOneAndProviderName(),
                getDocumentMetaDataOriginalCompanionRecordReal()

        );

        var listDocumentMultiMap = getMultiMapDocumentMetadata(listDocumentMetaData);
        var correlationIds = LazyIterate.adapt(listDocumentMetaData)
                .collect(x -> x == null? Tuples.pair(StringUtils.EMPTY, StringUtils.EMPTY) :
                        Tuples.pair(x.getId(), String.valueOf(x.getSpaceId())))
                .toMap(Pair::getOne, x -> x.getOne() + "_" + x.getTwo());

        var manifestFileList = listDocumentMultiMap.keySet().toList();

        List<String> fileList = new ArrayList<String>();
        fileList.add("testone.pdf");
        fileList.add("testtwo.pdf");

        execution.setVariable(OUTPUT_FILE_DIR_SHUTTERFLY, "/test/");
        execution.setVariable(PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP, listDocumentMultiMap);
        execution.setVariable(PRINT_SERVICES_MANIFEST, manifestFileList);
        execution.setVariable(CORRELATION_IDS, correlationIds);
        execution.setVariable(SFTP_FILE_LIST, fileList);
        execution.setVariable(PROCESS_KEY, "processKey");

    }

    @Test
    public void testCreatePdfZipForFdsReprint() throws Exception {
        // Prepare test data
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setFileName("testFile.pdf");
        documentMetaData.setMetadata(new Document("DOCUMENT_ABSOLUTE_PATH", "/test/dir"));

        createStorageErrorZipfilePrintServices.execute(execution);
        // Use reflection to access the private method
//        Method method = CreateStorageErrorZipfilePrintServices.class
//                .getDeclaredMethod("createPdfZipForFdsReprint", DocumentMetaData.class, boolean.class, DelegateExecution.class);
//        method.setAccessible(true);
//
//        // Invoke the private method
//        Iterable<?> result = (Iterable<?>) method.invoke(createStorageErrorZipfilePrintServices, documentMetaData, true, execution);
//
//        // Convert Iterable to List for assertions
//        List<?> resultList = org.eclipse.collections.impl.factory.Lists.mutable.withAll(result);
//
//        // Assertions
//        assertNotNull(resultList);
//        assertEquals(1, resultList.size());
//        assertEquals("testFile.pdf", resultList.get(0).getClass().getMethod("getFileName").invoke(resultList.get(0)));
    }

    @Test
    public void testCreatePdfZipForFdsReprintWithNonFdsReprintFileName() throws Exception {
        // Prepare test data
        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setFileName("nonFdsReprintFile.pdf");
        documentMetaData.setMetadata(new Document("DOCUMENT_ABSOLUTE_PATH", "/test/dir"));

        createStorageErrorZipfilePrintServices.execute(execution);
//        // Use reflection to access the private method
//        Method method = CreateStorageErrorZipfilePrintServices.class
//                .getDeclaredMethod("createPdfZipForFdsReprint", DocumentMetaData.class, boolean.class, DelegateExecution.class);
//        method.setAccessible(true);
//
//        // Invoke the private method with isFileNameFDSRePrint set to false
//        Iterable<?> result = (Iterable<?>) method.invoke(createStorageErrorZipfilePrintServices, documentMetaData, false, execution);
//
//        // Convert Iterable to List for assertions
//        List<?> resultList = org.eclipse.collections.impl.factory.Lists.mutable.withAll(result);
//
//        // Assertions
//        assertNotNull(resultList);
//        assertTrue(resultList.isEmpty()); // Expecting no ZipUtilBean to be created
    }

    private DocumentMetaData getDocumentMetaData() {
        var dmd = new DocumentMetaData();
        dmd.setId("testAnyDocumentId");
        dmd.setSpaceId(Integer.parseInt("99900999"));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt("88877888"));
        dmd.setAppIdentifier("testapp");
        dmd.setTransactionId("zxy8888");
        Document metadataObj = Document.parse("{ " +
                "\"fileDescription\" : \"Claim information request     \", " +
                "\"employeeName\" : \"PAMELA FERNANDO              \", " +
                "\"subCategory\" : \"C8\", " +
                "\"policyNumber\" : \"744530 \", " +
                "\"memberName\" : \"PAMELA FERNANDO               \", " +
                "\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
                "\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
                "\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
                "\"tin\" : \"03047636000002                \", " +
                "\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
                "\"category\" : \"Claim\", " +
                "\"claimNumber\" : \"1043126449\", " +
                "\"memberId\" : \"887543999\", " +
                "\"providerEmailId\" : \"andre@optum.com\", " +
                "\"absolutePath\" : \"/test/\", " +
                "}");
        var listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        var documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("documentfile1.txt");
        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);


        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da9");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("documentfile2.txt");
        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);

        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);

        return dmd;
    }

    private DocumentMetaData getDocumentMetaDataFirst() {
        var dmd = new DocumentMetaData();
        dmd.setId("testAnyDocumentId");
        dmd.setSpaceId(Integer.parseInt("99900999"));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt("88877888"));
        dmd.setAppIdentifier("testapp");
        dmd.setTransactionId("zxy8888");
        Document metadataObj = Document.parse("{ " +
                "\"fileDescription\" : \"Claim information request     \", " +
                "\"employeeName\" : \"PAMELA FERNANDO              \", " +
                "\"subCategory\" : \"C8\", " +
                "\"policyNumber\" : \"744530 \", " +
                "\"memberName\" : \"PAMELA FERNANDO               \", " +
                "\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
                "\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
                "\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
                "\"tin\" : \"03047636000002                \", " +
                "\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
                "\"category\" : \"Claim\", " +
                "\"claimNumber\" : \"1043126449\", " +
                "\"memberId\" : \"887543999\", " +
                "\"providerEmailId\" : \"andre@optum.com\", " +
                "\"absolutePath\" : \"/test/\", " +
                "}");
        var listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        var documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("documentfile1.pdf");
        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);

        return dmd;
    }

    private DocumentMetaData getDocumentMetaDataSecond() {
        DocumentMetaData dmd = new DocumentMetaData();
        dmd.setId("testAnyDocumentId");
        dmd.setSpaceId(Integer.parseInt("99900999"));
        dmd.setStatus("AVAILABLE");
        dmd.setClientId(Integer.parseInt("88877888"));
        dmd.setAppIdentifier("testapp");
        dmd.setTransactionId("zxy8888");
        Document metadataObj = Document.parse("{ " +
                "\"fileDescription\" : \"Claim information request     \", " +
                "\"employeeName\" : \"PAMELA FERNANDO              \", " +
                "\"subCategory\" : \"C8\", " +
                "\"policyNumber\" : \"744530 \", " +
                "\"memberName\" : \"PAMELA FERNANDO               \", " +
                "\"expiryDate\" : \"2017-12-03T04:06:31Z\", " +
                "\"createdDate\" : \"2017-01-24T00:05:00.000Z\", " +
                "\"physicianName\" : \"MOHAMED A ZINEDDIN MD         \", " +
                "\"tin\" : \"03047636000002                \", " +
                "\"dateOfService\" : \"0017-01-21T00:04:00.000Z\", " +
                "\"category\" : \"Claim\", " +
                "\"claimNumber\" : \"1043126449\", " +
                "\"memberId\" : \"887543999\", " +
                "\"providerEmailId\" : \"andre@optum.com\", " +
                "\"absolutePath\" : \"/test/\", " +
                "}");
        List<DocumentAttachmentMetaData> listDocumentAttachmentMetaData = new ArrayList<DocumentAttachmentMetaData>();
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        documentAttachmentMetaData.setFsId("5638dc0d-ee56-4e3e-b587-d52100546da8");
        documentAttachmentMetaData.setIndex(1);
        documentAttachmentMetaData.setName("documentfile1.pdf");
        listDocumentAttachmentMetaData.add(documentAttachmentMetaData);
        dmd.setDocumentAttachments(listDocumentAttachmentMetaData);
        dmd.setMetadata(metadataObj);

        return dmd;
    }

    private ProcessorFileTask getFirstProcessorFileTask() {
        var processorFileTask = new ProcessorFileTask();
        var processorExecutionRecordList = new ArrayList<ProcessorExecutionRecord>();
        var processorExecutionRecord = new ProcessorExecutionRecord();
        processorExecutionRecord.setActivitiProcessKey("IntegratePrintServices");
        processorExecutionRecord.addMessage(Maps.mutable.of("outcome", "Files needed are present."));
        processorExecutionRecord.addMessage(Maps.mutable.of("fsId", "abc123", "providerEmailId", "max@optum.com"));

        processorExecutionRecordList.add(processorExecutionRecord);
        processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
        processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a789");
        return processorFileTask;
    }

    private ProcessorFileTask getSecondProcessorFileTask() {
        var processorFileTask = new ProcessorFileTask();
        var processorExecutionRecordList = new ArrayList<ProcessorExecutionRecord>();
        var processorExecutionRecord = new ProcessorExecutionRecord();
        processorExecutionRecord.setActivitiProcessKey("IntegratePrintServices2");
//		var message1 = new HashMap<String, Object>();
//		message1.put("outcome", "Files needed are present.");
//		processorExecutionRecord.addMessage(message1);
//		Map<String, Object> message2 = new HashMap<String, Object>();
//		message2.put("fsId", "abc1234");
//		message2.put("providerEmailId", "max@optum.com");
//		processorExecutionRecord.addMessage(message2);

        processorExecutionRecordList.add(processorExecutionRecord);
        processorFileTask.setProcessorExecutionRecordList(processorExecutionRecordList);
        processorFileTask.setProcessorTransactionId("1232ac3004bbb3044a787");
        return processorFileTask;
    }


    private Multimap<String, DocumentMetaData> getMultiMapDocumentMetadata(List<DocumentMetaData> listDocumentMetaData) {
        var fileSet = Sets.mutable.<String>empty();
        return LazyIterate.adapt(listDocumentMetaData)
                .select(x -> fileSet.add(x.getMetadata().getString(FILE_NAME)))
                .groupBy(this::getFileName);
    }

    private String getFileName(DocumentMetaData documentMetaData) {
        var x = documentMetaData.getMetadata();
        var postCardInd = (boolean) x.getOrDefault(POST_CARD_IND, false);
        var providerEmailId = x.getString(PROVIDER_EMAIL_ID);
        var originalPrintTrail = (String) x.getOrDefault(ORIGINAL_PRINT_TRAIL, ORIGINAL_PRINT_TRAIL);
        String fileName;
        if (postCardInd && (Strings.isNullOrEmpty(x.getString(TIN)) || Strings.isNullOrEmpty(x.getString(PROV_CORP_MPIN)))) {
            fileName = FDS_RPRNT_APPLICATION_NAME;
        } else if (postCardInd && Strings.isNullOrEmpty(providerEmailId)) {
            fileName = FDS_NO_RPRNT_APPLICATION_NAME + "_" + originalPrintTrail;
        } else {
            fileName = (postCardInd) ? FDS_NO_RPRNT_APPLICATION_NAME + "_" + originalPrintTrail : FDS_RPRNT_APPLICATION_NAME;
        }
        return fileName;
    }

}