package com.optum.fds.paperless.java.delegate;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.rules.TemporaryFolder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.mockito.stubbing.Stubber;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorTransactions;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fs.workflow.java.delegate.bean.DelegateExecutionImpl;

public class CreateAckTemplateTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(CreateAckTemplateTest.class);
    private static final String COSMOS_TEMPLATE_ID = "5ae0e4c2e8beb044bde8f5a5";
    private static String ingestDir = null;
    private final String PATH_JSON_FILE = "/TransformJsonFileWithTemplate/ProcessorTransactionListJsonExample1.json";
    private final String PATH_JSON_SYNTAX_ER_FILE = "/TransformJsonFileWithTemplate/ProcessorTransactionListJsonExample2.json";
    private final String PATH_JSON_NO_EXE_LIST = "/TransformJsonFileWithTemplate/ProcessorTransactionListJsonWithNoExecutionListExample.json";
    private final String PATH_PRNT_SERVICES_W_ERR_JSON_FILE = "/TransformJsonFileWithTemplate/ProcessorTransListJsonPrintSvcCompleteWithError.json";
    private final String PATH_PRNT_SERVICES_COMPLETE_JSON_FILE = "/TransformJsonFileWithTemplate/ProcessorTransactionListJsonPrintSvcComplete.json";
	private final String TEST = "test";
    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();
    @Rule
    public TemporaryFolder TEMP_FOLDER = new TemporaryFolder();

    @Mock
    ProcessorService processorService;
    @Mock
    DocumentMetaDataService documentMetaDataService;
    @Mock
    DelegateExecutionImpl execution;
    
    
    @Mock
    EmailService emailService;
    @Mock
    ErrorMetaDataService errorMetaDataService;
    Map<String,Object> delegateMap;
    @InjectMocks
    CreateAckTemplate createAckTemplate;

    @Before
    public void setUp() throws Exception{
        
        MockitoAnnotations.initMocks(this);
        
        DelegateExecution exe = Mockito.mock(DelegateExecution.class);

        delegateMap = new HashMap<String, Object>();
        delegateMap.put(Workflow.TEMPLATE_NAME, Templates.COSMOS_ACK.getTemplate());
        MockitoAnnotations.initMocks(this);
        Stubber getDelegateMap = doAnswer(new Answer<Object>() {
            public Object answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                return delegateMap.get(args[0]);
            }
        });
        getDelegateMap.when(execution).getVariable(anyString());

        Stubber setDelegateMap = doAnswer(new Answer<Void>() {
            public Void answer(InvocationOnMock invocation) {
                Object[] args = invocation.getArguments();
                delegateMap.put((String) args[0], args[1]);
                return null;
            }
        });
        setDelegateMap.when(execution).setVariable(anyString(), any());

        Stubber getVariablesMap = doAnswer(new Answer<Map<String, Object>>() {
            public Map<String, Object> answer(InvocationOnMock invocation) {
                return delegateMap;
            }
        });
        getVariablesMap.when(execution).getVariables();
        
        String fileTaskTransaction1 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b2363\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813835.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"FATAL_ERROR\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"Y\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 

        String fileTaskTransaction2 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b2364\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813835.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"FATAL_ERROR\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"N\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 

        String fileTaskTransaction3 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b2365\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813835.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"FATAL_ERROR\","
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 

        String fileTaskTransaction4 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b235d\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813833.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"targetId\" : \"5b11e1c4c2a3c69cd31b2350\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"SEVERE_ERROR\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"Y\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 

        String fileTaskTransaction5 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b2361\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813833.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"targetId\" : \"5b11e1c4c2a3c69cd31b2351\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"SEVERE_ERROR\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"N\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}";
        

        String fileTaskTransaction6 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b235e\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"targetId\" : \"5b11e1c4c2a3c69cd31b2352\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"COMPLETE\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"N\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 
        
        String fileTaskTransaction7 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b235f\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"targetId\" : \"5b11e1c4c2a3c69cd31b2361\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"COMPLETE\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"Y\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 

        String fileTaskTransaction8 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b2342\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"targetId\" : \"5b11e1c4c2a3c69cd31b2362\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"COMPLETE\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"Y\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 


        String fileTaskTransaction9 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b2366\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"targetId\" : \"5b11e1c4c2a3c69cd31b2363\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"COMPLETE\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"Y\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 
        
        String fileTaskTransaction10 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b2368\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"targetId\" : \"5b11e1c4c2a3c69cd31b2364\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"COMPLETE\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"Y\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 

        String fileTaskTransaction11 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b2369\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"targetId\" : \"5b11e1c4c2a3c69cd31b2365\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"COMPLETE\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"Y\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 

        String fileTaskTransaction12 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b2369\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"targetId\" : \"5b11e1c4c2a3c69cd31b2366\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"COMPLETE\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"Y\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 

        String fileTaskTransaction13 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b2369\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"targetId\" : \"5b11e1c4c2a3c69cd31b2367\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"COMPLETE\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"Y\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 

        String fileTaskTransaction14 = "{"
	    		+ "\"id\" : \"5b11e1c1c2a3c69cd31b2369\","
	    		+ "\"fileSize\" : 12098,"
	    		+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"processedByHost\" : \"test.uhc.com\","
				+ "\"serverType\" : \"ose\","
	    		+ "\"targetId\" : \"5b11e1c4c2a3c69cd31b2368\","
	    		+ "\"processorTransactionId\" : \"59f55dfce4b0ed1191daa570\","
	    		+ "\"dateProcessed\" : \"2017-04-26T18:51:58.221Z\","
	    		+ "\"processorRecordType\" : \"processorFileTask\","
	    		+ "\"status\" : \"COMPLETE\","
	    		+ "\"metadata\" : {"
	    		+ "\"emailAlertReq\" : \"Y\""
				+ "},"
	    		+ "\"summary\" : {"
	    		+ "\"runTime\" : 2791,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.431Z\","
				+ "\"endTime\" : \"2017-04-26T18:51:58.222Z\","
				+ "\"xmlObject\" : {"
				+ "\"applicationID\" : \"ELGS\","
				+ "\"datagroup\" : \"NASC\","
				+ "\"fileFormat\" : \"PDF\""
				+ "}"
				+ "}"
				+ "}"; 

        String documentIds[] = {"5b11e1c4c2a3c69cd31b2361", "5b11e1c4c2a3c69cd31b2362", "5b11e1c4c2a3c69cd31b2363", "5b11e1c4c2a3c69cd31b2364", "5b11e1c4c2a3c69cd31b2365", "5b11e1c4c2a3c69cd31b2366", "5b11e1c4c2a3c69cd31b2367", "5b11e1c4c2a3c69cd31b2368"};
        List<ProcessorFileTask> processorFileTasksList = new ArrayList<>();
	    ProcessorFileTask processorFileTask1 = Parser.parseJson(fileTaskTransaction1, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask2 = Parser.parseJson(fileTaskTransaction2, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask3 = Parser.parseJson(fileTaskTransaction3, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask4 = Parser.parseJson(fileTaskTransaction4, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask5 = Parser.parseJson(fileTaskTransaction5, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask6 = Parser.parseJson(fileTaskTransaction6, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask7 = Parser.parseJson(fileTaskTransaction7, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask8 = Parser.parseJson(fileTaskTransaction8, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask9 = Parser.parseJson(fileTaskTransaction9, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask10 = Parser.parseJson(fileTaskTransaction10, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask11 = Parser.parseJson(fileTaskTransaction11, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask12 = Parser.parseJson(fileTaskTransaction12, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask13 = Parser.parseJson(fileTaskTransaction13, ProcessorFileTask.class);
	    ProcessorFileTask processorFileTask14 = Parser.parseJson(fileTaskTransaction14, ProcessorFileTask.class);
	    processorFileTasksList.add(processorFileTask1);
	    processorFileTasksList.add(processorFileTask2);
	    processorFileTasksList.add(processorFileTask3);	    
	    processorFileTasksList.add(processorFileTask4);	    
	    processorFileTasksList.add(processorFileTask5);	    
	    processorFileTasksList.add(processorFileTask6);	    
	    processorFileTasksList.add(processorFileTask7);	    
	    processorFileTasksList.add(processorFileTask8);	    
	    processorFileTasksList.add(processorFileTask9);	    
	    processorFileTasksList.add(processorFileTask10);	    
	    processorFileTasksList.add(processorFileTask11);	    
	    processorFileTasksList.add(processorFileTask12);	    
	    processorFileTasksList.add(processorFileTask13);	    
	    processorFileTasksList.add(processorFileTask14);	    
	    
        ingestDir=UUID.randomUUID().toString();
        //when(templatesService.getTemplateById(Mockito.anyString())).thenReturn(template);

        when(execution.getVariable(Workflow.OUTPUT_FILE_DIR, String.class)).thenReturn(TEMP_FOLDER.getRoot() + File.separator + ingestDir);

        
        String jsonFile = "src/test/resources"+File.separator+PATH_JSON_FILE;
        
        when(execution.getVariable(Workflow.JSON_FILE, String.class)).thenReturn(jsonFile);
		when(execution.getVariable(Workflow.TEMPLATE_NAME, String.class)).thenReturn(Templates.COSMOS_ACK.getTemplate());
        when(execution.getCurrentActivityId()).thenReturn("1234567");
        when(processorService.getProcessorFileTasksForTransactionId(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(processorFileTasksList);
        List<DocumentMetaData> documentList = getDocumentMetaData();
        when(documentMetaDataService.getDocumentMetaData(documentIds[0])).thenReturn(documentList.get(0));
        when(documentMetaDataService.getDocumentMetaData(documentIds[1])).thenReturn(documentList.get(1));
        when(documentMetaDataService.getDocumentMetaData(documentIds[2])).thenReturn(documentList.get(2));
        when(documentMetaDataService.getDocumentMetaData(documentIds[3])).thenReturn(documentList.get(3));
        when(documentMetaDataService.getDocumentMetaData(documentIds[4])).thenReturn(documentList.get(4));
        when(documentMetaDataService.getDocumentMetaData(documentIds[5])).thenReturn(documentList.get(5));
        when(documentMetaDataService.getDocumentMetaData(documentIds[6])).thenReturn(documentList.get(6));
        when(documentMetaDataService.getDocumentMetaData(documentIds[7])).thenReturn(null);

        delegateMap.put(Workflow.OUTPUT_FILE_DIR,tempFolder.getRoot().getAbsolutePath() + "/" + ingestDir);
        delegateMap.put(Workflow.JSON_FILE, jsonFile);
        delegateMap.put(Workflow.TEMPLATE_ID,"5ae0e4c2e8beb044bde8f5a5" );
        delegateMap.put(Workflow.PROCESSOR_TRANSACTION_UPDATE, new ProcessorTransactions());
        delegateMap.put(Workflow.EMAIL_RECEIVER, TEST);
        delegateMap.put(Workflow.ENVIRONMENT, TEST);
        delegateMap.put(Workflow.OUTPUT_FILE_EXTENSION, "txt");
        delegateMap.put(Workflow.ZIP_OUTPUT_FILE, true);
        
        when(execution.getVariable(Workflow.EMAIL_RECEIVER, String.class)).thenReturn(TEST);
        when(execution.getVariable(Workflow.ENVIRONMENT, String.class)).thenReturn(TEST);
        when(execution.getVariable(Workflow.OUTPUT_FILE_EXTENSION, String.class)).thenReturn("txt");
        when(execution.getVariable(Workflow.ZIP_OUTPUT_FILE, Boolean.class)).thenReturn(true);
        when(emailService.sendEmail(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true); 
        when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
    }
    
    private List<DocumentMetaData> getDocumentMetaData() throws IOException {
		DocumentMetaData documentMetaData1 = null;
		String docStr = "{"
				+ "\"id\" : \"5b11e1c4c2a3c69cd31b2361\","
				+ "\"clientId\" : 1,"
				+ "\"spaceId\" : 3007,"
				+ "\"appIdentifier\" : \"testapp\","
				+ "\"status\" : \"AVAILABLE\","
				+ "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"transactionId\" : \"593e9fadef8654760f6b464b\","
				+ "\"documentAttachments\" : [" 
				+ "{"
				+ "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
				+ "\"index\" : 1,"
				+ "\"file_name\" : \"132987665_181813833.pdf\","
				+ "\"status\" : \"AVAILABLE\""
				+ "}"
				+ "]"
				+ "}";


		String metaData =     "{"
				+ "\"fileDescription\" : \"sample_provider\","
				+ "\"fileDescription\" : \"very simple file\","
				+ "\"sendToDocVault\" : true,"
				+ "\"sendToShutterfly\" : false,"
				+ "\"docSentTo\" : \"DocVault\","
				+ "\"fileName\" : \"132987665_181813833.pdf\","
				+ "\"createApplication\" : \"sample application\","
				+ "\"expiryDate\" : \"05/30/2050\","
				+ "\"filePath\" : \"reports/FEB2017\","
				+ "\"dateOfService\" : \"01/30/2017\","
				+ "\"fileType\" : \"reports/FEB2017\","
				+ "\"tenant\" : \"suhcbo\","
				+ "\"claimNumber\" : \"12345678\","
				+ "\"category\" : \"Benefits\","
				+ "\"subCategory\" : \"C1\","
				+ "\"organization\" : \"Optum Technologies\","
				+ "\"privilege\" : \"Claim Status\","
				+ "\"corporateMpin\" : \"002535119\","
				+ "\"tin\" : \"201459415\","
				+ "\"mpin\" : \"12345\","
				+ "\"memberId\" : \"45678123\","
				+ "\"physicianName\" : \"Paramesh,Korrakuti\","
				+ "\"employeeName\" : \"Murthy, Sriram\","
				+ "\"dateOfService\" : \"05/30/2017\","
				+ "\"memberName\" : \"COCHRAN CRYSTAL\","
				+ "\"emailAlertReq\" : \"Y\""
				+ "}"
				+ "}";

		Document metaDataObject1  = Document.parse(metaData);
		documentMetaData1 = Parser.parseJson(docStr, DocumentMetaData.class);
		documentMetaData1.setMetadata(metaDataObject1);
		
		List<DocumentMetaData>documentMetaDataList = new ArrayList<>();
		documentMetaDataList.add(documentMetaData1);
		
		DocumentMetaData documentMetaData2 = null;
	    docStr = "{"
				+ "\"id\" : \"5b11e1c4c2a3c69cd31b2362\","
				+ "\"clientId\" : 1,"
				+ "\"spaceId\" : 3007,"
				+ "\"appIdentifier\" : \"testapp\","
				+ "\"status\" : \"AVAILABLE\","
				+ "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"transactionId\" : \"593e9fadef8654760f6b464b\","
				+ "\"documentAttachments\" : [" 
				+ "{"
				+ "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
				+ "\"index\" : 1,"
				+ "\"file_name\" : \"132987665_181813834.pdf\","
				+ "\"status\" : \"AVAILABLE\""
				+ "}"
				+ "]"
				+ "}";


		 metaData =     "{"
				+ "\"fileDescription\" : \"sample_provider\","
				+ "\"fileDescription\" : \"very simple file\","
				+ "\"sendToDocVault\" : true,"
				+ "\"sendToShutterfly\" : false,"
				+ "\"docSentTo\" : \"PrintServices\","
				+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"createApplication\" : \"sample application\","
				+ "\"expiryDate\" : \"05/30/2050\","
				+ "\"filePath\" : \"reports/FEB2017\","
				+ "\"dateOfService\" : \"01/30/2017\","
				+ "\"fileType\" : \"reports/FEB2017\","
				+ "\"tenant\" : \"suhcbo\","
				+ "\"claimNumber\" : \"12345678\","
				+ "\"category\" : \"Benefits\","
				+ "\"subCategory\" : \"C1\","
				+ "\"organization\" : \"Optum Technologies\","
				+ "\"privilege\" : \"Claim Status\","
				+ "\"corporateMpin\" : \"002535119\","
				+ "\"tin\" : \"201459415\","
				+ "\"mpin\" : \"12345\","
				+ "\"memberId\" : \"45678123\","
				+ "\"physicianName\" : \"Paramesh,Korrakuti\","
				+ "\"employeeName\" : \"Murthy, Sriram\","
				+ "\"dateOfService\" : \"05/30/2017\","
				+ "\"memberName\" : \"COCHRAN CRYSTAL\","
				+ "\"emailAlertReq\" : \"Y\""
				+ "}"
				+ "}";

		Document metaDataObject2  = Document.parse(metaData);
		documentMetaData2 = Parser.parseJson(docStr, DocumentMetaData.class);
		documentMetaData2.setMetadata(metaDataObject2);
		documentMetaDataList.add(documentMetaData2);

		DocumentMetaData documentMetaData3 = null;
	    docStr = "{"
				+ "\"id\" : \"5b11e1c4c2a3c69cd31b2363\","
				+ "\"clientId\" : 1,"
				+ "\"spaceId\" : 3007,"
				+ "\"appIdentifier\" : \"testapp\","
				+ "\"status\" : \"AVAILABLE\","
				+ "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"transactionId\" : \"593e9fadef8654760f6b464b\","
				+ "\"documentAttachments\" : [" 
				+ "{"
				+ "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
				+ "\"index\" : 1,"
				+ "\"file_name\" : \"132987665_181813834.pdf\","
				+ "\"status\" : \"AVAILABLE\""
				+ "}"
				+ "]"
				+ "}";


		 metaData =     "{"
				+ "\"fileDescription\" : \"sample_provider\","
				+ "\"fileDescription\" : \"very simple file\","
				+ "\"sendToDocVault\" : true,"
				+ "\"sendToShutterfly\" : false,"
				+ "\"docSentTo\" : \"\","
				+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"createApplication\" : \"sample application\","
				+ "\"expiryDate\" : \"05/30/2050\","
				+ "\"filePath\" : \"reports/FEB2017\","
				+ "\"dateOfService\" : \"01/30/2017\","
				+ "\"fileType\" : \"reports/FEB2017\","
				+ "\"tenant\" : \"suhcbo\","
				+ "\"claimNumber\" : \"12345678\","
				+ "\"category\" : \"Benefits\","
				+ "\"subCategory\" : \"C1\","
				+ "\"organization\" : \"Optum Technologies\","
				+ "\"privilege\" : \"Claim Status\","
				+ "\"corporateMpin\" : \"002535119\","
				+ "\"tin\" : \"201459415\","
				+ "\"mpin\" : \"12345\","
				+ "\"memberId\" : \"45678123\","
				+ "\"physicianName\" : \"Paramesh,Korrakuti\","
				+ "\"employeeName\" : \"Murthy, Sriram\","
				+ "\"dateOfService\" : \"05/30/2017\","
				+ "\"memberName\" : \"COCHRAN CRYSTAL\","
				+ "\"emailAlertReq\" : \"Y\""
				+ "}"
				+ "}";

		Document metaDataObject3  = Document.parse(metaData);
		documentMetaData3 = Parser.parseJson(docStr, DocumentMetaData.class);
		documentMetaData3.setMetadata(metaDataObject3);
		documentMetaDataList.add(documentMetaData3);

		DocumentMetaData documentMetaData4 = null;
	    docStr = "{"
				+ "\"id\" : \"5b11e1c4c2a3c69cd31b2364\","
				+ "\"clientId\" : 1,"
				+ "\"spaceId\" : 3007,"
				+ "\"appIdentifier\" : \"testapp\","
				+ "\"status\" : \"AVAILABLE\","
				+ "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"transactionId\" : \"593e9fadef8654760f6b464b\","
				+ "\"documentAttachments\" : [" 
				+ "{"
				+ "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
				+ "\"index\" : 1,"
				+ "\"file_name\" : \"132987665_181813834.pdf\","
				+ "\"status\" : \"AVAILABLE\""
				+ "}"
				+ "]"
				+ "}";


		 metaData =     "{"
				+ "\"fileDescription\" : \"sample_provider\","
				+ "\"fileDescription\" : \"very simple file\","
				+ "\"sendToDocVault\" : false,"
				+ "\"sendToShutterfly\" : true,"
				+ "\"docSentTo\" : \"PrintServices\","
				+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"createApplication\" : \"sample application\","
				+ "\"expiryDate\" : \"05/30/2050\","
				+ "\"filePath\" : \"reports/FEB2017\","
				+ "\"dateOfService\" : \"01/30/2017\","
				+ "\"fileType\" : \"reports/FEB2017\","
				+ "\"tenant\" : \"suhcbo\","
				+ "\"claimNumber\" : \"12345678\","
				+ "\"category\" : \"Benefits\","
				+ "\"subCategory\" : \"C1\","
				+ "\"organization\" : \"Optum Technologies\","
				+ "\"privilege\" : \"Claim Status\","
				+ "\"corporateMpin\" : \"002535119\","
				+ "\"tin\" : \"201459415\","
				+ "\"mpin\" : \"12345\","
				+ "\"memberId\" : \"45678123\","
				+ "\"physicianName\" : \"Paramesh,Korrakuti\","
				+ "\"employeeName\" : \"Murthy, Sriram\","
				+ "\"dateOfService\" : \"05/30/2017\","
				+ "\"memberName\" : \"COCHRAN CRYSTAL\","
				+ "\"emailAlertReq\" : \"Y\""
				+ "}"
				+ "}";

		Document metaDataObject4  = Document.parse(metaData);
		documentMetaData4 = Parser.parseJson(docStr, DocumentMetaData.class);
		documentMetaData4.setMetadata(metaDataObject4);
		documentMetaDataList.add(documentMetaData4);
		
		DocumentMetaData documentMetaData5 = null;
	    docStr = "{"
				+ "\"id\" : \"5b11e1c4c2a3c69cd31b2365\","
				+ "\"clientId\" : 1,"
				+ "\"spaceId\" : 3007,"
				+ "\"appIdentifier\" : \"testapp\","
				+ "\"status\" : \"AVAILABLE\","
				+ "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"transactionId\" : \"593e9fadef8654760f6b464b\","
				+ "\"documentAttachments\" : [" 
				+ "{"
				+ "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
				+ "\"index\" : 1,"
				+ "\"file_name\" : \"132987665_181813834.pdf\","
				+ "\"status\" : \"AVAILABLE\""
				+ "}"
				+ "]"
				+ "}";


		 metaData =     "{"
				+ "\"fileDescription\" : \"sample_provider\","
				+ "\"fileDescription\" : \"very simple file\","
				+ "\"docSentTo\" : \"DocVault\","
				+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"createApplication\" : \"sample application\","
				+ "\"expiryDate\" : \"05/30/2050\","
				+ "\"filePath\" : \"reports/FEB2017\","
				+ "\"dateOfService\" : \"01/30/2017\","
				+ "\"fileType\" : \"reports/FEB2017\","
				+ "\"tenant\" : \"suhcbo\","
				+ "\"claimNumber\" : \"12345678\","
				+ "\"category\" : \"Benefits\","
				+ "\"subCategory\" : \"C1\","
				+ "\"organization\" : \"Optum Technologies\","
				+ "\"privilege\" : \"Claim Status\","
				+ "\"corporateMpin\" : \"002535119\","
				+ "\"tin\" : \"201459415\","
				+ "\"mpin\" : \"12345\","
				+ "\"memberId\" : \"45678123\","
				+ "\"physicianName\" : \"Paramesh,Korrakuti\","
				+ "\"employeeName\" : \"Murthy, Sriram\","
				+ "\"dateOfService\" : \"05/30/2017\","
				+ "\"memberName\" : \"COCHRAN CRYSTAL\","
				+ "\"emailAlertReq\" : \"Y\""
				+ "}"
				+ "}";

		Document metaDataObject5  = Document.parse(metaData);
		documentMetaData5 = Parser.parseJson(docStr, DocumentMetaData.class);
		documentMetaData5.setMetadata(metaDataObject5);
		documentMetaDataList.add(documentMetaData5);

		DocumentMetaData documentMetaData6 = null;
	    docStr = "{"
				+ "\"id\" : \"5b11e1c4c2a3c69cd31b2366\","
				+ "\"clientId\" : 1,"
				+ "\"spaceId\" : 3007,"
				+ "\"appIdentifier\" : \"testapp\","
				+ "\"status\" : \"AVAILABLE\","
				+ "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"transactionId\" : \"593e9fadef8654760f6b464b\","
				+ "\"documentAttachments\" : [" 
				+ "{"
				+ "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
				+ "\"index\" : 1,"
				+ "\"file_name\" : \"132987665_181813834.pdf\","
				+ "\"status\" : \"AVAILABLE\""
				+ "}"
				+ "]"
				+ "}";


		 metaData =     "{"
				+ "\"fileDescription\" : \"sample_provider\","
				+ "\"fileDescription\" : \"very simple file\","
				+ "\"docSentTo\" : \"PrintServices\","
				+ "\"fileName\" : \"132987665_181813834.pdf\","
				+ "\"createApplication\" : \"sample application\","
				+ "\"expiryDate\" : \"05/30/2050\","
				+ "\"filePath\" : \"reports/FEB2017\","
				+ "\"dateOfService\" : \"01/30/2017\","
				+ "\"fileType\" : \"reports/FEB2017\","
				+ "\"tenant\" : \"suhcbo\","
				+ "\"claimNumber\" : \"12345678\","
				+ "\"category\" : \"Benefits\","
				+ "\"subCategory\" : \"C1\","
				+ "\"organization\" : \"Optum Technologies\","
				+ "\"privilege\" : \"Claim Status\","
				+ "\"corporateMpin\" : \"002535119\","
				+ "\"tin\" : \"201459415\","
				+ "\"mpin\" : \"12345\","
				+ "\"memberId\" : \"45678123\","
				+ "\"physicianName\" : \"Paramesh,Korrakuti\","
				+ "\"employeeName\" : \"Murthy, Sriram\","
				+ "\"dateOfService\" : \"05/30/2017\","
				+ "\"memberName\" : \"COCHRAN CRYSTAL\","
				+ "\"emailAlertReq\" : \"Y\""
				+ "}"
				+ "}";

		Document metaDataObject6  = Document.parse(metaData);
		documentMetaData6 = Parser.parseJson(docStr, DocumentMetaData.class);
		documentMetaData6.setMetadata(metaDataObject6);
		documentMetaDataList.add(documentMetaData6);
		
		DocumentMetaData documentMetaData7 = null;
	    docStr = "{"
				+ "\"id\" : \"5b11e1c4c2a3c69cd31b2367\","
				+ "\"clientId\" : 1,"
				+ "\"spaceId\" : 3007,"
				+ "\"appIdentifier\" : \"testapp\","
				+ "\"status\" : \"AVAILABLE\","
				+ "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"transactionId\" : \"593e9fadef8654760f6b464b\","
				+ "\"documentAttachments\" : [" 
				+ "{"
				+ "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\","
				+ "\"index\" : 1,"
				+ "\"file_name\" : \"132987665_181813834.pdf\","
				+ "\"status\" : \"AVAILABLE\""
				+ "}"
				+ "]"
				+ "}";
		
	    documentMetaData7 = Parser.parseJson(docStr, DocumentMetaData.class);
		documentMetaData7.setMetadata(null);
		documentMetaDataList.add(documentMetaData7);

		
		return documentMetaDataList;
	}

    /**
     *
     * @throws Exception
     */
	@Test
	@UserStory(references = "US24300")
	@RallyTestCase(references = "TC28848")
    public void testGetTemplate_ProcessorTrans() throws Exception{
		createAckTemplate.execute(execution);
		assertTrue((Integer)createAckTemplate.errorMap.get(Workflow.NEW_ERRORS)!=0);   
		checkProcessorTransactionUpdateJsonContent();
	}

	@Test
    @UserStory(references = "US24300")
    @RallyTestCase(references = "TC28849")
    public void testCheckProcessorTransactionUpdate() throws Exception{
        createAckTemplate.execute(execution);
        checkProcessorTransactionUpdateJsonContent();
    }
   
	@SuppressWarnings("rawtypes")
	private void checkProcessorTransactionUpdateJsonContent() throws IOException {
		List updateProcessorTransactionData  = Arrays.asList(delegateMap.get(Workflow.PROCESSOR_TRANSACTION_UPDATE));
		assertTrue(updateProcessorTransactionData.size()==1);
	}

   @Test
   @UserStory(references = "US24300")
   @RallyTestCase(references="TC28838")
   public void testDoExecuteWithNullFilePath() throws Exception {
        when(execution.getVariable(Workflow.OUTPUT_FILE_DIR, String.class)).thenReturn(null);
        createAckTemplate.execute(execution);
        assertTrue(createAckTemplate.errorMap.size()>1); 
   }

    @Test
    @RallyTestCase(references="TC28850")
    public void testDoExecuteErrorMap() throws Exception {
        when(execution.getVariable(Workflow.TEMPLATE_NAME)).thenReturn(null);
        createAckTemplate.execute(execution);
        assertTrue(createAckTemplate.errorMap.size()>1); 
    }

    @Test
    @UserStory(references = "US24300")
    @RallyTestCase(references="TC28880")
    public void testDoExecuteWithNoprocessorExecutionRecordList() throws Exception {
    	String jsonFile= "src/test/resources"+File.separator+PATH_JSON_NO_EXE_LIST;
        when(execution.getVariable(Workflow.JSON_FILE, String.class)).thenReturn(jsonFile);
        createAckTemplate.execute(execution);
        assertTrue(createAckTemplate.errorMap.size()>1);
    }
    
    @Test
    @UserStory(references = "US24300")
    @RallyTestCase(references="TC28840")
    public void testDoExecuteWithNoJsonFile() throws Exception {
        String jsonFile= "src/test/resources"+File.separator+PATH_PRNT_SERVICES_COMPLETE_JSON_FILE+"1";
        when(execution.getVariable(Workflow.JSON_FILE, String.class)).thenReturn(jsonFile);
        createAckTemplate.execute(execution);
        assertTrue(createAckTemplate.errorMap.size()>1); 
    }

    @Test
    @UserStory(references = "US24275")
    @RallyTestCase(references="TC28860")
     public void testDoExecuteWithPrintServicesValidationsCompleteWithError() throws Exception {
    	String jsonFilePath = "src/test/resources"+File.separator+PATH_PRNT_SERVICES_W_ERR_JSON_FILE;
        when(execution.getVariable(Workflow.JSON_FILE, String.class)).thenReturn(jsonFilePath);
        createAckTemplate.execute(execution);
        Assert.assertTrue(createAckTemplate.errorMap.size()>1);
    }
    
    @Test
    @UserStory(references = "US24275")
    @RallyTestCase(references="TC28859")
     public void testDoExecuteWithPrintServicesValidationsComplete() throws Exception {
        String jsonFilePath = "src/test/resources"+File.separator+PATH_PRNT_SERVICES_COMPLETE_JSON_FILE;
        when(execution.getVariable(Workflow.JSON_FILE, String.class)).thenReturn(jsonFilePath);
        createAckTemplate.execute(execution);
        Assert.assertTrue(createAckTemplate.errorMap.size()>=0);
    }
    
	@SuppressWarnings("unchecked")
	@Test
	@UserStory(references = "US25214")
	@RallyTestCase(references = "TC29681")
    public void testGetTemplateWithZipOutputFileFalse() throws Exception{
		when(execution.getVariable(Workflow.OUTPUT_FILE_EXTENSION, String.class)).thenReturn("stat");
		when(execution.getVariable(Workflow.ZIP_OUTPUT_FILE, Boolean.class)).thenReturn(false);
		createAckTemplate.execute(execution);
		assertTrue((Integer)createAckTemplate.errorMap.get(Workflow.NEW_ERRORS)!=0);
		ArrayList<String> sftpFileList = new ArrayList<String>();
		sftpFileList.add("25655.stat");
		sftpFileList.add("98688");
		sftpFileList.add("986595");
		delegateMap.put(Workflow.SFTP_FILE_LIST, sftpFileList);
		List<String> fileList  = (ArrayList<String>) delegateMap.get(Workflow.SFTP_FILE_LIST);
		assertEquals(3, fileList.size());
		assertTrue(fileList.get(0).toString().endsWith(".stat"));
	}
	
    @Test
	@UserStory(references = "DE6583")
    @RallyTestCase(references = "TC29761")
    public void testDoExecuteWithNoFileTasks() throws Exception {
    	when(processorService.getProcessorFileTasksForTransactionId(Mockito.anyString(), Mockito.anyString())).thenReturn(new ArrayList<ProcessorFileTask>());
        createAckTemplate.execute(execution);
        assertTrue(createAckTemplate.errorMap.size() >= 1);
    }
    
    @Test
    public void testDoExecuteJsonSyntaxException() throws Exception {
    	String jsonFilePath = "src/test/resources"+File.separator+ PATH_JSON_SYNTAX_ER_FILE;
        when(execution.getVariable(Workflow.JSON_FILE, String.class)).thenReturn(jsonFilePath);
        createAckTemplate.execute(execution);
        assertTrue(createAckTemplate.errorMap.size()>1);
    }

    @After
    public void testFinish(){
        System.out.println(TEMP_FOLDER.getRoot());
        System.out.println("test is finished");
    }
    
    @Test
    public void testGetDelegateExecutionId() throws Exception{
        String value = createAckTemplate.getDelegateExecutionId(null);
        assertEquals("NULL", value);
    }
    
    @Test(expected = NullPointerException.class)
    public void testDoExecuteThrowsException() {
    	ExpectedException thrown = ExpectedException.none();
        thrown.expect(Exception.class);
        //you can test the exception message like
        thrown.isAnyExceptionExpected();
        createAckTemplate.doExecute(execution);
    }
    
    @Test
    public void testupdateDateFieldThrowsException() throws IOException {
    	
    	ExpectedException thrown = ExpectedException.none();
        thrown.expect(Exception.class);
        //you can test the exception message like
        thrown.isAnyExceptionExpected();
        byte[] bt = new byte[5];
     
        File file1 = tempFolder.newFile( "testfile1.txt" );;
        ReflectionTestUtils.invokeMethod(createAckTemplate,"generateZip", file1, PATH_JSON_FILE, "test.zip", bt, execution);
    }

}
