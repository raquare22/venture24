package com.optum.fds.paperless.java.delegate;

import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;


import org.flowable.engine.delegate.DelegateExecution;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class CsvSftpProcessTest {

    @Mock
    private ScheduledCsvSftpMonitor scheduledCsvSftpMonitor;

    @Mock
    private ErrorMetaDataService errorMetaDataService;

    @Mock
    private DelegateExecution execution;

    @InjectMocks
    private CsvSftpProcess csvSftpProcess;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testDoExecute_Success() throws Exception {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        Map<String, String> processMap = new HashMap<>();
        processMap.put("processKey", "testProcess");
        processorMetaData.setProcess(processMap);
        when(execution.getVariable("processorMetaData")).thenReturn(processorMetaData);

        csvSftpProcess.doExecute(execution);

        verify(scheduledCsvSftpMonitor).runCsvSFTPMonitor(execution, processorMetaData);
        verify(execution).setTransientVariable("Monitor_Message", "SUCCESS");
        verify(execution).setTransientVariable(Workflow.PROCESSOR_METADATA, processorMetaData);
    }

    @Test
    public void testDoExecute_Exception() throws Exception {
//        ProcessorMetaData processorMetaData = new ProcessorMetaData();
//        Map<String, String> processMap = new HashMap<>();
//        processMap.put("processKey", "testProcess");
//        processorMetaData.setProcess(processMap);
//        when(execution.getVariable("processorMetaData")).thenReturn(processorMetaData);
//        doThrow(new RuntimeException("Error")).when(scheduledCsvSftpMonitor).runCsvSFTPMonitor(execution, processorMetaData);
//
//        csvSftpProcess.doExecute(execution);
//
//        verify(errorMetaDataService).writeToErrorCollection(eq(execution), contains("CsvSftpProcess --> doExecute: Error"));
//        verify(execution).setTransientVariable("Monitor_Message", "SUCCESS");
//        verify(execution).setTransientVariable(Workflow.PROCESSOR_METADATA, processorMetaData);
    }
}