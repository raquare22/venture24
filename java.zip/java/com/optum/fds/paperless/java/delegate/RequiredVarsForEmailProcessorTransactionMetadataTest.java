package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;

public class RequiredVarsForEmailProcessorTransactionMetadataTest {

	private final String TEST = "test";

	DelegateExecution execution;

	@InjectMocks
	RequiredVarsForEmailProcessorTransactionMetadata RequiredVarsForEmailProcessorTransactionMetadata;

	Document execVars = new Document();

	@Before
	public void setUp() throws Exception {
		execution = Mockito.mock(DelegateExecution.class);

	}

	@Test
	public void testSuccess() throws Exception {
		execVars.append(Workflow.SEARCH_CRITERIA, TEST).append(Workflow.SEARCH_WINDOW, TEST)
				.append(Workflow.TEMPLATE_ID, TEST).append(Workflow.EMAIL_SENDER, TEST)
				.append(Workflow.EMAIL_RECEIVER, TEST).append(Workflow.EMAIL_SUBJECT, TEST)
				.append(Workflow.ENVIRONMENT, TEST).append(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, TEST)
				.append(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, TEST);

		when(execution.getVariables()).thenReturn(execVars);
		when(execution.getVariable(Workflow.SEARCH_CRITERIA, String.class))
				.thenReturn(execVars.get(Workflow.SEARCH_CRITERIA, String.class));
		when(execution.getVariable(Workflow.SEARCH_WINDOW, String.class))
				.thenReturn(execVars.get(Workflow.SEARCH_WINDOW, String.class));
		when(execution.getVariable(Workflow.TEMPLATE_ID, String.class))
				.thenReturn(execVars.get(Workflow.TEMPLATE_ID, String.class));
		when(execution.getVariable(Workflow.EMAIL_SENDER, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_SENDER, String.class));
		when(execution.getVariable(Workflow.EMAIL_RECEIVER, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_RECEIVER, String.class));
		when(execution.getVariable(Workflow.EMAIL_SUBJECT, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_SUBJECT, String.class));
		when(execution.getVariable(Workflow.ENVIRONMENT, String.class))
				.thenReturn(execVars.get(Workflow.ENVIRONMENT, String.class));
		when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, String.class))
				.thenReturn(execVars.get(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, String.class));
		when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, String.class))
				.thenReturn(execVars.get(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, String.class));
		RequiredVarsForEmailProcessorTransactionMetadata verifyRequiredVars = new RequiredVarsForEmailProcessorTransactionMetadata();

		assertFalse(verifyRequiredVars.isExitNow(execution));

		verifyRequiredVars.execute(execution);
		assertNotNull(verifyRequiredVars.errorMap);

		verifyRequiredVars.addErrorMsg("Test Description2", "TestErrorMsg2");
		assertEquals(1, verifyRequiredVars.errorMap.get(Workflow.NEW_ERRORS));

	}

	/**
	 * Missing Search Criteria and Search Window
	 * 
	 * @throws Exception
	 */
	@UserStory(references = "25130")
	@RallyTestCase(references = "TC30644")
	@Test
	public void testErrors() throws Exception {
		execution.setVariable(Workflow.SEARCH_CRITERIA, "");
		execution.setVariable(Workflow.SEARCH_WINDOW, "");

		execVars.append(Workflow.TEMPLATE_ID, TEST).append(Workflow.EMAIL_SENDER, TEST)
				.append(Workflow.EMAIL_RECEIVER, TEST).append(Workflow.EMAIL_SUBJECT, TEST)
				.append(Workflow.ENVIRONMENT, TEST).append(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, TEST)
				.append(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, TEST);

		when(execution.getVariables()).thenReturn(execVars);
		when(execution.getVariable(Workflow.TEMPLATE_ID, String.class))
				.thenReturn(execVars.get(Workflow.TEMPLATE_ID, String.class));
		when(execution.getVariable(Workflow.EMAIL_SENDER, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_SENDER, String.class));
		when(execution.getVariable(Workflow.EMAIL_RECEIVER, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_RECEIVER, String.class));
		when(execution.getVariable(Workflow.EMAIL_SUBJECT, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_SUBJECT, String.class));
		when(execution.getVariable(Workflow.ENVIRONMENT, String.class))
				.thenReturn(execVars.get(Workflow.ENVIRONMENT, String.class));
		when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, String.class))
				.thenReturn(execVars.get(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, String.class));
		when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, String.class))
				.thenReturn(execVars.get(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, String.class));

		RequiredVarsForEmailProcessorTransactionMetadata verifyRequiredVars = new RequiredVarsForEmailProcessorTransactionMetadata();
		verifyRequiredVars.execute(execution);
		assertNotNull(verifyRequiredVars.errorMap);
		assertEquals(2, verifyRequiredVars.errorMap.get(Workflow.NEW_ERRORS));
	}

	/**
	 * Missing Email Receiver
	 * 
	 * @throws Exception
	 */
	@UserStory(references = "25130")
	@RallyTestCase(references = "TC30645")
	@Test
	public void testErrorsMatchCriteria() throws Exception {

		execVars.append(Workflow.SEARCH_CRITERIA, TEST).append(Workflow.SEARCH_WINDOW, TEST)
				.append(Workflow.TEMPLATE_ID, TEST).append(Workflow.EMAIL_SENDER, TEST)
				.append(Workflow.EMAIL_SUBJECT, TEST).append(Workflow.ENVIRONMENT, TEST)
				.append(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, TEST)
				.append(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, TEST);

		when(execution.getVariables()).thenReturn(execVars);
		when(execution.getVariable(Workflow.SEARCH_CRITERIA, String.class))
				.thenReturn(execVars.get(Workflow.SEARCH_CRITERIA, String.class));
		when(execution.getVariable(Workflow.SEARCH_WINDOW, String.class))
				.thenReturn(execVars.get(Workflow.SEARCH_WINDOW, String.class));
		when(execution.getVariable(Workflow.TEMPLATE_ID, String.class))
				.thenReturn(execVars.get(Workflow.TEMPLATE_ID, String.class));
		when(execution.getVariable(Workflow.EMAIL_SENDER, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_SENDER, String.class));
		when(execution.getVariable(Workflow.EMAIL_SUBJECT, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_SUBJECT, String.class));
		when(execution.getVariable(Workflow.ENVIRONMENT, String.class))
				.thenReturn(execVars.get(Workflow.ENVIRONMENT, String.class));
		when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, String.class))
				.thenReturn(execVars.get(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, String.class));
		when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, String.class))
				.thenReturn(execVars.get(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, String.class));

		RequiredVarsForEmailProcessorTransactionMetadata verifyRequiredVars = new RequiredVarsForEmailProcessorTransactionMetadata();

		verifyRequiredVars.execute(execution);
		assertNotNull(verifyRequiredVars.errorMap);
		assertEquals(1, verifyRequiredVars.errorMap.get(Workflow.NEW_ERRORS));

	}

	/**
	 * Missing Template Id
	 * 
	 * @throws Exception
	 */
	@UserStory(references = "25130")
	@RallyTestCase(references = "TC30646")
	@Test
	public void testErrorsMergedMetadataTemplateId() throws Exception {

		execVars.append(Workflow.SEARCH_CRITERIA, TEST).append(Workflow.SEARCH_WINDOW, TEST)
				.append(Workflow.EMAIL_SENDER, TEST).append(Workflow.EMAIL_RECEIVER, TEST)
				.append(Workflow.EMAIL_SUBJECT, TEST).append(Workflow.ENVIRONMENT, TEST)
				.append(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, TEST)
				.append(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, TEST);

		when(execution.getVariables()).thenReturn(execVars);
		when(execution.getVariable(Workflow.SEARCH_CRITERIA, String.class))
				.thenReturn(execVars.get(Workflow.SEARCH_CRITERIA, String.class));
		when(execution.getVariable(Workflow.SEARCH_WINDOW, String.class))
				.thenReturn(execVars.get(Workflow.SEARCH_WINDOW, String.class));
		when(execution.getVariable(Workflow.EMAIL_SENDER, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_SENDER, String.class));
		when(execution.getVariable(Workflow.EMAIL_RECEIVER, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_RECEIVER, String.class));
		when(execution.getVariable(Workflow.EMAIL_SUBJECT, String.class))
				.thenReturn(execVars.get(Workflow.EMAIL_SUBJECT, String.class));
		when(execution.getVariable(Workflow.ENVIRONMENT, String.class))
				.thenReturn(execVars.get(Workflow.ENVIRONMENT, String.class));
		when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, String.class))
				.thenReturn(execVars.get(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, String.class));
		when(execution.getVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, String.class))
				.thenReturn(execVars.get(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, String.class));
		RequiredVarsForEmailProcessorTransactionMetadata verifyRequiredVars = new RequiredVarsForEmailProcessorTransactionMetadata();
		verifyRequiredVars.execute(execution);
		assertNotNull(verifyRequiredVars.errorMap);
		assertEquals(1, verifyRequiredVars.errorMap.get(Workflow.NEW_ERRORS));
	}

}
