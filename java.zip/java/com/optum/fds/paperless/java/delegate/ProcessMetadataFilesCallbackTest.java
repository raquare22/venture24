package com.optum.fds.paperless.java.delegate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.*;

import com.optum.fds.paperless.domain.service.*;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorErrorCode;
import com.optum.fds.paperless.mongo.processors.ProcessorSummary;
import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;

import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.util.ProcessorTaskUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class ProcessMetadataFilesCallbackTest {
	
	
	DocumentMetaData documentMetaData = null;
	
	@Mock
	ProcessorsService processorsService;
	
	@Mock
	ProcessorFileTaskService processorFileTaskService;
	
	@Mock
	DocumentMetaDataService documentMetaDataService;
	
	@Mock
	ErrorMetaDataService errorMetaDataService;

	@Mock
	GenericResponse genericResponse;

    @Mock
    FilestoreService filestoreService;

	@InjectMocks
	ProcessMetadataFilesCallback processMetadataFilesCallback;
	
	DelegateExecution execution;
	
    @Before
    public void setUp() throws Exception {
    	MockitoAnnotations.initMocks(this);
        execution = new DelegateExecutionImpl();
        documentMetaData = getDocumentMetaData();
        execution.setVariable(Workflow.DOCUMENT, documentMetaData);
        execution.setVariable(Workflow.DOCID, "1234567");
        execution.setVariable(Workflow.PROCESSOR_FILE_TASK_ID, "12345");
        execution.setVariable(Workflow.APP_IDENTIFIER, "123456");
        execution.setVariable("prunDocumentId", "1245"); 
        
        when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
        
    }
    
    @Test
    public void testDoExecuteWithProcessorFileTaskNull() {
    	processMetadataFilesCallback.doExecute(execution);
        assertNull(processMetadataFilesCallback.errorMap);
        
    }
    
    @Test
    public void testDoExecuteWithProcessorFileTaskNotNullButPrunDocumentNull() {
    	when(processorFileTaskService.getProcessorFileTaskById(Mockito.anyString(), Mockito.anyString())).thenReturn(new ProcessorFileTask());
    	processMetadataFilesCallback.doExecute(execution);
        assertNull(processMetadataFilesCallback.errorMap);
   
    }
    
    @Test
    public void testDoExecutewithPrunDocumentNotNull() {
    	when(documentMetaDataService.getDocumentMetaData(Mockito.anyString())).thenReturn(new DocumentMetaData());
    	processMetadataFilesCallback.doExecute(execution);
        assertNull(processMetadataFilesCallback.errorMap);
 
    }
    
    @Test(expected = NullPointerException.class)
    public void testResponseCode200() {
    	when(processorFileTaskService.getProcessorFileTaskById(Mockito.anyString(), Mockito.anyString())).thenReturn(new ProcessorFileTask());
    	when(documentMetaDataService.getDocumentMetaData(Mockito.anyString())).thenReturn(new DocumentMetaData());
    	Map<String, Object> testresponse = new HashMap<>();
    	testresponse.put("documentId", "123");
    	genericResponse = new GenericResponse("200", "success", testresponse);
    	execution.setVariable("response", genericResponse);
    	processMetadataFilesCallback.doExecute(execution);

    }
    
    @Test(expected = NullPointerException.class)
    public void testResponseCode200ResponseEmpty() {
    	when(processorFileTaskService.getProcessorFileTaskById(Mockito.anyString(), Mockito.anyString())).thenReturn(new ProcessorFileTask());
    	when(documentMetaDataService.getDocumentMetaData(Mockito.anyString())).thenReturn(new DocumentMetaData());
    	Map<String, Object> testresponse = new HashMap<>();
    	genericResponse = new GenericResponse("200", "success", testresponse);
    	execution.setVariable("response", genericResponse);
    	processMetadataFilesCallback.doExecute(execution);

    }
    
    
    @Test(expected = NullPointerException.class)
    public void testResponseCodeNot200WithFatalError() {
    	ProcessorFileTask processorFileTask = getProcessorFileTaskWithFatalError();
    	when(processorFileTaskService.getProcessorFileTaskById(Mockito.anyString(), Mockito.anyString())).thenReturn(processorFileTask);
    	when(documentMetaDataService.getDocumentMetaData(Mockito.anyString())).thenReturn(new DocumentMetaData());
    	when(processorFileTaskService.getProcessorFileTask(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(processorFileTask);
    	genericResponse = new GenericResponse("500", "failure", "testResponse");
    	execution.setVariable("response", genericResponse);
    	processMetadataFilesCallback.doExecute(execution);

    }

    @Test(expected = NullPointerException.class)
    public void testResponseCodeNot200() {
    	when(processorFileTaskService.getProcessorFileTaskById(Mockito.anyString(), Mockito.anyString())).thenReturn(new ProcessorFileTask());
    	when(documentMetaDataService.getDocumentMetaData(Mockito.anyString())).thenReturn(new DocumentMetaData());
    	genericResponse = new GenericResponse("500", "failure", "testResponse");
    	execution.setVariable("response", genericResponse);
    	processMetadataFilesCallback.doExecute(execution);
    	
    }
    
    
    
    
    private DocumentMetaData getDocumentMetaData() {
        DocumentMetaData dmd = new DocumentMetaData();
        Document metadataObj = Document.parse("{ " +
                "\"tin\" : \"123\"," +
                "\"mpin\" : \"456\"," +
                "\"corporateMpin\" : \"789\"," +
                "\"providerEmailId\" : \"test@test.com\"," +
                "\"emailAlertReq\" : \"Y\""+
                "\"sendToDocVault\" : false"+
                "\"sendToShutterfly\" : false"+
                "}");
        dmd.setMetadata(metadataObj);
        return dmd;
    }
    
    private ProcessorFileTask getProcessorFileTaskWithFatalError() {
    	ProcessorFileTask processorFileTask =  new ProcessorFileTask();
    	processorFileTask.setStatus(MetaDataStatus.FATAL_ERROR);
    	processorFileTask.setSummary(null);
    	return processorFileTask;
    }

    @Test
    public void testDoExecute_non200_setsStorageErrorAndFatalError_withExistingSummary() {
        ProcessorFileTask pft = new ProcessorFileTask();
        pft.setId("pft-1");
        pft.setAppIdentifier("app-1");
        pft.setServerType("srv");
        pft.setLocation("s3://bucket/fds/clientA/batch9/in.pdf");
        pft.setFileName("in.pdf");
        pft.setSummary(new ProcessorSummary());

        DocumentMetaData prunDoc = new DocumentMetaData();
        prunDoc.setId("doc-1");

        // real DelegateExecutionImpl -> set variables directly
        execution.setVariable("processorFileTaskId", "pft-1");
        execution.setVariable("prunDocumentId", "doc-1");
        execution.setVariable("appIdentifier", "app-1");
        execution.setVariable("response", new GenericResponse("500", "failure", "err"));

        when(processorFileTaskService.getProcessorFileTaskById("pft-1", "app-1")).thenReturn(pft);
        when(documentMetaDataService.getDocumentMetaData("doc-1")).thenReturn(prunDoc);
        when(processorFileTaskService.getProcessorFileTask("pft-1", "app-1", "srv")).thenReturn(pft);

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            ProcessorExecutionRecord rec = new ProcessorExecutionRecord();
            util.when(() -> ProcessorTaskUtil.createProcessorExecutionRecord("Updating processorFileTask from callback"))
                    .thenReturn(rec);
            util.when(() -> ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(
                    eq(processorFileTaskService), eq(pft), eq(rec), any()))
                    .thenAnswer(inv -> null);

            processMetadataFilesCallback.doExecute(execution);

            verify(documentMetaDataService, times(1)).saveDocumentMetaData(prunDoc);
            verify(filestoreService, times(1)).insertFile("s3://bucket/fds/clientA/batch9/in.pdf", "in.pdf");

            assertEquals("fds/clientA/", prunDoc.getS3FilePath());
            assertEquals("in.pdf", prunDoc.getFileName());
            assertEquals(MetaDataStatus.STORAGE_ERROR, prunDoc.getStatus());

            assertNotNull(pft.getSummary());
            assertEquals(MetaDataStatus.FATAL_ERROR, pft.getStatus());
            verify(errorMetaDataService, never()).writeToErrorCollection(any(), any());

            util.verify(() -> ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(
                    eq(processorFileTaskService), eq(pft), eq(rec), any()), times(1));
        }
    }

    @Test
    public void testDoExecute_non200_createsSummaryWhenNull() {
        ProcessorFileTask pft = new ProcessorFileTask();
        pft.setId("pft-2");
        pft.setAppIdentifier("app-1");
        pft.setServerType("srv");
        pft.setLocation("s3://bucket/fds/clientB/batch1/in2.pdf");
        pft.setFileName("in2.pdf");
        pft.setSummary(null);

        DocumentMetaData prunDoc = new DocumentMetaData();
        prunDoc.setId("doc-2");

        // use real DelegateExecution API, not Mockito when(...)
        execution.setVariable("processorFileTaskId", "pft-2");
        execution.setVariable("prunDocumentId", "doc-2");
        execution.setVariable("appIdentifier", "app-1");
        execution.setVariable("response", new GenericResponse("500", "failure", "err"));

        when(processorFileTaskService.getProcessorFileTaskById("pft-2", "app-1")).thenReturn(pft);
        when(documentMetaDataService.getDocumentMetaData("doc-2")).thenReturn(prunDoc);
        when(processorFileTaskService.getProcessorFileTask("pft-2", "app-1", "srv")).thenReturn(pft);

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            ProcessorExecutionRecord rec = new ProcessorExecutionRecord();
            util.when(() -> ProcessorTaskUtil.createProcessorExecutionRecord("Updating processorFileTask from callback"))
                    .thenReturn(rec);
            util.when(() -> ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(
                            eq(processorFileTaskService), eq(pft), eq(rec), any()))
                    .thenAnswer(inv -> null);

            processMetadataFilesCallback.doExecute(execution);

            assertNotNull(pft.getSummary());
            assertEquals(MetaDataStatus.FATAL_ERROR, pft.getStatus());
            verify(filestoreService, times(1)).insertFile("s3://bucket/fds/clientB/batch1/in2.pdf", "in2.pdf");
        }
    }

    
}

