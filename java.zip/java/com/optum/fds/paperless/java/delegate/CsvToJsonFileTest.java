package com.optum.fds.paperless.java.delegate;


import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.csv.CsvToJsonUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;




@RunWith(MockitoJUnitRunner.class)
public class CsvToJsonFileTest {

	@Mock
	private CsvToJsonUtil csvToJsonUtil;

	@Mock
	private CsvProcessorsService csvProcessorsService;

	@Mock
	ProcessorTaskUtil processorTaskUtil;

	@Mock
	ProcessorTransaction processorTransaction;

	@Mock
	private CsvProcessorService csvProcessorService;

	@Mock
	ErrorMetaDataService errorMetaDataService;

	@InjectMocks
	CsvToJsonFile csvToJsonFile;

	DelegateExecution execution;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);

		Document execVars = new Document().append(Workflow.APP_IDENTIFIER, "7rf7f6646").append(Workflow.JOB,
				Map.of("testKey", "testValue"));

		Mockito.lenient().when(execution.getVariables()).thenReturn(execVars);
		Mockito.lenient().when(execution.getVariable(Workflow.APP_IDENTIFIER, String.class))
				.thenReturn(execVars.get(Workflow.APP_IDENTIFIER, String.class));
		Mockito.lenient().when(execution.getVariable(Workflow.JOB, Map.class)).thenReturn(execVars.get(Workflow.JOB, Map.class));
	}

	@Test(expected = NullPointerException.class)
	public void testDoExecuteWithPocessorMetaDataNull() {
		csvToJsonFile.doExecute(execution);
	}

	@SuppressWarnings({ "deprecation", "static-access" })
	@Test
	public void testDoExecuteWithProcessorMetDataNotNull() {
		DelegateExecution exe = new DelegateExecutionImpl();
		ProcessorMetaData processorMetaData = new ProcessorMetaData();
		Map<String, Object> process = new HashMap<String, Object>();

		HashMap<String, Object> config = new HashMap<String, Object>();
		config.put("companionTRL", true);
		config.put("delimit", "sdsdsddsd");
		config.put(Workflow.TEMPLATE_NAME, "temptest");
		process.put("config", config);
		processorMetaData.setProcess(process);

		exe.setVariable("processorMetaData", processorMetaData);

		CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
		csvProcessorTransaction.setConfigSpaceId(236958);
		csvProcessorTransaction.setId("sdsdsd");
		exe.setVariable(Workflow.CSV_PROCESSOR_TRANSACTION, csvProcessorTransaction);
		exe.setVariable(Workflow.SPACE__ID, 23659);
		csvToJsonFile.doExecute(exe);
	}

	@Test
	public void testRemoveTrailerIsSuccess() throws IOException
	{
		csvToJsonFile.removeTrailer("src/test/resources/csv/", "FDSBatchInserts-test.csv");
		assert true;
	}
}
