package com.optum.fds.paperless.java.delegate;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.optum.fds.paperless.util.SftpUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;

import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.mongo.ProcessorTransactionCore;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.workflow.constants.Workflow;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

public class CsvMoveOriginalToArchiveFolderTest {

	@Mock
	CsvProcessorService csvProcessorService;
	
	@Mock
	ProcessorExecutionRecord processorExecutionRecord;
	
	@Mock
	ProcessorTaskUtil processorTaskUtil;
	
	@Mock
	ProcessorTransactionCore processorTransactionCore;

    @Mock
    SftpUtil sftpUtil;
	
	
	@InjectMocks
	CsvMoveOriginalToArchiveFolder csvMoveOriginalToArchiveFolder;

	DelegateExecution execution;

    private CsvProcessorTransaction txn;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);
		CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
		csvProcessorTransaction.setId("sdsdsd");
//		csvProcessorTransaction.setClientId(236589);
//		csvProcessorTransaction.setConfigSpaceId(658945);
		when(execution.getVariable(Workflow.CSV_PROCESSOR_TRANSACTION, CsvProcessorTransaction.class))
				.thenReturn(csvProcessorTransaction);

        txn = new CsvProcessorTransaction();
        txn.setId("txn-1");
        txn.setFileName("in.csv");
        txn.setLocation("C:\\\\tmp");

        when(execution.getId()).thenReturn("exec-1");
        when(execution.getVariable(Workflow.CSV_PROCESSOR_TRANSACTION, CsvProcessorTransaction.class)).thenReturn(txn);
        when(execution.getVariable(Workflow.SFTP_HOSTNAME, String.class)).thenReturn("host");
        when(execution.getVariable(Workflow.SFTP_USERNAME, String.class)).thenReturn("user");
        when(execution.getVariable(Workflow.SFTP_PW, String.class)).thenReturn("pw");
        when(execution.getVariable(Workflow.SFTP_ROOT_DIRECTORY, String.class)).thenReturn("/root");
        when(execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, String.class)).thenReturn("/archive");
        when(execution.getVariable(Workflow.MAX_SFTP_TRIES, Integer.class)).thenReturn(5);
        when(execution.getVariable(Workflow.RETRY_TIME_SECS, Integer.class)).thenReturn(30);
		
	}
	
	@Test(expected = NullPointerException.class)
	public void testDoExecuteIsSuccess()
	{
		csvMoveOriginalToArchiveFolder.doExecute(execution);
	}

    @Test
    public void testDoExecute_successBranch_andFinally() throws Exception {
        ProcessorExecutionRecord rec = mock(ProcessorExecutionRecord.class);

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            util.when(() -> ProcessorTaskUtil.createProcessorExecutionRecord("Cleanup CSV files", txn)).thenReturn(rec);

            csvMoveOriginalToArchiveFolder.doExecute(execution);

            verify(sftpUtil, times(1)).moveFileFromLocalToSFTPLocation(
                    eq("user"),
                    eq("pw"),
                    eq("host"),
                    eq(22),
                    eq("/archive"),
                    eq(txn.getLocation() + File.separator + txn.getFileName()),
                    eq(5),
                    eq(30L)
            );

            util.verify(() -> ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(
                    eq(txn), eq(rec), argThat((Map<String, String> m) ->
                            m != null && m.containsKey(Workflow.OUTCOME_KEY) &&
                                    m.get(Workflow.OUTCOME_KEY).contains("archive correctly")
                    )), times(1));

            verify(execution, times(1)).setTransientVariable(Workflow.CSV_PROCESSOR_TRANSACTION, txn);
            verify(csvProcessorService, times(1)).updateCsvProcessorTransactionMetaData(txn);
        }
    }

    @Test
    public void testDoExecute_sftpExceptionBranch_andFinally() throws Exception {
        ProcessorExecutionRecord rec = mock(ProcessorExecutionRecord.class);

        doThrow(new SftpException(4, "sftp fail")).when(sftpUtil).moveFileFromLocalToSFTPLocation(
                anyString(), anyString(), anyString(), anyInt(), anyString(), anyString(), anyInt(), anyLong());

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            util.when(() -> ProcessorTaskUtil.createProcessorExecutionRecord("Cleanup CSV files", txn))
                    .thenReturn(rec);

            csvMoveOriginalToArchiveFolder.doExecute(execution);

            util.verify(() -> ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(
                    eq(txn), eq(rec), any(Map.class)
            ), times(1));

            verify(execution, times(1)).setTransientVariable(Workflow.CSV_PROCESSOR_TRANSACTION, txn);
            verify(csvProcessorService, times(1)).updateCsvProcessorTransactionMetaData(txn);
        }
    }

    @Test
    public void testDoExecute_jschExceptionBranch_andFinally() throws Exception {
        ProcessorExecutionRecord rec = mock(ProcessorExecutionRecord.class);

        doThrow(new JSchException("jsch fail")).when(sftpUtil).moveFileFromLocalToSFTPLocation(
                anyString(), anyString(), anyString(), anyInt(), anyString(), anyString(), anyInt(), anyLong());

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            util.when(() -> ProcessorTaskUtil.createProcessorExecutionRecord("Cleanup CSV files", txn))
                    .thenReturn(rec);

            csvMoveOriginalToArchiveFolder.doExecute(execution);

            Map<String, String> expectedMessage = new java.util.HashMap<>();
            expectedMessage.put(Workflow.OUTCOME_KEY, "CSV File did not archived correctly: fileName" + txn.getFileName());

            util.verify(() -> ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(
                    txn, rec, expectedMessage
            ), times(1));

            verify(execution, times(1)).setTransientVariable(Workflow.CSV_PROCESSOR_TRANSACTION, txn);
            verify(csvProcessorService, times(1)).updateCsvProcessorTransactionMetaData(txn);
        }
    }

    @Test
    public void testDoExecute_ioExceptionBranch_andFinally() throws Exception {
        ProcessorExecutionRecord rec = mock(ProcessorExecutionRecord.class);

        doThrow(new IOException("io fail")).when(sftpUtil).moveFileFromLocalToSFTPLocation(
                anyString(), anyString(), anyString(), anyInt(), anyString(), anyString(), anyInt(), anyLong());

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            util.when(() -> ProcessorTaskUtil.createProcessorExecutionRecord("Cleanup CSV files", txn))
                    .thenReturn(rec);

            csvMoveOriginalToArchiveFolder.doExecute(execution);

            Map<String, String> expectedMessage = new java.util.HashMap<>();
            expectedMessage.put(Workflow.OUTCOME_KEY, "CSV File did not archived correctly: fileName" + txn.getFileName());

            util.verify(() -> ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(
                    txn, rec, expectedMessage
            ), times(1));

            verify(execution, times(1)).setTransientVariable(Workflow.CSV_PROCESSOR_TRANSACTION, txn);
            verify(csvProcessorService, times(1)).updateCsvProcessorTransactionMetaData(txn);
        }
    }

    @Test
    public void testDoExecute_outerExceptionBranch_andFinally() {
        when(execution.getVariable(Workflow.CSV_PROCESSOR_TRANSACTION, CsvProcessorTransaction.class))
                .thenThrow(new RuntimeException("outer fail"));

        try (MockedStatic<ProcessorTaskUtil> util = mockStatic(ProcessorTaskUtil.class)) {
            csvMoveOriginalToArchiveFolder.doExecute(execution);

            util.verify(() -> ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(
                    isNull(), isNull(), argThat((Map<String, String> m) ->
                            m != null && m.containsKey(Workflow.OUTCOME_KEY)
                    )), times(1));

            verify(execution, times(1)).setTransientVariable(Workflow.CSV_PROCESSOR_TRANSACTION, null);
            verify(csvProcessorService, times(1)).updateCsvProcessorTransactionMetaData(null);
        }
    }
}
