package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

@RunWith(MockitoJUnitRunner.class)
public class RequiredVarsResponseFileProcessTest {

    private final String TEST = "test";

    DelegateExecution execution;
    Map<String, Object> map = new HashMap<>();

    @InjectMocks
    RequiredVarsResponseFileProcess requiredVarResponseFileProcess;

    @Before
    public void setUp() throws Exception {

        execution = new DelegateExecutionImpl(map);
        execution.setVariable(Workflow.SEARCH_CRITERIA, TEST);
        execution.setVariable(Workflow.SEARCH_WINDOW, TEST);
        execution.setVariable(Workflow.TEMPLATE_NAME, TEST);

        execution.setVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, TEST);

        execution.setVariable(Workflow.SFTP_USERNAME, TEST);
        execution.setVariable(Workflow.SFTP_PW, TEST);
        execution.setVariable(Workflow.SFTP_DIRECTORY, TEST);
        execution.setVariable(Workflow.SFTP_HOSTNAME, TEST);
        execution.setVariable(Workflow.SFTP_FILENAME, TEST);
        execution.setVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, TEST);
    }

    @UserStory(references = "30212")
    @RallyTestCase(references = "TC31886")
    @Test
    public void testSuccess() throws Exception {
        requiredVarResponseFileProcess.execute(execution);
        assertNotNull(requiredVarResponseFileProcess.errorMap);
        assertEquals(0, requiredVarResponseFileProcess.errorMap.get(Workflow.NEW_ERRORS));
    }

    /**
     * Missing Search Criteria and Search Window
     * @throws Exception
     */
    @UserStory(references = "30212")
    @RallyTestCase(references = "TC31887")
    @Test
    public void testErrors() throws Exception {
        execution.setVariable(Workflow.SEARCH_CRITERIA, "");
        execution.setVariable(Workflow.SEARCH_WINDOW, "");
        requiredVarResponseFileProcess.execute(execution);
        assertNotNull(requiredVarResponseFileProcess.errorMap);
        assertEquals(2, requiredVarResponseFileProcess.errorMap.get(Workflow.NEW_ERRORS));
    }
    
    @Test
    public void testResponseFileProcessWithNullTemplate() throws Exception {
        execution.setVariable(Workflow.TEMPLATE_NAME, "");
        requiredVarResponseFileProcess.execute(execution);
        Document errorMap = requiredVarResponseFileProcess.errorMap;
		assertNotNull(errorMap);
        assertEquals(1, errorMap.get(Workflow.NEW_ERRORS));
    }

}
