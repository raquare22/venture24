package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.util.SftpUtil;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.workflow.constants.Workflow;


@RunWith(MockitoJUnitRunner.class)
public class SendACKFileToSftpServerTest {

	Map<String, Object> delegateMap = new HashMap<>();
	/*
	 * @Rule public PowerMockRule rule = new PowerMockRule();
	 */
	@Mock
	ProcessorService processorService;
	
	@Mock
	ErrorMetaDataService errorMetaDataService;

	@InjectMocks
	SendACKFileToSftpServer sendACKFileToSftpServer;

	DelegateExecution execution;

	@Mock
	SftpUtil sftpUtil;
	
    private static final Integer MAX_SFTP_TRIES = 2;
    private static final Long RETRY_TIME_SECS = 2L;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);

		execution = new DelegateExecutionImpl(delegateMap);

		ProcessorTransaction processorTransaction = new ProcessorTransaction();
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION, processorTransaction);
		execution.setVariable(Workflow.ACK_FLAG, true);
		execution.setVariable(Workflow.SFTP_HOSTNAME, "testhost");
		execution.setVariable(Workflow.SFTP_USERNAME, "testuser");
		execution.setVariable(Workflow.SFTP_PW, "testuserpw");
		execution.setVariable(Workflow.SFTP_ACK_DIRECTORY, "/dropzone/integration/");
		execution.setVariable(Workflow.ACK_FILE, Utilities.getInstance().getResourceFile("zippedfile1.zip").getAbsolutePath());
		execution.setVariable(Workflow.MAX_SFTP_TRIES, MAX_SFTP_TRIES);
		execution.setVariable(Workflow.RETRY_TIME_SECS, RETRY_TIME_SECS);
		
		when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
	}

	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29614")
	@Test
	public void testExecutionWithNoArchiveDirectory() throws Exception {
		Mockito.doThrow(new SftpException(1, "Test")).when(sftpUtil).moveFileFromLocalToSFTPLocation(
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyInt(), Mockito.anyLong());
		sendACKFileToSftpServer.execute(execution);
		assertNotNull(sendACKFileToSftpServer.errorMap);
		assertEquals(1, sendACKFileToSftpServer.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29615")
	@Test
	public void testExecutionWithArchiveDirectory() throws Exception {
		Mockito.doNothing().when(sftpUtil).moveFileFromLocalToSFTPLocation(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(),
				Mockito.anyLong());
		execution.setVariable(Workflow.SFTP_ARCHIVE_DIRECTORY,"/dropzone/integration/");
		sendACKFileToSftpServer.execute(execution);
		assertNotNull(sendACKFileToSftpServer.errorMap);
		assertEquals(0, sendACKFileToSftpServer.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	@UserStory(references = "US26654")
	@RallyTestCase(references = "TC30326")
	@Test
	public void testExecutionForFatalErrorWithArchiveDirectory() throws Exception {
		execution.setVariable(Workflow.SFTP_ARCHIVE_DIRECTORY,"/dropzone/integration/");
		ProcessorTransaction processorTransaction = execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class);
		processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION, processorTransaction);
		sendACKFileToSftpServer.execute(execution);
		assertEquals(MetaDataStatus.FATAL_ERROR, execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class).getStatus());
		assertNotNull(sendACKFileToSftpServer.errorMap);
		assertEquals(0, sendACKFileToSftpServer.errorMap.get(Workflow.NEW_ERRORS));
	}
	
//	 @UserStory(references = "US26654")
//	 @RallyTestCase(references = "TC30327")
//	 @Test public void testExecutionForInProcessWithArchiveDirectory() throws Exception {
//    	Map<String, String> mapMock = mock(Map.class);
//    	boolean value = false;
//    	try(MockedStatic<SftpUtil> mockedStatic = Mockito.mockStatic(SftpUtil.class)) {
//    		mockedStatic.when(() -> SftpUtil.moveFileFromLocalToSFTPLocation(
//    				Mockito.anyString(),Mockito.anyString(),
//					Mockito.anyString(),Mockito.anyInt(),
//					Mockito.anyString(),Mockito.anyString(),
//					Mockito.anyInt(),Mockito.anyLong())).thenAnswer(Answers.RETURNS_DEFAULTS);
//    	}
//    	// Mockito.when(sendACKFileToSftpServer.moveFileFromLocalToSFTPLocation(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),Mockito.anyInt(), Mockito.anyLong())).thenAnswer(Answers.RETURNS_DEFAULTS);
//		// Mockito.when(sendACKFileToSftpServer.moveFileFromLocalToSFTPLocation(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(),Mockito.anyLong())).thenAnswer(Answers.RETURNS_DEFAULTS);
//		execution.setVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, "/dropzone/integration/");
//    	ProcessorTransaction processorTransaction = execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class);
//    	processorTransaction.setStatus(MetaDataStatus.IN_PROCESS);
//    	execution.setVariable(Workflow.PROCESSOR_TRANSACTION, processorTransaction);
//    	sendACKFileToSftpServer.execute(execution);
//    	assertEquals(MetaDataStatus.COMPLETE, execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class).getStatus());
//    	assertNotNull(sendACKFileToSftpServer.errorMap); assertEquals(0, sendACKFileToSftpServer.errorMap.get(Workflow.NEW_ERRORS));
//    }

	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29616")
	@Test
	public void testExecutionWithAckFlagFalse() throws Exception {
		execution.setVariable(Workflow.ACK_FLAG, false);
		sendACKFileToSftpServer.execute(execution);
		assertNotNull(sendACKFileToSftpServer.errorMap);
		assertEquals(0, sendACKFileToSftpServer.errorMap.get(Workflow.NEW_ERRORS));
	}

	//SFTP exception
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29617")
	@Test
	public void testExecutionWithInvalidAckDirectory() throws Exception {
		execution.setVariable(Workflow.SFTP_ACK_DIRECTORY, null);
		sendACKFileToSftpServer.execute(execution);
		assertNotNull(sendACKFileToSftpServer.errorMap);
		assertEquals(0, sendACKFileToSftpServer.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	//JSchException exception.
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29620")
	@Test
	public void testExecutionWithJSchException() throws Exception {
		Mockito.doThrow(new JSchException()).when(sftpUtil).moveFileFromLocalToSFTPLocation(Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyInt(), Mockito.anyLong());
		sendACKFileToSftpServer.execute(execution);
		assertNotNull(sendACKFileToSftpServer.errorMap);
		assertEquals(1, sendACKFileToSftpServer.errorMap.get(Workflow.NEW_ERRORS));
	}

	//FileNotFoundException exception
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29618")
	@Test
	public void testExecutionWithAckZipFileWithInvalidFilePath() throws Exception {
		Mockito.doThrow(new FileNotFoundException()).when(sftpUtil).moveFileFromLocalToSFTPLocation(Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyInt(), Mockito.anyLong());
		execution.setVariable(Workflow.ACK_FILE, "zippedfile1.zip");
		sendACKFileToSftpServer.execute(execution);
		assertNotNull(sendACKFileToSftpServer.errorMap);
		assertEquals(1, sendACKFileToSftpServer.errorMap.get(Workflow.NEW_ERRORS));
	}


	//Invalid for checked exception for this call.
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29621")
	@Test
	public void testExecutionWithIOException() throws Exception {
		Mockito.doThrow(new IOException()).when(sftpUtil).moveFileFromLocalToSFTPLocation(Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyInt(), Mockito.anyLong());
		sendACKFileToSftpServer.execute(execution);
		assertNotNull(sendACKFileToSftpServer.errorMap);
		assertEquals(1, sendACKFileToSftpServer.errorMap.get(Workflow.NEW_ERRORS));
	}


	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29619")
	@Test
	public void testExecutionWithException() throws Exception {
		Mockito.doThrow(new RuntimeException("test exception")).when(sftpUtil).moveFileFromLocalToSFTPLocation(
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyInt(), Mockito.anyLong());
		delegateMap.put(Workflow.ACK_FLAG, true);
		ProcessorTransaction processorTransaction = new ProcessorTransaction();
		delegateMap.put(Workflow.PROCESSOR_TRANSACTION, processorTransaction);
		sendACKFileToSftpServer.execute(execution);
		assertNotNull(sendACKFileToSftpServer.errorMap);
		assertEquals(1, sendACKFileToSftpServer.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	
	@UserStory(references = "US25077")
	@RallyTestCase(references = "TC29622")
	@Test
	public void testExecutionWithMissingRequiredVariables() throws Exception {
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION, null);
		execution.setVariable(Workflow.ACK_FLAG, null);
		sendACKFileToSftpServer.execute(execution);
		assertNotNull(sendACKFileToSftpServer.errorMap);
		assertEquals(2, sendACKFileToSftpServer.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	@UserStory(references = "")
	@RallyTestCase(references = "")
	@Test
	public void testExecutionWithMissingSftpRetries() throws Exception {
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION, null);
		execution.setVariable(Workflow.ACK_FLAG, null);
		execution.setVariable(Workflow.MAX_SFTP_TRIES, null);
		execution.setVariable(Workflow.RETRY_TIME_SECS, null);
		sendACKFileToSftpServer.execute(execution);
		assertNotNull(sendACKFileToSftpServer.errorMap);
		assertEquals(2, sendACKFileToSftpServer.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	@Test
	public void testDoExecutewithException()
	{
		ExpectedException thrown = ExpectedException.none();
		thrown.expect(Exception.class);
        thrown.isAnyExceptionExpected();
        
        execution.setVariable(Workflow.SFTP_ACK_DIRECTORY, null);
		sendACKFileToSftpServer.execute(execution);
	}

	@Test
	public void testmoveFileFromLocalToSFTPLocationwithSftpException()
	{
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION, null);
		
        var message = new HashMap<>();
        String sftpHost = execution.getVariable(Workflow.SFTP_HOSTNAME, String.class);
		String sftpUser = execution.getVariable(Workflow.SFTP_USERNAME, String.class);
		String sftpPass = execution.getVariable(Workflow.SFTP_PW, String.class);
		String sftpAckDir = execution.getVariable(Workflow.SFTP_ACK_DIRECTORY, String.class);
		String sftpArchiveDir = execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, String.class);
		String ackFile = execution.getVariable(Workflow.ACK_FILE, String.class);
		
		  Integer maxSftpTriesVar = execution.getVariable(Workflow.MAX_SFTP_TRIES, Integer.class);
          Long retryTimeSecsVar = execution.getVariable(Workflow.RETRY_TIME_SECS, Long.class);
          int maxSftpTries = maxSftpTriesVar != null ? maxSftpTriesVar : 10;
          long retryTimeSecs = retryTimeSecsVar != null ? retryTimeSecsVar: 360;  // 6 minutes
        
        Map<String,String> sftpMap = new HashMap<>();
		sftpMap.put("sftpHost",sftpHost);
		sftpMap.put("sftpUser",sftpUser);
		sftpMap.put("sftpPass",sftpPass);
		
		ExpectedException thrown = ExpectedException.none();
		thrown.expect(FileNotFoundException.class);
        thrown.isAnyExceptionExpected();
        
		ReflectionTestUtils.invokeMethod(sendACKFileToSftpServer,"moveFileFromLocalToSFTPLocation", 
				message, sftpMap, sftpAckDir, ackFile, "ACK", maxSftpTries, retryTimeSecs);
		
	}
	
	@Test
	public void testmoveFileFromLocalToSFTPLocationwithFileNotFoundException()
	{
		execution.setVariable(Workflow.PROCESSOR_TRANSACTION, null);
		
        var message = new HashMap<>();
        String sftpHost = execution.getVariable(Workflow.SFTP_HOSTNAME, String.class);
		String sftpUser = execution.getVariable(Workflow.SFTP_USERNAME, String.class);
		String sftpPass = execution.getVariable(Workflow.SFTP_PW, String.class);
		String sftpAckDir = execution.getVariable(Workflow.SFTP_ACK_DIRECTORY, String.class);
		String sftpArchiveDir = execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, String.class);
		String ackFile = execution.getVariable(Workflow.ACK_FILE, String.class);
		
		  Integer maxSftpTriesVar = execution.getVariable(Workflow.MAX_SFTP_TRIES, Integer.class);
          Long retryTimeSecsVar = execution.getVariable(Workflow.RETRY_TIME_SECS, Long.class);
          int maxSftpTries = maxSftpTriesVar != null ? maxSftpTriesVar : 10;
          long retryTimeSecs = retryTimeSecsVar != null ? retryTimeSecsVar: 360;  // 6 minutes
        
        Map<String,String> sftpMap = new HashMap<>();
		sftpMap.put("sftpHost",sftpHost);
		sftpMap.put("sftpUser",sftpUser);
		sftpMap.put("sftpPass",sftpPass);
		
		ExpectedException thrown = ExpectedException.none();
		thrown.expect(FileNotFoundException.class);
        thrown.isAnyExceptionExpected();
        
		ReflectionTestUtils.invokeMethod(sendACKFileToSftpServer,"moveFileFromLocalToSFTPLocation", 
				message, sftpMap, null, null, null, maxSftpTries, retryTimeSecs);
		
	}

}
