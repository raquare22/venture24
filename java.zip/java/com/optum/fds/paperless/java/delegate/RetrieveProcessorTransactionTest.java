package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.constants.ProcessKeys;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class RetrieveProcessorTransactionTest {
	

	@Value("${INGEST_ROOT}")
	private static String ingestRoot;
	
	
	private final String SEARCH_CRITERIA = "{\"status\": {\"$in\": [\"COMPLETE\", \"COMPLETE_WITH_ERRORS\", \"FATAL_ERROR\"]}, \"ackStatus\": {\"$exists\": false}, \"configSpaceId\":8932 }";
	private final String INVALID_SEARCH_CRITERIA = "{\"status\": {\"$in\": [\"COMPLETE\", \"COMPLETE_WITH_ERRORS\", \"FATAL_ERROR\"]}, \"ackStatus\": {\"$exists\": false}, \"configSpaceId\":8932 ";
	private final String SEARCH_CRITERIA_WITH_NO_CONFIG_SPACE_ID = "{\"status\": {\"$in\": [\"COMPLETE\", \"COMPLETE_WITH_ERRORS\", \"FATAL_ERROR\"]}, \"ackStatus\": {\"$exists\": false} }";
	private final String SEARCH_WINDOW_WITH_VALID_OFFSETS = "{\"start_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"24\",\"format\":\"Hours\"}}";
	private final String SEARCH_WINDOW_WITH_DATES = "{\"start_date\":\"2018-06-16T00:00:00.000-06:00\",\"end_date\":\"2018-06-19T00:00:00.000-06:00\"}";
	private final String INVALID_SEARCH_WINDOW = "{\"start_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"24\",\"format\":\"Hours\"}";
	private final String SEARCH_WINDOW_WITH_NO_OFFSETS_OR_DATES = "{}";
	private final String TEST = "test";
	
	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();

//	@Mock
//	ApplicationPropertyUtil applicationPropertyUtil;

	@Mock
    MongoTemplate mongoTemplate;
	
	@Mock
	ErrorMetaDataService errorMetaDataService;

	@Mock
    EmailService emailService;
   
	@InjectMocks
    RetrieveProcessorTransaction RetrieveProcessorTransaction;
	
	Map<String, Object> delegateMap = new HashMap<>();
	DelegateExecution execution = new DelegateExecutionImpl(delegateMap);

    @Before
	public void setUp() throws Exception {
    	

        execution.setVariable(Workflow.SEARCH_CRITERIA, SEARCH_CRITERIA);

        execution.setVariable(Workflow.SEARCH_WINDOW, SEARCH_WINDOW_WITH_VALID_OFFSETS);
        
        execution.setVariable(Workflow.PROCESS_KEY, ProcessKeys.CLEANUP_PROCESS_KEY);
            	
    	List<ProcessorTransaction> processorTransactionList = getProcessorTransactionList();
//    	when(mongoTemplate.find(Mockito.any(), Mockito.eq(ProcessorTransaction.class), Mockito.eq(Workflow.PROCESSOR_COLLECTION_NAME))).thenReturn(processorTransactionList);

        String ingestWorkingDir = ingestRoot;
        execution.setVariable(Workflow.OUTPUT_FILE_DIR, ingestWorkingDir);

    	execution.setVariable(Workflow.EMAIL_RECEIVER, TEST);
    	execution.setVariable(Workflow.ENVIRONMENT, TEST);
//        when(emailService.sendEmail(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true); 
    	
//    	when(errorMetaDataService.writeToErrorCollection(Mockito.any(), Mockito.any())).thenReturn(new ErrorMetaData());
	}

	@Test
	@UserStory(references = "US24204")
	@RallyTestCase(references = "TC28823")
	public void testDoExecuteWithSearchWindowWithValidOffsets() throws Exception {
		List<String> processorTransactionIds = new ArrayList<>();
        processorTransactionIds.add("5900ec4b30043ae97bb5cbf7");
        processorTransactionIds.add("5900ec4b30043ae97bb5cc00");
        execution.setVariable(Workflow.PROCESSOR_TRANSACTION_IDS_MESSAGE, processorTransactionIds.toString());
		RetrieveProcessorTransaction.execute(execution);
		assertNotNull(RetrieveProcessorTransaction.errorMap);
		assertEquals(0, RetrieveProcessorTransaction.errorMap.get(Workflow.NEW_ERRORS));
		assertNotNull(execution.getVariable(Workflow.PROCESSOR_TRANSACTION_IDS_MESSAGE));
	}

	@Test
	@UserStory(references = "US24204")
	@RallyTestCase(references = "TC28824")
	public void testDoExecuteWithSearchWindowWithDates() throws Exception {
		   List<String> processorTransactionIds = new ArrayList<>();
	        processorTransactionIds.add("5900ec4b30043ae97bb5cbf7");
	        processorTransactionIds.add("5900ec4b30043ae97bb5cc00");
	    execution.setVariable(Workflow.PROCESSOR_TRANSACTION_IDS_MESSAGE, processorTransactionIds.toString());
		execution.setVariable(Workflow.SEARCH_WINDOW, SEARCH_WINDOW_WITH_DATES);
		RetrieveProcessorTransaction.execute(execution);
		assertNotNull(RetrieveProcessorTransaction.errorMap);
		assertEquals(0, RetrieveProcessorTransaction.errorMap.get(Workflow.NEW_ERRORS));
		assertNotNull(execution.getVariable(Workflow.PROCESSOR_TRANSACTION_IDS_MESSAGE));
	}

	@Test
	@UserStory(references = "US24204")
	@RallyTestCase(references = "TC28825")
	public void testDoExecuteWithNoSearchCriteria() throws Exception {
		execution.setVariable(Workflow.SEARCH_CRITERIA, null);
		RetrieveProcessorTransaction.execute(execution);
		assertNotNull(RetrieveProcessorTransaction.errorMap);
		assertEquals(1, RetrieveProcessorTransaction.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US24204")
	@RallyTestCase(references = "TC28826")
	public void testDoExecuteWithInvalidSearchCriteria() throws Exception {
		execution.setVariable(Workflow.SEARCH_CRITERIA, INVALID_SEARCH_CRITERIA);
		RetrieveProcessorTransaction.execute(execution);
		assertNotNull(RetrieveProcessorTransaction.errorMap);
		assertEquals(2, RetrieveProcessorTransaction.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	@Test
	@UserStory(references = "US24204")
	@RallyTestCase(references = "TC28828")
	public void testDoExecuteWithSearchCriteriaWithNoConfigSpaceId() throws Exception {
		execution.setVariable(Workflow.SEARCH_CRITERIA, SEARCH_CRITERIA_WITH_NO_CONFIG_SPACE_ID);
		RetrieveProcessorTransaction.execute(execution);
		assertNotNull(RetrieveProcessorTransaction.errorMap);
		assertEquals(1, RetrieveProcessorTransaction.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US24204")
	@RallyTestCase(references = "TC28829")
	public void testDoExecuteWithNoSearchWindow() throws Exception {
		execution.setVariable(Workflow.SEARCH_WINDOW, null);
		RetrieveProcessorTransaction.execute(execution);
		assertNotNull(RetrieveProcessorTransaction.errorMap);
		assertEquals(1, RetrieveProcessorTransaction.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US24204")
	@RallyTestCase(references = "TC28830")
	public void testDoExecuteWithInvalidSearchWindow() throws Exception {
		execution.setVariable(Workflow.SEARCH_WINDOW, INVALID_SEARCH_WINDOW);
		RetrieveProcessorTransaction.execute(execution);
		assertNotNull(RetrieveProcessorTransaction.errorMap);
		assertEquals(1, RetrieveProcessorTransaction.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US24204")
	@RallyTestCase(references = "TC28831")
	public void testDoExecuteWithSearchWindowWithNoOffsetstOrDates() throws Exception {
		execution.setVariable(Workflow.SEARCH_WINDOW, SEARCH_WINDOW_WITH_NO_OFFSETS_OR_DATES);
		RetrieveProcessorTransaction.execute(execution);
		assertNotNull(RetrieveProcessorTransaction.errorMap);
		assertEquals(1, RetrieveProcessorTransaction.errorMap.get(Workflow.NEW_ERRORS));
	}
	
	@Test
	@UserStory(references = "US24204")
	@RallyTestCase(references = "TC28833")
	public void testDoExecuteWithNoProcessorTransactionList() throws Exception {
//		when(mongoTemplate.find(Mockito.any(), Mockito.eq(ProcessorTransaction.class), Mockito.eq(Workflow.PROCESSOR_COLLECTION_NAME))).thenReturn(null);
		RetrieveProcessorTransaction.execute(execution);
		assertNotNull(RetrieveProcessorTransaction.errorMap);
		assertEquals(0, RetrieveProcessorTransaction.errorMap.get(Workflow.NEW_ERRORS));
		assertNotNull(execution.getVariable("exitNow", Boolean.class));
		assertTrue(execution.getVariable("exitNow", Boolean.class));
	}

	@Test
	@UserStory(references = "US24204")
	@RallyTestCase(references = "TC28834")
	public void testDoExecuteWithEmptyProcessorTransactionList() throws Exception {
    	List<ProcessorTransaction> processorTransactionList = new ArrayList<ProcessorTransaction>();
//		when(mongoTemplate.find(Mockito.any(), Mockito.eq(ProcessorTransaction.class), Mockito.eq(Workflow.PROCESSOR_COLLECTION_NAME))).thenReturn(processorTransactionList);
		RetrieveProcessorTransaction.execute(execution);
		assertNotNull(RetrieveProcessorTransaction.errorMap);
		assertEquals(0, RetrieveProcessorTransaction.errorMap.get(Workflow.NEW_ERRORS));
		assertNotNull(execution.getVariable("exitNow", Boolean.class));
		assertTrue(execution.getVariable("exitNow", Boolean.class));
	}

//	@Test
//	@UserStory(references = "US24488")
//	@RallyTestCase(references = "TC29008")
//	public void testDoExecuteWithSetVarOutputFileDir() throws Exception {
//		RetrieveProcessorTransaction.execute(execution);
//		assertNotNull(execution.getVariable(Workflow.OUTPUT_FILE_DIR));
//		String var = (String) execution.getVariable(Workflow.OUTPUT_FILE_DIR);
//		assertEquals(var, execution.getVariable(Workflow.OUTPUT_FILE_DIR));
//	}
	
//	@SuppressWarnings("unchecked")
//	@Test
//	@UserStory(references = "US24204")
//	@RallyTestCase(references = "TC28835")
//	public void testDoExecuteWithExceptionWhileGettingIngestRoot() throws Exception {
//		when(ConfigData.getOrDefaultStringWithActiveProfile(Workflow.INGEST_ROOT)).thenThrow(FSDataException.class);
//		RetrieveProcessorTransaction.execute(execution);
//		assertNotNull(RetrieveProcessorTransaction.errorMap);
//		assertEquals(1, RetrieveProcessorTransaction.errorMap.get(Workflow.NEW_ERRORS));
//	}

	private List<ProcessorTransaction> getProcessorTransactionList() throws Exception {
	    List<ProcessorTransaction> processorTransactionList = new ArrayList<>();
	    processorTransactionList.add(getProcessorTransaction1());
	    processorTransactionList.add(getProcessorTransaction2());
	    return processorTransactionList;
	}
	
	private ProcessorTransaction getProcessorTransaction1() throws IOException {
		ProcessorTransaction processorTransaction1;
	    String processTrans1 = "{"
	    		+ "\"id\" : \"5900ec4b30043ae97bb5cbf7\","
	    		+ "\"processorId\" : \"58cab698c2e6f7ff1c8e8c44\","
	    		+ "\"fileName\" : \"good.zip\","
	    		+ "\"location\" : \"/bconnected/ingest/testapp/3007/5900ec4a30043ae97bb5cbf6\","
	    		+ "\"processorRecordType\" : \"processorTransaction\","
	    	    + "\"fileToProcessList\" : ["
	    	    + "\"53760302_72269907.pdf\", "
	    	    + "\"empty.pdf\""
	    	    + "],"
	    		+ "\"summary\" : {"
	    	    + "\"processingMetrics\" : {"
	    		+ "\"totalBytes\" : 12300"
	    		+ "},"
	    		+ "\"errorList\" : [ "
	    		+ "{"
	    		+ "\"errorMessage\" : \"There was a mismatch between count and files to be processed. Count is at 1 and there are 2 files listed.\","
	    		+ "\"errorCode\" : 7"
	    		+ "}"
	    		+ "],"
	    		+ "\"runTime\" : 3051,"
	    		+ "\"startTime\" : \"2017-04-26T18:51:55.184Z\","
	    		+ "\"endTime\" : \"2017-04-26T18:51:58.235Z\","
	    		+ "\"xmlObject\" : {"
	    		+ "\"batchId\" : \"2017031_104410_ELGS_Customer_Care_A\","
	    		+ "\"dataGroup\" : \"NASC\","
	    		+ "\"count\" : 1,"
	    		+ "\"files\" : {"
	    		+ "\"fileList\" : [ "
	    		+ "{"
	    		+ "\"fileName\" : \"empty.pdf\""
	    		+ "}, "
	    		+ "{"
	    		+ "\"fileName\" : \"53760302_72269907.pdf\""
	    		+ "}"
	    		+ "]"
	    		+ "}"
	    		+ "}"
	    		+ "},"
	    		+ "\"status\" : \"COMPLETE\","
	    		+ "\"appIdentifier\" : \"testapp\""
	    		+ "}";
	    processorTransaction1 = Parser.parseJson(processTrans1, ProcessorTransaction.class);
	    return processorTransaction1;
	}	
	
	private ProcessorTransaction getProcessorTransaction2() throws IOException {
		ProcessorTransaction processorTransaction2;
	    String processTrans2 = "{"
	    		+ "\"id\" : \"5900ec4b30043ae97bb5cc00\","
	    		+ "\"processorId\" : \"58cab698c2e6f7ff1c8e8c44\","
	    		+ "\"fileName\" : \"testNoSummary.zip\","
	    		+ "\"location\" : \"/bconnected/ingest/testapp/3007/5900ec4b30043ae97bb5cbf9\","
	    		+ "\"processorRecordType\" : \"processorTransaction\","
	    		+ "\"summary\" : {"
	    		+ "\"processingMetrics\" : {"
	    		+ "\"totalBytes\" : 36900"
	    		+ "},"
	    		+ "\"errorList\" : [ "
	    		+ "{"
	    		+ "\"errorMessage\" : \"File not found\","
	    		+ "\"errorCode\" : 1"
	    				+ "}"
	    				+ "],"
	    				+ "\"startTime\" : \"2017-04-26T18:51:58.343Z\""
	    				+ "},"
	    				+ "\"status\" : \"FATAL_ERROR\","
	    	    		+ "\"appIdentifier\" : \"testapp\""
	    				+ "}";
	    processorTransaction2 = Parser.parseJson(processTrans2, ProcessorTransaction.class);
	    return processorTransaction2;
	}
	
	@UserStory(references = "US28220")
	@RallyTestCase(references = "TC31197")
	@Test
    public void testGetProcessorTransactionsException() throws NoSuchMethodException, SecurityException {
		Mockito.when(mongoTemplate.find(Mockito.any(Query.class), Mockito.eq(ProcessorTransaction.class), Mockito.anyString())).thenThrow(new RuntimeException("TEST"));
		Object[] objs = { new String("{\"key\" : \"value\"}"), new Criteria(), execution };
		Class<?> parms[] = new Class[objs.length];
		parms[0] = String.class;
		parms[1] = Criteria.class;
		parms[2] = DelegateExecution.class;
		Method privateMethod = RetrieveProcessorTransaction.getClass().getDeclaredMethod("getProcessorTransactions", parms);
		privateMethod.setAccessible(true);
		try
		{
			privateMethod.invoke(RetrieveProcessorTransaction, objs);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
    }

}
