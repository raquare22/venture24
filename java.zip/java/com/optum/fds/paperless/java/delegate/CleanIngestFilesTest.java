package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import org.mockito.junit.MockitoJUnitRunner;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;

@RunWith(MockitoJUnitRunner.class)
public class CleanIngestFilesTest {

	private final String TEMP_FOLDER = System.getenv("WORKSPACE") + "/temp";
	private final String TEST = "test";

	@InjectMocks
	CleanIngestFiles cleanIngestFiles;

	@Rule
	public TemporaryFolder tempFolder = new TemporaryFolder();

	DelegateExecution execution = new DelegateExecutionImpl();

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);

		// Ensure the temp folder exists
//		Path tempFolderPath = Paths.get(TEMP_FOLDER);
//		if (!Files.exists(tempFolderPath)) {
//			Files.createDirectories(tempFolderPath);
//		}
//
//		Path tempWorkingPath = Utilities
//				.createWorkingDirectory(tempFolderPath.toString() + Workflow.DEFAULT_FILE_SEPARATOR + UUID.randomUUID().toString());
		String tempWorkingPath = tempFolder.getRoot().getAbsolutePath();

		Files.copy(Utilities.getInstance().getResourceFile("zippedfile1.zip").toPath(),
				Paths.get(tempWorkingPath + Workflow.DEFAULT_FILE_SEPARATOR + "test.zip"),
				StandardCopyOption.REPLACE_EXISTING);

		execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempWorkingPath);
		execution.setVariable(Workflow.EMAIL_RECEIVER, TEST);
		execution.setVariable(Workflow.ENVIRONMENT, TEST);
	}

	@Test
	@UserStory(references = "US24488")
	@RallyTestCase(references = "TC29024")
	public void testExecute() throws Exception {
		cleanIngestFiles.execute(execution);
		assertNotNull(cleanIngestFiles.errorMap);
		assertEquals(0, cleanIngestFiles.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testExecuteShutterfly() throws Exception {
		String tempWorkingPath = tempFolder.getRoot().getAbsolutePath();
		execution.setVariable(Workflow.OUTPUT_FILE_DIR, null);
		execution.setVariable(Workflow.OUTPUT_FILE_DIR_SHUTTERFLY, tempWorkingPath);
		cleanIngestFiles.execute(execution);
		assertNotNull(cleanIngestFiles.errorMap);
		assertEquals(0, cleanIngestFiles.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	public void testExecuteBounce() throws Exception {
		String tempWorkingPath = tempFolder.getRoot().getAbsolutePath();
		execution.setVariable(Workflow.OUTPUT_FILE_DIR, null);
		execution.setVariable(Workflow.OUTPUT_FILE_DIR_BOUNCE, tempWorkingPath);
		cleanIngestFiles.execute(execution);
		assertNotNull(cleanIngestFiles.errorMap);
		assertEquals(0, cleanIngestFiles.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US24488")
	@RallyTestCase(references = "TC29025")
	public void testExecuteWithNullOutputFileDir() throws Exception {
		execution.setVariable(Workflow.OUTPUT_FILE_DIR, null);
		cleanIngestFiles.execute(execution);
		assertNotNull(cleanIngestFiles.errorMap);
		assertEquals(0, cleanIngestFiles.errorMap.get(Workflow.NEW_ERRORS));
	}

	@Test
	@UserStory(references = "US25556")
	@RallyTestCase(references = "TC29808")
	public void testExecuteWithIOException() throws Exception {
		String tempWorkingPath = tempFolder.getRoot().getAbsolutePath();
		Files.copy(Utilities.getInstance().getResourceFile("zippedfile1.zip").toPath(),
				Paths.get(tempWorkingPath + Workflow.DEFAULT_FILE_SEPARATOR + "test.zip"),
				StandardCopyOption.REPLACE_EXISTING);
		execution.setVariable(Workflow.OUTPUT_FILE_DIR, tempWorkingPath);
		CleanIngestFiles cleanIngestFilesSpy = Mockito.spy(cleanIngestFiles);
		cleanIngestFiles.execute(execution);
		assertNotNull(cleanIngestFiles.errorMap);
		assertEquals(0, cleanIngestFiles.errorMap.get(Workflow.NEW_ERRORS));
	}

}