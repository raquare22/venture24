package com.optum.fds.paperless.java.delegate;

import static org.mockito.Mockito.when;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorRowTask;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class CsvSftpProcessCallbackTest {

	@Mock
	CsvProcessorsService csvProcessorsService;

	@Mock
	CsvProcessorService csvProcessorService;

	@Mock
	CsvCleanupFilesProcess csvCleanupFilesProcess;;

	@Mock
	ErrorMetaDataService errorMetaDataService;

	@InjectMocks
	CsvSftpProcessCallback csvSftpProcessCallback;

	@Mock
	GenericResponse genericResponse;

	@Mock
	CsvProcessorRowTask csvProcessorRowTask;

	@Mock
	CsvProcessorTransaction csvProcessorTransaction;

	DelegateExecution execution;

	@SuppressWarnings("deprecation")
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);
	}

	@Test
	public void testDoExecuteIsSuccess() {
		genericResponse = new GenericResponse("200", "success", "testResponse");
		when(execution.getVariable("response")).thenReturn(genericResponse);
		when(execution.getVariable(Workflow.REST_CSV_PROCESSOR_ROW_TASK)).thenReturn("id8978");

		when(csvProcessorService.getCsvProcessorRowTaskById("id8978")).thenReturn(csvProcessorRowTask);
		when(execution.getVariable(Workflow.REST_RECORD_NUMBER)).thenReturn(1);
//    	Integer recordNumber = (Integer) execution.getVariable(Workflow.REST_RECORD_NUMBER);
//    	csvProcessorService.getCsvProcessorTransactionById(processorId);
		when(csvProcessorService.getCsvProcessorTransactionById("id8978")).thenReturn(csvProcessorTransaction);
		csvSftpProcessCallback.execute(execution);
	}

	@Test
	public void testDoExecuteWithRestRecordNumberNotEqualtoOne() {

		genericResponse = new GenericResponse("200", "success", "testResponse");
		when(execution.getVariable("response")).thenReturn(genericResponse);
		when(execution.getVariable(Workflow.REST_CSV_PROCESSOR_ROW_TASK)).thenReturn("id8978");

		when(csvProcessorService.getCsvProcessorRowTaskById("id8978")).thenReturn(csvProcessorRowTask);
		when(execution.getVariable(Workflow.REST_RECORD_NUMBER)).thenReturn(2658);
//    	Integer recordNumber = (Integer) execution.getVariable(Workflow.REST_RECORD_NUMBER);
//    	csvProcessorService.getCsvProcessorTransactionById(processorId);
		when(csvProcessorService.getCsvProcessorTransactionById("id8978")).thenReturn(csvProcessorTransaction);
		csvSftpProcessCallback.execute(execution);
	}

	@Test
	public void testDoExecuteWithCsvProcessorTransactionNotEqualtoNull() {

		genericResponse = new GenericResponse("200", "success", "testResponse");
		when(execution.getVariable("response")).thenReturn(genericResponse);
		when(execution.getVariable(Workflow.REST_CSV_PROCESSOR_ROW_TASK)).thenReturn("id8978");

		when(csvProcessorService.getCsvProcessorRowTaskById("id8978")).thenReturn(csvProcessorRowTask);
		when(execution.getVariable(Workflow.REST_RECORD_NUMBER)).thenReturn(2658);
		when(execution.getVariable(Workflow.REST_LAST_RECORD)).thenReturn(true);
		when(execution.getVariable(Workflow.REST_TRX_ID)).thenReturn("etet5getet");

		csvProcessorTransaction = new CsvProcessorTransaction();
		csvProcessorTransaction.setRowCount(1);
		csvProcessorTransaction.setJsonFileName("test.json");
		when(csvProcessorService.getCsvProcessorTransactionById("id8978")).thenReturn(csvProcessorTransaction);
		csvSftpProcessCallback.execute(execution);
	}
}
