package com.optum.fds.paperless.java.delegate;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class CsvCleanupFilesProcessTest {

	@InjectMocks
	CsvCleanupFilesProcess csvCleanupFilesProcess;

	@Mock
	CsvMoveOriginalToArchiveFolder csvMoveOriginalToArchiveFolder;

	@Mock
	CSVDeleteWorkingDirectory csvDeleteWorkingDirectory;

	@Mock
	CsvProcessorTransaction csvProcessorTransaction;

	DelegateExecution execution;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		execution = Mockito.mock(DelegateExecution.class);
		
		Document execVars = new Document().append(Workflow.CSV_PROCESSOR_TRANSACTION, csvProcessorTransaction);

		when(execution.getVariables()).thenReturn(execVars);
		when(execution.getVariable(Workflow.CSV_PROCESSOR_TRANSACTION, CsvProcessorTransaction.class))
				.thenReturn(execVars.get(Workflow.CSV_PROCESSOR_TRANSACTION, CsvProcessorTransaction.class));
		
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testDoExecuteIsSuccess() {
		when(csvProcessorTransaction.getId()).thenReturn("sdghsdhshd");
		when(csvProcessorTransaction.getLocation()).thenReturn("sdghsdhshd");
		csvCleanupFilesProcess.doExecute(execution);
		Map<String, Object> errorMap = execution.getVariable("errorMap", Map.class);
		assertTrue(errorMap == null);
	}

}
