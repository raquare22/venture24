package com.optum.fds.paperless.java.delegate;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;

import org.flowable.engine.delegate.DelegateExecution;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.optum.fds.paperless.java.delegate.docvault.OutOfRetriesException;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class USPClaimsResponseFileApiNotifyTest {

    @InjectMocks
    private USPClaimsResponseFileApiNotify uspClaimsResponseFileApiNotify;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private OauthManagerUtil oauthManagerUtil;

    @Mock
    private DelegateExecution execution;

    @Mock
    private TemplateHandler templateHandler;

    private MockedStatic<TemplateFactory> mockedTemplateFactory;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        // Mock TemplateFactory to return a valid TemplateHandler
        mockedTemplateFactory = mockStatic(TemplateFactory.class);
        mockedTemplateFactory.when(() -> TemplateFactory.getInstance(anyString())).thenReturn(templateHandler);
    }

    @After
    public void tearDown() {
        // Close the static mock to avoid conflicts in other tests
        if (mockedTemplateFactory != null) {
            mockedTemplateFactory.close();
        }
    }

    @Test
    public void testDoExecute_Success() throws Exception {
        // Mock variables
        ArrayList<HashMap<String, Object>> apiNotifyList = new ArrayList<>();
        HashMap<String, Object> notifyMap = new HashMap<>();
        notifyMap.put("zipFileName", "test.zip");
        apiNotifyList.add(notifyMap);

        when(execution.getVariable("USPClaimsNotifyList", ArrayList.class)).thenReturn(apiNotifyList);
        when(execution.getVariable(Workflow.USPCLAIMS_REST_URL, String.class)).thenReturn("http://mock-endpoint");
        when(execution.getVariable(Workflow.NOTIFY_API_OAUTH_URL, String.class)).thenReturn("http://mock-oauth-url");
        when(execution.getVariable(Workflow.NOTIFY_API_CLIENT_ID, String.class)).thenReturn("mockClientId");
        when(execution.getVariable(Workflow.NOTIFY_API_CLIENT_SECRET, String.class)).thenReturn("mockClientSecret");
        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false),isNull()))
                .thenReturn("mockToken");
        when(templateHandler.convertWithTemplate(any())).thenReturn("{\"mock\":\"json\"}");
        when(restTemplate.exchange(anyString(), any(), any(), eq(String.class)))
                .thenReturn(ResponseEntity.ok("Success"));

        // Execute
        uspClaimsResponseFileApiNotify.doExecute(execution);

        // Verify
        verify(restTemplate, times(1)).exchange(anyString(), any(), any(), eq(String.class));
    }


    @Test
    public void testDoExecute_BadRequest() throws Exception {
        // Mock variables
        ArrayList<HashMap<String, Object>> apiNotifyList = new ArrayList<>();
        HashMap<String, Object> notifyMap = new HashMap<>();
        notifyMap.put("zipFileName", "test.zip");
        apiNotifyList.add(notifyMap);

        when(execution.getVariable("USPClaimsNotifyList", ArrayList.class)).thenReturn(apiNotifyList);
        when(execution.getVariable(Workflow.USPCLAIMS_REST_URL, String.class)).thenReturn("http://mock-endpoint");
        when(execution.getVariable(Workflow.NOTIFY_API_OAUTH_URL, String.class)).thenReturn("http://mock-oauth-url");
        when(execution.getVariable(Workflow.NOTIFY_API_CLIENT_ID, String.class)).thenReturn("mockClientId");
        when(execution.getVariable(Workflow.NOTIFY_API_CLIENT_SECRET, String.class)).thenReturn("mockClientSecret");
        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken");
        when(templateHandler.convertWithTemplate(any())).thenReturn("{\"mock\":\"json\"}");


        HttpClientErrorException exception = HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST, null, null, null, null);
        when(restTemplate.exchange(anyString(), any(), any(), eq(String.class)))
                .thenThrow(exception);

        // Execute
        uspClaimsResponseFileApiNotify.doExecute(execution);

        // Verify
        verify(restTemplate, times(1)).exchange(anyString(), any(), any(), eq(String.class));
    }

    @Test
    public void testDoExecute_UnauthorizedError() throws Exception {
        // Mock variables
        ArrayList<HashMap<String, Object>> apiNotifyList = new ArrayList<>();
        HashMap<String, Object> notifyMap = new HashMap<>();
        notifyMap.put("zipFileName", "test.zip");
        apiNotifyList.add(notifyMap);

        when(execution.getVariable("USPClaimsNotifyList", ArrayList.class)).thenReturn(apiNotifyList);
        when(execution.getVariable(Workflow.USPCLAIMS_REST_URL, String.class)).thenReturn("http://mock-endpoint");
        when(execution.getVariable(Workflow.NOTIFY_API_OAUTH_URL, String.class)).thenReturn("http://mock-oauth-url");
        when(execution.getVariable(Workflow.NOTIFY_API_CLIENT_ID, String.class)).thenReturn("mockClientId");
        when(execution.getVariable(Workflow.NOTIFY_API_CLIENT_SECRET, String.class)).thenReturn("mockClientSecret");
        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false), isNull()))
                .thenReturn("mockToken");
        when(templateHandler.convertWithTemplate(any())).thenReturn("{\"mock\":\"json\"}");


        HttpClientErrorException exception = HttpClientErrorException.Unauthorized.create(HttpStatus.UNAUTHORIZED, null, null, null, null);
        when(restTemplate.exchange(anyString(), any(), any(), eq(String.class)))
                .thenThrow(exception);

        // Execute
        uspClaimsResponseFileApiNotify.doExecute(execution);

        // Verify
        verify(restTemplate, times(5)).exchange(anyString(), any(), any(), eq(String.class));
    }

    @Test
    public void testDoExecute_5XXError() throws Exception {
        // Mock variables
        ArrayList<HashMap<String, Object>> apiNotifyList = new ArrayList<>();
        HashMap<String, Object> notifyMap = new HashMap<>();
        notifyMap.put("zipFileName", "test.zip");
        apiNotifyList.add(notifyMap);

        when(execution.getVariable("USPClaimsNotifyList", ArrayList.class)).thenReturn(apiNotifyList);
        when(execution.getVariable(Workflow.USPCLAIMS_REST_URL, String.class)).thenReturn("http://mock-endpoint");
        when(execution.getVariable(Workflow.NOTIFY_API_OAUTH_URL, String.class)).thenReturn("http://mock-oauth-url");
        when(execution.getVariable(Workflow.NOTIFY_API_CLIENT_ID, String.class)).thenReturn("mockClientId");
        when(execution.getVariable(Workflow.NOTIFY_API_CLIENT_SECRET, String.class)).thenReturn("mockClientSecret");
        when(oauthManagerUtil.getOauthToken(anyString(), anyString(), anyString(), anyString(), anyString(), eq(false),isNull()))
                .thenReturn("mockToken");
        when(templateHandler.convertWithTemplate(any())).thenReturn("{\"mock\":\"json\"}");

        HttpServerErrorException exception = HttpServerErrorException.GatewayTimeout.create(HttpStatus.GATEWAY_TIMEOUT, null, null, null, null);
        when(restTemplate.exchange(anyString(), any(), any(), eq(String.class)))
                .thenThrow(exception);

        // Execute
        uspClaimsResponseFileApiNotify.doExecute(execution);

        // Verify
        verify(restTemplate, times(5)).exchange(anyString(), any(), any(), eq(String.class));
    }

    @Test
    public void testDoExecute_ExceptionHandling() throws Exception {
        // Mock variables
        when(execution.getVariable("USPClaimsNotifyList", ArrayList.class)).thenThrow(new RuntimeException("Mock Exception"));

        // Execute
        uspClaimsResponseFileApiNotify.doExecute(execution);

        // Verify
        verify(execution, times(1)).setTransientVariable(eq("exitNow"), eq(true));
    }
}