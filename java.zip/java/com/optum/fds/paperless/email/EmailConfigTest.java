package com.optum.fds.paperless.email;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.mail.javamail.JavaMailSender;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;

public class EmailConfigTest {

	@UserStory(references = "US21610")
	@RallyTestCase(references = "TC26301")
	@Test
	public void getMailSenderTest() {
		String hostName = "www.optum.com";
		int portNumber = 25;
		EmailConfig emailConfig = new EmailConfig();
		JavaMailSender mailSender = emailConfig.getMailSender(hostName, portNumber);
		Assert.assertNotNull(mailSender);
	}
}
