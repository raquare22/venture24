package com.optum.fds.paperless.email;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;

import org.junit.Test;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;

public class EmailUtilTest {
	@UserStory(references = "US23339")
    @RallyTestCase(references = "TC28148")
    @Test
    public void testJsonToHtmlWithTwoLevels() throws IOException {
        String jsonStr = "{\n" +
                "  \"form_id\": \"37\",\n" +
                "  \"form_name\": \"UHC Form\",\n" +
                "  \"form_data\": {\n" +
                "    \"First Name\": \"Ann\",\n" +
                "    \"Last Name\": \"Smith\"\n" +
                "  }\n" +
                "}";

        String expectedHtmlWithTwoLevel = "<html>" +
                "<b> form_id: </b>&nbsp; 37<br><br>" +
                "<b> form_name: </b>&nbsp; UHC Form<br><br>" +
                "<b> form_data: </b><br><br>" +
                "<div style=\"padding-left: 40px;\">" +
                  "<b> First Name: </b>&nbsp; Ann<br><br>" +
                  "<b> Last Name: </b>&nbsp; Smith<br><br></div>" +
                "</html>";

        assertEquals(expectedHtmlWithTwoLevel, EmailUtil.jsonToHtml(jsonStr));
    }

    @UserStory(references = "US23339")
    @RallyTestCase(references = "TC28149")
    @Test
    public void testJsonToHtmlWithThreeLevelsAndArray() throws IOException {
        String jsonStr = "{\n" +
                "  \"form_id\": \"37\",\n" +
                "  \"form_name\": \"UHC Form\",\n" +
                "  \"form_data\": {\n" +
                "         \"First Name\": \"JoAnn\",\n" +
                "         \"formContextData\":{\n" +
                "            \"postalCode\":\"12345\",\n" +
                "            \"ids\":[\n" +
                "               {\n" +
                "                  \"id\":\"556223333\",\n" +
                "                  \"type\":\"NPI\"\n" +
                "               },\n" +
                "               {\n" +
                "                  \"id\":\"111-22-3333\",\n" +
                "                  \"type\":\"SSN\"\n" +
                "               }\n" +
                "            ]}\n" +
                "  }\n" +
                "}";

        String expectedHtmlWithThreeLevelAndArray =
              "<html>" +
                "<b> form_id: </b>&nbsp; 37<br><br>" +
                "<b> form_name: </b>&nbsp; UHC Form<br><br>" +
                "<b> form_data: </b><br><br>" +
                "<div style=\"padding-left: 40px;\">" +
                  "<b> First Name: </b>&nbsp; JoAnn<br><br>" +
                  "<b> formContextData: </b><br><br>" +
                  "<div style=\"padding-left: 40px;\">" +
                    "<b> postalCode: </b>&nbsp; 12345<br><br>" +
                    "<b> ids: </b>" +
                    "<div style=\"padding-left: 40px;\">" +
                    "<b> id: </b>&nbsp; 556223333<br><br>" +
                    "<b> type: </b>&nbsp; NPI<br><br>" +
                    "<b> id: </b>&nbsp; 111-22-3333<br><br>" +
                    "<b> type: </b>&nbsp; SSN<br><br>" +
                  "</div>" +
                "</div>" +
              "</html>";
        assertEquals(expectedHtmlWithThreeLevelAndArray, EmailUtil.jsonToHtml(jsonStr));
    }

    @UserStory(references = "US23339")
    @RallyTestCase(references = "TC28150")
    @Test
    public void testJsonToHtmlWithEmptyString() throws IOException {
        assertEquals("<html></html>",EmailUtil.jsonToHtml(""));
    }

}
