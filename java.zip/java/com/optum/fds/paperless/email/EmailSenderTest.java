package com.optum.fds.paperless.email;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import jakarta.mail.internet.MimeMessage;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessagePreparator;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;

public class EmailSenderTest {


	private ArgumentCaptor<MimeMessagePreparator> preparatorArgumentCaptor;
	private MimeMessage mimeMessage;

	EmailSender emailSender;

	@Mock
	JavaMailSender mailSender;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		preparatorArgumentCaptor = ArgumentCaptor.forClass(MimeMessagePreparator.class);
		Mockito.doNothing().when(mailSender).send(preparatorArgumentCaptor.capture());
		mimeMessage = new JavaMailSenderImpl().createMimeMessage();
	}

	@UserStory(references = "US21610")
	@RallyTestCase(references = "TC26299")
	@Test
	public void sendMailTest() throws Exception {
		Mockito.doNothing().when(mailSender).send(Mockito.any(SimpleMailMessage.class));
		emailSender.sendMail("dian.jiang@optum.com", "dian.jiang@optum.com", "Unit Test", "msg", mailSender);
	}

	@UserStory(references = "US21610")
	@RallyTestCase(references = "TC26300")
	@Test(expected=MailSendException.class)
	public void sendMailTestWithException() throws Exception, MailSendException {
		Mockito.doThrow(new MailSendException("Send email failed")).when(mailSender).send(Mockito.any(SimpleMailMessage.class));
		emailSender.sendMail("dian.jiang@optum.com", "dian.jiang@optum.com", "Unit Test", "msg", mailSender);
	}


	@UserStory(references = "US22105")
	@RallyTestCase(references = "TC27208")
	@Test
	public void sendMailWithAttachmentsTest() throws Exception {
		Mockito.doNothing().when(mailSender).send(Mockito.any(MimeMessage.class));
		Mockito.when(mailSender.createMimeMessage()).thenReturn(mimeMessage);
		List<File> attachments = new ArrayList<>();
		File file =  new File("/src/test/resources/sendmail/sendemail.pdf");
		attachments.add(file);
		emailSender.sendMailWithAttachments("nagendhar_reddypappu@optum.com", "nagendhar_reddypappu@optum.com", "Unit Test", "msg",attachments, mailSender);
	}

}
