package com.optum.fds.paperless.file.summary;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class SummaryFileWithAttributesTest {

    @Test
    public void testGetAndSetBatchId() {
        SummaryFileWithAttributes summaryFile = new SummaryFileWithAttributes();
        String batchId = "12345";
        summaryFile.setBatchId(batchId);
        assertEquals(batchId, summaryFile.getBatchId());
    }

    @Test
    public void testGetAndSetDataGroup() {
        SummaryFileWithAttributes summaryFile = new SummaryFileWithAttributes();
        String dataGroup = "Group1";
        summaryFile.setDataGroup(dataGroup);
        assertEquals(dataGroup, summaryFile.getDataGroup());
    }

    @Test
    public void testGetAndSetCount() {
        SummaryFileWithAttributes summaryFile = new SummaryFileWithAttributes();
        String count = "10";
        summaryFile.setCount(count);
        assertEquals(count, summaryFile.getCount());
    }

    @Test
    public void testGetAndSetFileList() {
        SummaryFileWithAttributes summaryFile = new SummaryFileWithAttributes();
        SummaryFileWithAttributes.Files file1 = new SummaryFileWithAttributes.Files();
        file1.status = "Processed";
        file1.value = "file1.txt";

        SummaryFileWithAttributes.Files file2 = new SummaryFileWithAttributes.Files();
        file2.status = "Pending";
        file2.value = "file2.txt";

        List<SummaryFileWithAttributes.Files> fileList = Arrays.asList(file1, file2);
        summaryFile.setFileList(fileList);
        assertEquals(fileList, summaryFile.getFileList());
    }

    @Test
    public void testGetFileListAsStringNames() {
        SummaryFileWithAttributes summaryFile = new SummaryFileWithAttributes();
        SummaryFileWithAttributes.Files file1 = new SummaryFileWithAttributes.Files();
        file1.status = "Processed";
        file1.value = "file1.txt";

        SummaryFileWithAttributes.Files file2 = new SummaryFileWithAttributes.Files();
        file2.status = "Pending";
        file2.value = "file2.txt";

        List<SummaryFileWithAttributes.Files> fileList = Arrays.asList(file1, file2);
        summaryFile.setFileList(fileList);

        List<String> expectedFileNames = Arrays.asList("file1.txt", "file2.txt");
        assertEquals(expectedFileNames, summaryFile.getFileListAsStringNames());
    }
}