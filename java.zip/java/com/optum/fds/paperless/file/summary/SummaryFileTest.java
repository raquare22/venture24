package com.optum.fds.paperless.file.summary;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.List;

public class SummaryFileTest {

    @Test
    public void testGetAndSetBatchId() {
        SummaryFile summaryFile = new SummaryFile();
        String batchId = "12345";
        summaryFile.setBatchId(batchId);
        assertEquals(batchId, summaryFile.getBatchId());
    }

    @Test
    public void testGetAndSetDataGroup() {
        SummaryFile summaryFile = new SummaryFile();
        String dataGroup = "Group1";
        summaryFile.setDataGroup(dataGroup);
        assertEquals(dataGroup, summaryFile.getDataGroup());
    }

    @Test
    public void testGetAndSetCount() {
        SummaryFile summaryFile = new SummaryFile();
        String count = "10";
        summaryFile.setCount(count);
        assertEquals(count, summaryFile.getCount());
    }

    @Test
    public void testGetAndSetFileList() {
        SummaryFile summaryFile = new SummaryFile();
        List<String> fileList = Arrays.asList("file1.txt", "file2.txt");
        summaryFile.setFileList(fileList);
        assertEquals(fileList, summaryFile.getFileList());
    }
}