package com.optum.fds.paperless.file.summary;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorError;
import com.optum.fds.paperless.mongo.processors.ProcessorErrorCode;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.domain.service.ProcessorService;

import com.optum.fds.paperless.util.FileUtil;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.Utilities;


import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import org.junit.jupiter.api.io.TempDir;
import org.mockito.MockedStatic;
import org.springframework.test.util.ReflectionTestUtils;

@RunWith(MockitoJUnitRunner.class)
public class ProcessSummaryTest {

    @Rule
    public TemporaryFolder tempDir = new TemporaryFolder();

    ProcessorService processorService;

    ProcessSummary processSummary;

    private final String XML_MISMATCH_FILE_COUNT = "file.summary/summaryFile-mismatchCount.xml";
    private final String XML_MATCHING_FILE_COUNT = "file.summary/summaryFile-matchingCount.xml";
//    private final String XML_MISMATCH_FILE_COUNT = "file.summary/summaryFile-mismatchCount.xml";


    @Before
    public void setUp() {
        processorService = mock(ProcessorService.class);
        processSummary = new ProcessSummary(processorService);
    }


    @Test
    public void getSummaryFile_noSummary() throws IOException {
        assertThrows(
                java.io.FileNotFoundException.class,
                () -> processSummary.getSummaryFile(tempDir.getRoot().getAbsolutePath())
        );

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);

        try (MockedStatic<Files> mockedFiles = mockStatic(Files.class)) {
            // Arrange: Mock Files.newDirectoryStream to throw an exception
            mockedFiles.when(() -> Files.newDirectoryStream(any(), anyString()))
                    .thenThrow(new RuntimeException("Mocked exception"));

            Exception exception = assertThrows(RuntimeException.class,
                    () -> processSummary.processSummaryFile(txn));
        }}



    @Test
    public void getSummaryFile_oneSummary_missingXMLContent() throws Exception {
//        File summary = tempDir.resolve("one.summary").toFile();
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "one.summary");
        assertTrue(summary.createNewFile());

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.toString());

        processSummary.processSummaryFile(txn);

        //Invalid xml file "one.summary"
        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
    }


    @Test
    public void getSummaryFile_manySummaries_usesFirstWithWarning() throws Exception {
//        File a = tempDir.resolve("a.summary").toFile();
//        File b = tempDir.resolve("b.summary").toFile();
        File a = new File(tempDir.getRoot().getAbsolutePath() + "/a.summary");
        File b = new File(tempDir.getRoot().getAbsolutePath() + "/b.summary");
        assertTrue(a.createNewFile());
        assertTrue(b.createNewFile());
        List<Object> out = processSummary.getSummaryFile(tempDir.getRoot().getAbsolutePath());
        // lexicographically a < b
        assertEquals(a, out.get(0));
        assertTrue(((String) out.get(1)).contains("Using first summary file"));
    }


    @Test
    public void getSummaryFile_summaryXMLHighLevelValidation_missingFiles() throws IOException, URISyntaxException {
//        File summary = tempDir.resolve("one.summary").toFile();
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "/one.summary");
        assertTrue(summary.createNewFile());
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MISMATCH_FILE_COUNT).getAbsolutePath();

        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.getRoot().getAbsolutePath());

        processSummary.processSummaryFile(txn);

        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
        assertNotNull(txn.getSummary().getErrorList().get(0));
    }


    @Test
    public void getSummaryFile_summaryXMLHighLevelValidation_validFiles() throws IOException, URISyntaxException {
//        File summary = tempDir.resolve("one.summary").toFile();
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "/one.summary");
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MATCHING_FILE_COUNT).getAbsolutePath();

        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.getRoot().getAbsolutePath());
        txn.setFileToProcessList(Collections.singletonList("a.pdf"));

        processSummary.processSummaryFile(txn);

        assertEquals(MetaDataStatus.NEW, txn.getStatus());
        assertNull(txn.getSummary().getErrorList());
    }


    @Test
    public void summaryFileCountFieldValidation_badCount_setsFatal() {
        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        HashMap<String,String> msg = new HashMap<>();
        SummaryFileWithAttributes sfa = new SummaryFileWithAttributes();
        sfa.setCount("NaN");
        sfa.setBatchId("B");
        processSummary.summaryFileCountFieldValidation(sfa, txn, msg);
        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertFalse(msg.isEmpty());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
    }


    @Test
    public void testProcessSummaryFile_FileNotFoundException() throws Exception {
        // Arrange
        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation("dummy/location");

        ProcessSummary spyProcessSummary = spy(processSummary);

        doThrow(new FileNotFoundException("No Summary File found"))
                .when(spyProcessSummary).getSummaryFile("dummy/location");

        spyProcessSummary.processSummaryFile(txn);

        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
    }

    @Test
    public void testProcessSummaryFile_IOException() throws Exception {
        // Arrange
        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation("dummy/location");

        ProcessSummary spyProcessSummary = spy(processSummary);

        doThrow(new IOException("No Summary File found"))
                .when(spyProcessSummary).getSummaryFile("dummy/location");

        spyProcessSummary.processSummaryFile(txn);

        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
    }

    @Test
    public void testProcessSummaryFile_SummaryFileParse_JsonParseException() throws Exception {
//        File summary = tempDir.resolve("one.summary").toFile();
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "one.summary");
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MATCHING_FILE_COUNT).getAbsolutePath();

        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.toString());
        txn.setFileToProcessList(Collections.singletonList("a.pdf"));

        ProcessSummary spyProcessSummary = spy(processSummary);

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.parseXMLFile(summary, SummaryFileWithAttributes.class))
                    .thenThrow(new JsonParseException(null, "Error parsing JSON"));

        spyProcessSummary.processSummaryFile(txn);

        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
        }
    }

    @Test
    public void testProcessSummaryFile_SummaryFileParse_JsonMappingException() throws Exception {
//        File summary = tempDir.resolve("one.summary").toFile();
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "one.summary");
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MATCHING_FILE_COUNT).getAbsolutePath();

        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.toString());
        txn.setFileToProcessList(Collections.singletonList("a.pdf"));

        ProcessSummary spyProcessSummary = spy(processSummary);

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.parseXMLFile(summary, SummaryFileWithAttributes.class))
                    .thenThrow(new JsonMappingException(null, "Error parsing JSON"));

        spyProcessSummary.processSummaryFile(txn);

        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
        }
    }

    @Test
    public void testProcessSummaryFile_SummaryFileParse_IOException() throws Exception {
//        File summary = tempDir.resolve("one.summary").toFile();
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "one.summary");
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MATCHING_FILE_COUNT).getAbsolutePath();

        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.toString());
        txn.setFileToProcessList(Collections.singletonList("a.pdf"));

        ProcessSummary spyProcessSummary = spy(processSummary);

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.parseXMLFile(summary, SummaryFileWithAttributes.class))
                    .thenThrow(new IOException("Error parsing JSON"));
        spyProcessSummary.processSummaryFile(txn);

        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
        }
    }


    @Test
    public void summaryFileValidationTest_throwException() throws URISyntaxException, IOException {
//        File summary = tempDir.resolve("one.summary").toFile();
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "one.summary");
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MATCHING_FILE_COUNT).getAbsolutePath();

        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.toString());
        txn.setFileToProcessList(Collections.singletonList("a.pdf"));

        try (MockedStatic<FileUtil> mockedFileUtil = mockStatic(FileUtil.class)) {
            // Mock FileUtil.getFilesByExtension to throw an exception
            FileUtil mockFileUtil = mock(FileUtil.class);
            mockedFileUtil.when(FileUtil::getInstance).thenReturn(mockFileUtil);

            // Mock getLocalHostName or any other required methods
            when(mockFileUtil.getLocalHostName()).thenReturn("mocked-host");

            mockedFileUtil.when(() -> FileUtil.getFilesByExtension(any(), any(Path.class)))
                    .thenThrow(new RuntimeException("Mocked exception"));

            processSummary.processSummaryFile(txn);
        }
    }

    @Test
    public void extraFileTest() throws URISyntaxException, IOException {
//        File summary = tempDir.resolve("one.summary").toFile();
//        File extraPdf = tempDir.resolve("one.pdf").toFile();

        File summary = new File(tempDir.getRoot().getAbsolutePath() + "one.summary");
        File extraPdf = new File(tempDir.getRoot().getAbsolutePath() + "one.pdf");

        boolean isFileCreated = extraPdf.createNewFile();
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MATCHING_FILE_COUNT).getAbsolutePath();

        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.toString());
        txn.setFileToProcessList(Collections.singletonList("a.pdf"));

        processSummary.processSummaryFile(txn);
    }

    @Test
    public void testProcessSummaryFile_ParseSummary_JsonParseException_SetsFatalAndErrorCode() throws Exception {
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "/one.summary");
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MATCHING_FILE_COUNT).getAbsolutePath();
        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.getRoot().getAbsolutePath());
        txn.setFileToProcessList(Collections.singletonList("a.pdf"));

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.parseXMLFile(any(File.class), eq(SummaryFileWithAttributes.class)))
                    .thenThrow(new JsonParseException(null, "parse error"));

            processSummary.processSummaryFile(txn);
        }

        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertNotNull(txn.getSummary());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
        assertEquals(ProcessorErrorCode.FILE_COULD_NOT_BE_PARSED.getErrorCode(),
                txn.getSummary().getErrorList().get(0).getErrorCode());
    }

    @Test
    public void testProcessSummaryFile_ParseSummary_JsonMappingException_SetsFatalAndErrorCode() throws Exception {
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "/one.summary");
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MATCHING_FILE_COUNT).getAbsolutePath();
        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.getRoot().getAbsolutePath());
        txn.setFileToProcessList(Collections.singletonList("a.pdf"));

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.parseXMLFile(any(File.class), eq(SummaryFileWithAttributes.class)))
                    .thenThrow(new JsonMappingException(null, "mapping error"));

            processSummary.processSummaryFile(txn);
        }

        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertNotNull(txn.getSummary());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
        assertEquals(ProcessorErrorCode.XML_COULD_NOT_BE_MAPPED_IN_SUMMARY.getErrorCode(),
                txn.getSummary().getErrorList().get(0).getErrorCode());
    }

    @Test
    public void testProcessSummaryFile_ParseSummary_IOException_SetsFatalAndErrorCode() throws Exception {
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "/one.summary");
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MATCHING_FILE_COUNT).getAbsolutePath();
        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.getRoot().getAbsolutePath());
        txn.setFileToProcessList(Collections.singletonList("a.pdf"));

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            mockedParser.when(() -> Parser.parseXMLFile(any(File.class), eq(SummaryFileWithAttributes.class)))
                    .thenThrow(new IOException("io error"));

            processSummary.processSummaryFile(txn);
        }

        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertNotNull(txn.getSummary());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
        assertEquals(ProcessorErrorCode.UNKNOWN_ERROR_READING_FILE.getErrorCode(),
                txn.getSummary().getErrorList().get(0).getErrorCode());
    }

    @Test
    public void testProcessSummaryFile_HighLevelValidationFails_SetsFatalAndReturns() throws Exception {
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "/one.summary");
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MATCHING_FILE_COUNT).getAbsolutePath();
        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.getRoot().getAbsolutePath());
        // force summaryXMLHighLevelValidation\(\) failure: fileList null/empty
        txn.setFileToProcessList(Collections.emptyList());

        try (MockedStatic<Parser> mockedParser = mockStatic(Parser.class)) {
            SummaryFileWithAttributes sfa = new SummaryFileWithAttributes();
            sfa.setBatchId("B1");
            sfa.setCount("1");
            sfa.setDataGroup("DG");
            sfa.setFileList(null); // causes XML_MISSING_FILES_TO_PROCESS in high-level validation

            mockedParser.when(() -> Parser.parseXMLFile(any(File.class), eq(SummaryFileWithAttributes.class)))
                    .thenReturn(sfa);

            processSummary.processSummaryFile(txn);
        }

        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertNotNull(txn.getSummary());
        assertNotNull(txn.getSummary().getErrorList());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
        assertEquals(
                Integer.valueOf(ProcessorErrorCode.XML_MISSING_FILES_TO_PROCESS.getErrorCode()),
                txn.getSummary().getErrorList().get(0).getErrorCode()
        );
        // returned before summaryFileValidation adds files to process
        assertTrue(txn.getFileToProcessList() == null || txn.getFileToProcessList().isEmpty());
    }

    @Test
    public void testSummaryXMLHighLevelValidation_WhenFileListMissing_ReturnsFalseWithExpectedError() {
        SummaryFile summaryXML = new SummaryFile();
        summaryXML.setBatchId("B1");
        summaryXML.setCount("1");
        summaryXML.setDataGroup("DG");
        summaryXML.setFileList(null); // triggers selected branch

        List outcome = processSummary.summaryXMLHighLevelValidation(summaryXML);

        assertNotNull(outcome);
        assertFalse((Boolean) outcome.get(0));

        @SuppressWarnings("unchecked")
        HashMap<String, String> message = (HashMap<String, String>) outcome.get(1);
        assertNotNull(message);
        assertEquals("XML missing Files Node", message.get("outcome"));

        ProcessorError error = (ProcessorError) outcome.get(2);
        assertNotNull(error);
        assertEquals(
                Integer.valueOf(ProcessorErrorCode.XML_MISSING_FILES_TO_PROCESS.getErrorCode()),
                error.getErrorCode()
        );
    }

    @Test
    public void testSummaryFileValidation_MetadataLookupFails_EarlyReturnSetsFatal() throws Exception {
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "/one.summary");
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MATCHING_FILE_COUNT).getAbsolutePath();
        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.getRoot().getAbsolutePath());
        txn.setFileToProcessList(Collections.singletonList("a.pdf"));

        try (MockedStatic<FileUtil> mockedFileUtil = mockStatic(FileUtil.class)) {
            FileUtil fileUtilMock = mock(FileUtil.class);
            mockedFileUtil.when(FileUtil::getInstance).thenReturn(fileUtilMock);

            // Force getMetadataFiles\(\) catch branch -> status becomes FATAL_ERROR
            mockedFileUtil.when(() -> FileUtil.getFilesByExtension(anyString(), any(Path.class)))
                    .thenThrow(new RuntimeException("metadata read failure"));

            processSummary.processSummaryFile(txn);
        }

        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertNotNull(txn.getSummary());
        assertNotNull(txn.getSummary().getErrorList());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
        assertEquals(
                Integer.valueOf(ProcessorErrorCode.UNKNOWN_ERROR_READING_FILE.getErrorCode()),
                txn.getSummary().getErrorList().get(0).getErrorCode()
        );
    }

    @Test
    public void testSummaryFileValidation_GetFilesAtLocationFails_EarlyReturnSetsFatal() throws Exception {
        File summary = new File(tempDir.getRoot().getAbsolutePath() + "/one.summary");
        String xmlFile = Utilities.getInstance().getResourceFile(XML_MATCHING_FILE_COUNT).getAbsolutePath();
        Files.copy(Path.of(xmlFile), summary.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        ProcessorTransaction txn = new ProcessorTransaction();
        txn.setStatus(MetaDataStatus.NEW);
        txn.setConfigSpaceId(123);
        txn.setLocation(tempDir.getRoot().getAbsolutePath());
        txn.setFileToProcessList(Collections.singletonList("a.pdf"));

        try (MockedStatic<FileUtil> mockedFileUtil = mockStatic(FileUtil.class);
             MockedStatic<Files> mockedFiles = mockStatic(Files.class, Mockito.CALLS_REAL_METHODS)) {

            FileUtil fileUtilMock = mock(FileUtil.class);
            mockedFileUtil.when(FileUtil::getInstance).thenReturn(fileUtilMock);

            // Let metadata lookup succeed so code reaches getFilesAtLocation\(\)
            mockedFileUtil.when(() -> FileUtil.getFilesByExtension(anyString(), any(Path.class)))
                    .thenReturn(Collections.emptyList());

            // Force getFilesAtLocation\(\) catch branch -> status FATAL -> selected return path
            mockedFiles.when(() -> Files.list(any(Path.class)))
                    .thenThrow(new RuntimeException("list failure"));

            processSummary.processSummaryFile(txn);
        }

        assertEquals(MetaDataStatus.FATAL_ERROR, txn.getStatus());
        assertNotNull(txn.getSummary());
        assertNotNull(txn.getSummary().getErrorList());
        assertFalse(txn.getSummary().getErrorList().isEmpty());
        assertEquals(
                Integer.valueOf(ProcessorErrorCode.UNKNOWN_ERROR_READING_FILE.getErrorCode()),
                txn.getSummary().getErrorList().get(0).getErrorCode()
        );
    }

    @Test
    public void processSummaryFile_shouldReturnImmediately_whenTransactionStatusIsFatalError() {
        ProcessorService processorService = Mockito.mock(ProcessorService.class);
        ProcessSummary processSummary = new ProcessSummary(processorService);

        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);

        processSummary.processSummaryFile(processorTransaction);

        verifyNoInteractions(processorService);
    }

    @Test
    public void checkIfFileIsMetadataAndHasCorrespondingFile_shouldAddMessageAndMarkMissingAndExtra_whenNoMatchingFileExists()
            throws Exception {

        String fileName = "batch1.metadata";
        String metadataExtension = "metadata";
        List<String> filesAtLocation = Arrays.asList("batch1.metadata");

        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();
        ProcessorTransaction processorTransaction = spy(new ProcessorTransaction());

        Method method = ProcessSummary.class.getDeclaredMethod(
                "checkIfFileIsMetadataAndHasCorrespondingFile",
                String.class,
                String.class,
                List.class,
                ProcessorExecutionRecord.class,
                ProcessorTransaction.class
        );
        method.setAccessible(true);

        method.invoke(null, fileName, metadataExtension, filesAtLocation, executionRecord, processorTransaction);

        verify(processorTransaction).addMissingFile(fileName);
        verify(processorTransaction).addExtraFile(fileName);

        assertNotNull(executionRecord.getMessageList());
        assertEquals(1, executionRecord.getMessageList().size());

        Map<String, String> message = executionRecord.getMessageList().get(0);
        assertEquals("Metadata File did not have corresponding file.", message.get("outcome"));
        assertEquals("No file found for metadata file " + fileName, message.get("error"));
    }

    @Test
    public void checkIfFileIsMetadataAndHasCorrespondingFile_shouldDoNothing_whenMatchingFileExists()
            throws Exception {

        String fileName = "batch1.metadata";
        String metadataExtension = "metadata";
        List<String> filesAtLocation = Arrays.asList("batch1.metadata", "batch1.pdf");

        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();
        ProcessorTransaction processorTransaction = spy(new ProcessorTransaction());

        Method method = ProcessSummary.class.getDeclaredMethod(
                "checkIfFileIsMetadataAndHasCorrespondingFile",
                String.class,
                String.class,
                List.class,
                ProcessorExecutionRecord.class,
                ProcessorTransaction.class
        );
        method.setAccessible(true);

        method.invoke(null, fileName, metadataExtension, filesAtLocation, executionRecord, processorTransaction);

        verify(processorTransaction, never()).addMissingFile(anyString());
        verify(processorTransaction, never()).addExtraFile(anyString());
        assertTrue(executionRecord.getMessageList() == null || executionRecord.getMessageList().isEmpty());
    }

    @Test
    public void checkIfFilesWereMissing_shouldAddMetadataAndExtraFileErrors() throws Exception {
        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.addMissingFile("orphan.metadata");
        processorTransaction.addMissingFile("missing.pdf");
        processorTransaction.addMissingFile("ignored.txt");
        processorTransaction.addMissingFile(".nfs0001");

        Method method = ProcessSummary.class.getDeclaredMethod(
                "checkIfFilesWereMissing",
                ProcessorTransaction.class,
                String.class
        );
        method.setAccessible(true);

        method.invoke(null, processorTransaction, "metadata");

        assertNotNull(processorTransaction.getSummary());
        assertNotNull(processorTransaction.getSummary().getErrorList());
        assertEquals(2, processorTransaction.getSummary().getErrorList().size());

        ProcessorError metadataError = processorTransaction.getSummary().getErrorList().get(0);
        ProcessorError extraFileError = processorTransaction.getSummary().getErrorList().get(1);

        assertEquals(
                Integer.valueOf(ProcessorErrorCode.EXTRA_METADATA_FILE_FOUND.getErrorCode()),
                metadataError.getErrorCode()
        );

        assertEquals(
                Integer.valueOf(ProcessorErrorCode.EXTRA_FILE_FOUND_WITH_NO_METADATA.getErrorCode()),
                extraFileError.getErrorCode()
        );
        assertEquals("missing.pdf", extraFileError.getFileName());
    }

    @Test
    public void checkIfFilesWereMissing_shouldNotAddErrorsForOnlyIgnoredFiles() throws Exception {
        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.addMissingFile("ignored.txt");
        processorTransaction.addMissingFile(".nfsABC");

        Method method = ProcessSummary.class.getDeclaredMethod(
                "checkIfFilesWereMissing",
                ProcessorTransaction.class,
                String.class
        );
        method.setAccessible(true);

        method.invoke(null, processorTransaction, "metadata");

        assertTrue(
                processorTransaction.getSummary().getErrorList() == null
                        || processorTransaction.getSummary().getErrorList().isEmpty()
        );
    }

    @Test
    public void cycleThroughZipFiles_shouldAddFileToProcess_whenFileIsListedAndMetadataExists() {
        ProcessSummary processSummary = new ProcessSummary(mock(ProcessorService.class));
        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();

        List<String> files = Collections.singletonList("doc1.pdf");
        List<String> metadataFiles = Collections.singletonList("doc1.metadata");
        List<String> filesAtContentLocation = Collections.singletonList("doc1.pdf");

        ReflectionTestUtils.invokeMethod(
                processSummary,
                "cycleThroughZipFiles",
                processorTransaction,
                "metadata",
                executionRecord,
                files,
                metadataFiles,
                filesAtContentLocation
        );

        assertNotNull(processorTransaction.getFileToProcessList());
        assertEquals(1, processorTransaction.getFileToProcessList().size());
        assertEquals("doc1.pdf", processorTransaction.getFileToProcessList().get(0));

        assertNull(processorTransaction.getExtraFileList());
        assertNull(processorTransaction.getSummary().getErrorList());
    }

    @Test
    public void cycleThroughZipFiles_shouldAddMismatchError_whenExtraFileAlsoHasMetadata() {
        ProcessSummary processSummary = new ProcessSummary(mock(ProcessorService.class));
        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();

        List<String> files = Collections.singletonList("listed.pdf");
        List<String> metadataFiles = Collections.singletonList("extra.metadata");
        List<String> filesAtContentLocation = Collections.singletonList("extra.pdf");

        ReflectionTestUtils.invokeMethod(
                processSummary,
                "cycleThroughZipFiles",
                processorTransaction,
                "metadata",
                executionRecord,
                files,
                metadataFiles,
                filesAtContentLocation
        );

        assertNotNull(processorTransaction.getExtraFileList());
        assertEquals(1, processorTransaction.getExtraFileList().size());
        assertEquals("extra.pdf", processorTransaction.getExtraFileList().get(0));

        assertNotNull(processorTransaction.getFileToProcessList());
        assertEquals(1, processorTransaction.getFileToProcessList().size());
        assertEquals("extra.pdf", processorTransaction.getFileToProcessList().get(0));

        List<ProcessorError> errors = processorTransaction.getSummary().getErrorList();
        assertNotNull(errors);
        assertEquals(1, errors.size());
        assertEquals(
                ProcessorErrorCode.PDF_FILE_NAME_MISMATCH.getErrorCode(),
                errors.get(0).getErrorCode()
        );
    }

    @Test
    public void cycleThroughZipFiles_shouldNotAddFileToProcess_whenMetadataDoesNotExist() {
        ProcessSummary processSummary = new ProcessSummary(mock(ProcessorService.class));
        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();

        List<String> files = Collections.singletonList("doc2.pdf");
        List<String> metadataFiles = Collections.emptyList();
        List<String> filesAtContentLocation = Collections.singletonList("doc2.pdf");

        ReflectionTestUtils.invokeMethod(
                processSummary,
                "cycleThroughZipFiles",
                processorTransaction,
                "metadata",
                executionRecord,
                files,
                metadataFiles,
                filesAtContentLocation
        );

        assertNull(processorTransaction.getFileToProcessList());

        assertNotNull(processorTransaction.getMissingFileList());
        assertEquals(1, processorTransaction.getMissingFileList().size());
        assertEquals("doc2.pdf", processorTransaction.getMissingFileList().get(0));

        assertNull(processorTransaction.getSummary().getErrorList());
    }

    @Test
    public void fileInList_shouldReturnTrue_whenFileExistsInList() throws Exception {
        List<String> files = Arrays.asList("doc1.pdf", "doc2.pdf");
        String fileName = "doc1.pdf";
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();
        ProcessorTransaction processorTransaction = new ProcessorTransaction();

        Method method = ProcessSummary.class.getDeclaredMethod(
                "fileInList",
                List.class,
                String.class,
                ProcessorExecutionRecord.class,
                ProcessorTransaction.class
        );
        method.setAccessible(true);

        boolean result = (boolean) method.invoke(null, files, fileName, executionRecord, processorTransaction);

        assertTrue(result);
        assertTrue(processorTransaction.getExtraFileList() == null || processorTransaction.getExtraFileList().isEmpty());
        assertTrue(executionRecord.getMessageList() == null || executionRecord.getMessageList().isEmpty());
    }

    @Test
    public void fileInList_shouldReturnFalse_andAddMessageAndExtraFile_whenFileDoesNotExistInList() throws Exception {
        List<String> files = Arrays.asList("doc1.pdf", "doc2.pdf");
        String fileName = "missing.pdf";
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();
        ProcessorTransaction processorTransaction = new ProcessorTransaction();

        Method method = ProcessSummary.class.getDeclaredMethod(
                "fileInList",
                List.class,
                String.class,
                ProcessorExecutionRecord.class,
                ProcessorTransaction.class
        );
        method.setAccessible(true);

        boolean result = (boolean) method.invoke(null, files, fileName, executionRecord, processorTransaction);

        assertFalse(result);

        assertNotNull(processorTransaction.getExtraFileList());
        assertEquals(1, processorTransaction.getExtraFileList().size());
        assertEquals("missing.pdf", processorTransaction.getExtraFileList().get(0));

        assertNotNull(executionRecord.getMessageList());
        assertEquals(1, executionRecord.getMessageList().size());
        assertEquals("File was not specified in XML.", executionRecord.getMessageList().get(0).get("outcome"));
        assertEquals("File: missing.pdf", executionRecord.getMessageList().get(0).get("error"));
    }

    private boolean invokeHasMetadataFile(
            String fileName,
            String metadataExtension,
            List<String> metadataFiles,
            ProcessorExecutionRecord executionRecord,
            ProcessorTransaction processorTransaction) throws Exception {

        Method method = ProcessSummary.class.getDeclaredMethod(
                "hasMetadataFile",
                String.class,
                String.class,
                List.class,
                ProcessorExecutionRecord.class,
                ProcessorTransaction.class
        );
        method.setAccessible(true);

        return (Boolean) method.invoke(
                null,
                fileName,
                metadataExtension,
                metadataFiles,
                executionRecord,
                processorTransaction
        );
    }

    @Test
    public void hasMetadataFile_shouldReturnTrue_whenMatchingMetadataFileExists() throws Exception {
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();
        ProcessorTransaction processorTransaction = new ProcessorTransaction();

        List<String> metadataFiles = Arrays.asList("document1.metadata");

        boolean result = invokeHasMetadataFile(
                "document1.pdf",
                "metadata",
                metadataFiles,
                executionRecord,
                processorTransaction
        );

        assertTrue(result);
        assertTrue(
                processorTransaction.getMissingFileList() == null
                        || processorTransaction.getMissingFileList().isEmpty()
        );
    }

    @Test
    public void hasMetadataFile_shouldReturnFalse_andAddMissingFile_whenMatchingMetadataFileDoesNotExist() throws Exception {
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();
        ProcessorTransaction processorTransaction = new ProcessorTransaction();

        List<String> metadataFiles = new ArrayList<>();

        boolean result = invokeHasMetadataFile(
                "document2.pdf",
                "metadata",
                metadataFiles,
                executionRecord,
                processorTransaction
        );

        assertFalse(result);
        assertNotNull(processorTransaction.getMissingFileList());
        assertTrue(processorTransaction.getMissingFileList().contains("document2.pdf"));
    }

}
            // Assert
//            assertTrue(result.isEmpty());
//            assertEquals(MetaDataStatus.FATAL_ERROR, mockTransaction.getStatus());
//            assertFalse(mockTransaction.getSummary().getErrorList().isEmpty());

//    }


//    @Test
//    void fileInList_missing() {
//        ProcessorTransaction txn = new ProcessorTransaction();
//        ProcessorExecutionRecord rec = new ProcessorExecutionRecord();
//        boolean in = processSummary.fileInList(List.of("x"), "y", rec, txn);
//        assertFalse(in);
//        assertTrue(txn.getExtraFileList().contains("y"));
//    }
//
//
////    @Test
//    void fileInList_present() {
//        ProcessorTransaction txn = new ProcessorTransaction();
//        ProcessorExecutionRecord rec = new ProcessorExecutionRecord();
//        boolean in = processSummary.fileInList(List.of("y"), "y", rec, txn);
//        assertTrue(in);
//        assertTrue(txn.getExtraFileList().isEmpty());
//    }
//
//
//    @Test
//    void hasMetadataFile_missing() {
//        ProcessorTransaction txn = new ProcessorTransaction();
//        ProcessorExecutionRecord rec = new ProcessorExecutionRecord();
//        boolean ok = processSummary.hasMetadataFile("f.pdf", "metadata", List.of(), rec, txn);
//        assertFalse(ok);
//        assertTrue(txn.getMissingFileList().contains("f.pdf"));
//    }
//
    //
    // hasMetadataFile(): present → true
    //
//    @Test
//    void hasMetadataFile_present() {
//        ProcessorTransaction txn = new ProcessorTransaction();
//        ProcessorExecutionRecord rec = new ProcessorExecutionRecord();
//        String meta = "f.metadata";
//        boolean ok = processSummary.hasMetadataFile("f.pdf", "metadata", List.of(meta), rec, txn);
//        assertTrue(ok);
//    }
//
    //
    // checkIfFileIsMetadataAndHasCorrespondingFile(): metadata with no file
    //
//
////    @Test
//    void checkIfFileIsMetadataAndHasCorrespondingFile_metadataOnly() {
//        ProcessorTransaction txn = new ProcessorTransaction();
//        ProcessorExecutionRecord rec = new ProcessorExecutionRecord();
//        // create a stray metadata
//        processSummary.checkIfFileIsMetadataAndHasCorrespondingFile("a.metadata", "metadata", List.of("a.metadata"), rec, txn);
//        assertTrue(txn.getMissingFileList().contains("a.metadata"));
//        assertTrue(txn.getExtraFileList().contains("a.metadata"));
//    }

    //
    // checkIfFilesWereMissing(): various
    //
//    @Test
//    void checkIfFilesWereMissing_extraPdfAndMetadataErrors() {
//        ProcessorTransaction txn = new ProcessorTransaction();
//        txn.addMissingFile("e.pdf");
//        txn.addMissingFile("x.metadata");
//        processSummary.checkIfFilesWereMissing(txn, "metadata");
//        // one extra metadata and one extra pdf error
//        assertFalse(txn.getSummary().getErrorList().isEmpty());
//    }
//
//
    // summaryFileValidation end-to-end:
    //   create files: a.pdf + a.metadata, b.pdf(no metadata), stray.metadata
    //
//    @Test

    //
    // convertSummaryFileWithAttributesToSummaryFile()
    //
//    @Test
//    void convertSummaryFileWithAttributesToSummaryFile_setsAll() {
//        SummaryFileWithAttributes sfa = new SummaryFileWithAttributes();
//        sfa.setBatchId("B");
//        sfa.setCount("3");
//        sfa.setDataGroup("DG");
//        sfa.setFileList(List.of());
//        SummaryFile out = new SummaryFile();
//        processSummary.convertSummaryFileWithAttributesToSummaryFile(out, sfa);
//        assertEquals("B", out.getBatchId());
//        assertEquals("3", out.getCount());
//        assertEquals("DG", out.getDataGroup());
//        assertEquals(List.of("x","y"), out.getFileList());
//    }
//            }
