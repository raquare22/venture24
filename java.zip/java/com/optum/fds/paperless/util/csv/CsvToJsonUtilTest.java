package com.optum.fds.paperless.util.csv;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.mongo.executions.UnprocessedRecord;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.TemplateHandler;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class CsvToJsonUtilTest {

    @InjectMocks
    private CsvToJsonUtil csvToJsonUtil;

    @Mock
    private TemplateFactory templateFactory;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testConvertCsvToJson_IOException() throws IOException, FSDataException {
        String locationDirectory = "src/test/resources";
        String csvFileName = "nonexistent.csv";
        char delimit = ',';
        int strictJsonFlag = 1;
        List<UnprocessedRecord> unprocessedRecords = new ArrayList<>();

        assertThrows(RuntimeException.class, () -> {
            csvToJsonUtil.convertCsvToJson(locationDirectory, csvFileName, delimit, strictJsonFlag, unprocessedRecords);
        });
    }

    @Test
    public void testWritetoFileUsingTemplate_IOException() throws IOException, FSDataException {
        String outputFileName = "invalid/output.json";
        String jsonFile = "{\"key\":\"value\"}";
        String startOrEnd = "start";
        int strictJsonFlag = 1;

        assertThrows(IOException.class, () -> {
            csvToJsonUtil.writetoFileUsingTemplate(outputFileName, jsonFile, startOrEnd, strictJsonFlag);
        });
    }

    @Test
    public void testCreateJsonFileName() {
        String locationDirectory = "src/test/resources";
        String csvFileName = "testFile.csv";

        // Test for STRICT_JSON_YES
        int strictJsonFlagYes = 1;
        String expectedJsonFileNameYes = "src/test/resources/testFile.json";
        String actualJsonFileNameYes = csvToJsonUtil.createJsonFileName(locationDirectory, csvFileName, strictJsonFlagYes);
        assertEquals(expectedJsonFileNameYes, actualJsonFileNameYes);

        // Test for STRICT_JSON_NO
        int strictJsonFlagNo = 0;
        String expectedJsonFileNameNo = "src/test/resources/testFile_json.txt";
        String actualJsonFileNameNo = csvToJsonUtil.createJsonFileName(locationDirectory, csvFileName, strictJsonFlagNo);
        assertEquals(expectedJsonFileNameNo, actualJsonFileNameNo);
    }
    @Test
    public void testSetTemplateName() {
        String templateName = "TestTemplate";
        csvToJsonUtil.setTemplateName(templateName);

        // Use reflection to access the private field and verify its value
        try {
            java.lang.reflect.Field field = CsvToJsonUtil.class.getDeclaredField("templateName");
            field.setAccessible(true);
            String actualTemplateName = (String) field.get(csvToJsonUtil);
            assertEquals(templateName, actualTemplateName);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Reflection failed: " + e.getMessage());
        }
    }

    @Test
    public void testWritetoFileUsingTemplate_ValidInput() throws IOException, FSDataException {
        String outputFileName = "src/test/resources/test_output.json"; // Changed file name
        String jsonFile = "{\"key\":\"value\"}";
        String startOrEnd = "start";
        int strictJsonFlag = 1;

        // Mock the behavior of the method
        CsvToJsonUtil mockCsvToJsonUtil = mock(CsvToJsonUtil.class);
        doNothing().when(mockCsvToJsonUtil).writetoFileUsingTemplate(outputFileName, jsonFile, startOrEnd, strictJsonFlag);

        // Call the mocked method
        mockCsvToJsonUtil.writetoFileUsingTemplate(outputFileName, jsonFile, startOrEnd, strictJsonFlag);

        // Verify the method was called with the correct parameters
        verify(mockCsvToJsonUtil, times(1)).writetoFileUsingTemplate(outputFileName, jsonFile, startOrEnd, strictJsonFlag);
    }

    @Test
    public void testWritetoFileUsingTemplate_whenStartOfFileAndStrictJsonYes_shouldWriteOpeningBracket() throws Exception {
        java.nio.file.Path outputFile = java.nio.file.Files.createTempFile("csv-to-json-", ".json");
        try {
            csvToJsonUtil.writetoFileUsingTemplate(
                    outputFile.toString(),
                    null,
                    "start",
                    1
            );

            String content = java.nio.file.Files.readString(outputFile, java.nio.charset.StandardCharsets.UTF_8);

            assertTrue(content.startsWith("["));
            assertEquals("[,", content);
        } finally {
            java.nio.file.Files.deleteIfExists(outputFile);
        }
    }

    @Test
    public void testWritetoFileUsingTemplate_whenTemplateNameEmptyAndStrictJsonYesNotEnd_shouldUseDefaultTemplateWriteProcessedJsonAndComma() throws Exception {
        java.nio.file.Path outputFile = java.nio.file.Files.createTempFile("csv-json-", ".json");
        TemplateHandler templateHandler = mock(TemplateHandler.class);

        when(templateHandler.convertWithTemplate("input-file.json"))
                .thenReturn("{\"id\":\"123\",\"emptyField\":\"\"}");

        try (org.mockito.MockedStatic<TemplateFactory> templateFactoryMock = mockStatic(TemplateFactory.class)) {
            templateFactoryMock.when(() -> TemplateFactory.getInstance("CosmosPRACompanion"))
                    .thenReturn(templateHandler);

            csvToJsonUtil.writetoFileUsingTemplate(
                    outputFile.toString(),
                    "input-file.json",
                    "NA",
                    1
            );

            String content = java.nio.file.Files.readString(outputFile, java.nio.charset.StandardCharsets.UTF_8);

            assertEquals("{\"id\":\"123\"},", content);
            verify(templateHandler).convertWithTemplate("input-file.json");
            templateFactoryMock.verify(() -> TemplateFactory.getInstance("CosmosPRACompanion"));
        } finally {
            java.nio.file.Files.deleteIfExists(outputFile);
        }
    }

    @Test
    public void testWritetoFileUsingTemplate_whenTemplateNameProvided_shouldWriteProcessedJsonAndNewLineForStrictJsonNo() throws Exception {
        java.nio.file.Path outputFile = java.nio.file.Files.createTempFile("csv-json-", ".txt");
        TemplateHandler templateHandler = mock(TemplateHandler.class);
        csvToJsonUtil.setTemplateName("TestTemplate");

        when(templateHandler.convertWithTemplate("input-file.json"))
                .thenReturn("{\"name\":\"alpha\",\"blank\":\"\"}");

        try (org.mockito.MockedStatic<TemplateFactory> templateFactoryMock = mockStatic(TemplateFactory.class)) {
            templateFactoryMock.when(() -> TemplateFactory.getInstance("TestTemplate"))
                    .thenReturn(templateHandler);

            csvToJsonUtil.writetoFileUsingTemplate(
                    outputFile.toString(),
                    "input-file.json",
                    "NA",
                    0
            );

            String content = java.nio.file.Files.readString(outputFile, java.nio.charset.StandardCharsets.UTF_8);

            assertEquals("{\"name\":\"alpha\"}\n", content);
            verify(templateHandler).convertWithTemplate("input-file.json");
            templateFactoryMock.verify(() -> TemplateFactory.getInstance("TestTemplate"));
        } finally {
            java.nio.file.Files.deleteIfExists(outputFile);
        }
    }

    @Test
    public void testWritetoFileUsingTemplate_whenStrictJsonYesAndEndOfFile_shouldWriteClosingBracket() throws Exception {
        java.nio.file.Path outputFile = java.nio.file.Files.createTempFile("csv-json-", ".json");
        TemplateHandler templateHandler = mock(TemplateHandler.class);
        csvToJsonUtil.setTemplateName("TestTemplate");

        when(templateHandler.convertWithTemplate("input-file.json"))
                .thenReturn("{\"name\":\"omega\"}");

        try (org.mockito.MockedStatic<TemplateFactory> templateFactoryMock = mockStatic(TemplateFactory.class)) {
            templateFactoryMock.when(() -> TemplateFactory.getInstance("TestTemplate"))
                    .thenReturn(templateHandler);

            csvToJsonUtil.writetoFileUsingTemplate(
                    outputFile.toString(),
                    "input-file.json",
                    "end",
                    1
            );

            String content = java.nio.file.Files.readString(outputFile, java.nio.charset.StandardCharsets.UTF_8);

            assertEquals("{\"name\":\"omega\"}]", content);
            verify(templateHandler).convertWithTemplate("input-file.json");
        } finally {
            java.nio.file.Files.deleteIfExists(outputFile);
        }
    }

    @Test
    public void testCreateJsonFileName_whenStrictJsonFlagIsNo_shouldAppendJsonTxtSuffix() {
        String result = csvToJsonUtil.createJsonFileName("src/test/resources", "sample.csv", 0);

        assertEquals("src/test/resources/sample_json.txt", result);
    }
}