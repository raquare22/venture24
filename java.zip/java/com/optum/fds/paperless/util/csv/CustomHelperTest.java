package com.optum.fds.paperless.util.csv;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;

import com.github.jknack.handlebars.Options;

public class CustomHelperTest {

    private CustomHelper customHelper;
    private Options options;

    @Before
    public void setUp() {
        customHelper = new CustomHelper();
        options = mock(Options.class);
    }

    @Test
    public void testApply_ValueIsEmpty() throws IOException {
        when(options.param(0, "")).thenReturn("default");

        CharSequence result = customHelper.apply(null, options);
        assertEquals("default", result);
    }

    @Test
    public void testApply_ValueIsNotEmpty() throws IOException {
        CharSequence result = customHelper.apply("value", options);
        assertEquals("value", result);
    }
}