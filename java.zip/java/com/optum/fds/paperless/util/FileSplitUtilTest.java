package com.optum.fds.paperless.util;

import java.util.List;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;

public class FileSplitUtilTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(FileSplitUtilTest.class);

	@Test
	@UserStory(references = "US6701787")
	@RallyTestCase(references = "TC4103992")
	public void testFileSplitUtilSmallFile() throws Exception {
		Configurator.setAllLevels("", Level.INFO);
		var filePath = "src/test/resources/csv/UHC4_AP20231120005124_v4_small.txt";

		int splitPerMbSize = 1;
		int maxBytesNewLineWithin = 1024;
		FileSplitUtil.setBytesSplitMultiple(1024L * 512L);

		List<StringBuilder> splitList = FileSplitUtil.checkAndSplitFile(filePath, splitPerMbSize, maxBytesNewLineWithin);
		LOGGER.info("splitList.size()={}", splitList.size());

		StringBuilder splitListSb = new StringBuilder();
		for (int i = 0; i < splitList.size(); i++) {
			//LOGGER.info("splitList[{}]: \n{}", i, splitList.get(i));
			splitListSb.append(splitList.get(i));
		}
	
		FileSplitUtil.setBytesSplitMultiple(1024L * 128L);
		List<StringBuilder> splitList2 = FileSplitUtil.checkAndSplitFile(filePath, splitPerMbSize, maxBytesNewLineWithin);
		LOGGER.info("splitList2.size()={}", splitList2.size());
		StringBuilder splitListSb2 = new StringBuilder();
		for (int i = 0; i < splitList2.size(); i++) {
			//LOGGER.info("splitList2[{}]: \n{}", i, splitList2.get(i));
			splitListSb2.append(splitList2.get(i));
		}

		Assert.assertTrue(splitListSb.toString().equals(splitListSb2.toString()));
		LOGGER.info("Success compare two small splits: bytesSplitMultiple=1024 * 512 versus 1024 * 128; splitList.size()={}, splitList2.size()={}", splitList.size(), splitList2.size());
	}

	@Test
	@UserStory(references = "US6701787")
	@RallyTestCase(references = "TC4103992")
	public void testFileSplitUtilLargeFile() throws Exception {
		Configurator.setAllLevels("", Level.INFO);
		var filePath = "src/test/resources/csv/UHC4_AP20231120005124_v4.txt";

		int splitPerMbSize = 2;
		int maxBytesNewLineWithin = 1024;

		FileSplitUtil.setBytesSplitMultiple(1024L * 1024L);
		List<StringBuilder> splitList = FileSplitUtil.checkAndSplitFile(filePath, splitPerMbSize, maxBytesNewLineWithin);
		LOGGER.info("splitList.size()={}", splitList.size());

		StringBuilder splitListSb = new StringBuilder();
		for (int i = 0; i < splitList.size(); i++) {
			//LOGGER.info("splitList[{}]: \n{}", i, splitList.get(i));
			splitListSb.append(splitList.get(i));
		}

		splitPerMbSize = 8;
		FileSplitUtil.setBytesSplitMultiple(1024L * 512L);
		List<StringBuilder> splitList2 = FileSplitUtil.checkAndSplitFile(filePath, splitPerMbSize, maxBytesNewLineWithin);
		LOGGER.info("splitList2.size()={}", splitList2.size());
		StringBuilder splitListSb2 = new StringBuilder();
		for (int i = 0; i < splitList2.size(); i++) {
			//LOGGER.info("splitList2[{}]: \n{}", i, splitList2.get(i));
			splitListSb2.append(splitList2.get(i));
		}

		Assert.assertTrue(splitListSb.toString().equals(splitListSb2.toString()));
		LOGGER.info("Success compare two large splits: splitPerMbSize=2MB versus splitPerMbSize=8MB; splitList.size()={}, splitList2.size()={}", splitList.size(), splitList2.size());
	}
}
