package com.optum.fds.paperless.util;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockedStatic;

public class FsCredentialsTest {

    private static final String ENCRYPTED_PASSWORD = "encryptedPassword";
    private static final String DECRYPTED_PASSWORD = "decryptedPassword";

    private MockedStatic<EncryptionUtil> mockedEncryptionUtil;

    @Before
    public void setUp() {
        // Mock the EncryptionUtil.decrypt method
        mockedEncryptionUtil = mockStatic(EncryptionUtil.class);
    }

    @After
    public void tearDown() {
        // Close the static mock to avoid conflicts
        mockedEncryptionUtil.close();
    }

    @Test
    public void testGetPassword_SuccessfulDecryption() throws Exception {
        // Arrange
        mockedEncryptionUtil.when(() -> EncryptionUtil.decrypt(ENCRYPTED_PASSWORD))
                .thenReturn(DECRYPTED_PASSWORD);
        FsCredentials credentials = new FsCredentials("username", ENCRYPTED_PASSWORD);

        // Act
        String password = credentials.getPassword();

        // Assert
        assertEquals(DECRYPTED_PASSWORD, password);
        mockedEncryptionUtil.verify(() -> EncryptionUtil.decrypt(ENCRYPTED_PASSWORD));
    }

    @Test
    public void testGetPassword_DecryptionError() throws Exception {
        // Arrange
        mockedEncryptionUtil.when(() -> EncryptionUtil.decrypt(ENCRYPTED_PASSWORD))
                .thenThrow(new DataLengthException("Decryption error"));
        FsCredentials credentials = new FsCredentials("username", ENCRYPTED_PASSWORD);

        // Act
        String password = credentials.getPassword();

        // Assert
        assertNull(password);
        mockedEncryptionUtil.verify(() -> EncryptionUtil.decrypt(ENCRYPTED_PASSWORD));
    }
}