package com.optum.fds.paperless.util;

import static org.junit.Assert.*;

import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class ApplicationUtilTest {

    @Test
    public void testIsNotNull() {
        assertTrue(ApplicationUtil.isNotNull("Test String"));
        assertFalse(ApplicationUtil.isNotNull(null));
    }

    @Test
    public void testGetServerDate() {
        String serverDate = ApplicationUtil.getServerDate();
        assertNotNull("Server date should not be null", serverDate);

        // Validate the server date format by parsing it
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.ENGLISH);
            sdf.setLenient(false);
            sdf.parse(serverDate); // If parsing fails, the format is incorrect
        } catch (Exception e) {
            fail("Server date should match the expected format: " + e.getMessage());
        }
    }

    @Test
    public void testRerSuccess() {
        ApplicationUtil util = new ApplicationUtil();
        String message = "Operation completed";
        String result = util.rerSuccess(message);
        assertEquals("Operation completed, RERstatus=SUCCESS", result);
    }

    @Test
    public void testRerFailure() {
        ApplicationUtil util = new ApplicationUtil();
        String message = "Operation failed";
        String result = util.rerFailure(message);
        assertEquals("Operation failed, RERstatus=FAILURE", result);
    }

    @Test
    public void testValidateExpiryDate() throws Exception {
        int numOfDays = 30;
        int offset = 5;

        // Dynamically calculate a valid expiry date
        Calendar validExpiryDate = Calendar.getInstance();
        validExpiryDate.add(Calendar.DAY_OF_YEAR, numOfDays);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.ENGLISH);
        String validExpiryDateString = sdf.format(validExpiryDate.getTime());

        // Dynamically calculate an invalid expiry date (e.g., too far in the past)
        Calendar invalidExpiryDate = Calendar.getInstance();
        invalidExpiryDate.add(Calendar.DAY_OF_YEAR, -(numOfDays + offset + 1));
        String invalidExpiryDateString = sdf.format(invalidExpiryDate.getTime());

        assertTrue("Expiry date should be valid", ApplicationUtil.validateExpiryDate(validExpiryDateString, numOfDays, offset));
        assertFalse("Expiry date should be invalid", ApplicationUtil.validateExpiryDate(invalidExpiryDateString, numOfDays, offset));
    }
}