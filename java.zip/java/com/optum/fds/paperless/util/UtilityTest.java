package com.optum.fds.paperless.util;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;
import java.util.function.Function;
import sun.misc.Unsafe;

public class UtilityTest {

    @Before
    public void setUp() throws Exception {
        // Set up the activeProfile field using reflection
        setActiveProfile(null);
    }

    @After
    public void tearDown() throws Exception {
        // Reset the activeProfile field after each test
        setActiveProfile(null);
    }

    private void setActiveProfile(String profile) throws Exception {
        Field field = Utility.class.getDeclaredField("activeProfile");
        field.setAccessible(true);
        field.set(null, profile);
    }

    private void setEnvFunction(Function<String, String> function) throws Exception {
        Field field = Utility.class.getDeclaredField("envFunction");
        field.setAccessible(true);

        // Use Unsafe to modify the final field
        Field unsafeField = Unsafe.class.getDeclaredField("theUnsafe");
        unsafeField.setAccessible(true);
        Unsafe unsafe = (Unsafe) unsafeField.get(null);

        unsafe.putObjectVolatile(Utility.class, unsafe.staticFieldOffset(field), function);
    }

    @Test
    public void testGetEnvironmentWhenActiveProfileIsNull() throws Exception {
        setActiveProfile(null);
        String result = Utility.getEnvironment();
        assertEquals("local", result);
    }

    @Test
    public void testGetEnvironmentWhenActiveProfileMatches() throws Exception {
        setActiveProfile("test");
        setEnvFunction(profile -> "test"); // Simulate the environment variable
        String result = Utility.getEnvironment();
        assertEquals("test", result);
    }

    @Test
    public void testGetEnvironmentWhenActiveProfileDoesNotMatch() throws Exception {
        setActiveProfile("unknown");
        setEnvFunction(profile -> "unknown"); // Simulate the environment variable
        String result = Utility.getEnvironment();
        assertEquals("local", result);
    }
}