package com.optum.fds.paperless.util;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class FileUtilTest {

    private FileUtil fileUtil;

    @Before
    public void setUp() {
        fileUtil = FileUtil.getInstance();
    }

    @Test
    public void testAddQuotesAroundName() {
        assertEquals("\"test file.txt\"", FileUtil.addQuotesAroundName("test file.txt"));
        assertEquals("\"file\"", FileUtil.addQuotesAroundName("file"));
        assertNull(FileUtil.addQuotesAroundName(null));
    }

    @Test
    public void testGetFilesByExtension() throws IOException {
        Path tempDir = Files.createTempDirectory("testDir");
        File tempFile1 = Files.createFile(tempDir.resolve("file1.txt")).toFile();
        File tempFile2 = Files.createFile(tempDir.resolve("file2.txt")).toFile();
        Files.createFile(tempDir.resolve("file3.csv"));

        List<File> files = FileUtil.getFilesByExtension("txt", tempDir.toFile());
        assertEquals(2, files.size());
        assertTrue(files.contains(tempFile1));
        assertTrue(files.contains(tempFile2));

        // Cleanup
        tempFile1.delete();
        tempFile2.delete();
        tempDir.toFile().delete();
    }

    @Test
    public void testReplaceSpaceToUnderScoreInFilename() {
        assertEquals("test_file.txt", FileUtil.replaceSpaceToUnderScoreInFilename("test file.txt"));
        assertEquals("file", FileUtil.replaceSpaceToUnderScoreInFilename("file"));
        assertNull(FileUtil.replaceSpaceToUnderScoreInFilename(null));
    }

    @Test
    public void testTotalBytesAtLocation() throws IOException {
        Path tempDir = Files.createTempDirectory("testDir");
        File tempFile1 = Files.createFile(tempDir.resolve("file1.txt")).toFile();
        File tempFile2 = Files.createFile(tempDir.resolve("file2.txt")).toFile();

        // Write some content to the files to ensure they have a size greater than 0
        Files.write(tempFile1.toPath(), "Sample content".getBytes());
        Files.write(tempFile2.toPath(), "Another sample content".getBytes());

        long totalBytes = FileUtil.totalBytesAtLocation(tempDir);
        assertTrue("Total bytes should be greater than 0", totalBytes > 0);

        // Cleanup
        tempFile1.delete();
        tempFile2.delete();
        tempDir.toFile().delete();
    }

    @Test
    public void testRemoveFileExtension() {
        assertEquals("file", fileUtil.removeFileExtesion("file.txt"));
        assertEquals("file.name", fileUtil.removeFileExtesion("file.name.txt"));
        assertEquals("file", fileUtil.removeFileExtesion("file"));
        assertNull(fileUtil.removeFileExtesion(null));
    }

    @Test
    public void testGetFilesByExtension_whenPathIsAFile_shouldRethrowIOException() throws IOException {
        Path tempFile = Files.createTempFile("fileUtil", ".txt");

        try {
            FileUtil.getFilesByExtension("txt", tempFile);
            fail("Expected IOException to be thrown");
        } catch (IOException e) {
            assertNotNull(e);
        } finally {
            Files.deleteIfExists(tempFile);
        }
    }

    @Test
    public void testTotalBytesAtLocation_whenPathDoesNotExist_shouldReturnZeroFromCatchBlock() {
        Path missingPath = java.nio.file.Paths.get(
                System.getProperty("java.io.tmpdir"),
                "missing-dir-" + System.nanoTime()
        );

        Long totalBytes = FileUtil.totalBytesAtLocation(missingPath, null);

        assertNotNull(totalBytes);
        assertEquals(Long.valueOf(0L), totalBytes);
    }
}