package com.optum.fds.paperless.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.springframework.data.mongodb.core.query.Query;

import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;

public class ProcessorUtilTest {

    @Test
    public void testAddServerTypeCriteria_shouldAddServerTypeToQuery() {
        Query query = new Query();

        ProcessorUtil.addServerTypeCriteria("ose", query);

        assertEquals("Query: { \"serverType\" : \"ose\"}, Fields: {}, Sort: {}", query.toString());
    }

    @Test
    public void testSetTransactionRecord_shouldPopulateTransactionFromProcessorMetaData() {
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setAppIdentifier("app-identifier");
        processor.setClientId(1234);
        processor.setConfigSpaceId(5678);

        Transaction transaction = ProcessorUtil.setTransactionRecord(processor);

        assertNotNull(transaction);
        assertEquals("app-identifier", transaction.getAppIdentifier());
        assertEquals(1234, transaction.getClientId());
        assertEquals(5678, transaction.getSpaceId());
        assertNotNull(transaction.getDateCreated());
        assertNotNull(transaction.getDateModified());
        assertTrue(!transaction.getDateModified().before(transaction.getDateCreated()));
    }
}

