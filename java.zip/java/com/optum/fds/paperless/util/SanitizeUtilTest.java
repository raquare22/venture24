package com.optum.fds.paperless.util;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.owasp.encoder.Encode;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SanitizeUtilTest {

	@Test
	public void testSanitizeString_NullInput() {
		assertNull(SanitizeUtil.sanitizeString(null));
	}

	@Test
	public void testSanitizeString_InvalidJson() {
		String input = "Invalid JSON";
		assertEquals("Sanitize Failure", SanitizeUtil.sanitizeString(input));
	}

	@Test
	public void testSanitizeString_ValidJson() {
		String input = "{\"key\":\"value\"}";
		assertEquals("{\"key\":\"value\"}", SanitizeUtil.sanitizeString(input));
	}

	@Test
	public void testSanitizeToString_NullInput() {
		assertNull(SanitizeUtil.sanitizeToString(null));
	}

	@Test
	public void testSanitizeToString_SpecialCharacters() {
		String input = "Line1\nLine2\rLine3";
		assertEquals("Line1Line2Line3", SanitizeUtil.sanitizeToString(input));
	}

	@Test
	public void testSanitizeAttachmentUrl() throws URISyntaxException {

		String url = "https://cloudfront.stage.federateddataservices.com/a0e6%2F098e6a28-80aa-4151-b2cb-f8d21f56033e%2Fb05d88dc-1e12-47d0-9207-feee341e482c%2F8c5919fe-ce4f-421d-8aa1-c571b5a0bc33%2F1412138609_1412138614.pdf?Expires=1712867481&Signature=C1vY9TKN-8iXf0jqz~TkAR5qYa4Pc3weLhDeOjyM1KgyYG6KzR7vZDka~60FdWKxLwxuje~l2gR8B2hTMv9hpjlKJ3h13m28DhNIGTmwyXGbPuKLDdJ6R0appwMv-F2Uc7T8x4dFTWKOV7iRrlaKFgaawjDaey7e5-WtUBBpGjC0tC4HZeeBFADtCwjb-PujviryeP2GHOZwBRiELAfAbdFJp-7AOqngvtQFfIXAkRomKDA7~LnHzaBZjLgzmkl0OKtw5C2aNMUVBdFAvqhDJafloRp0GQpo0~woWtX7kZYlrHw86l4SdHD9-hkeQ3yiT4scIzsAw3lSUm4uV1pthw__&Key-Pair-Id=K2MBYL5HYWOZLG";

		URI uri = new URI(url);

		String sanitizedUrl = SanitizeUtil.sanitizeAttachmentURL(uri);

		String encodeUrl=Encode.forJava(url);

		System.out.println(sanitizedUrl);


		assertEquals(url, sanitizedUrl);


		assertEquals(url,encodeUrl);


	}

	@Test
	public void testEncodeUrl()
	{
		String url = "https://cloudfront.stage.federateddataservices.com/a0e6%2F098e6a28-80aa-4151-b2cb-f8d21f56033e%2Fb05d88dc-1e12-47d0-9207-feee341e482c%2F8c5919fe-ce4f-421d-8aa1-c571b5a0bc33%2F1412138609_1412138614.pdf?Expires=1712867481&Signature=C1vY9TKN-8iXf0jqz~TkAR5qYa4Pc3weLhDeOjyM1KgyYG6KzR7vZDka~60FdWKxLwxuje~l2gR8B2hTMv9hpjlKJ3h13m28DhNIGTmwyXGbPuKLDdJ6R0appwMv-F2Uc7T8x4dFTWKOV7iRrlaKFgaawjDaey7e5-WtUBBpGjC0tC4HZeeBFADtCwjb-PujviryeP2GHOZwBRiELAfAbdFJp-7AOqngvtQFfIXAkRomKDA7~LnHzaBZjLgzmkl0OKtw5C2aNMUVBdFAvqhDJafloRp0GQpo0~woWtX7kZYlrHw86l4SdHD9-hkeQ3yiT4scIzsAw3lSUm4uV1pthw__&Key-Pair-Id=K2MBYL5HYWOZLG";

		String encodeUrl= Encode.forJava(url);

		assertEquals(url,encodeUrl);

	}

	@Test
	public void testSanitizeResponseEntityBody_NullResponse() {
		assertNull(SanitizeUtil.sanitizeResponseEntityBody(null));
	}

	@Test
	public void testSanitizeResponseEntityBody_ValidResponse() {
		ResponseEntity<String> response = mock(ResponseEntity.class);
		assertNull(SanitizeUtil.sanitizeResponseEntityBody(response));
	}

	@Test
	public void testSanitizeURL_ValidUrl() throws URISyntaxException {
		String url = "https://example.com/path?query=1#fragment";
		String sanitizedUrl = SanitizeUtil.sanitizeURL(url);
		assertEquals("https://example.com/path?query=1#fragment", sanitizedUrl);
	}

	@Test
	public void testSanitizeAttachmentURL_ValidUri() throws URISyntaxException {
		URI uri = new URI("https://example.com/path?query=1#fragment");
		String sanitizedUrl = SanitizeUtil.sanitizeAttachmentURL(uri);
		assertEquals("https://example.com/path?query=1#fragment", sanitizedUrl);
	}

	@Test
	public void testSanitizeAttachmentURL_NoQueryOrFragment() throws URISyntaxException {
		URI uri = new URI("https://example.com/path");
		String sanitizedUrl = SanitizeUtil.sanitizeAttachmentURL(uri);
		assertEquals("https://example.com/path", sanitizedUrl);
	}

    @Test
    public void testSanitizeHttpEntityHeaderRmAuth_whenContentTypeExists_shouldThrowIllegalArgumentException() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer token");
        headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);

        HttpEntity<String> requestEntity = new HttpEntity<>("body", headers);

        try {
            SanitizeUtil.sanitizeHttpEntityHeaderRmAuth(requestEntity);
            fail("Expected IllegalArgumentException to be thrown");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid token character ' ' in token \"Sanitize Failure\"", e.getMessage());
            assertFalse(headers.containsHeader("Authorization"));
        }
    }

    @Test
    public void testSanitizeHttpEntityHeaderRmAuth_whenContentTypeIsNull_shouldRemoveAuthorizationOnly() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer token");
        headers.add("custom-header", "custom-value");

        HttpEntity<String> requestEntity = new HttpEntity<>("body", headers);

        HttpEntity<?> sanitizedEntity = SanitizeUtil.sanitizeHttpEntityHeaderRmAuth(requestEntity);

        assertNotNull(sanitizedEntity);
        assertFalse(sanitizedEntity.getHeaders().containsHeader("Authorization"));
        assertEquals("custom-value", sanitizedEntity.getHeaders().getFirst("custom-header"));
        assertNull(sanitizedEntity.getHeaders().getContentType());
    }
}