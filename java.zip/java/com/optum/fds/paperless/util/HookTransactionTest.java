package com.optum.fds.paperless.util;

import static org.mockito.Mockito.*;

import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.mongo.executions.HookExecutionRecordMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HookTransactionTest {

    @Mock
    private HookService hookService;

    @Mock
    private DelegateExecution execution;

    @InjectMocks
    private HookTransaction hookTransaction;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testUpdateHookTransaction() {
        // Mock input data
        HookTransactionMetaData hookTransactionMetaData = new HookTransactionMetaData();
        HookExecutionRecordMetaData hookExecutionRecord = new HookExecutionRecordMetaData();
        List<HookExecutionRecordMetaData> hookExecutionList = new ArrayList<>();
        hookExecutionList.add(hookExecutionRecord);
        hookTransactionMetaData.setHookExecutionList(hookExecutionList);

        Map<String, String> messageList = new HashMap<>();
        hookExecutionRecord.setMessageList(List.of(messageList));

        List<String> fileList = List.of("file1.txt", "file2.txt");
        when(execution.getVariable(Workflow.SFTP_FILE_LIST)).thenReturn(fileList);

        Map<String, String> msg = new HashMap<>();
        msg.put("key", "value");

        // Call the method under test
        hookTransaction.updateHookTransaction(execution, hookTransactionMetaData, msg);

        // Verify behavior
        verify(hookService).updateHookTransaction(hookTransactionMetaData);
        verify(execution).getVariable(Workflow.SFTP_FILE_LIST);
    }

    @Test
    public void testUpdateHookTransactionWithEmptyFileList() {
        // Mock input data
        HookTransactionMetaData hookTransactionMetaData = new HookTransactionMetaData();
        HookExecutionRecordMetaData hookExecutionRecord = new HookExecutionRecordMetaData();
        List<HookExecutionRecordMetaData> hookExecutionList = new ArrayList<>();
        hookExecutionList.add(hookExecutionRecord);
        hookTransactionMetaData.setHookExecutionList(hookExecutionList);

        Map<String, String> messageList = new HashMap<>();
        hookExecutionRecord.setMessageList(List.of(messageList));

        when(execution.getVariable(Workflow.SFTP_FILE_LIST)).thenReturn(null);

        Map<String, String> msg = new HashMap<>();
        msg.put("key", "value");

        // Call the method under test
        hookTransaction.updateHookTransaction(execution, hookTransactionMetaData, msg);

        // Verify behavior
        verify(hookService).updateHookTransaction(hookTransactionMetaData);
        verify(execution).getVariable(Workflow.SFTP_FILE_LIST);
    }
}