package com.optum.fds.paperless.util;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.ProcessorTransactionCore;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import org.junit.Test;
import org.mockito.MockedStatic;
import org.mvel2.MVEL;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class ProcessorTaskUtilTest {

    @Test
    public void testFindDuplicateError() {
        String errorMessage = "error";
        Set<String> errorList = Set.of("error1", "error2", "error");

        boolean result = ProcessorTaskUtil.findDuplicateError(errorMessage, errorList);

        assertTrue("Duplicate error should be found", result);
    }

    @Test
    public void testCreateProcessorExecutionRecord() {
        String description = "Test description";

        ProcessorExecutionRecord record = ProcessorTaskUtil.createProcessorExecutionRecord(description);

        assertNotNull("Record should not be null", record);
        assertEquals("Description should match", description, record.getDescription());
    }

    @Test
    public void testGetFileName() {
        ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskService.class);
        ProcessorsService processorsService = mock(ProcessorsService.class);

        when(processorFileTaskService.getProcessorFileTaskForTargetId(anyString(), anyString(), anyString()))
                .thenReturn(null);

        String fileName = ProcessorTaskUtil.getFileName("docId", "appId", processorFileTaskService, processorsService);

        assertEquals("File name should be empty if no task is found", "", fileName);
    }

    @Test
    public void testValidateCriteriaMatch() {
        String expression = "key == 'value'";
        Map<String, Object> rootNodeMap = Map.of("key", "value");

        try (MockedStatic<MVEL> mockedMVEL = mockStatic(MVEL.class)) {
            mockedMVEL.when(() -> MVEL.eval(expression, rootNodeMap)).thenReturn(true);

            boolean result = ProcessorTaskUtil.validateCriteriaMatch(expression, rootNodeMap);

            assertTrue("Expression should evaluate to true", result);
        }
    }

    @Test
    public void testAddMessageToProcessorExecutionRecord() {
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();
        Map<String, String> message = Map.of("key", "value");

        // Call the method (it modifies the object in place)
        ProcessorTaskUtil.addMessageToProcessorExecutionRecord(executionRecord, message);

        // Verify that the message was added to the executionRecord
        assertNotNull("Execution record messages should not be null", executionRecord.getMessageList());
        assertEquals("Message should be added to the record", message, executionRecord.getMessageList().get(0));
    }

    @Test
    public void testAddMessageToProcessorExecutionRecordToProcessorTransaction() {
        ProcessorTransactionCore processorTransaction = mock(ProcessorTransactionCore.class);
        ProcessorExecutionRecord executionRecord = new ProcessorExecutionRecord();
        Map<String, String> message = Map.of("status", "processed");

        assertNull(executionRecord.getDateModified());
        assertNull(executionRecord.getMessageList());

        ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(
                processorTransaction, executionRecord, message);

        assertNotNull(executionRecord.getDateModified());
        assertEquals(1, executionRecord.getMessageList().size());
        assertEquals(message, executionRecord.getMessageList().get(0));
        verify(processorTransaction).addProcessorExecutionRecord(executionRecord);
    }

    @Test
    public void testGetFileName_whenProcessorFileTaskExists_shouldReturnProcessorTransactionFileName() {
        ProcessorFileTaskService processorFileTaskService = mock(ProcessorFileTaskService.class);
        ProcessorsService processorsService = mock(ProcessorsService.class);
        ProcessorFileTask processorFileTask = mock(ProcessorFileTask.class);
        com.optum.fds.paperless.mongo.processors.ProcessorTransaction processorTransaction =
                mock(com.optum.fds.paperless.mongo.processors.ProcessorTransaction.class);

        when(processorFileTaskService.getProcessorFileTaskForTargetId("docId", "documents", "appId"))
                .thenReturn(processorFileTask);
        when(processorFileTask.getProcessorTransactionId()).thenReturn("txn-123");
        when(processorsService.getProcessorTransactionById("txn-123"))
                .thenReturn(processorTransaction);
        when(processorTransaction.getFileName()).thenReturn("batch-file.zip");

        String fileName = ProcessorTaskUtil.getFileName("docId", "appId", processorFileTaskService, processorsService);

        assertEquals("batch-file.zip", fileName);
        verify(processorFileTaskService).getProcessorFileTaskForTargetId("docId", "documents", "appId");
        verify(processorFileTask).getProcessorTransactionId();
        verify(processorsService).getProcessorTransactionById("txn-123");
        verify(processorTransaction).getFileName();
    }

    @Test
    public void testCreateProcessorExecutionRecord_withMessage_shouldSetDescriptionAndAddMessage() {
        String description = "processor-step";
        Map<String, String> message = Map.of("status", "success");

        ProcessorExecutionRecord record =
                ProcessorTaskUtil.createProcessorExecutionRecord(description, message);

        assertNotNull(record);
        assertEquals(description, record.getDescription());

        assertNotNull(record.getMessageList());
        assertEquals(1, record.getMessageList().size());
        assertEquals(message, record.getMessageList().get(0));

        assertNotNull(record.getDateCreated());
        assertNotNull(record.getDateModified());
        assertNotNull(record.getServerName());
        assertNotNull(record.getServerIp());
    }

    @Test
    public void testValidateCriteriaMatch_whenPropertyAccessExceptionOccurs_shouldReturnFalse() {
        String expression = "missingField == 'value'";
        Map<String, Object> rootNodeMap = Map.of("otherField", "value");

        try (MockedStatic<MVEL> mockedMVEL = mockStatic(MVEL.class)) {
            mockedMVEL.when(() -> MVEL.eval(expression, rootNodeMap))
                    .thenThrow(new org.mvel2.PropertyAccessException("missingField", null, 0, null, null));

            boolean result = ProcessorTaskUtil.validateCriteriaMatch(expression, rootNodeMap);

            assertFalse("Expression should evaluate to false when PropertyAccessException occurs", result);
        }
    }
}