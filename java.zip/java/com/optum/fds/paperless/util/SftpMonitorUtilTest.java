package com.optum.fds.paperless.util;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.endsWith;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.jcraft.jsch.*;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;

public class SftpMonitorUtilTest {

    @InjectMocks
    private SftpMonitorUtil sftpMonitorUtil;

    @Mock
    private Session mockSession;

    @Mock
    private Channel mockChannel;

    @Mock
    private ChannelSftp mockChannelSftp;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testCreateFileOutputDirectoryPath() {
        Map<String, Object> processConfig = new HashMap<>();
        processConfig.put("space_id", "2804");
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setAppIdentifier("685");
        processor.setConfigSpaceId(10802);
        String dirFromFileName = "abcZipFile.zip";

        String outputDir = sftpMonitorUtil.createFileOutputDirectoryPath(processConfig, processor, dirFromFileName);

        assertThat(outputDir, endsWith("abcZipFile"));
    }

    @Test
    public void testIsMissingLoginCredential() {
        assertThat(sftpMonitorUtil.isMissingLoginCredential("", "user", "pass", "dir"), equalTo(true));
        assertThat(sftpMonitorUtil.isMissingLoginCredential("host", "", "pass", "dir"), equalTo(true));
        assertThat(sftpMonitorUtil.isMissingLoginCredential("host", "user", "", "dir"), equalTo(true));
        assertThat(sftpMonitorUtil.isMissingLoginCredential("host", "user", "pass", ""), equalTo(true));
        assertThat(sftpMonitorUtil.isMissingLoginCredential("host", "user", "pass", "dir"), equalTo(false));
    }

    @Test
    public void testHasValidStatus() {
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setStatus(MetaDataStatus.ACTIVE);
        assertThat(sftpMonitorUtil.hasValidStatus(processor), equalTo(true));

        processor.setStatus(MetaDataStatus.IN_PROCESS);
        assertThat(sftpMonitorUtil.hasValidStatus(processor), equalTo(true));

        processor.setStatus(MetaDataStatus.NEW);
        assertThat(sftpMonitorUtil.hasValidStatus(processor), equalTo(true));

        processor.setStatus(MetaDataStatus.AVAILABLE);
        assertThat(sftpMonitorUtil.hasValidStatus(processor), equalTo(false));

        assertThat(sftpMonitorUtil.hasValidStatus(null), equalTo(false));
    }

    @Test
    public void testExceptionForMissingLoginCredential() {
        try {
            sftpMonitorUtil.exceptionForMissingLoginCredential("", "user", "pass", "dir");
        } catch (IOException e) {
            assertThat(e.getMessage(), equalTo("Missing login credentials host="));
        }
    }

    @Test
    public void testCloseSFTPChannel() throws JSchException {
        when(mockChannelSftp.isConnected()).thenReturn(true);
        when(mockChannelSftp.getSession()).thenReturn(mockSession);

        sftpMonitorUtil.closeSFTPChannel(mockChannelSftp, mockSession, mockChannel);

        verify(mockChannel).disconnect();
        verify(mockChannelSftp).disconnect();
        verify(mockChannelSftp).quit();
        verify(mockSession).disconnect();
    }

    @Test
    public void testExceptionForMissingLoginCredential_Success() throws IOException {
        String sftpHost = "host";
        String sftpUSER = "user";
        String sftpPASS = "pass";
        String sftpWorkingDir = "/testDir";

        boolean result = sftpMonitorUtil.exceptionForMissingLoginCredential(sftpHost, sftpUSER, sftpPASS, sftpWorkingDir);

        assertFalse(result);
    }
    @Test
    public void testHasValidStatus_InvalidStatus() {
        ProcessorMetaData processor = new ProcessorMetaData();
        processor.setStatus(MetaDataStatus.AVAILABLE); // Invalid status

        boolean result = sftpMonitorUtil.hasValidStatus(processor);

        assertThat(result, equalTo(false));
    }

    @Test
    public void testProccessSFTPDirectory_success_returnsSortedDirectoryListingAndObjects() throws Exception {
        Session session = mock(Session.class);
        ChannelSftp channelSftp = mock(ChannelSftp.class);

        ChannelSftp.LsEntry entry1 = mock(ChannelSftp.LsEntry.class);
        ChannelSftp.LsEntry entry2 = mock(ChannelSftp.LsEntry.class);
        SftpATTRS attrs1 = mock(SftpATTRS.class);
        SftpATTRS attrs2 = mock(SftpATTRS.class);

        when(entry1.getAttrs()).thenReturn(attrs1);
        when(entry2.getAttrs()).thenReturn(attrs2);
        when(attrs1.getMTime()).thenReturn(200);
        when(attrs2.getMTime()).thenReturn(100);

        when(channelSftp.pwd()).thenReturn("/work");

        Vector<ChannelSftp.LsEntry> lsEntries = new Vector<>();
        lsEntries.add(entry1);
        lsEntries.add(entry2);

        when(channelSftp.ls("/work")).thenReturn(lsEntries);

        try (MockedStatic<SftpUtil> mockedStatic = mockStatic(SftpUtil.class)) {
            mockedStatic.when(() -> SftpUtil.createSesssion("user", "pass", "host", 22)).thenReturn(session);
            mockedStatic.when(() -> SftpUtil.createSFTPChannel(session)).thenReturn(channelSftp);

            Map<String, Object> result =
                    sftpMonitorUtil.proccessSFTPDirectory("user", "pass", "host", "/work");

            assertNotNull(result);
            assertSame(session, result.get("sftpSession"));
            assertSame(channelSftp, result.get("channel"));
            assertSame(channelSftp, result.get("channelSftp"));

            @SuppressWarnings("unchecked")
            List<ChannelSftp.LsEntry> directoryListing =
                    (List<ChannelSftp.LsEntry>) result.get("directoryListing");

            assertNotNull(directoryListing);
            assertEquals(2, directoryListing.size());
            assertSame(entry2, directoryListing.get(0));
            assertSame(entry1, directoryListing.get(1));

            verify(channelSftp).cd("/work");
            verify(channelSftp).pwd();
            verify(channelSftp).ls("/work");
        }
    }

    @Test
    public void testProccessSFTPDirectory_whenCdFails_throwsException() throws Exception {
        Session session = mock(Session.class);
        ChannelSftp channelSftp = mock(ChannelSftp.class);

        SftpException sftpException = new SftpException(4, "cd failed");
        doThrow(sftpException).when(channelSftp).cd("/bad-dir");

        try (MockedStatic<SftpUtil> mockedStatic = mockStatic(SftpUtil.class)) {
            mockedStatic.when(() -> SftpUtil.createSesssion("user", "pass", "host", 22)).thenReturn(session);
            mockedStatic.when(() -> SftpUtil.createSFTPChannel(session)).thenReturn(channelSftp);

            try {
                sftpMonitorUtil.proccessSFTPDirectory("user", "pass", "host", "/bad-dir");
                fail("Expected exception to be thrown");
            } catch (Exception e) {
                assertSame(sftpException, e);
                assertEquals("cd failed", e.getMessage());
            }

            verify(channelSftp).cd("/bad-dir");
            verify(channelSftp, never()).ls(anyString());
        }
    }

    @Test
    public void testCloseSFTPChannel_whenSessionNull_getsSessionFromChannelAndDisconnects() throws Exception {
        ChannelSftp channelSftp = mock(ChannelSftp.class);
        Session resolvedSession = mock(Session.class);
        com.jcraft.jsch.Channel channel = mock(com.jcraft.jsch.Channel.class);

        when(channelSftp.isConnected()).thenReturn(true);
        when(channelSftp.getSession()).thenReturn(resolvedSession);

        sftpMonitorUtil.closeSFTPChannel(channelSftp, null, channel);

        verify(channel).disconnect();
        verify(channelSftp).disconnect();
        verify(channelSftp).quit();
        verify(channelSftp).getSession();
        verify(resolvedSession).disconnect();
    }

    @Test
    public void testCloseSFTPChannel_whenDisconnectThrows_exceptionIsCaught() throws Exception {
        ChannelSftp channelSftp = mock(ChannelSftp.class);
        Session session = mock(Session.class);
        com.jcraft.jsch.Channel channel = mock(com.jcraft.jsch.Channel.class);

        when(channelSftp.isConnected()).thenReturn(true);
        doThrow(new RuntimeException("disconnect failure")).when(channel).disconnect();

        sftpMonitorUtil.closeSFTPChannel(channelSftp, session, channel);

        verify(channel).disconnect();
        verify(channelSftp, never()).disconnect();
        verify(channelSftp, never()).quit();
        verify(session, never()).disconnect();
    }
}