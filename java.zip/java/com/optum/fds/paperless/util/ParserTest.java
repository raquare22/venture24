package com.optum.fds.paperless.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.Test;
import org.json.JSONObject;
import org.json.XML;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import com.fasterxml.jackson.annotation.JsonFilter;

public class ParserTest {

    @Test
    public void testParseXMLFilePathAndStringOverloads() throws IOException {
        Path xmlFile = Files.createTempFile("parser-", ".xml");
        try {
            Files.write(xmlFile,
                    "<XmlPojo><name>alpha</name><count>5</count></XmlPojo>".getBytes(StandardCharsets.UTF_8));

            XmlPojo fromPath = Parser.parseXMLFile(xmlFile, XmlPojo.class);
            XmlPojo fromString = Parser.parseXMLFile(xmlFile.toString(), XmlPojo.class);

            assertNotNull(fromPath);
            assertEquals("alpha", fromPath.getName());
            assertEquals(5, fromPath.getCount());

            assertNotNull(fromString);
            assertEquals("alpha", fromString.getName());
            assertEquals(5, fromString.getCount());
        } finally {
            Files.deleteIfExists(xmlFile);
        }
    }

    @Test
    public void testConvertValue() {
        java.util.Map<String, Object> source = new java.util.HashMap<>();
        source.put("name", "beta");
        source.put("count", 7);

        JsonPojo converted = Parser.convertValue(source, JsonPojo.class);

        assertNotNull(converted);
        assertEquals("beta", converted.getName());
        assertEquals(7, converted.getCount());
    }

    @Test
    public void testParseJsonWhenAllowSingleQuotesTrue() throws IOException {
        JsonPojo parsed = Parser.parseJson("{\"name\":\"gamma\",\"count\":9}", JsonPojo.class, true);

        assertNotNull(parsed);
        assertEquals("gamma", parsed.getName());
        assertEquals(9, parsed.getCount());
    }

    @Test
    public void testParseJsonWhenAllowSingleQuotesFalse() throws IOException {
        JsonPojo parsed = Parser.parseJson("{\"name\":\"delta\",\"count\":11}", JsonPojo.class, false);

        assertNotNull(parsed);
        assertEquals("delta", parsed.getName());
        assertEquals(11, parsed.getCount());
    }

    @Test
    public void testToJsonWithFilters() throws IOException {
        FilteredPojo pojo = new FilteredPojo();
        pojo.setVisible("shown");
        pojo.setSecret("hidden");

        String json = Parser.toJsonWithFilters(pojo, FilterMixin.class, new String[]{"secret"});

        assertTrue(json.contains("shown"));
        assertFalse(json.contains("hidden"));
        assertFalse(json.contains("secret"));
    }

    @Test
    public void testXmlToJsonPrettyPrintAndCompact() throws Exception {
        String xml = "<root><name>value</name></root>";
        JSONObject jsonObject = new JSONObject("{\"root\":{\"name\":\"value\"}}");

        try (MockedStatic<XML> xmlMock = Mockito.mockStatic(XML.class)) {
            xmlMock.when(() -> XML.toJSONObject(xml))
                    .thenReturn(jsonObject);

            String pretty = Parser.xmltoJson(true, xml);
            String compact = Parser.xmltoJson(false, xml);

            assertEquals(jsonObject.toString(Parser.PRETTY_PRINT_INDENT_FACTOR), pretty);
            assertEquals(jsonObject.toString(Parser.PRINT_DEFAULT_IDENTATION), compact);
        }
    }

    @Test
    public void testInputStreamToString_withoutBom_readsContent() throws IOException {
        String result = Parser.inputStreamToString(
                new ByteArrayInputStream("plain-text".getBytes(StandardCharsets.UTF_8)));

        assertEquals("plain-text", result);
    }

    @Test
    public void testDetectAndExcludeBOM_whenUtf8Bom_returnsReaderForUtf8() throws IOException {
        byte[] bytes = concat(new byte[]{(byte) 0xEF, (byte) 0xBB, (byte) 0xBF},
                "utf8-text".getBytes(StandardCharsets.UTF_8));

        try (InputStreamReader reader = Parser.detectAndExcludeBOM(new ByteArrayInputStream(bytes))) {
            assertEquals("utf8-text", readAll(reader));
        }
    }

    @Test
    public void testDetectAndExcludeBOM_whenUtf16BeBom_returnsReaderForUtf16Be() throws IOException {
        byte[] bytes = concat(new byte[]{(byte) 0xFE, (byte) 0xFF},
                "be-text".getBytes(StandardCharsets.UTF_16BE));

        try (InputStreamReader reader = Parser.detectAndExcludeBOM(new ByteArrayInputStream(bytes))) {
            assertEquals("be-text", readAll(reader));
        }
    }

    @Test
    public void testDetectAndExcludeBOM_whenUtf16LeBom_returnsReaderForUtf16Le() throws IOException {
        byte[] bytes = concat(new byte[]{(byte) 0xFF, (byte) 0xFE},
                "le-text".getBytes(StandardCharsets.UTF_16LE));

        try (InputStreamReader reader = Parser.detectAndExcludeBOM(new ByteArrayInputStream(bytes))) {
            assertEquals("le-text", readAll(reader));
        }
    }

    private static String readAll(InputStreamReader reader) throws IOException {
        StringBuilder sb = new StringBuilder();
        char[] buffer = new char[64];
        int len;
        while ((len = reader.read(buffer)) != -1) {
            sb.append(buffer, 0, len);
        }
        return sb.toString();
    }

    private static byte[] concat(byte[] first, byte[] second) {
        byte[] result = new byte[first.length + second.length];
        System.arraycopy(first, 0, result, 0, first.length);
        System.arraycopy(second, 0, result, first.length, second.length);
        return result;
    }

    public static class XmlPojo {
        private String name;
        private int count;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }
    }

    public static class JsonPojo {
        private String name;
        private int count;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }
    }

    public static class FilteredPojo {
        private String visible;
        private String secret;

        public String getVisible() {
            return visible;
        }

        public void setVisible(String visible) {
            this.visible = visible;
        }

        public String getSecret() {
            return secret;
        }

        public void setSecret(String secret) {
            this.secret = secret;
        }
    }

    @JsonFilter("filter properties by name")
    public static abstract class FilterMixin {
    }

    @Test
    public void testParseXML_whenXmlIsInvalid_shouldWrapExceptionInIOException() {
        String invalidXml = "<XmlPojo><name>alpha</name><count>5</XmlPojo>";

        try {
            Parser.parseXML(invalidXml, XmlPojo.class);
            org.junit.Assert.fail("Expected IOException to be thrown");
        } catch (IOException e) {
            assertTrue(e.getMessage().contains("xmlContent="));
            assertTrue(e.getMessage().contains(invalidXml.replaceAll("&(?![^&]{2,4};)", "&#038;")));
        }
    }
}

