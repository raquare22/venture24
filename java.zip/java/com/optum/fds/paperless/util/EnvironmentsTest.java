package com.optum.fds.paperless.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class EnvironmentsTest {

    @Test
    public void testGetEnv() {
        // Test each enum constant and its corresponding environment string
        assertEquals("local", Environments.LOCAL.getEnv());
        assertEquals("test", Environments.TEST.getEnv());
        assertEquals("dev", Environments.DEV.getEnv());
        assertEquals("stage", Environments.STAGE.getEnv());
        assertEquals("prod", Environments.PROD.getEnv());
    }

    @Test
    public void testEnumValues() {
        // Ensure all enum constants are present
        Environments[] values = Environments.values();
        assertEquals(5, values.length);
        assertEquals(Environments.LOCAL, values[0]);
        assertEquals(Environments.TEST, values[1]);
        assertEquals(Environments.DEV, values[2]);
        assertEquals(Environments.STAGE, values[3]);
        assertEquals(Environments.PROD, values[4]);
    }

    @Test
    public void testEnumValueOf() {
        // Test the valueOf method for each enum constant
        assertEquals(Environments.LOCAL, Environments.valueOf("LOCAL"));
        assertEquals(Environments.TEST, Environments.valueOf("TEST"));
        assertEquals(Environments.DEV, Environments.valueOf("DEV"));
        assertEquals(Environments.STAGE, Environments.valueOf("STAGE"));
        assertEquals(Environments.PROD, Environments.valueOf("PROD"));
    }
}