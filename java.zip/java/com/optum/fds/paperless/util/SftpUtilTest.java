package com.optum.fds.paperless.util;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import com.jcraft.jsch.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.MockedStatic;

import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import org.junit.Rule;
import org.junit.rules.TemporaryFolder;

public class SftpUtilTest {

    @Rule
    public TemporaryFolder folder = new TemporaryFolder();

    @Mock
    private Session mockSession;

    @Mock
    private ChannelSftp mockChannelSftp;

    private SftpUtil sftpUtil;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        sftpUtil = new SftpUtil();
    }

    @Test
    public void testIsEnoughFreeSpace() {
        Path mockPath = mock(Path.class);
        File mockFile = mock(File.class);

        when(mockPath.toFile()).thenReturn(mockFile);
        when(mockFile.getFreeSpace()).thenReturn(500L);
        when(mockFile.getTotalSpace()).thenReturn(1000L);

        sftpUtil.minFreeSpacePercentage = 30;

        boolean result = sftpUtil.isEnoughFreeSpace(mockPath, true);
        assertTrue(result);
    }

    @Test
    public void testGetFreeSpacePercentage() {
        File mockFile = mock(File.class);

        when(mockFile.getFreeSpace()).thenReturn(500L);
        when(mockFile.getTotalSpace()).thenReturn(1000L);

        int freeSpacePercentage = sftpUtil.getFreeSpacePercentage(mockFile, true);
        assertEquals(50, freeSpacePercentage);
    }

    @Test
    public void testIsEnoughFreeSpace_InsufficientSpace() {
        Path mockPath = mock(Path.class);
        File mockFile = mock(File.class);

        when(mockPath.toFile()).thenReturn(mockFile);
        when(mockFile.getFreeSpace()).thenReturn(100L);
        when(mockFile.getTotalSpace()).thenReturn(1000L);

        sftpUtil.minFreeSpacePercentage = 20;

        boolean result = sftpUtil.isEnoughFreeSpace(mockPath, true);
        assertFalse(result);
    }

    @Test
    public void testGetFreeSpacePercentage_ZeroTotalSpace() {
        File mockFile = mock(File.class);

        when(mockFile.getFreeSpace()).thenReturn(500L);
        when(mockFile.getTotalSpace()).thenReturn(0L);

        int freeSpacePercentage = sftpUtil.getFreeSpacePercentage(mockFile, true);
        assertEquals(2147483647, freeSpacePercentage);
    }

    @Test
    public void testIsEnoughFreeSpace_NoLogging() {
        Path mockPath = mock(Path.class);
        File mockFile = mock(File.class);

        when(mockPath.toFile()).thenReturn(mockFile);
        when(mockFile.getFreeSpace()).thenReturn(300L);
        when(mockFile.getTotalSpace()).thenReturn(1000L);

        sftpUtil.minFreeSpacePercentage = 20;

        boolean result = sftpUtil.isEnoughFreeSpace(mockPath, false);
        assertTrue(result);
    }
    @Test
    public void testIsEnoughFreeSpace_NoLogging_InsufficientSpace() {
        Path mockPath = mock(Path.class);
        File mockFile = mock(File.class);

        when(mockPath.toFile()).thenReturn(mockFile);
        when(mockFile.getFreeSpace()).thenReturn(100L);
        when(mockFile.getTotalSpace()).thenReturn(1000L);

        sftpUtil.minFreeSpacePercentage = 20;

        boolean result = sftpUtil.isEnoughFreeSpace(mockPath, false);
        assertFalse(result);
    }
    
    @Test
    public void testSemaphoreNotCreatedWhenLimitIsZero() {
        SftpUtil util = new SftpUtil();
        util.setMaxConcurrentSftp(0);

        Semaphore semaphore = util.getSftpSemaphore();
        assertNull(semaphore);
    }

    @Test
    public void testSemaphoreCreatedWhenLimitIsConfigured() {
        SftpUtil util = new SftpUtil();
        util.setMaxConcurrentSftp(2);

        Semaphore semaphore = util.getSftpSemaphore();
        assertNotNull(semaphore);
        assertEquals(2, semaphore.availablePermits());
    }

    @Test(expected = IllegalArgumentException.class)
    public void moveFileFromLocalToSFTPLocation_throwsIllegalArgumentException_forPathTraversal() throws Exception {
        sftpUtil.moveFileFromLocalToSFTPLocation(
                "user", "pass", "host", 22, "/target", "../evil.txt", 1, 1
        );
    }

    @Test
    public void moveFileFromLocalToSFTPLocation_throwsWhenSemaphoreAcquireTimesOut() throws Exception {
        SftpUtil spyUtil = Mockito.spy(new SftpUtil());
        Semaphore semaphore = mock(Semaphore.class);
        doReturn(semaphore).when(spyUtil).getSftpSemaphore();
        when(semaphore.tryAcquire(30, TimeUnit.SECONDS)).thenReturn(false);

        try {
            spyUtil.moveFileFromLocalToSFTPLocation("u", "p", "h", 22, "/t", "a.txt", 1, 1);
            fail("Expected JSchException");
        } catch (JSchException ex) {
            assertTrue(ex.getMessage().contains("Could not acquire permit"));
        }

        verify(semaphore, never()).release();
    }

    @Test
    public void moveFileFromLocalToSFTPLocation_throwsWhenSemaphoreAcquireInterrupted() throws Exception {
        SftpUtil spyUtil = Mockito.spy(new SftpUtil());
        Semaphore semaphore = mock(Semaphore.class);
        doReturn(semaphore).when(spyUtil).getSftpSemaphore();
        when(semaphore.tryAcquire(30, TimeUnit.SECONDS)).thenThrow(new InterruptedException("interrupted"));

        try {
            spyUtil.moveFileFromLocalToSFTPLocation("u", "p", "h", 22, "/t", "a.txt", 1, 1);
            fail("Expected JSchException");
        } catch (JSchException ex) {
            assertTrue(ex.getMessage().contains("Interrupted while acquiring"));
        }

        assertTrue(Thread.currentThread().isInterrupted());
        Thread.interrupted();
        verify(semaphore, never()).release();
    }

    @Test
    public void moveFileFromLocalToSFTPLocation_releasesSemaphore_onRetryableFailure() throws Exception {
        SftpUtil spyUtil = Mockito.spy(new SftpUtil());
        Semaphore semaphore = mock(Semaphore.class);
        doReturn(semaphore).when(spyUtil).getSftpSemaphore();
        when(semaphore.tryAcquire(30, TimeUnit.SECONDS)).thenReturn(true);

        File local = folder.newFile("payload.txt");
        try (FileWriter fw = new FileWriter(local)) {
            fw.write("data");
        }

        Session session = mock(Session.class);
        ChannelSftp channel = mock(ChannelSftp.class);

        try (MockedStatic<SftpUtil> mocked = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> SftpUtil.createSesssion(anyString(), anyString(), anyString(), anyInt()))
                    .thenReturn(session);
            mocked.when(() -> SftpUtil.createSFTPChannel(session))
                    .thenReturn((Channel) channel);

            doThrow(new SftpException(4, "cd failed"))
                    .doThrow(new SftpException(4, "cd failed"))
                    .when(channel).cd(anyString());

            try {
                spyUtil.moveFileFromLocalToSFTPLocation("u", "p", "h", 22, "/target", local.getAbsolutePath(), 2, 1);
                fail("Expected SftpException");
            } catch (SftpException expected) {
                // expected on last try
            }
        }

        verify(semaphore, times(2)).release();
        verify(channel, atLeastOnce()).disconnect();
        verify(session, atLeastOnce()).disconnect();
    }

    @Test
    public void moveFileFromSFTPDirToArchive_throwsWhenSemaphoreAcquireTimesOut() throws Exception {
        SftpUtil spyUtil = Mockito.spy(new SftpUtil());
        Semaphore semaphore = mock(Semaphore.class);
        doReturn(semaphore).when(spyUtil).getSftpSemaphore();
        when(semaphore.tryAcquire(30, TimeUnit.SECONDS)).thenReturn(false);

        try {
            spyUtil.moveFileFromSFTPDirToArchive("u", "p", "h", 22, "/from", "/arch", "f.txt", 1, 1);
            fail("Expected JSchException");
        } catch (JSchException ex) {
            assertTrue(ex.getMessage().contains("Could not acquire permit"));
        }

        verify(semaphore, never()).release();
    }

    @Test
    public void moveFileFromSFTPDirToArchive_releasesSemaphore_onRetryableFailure() throws Exception {
        SftpUtil spyUtil = Mockito.spy(new SftpUtil());
        Semaphore semaphore = mock(Semaphore.class);
        doReturn(semaphore).when(spyUtil).getSftpSemaphore();
        when(semaphore.tryAcquire(30, TimeUnit.SECONDS)).thenReturn(true);

        Session session = mock(Session.class);
        ChannelSftp channel = mock(ChannelSftp.class);

        try (MockedStatic<SftpUtil> mocked = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            mocked.when(() -> SftpUtil.createSesssion(anyString(), anyString(), anyString(), anyInt()))
                    .thenReturn(session);
            mocked.when(() -> SftpUtil.createSFTPChannel(session))
                    .thenReturn((Channel) channel);

            doThrow(new SftpException(4, "cd failed"))
                    .doThrow(new SftpException(4, "cd failed"))
                    .when(channel).cd(anyString());

            try {
                spyUtil.moveFileFromSFTPDirToArchive("u", "p", "h", 22, "/from", "/arch", "f.txt", 2, 1);
                fail("Expected SftpException");
            } catch (SftpException expected) {
                // expected on last try
            }
        }

        verify(semaphore, times(2)).release();
        verify(channel, atLeastOnce()).disconnect();
        verify(session, atLeastOnce()).disconnect();
    }

}