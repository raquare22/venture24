package com.optum.fds.paperless.util;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;

public class DocumentUtilTest {

    @InjectMocks
    private DocumentUtil documentUtil;

    @Mock
    private ConfigData config;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testUpdateDateModified() {
        DocumentMetaData doc = new DocumentMetaData();
        DocumentUtil.updateDateModified(doc);
        assertNotNull(doc.getDateModified());
    }

    @Test
    public void testUpdateDocumentMetaDataRevisions() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setSpaceId(123);
        DocumentUtil.updateDocumentMetaDataRevisions(doc);
        assertNotNull(doc.getRevisions());
        assertEquals(1, doc.getRevisions().size());
    }

    @Test
    public void testAppendDefaultValuesWithSpaceId() {
        DocumentMetaData doc = new DocumentMetaData();
        int spaceId = 123;

        when(config.getCredentials(spaceId)).thenReturn(Map.of(
                "clientId", "456",
                "appIdentifier", "TestApp"
        ));

        documentUtil.appendDefaultValuesWithSpaceId(doc, spaceId);

        assertNotNull(doc.getTransactionId());
        assertEquals(MetaDataStatus.AVAILABLE, doc.getStatus());
        assertEquals(456, doc.getClientId()); // Direct comparison with primitive int
        assertEquals("TestApp", doc.getAppIdentifier());
    }

    @Test(expected = NullPointerException.class)
    public void testAppendDefaultValuesThrowsException() {
        DocumentMetaData doc = new DocumentMetaData();
        documentUtil.appendDefaultValues(doc);
    }

    @Test
    public void appendDefaultValuesWithSpaceId_setsAllDefaultsAndMappedValues() {
        DocumentMetaData doc = new DocumentMetaData();
        int spaceId = 123;

        Map<String, Object> creds = new HashMap<>();
        creds.put("clientId", "456");
        creds.put("appIdentifier", "TestApp");
        when(config.getCredentials(spaceId)).thenReturn(creds);

        documentUtil.appendDefaultValuesWithSpaceId(doc, spaceId);

        assertNotNull(doc.getTransactionId());
        assertEquals(MetaDataStatus.AVAILABLE, doc.getStatus());
        assertEquals(spaceId, doc.getSpaceId());
        assertEquals(456, doc.getClientId());
        assertEquals("TestApp", doc.getAppIdentifier());
        verify(config, times(2)).getCredentials(spaceId);
    }

    @Test(expected = NumberFormatException.class)
    public void appendDefaultValuesWithSpaceId_throwsWhenClientIdIsNotNumeric() {
        DocumentMetaData doc = new DocumentMetaData();
        int spaceId = 321;

        Map<String, Object> creds = new HashMap<>();
        creds.put("clientId", "not-a-number");
        creds.put("appIdentifier", "TestApp");
        when(config.getCredentials(spaceId)).thenReturn(creds);

        documentUtil.appendDefaultValuesWithSpaceId(doc, spaceId);
    }

    @Test
    public void appendDefaultValues_setsDefaultsAndMappedValues_whenSpaceIdPresent() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setSpaceId(555);

        Map<String, Object> creds = new HashMap<>();
        creds.put("clientId", "789");
        creds.put("appIdentifier", "AnotherApp");
        when(config.getCredentials(555)).thenReturn(creds);

        documentUtil.appendDefaultValues(doc);

        assertNotNull(doc.getTransactionId());
        assertEquals(MetaDataStatus.AVAILABLE, doc.getStatus());
        assertEquals(789, doc.getClientId());
        assertEquals("AnotherApp", doc.getAppIdentifier());
        verify(config, times(2)).getCredentials(555);
    }

    @Test(expected = NullPointerException.class)
    public void appendDefaultValues_throwsWhenSpaceIdIsZero() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setSpaceId(0);

        documentUtil.appendDefaultValues(doc);
    }

    @Test(expected = NumberFormatException.class)
    public void appendDefaultValues_throwsWhenClientIdIsNotNumeric() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setSpaceId(100);

        Map<String, Object> creds = new HashMap<>();
        creds.put("clientId", "bad-id");
        creds.put("appIdentifier", "App");
        when(config.getCredentials(100)).thenReturn(creds);

        documentUtil.appendDefaultValues(doc);
    }

    @Test
    public void testUpdateDocumentMetaDataRevisions_whenRevisionListAlreadyExists_addsRevisionToExistingList() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setSpaceId(123);
        doc.setAppIdentifier("TestApp");
        doc.setClientId(456);
        doc.setDateCreated(new Date());
        doc.setDateModified(new Date());
        doc.setStatus(MetaDataStatus.AVAILABLE);
        doc.setTransactionId("txn-123");

        java.util.List<com.optum.fds.paperless.domain.revision.DocumentRevision> existingRevisions =
                new java.util.ArrayList<>();

        com.optum.fds.paperless.domain.revision.DocumentRevision existingRevision =
                new com.optum.fds.paperless.domain.revision.DocumentRevision();
        existingRevision.setTransactionId("old-txn");
        existingRevisions.add(existingRevision);

        doc.setRevisions(existingRevisions);

        DocumentUtil.updateDocumentMetaDataRevisions(doc);

        assertNotNull(doc.getRevisions());
        assertSame(existingRevisions, doc.getRevisions());
        assertEquals(2, doc.getRevisions().size());

        com.optum.fds.paperless.domain.revision.DocumentRevision addedRevision =
                doc.getRevisions().get(1);

        assertEquals("TestApp", addedRevision.getAppIdentifier());
        assertEquals(456, addedRevision.getClientId());
        assertEquals(123, addedRevision.getSpaceId());
        assertEquals("txn-123", addedRevision.getTransactionId());
        assertEquals(MetaDataStatus.AVAILABLE, addedRevision.getStatus());
    }

    @Test
    public void testCreateRevision_whenDocumentAttachmentsAndErrorMessagePresent_setsBoth() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setAppIdentifier("TestApp");
        doc.setClientId(123);
        doc.setDateCreated(new Date());
        doc.setDateModified(new Date());
        doc.setStatus(MetaDataStatus.AVAILABLE);
        doc.setTransactionId("txn-123");

        com.optum.fds.paperless.mongo.DocumentAttachmentMetaData attachment =
                new com.optum.fds.paperless.mongo.DocumentAttachmentMetaData();
        attachment.setAttachmentId("att-1");
        attachment.setName("file.pdf");

        java.util.List<com.optum.fds.paperless.mongo.DocumentAttachmentMetaData> attachments =
                new java.util.ArrayList<>();
        attachments.add(attachment);

        doc.setDocumentAttachments(attachments);
        doc.setErrorMessage("sample error");

        com.optum.fds.paperless.domain.revision.DocumentRevision revision =
                DocumentUtil.createRevision(doc, "456");

        assertNotNull(revision);
        assertNotNull(revision.getDocumentAttachments());
        assertEquals(1, revision.getDocumentAttachments().size());
        assertEquals("att-1", revision.getDocumentAttachments().get(0).getAttachmentId());
        assertEquals("sample error", revision.getErrorMessage());
    }

    @Test
    public void testCreateRevision_whenDocumentAttachmentsEmptyAndErrorMessageEmpty_doesNotSetBoth() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setAppIdentifier("TestApp");
        doc.setClientId(123);
        doc.setDateCreated(new Date());
        doc.setDateModified(new Date());
        doc.setStatus(MetaDataStatus.AVAILABLE);
        doc.setTransactionId("txn-123");
        doc.setDocumentAttachments(new java.util.ArrayList<>());
        doc.setErrorMessage("");

        com.optum.fds.paperless.domain.revision.DocumentRevision revision =
                DocumentUtil.createRevision(doc, "456");

        assertNotNull(revision);
        assertNull(revision.getDocumentAttachments());
        assertNull(revision.getErrorMessage());
    }

    @Test
    public void testAppendDefaultValuesWithSpaceId_whenValidValues_setsAllFields() {
        DocumentMetaData doc = new DocumentMetaData();
        int spaceId = 123;

        Map<String, Object> creds = new HashMap<>();
        creds.put("clientId", "456");
        creds.put("appIdentifier", "TestApp");
        when(config.getCredentials(spaceId)).thenReturn(creds);

        documentUtil.appendDefaultValuesWithSpaceId(doc, spaceId);

        assertNotNull(doc.getTransactionId());
        assertEquals(MetaDataStatus.AVAILABLE, doc.getStatus());
        assertEquals(spaceId, doc.getSpaceId());
        assertEquals(456, doc.getClientId());
        assertEquals("TestApp", doc.getAppIdentifier());
        verify(config, times(2)).getCredentials(spaceId);
    }

    @Test(expected = NumberFormatException.class)
    public void testAppendDefaultValuesWithSpaceId_whenClientIdIsNotNumeric_throwsException() {
        DocumentMetaData doc = new DocumentMetaData();
        int spaceId = 123;

        Map<String, Object> creds = new HashMap<>();
        creds.put("clientId", "abc");
        creds.put("appIdentifier", "TestApp");
        when(config.getCredentials(spaceId)).thenReturn(creds);

        documentUtil.appendDefaultValuesWithSpaceId(doc, spaceId);
    }

    @Test(expected = NullPointerException.class)
    public void testAppendDefaultValues_whenSpaceIdIsZero_hitsIfBranch() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setSpaceId(0);

        documentUtil.appendDefaultValues(doc);
    }

    @Test
    public void testAppendDefaultValues_whenSpaceIdIsPresent_hitsNonIfPathAndSetsFields() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setSpaceId(555);

        Map<String, Object> creds = new HashMap<>();
        creds.put("clientId", "789");
        creds.put("appIdentifier", "AnotherApp");
        when(config.getCredentials(555)).thenReturn(creds);

        documentUtil.appendDefaultValues(doc);

        assertNotNull(doc.getTransactionId());
        assertEquals(MetaDataStatus.AVAILABLE, doc.getStatus());
        assertEquals(789, doc.getClientId());
        assertEquals("AnotherApp", doc.getAppIdentifier());
        verify(config, times(2)).getCredentials(555);
    }

    @Test(expected = NumberFormatException.class)
    public void testAppendDefaultValues_whenSpaceIdPresentAndClientIdInvalid_throwsException() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setSpaceId(555);

        Map<String, Object> creds = new HashMap<>();
        creds.put("clientId", "bad-id");
        creds.put("appIdentifier", "AnotherApp");
        when(config.getCredentials(555)).thenReturn(creds);

        documentUtil.appendDefaultValues(doc);
    }


}