package com.optum.fds.paperless.util.handlebar.helper;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;

import com.github.jknack.handlebars.Options;

public class UHCWestFixedWidthHelperTest {

    private UHCWestFixedWidthHelper helper;
    private Options options;

    @Before
    public void setUp() {
        helper = new UHCWestFixedWidthHelper();
        options = mock(Options.class);
    }

    @Test
    public void testApply_ValueIsNull() throws IOException {
        when(options.param(0)).thenReturn("10");
        when(options.param(1)).thenReturn(" ");
        when(options.param(2)).thenReturn("L");
        when(options.param(3)).thenReturn("R");

        CharSequence result = helper.apply(null, options);
        assertEquals(null, result);
    }

    @Test
    public void testApply_ValueIsEmpty() throws IOException {
        when(options.param(0)).thenReturn("10");
        when(options.param(1)).thenReturn(" ");
        when(options.param(2)).thenReturn("L");
        when(options.param(3)).thenReturn("R");

        CharSequence result = helper.apply("", options);
        assertEquals(null, result);
    }

    @Test
    public void testApply_ValueExceedsLength() throws IOException {
        when(options.param(0)).thenReturn("5");
        when(options.param(1)).thenReturn(" ");
        when(options.param(2)).thenReturn("L");
        when(options.param(3)).thenReturn("R");

        CharSequence result = helper.apply("1234567890", options);
        assertEquals("12345", result);
    }

    @Test
    public void testApply_ValueEqualsLength() throws IOException {
        when(options.param(0)).thenReturn("10");
        when(options.param(1)).thenReturn(" ");
        when(options.param(2)).thenReturn("L");
        when(options.param(3)).thenReturn("R");

        CharSequence result = helper.apply("1234567890", options);
        assertEquals("1234567890", result);
    }

    @Test
    public void testApply_ValueLessThanLengthWithPadding() throws IOException {
        when(options.param(0)).thenReturn("10");
        when(options.param(1)).thenReturn(" ");
        when(options.param(2)).thenReturn("L");
        when(options.param(3)).thenReturn("R");

        CharSequence result = helper.apply("12345", options);
        assertEquals("     12345", result);
    }

    @Test
    public void testApply_ValueLessThanLengthWithoutPadding() throws IOException {
        when(options.param(0)).thenReturn("10");
        when(options.param(1)).thenReturn("");
        when(options.param(2)).thenReturn("L");
        when(options.param(3)).thenReturn("R");

        CharSequence result = helper.apply("12345", options);
        assertEquals("12345", result);
    }

    @Test
    public void testApply_WhenLengthIsNotNumeric_ShouldCatchNumberFormatExceptionAndReturnNull() throws IOException {
        when(options.param(0)).thenReturn("invalid-number");
        when(options.param(1)).thenReturn(" ");
        when(options.param(2)).thenReturn("L");
        when(options.param(3)).thenReturn("R");

        CharSequence result = helper.apply("12345", options);

        assertNull(result);
    }

    @Test
    public void testApply_WhenOptionToStringThrows_ShouldCatchGenericExceptionAndReturnNull() throws IOException {
        Object badOption = new Object() {
            @Override
            public String toString() {
                throw new RuntimeException("forced failure");
            }
        };

        when(options.param(0)).thenReturn("5");
        when(options.param(1)).thenReturn(" ");
        when(options.param(2)).thenReturn("L");
        when(options.param(3)).thenReturn(badOption);

        CharSequence result = helper.apply("12345", options);

        assertNull(result);
    }

    @Test
    public void testApply_ValueExceedsLength_WithLeftTruncDirection_ShouldReturnRightMostCharacters() throws IOException {
        when(options.param(0)).thenReturn("5");
        when(options.param(1)).thenReturn(" ");
        when(options.param(2)).thenReturn("L");
        when(options.param(3)).thenReturn("L");

        CharSequence result = helper.apply("1234567890", options);

        assertEquals("67890", result);
    }

    @Test
    public void testApply_ValueLessThanLength_WithRightAlign_ShouldPadEnd() throws IOException {
        when(options.param(0)).thenReturn("10");
        when(options.param(1)).thenReturn(" ");
        when(options.param(2)).thenReturn("R");
        when(options.param(3)).thenReturn("L");

        CharSequence result = helper.apply("12345", options);

        assertEquals("12345     ", result);
    }
}