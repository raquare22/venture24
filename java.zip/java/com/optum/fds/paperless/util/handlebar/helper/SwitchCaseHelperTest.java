package com.optum.fds.paperless.util.handlebar.helper;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;

import com.github.jknack.handlebars.Options;
import com.optum.fds.paperless.util.handlebar.helper.pojo.SwitchCase;

public class SwitchCaseHelperTest {

    private SwitchCaseHelper switchCaseHelper;
    private SwitchCaseHelper.Case caseHelper;
    private SwitchCaseHelper.Default defaultHelper;
    private SwitchCase switchCase;
    private Options options;

    @Before
    public void setUp() {
        switchCase = new SwitchCase();
        switchCaseHelper = new SwitchCaseHelper(switchCase);
        caseHelper = new SwitchCaseHelper.Case(switchCase);
        defaultHelper = new SwitchCaseHelper.Default(switchCase);
        options = mock(Options.class);
    }

    @Test
    public void testSwitchCaseHelperApply() throws IOException {
        when(options.fn()).thenReturn("fnResult");

        CharSequence result = switchCaseHelper.apply("value", options);
        assertEquals("fnResult", result);
        assertEquals("value", switchCase.getValue());
        assertEquals(false, switchCase.isSwitchBreak());
    }

    @Test
    public void testCaseHelperApply_MatchingValue() throws IOException {
        when(options.fn(caseHelper)).thenReturn("fnResult");
        when(options.inverse()).thenReturn("inverseResult");

        switchCase.setValue("value");
        CharSequence result = caseHelper.apply("value", options);
        assertEquals("fnResult", result);
        assertEquals(true, switchCase.isSwitchBreak());
    }

    @Test
    public void testCaseHelperApply_NonMatchingValue() throws IOException {
        when(options.inverse()).thenReturn("inverseResult");

        switchCase.setValue("value");
        CharSequence result = caseHelper.apply("nonMatchingValue", options);
        assertEquals("inverseResult", result);
        assertEquals(false, switchCase.isSwitchBreak());
    }

    @Test
    public void testDefaultHelperApply_SwitchBreakFalse() throws IOException {
        when(options.fn()).thenReturn("fnResult");
        when(options.inverse()).thenReturn("inverseResult");

        switchCase.setSwitchBreak(false);
        CharSequence result = defaultHelper.apply(null, options);
        assertEquals("fnResult", result);
    }

    @Test
    public void testDefaultHelperApply_SwitchBreakTrue() throws IOException {
        when(options.inverse()).thenReturn("inverseResult");

        switchCase.setSwitchBreak(true);
        CharSequence result = defaultHelper.apply(null, options);
        assertEquals("inverseResult", result);
    }

    @Test
    public void testCaseHelperApply_WhenSwitchBreakAlreadyTrue_ShouldReturnInverse() throws IOException {
        when(options.inverse()).thenReturn("inverseResult");

        switchCase.setSwitchBreak(true);
        switchCase.setValue("value");

        CharSequence result = caseHelper.apply("value", options);

        assertEquals("inverseResult", result);
        assertTrue(switchCase.isSwitchBreak());
    }
}