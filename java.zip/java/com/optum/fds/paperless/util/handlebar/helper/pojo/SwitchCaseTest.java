package com.optum.fds.paperless.util.handlebar.helper.pojo;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class SwitchCaseTest {

    private SwitchCase switchCase;

    @Before
    public void setUp() {
        switchCase = new SwitchCase();
    }

    @Test
    public void testGetValue() {
        Object value = "testValue";
        switchCase.setValue(value);
        assertEquals(value, switchCase.getValue());
    }

    @Test
    public void testIsSwitchBreak() {
        switchCase.setSwitchBreak(true);
        assertTrue(switchCase.isSwitchBreak());
    }

    @Test
    public void testSetValue() {
        Object value = "testValue";
        switchCase.setValue(value);
        assertEquals(value, switchCase.getValue());
    }

    @Test
    public void testSetSwitchBreak() {
        switchCase.setSwitchBreak(true);
        assertTrue(switchCase.isSwitchBreak());
    }
}