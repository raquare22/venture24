package com.optum.fds.paperless.util;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.Test;
import org.mockito.Mockito;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;

public class UtilitiesTest {
	@Test
	@UserStory(references = "Us24638")
	@RallyTestCase(references = "TC29188")
	public void testIsZipSlip() throws Exception {
		Configurator.setAllLevels("", Level.DEBUG);
		File destinationFile = new File("/junk/2b489bb4aa784f198aaeaba1e763a06f/10403/ProvPRA_sprs_FACETSCSP_UHGCSP_20220804-041001_1_4");
		boolean zipSlip = Utilities.isZipSlip(destinationFile);
		assertFalse(zipSlip);

		destinationFile = new File("../junk/2b489bb4aa784f198aaeaba1e763a06f/10403/ProvPRA_sprs_FACETSCSP_UHGCSP_20220804-041001_1_4");
		zipSlip = Utilities.isZipSlip(destinationFile);
		assertTrue(zipSlip);

		destinationFile = new File("../../junk/2b489bb4aa784f198aaeaba1e763a06f/10403/ProvPRA_sprs_FACETSCSP_UHGCSP_20220804-041001_1_4");
		zipSlip = Utilities.isZipSlip(destinationFile);
		assertTrue(zipSlip);

		
	}
	
	
	@Test
	public void testValidateProviderEmail () {
		// ^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" + "[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9]+)*$
		
		// molleti.varajyothi@veradigm.com|jonnada.lavanya@veradigm.com
//		String providerEmail = "molleti.varajyothi@veradigm.com|jonnada.lavanya@veradigm.com";
		
		String providerEmail = "jenny.j.wang@optum.com";
		
		assertTrue(Utilities.validateProviderEmail(providerEmail));
		
		providerEmail = "molleti.varajyothi@veradigm.com|jonnada.lavanya@veradigm.com";
		assertFalse(Utilities.validateProviderEmail(providerEmail));
	}

    @Test
    public void testDeleteWorkingDirectoryString_whenPathIsNull_shouldHitCatchAndReturnTrue() {
        boolean result = Utilities.deleteWorkingDirectory((String) null);

        assertTrue(result);
    }

    @Test
    public void testDeleteWorkingDirectoryPath_whenFileDeleteFails_shouldReturnFalse() throws Exception {
        Path workingDirectory = Mockito.mock(Path.class);
        Path filePath = Mockito.mock(Path.class);
        File file = Mockito.mock(File.class);

        Mockito.when(filePath.toFile()).thenReturn(file);
        Mockito.when(file.isDirectory()).thenReturn(false);

        try (org.mockito.MockedStatic<Files> filesMock = Mockito.mockStatic(Files.class, Mockito.CALLS_REAL_METHODS)) {
            filesMock.when(() -> Files.walk(workingDirectory, java.nio.file.FileVisitOption.FOLLOW_LINKS))
                    .thenReturn(java.util.stream.Stream.of(filePath));
            filesMock.when(() -> Files.delete(filePath))
                    .thenThrow(new IOException("delete failed"));

            boolean result = Utilities.deleteWorkingDirectory(workingDirectory);

            assertFalse(result);
        }
    }

    @Test
    public void testCheckAndCreateLockFile_whenLockAlreadyExists_returnsTrue() throws Exception {
        Path tempDir = Files.createTempDirectory("lock-exists");
        try {
            Files.createFile(tempDir.resolve("locked.txt"));

            boolean result = Utilities.checkAndCreateLockFile(tempDir.toString());

            assertTrue(result);
            assertTrue(Files.exists(tempDir.resolve("locked.txt")));
        } finally {
            deleteRecursively(tempDir);
        }
    }

    @Test
    public void testCheckAndCreateLockFile_whenLockDoesNotExist_createsItAndReturnsFalse() throws Exception {
        Path tempDir = Files.createTempDirectory("lock-create");
        try {
            boolean result = Utilities.checkAndCreateLockFile(tempDir.toString());

            assertFalse(result);
            assertTrue(Files.exists(tempDir.resolve("locked.txt")));
        } finally {
            deleteRecursively(tempDir);
        }
    }

    @Test
    public void testTouch_whenFileDoesNotExist_createsFileAndReturnsTrue() throws Exception {
        Path tempDir = Files.createTempDirectory("touch-new");
        try {
            File file = tempDir.resolve("new-file.txt").toFile();

            boolean result = Utilities.touch(file);

            assertTrue(result);
            assertTrue(file.exists());
        } finally {
            deleteRecursively(tempDir);
        }
    }

    @Test
    public void testTouch_whenFileAlreadyExists_returnsFalse() throws Exception {
        Path tempDir = Files.createTempDirectory("touch-existing");
        try {
            File file = tempDir.resolve("existing-file.txt").toFile();
            assertTrue(file.createNewFile());

            boolean result = Utilities.touch(file);

            assertFalse(result);
            assertTrue(file.exists());
        } finally {
            deleteRecursively(tempDir);
        }
    }

    @Test
    public void testExpandFile_whenLockFileAlreadyExists_returnsTrueWithoutExtracting() throws Exception {
        Path zipFile = createZipFile("inside.txt", "hello");
        Path destination = Files.createTempDirectory("expand-locked");
        try {
            Files.createFile(destination.resolve("locked.txt"));

            boolean result = Utilities.expandFile(zipFile, destination);

            assertTrue(result);
            assertFalse(Files.exists(destination.resolve("inside.txt")));
        } finally {
            deleteRecursively(zipFile);
            deleteRecursively(destination);
        }
    }

    @Test
    public void testExpandFile_whenZipIsValid_extractsFileAndReturnsFalse() throws Exception {
        Path zipFile = createZipFile("inside.txt", "hello-world");
        Path destination = Files.createTempDirectory("expand-success");
        try {
            boolean result = Utilities.expandFile(zipFile, destination);

            assertFalse(result);
            assertTrue(Files.exists(destination.resolve("inside.txt")));
            assertEquals(
                    "hello-world",
                    new String(Files.readAllBytes(destination.resolve("inside.txt")), StandardCharsets.UTF_8)
            );
            assertTrue(Files.exists(destination.resolve("locked.txt")));
        } finally {
            deleteRecursively(zipFile);
            deleteRecursively(destination);
        }
    }

    @Test(expected = IOException.class)
    public void testExpandFile_whenZipEntryIsOutsideTargetDir_throwsIOException() throws Exception {
        Path zipFile = createZipFile("../evil.txt", "bad");
        Path destination = Files.createTempDirectory("expand-zip-slip");
        try {
            Utilities.expandFile(zipFile, destination);
        } finally {
            deleteRecursively(zipFile);
            deleteRecursively(destination);
        }
    }

    @Test
    public void testWriteFile_whenDestinationIsZipSlip_returnsWithoutWriting() throws Exception {
        ZipInputStream zipInputStream = new ZipInputStream(new ByteArrayInputStream(new byte[0]));
        File destinationFile = new File("../evil.txt");

        Utilities.writeFile(zipInputStream, destinationFile);

        assertFalse(destinationFile.exists());
    }

    @Test
    public void testWriteFile_whenOutputStreamCreationFails_hitsExceptionCatch() throws Exception {
        byte[] zipBytes = createZipBytes("file.txt", "content");
        ZipInputStream zipInputStream = new ZipInputStream(new ByteArrayInputStream(zipBytes));
        assertNotNull(zipInputStream.getNextEntry());

        Path tempDir = Files.createTempDirectory("write-exception");
        try {
            File destinationFile = tempDir.resolve("missing-parent").resolve("file.txt").toFile();

            Utilities.writeFile(zipInputStream, destinationFile);

            assertFalse(destinationFile.exists());
        } finally {
            deleteRecursively(tempDir);
        }
    }

    private Path createZipFile(String entryName, String content) throws IOException {
        Path zipFile = Files.createTempFile("utilities-", ".zip");
        try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(zipFile))) {
            zos.putNextEntry(new ZipEntry(entryName));
            zos.write(content.getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();
        }
        return zipFile;
    }

    private byte[] createZipBytes(String entryName, String content) throws IOException {
        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(baos)) {
            zos.putNextEntry(new ZipEntry(entryName));
            zos.write(content.getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();
        }
        return baos.toByteArray();
    }

    private void deleteRecursively(Path path) throws IOException {
        if (path == null || !Files.exists(path)) {
            return;
        }

        if (Files.isDirectory(path)) {
            Files.walk(path)
                    .sorted(Comparator.reverseOrder())
                    .forEach(p -> {
                        try {
                            Files.deleteIfExists(p);
                        } catch (IOException ignored) {
                        }
                    });
        } else {
            Files.deleteIfExists(path);
        }
    }

    @Test
    public void testIsZipSlip_whenGetCanonicalPathsThrowsIOException_returnsTrue() throws Exception {
        File destinationFile = new File("test-file.txt");

        try (org.mockito.MockedStatic<Utilities> utilitiesMock =
                     Mockito.mockStatic(Utilities.class, Mockito.CALLS_REAL_METHODS)) {

            utilitiesMock.when(() -> Utilities.getCanonicalPaths(Mockito.any(File.class)))
                    .thenThrow(new IOException("canonical path failure"));

            boolean result = Utilities.isZipSlip(destinationFile);

            assertTrue(result);
        }
    }

    @Test
    public void testGetZipEntryInfo_whenZipEntryIsNotNull_returnsNameAndMethod() {
        ZipEntry zipEntry = new ZipEntry("inside.txt");
        zipEntry.setMethod(ZipEntry.DEFLATED);

        String result = Utilities.getZipEntryInfo(zipEntry);

        assertEquals("name=inside.txt, method=" + ZipEntry.DEFLATED, result);
    }

    @Test
    public void testGetZipEntryInfo_whenZipEntryIsNull_returnsNULL() {
        String result = Utilities.getZipEntryInfo(null);

        assertEquals("NULL", result);
    }
}
