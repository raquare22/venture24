package com.optum.fds.paperless.util;

import static org.junit.Assert.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.net.URI;
import java.net.URISyntaxException;

import com.optum.fds.paperless.mongo.DocumentAttachmentDoc360;
import com.optum.fds.paperless.mongo.FDSCloudDocument;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.optum.fds.paperless.java.delegate.IdentifyDocuments;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.provider.pojo.RequestBody;
import com.optum.fds.paperless.provider.pojo.RequestHeader;

@RunWith(MockitoJUnitRunner.Silent.class) 
public class RetryUtilTest {

	
	@InjectMocks
	RetryUtil retryUtil;
	
	
	@Mock
	RestTemplate restTemplate;
	
	@Test
	public void testRetryFDSCloudCall() throws URISyntaxException, InterruptedException {
		
		DocumentAttachmentMetaData attachment = new DocumentAttachmentMetaData();
		attachment.setUrl("http://test");
		attachment.setUrlToken("abc123");
		attachment.setAttachmentId("123456");
		ResponseEntity<DocumentAttachmentMetaData> attachmentResponse = new ResponseEntity<>(attachment, HttpStatus.OK);
		when(restTemplate.exchange(Mockito.any(URI.class), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(DocumentAttachmentMetaData.class))).thenReturn(attachmentResponse);
		
		URI uri = new URI("http://test");
		
		ResponseEntity<DocumentAttachmentMetaData> response = retryUtil.retryFDSCloudCall(uri, "token123", restTemplate);
		
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		
	}
	
//	@Test
//	public void testGetAttachment() throws URISyntaxException, InterruptedException {
//		ResponseEntity<byte[]> byteResponse = new ResponseEntity<>(new byte[] {}, HttpStatus.OK);
//		when(restTemplate.exchange(Mockito.any(String.class), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(byte[].class))).thenReturn(byteResponse);
//		
//		String token = "abc123";
//		URI uri = new URI("http://test");
//		
//		ResponseEntity<byte[]> response = retryUtil.retryGetAttachment(uri, token, restTemplate);
//		
//		assertNotNull(response);
//	}
	
	
	@Test
	public void testRetryFDSCloudCallException() throws URISyntaxException, InterruptedException {
		when(restTemplate.exchange(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.eq(DocumentAttachmentMetaData.class) ) )
			.thenThrow(new HttpServerErrorException(HttpStatusCode.valueOf(504)));
		
		URI uri = new URI("http://test");
		
		ResponseEntity<DocumentAttachmentMetaData> response = retryUtil.retryFDSCloudCall(uri, "token123", restTemplate);
		
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}
	
//	@Test(expected=Exception.class)
//	public void testGetAttachmentException() throws URISyntaxException, InterruptedException {
//		when(restTemplate.exchange(Mockito.any(String.class), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(byte[].class))).thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Internal server error"));
//		String token = "abc123";
//		URI uri = new URI("http://test");
//		
//		retryUtil.retryGetAttachment(uri, token, restTemplate);
//		
//	}
	
	@Test(expected=Exception.class)
	public void testRetryFDSCloudCallInterruptedException() throws URISyntaxException, InterruptedException {
		when(restTemplate.exchange(Mockito.any(URI.class), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(DocumentAttachmentMetaData.class))).thenThrow(InterruptedException.class);
		
		URI uri = new URI("http://test");
		
		retryUtil.retryFDSCloudCall(uri, "token123", restTemplate);
	}
	
//	@Test(expected=Exception.class)
//	public void testGetAttachmentInterruptedException() throws URISyntaxException, InterruptedException {
//		when(restTemplate.exchange(Mockito.any(URI.class), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(byte[].class))).thenThrow(InterruptedException.class);
//		String token = "abc123";
//		URI uri = new URI("http://test");
//		
//		retryUtil.retryGetAttachment(uri, token, restTemplate);
//	}

	@Test
	public void testRetryFDSCloudCall_Success() throws URISyntaxException, InterruptedException {
		URI uri = new URI("http://test");
		DocumentAttachmentMetaData attachment = new DocumentAttachmentMetaData();
		attachment.setUrl("http://test");
		ResponseEntity<DocumentAttachmentMetaData> responseEntity = new ResponseEntity<>(attachment, HttpStatus.OK);

		when(restTemplate.exchange(Mockito.eq(uri), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(DocumentAttachmentMetaData.class)))
				.thenReturn(responseEntity);

		ResponseEntity<DocumentAttachmentMetaData> response = retryUtil.retryFDSCloudCall(uri, "token123", restTemplate);

		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("http://test", response.getBody().getUrl());
	}

	@Test
	public void testRetryFDSCloudCall_Exception() throws URISyntaxException, InterruptedException {
		URI uri = new URI("http://test");

		when(restTemplate.exchange(Mockito.eq(uri), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(DocumentAttachmentMetaData.class)))
				.thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

		ResponseEntity<DocumentAttachmentMetaData> response = retryUtil.retryFDSCloudCall(uri, "token123", restTemplate);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@Test
	public void testRetryGetAttachment_Success() throws URISyntaxException, InterruptedException {
		String uri = "http://test";
		ResponseEntity<byte[]> responseEntity = new ResponseEntity<>(new byte[]{1, 2, 3}, HttpStatus.OK);

		when(restTemplate.exchange(Mockito.eq(uri), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(byte[].class)))
				.thenReturn(responseEntity);

		ResponseEntity<byte[]> response = retryUtil.retryGetAttachment(uri, "token123", restTemplate);

		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(3, response.getBody().length);
	}
	@Test
	public void testRetryFDSCloudGetCall_Success() throws URISyntaxException, InterruptedException {
		URI uri = new URI("http://test");
		FDSCloudDocument document = new FDSCloudDocument();
		document.setDocumentId("doc123");
		ResponseEntity<FDSCloudDocument> responseEntity = new ResponseEntity<>(document, HttpStatus.OK);

		when(restTemplate.exchange(Mockito.eq(uri), Mockito.eq(HttpMethod.GET), Mockito.any(), Mockito.eq(FDSCloudDocument.class)))
				.thenReturn(responseEntity);

		ResponseEntity<FDSCloudDocument> response = retryUtil.retryFDSCloudGetCall(uri, "token123", restTemplate);

		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("doc123", response.getBody().getDocumentId());
	}

    @Test
    public void testRetryGetAttachment_HttpStatusCodeExceptionNonRetryable_ReturnsErrorResponse()
            throws InterruptedException, URISyntaxException {

        String awsUri = "http://test";
        String token = "token123";

        when(restTemplate.exchange(
                Mockito.eq(awsUri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(byte[].class)))
                .thenThrow(new org.springframework.web.client.HttpClientErrorException(HttpStatus.NOT_FOUND, "Not Found"));

        ResponseEntity<byte[]> response = retryUtil.retryGetAttachment(awsUri, token, restTemplate);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
    }

    @Test
    public void testRetryGetAttachment_OutOfRetriesException_ReturnsInternalServerError()
            throws InterruptedException, URISyntaxException {

        String awsUri = "http://test";
        String token = "token123";

        when(restTemplate.exchange(
                Mockito.eq(awsUri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(byte[].class)))
                .thenThrow(new HttpServerErrorException(HttpStatus.GATEWAY_TIMEOUT));

        ResponseEntity<byte[]> response = retryUtil.retryGetAttachment(awsUri, token, restTemplate);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void testRetryFDSCloudCall_HttpStatusCodeExceptionNonRetryable_ReturnsErrorResponse()
            throws URISyntaxException, InterruptedException {

        URI uri = new URI("http://test");

        when(restTemplate.exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentMetaData.class)))
                .thenThrow(new org.springframework.web.client.HttpClientErrorException(
                        HttpStatus.NOT_FOUND, "Not Found"));

        ResponseEntity<DocumentAttachmentMetaData> response =
                retryUtil.retryFDSCloudCall(uri, "token123", restTemplate);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
    }

    @Test
    public void testRetryDoc360Call_Success() throws Exception {
        URI uri = new URI("http://test");
        String accessToken = "token123";
        String upstreamEnv = "dev";

        DocumentAttachmentDoc360 body = new DocumentAttachmentDoc360();
        ResponseEntity<DocumentAttachmentDoc360> okResponse =
                new ResponseEntity<>(body, HttpStatus.OK);

        when(restTemplate.exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentDoc360.class)))
                .thenReturn(okResponse);

        ResponseEntity<DocumentAttachmentDoc360> response =
                retryUtil.retryDoc360Call(uri, accessToken, restTemplate, upstreamEnv);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(body, response.getBody());

        verify(restTemplate, Mockito.times(1)).exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentDoc360.class));
    }

    @Test
    public void testRetryDoc360Call_RetryableHttpStatusCodeException_ThenSuccess() throws Exception {
        URI uri = new URI("http://test");
        String accessToken = "token123";
        String upstreamEnv = "dev";

        DocumentAttachmentDoc360 body = new DocumentAttachmentDoc360();
        ResponseEntity<DocumentAttachmentDoc360> okResponse =
                new ResponseEntity<>(body, HttpStatus.OK);

        when(restTemplate.exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentDoc360.class)))
                .thenThrow(new HttpServerErrorException(HttpStatus.GATEWAY_TIMEOUT))
                .thenReturn(okResponse);

        ResponseEntity<DocumentAttachmentDoc360> response =
                retryUtil.retryDoc360Call(uri, accessToken, restTemplate, upstreamEnv);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertSame(body, response.getBody());

        verify(restTemplate, Mockito.times(2)).exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentDoc360.class));
    }

    @Test
    public void testRetryDoc360Call_NonRetryableHttpStatusCodeException_ReturnsErrorResponse() throws Exception {
        URI uri = new URI("http://test");
        String accessToken = "token123";
        String upstreamEnv = "dev";

        when(restTemplate.exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentDoc360.class)))
                .thenThrow(new org.springframework.web.client.HttpClientErrorException(
                        HttpStatus.BAD_REQUEST, "Bad Request"));

        ResponseEntity<DocumentAttachmentDoc360> response =
                retryUtil.retryDoc360Call(uri, accessToken, restTemplate, upstreamEnv);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNull(response.getBody());

        verify(restTemplate, Mockito.times(1)).exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentDoc360.class));
    }

    @Test
    public void testRetryDoc360Call_OutOfRetries_ReturnsInternalServerError() throws Exception {
        URI uri = new URI("http://test");
        String accessToken = "token123";
        String upstreamEnv = "dev";

        when(restTemplate.exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentDoc360.class)))
                .thenThrow(new HttpServerErrorException(HttpStatus.GATEWAY_TIMEOUT));

        ResponseEntity<DocumentAttachmentDoc360> response =
                retryUtil.retryDoc360Call(uri, accessToken, restTemplate, upstreamEnv);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNull(response.getBody());

        verify(restTemplate, Mockito.times(4)).exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentDoc360.class));
    }

    @Test
    public void testRetryDoc360Call_whenHttpStatusCodeExceptionIsNonRetryable_shouldReturnErrorResponse() throws Exception {
        URI uri = new URI("http://test");
        String accessToken = "token123";
        String upstreamEnv = "dev";

        when(restTemplate.exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentDoc360.class)))
                .thenThrow(new org.springframework.web.client.HttpClientErrorException(
                        HttpStatus.BAD_REQUEST, "Bad Request"));

        ResponseEntity<DocumentAttachmentDoc360> response =
                retryUtil.retryDoc360Call(uri, accessToken, restTemplate, upstreamEnv);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNull(response.getBody());

        verify(restTemplate, Mockito.times(1)).exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentDoc360.class));
    }

    @Test
    public void testRetryDoc360Call_whenRetryableHttpStatusCodeExceptionExhaustsRetries_shouldReturnInternalServerError() throws Exception {
        URI uri = new URI("http://test");
        String accessToken = "token123";
        String upstreamEnv = "dev";

        when(restTemplate.exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentDoc360.class)))
                .thenThrow(new HttpServerErrorException(HttpStatus.GATEWAY_TIMEOUT));

        ResponseEntity<DocumentAttachmentDoc360> response =
                retryUtil.retryDoc360Call(uri, accessToken, restTemplate, upstreamEnv);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNull(response.getBody());

        verify(restTemplate, Mockito.times(4)).exchange(
                Mockito.eq(uri),
                Mockito.eq(HttpMethod.GET),
                Mockito.any(),
                Mockito.eq(DocumentAttachmentDoc360.class));
    }
}
