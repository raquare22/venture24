package com.optum.fds.paperless.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringUtilsTest {

    @Test
    public void testFormat() {
        // Test with a valid array of strings
        String[] input = {"Hello", "World", "!"};
        String expected = "Hello World !";
        assertEquals(expected, StringUtils.format(input));

        // Test with a single element array
        String[] singleInput = {"Hello"};
        String singleExpected = "Hello";
        assertEquals(singleExpected, StringUtils.format(singleInput));

        // Test with an empty array
        String[] emptyInput = {};
        String emptyExpected = "";
        assertEquals(emptyExpected, StringUtils.format(emptyInput));
    }

    @Test
    public void testIsNullOrEmpty() {
        // Test with a null string
        assertTrue(StringUtils.isNullOrEmpty(null));

        // Test with an empty string
        assertTrue(StringUtils.isNullOrEmpty(""));

        // Test with a string containing only spaces
        assertTrue(StringUtils.isNullOrEmpty("   "));

        // Test with a valid non-empty string
        assertFalse(StringUtils.isNullOrEmpty("Hello"));
    }
}