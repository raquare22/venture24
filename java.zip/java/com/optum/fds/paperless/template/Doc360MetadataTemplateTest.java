package com.optum.fds.paperless.template;

import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.impl.Doc360MetadataTemplate;
import org.junit.Assert;
import org.junit.Test;

import java.util.Map;

public class Doc360MetadataTemplateTest {
	
    @Test
    public void testTemplate() throws Exception {
        var metadata = getMetadata();
        String output = TemplateFactory.getInstance(Templates.DOC360_METADATA_TEMPLATE.getTemplate()).convertWithTemplate(metadata);
        System.out.println(output);
        String expected = "{\"u_category\" : \"Claim\",\n" +
                " \"u_file_desc\" : \"\",\n" +
                " \"u_file_path\" : \"Commercial/Additional Info Needed\",\n" +
                " \"u_email_alert_req\" : \"Y\",\n" +
                " \"u_tin\" : \"1234567\",\n" +
                " \"u_sub_category\" : \"C1\",\n" +
                " \"u_mpin\" : \"1234567\",\n" +
                " \"u_privilege\" : \"\",\n" +
                " \"u_trail_id\" : \"\",\n" +
                " \"u_filename\" : \"\",\n" +
                " \"u_expiry_dt\" : \"2023-07-19T12:38:43.204Z\",\n" +
                " \"u_doc_creation_dt\" : \"2022-01-05T02:17:29.000Z\"}";
        Assert.assertEquals(expected, output);
    }

    public org.bson.Document getMetadataCSPPRA() throws Exception {
    	org.bson.Document metadata = new org.bson.Document();
    	metadata.put("createApplication", "CSP-PRA");
    	metadata.put("tin", "1234567");
    	metadata.put("mpin", "1234567");
    	metadata.put("createdDate", "2022-01-05T02:17:29.000Z");
    	metadata.put("expiryDate", "2023-07-19T12:38:43.204Z");
    	metadata.put("category", "PRA");
    	metadata.put("subCategory", "C1");
    	metadata.put("filePath", "Commercial/Additional Info Needed");
    	metadata.put("emailAlertReq", "Y");
    	metadata.put("policyNumber", "9F5633");
    	metadata.put("physicianName", "Jane Doe MD");
    	metadata.put("memberName", "John Doe");
    	metadata.put("multClaimNumber", "|CV61054877|CV61054877");
        metadata.put("multMemberId", "943818795");    	
        metadata.put("Ind_835", true);    	
    	return metadata;
    }
    
    public org.bson.Document getMetadata() throws Exception {
    	org.bson.Document metadata = new org.bson.Document();
    	metadata.put("createApplication", "ELGS");
    	metadata.put("tin", "1234567");
    	metadata.put("mpin", "1234567");
    	metadata.put("createdDate", "2022-01-05T02:17:29.000Z");
    	metadata.put("expiryDate", "2023-07-19T12:38:43.204Z");
    	metadata.put("category", "Claim");
    	metadata.put("subCategory", "C1");
    	metadata.put("filePath", "Commercial/Additional Info Needed");
    	metadata.put("emailAlertReq", "Y");
    	metadata.put("policyNumber", "9F5633");
    	metadata.put("providerName", "Jane Doe MD");
    	metadata.put("PatientName", "John Doe");
    	metadata.put("patientAccountNumber", "943818795");
    	metadata.put("memberName", "Jhon Doe");
    	metadata.put("claimNumber", "CV61054877");
        metadata.put("MemberAltID", "943818795");    	
    	return metadata;
    }

	@Test
	public void testFilterDuplicates() {
		Doc360MetadataTemplate template = new Doc360MetadataTemplate();

		String input = "|value1|value2|value1|value3||value2|";
		String expectedOutput = "|value1|value2|value3|";

		String actualOutput = template.filterDuplicates(input);
        System.out.println(actualOutput);
		Assert.assertEquals("Filtered output does not match expected result", expectedOutput, actualOutput);
	}
	@Test
	public void testFilterDuplicatesWithEmptyInput() {
        Doc360MetadataTemplate template = new Doc360MetadataTemplate();

		String input = "";
		String expectedOutput = "";

		String actualOutput = template.filterDuplicates(input);

		Assert.assertEquals("Filtered output does not match expected result for empty input", expectedOutput, actualOutput);
	}
	@Test
	public void testFilterDuplicatesWithOnlyDelimiters() {
        Doc360MetadataTemplate template = new Doc360MetadataTemplate();

		String input = "|||||";
		String expectedOutput = "||";

		String actualOutput = template.filterDuplicates(input);

		Assert.assertEquals("Filtered output does not match expected result for input with only delimiters", expectedOutput, actualOutput);
	}
	@Test
	public void testFilterDuplicatesWithUniqueValues() {
        Doc360MetadataTemplate template = new Doc360MetadataTemplate();

		String input = "|value1|value2|value3|value4|";
		String expectedOutput = "|value1|value2|value3|value4|";

		String actualOutput = template.filterDuplicates(input);

		Assert.assertEquals("Filtered output does not match expected result for input with unique values", expectedOutput, actualOutput);
	}
	@Test
	public void testFilterDuplicatesWithSingleValue() {
        Doc360MetadataTemplate template = new Doc360MetadataTemplate();

		String input = "|value1|";
		String expectedOutput = "|value1|";

		String actualOutput = template.filterDuplicates(input);

		Assert.assertEquals("Filtered output does not match expected result for input with a single value", expectedOutput, actualOutput);
	}
	@Test
	public void testGetMetadataCSPPRA() throws Exception {
		Doc360MetadataTemplateTest testInstance = new Doc360MetadataTemplateTest();

		org.bson.Document metadata = testInstance.getMetadataCSPPRA();

		Assert.assertNotNull("Metadata should not be null", metadata);
		Assert.assertEquals("CSP-PRA", metadata.getString("createApplication"));
		Assert.assertEquals("1234567", metadata.getString("tin"));
		Assert.assertEquals("1234567", metadata.getString("mpin"));
		Assert.assertEquals("2022-01-05T02:17:29.000Z", metadata.getString("createdDate"));
		Assert.assertEquals("2023-07-19T12:38:43.204Z", metadata.getString("expiryDate"));
		Assert.assertEquals("PRA", metadata.getString("category"));
		Assert.assertEquals("C1", metadata.getString("subCategory"));
		Assert.assertEquals("Commercial/Additional Info Needed", metadata.getString("filePath"));
		Assert.assertEquals("Y", metadata.getString("emailAlertReq"));
		Assert.assertEquals("9F5633", metadata.getString("policyNumber"));
		Assert.assertEquals("Jane Doe MD", metadata.getString("physicianName"));
		Assert.assertEquals("John Doe", metadata.getString("memberName"));
		Assert.assertTrue("Ind_835 should be true", metadata.getBoolean("Ind_835"));
	}
	@Test
	public void testGetMetadata() throws Exception {
		Doc360MetadataTemplateTest testInstance = new Doc360MetadataTemplateTest();

		org.bson.Document metadata = testInstance.getMetadata();

		Assert.assertNotNull("Metadata should not be null", metadata);
		Assert.assertEquals("ELGS", metadata.getString("createApplication"));
		Assert.assertEquals("1234567", metadata.getString("tin"));
		Assert.assertEquals("1234567", metadata.getString("mpin"));
		Assert.assertEquals("2022-01-05T02:17:29.000Z", metadata.getString("createdDate"));
		Assert.assertEquals("2023-07-19T12:38:43.204Z", metadata.getString("expiryDate"));
		Assert.assertEquals("Claim", metadata.getString("category"));
		Assert.assertEquals("C1", metadata.getString("subCategory"));
		Assert.assertEquals("Commercial/Additional Info Needed", metadata.getString("filePath"));
		Assert.assertEquals("Y", metadata.getString("emailAlertReq"));
		Assert.assertEquals("9F5633", metadata.getString("policyNumber"));
		Assert.assertEquals("Jane Doe MD", metadata.getString("providerName"));
		Assert.assertEquals("John Doe", metadata.getString("PatientName"));
		Assert.assertEquals("943818795", metadata.getString("patientAccountNumber"));
		Assert.assertEquals("Jhon Doe", metadata.getString("memberName"));
		Assert.assertEquals("CV61054877", metadata.getString("claimNumber"));
		Assert.assertEquals("943818795", metadata.getString("MemberAltID"));
	}
	@Test
	public void testFilterDuplicatesWithDuplicateDelimiters() {
        Doc360MetadataTemplate template = new Doc360MetadataTemplate();

		String input = "|value1||value2|||value1|value3||";
		String expectedOutput = "|value1|value2|value3|";

		String actualOutput = template.filterDuplicates(input);
        System.out.println(actualOutput);
		Assert.assertEquals("Filtered output does not match expected result for input with duplicate delimiters", expectedOutput, actualOutput);
	}
	@Test
	public void testConvertWithTemplateFromFilePath() {
        Doc360MetadataTemplate template = new Doc360MetadataTemplate();

		String filePath = "some/file/path";
		String result = template.convertWithTemplateFromFilePath(filePath);

		Assert.assertNull("Expected null as the method is not implemented", result);
	}
	@Test
	public void testFilterDuplicatesWithNullInput() {
        Doc360MetadataTemplate template = new Doc360MetadataTemplate();

		String input = null;
		String expectedOutput = "";

		String actualOutput = template.filterDuplicates(input);

		Assert.assertEquals("Filtered output does not match expected result for null input", expectedOutput, actualOutput);
	}
	@Test
	public void testCreateSearchTermsMapForMACESS() {
		Doc360MetadataTemplate template = new Doc360MetadataTemplate();

		org.bson.Document metadata = new org.bson.Document();
		metadata.put("createApplication", "MACESS");
		metadata.put("providerName", "Dr. John Doe");
		metadata.put("claimNumber", "1000");
		metadata.put("patientAccountNumber", "12345");

		Map<String, String> result = template.createMetadataMap(metadata);
        System.out.println(result);

		Assert.assertEquals("Dr. John Doe", result.get("u_physician_nm"));
		Assert.assertEquals("1000", result.get("u_clm_nbr"));
		Assert.assertNull(result.get("checkId"));
	}
	@Test
	public void testCreateSearchTermsMapForLetGen() {
        Doc360MetadataTemplate template = new Doc360MetadataTemplate();

		org.bson.Document metadata = new org.bson.Document();
		metadata.put("createApplication", "LETGEN");
		metadata.put("memberName", "Jane Doe");
		metadata.put("claimNumber", "CL123456");
		metadata.put("memberId", "987654321");

		Map<String, String> result = template.createMetadataMap(metadata);

        System.out.println(result);

		Assert.assertEquals("CL123456", result.get("u_clm_nbr"));
		Assert.assertEquals("987654321", result.get("u_mbr_id"));
	}
}
