package com.optum.fds.paperless.template;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import org.junit.Assert;
import org.junit.Test;

public class CSPClaimsResponseTemplateTest {

    @Test
    public void testCSPClaimsResponseTemplate() {
        var jsonFileName = "InputJson/CSPClaimsResponse.json";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.CSP_CLAIMS_RESPONSE.getTemplate())
                .convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        Assert.assertTrue(output.contains("MACESS"));

    }
}
