package com.optum.fds.paperless.template;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.json.JSONException;
import org.junit.Test;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.workflow.constants.Workflow;

public class USPClaimsResponseApiNotifyTest {
	
	@Test
	public void testUSPClaimsApiNotifyTemplate() throws IOException, JSONException
	{
		HashMap<String,Object> apiNotifyMap=new HashMap<>();
		apiNotifyMap.put("zipFileName", "MCb906036b-72ad-4f37-a76c-cb14407f332e");
        apiNotifyMap.put("zipFileCreationDate","12-30-2022");  
        apiNotifyMap.put("successCount",3);
        apiNotifyMap.put("fileName","FDS_Response_Test1_12-30-2022.xml");
        apiNotifyMap.put("fileSize",34567);
        apiNotifyMap.put("itemCount",2);
        
        
        
        
        String output = TemplateFactory.getInstance(Templates.USP_CLAIMS_RESPONSE_API_NOTIFY.getTemplate())
                .convertWithTemplate(apiNotifyMap);
        assertTrue(output.contains("MCb906036b-72ad-4f37-a76c-cb14407f332e"));
	}

}
