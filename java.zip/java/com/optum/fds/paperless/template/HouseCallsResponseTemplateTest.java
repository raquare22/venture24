package com.optum.fds.paperless.template;

import com.optum.fds.paperless.template.java.TemplateFactory;
import org.junit.Assert;
import org.junit.Test;

public class HouseCallsResponseTemplateTest {

    @Test
    public void testHouseCallsResponseTemplate() {
        var jsonFileName = "InputJson/HouseCallsResponse.json";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.HOUSE_CALLS_RESPONSE.getTemplate())
                .convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);

        Assert.assertTrue(output.contains("DateDocumentUploadedtoDocLib"));
        Assert.assertTrue(output.contains("Wed Dec 25 15:30"));
        Assert.assertTrue(output.contains("Wed Dec 25 15:32"));


    }
}
