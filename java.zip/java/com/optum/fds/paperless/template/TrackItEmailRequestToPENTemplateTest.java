package com.optum.fds.paperless.template;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.impl.ADTCNSEmailRequestToPENTemplate;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.io.File;
import java.io.FileWriter;

public class TrackItEmailRequestToPENTemplateTest {

    @Test
    public void testConvertWithTemplateFromString() throws Exception {
        String jsonString = "{\n" +
                "  \"spaceId\": 20702,\n" +
                "  \"metadata\": {\n" +
                "    \"recordID\": \"record123\",\n" +
                "    \"recordLastUpdatedDate\": \"01-20-2026\",\n" +
                "    \"providerEmailId\": \"email@test.com\",\n" +
                "    \"deliveryStatus\": \"deliveryStatus\",\n" +
                "    \"recordsCountList\": [\n" +
                "      {\n" +
                "        \"dailyReconCount\": \"19\",\n" +
                "        \"weeklyReconCount\": \"24\",\n" +
                "        \"dailyPendCount\": \"2\",\n" +
                "        \"weeklyPendCount\": \"23\",\n" +
                "        \"dailyAppealsCount\": \"12\",\n" +
                "        \"weeklyAppealsCount\": \"37\",\n" +
                "        \"tin\": \"123456789\",\n" +
                "        \"providerName\": \"Provider Name\",\n" +
                "        \"corpMpin\": \"123456789\",\n" +
                "        \"dailyPaanAdditionalInfoCount\": \"2\",\n" +
                "        \"dailyPaanAppealsCount\": \"5\",\n" +
                "        \"weeklyPaanAdditionalInfoCount\": \"7\",\n" +
                "        \"weeklyPaanAppealsCount\": \"0\",\n" +
                "        \"dailySmartEditsCount\": \"1\",\n" +
                "        \"actionRequiredPendingClaimsCount\": \"3\",\n" +
                "        \"retryDocumentPendingClaimsCount\": \"0\",\n" +
                "        \"bothPendingClaimsCount\": \"0\",\n" +
                "        \"referralCreatedCount\": \"1\",\n" +
                "        \"referralAboutToExpireCount\": \"14\",\n" +
                "        \"referralBothCount\": \"3\",\n" +
                "        \"dailyDisputeCount\": \"5\",\n" +
                "        \"weeklyDisputeCount\": \"20\",\n" +
                "        \"dailySmartEditsActionRequiredCount\": \"5\",\n" +
                "        \"dailySmartEditsRetryDocCount\": \"6\",\n" +
                "        \"dailyRejectedClaimsActionRequiredCount\": \"37\"\n" +
                "      }\n" +
                "    ]\n" +
                "  }\n" +
                "}";
        String expected =
        		"{\"AppId\" : \"20702\"," +
        		"\"TemplateName\" : \"TrackIt\"," +
        		"\"ProviderEmailId\" : \"email@test.com\"," +
        		"\"providerEmailIdList\" : \"email@test.com\"," +
        		"\"Category\" : \"TrackIt\"," +
        		"\"metadata\": {\"list\": [" +
        		    "{\"CorporateOwnerName\": \"Provider Name\"," +
        		    "\"TaxIDNumber\" : \"XXXXX6789\"," +
        		    "\"CorporateTaxIDOwner\" : \"XXXXX6789\"," +
        		    "\"ProviderName\" : \"Provider Name\"," +
        		    "\"RejectedClaims\" : \"37\"," +
        		    "\"DocumentationEdits\" : \"1\"," +
        		    "\"PriorAuthorizations\" : \"2\"," +
        		    "\"Referrals\" : \"3\"," +
        		    "\"Recons\" : \"24\"," +
        		    "\"PendingClaims\" : \"0\"," +  
        		    "\"PendedTickets\" : \"2\"," +          
        		    "\"PriorAuthAppeals\" : \"5\"," +
        		    "\"ExpiringReferrals\" : \"14\"," +
        		    "\"RecordType\" : \"\"}" +
        		"]}}";


        String output = TemplateFactory.getInstance(Templates.TRACKIT_EMAIL_REQUEST_TO_PEN.getTemplate()).convertWithTemplate(jsonString);
        System.out.println(output);

		String normalizedExpected = expected.replaceAll("\\s+", "");
		String normalizedOutput = output.replaceAll("\\s+", "");

		Assert.assertEquals(normalizedExpected, normalizedOutput);

    }

    @Test
    public void testConvertWithTemplateFromFilePath() throws Exception {
        String expected = "{\"AppId\" : \"20702\",\"TemplateName\" : \"TrackIt\",\"ProviderEmailId\" : \"email@test.com\",\"providerEmailIdList\" : \"email@test.com\",\"Category\" : \"TrackIt\",\"metadata\": {\"list\": [{\"CorporateOwnerName\": \"Provider Name\",\"TaxIDNumber\" : \"XXXXX6789\",\"CorporateTaxIDOwner\" : \"XXXXX6789\",\"ProviderName\" : \"Provider Name\",\"RejectedClaims\" : \"37\",\"DocumentationEdits\" : \"1\",\"PriorAuthorizations\" : \"2\",\"Referrals\" : \"3\", \"Recons\" : \"24\", \"PendingClaims\" : \"0\",\"PendedTickets\" : \"5\",\"PriorAuthAppeals\" : \"5\", \"ExpiringReferrals\" : \"14\", \"RecordType\" : \"\"}]}}";

        var jsonFileName = "InputJson/TrackItEmailRequestToPEN.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.TRACKIT_EMAIL_REQUEST_TO_PEN.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);

        Assert.assertEquals(expected, output);
    }


}
