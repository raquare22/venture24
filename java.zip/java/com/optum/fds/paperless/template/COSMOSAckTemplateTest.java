package com.optum.fds.paperless.template;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.mongo.AckFileBean;
import com.optum.fds.paperless.mongo.FileDetail;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.util.Parser;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class COSMOSAckTemplateTest  {

    @Test
    @RallyTestCase(references = "")
    public void testCOSMOSAckTemplate() throws IOException {

        AckFileBean ackObject = new AckFileBean();
        ackObject.setBatchId("121212");
        ackObject.setCount(4);

        List<FileDetail> fileList = new ArrayList<>();

        FileDetail fileName1 = new FileDetail();
        fileName1.setFileName("Test1.pdf");
        fileName1.setStatus("Success");
        FileDetail fileName2 = new FileDetail();
        fileName2.setFileName("Test2.pdf");
        fileName2.setStatus("Failed");
        FileDetail fileName3 = new FileDetail();
        fileName3.setFileName("Test3.pdf");
        fileName3.setStatus("Success");
        FileDetail fileName4 = new FileDetail();
        fileName4.setFileName("Test4.pdf");
        fileName4.setStatus("Failed");

        fileList.add(fileName1);
        fileList.add(fileName2);
        fileList.add(fileName3);
        fileList.add(fileName4);
        ackObject.setFileList(fileList);

        String json = Parser.toJson(ackObject);
        String output = TemplateFactory.getInstance(Templates.COSMOS_ACK.getTemplate()).convertWithTemplate(json);
        System.out.println(output);

        Assert.assertTrue(output.contains("Test3.pdf"));

    }
}