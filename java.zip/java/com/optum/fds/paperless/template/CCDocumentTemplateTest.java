package com.optum.fds.paperless.template;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import org.junit.Assert;
import org.junit.Test;

public class CCDocumentTemplateTest {

    @Test
    public void testCCDocumentTemplate() {
        var jsonFileName = "csv/CC.csv";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.CC_DOCUMENT_TEMPLATE.getTemplate())
                .convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"Documents\": [{\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"CC\",\"tin\" : \"001160933\",\n"
        		+ "               \"category\" : \"cc1\",\n"
        		+ "               \"corporateMpin\" : \"351913875\",\n"
        		+ "               \"templateEmailIndicator\" : \"cc1\"}},\n"
        		+ "               {\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"CC\",\"tin\" : \"002203941\",\n"
        		+ "               \"category\" : \"cc1\",\n"
        		+ "               \"corporateMpin\" : \"350868157\",\n"
        		+ "               \"templateEmailIndicator\" : \"cc1\"}},\n"
        		+ "               {\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"CC\",\"tin\" : \"002203942\",\n"
        		+ "               \"category\" : \"cc1\",\n"
        		+ "               \"corporateMpin\" : \"205392766\",\n"
        		+ "               \"templateEmailIndicator\" : \"cc1\"}},\n"
        		+ "               {\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"CC\",\"tin\" : \"002497288\",\n"
        		+ "               \"category\" : \"cc1\",\n"
        		+ "               \"corporateMpin\" : \"134289485\",\n"
        		+ "               \"templateEmailIndicator\" : \"cc1\"}}]}";

//        Assert.assertEquals(expected, output);
        Assert.assertTrue(output.contains("templateEmailIndicator"));

    }


}
