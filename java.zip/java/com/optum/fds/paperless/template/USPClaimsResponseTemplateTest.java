package com.optum.fds.paperless.template;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.IOException;



import org.json.JSONException;
import org.junit.Test;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class USPClaimsResponseTemplateTest {
	
	@Test
	public void testUSPClaimsResponseTemplate() throws IOException, JSONException
	{
		var jsonFileName = "InputJson/USPClaimsResponseFile.json";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String jsonString= WorkFlowUtil.readDocumentsFromJsonFileToString(jsonFile);
        String output = TemplateFactory.getInstance(Templates.USP_CLAIMS_RESPONSE.getTemplate())
                .convertWithTemplate(jsonString);
        assertTrue(output.contains("MCb906036b-72ad-4f37-a76c-cb14407f332e"));
        assertFalse(output.contains("MCb906036b-72ad-4f37-a76c-cb14407f332e_1_1.zip"));
        assertFalse(output.contains("MCb906036b-72ad-4f37-a76c-cb14407f332e_1.zip"));
	}
	
	
}
