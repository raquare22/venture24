package com.optum.fds.paperless.template;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import org.junit.Assert;
import org.junit.Test;


public class TXGCJsonDocumentTemplateTest {

    @Test
    public void testTXGCsvTemplate() {
        var jsonFileName = "ndjson/P360_tx_gc.ndjson";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.TXGC_JSON_DOCUMENT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);

        String expected = "{\"Documents\": [{\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"P360\",\"providerNPI\": \"123456789\",\"exemptionEffectiveEndDate\": \"9999-12-31\",\"exemptionEffectiveStartDate\": \"2024-04-01\",\"exemptionFlag\": \"N\",\"cycleStartDate\": \"2023-10-01\",\"cycleEndDate\": \"2024-03-31\",\"Codes\" : [{\"procCodes\":\"J3452\",\"procCodesDescription\":\"J Code Description\",\"approvalRate\":\"80.09\",\"nbrOfCodes\":\"2\"},{\"procCodes\":\"ABCDE\",\"procCodesDescription\":\"A Code Description\",\"approvalRate\":\"76.09\",\"nbrOfCodes\":\"1\"}]}},\n" +
                "               {\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"P360\",\"providerNPI\": \"987819812\",\"exemptionEffectiveEndDate\": \"9999-12-31\",\"exemptionEffectiveStartDate\": \"2024-04-01\",\"exemptionFlag\": \"Y\",\"cycleStartDate\": \"2023-10-01\",\"cycleEndDate\": \"2024-03-31\",\"Codes\" : [{\"procCodes\":\"J3452\",\"procCodesDescription\":\"J Code Description\",\"nbrOfCodes\":\"2\"}]}}]}";

        Assert.assertEquals(expected, output);

    }

}
