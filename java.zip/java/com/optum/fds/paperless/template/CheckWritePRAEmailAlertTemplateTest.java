package com.optum.fds.paperless.template;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.FileInputStream;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;

public class CheckWritePRAEmailAlertTemplateTest {


	@Test
	@UserStory(references = "US26195")
	@RallyTestCase(references = "TC30170")
	public void testApplyCheckWritePRACompanionTemplate() throws IOException {
		//var jsonFileName = "InputJson/CheckWritePRAEmailAlertUndreadableEmailSampleInput.json";
		var jsonFileName = "InputJson/CheckWritePRAEmailAlertMissingEmailSampleInput.json";

		var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
		String output = TemplateFactory.getInstance(Templates.CHECK_WRITE_PRA_EMAIL_ALERT.getTemplate())
				.convertWithTemplateFromFilePath(jsonFile);
		System.out.println(output);
		String expected = "File 2019030ZDDPIS0.zip has been waiting for its companion file in the 20190 file processing system since 2018-07-27 05:10:46.000  ";
//		Assert.assertEquals(expected, output);
		
		Assert.assertTrue(output.contains("File 2019030ZDDPIS0.zip"));

	}
}
