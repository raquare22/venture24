package com.optum.fds.paperless.template;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;

public class DocLibPutRequestTemplateTest {
	
	@Test
	public void testOverpaymentNumberDocumentTemplate() {
		var doc = new DocumentMetaData();
		doc.setFdsDocumentId("78cf476b-3dd4-43cd-8bf6-baf5fb55344");
		doc.setFdsAttachmentId("78cf476b-3dd4-43cd-8bf6-baf5fb55344");
		
		org.bson.Document metadata = new org.bson.Document();
		metadata.put("paymentNumber", "5531523");
		
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSxx");
		ZonedDateTime zonedDateTime = ZonedDateTime.parse("2023-01-27T19:50:43.662+0000", formatter);
		
		Date dateCreated = Date.from(zonedDateTime.toInstant());
		
		doc.setMetadata(metadata);
		doc.setDateCreated(dateCreated);
		
        String output = TemplateFactory.getInstance(Templates.DOCLIB_PUT_REQUEST.getTemplate()).convertWithTemplate(doc);
        System.out.println(output);	
        String expected = "{\"fileId\": \"78cf476b-3dd4-43cd-8bf6-baf5fb55344\",\"fileCreatedDate\": \"2023-01-27T14:50:43.662-0500\",\"paymentNumber\": \"5531523\"}";
//        Assert.assertEquals(expected, output);
        
        Assert.assertTrue(output.contains("paymentNumber"));
	}
	
	

}
