package com.optum.fds.paperless.template.listener;

import org.junit.Before;
import org.junit.Test;
import org.stringtemplate.v4.misc.STMessage;

import static org.junit.Assert.assertTrue;

public class ErrorListenerTest {

    private ErrorListener errorListener;

    // Custom subclass of STMessage for testing
    private static class MockSTMessage extends STMessage {
        private final String mockMessage;

        public MockSTMessage(String mockMessage) {
            super(null, null, null); // Pass null or appropriate arguments to the superclass constructor
            this.mockMessage = mockMessage;
        }

        @Override
        public String toString() {
            return mockMessage;
        }
    }

    @Before
    public void setUp() {
        errorListener = new ErrorListener();
    }

    @Test
    public void testCompileTimeError() {
        STMessage mockMessage = new MockSTMessage("Mock compile time error");

        try {
            errorListener.compileTimeError(mockMessage);
        } catch (RuntimeException e) {
            assertTrue(e.getMessage().contains("compile time"));
        }
    }

    @Test
    public void testRunTimeError() {
        STMessage mockMessage = new MockSTMessage("Mock run time error");

        try {
            errorListener.runTimeError(mockMessage);
        } catch (RuntimeException e) {
            assertTrue(e.getMessage().contains("run time"));
        }
    }

    @Test
    public void testIOError() {
        STMessage mockMessage = new MockSTMessage("Mock IO error");

        try {
            errorListener.IOError(mockMessage);
        } catch (RuntimeException e) {
            assertTrue(e.getMessage().contains("IO"));
        }
    }

    @Test
    public void testInternalError() {
        STMessage mockMessage = new MockSTMessage("Mock internal error");

        try {
            errorListener.internalError(mockMessage);
        } catch (RuntimeException e) {
            assertTrue(e.getMessage().contains("internal"));
        }
    }
}