package com.optum.fds.paperless.template;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.java.impl.SSBCIEmailRequestToPENTemplate;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.lang.reflect.Field;
import java.util.Arrays;
import static org.junit.Assert.*;

public class SSBCIEmailRequestToPENTemplateTest {

    private SSBCIEmailRequestToPENTemplate template;

    @Mock
    private Templates templateLoader;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        template = new SSBCIEmailRequestToPENTemplate();
        this.templateLoader = templateLoader;
    }

    @Test
    public void testConvertWithTemplate_InvalidJson() {
        String invalidJson = "invalid json";
        assertThrows(RuntimeException.class, () -> template.convertWithTemplate(invalidJson));
    }

    @Test
    public void convertWithTemplate() throws NoSuchFieldException, IllegalAccessException {
        SSBCIEmailRequestToPENTemplate template = new SSBCIEmailRequestToPENTemplate();
        Document provider1 = new Document()
                .append("providerId", "P001")
                .append("npi", "NPI001")
                .append("pcpName", "Dr. Smith")
                .append("taxId", "TID001")
                .append("emailAddress", Arrays.asList("drsmith@example.com", "drandrew@example.com"));

        Document provider2 = new Document()
                .append("providerId", "P002")
                .append("npi", "NPI002")
                .append("pcpName", "Dr. Jack")
                .append("taxId", "TID002")
                .append("emailAddress", Arrays.asList("drjack@example.com"));

        Document metadata = new Document()
                .append("id", 123)
                .append("householdId", "HH001")
                .append("insuredPlanId", "PLN001")
                .append("applicationId", "APP001")
                .append("type", "Medical")
                .append("effectiveDate", "2025-01-01")
                .append("endDate", "2025-12-31")
                .append("status", "Active")
                .append("eventType", "Referral")
                .append("sourceType", "System")
                .append("programNames", Arrays.asList("ProgramA", "ProgramB"))
                .append("providers", Arrays.asList(provider1, provider2))
                .append("tin", "TID001")
                .append("providerEmailId", "drsmith@example.com")
                .append("providerName", "Dr. Smith")
                .append("mpin", "P001")
                .append("transactionId", "txn-001");

        // Create DocumentMetaData and inject the metadata via reflection
        DocumentMetaData realDoc = new DocumentMetaData();
        Field metadataField = DocumentMetaData.class.getDeclaredField("metadata");
        metadataField.setAccessible(true);
        metadataField.set(realDoc, metadata);

        String result = template.convertWithTemplate(realDoc);
        System.out.println("Generated Template: \n" + result);
        assertNotNull(result);
    }
}