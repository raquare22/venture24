package com.optum.fds.paperless.template;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

import static org.junit.Assert.assertEquals;

public class AppealsNotificationsResponseTemplateTest {

    @Test
    public void testFormatDateCreated_ValidDate() throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        Date date = sdf.parse("2024-07-23 17:44:13.815");
        String formatted = com.optum.fds.paperless.template.java.impl.AppealsNotificationsResponseTemplate
                .formatDateCreated(date);
        assertEquals("2024-07-23 17:44:13.815", formatted);
    }

    @Test
    public void testFormatDateCreated_NullDate() {
        String formatted = com.optum.fds.paperless.template.java.impl.AppealsNotificationsResponseTemplate
                .formatDateCreated(null);
        assertEquals("", formatted);
    }

    @Test
    public void testConvertWithTemplate() throws IOException, JSONException {
        String expectedCsv = "tin|corporateMpin|providerEmailId|dateEmailSent|eDeliveryError|appealsReferenceNumber|status|attemptNumber|receivedDate\n" +
                "'123456789'|'987654321'|||SMTP , Timeout , Code , 504|A123456||2|2018-07-27 05:10:46.000\n" +
                "'123456789'|'987654321'|||Missing or invalid data: providerEmailId||||2018-07-27 05:10:46.000\n" +
                "'123456789'|'987654321'|||Missing or invalid data: providerEmailId||||2018-07-27 05:10:46.000\n" +
                "'123456789'|'987654321'|testemail@optum.com|2024-07-23 17:44:13.815|||||2018-07-27 05:10:46.000\n" + // <-- extra |
                "'123456789'|'987654321'|testemail@optum.com|2024-07-23 17:44:13.815||A123456||1|2018-07-27 05:10:46.000";
        String jsonString = "{"
                + "\"Documents\": ["
                + "  {"
                + "    \"metadata\": {"
                + "      \"tin\": \"123456789\","
                + "      \"corporateMpin\": \"987654321\","
                + "      \"providerEmailId\": \"\","
                + "      \"dateEmailSent\": \"\","
                + "      \"eDeliveryError\": \"SMTP | Timeout | Code | 504\","
                + "      \"caseNumber\": \"A123456\","
                + "      \"attemptNumber\": 2,"
                + "      \"appealStatus\": \"Action Required\""
                + "    },"
                + "    \"dateCreated\": \"Fri Jul 27 09:10:46 UTC 2018\""
                + "  },"
                + "  {"
                + "    \"metadata\": {"
                + "      \"tin\": \"123456789\","
                + "      \"corporateMpin\": \"987654321\","
                + "      \"providerEmailId\": \"\","
                + "      \"dateEmailSent\": \"\","
                + "      \"eDeliveryError\": \"Missing or invalid data: providerEmailId\","
                + "      \"caseNumber\": \"\","
                + "      \"appealStatus\": \"Resubmit attachments\""
                + "    },"
                + "    \"dateCreated\": \"Fri Jul 27 09:10:46 UTC 2018\""
                + "  },"
                + "  {"
                + "    \"metadata\": {"
                + "      \"tin\": \"123456789\","
                + "      \"corporateMpin\": \"987654321\","
                + "      \"providerEmailId\": \"\","
                + "      \"dateEmailSent\": \"\","
                + "      \"eDeliveryError\": \"Missing or invalid data: providerEmailId\","
                + "      \"caseNumber\": \"\","
                + "      \"appealStatus\": \"Action Required\""
                + "    },"
                + "    \"dateCreated\": \"Fri Jul 27 09:10:46 UTC 2018\""
                + "  },"
                + "  {"
                + "    \"metadata\": {"
                + "      \"tin\": \"123456789\","
                + "      \"corporateMpin\": \"987654321\","
                + "      \"providerEmailId\": \"testemail@optum.com\","
                + "      \"dateEmailSent\": \"2024-07-23T17:44:13.815Z\","
                + "      \"eDeliveryError\": \"\","
                + "      \"caseNumber\": \"\","
                + "      \"appealStatus\": \"\""
                + "    },"
                + "    \"dateCreated\": \"Fri Jul 27 09:10:46 UTC 2018\""
                + "  },"
                + "  {"
                + "    \"metadata\": {"
                + "      \"tin\": \"123456789\","
                + "      \"corporateMpin\": \"987654321\","
                + "      \"providerEmailId\": \"testemail@optum.com\","
                + "      \"dateEmailSent\": \"2024-07-23T17:44:13.815Z\","
                + "      \"eDeliveryError\": \"\","
                + "      \"attemptNumber\": 1,"
                + "      \"caseNumber\": \"A123456\","
                + "      \"appealStatus\": \"Action Required\""
                + "    },"
                + "    \"dateCreated\": \"Fri Jul 27 09:10:46 UTC 2018\""
                + "  }"
                + "]"
                + "}";

        String result = TemplateFactory.getInstance(Templates.APPEALS_NOTIFICATIONS_RESPONSE.getTemplate()).convertWithTemplate(jsonString);
        System.out.println("Result from convertWithTemplate: \n" + result + "\n");

        Assert.assertEquals(expectedCsv, result);
    }

    @Test
    public void testConvertWithTemplateFromFilePath() throws IOException, JSONException {
        String expectedCsv = "tin|corporateMpin|providerEmailId|dateEmailSent|eDeliveryError|appealsReferenceNumber|status|attemptNumber|receivedDate\n" +
                "'123456789'|'987654321'|||Missing or invalid data: providerEmailId|A123456||1|2018-07-27 05:10:46.000\n" +
                "'123456789'|'987654321'|||Missing or invalid data: providerEmailId|||1|2018-07-27 05:10:46.000\n" +
                "'123456789'|'987654321'|||Missing or invalid data: providerEmailId||||2018-07-27 05:10:46.000\n" +
                "'123456789'|'987654321'|testemail@optum.com|2024-07-23 17:44:13.815||||2|2018-07-27 05:10:46.000\n" +
                "'123456789'|'987654321'|testemail@optum.com|2024-07-23 17:44:13.815||A123456|||2018-07-27 05:10:46.000";

        var jsonFileName = "InputJson/AppealsNotificationsResponse.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.APPEALS_NOTIFICATIONS_RESPONSE.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println("Result from convertWithTemplateFromFilePath: \n" + output + "\n");

        Assert.assertEquals(expectedCsv, output);
    }


    @Test
    public void testFormatDateEmailSent_ValidDate() {
        String input = "2024-07-23T17:44:13.815Z";
        String expected = "2024-07-23 17:44:13.815";
        String result = com.optum.fds.paperless.template.java.impl.AppealsNotificationsResponseTemplate
                .formatDateEmailSent(input);
        assertEquals(expected, result);
    }

    @Test
    public void testFormatDateEmailSent_NullInput() {
        String result = com.optum.fds.paperless.template.java.impl.AppealsNotificationsResponseTemplate
                .formatDateEmailSent(null);
        assertEquals("", result);
    }

    @Test
    public void testFormatDateEmailSent_EmptyInput() {
        String result = com.optum.fds.paperless.template.java.impl.AppealsNotificationsResponseTemplate
                .formatDateEmailSent("");
        assertEquals("", result);
    }
}