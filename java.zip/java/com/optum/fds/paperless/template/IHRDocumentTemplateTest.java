package com.optum.fds.paperless.template;

import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;

public class IHRDocumentTemplateTest {

	@Test
	public void testIHRResponseTemplate() {
		var jsonFileName = "xlsx/IHRExcel.xlsx";

		var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
		String output = TemplateFactory.getInstance(Templates.IHR_DOCUMENT_TEMPLATE.getTemplate())
				.convertWithTemplateFromFilePath(jsonFile);
		System.out.println(output);
		
		String expected = "{\"Documents\": [{\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"IHR\",\"provAddressLine2\" : \"\",\n"
				+ "               \"provAddressLine1\" : \"2209 JOHN R WOODEN DR\",\n"
				+ "               \"npi\" : \"1588955215\",\n"
				+ "               \"groupNpi\" : \"1013953983\",\n"
				+ "               \"groupTaxId\" : \"351913875\",\n"
				+ "               \"groupProviderId\" : \"001160933006\",\n"
				+ "               \"corporateMpin\" : \"001160933\",\n"
				+ "               \"providerSpecialty\" : \"Pediatrics\",\n"
				+ "               \"providerType\" : \"\",\n"
				+ "               \"providerId\" : \"005156487006\",\n"
				+ "               \"tin\" : \"351913875\",\n"
				+ "               \"pcpFlag\" : \"Y\",\n"
				+ "               \"providerName\" : \"FULLER, JUSTIN T.\",\n"
				+ "               \"email\" : \"\"}},\n"
				+ "               {\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"IHR\",\"provAddressLine2\" : \"\",\n"
				+ "               \"provAddressLine1\" : \"60205 BODNAR BLVD\",\n"
				+ "               \"npi\" : \"1629514799\",\n"
				+ "               \"groupNpi\" : \"1013962984\",\n"
				+ "               \"groupTaxId\" : \"350868157\",\n"
				+ "               \"groupProviderId\" : \"002203941015\",\n"
				+ "               \"corporateMpin\" : \"002203941\",\n"
				+ "               \"providerSpecialty\" : \"Family Nurse Practitioner\",\n"
				+ "               \"providerType\" : \"\",\n"
				+ "               \"providerId\" : \"006406447004\",\n"
				+ "               \"tin\" : \"350868157\",\n"
				+ "               \"pcpFlag\" : \"Y\",\n"
				+ "               \"providerName\" : \"CAMPBELL, DAWN L.\",\n"
				+ "               \"email\" : \"\"}},\n"
				+ "               {\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"IHR\",\"provAddressLine2\" : \"\",\n"
				+ "               \"provAddressLine1\" : \"7330 E 82ND ST STE A\",\n"
				+ "               \"npi\" : \"1225263106\",\n"
				+ "               \"groupNpi\" : \"\",\n"
				+ "               \"groupTaxId\" : \"\",\n"
				+ "               \"groupProviderId\" : \"\",\n"
				+ "               \"corporateMpin\" : \"002203942\",\n"
				+ "               \"providerSpecialty\" : \"Social Worker - Licensed\",\n"
				+ "               \"providerType\" : \"\",\n"
				+ "               \"providerId\" : \"002081996685\",\n"
				+ "               \"tin\" : \"205392766\",\n"
				+ "               \"pcpFlag\" : \"N\",\n"
				+ "               \"providerName\" : \"COMMUNITY HOSPITALS OF INDIANA\",\n"
				+ "               \"email\" : \"\"}},\n"
				+ "               {\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"IHR\",\"provAddressLine2\" : \"\",\n"
				+ "               \"provAddressLine1\" : \"8424 NAAB RD STE 1B BLDG 1\",\n"
				+ "               \"npi\" : \"1144513375\",\n"
				+ "               \"groupNpi\" : \"\",\n"
				+ "               \"groupTaxId\" : \"\",\n"
				+ "               \"groupProviderId\" : \"\",\n"
				+ "               \"corporateMpin\" : \"\",\n"
				+ "               \"providerSpecialty\" : \"Social Worker - Licensed\",\n"
				+ "               \"providerType\" : \"\",\n"
				+ "               \"providerId\" : \"003193028372\",\n"
				+ "               \"tin\" : \"272039417\",\n"
				+ "               \"pcpFlag\" : \"N\",\n"
				+ "               \"providerName\" : \"ASCENSION MEDICAL GROUP ST VINCENT\",\n"
				+ "               \"email\" : \"\"}},\n"
				+ "               {\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"IHR\",\"provAddressLine2\" : \"\",\n"
				+ "               \"provAddressLine1\" : \"865 WESTFIELD RD STE B\",\n"
				+ "               \"npi\" : \"1629444682\",\n"
				+ "               \"groupNpi\" : \"1144513375\",\n"
				+ "               \"groupTaxId\" : \"272039417\",\n"
				+ "               \"groupProviderId\" : \"002497288\",\n"
				+ "               \"corporateMpin\" : \"002497288\",\n"
				+ "               \"providerSpecialty\" : \"Nurse Practitioner\",\n"
				+ "               \"providerType\" : \"\",\n"
				+ "               \"providerId\" : \"5677581001\",\n"
				+ "               \"tin\" : \"134289485\",\n"
				+ "               \"pcpFlag\" : \"Y\",\n"
				+ "               \"providerName\" : \"BRANIFF, HEATHER\",\n"
				+ "               \"email\" : \"\"}}]}";
		
//		Assert.assertEquals(expected, output);
		
		Assert.assertTrue(output.contains("groupNpi"));

	}

	
}
