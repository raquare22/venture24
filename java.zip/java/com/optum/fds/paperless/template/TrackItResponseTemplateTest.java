package com.optum.fds.paperless.template;

import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;

public class TrackItResponseTemplateTest {

    @Test
    public void testTrackItResponseTemplate() throws JSONException, IOException {
        String jsonString= "{\n" +
                "  \"metadata\" : {\n" +
                "    \"recordID\" : \"1775066534981\",\n" +
                "    \"recordLastUpdatedDate\" : \"2026-04-01 13:02:14\",\n" +
                "    \"providerEmailId\" : \"test@email.com\",\n" +
                "    \"deliveryStatus\" : \"Pending\",\n" +
                "    \"recordsCountList\" : [\n" +
                "      {\n" +
                "        \"dailyReconCount\" : \"0\",\n" +
                "        \"weeklyReconCount\" : \"0\",\n" +
                "        \"dailyPendCount\" : \"0\",\n" +
                "        \"weeklyPendCount\" : \"0\",\n" +
                "        \"dailyAppealsCount\" : \"0\",\n" +
                "        \"weeklyAppealsCount\" : \"0\",\n" +
                "        \"tin\" : \"223624559\",\n" +
                "        \"providerName\" : \"OPTUM MEDICAL CARE OF NEW JERSEY\",\n" +
                "        \"corpMpin\" : \"007047232\",\n" +
                "        \"dailyPaanAdditionalInfoCount\" : \"0\",\n" +
                "        \"dailyPaanAppealsCount\" : \"0\",\n" +
                "        \"weeklyPaanAdditionalInfoCount\" : \"0\",\n" +
                "        \"weeklyPaanAppealsCount\" : \"0\",\n" +
                "        \"dailySmartEditsCount\" : \"0\",\n" +
                "        \"actionRequiredPendingClaimsCount\" : \"0\",\n" +
                "        \"retryDocumentPendingClaimsCount\" : \"0\",\n" +
                "        \"bothPendingClaimsCount\" : \"0\",\n" +
                "        \"referralCreatedCount\" : \"0\",\n" +
                "        \"referralAboutToExpireCount\" : \"0\",\n" +
                "        \"referralBothCount\" : \"0\",\n" +
                "        \"dailyDisputeCount\" : \"0\",\n" +
                "        \"weeklyDisputeCount\" : \"0\",\n" +
                "        \"dailySmartEditsActionRequiredCount\" : \"0\",\n" +
                "        \"dailySmartEditsRetryDocCount\" : \"0\",\n" +
                "        \"dailyRejectedClaimsActionRequiredCount\" : \"0\"\n" +
                "      }\n" +
                "    ],\n" +
                "    \"messageId\" : \"[<1524493499.3553.1775085000669@fds-paperless-pen-api-stage-86c644fc86-fch9n>]\",\n" +
                "    \"prepostEnded\" : true,\n" +
                "    \"sendEmailNotifications\" : true,\n" +
                "    \"dateEmailSent\" : \"2026-03-11T12:30:00.000Z\",\n" +
                "    \"sendPENAPIRequest\" : true,\n" +
                "    \"createApplication\" : \"TrackIt\"\n" +
                "  }\n" +
                "}";

        String output = TemplateFactory.getInstance(Templates.TRACK_IT_RESPONSE.getTemplate())
                .convertWithTemplate(jsonString);

        System.out.println(output);
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("Success"));
        Assert.assertTrue(output.contains("1775066534981"));
        Assert.assertTrue(output.contains("test@email.com"));
    }

    @Test
    public void testTrackItResponseTemplateEDeliveryError() throws JSONException, IOException {
        String jsonString= "{\n" +
                "  \"metadata\" : {\n" +
                "    \"recordID\" : \"1775066534981\",\n" +
                "    \"recordLastUpdatedDate\" : \"2026-04-01 13:02:14\",\n" +
                "    \"providerEmailId\" : \"test@email.com\",\n" +
                "    \"eDeliveryError\" : \"Missing or invalid data: email bounced\",\n" +
                "    \"deliveryStatus\" : \"Pending\",\n" +
                "    \"recordsCountList\" : [\n" +
                "      {\n" +
                "        \"dailyReconCount\" : \"0\",\n" +
                "        \"weeklyReconCount\" : \"0\",\n" +
                "        \"dailyPendCount\" : \"0\",\n" +
                "        \"weeklyPendCount\" : \"0\",\n" +
                "        \"dailyAppealsCount\" : \"0\",\n" +
                "        \"weeklyAppealsCount\" : \"0\",\n" +
                "        \"tin\" : \"223624559\",\n" +
                "        \"providerName\" : \"OPTUM MEDICAL CARE OF NEW JERSEY\",\n" +
                "        \"corpMpin\" : \"007047232\",\n" +
                "        \"dailyPaanAdditionalInfoCount\" : \"0\",\n" +
                "        \"dailyPaanAppealsCount\" : \"0\",\n" +
                "        \"weeklyPaanAdditionalInfoCount\" : \"0\",\n" +
                "        \"weeklyPaanAppealsCount\" : \"0\",\n" +
                "        \"dailySmartEditsCount\" : \"0\",\n" +
                "        \"actionRequiredPendingClaimsCount\" : \"0\",\n" +
                "        \"retryDocumentPendingClaimsCount\" : \"0\",\n" +
                "        \"bothPendingClaimsCount\" : \"0\",\n" +
                "        \"referralCreatedCount\" : \"0\",\n" +
                "        \"referralAboutToExpireCount\" : \"0\",\n" +
                "        \"referralBothCount\" : \"0\",\n" +
                "        \"dailyDisputeCount\" : \"0\",\n" +
                "        \"weeklyDisputeCount\" : \"0\",\n" +
                "        \"dailySmartEditsActionRequiredCount\" : \"0\",\n" +
                "        \"dailySmartEditsRetryDocCount\" : \"0\",\n" +
                "        \"dailyRejectedClaimsActionRequiredCount\" : \"0\"\n" +
                "      }\n" +
                "    ],\n" +
                "    \"messageId\" : \"[<1524493499.3553.1775085000669@fds-paperless-pen-api-stage-86c644fc86-fch9n>]\",\n" +
                "    \"prepostEnded\" : true,\n" +
                "    \"dateEmailSent\" : \"2026-03-11T12:30:00.000Z\",\n" +
                "    \"sendEmailNotifications\" : true,\n" +
                "    \"sendPENAPIRequest\" : true,\n" +
                "    \"createApplication\" : \"TrackIt\"\n" +
                "  }\n" +
                "}";

        String output = TemplateFactory.getInstance(Templates.TRACK_IT_RESPONSE.getTemplate())
                .convertWithTemplate(jsonString);

        System.out.println(output);
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("Failure"));
        Assert.assertTrue(output.contains("email bounced"));
        Assert.assertTrue(output.contains("1775066534981"));
        Assert.assertTrue(output.contains("test@email.com"));
    }
}
