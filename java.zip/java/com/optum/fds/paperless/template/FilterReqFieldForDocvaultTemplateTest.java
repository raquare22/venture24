package com.optum.fds.paperless.template;

import java.util.HashMap;
import java.util.Map;

import org.bson.Document;
import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.document.util.DocumentResponse;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.impl.FilterReqFieldForDocvaultTemplate;

@UserStory(references = "US32407")
public class FilterReqFieldForDocvaultTemplateTest {
	
    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateETS() {
        var jsonFileName = "InputJson/docvault/ETSAppealsDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"\",\"attachments\" : [{\"status\":\"AVAILABLE\",\"fileId\":\"e0636ede-b216-42bc-8224-f7a6d5005441\",\"spaceId\":\"10702\",\"fileName\":\"60256321.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"12345\",\"sourceCreatedDate\" : \"2021-07-12T12:55:12.000Z\",\"physicianName\" : \"Walgreens Respiratory Services\",\"npi\" : \"\",\"caseId\" : \"K1501310002\",\"memberName\" : \"\",\"source\" : \"PRUN\",\"memberId\" : \"105675466\",\"docClass\": \"u_doc_class\",\"fileDescription\" : \"Appeals and Disputes\",\"fileName\" : \"60256321.pdf\",\"subCategory\" : \"X2\",\"filePath\" : \"Community Plan Appeals and Disputes / Acknowledgement, Notification, and Response\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2023-07-12T12:13:48.102-06:00\",\"createApplication\" : \"ETS\",\"tin\" : \"680208702\",\"mpin\" : \"003409557\",\"category\" : \"Appeals and Disputes\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"002464887\"}}";
        Assert.assertTrue(output.contains("u_doc_class"));
        Assert.assertTrue(output.contains("e0636ede-b216-42bc-8224-f7a6d5005441"));
        Assert.assertTrue(output.contains("Walgreens Respiratory Services"));
    }
    
    
    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateETSJsonStr() {
        var jsonStr = "{\n" + 
        		"  \"id\" : \"60ec86611432e300517ec3f8\",\n" + 
        		"  \"attachments\" : [\n" + 
        		"    {\n" + 
        		"      \"fileId\" : \"e0636ede-b216-42bc-8224-f7a6d5005441\",\n" + 
        		"      \"index\" : 1,\n" + 
        		"      \"fileName\" : \"60256321.pdf\",\n" + 
        		"      \"contentType\" : \"application/pdf\",\n" + 
        		"      \"fileSize\" : 481396,\n" + 
        		"      \"status\" : \"AVAILABLE\",\n" + 
        		"      \"spaceId\" : \"10702\",\n" + 
        		"      \"dateCreated\" : \"2021-07-19T17:36:51.378Z\"\n" + 
        		"    }\n" + 
        		"  ],\n" + 
        		"  \"metadata\" : {\n" + 
        		"    \"emailAlertReq\" : \"Y\",\n" + 
        		"    \"fileDescription\" : \"Appeals and Disputes\",\n" + 
        		"    \"docSentTo\" : \"Both\",\n" + 
        		"    \"fileName\" : \"60256321.pdf\",\n" + 
        		"    \"subCategory\" : \"X2\",\n" + 
        		"    \"originalPrintTrail\" : \"3256\",\n" + 
        		"    \"docVaultUploadDate\" : \"2021-07-12T18:14:55.320Z\",\n" + 
        		"    \"postCardInd\" : true,\n" + 
        		"    \"privilege\" : \"Claim Status\",\n" + 
        		"    \"corporateMpin\" : \"002464887\",\n" + 
        		"    \"expiryDate\" : \"2023-07-12T12:13:48.102-06:00\",\n" + 
        		"    \"historyId\" : \"60256321\",\n" + 
        		"    \"caseId\" : \"K1501310002\",\n" + 
        		"    \"tin\" : \"680208702\",\n" + 
        		"    \"CONFIGKEY\" : \"FDSPP3256\",\n" + 
        		"    \"skipManipulatePdfFile\" : true,\n" + 
        		"    \"absolutePath\" : \"/bconnected/ingest/89de2aa36a3b43f49395116255be8c0a/10702/20210712191503166/\",\n" + 
        		"    \"emailAlertReqNullCheck\" : \"Y\",\n" + 
        		"    \"sendToDocVault\" : true,\n" + 
        		"    \"createdDateNullCheck\" : \"2021-07-12T12:55:12.000Z\",\n" + 
        		"    \"tenant\" : \"Link\",\n" + 
        		"    \"memberId\" : \"105675466\",\n" + 
        		"    \"MailToAddress1\" : \"Walgreens Respiratory Services\",\n" + 
        		"    \"docVaultAPIResponse\" : true,\n" + 
        		"    \"filePath\" : \"Community Plan Appeals and Disputes / Acknowledgement, Notification, and Response\",\n" + 
        		"    \"sendEmailNotifications\" : false,\n" + 
        		"    \"providerEmailId\" : \"\",\n" + 
        		"    \"dateEmailSent\" : null,\n" + 
        		"    \"sendPENAPIRequest\" : false,\n" + 
        		"    \"eDeliveryError\" : \"Missing or invalid data: providerEmailId\",\n" + 
        		"    \"subCategoryNullCheck\" : \"X2\",\n" + 
        		"    \"rprntSentToSF\" : true,\n" + 
        		"    \"createdDate\" : \"2021-07-12T12:55:12.000Z\",\n" + 
        		"    \"physicianName\" : \"Walgreens Respiratory Services\",\n" + 
        		"    \"createApplication\" : \"ETS\",\n" + 
        		"    \"PassThruData\" : \"K1501310002|60256321|20210712131006_ETS_PDF_FDS.zip\",\n" + 
        		"    \"MailToAddress6\" : \"651096023\",\n" + 
        		"    \"mpin\" : \"003409557\",\n" + 
        		"    \"MailToAddress4\" : \"Jefferson City\",\n" + 
        		"    \"category\" : \"Appeals and Disputes\",\n" + 
        		"    \"MailToAddress5\" : \"MO\",\n" + 
        		"    \"MailToAddress2\" : \"1241 W Stadium Blvd\",\n" + 
        		"    \"fileType\" : \"Letter\",\n" + 
        		"    \"MailToAddress3\" : \"\",\n" + 
        		"    \"sendToShutterfly\" : true,\n" + 
        		"    \"addedToResponseFile\" : true\n" + 
        		"  },\n" + 
        		"  \"spaceId\" : 10702,\n" + 
        		"  \"cloudSpaceId\" : \"123\",\n" +
        		"  \"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\n" +
        		"  \"dateCreated\" : \"2021-07-12T18:13:53.940Z\",\n" + 
        		"  \"dateModified\" : \"2021-07-12T22:00:14.239Z\",\n" + 
        		"  \"status\" : \"AVAILABLE\"\n" + 
        		"}";
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplate(jsonStr);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"10702\",\"docClass\" : \"\",\"cloudSpaceId\" : \"123\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-12T18:13:53.940Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"e0636ede-b216-42bc-8224-f7a6d5005441\",\"spaceId\":\"10702\",\"fileName\":\"60256321.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"\",\"sourceCreatedDate\" : \"2021-07-12T12:55:12.000Z\",\"physicianName\" : \"Walgreens Respiratory Services\",\"npi\" : \"\",\"caseId\" : \"K1501310002\",\"memberName\" : \"\",\"source\" : \"PRUN\",\"memberId\" : \"105675466\",\"fileDescription\" : \"Appeals and Disputes\",\"fileName\" : \"60256321.pdf\",\"subCategory\" : \"X2\",\"filePath\" : \"Community Plan Appeals and Disputes / Acknowledgement, Notification, and Response\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2023-07-12T12:13:48.102-06:00\",\"createApplication\" : \"ETS\",\"tin\" : \"680208702\",\"mpin\" : \"003409557\",\"category\" : \"Appeals and Disputes\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"002464887\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("X2"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateCSPPRA() {
        var jsonFileName = "InputJson/docvault/CSPPRADocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"10402\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-12T19:23:28.563Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"f9cd9fcc-82d0-4162-b267-d6d155dd36fb\",\"spaceId\":\"8935\",\"fileName\":\"0002461881_00000329.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"\",\"sourceCreatedDate\" : \"2021-07-12T19:05:53.664Z\",\"physicianName\" : \"LIVINGSTON PHYSICAL THERAPY PC\",\"checkAmount\" : \"168.43\",\"npi\" : \"\",\"source\" : \"PRUN\",\"checkId\" : \"2021070215700219\",\"claimNumber\" : \"\",\"paymentNumber\" : \"2021070215700219\",\"memberId\" : \"\",\"fileDescription\" : \"Payment Document\",\"fileName\" : \"0002461881_00000329.pdf\",\"subCategory\" : \"P6\",\"filePath\" : \"Community Plan/PRA\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2023-07-12T13:05:53.678-06:00\",\"createApplication\" : \"CSP-PRA\",\"tin\" : \"760158174\",\"mpin\" : \"000120796\",\"category\" : \"Payment Document\",\"fileType\" : \"Advice\",\"tenant\" : \"Link\",\"corporateMpin\" : \"000120796\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("checkId"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateCheckWrite() {
        var jsonFileName = "InputJson/docvault/CheckWriteDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"10070\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-12T13:32:38.308Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"1009e122-d251-4ebb-8152-784d0239b0c0\",\"spaceId\":\"8935\",\"fileName\":\"2021190ZCCPAU0_000001.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"\",\"sourceCreatedDate\" : \"2021-07-12T13:31:36.873Z\",\"physicianName\" : \"SIMOS, D.M.D., CONSTANTINE\",\"checkAmount\" : \"\",\"npi\" : \"\",\"source\" : \"PRUN\",\"checkId\" : \"K5953803\",\"claimNumber\" : \"|68590003-00|\",\"paymentNumber\" : \"K5953803\",\"memberId\" : \"\",\"fileDescription\" : \"Payment Document\",\"fileName\" : \"2021190ZCCPAU0_000001.pdf\",\"subCategory\" : \"P3\",\"filePath\" : \"Medicare PRAs/Detail PRA\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2023-07-12T07:32:36.884-06:00\",\"createApplication\" : \"CheckWrite\",\"tin\" : \"221996104\",\"mpin\" : \"000000000\",\"category\" : \"Payment Document\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"000027599\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("Medicare PRAs/Detail PRA"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateCDC() {
        var jsonFileName = "InputJson/docvault/CDCDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"e0636ede-b216-42bc-8224-f7a6d5005441\",\"spaceId\":\"10070\",\"fileName\":\"0001915734_00001749.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"\",\"sourceCreatedDate\" : \"2020-12-21T10:44:03.562Z\",\"physicianName\" : \"\",\"checkAmount\" : \"\",\"npi\" : \"\",\"source\" : \"PRUN\",\"checkId\" : \"0005720D\",\"claimNumber\" : \"||\",\"paymentNumber\" : \"0005720D\",\"memberId\" : \"\",\"docClass\": \"\",\"fileDescription\" : \"Payment Document\",\"fileName\" : \"0001915734_00001749.pdf\",\"subCategory\" : \"P4\",\"filePath\" : \"Medicare PRAs/Info Only\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2022-12-21T10:44:03.568-06:00\",\"createApplication\" : \"CDC\",\"tin\" : \"341966269\",\"mpin\" : \"\",\"category\" : \"Payment Document\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"002933475\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("CDC"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateODAR() {
        var jsonFileName = "InputJson/docvault/ODARDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"10503\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-19T14:27:10.128Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"58d23275-c39c-447e-a9a1-e23cfb5998cc\",\"spaceId\":\"8935\",\"fileName\":\"0015997468_00000003.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"|CC1528761501|CD3766862403|CC1528761502|CD3766862403|CC1793326401|CD3766862403|CD3530799502|CD3766862403|CC1793326403|CC5391113201|CC5391113203|CC8560571303|CD3766862403|\",\"sourceCreatedDate\" : \"2021-07-16T22:25:46.000Z\",\"physicianName\" : \"BERNICE GONZALEZ\",\"npi\" : \"\",\"policyNumber\" : \"\",\"memberName\" : \"\",\"source\" : \"PRUN\",\"claimNumber\" : \"\",\"memberId\" : \"\",\"fileDescription\" : \"Overpayment Document\",\"fileName\" : \"0015997468_00000003.pdf\",\"subCategory\" : \"O1\",\"filePath\" : \"Commercial Overpayment Letters/Overpayment Reconsideration Requests\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2023-07-19T08:27:08.744-06:00\",\"createApplication\" : \"ODAR\",\"tin\" : \"770690313\",\"mpin\" : \"001376223\",\"category\" : \"Overpayment Documents\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"001376223\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("patientAccountNumber"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateELGS() {
        var jsonFileName = "InputJson/docvault/ELGSDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"8889\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-19T18:38:44.407Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"3415dc81-d52a-4f3f-a4b3-d74e31e7c899\",\"spaceId\":\"8935\",\"fileName\":\"1324512115_1324512115.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"|132451211513|\",\"sourceCreatedDate\" : \"2021-07-19T00:00:00.000Z\",\"physicianName\" : \"PENNY S TURTEL MD\",\"npi\" : \"\",\"policyNumber\" : \"9F5633\",\"memberName\" : \"LIONEL LUCAS\",\"dateOfService\" : \"2021-07-08T00:00:00.000Z\",\"source\" : \"PRUN\",\"claimNumber\" : \"CV61054877\",\"memberId\" : \"943818795\",\"fileDescription\" : \"Claim status update\",\"fileName\" : \"1324512115_1324512115.pdf\",\"subCategory\" : \"C2\",\"filePath\" : \"Commercial/Acknowledgements\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2023-07-19T12:38:43.204-06:00\",\"createApplication\" : \"ELGS\",\"tin\" : \"463915494\",\"mpin\" : \"001123845\",\"category\" : \"Claim\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"005280740\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("claimNumber"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateLetGen() {
        var jsonFileName = "InputJson/docvault/LetGenDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"8935\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-19T17:34:17.218Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"9a368abd-56ad-4c92-9cc2-812605e22cbc\",\"spaceId\":\"8935\",\"fileName\":\"FDSMANUAL_202107191030_N_NTL_FS_000104_202107018233_00_616_1pg_dpx.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"6745234\",\"sourceCreatedDate\" : \"2021-07-19T00:00:00.000Z\",\"physicianName\" : \"RESPIRATORY PLUS INC\",\"npi\" : \"\",\"policyNumber\" : \"00000\",\"memberName\" : \"WILMA THRASHER\",\"dateOfService\" : \"2021-04-16T00:00:00.000Z\",\"source\" : \"PRUN\",\"claimNumber\" : \"000957691\",\"memberId\" : \"912787929\",\"fileDescription\" : \"Medicare/Reconsideration\",\"fileName\" : \"FDSMANUAL_202107191030_N_NTL_FS_000104_202107018233_00_616_1pg_dpx.pdf\",\"subCategory\" : \"R2\",\"filePath\" : \"Medicare/Reconsideration\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2023-07-19T11:33:35.599-06:00\",\"createApplication\" : \"LETGEN\",\"tin\" : \"710802269\",\"mpin\" : \"002084263\",\"category\" : \"Claim\",\"fileType\" : \"letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"002084263\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("LETGEN"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateBottomLine() {
        var jsonFileName = "InputJson/docvault/BottomLineDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"10302\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-02-02T15:22:34.554Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"c1562e4f-6a5e-4b01-a02d-08b6e7e1e1b8\",\"spaceId\":\"10302\",\"fileName\":\"0001915734_00001749.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"sourceCreatedDate\" : \"2020-07-30T06:53:33.757-06:00\",\"physicianName\" : \"FDSPEN LOADTEST\",\"CheckTraceNumber\" : \"TR10389775\",\"source\" : \"PRUN\",\"claimNumber\" : \"1223337600\",\"fileDescription\" : \"Payment Package\",\"fileName\" : \"loadTest.pdf\",\"subCategory\" : \"P5\",\"filePath\" : \"Commercial PRAs/Detail PRA\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2022-07-30T06:53:33.757Z\",\"createApplication\" : \"Bottomline\",\"tin\" : \"000001999\",\"mpin\" : \"000009999\",\"category\" : \"Payment Document\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"001889526\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("CheckTraceNumber"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateNGS() {
        var jsonFileName = "InputJson/docvault/NGSDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"10602\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-19T08:19:43.058Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"d38d6489-265f-4cec-903f-d7b41ef00174\",\"spaceId\":\"10602\",\"fileName\":\"AT-1974222-A CLOSING LTR 6492355.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"12345\",\"sourceCreatedDate\" : \"2021-07-06T19:42:03.000Z\",\"physicianName\" : \"Slater\",\"npi\" : \"\",\"caseId\" : \"AT-1974222-A\",\"memberName\" : \"Andrea N. Catsicas\",\"source\" : \"PRUN\",\"notificationNumber\" : \"\",\"claimNumber\" : \"\",\"memberId\" : \"952581999\",\"fileDescription\" : \"Appeals and Disputes\",\"fileName\" : \"AT-1974222-A CLOSING LTR 6492355.pdf\",\"subCategory\" : \"X6\",\"filePath\" : \"Medicare Appeals and Disputes / Resolution\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2023-07-19T02:18:50.945-06:00\",\"createApplication\" : \"NGS\",\"tin\" : \"590910342\",\"mpin\" : \"000389811\",\"category\" : \"Appeals and Disputes\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"000389811\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("X6"));
    }


    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateNGSClaims() {
        var jsonFileName = "InputJson/docvault/NGSClaimsDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"d38d6489-265f-4cec-903f-d7b41ef00174\",\"spaceId\":\"10602\",\"fileName\":\"AT-1974222-A CLOSING LTR 6492355.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"12345\",\"sourceCreatedDate\" : \"2021-07-06T19:42:03.000Z\",\"physicianName\" : \"Slater\",\"npi\" : \"\",\"caseId\" : \"AT-1974222-A\",\"memberName\" : \"Andrea N. Catsicas\",\"source\" : \"PRUN\",\"notificationNumber\" : \"\",\"claimNumber\" : \"\",\"memberId\" : \"952581999\",\"docClass\": \"\",\"fileDescription\" : \"Appeals and Disputes\",\"fileName\" : \"AT-1974222-A CLOSING LTR 6492355.pdf\",\"subCategory\" : \"X6\",\"filePath\" : \"Medicare Appeals and Disputes / Resolution\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2023-07-19T02:18:50.945-06:00\",\"createApplication\" : \"NGS\",\"tin\" : \"590910342\",\"mpin\" : \"000389811\",\"category\" : \"Appeals and Disputes\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"000389811\"}}";
        Assert.assertEquals(expected, output);
    }
    
    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateNICE() {
        var jsonFileName = "InputJson/docvault/NICEDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"10303\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-24T08:34:40.102Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"a722f298-3d9e-421c-9574-a9c798d2588a\",\"spaceId\":\"10303\",\"fileName\":\"15301_COCLM.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"sourceCreatedDate\" : \"2021-07-23T00:00:00.000Z\",\"physicianName\" : \"DENVER TECH DERMATOLOGY A PC\",\"checkAmount\" : \"57.94\",\"source\" : \"PRUN\",\"checkId\" : \"15301\",\"paymentNumber\" : \"15301\",\"fileDescription\" : \"Payment Package\",\"fileName\" : \"15301_COCLM.pdf\",\"subCategory\" : \"P5\",\"filePath\" : \"UHC West Payment Packages/Detailed Pmt Docs\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2023-07-24T02:34:38.611-06:00\",\"createApplication\" : \"NICE\",\"tin\" : \"823006606\",\"mpin\" : \"003421644\",\"category\" : \"Payment Document\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"006633211\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("NICE"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplate1Click() {
        var jsonFileName = "InputJson/docvault/1ClickDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"8937\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-19T09:41:24.289Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"24f425c0-22ea-4b3f-b3e1-44153f6ffd4b\",\"spaceId\":\"8937\",\"fileName\":\"1324096062_1324096117.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"sourceCreatedDate\" : \"2021-07-17T20:16:47.000Z\",\"physicianName\" : \"ARMSTRONG JARED\",\"npi\" : \"\",\"policyNumber\" : \"77014\",\"memberName\" : \"CAMPBELL CAROLEE\",\"notificationId\" : \"A128647630\",\"dateOfService\" : \"2021-08-02T00:00:00.000Z\",\"source\" : \"PRUN\",\"memberId\" : \"934825188\",\"fileDescription\" : \"Medicare Prior Auth/Approved\",\"fileName\" : \"1324096062_1324096117.pdf\",\"subCategory\" : \"A4\",\"filePath\" : \"Medicare Prior Auth/Approved\",\"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\"expiryDate\" : \"2023-07-19T03:40:42.912-06:00\",\"createApplication\" : \"1Click\",\"tin\" : \"861506816\",\"mpin\" : \"003605492\",\"category\" : \"Prior Auth Notification\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"007625251\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("policyNumber"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateNextGen() {
        var jsonFileName = "InputJson/docvault/NextGenDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"8936\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-19T19:54:16.841Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"586ba15f-2c51-4236-b5ad-dec271e4d598\",\"spaceId\":\"8937\",\"fileName\":\"1322567912_1322567915.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"sourceCreatedDate\" : \"2021-07-14T18:50:51.000Z\",\"physicianName\" : \"Jennifer Hsieh\",\"npi\" : \"\",\"policyNumber\" : \"323985\",\"memberName\" : \"Victor Rosenzweig\",\"notificationId\" : \"A128705648\",\"dateOfService\" : \"2021-07-16T00:00:00.000Z\",\"source\" : \"PRUN\",\"memberId\" : \"61253921800\",\"fileDescription\" : \"Commercial Prior Auth/Approved\",\"fileName\" : \"1322567912_1322567915.pdf\",\"subCategory\" : \"A1\",\"filePath\" : \"Commercial Prior Auth/Approved\",\"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\"expiryDate\" : \"2023-07-19T13:51:45.069-06:00\",\"createApplication\" : \"NextGen\",\"tin\" : \"272900232\",\"mpin\" : \"\",\"category\" : \"Prior Auth Notification\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"003225033\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("A1"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateCCSManual() {
        var jsonFileName = "InputJson/docvault/CCSManualDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"8938\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-19T19:27:46.218Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"40a0bcde-52a3-4958-b093-268066835f90\",\"spaceId\":\"8937\",\"fileName\":\"1323978137_1323974610.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"sourceCreatedDate\" : \"2021-07-17T10:25:37.000Z\",\"physicianName\" : \"ELLE FISCH\",\"npi\" : \"\",\"policyNumber\" : \"04Y1891\",\"memberName\" : \"VOGT, BRITTANY L\",\"notificationId\" : \"A128908828\",\"dateOfService\" : \"2021-07-08T00:00:00.000Z\",\"source\" : \"PRUN\",\"memberId\" : \"957714934\",\"fileDescription\" : \"Commercial Prior Auth/Denied\",\"fileName\" : \"1323978137_1323974610.pdf\",\"subCategory\" : \"A2\",\"filePath\" : \"Commercial Prior Auth/Denied\",\"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\"expiryDate\" : \"2023-07-19T13:25:14.703-06:00\",\"createApplication\" : \"CCSManual\",\"tin\" : \"391595302\",\"mpin\" : \"007543546\",\"category\" : \"Prior Auth Notification\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"000131413\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("notificationId"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateDoc1() {
        var jsonFileName = "InputJson/docvault/Doc1Document.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"10103\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-19T11:26:56.335Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"14a75bdc-70d7-40c1-b856-85590b530bb3\",\"spaceId\":\"8937\",\"fileName\":\"DL_000106_OEB_20210719_3682001100_P_1.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"44324512115131\",\"sourceCreatedDate\" : \"2021-07-19T00:00:00.000Z\",\"physicianName\" : \"WESTERN SLEEP MEDICINE LLC\",\"npi\" : \"\",\"policyNumber\" : \"36908\",\"memberName\" : \"MICHAEL L DUNN\",\"dateOfService\" : \"2021-04-22T00:00:00.000Z\",\"source\" : \"PRUN\",\"claimNumber\" : \"3682001100\",\"memberId\" : \"3690897761921700\",\"fileDescription\" : \"Medicare Claim Letter\",\"fileName\" : \"DL_000106_OEB_20210719_3682001100_P_1.pdf\",\"subCategory\" : \"R1\",\"filePath\" : \"Medicare/Additional Info Needed\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2023-07-19T05:24:25.313-06:00\",\"createApplication\" : \"DOC1\",\"tin\" : \"134338749\",\"mpin\" : \"002712605\",\"category\" : \"Claim\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"002712605\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("DOC1"));
    }
    
    @Test
    @RallyTestCase(references = "")
    public void testcreatedDateTemplateNextGen() {
        var jsonFileName = "InputJson/docvault/NextGencreatedDate.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"8936\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-19T19:54:16.841Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"586ba15f-2c51-4236-b5ad-dec271e4d598\",\"spaceId\":\"8937\",\"fileName\":\"1322567912_1322567915.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"sourceCreatedDate\" : \"2021-07-14T18:50:51.000Z\",\"physicianName\" : \"Jennifer Hsieh\",\"policyNumber\" : \"323985\",\"memberName\" : \"Victor Rosenzweig\",\"notificationId\" : \"A128705648\",\"dateOfService\" : \"2021-07-16T00:00:00.000Z\",\"source\" : \"PRUN\",\"memberId\" : \"61253921800\",\"fileDescription\" : \"Commercial Prior Auth/Approved\",\"fileName\" : \"1322567912_1322567915.pdf\",\"subCategory\" : \"A1\",\"filePath\" : \"Commercial Prior Auth/Approved\",\"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\"expiryDate\" : \"2023-07-19T13:51:45.069-06:00\",\"createApplication\" : \"NextGen\",\"tin\" : \"272900232\",\"mpin\" : \"\",\"category\" : \"Prior Auth Notification\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"003225033\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("Commercial Prior Auth/Approved"));
    }
    
    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateUSPPRA() {
        var jsonFileName = "InputJson/docvault/USPPRADocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"10802\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-19T18:38:44.407Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"c60d49c7-be3a-45c2-926f-ab84878ad738\",\"spaceId\":\"8935\",\"fileName\":\"0015843275_00000002.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"\",\"sourceCreatedDate\" : \"2022-07-26T00:00:00.000Z\",\"physicianName\" : \"ABLE TO BEHAVIORAL HEALTH SERVICES PC\",\"checkAmount\" : \"60.00\",\"npi\" : \"\",\"source\" : \"PRUN\",\"checkId\" : \"1629\",\"claimNumber\" : \"|AB7396611V|\",\"paymentNumber\" : \"1629\",\"memberId\" : \"|14831114600|\",\"fileDescription\" : \"Provider Remittance Advice\",\"fileName\" : \"0002973406_00000001.pdf\",\"subCategory\" : \"PR\",\"filePath\" : \"Other PRAs/Other\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2024-08-21T17:00:27.022Z\",\"createApplication\" : \"USP-COM-PRS\",\"tin\" : \"475519672\",\"mpin\" : \"000000000\",\"category\" : \"Payment Document\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("checkAmount"));
    }
    
    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateUSPClaims() {
        var jsonFileName = "InputJson/docvault/USPClaimsDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"10902\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-19T18:38:44.407Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"3415dc81-d52a-4f3f-a4b3-d74e31e7c899\",\"spaceId\":\"8935\",\"fileName\":\"1324512115_1324512115.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"patientAccountNumber\" : \"\",\"sourceCreatedDate\" : \"2021-07-19T00:00:00.000Z\",\"physicianName\" : \"PENNY S TURTEL MD\",\"npi\" : \"\",\"policyNumber\" : \"9F5633\",\"memberName\" : \"LIONEL LUCAS\",\"dateOfService\" : \"2021-07-08T00:00:00.000Z\",\"source\" : \"PRUN\",\"claimNumber\" : \"CV61054877\",\"memberId\" : \"147927246\",\"fileDescription\" : \"Claim status update\",\"fileName\" : \"1324512115_1324512115.pdf\",\"subCategory\" : \"C2\",\"filePath\" : \"Commercial/Acknowledgements\",\"privilege\" : \"Claim Status\",\"expiryDate\" : \"2023-07-19T12:38:43.204-06:00\",\"createApplication\" : \"CIRRUS\",\"tin\" : \"463915494\",\"mpin\" : \"001123845\",\"category\" : \"Claim\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"005280740\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("C2"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateTXGC() {
        var jsonFileName = "InputJson/docvault/TXGCDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"11601\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-19T18:38:44.407Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"3415dc81-d52a-4f3f-a4b3-d74e31e7c899\",\"spaceId\":\"11601\",\"fileName\":\"1324512115_1324512115.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"sourceCreatedDate\" : \"2021-07-19T00:00:00.000Z\",\"source\" : \"PRUN\",\"fileDescription\" : \"Gold Card update\",\"fileName\" : \"1324512115_1324512115.pdf\",\"subCategory\" : \"N4\",\"filePath\" : \"Texas Gold Card/Approved\",\"privilege\" : \"Gold Card Status\",\"expiryDate\" : \"2023-07-19T12:38:43.204-06:00\",\"createApplication\" : \"TXGC\",\"tin\" : \"463915494\",\"mpin\" : \"001123845\",\"category\" : \"Claim\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"005280740\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("Gold Card Status"));
    }
    
    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateCAP() {
        var jsonFileName = "InputJson/docvault/CAPDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected= "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"3415dc81-d52a-4f3f-a4b3-d74e31e7c899\",\"spaceId\":\"11502\",\"fileName\":\"1324512115_1324512115.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"sourceCreatedDate\" : \"2021-07-19T00:00:00.000Z\",\"physicianName\" : \"\",\"dateOfService\" : \"2021-07-08T00:00:00.000Z\",\"source\" : \"PRUN\",\"claimNumber\" : \"\",\"memberId\" : \"\",\"docClass\": \"\",\"fileDescription\" : \"CAP update\",\"fileName\" : \"1324512115_1324512115.pdf\",\"subCategory\" : \"N4\",\"filePath\" : \"CAP/Approved\",\"privilege\" : \"CAP Status\",\"expiryDate\" : \"2023-07-19T12:38:43.204-06:00\",\"createApplication\" : \"CAP\",\"tin\" : \"463915494\",\"mpin\" : \"001123845\",\"category\" : \"Claim\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"005280740\"}}";
        Assert.assertEquals(expected, output);
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplateHouseCalls(){
        var jsonFileName = "InputJson/docvault/HouseCallsDocument.json";
        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        String expected = "{\"fdsDocumentId\" : \"6ad377f9-dd79-46da-85ec-ab1a609cd7bf\",\"space_id\" : \"11803\",\"docClass\" : \"\",\"cloudSpaceId\" : \"8daf3b67-ee46-4850-a3c4-45db19449b4a\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2021-07-12T19:23:28.563Z\",\"attachments\" : [{\"index\":1,\"status\":\"AVAILABLE\",\"fileId\":\"f9cd9fcc-82d0-4162-b267-d6d155dd36fb\",\"spaceId\":\"11803\",\"fileName\":\"0002461881_00000329.pdf\",\"fileSize\":\"481396\",\"contentType\":\"application/pdf\"}],\"metadata\": {\"sourceCreatedDate\" : \"2021-03-22T22:18:51.000Z\",\"source\" : \"PRUN\",\"fileDescription\" : \"Post Assessment Letter\",\"fileName\" : \"\",\"subCategory\" : \"H1\",\"filePath\" : \"House Call/Post Assessment Letter\",\"privilege\" : \"Notification/Prior Authorization Status Inquiry/Update\",\"expiryDate\" : \"2023-03-22T22:18:51.000Z\",\"createApplication\" : \"Schedular\",\"tin\" : \"123456789\",\"mpin\" : \"000123456\",\"category\" : \"House Call\",\"fileType\" : \"Letter\",\"tenant\" : \"Link\",\"corporateMpin\" : \"005280740\"}}";
        Assert.assertNotNull(output);
        Assert.assertTrue(output.contains("House Call"));
    }
    
    @Test
	public void testReplaceSpecialCharacters() {
    FilterReqFieldForDocvaultTemplate filterReqFieldForDocvaultTemplate = new FilterReqFieldForDocvaultTemplate();
	Map<String, String> metadataMap = new HashMap<>();
	DocumentResponse document = new DocumentResponse();
	String metaData = "{\n" +
			"\"fileName\" : \"341049502_341049502.pdf\",\n" +
			"\"CONFIGKEY\" : \"CETPUH_Duplex_Std-NoBox\",\n" +
			"\"providerName\" : \"MUSTAFA ABAS MD\",\n" +
			"\"MailToAddress4\" : \"BELFAST\",\n" +
			"\"docVaultUploadDate\" : \"2021-04-15T21:04:08.773Z\",\n" +
			"\"checkAmount\" : \"0[.00\",\n" +
			"\"claimNumber\" : \"||\",\n" +
			"\"memberName\" : \"CHIA, PARSON\",\n" +
			"\"physicianName\" : \"ELLE, FISCH\",\n" +
			"\"specialCharacters\" : \"\n\n\tPO BOX 8792\t@#!\",\n" +
			"\"dateOfService\" : \"[2021-08-02T00:00:00.000Z]\"\n" +
			"}";
		var metaDataObject = Document.parse(metaData);
		document.setMetadata(metaDataObject);
		filterReqFieldForDocvaultTemplate.removeSpecialCharacters(metadataMap, document, "fileName", "fileName"); //no replace on _.
		filterReqFieldForDocvaultTemplate.removeSpecialCharacters(metadataMap, document, "CONFIGKEY", "CONFIGKEY"); //no replace on _-
		filterReqFieldForDocvaultTemplate.removeSpecialCharacters(metadataMap, document, "providerName", "providerName"); //no replace
		filterReqFieldForDocvaultTemplate.removeSpecialCharacters(metadataMap, document, "toMailToAddress4", "MailToAddress4"); //no replace
		filterReqFieldForDocvaultTemplate.removeSpecialCharacters(metadataMap, document, "docVaultUploadDate", "docVaultUploadDate"); //-:.
		filterReqFieldForDocvaultTemplate.removeSpecialCharacters(metadataMap, document, "checkAmount" , "checkAmount"); // no replace on .
		filterReqFieldForDocvaultTemplate.removeSpecialCharacters(metadataMap, document, "claimNumber" , "claimNumber"); // no replace on pipe
		filterReqFieldForDocvaultTemplate.removeSpecialCharacters(metadataMap, document, "memberName", "memberName"); // no replace on ,
		filterReqFieldForDocvaultTemplate.removeSpecialCharacters(metadataMap, document, "physicianName", "physicianName"); //no replace on ,
		filterReqFieldForDocvaultTemplate.removeSpecialCharacters(metadataMap, document, "toSpecialCharacters", "specialCharacters"); // replace \n\n@#!
		filterReqFieldForDocvaultTemplate.removeSpecialCharacters(metadataMap, document, "dateOfService" , "dateOfService");// no replace on -:.
		System.out.println("testReplaceSpecialCharacters: metadataMap=" + metadataMap);
		Assert.assertEquals("341049502_341049502.pdf", metadataMap.get("fileName"));
		Assert.assertEquals("CETPUH_Duplex_Std-NoBox", metadataMap.get("CONFIGKEY"));
		Assert.assertEquals("MUSTAFA ABAS MD", metadataMap.get("providerName"));
		Assert.assertEquals("BELFAST", metadataMap.get("toMailToAddress4"));
		Assert.assertEquals("2021-04-15T21:04:08.773Z", metadataMap.get("docVaultUploadDate"));
		Assert.assertEquals("0.00", metadataMap.get("checkAmount"));
		Assert.assertEquals("||", metadataMap.get("claimNumber"));
		Assert.assertEquals("CHIA, PARSON", metadataMap.get("memberName"));
		Assert.assertEquals("ELLE, FISCH", metadataMap.get("physicianName"));
		Assert.assertEquals("PO BOX 8792", metadataMap.get("toSpecialCharacters"));
		Assert.assertEquals("2021-08-02T00:00:00.000Z", metadataMap.get("dateOfService"));
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplatePmntEng_DLY() {
        String jsonStr = "{\n" +
                "  \"status\" : \"AVAILABLE\",\n" +
                "  \"dateCreated\" : \"2024-06-01T12:00:00.000Z\",\n" +
                "  \"metadata\" : {\n" +
                "    \"createApplication\" : \"PmntEng\",\n" +
                "    \"tin\" : \"123456789\",\n" +
                "    \"paymentDate\" : \"2024-06-01T12:00:00.000Z\",\n" +
                "    \"paymentType\" : \"DLY\",\n" +
                "    \"filePath\" : \"Payment Summary Reports/Daily\",\n" +
                "    \"fileName\" : \"summary_20240601.pdf\",\n" +
                "    \"paymentNumber\" : \"PAY123456\",\n" +
                "    \"corporateMpin\" : \"000589126\",\n" +
                "    \"createdDate\" : \"2024-06-01T12:00:00.000Z\"\n" +
                "  }\n" +
                "}";

        String output = TemplateFactory
                .getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate())
                .convertWithTemplate(jsonStr);

        String expected = "{\"fdsDocumentId\" : \"\",\"space_id\" : \"\",\"documentClass\" : \"\",\"cloudSpaceId\" : \"\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2024-06-01T12:00:00.000Z\",\"attachments\" : null,\"metadata\": {\"fileName\" : \"summary_20240601.pdf\",\"sourceCreatedDate\" : \"2024-06-01T12:00:00.000Z\",\"source\" : \"PRUN\",\"paymentDate\" : \"2024-06-01T12:00:00.000Z\",\"paymentNumber\" : \"PAY123456\",\"paymentType\" : \"DLY\",\"fileDescription\" : \"\",\"fileName\" : \"summary_20240601.pdf\",\"subCategory\" : \"\",\"filePath\" : \"Payment Summary Reports/Daily\",\"privilege\" : \"\",\"expiryDate\" : \"\",\"createApplication\" : \"PmntEng\",\"tin\" : \"123456789\",\"mpin\" : \"\",\"category\" : \"Payment Documents\",\"fileType\" : \"\",\"tenant\" : \"\",\"corporateMpin\" : \"000589126\"}}";
        Assert.assertEquals(expected, output);
    }

    @Test
    @RallyTestCase(references = "")
    public void testFilterReqFieldForDocvaultTemplatePmntEng_MTY() {
        String jsonStr = "{\n" +
                "  \"status\" : \"AVAILABLE\",\n" +
                "  \"dateCreated\" : \"2024-06-01T12:00:00.000Z\",\n" +
                "  \"metadata\" : {\n" +
                "    \"createApplication\" : \"PmntEng\",\n" +
                "    \"tin\" : \"123456789\",\n" +
                "    \"paymentDate\" : \"2024-06-01T12:00:00.000Z\",\n" +
                "    \"paymentType\" : \"MTY\",\n" +
                "    \"filePath\" : \"Payment Summary Reports/Monthly\",\n" +
                "    \"fileName\" : \"summary_20240601.pdf\",\n" +
                "    \"paymentNumber\" : \"PAY654321\",\n" +
                "    \"corporateMpin\" : \"000589126\",\n" +
                "    \"createdDate\" : \"2024-06-01T12:00:00.000Z\"\n" +
                "  }\n" +
                "}";

        String output = TemplateFactory
                .getInstance(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate())
                .convertWithTemplate(jsonStr);

        String expected = "{\"fdsDocumentId\" : \"\",\"space_id\" : \"\",\"documentClass\" : \"\",\"cloudSpaceId\" : \"\",\"status\" : \"AVAILABLE\",\"dateCreated\" : \"2024-06-01T12:00:00.000Z\",\"attachments\" : null,\"metadata\": {\"fileName\" : \"summary_20240601.pdf\",\"sourceCreatedDate\" : \"2024-06-01T12:00:00.000Z\",\"source\" : \"PRUN\",\"paymentDate\" : \"2024-06-01T12:00:00.000Z\",\"paymentNumber\" : \"PAY654321\",\"paymentType\" : \"MTY\",\"fileDescription\" : \"\",\"fileName\" : \"summary_20240601.pdf\",\"subCategory\" : \"\",\"filePath\" : \"Payment Summary Reports/Monthly\",\"privilege\" : \"\",\"expiryDate\" : \"\",\"createApplication\" : \"PmntEng\",\"tin\" : \"123456789\",\"mpin\" : \"\",\"category\" : \"Payment Documents\",\"fileType\" : \"\",\"tenant\" : \"\",\"corporateMpin\" : \"000589126\"}}";
        Assert.assertEquals(expected, output);
    }
}
