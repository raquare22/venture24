package com.optum.fds.paperless.template;

import java.io.IOException;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class NGSResponseTemplateTest {
	
	@Test
	public void NGSResponseFileTest() throws IOException, JSONException
	{
		var jsonFileName ="InputJson/NGSResponse.json";
		
		var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
		String output = TemplateFactory.getInstance(Templates.NGS_RESPONSE.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        
        String expected = "Format|MeterDate|CaseID|HistoryID|ZipFileName\n" +
                "Emailed|11-15-2020 02:07:58|K1931126006|89320918|20200725010021_ETS_PDF_3256.zip\n" +
                "Emailed|11-15-2020 02:07:58|U2041205003|89502785|20200728010038_ETS_PDF_3256.zip\n" +
                "Emailed|11-15-2020 02:07:58|W2061847015|89574175|20200728010038_ETS_PDF_3256.zip\n" +
                "Emailed|10-15-2020 03:07:58|W2060850031|89574175|20200728010038_ETS_PDF_3256.zip";
        
        Assert.assertEquals(expected, output);
        
        String jsonString= WorkFlowUtil.readDocumentsFromJsonFileToString(jsonFile);
        
        output=TemplateFactory.getInstance(Templates.NGS_RESPONSE.getTemplate()).convertWithTemplate(jsonString);
        
        Assert.assertEquals(expected, output);
		
	}

}
