package com.optum.fds.paperless.template;

import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;

public class TXGCCsvDocumentTest {

	@Test
	public void testTXGCsvTemplate() {
		var jsonFileName = "csv/P360.csv";

		var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
		String output = TemplateFactory.getInstance(Templates.TXGC_CSV_DOCUMENT.getTemplate())
				.convertWithTemplateFromFilePath(jsonFile);
		System.out.println(output);
		
		String expected = "{\"Documents\": [{\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"P360\",\"procedureClinicalGroupId\" : \"groupId\",\n"
				+ "               \"exemptionFlag\" : \"Y\",\n"
				+ "               \"exemptionEffectiveStartDate\" : \"12/28/23\",\n"
				+ "               \"providerNPI\" : \"123456\",\n"
				+ "               \"procedureCodeType\" : \"TEST\",\n"
				+ "               \"cycleEndDate\" : \"12/28/23\",\n"
				+ "               \"cycleStartDate\" : \"12/28/23\",\n"
				+ "               \"procCodeDescription\" : \"description\",\n"
				+ "               \"procedureClinicalGroupType\" : \"groupType\",\n"
				+ "               \"exemptionEffectiveEndDate\" : \"12/28/23\",\n"
				+ "               \"stateCode\" : \"TX\",\n"
				+ "               \"approvalRate\" : \"approvalRate\",\n"
				+ "               \"numberOfCodesInCluster\" : \"123\"}},\n"
				+ "               {\"status\" : \"AVAILABLE\",\"metadata\": {\"createApplication\": \"P360\",\"procedureClinicalGroupId\" : \"groupId\",\n"
				+ "               \"exemptionFlag\" : \"Y\",\n"
				+ "               \"exemptionEffectiveStartDate\" : \"12/28/23\",\n"
				+ "               \"providerNPI\" : \"123456\",\n"
				+ "               \"procedureCodeType\" : \"TEST\",\n"
				+ "               \"cycleEndDate\" : \"12/28/23\",\n"
				+ "               \"cycleStartDate\" : \"12/28/23\",\n"
				+ "               \"procCodeDescription\" : \"description\",\n"
				+ "               \"procedureClinicalGroupType\" : \"groupType\",\n"
				+ "               \"exemptionEffectiveEndDate\" : \"12/28/23\",\n"
				+ "               \"stateCode\" : \"TX\",\n"
				+ "               \"approvalRate\" : \"approvalRate\",\n"
				+ "               \"numberOfCodesInCluster\" : \"123\"}}]}";
		
		Assert.assertEquals(expected, output);

	}

	
}
