package com.optum.fds.paperless.template;

import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;

public class CAPResponseTemplateTest {

	@Test
	public void testCAPResponseTemplate() {
		var jsonFileName = "InputJson/CAPResponse.json";

		var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
		String output = TemplateFactory.getInstance(Templates.CAP_RESPONSE.getTemplate())
				.convertWithTemplateFromFilePath(jsonFile);
		System.out.println(output);

		String expected = "deliveryFormat,documentLibraryDate,emailNotificationDate,letterId,eDeliverySuccessful,documentId,eDeliveryError,emailAlertReq\n"
				+ " emailed,20220520T22:35:18.077Z,20240301T07:20:00.234Z,6577deffd1c84706ea439851,yes,,,Y\n"
				+ " paper,,,6577deffd1c84706ea439852,no,,Missing or invalid data: corporateMpin,N\n"
				+ " emailed,20220520T22:35:18.077Z,20240301T07:20:00.234Z,6577deffd1c84706ea439853,yes,,,Y\n"
				+ " postcard,20220520T22:35:18.077Z,,6577deffd1c84706ea439854,yes,,,Y\n";
//		Assert.assertEquals(expected, output);
		Assert.assertTrue(output.contains("postcard"));
	}


}

