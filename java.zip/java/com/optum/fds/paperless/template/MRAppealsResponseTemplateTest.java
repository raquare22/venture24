package com.optum.fds.paperless.template;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.java.impl.MRAppealsResponseTemplate; // Add this import
import com.optum.fds.paperless.template.java.TemplateFactory;
import org.junit.Assert;
import org.junit.Test;

import org.mockito.Mockito;

import java.lang.reflect.Method;

import static org.junit.Assert.assertEquals;

@UserStory(references = "")
public class MRAppealsResponseTemplateTest {

    @Test
    @RallyTestCase(references = "")
    public void testMRAppealsResponseTemplate() {
        var jsonFileName = "InputJson/MRAppealResponseFile.json";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.MR_APPEALS_RESPONSE.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);

        String expected = "Case_Id|LetterFilename|NGSID|Original_Zip_file|Preference|Delivery_Status|EmailAddress|UploadDateTime|EmailDateTime|EmailFailure_Reason\n" +
                "ST004567|appeals_00001.pdf|C-00666CC|BP_MBR_NGS_32723_0519202041504.zip|E|UPLOADED|GIANINABLANK@GMAIL.COM|06-27-2017 21:14:44|06-27-2017 21:14:44|Bounced email\n" +
                "AT004567|appeals_00002.pdf|C-00666AA|BP_MBR_NGS_32723_0519202041504.zip|E|UPLOADED|abcd123@GMAIL.COM|06-27-2017 21:14:44|06-27-2017 21:14:44|\n" +
                "BT004567|appeals_00003.pdf|C-00666BB|BP_MBR_NGS_32723_0519202041504.zip|E|FAILED|abcd123@GMAIL.COM|06-27-2017 21:14:44|06-27-2017 21:14:44|";

        Assert.assertEquals(expected, output);
    }
    @Test
    public void testConvertDateToCSTFormat() throws Exception {
        MRAppealsResponseTemplate template = Mockito.spy(new MRAppealsResponseTemplate());
        String inputDate = "2017-06-28T02:14:44.378Z";
        String expectedDate = "06-27-2017 21:14:44";

        // Use reflection to access the private method
        Method method = MRAppealsResponseTemplate.class.getDeclaredMethod("convertDateToCSTFormat", String.class);
        method.setAccessible(true);
        String actualDate = (String) method.invoke(template, inputDate);

        assertEquals(expectedDate, actualDate);
    }
}