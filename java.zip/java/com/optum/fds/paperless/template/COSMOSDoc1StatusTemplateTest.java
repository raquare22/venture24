package com.optum.fds.paperless.template;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import org.junit.Assert;
import org.junit.Test;

@UserStory(references = "")
public class COSMOSDoc1StatusTemplateTest {

    @Test
    @RallyTestCase(references = "")
    public void testCOSMOSDoc1StatusTemplate() {

        String json = "{\n" +
                "	\"FileNameList\": [{\n" +
                "		\"Status\": \"Failed\",\n" +
                "		\"FileName\": \"Test1.pdf\"\n" +
                "	}, {\n" +
                "		\"Status\": \"Failed\",\n" +
                "		\"FileName\": \"Test2.pdf\"\n" +
                "	}, {\n" +
                "		\"Status\": \"Success\",\n" +
                "		\"FileName\": \"Test3.pdf\"\n" +
                "	}, {\n" +
                "		\"Status\": \"Success\",\n" +
                "		\"FileName\": \"Test4.pdf\"\n" +
                "	}],\n" +
                "	\"BatchID\": \"FDS_PDF_Y_20181206_045\",\n" +
                "	\"Count\": 2,\n" +
                "	\"UploadDate\": \"2018-09-27T07:54:27.000Z\"\n" +
                "}";

        String output = TemplateFactory.getInstance(Templates.COSMOS_DOC1_STATUS.getTemplate()).convertWithTemplate(json);
        System.out.println(output);

        String expected = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<Batch>\n" +
                "<BatchID>FDS_PDF_Y_20181206_045</BatchID>\n" +
                "<Count>2</Count>\n" +
                "<UploadDate>20180927</UploadDate>\n" +
                "<FileNameList>\n" +
                "<FileName Status=\"Failed\">Test1.pdf</FileName>\n" +
                "<FileName Status=\"Failed\">Test2.pdf</FileName>\n" +
                "<FileName Status=\"Success\">Test3.pdf</FileName>\n" +
                "<FileName Status=\"Success\">Test4.pdf</FileName>\n" +
                "</FileNameList>\n" +
                "</Batch>";

        Assert.assertEquals(expected, output);

    }

    @Test
    @RallyTestCase(references = "")
    public void testApplyTemplateforCOSMOSDoc1StatusWithoutFileNameListAndUploadDate() {

        String json = "{\n" +
                "	\"BatchID\": \"FDS_PDF_Y_20181206_045\",\n" +
                "	\"Count\": 0\n" +
                "}";

        String output = TemplateFactory.getInstance(Templates.COSMOS_DOC1_STATUS.getTemplate()).convertWithTemplate(json);
        System.out.println(output);

        String expected = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<Batch>\n" +
                "<BatchID>FDS_PDF_Y_20181206_045</BatchID>\n" +
                "<Count>0</Count>\n" +
                "<UploadDate></UploadDate>\n" +
                "<FileNameList>\n"
                + "\n"
                + "</FileNameList>\n" +
                "</Batch>";

        Assert.assertEquals(expected, output);
    }
}