package com.optum.fds.paperless.template;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;

public class CosmosPRACompanionTemplateTest {

    private static final String TEMPLATE = "COSMOS_PRA_COMPANION";
    protected static final String INPUT_CMP = "COSMOSPRACompanion.cmp";

    @Test
    @UserStory(references = "")
    @RallyTestCase(references = "")
    public void testApplyCosmosWritePRACompanionTemplate() throws IOException {
        var cmpFileName = "cmp/COSMOSPRACompanion.cmp";

        var cmpFile = Thread.currentThread().getContextClassLoader().getResource(cmpFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.COSMOS_PRA_COMPANION.getTemplate())
                .convertWithTemplate(cmpFile);
        System.out.println(output);
        String expected = "[{\"BARCODE\":\"145ZAAPIU00000202\",\"BARCODE_FIFTEEN\":\"145ZAAPIU000002\",\"DIV\":\"MSP\",\"memberNumber\":\"90253-946578522-00\",\"memberName\":\"CURTIS, CURT A.\",\"claimNumber\":\"42069070-00\",\"mediaType\":\"PRA\",\"claimSystem\":\"COSMOS\"},\n" + 
        		" {\"BARCODE\":\"145ZAAPIU00000302\",\"BARCODE_FIFTEEN\":\"145ZAAPIU000003\",\"DIV\":\"MSP\",\"memberNumber\":\"70219-916698065-00\",\"memberName\":\"BETKER, KATHLEEN K.\",\"claimNumber\":\"42069144-00\",\"mediaType\":\"PRA\",\"claimSystem\":\"COSMOS\"},\n" + 
        		" {\"BARCODE\":\"145ZAAPIU00000302\",\"BARCODE_FIFTEEN\":\"145ZAAPIU000003\",\"DIV\":\"MSP\",\"memberNumber\":\"70270-937666578-00\",\"memberName\":\"CUDD, DOUGLAS J.\",\"claimNumber\":\"42069146-00\",\"mediaType\":\"PRA\",\"claimSystem\":\"COSMOS\"},\n" + 
        		" {\"BARCODE\":\"145ZAAPIU\",\"BARCODE_FIFTEEN\":\"145ZAAPIU\",\"DIV\":\"MSP\",\"memberNumber\":\"70270-937666578-00\",\"memberName\":\"CUDD, DOUGLAS J.\",\"claimNumber\":\"42069146-00\",\"mediaType\":\"PRA\",\"claimSystem\":\"COSMOS\"},\n" + 
        		" {\"BARCODE\":\"145ZAAPIU\",\"BARCODE_FIFTEEN\":\"145ZAAPIU\",\"DIV\":\"MSP\",\"memberNumber\":\"70270-937666578-00\",\"memberName\":\"CUDD, DOUGLAS J.\",\"claimNumber\":\"42069146-00\",\"mediaType\":\"PRA\",\"claimSystem\":\"COSMOS\"}]";
        Assert.assertEquals(expected, output);

    }
}