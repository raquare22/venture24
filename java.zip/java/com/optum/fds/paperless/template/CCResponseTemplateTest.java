package com.optum.fds.paperless.template;

import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;

public class CCResponseTemplateTest {

	@Test
	public void testCCResponseTemplate() {
		var jsonFileName = "InputJson/CCResponse.json";

		var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
		String output = TemplateFactory.getInstance(Templates.CC_RESPONSE.getTemplate())
				.convertWithTemplateFromFilePath(jsonFile);
		System.out.println(output);
		
		String expected = "tin,corporateMpin,providerEmailId,dateEmailSent,eDeliveryError\n"
				+ " 351913875,001160933,,20200626T10:49:00.000Z,\n"
				+ " 351913875,001160933,,20200626T10:49:00.000Z,\n"
				+ " 351913875,001160933,,20200626T10:49:00.000Z,Missing or invalid data: corporateMpin|Missing or invalid data: providerEmailId|Missing or invalid data: mpin|Missing or invalid data: tin|Missing or invalid data: email bounced\n"
				+ " 351913875,001160933,,20200626T10:49:00.000Z,Missing or invalid data: email bounced";
//		Assert.assertEquals(expected, output);
		Assert.assertTrue(output.contains("351913875,001160933"));

	}

	
}
