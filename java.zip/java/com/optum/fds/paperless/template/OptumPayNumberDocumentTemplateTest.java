package com.optum.fds.paperless.template;

import com.optum.fds.paperless.template.java.impl.OptumPayNumberDocumentTemplate;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.core.config.Configurator;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.java.TemplateFactory;

public class OptumPayNumberDocumentTemplateTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(OptumPayNumberDocumentTemplateTest.class);

	@Test
	public void testOptumPayNumberDocumentTemplate() {
		var filePath = "InputTxtFile/AccountsPayableFileTest.txt";
		var file = Thread.currentThread().getContextClassLoader().getResource(filePath).getPath();
		String output = TemplateFactory.getInstance(Templates.OPTUM_PAY_NUMBER_DOCUMENT.getTemplate()).convertWithTemplateFromFilePath(file);
		String expected = "{\"Documents\": [{\"status\" : \"AVAILABLE\",\"fileType\" : \"APFile\",\"metadata\": {\"payerId\" : \"00008772\",\"payerAdditionalId\" : \"80560000\",\"npi\" : \"115453506\",\"providerTin\" : \"75300266\",\"unconsolidatedPaymentNumber\" : \"2022120310800834\",\"unconsolidatedPaymentAmt\" : \"000002922\",\"consolidatedPaymentNumber\" : \"1844299390\",\"consolidatedPaymentAmt\" : \"000002922\",\"origPaymentMethod\" : \"AC\",\"payeeName\" : \"MARIA C DAVILA MD\",\"origPaymentDate\" : \"2022120\",\"checkNumber\" : \"\",\"revisedPaymentMethod\" : \"\",\"norCode\": \"\",\"vcpStatus\": \"\",\"reOriginatedDate\": \"\"}},\n"
				+ "               {\"status\" : \"AVAILABLE\",\"fileType\" : \"APFile\",\"metadata\": {\"payerId\" : \"00008772\",\"payerAdditionalId\" : \"80560000\",\"npi\" : \"134665861\",\"providerTin\" : \"46470894\",\"unconsolidatedPaymentNumber\" : \"2022120310400382\",\"unconsolidatedPaymentAmt\" : \"000005110\",\"consolidatedPaymentNumber\" : \"1844299393\",\"consolidatedPaymentAmt\" : \"000005110\",\"origPaymentMethod\" : \"AC\",\"payeeName\" : \"Doctor On Demand Professionals of California PC\",\"origPaymentDate\" : \"2022120\",\"checkNumber\" : \"\",\"revisedPaymentMethod\" : \"\",\"norCode\": \"\",\"vcpStatus\": \"\",\"reOriginatedDate\": \"\"}},\n"
				+ "               {\"status\" : \"AVAILABLE\",\"fileType\" : \"APFile\",\"metadata\": {\"payerId\" : \"00008772\",\"payerAdditionalId\" : \"80560000\",\"npi\" : \"185188653\",\"providerTin\" : \"83056737\",\"unconsolidatedPaymentNumber\" : \"2022120310901691\",\"unconsolidatedPaymentAmt\" : \"000001086\",\"consolidatedPaymentNumber\" : \"1844299394\",\"consolidatedPaymentAmt\" : \"000003819\",\"origPaymentMethod\" : \"AC\",\"payeeName\" : \"CALA Psychological Services\",\"origPaymentDate\" : \"2022120\",\"checkNumber\" : \"\",\"revisedPaymentMethod\" : \"\",\"norCode\": \"\",\"vcpStatus\": \"\",\"reOriginatedDate\": \"\"}},\n"
				+ "               {\"status\" : \"AVAILABLE\",\"fileType\" : \"APFile\",\"metadata\": {\"payerId\" : \"00008772\",\"payerAdditionalId\" : \"80560000\",\"npi\" : \"185188653\",\"providerTin\" : \"83056737\",\"unconsolidatedPaymentNumber\" : \"2022120311001419\",\"unconsolidatedPaymentAmt\" : \"000000859\",\"consolidatedPaymentNumber\" : \"1844299394\",\"consolidatedPaymentAmt\" : \"000003819\",\"origPaymentMethod\" : \"AC\",\"payeeName\" : \"CALA Psychological Services\",\"origPaymentDate\" : \"2022120\",\"checkNumber\" : \"\",\"revisedPaymentMethod\" : \"\",\"norCode\": \"\",\"vcpStatus\": \"\",\"reOriginatedDate\": \"\"}},\n"
				+ "               {\"status\" : \"AVAILABLE\",\"fileType\" : \"APFile\",\"metadata\": {\"payerId\" : \"00008772\",\"payerAdditionalId\" : \"80560000\",\"npi\" : \"185188653\",\"providerTin\" : \"83056737\",\"unconsolidatedPaymentNumber\" : \"2022120311001264\",\"unconsolidatedPaymentAmt\" : \"000001873\",\"consolidatedPaymentNumber\" : \"1844299394\",\"consolidatedPaymentAmt\" : \"000003819\",\"origPaymentMethod\" : \"AC\",\"payeeName\" : \"CALA Psychological Services\",\"origPaymentDate\" : \"2022120\",\"checkNumber\" : \"\",\"revisedPaymentMethod\" : \"\",\"norCode\": \"\",\"vcpStatus\": \"\",\"reOriginatedDate\": \"\"}},\n"
				+ "               {\"status\" : \"AVAILABLE\",\"fileType\" : \"APFile\",\"metadata\": {\"payerId\" : \"00008772\",\"payerAdditionalId\" : \"80560000\",\"npi\" : \"165974949\",\"providerTin\" : \"47486160\",\"unconsolidatedPaymentNumber\" : \"2022120310900092\",\"unconsolidatedPaymentAmt\" : \"000000517\",\"consolidatedPaymentNumber\" : \"1844299396\",\"consolidatedPaymentAmt\" : \"000000517\",\"origPaymentMethod\" : \"AC\",\"payeeName\" : \"Walnut Psychotherapy Center LLC\",\"origPaymentDate\" : \"2022120\",\"checkNumber\" : \"\",\"revisedPaymentMethod\" : \"\",\"norCode\": \"\",\"vcpStatus\": \"\",\"reOriginatedDate\": \"\"}},\n"
				+ "               {\"status\" : \"AVAILABLE\",\"fileType\" : \"APFile\",\"metadata\": {\"payerId\" : \"00008772\",\"payerAdditionalId\" : \"80560000\",\"npi\" : \"144737427\",\"providerTin\" : \"03752830\",\"unconsolidatedPaymentNumber\" : \"2022120311200433\",\"unconsolidatedPaymentAmt\" : \"000001050\",\"consolidatedPaymentNumber\" : \"1844299400\",\"consolidatedPaymentAmt\" : \"000003554\",\"origPaymentMethod\" : \"AC\",\"payeeName\" : \"Heather Woodward\",\"origPaymentDate\" : \"2022120\",\"checkNumber\" : \"\",\"revisedPaymentMethod\" : \"\",\"norCode\": \"\",\"vcpStatus\": \"\",\"reOriginatedDate\": \"\"}}]}";
		Assert.assertEquals(expected, output);
	}

	@UserStory(references = "US6701787")
	@RallyTestCase(references = "TC4103992")
	@Test
	public void testOptumPayNumberDocumentTemplateSmallFileSplit() {
		Configurator.setAllLevels("", Level.INFO);
		var file = "src/test/resources/csv/UHC4_AP20231120005124_v4_small.txt";
		boolean done = false;
		String documentMetaDataListStr = null;
		OptumPayNumberDocumentTemplate templateHandler = (OptumPayNumberDocumentTemplate) TemplateFactory.getInstance(Templates.OPTUM_PAY_NUMBER_DOCUMENT.getTemplate());
		templateHandler.setSplitPerMbSize(1);
		templateHandler.setSplitFileMaxBytesNewLineWithin(1024);
		LOGGER.info("Running SPLIT");
		while (! done) {
			documentMetaDataListStr = templateHandler.convertWithTemplateFromFilePath(file);
			LOGGER.info("SPLIT documentMetaDataListStr: \n{}", documentMetaDataListStr);
			if (templateHandler instanceof OptumPayNumberDocumentTemplate) {
				done = ((OptumPayNumberDocumentTemplate) templateHandler).isDone();
			} else {
				done = true;
			}
		}
	}

	@UserStory(references = "US6701787")
	@RallyTestCase(references = "TC4103992")
	@Test
	public void testOptumPayNumberDocumentTemplateSmallFileNonSplit() {
		Configurator.setAllLevels("", Level.INFO);
		var file = "src/test/resources/csv/UHC4_AP20231120005124_v4_small.txt";
		boolean done = false;
		String documentMetaDataListStr = null;
		OptumPayNumberDocumentTemplate templateHandler = (OptumPayNumberDocumentTemplate) TemplateFactory.getInstance(Templates.OPTUM_PAY_NUMBER_DOCUMENT.getTemplate());
		templateHandler.setSplitPerMbSize(10);
		templateHandler.setSplitFileMaxBytesNewLineWithin(1024);
		LOGGER.info("Running NON SPLIT");
		while (! done) {
			documentMetaDataListStr = templateHandler.convertWithTemplateFromFilePath(file);
			LOGGER.info("NON SPLIT documentMetaDataListStr: \n{}", documentMetaDataListStr);
			if (templateHandler instanceof OptumPayNumberDocumentTemplate) {
				done = ((OptumPayNumberDocumentTemplate) templateHandler).isDone();
			} else {
				done = true;
			}
		}
	}

	@UserStory(references = "US6701787")
	@RallyTestCase(references = "TC4103992")
	@Test
	public void testOptumPayNumberDocumentTemplateLargeFile() {
		Configurator.setAllLevels("", Level.INFO);
		var file = "src/test/resources/csv/UHC4_AP20231120005124_v4.txt";

		boolean done = false;
		String documentMetaDataListStr = null;
		OptumPayNumberDocumentTemplate templateHandler = (OptumPayNumberDocumentTemplate) TemplateFactory.getInstance(Templates.OPTUM_PAY_NUMBER_DOCUMENT.getTemplate());
		templateHandler.setSplitPerMbSize(4);
		templateHandler.setSplitFileMaxBytesNewLineWithin(1024);
		LOGGER.info("Running SPLIT 13 parts");
		while (! done) {
			documentMetaDataListStr = templateHandler.convertWithTemplateFromFilePath(file);
			LOGGER.info("SPLIT documentMetaDataListStr: documentMetaDataListStr.length={}", documentMetaDataListStr.length());
			if (templateHandler instanceof OptumPayNumberDocumentTemplate) {
				done = ((OptumPayNumberDocumentTemplate) templateHandler).isDone();
			} else {
				done = true;
			}
		}

		done = false;
		documentMetaDataListStr = null;
		templateHandler = (OptumPayNumberDocumentTemplate) TemplateFactory.getInstance(Templates.OPTUM_PAY_NUMBER_DOCUMENT.getTemplate());
		templateHandler.setSplitPerMbSize(24);
		templateHandler.setSplitFileMaxBytesNewLineWithin(1024);
		LOGGER.info("Running SPLIT 3 parts");
		while (! done) {
			documentMetaDataListStr = templateHandler.convertWithTemplateFromFilePath(file);
			LOGGER.info("SPLIT documentMetaDataListStr: documentMetaDataListStr.length={}", documentMetaDataListStr.length());
			if (templateHandler instanceof OptumPayNumberDocumentTemplate) {
				done = ((OptumPayNumberDocumentTemplate) templateHandler).isDone();
			} else {
				done = true;
			}
		}
		
		done = false;
		documentMetaDataListStr = null;
		templateHandler = (OptumPayNumberDocumentTemplate) TemplateFactory.getInstance(Templates.OPTUM_PAY_NUMBER_DOCUMENT.getTemplate());
		templateHandler.setSplitPerMbSize(128);
		templateHandler.setSplitFileMaxBytesNewLineWithin(1024);
		LOGGER.info("Running NON SPLIT");
		while (! done) {
			documentMetaDataListStr = templateHandler.convertWithTemplateFromFilePath(file);
			LOGGER.info("NON SPLIT documentMetaDataListStr: documentMetaDataListStr.length={}", documentMetaDataListStr.length());
			if (templateHandler instanceof OptumPayNumberDocumentTemplate) {
				done = ((OptumPayNumberDocumentTemplate) templateHandler).isDone();
			} else {
				done = true;
			}
		}
	}
}
