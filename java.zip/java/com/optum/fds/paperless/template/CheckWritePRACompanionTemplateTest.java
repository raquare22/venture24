package com.optum.fds.paperless.template;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.FileInputStream;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;

public class CheckWritePRACompanionTemplateTest {

	private static final String TEMPLATE = "CheckWrite_PRA_Companion";
	protected static final String INPUT_JSON = "CheckWritePRACompanionSampleInput.json";

	@Test
	@UserStory(references = "US26195")
	@RallyTestCase(references = "TC30170")
	public void testApplyCheckWritePRACompanionTemplate() throws IOException {
		var jsonFileName = "InputJson/CheckWritePRACompanionSampleInput.json";

		var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
		String output = TemplateFactory.getInstance(Templates.CHECK_WRITE_PRA_COMPANION.getTemplate())
				.convertWithTemplateFromFilePath(jsonFile);
		System.out.println(output);
		String expected = "BARCODE|DIV|MEMBER NUMBER|MEMBER NAME|CLAIM NUMBER|MEDIA TYPE|CLAIM SYSTEM\n"
				+ "145ZAAPIU00000301|MSP|70219-916698066-00|DOE2, JOHN K.                 |42069144-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000301|MSP|70270-937666579-00|DOE3, JOHN J.                 |42069146-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000301|MSP|70270-937666559-00|DOE4, JOHN J.                 |42069156-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000302|MSP|80219-916698065-00|DOE2, JOHN K.                 |42069143-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000302|MSP|80270-937666578-00|DOE3, JOHN J.                 |42069145-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000303|MSP|80219-916698064-00|DOE2, JOHN K.                 |42069142-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000303|MSP|80270-937666577-00|DOE3, JOHN J.                 |42069141-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000303|MSP|80270-937666557-00|DOE4, JOHN J.                 |42069149-01|PRA|COSMOS\n"
				+ "TRL|000000008";
		Assert.assertEquals(expected, output);

	}
	
	@Test
	public void testWithJsonString() {
		
		String jsonString = "{\n" + 
				"	\"Documents\": [{\n" + 
				"			\"spaceId\": 10068,\n" + 
				"			\"metadata\": {\n" + 
				"				\"fileName\": \"223796_336607.pdf\",\n" + 
				"				\"originalPrintTrail\": \"3206\",\n" + 
				"				\"originalCompanionFileRecords\": [\n" + 
				"					\"145ZAAPIU00000301|MSP|70219-916698066-00|DOE2, JOHN K.                 |42069144-01|PRA|COSMOS\",\n" + 
				"					\"145ZAAPIU00000301|MSP|70270-937666579-00|DOE3, JOHN J.                 |42069146-01|PRA|COSMOS\",\n" + 
				"					\"145ZAAPIU00000301|MSP|70270-937666559-00|DOE4, JOHN J.                 |42069156-01|PRA|COSMOS\"\n" + 
				"				],\n" + 
				"				\"merged\": true\n" + 
				"			},\n" + 
				"			\"dateCreated\": \"Fri Jul 27 09:10:46 UTC 2018\",\n" + 
				"			\"clientId\": 685,\n" + 
				"			\"documentAttachments\": [{\n" + 
				"				\"file_name\": \"223796_336607.pdf\",\n" + 
				"				\"id\": \"a04a2f3a-7370-4ffa-8ff8-872811514581\",\n" + 
				"				\"index\": 1\n" + 
				"			}],\n" + 
				"			\"dateModified\": \"Fri Jul 27 09:10:46 UTC 2018\",\n" + 
				"			\"id\": \"5b476f1dad515477dcb8b7cd\",\n" + 
				"			\"appIdentifier\": \"mof6yifgxpgmd49d0ltk7xkqai8rjqa7\",\n" + 
				"			\"transactionId\": \"0a4738b9-873c-4a76-9f2d-2dc65b3a58ce\",\n" + 
				"			\"status\": \"AVAILABLE\"\n" + 
				"		},\n" + 
				"		{\n" + 
				"			\"spaceId\": 10068,\n" + 
				"			\"metadata\": {\n" + 
				"				\"fileName\": \"223796_336608.pdf\",\n" + 
				"				\"originalPrintTrail\": \"3206\",\n" + 
				"				\"originalCompanionFileRecords\": [\n" + 
				"					\"145ZAAPIU00000302|MSP|80219-916698065-00|DOE2, JOHN K.                 |42069143-01|PRA|COSMOS\",\n" + 
				"					\"145ZAAPIU00000302|MSP|80270-937666578-00|DOE3, JOHN J.                 |42069145-01|PRA|COSMOS\"\n" + 
				"				],\n" + 
				"				\"merged\": true\n" + 
				"			},\n" + 
				"			\"dateCreated\": \"Fri Jul 27 09:11:46 UTC 2018\",\n" + 
				"			\"clientId\": 685,\n" + 
				"			\"documentAttachments\": [{\n" + 
				"				\"file_name\": \"223796_336608.pdf\",\n" + 
				"				\"id\": \"a04a2f3a-7370-4ffa-8ff8-872811514582\",\n" + 
				"				\"index\": 1\n" + 
				"			}],\n" + 
				"			\"dateModified\": \"Fri Jul 27 09:11:46 UTC 2018\",\n" + 
				"			\"id\": \"5b476f1dad515477dcb8b7ce\",\n" + 
				"			\"appIdentifier\": \"mof6yifgxpgmd49d0ltk7xkqai8rjqa7\",\n" + 
				"			\"transactionId\": \"0a4738b9-873c-4a76-9f2d-2dc65b3a58ce\",\n" + 
				"			\"status\": \"AVAILABLE\"\n" + 
				"		},\n" + 
				"		{\n" + 
				"			\"spaceId\": 10068,\n" + 
				"			\"metadata\": {\n" + 
				"				\"fileName\": \"223796_336609.pdf\",\n" + 
				"				\"originalPrintTrail\": \"3206\",\n" + 
				"				\"originalCompanionFileRecords\": [\n" + 
				"					\"145ZAAPIU00000303|MSP|80219-916698064-00|DOE2, JOHN K.                 |42069142-01|PRA|COSMOS\",\n" + 
				"					\"145ZAAPIU00000303|MSP|80270-937666577-00|DOE3, JOHN J.                 |42069141-01|PRA|COSMOS\",\n" + 
				"					\"145ZAAPIU00000303|MSP|80270-937666557-00|DOE4, JOHN J.                 |42069149-01|PRA|COSMOS\"\n" + 
				"				],\n" + 
				"				\"merged\": true\n" + 
				"			},\n" + 
				"			\"dateCreated\": \"Fri Jul 27 09:12:46 UTC 2018\",\n" + 
				"			\"clientId\": 685,\n" + 
				"			\"documentAttachments\": [{\n" + 
				"				\"file_name\": \"223796_336609.pdf\",\n" + 
				"				\"id\": \"a04a2f3a-7370-4ffa-8ff8-872811514582\",\n" + 
				"				\"index\": 1\n" + 
				"			}],\n" + 
				"			\"dateModified\": \"Fri Jul 27 09:12:46 UTC 2018\",\n" + 
				"			\"id\": \"5b476f1dad515477dcb8b7cf\",\n" + 
				"			\"appIdentifier\": \"mof6yifgxpgmd49d0ltk7xkqai8rjqa7\",\n" + 
				"			\"transactionId\": \"0a4738b9-873c-4a76-9f2d-2dc65b3a58ce\",\n" + 
				"			\"status\": \"AVAILABLE\"\n" + 
				"		}\n" + 
				"	]\n" + 
				"}";
		
		String output = TemplateFactory.getInstance(Templates.CHECK_WRITE_PRA_COMPANION.getTemplate())
				.convertWithTemplate(jsonString);
		System.out.println(output);
		String expected = "BARCODE|DIV|MEMBER NUMBER|MEMBER NAME|CLAIM NUMBER|MEDIA TYPE|CLAIM SYSTEM\n"
				+ "145ZAAPIU00000301|MSP|70219-916698066-00|DOE2, JOHN K.                 |42069144-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000301|MSP|70270-937666579-00|DOE3, JOHN J.                 |42069146-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000301|MSP|70270-937666559-00|DOE4, JOHN J.                 |42069156-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000302|MSP|80219-916698065-00|DOE2, JOHN K.                 |42069143-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000302|MSP|80270-937666578-00|DOE3, JOHN J.                 |42069145-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000303|MSP|80219-916698064-00|DOE2, JOHN K.                 |42069142-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000303|MSP|80270-937666577-00|DOE3, JOHN J.                 |42069141-01|PRA|COSMOS\n"
				+ "145ZAAPIU00000303|MSP|80270-937666557-00|DOE4, JOHN J.                 |42069149-01|PRA|COSMOS\n"
				+ "TRL|000000008";
		Assert.assertEquals(expected, output);
	}
}
