package com.optum.fds.paperless.template;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;

import org.bson.Document;
import org.junit.Assert;
import org.junit.Test;

@UserStory(references = "US32409")
public class EmailRequestToPENTemplateTest {

    @Test
    @RallyTestCase(references = "")
    public void testEmailRequestToPENTemplate() {

        var jsonFileName = "InputJson/PENRequest.json";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.EMAIL_REQUEST_TO_PEN.getTemplate()).convertWithTemplate(jsonFile);
        System.out.println(output);

        String expected = "{\"id\" : \"5e85d6bfe53f06004f66fc4d\",\"spaceId\" : \"8934\",\"metadata\": {\"providerEmailId\" : \"dummy@optum.com\",\"dayOfWeek\" : \"1\",\"category\" : \"Payment Document\",\"frequency\" : \"D\"}}";

//        Assert.assertEquals(output, expected);
        Assert.assertTrue(output.contains("providerEmailId"));
    }
    
    
    @Test
    @RallyTestCase(references = "")
    public void testEmailRequestToPENTemplatePOJO() {
        
        var document = new DocumentMetaData();
        document.setId("5e85d6bfe53f06004f66fc4d");
        document.setSpaceId(8934);
        Document metadata = new Document();
        metadata.append("providerEmailId", "dummy@optum.com");
        metadata.append("category", "Payment Document");
        metadata.append("frequency", "D");
        metadata.append("dayOfWeek", "1");
        
        document.setMetadata(metadata);
        
        String output = TemplateFactory.getInstance(Templates.EMAIL_REQUEST_TO_PEN.getTemplate()).convertWithTemplate(document);
        System.out.println(output);

        String expected = "{\"id\" : \"5e85d6bfe53f06004f66fc4d\",\"spaceId\" : \"8934\",\"metadata\": {\"providerEmailId\" : \"dummy@optum.com\",\"dayOfWeek\" : \"1\",\"category\" : \"Payment Document\",\"frequency\" : \"D\"}}";

//        Assert.assertEquals(output, expected);
        Assert.assertTrue(output.contains("providerEmailId"));
    }
}