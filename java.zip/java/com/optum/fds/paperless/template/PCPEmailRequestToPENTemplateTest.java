package com.optum.fds.paperless.template;

import com.optum.fds.paperless.kafka.consumer.model.PlanDetails;
import com.optum.fds.paperless.kafka.consumer.model.ReferralDetails;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.java.impl.PCPEmailRequestToPENTemplate;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.bson.Document;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Field;
import java.util.Collections;
import java.nio.file.Files;

import static org.junit.Assert.assertNotNull;

public class PCPEmailRequestToPENTemplateTest {

    @Test
    public void convertWithTemplateTest_template1() throws Exception {
        PCPEmailRequestToPENTemplate template = new PCPEmailRequestToPENTemplate();
        ReferralDetails rd = new ReferralDetails();
        rd.setRequestId("REQ123");
        PlanDetails pd = new PlanDetails();
        pd.setPlanEndDate("2025-12-31");
        Document metadata = new Document()
                .append("providerEmailId", "drsmith@example.com")
                .append("taxIdNumber", "123456789")
                .append("effectiveDate", "2025-01-01")
                .append("planDetails", pd)
                .append("referralDetails", rd)
                .append("providerEmailId", Collections.singletonList("drsmith@example.com"));

        DocumentMetaData realDoc = new DocumentMetaData();
        Field metadataField = DocumentMetaData.class.getDeclaredField("metadata");
        metadataField.setAccessible(true);
        metadataField.set(realDoc, metadata);
        String result = template.convertWithTemplate(realDoc);
        System.out.println("Result: " + result);
        assertNotNull(result);
    }

    @Test
    public void convertWithTemplateTest_template2() throws Exception {
        PCPEmailRequestToPENTemplate template = new PCPEmailRequestToPENTemplate();
        ReferralDetails rd = new ReferralDetails();
        rd.setRequestId("REQ123");
        PlanDetails pd = new PlanDetails();
        pd.setPlanEndDate("2025-12-31");
        Document metadata = new Document()
                .append("providerEmailId", "drsmith@example.com")
                .append("taxIdNumber", "123456789")
                .append("effectiveDate", "2025-01-01")
                .append("planDetails", pd)
                .append("referralDetails", rd)
                .append(Workflow.SEND_EMAIL_NOTIFICATIONS, true)
                .append("providerEmailId", Collections.singletonList("drsmith@example.com"));

        DocumentMetaData realDoc = new DocumentMetaData();
        Field metadataField = DocumentMetaData.class.getDeclaredField("metadata");
        metadataField.setAccessible(true);
        metadataField.set(realDoc, metadata);
        String result = template.convertWithTemplate(realDoc);
        System.out.println("Result: " + result);
        assertNotNull(result);
    }

    @Test
    public void testConvertWithTemplateFromFilePath() throws Exception {
        // Create a temporary file to simulate a valid file path
        File tempFile = Files.createTempFile("test", ".json").toFile();
        tempFile.deleteOnExit();

        try (FileWriter writer = new FileWriter(tempFile)) {
            writer.write("{\"metadata\": {\"tin\": \"123456789\", \"corporateMpin\": \"987654321\", \"recordInfo\": {\"recordType\": \"ADMIT\"}, \"TinDocumentCount\": 5}}");
        }

        try (MockedStatic<WorkFlowUtil> mockedStatic = Mockito.mockStatic(WorkFlowUtil.class)) {
            DocumentMetaData mockDocument = Mockito.mock(DocumentMetaData.class);
            mockedStatic.when(() -> WorkFlowUtil.readDocumentFromJsonFile(tempFile.getAbsolutePath()))
                    .thenReturn(mockDocument);

            PCPEmailRequestToPENTemplate template = new PCPEmailRequestToPENTemplate();
            String result = template.convertWithTemplateFromFilePath(tempFile.getAbsolutePath());

            Assert.assertNull("Expected null as the method is not implemented", result);
        }
    }

}