package com.optum.fds.paperless.template;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.json.JSONException;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.*;

public class TexasGoldELGSTemplateTest {

    @Test
    public void testTexasGoldELGSTemplate() throws IOException, JSONException
    {
        var jsonFileName = "InputJson/TexasGoldELGSFile.json";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String jsonString= WorkFlowUtil.readDocumentsFromJsonFileToString(jsonFile);
        String output = TemplateFactory.getInstance(Templates.TXGC_ELGS_FILE.getTemplate()).convertWithTemplate(jsonString);
        System.out.println(output);
        assertTrue(output.contains("Jane"));
        assertTrue(output.contains("Cena"));
        assertTrue(output.contains("Texas"));
        assertTrue(output.contains("&amp;"));
        assertTrue(output.contains("RecipientType"));

    }

}
