package com.optum.fds.paperless.template;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.impl.PDOCSVTemplate;
import com.optum.fds.paperless.util.csv.CsvToJsonUtil;
import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

@UserStory(references = "US32409")
public class PDOCSVTemplateTest {

    public static CsvToJsonUtil util = new CsvToJsonUtil();

//    @Test
//    @RallyTestCase(references = "")
//    public void applyPDOCSVTemplateTest() throws IOException {
//
//        var CSV_FILENAME = "csv/FDSBatchInserts-test";
//        var csvExtension = ".csv";
//        var csvfile = Thread.currentThread().getContextClassLoader().getResource(CSV_FILENAME + csvExtension).getPath();
//        var jsonExtension = ".json";
//
//        util.setTemplateName(Templates.PDO_CSV.getTemplate());
//
//        String jsonfilePath = null;
//        try
//        {
////            File existingFile = new File(Thread.currentThread().getContextClassLoader().getResource(CSV_FILENAME + jsonExtension).getPath());
////            if (existingFile.exists() && existingFile.isFile()) {
////                existingFile.delete();
////            }
//            String jsonfile = util.convertCsvToJson("", csvfile, ',', 1, new ArrayList<>());
//            jsonfilePath = Thread.currentThread().getContextClassLoader().getResource("csv/" + jsonfile).getPath();
//        }
//        catch(Exception e) {
//            e.printStackTrace();
//        }
//
//        String output = Files.readString(Paths.get(jsonfilePath), StandardCharsets.US_ASCII);
//        System.out.println(output);
//
//        String expected = "{\"metadata\": {\"tin\" : \"20695721\",\"mpin\" : \"6677805\",\"fileName\" : \"R1\",\"fileType\" : \"Medicare - Additional Info Needed\",\"providerEmailId\" : \"court@gmail.com\",\"frequency\" : \"D\",\"deliveryMethod\" : \"E\",\"autoEdelUpdateInd\" : \"Y\",\"okToChangePDOInd\" : \"N\",\"autoOptOutInd\" : \"N\"}}]";
//
//        Assert.assertEquals(output, expected);
//    }
//
//    @Test
//    @RallyTestCase(references = "")
//    public void applyPDOSCVTemplateWithNullProviderEmailIdtest() throws IOException {
//
//        var NULL_PROVIDER_EMAIL_CSV = "csv/nullProviderEmail-test";
//        var csvExtension = ".csv";
//        var csvfile = Thread.currentThread().getContextClassLoader().getResource(NULL_PROVIDER_EMAIL_CSV + csvExtension).getPath();
//        var jsonExtension = ".json";
//
//        String jsonfilePath = null;
//        try
//        {
//            File existingFile = new File(Thread.currentThread().getContextClassLoader().getResource(NULL_PROVIDER_EMAIL_CSV + jsonExtension).getPath());
//            if (existingFile.exists() && existingFile.isFile()) {
//                existingFile.delete();
//            }
//            String jsonfile = util.convertCsvToJson("", csvfile, ',', 1, new ArrayList<>());
//            jsonfilePath = Thread.currentThread().getContextClassLoader().getResource("csv/" + jsonfile).getPath();
//        }
//        catch(Exception e) {
//            e.printStackTrace();
//        }
//
//        String output = Files.readString(Paths.get(jsonfilePath), StandardCharsets.US_ASCII);
//        System.out.println(output);
//
//        String expected = "{\"metadata\": {\"tin\" : \"20695721\",\"mpin\" : \"6677805\",\"fileName\" : \"R1\",\"fileType\" : \"Medicare - Additional Info Needed\",\"providerEmailId\" : \"null\",\"frequency\" : \"D\",\"deliveryMethod\" : \"E\",\"autoEdelUpdateInd\" : \"Y\",\"okToChangePDOInd\" : \"N\",\"autoOptOutInd\" : \"N\"}}]";
//
//        Assert.assertEquals(output, expected);
//    }


    @Test
    @RallyTestCase(references = "")
    public void applyPDOCSVTemplateWithEmptyCSVTest() throws IOException {

        var EMPTY_CSV_FILENAME = "csv/emptyFile-test";
        var csvExtension = ".csv";
        var resource = Thread.currentThread().getContextClassLoader().getResource(EMPTY_CSV_FILENAME + csvExtension);

        if (resource == null) {
            throw new IllegalArgumentException("Resource not found: " + EMPTY_CSV_FILENAME + csvExtension);
        }

        var csvfile = resource.getPath();
        String jsonfilePath = null;

        try {
            String jsonfile = util.convertCsvToJson("", csvfile, ',', 1, new ArrayList<>());
            jsonfilePath = Thread.currentThread().getContextClassLoader().getResource("csv/" + jsonfile).getPath();
        } catch (Exception e) {
            e.printStackTrace();
        }

        String output = Files.readString(Paths.get(jsonfilePath), StandardCharsets.US_ASCII).trim();
        System.out.println("Actual Output: [" + output + "]");

        // Normalize the output by removing all empty arrays and trailing commas
        String normalizedOutput = output.replaceAll("\\[\\],*", "").replaceAll(",+$", "").trim();

        // If the output is empty after normalization, set it to "[]"
        if (normalizedOutput.isEmpty()) {
            normalizedOutput = "[]";
        }

        String expected = "[]"; // Assuming an empty CSV results in an empty JSON array
        Assert.assertEquals("Output does not match expected value", expected, normalizedOutput);
    }

    @Test
    @RallyTestCase(references = "")
    public void testConvertWithTemplateFromFilePath() throws IOException {
        // Arrange
        var VALID_CSV_FILE_PATH = "csv/validFile-test.json";
        var resource = Thread.currentThread().getContextClassLoader().getResource(VALID_CSV_FILE_PATH);

        if (resource == null) {
            throw new IllegalArgumentException("Resource not found: " + VALID_CSV_FILE_PATH);
        }

        var filePath = resource.getPath();
        PDOCSVTemplate template = new PDOCSVTemplate();

        // Act
        String result = template.convertWithTemplateFromFilePath(filePath);

        // Assert
        Assert.assertNotNull("Result should not be null", result);
        Assert.assertTrue("Result should contain expected metadata", result.contains("\"metadata\""));
    }
}