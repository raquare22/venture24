package com.optum.fds.paperless.template;

import com.optum.fds.paperless.template.java.TemplateFactory;

import org.junit.Assert;
import org.junit.Test;

public class SSBCIResponseTemplateTest {

    @Test
    public void testConvertWithTemplate_ValidJsonWithAllFields() {
        String jsonInput = "{\n" +
                "  \"Documents\": [\n" +
                "    {\n" +
                "      \"metadata\": {\n" +
                "        \"tin\": \"123456789\",\n" +
                "        \"corporateMpin\": \"CORPMPIN123\",\n" +
                "        \"providerEmailId\": \"test@example.com\",\n" +
                "        \"type\": \"SSBCI\",\n" +
                "        \"dateEmailSent\": \"2025-12-05T10:30:00.000Z\",\n" +
                "        \"eDeliveryError\": \"\",\n" +
                "        \"transactionId\": \"TXN12345\",\n" +
                "        \"householdId\": \"HH123\",\n" +
                "        \"insuredPlanId\": \"PLAN456\",\n" +
                "        \"effectiveDate\": \"2025-01-01T00:00:00.000Z\",\n" +
                "        \"endDate\": \"2026-01-01T00:00:00.000Z\",\n" +
                "        \"eventType\": \"ENROLLMENT\",\n" +
                "        \"providerName\": \"Test Provider\",\n" +
                "        \"providers\": { \"npi\": \"NPI98765\" }\n" +
                "      }\n" +
                "    }\n" +
                "  ]\n" +
                "}";

        String output = TemplateFactory.getInstance(Templates.SSBCI_RESPONSE.getTemplate()).convertWithTemplate(jsonInput);

        String expected = "Provider TIN,Corporate MPIN,Provider Email ID,Type,Date Email Sent,eDelivery Error,Transaction ID,Household ID,Insured Plan ID,Effective Date,End Date,Event Type,Provider Name,Provider NPI\n" +
                "123456789,CORPMPIN123,test@example.com,SSBCI,2025-12-05T10:30:00.000Z,,TXN12345,HH123,PLAN456,2025-01-01T00:00:00.000Z,2026-01-01T00:00:00.000Z,ENROLLMENT,Test Provider,NPI98765";

        Assert.assertEquals(expected, output);
    }

    @Test
    public void testConvertWithTemplate_ValidJsonWithNullFields() {
        String jsonInput = "{\n" +
                "  \"Documents\": [\n" +
                "    {\n" +
                "      \"metadata\": {\n" +
                "        \"tin\": \"123456789\",\n" +
                "        \"corporateMpin\": null,\n" +
                "        \"providerEmailId\": \"test@example.com\",\n" +
                "        \"type\": \"SSBCI\",\n" +
                "        \"dateEmailSent\": \"2025-12-05T10:30:00.000Z\",\n" +
                "        \"eDeliveryError\": null,\n" +
                "        \"transactionId\": \"TXN12345\",\n" +
                "        \"householdId\": \"HH123\",\n" +
                "        \"insuredPlanId\": null,\n" +
                "        \"effectiveDate\": \"2025-01-01T00:00:00.000Z\",\n" +
                "        \"endDate\": null,\n" +
                "        \"eventType\": \"ENROLLMENT\",\n" +
                "        \"providerName\": null,\n" +
                "        \"providers\": { \"npi\": \"NPI98765\" }\n" +
                "      }\n" +
                "    }\n" +
                "  ]\n" +
                "}";

        String output = TemplateFactory.getInstance(Templates.SSBCI_RESPONSE.getTemplate()).convertWithTemplate(jsonInput);

        String expected = "Provider TIN,Corporate MPIN,Provider Email ID,Type,Date Email Sent,eDelivery Error,Transaction ID,Household ID,Insured Plan ID,Effective Date,End Date,Event Type,Provider Name,Provider NPI\n" +
                "123456789,,test@example.com,SSBCI,2025-12-05T10:30:00.000Z,,TXN12345,HH123,,2025-01-01T00:00:00.000Z,,ENROLLMENT,,NPI98765";

        Assert.assertEquals(expected, output);
    }

    @Test
    public void testConvertWithTemplate_ValidJsonWithEmptyFields() {
        String jsonInput = "{\n" +
                "  \"Documents\": [\n" +
                "    {\n" +
                "      \"metadata\": {\n" +
                "        \"tin\": \"123456789\",\n" +
                "        \"corporateMpin\": \"\",\n" +
                "        \"providerEmailId\": \"test@example.com\",\n" +
                "        \"type\": \"SSBCI\",\n" +
                "        \"dateEmailSent\": \"2025-12-05T10:30:00.000Z\",\n" +
                "        \"eDeliveryError\": \"\",\n" +
                "        \"transactionId\": \"TXN12345\",\n" +
                "        \"householdId\": \"HH123\",\n" +
                "        \"insuredPlanId\": \"\",\n" +
                "        \"effectiveDate\": \"2025-01-01T00:00:00.000Z\",\n" +
                "        \"endDate\": null,\n" +
                "        \"eventType\": \"ENROLLMENT\",\n" +
                "        \"providerName\": \"\",\n" +
                "        \"providers\": { \"npi\": \"NPI98765\" }\n" +
                "      }\n" +
                "    }\n" +
                "  ]\n" +
                "}";

        String output = TemplateFactory.getInstance(Templates.SSBCI_RESPONSE.getTemplate()).convertWithTemplate(jsonInput);

        String expected = "Provider TIN,Corporate MPIN,Provider Email ID,Type,Date Email Sent,eDelivery Error,Transaction ID,Household ID,Insured Plan ID,Effective Date,End Date,Event Type,Provider Name,Provider NPI\n" +
                "123456789,,test@example.com,SSBCI,2025-12-05T10:30:00.000Z,,TXN12345,HH123,,2025-01-01T00:00:00.000Z,,ENROLLMENT,,NPI98765";

        Assert.assertEquals(expected, output);
    }

    @Test
    public void testConvertWithTemplate_MultipleDocuments() {
        String jsonInput = "{\n" +
                "  \"Documents\": [\n" +
                "    {\n" +
                "      \"metadata\": {\n" +
                "        \"tin\": \"123456789\",\n" +
                "        \"corporateMpin\": \"CORPMPIN123\",\n" +
                "        \"providerEmailId\": \"test1@example.com\",\n" +
                "        \"type\": \"SSBCI\",\n" +
                "        \"dateEmailSent\": \"2025-12-05T10:30:00.000Z\",\n" +
                "        \"transactionId\": \"TXN1\",\n" +
                "        \"householdId\": \"HH1\",\n" +
                "        \"insuredPlanId\": \"PLAN1\",\n" +
                "        \"effectiveDate\": \"2025-01-01T00:00:00.000Z\",\n" +
                "        \"endDate\": \"2026-01-01T00:00:00.000Z\",\n" +
                "        \"eventType\": \"ENROLLMENT\",\n" +
                "        \"providerName\": \"Provider One\",\n" +
                "        \"providers\": { \"npi\": \"NPI1\" }\n" +
                "      }\n" +
                "    },\n" +
                "    {\n" +
                "      \"metadata\": {\n" +
                "        \"tin\": \"987654321\",\n" +
                "        \"corporateMpin\": \"CORPMPIN456\",\n" +
                "        \"providerEmailId\": \"test2@example.com\",\n" +
                "        \"type\": \"CSNP\",\n" +
                "        \"dateEmailSent\": \"2025-12-06T11:00:00.000Z\",\n" +
                "        \"transactionId\": \"TXN2\",\n" +
                "        \"householdId\": \"HH2\",\n" +
                "        \"insuredPlanId\": \"PLAN2\",\n" +
                "        \"effectiveDate\": \"2025-02-01T00:00:00.000Z\",\n" +
                "        \"endDate\": \"2026-02-01T00:00:00.000Z\",\n" +
                "        \"eventType\": \"UPDATE\",\n" +
                "        \"providerName\": \"Provider Two\",\n" +
                "        \"providers\": { \"npi\": \"NPI2\" }\n" +
                "      }\n" +
                "    }\n" +
                "  ]\n" +
                "}";

        String output = TemplateFactory.getInstance(Templates.SSBCI_RESPONSE.getTemplate()).convertWithTemplate(jsonInput);

        String expected = "Provider TIN,Corporate MPIN,Provider Email ID,Type,Date Email Sent,eDelivery Error,Transaction ID,Household ID,Insured Plan ID,Effective Date,End Date,Event Type,Provider Name,Provider NPI\n" +
                "123456789,CORPMPIN123,test1@example.com,SSBCI,2025-12-05T10:30:00.000Z,,TXN1,HH1,PLAN1,2025-01-01T00:00:00.000Z,2026-01-01T00:00:00.000Z,ENROLLMENT,Provider One,NPI1\n" +
                "987654321,CORPMPIN456,test2@example.com,CSNP,2025-12-06T11:00:00.000Z,,TXN2,HH2,PLAN2,2025-02-01T00:00:00.000Z,2026-02-01T00:00:00.000Z,UPDATE,Provider Two,NPI2";

        Assert.assertEquals(expected, output);
    }

    @Test
    public void testConvertWithTemplate_EmptyDocumentList() {
        String jsonInput = "{ \"Documents\": [] }";

        String output = TemplateFactory.getInstance(Templates.SSBCI_RESPONSE.getTemplate()).convertWithTemplate(jsonInput);

        String expected = "Provider TIN,Corporate MPIN,Provider Email ID,Type,Date Email Sent,eDelivery Error,Transaction ID,Household ID,Insured Plan ID,Effective Date,End Date,Event Type,Provider Name,Provider NPI\n";

        Assert.assertEquals(expected, output);
    }

    @Test
    public void testSSBCITemplatefromFilePath() {
        var jsonFileName = "InputJson/SSBCIResponse.json";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.SSBCI_RESPONSE.getTemplate()).convertWithTemplateFromFilePath(jsonFile);

        String expected = "Provider TIN,Corporate MPIN,Provider Email ID,Type,Date Email Sent,eDelivery Error,Transaction ID,Household ID,Insured Plan ID,Effective Date,End Date,Event Type,Provider Name,Provider NPI\n" +
                "123456789,CORPMPIN123,test@example.com,CSNP,2025-12-05T10:30:00.000Z,,TXN12345,HH123,PLAN456,2025-01-01T00:00:00.000Z,2026-01-01T00:00:00.000Z,ENROLLMENT,Test Provider,NPI98765";

        Assert.assertEquals(expected, output);

    }

    @Test
    public void testConvertWithTemplate_MissingFields() {
        String jsonInput = "{\n" +
                "  \"Documents\": [\n" +
                "    {\n" +
                "      \"metadata\": {\n" +
                "        \"tin\": \"123456789\"\n" +
                "      }\n" +
                "    }\n" +
                "  ]\n" +
                "}";
        String output = TemplateFactory.getInstance(Templates.SSBCI_RESPONSE.getTemplate()).convertWithTemplate(jsonInput);
        String expected = "Provider TIN,Corporate MPIN,Provider Email ID,Type,Date Email Sent,eDelivery Error,Transaction ID,Household ID,Insured Plan ID,Effective Date,End Date,Event Type,Provider Name,Provider NPI\n" +
                "123456789,,,,,,,,,,,,,";
        Assert.assertEquals(expected, output);
    }

    @Test
    public void testConvertWithTemplate_UnescapedProviderNameAndEmail() {
        String jsonInput = "{\n" +
                "  \"Documents\": [\n" +
                "    {\n" +
                "      \"metadata\": {\n" +
                "        \"tin\": \"123456789\",\n" +
                "        \"corporateMpin\": \"CORPMPIN123\",\n" +
                "        \"providerEmailId\": \"test@example.com,with,commas \\nand \\nnewlines\",\n" +
                "        \"type\": \"SSBCI\",\n" +
                "        \"dateEmailSent\": \"2025-12-05T10:30:00.000Z\",\n" +
                "        \"eDeliveryError\": \"\",\n" +
                "        \"transactionId\": \"TXN12345\",\n" +
                "        \"householdId\": \"HH123\",\n" +
                "        \"insuredPlanId\": \"PLAN456\",\n" +
                "        \"effectiveDate\": \"2025-01-01T00:00:00.000Z\",\n" +
                "        \"endDate\": \"2026-01-01T00:00:00.000Z\",\n" +
                "        \"eventType\": \"ENROLLMENT\",\n" +
                "        \"providerName\": \"Test Provider, with \\\"quotes\\\" and \\n newlines\",\n" +
                "        \"providers\": { \"npi\": \"NPI98765\" }\n" +
                "      }\n" +
                "    }\n" +
                "  ]\n" +
                "}";

        String output = TemplateFactory.getInstance(Templates.SSBCI_RESPONSE.getTemplate()).convertWithTemplate(jsonInput);

        String expected = "Provider TIN,Corporate MPIN,Provider Email ID,Type,Date Email Sent,eDelivery Error,Transaction ID,Household ID,Insured Plan ID,Effective Date,End Date,Event Type,Provider Name,Provider NPI\n" +
                "123456789,CORPMPIN123,\"test@example.com,with,commas and newlines\",SSBCI,2025-12-05T10:30:00.000Z,,TXN12345,HH123,PLAN456,2025-01-01T00:00:00.000Z,2026-01-01T00:00:00.000Z,ENROLLMENT,\"Test Provider, with \"\"quotes\"\" and  newlines\",NPI98765";

        Assert.assertEquals(expected, output);
    }
}