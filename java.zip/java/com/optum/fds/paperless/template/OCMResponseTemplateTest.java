package com.optum.fds.paperless.template;

import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;

public class OCMResponseTemplateTest {

	@Test
	@RallyTestCase(references = "")
	public void testOCMResponseTemplate() {
		var jsonFileName = "InputJson/OCMResponse.json";

		var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
		String output = TemplateFactory.getInstance(Templates.OCM_RESPONSE.getTemplate())
				.convertWithTemplateFromFilePath(jsonFile);
		System.out.println(output);
		Assert.assertTrue(output.contains("T0000031"));

	}

}
