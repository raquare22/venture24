package com.optum.fds.paperless.template;

import java.io.IOException;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class NGSClaimsResponseTemplateTest {

    @Test
    public void NGSClaimsResponseFileTest() throws IOException, JSONException
    {
        var jsonFileName ="InputJson/NGSClaimsResponse.json";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.NGS_CLAIMS_RESPONSE.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);

        String expected = "Case_Id|LetterFilename|NGSID|Original_Zip_file|Preference|Delivery_Status|EmailAddress|UploadDateTime|EmailDateTime|EmailFailure_Reason\n" +
                "|8047721601_FS106_0000010731.pdf|10731|20200728010038_ETS_PDF_3256.zip|E|FAILED||||Missing or invalid data: corporateMpin|Missing or invalid data: providerEmailId\n" +
                "U2041205003|appeals_00001.pdf|C-00666CC|20200728010038_ETS_PDF_3256.zip|E|UPLOADED|GIANINABLANK@GMAIL.COM|11-15-2020 02:07:58|06-27-2017 21:14:44|Bounced email\n" +
                "W2061847015|appeals_00001.pdf|C-00666CC|20200728010038_ETS_PDF_3256.zip|E|UPLOADED|GIANINABLANK@GMAIL.COM|11-15-2020 02:07:58|06-27-2017 21:14:44|\n" +
                "W2060850031|appeals_00001.pdf|C-00666CC|20200728010038_ETS_PDF_3256.zip|E|UPLOADED|GIANINABLANK@GMAIL.COM|10-15-2020 03:07:58|06-27-2017 21:14:44|";

        Assert.assertEquals(expected, output);

        String jsonString= WorkFlowUtil.readDocumentsFromJsonFileToString(jsonFile);

        output=TemplateFactory.getInstance(Templates.NGS_CLAIMS_RESPONSE.getTemplate()).convertWithTemplate(jsonString);

        Assert.assertEquals(expected, output);

    }

}
