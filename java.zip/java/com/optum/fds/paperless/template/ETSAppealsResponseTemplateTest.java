package com.optum.fds.paperless.template;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import org.junit.Assert;
import org.junit.Test;

@UserStory(references = "")
public class ETSAppealsResponseTemplateTest {

    @Test
    @RallyTestCase(references = "")
    public void testETSAppealsResponseTemplate() {
        var jsonFileName = "InputJson/ETSAppealResponseFile.json";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.ETS_APPEALS_RESPONSE.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);

        String expected = "Format|MeterDate|CaseID|HistoryID|ZipFileName|emailNotificationDate\n" +
                "Emailed|11-15-2020 02:07:58|K1931126006|89320918|BP_MBR_NGS_32723_0519202041504.zip|11-15-2020 13:00:00\n" +
                "Emailed|11-15-2020 02:07:58|U2041205003|89502785|BP_MBR_NGS_32723_0519202041504.zip|10-15-2020 14:00:00\n" +
                "Emailed|11-15-2020 02:07:58|W2061847015|89574175|BP_MBR_NGS_32723_0519202041504.zip|11-15-2020 13:30:00\n" +
                "Emailed|10-15-2020 03:07:58|W2060850031|89574175|BP_MBR_NGS_32723_0519202041504.zip|10-15-2020 14:30:00";

//        Assert.assertEquals(expected, output);
        Assert.assertTrue(output.contains("K1931126006"));

    }
}