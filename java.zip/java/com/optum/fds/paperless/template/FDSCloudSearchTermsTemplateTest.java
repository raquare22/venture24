package com.optum.fds.paperless.template;

import com.optum.fds.paperless.template.java.impl.FDSCloudSearchTermsTemplate;
import org.junit.Assert;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Map;

import org.junit.Test;
import org.springframework.stereotype.Component;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;

public class FDSCloudSearchTermsTemplateTest {
	
    @Test
    public void testTemplate() throws Exception {
        var metadata = getMetadata();
        String output = TemplateFactory.getInstance(Templates.FDS_CLOUD_SEARCH_TERMS.getTemplate()).convertWithTemplate(metadata);
        System.out.println(output);
        String expected = "{\"emailAlertReq\" : \"Y\",\n"
        		+ " \"patientName\" : \"LAUREN LUCAS\",\n"
        		+ " \"patientAccountNumber\" : \"943818795\",\n"
        		+ " \"subCategory\" : \"C1\",\n"
        		+ " \"filePath\" : \"Commercial/Additional Info Needed\",\n"
        		+ " \"policyNumber\" : \"9F5633\",\n"
        		+ " \"memberName\" : \"LIONEL LUCAS\",\n"
        		+ " \"expiryDate\" : \"2023-07-19T12:38:43.204Z\",\n"
        		+ " \"createdDate\" : \"2022-01-05T02:17:29.000Z\",\n"
        		+ " \"physicianName\" : \"PENNY S TURTEL MD\",\n"
        		+ " \"tin\" : \"1234567\",\n"
        		+ " \"mpin\" : \"1234567\",\n"
        		+ " \"category\" : \"Claim\",\n"
        		+ " \"claimNumber\" : \"CV61054877\",\n"
        		+ " \"memberId\" : \"943818795\"}";
        Assert.assertEquals(expected, output);
    }
    
    @Test
    public void testTemplateCSPPRA() throws Exception {
        var metadata = getMetadataCSPPRA();
        String output = TemplateFactory.getInstance(Templates.FDS_CLOUD_SEARCH_TERMS.getTemplate()).convertWithTemplate(metadata);
        System.out.println(output);
        String expected = "{\"emailAlertReq\" : \"Y\",\n"
        		+ " \"patientAccountNumber\" : \"\",\n"
        		+ " \"subCategory\" : \"C1\",\n"
        		+ " \"checkNumber\" : \"\",\n"
        		+ " \"filePath\" : \"Commercial/Additional Info Needed\",\n"
        		+ " \"memberName\" : \"LIONEL LUCAS\",\n"
        		+ " \"expiryDate\" : \"2023-07-19T12:38:43.204Z\",\n"
        		+ " \"createdDate\" : \"2022-01-05T02:17:29.000Z\",\n"
        		+ " \"Ind_835\" : \"true\",\n"
        		+ " \"physicianName\" : \"PENNY S TURTEL MD\",\n"
        		+ " \"checkAmount\" : \"\",\n"
        		+ " \"tin\" : \"1234567\",\n"
        		+ " \"mpin\" : \"1234567\",\n"
        		+ " \"category\" : \"PRA\",\n"
        		+ " \"checkId\" : \"\"}";
        Assert.assertEquals(expected, output);
    }
    
    public org.bson.Document getMetadataCSPPRA() throws Exception {
    	org.bson.Document metadata = new org.bson.Document();
    	metadata.put("createApplication", "CSP-PRA");
    	metadata.put("tin", "1234567");
    	metadata.put("mpin", "1234567");
    	metadata.put("createdDate", "2022-01-05T02:17:29.000Z");
    	metadata.put("expiryDate", "2023-07-19T12:38:43.204Z");
    	metadata.put("category", "PRA");
    	metadata.put("subCategory", "C1");
    	metadata.put("filePath", "Commercial/Additional Info Needed");
    	metadata.put("emailAlertReq", "Y");
    	metadata.put("policyNumber", "9F5633");
    	metadata.put("physicianName", "PENNY S TURTEL MD");
    	metadata.put("memberName", "LAUREN LUCAS");
    	metadata.put("memberName", "LIONEL LUCAS");
    	metadata.put("multClaimNumber", "|CV61054877|CV61054877");
        metadata.put("multMemberId", "943818795");    	
        metadata.put("Ind_835", true);    	
    	return metadata;
    }
    
    public org.bson.Document getMetadata() throws Exception {
    	org.bson.Document metadata = new org.bson.Document();
    	metadata.put("createApplication", "ELGS");
    	metadata.put("tin", "1234567");
    	metadata.put("mpin", "1234567");
    	metadata.put("createdDate", "2022-01-05T02:17:29.000Z");
    	metadata.put("expiryDate", "2023-07-19T12:38:43.204Z");
    	metadata.put("category", "Claim");
    	metadata.put("subCategory", "C1");
    	metadata.put("filePath", "Commercial/Additional Info Needed");
    	metadata.put("emailAlertReq", "Y");
    	metadata.put("policyNumber", "9F5633");
    	metadata.put("providerName", "PENNY S TURTEL MD");
    	metadata.put("PatientName", "LAUREN LUCAS");
    	metadata.put("patientAccountNumber", "943818795");
    	metadata.put("memberName", "LIONEL LUCAS");
    	metadata.put("claimNumber", "CV61054877");
        metadata.put("MemberAltID", "943818795");    	
    	return metadata;
    }

	@Test
	public void testFilterDuplicates() {
		FDSCloudSearchTermsTemplate template = new FDSCloudSearchTermsTemplate();

		String input = "|value1|value2|value1|value3||value2|";
		String expectedOutput = "|value2|value1|value3|";

		String actualOutput = template.filterDuplicates(input);

		Assert.assertEquals("Filtered output does not match expected result", expectedOutput, actualOutput);
	}
	@Test
	public void testFilterDuplicatesWithEmptyInput() {
		FDSCloudSearchTermsTemplate template = new FDSCloudSearchTermsTemplate();

		String input = "";
		String expectedOutput = "";

		String actualOutput = template.filterDuplicates(input);

		Assert.assertEquals("Filtered output does not match expected result for empty input", expectedOutput, actualOutput);
	}
	@Test
	public void testFilterDuplicatesWithOnlyDelimiters() {
		FDSCloudSearchTermsTemplate template = new FDSCloudSearchTermsTemplate();

		String input = "|||||";
		String expectedOutput = "||";

		String actualOutput = template.filterDuplicates(input);

		Assert.assertEquals("Filtered output does not match expected result for input with only delimiters", expectedOutput, actualOutput);
	}
	@Test
	public void testFilterDuplicatesWithUniqueValues() {
		FDSCloudSearchTermsTemplate template = new FDSCloudSearchTermsTemplate();

		String input = "|value1|value2|value3|value4|";
		String expectedOutput = "|value2|value1|value4|value3|";

		String actualOutput = template.filterDuplicates(input);

		Assert.assertEquals("Filtered output does not match expected result for input with unique values", expectedOutput, actualOutput);
	}
	@Test
	public void testFilterDuplicatesWithSingleValue() {
		FDSCloudSearchTermsTemplate template = new FDSCloudSearchTermsTemplate();

		String input = "|value1|";
		String expectedOutput = "|value1|";

		String actualOutput = template.filterDuplicates(input);

		Assert.assertEquals("Filtered output does not match expected result for input with a single value", expectedOutput, actualOutput);
	}
	@Test
	public void testGetMetadataCSPPRA() throws Exception {
		FDSCloudSearchTermsTemplateTest testInstance = new FDSCloudSearchTermsTemplateTest();

		org.bson.Document metadata = testInstance.getMetadataCSPPRA();

		Assert.assertNotNull("Metadata should not be null", metadata);
		Assert.assertEquals("CSP-PRA", metadata.getString("createApplication"));
		Assert.assertEquals("1234567", metadata.getString("tin"));
		Assert.assertEquals("1234567", metadata.getString("mpin"));
		Assert.assertEquals("2022-01-05T02:17:29.000Z", metadata.getString("createdDate"));
		Assert.assertEquals("2023-07-19T12:38:43.204Z", metadata.getString("expiryDate"));
		Assert.assertEquals("PRA", metadata.getString("category"));
		Assert.assertEquals("C1", metadata.getString("subCategory"));
		Assert.assertEquals("Commercial/Additional Info Needed", metadata.getString("filePath"));
		Assert.assertEquals("Y", metadata.getString("emailAlertReq"));
		Assert.assertEquals("9F5633", metadata.getString("policyNumber"));
		Assert.assertEquals("PENNY S TURTEL MD", metadata.getString("physicianName"));
		Assert.assertEquals("LIONEL LUCAS", metadata.getString("memberName"));
		Assert.assertTrue("Ind_835 should be true", metadata.getBoolean("Ind_835"));
	}
	@Test
	public void testGetMetadata() throws Exception {
		FDSCloudSearchTermsTemplateTest testInstance = new FDSCloudSearchTermsTemplateTest();

		org.bson.Document metadata = testInstance.getMetadata();

		Assert.assertNotNull("Metadata should not be null", metadata);
		Assert.assertEquals("ELGS", metadata.getString("createApplication"));
		Assert.assertEquals("1234567", metadata.getString("tin"));
		Assert.assertEquals("1234567", metadata.getString("mpin"));
		Assert.assertEquals("2022-01-05T02:17:29.000Z", metadata.getString("createdDate"));
		Assert.assertEquals("2023-07-19T12:38:43.204Z", metadata.getString("expiryDate"));
		Assert.assertEquals("Claim", metadata.getString("category"));
		Assert.assertEquals("C1", metadata.getString("subCategory"));
		Assert.assertEquals("Commercial/Additional Info Needed", metadata.getString("filePath"));
		Assert.assertEquals("Y", metadata.getString("emailAlertReq"));
		Assert.assertEquals("9F5633", metadata.getString("policyNumber"));
		Assert.assertEquals("PENNY S TURTEL MD", metadata.getString("providerName"));
		Assert.assertEquals("LAUREN LUCAS", metadata.getString("PatientName"));
		Assert.assertEquals("943818795", metadata.getString("patientAccountNumber"));
		Assert.assertEquals("LIONEL LUCAS", metadata.getString("memberName"));
		Assert.assertEquals("CV61054877", metadata.getString("claimNumber"));
		Assert.assertEquals("943818795", metadata.getString("MemberAltID"));
	}
	@Test
	public void testFilterDuplicatesWithDuplicateDelimiters() {
		FDSCloudSearchTermsTemplate template = new FDSCloudSearchTermsTemplate();

		String input = "|value1||value2|||value1|value3||";
		String expectedOutput = "|value2|value1|value3|";

		String actualOutput = template.filterDuplicates(input);

		Assert.assertEquals("Filtered output does not match expected result for input with duplicate delimiters", expectedOutput, actualOutput);
	}
	@Test
	public void testConvertWithTemplateFromFilePath() {
		FDSCloudSearchTermsTemplate template = new FDSCloudSearchTermsTemplate();

		String filePath = "some/file/path";
		String result = template.convertWithTemplateFromFilePath(filePath);

		Assert.assertNull("Expected null as the method is not implemented", result);
	}
	@Test
	public void testFilterDuplicatesWithNullInput() {
		FDSCloudSearchTermsTemplate template = new FDSCloudSearchTermsTemplate();

		String input = null;
		String expectedOutput = "";

		String actualOutput = template.filterDuplicates(input);

		Assert.assertEquals("Filtered output does not match expected result for null input", expectedOutput, actualOutput);
	}
	@Test
	public void testCreateSearchTermsMapForNICE() {
		FDSCloudSearchTermsTemplate template = new FDSCloudSearchTermsTemplate();

		org.bson.Document metadata = new org.bson.Document();
		metadata.put("createApplication", "NICE");
		metadata.put("physicianName", "Dr. John Doe");
		metadata.put("CheckAmt", "1000");
		metadata.put("CheckTraceNumber", "12345");

		Map<String, String> result = template.createSearchTermsMap(metadata);

		Assert.assertEquals("Dr. John Doe", result.get("physicianName"));
		Assert.assertEquals("1000", result.get("checkAmount"));
		Assert.assertEquals("12345", result.get("checkId"));
	}
	@Test
	public void testCreateSearchTermsMapForELGS() {
		FDSCloudSearchTermsTemplate template = new FDSCloudSearchTermsTemplate();

		org.bson.Document metadata = new org.bson.Document();
		metadata.put("createApplication", "ELGS");
		metadata.put("memberName", "Jane Doe");
		metadata.put("claimNumber", "CL123456");
		metadata.put("memberId", "987654321");

		Map<String, String> result = template.createSearchTermsMap(metadata);

		Assert.assertEquals("Jane Doe", result.get("memberName"));
		Assert.assertEquals("CL123456", result.get("claimNumber"));
		Assert.assertEquals("987654321", result.get("memberId"));
	}
}
