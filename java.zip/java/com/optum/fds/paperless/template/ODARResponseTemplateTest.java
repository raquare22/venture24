package com.optum.fds.paperless.template;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import org.junit.Assert;
import org.junit.Test;

@UserStory(references = "")
public class ODARResponseTemplateTest {

    @Test
    @RallyTestCase(references = "")
    public void testODARResponseTemplate() {
        var jsonFileName = "InputJson/ODARResponse.json";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.ODAR_RESPONSE.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);

        String expected = "LetterGroupId,LetterType,LetterSentDate,LetterStatus\n" + 
        		"ODAR1234,COL211,07/27/2018,LINK\n" + 
        		"1343252345,ICM701,07/27/2018,LINK\n" + 
        		"OD3123123AR1234,FRO002,07/27/2018,LINK\n" + 
        		"O123123DAR1234,FRO002,07/27/2018,LINK";

        Assert.assertEquals(expected, output);

    }
}