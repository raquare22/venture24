package com.optum.fds.paperless.template;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import org.junit.Assert;
import org.junit.Test;

@UserStory(references = "")
public class PriorAuthResponseTemplateTest {

    @Test
    @RallyTestCase(references = "")
    public void testPriorAuthResponseTemplate() {
        var jsonFileName = "InputJson/PriorAuthResponse.json";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.PRIOR_AUTH_RESPONSE.getTemplate())
                .convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);
        Assert.assertTrue(output.contains("T0000031"));

    }
}