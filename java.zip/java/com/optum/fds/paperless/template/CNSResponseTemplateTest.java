package com.optum.fds.paperless.template;


import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.json.JSONException;
import org.junit.Test;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class CNSResponseTemplateTest  {
	
	@Test
	public void testCNSResponseTemplate() throws IOException, JSONException
	{
		
		var jsonFileName = "InputJson/CNSResponse.json";
		 var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
//	        String jsonString= WorkFlowUtil.readDocumentsFromJsonFileToString(jsonFile);
		 
		 
		 String jsonString = "\n"
		 		+ "{\n"
		 		+ "    \"metadata\" : {\n"
		 		+ "        \"encounterDetails\" : {\n"
		 		+ "            \"isAdmitAcknowledged\" : \"\",\n"
		 		+ "            \"isDischargeAcknowledged\" : \"\",\n"
		 		+ "            \"dischargeDate\" : \"\",\n"
		 		+ "            \"emergencyDate\" : \"\",\n"
		 		+ "            \"admitDate\" : \"2024-02-23 08:20:05\",\n"
		 		+ "            \"chiefComplaintList\" : \"\",\n"
		 		+ "            \"dischargeDisposition\" : \"NULL\",\n"
		 		+ "            \"isEmergencyAcknowledged\" : \"\"\n"
		 		+ "        },\n"
		 		+ "        \"createApplication\" : \"TrackIt\",\n"
		 		+ "        \"recordInfo\" : {\n"
		 		+ "            \"recordID\" : \"591404594-1227654317-1708676405000\",\n"
		 		+ "            \"recordType\" : \"ADMIT\",\n"
		 		+ "            \"recordLastUpdateDate\" : \"\",\n"
		 		+ "            \"encounterID\" : \"a085943d811d9910b99560a39d377c18\"\n"
		 		+ "        },\n"
		 		+ "        \"providerDetails\" : {\n"
		 		+ "            \"admittingProviderName\" : \"RAUL B TALLO\",\n"
		 		+ "            \"facilityProvider\" : \"LAKELAND REGIONAL HEALTH SYSTEMS\",\n"
		 		+ "            \"providerNpi\" : \"1942212592\",\n"
		 		+ "            \"providerTin\" : \"150559686\",\n"
		 		+ "            \"providerName\" : \"NELSON-JAMES, CARA R.\"\n"
		 		+ "        },\n"
		 		+ "        \"tin\" : \"150559686\",\n"
		 		+ "        \"memberDetails\" : {\n"
		 		+ "            \"patientFirstName\" : \"EDWARD\",\n"
		 		+ "            \"patientDateOfBirth\" : \"08/23/1954\",\n"
		 		+ "            \"state\" : \"FL\",\n"
		 		+ "            \"lob\" : \"C&S\",\n"
		 		+ "            \"patientLastName\" : \"JAMES\"\n"
		 		+ "        },\n"
		 		+ "        \"transactionId\" : \"21836e97-2e4a-4b7c-a73c-af134b8198f9\",\n"
		 		+ "        \"corporateMpin\" : \"000205066\",\n"
		 		+ "        \"providerEmailId\" : \"\",\n"
		 		+ "        \"isBHProvider\" : true,\n"
		 		+ "        \"PAAEmailOptOut\" : true,\n"
		 		+ "        \"eDeliveryError\": \"Missing or invalid data: email bounced\"\n"
		 		+ "    }\n"
		 		+ "}";
		 
	        String output = TemplateFactory.getInstance(Templates.CNS_RESPONSE.getTemplate())
	                .convertWithTemplate(jsonString);
	        System.out.println(output);
	        assertTrue(output.contains("transactionId"));
	        assertTrue(output.contains("providerDetailsList"));
	        assertTrue(output.contains("isBHProvider"));
	}

}