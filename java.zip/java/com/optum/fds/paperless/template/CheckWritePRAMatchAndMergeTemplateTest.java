package com.optum.fds.paperless.template;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.FileInputStream;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;

public class CheckWritePRAMatchAndMergeTemplateTest {


    @Test
    @RallyTestCase(references = "TC32734")
    public void testCheckWritePRAResponseTemplate() {
        var jsonFileName = "InputJson/CheckWritePRAMergedMetadataSampleInput.json";

        var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
        String output = TemplateFactory.getInstance(Templates.MATCH_AND_MERGE.getTemplate()).convertWithTemplateFromFilePath(jsonFile);
        System.out.println(output);

        
        String expected = "{\"originalCompanionFileRecords\" : [\"145ZAAPIU00000301|MSP|70219-916698066-00|DOE2, JOHN K.                 |42069144-01|PRA|COSMOS\",\n" + 
        		"                                   \"145ZAAPIU00000301|MSP|70270-937666579-00|DOE3, JOHN J.                 |42069146-01|PRA|COSMOS\"]}";
		Assert.assertEquals(expected, output);

	}
}
