package com.optum.fds.paperless.template;

import org.junit.Assert;
import org.junit.Test;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;

public class IHRResponseTemplateTest {

	@Test
	public void testIHRResponseTemplate() {
		var jsonFileName = "InputJson/IHRResponse.json";

		var jsonFile = Thread.currentThread().getContextClassLoader().getResource(jsonFileName).getPath();
		String output = TemplateFactory.getInstance(Templates.IHR_RESPONSE.getTemplate())
				.convertWithTemplateFromFilePath(jsonFile);
		System.out.println(output);
		
		String expected = "PROVIDER_NAME,PROVIDER_ID,NPI,TAX_ID,GROUP_PROVIDER_ID,GROUP_PROVIDER_MPIN,GROUP_NPI,GROUP_TAX_ID,EMAIL,PROV_ADDRESS_LINE_1,PROV_ADDRESS_LINE_2,PCP_FLAG,PROVIDER_SPECIALITY,PROVIDER_TYPE,DATE_EMAIL_SENT,EDELIVERYERROR\n"
				+ "\"FULLER, JUSTIN T.\",005156487006,1588955215,351913875,001160933006,001160933,1013953983,351913875,alvaro.soares@polycom.com,2209 JOHN R WOODEN DR,,Y,Pediatrics,,20200626T10:49:00.000Z,\n"
				+ "\"FULLER, JUSTIN T.\",005156487006,1588955215,351913875,001160933006,001160933,1013953983,351913875,RHARSTA@GLOBAL-BUSINESS.NET,2209 JOHN R WOODEN DR,,Y,Pediatrics,,20200626T10:49:00.000Z,\n"
				+ "\"FULLER, JUSTIN T.\",005156487006,1588955215,351913875,001160933006,001160933,1013953983,351913875,,2209 JOHN R WOODEN DR,,Y,Pediatrics,,20200626T10:49:00.000Z,Missing or invalid data: corporateMpin|Missing or invalid data: providerEmailId|Missing or invalid data: mpin|Missing or invalid data: tin|Missing or invalid data: email bounced\n"
				+ "\"FULLER, JUSTIN T.\",005156487006,1588955215,351913875,001160933006,001160933,1013953983,351913875,WILLIAMHANES@HOTMAIL.COM,2209 JOHN R WOODEN DR,,Y,Pediatrics,,20200626T10:49:00.000Z,Missing or invalid data: email bounced";
		Assert.assertEquals(expected, output);

	}

	
}
