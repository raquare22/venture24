package com.optum.fds.paperless.junit.references;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Collection of references related to the supported annotations.
 */
@JsonAutoDetect
public class References {

  @JsonInclude(value = Include.NON_EMPTY)
  @JsonProperty
  private final List<String> userStories = new ArrayList<>();

  @JsonProperty
  @JsonInclude(value = Include.NON_EMPTY)
  private final List<String> rallyTestCases = new ArrayList<>();

  public List<String> getUserStories() {
	return userStories == null?null:new ArrayList<>(userStories);
  }

  public List<String> getRallyTestCases() {
	return rallyTestCases == null?null:new ArrayList<>(rallyTestCases);
  }
}
