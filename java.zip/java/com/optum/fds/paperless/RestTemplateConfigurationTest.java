package com.optum.fds.paperless;

import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import static org.junit.Assert.*;

/**
 * Simplified Test class for RestTemplateConfiguration.
 */
@RunWith(MockitoJUnitRunner.class)
public class RestTemplateConfigurationTest {

    @Spy
    @InjectMocks
    private RestTemplateConfiguration restTemplateConfiguration;

    @Before
    public void setUp() {
        // No setup required as RestTemplateConfiguration does not have external dependencies
    }

    /**
     * Test the restTemplate() method to ensure it returns a non-null RestTemplate instance.
     */
    @Test
    public void testRestTemplateIsNotNull() {
        // Act
        RestTemplate restTemplate = restTemplateConfiguration.restTemplate();

        // Assert
        assertNotNull("RestTemplate should not be null", restTemplate);
    }

    /**
     * Test that the RestTemplate is configured with a non-null ClientHttpRequestFactory.
     */
    @Test
    public void testRestTemplateHasRequestFactory() {
        // Act
        RestTemplate restTemplate = restTemplateConfiguration.restTemplate();
        ClientHttpRequestFactory requestFactory = restTemplate.getRequestFactory();

        // Assert
        assertNotNull("ClientHttpRequestFactory should not be null", requestFactory);
    }

    @Test
    public void testRestTemplate_catchNoSuchAlgorithmException() throws Exception {
        try (MockedStatic<SSLContexts> mockedSslContexts =
                     Mockito.mockStatic(org.apache.http.ssl.SSLContexts.class)) {

            SSLContextBuilder sslContextBuilder = Mockito.mock(SSLContextBuilder.class);
            mockedSslContexts.when(org.apache.http.ssl.SSLContexts::custom).thenReturn(sslContextBuilder);

            Mockito.when(sslContextBuilder.loadTrustMaterial(
                            Mockito.isNull(),
                            Mockito.any(TrustStrategy.class)))
                    .thenThrow(new NoSuchAlgorithmException("forced"));

            try {
                restTemplateConfiguration.restTemplate();
                fail("Expected NullPointerException because sslContext stays null after catch block.");
            } catch (NullPointerException expected) {
                assertNotNull(expected);
            }
        }
    }

    @Test
    public void testRestTemplate_catchKeyManagementException() throws Exception {
        try (MockedStatic<org.apache.http.ssl.SSLContexts> mockedSslContexts =
                     Mockito.mockStatic(org.apache.http.ssl.SSLContexts.class)) {

            SSLContextBuilder sslContextBuilder = Mockito.mock(SSLContextBuilder.class);
            mockedSslContexts.when(org.apache.http.ssl.SSLContexts::custom).thenReturn(sslContextBuilder);

            Mockito.when(sslContextBuilder.loadTrustMaterial(
                            Mockito.isNull(),
                            Mockito.any(TrustStrategy.class)))
                    .thenReturn(sslContextBuilder);
            Mockito.when(sslContextBuilder.build())
                    .thenThrow(new KeyManagementException("forced"));

            try {
                restTemplateConfiguration.restTemplate();
                fail("Expected NullPointerException because sslContext stays null after catch block.");
            } catch (NullPointerException expected) {
                assertNotNull(expected);
            }
        }
    }

    @Test
    public void testRestTemplate_catchKeyStoreException() throws Exception {
        try (MockedStatic<org.apache.http.ssl.SSLContexts> mockedSslContexts =
                     Mockito.mockStatic(org.apache.http.ssl.SSLContexts.class)) {

            SSLContextBuilder sslContextBuilder = Mockito.mock(SSLContextBuilder.class);
            mockedSslContexts.when(org.apache.http.ssl.SSLContexts::custom).thenReturn(sslContextBuilder);

            Mockito.when(sslContextBuilder.loadTrustMaterial(
                            Mockito.isNull(),
                            Mockito.any(TrustStrategy.class)))
                    .thenThrow(new KeyStoreException("forced"));

            try {
                restTemplateConfiguration.restTemplate();
                fail("Expected NullPointerException because sslContext stays null after catch block.");
            } catch (NullPointerException expected) {
                assertNotNull(expected);
            }
        }
    }
}