package com.optum.fds.paperless;

import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Test class for ConfigData.
 */
public class ConfigDataTest {

    private ConfigData configData;

    @Before
    public void setUp() throws Exception {
        // Initialize ConfigData instance
        configData = new ConfigData();

        // Initialize Mockito annotations if any (not strictly necessary here)

        // Set up sample JSON data for printTrailMap
        String samplePrintTrailMap = "{ \"trail1\": { \"key1\": \"value1\", \"key2\": \"value2\" }, "
                + "\"trail2\": { \"keyA\": \"valueA\", \"keyB\": \"valueB\" } }";

        // Set up sample JSON data for credentials
        String sampleCAP_credentials =  "{\"20\": {\"appIdentifier\":\"test\",\"appSecret\":\"test\", \"clientId\": \"test\",\"fdsCloudSpaceId\":\"spaceId\", \"clientName\": \"CAP\", \"doc360DocClass\": \"DOC_CLASS_ABC\", \"uploadProvider\": \"DOC360\"}}";
        String sampleLETGEN_credentials =  "{ \"1\": { \"username\": \"letgen_user\", \"password\": \"letgen_pass\" } }";
        String sampleUNET_credentials = "{ \"2\": { \"username\": \"unet_user\", \"password\": \"unet_pass\" } }";
        String sampleNEXTGEN_credentials = "{ \"3\": { \"username\": \"nextgen_user\", \"password\": \"nextgen_pass\" } }";
        String sample_1CLICK_credentials = "{ \"4\": { \"username\": \"1click_user\", \"password\": \"1click_pass\" } }";
        String sampleCCSManual_credentials = "{ \"5\": { \"username\": \"ccsmanual_user\", \"password\": \"ccsmanual_pass\" } }";
        String sampleUNET_PRA_credentials = "{ \"6\": { \"username\": \"unet_pra_user\", \"password\": \"unet_pra_pass\" } }";
        String sampleCOSMOS_PRA_credentials = "{ \"7\": { \"username\": \"cosmos_pra_user\", \"password\": \"cosmos_pra_pass\" } }";
        String sampleCOSMOS_credentials = "{ \"8\": { \"username\": \"cosmos_user\", \"password\": \"cosmos_pass\" } }";
        String sampleUHC_WEST_credentials = "{ \"9\": { \"username\": \"uhc_west_user\", \"password\": \"uhc_west_pass\" } }";
        String sampleCSP_PRA_credentials = "{ \"10\": { \"username\": \"csp_pra_user\", \"password\": \"csp_pra_pass\" } }";
        String sampleODAR_credentials = "{ \"11\": { \"username\": \"odar_user\", \"password\": \"odar_pass\" } }";
        String sampleMR_APPEALS_credentials = "{ \"12\": { \"username\": \"mr_appeals_user\", \"password\": \"mr_appeals_pass\" } }";
        String sampleETS_APPEALS_credentials = "{ \"13\": { \"username\": \"ets_appeals_user\", \"password\": \"ets_appeals_pass\" } }";
        String sampleUSP_CLAIMS_credentials = "{ \"14\": { \"username\": \"usp_claims_user\", \"password\": \"usp_claims_pass\" } }";
        String sampleUSP_PRA_credentials = "{ \"15\": { \"username\": \"usp_pra_user\", \"password\": \"usp_pra_pass\" } }";
        String sampleCSP_CLAIMS_credentials = "{ \"16\": { \"username\": \"csp_claims_user\", \"password\": \"csp_claims_pass\" } }";
        String sampleOCM_credentials = "{ \"17\": { \"username\": \"ocm_user\", \"password\": \"ocm_pass\" } }";
        String sampleIHR_credentials = "{ \"18\": { \"username\": \"ihr_user\", \"password\": \"ihr_pass\" } }";
        String sampleCC_credentials = "{ \"19\": { \"username\": \"cc_user\", \"password\": \"cc_pass\" } }";
        String sampleHouseCalls_credentials = "{ \"21\": { \"username\": \"housecalls_user\", \"password\": \"housecalls_pass\" } }";
        String sampleTEXAS_GOLD_CARD_credentials = "{ \"22\": { \"username\": \"texas_gold_user\", \"password\": \"texas_gold_pass\" } }";
        String sampleTRACKIT_credentials = "{ \"23\": { \"username\": \"trackit_user\", \"password\": \"trackit_pass\" } }";
        String sampleNGSClaims_credentials = "{ \"24\": { \"username\": \"ngsclaims_user\", \"password\": \"ngsclaims_pass\" } }";
        String sampleATSAppeals_credentials = "{ \"26\": { \"username\": \"atsappeals\", \"password\": \"other_pass\" } }";

        String sampleOTHER_credentials = "{ \"25\": { \"username\": \"other_user\", \"password\": \"other_pass\" } }";
        String sampleMemberPayment_credentials = "{ \"26\": { \"username\": \"memberpayment_user\", \"password\": \"memberpayment_pass\" } }";
        String consumerEngineering_credentials = "{ \"27\": { \"username\": \"referral_user\", \"password\": \"consumerEngineering\" } }";
        String ssbciConfig_credentials = "{ \"28\": { \"username\": \"sscbci_user\", \"password\": \"ssbci\" } }";

        // Use Reflection to set private fields
        setPrivateField("printTrailMap", samplePrintTrailMap);
        setPrivateField("LETGEN_configcredentials", sampleLETGEN_credentials);
        setPrivateField("UNET_configcredentials", sampleUNET_credentials);
        setPrivateField("NEXTGEN_configcredentials", sampleNEXTGEN_credentials);
        setPrivateField("_1CLICK_configcredentials", sample_1CLICK_credentials);
        setPrivateField("CCSManual_configcredentials", sampleCCSManual_credentials);
        setPrivateField("UNET_PRA_configcredentials", sampleUNET_PRA_credentials);
        setPrivateField("COSMOS_PRA_configcredentials", sampleCOSMOS_PRA_credentials);
        setPrivateField("COSMOS_configcredentials", sampleCOSMOS_credentials);
        setPrivateField("UHC_WEST_configcredentials", sampleUHC_WEST_credentials);
        setPrivateField("CSP_PRA_configcredentials", sampleCSP_PRA_credentials);
        setPrivateField("ODAR_configcredentials", sampleODAR_credentials);
        setPrivateField("MR_APPEALS_configcredentials", sampleMR_APPEALS_credentials);
        setPrivateField("ETS_APPEALS_configcredentials", sampleETS_APPEALS_credentials);
        setPrivateField("USP_CLAIMS_configcredentials", sampleUSP_CLAIMS_credentials);
        setPrivateField("USP_PRA_configcredentials", sampleUSP_PRA_credentials);
        setPrivateField("CSP_CLAIMS_configcredentials", sampleCSP_CLAIMS_credentials);
        setPrivateField("OCM_configcredentials", sampleOCM_credentials);
        setPrivateField("IHR_configcredentials", sampleIHR_credentials);
        setPrivateField("CC_configcredentials", sampleCC_credentials);
        setPrivateField("CAP_configcredentials", sampleCAP_credentials);
        setPrivateField("HouseCalls_configcredentials", sampleHouseCalls_credentials);
        setPrivateField("TEXAS_GOLD_CARD_configcredentials", sampleTEXAS_GOLD_CARD_credentials);
        setPrivateField("TRACKIT_configcredentials", sampleTRACKIT_credentials);
        setPrivateField("NGSClaims_configcredentials", sampleNGSClaims_credentials);
        setPrivateField("ATSAPPEALS_configcredentials", sampleATSAppeals_credentials);
        setPrivateField("mnrConfigcredentials", sampleATSAppeals_credentials);
        setPrivateField("MemberPayment_configcredentials", sampleMemberPayment_credentials);
        setPrivateField("OTHER_configcredentials", sampleOTHER_credentials);
        setPrivateField("consumerEngineeringConfigcredentials", consumerEngineering_credentials);
        setPrivateField("ssbciConfigcredentials", ssbciConfig_credentials);

        // Optionally, instantiate ObjectMapper and set it if needed
        // However, ConfigData creates a new ObjectMapper in its methods, so it's not strictly necessary
    }

    /**
     * Helper method to set private fields using reflection.
     *
     * @param fieldName Name of the private field.
     * @param value     Value to set.
     * @throws Exception If reflection fails.
     */
    private void setPrivateField(String fieldName, String value) throws Exception {
        Field field = ConfigData.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(configData, value);
    }

    /**
     * Test the getClientMapFromPrintTrail method with a valid printTrail.
     */
    @Test
    public void testGetClientMapFromPrintTrail_ValidTrail() {
        // Act
        Map<String, Object> result = configData.getClientMapFromPrintTrail("trail1");

        // Assert
        assertNotNull("Result should not be null for valid trail", result);
        assertEquals("Value for key1 should match", "value1", result.get("key1"));
        assertEquals("Value for key2 should match", "value2", result.get("key2"));
    }

    /**
     * Test the getClientMapFromPrintTrail method with an invalid printTrail.
     */
    @Test
    public void testGetClientMapFromPrintTrail_InvalidTrail() {
        // Act
        Map<String, Object> result = configData.getClientMapFromPrintTrail("nonexistentTrail");

        // Assert
        assertNull("Result should be null for invalid trail", result);
    }

    /**
     * Test the getClientMapFromPrintTrail method when printTrailMap JSON is malformed.
     */
    @Test
    public void testGetClientMapFromPrintTrail_MalformedJSON() throws Exception {
        // Set malformed JSON
        setPrivateField("printTrailMap", "{ invalid json }");

        // Act
        Map<String, Object> result = configData.getClientMapFromPrintTrail("trail1");

        // Assert
        assertNull("Result should be null when JSON is malformed", result);
    }

    /**
     * Test the getCredentials method with a valid spaceId.
     */
    @Test
    public void testGetCredentials_ValidSpaceId() {
        // Act
        Map<String, Object> credentials = configData.getCredentials(1);

        // Assert
        assertNotNull("Credentials should not be null for valid spaceId", credentials);
        assertEquals("Username should match", "letgen_user", credentials.get("username"));
        assertEquals("Password should match", "letgen_pass", credentials.get("password"));
    }

    /**
     * Test the getCredentials method with another valid spaceId.
     */
    @Test
    public void testGetCredentials_AnotherValidSpaceId() {
        // Act
        Map<String, Object> credentials = configData.getCredentials(2);

        // Assert
        assertNotNull("Credentials should not be null for valid spaceId", credentials);
        assertEquals("Username should match", "unet_user", credentials.get("username"));
        assertEquals("Password should match", "unet_pass", credentials.get("password"));
    }

    /**
     * Test the getCredentials method with an invalid spaceId.
     */
    @Test
    public void testGetCredentials_InvalidSpaceId() {
        // Act
        Map<String, Object> credentials = configData.getCredentials(999);

        // Assert
        assertTrue("Credentials should be empty for invalid spaceId", credentials.isEmpty());
    }

    /**
     * Test the getCredentials method when credentials JSON is malformed.
     */
    @Test
    public void testGetCredentials_MalformedCredentialsJSON() throws Exception {
        // Set malformed JSON for one of the credentials
        setPrivateField("LETGEN_configcredentials", "{ invalid json }");

        // Act
        Map<String, Object> credentials = configData.getCredentials(1);

        // Assert
        // Since LETGEN_configcredentials is malformed, credentials for spaceId 1 should be empty
        assertTrue("Credentials should be empty when JSON is malformed", credentials.isEmpty());
    }

    /**
     * Test the getCredentials method to ensure it retries upon missing credentials.
     */
    @Test
    public void testGetCredentials_RetriesOnMissingCredentials() throws Exception {
        // Remove a credential to simulate missing credentials
        setPrivateField("LETGEN_configcredentials", "{}"); // Empty JSON

        // Act
        Map<String, Object> credentials = configData.getCredentials(1);

        // Assert
        // Since credentials are empty after retrying, credentials should be empty
        assertTrue("Credentials should be empty after retries", credentials.isEmpty());
    }


    @Test
    public void testGetUploadProvider_returnsExpectedProvider() {
        String provider = configData.getUploadProvider(20);
        assertEquals("DOC360", provider);
    }


    @Test
    public void testGetDoc360DocClass_returnsExpectedClass() throws NoSuchFieldException, IllegalAccessException {
        String docClass = configData.getDoc360DocClass(20);
        assertEquals("DOC_CLASS_ABC", docClass);
    }

}
