package com.optum.fds.paperless.queue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.optum.fds.paperless.domain.service.ServiceBase;
import com.optum.fds.paperless.exception.ValidationException;
import com.optum.fds.paperless.model.GenericResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * Test class for SendQueue.
 */
@RunWith(MockitoJUnitRunner.class)
public class SendQueueTest {

    /**
     * Concrete subclass for testing since SendQueue is abstract.
     */
    public static class TestSendQueue extends SendQueue {

        // For simplicity, use a simple retry list
        private final List<ObjectNode> retryList = new ArrayList<>();

        protected TestSendQueue() throws IOException {
            super("testPath", "testName");
        }

        @Override
        protected List<ObjectNode> getRetryList() {
            return retryList;
        }

        @Override
        protected boolean addToErrorQueue(String request) {
            // For testing, assume adding to error queue always succeeds
            return true;
        }
    }

    private TestSendQueue sendQueue;

    @Mock
    private ServiceBase serviceBaseMock;

    @Mock
    private ObjectNode objectNodeMock;

    @Before
    public void setUp() throws IOException, NoSuchFieldException, IllegalAccessException {
        sendQueue = spy(new TestSendQueue());
        sendQueue.serviceBase = serviceBaseMock;
        sendQueue.mapper = new ObjectMapper();

        doReturn(objectNodeMock).when(sendQueue)
                .getSendingParameters(anyString(), anyString(), anyString(), anyString(), anyString(), anyInt());

        Field retryCountField = SendQueue.class.getDeclaredField("sendQueueRetryCountMax");
        retryCountField.setAccessible(true);
        retryCountField.set(sendQueue, 3);

        ReflectionTestUtils.setField(sendQueue, "queuedId", "id");
        ReflectionTestUtils.setField(sendQueue, "queuedpathVariable", "pathVariable");
        ReflectionTestUtils.setField(sendQueue, "queuedDelegate", "delegate");
        ReflectionTestUtils.setField(sendQueue, "queuedDelegateParams", "delegateParams");
        ReflectionTestUtils.setField(sendQueue, "queuedApiUrl", "apiUrl");
        ReflectionTestUtils.setField(sendQueue, "queuedRetryCnt", "retryCnt");
        ReflectionTestUtils.setField(sendQueue, "queuedRequest", "request");
        ReflectionTestUtils.setField(sendQueue, "maxRetries", 3);
    }

    /**
     * Test the addSendDocumentRequestToFds method with seven parameters.
     * It should delegate to the overloaded method with an additional null parameter.
     */
    @Test
    public void testAddSendDocumentRequestToFds_WithSevenParameters() throws ValidationException, JsonProcessingException {
        String delegate = "testDelegate";
        Map<String, Object> delegateParams = new HashMap<>();
        delegateParams.put("key", "value");
        String apiUrl = "http://testapi.com/endpoint";
        String request = "{\"data\":\"test\"}";
        Integer retryCnt = 1;
        boolean enqueue = true;
        boolean loadTest = false;

        sendQueue.addSendDocumentRequestToFds(delegate, delegateParams, apiUrl, request, retryCnt, enqueue, loadTest);

        verify(sendQueue, times(1)).addSendDocumentRequestToFds(
                eq(delegate),
                eq(delegateParams),
                eq(apiUrl),
                eq(request),
                eq(retryCnt),
                eq(enqueue),
                eq(loadTest),
                isNull(String.class)
        );
    }

    @Test
    public void testConvertAndRetryParameters() {
        ReflectionTestUtils.setField(sendQueue, "maxRetries", 3);

        String delegate = "testDelegate";
        String delegateParms = "delegate";
        String apiUrl = "http://testapi.com/endpoint";
        String request = "{\"data\":\"test\"}";
        Integer retryCnt = 1;
        String id = "01";
        String pathVariable = "pathvariable";

        ObjectNode retried = sendQueue.convertAndRetry(id, pathVariable, delegate, delegateParms, apiUrl, retryCnt, request);

        assertNotNull(retried);
        assertEquals(2, retried.get("retryCnt").asInt());
        assertEquals(id, retried.get("id").asText());
    }

    @Test
    public void testConvertAndRetryReturnsNullWhenRetryCountExceedsMax() {
        ObjectNode retried = sendQueue.convertAndRetry("01", "path", "delegate", "{}", "api", 2, "request");

        assertTrue(retried == null);
    }

    @Test
    public void convertAndProcessNullTest() {
        boolean result =  sendQueue.convertAndProcess(null);
        assertTrue(result);
    }

    @Test
    public void convertAndProcessSuccessTest() throws Exception {
        ObjectNode readNode = new ObjectMapper().createObjectNode();
        readNode.put("id", "01");
        readNode.put("pathVariable", "space-1");
        readNode.put("delegate", "delegate-name");
        readNode.put("delegateParams", "{}");
        readNode.put("apiUrl", "http://testapi.com/endpoint");
        readNode.put("retryCnt", 1);
        readNode.put("request", "payload");

        byte[] data = new ObjectMapper().writeValueAsBytes(readNode);

        doReturn(true).when(sendQueue).sendRequestToSvc(
                eq("space-1"),
                eq("delegate-name"),
                anyMap(),
                eq("http://testapi.com/endpoint"),
                eq(1),
                eq("\"payload\"")
        );

        boolean result = sendQueue.convertAndProcess(data);

        assertTrue(result);
        assertTrue(sendQueue.getRetryList().isEmpty());

        verify(sendQueue).sendRequestToSvc(
                eq("space-1"),
                eq("delegate-name"),
                anyMap(),
                eq("http://testapi.com/endpoint"),
                eq(1),
                eq("\"payload\"")
        );
    }

    @Test
    public void convertAndProcessAddsRetryWhenSendFails() throws Exception {
        ObjectNode readNode = new ObjectMapper().createObjectNode();
        readNode.put("id", "02");
        readNode.put("pathVariable", "space-2");
        readNode.put("delegate", "delegate-name");
        readNode.put("delegateParams", "{}");
        readNode.put("apiUrl", "http://testapi.com/endpoint");
        readNode.put("retryCnt", 1);
        readNode.put("request", "payload");

        byte[] data = new ObjectMapper().writeValueAsBytes(readNode);

        doReturn(false).when(sendQueue).sendRequestToSvc(
                eq("space-2"),
                eq("delegate-name"),
                anyMap(),
                eq("http://testapi.com/endpoint"),
                eq(1),
                eq("\"payload\"")
        );

        boolean result = sendQueue.convertAndProcess(data);

        assertFalse(result);
        assertEquals(1, sendQueue.getRetryList().size());
    }

    @Test
    public void testAddSendDocumentRequestToFds_WhenLoadTestTrue_ShouldReturnWithoutSendingOrQueueing() throws Exception {
        Map<String, Object> delegateParams = new HashMap<>();
        delegateParams.put("key", "value");

        sendQueue.addSendDocumentRequestToFds(
                "delegate-name",
                delegateParams,
                "http://testapi.com/endpoint",
                "{\"data\":\"test\"}",
                1,
                true,
                true,
                null
        );

        verify(sendQueue, never()).sendRequestToSvc(
                any(),
                any(),
                anyMap(),
                anyString(),
                anyInt(),
                any()
        );

        verify(sendQueue, never()).getSendingParameters(
                anyString(),
                anyString(),
                anyString(),
                anyString(),
                anyString(),
                anyInt()
        );

        verify(sendQueue, never()).addToQueue(any(ObjectNode.class));
        verifyNoInteractions(serviceBaseMock);
        assertTrue(sendQueue.getRetryList().isEmpty());
    }

    @Test
    public void testAddSendDocumentRequestToFds_WhenApiUrlIsNull_ShouldThrowValidationException() throws Exception {
        Map<String, Object> delegateParams = new HashMap<>();
        delegateParams.put("key", "value");

        ValidationException exception = assertThrows(
                ValidationException.class,
                () -> sendQueue.addSendDocumentRequestToFds(
                        "delegate-name",
                        delegateParams,
                        null,
                        "{\"data\":\"test\"}",
                        1,
                        true,
                        false,
                        null
                )
        );

        assertEquals("No corresponding apiUrl to URL: apiUrl=null", exception.getMessage());

        verify(sendQueue, never()).sendRequestToSvc(
                any(),
                any(),
                anyMap(),
                any(),
                anyInt(),
                any()
        );
        verify(sendQueue, never()).getSendingParameters(
                anyString(),
                anyString(),
                anyString(),
                anyString(),
                anyString(),
                anyInt()
        );
        verify(sendQueue, never()).addToQueue(any(ObjectNode.class));
    }

    @Test
    public void testAddSendDocumentRequestToFds_WhenEnqueueFalseAndSendSucceeds_ShouldReturnWithoutQueueing() throws Exception {
        Map<String, Object> delegateParams = new HashMap<>();
        delegateParams.put("key", "value");

        doReturn(true).when(sendQueue).sendRequestToSvc(
                eq("NULL"),
                eq("delegate-name"),
                eq(delegateParams),
                eq("http://testapi.com/endpoint"),
                eq(1),
                eq("{\"data\":\"test\"}")
        );

        sendQueue.addSendDocumentRequestToFds(
                "delegate-name",
                delegateParams,
                "http://testapi.com/endpoint",
                "{\"data\":\"test\"}",
                1,
                false,
                false,
                null
        );

        verify(sendQueue, times(1)).sendRequestToSvc(
                eq("NULL"),
                eq("delegate-name"),
                eq(delegateParams),
                eq("http://testapi.com/endpoint"),
                eq(1),
                eq("{\"data\":\"test\"}")
        );

        verify(sendQueue, never()).getSendingParameters(
                anyString(),
                anyString(),
                anyString(),
                anyString(),
                anyString(),
                anyInt()
        );

        verify(sendQueue, never()).addToQueue(any(ObjectNode.class));
    }

    @Test
    public void testAddSendDocumentRequestToFds_WhenRequestIsMultiValueMap_ShouldSerializeRequestAndQueueIt() throws Exception {
        ObjectMapper mapperSpy = spy(new ObjectMapper());
        sendQueue.mapper = mapperSpy;

        Map<String, Object> delegateParams = new LinkedHashMap<>();
        delegateParams.put("key", "value");

        MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
        requestMap.add("fileName", "test.pdf");
        requestMap.add("docId", "123");

        ObjectMapper realMapper = new ObjectMapper();
        String expectedDelegateParamsJson = realMapper.writeValueAsString(delegateParams);
        String expectedRequestJson = realMapper.writeValueAsString(requestMap);

        doReturn(objectNodeMock).when(sendQueue).getSendingParameters(
                eq("NULL"),
                eq("delegate-name"),
                eq(expectedDelegateParamsJson),
                eq("http://testapi.com/endpoint"),
                eq(expectedRequestJson),
                eq(1)
        );

        doReturn(true).when(sendQueue).addToQueue(objectNodeMock);

        sendQueue.addSendDocumentRequestToFds(
                "delegate-name",
                delegateParams,
                "http://testapi.com/endpoint",
                requestMap,
                1,
                true,
                false,
                null
        );

        verify(mapperSpy, times(1)).writeValueAsString(requestMap);
        verify(mapperSpy, times(1)).writeValueAsString(delegateParams);
        verify(sendQueue).getSendingParameters(
                eq("NULL"),
                eq("delegate-name"),
                eq(expectedDelegateParamsJson),
                eq("http://testapi.com/endpoint"),
                eq(expectedRequestJson),
                eq(1)
        );
        verify(sendQueue).addToQueue(objectNodeMock);
    }

    @Test
    public void testSendToSvc_WhenQueueIsEmpty_ShouldGcAndRequeue() throws Exception {
        doReturn(true).when(sendQueue).isEmpty();
        doReturn(0L).when(sendQueue).size();
        doNothing().when(sendQueue).gc();
        doNothing().when(sendQueue).requeue();

        sendQueue.sendToSvc();

        verify(sendQueue, never()).dequeue();
        verify(sendQueue, never()).convertAndProcess(any());
        verify(sendQueue, times(1)).gc();
        verify(sendQueue, times(1)).requeue();
    }

    @Test
    public void testSendToSvc_WhenConvertAndProcessReturnsFalse_ShouldContinueAndRequeue() throws Exception {
        byte[] input = "test-data".getBytes();

        doReturn(false, true, true).when(sendQueue).isEmpty();
        doReturn(1L, 0L).when(sendQueue).size();
        doReturn(input).when(sendQueue).dequeue();
        doReturn(false).when(sendQueue).convertAndProcess(input);
        doNothing().when(sendQueue).gc();
        doNothing().when(sendQueue).requeue();

        sendQueue.sendToSvc();

        verify(sendQueue, times(1)).dequeue();
        verify(sendQueue, times(1)).convertAndProcess(input);
        verify(sendQueue, times(1)).gc();
        verify(sendQueue, times(1)).requeue();
    }

    @Test
    public void testSendToSvc_WhenDequeueThrowsIOException_ShouldCleanupAndContinue() throws Exception {
        doReturn(false, true, true).when(sendQueue).isEmpty();
        doReturn(1L, 0L).when(sendQueue).size();
        doThrow(new IOException("dequeue failed")).when(sendQueue).dequeue();
        doNothing().when(sendQueue).close();
        doNothing().when(sendQueue).gc();
        doNothing().when(sendQueue).requeue();

        sendQueue.sendToSvc();

        verify(sendQueue, times(1)).dequeue();
        verify(sendQueue, atLeastOnce()).close();
        verify(sendQueue, atLeastOnce()).gc();
        verify(sendQueue, times(1)).requeue();
    }

    @Test
    public void testSendToSvc_WhenGcThrowsIOException_ShouldCleanupAndReturnWithoutRequeue() throws Exception {
        doReturn(true).when(sendQueue).isEmpty();
        doReturn(0L).when(sendQueue).size();

        doThrow(new IOException("gc failed"))
                .doNothing()
                .when(sendQueue).gc();

        doNothing().when(sendQueue).close();
        sendQueue.sendToSvc();

        verify(sendQueue, never()).dequeue();
        verify(sendQueue, times(1)).close();
        verify(sendQueue, times(2)).gc(); // one from sendToSvc, one from cleanup()
        verify(sendQueue, never()).requeue();
    }

    @Test
    public void testAddToErrorQueue_DefaultImplementationReturnsFalse() throws Exception {
        SendQueue baseSendQueue = new SendQueue("testPath-default", "testName-default") {
            private final List<ObjectNode> retryList = new ArrayList<>();

            @Override
            protected List<ObjectNode> getRetryList() {
                return retryList;
            }
        };

        try {
            assertFalse(baseSendQueue.addToErrorQueue("{\"data\":\"test\"}"));
        } finally {
            baseSendQueue.close();
        }
    }

    @Test
    public void testGetSendingParameters_ShouldPopulateAllQueuedFields() {
        doCallRealMethod().when(sendQueue).getSendingParameters(
                anyString(), anyString(), anyString(), anyString(), anyString(), anyInt()
        );

        String pathVariable = "space-123";
        String delegate = "delegate-name";
        String delegateParams = "{\"key\":\"value\"}";
        String apiUrl = "http://testapi.com/endpoint";
        String request = "{\"data\":\"test\"}";
        Integer retryCnt = 2;

        ObjectNode result = sendQueue.getSendingParameters(
                pathVariable,
                delegate,
                delegateParams,
                apiUrl,
                request,
                retryCnt
        );

        assertNotNull(result);
        assertTrue(result.has("id"));
        assertNotNull(result.get("id").asText());
        assertFalse(result.get("id").asText().isEmpty());

        UUID.fromString(result.get("id").asText());

        assertEquals(pathVariable, result.get("pathVariable").asText());
        assertEquals(delegate, result.get("delegate").asText());
        assertEquals(delegateParams, result.get("delegateParams").asText());
        assertEquals(apiUrl, result.get("apiUrl").asText());
        assertEquals(retryCnt.intValue(), result.get("retryCnt").asInt());
        assertEquals(request, result.get("request").asText());
    }
    @Test
    public void testAddToQueue_WhenEnqueueThrowsIOException_ShouldReturnFalseAndCleanup() throws Exception {
        ObjectNode requestNode = new ObjectMapper().createObjectNode();
        requestNode.put("request", "{\"data\":\"test\"}");

        doThrow(new IOException("queue write failed"))
                .when(sendQueue).enqueue(any(byte[].class));
        doNothing().when(sendQueue).close();
        doNothing().when(sendQueue).gc();

        boolean result = sendQueue.addToQueue(requestNode);

        assertFalse(result);
        verify(sendQueue, times(1)).enqueue(any(byte[].class));
        verify(sendQueue, times(1)).close();
        verify(sendQueue, times(1)).gc();
    }

    @Test
    public void convertAndProcess_WhenSendFailsAndRetryCountExceededAndErrorQueueAddFails_ShouldReturnFalseWithoutAddingRetry() throws Exception {
        ReflectionTestUtils.setField(sendQueue, "maxRetries", 3);

        ObjectNode readNode = new ObjectMapper().createObjectNode();
        readNode.put("id", "03");
        readNode.put("pathVariable", "space-3");
        readNode.put("delegate", "delegate-name");
        readNode.put("delegateParams", "{}");
        readNode.put("apiUrl", "http://testapi.com/endpoint");
        readNode.put("retryCnt", 3); // equal to maxRetries
        readNode.put("request", "payload");

        byte[] data = new ObjectMapper().writeValueAsBytes(readNode);

        doReturn(false).when(sendQueue).sendRequestToSvc(
                eq("space-3"),
                eq("delegate-name"),
                anyMap(),
                eq("http://testapi.com/endpoint"),
                eq(3),
                eq("\"payload\"")
        );

        doReturn(false).when(sendQueue).addToErrorQueue("\"payload\"");

        boolean result = sendQueue.convertAndProcess(data);

        assertFalse(result);
        assertTrue(sendQueue.getRetryList().isEmpty());

        verify(sendQueue).sendRequestToSvc(
                eq("space-3"),
                eq("delegate-name"),
                anyMap(),
                eq("http://testapi.com/endpoint"),
                eq(3),
                eq("\"payload\"")
        );
        verify(sendQueue).addToErrorQueue("\"payload\"");
    }

    @Test
    public void convertAndProcess_WhenSendThrowsAndRetryCountExceededAndAddToErrorQueueReturnsFalse_ShouldReturnFalseWithoutRetrying() throws Exception {
        ReflectionTestUtils.setField(sendQueue, "maxRetries", 3);

        ObjectNode readNode = new ObjectMapper().createObjectNode();
        readNode.put("id", "04");
        readNode.put("pathVariable", "space-4");
        readNode.put("delegate", "delegate-name");
        readNode.put("delegateParams", "{}");
        readNode.put("apiUrl", "http://testapi.com/endpoint");
        readNode.put("retryCnt", 3);
        readNode.put("request", "payload");

        byte[] data = new ObjectMapper().writeValueAsBytes(readNode);

        doThrow(new RuntimeException("send failure")).when(sendQueue).sendRequestToSvc(
                eq("space-4"),
                eq("delegate-name"),
                anyMap(),
                eq("http://testapi.com/endpoint"),
                eq(3),
                eq("\"payload\"")
        );
        doReturn(false).when(sendQueue).addToErrorQueue("\"payload\"");

        boolean result = sendQueue.convertAndProcess(data);

        assertFalse(result);
        assertTrue(sendQueue.getRetryList().isEmpty());

        verify(sendQueue).sendRequestToSvc(
                eq("space-4"),
                eq("delegate-name"),
                anyMap(),
                eq("http://testapi.com/endpoint"),
                eq(3),
                eq("\"payload\"")
        );
        verify(sendQueue).addToErrorQueue("\"payload\"");
        verify(sendQueue, never()).convertAndRetry(
                anyString(), anyString(), anyString(), anyString(), anyString(), anyInt(), anyString()
        );
    }

    @Test
    public void convertAndProcess_WhenSendThrowsAndRetryCountExceededAndAddToErrorQueueReturnsTrue_ShouldReturnFalseWithoutRetrying() throws Exception {
        ReflectionTestUtils.setField(sendQueue, "maxRetries", 3);

        ObjectNode readNode = new ObjectMapper().createObjectNode();
        readNode.put("id", "05");
        readNode.put("pathVariable", "space-5");
        readNode.put("delegate", "NULL");
        readNode.put("delegateParams", "{}");
        readNode.put("apiUrl", "http://testapi.com/endpoint");
        readNode.put("retryCnt", 3);
        readNode.put("request", "payload");

        byte[] data = new ObjectMapper().writeValueAsBytes(readNode);

        doThrow(new RuntimeException("send failure")).when(sendQueue).sendRequestToSvc(
                eq("space-5"),
                eq("NULL"),
                anyMap(),
                eq("http://testapi.com/endpoint"),
                eq(3),
                eq("\"payload\"")
        );
        doReturn(true).when(sendQueue).addToErrorQueue("\"payload\"");

        boolean result = sendQueue.convertAndProcess(data);

        assertFalse(result);
        assertTrue(sendQueue.getRetryList().isEmpty());

        verify(sendQueue).addToErrorQueue("\"payload\"");
        verify(sendQueue, never()).convertAndRetry(
                anyString(), anyString(), anyString(), anyString(), anyString(), anyInt(), anyString()
        );
    }

    @Test
    public void convertAndProcess_WhenSendThrowsAndRetryCountBelowMaxAndConvertAndRetryReturnsNode_ShouldAddRetryRequest() throws Exception {
        ReflectionTestUtils.setField(sendQueue, "maxRetries", 4);

        ObjectNode readNode = new ObjectMapper().createObjectNode();
        readNode.put("id", "06");
        readNode.put("pathVariable", "space-6");
        readNode.put("delegate", "delegate-name");
        readNode.put("delegateParams", "{}");
        readNode.put("apiUrl", "http://testapi.com/endpoint");
        readNode.put("retryCnt", 1);
        readNode.put("request", "payload");

        byte[] data = new ObjectMapper().writeValueAsBytes(readNode);

        ObjectNode retryNode = new ObjectMapper().createObjectNode();
        retryNode.put("id", "06");
        retryNode.put("retryCnt", 2);

        doThrow(new RuntimeException("send failure")).when(sendQueue).sendRequestToSvc(
                eq("space-6"),
                eq("delegate-name"),
                anyMap(),
                eq("http://testapi.com/endpoint"),
                eq(1),
                eq("\"payload\"")
        );
        doReturn(retryNode).when(sendQueue).convertAndRetry(
                eq("06"),
                eq("space-6"),
                eq("delegate-name"),
                eq("{}"),
                eq("http://testapi.com/endpoint"),
                eq(1),
                eq("\"payload\"")
        );

        boolean result = sendQueue.convertAndProcess(data);

        assertFalse(result);
        assertEquals(1, sendQueue.getRetryList().size());
        assertSame(retryNode, sendQueue.getRetryList().get(0));

        verify(sendQueue, never()).addToErrorQueue(anyString());
        verify(sendQueue).convertAndRetry(
                eq("06"),
                eq("space-6"),
                eq("delegate-name"),
                eq("{}"),
                eq("http://testapi.com/endpoint"),
                eq(1),
                eq("\"payload\"")
        );
    }

    @Test
    public void convertAndProcess_WhenSendThrowsAndRetryCountBelowMaxAndConvertAndRetryReturnsNull_ShouldNotAddRetryRequest() throws Exception {
        ReflectionTestUtils.setField(sendQueue, "maxRetries", 3);

        ObjectNode readNode = new ObjectMapper().createObjectNode();
        readNode.put("id", "07");
        readNode.put("pathVariable", "space-7");
        readNode.put("delegate", "delegate-name");
        readNode.put("delegateParams", "{}");
        readNode.put("apiUrl", "http://testapi.com/endpoint");
        readNode.put("retryCnt", 2);
        readNode.put("request", "payload");

        byte[] data = new ObjectMapper().writeValueAsBytes(readNode);

        doThrow(new RuntimeException("send failure")).when(sendQueue).sendRequestToSvc(
                eq("space-7"),
                eq("delegate-name"),
                anyMap(),
                eq("http://testapi.com/endpoint"),
                eq(2),
                eq("\"payload\"")
        );
        doReturn(null).when(sendQueue).convertAndRetry(
                eq("07"),
                eq("space-7"),
                eq("delegate-name"),
                eq("{}"),
                eq("http://testapi.com/endpoint"),
                eq(2),
                eq("\"payload\"")
        );

        boolean result = sendQueue.convertAndProcess(data);

        assertFalse(result);
        assertTrue(sendQueue.getRetryList().isEmpty());

        verify(sendQueue, never()).addToErrorQueue(anyString());
        verify(sendQueue).convertAndRetry(
                eq("07"),
                eq("space-7"),
                eq("delegate-name"),
                eq("{}"),
                eq("http://testapi.com/endpoint"),
                eq(2),
                eq("\"payload\"")
        );
    }

    @Test
    public void testSendRequestToSvc_WhenApiUrlIsNull_ShouldReturnFalse() {
        boolean result = sendQueue.sendRequestToSvc(
                "space-1",
                "delegate-name",
                new HashMap<>(),
                null,
                1,
                "payload"
        );

        assertFalse(result);
        verify(sendQueue, never()).postRequestGenericResponse(anyString(), anyString(), any());
        verify(sendQueue, never()).postRequestMultipart(anyString(), any(MultiValueMap.class), any());
    }

    @Test
    public void testSendRequestToSvc_WhenPathVariableIsNULLAndGenericResponseIsOkAndCallbackDelegateIsNull_ShouldReturnTrue() {
        GenericResponse responseBody = mock(GenericResponse.class);
        ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);

        doReturn(responseEntity).when(sendQueue).postRequestGenericResponse(
                eq("http://testapi.com/endpoint"),
                eq("payload"),
                isNull()
        );

        boolean result = sendQueue.sendRequestToSvc(
                "NULL",
                null,
                new HashMap<>(),
                "http://testapi.com/endpoint",
                1,
                "payload"
        );

        assertTrue(result);
        verify(sendQueue).postRequestGenericResponse(
                eq("http://testapi.com/endpoint"),
                eq("payload"),
                isNull()
        );
        verify(sendQueue, never()).postRequestMultipart(anyString(), any(MultiValueMap.class), any());
    }

    @Test
    public void testSendRequestToSvc_WhenMultipartRequestAndCreatedResponseAndValidCallbackDelegate_ShouldInvokeCallback() {
        GenericResponse responseBody = mock(GenericResponse.class);
        ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.CREATED);

        Map<String, Object> delegateParams = new HashMap<>();
        delegateParams.put("key", "value");

        MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
        requestMap.add("fileName", "test.pdf");

        doReturn(responseEntity).when(sendQueue).postRequestMultipart(
                eq("http://testapi.com/endpoint"),
                eq(requestMap),
                eq("space-9")
        );

        try (MockedStatic<com.optum.fds.paperless.FDSHelper> helperMock = mockStatic(com.optum.fds.paperless.FDSHelper.class)) {
            boolean result = sendQueue.sendRequestToSvc(
                    "space-9",
                    "delegate-name",
                    delegateParams,
                    "http://testapi.com/endpoint",
                    1,
                    requestMap
            );

            assertTrue(result);

            verify(sendQueue).postRequestMultipart(
                    eq("http://testapi.com/endpoint"),
                    eq(requestMap),
                    eq("space-9")
            );
            verify(sendQueue, never()).postRequestGenericResponse(anyString(), anyString(), any());

            helperMock.verify(() ->
                    com.optum.fds.paperless.FDSHelper.runProcess(
                            eq("delegate-name"),
                            eq(delegateParams),
                            eq(responseBody)
                    )
            );
        }
    }

    @Test
    public void testSendRequestToSvc_WhenGenericResponseIsNotSuccessful_ShouldReturnFalseAndNotInvokeCallback() {
        GenericResponse responseBody = mock(GenericResponse.class);
        ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.BAD_REQUEST);

        Map<String, Object> delegateParams = new HashMap<>();
        delegateParams.put("key", "value");

        doReturn(responseEntity).when(sendQueue).postRequestGenericResponse(
                eq("http://testapi.com/endpoint"),
                eq("payload"),
                eq("space-10")
        );

        try (MockedStatic<com.optum.fds.paperless.FDSHelper> helperMock = mockStatic(com.optum.fds.paperless.FDSHelper.class)) {
            boolean result = sendQueue.sendRequestToSvc(
                    "space-10",
                    "delegate-name",
                    delegateParams,
                    "http://testapi.com/endpoint",
                    1,
                    "payload"
            );

            assertFalse(result);

            verify(sendQueue).postRequestGenericResponse(
                    eq("http://testapi.com/endpoint"),
                    eq("payload"),
                    eq("space-10")
            );
            verify(sendQueue, never()).postRequestMultipart(anyString(), any(MultiValueMap.class), any());

            helperMock.verifyNoInteractions();
        }
    }

    @Test
    public void testSendRequestToSvc_WhenCallbackDelegateIsNULL_ShouldReturnTrueWithoutInvokingCallback() {
        GenericResponse responseBody = mock(GenericResponse.class);
        ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);

        doReturn(responseEntity).when(sendQueue).postRequestGenericResponse(
                eq("http://testapi.com/endpoint"),
                eq("payload"),
                eq("space-11")
        );

        try (MockedStatic<com.optum.fds.paperless.FDSHelper> helperMock = mockStatic(com.optum.fds.paperless.FDSHelper.class)) {
            boolean result = sendQueue.sendRequestToSvc(
                    "space-11",
                    "NULL",
                    new HashMap<>(),
                    "http://testapi.com/endpoint",
                    1,
                    "payload"
            );

            assertTrue(result);
            helperMock.verifyNoInteractions();
        }
    }

    @Test
    public void testPostRequestGenericResponse_ShouldDelegateToServiceBase() {
        GenericResponse responseBody = mock(GenericResponse.class);
        ResponseEntity<GenericResponse> expected = new ResponseEntity<>(responseBody, HttpStatus.OK);

        when(serviceBaseMock.postRequestToSvc(
                eq("http://testapi.com/endpoint"),
                eq("payload"),
                eq("space-12")
        )).thenReturn(expected);

        ResponseEntity<GenericResponse> actual = sendQueue.postRequestGenericResponse(
                "http://testapi.com/endpoint",
                "payload",
                "space-12"
        );

        assertSame(expected, actual);
        verify(serviceBaseMock).postRequestToSvc(
                eq("http://testapi.com/endpoint"),
                eq("payload"),
                eq("space-12")
        );
    }

    @Test
    public void testPostRequestMultipart_ShouldDelegateToServiceBaseMultipartForm() {
        GenericResponse responseBody = mock(GenericResponse.class);
        ResponseEntity<GenericResponse> expected = new ResponseEntity<>(responseBody, HttpStatus.OK);

        MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
        requestMap.add("fileName", "test.pdf");

        when(serviceBaseMock.postRequestToSvcMultipartForm(
                eq("http://testapi.com/endpoint"),
                eq(requestMap),
                eq("space-13")
        )).thenReturn(expected);

        ResponseEntity<GenericResponse> actual = sendQueue.postRequestMultipart(
                "http://testapi.com/endpoint",
                requestMap,
                "space-13"
        );

        assertSame(expected, actual);
        verify(serviceBaseMock).postRequestToSvcMultipartForm(
                eq("http://testapi.com/endpoint"),
                eq(requestMap),
                eq("space-13")
        );
    }

    @Test
    public void testRequeue_WhenRetryListIsEmpty_ShouldNotAddAnythingToQueue() {
        assertTrue(sendQueue.getRetryList().isEmpty());

        sendQueue.requeue();

        verify(sendQueue, never()).addToQueue(any(ObjectNode.class));
        assertTrue(sendQueue.getRetryList().isEmpty());
    }

    @Test
    public void testRequeue_WhenRetryListHasItems_ShouldAddEachItemAndClearRetryList() {
        ObjectNode first = new ObjectMapper().createObjectNode();
        first.put("id", "1");

        ObjectNode second = new ObjectMapper().createObjectNode();
        second.put("id", "2");

        sendQueue.getRetryList().add(first);
        sendQueue.getRetryList().add(second);

        doReturn(true).when(sendQueue).addToQueue(any(ObjectNode.class));

        sendQueue.requeue();

        verify(sendQueue).addToQueue(first);
        verify(sendQueue).addToQueue(second);
        assertTrue(sendQueue.getRetryList().isEmpty());
    }

    @Test
    public void testCleanup_ShouldCloseAndGc_WhenNoExceptionOccurs() throws Exception {
        Method cleanupMethod = SendQueue.class.getDeclaredMethod("cleanup");
        cleanupMethod.setAccessible(true);

        doNothing().when(sendQueue).close();
        doNothing().when(sendQueue).gc();

        cleanupMethod.invoke(sendQueue);

        verify(sendQueue).close();
        verify(sendQueue).gc();
    }

    @Test
    public void testCleanup_ShouldSwallowIOException_WhenCloseThrows() throws Exception {
        Method cleanupMethod = SendQueue.class.getDeclaredMethod("cleanup");
        cleanupMethod.setAccessible(true);

        doThrow(new IOException("close failed")).when(sendQueue).close();

        cleanupMethod.invoke(sendQueue);

        verify(sendQueue).close();
        verify(sendQueue, never()).gc();
    }
}