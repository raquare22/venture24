package com.optum.fds.paperless.queue;

import static org.junit.Assert.*;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;

import java.io.IOException;
import java.util.List;

public class HookSendQueueTest {

    @Test
    public void testConstructorAndGetRetryList() throws IOException {
        String path = "testPath";
        String name = "testName";
        HookSendQueue queue = new HookSendQueue(path, name);

        assertNotNull(queue);
        List<ObjectNode> retryList = queue.getRetryList();
        assertNotNull(retryList);
        assertTrue(retryList.isEmpty());
    }

    @Test
    public void testAddToRetryList() throws IOException {
        String path = "testPath";
        String name = "testName";
        HookSendQueue queue = new HookSendQueue(path, name);

        ObjectNode node = JsonNodeFactory.instance.objectNode();
        node.put("key", "value");
        queue.getRetryList().add(node);

        List<ObjectNode> retryList = queue.getRetryList();
        assertEquals(1, retryList.size());
        assertEquals("value", retryList.get(0).get("key").asText());
    }

    @Test
    public void testAddToErrorQueue() throws IOException {
        String path = "testPath";
        String name = "testName";
        HookSendQueue queue = new HookSendQueue(path, name);

        // Set the private field hookSendQueueAutoError using ReflectionTestUtils
        ReflectionTestUtils.setField(queue, "hookSendQueueAutoError", true);
        assertTrue(queue.addToErrorQueue("testRequest"));

        ReflectionTestUtils.setField(queue, "hookSendQueueAutoError", false);
        assertFalse(queue.addToErrorQueue("testRequest"));
    }
}