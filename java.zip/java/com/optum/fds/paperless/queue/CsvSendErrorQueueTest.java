package com.optum.fds.paperless.queue;

import static org.junit.Assert.*;
import org.junit.Test;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;

import java.io.IOException;
import java.util.List;

public class CsvSendErrorQueueTest {

    @Test
    public void testConstructorAndGetRetryList() throws IOException {
        String path = "testPath";
        String name = "testName";
        CsvSendErrorQueue queue = new CsvSendErrorQueue(path, name);

        assertNotNull(queue);
        List<ObjectNode> retryList = queue.getRetryList();
        assertNotNull(retryList);
        assertTrue(retryList.isEmpty());
    }

    @Test
    public void testAddToRetryList() throws IOException {
        String path = "testPath";
        String name = "testName";
        CsvSendErrorQueue queue = new CsvSendErrorQueue(path, name);

        ObjectNode node = JsonNodeFactory.instance.objectNode();
        node.put("key", "value");
        queue.getRetryList().add(node);

        List<ObjectNode> retryList = queue.getRetryList();
        assertEquals(1, retryList.size());
        assertEquals("value", retryList.get(0).get("key").asText());
    }
}