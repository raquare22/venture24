package com.optum.fds.paperless.queue;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.File;
import java.io.IOException;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * Test class for SendQueueFactory.
 */
@RunWith(MockitoJUnitRunner.class)
public class SendQueueFactoryTest {

    @Spy
    @InjectMocks
    private SendQueueFactory sendQueueFactory;

    @Rule
    public TemporaryFolder mockPath = new TemporaryFolder();

    @Before
    public void setUp() throws IOException {
        // Mock getQueuePath() to return a safe, existing directory
//        mockPath = System.getProperty("java.io.tmpdir"); // Typically exists and is writable
        doReturn(mockPath.getRoot().getAbsolutePath()).when(sendQueueFactory).getQueuePath();
    }

    /**
     * Test createCsvSendQueue() method.
     */
    @Test
    public void testCreateCsvSendQueue() throws IOException {
        // Act
        CsvSendQueue csvSendQueue = sendQueueFactory.createCsvSendQueue();

        // Assert
        assertNotNull("CsvSendQueue should not be null", csvSendQueue);
        assertTrue("Instance should be of type CsvSendQueue", csvSendQueue instanceof CsvSendQueue);

        // Verify that getQueuePath() was called once
        verify(sendQueueFactory, times(1)).getQueuePath();
    }

    /**
     * Test createCsvSendErrorQueue() method.
     */
    @Test
    public void testCreateCsvSendErrorQueue() throws IOException {
        // Act
        CsvSendErrorQueue csvSendErrorQueue = sendQueueFactory.createCsvSendErrorQueue();

        // Assert
        assertNotNull("CsvSendErrorQueue should not be null", csvSendErrorQueue);
        assertTrue("Instance should be of type CsvSendErrorQueue", csvSendErrorQueue instanceof CsvSendErrorQueue);

        // Verify that getQueuePath() was called once
        verify(sendQueueFactory, times(1)).getQueuePath();
    }

    /**
     * Test createHookSendQueue() method.
     */
    @Test
    public void testCreateHookSendQueue() throws IOException {
        // Act
        HookSendQueue hookSendQueue = sendQueueFactory.createHookSendQueue();

        // Assert
        assertNotNull("HookSendQueue should not be null", hookSendQueue);
        assertTrue("Instance should be of type HookSendQueue", hookSendQueue instanceof HookSendQueue);

        // Verify that getQueuePath() was called once
        verify(sendQueueFactory, times(1)).getQueuePath();
    }

    /**
     * Test createHookSendErrorQueue() method.
     */
    @Test
    public void testCreateHookSendErrorQueue() throws IOException {
        // Act
        HookSendErrorQueue hookSendErrorQueue = sendQueueFactory.createHookSendErrorQueue();

        // Assert
        assertNotNull("HookSendErrorQueue should not be null", hookSendErrorQueue);
        assertTrue("Instance should be of type HookSendErrorQueue", hookSendErrorQueue instanceof HookSendErrorQueue);

        // Verify that getQueuePath() was called once
        verify(sendQueueFactory, times(1)).getQueuePath();
    }

    /**
     * Test createMetadataSendQueue() method.
     */
    @Test
    public void testCreateMetadataSendQueue() throws IOException {
        // Act
        MetadataSendQueue metadataSendQueue = sendQueueFactory.createMetadataSendQueue();

        // Assert
        assertNotNull("MetadataSendQueue should not be null", metadataSendQueue);
        assertTrue("Instance should be of type MetadataSendQueue", metadataSendQueue instanceof MetadataSendQueue);

        // Verify that getQueuePath() was called once
        verify(sendQueueFactory, times(1)).getQueuePath();
    }

    /**
     * Test createMetadataSendErrorQueue() method.
     */
    @Test
    public void testCreateMetadataSendErrorQueue() throws IOException {
        MetadataSendErrorQueue metadataSendErrorQueue = sendQueueFactory.createMetadataSendErrorQueue();

        assertNotNull("MetadataSendErrorQueue should not be null", metadataSendErrorQueue);
        assertTrue("Instance should be of type MetadataSendErrorQueue", metadataSendErrorQueue instanceof MetadataSendErrorQueue);

        // Verify that getQueuePath() was called once
        verify(sendQueueFactory, times(1)).getQueuePath();
    }
    @Test
    public void getQuotePathWhenDirectoryExistsTest() throws IOException {
        SendQueueFactory factory = new SendQueueFactory();
//        File mockDirectory = mock(File.class);
//        when(mockDirectory.exists()).thenReturn(true);

        String result = factory.getQueuePath();

        assertNotNull(result);
    }
}
