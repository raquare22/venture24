package com.optum.fds.paperless.queue;

import static org.junit.Assert.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.exception.ValidationException;
import org.apache.commons.lang.SerializationUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Answers;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class MetadataSendQueueTest {
    private MetadataSendQueue sendQueueMock;

    @Before
    public void setUp() throws IOException {
        // Instantiate MetadataSendQueue with any required dependencies
        sendQueueMock = new MetadataSendQueue("testPath", "testName");
    }

    @Test
    public void testConstructorAndGetRetryList() throws IOException {
        String path = "testPath";
        String name = "testName";
        MetadataSendQueue queue = new MetadataSendQueue(path, name);

        assertNotNull(queue);
        List<ObjectNode> retryList = queue.getRetryList();
        assertNotNull(retryList);
        assertTrue(retryList.isEmpty());
    }

    @Test
    public void testAddToRetryList() throws IOException {
        String path = "testPath";
        String name = "testName";
        MetadataSendQueue queue = new MetadataSendQueue(path, name);

        ObjectNode node = JsonNodeFactory.instance.objectNode();
        node.put("key", "value");
        queue.getRetryList().add(node);

        List<ObjectNode> retryList = queue.getRetryList();
        assertEquals(1, retryList.size());
        assertEquals("value", retryList.get(0).get("key").asText());
    }

    @Test
    public void testAddToErrorQueue() throws IOException, NoSuchFieldException, IllegalAccessException {
        String path = "testPath";
        String name = "testName";
        MetadataSendQueue queue = new MetadataSendQueue(path, name);
        // Set up any necessary data or configuration
        Field field = MetadataSendQueue.class.getDeclaredField("metadataSendQueueAutoError");
        field.setAccessible(true);

        // Set the value of metadataSendQueueAutoError to true
        field.set(queue, true);
        assertTrue(queue.addToErrorQueue("exampleRequest"));

        // Set the value of metadataSendQueueAutoError to false
        field.set(queue, false);
        assertFalse(queue.addToErrorQueue("exampleRequest"));
    }
    @Test
    public void convertAndProcessSuccessTest()  throws IOException {
        String id = "01";
        String pathVariable = "var1";
        String delegate = "var2";
        String delegateParms = "var3";
        String apiUrl = "var4";
        Integer retryCnt = 3;
        String request = "var5";

        ObjectMapper objectMapper = new ObjectMapper();
        ObjectNode readNode = objectMapper.createObjectNode();

        String path = "testPath";
        String name = "testName";
        MetadataSendQueue queue = new MetadataSendQueue(path, name);

        ReflectionTestUtils.setField(queue, "queuedId", "id");
        ReflectionTestUtils.setField(queue, "queuedpathVariable", "pathVariable");
        ReflectionTestUtils.setField(queue, "queuedDelegate", "delegate");
        ReflectionTestUtils.setField(queue, "queuedDelegateParams", "delegateParms");
        ReflectionTestUtils.setField(queue, "queuedApiUrl", "apiUrl");
        ReflectionTestUtils.setField(queue, "queuedRetryCnt", "retryCnt");
        ReflectionTestUtils.setField(queue, "queuedRequest", "request");

        readNode.put("id",id);
        readNode.put("pathVariable",pathVariable);
        readNode.put("delegate",delegate);
        readNode.put("delegateParms",delegateParms);
        readNode.put("apiUrl",apiUrl);
        readNode.put("retryCnt",retryCnt);
        readNode.put("request",request);

        byte[] data = SerializationUtils.serialize(readNode);

       // MetadataSendQueue sendQueue2 = Mockito.mock(MetadataSendQueue.class, Answers.CALLS_REAL_METHODS);
        boolean result = sendQueueMock.convertAndProcess(data);

        assertFalse(result);
//        SendQueue sendQueue2 = Mockito.mock(SendQueue.class, Answers.CALLS_REAL_METHODS);
//        boolean result = sendQueue2.convertAndProcess(data);

    }
}