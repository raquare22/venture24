package com.optum.fds.paperless.processors;

import com.optum.fds.paperless.domain.service.*;
import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorRowTask;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.util.ArrayList;
import java.util.List;

import org.junit.rules.TemporaryFolder;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class CsvProcessorsMonitorTest {

    @Mock
    ProcessorsService processorsService;

    @Mock
    ProcessorService processorService;

    @Mock
    CsvProcessorsService csvProcessorsService;


    @InjectMocks
    CsvProcessorsMonitor csvProcessorsMonitor;

    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder(); // TemporaryFolder uses deleteOnExit

    private static final String WRK_FLOW = "csvCleanupFilesProcess";

    @Before
    public void setUp() throws FSDataException {
        try
        {
            File file = temporaryFolder.newFile("application.properties");
            BufferedWriter output = new BufferedWriter(new FileWriter(file));
            output.write("serverType=xaas");
            output.close();
            System.setProperty("application.properties",file.getAbsolutePath());
        }
        catch (Exception e)
        {
            System.out.println("TemporyFolder: " + e.getClass().getSimpleName() + "; " + e.getMessage());
        }
        List<CsvProcessorTransaction> processorTransactionList = new ArrayList<CsvProcessorTransaction>();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testPollCsvProcessorsCollectionForCleanupWithJobsInQueue() throws IOException, FSDataException {
        List<CsvProcessorTransaction> processorTransactionList = new ArrayList<CsvProcessorTransaction>();
        processorTransactionList.add(getProcessorTransaction("IN_PROCESS"));
        processorTransactionList.add(getProcessorTransaction("FATAL_ERROR"));
        Mockito.when(csvProcessorsService.getAllCsvProcessorsTransactions(Mockito.any(List.class), Mockito.anyInt())).thenReturn(processorTransactionList);
        Mockito.when(processorsService.findProcessorJobByTransactionIdFromQueue(Mockito.anyString())).thenReturn(true);
        csvProcessorsMonitor.pollCsvProcessorsForCleanup();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testPollCsvProcessorsCollectionForCleanupWithAllCsvProcessorRowTasksComplete() throws IOException, FSDataException {
        List<CsvProcessorTransaction> processorTransactionList = new ArrayList<CsvProcessorTransaction>();
        processorTransactionList.add(getProcessorTransaction("IN_PROCESS"));
        processorTransactionList.add(getProcessorTransaction("IN_PROCESS"));
        CsvProcessorTransaction cvs=new CsvProcessorTransaction();
        csvProcessorsMonitor.pollCsvProcessorsCollectionForCleanup();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testPollCsvProcessorsCollectionForCleanupWithCreatingJobEntry() throws IOException, FSDataException {
        List<CsvProcessorTransaction> processorTransactionList = new ArrayList<CsvProcessorTransaction>();
        processorTransactionList.add(getProcessorTransaction("IN_PROCESS"));
        csvProcessorsMonitor.pollCsvProcessorsCollectionForCleanup();

    }

    @SuppressWarnings("unchecked")
    @Test
    public void testPollCsvProcessorsCollectionForCleanupWithCreatingJobEntryWithWorkFlowHardCode() throws IOException, FSDataException {
        List<CsvProcessorTransaction> processorTransactionList = new ArrayList<CsvProcessorTransaction>();
        processorTransactionList.add(getProcessorTransaction("IN_PROCESS"));
        csvProcessorsMonitor.pollCsvProcessorsCollectionForCleanup();

    }

    private CsvProcessorTransaction getProcessorTransaction(String status) {
        CsvProcessorTransaction csvProcessorTransaction = new CsvProcessorTransaction();
        csvProcessorTransaction.setAppIdentifier("testApp");
        csvProcessorTransaction.setTransactionId("1234");
        csvProcessorTransaction.setProcessorId("5ab168aee4b0bd6117785d07");
        csvProcessorTransaction.setStartTime();
        csvProcessorTransaction.setId("123");
        csvProcessorTransaction.setFileName("csvProcessorTest20180320030150_ba13d1a2-a319-4bc6-8d6e-56c66f6d79e4.csv");
        csvProcessorTransaction.setStatus(status);
        return csvProcessorTransaction;
    }

    @Test
    public void testPollCsvProcessorsCollectionForCleanup_enabled_callsPoll() {
        csvProcessorsMonitor.pollSchedulersEnabled = "true";
        Mockito.when(csvProcessorsService.getAllCsvProcessorsTransactions(Mockito.any(List.class), Mockito.anyInt()))
                .thenReturn(new ArrayList<CsvProcessorTransaction>());

        csvProcessorsMonitor.pollCsvProcessorsCollectionForCleanup();

        Mockito.verify(csvProcessorsService, Mockito.times(1))
                .getAllCsvProcessorsTransactions(Mockito.any(List.class), Mockito.anyInt());
    }

    @Test
    public void testPollCsvProcessorsCollectionForCleanup_disabled_skipsPoll() {
        csvProcessorsMonitor.pollSchedulersEnabled = "false";

        csvProcessorsMonitor.pollCsvProcessorsCollectionForCleanup();

        Mockito.verify(csvProcessorsService, Mockito.never())
                .getAllCsvProcessorsTransactions(Mockito.any(List.class), Mockito.anyInt());
    }

    @Test
    public void testPollCsvProcessorsForCleanup_jobExists_doesNotCreateCleanupJob() {
        List<CsvProcessorTransaction> transactions = new ArrayList<CsvProcessorTransaction>();
        CsvProcessorTransaction transaction = getProcessorTransaction("IN_PROCESS");
        transactions.add(transaction);

        Mockito.when(csvProcessorsService.getAllCsvProcessorsTransactions(Mockito.any(List.class), Mockito.anyInt()))
                .thenReturn(transactions);
        Mockito.when(processorsService.findProcessorJobByTransactionIdFromQueue(transaction.getId()))
                .thenReturn(true);

        csvProcessorsMonitor.pollCsvProcessorsForCleanup();

        Mockito.verify(csvProcessorsService, Mockito.never())
                .isAllCsvProcessorRowTasksProcessed(any(CsvProcessorTransaction.class));
        Mockito.verify(csvProcessorsService, Mockito.never())
                .createCsvProcessorJobEntry(any(ProcessorMetaData.class), any(CsvProcessorTransaction.class), any(String.class), any(String.class));
    }

    @Test
    public void testPollCsvProcessorsForCleanup_allCompleteAndInProcess_createsCleanupJob() {
        List<CsvProcessorTransaction> transactions = new ArrayList<CsvProcessorTransaction>();
        CsvProcessorTransaction transaction = getProcessorTransaction("IN_PROCESS");
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        transactions.add(transaction);

        Mockito.when(csvProcessorsService.getAllCsvProcessorsTransactions(Mockito.any(List.class), Mockito.anyInt()))
                .thenReturn(transactions);
        Mockito.when(processorsService.findProcessorJobByTransactionIdFromQueue(transaction.getId()))
                .thenReturn(false);
        Mockito.when(csvProcessorsService.isAllCsvProcessorRowTasksProcessed(transaction))
                .thenReturn(true);
        Mockito.when(processorsService.findProcessorMetaDataById(transaction.getProcessorId(), transaction.getAppIdentifier()))
                .thenReturn(processorMetaData);

        csvProcessorsMonitor.pollCsvProcessorsForCleanup();

        Mockito.verify(csvProcessorsService, Mockito.times(1)).updateCsvProcessorTransactionMetaData(transaction);
        Mockito.verify(csvProcessorsService, Mockito.times(1))
                .createCsvProcessorJobEntry(processorMetaData, transaction, "cleanUpProcessor", WRK_FLOW);
    }

    @Test
    public void testPollCsvProcessorsForCleanup_allCompleteButNotInProcess_noCleanupJobCreated() {
        List<CsvProcessorTransaction> transactions = new ArrayList<CsvProcessorTransaction>();
        CsvProcessorTransaction transaction = getProcessorTransaction("FATAL_ERROR");
        transactions.add(transaction);

        Mockito.when(csvProcessorsService.getAllCsvProcessorsTransactions(Mockito.any(List.class), Mockito.anyInt()))
                .thenReturn(transactions);
        Mockito.when(processorsService.findProcessorJobByTransactionIdFromQueue(transaction.getId()))
                .thenReturn(false);
        Mockito.when(csvProcessorsService.isAllCsvProcessorRowTasksProcessed(transaction))
                .thenReturn(true);

        csvProcessorsMonitor.pollCsvProcessorsForCleanup();

        Mockito.verify(csvProcessorsService, Mockito.never()).updateCsvProcessorTransactionMetaData(any(CsvProcessorTransaction.class));
        Mockito.verify(csvProcessorsService, Mockito.never())
                .createCsvProcessorJobEntry(any(ProcessorMetaData.class), any(CsvProcessorTransaction.class), any(String.class), any(String.class));
    }

    @Test
    public void testPollCsvProcessorsForCleanup_notAllComplete_noCleanupJobCreated() {
        List<CsvProcessorTransaction> transactions = new ArrayList<CsvProcessorTransaction>();
        CsvProcessorTransaction transaction = getProcessorTransaction("IN_PROCESS");
        transactions.add(transaction);

        Mockito.when(csvProcessorsService.getAllCsvProcessorsTransactions(Mockito.any(List.class), Mockito.anyInt()))
                .thenReturn(transactions);
        Mockito.when(processorsService.findProcessorJobByTransactionIdFromQueue(transaction.getId()))
                .thenReturn(false);
        Mockito.when(csvProcessorsService.isAllCsvProcessorRowTasksProcessed(transaction))
                .thenReturn(false);

        csvProcessorsMonitor.pollCsvProcessorsForCleanup();

        Mockito.verify(csvProcessorsService, Mockito.never()).updateCsvProcessorTransactionMetaData(any(CsvProcessorTransaction.class));
        Mockito.verify(csvProcessorsService, Mockito.never())
                .createCsvProcessorJobEntry(any(ProcessorMetaData.class), any(CsvProcessorTransaction.class), any(String.class), any(String.class));
    }

    @Test
    public void testPollCsvProcessorsForCleanup_exceptionInOneTransaction_continuesWithNext() {
        List<CsvProcessorTransaction> transactions = new ArrayList<CsvProcessorTransaction>();

        CsvProcessorTransaction first = getProcessorTransaction("IN_PROCESS");
        first.setId("first-id");
        CsvProcessorTransaction second = getProcessorTransaction("IN_PROCESS");
        second.setId("second-id");
        ProcessorMetaData processorMetaData = new ProcessorMetaData();

        transactions.add(first);
        transactions.add(second);

        Mockito.when(csvProcessorsService.getAllCsvProcessorsTransactions(Mockito.any(List.class), Mockito.anyInt()))
                .thenReturn(transactions);

        // 1st tx throws -> catch block, 2nd tx continues
        Mockito.when(processorsService.findProcessorJobByTransactionIdFromQueue(Mockito.anyString()))
                .thenThrow(new RuntimeException("boom"))
                .thenReturn(false);

        Mockito.when(csvProcessorsService.isAllCsvProcessorRowTasksProcessed(any(CsvProcessorTransaction.class)))
                .thenReturn(true);
        Mockito.when(processorsService.findProcessorMetaDataById(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(processorMetaData);

        csvProcessorsMonitor.pollCsvProcessorsForCleanup();

        Mockito.verify(csvProcessorsService, Mockito.times(1))
                .createCsvProcessorJobEntry(any(ProcessorMetaData.class), any(CsvProcessorTransaction.class), any(String.class), any(String.class));
    }

    @Test
    public void testCreateCsvCleanupJobIfRequired_allCompleteAndInProcess_createsCleanupJob() {
        CsvProcessorTransaction transaction = getProcessorTransaction("IN_PROCESS");
        ProcessorMetaData processorMetaData = new ProcessorMetaData();

        Mockito.when(csvProcessorsService.isAllCsvProcessorRowTasksProcessed(transaction)).thenReturn(true);
        Mockito.when(processorsService.findProcessorMetaDataById(transaction.getProcessorId(), transaction.getAppIdentifier()))
                .thenReturn(processorMetaData);

        csvProcessorsMonitor.createCsvCleanupJobIfRequired(transaction);

        Mockito.verify(csvProcessorsService, Mockito.times(1)).updateCsvProcessorTransactionMetaData(transaction);
        Mockito.verify(csvProcessorsService, Mockito.times(1))
                .createCsvProcessorJobEntry(processorMetaData, transaction, "cleanUpProcessor", WRK_FLOW);
    }

    @Test
    public void testCreateCsvCleanupJobIfRequired_notAllComplete_doesNotCreateCleanupJob() {
        CsvProcessorTransaction transaction = getProcessorTransaction("IN_PROCESS");
        Mockito.when(csvProcessorsService.isAllCsvProcessorRowTasksProcessed(transaction)).thenReturn(false);

        csvProcessorsMonitor.createCsvCleanupJobIfRequired(transaction);

        Mockito.verify(csvProcessorsService, Mockito.never()).updateCsvProcessorTransactionMetaData(any(CsvProcessorTransaction.class));
        Mockito.verify(csvProcessorsService, Mockito.never())
                .createCsvProcessorJobEntry(any(ProcessorMetaData.class), any(CsvProcessorTransaction.class), any(String.class), any(String.class));
    }

    @Test
    public void testCreateCsvCleanupJobIfRequired_allCompleteButNotInProcess_doesNotCreateCleanupJob() {
        CsvProcessorTransaction transaction = getProcessorTransaction("FATAL_ERROR");
        Mockito.when(csvProcessorsService.isAllCsvProcessorRowTasksProcessed(transaction)).thenReturn(true);

        csvProcessorsMonitor.createCsvCleanupJobIfRequired(transaction);

        Mockito.verify(csvProcessorsService, Mockito.never()).updateCsvProcessorTransactionMetaData(any(CsvProcessorTransaction.class));
        Mockito.verify(csvProcessorsService, Mockito.never())
                .createCsvProcessorJobEntry(any(ProcessorMetaData.class), any(CsvProcessorTransaction.class), any(String.class), any(String.class));
    }
}
