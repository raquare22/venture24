package com.optum.fds.paperless.workflow.beans;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class ProviderDocumentTest {

    private ProviderDocument providerDocument;

    @Before
    public void setUp() {
        providerDocument = new ProviderDocument();
    }

    @Test
    public void testGetAndSetDocumentId() {
        String documentId = "doc123";
        providerDocument.setDocumentId(documentId);
        assertEquals(documentId, providerDocument.getDocumentId());
    }

    @Test
    public void testGetAndSetId() {
        String id = "id123";
        providerDocument.setId(id);
        assertEquals(id, providerDocument.getId());
    }

    @Test
    public void testGetAndSetSpaceId() {
        String spaceId = "space123";
        providerDocument.setSpaceId(spaceId);
        assertEquals(spaceId, providerDocument.getSpaceId());
    }

    @Test
    public void testGetAndSetStatus() {
        String status = "active";
        providerDocument.setStatus(status);
        assertEquals(status, providerDocument.getStatus());
    }

    @Test
    public void testGetAndSetDateCreated() {
        String dateCreated = "2023-10-01";
        providerDocument.setDateCreated(dateCreated);
        assertEquals(dateCreated, providerDocument.getDateCreated());
    }

    @Test
    public void testGetAndSetMetadata() {
        ProviderDocumentMetaData metadata = new ProviderDocumentMetaData();
        providerDocument.setMetadata(metadata);
        assertEquals(metadata, providerDocument.getMetadata());
    }

    @Test
    public void testSetMetadataFromJson() throws JsonMappingException, JsonProcessingException {
        String metadataJsonStr = "{\"key\":\"value\"}";
        providerDocument.setMetadata(metadataJsonStr);
        assertNotNull(providerDocument.getMetadata());
        // Adjust the assertion based on the actual structure of ProviderDocumentMetaData
    }

    @Test
    public void testSetMetadataFromInvalidJson() {
        String invalidJsonStr = "invalid json";
        assertThrows(JsonProcessingException.class, () -> {
            providerDocument.setMetadata(invalidJsonStr);
        });
    }

    @Test
    public void testToString() {
        String documentId = "doc123";
        ProviderDocumentMetaData metadata = new ProviderDocumentMetaData();
        // Adjust the metadata setup based on the actual structure of ProviderDocumentMetaData
        providerDocument.setDocumentId(documentId);
        providerDocument.setMetadata(metadata);
        String expected = "ProviderDocument [ documentId: doc123, metadata: " + metadata + " ] ";
        assertEquals(expected, providerDocument.toString());
    }
}