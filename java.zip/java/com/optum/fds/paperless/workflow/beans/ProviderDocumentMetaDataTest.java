package com.optum.fds.paperless.workflow.beans;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class ProviderDocumentMetaDataTest {

    private ProviderDocumentMetaData metadata;

    @Before
    public void setUp() {
        metadata = new ProviderDocumentMetaData();
    }

    @Test
    public void testGetAndSetProviderEmailId() {
        String providerEmailId = "provider@example.com";
        metadata.setProviderEmailId(providerEmailId);
        assertEquals(providerEmailId, metadata.getProviderEmailId());
    }

    @Test
    public void testGetAndSetWeekday() {
        String weekday = "Monday";
        metadata.setWeekday(weekday);
        assertEquals(weekday, metadata.getWeekday());
    }

    @Test
    public void testGetAndSetFrequency() {
        String frequency = "Weekly";
        metadata.setFrequency(frequency);
        assertEquals(frequency, metadata.getFrequency());
    }

    @Test
    public void testGetAndSetDeliveryMethod() {
        String deliveryMethod = "Email";
        metadata.setDeliveryMethod(deliveryMethod);
        assertEquals(deliveryMethod, metadata.getDeliveryMethod());
    }

    @Test
    public void testGetAndSetMpin() {
        String mpin = "1234";
        metadata.setMpin(mpin);
        assertEquals(mpin, metadata.getMpin());
    }

    @Test
    public void testGetAndSetTin() {
        String tin = "TIN123";
        metadata.setTin(tin);
        assertEquals(tin, metadata.getTin());
    }

    @Test
    public void testGetAndSetActiveDate() {
        String activeDate = "2023-10-01";
        metadata.setActiveDate(activeDate);
        assertEquals(activeDate, metadata.getActiveDate());
    }

    @Test
    public void testGetAndSetSubscribeToEmail() {
        String subscribeToEmail = "true";
        metadata.setSubsribeToEmail(subscribeToEmail);
        assertEquals(subscribeToEmail, metadata.getSubscribeToEmail());
    }

    @Test
    public void testToString() {
        String mpin = "1234";
        String tin = "TIN123";
        String providerEmailId = "provider@example.com";
        String subscribeToEmail = "true";
        metadata.setMpin(mpin);
        metadata.setTin(tin);
        metadata.setProviderEmailId(providerEmailId);
        metadata.setSubsribeToEmail(subscribeToEmail);
        String expected = "[ mpin : 1234, tin : TIN123, providerEmailId: provider@example.com, subscribeToEmail: true ]";
        assertEquals(expected, metadata.toString());
    }
}