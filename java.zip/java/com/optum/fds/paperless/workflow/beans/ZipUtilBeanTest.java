package com.optum.fds.paperless.workflow.beans;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class ZipUtilBeanTest {

    private ZipUtilBean zipUtilBean;

    @Before
    public void setUp() {
        zipUtilBean = new ZipUtilBean("file1.txt", "entry1.txt", "/path/to/origin");
    }

    @Test
    public void testGetAndSetFileName() {
        String fileName = "file2.txt";
        zipUtilBean.setFileName(fileName);
        assertEquals(fileName, zipUtilBean.getFileName());
    }

    @Test
    public void testGetAndSetZipEntryFileName() {
        String zipEntryFileName = "entry2.txt";
        zipUtilBean.setZipEntryFileName(zipEntryFileName);
        assertEquals(zipEntryFileName, zipUtilBean.getZipEntryFileName());
    }

    @Test
    public void testGetAndSetPathOrigin() {
        String pathOrigin = "/new/path/to/origin";
        zipUtilBean.setPathOrigin(pathOrigin);
        assertEquals(pathOrigin, zipUtilBean.getPathOrigin());
    }

    @Test
    public void testToString() {
        String expected = "ZipUtilBean [fileName=file1.txt, zipEntryFileName=entry1.txt, pathOrigin=/path/to/origin]";
        assertEquals(expected, zipUtilBean.toString());
    }

    @Test
    public void testFrom() {
        ZipUtilBean newZipUtilBean = ZipUtilBean.from("file3.txt", "entry3.txt", "/another/path");
        assertEquals("file3.txt", newZipUtilBean.getFileName());
        assertEquals("entry3.txt", newZipUtilBean.getZipEntryFileName());
        assertEquals("/another/path", newZipUtilBean.getPathOrigin());
    }
}