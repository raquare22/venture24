package com.optum.fds.paperless.workflow.beans;

import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class FDSCloudGetDocumentsResponseTest {

    private FDSCloudGetDocumentsResponse response;

    @Before
    public void setUp() {
        response = new FDSCloudGetDocumentsResponse();
    }

    @Test
    public void testGetAndSetCount() {
        String count = "10";
        response.setCount(count);
        assertEquals(count, response.getCount());
    }

    @Test
    public void testGetAndSetStart() {
        String start = "1";
        response.setStart(start);
        assertEquals(start, response.getStart());
    }

    @Test
    public void testGetAndSetDocuments() {
        List<ProviderDocument> documents = new ArrayList<>();
        documents.add(new ProviderDocument());
        response.setDocuments(documents);
        assertEquals(documents, response.getDocuments());
    }

    @Test
    public void testGetDocuments_Empty() {
        List<ProviderDocument> documents = response.getDocuments();
        assertTrue(documents.isEmpty());
    }

    @Test
    public void testGetAndSetTotalRecords() {
        String totalRecords = "100";
        response.setTotalRecords(totalRecords);
        assertEquals(totalRecords, response.getTotalRecords());
    }

    @Test
    public void testToString() {
        String totalRecords = "100";
        List<ProviderDocument> documents = new ArrayList<>();
        documents.add(new ProviderDocument());
        response.setTotalRecords(totalRecords);
        response.setDocuments(documents);
        String expected = "FDSCloudGetDocumentResponse [ totalRecords: 100, documents: " + documents + " ]";
        assertEquals(expected, response.toString());
    }
}