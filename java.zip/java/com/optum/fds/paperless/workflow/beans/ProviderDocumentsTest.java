package com.optum.fds.paperless.workflow.beans;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class ProviderDocumentsTest {

    private ProviderDocuments providerDocuments;

    @Before
    public void setUp() {
        providerDocuments = new ProviderDocuments();
    }

    @Test
    public void testGetDocuments_Empty() {
        List<ProviderDocument> documents = providerDocuments.getDocuments();
        assertTrue(documents.isEmpty());
    }

    @Test
    public void testSetAndGetDocuments() {
        List<ProviderDocument> documents = new ArrayList<>();
        documents.add(new ProviderDocument());
        providerDocuments.setDocuments(documents);
        assertEquals(documents, providerDocuments.getDocuments());
    }

    @Test
    public void testSetAndGetTotalRecords() {
        String totalRecords = "100";
        providerDocuments.setTotalRecords(totalRecords);
        assertEquals(totalRecords, providerDocuments.getTotalRecords());
    }

    @Test
    public void testSetAndGetStartRecord() {
        String startRecord = "1";
        providerDocuments.setStartRecord(startRecord);
        assertEquals(startRecord, providerDocuments.getStartRecord());
    }

    @Test
    public void testSetAndGetCount() {
        int count = 10;
        providerDocuments.setCount(count);
        assertEquals(count, providerDocuments.getCount());
    }
}