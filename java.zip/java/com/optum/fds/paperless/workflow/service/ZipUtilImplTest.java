package com.optum.fds.paperless.workflow.service;

import com.optum.fds.paperless.workflow.beans.ZipUtilBean;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;
import java.util.zip.ZipFile;

import static org.junit.Assert.*;

public class ZipUtilImplTest {

    @Rule
    public TemporaryFolder tempFolder = new TemporaryFolder();

    private final ZipUtilImpl zipUtil = new ZipUtilImpl();

    @Test
    public void zipFiles_returnsTrue_andCreatesZip_withAllEntries() throws Exception {
        var inputDir = tempFolder.newFolder("input");
        var outputDir = tempFolder.newFolder("output");

        var file1 = new java.io.File(inputDir, "a.txt");
        var file2 = new java.io.File(inputDir, "b.txt");
        Files.write(file1.toPath(), "alpha".getBytes(StandardCharsets.UTF_8));
        Files.write(file2.toPath(), "beta".getBytes(StandardCharsets.UTF_8));

        List<ZipUtilBean> filesToZip = List.of(
                ZipUtilBean.from("a.txt", "entryA.txt", inputDir.getAbsolutePath() + java.io.File.separator),
                ZipUtilBean.from("b.txt", "entryB.txt", inputDir.getAbsolutePath() + java.io.File.separator)
        );

        String outputPath = outputDir.getAbsolutePath() + java.io.File.separator;
        String zipFileName = "result.zip";

        // act
        boolean result = zipUtil.zipFiles(filesToZip, outputPath, zipFileName);

        // assert
        assertTrue(result);

        var zipPath = new java.io.File(outputDir, zipFileName).toPath();
        assertTrue(Files.exists(zipPath));

        try (ZipFile zf = new ZipFile(zipPath.toFile())) {
            assertNotNull(zf.getEntry("entryA.txt"));
            assertNotNull(zf.getEntry("entryB.txt"));
            assertEquals(2, zf.size());
        }
    }

    @Test(expected = IOException.class)
    public void zipFiles_throwsIOException_whenInputFileDoesNotExist() throws Exception {
        // arrange
        var inputDir = tempFolder.newFolder("inputMissing");
        var outputDir = tempFolder.newFolder("outputMissing");

        List<ZipUtilBean> filesToZip = List.of(
                ZipUtilBean.from("missing.txt", "entryMissing.txt", inputDir.getAbsolutePath() + java.io.File.separator)
        );

        String outputPath = outputDir.getAbsolutePath() + java.io.File.separator;
        String zipFileName = "missing.zip";

        // act
        zipUtil.zipFiles(filesToZip, outputPath, zipFileName);

    }
}