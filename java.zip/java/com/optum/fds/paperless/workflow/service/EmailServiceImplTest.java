package com.optum.fds.paperless.workflow.service;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import com.optum.fds.paperless.email.EmailSender;
import org.assertj.core.util.Arrays;
import org.flowable.engine.delegate.DelegateExecution;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.mockito.stubbing.Stubber;
import org.springframework.mail.javamail.JavaMailSender;

import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fs.workflow.java.delegate.bean.DelegateExecutionImpl;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.test.util.ReflectionTestUtils;

public class EmailServiceImplTest {

	@Mock
	JavaMailSender javaMailSender;

	@InjectMocks
	EmailServiceImpl emailServiceImpl;
	
	@Mock
	DelegateExecutionImpl delegateExecution;
	
	
	private Map<String, Object> delegateMap;
	Map<String, Object> errorMap = new HashMap<>() ;
	
	@Before
	public void setUp() throws URISyntaxException, IOException, FSDataException {

		MockitoAnnotations.initMocks(this);
		delegateMap = new HashMap<String, Object>();
		Stubber getDelegateMap = doAnswer(new Answer<Object>() {
			public Object answer(InvocationOnMock invocation) {
				Object[] args = invocation.getArguments();
				return delegateMap.get(args[0]);
			}
		});
		getDelegateMap.when(delegateExecution).getVariable(Mockito.anyString());

		Stubber setDelegateMap = doAnswer(new Answer<Void>() {
			public Void answer(InvocationOnMock invocation) {
				Object[] args = invocation.getArguments();
				delegateMap.put((String) args[0], args[1]);
				return null;
			}
		});
		setDelegateMap.when(delegateExecution).setVariable(Mockito.anyString(), any());

		Stubber getVariablesMap = doAnswer(new Answer<Map<String, Object>>() {
			public Map<String, Object> answer(InvocationOnMock invocation) {
				return delegateMap;
			}
		});
		getVariablesMap.when(delegateExecution).getVariables();
		when(delegateExecution.getCurrentActivityId()).thenReturn("emailServiceImpl");

		delegateMap.put(Workflow.EMAIL_RECEIVER, "");
		delegateMap.put(Workflow.ENVIRONMENT, "");
	}

	@Test
	public void testSendEmailWithNoErrorsExist() throws IOException {
		boolean success = false;
		try {
			success = emailServiceImpl.sendEmail(delegateExecution, errorMap, DelegateUtils.addDocumentIdInErrors(delegateExecution)) ;
			assertFalse(success);
		} catch (Exception ex) {
			System.out.println("Error:" + ex.getMessage());
			assertFalse(success);
		}
	}
	
	@Test
	public void testSendEmailWithErrorsExist() throws IOException {
		boolean success = false;
        when(delegateExecution.getVariable(Workflow.EMAIL_RECEIVER, String.class)).thenReturn("");
        try {
			errorMap.put("errorKey", "errorExists");
			success = emailServiceImpl.sendEmail(delegateExecution, errorMap, DelegateUtils.addDocumentIdInErrors(delegateExecution)) ;
			assertTrue(success);
		} catch (Exception ex) {
			System.out.println("Error:" + ex.getMessage());
			assertFalse(success);
		}
	}
	
	@Test
	@UserStory(references = "US26748")
	@RallyTestCase(references = "TC30635")
	public void testSendEmailWithMessageOnly() throws IOException {
		boolean success = false;
        when(delegateExecution.getVariable(Workflow.EMAIL_RECEIVER, String.class)).thenReturn("");
		try {
			success = emailServiceImpl.sendEmail(delegateExecution, "test") ;
			assertTrue(success);
		} catch (Exception ex) {
			System.out.println("Error:" + ex.getMessage());
			assertFalse(success);
		}
	}
	
	@Test
	public void testParseEmailReceiver() throws Exception {
		 // {SystemOperatingControls_DL@uhc.com; CosmosBatch_DL@ds.uhc.com; hsupport@optum.com; william.nierenhausen@optum.com}
		String[] expectedResult = {"SystemOperatingControls_DL@uhc.com", "CosmosBatch_DL@ds.uhc.com", "hsupport@optum.com", "william.nierenhausen@optum.com"};
		String[] result = emailServiceImpl.parseEmailReceiver("{SystemOperatingControls_DL@uhc.com; CosmosBatch_DL@ds.uhc.com; hsupport@optum.com; william.nierenhausen@optum.com}");
		
		System.out.println(Arrays.asList(result));
		assertEquals(expectedResult, result);
		
	}

    @Test
    public void testSendEmail_WhenJavaMailSenderImplAndMultipleReceivers_ShouldSetHostAndSendToArray() throws Exception {
        JavaMailSenderImpl javaMailSenderImpl = new JavaMailSenderImpl();
        EmailServiceImpl service = new EmailServiceImpl(javaMailSenderImpl);
        ReflectionTestUtils.setField(service, "elrSMTPRelayOSEHost", "smtp.test.local");

        DelegateExecution execution = mock(DelegateExecution.class);
        when(execution.getVariable(Workflow.EMAIL_RECEIVER, String.class))
                .thenReturn("{first@test.com; second@test.com}");
        when(execution.getVariable(Workflow.ENVIRONMENT, String.class))
                .thenReturn("DEV");
        when(execution.getEventName()).thenReturn("testEvent");

        Map<String, Object> errorMap = new HashMap<>();
        errorMap.put("errorKey", "errorValue");

        try (MockedStatic<EmailSender> emailSenderMock = mockStatic(EmailSender.class)) {
            boolean result = service.sendEmail(execution, errorMap, "test-message");

            assertTrue(result);
            assertEquals("smtp.test.local", javaMailSenderImpl.getHost());

            emailSenderMock.verify(() -> EmailSender.sendMail(
                    eq("noreply@optum.com"),
                    eq(new String[]{"first@test.com", "second@test.com"}),
                    any(String.class),
                    eq("test-message\nerrorKey: errorValue"),
                    eq(javaMailSenderImpl)
            ));
        }
    }

    @Test
    public void testSendEmail_WhenNonJavaMailSenderAndSingleReceiver_ShouldSendToSingleEmail() throws Exception {
        JavaMailSender mailSender = mock(JavaMailSender.class);
        EmailServiceImpl service = new EmailServiceImpl(mailSender);

        DelegateExecution execution = mock(DelegateExecution.class);
        when(execution.getVariable(Workflow.EMAIL_RECEIVER, String.class))
                .thenReturn("single@test.com");
        when(execution.getVariable(Workflow.ENVIRONMENT, String.class))
                .thenReturn("QA");
        when(execution.getEventName()).thenReturn("singleReceiverEvent");

        Map<String, Object> errorMap = new HashMap<>();
        errorMap.put("errorKey", "errorValue");

        try (MockedStatic<EmailSender> emailSenderMock = mockStatic(EmailSender.class)) {
            boolean result = service.sendEmail(execution, errorMap, "plain-message");

            assertTrue(result);

            emailSenderMock.verify(() -> EmailSender.sendMail(
                    eq("noreply@optum.com"),
                    eq("single@test.com"),
                    any(String.class),
                    eq("plain-message\nerrorKey: errorValue"),
                    eq(mailSender)
            ));
        }
    }

    @Test
    public void testSendEmail_WhenExecutionIsNull_ShouldReturnFalseFromCatchBlock() {
        JavaMailSender mailSender = mock(JavaMailSender.class);
        EmailServiceImpl service = new EmailServiceImpl(mailSender);

        Map<String, Object> errorMap = new HashMap<>();
        errorMap.put("errorKey", "errorValue");

        boolean result = service.sendEmail(null, errorMap, "test-message");

        assertFalse(result);
    }

    @Test
    public void testSendEmail_MessageOnly_WhenJavaMailSenderImplAndMultipleReceivers_ShouldSetHostAndSendArray() throws Exception {
        JavaMailSenderImpl javaMailSenderImpl = new JavaMailSenderImpl();
        EmailServiceImpl service = new EmailServiceImpl(javaMailSenderImpl);
        ReflectionTestUtils.setField(service, "elrSMTPRelayOSEHost", "smtp.test.local");

        DelegateExecution execution = mock(DelegateExecution.class);
        when(execution.getVariable(Workflow.EMAIL_SENDER, String.class)).thenReturn("sender@test.com");
        when(execution.getVariable(Workflow.EMAIL_RECEIVER, String.class))
                .thenReturn("{first@test.com; second@test.com}");
        when(execution.getVariable(Workflow.EMAIL_SUBJECT, String.class)).thenReturn("subject-line");

        try (MockedStatic<EmailSender> emailSenderMock = mockStatic(EmailSender.class)) {
            boolean result = service.sendEmail(execution, "message-body");

            assertTrue(result);
            assertEquals("smtp.test.local", javaMailSenderImpl.getHost());

            emailSenderMock.verify(() -> EmailSender.sendMail(
                    eq("sender@test.com"),
                    eq(new String[]{"first@test.com", "second@test.com"}),
                    eq("subject-line"),
                    eq("message-body\n"),
                    eq(javaMailSenderImpl)
            ));
        }
    }

    @Test
    public void testSendEmail_MessageOnly_WhenNonJavaMailSenderAndSingleReceiver_ShouldSendSingleEmail() throws Exception {
        JavaMailSender mailSender = mock(JavaMailSender.class);
        EmailServiceImpl service = new EmailServiceImpl(mailSender);

        DelegateExecution execution = mock(DelegateExecution.class);
        when(execution.getVariable(Workflow.EMAIL_SENDER, String.class)).thenReturn("sender@test.com");
        when(execution.getVariable(Workflow.EMAIL_RECEIVER, String.class)).thenReturn("single@test.com");
        when(execution.getVariable(Workflow.EMAIL_SUBJECT, String.class)).thenReturn("single-subject");

        try (MockedStatic<EmailSender> emailSenderMock = mockStatic(EmailSender.class)) {
            boolean result = service.sendEmail(execution, "plain-message");

            assertTrue(result);

            emailSenderMock.verify(() -> EmailSender.sendMail(
                    eq("sender@test.com"),
                    eq("single@test.com"),
                    eq("single-subject"),
                    eq("plain-message\n"),
                    eq(mailSender)
            ));
        }
    }

    @Test
    public void testSendEmail_WhenEmailSenderThrows_ShouldReturnFalseAndUseExecutionIdInCatch() throws Exception {
        JavaMailSender mailSender = mock(JavaMailSender.class);
        EmailServiceImpl service = new EmailServiceImpl(mailSender);

        DelegateExecution execution = mock(DelegateExecution.class);
        when(execution.getVariable(Workflow.EMAIL_RECEIVER, String.class)).thenReturn("single@test.com");
        when(execution.getVariable(Workflow.ENVIRONMENT, String.class)).thenReturn("DEV");
        when(execution.getEventName()).thenReturn("testEvent");
        when(execution.getId()).thenReturn("execution-123");

        Map<String, Object> errorMap = new HashMap<>();
        errorMap.put("errorKey", "errorValue");

        try (MockedStatic<EmailSender> emailSenderMock = mockStatic(EmailSender.class)) {
            emailSenderMock.when(() -> EmailSender.sendMail(
                    anyString(),
                    anyString(),
                    anyString(),
                    anyString(),
                    eq(mailSender)
            )).thenThrow(new RuntimeException("mail send failed"));

            boolean result = service.sendEmail(execution, errorMap, "test-message");

            assertFalse(result);
            verify(execution).getId();
        }
    }

    @Test
    public void testSendEmail_MessageOnly_WhenEmailSenderThrows_ShouldReturnFalseAndUseExecutionIdInCatch() throws Exception {
        JavaMailSender mailSender = mock(JavaMailSender.class);
        EmailServiceImpl service = new EmailServiceImpl(mailSender);

        DelegateExecution execution = mock(DelegateExecution.class);
        when(execution.getVariable(Workflow.EMAIL_SENDER, String.class)).thenReturn("sender@test.com");
        when(execution.getVariable(Workflow.EMAIL_RECEIVER, String.class)).thenReturn("single@test.com");
        when(execution.getVariable(Workflow.EMAIL_SUBJECT, String.class)).thenReturn("subject-line");
        when(execution.getId()).thenReturn("execution-456");

        try (MockedStatic<EmailSender> emailSenderMock = mockStatic(EmailSender.class)) {
            emailSenderMock.when(() -> EmailSender.sendMail(
                    eq("sender@test.com"),
                    eq("single@test.com"),
                    eq("subject-line"),
                    eq("message-body\n"),
                    eq(mailSender)
            )).thenThrow(new RuntimeException("mail send failed"));

            boolean result = service.sendEmail(execution, "message-body");

            assertFalse(result);
            verify(execution).getId();
        }
    }

    @Test
    public void testSendEmail_MessageOnly_WhenExecutionIsNull_ShouldReturnFalseFromCatchBlock() {
        JavaMailSender mailSender = mock(JavaMailSender.class);
        EmailServiceImpl service = new EmailServiceImpl(mailSender);

        boolean result = service.sendEmail(null, "message-body");

        assertFalse(result);
    }
	


}
