package com.optum.fds.paperless.workflow.util;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.Map;

import com.optum.fds.paperless.workflow.constants.Workflow;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.mongo.executions.HookExecutionRecordMetaData;

@SpringBootTest(webEnvironment = WebEnvironment.MOCK)
@RunWith(MockitoJUnitRunner.class)
@AutoConfigureMockMvc
public class HookTransactionUtilTest {

	@Mock
	HookTransactionUtil hookTransactionUtil;

	@SuppressWarnings("static-access")
	@Test
	public void createHookTransactionTest() throws Exception {

		DocumentMetaData documentMetaDataObject = new DocumentMetaData();
		documentMetaDataObject.setSpaceId(23695);
		documentMetaDataObject.setClientId(69356);
		documentMetaDataObject.setAppIdentifier("appIdentifier");
		HookTransactionMetaData createHookTransactionResult = hookTransactionUtil
				.createHookTransaction(documentMetaDataObject, Map.of("test", "one"), "testprocess");
		assertNotNull(createHookTransactionResult);
	}

	@SuppressWarnings("static-access")
	@Test
	public void createCronHookTransactionTest() throws Exception {

		HookExecutionRecordMetaData hookExecutionRecordMetaData = new HookExecutionRecordMetaData();
		hookExecutionRecordMetaData.setSpaceId(2323);
		hookExecutionRecordMetaData.setClientId(3445);
		hookExecutionRecordMetaData.setHookId("hookID");
		HookTransactionMetaData createHookTransactionResult = hookTransactionUtil
				.createCronHookTransaction(hookExecutionRecordMetaData);
		assertNotNull(createHookTransactionResult);
	}

	@SuppressWarnings("static-access")
	@Test
	public void getHookExecutionRecordTestOne() throws Exception {
		HookExecutionRecordMetaData hookExecutionRecordMetaData = new HookExecutionRecordMetaData();
		hookExecutionRecordMetaData.getSpaceId();
		hookExecutionRecordMetaData.setSpaceId(23233);
		hookExecutionRecordMetaData.setClientId(3445);
		hookExecutionRecordMetaData.setHookId("hookID");
		HookExecutionRecordMetaData hookExecutionRecordResult = hookTransactionUtil
				.getHookExecutionRecord(Map.of("clientId", "1", "spaceId", "2"), Map.of("spaceId", "1"), "testprocess");
		assertNotNull(hookExecutionRecordResult);
	}

	@SuppressWarnings("static-access")
	@Test
	public void createHookTransactionWithHookIdTest() throws Exception {
		DocumentMetaData documentMetaDataObject = new DocumentMetaData();
		documentMetaDataObject.setSpaceId(23695);
		documentMetaDataObject.setClientId(69356);
		documentMetaDataObject.setAppIdentifier("appIdentifier");
		HookTransactionMetaData createHookTransactionWithHookIResultd = hookTransactionUtil
				.createHookTransactionWithHookId(documentMetaDataObject, Map.of("test", "one"), "testprocess",
						"HookID");
		assertNotNull(createHookTransactionWithHookIResultd);

	}

    @Test
    public void createHookTransaction_shouldPopulateTransactionAndExecutionRecordFields() {
        DocumentMetaData documentMetaDataObject = new DocumentMetaData();
        documentMetaDataObject.setId("doc-123");
        documentMetaDataObject.setSpaceId(23695);
        documentMetaDataObject.setClientId(69356);
        documentMetaDataObject.setAppIdentifier("appIdentifier");

        Map<String, String> hookExecutionMessage = Map.of("test", "one");
        String processName = "testprocess";

        HookTransactionMetaData result = HookTransactionUtil.createHookTransaction(
                documentMetaDataObject,
                hookExecutionMessage,
                processName
        );

        assertNotNull(result);
        assertEquals(23695, result.getSpaceId());
        assertEquals(69356, result.getClientId());
        assertEquals("appIdentifier", result.getAppIdentifier());
        assertEquals(Workflow.HOOK_STATUS_ACTIVE, result.getStatus());
        assertEquals(Workflow.HOOK_RECORD_TYPE_TRANSACTION, result.getHookRecordType());
        assertEquals("doc-123", result.getTargetId());
        assertEquals(Workflow.DOCUMENTS_COLLECTION, result.getTargetType());
        assertNotNull(result.getDateCreated());
        assertNotNull(result.getDateModified());

        assertNotNull(result.getHookExecutionList());
        assertEquals(1, result.getHookExecutionList().size());

        HookExecutionRecordMetaData executionRecord = result.getHookExecutionList().get(0);
        assertEquals("appIdentifier", executionRecord.getAppIdentifier());
        assertEquals(69356, executionRecord.getClientId());
        assertEquals(23695, executionRecord.getSpaceId());
        assertEquals("testprocess", executionRecord.getActivitiProcessKey());
        assertNotNull(executionRecord.getDateCreated());
        assertNotNull(executionRecord.getMessageList());
        assertEquals(1, executionRecord.getMessageList().size());
        assertEquals("one", executionRecord.getMessageList().get(0).get("test"));
    }
}
