package com.optum.fds.paperless.workflow.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.optum.fds.paperless.util.SftpUtil;
import org.bson.Document;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.query.Criteria;
import com.optum.fds.paperless.document.util.DocumentResponse;
import com.optum.fds.paperless.junit.references.RallyTestCase;
import com.optum.fds.paperless.junit.references.UserStory;
import com.optum.fds.paperless.mongo.Batch;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.Parser;
import org.springframework.test.util.ReflectionTestUtils;

@RunWith(MockitoJUnitRunner.class)
public class WorkFlowUtilTest {

	@InjectMocks
	WorkFlowUtil workFlowUtil;

	@Rule
	public TemporaryFolder folder = new TemporaryFolder();

	private final String SEARCH_WINDOW_WITH_DATES = "{\"start_date\":\"2018-06-16T00:00:00.000-06:00\",\"end_date\":\"2018-06-19T00:00:00.000-06:00\"}";
	private final String SEARCH_WINDOW_OFFSET_WITH_DATES = "{\"start_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"},\"end_date_offset\":{\"time_window\":\"24\",\"format\":\"Hours\"}}";
	private final String SEARCH_WINDOW_OFFSET_WITH_NO_FORMAT = "{\"start_date_offset\":{\"time_window\":\"48\"},\"end_date_offset\":{\"time_window\":\"24\"}}";
	private final String SEARCH_WINDOW_OFFSET_WITH_NO_ENDDATE = "{\"start_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"}}";
	private final String SEARCH_WINDOW_OFFSET_WITH_NO_STARTDATE = "{\"end_date_offset\":{\"time_window\":\"48\",\"format\":\"Hours\"}}";
	private final String SEARCH_WINDOW_OFFSET_WITH_DATES_INVALID = "{\"start_date_offset\":{\"time\":\"48\"},\"end\":{\"time_window\":\"24\",\"format\":\"Hours\"}}";
	private final String INVALID_SEARCH_WINDOW = "{\"time_window\":\"24\",\"format\":\"Hours\"";
	private final String SEARCH_WINDOW_WITH_NO_TIME_WINDOW_AND_FORMAT_OR_DATES = "{}";
	private final String data = "test";
	private String path = "";
	private final String fileName = "src/test/resources/InputJson/PENRequest.json";
	private final String fileNameOne = "src/test/resources/InputJson/PENRequest";
	private final String jsonString = "null";
	private final String INVALID_SEARCH = "{\"time_window\":\"24\",\"format\":\"Hours\"}";

	@Before
	public void setUp() {
		path = folder.getRoot().getAbsolutePath();
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaWithSearchWindowOffSet() throws Exception {
		Criteria criteria = WorkFlowUtil.getSearchWindowCriteria(SEARCH_WINDOW_OFFSET_WITH_DATES);
		assertNotNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testgenerateFileFromString() throws Exception {
		File file = WorkFlowUtil.generateFileFromString(data, path + "file.txt");
		assertNotNull(file);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testreadDocumentFromJsonFile() throws Exception {
		DocumentMetaData readDocumentFromJsonFile = WorkFlowUtil.readDocumentFromJsonFile(fileName);
		assertNotNull(readDocumentFromJsonFile);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void readBatchFromJsonFileTest() throws Exception {
		Batch readBatchFromJsonFile = WorkFlowUtil.readBatchFromJsonFile(jsonString);
		assertNull(readBatchFromJsonFile);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void readDocumentFromJsonFilePathTest() throws Exception {
		DocumentMetaData readDocumentFromJsonFilePath = WorkFlowUtil.readDocumentFromJsonFilePath(fileName);
		assertNotNull(readDocumentFromJsonFilePath);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void convertDocumentToFileTest() throws Exception {
		File convertDocumentToFile = WorkFlowUtil.convertDocumentToFile("data", "src/test/resources/InputJson/",
				"PENRequest");
		assertNotNull(convertDocumentToFile);

	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void readDocumentResponseFromJsonStringTest() throws Exception {
		DocumentResponse readDocumentResponseFromJsonFile = WorkFlowUtil
				.readDocumentResponseFromJsonString(SEARCH_WINDOW_WITH_NO_TIME_WINDOW_AND_FORMAT_OR_DATES);
		assertNotNull(readDocumentResponseFromJsonFile);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void documentListToFileTest() throws Exception {
		DocumentResponse readDocumentResponseFromJsonFile = WorkFlowUtil
				.readDocumentResponseFromJsonString(SEARCH_WINDOW_WITH_NO_TIME_WINDOW_AND_FORMAT_OR_DATES);
		assertNotNull(readDocumentResponseFromJsonFile);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testreadDocumentMetadataFromJsonString() throws Exception {
		DocumentMetaData docmetadata = WorkFlowUtil.readDocumentMetadataFromJsonString(jsonString);
		assertNotNull(docmetadata);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaWithNOEndDateOffSet() throws Exception {
		Criteria criteria = WorkFlowUtil.getSearchWindowCriteria(SEARCH_WINDOW_OFFSET_WITH_NO_ENDDATE);
		assertNotNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaStringWithNOEndDateOffSet() throws Exception {
		String criteria = WorkFlowUtil.getSearchWindowCriteriaString(SEARCH_WINDOW_OFFSET_WITH_NO_ENDDATE);
		assertNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaWithNOStartDateOffSet() throws Exception {
		Criteria criteria = WorkFlowUtil.getSearchWindowCriteria(SEARCH_WINDOW_OFFSET_WITH_NO_STARTDATE);
		assertNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaStringWithNOStartDateOffSet() throws Exception {
		String criteria = WorkFlowUtil.getSearchWindowCriteriaString(SEARCH_WINDOW_OFFSET_WITH_NO_STARTDATE);
		assertNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaWithNOFormatOffSet() throws Exception {
		Criteria criteria = WorkFlowUtil.getSearchWindowCriteria(SEARCH_WINDOW_OFFSET_WITH_NO_FORMAT);
		assertNotNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaStringWithNOFormatOffSet() throws Exception {
		String criteria = WorkFlowUtil.getSearchWindowCriteriaString(SEARCH_WINDOW_OFFSET_WITH_NO_FORMAT);
		assertNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaWithInvalidSearchWindowOffSet() throws Exception {
		Criteria criteria = WorkFlowUtil.getSearchWindowCriteria(SEARCH_WINDOW_OFFSET_WITH_DATES_INVALID);
		assertNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaStringWithInvalidSearchWindowOffSet() throws Exception {
		String criteria = WorkFlowUtil.getSearchWindowCriteriaString(SEARCH_WINDOW_OFFSET_WITH_DATES_INVALID);
		assertNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaWithDates() throws Exception {
		Criteria criteria = WorkFlowUtil.getSearchWindowCriteria(SEARCH_WINDOW_WITH_DATES);
		assertNotNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaStringWithDates() throws Exception {
		String criteria = WorkFlowUtil.getSearchWindowCriteriaString(SEARCH_WINDOW_WITH_DATES);
		assertNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaWithNoSearchWindow() throws Exception {
		Criteria criteria = WorkFlowUtil.getSearchWindowCriteria(null);
		assertNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaStringWithNoSearchWindow() throws Exception {
		String criteria = WorkFlowUtil.getSearchWindowCriteriaString(null);
		assertNull(criteria);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaWithInvalidSearchWindow() {
		boolean thrown = false;
		try {
			WorkFlowUtil.getSearchWindowCriteria(INVALID_SEARCH_WINDOW);
		} catch (IOException | ParseException e) {
			thrown = true;
		}
		assertTrue(thrown);
	}

	@Test
	@UserStory(references = "Us4359420")
	@RallyTestCase(references = "TA13318101")
	public void testGetSearchWindowCriteriaWithSearchWindowWithNoTimeWindowAndFormatOrDates() throws Exception {
		Criteria criteria = WorkFlowUtil.getSearchWindowCriteria(SEARCH_WINDOW_WITH_NO_TIME_WINDOW_AND_FORMAT_OR_DATES);
		assertNull(criteria);
	}

	@Test
	public void testGetSearchWindowCriteriaStringWithSearchWindowWithNoTimeWindowAndFormatOrDates() throws Exception {
		String criteria = WorkFlowUtil
				.getSearchWindowCriteriaString(SEARCH_WINDOW_WITH_NO_TIME_WINDOW_AND_FORMAT_OR_DATES);
		assertNull(criteria);
	}

	@Test

	@UserStory(references = "US25126")

	@RallyTestCase(references = "TC30188")
	public void testReplacePlaceHolders() throws Exception {
		String input = "{ \"metadata.BARCODE\" : ${$.metadata.PTRS}, \"spaceId\" : 3006 }";
		DocumentMetaData documentMetaData = getDocumentMetaData();
		String documentMetaDataAsJsonString = Parser.toJson(documentMetaData, "yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		String result = WorkFlowUtil.replacePlaceHolders(input, documentMetaDataAsJsonString);
		assertNotNull(result);
		String expected = "{ \"metadata.BARCODE\" : \"145ZAAPIU00000301\", \"spaceId\" : 3006 }";
		assertEquals(result, expected);
	}

	private DocumentMetaData getDocumentMetaData() throws IOException {
		DocumentMetaData documentMetaData = null;
		String docStr = "{" + "\"id\" : \"593e9fadef8654760f6b464c\"," + "\"clientId\" : 1," + "\"spaceId\" : 3007,"
				+ "\"appIdentifier\" : \"testapp\"," + "\"status\" : \"AVAILABLE\","
				+ "\"dateCreated\" : \"2017-06-12T23:02:38.693Z\"," + "\"dateModified\" : \"2017-06-12T23:02:38.693Z\","
				+ "\"transactionId\" : \"593e9fadef8654760f6b464b\"," + "\"documentAttachments\" : [" + "{"
				+ "\"id\" : \"bdec0602-7dc2-4f4f-9484-d4e97863a40e\"," + "\"index\" : 1,"
				+ "\"file_name\" : \"balloon.jpg\"," + "\"status\" : \"AVAILABLE\"" + "}" + "]" + "}";

		String metaData = "{" + "\"PTRS\" : \"145ZAAPIU00000301\"" + "}" + "}";
		Document metaDataObject = Document.parse(metaData);
		documentMetaData = Parser.parseJson(docStr, DocumentMetaData.class);
		documentMetaData.setMetadata(metaDataObject);
		return documentMetaData;
	}

	@Test
	@UserStory(references = "US26708")
	@RallyTestCase(references = "TC30348")
	public void testConvertToCompanionFileName() throws Exception {
		String fileName = "convertToCompanionFileName";
		int startIndex = 0;
		int endIndex = 10;
		String fileExtension = ".cmp";
		String result = WorkFlowUtil.convertToCompanionFileName(fileName, fileExtension, startIndex, endIndex);
		String expected = "convertToC.cmp";
		assertEquals(result, expected);
	}

	@Test
	@UserStory(references = "US26708")
	@RallyTestCase(references = "TC30348")
	public void testConvertToCompanionFileNameWithNullValue() throws Exception {
		int startIndex = 0;
		int endIndex = 10;
		String fileExtension = ".cmp";
		String result = WorkFlowUtil.convertToCompanionFileName(null, fileExtension, startIndex, endIndex);
		String expected = "";
		assertEquals(result, expected);
	}

	@Test
	@UserStory(references = "US28949")
	@RallyTestCase(references = "TC31319")
	public void testUpdateEDeliveryErrorEmpty() throws Exception {
		org.bson.Document metadata = org.bson.Document.parse("{}");
		WorkFlowUtil.updateEDeliveryError(metadata, "claimNumber");
		System.out.println("metadata=" + metadata.toString());
		assertEquals("Document{{eDeliveryError=Missing or invalid data: claimNumber}}", metadata.toString());
	}

	@Test
	@UserStory(references = "US28949")
	@RallyTestCase(references = "TC31319")
	public void testUpdateEDeliveryErrorAlreadyExists() throws Exception {
		org.bson.Document metadata = org.bson.Document
				.parse("{'eDeliveryError' : 'Missing or invalid data: claimNumber'}");
		WorkFlowUtil.updateEDeliveryError(metadata, "claimNumber");
		System.out.println("metadata=" + metadata.toString());
		assertEquals("Document{{eDeliveryError=Missing or invalid data: claimNumber}}", metadata.toString());
	}

	@Test
	@UserStory(references = "US28949")
	@RallyTestCase(references = "TC31319")
	public void testUpdateEDeliveryError() throws Exception {
		org.bson.Document metadata = org.bson.Document
				.parse("{'eDeliveryError' : 'Missing or invalid data: ODARLetterId'}");
		WorkFlowUtil.updateEDeliveryError(metadata, "claimNumber");
		System.out.println("metadata=" + metadata.toString());
		assertEquals(
				"Document{{eDeliveryError=Missing or invalid data: ODARLetterId|Missing or invalid data: claimNumber}}",
				metadata.toString());
	}

    @Test
    public void testGetTemporaryWorkingPath_ShouldCreateDirectoryUnderIngestRootForSpaceId() throws Exception {
        String ingestRootPath = folder.newFolder("ingest-root").getAbsolutePath();
        ReflectionTestUtils.setField(WorkFlowUtil.class, "ingestRoot", ingestRootPath);

        String result = WorkFlowUtil.getTemporaryWorkingPath(12345);

        assertNotNull(result);
        assertTrue(result.startsWith(ingestRootPath + File.separator + 12345 + File.separator));
        assertTrue(Files.exists(Paths.get(result)));
        assertTrue(Files.isDirectory(Paths.get(result)));
    }

    @Test
    public void testReadDocumentsFromJsonFileToString_ShouldReturnFileContents() throws Exception {
        File tempFile = folder.newFile("documents.json");
        String expected = "{\"documents\":[{\"id\":\"123\"}]}";

        java.nio.file.Files.write(tempFile.toPath(), expected.getBytes(java.nio.charset.StandardCharsets.UTF_8));

        String result = WorkFlowUtil.readDocumentsFromJsonFileToString(tempFile.getAbsolutePath());

        assertNotNull(result);
        assertEquals(expected, result);
    }

    @Test
    public void testReadDocumentFromJsonFile_ShouldParseDocumentMetadataFields() throws Exception {
        File tempFile = folder.newFile("document.json");
        String json = "{"
                + "\"spaceId\":3007,"
                + "\"fileName\":\"test-file.pdf\","
                + "\"fileType\":\"pdf\","
                + "\"dateCreated\":\"2024-01-01T10:15:30.000Z\","
                + "\"dateModified\":\"2024-01-01T10:15:30.000Z\""
                + "}";

        java.nio.file.Files.write(
                tempFile.toPath(),
                json.getBytes(java.nio.charset.StandardCharsets.UTF_8)
        );

        DocumentMetaData result = WorkFlowUtil.readDocumentFromJsonFile(tempFile.getAbsolutePath());

        assertNotNull(result);
        assertEquals(3007, result.getSpaceId());
        assertEquals("test-file.pdf", result.getFileName());
        assertEquals("pdf", result.getFileType());
        assertNotNull(result.getDateCreated());
        assertNotNull(result.getDateModified());
    }

    @Test
    public void testReadDocumentFromJsonFilePath_ShouldSetMetadataFromFile() throws Exception {
        File tempFile = folder.newFile("document-metadata-wrapper.json");
        String json = "{"
                + "\"metadata\":{"
                + "\"claimNumber\":\"CLM-12345\","
                + "\"memberId\":\"MBR-98765\""
                + "}"
                + "}";

        java.nio.file.Files.write(
                tempFile.toPath(),
                json.getBytes(java.nio.charset.StandardCharsets.UTF_8)
        );

        DocumentMetaData result = WorkFlowUtil.readDocumentFromJsonFilePath(tempFile.getAbsolutePath());

        assertNotNull(result);
        assertNotNull(result.getMetadata());
        assertEquals("CLM-12345", result.getMetadata().getString("claimNumber"));
        assertEquals("MBR-98765", result.getMetadata().getString("memberId"));
    }

    @Test
    public void testReadDocumentMetadataFromJsonString_ShouldSetMetadataFromJsonString() throws Exception {
        String json = "{"
                + "\"claimNumber\":\"CLM-22222\","
                + "\"memberId\":\"MBR-33333\""
                + "}";

        DocumentMetaData result = WorkFlowUtil.readDocumentMetadataFromJsonString(json);

        assertNotNull(result);
        assertNotNull(result.getMetadata());
        assertEquals("CLM-22222", result.getMetadata().getString("claimNumber"));
        assertEquals("MBR-33333", result.getMetadata().getString("memberId"));
    }

    @Test
    public void testReadMetadataFromJsonString_ShouldReturnBsonDocument() throws Exception {
        String json = "{"
                + "\"claimNumber\":\"CLM-77777\","
                + "\"memberId\":\"MBR-88888\""
                + "}";

        org.bson.Document result = WorkFlowUtil.readMetadataFromJsonString(json);

        assertNotNull(result);
        assertEquals("CLM-77777", result.getString("claimNumber"));
        assertEquals("MBR-88888", result.getString("memberId"));
    }

    @Test
    public void testConvertDocumentToFile_ShouldWriteMetadataWrapperJsonToFile() throws Exception {
        File tempDir = folder.newFolder("convert-document");
        String metadata = "{\"claimNumber\":\"CLM-99999\"}";
        String fileName = "document.json";

        File result = WorkFlowUtil.convertDocumentToFile(metadata, tempDir.getAbsolutePath(), fileName);

        assertNotNull(result);
        assertTrue(result.exists());

        String fileContents = new String(
                java.nio.file.Files.readAllBytes(result.toPath()),
                java.nio.charset.StandardCharsets.UTF_8
        );

        assertTrue(fileContents.contains("\"metadata\""));
        assertTrue(fileContents.contains("CLM-99999"));
    }

    @Test
    public void testReadDocumentResponseFromJsonFile_ShouldParseDocumentResponseFields() throws Exception {
        File tempFile = folder.newFile("document-response.json");
        String json = "{"
                + "\"id\":\"doc-response-1\","
                + "\"spaceId\":3009,"
                + "\"status\":\"AVAILABLE\","
                + "\"dateCreated\":\"2024-01-01T10:15:30.000Z\","
                + "\"dateModified\":\"2024-01-01T11:15:30.000Z\""
                + "}";

        java.nio.file.Files.write(
                tempFile.toPath(),
                json.getBytes(java.nio.charset.StandardCharsets.UTF_8)
        );

        DocumentResponse result = WorkFlowUtil.readDocumentResponseFromJsonFile(tempFile.getAbsolutePath());

        assertNotNull(result);
        assertEquals("doc-response-1", result.getId());
        assertEquals(Integer.valueOf(3009), result.getSpaceId());
        assertEquals("AVAILABLE", result.getStatus());
        assertEquals("2024-01-01T10:15:30.000Z", result.getDateCreated());
        assertEquals("2024-01-01T11:15:30.000Z", result.getDateModified());
    }

    @Test
    public void testDocumentMapToFile_ShouldWriteDocumentMapJsonToFile() throws Exception {
        File tempDir = folder.newFolder("document-map");

        DocumentMetaData documentMetaData = new DocumentMetaData();
        documentMetaData.setSpaceId(4001);
        documentMetaData.setFileName("mapped-doc.pdf");
        documentMetaData.setFileType("pdf");

        Map<String, List<DocumentMetaData>> documentMap = new java.util.HashMap<>();
        documentMap.put("zip-one.zip", java.util.Collections.singletonList(documentMetaData));

        File result = WorkFlowUtil.documentMapToFile(documentMap, tempDir.getAbsolutePath(), "document-map.json");

        assertNotNull(result);
        assertTrue(result.exists());

        String fileContents = new String(
                java.nio.file.Files.readAllBytes(result.toPath()),
                java.nio.charset.StandardCharsets.UTF_8
        );

        assertTrue(fileContents.contains("zip-one.zip"));
        assertTrue(fileContents.contains("mapped-doc.pdf"));
        assertTrue(fileContents.contains("\"spaceId\":4001"));
    }

    @Test
    public void testMoveFileFromSFTPDirToArchive_ShouldDelegateToSftpUtil() throws Exception {
        SftpUtil sftpUtilMock = org.mockito.Mockito.mock(SftpUtil.class);
        ReflectionTestUtils.setField(workFlowUtil, "sftpUtil", sftpUtilMock);

        workFlowUtil.moveFileFromSFTPDirToArchive(
                "user1",
                "pass1",
                "host1",
                22,
                "/ftp/working",
                "/ftp/archive",
                "test.zip",
                3,
                10L
        );

        org.mockito.Mockito.verify(sftpUtilMock).moveFileFromSFTPDirToArchive(
                "user1",
                "pass1",
                "host1",
                22,
                "/ftp/working",
                "/ftp/archive",
                "test.zip",
                3,
                10L
        );
    }

    @Test
    public void testGetSearchWindowCriteriaString_ShouldReturnNull() {
        String result = WorkFlowUtil.getSearchWindowCriteriaString(SEARCH_WINDOW_OFFSET_WITH_DATES);

        assertNull(result);
    }

    @Test
    public void testReadOneProcessorTransactionMetadataFromJsonFile_ShouldParseSingleProcessorTransactionMetadata() throws Exception {
        File tempFile = folder.newFile("processor-transaction-metadata.json");
        String json = "{"
                + "\"processorTransactionMetadata\":{"
                + "\"configSpaceId\":3005,"
                + "\"clientId\":12,"
                + "\"appIdentifier\":\"test-app\","
                + "\"dateCreated\":\"Mon Jan 01 10:15:30 UTC 2024\","
                + "\"dateModified\":\"Mon Jan 01 11:15:30 UTC 2024\""
                + "}"
                + "}";

        java.nio.file.Files.write(
                tempFile.toPath(),
                json.getBytes(java.nio.charset.StandardCharsets.UTF_8)
        );

        List<com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata> result =
                WorkFlowUtil.readOneProcessorTransactionMetadataFromJsonFile(tempFile.getAbsolutePath());

        assertNotNull(result);
        assertEquals(1, result.size());
        assertNotNull(result.get(0));
        assertEquals(Integer.valueOf(3005), result.get(0).getConfigSpaceId());
        assertEquals(12, result.get(0).getClientId());
        assertEquals("test-app", result.get(0).getAppIdentifier());
        assertNotNull(result.get(0).getDateCreated());
        assertNotNull(result.get(0).getDateModified());
    }
}