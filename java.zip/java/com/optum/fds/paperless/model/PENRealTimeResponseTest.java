package com.optum.fds.paperless.model;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class PENRealTimeResponseTest {

    private PENRealTimeResponse penRealTimeResponse;

    @Before
    public void setUp() {
        penRealTimeResponse = new PENRealTimeResponse();
    }

    @Test
    public void testGetSetStatusCode() {
        String statusCode = "200";
        penRealTimeResponse.setStatusCode(statusCode);
        assertEquals(statusCode, penRealTimeResponse.getStatusCode());
    }

    @Test
    public void testGetSetStatusMessage() {
        String statusMessage = "Success";
        penRealTimeResponse.setStatusMessage(statusMessage);
        assertEquals(statusMessage, penRealTimeResponse.getStatusMessage());
    }

    @Test
    public void testGetSetResponseMessage() {
        PENRealTimeResponseMessage responseMessage = new PENRealTimeResponseMessage();
        penRealTimeResponse.setResponseMessage(responseMessage);
        assertEquals(responseMessage, penRealTimeResponse.getResponseMessage());
    }

    @Test
    public void testToString() {
        String statusCode = "200";
        String statusMessage = "Success";
        PENRealTimeResponseMessage responseMessage = new PENRealTimeResponseMessage();

        penRealTimeResponse.setStatusCode(statusCode);
        penRealTimeResponse.setStatusMessage(statusMessage);
        penRealTimeResponse.setResponseMessage(responseMessage);

        String expectedString = "PENRealTimeResponse [statusCode=" + statusCode + ", statusMessage=" + statusMessage
                + ", responseMessage=" + responseMessage + "]";
        assertEquals(expectedString, penRealTimeResponse.toString());
    }
}