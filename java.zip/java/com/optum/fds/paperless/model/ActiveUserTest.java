package com.optum.fds.paperless.model;

import static org.junit.Assert.*;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class ActiveUserTest {

    @Test
    public void testGettersAndSetters() {
        ActiveUser activeUser = new ActiveUser();
        User user1 = new User();
        User user2 = new User();
        List<User> users = Arrays.asList(user1, user2);

        activeUser.setCorpMpin("MPIN123");
        activeUser.setTin("TIN456");
        activeUser.setUsers(users);

        assertEquals("MPIN123", activeUser.getCorpMpin());
        assertEquals("TIN456", activeUser.getTin());
        assertEquals(users, activeUser.getUsers());
    }
}