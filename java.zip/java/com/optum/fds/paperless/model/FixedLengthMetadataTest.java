package com.optum.fds.paperless.model;

import static org.junit.Assert.*;
import org.junit.Test;


public class FixedLengthMetadataTest {

    @Test
    public void testGettersAndSetters() {
        FixedLengthMetadata metadata = new FixedLengthMetadata();

        metadata.setTagLine("Sample Tag Line");
        metadata.setProviderId("Provider123");
        metadata.setMpin("MPIN456");
        metadata.setPatientName("John Doe");
        metadata.setPatientDateOfBirth("1990-01-01");
        metadata.setRecipientName("Jane Doe");
        metadata.setApplicationPassThru("PassThruData");
        metadata.setCheckAmount("1000");
        metadata.setCheckNumber("CHK123");
        metadata.setSubCategory("SC");
        metadata.setCategory("Category1");
        metadata.setRecipientAddressLine1("Address Line 1");
        metadata.setRecipientAddressLine2("Address Line 2");
        metadata.setRecipientAddressLine3("Address Line 3");
        metadata.setRecipientAddressLine4("Address Line 4");
        metadata.setRecipientAddressLine5("Address Line 5");
        metadata.setConfigKey("ConfigKey123");
        metadata.setOriginalPrintTrail("PrintTrail");
        metadata.setEdeliveryError("Error");
        metadata.setEmailAddress("email@example.com");
        metadata.setFileName("FileName.txt");
        metadata.setNextLine("NextLine");

        assertEquals("Sample Tag Line", metadata.getTagLine());
        assertEquals("Provider123", metadata.getProviderId());
        assertEquals("MPIN456", metadata.getMpin());
        assertEquals("John Doe", metadata.getPatientName());
        assertEquals("1990-01-01", metadata.getPatientDateOfBirth());
        assertEquals("Jane Doe", metadata.getRecipientName());
        assertEquals("PassThruData", metadata.getApplicationPassThru());
        assertEquals("1000", metadata.getCheckAmount());
        assertEquals("CHK123", metadata.getCheckNumber());
        assertEquals("SC", metadata.getSubCategory());
        assertEquals("Category1", metadata.getCategory());
        assertEquals("Address Line 1", metadata.getRecipientAddressLine1());
        assertEquals("Address Line 2", metadata.getRecipientAddressLine2());
        assertEquals("Address Line 3", metadata.getRecipientAddressLine3());
        assertEquals("Address Line 4", metadata.getRecipientAddressLine4());
        assertEquals("Address Line 5", metadata.getRecipientAddressLine5());
        assertEquals("ConfigKey123", metadata.getConfigKey());
        assertEquals("PrintTrail", metadata.getOriginalPrintTrail());
        assertEquals("Error", metadata.getEdeliveryError());
        assertEquals("email@example.com", metadata.getEmailAddress());
        assertEquals("FileName.txt", metadata.getFileName());
        assertEquals("NextLine", metadata.getNextLine());
    }
}