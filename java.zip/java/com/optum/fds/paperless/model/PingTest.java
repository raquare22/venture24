package com.optum.fds.paperless.model;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class PingTest {

    private Ping ping;

    @Before
    public void setUp() {
        ping = new Ping("1.0.0", "2023-10-01T12:00:00Z");
    }

    @Test
    public void testGetSetBuildNumber() {
        String buildNumber = "2.0.0";
        ping.setBuildNumber(buildNumber);
        assertEquals(buildNumber, ping.getBuildNumber());
    }

    @Test
    public void testGetSetTimeStamp() {
        String timeStamp = "2023-10-02T12:00:00Z";
        ping.setTimeStamp(timeStamp);
        assertEquals(timeStamp, ping.getTimeStamp());
    }

    @Test
    public void testToString() {
        String expectedString = "buildNumber: 1.0.0, timeStamp: 2023-10-01T12:00:00Z";
        assertEquals(expectedString, ping.toString());
    }
}