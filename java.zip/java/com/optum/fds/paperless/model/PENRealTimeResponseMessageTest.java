package com.optum.fds.paperless.model;

import java.util.List;
import java.util.Map;
import java.util.Arrays;
import java.util.HashMap;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class PENRealTimeResponseMessageTest {

    private PENRealTimeResponseMessage penRealTimeResponseMessage;

    @Before
    public void setUp() {
        penRealTimeResponseMessage = new PENRealTimeResponseMessage();
    }

    @Test
    public void testGetSetDocumentId() {
        String documentId = "doc123";
        penRealTimeResponseMessage.setDocumentId(documentId);
        assertEquals(documentId, penRealTimeResponseMessage.getDocumentId());
    }

    @Test
    public void testGetSetAppId() {
        String appId = "app123";
        penRealTimeResponseMessage.setAppId(appId);
        assertEquals(appId, penRealTimeResponseMessage.getAppId());
    }

    @Test
    public void testGetSetCategory() {
        String category = "category1";
        penRealTimeResponseMessage.setCategory(category);
        assertEquals(category, penRealTimeResponseMessage.getCategory());
    }

    @Test
    public void testGetSetFrequency() {
        String frequency = "daily";
        penRealTimeResponseMessage.setFrequency(frequency);
        assertEquals(frequency, penRealTimeResponseMessage.getFrequency());
    }

    @Test
    public void testGetSetEmailSent() {
        boolean emailSent = true;
        penRealTimeResponseMessage.setEmailSent(emailSent);
        assertEquals(emailSent, penRealTimeResponseMessage.isEmailSent());
    }

    @Test
    public void testGetSetProviderEmailIdList() {
        List<String> providerEmailIdList = Arrays.asList("email1@example.com", "email2@example.com");
        penRealTimeResponseMessage.setProviderEmailIdList(providerEmailIdList);
        assertEquals(providerEmailIdList, penRealTimeResponseMessage.getProviderEmailIdList());
    }

    @Test
    public void testGetSetMessageIdList() {
        Map<String, String> messageIdList = new HashMap<>();
        messageIdList.put("key1", "value1");
        penRealTimeResponseMessage.setMessageIdList(messageIdList);
        assertEquals(messageIdList, penRealTimeResponseMessage.getMessageIdList());
    }

    @Test
    public void testToString() {
        String documentId = "doc123";
        String appId = "app123";
        String category = "category1";
        String frequency = "daily";
        boolean emailSent = true;
        List<String> providerEmailIdList = Arrays.asList("email1@example.com", "email2@example.com");
        Map<String, String> messageIdList = new HashMap<>();
        messageIdList.put("key1", "value1");

        penRealTimeResponseMessage.setDocumentId(documentId);
        penRealTimeResponseMessage.setAppId(appId);
        penRealTimeResponseMessage.setCategory(category);
        penRealTimeResponseMessage.setFrequency(frequency);
        penRealTimeResponseMessage.setEmailSent(emailSent);
        penRealTimeResponseMessage.setProviderEmailIdList(providerEmailIdList);
        penRealTimeResponseMessage.setMessageIdList(messageIdList);

        String expectedString = "PENRealTimeResponseMessage [documentId=" + documentId + ", appId=" + appId
                + ", category=" + category + ", frequency=" + frequency + ", emailSent=" + emailSent
                + ", providerEmailIdList=" + providerEmailIdList + ", messageIdList=" + messageIdList + "]";
        assertEquals(expectedString, penRealTimeResponseMessage.toString());
    }
}