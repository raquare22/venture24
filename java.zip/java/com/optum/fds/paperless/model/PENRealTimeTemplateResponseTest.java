package com.optum.fds.paperless.model;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class PENRealTimeTemplateResponseTest {

    private PENRealTimeTemplateResponse penRealTimeTemplateResponse;

    @Before
    public void setUp() {
        penRealTimeTemplateResponse = new PENRealTimeTemplateResponse();
    }

    @Test
    public void testGetSetStatusCode() {
        String statusCode = "200";
        penRealTimeTemplateResponse.setStatusCode(statusCode);
        assertEquals(statusCode, penRealTimeTemplateResponse.getStatusCode());
    }

    @Test
    public void testGetSetStatusMessage() {
        String statusMessage = "Success";
        penRealTimeTemplateResponse.setStatusMessage(statusMessage);
        assertEquals(statusMessage, penRealTimeTemplateResponse.getStatusMessage());
    }

    @Test
    public void testGetSetResponseMessage() {
        String responseMessage = "Response received";
        penRealTimeTemplateResponse.setResponseMessage(responseMessage);
        assertEquals(responseMessage, penRealTimeTemplateResponse.getResponseMessage());
    }

    @Test
    public void testToString() {
        String statusCode = "200";
        String statusMessage = "Success";
        String responseMessage = "Response received";

        penRealTimeTemplateResponse.setStatusCode(statusCode);
        penRealTimeTemplateResponse.setStatusMessage(statusMessage);
        penRealTimeTemplateResponse.setResponseMessage(responseMessage);

        String expectedString = "PENRealTimeTemplateResponse [statusCode=" + statusCode + ", statusMessage=" + statusMessage
                + ", responseMessage=" + responseMessage + "]";
        assertEquals(expectedString, penRealTimeTemplateResponse.toString());
    }
}