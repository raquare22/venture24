package com.optum.fds.paperless.model;

import static org.junit.Assert.*;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class MultiPostResponseTest {

    @Test
    public void testGettersAndSetters() {
        List<String> docIds = Arrays.asList("doc1", "doc2", "doc3");
        MultiPostResponse response = new MultiPostResponse(docIds);

        assertEquals(docIds, response.getInsertedDocIds());

        List<String> newDocIds = Arrays.asList("doc4", "doc5");
        response.setInsertedDocIds(newDocIds);
        assertEquals(newDocIds, response.getInsertedDocIds());
    }
}