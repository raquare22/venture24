package com.optum.fds.paperless.model;

import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Arrays;
import java.util.List;

public class MultiPutResponseTest {

    @Test
    public void testGettersAndSetters() {
        List<String> updated = Arrays.asList("item1", "item2");
        List<String> notUpdated = Arrays.asList("item3", "item4");
        MultiPutResponse response = new MultiPutResponse(updated, notUpdated);

        assertEquals(updated, response.getUpdated());
        assertEquals(notUpdated, response.getNotUpdated());

        List<String> newUpdated = Arrays.asList("item5", "item6");
        List<String> newNotUpdated = Arrays.asList("item7", "item8");
        response.setUpdated(newUpdated);
        response.setNotUpdated(newNotUpdated);

        assertEquals(newUpdated, response.getUpdated());
        assertEquals(newNotUpdated, response.getNotUpdated());
    }
}