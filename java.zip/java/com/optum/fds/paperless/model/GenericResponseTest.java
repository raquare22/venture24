package com.optum.fds.paperless.model;

import static org.junit.Assert.*;
import org.junit.Test;


public class GenericResponseTest {

    @Test
    public void testGettersAndSetters() {
        GenericResponse response = new GenericResponse();

        response.setStatusCode("200");
        response.setStatusMessage("OK");
        response.setResponse("Sample Response");

        assertEquals("200", response.getStatusCode());
        assertEquals("OK", response.getStatusMessage());
        assertEquals("Sample Response", response.getResponse());
    }

    @Test
    public void testConstructor() {
        GenericResponse response = new GenericResponse("404", "Not Found", "Error Response");

        assertEquals("404", response.getStatusCode());
        assertEquals("Not Found", response.getStatusMessage());
        assertEquals("Error Response", response.getResponse());
    }

    @Test
    public void testStaticFromMethod() {
        GenericResponse response = GenericResponse.from("500", "Internal Server Error", "Server Error Response");

        assertEquals("500", response.getStatusCode());
        assertEquals("Internal Server Error", response.getStatusMessage());
        assertEquals("Server Error Response", response.getResponse());
    }

    @Test
    public void testToString() {
        GenericResponse response = new GenericResponse("200", "OK", "Sample Response");

        String expectedString = "statusCode: 200, statusMessage: OK, responseBody: Sample Response";
        assertEquals(expectedString, response.toString());
    }
}