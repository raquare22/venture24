package com.optum.fds.paperless.exception;

import static org.junit.Assert.*;
import org.junit.Test;

public class InvalidExpressionExceptionTest {

    @Test
    public void testConstructorWithString() {
        String message = "Test message";
        InvalidExpressionException exception = new InvalidExpressionException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithStringAndThrowable() {
        String message = "Test message";
        Throwable cause = new Throwable("Cause message");
        InvalidExpressionException exception = new InvalidExpressionException(message, cause);
        assertEquals(message, exception.getMessage());
        assertSame(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithThrowable() {
        Throwable cause = new Throwable("Cause message");
        InvalidExpressionException exception = new InvalidExpressionException(cause);
        assertEquals(cause.toString(), exception.getMessage());
        assertSame(cause, exception.getCause());
    }
}