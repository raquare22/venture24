package com.optum.fds.paperless.exception;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class ErrorCodeTest {

    @Test
    public void testGetCode() {
        assertEquals(0, ErrorCode.PROCESS.getCode());
        assertEquals(1, ErrorCode.VALIDATION.getCode());
        assertEquals(3, ErrorCode.OUT_OF_RETRIES.getCode());
        assertEquals(41, ErrorCode.REST_API_ERROR.getCode());
    }

    @Test
    public void testGetDescription() {
        assertEquals("A process error has occurred.", ErrorCode.PROCESS.getDescription());
        assertEquals("A validation error has occurred.", ErrorCode.VALIDATION.getDescription());
        assertEquals("An out of retries error has occurred.", ErrorCode.OUT_OF_RETRIES.getDescription());
        assertEquals("Message Service Rest Api Error", ErrorCode.REST_API_ERROR.getDescription());
    }

    @Test
    public void testToString() {
        assertEquals("0: A process error has occurred.", ErrorCode.PROCESS.toString());
        assertEquals("1: A validation error has occurred.", ErrorCode.VALIDATION.toString());
        assertEquals("3: An out of retries error has occurred.", ErrorCode.OUT_OF_RETRIES.toString());
        assertEquals("41: Message Service Rest Api Error", ErrorCode.REST_API_ERROR.toString());
    }
}