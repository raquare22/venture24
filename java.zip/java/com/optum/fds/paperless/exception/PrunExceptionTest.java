package com.optum.fds.paperless.exception;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class PrunExceptionTest {

    @Test
    public void testConstructorWithErrorCode() {
        ErrorCode errorCode = ErrorCode.AUTHORIZATION_INITIALIZE;
        PrunException exception = new PrunException(errorCode);
        assertEquals(errorCode, exception.getCode());
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithStringThrowableAndErrorCode() {
        String message = "Test message";
        Throwable cause = new Throwable("Cause message");
        ErrorCode errorCode = ErrorCode.AUTHORIZATION_INITIALIZE;
        PrunException exception = new PrunException(message, cause, errorCode);
        assertEquals(message, exception.getMessage());
        assertSame(cause, exception.getCause());
        assertEquals(errorCode, exception.getCode());
    }

    @Test
    public void testConstructorWithStringAndErrorCode() {
        String message = "Test message";
        ErrorCode errorCode = ErrorCode.AUTHORIZATION_INITIALIZE;
        PrunException exception = new PrunException(message, errorCode);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
        assertEquals(errorCode, exception.getCode());
    }

    @Test
    public void testConstructorWithThrowableAndErrorCode() {
        Throwable cause = new Throwable("Cause message");
        ErrorCode errorCode = ErrorCode.AUTHORIZATION_INITIALIZE;
        PrunException exception = new PrunException(cause, errorCode);
        assertEquals(cause.toString(), exception.getMessage());
        assertSame(cause, exception.getCause());
        assertEquals(errorCode, exception.getCode());
    }
}