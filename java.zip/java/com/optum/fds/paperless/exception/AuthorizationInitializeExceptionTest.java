package com.optum.fds.paperless.exception;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class AuthorizationInitializeExceptionTest {

    @Test
    public void testConstructorWithNoArgs() {
        AuthorizationInitializeException exception = new AuthorizationInitializeException();
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithString() {
        String message = "Test message";
        AuthorizationInitializeException exception = new AuthorizationInitializeException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithStringAndThrowable() {
        String message = "Test message";
        Throwable cause = new Throwable("Cause message");
        AuthorizationInitializeException exception = new AuthorizationInitializeException(message, cause);
        assertEquals(message, exception.getMessage());
        assertSame(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithThrowable() {
        Throwable cause = new Throwable("Cause message");
        AuthorizationInitializeException exception = new AuthorizationInitializeException(cause);
        assertEquals(cause.toString(), exception.getMessage());
        assertSame(cause, exception.getCause());
    }
}