package com.optum.fds.paperless.exception;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class ValidationExceptionTest {

    @Test
    public void testConstructorWithNoArgs() {
        ValidationException exception = new ValidationException();
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithString() {
        String message = "Test message";
        ValidationException exception = new ValidationException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithStringAndThrowable() {
        String message = "Test message";
        Throwable cause = new Throwable("Cause message");
        ValidationException exception = new ValidationException(message, cause);
        assertEquals(message, exception.getMessage());
        assertSame(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithThrowable() {
        Throwable cause = new Throwable("Cause message");
        ValidationException exception = new ValidationException(cause);
        assertEquals(cause.toString(), exception.getMessage());
        assertSame(cause, exception.getCause());
    }
}