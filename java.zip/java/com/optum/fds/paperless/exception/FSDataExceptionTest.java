package com.optum.fds.paperless.exception;

import static org.junit.Assert.*;
import org.junit.Test;

public class FSDataExceptionTest {

    @Test
    public void testConstructorWithString() {
        String message = "Test message";
        FSDataException exception = new FSDataException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithStringAndThrowable() {
        String message = "Test message";
        Throwable cause = new Throwable("Cause message");
        FSDataException exception = new FSDataException(message, cause);
        assertEquals(message, exception.getMessage());
        assertSame(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithThrowable() {
        Throwable cause = new Throwable("Cause message");
        FSDataException exception = new FSDataException(cause);
        assertEquals(cause.toString(), exception.getMessage());
        assertSame(cause, exception.getCause());
    }
}