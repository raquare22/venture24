package com.optum.fds.paperless.exception;

import static org.junit.Assert.*;
import org.junit.Test;

public class MongoDBApiExceptionTest {

    @Test
    public void testConstructorWithString() {
        String message = "Test message";
        MongoDBApiException exception = new MongoDBApiException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithStringAndThrowable() {
        String message = "Test message";
        Throwable cause = new Throwable("Cause message");
        MongoDBApiException exception = new MongoDBApiException(message, cause);
        assertEquals(message, exception.getMessage());
        assertSame(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithThrowable() {
        Throwable cause = new Throwable("Cause message");
        MongoDBApiException exception = new MongoDBApiException(cause);
        assertEquals(cause.toString(), exception.getMessage());
        assertSame(cause, exception.getCause());
    }
}