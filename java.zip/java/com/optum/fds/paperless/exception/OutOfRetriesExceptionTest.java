package com.optum.fds.paperless.exception;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class OutOfRetriesExceptionTest {

    @Test
    public void testConstructorWithNoArgs() {
        OutOfRetriesException exception = new OutOfRetriesException();
        assertNull(exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithString() {
        String message = "Test message";
        OutOfRetriesException exception = new OutOfRetriesException(message);
        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testConstructorWithStringAndThrowable() {
        String message = "Test message";
        Throwable cause = new Throwable("Cause message");
        OutOfRetriesException exception = new OutOfRetriesException(message, cause);
        assertEquals(message, exception.getMessage());
        assertSame(cause, exception.getCause());
    }

    @Test
    public void testConstructorWithThrowable() {
        Throwable cause = new Throwable("Cause message");
        OutOfRetriesException exception = new OutOfRetriesException(cause);
        assertEquals(cause.toString(), exception.getMessage());
        assertSame(cause, exception.getCause());
    }
}