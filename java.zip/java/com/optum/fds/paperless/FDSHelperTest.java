package com.optum.fds.paperless;

import com.optum.fds.paperless.constants.ProcessKeys;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.ProcessEngine;
import org.flowable.engine.ProcessEngines;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.engine.runtime.ProcessInstanceBuilder;
import org.junit.Test;
import org.mockito.MockedStatic;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertSame;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class FDSHelperTest {

    @Test
    public void runProcess_withMap_startsProcessInstance() {
        ProcessEngine processEngine = mock(ProcessEngine.class);
        RuntimeService runtimeService = mock(RuntimeService.class);
        ProcessInstanceBuilder builder = mock(ProcessInstanceBuilder.class);
        ProcessInstance processInstance = mock(ProcessInstance.class);
        Map<String, Object> variables = new HashMap<String, Object>();

        try (MockedStatic<ProcessEngines> engines = mockStatic(ProcessEngines.class)) {
            engines.when(ProcessEngines::getDefaultProcessEngine).thenReturn(processEngine);

            when(processEngine.getRuntimeService()).thenReturn(runtimeService);
            when(runtimeService.createProcessInstanceBuilder()).thenReturn(builder);
            when(builder.processDefinitionKey("proc")).thenReturn(builder);
            when(builder.transientVariables(variables)).thenReturn(builder);
            when(builder.start()).thenReturn(processInstance);

            ProcessInstance result = FDSHelper.runProcess("proc", variables);
            assertSame(processInstance, result);
        }
    }

    @Test
    public void fileUnzipRunProcess_startsProcessInstanceByKey() {
        ProcessEngine processEngine = mock(ProcessEngine.class);
        RuntimeService runtimeService = mock(RuntimeService.class);
        ProcessInstance processInstance = mock(ProcessInstance.class);
        Map<String, Object> variables = new HashMap<String, Object>();

        try (MockedStatic<ProcessEngines> engines = mockStatic(ProcessEngines.class)) {
            engines.when(ProcessEngines::getDefaultProcessEngine).thenReturn(processEngine);
            when(processEngine.getRuntimeService()).thenReturn(runtimeService);
            when(runtimeService.startProcessInstanceByKey("proc", variables)).thenReturn(processInstance);

            ProcessInstance result = FDSHelper.fileUnziprunProcess("proc", variables);
            assertSame(processInstance, result);
        }
    }

    @Test
    public void runProcess_overloads_andConfig_delegateToRunProcessMap() throws Exception {
        ProcessInstance processInstance = mock(ProcessInstance.class);
        Map<String, Object> variables = new HashMap<String, Object>();
        GenericResponse response = new GenericResponse();
        ProcessorMetaData processorMetaData = new ProcessorMetaData();

        try (MockedStatic<FDSHelper> helper = mockStatic(FDSHelper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> FDSHelper.runProcess(eq("proc"), anyMap())).thenReturn(processInstance);

            assertSame(processInstance, FDSHelper.sftpRunProcess("proc", "{\"a\":1}"));
            assertSame(processInstance, FDSHelper.zipFileRunProcess("proc", "{\"a\":1}", "app", "processor"));
            assertSame(processInstance, FDSHelper.runProcess("proc", "{\"a\":1}", "{\"b\":2}"));
            assertSame(processInstance, FDSHelper.runProcess("proc", variables, response));
            assertSame(processInstance, FDSHelper.runProcessConfig("proc", "{\"a\":1}"));
            assertSame(processInstance, FDSHelper.runProcess("proc", processorMetaData));

            helper.verify(() -> FDSHelper.runProcess(eq("proc"), anyMap()), times(6));
        }
    }

    @Test
    public void processTextAndSftpMethods_success_paths_delegateToFlowableStart() throws Exception {
        ProcessorMetaData processorMetaData = buildProcessorMetaDataWithConfig("proc");
        Map<String, Object> tx = new HashMap<>();
        tx.put(Workflow.FILE_NAME, "a.txt");
        tx.put(Workflow.LOCATION, "C:/tmp");
        tx.put("id", "id-1");

        ProcessEngine processEngine = mock(ProcessEngine.class);
        RuntimeService runtimeService = mock(RuntimeService.class);
        ProcessInstanceBuilder builder = mock(ProcessInstanceBuilder.class);
        ProcessInstance pi = mock(ProcessInstance.class);

        try (MockedStatic<ProcessEngines> engines = mockStatic(ProcessEngines.class)) {
            engines.when(ProcessEngines::getDefaultProcessEngine).thenReturn(processEngine);

            when(processEngine.getRuntimeService()).thenReturn(runtimeService);
            when(runtimeService.createProcessInstanceBuilder()).thenReturn(builder);
            when(builder.processDefinitionKey(anyString())).thenReturn(builder);
            when(builder.transientVariables(anyMap())).thenReturn(builder);
            when(builder.start()).thenReturn(pi);

            FDSHelper.processTextFile(processorMetaData);
            FDSHelper.sftpConvertFileToDocument(processorMetaData);
            FDSHelper.sftpSendEmailProcess(processorMetaData);
            FDSHelper.realTimeAPISendEmailProcess(processorMetaData, tx);

            verify(builder, times(4)).start();
        }
    }

    private ProcessorMetaData buildProcessorMetaDataWithConfig(String processKey) {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();

        Map<String, Object> process = new HashMap<>();
        process.put(Workflow.PROCESS_KEY, processKey);

        Map<String, Object> config = new HashMap<>();
        config.put(Workflow.TEMPLATE_NAME, "template");
        config.put(Workflow.SPACE_ID, "space-1");
        config.put(Workflow.APP_IDENTIFIER, "app-1");
        config.put(Workflow.MATCH_CRITERIA, "criteria");
        config.put(Workflow.SEARCH_WINDOW, "window");
        config.put(Workflow.CLIENT_NAME, "client");
        config.put(Workflow.PES_APP_ID, "pes-id");
        config.put(Workflow.PES_APP_SECRET, "pes-secret");
        config.put(Workflow.PES_OAUTH_URL, "https://oauth");
        config.put(Workflow.PES_GRANT_TYPE, "client_credentials");
        config.put(Workflow.CATEGORY, "cat");
        config.put(Workflow.DOCLIB_PUT_URL, "https://doclib-put");
        config.put(Workflow.DOCLIB_OAUTH_URL, "https://doclib-oauth");
        config.put(Workflow.DOCLIB_CLIENT_ID, "doclib-id");
        config.put(Workflow.DOCLIB_CLIENT_SECRET, "doclib-secret");

        process.put("config", config);
        processorMetaData.setProcess(process);
        return processorMetaData;
    }

    @Test
    public void processTextAndSftpMethods_catch_paths_doNotThrow() throws Exception {
        ProcessorMetaData badMetaData = new ProcessorMetaData();

        FDSHelper.processTextFile(badMetaData);
        FDSHelper.sftpConvertFileToDocument(badMetaData);
        FDSHelper.sftpSendEmailProcess(badMetaData);
        FDSHelper.realTimeAPISendEmailProcess(badMetaData, new HashMap<String, Object>());
    }

    @Test
    public void retrieveAndSendEmailProcess_ifAndElseAndCatch() throws IOException {
        try (MockedStatic<FDSHelper> helper = mockStatic(FDSHelper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.RETRIEVE_AND_SEND_EMAIL_PROCESS), anyMap())).thenReturn(mock(ProcessInstance.class));

            Map<String, Object> yesVars = buildHookVariables(ProcessKeys.RETRIEVE_AND_SEND_EMAIL_PROCESS);
            FDSHelper.retrieveAndSendEmailProcess(yesVars);
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.RETRIEVE_AND_SEND_EMAIL_PROCESS), anyMap()), times(1));

            Map<String, Object> noVars = buildHookVariables("otherProcess");
            FDSHelper.retrieveAndSendEmailProcess(noVars);
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.RETRIEVE_AND_SEND_EMAIL_PROCESS), anyMap()), times(1));
        }

        FDSHelper.retrieveAndSendEmailProcess(new HashMap<String, Object>());
    }

    @Test
    public void sendBatchDynamicEmailRequestToPEN_ifAndElseAndCatch() throws IOException {
        try (MockedStatic<FDSHelper> helper = mockStatic(FDSHelper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.SEND_BATCH_DYNAMIC_REQUEST_TO_PEN), anyMap())).thenReturn(mock(ProcessInstance.class));

            FDSHelper.sendBatchDynamicEmailRequestToPEN(buildHookVariables(ProcessKeys.SEND_BATCH_DYNAMIC_REQUEST_TO_PEN));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.SEND_BATCH_DYNAMIC_REQUEST_TO_PEN), anyMap()), times(1));

            FDSHelper.sendBatchDynamicEmailRequestToPEN(buildHookVariables("differentProcess"));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.SEND_BATCH_DYNAMIC_REQUEST_TO_PEN), anyMap()), times(1));
        }

        FDSHelper.sendBatchDynamicEmailRequestToPEN(new HashMap<String, Object>());
    }

    @Test
    public void processRequiredFieldRule_ifAndElseAndCatch() throws IOException {
        try (MockedStatic<FDSHelper> helper = mockStatic(FDSHelper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.REQUIRED_FIELD_RULE_PROCESS_KEY), anyMap())).thenReturn(mock(ProcessInstance.class));

            Map<String, Object> yesVars = buildHookVariables("unused");
            Map<String, Object> requiredCfg = new HashMap<String, Object>();
            requiredCfg.put(Workflow.PROCESS_KEY, ProcessKeys.REQUIRED_FIELD_RULE_PROCESS_KEY);
            List<Map<String, Object>> rules = new ArrayList<Map<String, Object>>();
            Map<String, Object> rule = new HashMap<String, Object>();
            rule.put("path", "a");
            rules.add(rule);
            requiredCfg.put(Workflow.RULES, rules);
            ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) yesVars.get("hook")).get("action")).get("config")).put("requiredFieldRule", requiredCfg);
            FDSHelper.processRequiredFieldRule(yesVars);
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.REQUIRED_FIELD_RULE_PROCESS_KEY), anyMap()), times(1));

            Map<String, Object> noVars = buildHookVariables("unused");
            Map<String, Object> noCfg = new HashMap<String, Object>();
            noCfg.put(Workflow.PROCESS_KEY, "nope");
            ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) noVars.get("hook")).get("action")).get("config")).put("requiredFieldRule", noCfg);
            FDSHelper.processRequiredFieldRule(noVars);
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.REQUIRED_FIELD_RULE_PROCESS_KEY), anyMap()), times(1));
        }

        FDSHelper.processRequiredFieldRule(new HashMap<String, Object>());
    }

    @Test
    public void retrieveProviderEmailAddress_ifAndElseAndCatch() throws IOException {
        try (MockedStatic<FDSHelper> helper = mockStatic(FDSHelper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.RETRIEVE_PROVIDER_EMAIL_PROCESS_KEY), anyMap())).thenReturn(mock(ProcessInstance.class));

            Map<String, Object> yesVars = buildHookVariables("unused");
            Map<String, Object> providerCfg = new HashMap<String, Object>();
            providerCfg.put(Workflow.PROCESS_KEY, ProcessKeys.RETRIEVE_PROVIDER_EMAIL_PROCESS_KEY);
            ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) yesVars.get("hook")).get("action")).get("config")).put("providerEmailAddress", providerCfg);
            FDSHelper.retrieveProviderEmailAddress(yesVars);
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.RETRIEVE_PROVIDER_EMAIL_PROCESS_KEY), anyMap()), times(1));

            Map<String, Object> noVars = buildHookVariables("unused");
            Map<String, Object> noCfg = new HashMap<String, Object>();
            noCfg.put(Workflow.PROCESS_KEY, "other");
            ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) noVars.get("hook")).get("action")).get("config")).put("providerEmailAddress", noCfg);
            FDSHelper.retrieveProviderEmailAddress(noVars);
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.RETRIEVE_PROVIDER_EMAIL_PROCESS_KEY), anyMap()), times(1));
        }

        FDSHelper.retrieveProviderEmailAddress(new HashMap<String, Object>());
    }

    @Test
    public void responseAndMetadataMethods_delegateToRunProcess() throws Exception {
        try (MockedStatic<FDSHelper> helper = mockStatic(FDSHelper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.RESPONSEFILE_PROCESS_KEY), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.RESPONSE_MESSAGE_PROCESS_KEY), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.PROCESS_CONVERT_METADATA), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.RESPONSEFILE_PROCESS_KEY_USP_CLAIMS), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.RETRIEVE_AND_SEND_METADATA_PROCESS), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.STATUSFILE_PROCESS_KEY), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq("cleanup"), anyMap())).thenReturn(mock(ProcessInstance.class));

            Map<String, Object> vars = buildHookVariables("unused");
            FDSHelper.responseFileProcess(vars);
            FDSHelper.responseMessageProcess(vars);
            FDSHelper.convertMetadataProcess(vars);
            FDSHelper.responseFileProcessUSPClaims(vars);
            FDSHelper.retrieveAndCreateMetadataFilesProcess(vars);
            FDSHelper.createStatusFileAndAckProcess(vars);
            FDSHelper.processCleanUp("cleanup", "tx-1", "app");

            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.RESPONSEFILE_PROCESS_KEY), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.RESPONSE_MESSAGE_PROCESS_KEY), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.PROCESS_CONVERT_METADATA), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.RESPONSEFILE_PROCESS_KEY_USP_CLAIMS), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.RETRIEVE_AND_SEND_METADATA_PROCESS), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.STATUSFILE_PROCESS_KEY), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq("cleanup"), anyMap()), times(1));
        }
    }

    @Test
    public void postProviderShutterflyAndOtherWorkflows_delegateToRunProcess() {
        try (MockedStatic<FDSHelper> helper = mockStatic(FDSHelper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> FDSHelper.runProcess(eq("postDocumentDocvaultForElgsProcess"), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq("providerEmailNotificationProcess"), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.BOUNCE_PROCESS_KEY), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.STORAGE_ERROR_SHUTTERFLY_PROCESS_KEY), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.SHUTTERFLY_PROCESS_KEY), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.MATCH_AND_MERGE_PROCESS_KEY), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.EMAIL_PROCESSOR_TRANSACTION_METADATA_PROCESS_KEY), anyMap())).thenReturn(mock(ProcessInstance.class));
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.UPDATE_DOCS_WITH_SECONDARY_EMAIL_PROCESS_KEY), anyMap())).thenReturn(mock(ProcessInstance.class));

            Map<String, Object> vars = buildHookVariables("unused");
            FDSHelper.postDocumentDocLibForELGSProcess(vars);
            FDSHelper.providerEmailNotificationProcess(vars);
            FDSHelper.storageErrorShutterflyWorkflow(vars);
            FDSHelper.shutterflyWorkflow(vars);
            FDSHelper.matchAndMergeWorkflow(vars);
            FDSHelper.emailProcessorTransactionMetadataWorkflow(vars);
            FDSHelper.updateDocsWithSecondaryEmailWorkflow(vars);

            Map<String, Object> bounceVars = buildBounceVariables();
            FDSHelper.bounceEmailWorkflow(bounceVars);

            helper.verify(() -> FDSHelper.runProcess(eq("postDocumentDocvaultForElgsProcess"), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq("providerEmailNotificationProcess"), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.BOUNCE_PROCESS_KEY), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.STORAGE_ERROR_SHUTTERFLY_PROCESS_KEY), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.SHUTTERFLY_PROCESS_KEY), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.MATCH_AND_MERGE_PROCESS_KEY), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.EMAIL_PROCESSOR_TRANSACTION_METADATA_PROCESS_KEY), anyMap()), times(1));
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.UPDATE_DOCS_WITH_SECONDARY_EMAIL_PROCESS_KEY), anyMap()), times(1));
        }
    }

    @Test
    public void corpMPIN_ifAndElseAndCatch() {
        try (MockedStatic<FDSHelper> helper = mockStatic(FDSHelper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> FDSHelper.runProcess(eq(ProcessKeys.RETRIEVE_CORPORATE_MPIN_PROCESS_KEY), anyMap())).thenReturn(mock(ProcessInstance.class));

            Map<String, Object> yesVars = buildHookVariables("unused");
            Map<String, Object> corpCfg = new HashMap<String, Object>();
            corpCfg.put(Workflow.PROCESS_KEY, ProcessKeys.RETRIEVE_CORPORATE_MPIN_PROCESS_KEY);
            ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) yesVars.get("hook")).get("action")).get("config")).put("corporateMPIN", corpCfg);
            FDSHelper.corpMPIN(yesVars);
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.RETRIEVE_CORPORATE_MPIN_PROCESS_KEY), anyMap()), times(1));

            Map<String, Object> noVars = buildHookVariables("unused");
            Map<String, Object> noCfg = new HashMap<String, Object>();
            noCfg.put(Workflow.PROCESS_KEY, "no");
            ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) noVars.get("hook")).get("action")).get("config")).put("corporateMPIN", noCfg);
            FDSHelper.corpMPIN(noVars);
            helper.verify(() -> FDSHelper.runProcess(eq(ProcessKeys.RETRIEVE_CORPORATE_MPIN_PROCESS_KEY), anyMap()), times(1));
        }

        FDSHelper.corpMPIN(new HashMap<String, Object>());
    }

    @Test
    public void retrieveCorporateMPINv2Process_directCall_verifiesBasedOnConstant() {
        try (MockedStatic<FDSHelper> helper = mockStatic(FDSHelper.class, CALLS_REAL_METHODS)) {
            helper.when(() -> FDSHelper.runProcess(eq("retrieveCorporateMPINv2Process"), anyMap()))
                    .thenReturn(mock(ProcessInstance.class));

            FDSHelper.retrieveCorporateMPINv2Process(buildHookVariables("unused"));

            if (ProcessKeys.RETRIEVE_CORPORATE_MPIN_PROCESS_KEY
                    .equalsIgnoreCase("retrieveCorporateMPINv2Process")) {
                helper.verify(() -> FDSHelper.runProcess(eq("retrieveCorporateMPINv2Process"), anyMap()), times(1));
            } else {
                helper.verify(() -> FDSHelper.runProcess(eq("retrieveCorporateMPINv2Process"), anyMap()), never());
            }
        }
    }

    private ProcessorMetaData buildProcessorMetaData(String processKey) {
        ProcessorMetaData processorMetaData = new ProcessorMetaData();
        Map<String, Object> process = new HashMap<String, Object>();
        process.put(Workflow.PROCESS_KEY, processKey);
        processorMetaData.setProcess(process);
        return processorMetaData;
    }

    private Map<String, Object> buildHookVariables(String processKey) {
        Map<String, Object> config = new HashMap<String, Object>();
        config.put(Workflow.PROCESS_KEY, processKey);
        config.put(Workflow.RULES, new ArrayList<Object>());

        Map<String, Object> action = new HashMap<String, Object>();
        action.put("config", config);

        Map<String, Object> hook = new HashMap<String, Object>();
        hook.put("action", action);

        Map<String, Object> variables = new HashMap<String, Object>();
        variables.put("id", "hook-1");
        variables.put("docId", "doc-1");
        variables.put(Workflow.DOCID, "doc-1");
        variables.put(Workflow.SPACE_ID, "space-1");
        variables.put(Workflow.APP_IDENTIFIER, "app-1");
        variables.put(Workflow.CLIENTID, "client-1");
        variables.put("clientId", "client-1");
        variables.put("hook", hook);
        return variables;
    }

    private Map<String, Object> buildBounceVariables() {
        Map<String, Object> config = new HashMap<String, Object>();
        Map<String, Object> action = new HashMap<String, Object>();
        action.put("config", config);
        Map<String, Object> innerHook = new HashMap<String, Object>();
        innerHook.put("action", action);

        Map<String, Object> bounceHook = new HashMap<String, Object>();
        bounceHook.put("id", "hook-1");
        bounceHook.put(Workflow.CLIENTID, "client-1");
        bounceHook.put("hook", innerHook);

        Map<String, Object> variables = new HashMap<String, Object>();
        variables.put("hook", bounceHook);
        variables.put("document", new HashMap<String, Object>());
        return variables;
    }
}