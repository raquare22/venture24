package com.optum.fds.paperless.kafka;

import static org.mockito.Mockito.*;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.kafka.core.KafkaTemplate;

public class KafkaProducerTest {

    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;

    @InjectMocks
    private KafkaProducer kafkaProducer;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testSend() {
        String message = "testMessage";
        String topicName = "testTopic";

        kafkaProducer.send(message, topicName);

        verify(kafkaTemplate, times(1)).send(topicName, message);
    }

    @Test
    public void testSend_Success() {
        String message = "testMessage";
        String topicName = "testTopic";

        kafkaProducer.send(message, topicName);

        verify(kafkaTemplate, times(1)).send(topicName, message);
    }

    @Test
    public void testSend_NullMessage_ThrowsIllegalArgumentException() {
        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> kafkaProducer.send(null, "testTopic")
        );

        assertEquals("KafkaProducer --> Message cannot be null or empty", ex.getMessage());
        verify(kafkaTemplate, never()).send(anyString(), anyString());
    }

    @Test
    public void testSend_EmptyMessage_ThrowsIllegalArgumentException() {
        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> kafkaProducer.send("", "testTopic")
        );

        assertEquals("KafkaProducer --> Message cannot be null or empty", ex.getMessage());
        verify(kafkaTemplate, never()).send(anyString(), anyString());
    }

    @Test
    public void testSend_NullTopic_ThrowsIllegalArgumentException() {
        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> kafkaProducer.send("testMessage", null)
        );

        assertEquals("KafkaProducer --> Topic name cannot be null or empty", ex.getMessage());
        verify(kafkaTemplate, never()).send(anyString(), anyString());
    }

    @Test
    public void testSend_EmptyTopic_ThrowsIllegalArgumentException() {
        IllegalArgumentException ex = assertThrows(
                IllegalArgumentException.class,
                () -> kafkaProducer.send("testMessage", "")
        );

        assertEquals("KafkaProducer --> Topic name cannot be null or empty", ex.getMessage());
        verify(kafkaTemplate, never()).send(anyString(), anyString());
    }

    @Test
    public void testSend_KafkaTemplateThrows_WrapsInRuntimeException() {
        String message = "testMessage";
        String topicName = "testTopic";
        RuntimeException kafkaError = new RuntimeException("broker down");

        doThrow(kafkaError).when(kafkaTemplate).send(topicName, message);

        RuntimeException ex = assertThrows(
                RuntimeException.class,
                () -> kafkaProducer.send(message, topicName)
        );

        assertEquals("Failed to send message to Kafka topic", ex.getMessage());
        assertSame(kafkaError, ex.getCause());
        verify(kafkaTemplate, times(1)).send(topicName, message);
    }

//    @Test
//    public void testSend_KafkaTemplateThrows_WrapsInRuntimeException() {
//        String message = "testMessage";
//        String topicName = "testTopic";
//        RuntimeException kafkaError = new RuntimeException("broker down");
//
//        doThrow(kafkaError).when(kafkaTemplate).send(topicName, message);
//
//        RuntimeException ex = assertThrows(
//                RuntimeException.class,
//                () -> kafkaProducer.send(message, topicName)
//        );
//
//        assertEquals("Failed to send message to Kafka topic", ex.getMessage());
//        assertSame(kafkaError, ex.getCause());
//        verify(kafkaTemplate, times(1)).send(topicName, message);
//    }
}