package com.optum.fds.paperless.kafka.consumer.model;

import static org.junit.Assert.*;
import org.junit.Test;

public class MemberInfoTest {

    @Test
    public void testGettersAndSetters() {
        MemberInfo memberInfo = new MemberInfo();

        RequestingMember requestingMember = new RequestingMember();
        RequestedMember requestedMember = new RequestedMember();

        memberInfo.setRequestingMember(requestingMember);
        memberInfo.setRequestedMember(requestedMember);

        assertEquals(requestingMember, memberInfo.getRequestingMember());
        assertEquals(requestedMember, memberInfo.getRequestedMember());
    }

    @Test
    public void testDefaultValues() {
        MemberInfo memberInfo = new MemberInfo();

        assertNull(memberInfo.getRequestingMember());
        assertNull(memberInfo.getRequestedMember());
    }
}