package com.optum.fds.paperless.kafka.consumer.model;

import static org.junit.Assert.*;
import org.junit.Test;

public class ProviderDetailsTest {

    @Test
    public void testGettersAndSetters() {
        ProviderDetails details = new ProviderDetails();

        details.setPrimaryCareProviderFirstName("John");
        details.setPrimaryCareProviderLastName("Doe");
        details.setPrimaryCareProviderCorpMpin("M123");
        details.setPrimaryCareProviderTin("TIN123");
        details.setReferredToProviderFirstName("Jane");
        details.setReferredToProviderLastName("Smith");
        details.setReferredToProviderTin("TIN456");
        details.setReferredToProviderCorpMpin("M456");
        details.setReferredToProviderId("ID789");

        assertEquals("John", details.getPrimaryCareProviderFirstName());
        assertEquals("Doe", details.getPrimaryCareProviderLastName());
        assertEquals("M123", details.getPrimaryCareProviderCorpMpin());
        assertEquals("TIN123", details.getPrimaryCareProviderTin());
        assertEquals("Jane", details.getReferredToProviderFirstName());
        assertEquals("Smith", details.getReferredToProviderLastName());
        assertEquals("TIN456", details.getReferredToProviderTin());
        assertEquals("M456", details.getReferredToProviderCorpMpin());
        assertEquals("ID789", details.getReferredToProviderId());
    }

    @Test
    public void testDefaultValues() {
        ProviderDetails details = new ProviderDetails();

        assertNull(details.getPrimaryCareProviderFirstName());
        assertNull(details.getPrimaryCareProviderLastName());
        assertNull(details.getPrimaryCareProviderCorpMpin());
        assertNull(details.getPrimaryCareProviderTin());
        assertNull(details.getReferredToProviderFirstName());
        assertNull(details.getReferredToProviderLastName());
        assertNull(details.getReferredToProviderTin());
        assertNull(details.getReferredToProviderCorpMpin());
        assertNull(details.getReferredToProviderId());
    }
}