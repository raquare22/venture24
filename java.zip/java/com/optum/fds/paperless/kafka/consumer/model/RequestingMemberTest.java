package com.optum.fds.paperless.kafka.consumer.model;

import static org.junit.Assert.*;
import org.junit.Test;

public class RequestingMemberTest {

    @Test
    public void testGettersAndSetters() {
        RequestingMember member = new RequestingMember();
        member.setMemberIdCardNbr("123");
        member.setFirstName("John");
        member.setLastName("Doe");
        member.setDob("2000-01-01");
        member.setGroupNumber("G123");
        member.setDependentSeqNbr("01");

        assertEquals("123", member.getMemberIdCardNbr());
        assertEquals("John", member.getFirstName());
        assertEquals("Doe", member.getLastName());
        assertEquals("2000-01-01", member.getDob());
        assertEquals("G123", member.getGroupNumber());
        assertEquals("01", member.getDependentSeqNbr());
    }

    @Test
    public void testDefaultValues() {
        RequestingMember member = new RequestingMember();
        assertNull(member.getMemberIdCardNbr());
        assertNull(member.getFirstName());
        assertNull(member.getLastName());
        assertNull(member.getDob());
        assertNull(member.getGroupNumber());
        assertNull(member.getDependentSeqNbr());
    }
}