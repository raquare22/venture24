package com.optum.fds.paperless.kafka.consumer.model;

import static org.junit.Assert.*;
import org.junit.Test;

public class RequestedMemberTest {

    @Test
    public void testGettersAndSetters() {
        RequestedMember member = new RequestedMember();
        member.setMemberIdCardNbr("456");
        member.setFirstName("Jane");
        member.setLastName("Smith");
        member.setDob("1990-12-31");
        member.setGroupNumber("G456");

        assertEquals("456", member.getMemberIdCardNbr());
        assertEquals("Jane", member.getFirstName());
        assertEquals("Smith", member.getLastName());
        assertEquals("1990-12-31", member.getDob());
        assertEquals("G456", member.getGroupNumber());
    }

    @Test
    public void testDefaultValues() {
        RequestedMember member = new RequestedMember();
        assertNull(member.getMemberIdCardNbr());
        assertNull(member.getFirstName());
        assertNull(member.getLastName());
        assertNull(member.getDob());
        assertNull(member.getGroupNumber());
    }
}