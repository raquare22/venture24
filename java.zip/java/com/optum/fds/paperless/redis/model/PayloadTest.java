package com.optum.fds.paperless.redis.model;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.optum.fds.paperless.model.GenericResponse;

public class PayloadTest {

    private Payload payload;
    private String jsonStr;

    @Before
    public void setUp() {
        jsonStr = "{\"key\":\"testKey\",\"url\":[\"http://test.com\"],\"delegate\":[\"testDelegate\"],\"request\":[\"testRequest\"],\"response\":{\"statusCode\":\"200\",\"statusMessage\":\"OK\",\"responseMsg\":{\"message\":\"Success\"}},\"callbackMap\":[{\"callbackKey\":\"callbackValue\"}]}";
        payload = new Payload(jsonStr);
    }

    @Test
    public void testGetKey() {
        assertEquals("testKey", payload.getKey());
    }

    @Test
    public void testSetKey() {
        payload.setKey("newKey");
        assertEquals("newKey", payload.getKey());
    }

    @Test
    public void testGetUrl() {
        assertEquals("http://test.com", payload.getUrl());
    }

    @Test
    public void testSetUrl() {
        payload.setUrl("http://newurl.com");
        assertEquals("http://newurl.com", payload.getUrl());
    }

    @Test
    public void testGetDelegate() {
        assertEquals("testDelegate", payload.getDelegate());
    }

    @Test
    public void testSetDelegate() {
        payload.setDelegate("newDelegate");
        assertEquals("newDelegate", payload.getDelegate());
    }

    @Test
    public void testGetRequest() {
        assertEquals("testRequest", payload.getRequest());
    }

    @Test
    public void testSetRequest() {
        payload.setRequest("newRequest");
        assertEquals("newRequest", payload.getRequest());
    }

    @Test
    public void testGetResponse() {
        Map<?, ?> response = payload.getResponse();
        assertNotNull(response);
        assertEquals("200", response.get("statusCode"));
        assertEquals("OK", response.get("statusMessage"));
    }

    @Test
    public void testSetResponse() {
        Map<String, String> newResponse = new HashMap<>();
        newResponse.put("statusCode", "404");
        newResponse.put("statusMessage", "Not Found");
        payload.setResponse(newResponse);
        assertEquals(newResponse, payload.getResponse());
    }

    @Test
    public void testGetGenericResponse() {
//        GenericResponse genericResponse = payload.getGenericResponse();
//        assertNotNull(genericResponse);
//        assertEquals("200", genericResponse.getStatusCode());
//        assertEquals("OK", genericResponse.getStatusMessage());
//        assertEquals("{\"message\":\"Success\"}", genericResponse.getResponseMessage()); // Updated method name
    }

    @Test
    public void testConvert() {
        String newJsonStr = "{\"key\":\"newKey\",\"url\":[\"http://newurl.com\"],\"delegate\":[\"newDelegate\"],\"request\":[\"newRequest\"],\"response\":{\"statusCode\":\"404\",\"statusMessage\":\"Not Found\",\"responseMsg\":\"Error\"},\"callbackMap\":[{\"callbackKey\":\"newCallbackValue\"}]}";
        payload.convert(newJsonStr, true);
        assertEquals("newKey", payload.getKey());
        assertEquals("http://newurl.com", payload.getUrl());
        assertEquals("newDelegate", payload.getDelegate());
        assertEquals("newRequest", payload.getRequest());
        Map<?, ?> response = payload.getResponse();
        assertNotNull(response);
        assertEquals("404", response.get("statusCode"));
        assertEquals("Not Found", response.get("statusMessage"));
    }

    @Test
    public void testGetCallback() {
        Map<?, ?> callback = payload.getCallback();
        assertNotNull(callback);
        assertEquals("callbackValue", callback.get("callbackKey"));
    }

    @Test
    public void testSetCallback() {
        Map<String, String> newCallback = new HashMap<>();
        newCallback.put("newCallbackKey", "newCallbackValue");
        payload.setCallback(newCallback);
        assertEquals(newCallback, payload.getCallback());
    }

    @Test
    public void testGetJsonStr() {
        assertEquals(jsonStr, payload.getJsonStr());
    }

    @Test
    public void testToString() {
        String expectedString = "Packet [key=testKey, url=http://test.com, delegate=testDelegate, request=testRequest, callback={callbackKey=callbackValue}, jsonStr=" + jsonStr + "]";
        assertEquals(expectedString, payload.toString());
    }
}