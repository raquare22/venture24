package com.optum.fs.workflow.java.delegate.common;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;


import org.flowable.engine.delegate.DelegateExecution;
import org.bson.Document;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.client.RestTemplate;

import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fs.workflow.java.delegate.bean.DelegateExecutionImpl;

@RunWith(MockitoJUnitRunner.class)
public class DelegateUtilsTest {
	@Mock
	EmailService emailService;

	@InjectMocks
	DelegateUtils delegateUtils;

	@Mock
	RestTemplate restTemplate;

	DelegateExecution execution;

	@Test
	public void testAddDocumentIdInErrors() throws Exception {
		DelegateUtils utils = new DelegateUtils();
		DelegateExecution execution = new DelegateExecutionImpl();
		DocumentMetaData documentMetaData = new DocumentMetaData();
		documentMetaData.setId("Test");
		execution.setVariable(Workflow.DOCUMENT, documentMetaData);
		DelegateUtils.addDocumentIdInErrors(execution);

	}

	@Test
	public void testAddDocumentIdInErrorsNew() throws Exception {
		String expected = "";
		String result = "";
		DelegateExecution execution = new DelegateExecutionImpl();
		DocumentMetaData documentMetaData = new DocumentMetaData();
		documentMetaData.setId("Test");
		execution.setVariable(Workflow.DOCUMENT, documentMetaData);

		if (execution.getVariable(Workflow.DOCUMENT, DocumentMetaData.class) != null) {
			result = "testResult";
			expected = "testResult";
		} else {
			result = "";
		}

		assertEquals(expected, result);

	}

	@Test
	public void testGenerateMessageforCronExpressionHookWorkflow() throws Exception {
		DelegateExecution execution = new DelegateExecutionImpl();
		DocumentMetaData documentMetaData = new DocumentMetaData();
		documentMetaData.setId("Test");
		execution.setVariable(Workflow.DOCUMENT, documentMetaData);
		execution.setVariable(Workflow.HOOK_EXECUTION_ID, "Test");
		DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution);

	}

	@Test
	public void testSendErrorNotification() throws Exception {
		DelegateExecution execution = new DelegateExecutionImpl();
		Map<String, Object> errorMap = new HashMap<>();
		when(emailService.sendEmail(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		DocumentMetaData documentMetaData = new DocumentMetaData();
		documentMetaData.setId("Test");
		execution.setVariable(Workflow.EMAIL_RECEIVER, "test");
		execution.setVariable(Workflow.ENVIRONMENT, "Test");
		DelegateUtils.sendErrorNotification(execution, errorMap, "Test", emailService);

	}

	@Test
	public void testtestAddDocumentIdInErrorsnew2() {

//		DelegateExecution execution = Mockito.mock(DelegateExecution.class);
//		when(execution.getVariable(Mockito.anyString())).thenReturn("sdsdsd");
//		DocumentMetaData documentMetaData = new DocumentMetaData();
//		documentMetaData.setId("Test");
//		execution.setVariable(Workflow.DOCUMENT, documentMetaData);

		execution = new DelegateExecutionImpl();
		DocumentMetaData value = getDocumentMetaData();
		value.setAppIdentifier("test");
		value.setClientId(122);
		execution.setVariable(Workflow.DOCUMENT, value);

		DelegateUtils.addDocumentIdInErrors(execution);

	}

	private DocumentMetaData getDocumentMetaData() {

		DocumentMetaData dmd = new DocumentMetaData();

		Document metadataObj = Document.parse("{ " +

				"\"tin\" : \"123\"," +

				"\"mpin\" : \"456\"," +

				"\"corporateMpin\" : \"789\"," +

				"\"providerEmailId\" : \"test@test.com\"," +

				"\"emailAlertReq\" : \"Y\"" +

				"\"sendToDocVault\" : false" +

				"\"sendToShutterfly\" : false" +

				"}");

		dmd.setMetadata(metadataObj);

		return dmd;

	}

}
