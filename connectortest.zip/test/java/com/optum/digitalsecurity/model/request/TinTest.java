package com.optum.digitalsecurity.model.request;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class TinTest {

    private Tin tin;

    @Before
    public void setUp() {
        tin = new Tin();
    }

    @Test
    public void testTinInstantiation() {
        // Verify that the Tin object is not null after instantiation
        assertNotNull(tin);
    }
}
