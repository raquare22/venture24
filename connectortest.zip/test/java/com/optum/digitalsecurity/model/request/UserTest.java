package com.optum.digitalsecurity.model.request;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class UserTest {

    private User user;

    @Before
    public void setUp() {
        user = new User();
    }

    @Test
    public void testGettersAndSetters() {
        // Test initial state
        assertNull(user.getUuid());
        assertNull(user.getOneHealthId());
        assertNull(user.getFirstName());
        assertNull(user.getLastName());
        assertNull(user.getEmail());

        // Set values
        user.setUuid("12345");
        user.setOneHealthId("OH123");
        user.setFirstName("John");
        user.setLastName("Doe");
        user.setEmail("john.doe@example.com");

        // Verify values
        assertEquals("12345", user.getUuid());
        assertEquals("OH123", user.getOneHealthId());
        assertEquals("John", user.getFirstName());
        assertEquals("Doe", user.getLastName());
        assertEquals("john.doe@example.com", user.getEmail());
    }

    @Test
    public void testToString() {
        user.setUuid("12345");
        user.setOneHealthId("OH123");
        user.setFirstName("John");
        user.setLastName("Doe");
        user.setEmail("john.doe@example.com");

        String expected = "User [uuid=12345, oneHealthId=OH123, firstName=John, lastName=Doe, email=john.doe@example.com]";
        assertEquals(expected, user.toString());
    }
}