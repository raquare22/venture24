package com.optum.digitalsecurity.model.request;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class OrgTest {

    private Org org;

    @Before
    public void setUp() {
        org = new Org();
    }

    @Test
    public void testGettersAndSetters() {
        // Test initial state
        assertNull(org.getId());
        assertNull(org.getCorpMpin());
        assertNull(org.getUhcProviderId());

        // Set values
        org.setId("123");
        org.setCorpMpin("456");
        org.setUhcProviderId("789");

        // Verify values
        assertEquals("123", org.getId());
        assertEquals("456", org.getCorpMpin());
        assertEquals("789", org.getUhcProviderId());
    }

    @Test
    public void testToString() {
        org.setId("123");
        org.setCorpMpin("456");
        org.setUhcProviderId("789");

        String expected = "Org [id=123, corpMpin=456, uhcProviderId=789]";
        assertEquals(expected, org.toString());
    }
}
