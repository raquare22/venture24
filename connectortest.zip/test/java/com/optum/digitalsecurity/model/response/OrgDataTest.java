package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class OrgDataTest {

    private OrgData orgData;

    @Before
    public void setUp() {
        orgData = new OrgData();
    }

    @Test
    public void testDefaultConstructor() {
        // Test initial state
        assertNull(orgData.getId());
        assertNull(orgData.getCorpMpin());
        assertNull(orgData.getTins());
    }

    @Test
    public void testParameterizedConstructor() {
        // Create a list of Tin objects
        Tin tin1 = new Tin(); // Assuming Tin has a default constructor
        Tin tin2 = new Tin();
        List<Tin> tins = Arrays.asList(tin1, tin2);

        // Create object with parameterized constructor
        OrgData orgData = new OrgData("ID123", "MPIN789", tins);

        // Verify values
        assertEquals("ID123", orgData.getId());
        assertEquals("MPIN789", orgData.getCorpMpin());
        assertEquals(tins, orgData.getTins());
    }

    @Test
    public void testGettersAndSetters() {
        // Create a list of Tin objects
        Tin tin1 = new Tin();
        Tin tin2 = new Tin();
        List<Tin> tins = Arrays.asList(tin1, tin2);

        // Set values
        orgData.setId("ID456");
        orgData.setCorpMpin("MPIN123");
        orgData.setTins(tins);

        // Verify values
        assertEquals("ID456", orgData.getId());
        assertEquals("MPIN123", orgData.getCorpMpin());
        assertEquals(tins, orgData.getTins());
    }
}