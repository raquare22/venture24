package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class ProviderTest {

    private Provider provider;

    @Before
    public void setUp() {
        provider = new Provider();
    }

    @Test
    public void testDefaultConstructor() {
        // Test initial state
        assertNull(provider.getFirstName());
        assertNull(provider.getLastName());
        assertNull(provider.getProviderMpin());
    }

    @Test
    public void testParameterizedConstructor() {
        // Create a Provider object using the parameterized constructor
        Provider provider = new Provider("John", "Doe", "MPIN123");

        // Verify values
        assertEquals("John", provider.getFirstName());
        assertEquals("Doe", provider.getLastName());
        assertEquals("MPIN123", provider.getProviderMpin());
    }

    @Test
    public void testGettersAndSetters() {
        // Set values
        provider.setFirstName("Jane");
        provider.setLastName("Smith");
        provider.setProviderMpin("MPIN456");

        // Verify values
        assertEquals("Jane", provider.getFirstName());
        assertEquals("Smith", provider.getLastName());
        assertEquals("MPIN456", provider.getProviderMpin());
    }
}