package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class NonProviderOrgTest {

    private NonProviderOrg nonProviderOrg;

    @Before
    public void setUp() {
        nonProviderOrg = new NonProviderOrg();
    }

    @Test
    public void testDefaultConstructor() {
        // Test initial state
        assertNull(nonProviderOrg.getIrsOrgId());
        assertNull(nonProviderOrg.getCorpName());
        assertFalse(nonProviderOrg.isPaa());
    }

    @Test
    public void testParameterizedConstructor() {
        // Create object with parameterized constructor
        NonProviderOrg nonProviderOrg = new NonProviderOrg("IRS123", "CorporateName", true);

        // Verify values
        assertEquals("IRS123", nonProviderOrg.getIrsOrgId());
        assertEquals("CorporateName", nonProviderOrg.getCorpName());
        assertTrue(nonProviderOrg.isPaa());
    }

    @Test
    public void testGettersAndSetters() {
        // Set values
        nonProviderOrg.setIrsOrgId("IRS456");
        nonProviderOrg.setCorpName("NewCorpName");
        nonProviderOrg.setPaa(false);

        // Verify values
        assertEquals("IRS456", nonProviderOrg.getIrsOrgId());
        assertEquals("NewCorpName", nonProviderOrg.getCorpName());
        assertFalse(nonProviderOrg.isPaa());
    }
}