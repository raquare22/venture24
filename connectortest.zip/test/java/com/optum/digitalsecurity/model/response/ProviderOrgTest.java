package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class ProviderOrgTest {

    private ProviderOrg providerOrg;

    @Before
    public void setUp() {
        providerOrg = new ProviderOrg();
    }

    @Test
    public void testDefaultConstructor() {
        // Test initial state
        assertNull(providerOrg.getId());
        assertNull(providerOrg.getCorpMpin());
        assertNull(providerOrg.getUhcProviderId());
        assertNull(providerOrg.getFirstName());
        assertNull(providerOrg.getLastName());
        assertFalse(providerOrg.isPaa());
        assertFalse(providerOrg.isIa());
    }

    @Test
    public void testParameterizedConstructor() {
        // Create a ProviderOrg object using the parameterized constructor
        ProviderOrg providerOrg = new ProviderOrg("ID123", "MPIN456", "UHC789", "John", "Doe", true, false);

        // Verify values
        assertEquals("ID123", providerOrg.getId());
        assertEquals("MPIN456", providerOrg.getCorpMpin());
        assertEquals("UHC789", providerOrg.getUhcProviderId());
        assertEquals("John", providerOrg.getFirstName());
        assertEquals("Doe", providerOrg.getLastName());
        assertTrue(providerOrg.isPaa());
        assertFalse(providerOrg.isIa());
    }

    @Test
    public void testGettersAndSetters() {
        // Set values
        providerOrg.setId("ID456");
        providerOrg.setCorpMpin("MPIN789");
        providerOrg.setUhcProviderId("UHC123");
        providerOrg.setFirstName("Jane");
        providerOrg.setLastName("Smith");
        providerOrg.setPaa(false);
        providerOrg.setIa(true);

        // Verify values
        assertEquals("ID456", providerOrg.getId());
        assertEquals("MPIN789", providerOrg.getCorpMpin());
        assertEquals("UHC123", providerOrg.getUhcProviderId());
        assertEquals("Jane", providerOrg.getFirstName());
        assertEquals("Smith", providerOrg.getLastName());
        assertFalse(providerOrg.isPaa());
        assertTrue(providerOrg.isIa());
    }
}