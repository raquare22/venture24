package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class ProviderProfileTest {

    private ProviderProfile providerProfile;
    private Demographics demographics;
    private List<JobFunction> jobFunctions;
    private List<ProviderOrg> providerOrgs;
    private List<NonProviderOrg> nonProviderOrgs;

    @Before
    public void setUp() {
        providerProfile = new ProviderProfile();
        demographics = new Demographics(); // Assuming a default constructor exists
        jobFunctions = Arrays.asList(new JobFunction(), new JobFunction()); // Assuming default constructors
        providerOrgs = Arrays.asList(new ProviderOrg(), new ProviderOrg()); // Assuming default constructors
        nonProviderOrgs = Arrays.asList(new NonProviderOrg(), new NonProviderOrg()); // Assuming default constructors
    }

    @Test
    public void testDefaultConstructor() {
        // Test initial state
        assertNull(providerProfile.getUuid());
        assertNull(providerProfile.getDemographics());
        assertNull(providerProfile.getJobFunction());
        assertNull(providerProfile.getProviderOrg());
        assertNull(providerProfile.getNonProviderOrg());
    }

    @Test
    public void testParameterizedConstructor() {
        // Create a ProviderProfile object using the parameterized constructor
        ProviderProfile providerProfile = new ProviderProfile(
                "UUID123", demographics, jobFunctions, providerOrgs, nonProviderOrgs
        );

        // Verify values
        assertEquals("UUID123", providerProfile.getUuid());
        assertEquals(demographics, providerProfile.getDemographics());
        assertEquals(jobFunctions, providerProfile.getJobFunction());
        assertEquals(providerOrgs, providerProfile.getProviderOrg());
        assertEquals(nonProviderOrgs, providerProfile.getNonProviderOrg());
    }

    @Test
    public void testGettersAndSetters() {
        // Set values
        providerProfile.setUuid("UUID456");
        providerProfile.setDemographics(demographics);
        providerProfile.setJobFunction(jobFunctions);
        providerProfile.setProviderOrg(providerOrgs);
        providerProfile.setNonProviderOrg(nonProviderOrgs);

        // Verify values
        assertEquals("UUID456", providerProfile.getUuid());
        assertEquals(demographics, providerProfile.getDemographics());
        assertEquals(jobFunctions, providerProfile.getJobFunction());
        assertEquals(providerOrgs, providerProfile.getProviderOrg());
        assertEquals(nonProviderOrgs, providerProfile.getNonProviderOrg());
    }
}