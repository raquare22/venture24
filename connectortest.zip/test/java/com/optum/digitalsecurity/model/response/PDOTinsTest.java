package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class PDOTinsTest {

    private PDOTins pdoTins;

    @Before
    public void setUp() {
        pdoTins = new PDOTins();
    }

    @Test
    public void testDefaultConstructor() {
        // Test initial state
        assertNull(pdoTins.getOptumUUID());
        assertNull(pdoTins.getUhcID());
        assertNull(pdoTins.getMpin());
        assertNull(pdoTins.getProviders());
    }

    @Test
    public void testGettersAndSetters() {
        // Create a list of Tin objects
        Tin tin1 = new Tin();
        Tin tin2 = new Tin();
        List<Tin> providers = Arrays.asList(tin1, tin2);

        // Set values
        pdoTins.setOptumUUID("UUID123");
        pdoTins.setUhcID("UHC456");
        pdoTins.setMpin("MPIN789");
        pdoTins.setProviders(providers);

        // Verify values
        assertEquals("UUID123", pdoTins.getOptumUUID());
        assertEquals("UHC456", pdoTins.getUhcID());
        assertEquals("MPIN789", pdoTins.getMpin());
        assertEquals(providers, pdoTins.getProviders());
    }
}