package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class CorporateTest {

    private Corporate corporate;

    @Before
    public void setUp() {
        corporate = new Corporate();
    }

    @Test
    public void testGettersAndSetters() {
        // Test initial state
        assertNull(corporate.getUhcID());
        assertNull(corporate.getMpin());
        assertNull(corporate.getCorporateName());
        assertNull(corporate.getProvId());

        // Set values
        corporate.setUhcID("UHC123");
        corporate.setMpin("MPIN456");
        corporate.setCorporateName("Optum");
        corporate.setProvId("PROV789");

        // Verify values
        assertEquals("UHC123", corporate.getUhcID());
        assertEquals("MPIN456", corporate.getMpin());
        assertEquals("Optum", corporate.getCorporateName());
        assertEquals("PROV789", corporate.getProvId());
    }
}