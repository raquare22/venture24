package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class JobFunctionTest {

    private JobFunction jobFunction;

    @Before
    public void setUp() {
        jobFunction = new JobFunction();
    }

    @Test
    public void testDefaultConstructor() {
        // Test initial state
        assertNull(jobFunction.getCode());
        assertNull(jobFunction.getDesc());
        assertNull(jobFunction.getNpi());
    }

    @Test
    public void testParameterizedConstructor() {
        // Create object with parameterized constructor
        JobFunction jobFunction = new JobFunction("CODE123", "Description", "NPI456");

        // Verify values
        assertEquals("CODE123", jobFunction.getCode());
        assertEquals("Description", jobFunction.getDesc());
        assertEquals("NPI456", jobFunction.getNpi());
    }

    @Test
    public void testGettersAndSetters() {
        // Set values
        jobFunction.setCode("CODE789");
        jobFunction.setDesc("New Description");
        jobFunction.setNpi("NPI987");

        // Verify values
        assertEquals("CODE789", jobFunction.getCode());
        assertEquals("New Description", jobFunction.getDesc());
        assertEquals("NPI987", jobFunction.getNpi());
    }
}