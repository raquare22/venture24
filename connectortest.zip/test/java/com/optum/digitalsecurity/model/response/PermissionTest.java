package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class PermissionTest {

    private Permission permission;

    @Before
    public void setUp() {
        permission = new Permission();
    }

    @Test
    public void testDefaultConstructor() {
        // Test initial state
        assertNull(permission.getCode());
        assertNull(permission.getSubCode());
        assertNull(permission.getCodeDesc());
        assertNull(permission.getSubCodeDesc());
    }

    @Test
    public void testParameterizedConstructor() {
        // Create a Permission object using the parameterized constructor
        Permission permission = new Permission("CODE123", "SUBCODE456", "Code Description", "SubCode Description");

        // Verify values
        assertEquals("CODE123", permission.getCode());
        assertEquals("SUBCODE456", permission.getSubCode());
        assertEquals("Code Description", permission.getCodeDesc());
        assertEquals("SubCode Description", permission.getSubCodeDesc());
    }

    @Test
    public void testGettersAndSetters() {
        // Set values
        permission.setCode("CODE123");
        permission.setSubCode("SUBCODE456");
        permission.setCodeDesc("Code Description");
        permission.setSubCodeDesc("SubCode Description");

        // Verify values
        assertEquals("CODE123", permission.getCode());
        assertEquals("SUBCODE456", permission.getSubCode());
        assertEquals("Code Description", permission.getCodeDesc());
        assertEquals("SubCode Description", permission.getSubCodeDesc());
    }
}