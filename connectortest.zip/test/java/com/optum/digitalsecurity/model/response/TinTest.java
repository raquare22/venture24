package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class TinTest {

    private Tin tin;
    private List<Permission> permissions;

    @Before
    public void setUp() {
        permissions = Arrays.asList(new Permission(), new Permission()); // Assuming default constructors
        tin = new Tin("TIN123", true, permissions); // Use parameterized constructor
    }

    @Test
    public void testDefaultConstructor() {
        Tin defaultTin = new Tin();
        // Verify initial state
        assertEquals(null, defaultTin.getTin());
        assertEquals(false, defaultTin.isAllPermission());
        assertEquals(null, defaultTin.getPermission());
    }

    @Test
    public void testParameterizedConstructor() {
        // Verify values
        assertEquals("TIN123", tin.getTin());
        assertTrue(tin.isAllPermission());
        assertEquals(permissions, tin.getPermission());
    }

    @Test
    public void testGettersAndSetters() {
        // Set values
        tin.setTin("TIN456");
        tin.setAllPermission(false);
        tin.setPermission(permissions);

        // Verify values
        assertEquals("TIN456", tin.getTin());
        assertEquals(false, tin.isAllPermission());
        assertEquals(permissions, tin.getPermission());
    }
}