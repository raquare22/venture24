package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class PDOProvTinTest {

    private PDOProvTin pdoProvTin;

    @Before
    public void setUp() {
        pdoProvTin = new PDOProvTin();
    }

    @Test
    public void testDefaultConstructor() {
        // Test initial state
        assertNull(pdoProvTin.getTin());
    }

    @Test
    public void testGettersAndSetters() {
        // Set value
        pdoProvTin.setTin("TIN123");

        // Verify value
        assertEquals("TIN123", pdoProvTin.getTin());
    }
}