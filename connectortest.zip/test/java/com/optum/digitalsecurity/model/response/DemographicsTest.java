package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class DemographicsTest {

    private Demographics demographics;

    @Before
    public void setUp() {
        demographics = new Demographics();
    }

    @Test
    public void testDefaultConstructor() {
        // Test initial state
        assertNull(demographics.getFirstName());
        assertNull(demographics.getLastName());
        assertNull(demographics.getEmail());
        assertNull(demographics.getPhone());
        assertNull(demographics.getPhoneExt());
    }

    @Test
    public void testParameterizedConstructor() {
        // Create object with parameterized constructor
        Demographics demographics = new Demographics("John", "Doe", "john.doe@example.com", "1234567890", "123");

        // Verify values
        assertEquals("John", demographics.getFirstName());
        assertEquals("Doe", demographics.getLastName());
        assertEquals("john.doe@example.com", demographics.getEmail());
        assertEquals("1234567890", demographics.getPhone());
        assertEquals("123", demographics.getPhoneExt());
    }

    @Test
    public void testGettersAndSetters() {
        // Set values
        demographics.setFirstName("Jane");
        demographics.setLastName("Smith");
        demographics.setEmail("jane.smith@example.com");
        demographics.setPhone("0987654321");
        demographics.setPhoneExt("456");

        // Verify values
        assertEquals("Jane", demographics.getFirstName());
        assertEquals("Smith", demographics.getLastName());
        assertEquals("jane.smith@example.com", demographics.getEmail());
        assertEquals("0987654321", demographics.getPhone());
        assertEquals("456", demographics.getPhoneExt());
    }
}