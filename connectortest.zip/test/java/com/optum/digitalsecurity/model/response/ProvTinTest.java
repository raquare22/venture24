package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class ProvTinTest {

    private ProvTin provTin;
    private List<Provider> providers;

    @Before
    public void setUp() {
        providers = Arrays.asList(new Provider(), new Provider()); // Assuming default constructors
        provTin = new ProvTin("UUID123", "MPIN456", "TIN789", providers); // Use parameterized constructor
    }

    @Test
    public void testParameterizedConstructor() {
        // Verify values
        assertEquals("UUID123", provTin.getUuid());
        assertEquals("MPIN456", provTin.getCorpMpin());
        assertEquals("TIN789", provTin.getTin());
        assertEquals(providers, provTin.getProvider());
    }

    @Test
    public void testGettersAndSetters() {
        // Set values
        provTin.setUuid("UUID456");
        provTin.setCorpMpin("MPIN789");
        provTin.setTin("TIN123");
        provTin.setProvider(providers);

        // Verify values
        assertEquals("UUID456", provTin.getUuid());
        assertEquals("MPIN789", provTin.getCorpMpin());
        assertEquals("TIN123", provTin.getTin());
        assertEquals(providers, provTin.getProvider());
    }
}