package com.optum.digitalsecurity.model.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class PDOCorporatesTest {

    private PDOCorporates pdoCorporates;

    @Before
    public void setUp() {
        pdoCorporates = new PDOCorporates();
    }

    @Test
    public void testDefaultConstructor() {
        // Test initial state
        assertNull(pdoCorporates.getOptumUUID());
        assertNull(pdoCorporates.getCorporates());
    }

    @Test
    public void testGettersAndSetters() {
        // Create a list of Corporate objects
        Corporate corporate1 = new Corporate();
        Corporate corporate2 = new Corporate();
        List<Corporate> corporates = Arrays.asList(corporate1, corporate2);

        // Set values
        pdoCorporates.setOptumUUID("UUID123");
        pdoCorporates.setCorporates(corporates);

        // Verify values
        assertEquals("UUID123", pdoCorporates.getOptumUUID());
        assertEquals(corporates, pdoCorporates.getCorporates());
    }

    @Test
    public void testToString() {
        // Create a list of Corporate objects
        Corporate corporate1 = new Corporate();
        Corporate corporate2 = new Corporate();
        List<Corporate> corporates = Arrays.asList(corporate1, corporate2);

        // Set values
        pdoCorporates.setOptumUUID("UUID123");
        pdoCorporates.setCorporates(corporates);

        // Verify toString output
        String expected = "PDOCorporates [optumUUID=UUID123, corporates=" + corporates + "]";
        assertEquals(expected, pdoCorporates.toString());
    }
}