//package com.optum.providerpreferences;
//
//import static org.junit.Assert.assertEquals;
//
//import org.junit.Before;
//import org.junit.Test;
//import org.springframework.test.util.ReflectionTestUtils;
//
//public class KafkaConfigTest {
//
//    private KafkaConfig kafkaConfig;
//
//    @Before
//    public void setUp() {
//        kafkaConfig = new KafkaConfig();
//    }
//
//    @Test
//    public void testSetAppAskId() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setAppAskId", "testAskId");
//        assertEquals("testAskId", KafkaConfig.appAskid);
//    }
//
//    @Test
//    public void testSetAppName() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setAppName", "testAppName");
//        assertEquals("testAppName", KafkaConfig.appname);
//    }
//
//    @Test
//    public void testSetDeviceVendor() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setDeviceVendor", "testVendor");
//        assertEquals("testVendor", KafkaConfig.devicevendor);
//    }
//
//    @Test
//    public void testSetDeviceProduct() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setDeviceProduct", "testProduct");
//        assertEquals("testProduct", KafkaConfig.deviceproduct);
//    }
//
//    @Test
//    public void testSetTags() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setTags", "testTags");
//        assertEquals("testTags", KafkaConfig.tag);
//    }
//
//    @Test
//    public void testSetBrokerList() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setBrokerList", "testBrokerList");
//        assertEquals("testBrokerList", KafkaConfig.brokerlist);
//    }
//
//    @Test
//    public void testSetKafkaTopic() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setKafkaTopic", "testTopic");
//        assertEquals("testTopic", KafkaConfig.kafkatopic);
//    }
//
//    @Test
//    public void testSetKafkaKeyPass() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setKafkaKeyPass", "testKeyPass");
//        assertEquals("testKeyPass", KafkaConfig.kafkaKeypass);
//    }
//
//    @Test
//    public void testSetKafkaKeystorePass() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setKafkaKeystorePass", "testKeystorePass");
//        assertEquals("testKeystorePass", KafkaConfig.kafkaKeystorepass);
//    }
//
//    @Test
//    public void testSetKafkaClientId() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setKafkaClientId", "testClientId");
//        assertEquals("testClientId", KafkaConfig.kafkaclientId);
//    }
//
//    @Test
//    public void testSetKafkaProtocol() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setKafkaProtocol", "testProtocol");
//        assertEquals("testProtocol", KafkaConfig.Kafkaprotocol);
//    }
//
//    @Test
//    public void testSetKafkaKeyStorePath() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setKafkaKeyStorePath", "testKeyStorePath");
//        assertEquals("testKeyStorePath", KafkaConfig.kafkaKeyStorepath);
//    }
//
//    @Test
//    public void testSetEnableNess() {
//        ReflectionTestUtils.invokeMethod(kafkaConfig, "setEnableNess", true);
//        assertEquals(true, KafkaConfig.enableNess);
//    }
//}