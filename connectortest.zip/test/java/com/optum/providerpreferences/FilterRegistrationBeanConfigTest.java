package com.optum.providerpreferences;

import static org.junit.Assert.*;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.web.servlet.FilterRegistrationBean;

public class FilterRegistrationBeanConfigTest {

	@Test
	public void testJwtFilterRegistration() {

		// ✅ Mock filter
		StargateJWTFilter mockFilter = Mockito.mock(StargateJWTFilter.class);

		// ✅ Create config with mocked filter
		FilterRegistrationBeanConfig config = new FilterRegistrationBeanConfig(mockFilter);

		// ✅ Call method
		FilterRegistrationBean<StargateJWTFilter> bean = config.jwtFilterRegistration();
		assertNotNull(bean);
		assertEquals(mockFilter, bean.getFilter());
		assertTrue(bean.getUrlPatterns().contains("/api/providers/v1/*"));
		assertEquals(1, bean.getOrder());
	}
}
