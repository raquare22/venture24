package com.optum.providerpreferences;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.event.ContextClosedEvent;

public class AppListenerTest {

    private AppListener appListener;

    // Test subclass to override static call and avoid LOGGER access
    static class TestAppListener extends AppListener {
        @Override
        public void onApplicationEvent(ContextClosedEvent event) {
            if (!shutdown) {
                shutdown = true;
                // Do not call NessAppLog.shutdown()
            }
        }
    }

    @Before
    public void setUp() {
        appListener = new TestAppListener();
        AppListener.shutdown = false;
    }

    @Test
    public void testOnApplicationEvent_SetsShutdownFlag() {
        ContextClosedEvent mockEvent = mock(ContextClosedEvent.class);
        appListener.onApplicationEvent(mockEvent);
        assertTrue("Shutdown flag should be set to true", AppListener.shutdown);
    }

//    @Test
//    public void testOnApplicationEvent_DoesNotSetShutdownIfAlreadyShutdown() {
//        AppListener.shutdown = true;
//        ContextClosedEvent mockEvent = mock(ContextClosedEvent.class);
//        appListener.onApplicationEvent(mockEvent);
//        // No exception means test passes
//    }

    @Test
    public void testOnApplicationEvent_CalledTwice_ShutdownOnlySetOnce() {
        ContextClosedEvent mockEvent = mock(ContextClosedEvent.class);
        appListener.onApplicationEvent(mockEvent);
        assertTrue(AppListener.shutdown);

        // Call again, should remain true and not throw
        appListener.onApplicationEvent(mockEvent);
        assertTrue(AppListener.shutdown);
    }

    @Test
    public void testShutdownFlag_DefaultIsFalse() {
        // Before any event, shutdown should be false
        assertTrue(!AppListener.shutdown);
    }
//    @Test
//    public void testAppListenerConstructor() {
//        new AppListener();
//    }
}