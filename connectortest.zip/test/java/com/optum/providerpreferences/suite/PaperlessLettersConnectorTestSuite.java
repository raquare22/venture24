package com.optum.providerpreferences.suite;


import com.optum.digitalsecurity.model.request.OrgTest;
import com.optum.digitalsecurity.model.request.TinTest;
import com.optum.digitalsecurity.model.request.UserTest;
import com.optum.digitalsecurity.model.response.*;
import com.optum.digitalsecurity.model.response.CorporateTest;
//import com.optum.digitalsecurity.model.response.TinTest;
import com.optum.providerpreferences.AppConfigTest;
import com.optum.providerpreferences.AppListenerTest;
import com.optum.providerpreferences.ApplicationTest;
import com.optum.providerpreferences.FilterRegistrationBeanConfigTest;
import com.optum.providerpreferences.HeaderFilterTest;
import com.optum.providerpreferences.StargateJWTFilterTest;
import com.optum.providerpreferences.StargateJWTValidatorTest;
//import com.optum.providerpreferences.KafkaConfigTest;
import com.optum.providerpreferences.autoenrollment.*;
import com.optum.providerpreferences.kafka.ConfigDataTest;
import com.optum.providerpreferences.kafka.EnvironmentsTest;
import com.optum.providerpreferences.kafka.KafkaProducerTest;
import com.optum.providerpreferences.kafka.NessAppLogTest;
//import com.optum.providerpreferences.kafka.KafkaProducerTest;
//import com.optum.providerpreferences.kafka.NessAppLogTest;
import com.optum.providerpreferences.kafka.UtilityTest;
import com.optum.providerpreferences.rs.controller.*;
import com.optum.providerpreferences.rs.exception.ApplicationExceptionTest;
import com.optum.providerpreferences.rs.exception.ErrorResponseTest;
import com.optum.providerpreferences.rs.handler.*;
import com.optum.providerpreferences.rs.model.*;
import com.optum.providerpreferences.rs.model.autoenroll.*;
import com.optum.providerpreferences.rs.model.fds.*;
import com.optum.providerpreferences.rs.model.logging.LogMessageTest;
import com.optum.providerpreferences.rs.model.ndb.*;
import com.optum.providerpreferences.rs.model.ndb.preferences.*;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinRequestTest;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponseTest;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinDataTest;
import com.optum.providerpreferences.rs.model.optout.*;
import com.optum.providerpreferences.rs.model.pes.*;
import com.optum.providerpreferences.rs.mongo.document.DeliveryPreferenceTest;
import com.optum.providerpreferences.rs.optout.SchedulerOptOutTest;
//import com.optum.providerpreferences.rs.service.OptOutServiceImplTest;
//import com.optum.providerpreferences.rs.service.ProviderPreferenceServiceImplTest;
import com.optum.providerpreferences.rs.service.*;
import com.optum.providerpreferences.rs.utility.*;
import com.optum.providerpreferences.service.PaymentPreferenceServiceImplTest;

import junit.framework.TestCase;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)

@Suite.SuiteClasses({
        //request
        OrgTest.class,
        TinTest.class,
        UserTest.class,
        //response
        CorporateTest.class,
        DemographicsTest.class,
        JobFunctionTest.class,
        NonProviderOrgTest.class,
        OrgDataTest.class,
        PDOCorporatesTest.class,
        PDOProvTinTest.class,
        PDOTinsTest.class,
        PermissionTest.class,
        ProviderOrgTest.class,
        ProviderProfileTest.class,
        ProviderTest.class,
        ProvTinTest.class,
        com.optum.digitalsecurity.model.response.TinTest.class,
        //autooenrollment
        SchedulerAutoEnrollmentTest.class,
        SftpUtilTest.class,
        //Kafka
        EnvironmentsTest.class,
        KafkaProducerTest.class,
        ConfigDataTest.class,
        UtilityTest.class,
        NessAppLogTest.class,
        //Controller
        LoggersControllerTest.class,
        OONPopUpControllerTest.class,
        OptOutControllerTest.class,
        ProvPrefDigiSecControllerTest.class,
        PaymentPreferenceControllerTest.class,
        RootControllerTest.class,
        //Exception
        ApplicationExceptionTest.class,
        ErrorResponseTest.class,
        //Autoenrollment
        AutoenrollmentAuditLogTest.class,
        AutoenrollmentObjTest.class,
        AutoenrollmentRequestTest.class,
        FDSMultiPostResponseTest.class,
        FDSMultiPutResponseTest.class,
        //Fds
        DocumentTest.class,
        FDSCloudGETResponseTest.class,
        FDSCloudRequestTest.class,
        MetadataTest.class,
        //LinkSecurity
        com.optum.providerpreferences.rs.model.linksecurity.UserTest.class,
        //logging
        LogMessageTest.class,
        //Preferences
        LetterPreferencesRequestTest.class,
        LetterPreferencesResponseTest.class,
        LetterTypeTest.class,
        MailPrefTest.class,
        RequestDataTest.class,
        RequestHeaderTest.class,
        com.optum.providerpreferences.rs.model.ndb.preferences.ResponseDataTest.class,
        ResponseDataTest.class,
        UILetterPreferencesRequestTest.class,
        //Provider
        CorpMpinRequestTest.class,
        CorpMpinResponseTest.class,
        MpinDataTest.class,
        RequestDataTest.class,
        com.optum.providerpreferences.rs.model.ndb.provider.RequestHeaderTest.class,
        com.optum.providerpreferences.rs.model.ndb.provider.ResponseDataTest.class,
        com.optum.providerpreferences.rs.model.ndb.provider.ResponseHeaderTest.class,
        //Ndn
        CorporateEntitiesTest.class,
        com.optum.providerpreferences.rs.model.ndb.CorporateTest.class,
        NDBProvidersTest.class,
        NDBProviderTest.class,
        ProviderOrganizationsTest.class,
        ProviderOrganizationTest.class,
        com.optum.providerpreferences.rs.model.ndb.TinsTest.class,
        com.optum.providerpreferences.rs.model.ndb.TinTest.class,
        //optout
        OptOutAuditMetadataTest.class,
        OptOutAuditUpdateTest.class,
        OptOutFDSCloudDocumentTest.class,
        OptOutFDSCloudPOSTRequestTest.class,
        OptOutFDSCloudPOSTResponseTest.class,
        OptOutRequestTest.class,
        OptOutTinRequestTest.class,
        OptOutTinResponseTest.class,
        //pes
        KeyTest.class,
        MetaTest.class,
        PESResponseTest.class,
        PESTinRequestTest.class,
        TinObjectTest.class,

        GenericResponseTest.class,
        LogLevelObjTest.class,
        LogRequestTest.class,
        OONProviderPopUpDateTest.class,
        OONRequestModelTest.class,
        PasswordOwnerInfoTest.class,
        PasswordOwnerRequestTest.class,
        PasswordOwnerTest.class,
        PreferencesRequestTest.class,
        PreferenceTypeTest.class,
        ProviderEmailRequestTest.class,
        ProviderPreferencesObjTest.class,
        TinRequestTest.class,
        TokenAbstTest.class,
        TokenTest.class,
        //optout
        SchedulerOptOutTest.class,
        //service
        OptOutServiceImplTest.class,
        ProviderPreferenceServiceImplTest.class,
        //utility
        ApplicationUtilTest.class,
        ClassifierDescriptionTest.class,
        ConstantsTest.class,
        ConverterTest.class,
        MessageBuilderTest.class,
        PasswordOwnerUtilTest.class,
        ProviderPreferencesUtilTest.class,
        SanitizeUtilTest.class,
        //asd
        AppConfigTest.class,
        ApplicationTest.class,
        AppListenerTest.class,
        FilterRegistrationBeanConfigTest.class,
        HeaderFilterTest.class,
        StargateJWTValidatorTest.class,
        StargateJWTFilterTest.class,
    //    KafkaConfigTest.class,
        //Handler
        NDBHandlerTest.class,
        FDSCloudHandlerTest.class,
        Oauth2HandlerTest.class,
        PESHandlerTest.class,
        RequestFactoryTest.class,
        ServiceBaseTest.class,
        PEHandlerTest.class,
        //Service
        AsyncComponentTest.class,
        AutoenrollmentServiceImplTest.class,
        DigitalSecurityServiceImplTest.class,
        OptOutServiceImplTest.class,
        ProviderPreferenceServiceImplTest.class,
        DocumentServiceImplTest.class,  
        PaymentPreferenceServiceImplTest.class,
        DeliveryPreferenceTest.class
        




})
public class PaperlessLettersConnectorTestSuite extends TestCase {}
