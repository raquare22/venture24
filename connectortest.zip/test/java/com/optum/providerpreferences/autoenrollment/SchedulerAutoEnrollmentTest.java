package com.optum.providerpreferences.autoenrollment;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import java.io.IOException;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import org.apache.logging.log4j.Logger;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

@RunWith(MockitoJUnitRunner.class)
public class SchedulerAutoEnrollmentTest {

    @Mock
    Logger mockLogger;
    private static final String TEST_CSV_FILEPATH = "src/test/resources/com/optum/test_csv/test-csv-file.csv";
    @Before
    public void setUp() {
        // Set up environment variables for SFTP credentials
        SchedulerAutoEnrollment.lock.set(false);
        SchedulerAutoEnrollment.getCount.set(0);
        SchedulerAutoEnrollment.postCount.set(0);
        SchedulerAutoEnrollment.emailCount.set(0);
        SchedulerAutoEnrollment.lastSchedulerCount.set(0);
        System.setProperty("PRUN_PORT", "8080");
        System.setProperty("PRUN_HOST", "host");
        System.setProperty("PRUN_USERNAME", "user");
        System.setProperty("PRUN_PASSWORD", "key");
        System.setProperty("PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY", "/work");
        System.setProperty("PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY", "/dest");
        System.setProperty("PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY", "/archive");
        System.setProperty("RETRY_WORKING_DIRECTORY", "/retrywork");
        System.setProperty("RETRY_PROCESSED_DIRECTORY", "/retryproc");
        System.setProperty("SPLIT_CSV_PER_MAX_MB_SIZE", "20");
        System.setProperty("SPLIT_MAX_BYTES_NEW_LINE_WITHIN", "256");
    }

    @Test
    public void pollCSVFilesWeekdays_ShouldSkipIfLocked() {
        SchedulerAutoEnrollment.lock.set(true);
        SchedulerAutoEnrollment.lastSchedulerCount.set(5);
        SchedulerAutoEnrollment.postCount.set(5);
        SchedulerAutoEnrollment.getCount.set(0);

        SchedulerAutoEnrollment.pollCSVFilesWeekdays();
        assertTrue(SchedulerAutoEnrollment.lock.get());
    }

    @Test
    public void pollCSVFilesWeekdays_ShouldProcessIfNotLocked_MissingCredentials() {
        SchedulerAutoEnrollment.lock.set(false);
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            sftpUtilMock.when(() -> SftpUtil.exceptionForMissingLoginCredential(any(), any(), any(), any()))
                    .thenReturn(true); // or false, depending on what you want to test
            SchedulerAutoEnrollment.pollCSVFilesWeekdays();
            assertFalse(SchedulerAutoEnrollment.lock.get());
        }
    }

    @Test
    public void testExecuteScheduledJob_SuccessfulExecution() throws IOException {

        try (MockedStatic<SftpUtil> mockedSftpUtil = Mockito.mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential(anyString(), anyString(), anyString(), anyString()))
                    .thenReturn(false);
            mockedSftpUtil.when(() -> SftpUtil.readFileFromServer(any(), any(), any(), eq(true)))
                    .thenReturn(TEST_CSV_FILEPATH);
            mockedSftpUtil.when(() -> SftpUtil.readFileFromServerCheckSize(any(), any(), any()))
                    .thenReturn(Map.of("file.csv", 100L));

            Map<String, Object> sftpResult = new HashMap<>();
            ArrayList<ChannelSftp.LsEntry> entries = new ArrayList<>();
            ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
            when(entry.getFilename()).thenReturn("test-csv-file.csv");
            entries.add(entry);
            sftpResult.put("directoryListing", entries);
            mockedSftpUtil.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenReturn(sftpResult);
            try{
            SchedulerAutoEnrollment.pollCSVFilesWeekdays();
            assertFalse("Lock should be released", SchedulerAutoEnrollment.lock.get());}catch (Exception e) {

            }
        }
    }

    @Test
    public void pollCSVFilesWeekends_ShouldSkipIfLocked() {
        SchedulerAutoEnrollment.lock.set(true);
        SchedulerAutoEnrollment.pollCSVFilesWeekends();
        assertTrue(SchedulerAutoEnrollment.lock.get());
    }

    @Test
    public void pollRetry_ShouldSkipIfLocked() {
        SchedulerAutoEnrollment.lock.set(true);
        SchedulerAutoEnrollment.pollRetry();
        assertTrue(SchedulerAutoEnrollment.lock.get());
    }

    @Test
    public void pollRetry_ShouldProcessIfCredentialsPresent() {
        SchedulerAutoEnrollment.lock.set(false);
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            sftpUtilMock.when(() -> SftpUtil.exceptionForMissingLoginCredential(any(), any(), any(), any()))
                    .thenReturn(false);
            ArrayList<ChannelSftp.LsEntry> entries = new ArrayList<>();
            ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
            when(entry.getFilename()).thenReturn("test-csv-file.csv");
            entries.add(entry);

            Map<String, Object> sftpResult = new HashMap<>();
            sftpResult.put("directoryListing", entries);
            sftpUtilMock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenReturn(sftpResult);
            SchedulerAutoEnrollment.pollRetry();
            assertFalse(SchedulerAutoEnrollment.lock.get());
        }
    }

    @Test
    public void pollRetry_ShouldProcessIfCredentialsPresent_Exception1() {
        SchedulerAutoEnrollment.lock.set(false);
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            sftpUtilMock.when(() -> SftpUtil.exceptionForMissingLoginCredential(any(), any(), any(), any()))
                    .thenReturn(false).thenReturn(true);

            SchedulerAutoEnrollment.pollRetry();
            assertFalse(SchedulerAutoEnrollment.lock.get());
        }
    }

    @Test
    public void pollRetry_ShouldProcessIfCredentialsPresent_Exception2() {
        SchedulerAutoEnrollment.lock.set(false);
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            sftpUtilMock.when(() -> SftpUtil.exceptionForMissingLoginCredential(any(), any(), any(), any()))
                    .thenReturn(false);
            ArrayList<ChannelSftp.LsEntry> entries = new ArrayList<>();
            ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
            when(entry.getFilename()).thenReturn("test-csv-file.csv");
            entries.add(entry);

            Map<String, Object> sftpResult = new HashMap<>();
            sftpResult.put("directoryListing", entries);
            sftpUtilMock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenReturn(sftpResult);
            sftpUtilMock.when(() -> SftpUtil.readRetryData(any(), any(), any(), any(), any()))
                    .thenThrow(new ApplicationException("a"));
            SchedulerAutoEnrollment.pollRetry();
            assertFalse(SchedulerAutoEnrollment.lock.get());
        }
    }

    @Test
    public void pollRetry_ShouldWarnIfCredentialsMissing() {
        SchedulerAutoEnrollment.lock.set(false);
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            sftpUtilMock.when(() -> SftpUtil.exceptionForMissingLoginCredential(any(), any(), any(), any()))
                    .thenReturn(true);
            SchedulerAutoEnrollment.pollRetry();
            assertFalse(SchedulerAutoEnrollment.lock.get());
        }
    }

    @Test
    public void createNewDirectoryAndMoveFiles_ShouldReturnFalseOnSftpException() {
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            sftpUtilMock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenThrow(new com.jcraft.jsch.SftpException(0, "fail"));
            boolean result = (boolean) ReflectionTestUtils.invokeMethod(
                    SchedulerAutoEnrollment.class,
                    "createNewDirectoryAndMoveFiles",
                    "PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY",
                    "PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY"
            );
            assertFalse(result);
        }
    }

    @Test
    public void createNewDirectoryAndMoveFiles_ShouldReturnTrueIfFilesToProcess() {
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            Map<String, Object> sftpResult = new HashMap<>();
            sftpUtilMock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenReturn(sftpResult);
            sftpUtilMock.when(() -> SftpUtil.readFileFromServerCheckSize(any(), any(), any()))
                    .thenReturn(Map.of("file.csv", 100L));
            sftpUtilMock.when(() -> SftpUtil.getFilesToSplit(anyInt(), any()))
                    .thenReturn(Map.of());
            boolean result = (boolean) ReflectionTestUtils.invokeMethod(
                    SchedulerAutoEnrollment.class,
                    "createNewDirectoryAndMoveFiles",
                    "PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY",
                    "PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY"
            );
            assertTrue(result);
        }
    }


//    @Test
    public void splitFiles_ShouldNotCallCheckAndSplit_WhenCredentialsMissing() {
        try (
                MockedStatic<SftpUtil> sftpUtilMock = mockStatic(SftpUtil.class);
        ) {
            sftpUtilMock.when(() -> SftpUtil.createDateintoString()).thenReturn("20240614");
            sftpUtilMock.when(() -> SftpUtil.exceptionForMissingLoginCredential(any(), any(), any(), any()))
                    .thenReturn(true);

            MockedStatic<SchedulerAutoEnrollment> schedulerMock = mockStatic(SchedulerAutoEnrollment.class, CALLS_REAL_METHODS);

            ReflectionTestUtils.invokeMethod(
                    SchedulerAutoEnrollment.class,
                    "splitFiles",
                    20, 256, Map.of("file.csv", 100L)
            );

            schedulerMock.verify(() -> SchedulerAutoEnrollment.checkAndSplit(anyString(), anyInt(), anyInt(), anyMap()), never());
        }
    }

    @Test
    public void processFilesHandlesValidCSVFile() throws Exception {
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            sftpUtilMock.when(SftpUtil::createDateintoString).thenReturn("20240320");
            sftpUtilMock.when(() -> SftpUtil.exceptionForMissingLoginCredential(any(), any(), any(), any()))
                    .thenReturn(false);

            ArrayList<ChannelSftp.LsEntry> entries = new ArrayList<>();
            ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
            when(entry.getFilename()).thenReturn("test.csv");
            entries.add(entry);

            Map<String, Object> sftpResult = new HashMap<>();
            sftpResult.put("directoryListing", entries);

            sftpUtilMock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenReturn(sftpResult);
            sftpUtilMock.when(() -> SftpUtil.readFileStoreData(any(), any(), any(), any(), anyBoolean()))
                    .thenReturn(Arrays.asList("data1", "data2"));

            ReflectionTestUtils.invokeMethod(
                    SchedulerAutoEnrollment.class,
                    "processFiles"
            );

            sftpUtilMock.verify(() -> SftpUtil.readFileSendAutoEnroCloud(any()));
        }
    }

    @Test
    public void processFilesSkipsNonCSVFiles() throws Exception {
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            sftpUtilMock.when(() -> SftpUtil.createDateintoString()).thenReturn("20240320");
            sftpUtilMock.when(() -> SftpUtil.exceptionForMissingLoginCredential(any(), any(), any(), any()))
                    .thenReturn(false);

            ArrayList<ChannelSftp.LsEntry> entries = new ArrayList<>();
            ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
            when(entry.getFilename()).thenReturn("test.txt");
            entries.add(entry);

            Map<String, Object> sftpResult = new HashMap<>();
            sftpResult.put("directoryListing", entries);

            sftpUtilMock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenReturn(sftpResult);

            ReflectionTestUtils.invokeMethod(
                    SchedulerAutoEnrollment.class,
                    "processFiles"
            );
            sftpUtilMock.verify(() -> SftpUtil.readFileStoreData(any(), any(), any(), any(), anyBoolean()), never());
        }
    }

    @Test
    public void processFilesHandlesMissingCredentials() throws Exception {
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            sftpUtilMock.when(() -> SftpUtil.createDateintoString()).thenReturn("20240320");
            sftpUtilMock.when(() -> SftpUtil.exceptionForMissingLoginCredential(any(), any(), any(), any()))
                    .thenReturn(true);

            ReflectionTestUtils.invokeMethod(
                    SchedulerAutoEnrollment.class,
                    "processFiles"
            );
            sftpUtilMock.verify(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()), never());
        }
    }

    @Test
    public void processFilesHandlesSftpException() throws Exception {
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            sftpUtilMock.when(() -> SftpUtil.createDateintoString()).thenReturn("20240320");
            sftpUtilMock.when(() -> SftpUtil.exceptionForMissingLoginCredential(any(), any(), any(), any()))
                    .thenReturn(false);
            sftpUtilMock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenThrow(new SftpException(1, "SFTP Error"));

            ReflectionTestUtils.invokeMethod(
                    SchedulerAutoEnrollment.class,
                    "processFiles"
            );
            sftpUtilMock.verify(() -> SftpUtil.readFileStoreData(any(), any(), any(), any(), anyBoolean()), never());
        }
    }

    @Test
    public void processFilesHandlesEmptyDirectory() throws Exception {
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            sftpUtilMock.when(() -> SftpUtil.createDateintoString()).thenReturn("20240320");
            sftpUtilMock.when(() -> SftpUtil.exceptionForMissingLoginCredential(any(), any(), any(), any()))
                    .thenReturn(false);

            Map<String, Object> sftpResult = new HashMap<>();
            sftpResult.put("directoryListing", new ArrayList<>());

            sftpUtilMock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenReturn(sftpResult);

            ReflectionTestUtils.invokeMethod(
                    SchedulerAutoEnrollment.class,
                    "processFiles"
            );
            sftpUtilMock.verify(() -> SftpUtil.readFileStoreData(any(), any(), any(), any(), anyBoolean()), never());
        }
    }


    @Test
    public void testCheckAndSplit_ValidCSVFiles() throws Exception {
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            ArrayList<ChannelSftp.LsEntry> entries = new ArrayList<>();
            ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
            when(entry.getFilename()).thenReturn("valid.csv");
            entries.add(entry);

            Map<String, Object> sftpResult = new HashMap<>();
            sftpResult.put("directoryListing", entries);

            sftpUtilMock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenReturn(sftpResult);

            Map<String, Long> fileSizeMap = new HashMap<>();
            fileSizeMap.put("valid.csv", 1024L);

            List<Path> splitPaths = List.of(Path.of("split1.csv"), Path.of("split2.csv"));
            sftpUtilMock.when(() -> SftpUtil.splitFilePerMbPerNewLine(any(), anyInt(), anyInt(), any(), anyBoolean()))
                    .thenReturn(splitPaths);

            SchedulerAutoEnrollment.checkAndSplit("destinationPath", 20, 256, fileSizeMap);

            sftpUtilMock.verify(() -> SftpUtil.copyFileToLocal(any(), any(), any(), any()), times(1));
            sftpUtilMock.verify(() -> SftpUtil.movefileFromlocalToServer(any(), any(), any()), times(2));
            sftpUtilMock.verify(() -> SftpUtil.removeFileFromServer(any(), any(), any()), times(1));
        }
    }

    @Test
    public void testCheckAndSplit_SkipsNonCSVFiles() throws Exception {
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            // Arrange
            ArrayList<ChannelSftp.LsEntry> entries = new ArrayList<>();
            ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
            when(entry.getFilename()).thenReturn("invalid.txt");
            entries.add(entry);

            Map<String, Object> sftpResult = new HashMap<>();
            sftpResult.put("directoryListing", entries);

            sftpUtilMock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenReturn(sftpResult);

            Map<String, Long> fileSizeMap = new HashMap<>();
            SchedulerAutoEnrollment.checkAndSplit("destinationPath", 20, 256, fileSizeMap);

            sftpUtilMock.verify(() -> SftpUtil.copyFileToLocal(any(), any(), any(), any()), never());
        }
    }

    @Test
    public void testCheckAndSplit_FileSizeNotInMap() throws Exception {
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            ArrayList<ChannelSftp.LsEntry> entries = new ArrayList<>();
            ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
            when(entry.getFilename()).thenReturn("missing.csv");
            entries.add(entry);

            Map<String, Object> sftpResult = new HashMap<>();
            sftpResult.put("directoryListing", entries);

            sftpUtilMock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenReturn(sftpResult);

            Map<String, Long> fileSizeMap = new HashMap<>();

            SchedulerAutoEnrollment.checkAndSplit("destinationPath", 20, 256, fileSizeMap);

            sftpUtilMock.verify(() -> SftpUtil.copyFileToLocal(any(), any(), any(), any()), never());
        }
    }

    @Test
    public void testCheckAndSplit_HandlesException() throws Exception {
        try (MockedStatic<SftpUtil> sftpUtilMock = Mockito.mockStatic(SftpUtil.class)) {
            // Arrange
            sftpUtilMock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any()))
                    .thenThrow(new SftpException(1, "SFTP Error"));

            Map<String, Long> fileSizeMap = new HashMap<>();

            // Act & Assert
            SchedulerAutoEnrollment.checkAndSplit("destinationPath", 20, 256, fileSizeMap);

            // Verify no further processing
            sftpUtilMock.verify(() -> SftpUtil.copyFileToLocal(any(), any(), any(), any()), never());
        }
    }

	@Test
	public void testExecuteScheduledJob_ResetsLock_WhenCountsMatch() {

		SchedulerAutoEnrollment.lock.set(true);
		SchedulerAutoEnrollment.lastSchedulerCount.set(5);
		SchedulerAutoEnrollment.postCount.set(5);
		SchedulerAutoEnrollment.getCount.set(5);

		SchedulerAutoEnrollment.pollCSVFilesWeekdays();

		// ✅ Instead of checking final state → check counter reset
		assertEquals(0, SchedulerAutoEnrollment.postCount.get());
		assertEquals(0, SchedulerAutoEnrollment.getCount.get());
		assertEquals(0, SchedulerAutoEnrollment.emailCount.get());
	}

	@Test
	public void testExecuteScheduledJob_ResetsLock_WhenCountsMismatch() {

		SchedulerAutoEnrollment.lock.set(true);
		SchedulerAutoEnrollment.lastSchedulerCount.set(5);
		SchedulerAutoEnrollment.postCount.set(5);
		SchedulerAutoEnrollment.getCount.set(2);

		SchedulerAutoEnrollment.pollCSVFilesWeekdays();

		// ✅ method still resets counters
		assertEquals(0, SchedulerAutoEnrollment.postCount.get());
	}

	@Test
	public void testCreateNewDirectoryAndMoveFiles_NonWorkingDirBranch() {

		try (MockedStatic<SftpUtil> mock = mockStatic(SftpUtil.class)) {

			mock.when(() -> SftpUtil.sftpDirectory(any(), any(), any(), any())).thenReturn(new HashMap<>());

			// ✅ KEY FIX: return empty string → SKIPS split()
			mock.when(() -> SftpUtil.readFileFromServer(any(), any(), any(), anyBoolean())).thenReturn("");

			boolean result = (boolean) ReflectionTestUtils.invokeMethod(SchedulerAutoEnrollment.class,
					"createNewDirectoryAndMoveFiles", "SOME_OTHER_DIR", "PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY");

			assertTrue(result);

			// ❌ DO NOT verify removeFile — it won't be called now
		}
	}

}