//package com.optum.providerpreferences.autoenrollment;
//
//import java.io.File;
//import java.io.FileWriter;
//
//import javax.mail.MessagingException;
//
//import org.junit.BeforeClass;
//import org.junit.Test;
//
//import static org.junit.Assert.assertTrue;
//import static org.junit.Assert.fail;
//
//public class EmailUtilsTest {
//
//    @BeforeClass
//    public static void setupEnvVars() {
//        setEnv("PRUN_EMAIL_HOST", "localhost");
//        setEnv("PRUN_EMAIL_FROM", "from@example.com");
//        setEnv("PRUN_EMAIL_TO", "to@example.com");
//        setEnv("PRUN_EMAIL_SUBJECT", "Test Subject [dateTime]");
//        setEnv("PRUN_EMAIL_MSG", "Test Message [dateTime]");
//        setEnv("PRUN_EMAIL_TO_PODM", "podm@example.com");
//    }
//
//    private static void setEnv(String key, String value) {
//        try {
//            java.util.Map<String, String> env = System.getenv();
//            java.lang.reflect.Field field = env.getClass().getDeclaredField("m");
//            field.setAccessible(true);
//            @SuppressWarnings("unchecked")
//            java.util.Map<String, String> writableEnv = (java.util.Map<String, String>) field.get(env);
//            writableEnv.put(key, value);
//        } catch (Exception ignored) {
//            // Fallback for other JVMs or if the above fails
//        }
//    }
//
//    //TODO: fix the null pointer error in these 2 tests as ITS BEEN SENT TO ConCurrentHashMap.java CLASS AND THE CONDITION:  Final V putVal(K key, V value, boolean onlyIfAbsent) { if (key == null || value == null) throw new NullPointerException();  IS BEING SATISFIED AND ITS THROWING NULLPOINEREXCEPTION
////    @Test(expected = MessagingException.class)
////    public void sendEmailMultiAttachmentsThrowsExceptionWithInvalidHost() throws Exception {
////        File tempFile = File.createTempFile("attachment", ".txt");
////        FileWriter writer = new FileWriter(tempFile);
////        writer.write("Attachment content");
////        writer.close();
////        String[] attachments = new String[]{tempFile.getAbsolutePath()};
////        try {
////            EmailUtils.sendEmailMultiAttachments("from@example.com", "to@example.com", "Subject", "Message", attachments);
////        } finally {
////            tempFile.delete();
////        }
////    }
////
//    @Test
//    public void sendEmailMultiAttachmentsHandlesNullAttachments() {
//        try {
//            EmailUtils.sendEmailMultiAttachments(
//                    "from@example.com",
//                    "to@example.com",
//                    "Subject",
//                    "Message",
//                    null);
//        } catch (MessagingException | NullPointerException e) {
//            // Expected due to invalid SMTP host, but method should still throw MessagingException
//        }
//    }
//
//    @Test
//    public void sendEmailSingleAttachmentHandlesNullFileLocation() {
//        try {
//            EmailUtils.sendEmailSingleAttachment("from@example.com", "to@example.com", "Subject", "Message", null);
//        } catch (MessagingException e) {
//            // Should not throw, as exception is caught internally
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailSingleAttachmentHandlesValidAttachment() throws Exception {
//        File tempFile = File.createTempFile("attachment", ".txt");
//        FileWriter writer = new FileWriter(tempFile);
//        writer.write("Attachment content");
//        writer.close();
//        try {
//            EmailUtils.sendEmailSingleAttachment("from@example.com", "to@example.com", "Subject", "Message", tempFile.getAbsolutePath());
//        } catch (MessagingException e) {
//            throw new AssertionError("Exception should not propagate");
//        } finally {
//            tempFile.delete();
//        }
//    }
//
//    @Test
//    public void sendEmailHandlesNullAttachmentsArray() {
//        try {
//            EmailUtils.sendEmail((String[]) null);
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailHandlesEmptyAttachmentsArray() {
//        try {
//            EmailUtils.sendEmail(new String[0]);
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailHandlesValidAttachmentArray() throws Exception {
//        File tempFile = File.createTempFile("attachment", ".txt");
//        FileWriter writer = new FileWriter(tempFile);
//        writer.write("Attachment content");
//        writer.close();
//        try {
//            EmailUtils.sendEmail(new String[]{tempFile.getAbsolutePath()});
//        } catch (Exception e) {
//            // Exception is caught internally, should not propagate
//        } finally {
//            tempFile.delete();
//        }
//    }
//
//    @Test
//    public void sendEmailWithFileLocationAndDateTimeHandlesNullFileLocation() {
//        try {
//            EmailUtils.sendEmail(null, "2024-01-01 12:00:00");
//        } catch (Exception e) {
//            // Exception is caught internally, should not propagate
//        }
//    }
//
//    @Test
//    public void sendEmailWithFileLocationAndDateTimeHandlesValidFileLocation() throws Exception {
//        File tempFile = File.createTempFile("attachment", ".txt");
//        FileWriter writer = new FileWriter(tempFile);
//        writer.write("Attachment content");
//        writer.close();
//        try {
//            EmailUtils.sendEmail(tempFile.getAbsolutePath(), "2024-01-01 12:00:00");
//        } catch (Exception e) {
//            // Exception is caught internally, should not propagate
//        } finally {
//            tempFile.delete();
//        }
//    }
//
//    @Test
//    public void sendEmailWithoutAttachmentHandlesValidInput() {
//        try {
//            EmailUtils.sendEmailWithoutAttachment("12345", "2024-01-01 12:00:00", "Subject [dateTime] [Tin]", "Message [dateTime] [Tin]");
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailWithoutAttachmentHandlesNullTinAndDateTime() {
//        try {
//            EmailUtils.sendEmailWithoutAttachment(null, null, "Subject [dateTime] [Tin]", "Message [dateTime] [Tin]");
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailWithoutAttachmentHandlesNullSubjectAndMessage() {
//        try {
//            EmailUtils.sendEmailWithoutAttachment("12345", "2024-01-01 12:00:00", null, null);
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailWithoutAttachmentHandlesEmptySubjectAndMessage() {
//        try {
//            EmailUtils.sendEmailWithoutAttachment("12345", "2024-01-01 12:00:00", "", "");
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailWithoutAttachmentHandlesNullAllParams() {
//        try {
//            EmailUtils.sendEmailWithoutAttachment(null, null, null, null);
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailWithoutAttachmentReplacesPlaceholdersCorrectly() {
//        // Using a subject and message that contain placeholders.
//        try {
//            EmailUtils.sendEmailWithoutAttachment("12345", "2024-10-10 10:00:00",
//                    "Subject [dateTime] and [Tin]", "Message [dateTime] with [Tin] info");
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailWithoutAttachmentWhenNoPlaceholdersPresent() {
//        try {
//            EmailUtils.sendEmailWithoutAttachment("67890", "2024-11-11 11:11:11",
//                    "Plain Subject", "Plain Message");
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
////    @Test
////    public void sendEmailMultiAttachmentsWorksForValidAttachments() throws Exception {
////        File tempFile = File.createTempFile("attachment", ".txt");
////        FileWriter writer = new FileWriter(tempFile);
////        writer.write("Valid attachment content");
////        writer.close();
////        String[] attachments = new String[]{tempFile.getAbsolutePath()};
////        try {
////            EmailUtils.sendEmailMultiAttachments("from@example.com", "to@example.com", "Valid Subject", "Valid Message", attachments);
////        } catch (MessagingException e) {
////            // Acceptable outcome if MessagingException occurs due to SMTP configuration
////        } finally {
////            tempFile.delete();
////        }
////    }
//
//    @Test
//    public void sendEmailSingleAttachmentHandlesNonExistentFile() {
//        try {
//            EmailUtils.sendEmailSingleAttachment("from@example.com", "to@example.com", "Subject", "Message", "nonexistent-file.txt");
//        } catch (MessagingException e) {
//            throw new AssertionError("Exception should not propagate for non-existent file attachment");
//        }
//    }
//
//    @Test
//    public void sendEmailWorksForValidAttachmentArray() throws Exception {
//        File tempFile = File.createTempFile("attachment", ".txt");
//        FileWriter writer = new FileWriter(tempFile);
//        writer.write("Attachment content for sendEmail");
//        writer.close();
//        try {
//            EmailUtils.sendEmail(new String[]{tempFile.getAbsolutePath()});
//        } catch (Exception e) {
//            // Acceptable outcome if an exception occurs due to SMTP configuration
//        } finally {
//            tempFile.delete();
//        }
//    }
//
////    @Test
////    public void sendEmailMultiAttachmentsHandlesEmptyAttachmentsArray() throws MessagingException {
////        try {
////            EmailUtils.sendEmailMultiAttachments("from@example.com", "to@example.com", "Subject", "Message", new String[]{});
////        } catch (Exception e) {
////            throw new AssertionError("Exception should not propagate");
////        }
////    }
//
//    @Test
//    public void sendEmailHandlesNullFileLocationAndDateTime() {
//        try {
//            EmailUtils.sendEmail(null, null);
//        } catch (Exception e) {
//            // Exception is caught internally, should not propagate
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailHandlesEmptyFileLocationAndDateTime() throws MessagingException {
//        try {
//            EmailUtils.sendEmail("", "");
//        } catch (Exception e) {
//            // Exception is caught internally, should not propagate
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailMultiAttachmentsHandlesNullSenderAddress() {
//        try {
//            EmailUtils.sendEmailMultiAttachments(null, "to@example.com", "Subject", "Message", new String[]{});
//        } catch (MessagingException | NullPointerException e) {
//            // Expected exception due to invalid parameters
//        }
//    }
//
//    @Test
//    public void sendEmailMultiAttachmentsHandlesNullRecipientAddress() {
//        try {
//            EmailUtils.sendEmailMultiAttachments("from@example.com", null, "Subject", "Message", new String[]{});
//        } catch (MessagingException | NullPointerException e) {
//            // Expected exception due to invalid parameters
//        }
//    }
//
//    @Test
//    public void sendEmailMultiAttachmentsHandlesNullSubject() {
//        try {
//            EmailUtils.sendEmailMultiAttachments("from@example.com", "to@example.com", null, "Message", new String[]{});
//        } catch (MessagingException | NullPointerException e) {
//            // Expected exception due to invalid parameters
//        }
//    }
//
//    @Test
//    public void sendEmailMultiAttachmentsHandlesNullMessage() {
//        try {
//            EmailUtils.sendEmailMultiAttachments("from@example.com", "to@example.com", "Subject", null, new String[]{});
//        } catch (MessagingException | NullPointerException e) {
//            // Expected exception due to invalid parameters
//        }
//    }
//
////    @Test
////    public void testSendEmailMultiAttachmentsFullFlow() throws Exception {
////        // Create multiple test files
////        File tempFile1 = File.createTempFile("attachment1", ".txt");
////        File tempFile2 = File.createTempFile("attachment2", ".txt");
////
////        try {
////            // Setup test files
////            FileWriter writer1 = new FileWriter(tempFile1);
////            FileWriter writer2 = new FileWriter(tempFile2);
////            writer1.write("Test content 1");
////            writer2.write("Test content 2");
////            writer1.close();
////            writer2.close();
////
////            // Setup environment variables
////            setupEnvironmentVariables();
////
////            String[] attachments = new String[]{tempFile1.getAbsolutePath(), tempFile2.getAbsolutePath()};
////
////            // Test with valid parameters
////            EmailUtils.sendEmailMultiAttachments(
////                    "test@example.com",
////                    "recipient@example.com",
////                    "Test Subject",
////                    "<html><body>Test Message</body></html>",
////                    attachments
////            );
////        } finally {
////            tempFile1.delete();
////            tempFile2.delete();
////        }
////    }
//
//    @Test
//    public void testSendEmailWithDateTimeReplacementFullFlow() throws Exception {
//        // Create test file
//        File tempFile = File.createTempFile("attachment", ".txt");
//
//        try {
//            // Setup test file
//            FileWriter writer = new FileWriter(tempFile);
//            writer.write("Test content");
//            writer.close();
//
//            // Setup environment variables with placeholders
//            setupEnvironmentVariablesWithPlaceholders();
//
//            String dateTime = "2024-03-20 15:30:00";
//
//            // Test the main flow
//            EmailUtils.sendEmail(tempFile.getAbsolutePath(), dateTime);
//
//            // Verify placeholder replacement and email sending
//            // Would need mock SMTP server for full verification
//
//        } finally {
//            tempFile.delete();
//        }
//    }
//
//    @Test
//    public void testSendEmailWithoutAttachmentFullFlow() throws Exception {
//        // Setup environment variables
//        setupEnvironmentVariables();
//
//        String tin = "123456789";
//        String dateTime = "2024-03-20 15:30:00";
//        String subject = "Test Subject for TIN: [Tin] at [dateTime]";
//        String message = "Test Message for TIN: [Tin] at [dateTime]";
//
//        // Test the main flow with placeholder replacement
//        EmailUtils.sendEmailWithoutAttachment(tin, dateTime, subject, message);
//
//        // Verify placeholder replacement and email sending
//        // Would need mock SMTP server for full verification
//    }
//
//    private void setupEnvironmentVariables() {
//        System.setProperty("PRUN_EMAIL_HOST", "localhost");
//        System.setProperty("PRUN_EMAIL_FROM", "from@example.com");
//        System.setProperty("PRUN_EMAIL_TO", "to@example.com");
//        System.setProperty("PRUN_EMAIL_TO_PODM", "podm@example.com");
//        System.setProperty("PRUN_EMAIL_SUBJECT", "Test Subject");
//        System.setProperty("PRUN_EMAIL_MSG", "Test Message");
//    }
//
//    private void setupEnvironmentVariablesWithPlaceholders() {
//        System.setProperty("PRUN_EMAIL_HOST", "localhost");
//        System.setProperty("PRUN_EMAIL_FROM", "from@example.com");
//        System.setProperty("PRUN_EMAIL_TO", "to@example.com");
//        System.setProperty("PRUN_EMAIL_SUBJECT", "Subject for [dateTime]");
//        System.setProperty("PRUN_EMAIL_MSG", "Message for [dateTime]");
//    }
//
//    @Test
//    public void testSendEmailSingleAttachmentFullFlow() throws Exception {
//        File tempFile = File.createTempFile("singleAttachment", ".txt");
//
//        try {
//            // Setup test file
//            FileWriter writer = new FileWriter(tempFile);
//            writer.write("Single attachment test content");
//            writer.close();
//
//            // Setup environment variables
//            setupEnvironmentVariables();
//
//            // Test with valid parameters
//            EmailUtils.sendEmailSingleAttachment(
//                    "sender@example.com",
//                    "recipient@example.com",
//                    "Single Attachment Test",
//                    "<html><body>Test with single attachment</body></html>",
//                    tempFile.getAbsolutePath()
//            );
//
//        } finally {
//            tempFile.delete();
//        }
//    }
//
//    @Test
//    public void sendEmailMultiAttachmentsHandlesEmptyRecipient() {
//        try {
//            EmailUtils.sendEmailMultiAttachments("from@example.com", "", "Subject", "Message", new String[]{});
//        } catch (MessagingException | NullPointerException e) {
//            // Expected exception due to invalid recipient
//        }
//    }
//
//    @Test
//    public void sendEmailSingleAttachmentHandlesEmptyRecipient() {
//        try {
//            EmailUtils.sendEmailSingleAttachment("from@example.com", "", "Subject", "Message", null);
//        } catch (MessagingException e) {
//            // Expected exception due to invalid recipient
//        }
//    }
//
//    @Test
//    public void sendEmailHandlesEmptyRecipient() {
//        try {
//            EmailUtils.sendEmail(new String[]{});
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailWithoutAttachmentHandlesEmptyRecipient() {
//        try {
//            EmailUtils.sendEmailWithoutAttachment("12345", "2024-01-01 12:00:00", "Subject", "Message");
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailMultiAttachmentsHandlesNullSender() {
//        try {
//            EmailUtils.sendEmailMultiAttachments(null, "to@example.com", "Subject", "Message", new String[]{});
//        } catch (MessagingException | NullPointerException e) {
//            // Expected exception due to invalid sender
//        }
//    }
//
//    @Test
//    public void sendEmailSingleAttachmentHandlesNullSender() {
//        try {
//            EmailUtils.sendEmailSingleAttachment(null, "to@example.com", "Subject", "Message", null);
//        } catch (MessagingException e) {
//            // Expected exception due to invalid sender
//        }
//    }
//
//    @Test
//    public void sendEmailWithoutAttachmentHandlesNullSender() {
//        try {
//            EmailUtils.sendEmailWithoutAttachment(null, "2024-01-01 12:00:00", "Subject", "Message");
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailMultiAttachmentsHandlesInvalidFilePath() {
//        try {
//            EmailUtils.sendEmailMultiAttachments("from@example.com", "to@example.com", "Subject", "Message", new String[]{"invalid/path/to/file.txt"});
//        } catch (Exception e) {
//            // Exception is caught internally, should not propagate
//        }
//    }
//
//    @Test
//    public void sendEmailSingleAttachmentHandlesInvalidFilePath() {
//        try {
//            EmailUtils.sendEmailSingleAttachment("from@example.com", "to@example.com", "Subject", "Message", "invalid/path/to/file.txt");
//        } catch (MessagingException e) {
//            throw new AssertionError("Exception should not propagate for invalid file path");
//        }
//    }
//
//    @Test
//    public void sendEmailHandlesInvalidFilePath() {
//        try {
//            EmailUtils.sendEmail(new String[]{"invalid/path/to/file.txt"});
//        } catch (Exception e) {
//            // Exception is caught internally, should not propagate
//        }
//    }
//
//    @Test
//    public void sendEmailWithoutAttachmentHandlesEmptySubjectAndMessageWithPlaceholders() {
//        try {
//            EmailUtils.sendEmailWithoutAttachment("12345", "2024-01-01 12:00:00", "[dateTime] [Tin]", "[dateTime] [Tin]");
//        } catch (Exception e) {
//            throw new AssertionError("Exception should not propagate");
//        }
//    }
//
//    @Test
//    public void sendEmailMultiAttachmentsHandlesMultipleValidAttachments() throws Exception {
//        File tempFile1 = File.createTempFile("attachment1", ".txt");
//        File tempFile2 = File.createTempFile("attachment2", ".txt");
//        try {
//            FileWriter writer1 = new FileWriter(tempFile1);
//            FileWriter writer2 = new FileWriter(tempFile2);
//            writer1.write("Attachment 1 content");
//            writer2.write("Attachment 2 content");
//            writer1.close();
//            writer2.close();
//
//            EmailUtils.sendEmailMultiAttachments("from@example.com", "to@example.com", "Subject", "Message", new String[]{tempFile1.getAbsolutePath(), tempFile2.getAbsolutePath()});
//        } catch (Exception e) {
//            // Exception is caught internally, should not propagate
//        } finally {
//            tempFile1.delete();
//            tempFile2.delete();
//        }
//    }
//
//    @Test
//    public void testSendEmailWithoutAttachmentMainLogic() throws Exception {
//        // Setup test data
//        String testTin = "123456789";
//        String testDateTime = "2024-03-21 10:00:00";
//        String testSubject = "Test Subject [dateTime] for TIN [Tin]";
//        String testMessage = "Test Message [dateTime] with TIN [Tin]";
//
//        // Setup environment variables
//        setEnv("PRUN_EMAIL_HOST", "smtp.test.com");
//        setEnv("PRUN_EMAIL_FROM", "from@test.com");
//        setEnv("PRUN_EMAIL_TO_PODM", "podm@test.com");
//
//        try {
//            // Call the method
//            EmailUtils.sendEmailWithoutAttachment(testTin, testDateTime, testSubject, testMessage);
//
//            // If no exception is thrown, test passes
//            // Note: Since we can't actually verify email sending without a mock SMTP server,
//            // we're mainly testing that the method executes without throwing exceptions
//        } catch (MessagingException e) {
//            // The test should fail if any unexpected exception occurs
//            fail("Should not throw exception: " + e.getMessage());
//        }
//
//        // Verify expected subject and message transformations
//        String expectedSubject = testSubject
//                .replace("[dateTime]", testDateTime)
//                .replace("[Tin]", testTin);
//        String expectedMessage = testMessage
//                .replace("[dateTime]", testDateTime)
//                .replace("[Tin]", testTin);
//
//        assertTrue(expectedSubject.contains(testDateTime));
//        assertTrue(expectedSubject.contains(testTin));
//        assertTrue(expectedMessage.contains(testDateTime));
//        assertTrue(expectedMessage.contains(testTin));
//    }
//
//}
