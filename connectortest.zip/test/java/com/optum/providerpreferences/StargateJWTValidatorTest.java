package com.optum.providerpreferences;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

import java.io.File;
import java.util.Base64;
import java.util.List;

import static org.junit.Assert.*;

public class StargateJWTValidatorTest {

	@InjectMocks
	private StargateJWTValidator validator;

	@Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);

		// Provide any dummy cert file path
		ReflectionTestUtils.setField(validator, "stargateCert", "src/test/resources/test-cert.crt");
	}

	@Test(expected = IllegalArgumentException.class)
	public void testValidateJWT_NullToken() throws Exception {
		validator.validateJWT(null);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testValidateJWT_EmptyToken() throws Exception {
		validator.validateJWT("");
	}

	@Test(expected = Exception.class)
	public void testValidateJWT_InvalidJWTFormat() throws Exception {
		validator.validateJWT("invalid.token.value");
	}

	@Test(expected = IllegalArgumentException.class)
	public void testValidateJWT_MissingX5C() throws Exception {
		String tokenWithoutX5C = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTYifQ.signature";
		validator.validateJWT(tokenWithoutX5C);
	}

	@Test(expected = Exception.class)
	public void testValidateJWT_FileNotFound() throws Exception {

		// Force wrong cert path
		ReflectionTestUtils.setField(validator, "stargateCert", "wrong-path.crt");

		String fakeToken = "eyJhbGciOiJIUzI1NiIsIng1YyI6WyJkdW1teSJdfQ.payload.signature";
		validator.validateJWT(fakeToken);
	}

	@Test(expected = Exception.class)
	public void testValidateJWT_InvalidCertificateFormat() throws Exception {

		File tempFile = File.createTempFile("invalid", ".crt");
		tempFile.deleteOnExit();

		ReflectionTestUtils.setField(validator, "stargateCert", tempFile.getAbsolutePath());

		String fakeToken = "eyJhbGciOiJIUzI1NiIsIng1YyI6WyJkdW1teSJdfQ.payload.signature";

		validator.validateJWT(fakeToken);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testValidateJWT_NullX5C() throws Exception {

		// Valid JWT format but no x5c
		String token = JWT.create().withSubject("test").sign(Algorithm.HMAC256("secret"));

		validator.validateJWT(token);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testValidateJWT_EmptyCertificate() throws Exception {

		String token = JWT.create().withHeader(java.util.Map.of("x5c", List.of(""))).sign(Algorithm.HMAC256("secret"));

		validator.validateJWT(token);
	}

	@Test(expected = Exception.class)
	public void testValidateJWT_PEMConversion() throws Exception {

		String pem = "-----BEGIN CERTIFICATE-----\nABCDEF\n-----END CERTIFICATE-----";

		String token = JWT.create().withHeader(java.util.Map.of("x5c", List.of(pem))).sign(Algorithm.HMAC256("secret"));

		validator.validateJWT(token);
	}

	@Test(expected = Exception.class)
	public void testValidateJWT_Base64ValidButVerificationFails() throws Exception {

		String validBase64 = Base64.getUrlEncoder().encodeToString("dummy".getBytes());

		String token = JWT.create().withHeader(java.util.Map.of("x5c", List.of(validBase64)))
				.sign(Algorithm.HMAC256("secret"));

		validator.validateJWT(token);
	}

	@Test(expected = Exception.class)
	public void testValidateJWT_CertificateValidityFailure() throws Exception {

		String cert = Base64.getUrlEncoder().encodeToString("expiredCert".getBytes());

		String token = JWT.create().withHeader(java.util.Map.of("x5c", List.of(cert)))
				.sign(Algorithm.HMAC256("secret"));

		validator.validateJWT(token);
	}
}
