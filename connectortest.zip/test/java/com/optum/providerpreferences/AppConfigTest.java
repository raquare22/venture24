package com.optum.providerpreferences;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

public class AppConfigTest {

    @Test
    public void testThreadPoolTaskExecutor() {
        AppConfig appConfig = new AppConfig();
        Executor executor = appConfig.threadPoolTaskExecutor();

        assertTrue(executor instanceof ThreadPoolTaskExecutor);

        ThreadPoolTaskExecutor threadPoolTaskExecutor = (ThreadPoolTaskExecutor) executor;
        assertEquals(100, threadPoolTaskExecutor.getCorePoolSize());
        assertEquals(100, threadPoolTaskExecutor.getMaxPoolSize());
        assertEquals(500, threadPoolTaskExecutor.getQueueCapacity());
    }
}