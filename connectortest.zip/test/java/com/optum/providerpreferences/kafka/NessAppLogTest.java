package com.optum.providerpreferences.kafka;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.MockedStatic;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.eis.kraken.core.NessLog;

import java.net.InetSocketAddress;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class NessAppLogTest {

	@BeforeClass
	public static void initConfigData() {

		ConfigData.appAskid = "ASK-123456"; // ✅ FIXED
		ConfigData.appname = "TestApp";
		ConfigData.devicevendor = "Optum";
		ConfigData.deviceproduct = "ProviderPref";

		ConfigData.enableNess = false; // ✅ avoid kafka
	}

	@Before
	public void setUp() {
		// ✅ prevent Kafka real initialization
		KafkaProducer.setUpOff();
		NessAppLog.kafkaAsyncProducer = null;
		NessAppLog.shutdown = false;
	}

	// ✅ Test default properties initialization
	@Test
	public void testGetDefaultProperties() {
		assertNotNull(NessAppLog.getDefaultProperties());
	}

	@Test
	public void testStartup() {

		NessLog.NessLogBuilder builder = mock(NessLog.NessLogBuilder.class);
		NessLog log = mock(NessLog.class);

		when(builder.setMsg(anyString())).thenReturn(builder);
		when(builder.setRequiredFields(any())).thenReturn(builder);
		when(builder.setReceivedTime(anyLong())).thenReturn(builder);
		when(builder.setApplicationEnvironment(any())).thenReturn(builder);
		when(builder.setSeverity(any())).thenReturn(builder);
		when(builder.setLogClass(any())).thenReturn(builder);
		when(builder.buildLog()).thenReturn(log);

		try (MockedStatic<NessAppLog> mock = mockStatic(NessAppLog.class, CALLS_REAL_METHODS)) {

			mock.when(NessAppLog::getNessLogBuilder).thenReturn(builder);

			NessAppLog.startup();

			assertFalse(NessAppLog.shutdown);
		}
	}

	@Test
	public void testShutdown() {

		NessLog.NessLogBuilder builder = mock(NessLog.NessLogBuilder.class);
		NessLog log = mock(NessLog.class);

		when(builder.setMsg(anyString())).thenReturn(builder);
		when(builder.setRequiredFields(any())).thenReturn(builder);
		when(builder.setReceivedTime(anyLong())).thenReturn(builder);
		when(builder.setApplicationEnvironment(any())).thenReturn(builder);
		when(builder.setSeverity(any())).thenReturn(builder);
		when(builder.setLogClass(any())).thenReturn(builder);
		when(builder.buildLog()).thenReturn(log);

		try (MockedStatic<NessAppLog> mock = mockStatic(NessAppLog.class, CALLS_REAL_METHODS)) {

			mock.when(NessAppLog::getNessLogBuilder).thenReturn(builder);

			NessAppLog.shutdown();

			assertTrue(NessAppLog.shutdown);
		}
	}

	@Test
	public void testCreateHttpLogEvent_StringSuccess() {

		KafkaProducer.setUpOff(); // disable publishing

		HttpHeaders headers = new HttpHeaders();
		headers.setHost(new InetSocketAddress("localhost", 8080));

		NessAppLog.createHttpLogEvent(headers, "msg", "response");

		assertFalse(NessAppLog.shutdown);
	}

	@Test
	public void testCreateHttpLogEvent_StringFailure() {

		KafkaProducer.setUpOff();

		HttpHeaders headers = new HttpHeaders();
		headers.setHost(new InetSocketAddress("localhost", 8080));

		NessAppLog.createHttpLogEvent(headers, "msg", "error", false);

		assertFalse(NessAppLog.shutdown);
	}

	@Test
	public void testCreateHttpLogEvent_ResponseEntitySuccess() {

		KafkaProducer.setUpOff();

		HttpHeaders headers = new HttpHeaders();
		headers.setHost(new InetSocketAddress("localhost", 8080));

		ResponseEntity<String> response = new ResponseEntity<>("body", HttpStatus.OK);

		NessAppLog.createHttpLogEvent(headers, "msg", response);

		assertNotNull(response);
	}

	@Test
	public void testCreateHttpLogEvent_ResponseEntityFailure() {

		KafkaProducer.setUpOff();

		HttpHeaders headers = new HttpHeaders();
		headers.setHost(new InetSocketAddress("localhost", 8080));

		ResponseEntity<String> response = new ResponseEntity<>("body", HttpStatus.BAD_REQUEST);

		NessAppLog.createHttpLogEvent(headers, "msg", response);

		assertNotNull(response);
	}

	@Test
	public void testPublishLog_WhenShutdown() {

		NessAppLog.shutdown = true;

		NessAppLog.publishLog(null); // should return safely

		assertTrue(NessAppLog.shutdown);
	}

	@Test
	public void testPublishLog_WithProducer() {

		NessAppLog.shutdown = false;

		NessAppLog.kafkaAsyncProducer = mock(com.optum.eis.kraken.kafka.producers.NessKafkaAsyncProducer.class);

		NessAppLog.publishLog(null);

		verify(NessAppLog.kafkaAsyncProducer, times(1)).publishNessLogsAsync(null);
	}

	@Test
	public void testGetNessLogBuilderIndirect() {

		NessLog.NessLogBuilder builder = mock(NessLog.NessLogBuilder.class);
		NessLog log = mock(NessLog.class);

		// ✅ stub builder chain
		when(builder.setMsg(anyString())).thenReturn(builder);
		when(builder.setRequiredFields(any())).thenReturn(builder);
		when(builder.setReceivedTime(anyLong())).thenReturn(builder);
		when(builder.setApplicationEnvironment(any())).thenReturn(builder);
		when(builder.setSeverity(any())).thenReturn(builder);
		when(builder.setLogClass(any())).thenReturn(builder);
		when(builder.buildLog()).thenReturn(log);

		try (MockedStatic<NessAppLog> mock = mockStatic(NessAppLog.class, CALLS_REAL_METHODS)) {

			// ✅ CRITICAL: override builder
			mock.when(NessAppLog::getNessLogBuilder).thenReturn(builder);

			NessAppLog.startup(); // ✅ now safe

			assertNotNull(NessAppLog.requiredFields);
		}
	}
	
	@Test
	public void testCreateHttpLogEvent_SuccessBranch() {
		
		ReflectionTestUtils.setField(KafkaProducer.class, "setUp", true);
	    HttpHeaders headers = new HttpHeaders();
	    headers.setHost(new java.net.InetSocketAddress("localhost", 8080));

	    NessLog.NessLogBuilder builder = mock(NessLog.NessLogBuilder.class);
	    NessLog log = mock(NessLog.class);

	    when(builder.setMsg(anyString())).thenReturn(builder);
	    when(builder.setOutcome(any())).thenReturn(builder);
	    when(builder.setReason(anyString())).thenReturn(builder);
	    when(builder.setSourceHostHostname(anyString())).thenReturn(builder);
	    when(builder.setSourceHostPort(anyInt())).thenReturn(builder);
	    when(builder.buildLog()).thenReturn(log);

	    try (MockedStatic<NessAppLog> mock = mockStatic(NessAppLog.class, CALLS_REAL_METHODS)) {

	        mock.when(NessAppLog::getNessLogBuilder).thenReturn(builder);

	        NessAppLog.createHttpLogEvent(headers, "msg", "response");

	        verify(builder).setOutcome(any());
	    }
	}
	
	@Test
	public void testCreateHttpLogEvent_FailureBranch() {

		// ✅ ENABLE flow
		ReflectionTestUtils.setField(KafkaProducer.class, "setUp", true);

	    HttpHeaders headers = new HttpHeaders();

	    NessLog.NessLogBuilder builder = mock(NessLog.NessLogBuilder.class);

	    when(builder.setMsg(anyString())).thenReturn(builder);
	    when(builder.setOutcome(any())).thenReturn(builder);
	    when(builder.setReason(anyString())).thenReturn(builder);
	    when(builder.buildLog()).thenReturn(mock(NessLog.class));

	    try (MockedStatic<NessAppLog> mock = mockStatic(NessAppLog.class, CALLS_REAL_METHODS)) {

	        mock.when(NessAppLog::getNessLogBuilder).thenReturn(builder);

	        NessAppLog.createHttpLogEvent(headers, "msg", "error", false);

	        verify(builder).setOutcome(any());
	    }
	}
	
	@Test
	public void testCreateHttpLogEvent_ResponseEntitySuccessBranch() {

		ReflectionTestUtils.setField(KafkaProducer.class, "setUp", true);

	    HttpHeaders headers = new HttpHeaders();

	    ResponseEntity<String> response =
	            new ResponseEntity<>("body", HttpStatus.OK);

	    NessLog.NessLogBuilder builder = mock(NessLog.NessLogBuilder.class);

	    when(builder.setMsg(anyString())).thenReturn(builder);
	    when(builder.setOutcome(any())).thenReturn(builder);
	    when(builder.setReason(anyString())).thenReturn(builder);
	    when(builder.buildLog()).thenReturn(mock(NessLog.class));

	    try (MockedStatic<NessAppLog> mock = mockStatic(NessAppLog.class, CALLS_REAL_METHODS)) {

	        mock.when(NessAppLog::getNessLogBuilder).thenReturn(builder);

	        NessAppLog.createHttpLogEvent(headers, "msg", response);

	        verify(builder).setOutcome(any());
	    }
	}

	@Test
	public void testCreateHttpLogEvent_ResponseEntityNull() {

		ReflectionTestUtils.setField(KafkaProducer.class, "setUp", true);

	    HttpHeaders headers = new HttpHeaders();

	    NessLog.NessLogBuilder builder = mock(NessLog.NessLogBuilder.class);

	    when(builder.setMsg(anyString())).thenReturn(builder);
	    when(builder.setOutcome(any())).thenReturn(builder);
	    when(builder.setReason(anyString())).thenReturn(builder);
	    when(builder.buildLog()).thenReturn(mock(NessLog.class));

	    try (MockedStatic<NessAppLog> mock = mockStatic(NessAppLog.class, CALLS_REAL_METHODS)) {

	        mock.when(NessAppLog::getNessLogBuilder).thenReturn(builder);

	        NessAppLog.createHttpLogEvent(headers, "msg", (ResponseEntity<?>) null);

	        verify(builder).setOutcome(any());
	    }
	}
}