package com.optum.providerpreferences.kafka;

import static org.junit.Assert.*;

import org.junit.Test;

public class ConfigDataTest {

	@Test
	public void testAllSetterMethods() {

		ConfigData config = new ConfigData();

		config.setBrokerList("broker1");
		config.setKafkaTopic("topic1");
		config.setKafkaKeyPass("keypass");
		config.setKafkaKeystorePass("storepass");
		config.setTags("tag1");
		config.setAppAskId("askid");
		config.setAppName("appName");
		config.setDeviceVendor("vendor");
		config.setDeviceProduct("product");
		config.setKafkaClientId("clientId");
		config.setKafkaProtocol("protocol");
		config.setKafkaKeyStorePath("path");
		config.setProducerType("producer");
		config.setEnableNess(true);

		// ✅ Assertions for static variables
		assertEquals("broker1", ConfigData.brokerlist);
		assertEquals("topic1", ConfigData.kafkatopic);
		assertEquals("keypass", ConfigData.kafkaKeypass);
		assertEquals("storepass", ConfigData.kafkaKeystorepass);
		assertEquals("tag1", ConfigData.tag);
		assertEquals("askid", ConfigData.appAskid);
		assertEquals("appName", ConfigData.appname);
		assertEquals("vendor", ConfigData.devicevendor);
		assertEquals("product", ConfigData.deviceproduct);
		assertEquals("clientId", ConfigData.kafkaclientId);
		assertEquals("protocol", ConfigData.Kafkaprotocol);
		assertEquals("path", ConfigData.kafkaKeyStorepath);
		assertEquals("producer", ConfigData.producerType);
		assertTrue(ConfigData.enableNess);
	}

	@Test
	public void testGetEnableNess() {

		ConfigData.enableNess = true;

		ConfigData config = new ConfigData();

		boolean result = config.getEnableNess();

		assertTrue(result);
	}
}