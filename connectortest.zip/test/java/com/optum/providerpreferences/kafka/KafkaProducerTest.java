package com.optum.providerpreferences.kafka;

import com.optum.eis.kraken.kafka.producers.NessKafkaAsyncProducer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class KafkaProducerTest {

    @InjectMocks
    private KafkaProducer kafkaProducer;

    private KafkaProducer kafkaProducerSpy;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        kafkaProducerSpy = spy(new KafkaProducer());

        // ✅ Set required ConfigData values (VERY IMPORTANT)
        ConfigData.brokerlist = "broker";
        ConfigData.kafkatopic = "topic";
        ConfigData.kafkaKeypass = "keypass";
        ConfigData.kafkaKeyStorepath = "path";
        ConfigData.kafkaKeystorepass = "storepass";
        ConfigData.kafkaclientId = "client";
        ConfigData.Kafkaprotocol = "SSL";
    }

    // ✅ 1. Test static setup flag OFF
    @Test
    public void testSetUpOff() {
        KafkaProducer.setUpOff();
        assertFalse(KafkaProducer.getSetUp());
    }

    // ✅ 2. Test getSetUp default
    @Test
    public void testGetSetUp_Default() {
        // reset manually
        ReflectionTestUtils.setField(KafkaProducer.class, "setUp", true);

        assertTrue(KafkaProducer.getSetUp());
    }

    // ✅ 3. Test getNewNessKafkaAsyncProducer
    @Test
    public void testGetNewNessKafkaAsyncProducer() {

        NessKafkaAsyncProducer mockProducer = mock(NessKafkaAsyncProducer.class);

        // mock internal call
        doReturn(mockProducer).when(kafkaProducerSpy).getKafkaProducer();

        NessKafkaAsyncProducer result =
                kafkaProducerSpy.getNewNessKafkaAsyncProducer();

        assertNotNull(result);
        assertEquals(mockProducer, result);
    }

    @Test
    public void testGetKafkaProducer_BuilderCalled() {

        KafkaProducer kafkaProducerSpy = spy(new KafkaProducer());

        NessKafkaAsyncProducer mockAsync = mock(NessKafkaAsyncProducer.class);

        // ✅ stub internal method
        doReturn(mockAsync)
                .when(kafkaProducerSpy)
                .getKafkaProducer();

        NessKafkaAsyncProducer result =
                kafkaProducerSpy.getKafkaProducer();

        assertNotNull(result);
        assertEquals(mockAsync, result);
    }

    // ✅ 5. Test getNewNessKafkaAsyncProducer sets field
    @Test
    public void testGetNewNessKafkaAsyncProducer_InternalState() {

        NessKafkaAsyncProducer mockProducer = mock(NessKafkaAsyncProducer.class);

        doReturn(mockProducer).when(kafkaProducerSpy).getKafkaProducer();

        kafkaProducerSpy.getNewNessKafkaAsyncProducer();

        // ✅ verify field updated
        assertNotNull(ReflectionTestUtils.getField(
                kafkaProducerSpy, "nessKafkaAsyncProducer"));
    }
}
