package com.optum.providerpreferences.kafka;

import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;

public class UtilityTest {

    @Test
    public void getEnvironment_envVariableNotSet() {
        ReflectionTestUtils.setField(Utility.class, "activeProfile", "local");
        String expected = "local";
        assertEquals(expected, Utility.getEnvironment());
    }
}
