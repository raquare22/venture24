package com.optum.providerpreferences.kafka;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class EnvironmentsTest {

    @Test
    public void testGetEnv() {
        // Test each enum value and its corresponding environment string
        assertEquals("local", Environments.LOCAL.getEnv());
        assertEquals("dev", Environments.DEV.getEnv());
        assertEquals("stage", Environments.STAGE.getEnv());
        assertEquals("prod", Environments.PROD.getEnv());
    }

    @Test
    public void testEnumValues() {
        // Test the number of enum values
        Environments[] values = Environments.values();
        assertEquals(4, values.length);

        // Test the order of enum values
        assertEquals(Environments.LOCAL, values[0]);
        assertEquals(Environments.DEV, values[1]);
        assertEquals(Environments.STAGE, values[2]);
        assertEquals(Environments.PROD, values[3]);
    }
}
