package com.optum.providerpreferences.service;

import com.optum.providerpreferences.rs.model.PaymentPreference;
import com.optum.providerpreferences.rs.service.PaymentPreferenceServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

@RunWith(MockitoJUnitRunner.class)
public class PaymentPreferenceServiceImplTest {

    @Mock
    MongoOperations mongoOperations;

    @Mock
    private MongoTemplate mongoTemplate;

    @InjectMocks
	@Spy
	PaymentPreferenceServiceImpl paymentPreferenceService;


    private PaymentPreference doc;
    
    @Before
    public void setUp() {
            doc = new PaymentPreference();
            doc.setId("testId");
            doc.setTin("451230492");
            doc.setPaymentpref("ACH");
            doc.setMpin("9358938");
            doc.setUpdatedBy("abc");
        }

    @Test
    public void testInsertPaymentPreference() {
		when(mongoTemplate.insert(any(PaymentPreference.class), eq("paymentPreference"))).thenReturn(doc);
        PaymentPreference result = paymentPreferenceService.insertPaymentPreference(doc);
        assertNotNull(result);
        assertEquals("testId", result.getId());
    }
    
    @Test
 
    public void testGetPaymentPreferenceByTinAndMpin() {

        when(mongoTemplate.findOne(query(where("tin").is(doc.getTin()).and("mpin").is(doc.getMpin())), PaymentPreference.class, "paymentPreference"))
                .thenReturn(doc);
        
        PaymentPreference result = paymentPreferenceService.getPaymentPreferenceByTinAndMpin(doc.getTin(), doc.getMpin());
        assertNotNull(result);
     
        assertEquals("9358938", result.getMpin());
        assertEquals("451230492", result.getTin());
        verify(mongoTemplate, times(1)).findOne(query(where("tin").is(doc.getTin()).and("mpin").is(doc.getMpin())), PaymentPreference.class, "paymentPreference");
    }


    @Test
    public void testUpdatePaymentPreference_DocumentExists() {
        when(mongoTemplate.findOne(query(where("tin").is(doc.getTin()).and("mpin").is(doc.getMpin())), PaymentPreference.class, "paymentPreference"))
                .thenReturn(doc);

        PaymentPreference result = paymentPreferenceService.updatePaymentPreference(doc.getTin(), doc.getMpin(), doc.getPaymentPref(), doc.getUpdatedBy(), doc.getUpdatedByName());

        assertNotNull(result);
        assertEquals("testId", result.getId());
        assertEquals("451230492", result.getTin());
        verify(mongoTemplate, times(1)).save(doc, "paymentPreference");
    }

    @Test
    public void testUpdatePaymentPreference_DocumentDoesNotExist() {
        when(mongoTemplate.findOne(query(where("tin").is(doc.getTin()).and("mpin").is(doc.getMpin())), PaymentPreference.class, "paymentPreference"))
                .thenReturn(null);

        PaymentPreference result = paymentPreferenceService.updatePaymentPreference(doc.getTin(), doc.getMpin(), doc.getPaymentPref(), doc.getUpdatedBy(), doc.getUpdatedByName());

        assertNull(result);
        verify(mongoTemplate, never()).save(any(PaymentPreference.class), eq("paymentPreference"));
    }
    
	@Test
	public void testInsertPaymentPreference_existingDoc() {

		doc.setId("123");

		when(mongoTemplate.findOne(any(), eq(PaymentPreference.class), eq("paymentPreference"))).thenReturn(doc);

		PaymentPreference result = paymentPreferenceService.insertPaymentPreference(doc);

		assertNotNull(result);
		verify(mongoTemplate).save(any(PaymentPreference.class), eq("paymentPreference"));
	}
	
	@Test
	public void testInsertPaymentPreference_idPresent_butNotFound() {

		doc.setId("123");

		when(mongoTemplate.findOne(any(), eq(PaymentPreference.class), eq("paymentPreference"))).thenReturn(null);

		when(mongoTemplate.insert(any(PaymentPreference.class), eq("paymentPreference"))).thenReturn(doc);

		PaymentPreference result = paymentPreferenceService.insertPaymentPreference(doc);

		assertNotNull(result);
	}
	
	@Test
	public void testGetPaymentPreference() {

		when(mongoTemplate.findOne(any(), eq(PaymentPreference.class))).thenReturn(doc);

		PaymentPreference result = paymentPreferenceService.getPaymentPreference("123");

		assertNotNull(result);
	}

	@Test
	public void testDeletePaymentPreference() {

		paymentPreferenceService.deletePaymentPreference("123");

		verify(mongoTemplate).remove(any(), eq(PaymentPreference.class), eq("paymentPreference"));
	}

	@Test
	public void testGetPaymentPreferenceList() {

		List<PaymentPreference> list = new ArrayList<>();
		list.add(doc);

		when(mongoTemplate.find(any(), eq(PaymentPreference.class), eq("paymentPreference"))).thenReturn(list);

		List<PaymentPreference> result = paymentPreferenceService.getPaymentPreferenceList(List.of("1"));

		assertEquals(1, result.size());
	}

	@Test
	public void testInsertMultiPaymentPreferences() {

		List<PaymentPreference> list = new ArrayList<>();
		list.add(doc);

		when(mongoTemplate.insert(any(List.class), eq("paymentPreference"))).thenReturn(list);

		List<PaymentPreference> result = paymentPreferenceService.insertMultiPaymentPreferences(list);

		assertEquals(1, result.size());
	}
	
	@Test
	public void testUpdatePaymentPreference_optOut() throws Exception {

		PaymentPreference existing = doc;

		when(mongoTemplate.findOne(any(), eq(PaymentPreference.class), eq("paymentPreference"))).thenReturn(existing);

		doNothing().when(paymentPreferenceService).handleOptOutPreference(anyString(), anyString());

		PaymentPreference result = paymentPreferenceService.updatePaymentPreference("tin", "mpin", "optOut", "user",
				"name");

		assertNotNull(result);
	}

	@Test
	public void testUpdatePaymentPreference_insertFlow() {

		when(mongoTemplate.findOne(any(), eq(PaymentPreference.class), eq("paymentPreference"))).thenReturn(null)
				.thenReturn(doc);

		PaymentPreference result = paymentPreferenceService.updatePaymentPreference("tin", "mpin", "ACH", "user",
				"name");

		assertNotNull(result);
	}

}
