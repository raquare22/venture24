package com.optum.providerpreferences.service;
import com.optum.providerpreferences.rs.model.PaymentPreference;
import com.optum.providerpreferences.rs.service.PaymentPreferenceServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

@RunWith(MockitoJUnitRunner.class)
public class PaymentPreferenceServiceTest {
	
	@Mock
	MongoTemplate mongoTemplate;
	 
	@InjectMocks
    PaymentPreferenceServiceImpl paymentPreferenceService;
    
    @Before
    public void setUp() {
    	paymentPreferenceService.setMongoQueryMaxMillis("30000");
    }


    @Test
    public void testInsertPaymentPreference() {
    	PaymentPreference paymentPref = new PaymentPreference();
    	paymentPref.setTin("451230492");
    	paymentPref.setId("testId");
    	paymentPref.setUpdatedBy("abc");
        when(mongoTemplate.insert(paymentPref, "paymentPreference"))
                .thenReturn(paymentPref);

        PaymentPreference result = paymentPreferenceService.insertPaymentPreference(paymentPref);
        System.out.print(result);
        assertNotNull(result);
        assertEquals("451230492", result.getTin());
        assertEquals("testId", result.getId());
        verify(mongoTemplate, times(1)).insert(paymentPref, "paymentPreference");
    }
    
    @Test
    public void testDeletePaymentPreference() {
    	String id = "123";
        paymentPreferenceService.deletePaymentPreference(id);
        verify(mongoTemplate, times(1)).remove(query(where("id").is(id)), PaymentPreference.class, "paymentPreference");
    }
    
    
    @Test
    public void testInsertMultiPaymentPreferences() {
      
		List<PaymentPreference> docList=new ArrayList<PaymentPreference>();
		List<PaymentPreference> list2=new ArrayList<PaymentPreference>();
		when(mongoTemplate.insert(any(List.class), anyString())).thenReturn(docList);
		List<PaymentPreference> result=paymentPreferenceService.insertMultiPaymentPreferences(list2);
		assertNotNull(result);
		assertEquals(result, docList);
    }

    @Test
    public void testUpdatePaymentPreference() {
        String tin = "12345";
        String mpin = "67890";
        String paymentPref = "NEW_PREF";
        String updatedBy = "testUser";
        String updatedByName = "Test User";

        PaymentPreference existingDoc = new PaymentPreference();
        existingDoc.setId("testId");
        existingDoc.setTin(tin);
        existingDoc.setMpin(mpin);

        when(mongoTemplate.findOne(query(where("tin").is(tin).and("mpin").is(mpin)), PaymentPreference.class, "paymentPreference"))
                .thenReturn(existingDoc);

        // Mock save to return the updated document
        when(mongoTemplate.save(any(PaymentPreference.class), eq("paymentPreference")))
                .thenAnswer(invocation -> invocation.getArgument(0));

        PaymentPreference result = paymentPreferenceService.updatePaymentPreference(tin, mpin, paymentPref, updatedBy, updatedByName);

        assertNotNull(result);
        assertEquals("testId", result.getId());
        assertEquals(tin, result.getTin());
        assertEquals(paymentPref, result.getPaymentPref());
        verify(mongoTemplate, times(1)).save(existingDoc, "paymentPreference");
    }

    
}

