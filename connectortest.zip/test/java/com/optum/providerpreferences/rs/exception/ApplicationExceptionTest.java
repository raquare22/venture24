package com.optum.providerpreferences.rs.exception;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ApplicationExceptionTest {

    @Test
    public void testApplicationExceptionMessage() {
        // Arrange
        String expectedMessage = "Test exception message";

        // Act
        ApplicationException exception = new ApplicationException(expectedMessage);

        // Assert
        assertEquals(expectedMessage, exception.getMessage());
    }
}