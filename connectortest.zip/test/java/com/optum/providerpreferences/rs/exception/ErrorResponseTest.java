package com.optum.providerpreferences.rs.exception;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ErrorResponseTest {

    @Test
    public void testErrorResponseConstructorAndGetters() {
        // Arrange
        String expectedErrorCode = "400";
        String expectedErrorMessage = "Bad Request";

        // Act
        ErrorResponse errorResponse = new ErrorResponse(expectedErrorCode, expectedErrorMessage);

        // Assert
        assertEquals(expectedErrorCode, errorResponse.getErrorCode());
        assertEquals(expectedErrorMessage, errorResponse.getErrorMessage());
    }

    @Test
    public void testErrorResponseSetters() {
        // Arrange
        ErrorResponse errorResponse = new ErrorResponse(null, null);
        String newErrorCode = "500";
        String newErrorMessage = "Internal Server Error";

        // Act
        errorResponse.setErrorCode(newErrorCode);
        errorResponse.setErrorMessage(newErrorMessage);

        // Assert
        assertEquals(newErrorCode, errorResponse.getErrorCode());
        assertEquals(newErrorMessage, errorResponse.getErrorMessage());
    }
}