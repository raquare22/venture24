package com.optum.providerpreferences.rs.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TokenTest {

    @Test
    public void testSettersAndGetters() {
        Token token = new Token();

        token.setAccessToken("access123");
        token.setRefreshToken("refresh123");
        token.setTokenType("Bearer");
        token.setExpiresIn("3600");
        token.setCreatedAt("2023-01-01T00:00:00Z");

        assertEquals("access123", token.getAccessToken());
        assertEquals("refresh123", token.getRefreshToken());
        assertEquals("Bearer", token.getTokenType());
        assertEquals("3600", token.getExpiresIn());
        assertEquals("2023-01-01T00:00:00Z", token.getCreatedAt());
    }

    @Test
    public void testToString() {
        Token token = new Token();
        token.setAccessToken("access123");
        token.setRefreshToken("refresh123");
        token.setTokenType("Bearer");
        token.setExpiresIn("3600");
        token.setCreatedAt("2023-01-01T00:00:00Z");

        String expected = "Token [access_token=access123, refresh_token=refresh123, token_type=Bearer, expires_in=3600, created_at=2023-01-01T00:00:00Z]";
        assertEquals(expected, token.toString());
    }
}