package com.optum.providerpreferences.rs.model.optout;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;

public class OptOutAuditMetadataTest {

    private OptOutAuditMetadata optOutAuditMetadata;

    @Before
    public void setUp() {
        optOutAuditMetadata = new OptOutAuditMetadata();
    }

    @Test
    public void testDefaultInitialization() {
        assertNotNull(optOutAuditMetadata.getOptOutRequest());
        assertNotNull(optOutAuditMetadata.getOptOutUpdate());
        assertNotNull(optOutAuditMetadata.getDocumentIds());
        assertNotNull(optOutAuditMetadata.getUpdated());
        assertNotNull(optOutAuditMetadata.getFailedDocumentIds());
    }

    @Test
    public void testSetAndGetRecordType() {
        String recordType = "TestRecordType";
        optOutAuditMetadata.setRecordType(recordType);
        assertEquals(recordType, optOutAuditMetadata.getRecordType());
    }

    @Test
    public void testSetAndGetOptOutRequest() {
        OptOutRequest optOutRequest = new OptOutRequest();
        optOutAuditMetadata.setOptOutRequest(optOutRequest);
        assertEquals(optOutRequest, optOutAuditMetadata.getOptOutRequest());
    }

    @Test
    public void testSetAndGetOptOutUpdate() {
        OptOutAuditUpdate optOutUpdate = new OptOutAuditUpdate();
        optOutAuditMetadata.setOptOutUpdate(optOutUpdate);
        assertEquals(optOutUpdate, optOutAuditMetadata.getOptOutUpdate());
    }

    @Test
    public void testSetAndGetDocumentIds() {
        optOutAuditMetadata.setDocumentIds(Arrays.asList("doc1", "doc2"));
        assertEquals(2, optOutAuditMetadata.getDocumentIds().size());
        assertTrue(optOutAuditMetadata.getDocumentIds().contains("doc1"));
        assertTrue(optOutAuditMetadata.getDocumentIds().contains("doc2"));
    }

    @Test
    public void testSetAndGetUpdated() {
        optOutAuditMetadata.setUpdated(Arrays.asList("update1", "update2"));
        assertEquals(2, optOutAuditMetadata.getUpdated().size());
        assertTrue(optOutAuditMetadata.getUpdated().contains("update1"));
        assertTrue(optOutAuditMetadata.getUpdated().contains("update2"));
    }

    @Test
    public void testSetAndGetFailedDocumentIds() {
        optOutAuditMetadata.setFailedDocumentIds(Arrays.asList("failed1", "failed2"));
        assertEquals(2, optOutAuditMetadata.getFailedDocumentIds().size());
        assertTrue(optOutAuditMetadata.getFailedDocumentIds().contains("failed1"));
        assertTrue(optOutAuditMetadata.getFailedDocumentIds().contains("failed2"));
    }

    @Test
    public void testToString() {
        optOutAuditMetadata.setRecordType("TestRecordType");
        String toStringResult = optOutAuditMetadata.toString();
        assertTrue(toStringResult.contains("TestRecordType"));
    }
}