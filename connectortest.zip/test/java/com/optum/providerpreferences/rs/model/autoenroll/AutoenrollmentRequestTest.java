package com.optum.providerpreferences.rs.model.autoenroll;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class AutoenrollmentRequestTest {

    @Test
    public void testGettersAndSetters() {
        AutoenrollmentRequest request = new AutoenrollmentRequest();

        // Test setting and getting autoenrollDocuments
        List<AutoenrollmentObj> documents = new ArrayList<>();
        AutoenrollmentObj obj = new AutoenrollmentObj();
        obj.setTin("123456789");
        documents.add(obj);

        request.setAutoenrollDocuments(documents);

        assertNotNull(request.getAutoenrollDocuments());
        assertEquals(1, request.getAutoenrollDocuments().size());
        assertEquals("123456789", request.getAutoenrollDocuments().get(0).getTin());
    }
}