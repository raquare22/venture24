package com.optum.providerpreferences.rs.model.ndb.preferences;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class UILetterPreferencesRequestTest {

    private UILetterPreferencesRequest uiLetterPreferencesRequest;

    @Before
    public void setUp() {
        uiLetterPreferencesRequest = new UILetterPreferencesRequest();
    }

    @Test
    public void testDefaultConstructor() {
        assertNull(uiLetterPreferencesRequest.getProviderId());
        assertNull(uiLetterPreferencesRequest.getProviderTIN());
    }

    @Test
    public void testParameterizedConstructor() {
        String providerId = "12345";
        String providerTIN = "67890";

        UILetterPreferencesRequest request = new UILetterPreferencesRequest(providerId, providerTIN);

        assertEquals(providerId, request.getProviderId());
        assertEquals(providerTIN, request.getProviderTIN());
    }

    @Test
    public void testGetAndSetProviderId() {
        String providerId = "12345";
        uiLetterPreferencesRequest.setProviderId(providerId);

        assertEquals(providerId, uiLetterPreferencesRequest.getProviderId());
    }

    @Test
    public void testGetAndSetProviderTIN() {
        String providerTIN = "67890";
        uiLetterPreferencesRequest.setProviderTIN(providerTIN);

        assertEquals(providerTIN, uiLetterPreferencesRequest.getProviderTIN());
    }
}