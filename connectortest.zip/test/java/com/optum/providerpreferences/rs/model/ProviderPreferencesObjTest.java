package com.optum.providerpreferences.rs.model;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class ProviderPreferencesObjTest {

    @Test
    public void testSettersAndGetters() {
        ProviderPreferencesObj obj = new ProviderPreferencesObj();

        obj.setCorporateTin("123456789");
        obj.setCorporateName("Corporate A");
        List<String> selectedProviders = Arrays.asList("Provider1", "Provider2");
        obj.setSelectedProviders(selectedProviders);
        List<PreferenceType> preferenceTypes = Arrays.asList(new PreferenceType(), new PreferenceType());
        obj.setPreferenceTypes(preferenceTypes);

        assertEquals("123456789", obj.getCorporateTin());
        assertEquals("Corporate A", obj.getCorporateName());
        assertEquals(selectedProviders, obj.getSelectedProviders());
        assertEquals(preferenceTypes, obj.getPreferenceTypes());
    }

    @Test
    public void testToString() {
        ProviderPreferencesObj obj = new ProviderPreferencesObj();
        obj.setCorporateTin("123456789");
        obj.setCorporateName("Corporate A");
        obj.setSelectedProviders(Arrays.asList("Provider1", "Provider2"));
        obj.setPreferenceTypes(null);

        String expected = "ProviderPreferencesObj [corporateTin=123456789, corporateName=Corporate A, selectedProviders=[Provider1, Provider2], preferenceTypes=null]";
        assertEquals(expected, obj.toString());
    }

    @Test
    public void testToStringMpins() {
        ProviderPreferencesObj obj = new ProviderPreferencesObj();
        obj.setSelectedProviders(Arrays.asList("Mpin1", "Mpin2", "Mpin3"));

        String expected = "Mpin1,Mpin2,Mpin3";
        assertEquals(expected, obj.toStringMpins());
    }
}