package com.optum.providerpreferences.rs.model.ndb.preferences;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class LetterTypeTest {

    private LetterType letterType;

    @Before
    public void setUp() {
        letterType = new LetterType();
    }

    @Test
    public void testDefaultConstructor() {
        assertNull(letterType.getLetterType());
    }

    @Test
    public void testParameterizedConstructor() {
        String letterTypeStr = "TestType";
        LetterType letterType = new LetterType(letterTypeStr);

        assertEquals(letterTypeStr, letterType.getLetterType());
    }

    @Test
    public void testGetAndSetLetterType() {
        String letterTypeStr = "SampleType";
        letterType.setLetterType(letterTypeStr);

        assertEquals(letterTypeStr, letterType.getLetterType());
    }

    @Test
    public void testToString() {
        String letterTypeStr = "ExampleType";
        letterType.setLetterType(letterTypeStr);

        String expected = "LetterType [letterTypeStr=" + letterTypeStr + "]";
        assertEquals(expected, letterType.toString());
    }
}