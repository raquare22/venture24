package com.optum.providerpreferences.rs.model.ndb.provider;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class CorpMpinRequestTest {

    private CorpMpinRequest corpMpinRequest;

    @Before
    public void setUp() {
        corpMpinRequest = new CorpMpinRequest();
    }

    @Test
    public void testGetAndSetRequestHeader() {
        RequestHeader requestHeader = new RequestHeader();
        corpMpinRequest.setRequestHeader(requestHeader);

        assertNotNull(corpMpinRequest.getRequestHeader());
        assertEquals(requestHeader, corpMpinRequest.getRequestHeader());
    }

    @Test
    public void testGetAndSetRequestData() {
        RequestData requestData = new RequestData();
        corpMpinRequest.setRequestData(requestData);

        assertNotNull(corpMpinRequest.getRequestData());
        assertEquals(requestData, corpMpinRequest.getRequestData());
    }

    @Test
    public void testToString() {
        RequestData requestData = new RequestData();
        corpMpinRequest.setRequestData(requestData);

        String expected = "CorpMpinRequest [requestData=" + requestData + "]";
        assertEquals(expected, corpMpinRequest.toString());
    }
}