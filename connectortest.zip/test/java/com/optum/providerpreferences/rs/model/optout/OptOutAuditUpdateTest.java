package com.optum.providerpreferences.rs.model.optout;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class OptOutAuditUpdateTest {

    private OptOutAuditUpdate optOutAuditUpdate;

    @Before
    public void setUp() {
        optOutAuditUpdate = new OptOutAuditUpdate();
    }

    @Test
    public void testSetAndGetDeliveryMethod() {
        String deliveryMethod = "Email";
        optOutAuditUpdate.setDeliveryMethod(deliveryMethod);
        assertEquals(deliveryMethod, optOutAuditUpdate.getDeliveryMethod());
    }

    @Test
    public void testSetAndGetOkToChangePDOInd() {
        String okToChangePDOInd = "Yes";
        optOutAuditUpdate.setOkToChangePDOInd(okToChangePDOInd);
        assertEquals(okToChangePDOInd, optOutAuditUpdate.getOkToChangePDOInd());
    }

    @Test
    public void testSetAndGetAutoEdelUpdateInd() {
        String autoEdelUpdateInd = "No";
        optOutAuditUpdate.setAutoEdelUpdateInd(autoEdelUpdateInd);
        assertEquals(autoEdelUpdateInd, optOutAuditUpdate.getAutoEdelUpdateInd());
    }

    @Test
    public void testSetAndGetLastUpdatedBy() {
        String lastUpdatedBy = "User123";
        optOutAuditUpdate.setLastUpdatedBy(lastUpdatedBy);
        assertEquals(lastUpdatedBy, optOutAuditUpdate.getLastUpdatedBy());
    }

    @Test
    public void testSetAndGetLastUpdatedById() {
        String lastUpdatedById = "12345";
        optOutAuditUpdate.setLastUpdatedById(lastUpdatedById);
        assertEquals(lastUpdatedById, optOutAuditUpdate.getLastUpdatedById());
    }

    @Test
    public void testSetAndGetAutoOptOutInd() {
        String autoOptOutInd = "Yes";
        optOutAuditUpdate.setAutoOptOutInd(autoOptOutInd);
        assertEquals(autoOptOutInd, optOutAuditUpdate.getAutoOptOutInd());
    }

    @Test
    public void testSetAndGetOptedOutDuration() {
        Integer optedOutDuration = 30;
        optOutAuditUpdate.setOptedOutDuration(optedOutDuration);
        assertEquals(optedOutDuration, optOutAuditUpdate.getOptedOutDuration());
    }

    @Test
    public void testSetAndGetOptedOutDateTime() {
        String optedOutDateTime = "2023-10-01T10:00:00";
        optOutAuditUpdate.setOptedOutDateTime(optedOutDateTime);
        assertEquals(optedOutDateTime, optOutAuditUpdate.getOptedOutDateTime());
    }

    @Test
    public void testSetAndGetExpiryDate() {
        String expiryDate = "2023-12-31";
        optOutAuditUpdate.setExpiryDate(expiryDate);
        assertEquals(expiryDate, optOutAuditUpdate.getExpiryDate());
    }

    @Test
    public void testSetAndGetExpiryDateEpoch() {
        Long expiryDateEpoch = 1704067200L;
        optOutAuditUpdate.setExpiryDateEpoch(expiryDateEpoch);
        assertEquals(expiryDateEpoch, optOutAuditUpdate.getExpiryDateEpoch());
    }

    @Test
    public void testSetAndGetSubscribeToEmail() {
        String subscribeToEmail = "true";
        optOutAuditUpdate.setSubscribeToEmail(subscribeToEmail);
        assertEquals(subscribeToEmail, optOutAuditUpdate.getSubscribeToEmail());
    }

    @Test
    public void testToString() {
        optOutAuditUpdate.setDeliveryMethod("Email");
        optOutAuditUpdate.setOkToChangePDOInd("Yes");
        String toStringResult = optOutAuditUpdate.toString();
        assertTrue(toStringResult.contains("Email"));
        assertTrue(toStringResult.contains("Yes"));
    }
}