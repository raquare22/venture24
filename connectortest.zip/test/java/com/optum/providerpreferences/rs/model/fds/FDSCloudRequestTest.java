package com.optum.providerpreferences.rs.model.fds;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class FDSCloudRequestTest {

    @Test
    public void testGettersAndSetters() {
        FDSCloudRequest request = new FDSCloudRequest();

        // Test setting and getting request
        Map<String, Object> requestData = new HashMap<>();
        requestData.put("key1", "value1");
        request.setRequest(requestData);
        assertNotNull(request.getRequest());
        assertEquals(requestData, request.getRequest());

        // Test setting and getting documentId
        String documentId = "doc-123";
        request.setDocumentId(documentId);
        assertEquals(documentId, request.getDocumentId());
    }

    @Test
    public void testToString() {
        FDSCloudRequest request = new FDSCloudRequest();

        Map<String, Object> requestData = new HashMap<>();
        requestData.put("key1", "value1");
        request.setRequest(requestData);

        String documentId = "doc-123";
        request.setDocumentId(documentId);

        String expected = "FDSCloudRequest [request=" + requestData + ", documentId=" + documentId + "]";
        assertEquals(expected, request.toString());
    }
}