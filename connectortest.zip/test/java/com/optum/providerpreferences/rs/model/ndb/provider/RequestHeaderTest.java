package com.optum.providerpreferences.rs.model.ndb.provider;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class RequestHeaderTest {

    private RequestHeader requestHeader;

    @Before
    public void setUp() {
        requestHeader = new RequestHeader();
    }

    @Test
    public void testGetAndSetApplicationId() {
        String applicationId = "App123";
        requestHeader.setApplicationId(applicationId);

        assertNotNull(requestHeader.getApplicationId());
        assertEquals(applicationId, requestHeader.getApplicationId());
    }

    @Test
    public void testGetAndSetClientId() {
        String clientId = "Client456";
        requestHeader.setClientId(clientId);

        assertNotNull(requestHeader.getClientId());
        assertEquals(clientId, requestHeader.getClientId());
    }

    @Test
    public void testGetAndSetSubscriber() {
        String subscriber = "Subscriber789";
        requestHeader.setSubscriber(subscriber);

        assertNotNull(requestHeader.getSubscriber());
        assertEquals(subscriber, requestHeader.getSubscriber());
    }

    @Test
    public void testGetAndSetCallingEntity() {
        String callingEntity = "Entity123";
        requestHeader.setCallingEntity(callingEntity);

        assertNotNull(requestHeader.getCallingEntity());
        assertEquals(callingEntity, requestHeader.getCallingEntity());
    }

    @Test
    public void testGetAndSetUserId() {
        String userId = "User456";
        requestHeader.setUserId(userId);

        assertNotNull(requestHeader.getUserId());
        assertEquals(userId, requestHeader.getUserId());
    }

    @Test
    public void testGetAndSetUserOfficeCode() {
        String userOfficeCode = "Office789";
        requestHeader.setUserOfficeCode(userOfficeCode);

        assertNotNull(requestHeader.getUserOfficeCode());
        assertEquals(userOfficeCode, requestHeader.getUserOfficeCode());
    }

    @Test
    public void testGetAndSetLastUpdateTypeCode() {
        String lastUpdateTypeCode = "Update123";
        requestHeader.setLastUpdateTypeCode(lastUpdateTypeCode);

        assertNotNull(requestHeader.getLastUpdateTypeCode());
        assertEquals(lastUpdateTypeCode, requestHeader.getLastUpdateTypeCode());
    }
}