package com.optum.providerpreferences.rs.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class OONRequestModelTest {

    @Test
    public void testDefaultValues() {
        OONRequestModel model = new OONRequestModel();
        assertNull(model.getCorpOwnerId());
        assertNull(model.getTaxIdNumber());
        assertNull(model.getProviderEmail());
        assertNull(model.getConvertToElectronic());
    }

    @Test
    public void testSettersAndGetters() {
        OONRequestModel model = new OONRequestModel();

        model.setCorpOwnerId("123456789");
        model.setTaxIdNumber("987654321");
        model.setProviderEmail("test@example.com");
        model.setConvertToElectronic(true);

        assertEquals("123456789", model.getCorpOwnerId());
        assertEquals("987654321", model.getTaxIdNumber());
        assertEquals("test@example.com", model.getProviderEmail());
        assertEquals(true, model.getConvertToElectronic());
    }

    @Test
    public void testToString() {
        OONRequestModel model = new OONRequestModel();
        model.setCorpOwnerId("123456789");
        model.setTaxIdNumber("987654321");
        model.setProviderEmail("test@example.com");
        model.setConvertToElectronic(true);

        String expected = "OONModel{corpMpin='123456789', tin='987654321', providerEmail='test@example.com', convertToElectronic=true}";
        assertEquals(expected, model.toString());
    }
}