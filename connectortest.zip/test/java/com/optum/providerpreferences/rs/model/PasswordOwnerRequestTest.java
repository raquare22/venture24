package com.optum.providerpreferences.rs.model;

import org.junit.Test;

import static org.junit.Assert.*;

public class PasswordOwnerRequestTest {

    @Test
    public void testDefaultConstructor() {
        PasswordOwnerRequest request = new PasswordOwnerRequest();
        assertNull(request.getOptumUUID());
    }

    @Test
    public void testSettersAndGetters() {
        PasswordOwnerRequest request = new PasswordOwnerRequest();
        request.setOptumUUID("UUID12345");

        assertEquals("UUID12345", request.getOptumUUID());
    }

    @Test
    public void testToString() {
        PasswordOwnerRequest request = new PasswordOwnerRequest();
        request.setOptumUUID("UUID12345");

        String expected = "PasswordOwnerRequest [optumUUID=UUID12345]";
        assertEquals(expected, request.toString());
    }
}