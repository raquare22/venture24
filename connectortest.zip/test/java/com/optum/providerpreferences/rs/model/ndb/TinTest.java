package com.optum.providerpreferences.rs.model.ndb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class TinTest {

    private Tin tin;

    @Before
    public void setUp() {
        tin = new Tin();
    }

    @Test
    public void testGetAndSetTin() {
        tin.setTin("123456789");
        assertEquals("123456789", tin.getTin());
    }

    @Test
    public void testGetAndSetTinType() {
        tin.setTinType("EIN");
        assertEquals("EIN", tin.getTinType());
    }

    @Test
    public void testGetAndSetProviderType() {
        tin.setProviderType("Individual");
        assertEquals("Individual", tin.getProviderType());
    }

    @Test
    public void testGetAndSetCorpTINFlag() {
        tin.setCorpTINFlag("Y");
        assertEquals("Y", tin.getCorpTINFlag());
    }

    @Test
    public void testTinInstantiation() {
        assertNotNull(tin);
    }
}