package com.optum.providerpreferences.rs.model;

import org.junit.Test;

import static org.junit.Assert.*;

public class PasswordOwnerInfoTest {

    @Test
    public void testDefaultConstructor() {
        PasswordOwnerInfo passwordOwnerInfo = new PasswordOwnerInfo();

        assertNull(passwordOwnerInfo.getTin());
        assertNull(passwordOwnerInfo.getUhcID());
        assertNull(passwordOwnerInfo.getMpin());
        assertNull(passwordOwnerInfo.getProviderName());
        assertNull(passwordOwnerInfo.getCorporateName());
        assertNull(passwordOwnerInfo.getOrganizationName());
    }

    @Test
    public void testSettersAndGetters() {
        PasswordOwnerInfo passwordOwnerInfo = new PasswordOwnerInfo();

        passwordOwnerInfo.setTin("123456789");
        passwordOwnerInfo.setUhcID("UHC123");
        passwordOwnerInfo.setMpin("MPIN123");
        passwordOwnerInfo.setProviderName("Provider A");
        passwordOwnerInfo.setCorporateName("Corporate A");
        passwordOwnerInfo.setOrganizationName("Organization A");

        assertEquals("123456789", passwordOwnerInfo.getTin());
        assertEquals("UHC123", passwordOwnerInfo.getUhcID());
        assertEquals("MPIN123", passwordOwnerInfo.getMpin());
        assertEquals("Provider A", passwordOwnerInfo.getProviderName());
        assertEquals("Corporate A", passwordOwnerInfo.getCorporateName());
        assertEquals("Organization A", passwordOwnerInfo.getOrganizationName());
    }
}