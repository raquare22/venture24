package com.optum.providerpreferences.rs.model.ndb.provider;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class CorpMpinResponseTest {

    private CorpMpinResponse corpMpinResponse;

    @Before
    public void setUp() {
        corpMpinResponse = new CorpMpinResponse();
    }

    @Test
    public void testGetAndSetRequestHeader() {
        RequestHeader requestHeader = new RequestHeader();
        corpMpinResponse.setRequestHeader(requestHeader);

        assertNotNull(corpMpinResponse.getRequestHeader());
        assertEquals(requestHeader, corpMpinResponse.getRequestHeader());
    }

    @Test
    public void testGetAndSetRequestData() {
        RequestData requestData = new RequestData();
        corpMpinResponse.setRequestData(requestData);

        assertNotNull(corpMpinResponse.getRequestData());
        assertEquals(requestData, corpMpinResponse.getRequestData());
    }

    @Test
    public void testGetAndSetResponseHeader() {
        ResponseHeader responseHeader = new ResponseHeader();
        corpMpinResponse.setResponseHeader(responseHeader);

        assertNotNull(corpMpinResponse.getResponseHeader());
        assertEquals(responseHeader, corpMpinResponse.getResponseHeader());
    }

    @Test
    public void testGetAndSetResponse() {
        ResponseData responseData = new ResponseData();
        corpMpinResponse.setResponse(responseData);

        assertNotNull(corpMpinResponse.getResponse());
        assertEquals(responseData, corpMpinResponse.getResponse());
    }
}