package com.optum.providerpreferences.rs.model.ndb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class NDBProvidersTest {

    private NDBProviders ndbProviders;

    @Before
    public void setUp() {
        ndbProviders = new NDBProviders();
    }

    @Test
    public void testGetAndSetProviderList() {
        List<NDBProvider> providerList = new ArrayList<>();
        NDBProvider provider1 = new NDBProvider();
        provider1.setName("Provider1");
        provider1.setMpin("12345");

        NDBProvider provider2 = new NDBProvider();
        provider2.setName("Provider2");
        provider2.setMpin("67890");

        providerList.add(provider1);
        providerList.add(provider2);

        ndbProviders.setProviderList(providerList);

        assertNotNull(ndbProviders.getProviderList());
        assertEquals(2, ndbProviders.getProviderList().size());
        assertEquals("Provider1", ndbProviders.getProviderList().get(0).getName());
        assertEquals("12345", ndbProviders.getProviderList().get(0).getMpin());
        assertEquals("Provider2", ndbProviders.getProviderList().get(1).getName());
        assertEquals("67890", ndbProviders.getProviderList().get(1).getMpin());
    }

    @Test
    public void testGetProviderListWhenNull() {
        assertNotNull(ndbProviders.getProviderList());
        assertTrue(ndbProviders.getProviderList().isEmpty());
    }

    @Test
    public void testGetAndSetStatusCode() {
        ndbProviders.setStatusCode("200");
        assertEquals("200", ndbProviders.getStatusCode());
    }

    @Test
    public void testGetAndSetStatusMessage() {
        ndbProviders.setStatusMessage("Success");
        assertEquals("Success", ndbProviders.getStatusMessage());
    }
}