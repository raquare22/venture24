package com.optum.providerpreferences.rs.model.ndb.preferences;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class RequestHeaderTest {

    private RequestHeader requestHeader;

    @Before
    public void setUp() {
        requestHeader = new RequestHeader();
    }

    @Test
    public void testGetAndSetCallingProgram() {
        String callingProgram = "Program123";
        requestHeader.setcallingprogram(callingProgram);

        assertNotNull(requestHeader.getcallingprogram());
        assertEquals(callingProgram, requestHeader.getcallingprogram());
    }

    @Test
    public void testGetAndSetUserId() {
        String userId = "User456";
        requestHeader.setUserid(userId);

        assertNotNull(requestHeader.getUserid());
        assertEquals(userId, requestHeader.getUserid());
    }

    @Test
    public void testGetAndSetUserOfCcd() {
        String userOfCcd = "Office789";
        requestHeader.setUserofccd(userOfCcd);

        assertNotNull(requestHeader.getUserofccd());
        assertEquals(userOfCcd, requestHeader.getUserofccd());
    }

    @Test
    public void testGetAndSetSqlCode() {
        String sqlCode = "SQL123";
        requestHeader.setSqlCode(sqlCode);

        assertNotNull(requestHeader.getSqlCode());
        assertEquals(sqlCode, requestHeader.getSqlCode());
    }

    @Test
    public void testToString() {
        requestHeader.setcallingprogram("Program123");
        requestHeader.setUserid("User456");
        requestHeader.setUserofccd("Office789");
        requestHeader.setSqlCode("SQL123");

        String expected = "RequestHeader [callingprogram=Program123, userid=User456, userofccd=Office789, sqlCode=SQL123]";
        assertEquals(expected, requestHeader.toString());
    }
}