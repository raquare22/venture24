package com.optum.providerpreferences.rs.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class OONProviderPopUpDateTest {

    @Test
    public void testDefaultConstructor() {
        OONProviderPopUpDate popUpDate = new OONProviderPopUpDate();
        assertEquals(false, popUpDate.isResponseFlag());
        assertEquals(null, popUpDate.getProviderEmailId());
    }

    @Test
    public void testParameterizedConstructor() {
        OONProviderPopUpDate popUpDate = new OONProviderPopUpDate(true, "test@example.com");
        assertEquals(true, popUpDate.isResponseFlag());
        assertEquals("test@example.com", popUpDate.getProviderEmailId());
    }

    @Test
    public void testSettersAndGetters() {
        OONProviderPopUpDate popUpDate = new OONProviderPopUpDate();
        popUpDate.setResponseFlag(true);
        popUpDate.setProviderEmailId("provider@example.com");

        assertEquals(true, popUpDate.isResponseFlag());
        assertEquals("provider@example.com", popUpDate.getProviderEmailId());
    }

    @Test
    public void testToString() {
        OONProviderPopUpDate popUpDate = new OONProviderPopUpDate(true, "test@example.com");
        String expected = "OONProviderPopUpDate [responseFlag=true, providerEmailId=test@example.com]";
        assertEquals(expected, popUpDate.toString());
    }
}