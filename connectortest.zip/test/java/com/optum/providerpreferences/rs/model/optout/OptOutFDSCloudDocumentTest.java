package com.optum.providerpreferences.rs.model.optout;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;

public class OptOutFDSCloudDocumentTest {

    private OptOutFDSCloudDocument optOutFDSCloudDocument;

    @Before
    public void setUp() {
        optOutFDSCloudDocument = new OptOutFDSCloudDocument();
    }

    @Test
    public void testSetAndGetDocumentId() {
        String documentId = "doc123";
        optOutFDSCloudDocument.setDocumentId(documentId);
        assertEquals(documentId, optOutFDSCloudDocument.getDocumentId());
    }

    @Test
    public void testSetAndGetSearchTerms() {
        Object searchTerms = Arrays.asList("term1", "term2");
        optOutFDSCloudDocument.setSearchTerms(searchTerms);
        assertEquals(searchTerms, optOutFDSCloudDocument.getSearchTerms());
    }

    @Test
    public void testSetAndGetSpaceId() {
        String spaceId = "space123";
        optOutFDSCloudDocument.setSpaceId(spaceId);
        assertEquals(spaceId, optOutFDSCloudDocument.getSpaceId());
    }

    @Test
    public void testSetAndGetModifiedOn() {
        Long modifiedOn = 1700000000L;
        optOutFDSCloudDocument.setModifiedOn(modifiedOn);
        assertEquals(modifiedOn, optOutFDSCloudDocument.getModifiedOn());
    }

    @Test
    public void testSetAndGetModifiedBy() {
        String modifiedBy = "user123";
        optOutFDSCloudDocument.setModifiedBy(modifiedBy);
        assertEquals(modifiedBy, optOutFDSCloudDocument.getModifiedBy());
    }

    @Test
    public void testSetAndGetCreatedBy() {
        String createdBy = "creator123";
        optOutFDSCloudDocument.setCreatedBy(createdBy);
        assertEquals(createdBy, optOutFDSCloudDocument.getCreatedBy());
    }

    @Test
    public void testSetAndGetCreatedOn() {
        Long createdOn = 1600000000L;
        optOutFDSCloudDocument.setCreatedOn(createdOn);
        assertEquals(createdOn, optOutFDSCloudDocument.getCreatedOn());
    }

    @Test
    public void testSetAndGetMetadata() {
        String metadata = "metadata123";
        optOutFDSCloudDocument.setMetadata(metadata);
        assertEquals(metadata, optOutFDSCloudDocument.getMetadata());
    }

    @Test
    public void testSetAndGetExpiryDate() {
        Long expiryDate = 1800000000L;
        optOutFDSCloudDocument.setExpiryDate(expiryDate);
        assertEquals(expiryDate, optOutFDSCloudDocument.getExpiryDate());
    }

    @Test
    public void testSetAndGetExternalId() {
        String externalId = "ext123";
        optOutFDSCloudDocument.setExternalId(externalId);
        assertEquals(externalId, optOutFDSCloudDocument.getExternalId());
    }

    @Test
    public void testSetAndGetAttachments() {
        Object attachment1 = "attachment1";
        Object attachment2 = "attachment2";
        optOutFDSCloudDocument.setAttachments(Arrays.asList(attachment1, attachment2));
        assertEquals(2, optOutFDSCloudDocument.getAttachments().size());
        assertTrue(optOutFDSCloudDocument.getAttachments().contains(attachment1));
        assertTrue(optOutFDSCloudDocument.getAttachments().contains(attachment2));
    }

    @Test
    public void testSetAndGetWorkflow() {
        String workflow = "workflow123";
        optOutFDSCloudDocument.setWorkflow(workflow);
        assertEquals(workflow, optOutFDSCloudDocument.getWorkflow());
    }

    @Test
    public void testSetAndGetAccessToken() {
        String accessToken = "token123";
        optOutFDSCloudDocument.setAccessToken(accessToken);
        assertEquals(accessToken, optOutFDSCloudDocument.getAccessToken());
    }

    @Test
    public void testSetAndGetStatus() {
        String status = "active";
        optOutFDSCloudDocument.setStatus(status);
        assertEquals(status, optOutFDSCloudDocument.getStatus());
    }

    @Test
    public void testSetAndGetTransactionId() {
        String transactionId = "txn123";
        optOutFDSCloudDocument.setTransactionId(transactionId);
        assertEquals(transactionId, optOutFDSCloudDocument.getTransactionId());
    }

    @Test
    public void testSetAndGetOnPremSpaceId() {
        String onPremSpaceId = "onPremSpace123";
        optOutFDSCloudDocument.setOnPremSpaceId(onPremSpaceId);
        assertEquals(onPremSpaceId, optOutFDSCloudDocument.getOnPremSpaceId());
    }

    @Test
    public void testSetAndGetOnPremRecordType() {
        String onPremRecordType = "recordType123";
        optOutFDSCloudDocument.setOnPremRecordType(onPremRecordType);
        assertEquals(onPremRecordType, optOutFDSCloudDocument.getOnPremRecordType());
    }

    @Test
    public void testToString() {
        optOutFDSCloudDocument.setDocumentId("doc123");
        optOutFDSCloudDocument.setSpaceId("space123");
        String toStringResult = optOutFDSCloudDocument.toString();
        assertTrue(toStringResult.contains("doc123"));
        assertTrue(toStringResult.contains("space123"));
    }
}