package com.optum.providerpreferences.rs.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TokenAbstTest {

    // Concrete subclass for testing
    private static class TokenAbstImpl extends TokenAbst {
    }

    @Test
    public void testAccessTokenGetterAndSetter() {
        TokenAbst token = new TokenAbstImpl();
        String testAccessToken = "testAccessToken";

        token.setAccessToken(testAccessToken);
        assertEquals(testAccessToken, token.getAccessToken());
    }
}