package com.optum.providerpreferences.rs.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ProviderEmailRequestTest {

    @Test
    public void testSettersAndGetters() {
        ProviderEmailRequest request = new ProviderEmailRequest();
        request.setCorpMpin("testMpin");

        assertEquals("testMpin", request.getCorpMpin());
    }

    @Test
    public void testToString() {
        ProviderEmailRequest request = new ProviderEmailRequest();
        request.setCorpMpin("testMpin");

        String expected = "ProviderEmailRequest [corpMpin=testMpin]";
        assertEquals(expected, request.toString());
    }
}