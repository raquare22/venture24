package com.optum.providerpreferences.rs.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class LogLevelObjTest {

    @Test
    public void testSettersAndGetters() {
        LogLevelObj logLevelObj = new LogLevelObj();

        logLevelObj.setLogLevel("INFO");
        logLevelObj.setPackageName("com.optum.providerpreferences");

        assertEquals("INFO", logLevelObj.getLogLevel());
        assertEquals("com.optum.providerpreferences", logLevelObj.getPackageName());
    }

    @Test
    public void testToString() {
        LogLevelObj logLevelObj = new LogLevelObj();
        logLevelObj.setLogLevel("DEBUG");
        logLevelObj.setPackageName("com.optum.providerpreferences.rs");

        String expected = "logLevel: DEBUG, packageName: com.optum.providerpreferences.rs";
        assertEquals(expected, logLevelObj.toString());
    }
}