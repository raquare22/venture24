package com.optum.providerpreferences.rs.model.fds;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class DocumentTest {

    @Test
    public void testGettersAndSetters() {
        Document document = new Document();

        // Test setting and getting dateCreated
        String dateCreated = "2023-10-01";
        document.setDateCreated(dateCreated);
        assertEquals(dateCreated, document.getDateCreated());

        // Test setting and getting dateModified
        String dateModified = "2023-10-02";
        document.setDateModified(dateModified);
        assertEquals(dateModified, document.getDateModified());

        // Test setting and getting id
        String id = "12345";
        document.setId(id);
        assertEquals(id, document.getId());

        // Test setting and getting spaceId
        String spaceId = "space-001";
        document.setSpaceId(spaceId);
        assertEquals(spaceId, document.getSpaceId());

        // Test setting and getting metadata
        Metadata metadata = new Metadata();
        document.setMetadata(metadata);
        assertNotNull(document.getMetadata());
        assertEquals(metadata, document.getMetadata());
    }

    @Test
    public void testToString() {
        Document document = new Document();

        document.setDateCreated("2023-10-01");
        document.setId("12345");
        document.setSpaceId("space-001");

        Metadata metadata = new Metadata();
        document.setMetadata(metadata);

        String expected = "Document [dateCreated=2023-10-01, id=12345, space_id=space-001, metadata=" + metadata.toString() + "]";
        assertEquals(expected, document.toString());
    }
}