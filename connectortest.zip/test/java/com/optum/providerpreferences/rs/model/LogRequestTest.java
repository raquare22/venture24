package com.optum.providerpreferences.rs.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class LogRequestTest {

    @Test
    public void testSettersAndGetters() {
        LogRequest logRequest = new LogRequest();

        logRequest.setLog("Test log message");
        logRequest.setTimestamp("2023-10-01T10:00:00Z");

        assertEquals("Test log message", logRequest.getLog());
        assertEquals("2023-10-01T10:00:00Z", logRequest.getTimestamp());
    }

    @Test
    public void testToString() {
        LogRequest logRequest = new LogRequest();
        logRequest.setLog("Another log message");
        logRequest.setTimestamp("2023-10-02T12:00:00Z");

        String expected = "LogRequest [log=Another log message, timestamp=2023-10-02T12:00:00Z]";
        assertEquals(expected, logRequest.toString());
    }
}