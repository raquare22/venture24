package com.optum.providerpreferences.rs.model.ndb.preferences;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class LetterPreferencesResponseTest {

    private LetterPreferencesResponse letterPreferencesResponse;

    @Before
    public void setUp() {
        letterPreferencesResponse = new LetterPreferencesResponse();
    }

    @Test
    public void testDefaultConstructor() {
        assertNull(letterPreferencesResponse.getResponseHeader());
        assertNull(letterPreferencesResponse.getRequestHeader());
        assertNull(letterPreferencesResponse.getRequest());
        assertNull(letterPreferencesResponse.getRequestResponse());
    }

    @Test
    public void testConstructorWithParameters() {
        ResponseHeader responseHeader = new ResponseHeader();
        RequestHeader requestHeader = new RequestHeader();
        RequestData requestData = new RequestData();
        ResponseData responseData = new ResponseData();

        LetterPreferencesResponse response = new LetterPreferencesResponse(responseHeader, requestHeader, requestData, responseData);

        assertEquals(responseHeader, response.getResponseHeader());
        assertEquals(requestHeader, response.getRequestHeader());
        assertEquals(requestData, response.getRequest());
        assertEquals(responseData, response.getRequestResponse());
    }

    @Test
    public void testGetAndSetResponseHeader() {
        ResponseHeader responseHeader = new ResponseHeader();
        letterPreferencesResponse.setResponseHeader(responseHeader);

        assertEquals(responseHeader, letterPreferencesResponse.getResponseHeader());
    }

    @Test
    public void testGetAndSetRequestHeader() {
        RequestHeader requestHeader = new RequestHeader();
        letterPreferencesResponse.setRequestHeader(requestHeader);

        assertEquals(requestHeader, letterPreferencesResponse.getRequestHeader());
    }

    @Test
    public void testGetAndSetRequest() {
        RequestData requestData = new RequestData();
        letterPreferencesResponse.setRequest(requestData);

        assertEquals(requestData, letterPreferencesResponse.getRequest());
    }

    @Test
    public void testGetAndSetRequestResponse() {
        ResponseData responseData = new ResponseData();
        letterPreferencesResponse.setRequestResponse(responseData);

        assertEquals(responseData, letterPreferencesResponse.getRequestResponse());
    }

//    @Test
//    public void testToString() {
//        ResponseHeader responseHeader = new ResponseHeader();
//        RequestHeader requestHeader = new RequestHeader();
//        RequestData requestData = new RequestData();
//        ResponseData responseData = new ResponseData();
//
//        letterPreferencesResponse.setResponseHeader(responseHeader);
//        letterPreferencesResponse.setRequestHeader(requestHeader);
//        letterPreferencesResponse.setRequest(requestData);
//        letterPreferencesResponse.setRequestResponse(responseData);
//
//        String expected = "{\"responseHeader\":null,\"requestHeader\":null,\"request\":null,\"requestResponse\":null}";
//        assertEquals(expected, letterPreferencesResponse.toString());
//    }
}