//package com.optum.providerpreferences.rs.model.ndb;
//
//import static org.junit.Assert.assertEquals;
//
//import java.lang.reflect.Field;
//
//import org.junit.Test;
//
//public class IndividualMPINResponseTest {
//
//    @Test
//    public void testConstructor() throws NoSuchFieldException, IllegalAccessException {
//        // Arrange
//        String expectedCode = "200";
//        String expectedMessage = "Success";
//
//        // Act
//        IndividualMPINResponse response = new IndividualMPINResponse(expectedCode, expectedMessage);
//
//        // Use reflection to access private fields from the superclass
//        Field codeField = GenericResponse.class.getDeclaredField("code");
//        Field messageField = GenericResponse.class.getDeclaredField("message");
//        codeField.setAccessible(true);
//        messageField.setAccessible(true);
//
//        String actualCode = (String) codeField.get(response);
//        String actualMessage = (String) messageField.get(response);
//
//        // Assert
//        assertEquals(expectedCode, actualCode);
//        assertEquals(expectedMessage, actualMessage);
//    }
//}