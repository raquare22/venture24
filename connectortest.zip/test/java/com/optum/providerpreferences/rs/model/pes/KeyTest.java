package com.optum.providerpreferences.rs.model.pes;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class KeyTest {

    @Test
    public void testGettersAndSetters() {
        Key key = new Key();

        // Test setting and getting taxIdNumber
        key.setTaxIdNumber("123456789");
        assertEquals("123456789", key.getTaxIdNumber());

        // Test setting and getting taxIdTypeCode
        key.setTaxIdTypeCode("TIN");
        assertEquals("TIN", key.getTaxIdTypeCode());
    }

    @Test
    public void testToString() {
        Key key = new Key();
        key.setTaxIdNumber("123456789");
        key.setTaxIdTypeCode("TIN");

        String expected = "taxIdNumber: 123456789, taxIdTypeCode: TIN";
        assertEquals(expected, key.toString());
    }
}
