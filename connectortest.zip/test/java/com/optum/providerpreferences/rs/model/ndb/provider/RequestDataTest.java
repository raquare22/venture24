package com.optum.providerpreferences.rs.model.ndb.provider;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class RequestDataTest {

    private RequestData requestData;

    @Before
    public void setUp() {
        requestData = new RequestData();
    }

    @Test
    public void testGetAndSetTaxIdNumber() {
        String taxIdNumber = "123456789";
        requestData.setTaxIdNumber(taxIdNumber);

        assertNotNull(requestData.getTaxIdNumber());
        assertEquals(taxIdNumber, requestData.getTaxIdNumber());
    }

    @Test
    public void testGetAndSetCorpOwnerId() {
        String corpOwnerId = "987654321";
        requestData.setCorpOwnerId(corpOwnerId);

        assertNotNull(requestData.getCorpOwnerId());
        assertEquals(corpOwnerId, requestData.getCorpOwnerId());
    }

    @Test
    public void testToString() {
        String taxIdNumber = "123456789";
        String corpOwnerId = "987654321";
        requestData.setTaxIdNumber(taxIdNumber);
        requestData.setCorpOwnerId(corpOwnerId);

        String expected = "RequestData [taxIdNumber=" + taxIdNumber + ", corpOwnerId=" + corpOwnerId + "]";
        assertEquals(expected, requestData.toString());
    }
}