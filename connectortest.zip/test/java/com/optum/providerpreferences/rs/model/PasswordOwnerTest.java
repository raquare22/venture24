package com.optum.providerpreferences.rs.model;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class PasswordOwnerTest {

    @Test
    public void testDefaultValues() {
        PasswordOwner passwordOwner = new PasswordOwner();

        assertNull(passwordOwner.getOptumUUID());
        assertNull(passwordOwner.getUhcID());
        assertNull(passwordOwner.getMpin());
        assertNull(passwordOwner.getTin());
        assertTrue(passwordOwner.getProviders().isEmpty());
        assertTrue(passwordOwner.getCorporates().isEmpty());
    }

    @Test
    public void testSettersAndGetters() {
        PasswordOwner passwordOwner = new PasswordOwner();

        passwordOwner.setOptumUUID("12345");
        passwordOwner.setUhcID("user123");
        passwordOwner.setMpin("mpin123");
        passwordOwner.setTin("tin123");

        List<PasswordOwnerInfo> providers = new ArrayList<>();
        PasswordOwnerInfo provider = new PasswordOwnerInfo();
        providers.add(provider);
        passwordOwner.setProviders(providers);

        List<PasswordOwnerInfo> corporates = new ArrayList<>();
        PasswordOwnerInfo corporate = new PasswordOwnerInfo();
        corporates.add(corporate);
        passwordOwner.setCorporates(corporates);

        assertEquals("12345", passwordOwner.getOptumUUID());
        assertEquals("user123", passwordOwner.getUhcID());
        assertEquals("mpin123", passwordOwner.getMpin());
        assertEquals("tin123", passwordOwner.getTin());
        assertEquals(1, passwordOwner.getProviders().size());
        assertEquals(provider, passwordOwner.getProviders().get(0));
        assertEquals(1, passwordOwner.getCorporates().size());
        assertEquals(corporate, passwordOwner.getCorporates().get(0));
    }

    @Test
    public void testGetProvidersReturnsCopy() {
        PasswordOwner passwordOwner = new PasswordOwner();
        List<PasswordOwnerInfo> providers = new ArrayList<>();
        PasswordOwnerInfo provider = new PasswordOwnerInfo();
        providers.add(provider);
        passwordOwner.setProviders(providers);

        List<PasswordOwnerInfo> retrievedProviders = passwordOwner.getProviders();
        retrievedProviders.add(new PasswordOwnerInfo()); // Modify the retrieved list

        assertEquals(1, passwordOwner.getProviders().size()); // Original list should remain unchanged
    }

    @Test
    public void testGetCorporatesReturnsCopy() {
        PasswordOwner passwordOwner = new PasswordOwner();
        List<PasswordOwnerInfo> corporates = new ArrayList<>();
        PasswordOwnerInfo corporate = new PasswordOwnerInfo();
        corporates.add(corporate);
        passwordOwner.setCorporates(corporates);

        List<PasswordOwnerInfo> retrievedCorporates = passwordOwner.getCorporates();
        retrievedCorporates.add(new PasswordOwnerInfo()); // Modify the retrieved list

        assertEquals(1, passwordOwner.getCorporates().size()); // Original list should remain unchanged
    }
}