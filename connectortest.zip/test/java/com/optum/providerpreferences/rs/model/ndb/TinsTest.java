package com.optum.providerpreferences.rs.model.ndb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class TinsTest {

    private Tins tins;

    @Before
    public void setUp() {
        tins = new Tins();
    }

    @Test
    public void testGetAndSetTinList() {
        List<Tin> tinList = new ArrayList<>();
        Tin tin = new Tin();
        tin.setTin("123456789");
        tinList.add(tin);

        tins.setTinList(tinList);

        assertNotNull(tins.getTinList());
        assertEquals(1, tins.getTinList().size());
        assertEquals("123456789", tins.getTinList().get(0).getTin());
    }

    @Test
    public void testGetAndSetStatusCode() {
        tins.setStatusCode("200");
        assertEquals("200", tins.getStatusCode());
    }

    @Test
    public void testGetAndSetStatusMessage() {
        tins.setStatusMessage("Success");
        assertEquals("Success", tins.getStatusMessage());
    }

    @Test
    public void testDefaultTinListInitialization() {
        assertNotNull(tins.getTinList());
        assertEquals(0, tins.getTinList().size());
    }
}