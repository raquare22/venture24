package com.optum.providerpreferences.rs.model.ndb.provider;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class MpinDataTest {

    private MpinData mpinData;

    @Before
    public void setUp() {
        mpinData = new MpinData();
    }

    @Test
    public void testGetAndSetTaxIdTypeCode() {
        String taxIdTypeCode = "TIN";
        mpinData.setTaxIdTypeCode(taxIdTypeCode);

        assertNotNull(mpinData.getTaxIdTypeCode());
        assertEquals(taxIdTypeCode, mpinData.getTaxIdTypeCode());
    }

    @Test
    public void testGetAndSetProviderId() {
        String providerId = "12345";
        mpinData.setProviderId(providerId);

        assertNotNull(mpinData.getProviderId());
        assertEquals(providerId, mpinData.getProviderId());
    }

    @Test
    public void testGetAndSetProvFstNm() {
        String provFstNm = "John";
        mpinData.setProvFstNm(provFstNm);

        assertNotNull(mpinData.getProvFstNm());
        assertEquals(provFstNm, mpinData.getProvFstNm());
    }

    @Test
    public void testGetAndSetProvLstNm() {
        String provLstNm = "Doe";
        mpinData.setProvLstNm(provLstNm);

        assertNotNull(mpinData.getProvLstNm());
        assertEquals(provLstNm, mpinData.getProvLstNm());
    }

    @Test
    public void testGetAndSetEpsCd() {
        String epsCd = "EPS123";
        mpinData.setEpsCd(epsCd);

        assertNotNull(mpinData.getEpsCd());
        assertEquals(epsCd, mpinData.getEpsCd());
    }
}