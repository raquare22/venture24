package com.optum.providerpreferences.rs.model.ndb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class CorporateEntitiesTest {

    private CorporateEntities corporateEntities;

    @Before
    public void setUp() {
        corporateEntities = new CorporateEntities();
    }

    @Test
    public void testGetAndSetPrivileges() {
        List<String> privileges = new ArrayList<>();
        privileges.add("READ");
        privileges.add("WRITE");

        corporateEntities.setPrivileges(privileges);

        assertNotNull(corporateEntities.getPrivileges());
        assertEquals(2, corporateEntities.getPrivileges().size());
        assertTrue(corporateEntities.getPrivileges().contains("READ"));
        assertTrue(corporateEntities.getPrivileges().contains("WRITE"));
    }

    @Test
    public void testGetPrivilegesWhenNull() {
        assertNotNull(corporateEntities.getPrivileges());
        assertTrue(corporateEntities.getPrivileges().isEmpty());
    }

    @Test
    public void testGetAndSetCorporates() {
        List<Corporate> corporates = new ArrayList<>();
        Corporate corporate1 = new Corporate();
        corporate1.setName("Corporate1");
        Corporate corporate2 = new Corporate();
        corporate2.setName("Corporate2");

        corporates.add(corporate1);
        corporates.add(corporate2);

        corporateEntities.setCorporates(corporates);

        assertNotNull(corporateEntities.getCorporates());
        assertEquals(2, corporateEntities.getCorporates().size());
        assertEquals("Corporate1", corporateEntities.getCorporates().get(0).getName());
        assertEquals("Corporate2", corporateEntities.getCorporates().get(1).getName());
    }

    @Test
    public void testGetCorporatesWhenNull() {
        assertNotNull(corporateEntities.getCorporates());
        assertTrue(corporateEntities.getCorporates().isEmpty());
    }

    @Test
    public void testGetAndSetStatusCode() {
        corporateEntities.setStatusCode("200");
        assertEquals("200", corporateEntities.getStatusCode());
    }

    @Test
    public void testGetAndSetStatusMessage() {
        corporateEntities.setStatusMessage("Success");
        assertEquals("Success", corporateEntities.getStatusMessage());
    }
}