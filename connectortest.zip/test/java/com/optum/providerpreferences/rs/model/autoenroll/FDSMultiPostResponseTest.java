package com.optum.providerpreferences.rs.model.autoenroll;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class FDSMultiPostResponseTest {

    @Test
    public void testGettersAndSetters() {
        FDSMultiPostResponse response = new FDSMultiPostResponse();

        // Test setting and getting inserted
        List<String> inserted = new ArrayList<>();
        inserted.add("Value1");
        inserted.add("Value2");

        response.setInserted(inserted);

        assertNotNull(response.getInserted());
        assertEquals(2, response.getInserted().size());
        assertEquals("Value1", response.getInserted().get(0));
        assertEquals("Value2", response.getInserted().get(1));
    }

    @Test
    public void testToString() {
        FDSMultiPostResponse response = new FDSMultiPostResponse();

        List<String> inserted = new ArrayList<>();
        inserted.add("Value1");
        response.setInserted(inserted);

        String expected = "inserted: [Value1]";
        assertEquals(expected, response.toString());
    }
}