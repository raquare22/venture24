package com.optum.providerpreferences.rs.model.logging;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.junit.Before;
import org.junit.Test;

public class LogMessageTest {

    private LogMessage logMessage;

    @Before
    public void setUp() {
        logMessage = new LogMessage();
    }

    @Test
    public void testGetLogType() {
        assertEquals("SECURITY_AUDIT", logMessage.getLogtype());
    }

    @Test
    public void testGetAndSetActorIp() {
        logMessage.setActorIp("192.168.1.1");
        assertEquals("192.168.1.1", logMessage.getActorIp());
    }

    @Test
    public void testGetAndSetActor() {
        logMessage.setActor("TestActor");
        assertEquals("TestActor", logMessage.getActor());
    }

    @Test
    public void testGetAndSetDetail() {
        logMessage.setDetail("TestDetail");
        assertEquals("TestDetail", logMessage.getDetail());
    }

    @Test
    public void testGetAndSetUsername() {
        logMessage.setUsername("TestUser");
        assertEquals("TestUser", logMessage.getUsername());
    }

    @Test
    public void testGetSrcIpWithValidHost() throws UnknownHostException {
        String expectedIp = InetAddress.getLocalHost().getHostAddress();
        assertEquals(expectedIp, logMessage.getSrcIp());
    }

    @Test
    public void testGetSrcIpWithUnknownHostException() {
        logMessage = new LogMessage() {
            @Override
            public String getSrcIp() {
                return "FallbackIP";
            }
        };
        assertEquals("FallbackIP", logMessage.getSrcIp());
    }
}