package com.optum.providerpreferences.rs.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PreferencesRequestTest {

    @Test
    public void testDefaultConstructor() {
        PreferencesRequest request = new PreferencesRequest();
        assertEquals(null, request.getTin());
        assertEquals(null, request.getMpin());
    }

    @Test
    public void testSettersAndGetters() {
        PreferencesRequest request = new PreferencesRequest();
        request.setTin("123456789");
        request.setMpin("987654321");

        assertEquals("123456789", request.getTin());
        assertEquals("987654321", request.getMpin());
    }

    @Test
    public void testToString() {
        PreferencesRequest request = new PreferencesRequest();
        request.setTin("123456789");
        request.setMpin("987654321");

        String expected = "PreferencesRequest [tin=123456789, mpin=987654321]";
        assertEquals(expected, request.toString());
    }
}