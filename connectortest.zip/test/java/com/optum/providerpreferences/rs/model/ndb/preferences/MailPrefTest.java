package com.optum.providerpreferences.rs.model.ndb.preferences;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class MailPrefTest {

    private MailPref mailPref;

    @Before
    public void setUp() {
        mailPref = new MailPref();
    }

    @Test
    public void testDefaultConstructor() {
        assertNull(mailPref.getLetterType());
        assertNull(mailPref.getMailingPref());
    }

    @Test
    public void testParameterizedConstructor() {
        String letterType = "TestLetterType";
        String mailingPref = "TestMailingPref";

        MailPref mailPref = new MailPref(letterType, mailingPref);

        assertEquals(letterType, mailPref.getLetterType());
        assertEquals(mailingPref, mailPref.getMailingPref());
    }

    @Test
    public void testGetAndSetLetterType() {
        String letterType = "SampleLetterType";
        mailPref.setLetterType(letterType);

        assertEquals(letterType, mailPref.getLetterType());
    }

    @Test
    public void testGetAndSetMailingPref() {
        String mailingPref = "SampleMailingPref";
        mailPref.setMailingPref(mailingPref);

        assertEquals(mailingPref, mailPref.getMailingPref());
    }

//    @Test
//    public void testToString() {
//        String letterType = "ExampleLetterType";
//        String mailingPref = "ExampleMailingPref";
//
//        mailPref.setLetterType(letterType);
//        mailPref.setMailingPref(mailingPref);
//
//        String expected = "MailPref [letterType=" + letterType + ", mailingPref=" + mailingPref + "]";
//        assertEquals(expected, mailPref.toString());
//    }
}