package com.optum.providerpreferences.rs.model.optout;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class OptOutFDSCloudPOSTResponseTest {

    private OptOutFDSCloudPOSTResponse response;

    @Before
    public void setUp() {
        response = new OptOutFDSCloudPOSTResponse();
    }

    @Test
    public void testSetAndGetDocumentId() {
        String documentId = "doc123";
        response.setDocumentId(documentId);
        assertEquals(documentId, response.getDocumentId());
    }

    @Test
    public void testSetAndGetSpaceId() {
        String spaceId = "space123";
        response.setSpaceId(spaceId);
        assertEquals(spaceId, response.getSpaceId());
    }

    @Test
    public void testSetAndGetMetadata() {
        String metadata = "metadata123";
        response.setMetadata(metadata);
        assertEquals(metadata, response.getMetadata());
    }

    @Test
    public void testSetAndGetSearchTerms() {
        List<String> searchTerms = Arrays.asList("term1", "term2");
        response.setSearchTerms(searchTerms);
        assertEquals(searchTerms, response.getSearchTerms());
    }

    @Test
    public void testSetAndGetCreatedOn() {
        Long createdOn = 123456789L;
        response.setCreatedOn(createdOn);
        assertEquals(createdOn, response.getCreatedOn());
    }

    @Test
    public void testSetAndGetModifiedOn() {
        Long modifiedOn = 987654321L;
        response.setModifiedOn(modifiedOn);
        assertEquals(modifiedOn, response.getModifiedOn());
    }

    @Test
    public void testSetAndGetCreatedBy() {
        String createdBy = "user123";
        response.setCreatedBy(createdBy);
        assertEquals(createdBy, response.getCreatedBy());
    }

    @Test
    public void testSetAndGetModifiedBy() {
        String modifiedBy = "user456";
        response.setModifiedBy(modifiedBy);
        assertEquals(modifiedBy, response.getModifiedBy());
    }

    @Test
    public void testSetAndGetAttachments() {
        Object attachment1 = "attachment1";
        Object attachment2 = "attachment2";
        List<Object> attachments = Arrays.asList(attachment1, attachment2);
        response.setAttachments(attachments);
        assertEquals(attachments, response.getAttachments());
    }

    @Test
    public void testToString() {
        response.setDocumentId("doc123");
        response.setSpaceId("space123");
        response.setMetadata("metadata123");
        response.setSearchTerms(Arrays.asList("term1", "term2"));
        response.setCreatedOn(123456789L);
        response.setModifiedOn(987654321L);
        response.setCreatedBy("user123");
        response.setModifiedBy("user456");
        response.setAttachments(Arrays.asList("attachment1", "attachment2"));

        String toStringResult = response.toString();
        assertTrue(toStringResult.contains("doc123"));
        assertTrue(toStringResult.contains("space123"));
        assertTrue(toStringResult.contains("metadata123"));
        assertTrue(toStringResult.contains("term1"));
        assertTrue(toStringResult.contains("term2"));
        assertTrue(toStringResult.contains("123456789"));
        assertTrue(toStringResult.contains("987654321"));
        assertTrue(toStringResult.contains("user123"));
        assertTrue(toStringResult.contains("user456"));
        assertTrue(toStringResult.contains("attachment1"));
        assertTrue(toStringResult.contains("attachment2"));
    }
}