package com.optum.providerpreferences.rs.model.ndb.preferences;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

public class LetterPreferencesRequestTest {

    private LetterPreferencesRequest letterPreferencesRequest;

    @Before
    public void setUp() {
        letterPreferencesRequest = new LetterPreferencesRequest();
    }

    @Test
    public void testGetAndSetRequestHeader() {
        RequestHeader requestHeader = new RequestHeader();
        letterPreferencesRequest.setRequestHeader(requestHeader);

        assertEquals(requestHeader, letterPreferencesRequest.getRequestHeader());
    }

    @Test
    public void testGetAndSetRequest() {
        RequestData requestData = new RequestData();
        letterPreferencesRequest.setRequest(requestData);

        assertEquals(requestData, letterPreferencesRequest.getRequest());
    }

    @Test
    public void testConstructorWithParameters() {
        RequestHeader requestHeader = new RequestHeader();
        RequestData requestData = new RequestData();

        LetterPreferencesRequest request = new LetterPreferencesRequest(requestHeader, requestData);

        assertEquals(requestHeader, request.getRequestHeader());
        assertEquals(requestData, request.getRequest());
    }

    @Test
    public void testDefaultConstructor() {
        LetterPreferencesRequest request = new LetterPreferencesRequest();

        assertNull(request.getRequestHeader());
        assertNull(request.getRequest());
    }

    @Test
    public void testToString() {
        RequestHeader requestHeader = new RequestHeader();
        RequestData requestData = new RequestData();

        letterPreferencesRequest.setRequestHeader(requestHeader);
        letterPreferencesRequest.setRequest(requestData);

        String expected = "LetterPreferencesRequest [requestHeader=" + requestHeader + ", request=" + requestData + "]";
        assertEquals(expected, letterPreferencesRequest.toString());
    }
}