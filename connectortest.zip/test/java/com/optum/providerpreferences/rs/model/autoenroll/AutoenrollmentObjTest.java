package com.optum.providerpreferences.rs.model.autoenroll;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class AutoenrollmentObjTest {

    @Test
    public void testGettersAndSetters() {
        AutoenrollmentObj obj = new AutoenrollmentObj();

        // Test setting and getting tin
        obj.setTin("123456789");
        assertEquals("123456789", obj.getTin());

        // Test setting and getting mpin
        obj.setMpin("987654321");
        assertEquals("987654321", obj.getMpin());

        // Test setting and getting fileName
        obj.setFileName("testFile.txt");
        assertEquals("testFile.txt", obj.getFileName());

        // Test setting and getting providerEmailId
        obj.setProviderEmailId("provider@example.com");
        assertEquals("provider@example.com", obj.getProviderEmailId());

        // Test setting and getting activeDate
        obj.setActiveDate("2023-10-01");
        assertEquals("2023-10-01", obj.getActiveDate());

        // Test setting and getting corpMpin
        obj.setCorpMpin("CORP123");
        assertEquals("CORP123", obj.getCorpMpin());
    }

    @Test
    public void testToString() {
        AutoenrollmentObj obj = new AutoenrollmentObj();
        obj.setTin("123456789");
        obj.setMpin("987654321");
        obj.setFileName("testFile.txt");
        obj.setProviderEmailId("provider@example.com");
        obj.setActiveDate("2023-10-01");
        obj.setCorpMpin("CORP123");

        String expected = "AutoenrollmentObj [tin=123456789, mpin=987654321, fileName=testFile.txt, providerEmailId=provider@example.com, activeDate=2023-10-01, corpMpin=CORP123]";
        assertEquals(expected, obj.toString());
    }
}