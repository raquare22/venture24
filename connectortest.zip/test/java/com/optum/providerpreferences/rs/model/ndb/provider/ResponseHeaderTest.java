package com.optum.providerpreferences.rs.model.ndb.provider;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class ResponseHeaderTest {

    private ResponseHeader responseHeader;

    @Before
    public void setUp() {
        responseHeader = new ResponseHeader();
    }

    @Test
    public void testGetAndSetReturnCode() {
        int returnCode = 200;
        responseHeader.setReturnCode(returnCode);

        assertEquals(returnCode, responseHeader.getReturnCode());
    }

    @Test
    public void testGetAndSetExplanationCode() {
        String[] explanationCode = {"CODE1", "CODE2"};
        responseHeader.setExplanationCode(explanationCode);

        assertArrayEquals(explanationCode, responseHeader.getExplanationCode());
    }
}