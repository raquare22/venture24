package com.optum.providerpreferences.rs.model.autoenroll;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class FDSMultiPutResponseTest {

    @Test
    public void testGettersAndSetters() {
        FDSMultiPutResponse response = new FDSMultiPutResponse();

        // Test setting and getting updated
        List<String> updated = new ArrayList<>();
        updated.add("UpdatedValue1");
        updated.add("UpdatedValue2");
        response.setUpdated(updated);

        assertNotNull(response.getUpdated());
        assertEquals(2, response.getUpdated().size());
        assertEquals("UpdatedValue1", response.getUpdated().get(0));
        assertEquals("UpdatedValue2", response.getUpdated().get(1));

        // Test setting and getting notfound
        List<String> notfound = new ArrayList<>();
        notfound.add("NotFoundValue1");
        response.setNotfound(notfound);

        assertNotNull(response.getNotfound());
        assertEquals(1, response.getNotfound().size());
        assertEquals("NotFoundValue1", response.getNotfound().get(0));
    }

    @Test
    public void testToString() {
        FDSMultiPutResponse response = new FDSMultiPutResponse();

        List<String> updated = new ArrayList<>();
        updated.add("UpdatedValue1");
        response.setUpdated(updated);

        List<String> notfound = new ArrayList<>();
        notfound.add("NotFoundValue1");
        response.setNotfound(notfound);

        String expected = "updated: [UpdatedValue1] ; notfound: [NotFoundValue1]";
        assertEquals(expected, response.toString());
    }
}