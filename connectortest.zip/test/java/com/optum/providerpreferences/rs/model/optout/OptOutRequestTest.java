package com.optum.providerpreferences.rs.model.optout;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class OptOutRequestTest {

    private OptOutRequest optOutRequest;

    @Before
    public void setUp() {
        optOutRequest = new OptOutRequest();
    }

    @Test
    public void testSetAndGetTin() {
        String tin = "123456789";
        optOutRequest.setTin(tin);
        assertEquals(tin, optOutRequest.getTin());
    }

    @Test
    public void testSetAndGetLastUpdatedBy() {
        String lastUpdatedBy = "user123";
        optOutRequest.setLastUpdatedBy(lastUpdatedBy);
        assertEquals(lastUpdatedBy, optOutRequest.getLastUpdatedBy());
    }

    @Test
    public void testSetAndGetLastUpdatedById() {
        String lastUpdatedById = "id123";
        optOutRequest.setLastUpdatedById(lastUpdatedById);
        assertEquals(lastUpdatedById, optOutRequest.getLastUpdatedById());
    }

    @Test
    public void testSetAndGetOptedOutDuration() {
        int duration = 30;
        optOutRequest.setOptedOutDuration(duration);
        assertEquals(duration, optOutRequest.getOptedOutDuration());
    }

    @Test
    public void testSetAndGetCorpMpin() {
        String corpMpin = "corp123";
        optOutRequest.setCorpMpin(corpMpin);
        assertEquals(corpMpin, optOutRequest.getCorpMpin());
    }

    @Test
    public void testSetAndGetProviderMpins() {
        List<String> providerMpins = Arrays.asList("mpin1", "mpin2");
        optOutRequest.setProviderMpins(providerMpins);
        assertEquals(providerMpins, optOutRequest.getProviderMpins());
    }

    @Test
    public void testSetAndGetCategories() {
        List<String> categories = Arrays.asList("category1", "category2");
        optOutRequest.setCategories(categories);
        assertEquals(categories, optOutRequest.getCategories());
    }

    @Test
    public void testToString() {
        optOutRequest.setTin("123456789");
        optOutRequest.setCorpMpin("corp123");
        optOutRequest.setProviderMpins(Arrays.asList("mpin1", "mpin2"));
        optOutRequest.setLastUpdatedBy("user123");
        optOutRequest.setLastUpdatedById("id123");
        optOutRequest.setOptedOutDuration(30);
        optOutRequest.setCategories(Arrays.asList("category1", "category2"));

        String toStringResult = optOutRequest.toString();
        assertTrue(toStringResult.contains("123456789"));
        assertTrue(toStringResult.contains("corp123"));
        assertTrue(toStringResult.contains("mpin1"));
        assertTrue(toStringResult.contains("mpin2"));
        assertTrue(toStringResult.contains("user123"));
        assertTrue(toStringResult.contains("id123"));
        assertTrue(toStringResult.contains("30"));
        assertTrue(toStringResult.contains("category1"));
        assertTrue(toStringResult.contains("category2"));
    }
}