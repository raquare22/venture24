package com.optum.providerpreferences.rs.model.pes;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class TinObjectTest {

    @Test
    public void testGettersAndSetters() {
        TinObject tinObject = new TinObject();
        Key key = new Key();
        key.setTaxIdNumber("123456789");
        key.setTaxIdTypeCode("TIN");

        tinObject.setKey(key);

        assertNotNull(tinObject.getKey());
        assertEquals("123456789", tinObject.getKey().getTaxIdNumber());
        assertEquals("TIN", tinObject.getKey().getTaxIdTypeCode());
    }

    @Test
    public void testToString() {
        TinObject tinObject = new TinObject();
        Key key = new Key();
        key.setTaxIdNumber("123456789");
        key.setTaxIdTypeCode("TIN");

        tinObject.setKey(key);

        String expected = "{ key: {taxIdNumber: 123456789, taxIdTypeCode: TIN} }";
        assertEquals(expected, tinObject.toString());
    }
}