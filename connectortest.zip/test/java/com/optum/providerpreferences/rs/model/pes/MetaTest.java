package com.optum.providerpreferences.rs.model.pes;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MetaTest {

    @Test
    public void testGettersAndSetters() {
        Meta meta = new Meta();

        // Test setting and getting transactionId
        meta.setTransactionId("12345");
        assertEquals("12345", meta.getTransactionId());

        // Test setting and getting pageOffset
        meta.setPageOffset("10");
        assertEquals("10", meta.getPageOffset());

        // Test setting and getting pageLimit
        meta.setPageLimit("50");
        assertEquals("50", meta.getPageLimit());

        // Test setting and getting totalRecordCount
        meta.setTotalRecordCount("100");
        assertEquals("100", meta.getTotalRecordCount());

        // Test setting and getting elapsedTimeMilliseconds
        meta.setElapsedTimeMilliseconds("200");
        assertEquals("200", meta.getElapsedTimeMilliseconds());

        // Test setting and getting supportContact
        meta.setSupportContact("support@example.com");
        assertEquals("support@example.com", meta.getSupportContact());
    }

    @Test
    public void testToString() {
        Meta meta = new Meta();
        meta.setTransactionId("12345");
        meta.setPageOffset("10");
        meta.setPageLimit("50");
        meta.setTotalRecordCount("100");
        meta.setElapsedTimeMilliseconds("200");
        meta.setSupportContact("support@example.com");

        String expected = "transactionId: 12345, pageOffset: 10, pageLimit: 50, totalRecordCount: 100, elapsedTimeMilliseconds: 200, supportContact: support@example.com";
        assertEquals(expected, meta.toString());
    }
}