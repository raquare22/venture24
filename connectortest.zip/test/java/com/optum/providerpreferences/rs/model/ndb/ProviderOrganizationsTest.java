package com.optum.providerpreferences.rs.model.ndb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class ProviderOrganizationsTest {

    private ProviderOrganizations providerOrganizations;

    @Before
    public void setUp() {
        providerOrganizations = new ProviderOrganizations();
    }

    @Test
    public void testGetAndSetRespOrgs() {
        List<ProviderOrganization> respOrgs = new ArrayList<>();
        ProviderOrganization org1 = new ProviderOrganization();
        org1.setUhcId("UHC123");
        org1.setRespOrgName("Org1");

        ProviderOrganization org2 = new ProviderOrganization();
        org2.setUhcId("UHC456");
        org2.setRespOrgName("Org2");

        respOrgs.add(org1);
        respOrgs.add(org2);

        providerOrganizations.setRespOrgs(respOrgs);

        assertNotNull(providerOrganizations.getRespOrgs());
        assertEquals(2, providerOrganizations.getRespOrgs().size());
        assertEquals("UHC123", providerOrganizations.getRespOrgs().get(0).getUhcId());
        assertEquals("Org1", providerOrganizations.getRespOrgs().get(0).getRespOrgName());
        assertEquals("UHC456", providerOrganizations.getRespOrgs().get(1).getUhcId());
        assertEquals("Org2", providerOrganizations.getRespOrgs().get(1).getRespOrgName());
    }

    @Test
    public void testGetRespOrgsWhenNull() {
        assertNotNull(providerOrganizations.getRespOrgs());
        assertTrue(providerOrganizations.getRespOrgs().isEmpty());
    }

    @Test
    public void testGetAndSetOptumUUId() {
        providerOrganizations.setOptumUUId("UUID123");
        assertEquals("UUID123", providerOrganizations.getOptumUUId());
    }

    @Test
    public void testGetAndSetStatusCode() {
        providerOrganizations.setStatusCode("200");
        assertEquals("200", providerOrganizations.getStatusCode());
    }

    @Test
    public void testGetAndSetStatusMessage() {
        providerOrganizations.setStatusMessage("Success");
        assertEquals("Success", providerOrganizations.getStatusMessage());
    }

    @Test
    public void testToString() {
        providerOrganizations.setOptumUUId("UUID123");
        providerOrganizations.setStatusCode("200");
        providerOrganizations.setStatusMessage("Success");

        List<ProviderOrganization> respOrgs = new ArrayList<>();
        ProviderOrganization org = new ProviderOrganization();
        org.setUhcId("UHC123");
        org.setRespOrgName("Org1");
        respOrgs.add(org);

        providerOrganizations.setRespOrgs(respOrgs);

        String expected = "ProviderOrganizations [respOrgs=" + respOrgs + ", optumUUId=UUID123, statusCode=200, statusMessage=Success]";
        assertEquals(expected, providerOrganizations.toString());
    }
}