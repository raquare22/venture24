package com.optum.providerpreferences.rs.model.ndb;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class ProviderOrganizationTest {

    private ProviderOrganization providerOrganization;

    @Before
    public void setUp() {
        providerOrganization = new ProviderOrganization();
    }

    @Test
    public void testGetAndSetUhcId() {
        providerOrganization.setUhcId("UHC123");
        assertEquals("UHC123", providerOrganization.getUhcId());
    }

    @Test
    public void testGetAndSetRespOrgName() {
        providerOrganization.setRespOrgName("Optum");
        assertEquals("Optum", providerOrganization.getRespOrgName());
    }

    @Test
    public void testToString() {
        providerOrganization.setUhcId("UHC123");
        providerOrganization.setRespOrgName("Optum");
        String expected = "ProviderOrganization [uhcId=UHC123, respOrgName=Optum]";
        assertEquals(expected, providerOrganization.toString());
    }
}