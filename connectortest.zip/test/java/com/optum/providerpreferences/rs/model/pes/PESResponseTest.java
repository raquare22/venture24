package com.optum.providerpreferences.rs.model.pes;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class PESResponseTest {

    @Test
    public void testGettersAndSetters() {
        PESResponse pesResponse = new PESResponse();

        // Test setting and getting Meta
        Meta meta = new Meta();
        meta.setTransactionId("12345");
        pesResponse.setMeta(meta);
        assertEquals(meta, pesResponse.getMeta());

        // Test setting and getting Data
        TinObject tinObject1 = new TinObject();
        TinObject tinObject2 = new TinObject();
        List<TinObject> data = Arrays.asList(tinObject1, tinObject2);
        pesResponse.setData(data);
        assertEquals(data, pesResponse.getData());
    }

//    @Test
//    public void testToString() {
//        PESResponse pesResponse = new PESResponse();
//
//        Meta meta = new Meta();
//        meta.setTransactionId("12345");
//        meta.setPageOffset("10");
//        meta.setPageLimit("50");
//        meta.setTotalRecordCount("100");
//        meta.setElapsedTimeMilliseconds("200");
//        meta.setSupportContact("support@example.com");
//        pesResponse.setMeta(meta);
//
//        TinObject tinObject1 = new TinObject();
//        TinObject tinObject2 = new TinObject();
//        List<TinObject> data = Arrays.asList(tinObject1, tinObject2);
//        pesResponse.setData(data);
//
//        String expected = "PESResponse: [ meta: { " + meta.toString() + " }, data: " + data.toString() + " ]";
//        assertEquals(expected, pesResponse.toString());
//    }

    @Test
    public void testConstructor() {
        PESResponse pesResponse = new PESResponse();
        assertNotNull(pesResponse);
    }
}