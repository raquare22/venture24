package com.optum.providerpreferences.rs.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TinRequestTest {

    @Test
    public void testSettersAndGetters() {
        TinRequest tinRequest = new TinRequest();

        tinRequest.setUhcID("UHC123");
        tinRequest.setMpin("MPIN456");
        tinRequest.setOptumUUID("UUID789");

        assertEquals("UHC123", tinRequest.getUhcID());
        assertEquals("MPIN456", tinRequest.getMpin());
        assertEquals("UUID789", tinRequest.getOptumUUID());
    }

    @Test
    public void testToString() {
        TinRequest tinRequest = new TinRequest();
        tinRequest.setUhcID("UHC123");
        tinRequest.setMpin("MPIN456");
        tinRequest.setOptumUUID("UUID789");

        String expected = "TinRequest [uhcID=UHC123, mpin=MPIN456, optumUUID=UUID789]";
        assertEquals(expected, tinRequest.toString());
    }
}