package com.optum.providerpreferences.rs.model.ndb.preferences;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.Collections;

import org.junit.Before;
import org.junit.Test;

public class RequestDataTest {

    private RequestData requestData;

    @Before
    public void setUp() {
        requestData = new RequestData();
    }

    @Test
    public void testDefaultConstructor() {
        assertNotNull(requestData);
        assertEquals("", requestData.getSubmitterIdNumber());
        assertEquals("", requestData.getFunctionCode());
        assertEquals("", requestData.getProviderId());
        assertEquals("", requestData.getProviderTIN());
        assertEquals("", requestData.getProviderTINType());
        assertEquals("", requestData.getTinPrefix());
        assertEquals("0", requestData.getTinSuffix());
        assertEquals("", requestData.getUhcid());
        assertEquals("", requestData.getDiv());
        assertTrue(requestData.getLetterTypeList().isEmpty());
    }

//    @Test
//    public void testParameterizedConstructor1() {
//        String providerId = "123";
//        String providerTIN = "456";
//        String functionCode = "FUNC";
//        String mailPref = "MAIL";
//        String classifier = "CLASS";
//
//        RequestData requestData = new RequestData(providerId, providerTIN, functionCode, mailPref, classifier);
//
//        assertEquals("PDO", requestData.getSubmitterIdNumber());
//        assertEquals(providerId, requestData.getProviderId());
//        assertEquals(providerTIN, requestData.getProviderTIN());
//        assertEquals(functionCode, requestData.getFunctionCode());
//        assertEquals(mailPref, requestData.getMailPref());
//        assertEquals("", requestData.getProviderTINType());
//        assertEquals("0", requestData.getUhcid());
//        assertEquals(1, requestData.getLetterTypeList().size());
//        assertEquals(classifier, requestData.getLetterTypeList().get(0).getClassifier());
//    }

    @Test
    public void testParameterizedConstructor2() {
        String providerId = "123";
        String providerTIN = "456";
        String functionCode = "FUNC";

        RequestData requestData = new RequestData(providerId, providerTIN, functionCode);

        assertEquals("PDO", requestData.getSubmitterIdNumber());
        assertEquals(providerId, requestData.getProviderId());
        assertEquals(providerTIN, requestData.getProviderTIN());
        assertEquals(functionCode, requestData.getFunctionCode());
    }

    @Test
    public void testGetAndSetFunctionCode() {
        String functionCode = "FUNC";
        requestData.setFunctionCode(functionCode);

        assertEquals(functionCode, requestData.getFunctionCode());
    }

    @Test
    public void testGetAndSetProviderId() {
        String providerId = "123";
        requestData.setProviderId(providerId);

        assertEquals(providerId, requestData.getProviderId());
    }

    @Test
    public void testGetAndSetProviderTIN() {
        String providerTIN = "456";
        requestData.setProviderTIN(providerTIN);

        assertEquals(providerTIN, requestData.getProviderTIN());
    }

//    @Test
//    public void testGetAndSetLetterTypeList() {
//        LetterType letterType1 = new LetterType("CLASS1");
//        LetterType letterType2 = new LetterType("CLASS2");
//        requestData.setLetterTypeList(Arrays.asList(letterType1, letterType2));
//
//        assertEquals(2, requestData.getLetterTypeList().size());
//        assertEquals("CLASS1", requestData.getLetterTypeList().get(0).getClassifier());
//        assertEquals("CLASS2", requestData.getLetterTypeList().get(1).getClassifier());
//    }

//    @Test
//    public void testToString() {
//        requestData.setSubmitterIdNumber("PDO");
//        requestData.setFunctionCode("FUNC");
//        requestData.setProviderId("123");
//        requestData.setProviderTIN("456");
//        requestData.setProviderTINType("TIN_TYPE");
//        requestData.setTinPrefix("PREFIX");
//        requestData.setTinSuffix("SUFFIX");
//        requestData.setUhcid("UHCID");
//        requestData.setDiv("DIV");
//        requestData.setLetterTypeList(Collections.singletonList(new LetterType("CLASS")));
//        requestData.setMailPref("MAIL");
//
//        String expected = "RequestData [submitterIdNumber=PDO, functionCode=FUNC, providerId=123, providerTIN=456, providerTINType=TIN_TYPE, tinPrefix=PREFIX, tinSuffix=SUFFIX, uhcid=UHCID, div=DIV, letterTypeList=[LetterType [classifier=CLASS]], mailPref=MAIL]";
//        assertEquals(expected, requestData.toString());
//    }
}