package com.optum.providerpreferences.rs.model.ndb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class NDBProviderTest {

    private NDBProvider ndbProvider;

    @Before
    public void setUp() {
        ndbProvider = new NDBProvider();
    }

    @Test
    public void testGetAndSetName() {
        String name = "Test Provider";
        ndbProvider.setName(name);

        assertNotNull(ndbProvider.getName());
        assertEquals(name, ndbProvider.getName());
    }

    @Test
    public void testGetAndSetMpin() {
        String mpin = "12345";
        ndbProvider.setMpin(mpin);

        assertNotNull(ndbProvider.getMpin());
        assertEquals(mpin, ndbProvider.getMpin());
    }
}