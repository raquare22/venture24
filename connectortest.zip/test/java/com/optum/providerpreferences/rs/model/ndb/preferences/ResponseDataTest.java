package com.optum.providerpreferences.rs.model.ndb.preferences;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class ResponseDataTest {

    private ResponseData responseData;

    @Before
    public void setUp() {
        responseData = new ResponseData();
    }

    @Test
    public void testGetAndSetProviderId() {
        String providerId = "12345";
        responseData.setProviderId(providerId);

        assertNotNull(responseData.getProviderId());
        assertEquals(providerId, responseData.getProviderId());
    }

    @Test
    public void testGetAndSetProviderTIN() {
        String providerTIN = "TIN123";
        responseData.setProviderTIN(providerTIN);

        assertNotNull(responseData.getProviderTIN());
        assertEquals(providerTIN, responseData.getProviderTIN());
    }

    @Test
    public void testGetAndSetProviderTINType() {
        String providerTINType = "TypeA";
        responseData.setProviderTINType(providerTINType);

        assertNotNull(responseData.getProviderTINType());
        assertEquals(providerTINType, responseData.getProviderTINType());
    }

    @Test
    public void testGetAndSetLtrTypMailPrfList() {
        List<MailPref> mailPrefList = new ArrayList<>();
        MailPref mailPref = new MailPref();
        mailPrefList.add(mailPref);

        responseData.setLtrTypMailPrfList(mailPrefList);

        assertNotNull(responseData.getLtrTypMailPrfList());
        assertEquals(mailPrefList, responseData.getLtrTypMailPrfList());
    }
}