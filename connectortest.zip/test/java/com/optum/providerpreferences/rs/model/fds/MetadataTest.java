package com.optum.providerpreferences.rs.model.fds;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class MetadataTest {

    @Test
    public void testGettersAndSetters() {
        Metadata metadata = new Metadata();

        // Test setting and getting tin
        String tin = "123456789";
        metadata.setTin(tin);
        assertEquals(tin, metadata.getTin());

        // Test setting and getting mpin
        String mpin = "987654321";
        metadata.setMpin(mpin);
        assertEquals(mpin, metadata.getMpin());

        // Test setting and getting providerName
        String providerName = "Provider Name";
        metadata.setProviderName(providerName);
        assertEquals(providerName, metadata.getProviderName());

        // Test setting and getting fileName
        String fileName = "file.txt";
        metadata.setFileName(fileName);
        assertEquals(fileName, metadata.getFileName());

        // Test setting and getting fileType
        String fileType = "text";
        metadata.setFileType(fileType);
        assertEquals(fileType, metadata.getFileType());

        // Test setting and getting providerEmailId
        String providerEmailId = "provider@example.com";
        metadata.setProviderEmailId(providerEmailId);
        assertEquals(providerEmailId, metadata.getProviderEmailId());

        // Test setting and getting frequency
        String frequency = "daily";
        metadata.setFrequency(frequency);
        assertEquals(frequency, metadata.getFrequency());

        // Test setting and getting deliveryMethod
        String deliveryMethod = "email";
        metadata.setDeliveryMethod(deliveryMethod);
        assertEquals(deliveryMethod, metadata.getDeliveryMethod());

        // Test setting and getting expiryDateEpoch
        Long expiryDateEpoch = 1696200000000L;
        metadata.setExpiryDateEpoch(expiryDateEpoch);
        assertEquals(expiryDateEpoch, metadata.getExpiryDateEpoch());
    }

    @Test
    public void testToString() {
        Metadata metadata = new Metadata();

        metadata.setTin("123456789");
        metadata.setMpin("987654321");
        metadata.setProviderName("Provider Name");
        metadata.setFileName("file.txt");
        metadata.setFileType("text");
        metadata.setProviderEmailId("provider@example.com");
        metadata.setFrequency("daily");
        metadata.setDeliveryMethod("email");

        String expected = "Metadata [tin=123456789, mpin=987654321, providerName=Provider Name, fileName=file.txt, fileType=text, providerEmailId=provider@example.com, frequency=daily, deliveryMethod=email, okToChangePDOInd=null, autoEdelUpdateInd=null, activeDate=null, lastUpdatedBy=null, lastUpdatedById=null, autoOptOutInd=null, optedOutDuration=null, optedOutDateTime=null, expiryDate=null, expiryDateEpoch=null, lastOONPopUpDate=null, subscribeToEmail=null]";
        assertEquals(expected, metadata.toString());
    }
}