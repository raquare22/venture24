package com.optum.providerpreferences.rs.model.optout;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class OptOutTinRequestTest {

    private OptOutTinRequest optOutTinRequest;

    @Before
    public void setUp() {
        optOutTinRequest = new OptOutTinRequest();
    }

    @Test
    public void testSetAndGetCorporateMpin() {
        String corporateMpin = "corp123";
        optOutTinRequest.setCorporateMpin(corporateMpin);
        assertEquals(corporateMpin, optOutTinRequest.getCorporateMpin());
    }

    @Test
    public void testToString() {
        String corporateMpin = "corp123";
        optOutTinRequest.setCorporateMpin(corporateMpin);
        String toStringResult = optOutTinRequest.toString();
        assertTrue(toStringResult.contains("corporateMpin=corp123"));
    }
}