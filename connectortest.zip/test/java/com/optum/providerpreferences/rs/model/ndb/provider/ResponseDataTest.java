package com.optum.providerpreferences.rs.model.ndb.provider;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class ResponseDataTest {

    private ResponseData responseData;

    @Before
    public void setUp() {
        responseData = new ResponseData();
    }

    @Test
    public void testGetAndSetMpinList() {
        List<MpinData> mpinList = new ArrayList<>();
        MpinData mpinData = new MpinData();
        mpinList.add(mpinData);

        responseData.setMpinList(mpinList);

        assertNotNull(responseData.getMpinList());
        assertEquals(mpinList, responseData.getMpinList());
    }
}