package com.optum.providerpreferences.rs.model.optout;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class OptOutTinResponseTest {

    private OptOutTinResponse optOutTinResponse;

    @Before
    public void setUp() {
        optOutTinResponse = new OptOutTinResponse(Arrays.asList("tin1", "tin2"));
    }

    @Test
    public void testConstructor() {
        List<String> tins = Arrays.asList("tin1", "tin2");
        OptOutTinResponse response = new OptOutTinResponse(tins);
        assertEquals(tins, response.getTins());
    }

    @Test
    public void testGetTins() {
        List<String> tins = optOutTinResponse.getTins();
        assertNotNull(tins);
        assertEquals(2, tins.size());
        assertTrue(tins.contains("tin1"));
        assertTrue(tins.contains("tin2"));
    }

    @Test
    public void testSetTins() {
        List<String> newTins = Arrays.asList("tin3", "tin4");
        optOutTinResponse.setTins(newTins);
        assertEquals(newTins, optOutTinResponse.getTins());
    }

    @Test
    public void testToString() {
        String toStringResult = optOutTinResponse.toString();
        assertTrue(toStringResult.contains("tin1"));
        assertTrue(toStringResult.contains("tin2"));
    }
}