package com.optum.providerpreferences.rs.model.linksecurity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class UserTest {

    private User user;

    @Before
    public void setUp() {
        user = new User();
    }

    @Test
    public void testGettersAndSetters() {
        // Set values
        user.setUserAcctSeqNbr("12345");
        user.setB2cUserId("b2c123");
        user.setAccessProfile("Admin");
        user.setStatusCode("Active");
        user.setStatusDesc("Active User");
        user.setAccountType("Premium");
        user.setAccountDesc("Premium Account");
        user.setDept("IT");
        user.setOrgType("Corporate");
        user.setTitle("Manager");
        user.setState("CA");
        user.setZipCode("90001");
        user.setRoleId("R123");
        user.setRoleDesc("Administrator");
        user.setRespOrgMpin("MPIN123");
        user.setHasAccessProfiles(true);

        // Verify values
        assertEquals("12345", user.getUserAcctSeqNbr());
        assertEquals("b2c123", user.getB2cUserId());
        assertEquals("Admin", user.getAccessProfile());
        assertEquals("Active", user.getStatusCode());
        assertEquals("Active User", user.getStatusDesc());
        assertEquals("Premium", user.getAccountType());
        assertEquals("Premium Account", user.getAccountDesc());
        assertEquals("IT", user.getDept());
        assertEquals("Corporate", user.getOrgType());
        assertEquals("Manager", user.getTitle());
        assertEquals("CA", user.getState());
        assertEquals("90001", user.getZipCode());
        assertEquals("R123", user.getRoleId());
        assertEquals("Administrator", user.getRoleDesc());
        assertEquals("MPIN123", user.getRespOrgMpin());
        assertTrue(user.isHasAccessProfiles());
    }

    @Test
    public void testSetHasAccessProfilesWithString() {
        // Test with "true"
        user.setHasAccessProfiles("true");
        assertTrue(user.isHasAccessProfiles());

        // Test with "false"
        user.setHasAccessProfiles("false");
        assertFalse(user.isHasAccessProfiles());

        // Test with invalid value
        user.setHasAccessProfiles("invalid");
        assertFalse(user.isHasAccessProfiles());
    }
}