package com.optum.providerpreferences.rs.model.fds;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;

public class FDSCloudGETResponseTest {

    @Test
    public void testGettersAndSetters() {
        FDSCloudGETResponse response = new FDSCloudGETResponse();

        // Test setting and getting total_records
        String totalRecords = "100";
        response.setTotal_records(totalRecords);
        assertEquals(totalRecords, response.getTotal_records());

        // Test setting and getting count
        String count = "10";
        response.setCount(count);
        assertEquals(count, response.getCount());

        // Test setting and getting start
        String start = "0";
        response.setStart(start);
        assertEquals(start, response.getStart());

        // Test setting and getting documents
        List<OptOutFDSCloudDocument> documents = new ArrayList<>();
        OptOutFDSCloudDocument document = new OptOutFDSCloudDocument();
        documents.add(document);
        response.setDocuments(documents);
        assertNotNull(response.getDocuments());
        assertEquals(documents, response.getDocuments());
    }

    @Test
    public void testToString() {
        FDSCloudGETResponse response = new FDSCloudGETResponse();

        response.setTotal_records("100");
        response.setCount("10");
        response.setStart("0");

        List<OptOutFDSCloudDocument> documents = new ArrayList<>();
        OptOutFDSCloudDocument document = new OptOutFDSCloudDocument();
        documents.add(document);
        response.setDocuments(documents);

        String expected = "FDSCloudGETResponse [totalRecords=100, count=10, documents=" + documents + "]";
        assertEquals(expected, response.toString());
    }
}