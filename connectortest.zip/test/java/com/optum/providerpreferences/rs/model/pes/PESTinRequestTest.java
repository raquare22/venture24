package com.optum.providerpreferences.rs.model.pes;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class PESTinRequestTest {

    @Test
    public void testConstructor() {
        String corpMpin = "12345";
        PESTinRequest request = new PESTinRequest(corpMpin);

        assertNotNull(request);
        assertEquals("fds.paperless.pdo", request.getApplicationName());
        assertEquals("0", request.getPageOffset());
        assertEquals("Active", request.getStatusCode());
        assertEquals(corpMpin, request.getCorporateOwnerProviderId());
    }

    @Test
    public void testGettersAndSetters() {
        PESTinRequest request = new PESTinRequest("12345");

        // Test setting and getting applicationName
        request.setApplicationName("newAppName");
        assertEquals("newAppName", request.getApplicationName());

        // Test setting and getting pageOffset
        request.setPageOffset("10");
        assertEquals("10", request.getPageOffset());

        // Test setting and getting statusCode
        request.setStatusCode("Inactive");
        assertEquals("Inactive", request.getStatusCode());

        // Test setting and getting corporateOwnerProviderId
        request.setCorporateOwnerProviderId("67890");
        assertEquals("67890", request.getCorporateOwnerProviderId());
    }

    @Test
    public void testToString() {
        PESTinRequest request = new PESTinRequest("12345");
        request.setApplicationName("newAppName");
        request.setPageOffset("10");
        request.setStatusCode("Inactive");

        String expected = "PESTinRequest = [ applicationName: newAppName, pageOffset: 10, statusCode: Inactive, corporateOwnerProviderId: 12345 ]";
        assertEquals(expected, request.toString());
    }
}