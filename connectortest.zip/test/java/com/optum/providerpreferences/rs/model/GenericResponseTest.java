package com.optum.providerpreferences.rs.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class GenericResponseTest {

    @Test
    public void testDefaultConstructor() {
        GenericResponse response = new GenericResponse();
        assertNull(response.getStatusCode());
        assertNull(response.getStatusMessage());
    }

    @Test
    public void testParameterizedConstructor() {
        GenericResponse response = new GenericResponse("200", "Success");
        assertEquals("200", response.getStatusCode());
        assertEquals("Success", response.getStatusMessage());
    }

    @Test
    public void testSettersAndGetters() {
        GenericResponse response = new GenericResponse();
        response.setStatusCode("404");
        response.setStatusMessage("Not Found");

        assertEquals("404", response.getStatusCode());
        assertEquals("Not Found", response.getStatusMessage());
    }
}
