package com.optum.providerpreferences.rs.model.autoenroll;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;

public class AutoenrollmentAuditLogTest {

    @Test
    public void testGettersAndSetters() {
        AutoenrollmentAuditLog auditLog = new AutoenrollmentAuditLog();

        // Test setting and getting recordType
        auditLog.setRecordType("TestRecordType");
        assertEquals("TestRecordType", auditLog.getRecordType());

        // Test setting and getting autoenrollDocuments
        List<Document> documents = new ArrayList<>();
        documents.add(new Document());
        auditLog.setAutoenrollDocuments(documents);
        assertNotNull(auditLog.getAutoenrollDocuments());
        assertEquals(1, auditLog.getAutoenrollDocuments().size());

        // Test setting and getting countToInsert
        auditLog.setCountToInsert(5L);
        assertEquals(5L, auditLog.getCountToInsert());

        // Test setting and getting inserted
        List<String> inserted = new ArrayList<>();
        inserted.add("InsertedValue");
        auditLog.setInserted(inserted);
        assertNotNull(auditLog.getInserted());
        assertEquals(1, auditLog.getInserted().size());
        assertEquals("InsertedValue", auditLog.getInserted().get(0));

        // Test setting and getting errors
        List<FDSCloudRequest> errors = new ArrayList<>();
        errors.add(new FDSCloudRequest());
        auditLog.setErrors(errors);
        assertNotNull(auditLog.getErrors());
        assertEquals(1, auditLog.getErrors().size());

        // Test setting and getting status
        auditLog.setStatus("Success");
        assertEquals("Success", auditLog.getStatus());
    }

    @Test
    public void testToString() {
        AutoenrollmentAuditLog auditLog = new AutoenrollmentAuditLog();
        auditLog.setRecordType("TestRecordType");
        auditLog.setCountToInsert(5L);
        auditLog.setStatus("Success");

        String expected = "AutoenrollmentAuditLog [recordType=TestRecordType, autoenrollDocuments=null, countToInsert=5, inserted=null, status=Success]";
        assertEquals(expected, auditLog.toString());
    }
}