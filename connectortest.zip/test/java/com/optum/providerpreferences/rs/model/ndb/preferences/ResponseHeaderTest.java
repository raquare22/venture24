package com.optum.providerpreferences.rs.model.ndb.preferences;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class ResponseHeaderTest {

    private ResponseHeader responseHeader;

    @Before
    public void setUp() {
        responseHeader = new ResponseHeader();
    }

    @Test
    public void testGetAndSetReturncode() {
        String returncode = "200";
        responseHeader.setReturncode(returncode);

        assertNotNull(responseHeader.getReturncode());
        assertEquals(returncode, responseHeader.getReturncode());
    }

    @Test
    public void testGetAndSetMessage() {
        String message = "Success";
        responseHeader.setMessage(message);

        assertNotNull(responseHeader.getMessage());
        assertEquals(message, responseHeader.getMessage());
    }

    @Test
    public void testConstructorWithParameters() {
        String returncode = "404";
        String message = "Not Found";

        ResponseHeader responseHeaderWithParams = new ResponseHeader(returncode, message);

        assertEquals(returncode, responseHeaderWithParams.getReturncode());
        assertEquals(message, responseHeaderWithParams.getMessage());
    }
}