package com.optum.providerpreferences.rs.model.ndb;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class CorporateTest {

    private Corporate corporate;

    @Before
    public void setUp() {
        corporate = new Corporate();
    }

    @Test
    public void testGettersAndSetters() {
        // Set values
        corporate.setName("Optum");
        corporate.setAllTins("TIN123");
        corporate.setMpin("MPIN456");

        // Verify values
        assertEquals("Optum", corporate.getName());
        assertEquals("TIN123", corporate.getAllTins());
        assertEquals("MPIN456", corporate.getMpin());
    }

    @Test
    public void testToString() {
        corporate.setName("Optum");
        corporate.setMpin("MPIN456");

        String expected = "Corporate [name=Optum, mpin=MPIN456]";
        assertEquals(expected, corporate.toString());
    }
}