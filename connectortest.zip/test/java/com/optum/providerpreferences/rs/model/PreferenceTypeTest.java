package com.optum.providerpreferences.rs.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class PreferenceTypeTest {

    @Test
    public void testDefaultConstructor() {
        PreferenceType preferenceType = new PreferenceType();

        assertNull(preferenceType.getClassifier());
        assertNull(preferenceType.getLob());
        assertNull(preferenceType.getProviderName());
        assertNull(preferenceType.getDescription());
        assertNull(preferenceType.getDocumentId());
        assertNull(preferenceType.getDeliveryMethod());
        assertNull(preferenceType.getProviderEmailId());
        assertNull(preferenceType.getFrequency());
        assertEquals("Y", preferenceType.getOkToChangePDOInd());
        assertNull(preferenceType.getAutoEdelUpdateInd());
        assertNull(preferenceType.getActiveDate());
        assertNull(preferenceType.getLastOONPopUpDate());
        assertNull(preferenceType.getLastUpdatedBy());
        assertNull(preferenceType.getLastUpdatedById());
        assertNull(preferenceType.getAutoOptOutInd());
        assertNull(preferenceType.getOptedOutDuration());
        assertNull(preferenceType.getOptedOutDateTime());
        assertNull(preferenceType.getExpiryDate());
        assertNull(preferenceType.getSubscribeToEmail());
        assertNull(preferenceType.getDateModified());
    }

    @Test
    public void testParameterizedConstructor() {
        PreferenceType preferenceType = new PreferenceType(
                "C1", "ProviderName", "Description", "Doc123", "Email",
                "provider@example.com", "Monthly", "N", "Y", "2023-01-01",
                "2023-02-01", "Admin", "123", "Y", 12, "2023-03-01",
                "2023-12-31", "Yes", "2023-04-01"
        );

        assertEquals("C1", preferenceType.getClassifier());
        assertEquals("ProviderName", preferenceType.getProviderName());
        assertEquals("Description", preferenceType.getDescription());
        assertEquals("Doc123", preferenceType.getDocumentId());
        assertEquals("Email", preferenceType.getDeliveryMethod());
        assertEquals("provider@example.com", preferenceType.getProviderEmailId());
        assertEquals("Monthly", preferenceType.getFrequency());
        assertEquals("N", preferenceType.getOkToChangePDOInd());
        assertEquals("Y", preferenceType.getAutoEdelUpdateInd());
        assertEquals("2023-01-01", preferenceType.getActiveDate());
        assertEquals("2023-02-01", preferenceType.getLastOONPopUpDate());
        assertEquals("Admin", preferenceType.getLastUpdatedBy());
        assertEquals("123", preferenceType.getLastUpdatedById());
        assertEquals("Y", preferenceType.getAutoOptOutInd());
        assertEquals(Integer.valueOf(12), preferenceType.getOptedOutDuration());
        assertEquals("2023-03-01", preferenceType.getOptedOutDateTime());
        assertEquals("2023-12-31", preferenceType.getExpiryDate());
        assertEquals("Yes", preferenceType.getSubscribeToEmail());
        assertEquals("2023-04-01", preferenceType.getDateModified());
    }

    @Test
    public void testSettersAndGetters() {
        PreferenceType preferenceType = new PreferenceType();

        preferenceType.setClassifier("C2");
        preferenceType.setProviderName("NewProvider");
        preferenceType.setDescription("NewDescription");
        preferenceType.setDocumentId("Doc456");
        preferenceType.setDeliveryMethod("Mail");
        preferenceType.setProviderEmailId("newprovider@example.com");
        preferenceType.setFrequency("Weekly");
        preferenceType.setOkToChangePDOInd("N");
        preferenceType.setAutoEdelUpdateInd("N");
        preferenceType.setActiveDate("2023-05-01");
        preferenceType.setLastOONPopUpDate("2023-06-01");
        preferenceType.setLastUpdatedBy("User");
        preferenceType.setLastUpdatedById("456");
        preferenceType.setAutoOptOutInd("N");
        preferenceType.setOptedOutDuration(6);
        preferenceType.setOptedOutDateTime("2023-07-01");
        preferenceType.setExpiryDate("2023-12-31");
        preferenceType.setSubscribeToEmail("No");
        preferenceType.setDateModified("2023-08-01");

        assertEquals("C2", preferenceType.getClassifier());
        assertEquals("NewProvider", preferenceType.getProviderName());
        assertEquals("NewDescription", preferenceType.getDescription());
        assertEquals("Doc456", preferenceType.getDocumentId());
        assertEquals("Mail", preferenceType.getDeliveryMethod());
        assertEquals("newprovider@example.com", preferenceType.getProviderEmailId());
        assertEquals("Weekly", preferenceType.getFrequency());
        assertEquals("N", preferenceType.getOkToChangePDOInd());
        assertEquals("N", preferenceType.getAutoEdelUpdateInd());
        assertEquals("2023-05-01", preferenceType.getActiveDate());
        assertEquals("2023-06-01", preferenceType.getLastOONPopUpDate());
        assertEquals("User", preferenceType.getLastUpdatedBy());
        assertEquals("456", preferenceType.getLastUpdatedById());
        assertEquals("N", preferenceType.getAutoOptOutInd());
        assertEquals(Integer.valueOf(6), preferenceType.getOptedOutDuration());
        assertEquals("2023-07-01", preferenceType.getOptedOutDateTime());
        assertEquals("2023-12-31", preferenceType.getExpiryDate());
        assertEquals("No", preferenceType.getSubscribeToEmail());
        assertEquals("2023-08-01", preferenceType.getDateModified());
    }

    @Test
    public void testToString() {
        PreferenceType preferenceType = new PreferenceType(
                "C1", "ProviderName", "Description", "Doc123", "Email",
                "provider@example.com", "Monthly", "N", "Y", "2023-01-01",
                "2023-02-01", "Admin", "123", "Y", 12, "2023-03-01",
                "2023-12-31", "Yes", "2023-04-01"
        );

        String expected = "PreferenceType [classifier=C1, lob=null, providerName=ProviderName, description=Description, documentId=Doc123, deliveryMethod=Email, providerEmailId=provider@example.com, frequency=Monthly, okToChangePDOInd=N, autoEdelUpdateInd=Y, activeDate=2023-01-01, lastOONPopUpDate=2023-02-01, lastUpdatedBy=Admin, autoOptOutInd=Y, optedOutDuration=12, optedOutDateTime=2023-03-01, expiryDate=2023-12-31, subscribeToEmail=Yes, dateModified=2023-04-01]";
        assertEquals(expected, preferenceType.toString());
    }
}