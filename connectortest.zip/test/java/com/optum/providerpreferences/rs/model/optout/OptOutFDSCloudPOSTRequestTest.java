package com.optum.providerpreferences.rs.model.optout;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class OptOutFDSCloudPOSTRequestTest {

    private OptOutFDSCloudPOSTRequest optOutFDSCloudPOSTRequest;

    @Before
    public void setUp() {
        optOutFDSCloudPOSTRequest = new OptOutFDSCloudPOSTRequest();
    }

    @Test
    public void testSetAndGetSpaceId() {
        String spaceId = "space123";
        optOutFDSCloudPOSTRequest.setSpace_id(spaceId);
        assertEquals(spaceId, optOutFDSCloudPOSTRequest.getSpace_id());
    }

    @Test
    public void testSetAndGetMetadata() {
        OptOutAuditMetadata metadata = new OptOutAuditMetadata();
        optOutFDSCloudPOSTRequest.setMetadata(metadata);
        assertEquals(metadata, optOutFDSCloudPOSTRequest.getMetadata());
    }
}