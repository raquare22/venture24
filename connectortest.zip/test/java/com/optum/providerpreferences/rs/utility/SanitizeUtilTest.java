package com.optum.providerpreferences.rs.utility;

import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.*;

public class SanitizeUtilTest {

    @Test
    public void testSanitizeString() {
        assertNull(SanitizeUtil.sanitizeString(null));
        assertEquals("{}", SanitizeUtil.sanitizeString("{}"));
        assertEquals("Sanitize Failure", SanitizeUtil.sanitizeString("{invalid json"));
    }

    @Test
    public void testSanitizeHttpRequestWithBody() {
        assertNull(SanitizeUtil.sanitizeHttpRequestWithBody(null));
    }

    @Test
    public void testSanitizeHttpEntityHeader() {
        HttpEntity<?> entity = new HttpEntity<>(new HttpHeaders());
        HttpEntity<?> sanitizedEntity = SanitizeUtil.sanitizeHttpEntityHeader(entity);
        assertNotNull(sanitizedEntity);
    }

    @Test
    public void testSanitizeHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        HttpHeaders sanitizedHeaders = SanitizeUtil.sanitizeHttpHeaders(headers);
        assertNotNull(sanitizedHeaders);
    }

//    @Test
//    public void testSanitizeHttpEntityHeaderRmAuth() {
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("Authorization", "Bearer token");
//        HttpEntity<?> entity = new HttpEntity<>(headers);
//        HttpEntity<?> sanitizedEntity = SanitizeUtil.sanitizeHttpEntityHeaderRmAuth(entity);
//        assertFalse(sanitizedEntity.getHeaders().containsKey("Authorization"));
//    }

    @Test
    public void testSanitizeResponseEntityBody() {
        ResponseEntity<String> response = ResponseEntity.ok("Test Body");
        assertEquals("Test Body", SanitizeUtil.sanitizeResponseEntityBody(response));
        assertNull(SanitizeUtil.sanitizeResponseEntityBody(null));
    }

    @Test
    public void testSanitizeStringContainsOnlyDigits() {
        assertEquals("12345", SanitizeUtil.sanitizeStringConatinsOnlyDigits("12345"));
        assertEquals("Sanitize failure not digits", SanitizeUtil.sanitizeStringConatinsOnlyDigits("123a45"));
    }

    @Test
    public void testSanitizeToString() {
        assertNull(SanitizeUtil.sanitizeToString(null));
        assertEquals("TestString", SanitizeUtil.sanitizeToString("TestString"));
    }

    @Test
    public void testSanitizeNumericString() {
        assertEquals("123456789", SanitizeUtil.sanitizeNumericString("123456789"));
        assertEquals("Sanitize failure", SanitizeUtil.sanitizeNumericString("12345"));
    }
}