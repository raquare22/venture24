package com.optum.providerpreferences.rs.utility;

import com.optum.providerpreferences.rs.model.logging.LogMessage;
import org.junit.Test;

import static org.junit.Assert.*;

public class MessageBuilderTest {

    @Test
    public void testBuild() {
        // Arrange
        MessageBuilder messageBuilder = new MessageBuilder();
        String actorIp = "192.168.1.1";
        String actor = "System";
        String username = "testUser";

        // Act
        LogMessage logMessage = messageBuilder.build(actorIp, actor, username);

        // Assert
        assertNotNull(logMessage);
        assertEquals(actorIp, logMessage.getActorIp());
        assertEquals(actor, logMessage.getActor());
        assertEquals(username, logMessage.getUsername());
    }
}