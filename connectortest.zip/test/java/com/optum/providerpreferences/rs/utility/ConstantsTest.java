package com.optum.providerpreferences.rs.utility;

import org.junit.Test;

import java.lang.reflect.Constructor;

import static org.junit.Assert.*;

public class ConstantsTest {

    @Test
    public void testConstantsValues() {
        assertEquals("update-prefs-amq", Constants.UPDATE_PREFS_QUEUE);
        assertEquals("tcp://" + System.getenv("QUEUE_HOST") + ":61616", Constants.QUEUE_BROKER_URL);
        assertEquals(System.getenv("QUEUE_PASSWORD"), Constants.PASSWORD);
        assertEquals("admin", Constants.USERNAME);
    }

    @Test
    public void testPrivateConstructor() {
        try {
            Constructor<Constants> constructor = Constants.class.getDeclaredConstructor();
            assertFalse("Constructor should be private", constructor.isAccessible());
            constructor.setAccessible(true);
            constructor.newInstance(); // Successfully invoke the private constructor
        } catch (ReflectiveOperationException e) {
            fail("Unexpected exception when invoking the private constructor: " + e.getMessage());
        }
    }
}