package com.optum.providerpreferences.rs.utility;

import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import org.junit.Test;

import java.text.ParseException;
import java.util.Date;

import static org.junit.Assert.*;

public class ConverterTest {

    @Test
    public void testConvertNullToString() {
        assertEquals("", Converter.convertNullToString(null));
        assertEquals("Test", Converter.convertNullToString(" Test "));
        assertEquals("", Converter.convertNullToString(""));
    }

    @Test
    public void testConvertStringToDate() {
        String validDate = "Mon January 01 12:00:00 UTC 2023";
        try {
            Date date = Converter.convertStringToDate(validDate);
            assertNotNull(date);
        } catch (ParseException e) {
            fail("ParseException should not have been thrown for a valid date");
        }

        String invalidDate = "Invalid Date String";
        try {
            Converter.convertStringToDate(invalidDate);
            fail("ParseException should have been thrown for an invalid date");
        } catch (ParseException e) {
            // Expected exception
        }
    }

    @Test
    public void testConvertPreferenceTypeToDoc() {
        PreferenceType preferenceType = new PreferenceType();
        preferenceType.setClassifier("C1");
        preferenceType.setFrequency("Monthly");
        preferenceType.setProviderEmailId("test@example.com");
        preferenceType.setDeliveryMethod("Email");
        preferenceType.setActiveDate("2023-01-01");

        String docId = "DOC123";
        String providerTin = "TIN123";
        String mpin = "MPIN123";
        String providerName = "Provider Name";

        Document document = Converter.convertPreferenceTypeToDoc(docId, preferenceType, providerTin, mpin, providerName);

        assertNotNull(document);
        assertEquals(docId, document.getId());
        assertEquals(System.getenv("SPACE_ID"), document.getSpaceId());

        Metadata metadata = document.getMetadata();
        assertNotNull(metadata);
        assertEquals(mpin, metadata.getMpin());
        assertEquals("C1", metadata.getFileName());
        assertEquals(ClassifierDescription.getClassifierDescription("C1"), metadata.getFileType());
        assertEquals("MONTHLY", metadata.getFrequency());
        assertEquals("test@example.com", metadata.getProviderEmailId());
        assertEquals(providerTin, metadata.getTin());
        assertEquals("PROVIDER NAME", metadata.getProviderName());
        assertEquals("EMAIL", metadata.getDeliveryMethod());
        assertEquals("2023-01-01", metadata.getActiveDate());
    }
}