package com.optum.providerpreferences.rs.utility;

import org.junit.Test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import static org.junit.Assert.*;

public class ApplicationUtilTest {

    @Test
    public void testIsNotNull() {
        assertTrue(ApplicationUtil.isNotNull(new Object()));
        assertFalse(ApplicationUtil.isNotNull(null));
    }

    @Test
    public void testGetServerDate() {
        String serverDate = ApplicationUtil.getServerDate();
        assertNotNull(serverDate);

        // Validate the format of the date
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        try {
            Date parsedDate = df.parse(serverDate);
            assertNotNull(parsedDate);
        } catch (Exception e) {
            fail("Date format is invalid: " + e.getMessage());
        }
    }

    @Test
    public void testRerSuccess() {
        ApplicationUtil util = new ApplicationUtil();
        String result = util.rerSuccess("Test message");
        assertEquals("Test message, RERstatus=SUCCESS", result);
    }

    @Test
    public void testRerFailure() {
        ApplicationUtil util = new ApplicationUtil();
        String result = util.rerFailure("Test message");
        assertEquals("Test message, RERstatus=FAILURE", result);
    }

    @Test
    public void testParseWithDefault() {
        assertEquals(123, ApplicationUtil.parseWithDefault("123", 0));
        assertEquals(0, ApplicationUtil.parseWithDefault("invalid", 0));
        assertEquals(10, ApplicationUtil.parseWithDefault(null, 10));
    }
}