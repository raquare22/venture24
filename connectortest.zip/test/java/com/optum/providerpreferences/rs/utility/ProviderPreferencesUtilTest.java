package com.optum.providerpreferences.rs.utility;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;

import org.junit.Test;

import java.io.IOException;
import java.text.ParseException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

public class ProviderPreferencesUtilTest {

    private ProviderPreferencesUtil util = new ProviderPreferencesUtil();

    @Test
    public void testCreateDocToSendCloud() throws ParseException {
        PreferenceType masterPref = new PreferenceType();
        masterPref.setDeliveryMethod("Email");
        masterPref.setClassifier("TestClassifier");
        masterPref.setFrequency("Monthly");
        masterPref.setProviderEmailId("test@example.com");
        masterPref.setProviderName("Test Provider");

        String mpin = "123456789";
        String tin = "987654321";
        String docId = "doc123";
        String activeDateStr = "2023-10-01T00:00:00.000Z";
        String subscribeToEmail = "Y";

        Map<String, Object> result = util.createDocToSendCloud(masterPref, mpin, tin, docId, activeDateStr, subscribeToEmail);

        assertNotNull(result);
        assertEquals("Email", result.get("deliveryMethod"));
        assertEquals("TestClassifier", result.get("fileName"));
        assertEquals("Monthly", result.get("frequency"));
        assertEquals("test@example.com", result.get("providerEmailId"));
        assertEquals("Test Provider", result.get("providerName"));
    }

    @Test
    public void testPadWithLeadingZeros() throws ApplicationException {
        assertEquals("000123456", util.padWithLeadingZeros("123456"));
        assertEquals("123456789", util.padWithLeadingZeros("123456789"));

        try {
            util.padWithLeadingZeros("1234567890");
            fail("Expected ApplicationException for MPIN longer than 9 digits");
        } catch (ApplicationException e) {
            assertEquals("MPIN longer than 9 digits", e.getMessage());
        }
    }

    @Test
    public void testCreateDocToSendWithClassifierCloud() throws ParseException {
        PreferenceType masterPref = new PreferenceType();
        masterPref.setDeliveryMethod("Mail");
        masterPref.setFrequency("Weekly");
        masterPref.setProviderEmailId("provider@example.com");
        masterPref.setProviderName("Provider Name");

        String mpin = "987654321";
        String tin = "123456789";
        String docId = "doc456";
        String activeDateStr = null;
        String subscribeToEmail = null;
        String classifier = "NewClassifier";

        Map<String, Object> result = util.createDocToSendWithClassifierCloud(masterPref, mpin, tin, docId, activeDateStr, subscribeToEmail, classifier);

        assertNotNull(result);
        assertEquals("Mail", result.get("deliveryMethod"));
        assertEquals("NewClassifier", result.get("fileName"));
        assertEquals("Weekly", result.get("frequency"));
        assertEquals("provider@example.com", result.get("providerEmailId"));
        assertEquals("Provider Name", result.get("providerName"));
    }
    @Test
    public void testPadWithLeadingZerosEmptyInput() {
        try {
            String result = util.padWithLeadingZeros("");
            assertEquals("000000000", result); // Assuming the method pads an empty string with zeros
        } catch (ApplicationException e) {
            fail("Did not expect an ApplicationException for empty MPIN");
        }
    }
    @Test
    public void testCreateDocToSendCloudWithNullActiveDate() throws ParseException {
        PreferenceType masterPref = new PreferenceType();
        masterPref.setDeliveryMethod("Email");
        masterPref.setClassifier("TestClassifier");
        masterPref.setFrequency("Monthly");
        masterPref.setProviderEmailId("test@example.com");
        masterPref.setProviderName("Test Provider");

        String mpin = "123456789";
        String tin = "987654321";
        String docId = "doc123";
        String activeDateStr = null; // Null active date
        String subscribeToEmail = "Y";

        Map<String, Object> result = util.createDocToSendCloud(masterPref, mpin, tin, docId, activeDateStr, subscribeToEmail);

        assertNotNull(result);
        assertEquals("Email", result.get("deliveryMethod"));
        assertEquals("TestClassifier", result.get("fileName"));
        assertEquals("Monthly", result.get("frequency"));
        assertEquals("test@example.com", result.get("providerEmailId"));
        assertEquals("Test Provider", result.get("providerName"));
        assertNull(result.get("activeDate")); // Assuming null activeDate is handled
    }
    
	@Test
	public void testCreateDocToSendCloud_ExpiryInfinite() throws Exception {

		PreferenceType pref = new PreferenceType();
		pref.setClassifier("C1");
		pref.setOptedOutDuration(-1);
		pref.setOptedOutDateTime("2023-01-01T00:00:00.000Z");

		Map<String, Object> result = util.createDocToSendCloud(pref, "1", "2", null, null, null);

		assertEquals("9999-12-31T23:59:59.000Z", result.get("expiryDate"));
	}

	@Test
	public void testCreateDocToSendCloud_ExpiryCalculated() throws Exception {

		PreferenceType pref = new PreferenceType();
		pref.setClassifier("C1");
		pref.setOptedOutDuration(5);
		pref.setOptedOutDateTime("2023-01-01T00:00:00.000Z");

		Map<String, Object> result = util.createDocToSendCloud(pref, "1", "2", null, null, null);

		assertNotNull(result.get("expiryDate"));
	}

	@Test
	public void testSubscribeToEmail_Default() throws Exception {

		PreferenceType pref = new PreferenceType();
		pref.setClassifier("C1");

		Map<String, Object> result = util.createDocToSendCloud(pref, "1", "2", null, null, null);

		assertEquals("Y", result.get("subscribeToEmail"));
	}

	@Test
	public void testFormatAndParseDate() throws Exception {

		Date now = new Date();

		String formatted = util.formatDate(now);
		Date parsed = util.parseDateString(formatted);

		assertNotNull(parsed);
	}

	@Test
	public void testDetermineDocumentIndex_Active() {

		List<Document> list = new ArrayList<>();
		Document doc = new Document();

		Metadata m = new Metadata();
		m.setActiveDate("2020-01-01T00:00:00.000+00:00"); // past

		doc.setMetadata(m);
		list.add(doc);

		ProviderPreferencesUtil.AutoEnrollment result = util.determineDocumentIndex(list, 1, 0, OffsetDateTime.now());

		assertTrue(result.isValidAutoEnrollment());
	}

	@Test
	public void testDetermineDocumentIndex_NoActiveDate() {

		List<Document> list = new ArrayList<>();
		Document doc = new Document();

		doc.setMetadata(new Metadata()); // no activeDate

		list.add(doc);

		ProviderPreferencesUtil.AutoEnrollment result = util.determineDocumentIndex(list, 1, 0, OffsetDateTime.now());

		assertFalse(result.isAutoEnrollment());
	}

	@Test
	public void testDetermineDocumentIndexCloud_ExpiryValid() throws Exception {

		OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();

		Metadata m = new Metadata();
		m.setExpiryDateEpoch(System.currentTimeMillis() + 10000);

		ObjectMapper mapper = new ObjectMapper();
		doc.setMetadata(mapper.writeValueAsString(m));

		List<OptOutFDSCloudDocument> list = List.of(doc);

		ProviderPreferencesUtil.AutoEnrollment result = util.determineDocumentIndexCloud(list, 1, 0,
				OffsetDateTime.now(), "cid");

		assertTrue(result.isValidAutoEnrollment());
	}

	@Test
	public void testDetermineMulti() {

		ProviderPreferencesUtil.AutoEnrollment a = new ProviderPreferencesUtil.AutoEnrollment(true, 0);

		ProviderPreferencesUtil.AutoEnrollment b = new ProviderPreferencesUtil.AutoEnrollment(false, -1);

		assertEquals(0, util.determineMulti(a, b));
	}

	@Test
	public void testDetermineDocumentIndex_FutureDate() {

		List<Document> list = new ArrayList<>();
		Document doc = new Document();

		Metadata m = new Metadata();
		m.setActiveDate("2999-01-01T00:00:00.000+00:00"); // future

		doc.setMetadata(m);
		list.add(doc);

		ProviderPreferencesUtil.AutoEnrollment result = util.determineDocumentIndex(list, 1, 0, OffsetDateTime.now());

		assertFalse(result.isValidAutoEnrollment());
	}

	@Test
	public void testDetermineDocumentIndex_ParseError() {

		List<Document> list = new ArrayList<>();
		Document doc = new Document();

		Metadata m = new Metadata();
		m.setActiveDate("INVALID_DATE");

		doc.setMetadata(m);
		list.add(doc);

		ProviderPreferencesUtil.AutoEnrollment result = util.determineDocumentIndex(list, 1, 0, OffsetDateTime.now());

		assertEquals(-1, result.index);
	}

	@Test(expected = IOException.class)
	public void testDetermineDocumentIndexCloud_ParseFail() throws Exception {

		OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
		doc.setMetadata("INVALID_JSON"); // ❌

		List<OptOutFDSCloudDocument> list = List.of(doc);

		util.determineDocumentIndexCloud(list, 1, 0, OffsetDateTime.now(), "cid");
	}

	@Test
	public void testDetermineDocumentIndexCloud_NoActiveDate() throws Exception {

		Metadata m = new Metadata();
		// no activeDate set

		ObjectMapper mapper = new ObjectMapper();
		OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
		doc.setMetadata(mapper.writeValueAsString(m));

		List<OptOutFDSCloudDocument> list = List.of(doc);

		ProviderPreferencesUtil.AutoEnrollment result = util.determineDocumentIndexCloud(list, 1, 0,
				OffsetDateTime.now(), "cid");

		assertFalse(result.isAutoEnrollment());
	}

	@Test
	public void testDetermineDocumentIndexCloud_FutureDate() throws Exception {

		Metadata m = new Metadata();
		m.setActiveDate("2999-01-01T00:00:00.000+00:00");

		ObjectMapper mapper = new ObjectMapper();
		OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
		doc.setMetadata(mapper.writeValueAsString(m));

		List<OptOutFDSCloudDocument> list = List.of(doc);

		ProviderPreferencesUtil.AutoEnrollment result = util.determineDocumentIndexCloud(list, 1, 0,
				OffsetDateTime.now(), "cid");

		assertFalse(result.isValidAutoEnrollment());
	}

	@Test
	public void testDetermineMulti_AllBranches() {

		ProviderPreferencesUtil.AutoEnrollment a = new ProviderPreferencesUtil.AutoEnrollment(true, 0);

		ProviderPreferencesUtil.AutoEnrollment b = new ProviderPreferencesUtil.AutoEnrollment(true, 1);

		assertEquals(0, util.determineMulti(a, b));

		ProviderPreferencesUtil.AutoEnrollment c = new ProviderPreferencesUtil.AutoEnrollment(false, -1);

		assertEquals(0, util.determineMulti(c, c)); // both false
		assertEquals(1, util.determineMulti(c, a));
	}

	@Test
	public void testSubscribeOverride() throws Exception {

		PreferenceType pref = new PreferenceType();
		pref.setClassifier("C1");
		pref.setSubscribeToEmail("N");

		Map<String, Object> result = util.createDocToSendCloud(pref, "1", "2", null, null, "Y");

		assertEquals("N", result.get("subscribeToEmail"));
	}
	
	@Test
	public void testDetermineMulti_ReturnMinusOne() {

		ProviderPreferencesUtil.AutoEnrollment a = new ProviderPreferencesUtil.AutoEnrollment(true, -1);

		ProviderPreferencesUtil.AutoEnrollment b = new ProviderPreferencesUtil.AutoEnrollment(true, -1);

		int result = util.determineMulti(a, b);

		assertEquals(-1, result);
	}
}
