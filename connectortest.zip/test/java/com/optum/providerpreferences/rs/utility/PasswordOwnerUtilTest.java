package com.optum.providerpreferences.rs.utility;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.PasswordOwnerInfo;
import com.optum.providerpreferences.rs.model.linksecurity.User;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class PasswordOwnerUtilTest {

//    @Test
//    public void testCompilePasswordOwnerInfo_Success() throws ApplicationException {
//        // Arrange
//        PasswordOwnerUtil passwordOwnerUtil = new PasswordOwnerUtil();
//        String optumUUID = "12345";
//        String sessionId = "session123";
//
//        List<PasswordOwnerInfo> passwordOwnerInfoList = new ArrayList<>();
//        PasswordOwnerInfo passwordOwnerInfo = new PasswordOwnerInfo();
//        passwordOwnerInfo.setUhcID("user123"); // Ensure this matches the User's userAcctSeqNbr
//        passwordOwnerInfo.setMpin("mpin123"); // Ensure this matches the User's respOrgMpin
//        passwordOwnerInfoList.add(passwordOwnerInfo);
//
//        List<User> userList = new ArrayList<>();
//        User user = new User();
//        user.setUserAcctSeqNbr("user123"); // Matches PasswordOwnerInfo's uhcID
//        user.setRespOrgMpin("mpin123");   // Matches PasswordOwnerInfo's mpin
//        userList.add(user);
//
//        // Act
//        PasswordOwner passwordOwner = passwordOwnerUtil.compilePasswordOwnerInfo(optumUUID, passwordOwnerInfoList, userList, sessionId);
//
//        // Assert
//        assertNotNull(passwordOwner);
//        assertEquals(optumUUID, passwordOwner.getOptumUUID());
//        assertEquals(1, passwordOwner.getCorporates().size());
//        assertEquals(passwordOwnerInfo, passwordOwner.getCorporates().get(0));
//    }

    @Test(expected = ApplicationException.class)
    public void testCompilePasswordOwnerInfo_NoCorporates() throws ApplicationException {
        // Arrange
        PasswordOwnerUtil passwordOwnerUtil = new PasswordOwnerUtil();
        String optumUUID = "12345";
        String sessionId = "session123";

        List<PasswordOwnerInfo> passwordOwnerInfoList = new ArrayList<>();
        PasswordOwnerInfo passwordOwnerInfo = new PasswordOwnerInfo();
        passwordOwnerInfo.setUhcID("user123");
        passwordOwnerInfo.setMpin("mpin123");
        passwordOwnerInfoList.add(passwordOwnerInfo);

        List<User> userList = new ArrayList<>();
        User user = new User();
        user.setUserAcctSeqNbr("user456"); // Mismatched user ID
        user.setRespOrgMpin("mpin456");   // Mismatched MPIN
        userList.add(user);

        // Act
        passwordOwnerUtil.compilePasswordOwnerInfo(optumUUID, passwordOwnerInfoList, userList, sessionId);

        // Assert: Exception is expected
    }
}