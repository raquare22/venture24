package com.optum.providerpreferences.rs.handler;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.ServiceBase;
import com.optum.providerpreferences.rs.model.Token;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.*;
import org.springframework.web.client.*;

import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

public class ServiceBaseTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private ServiceBase serviceBase;

    private HttpEntity<String> mockRequestEntity;
    private ResponseEntity<String> mockResponseEntitySuccess;
    private ResponseEntity<String> mockResponseEntityFailure;

    @Before
    public void setUp() throws NoSuchFieldException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        Field numRetriesField = ServiceBase.class.getDeclaredField("numRetries");
        numRetriesField.setAccessible(true);
        numRetriesField.set(serviceBase, 2);

        mockRequestEntity = new HttpEntity<>("mock-body", headers);
        mockResponseEntitySuccess = new ResponseEntity<>("mock-response-success", HttpStatus.OK);
        mockResponseEntityFailure = new ResponseEntity<>("mock-response", HttpStatus.BAD_REQUEST);
    }

    @Test
    public void testSendRequest_Success() throws Exception {
        String uri = "http://mock-url";
        String cid = "mock-cid";
        when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), eq(mockRequestEntity), eq(String.class)))
                .thenReturn(mockResponseEntitySuccess).thenReturn(mockResponseEntityFailure);

        serviceBase.numRetries = 2;
        ResponseEntity<?> response = serviceBase.sendRequest(uri, mockRequestEntity, String.class, HttpMethod.POST, cid);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }


    @Test
    public void testSendRequest_RetryAndFail() throws Exception {
        String uri = "http://mock-url";
        String cid = "mock-cid";

        when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), eq(mockRequestEntity), eq(String.class)))
                .thenReturn(mockResponseEntityFailure).thenReturn(mockResponseEntityFailure).thenReturn(mockResponseEntitySuccess);

        ResponseEntity<?> r = serviceBase.sendRequest(uri, mockRequestEntity, String.class, HttpMethod.POST, cid);
        assertEquals(HttpStatus.OK, r.getStatusCode());
    }


    @Test
    public void testSendDigiSecRequest_Success() {
        String uri = "http://mock-url";
        String cid = "mock-cid";
        when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), eq(mockRequestEntity), eq(String.class)))
                .thenReturn(mockResponseEntitySuccess);

        ResponseEntity<?> response = serviceBase.sendDigiSecRequest(uri, mockRequestEntity, String.class, HttpMethod.POST, cid);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("mock-response-success", response.getBody());
        verify(restTemplate, times(1)).exchange(eq(uri), eq(HttpMethod.POST), eq(mockRequestEntity), eq(String.class));
    }


    @Test
    public void testSendDigiSecRequest_RetryAndFail() {
        String uri = "http://mock-url";
        String cid = "mock-cid";
        when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), eq(mockRequestEntity), eq(String.class)))
                .thenReturn(null)
                .thenReturn(mockResponseEntityFailure)
                .thenReturn(mockResponseEntitySuccess);

        ResponseEntity<?> response = serviceBase.sendDigiSecRequest(uri, mockRequestEntity, String.class, HttpMethod.POST, cid);
        assertNotNull(response);
    }

    @Test
    public void testSendDigiSecRequest_Exceptionl() {
        String uri = "http://mock-url";
        String cid = "mock-cid";
        when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), eq(mockRequestEntity), eq(String.class)))
                .thenReturn(null)
                .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR))
                .thenReturn(mockResponseEntitySuccess);


        ResponseEntity<?> response = serviceBase.sendDigiSecRequest(uri, mockRequestEntity, String.class, HttpMethod.POST, cid);
        assertNotNull(response);
    }


    @Test
    public void testSendRequestFDS_Success() {
        String uri = "http://mock-url";
        when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), eq(mockRequestEntity), eq(String.class)))
                .thenReturn(mockResponseEntitySuccess);

        ResponseEntity<?> response = serviceBase.sendRequestFDS(uri, mockRequestEntity, String.class, HttpMethod.POST);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("mock-response-success", response.getBody());
        verify(restTemplate, times(1)).exchange(eq(uri), eq(HttpMethod.POST), eq(mockRequestEntity), eq(String.class));
    }

    @Test
    public void testSendRequestFDS_RetryAndFail() {
        String uri = "http://mock-url";
        when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), eq(mockRequestEntity), eq(String.class)))
                .thenReturn(mockResponseEntityFailure)
                .thenReturn(mockResponseEntityFailure)
                .thenReturn(mockResponseEntitySuccess);

        ResponseEntity<?> response = serviceBase.sendRequestFDS(uri, mockRequestEntity, String.class, HttpMethod.POST);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("mock-response-success", response.getBody());
        verify(restTemplate, times(3)).exchange(eq(uri), eq(HttpMethod.POST), eq(mockRequestEntity), eq(String.class));
    }

    @Test
    public void testSendRequestFDS_Failure() throws OAuthProblemException, ApplicationException, OAuthSystemException, IOException, NoSuchFieldException, IllegalAccessException {
        String uri = "http://mock-url";
        when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), eq(mockRequestEntity), eq(String.class)))
                .thenReturn(mockResponseEntityFailure);

        ResponseEntity<?> response = serviceBase.sendRequestFDS(uri, mockRequestEntity, String.class, HttpMethod.POST);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("mock-response", response.getBody());

    }

    @Test
    public void testRetryRequest_Success() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        ResponseEntity<String> mockResponse = new ResponseEntity<>("mock-response", HttpStatus.OK);

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenReturn(mockResponse);

        ResponseEntity<?> response = serviceBase.retryRequest(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }


    @Test
    public void testRetryRequest_ResourceAccessException() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        ResourceAccessException exception = new ResourceAccessException("Resource access error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryRequest(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNull(response);
    }

    @Test
    public void testRetryRequest_RestClientException() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        RestClientException exception = new RestClientException("Rest client error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryRequest(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNull(response);
    }

    @Test
    public void testRetryRequest_GenericException() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        RuntimeException exception = new RuntimeException("Unexpected error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        try {
            serviceBase.retryRequest(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");
            fail("Expected RuntimeException");
        } catch (RuntimeException thrown) {
            assertEquals("Unexpected error", thrown.getMessage());
        }
    }

    @Test
    public void testRetryRequestFDS_Success() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        ResponseEntity<String> mockResponse = new ResponseEntity<>("mock-response", HttpStatus.OK);

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenReturn(mockResponse);

        ResponseEntity<?> response = serviceBase.retryRequestFDS(uri, requestEntity, String.class, HttpMethod.POST);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testRetryRequestFDS_HttpServerErrorException_NullStatusText() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, null);

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        try {
            serviceBase.retryRequestFDS(uri, requestEntity, String.class, HttpMethod.POST);
            fail("Expected HttpServerErrorException");
        } catch (HttpServerErrorException thrown) {
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, thrown.getStatusCode());
        }
    }

    @Test
    public void testRetryRequestFDS_HttpServerErrorException_WithStatusText() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Server Error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryRequestFDS(uri, requestEntity, String.class, HttpMethod.POST);

        assertNull(response);
    }

    @Test
    public void testRetryRequestFDS_HttpClientErrorException_InvalidGrant() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        HttpClientErrorException exception = new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Bad Request", "invalid_grant".getBytes(), null);

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        try {
            serviceBase.retryRequestFDS(uri, requestEntity, String.class, HttpMethod.POST);
            fail("Expected HttpClientErrorException");
        } catch (HttpClientErrorException thrown) {
            assertEquals(HttpStatus.BAD_REQUEST, thrown.getStatusCode());
        }
    }

    @Test
    public void testRetryRequestFDS_HttpClientErrorException_Other() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        HttpClientErrorException exception = new HttpClientErrorException(HttpStatus.BAD_REQUEST, "Bad Request");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryRequestFDS(uri, requestEntity, String.class, HttpMethod.POST);

        assertNull(response);
    }

    @Test
    public void testRetryRequestFDS_ResourceAccessException() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        ResourceAccessException exception = new ResourceAccessException("Resource access error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryRequestFDS(uri, requestEntity, String.class, HttpMethod.POST);

        assertNull(response);
    }

    @Test
    public void testRetryRequestFDS_RestClientException() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        RestClientException exception = new RestClientException("Rest client error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryRequestFDS(uri, requestEntity, String.class, HttpMethod.POST);

        assertNull(response);
    }

    @Test
    public void testRetryRequestFDS_GenericException() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        RuntimeException exception = new RuntimeException("Unexpected error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        try {
            serviceBase.retryRequestFDS(uri, requestEntity, String.class, HttpMethod.POST);
            fail("Expected RuntimeException");
        } catch (RuntimeException thrown) {
            assertEquals("Unexpected error", thrown.getMessage());
        }
    }

    @Test
    public void testRetryDigiSecRequest_Success() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        ResponseEntity<String> mockResponse = new ResponseEntity<>("mock-response", HttpStatus.OK);

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenReturn(mockResponse);

        ResponseEntity<?> response = serviceBase.retryDigiSecRequest(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testRetryDigiSecRequest_HttpClientErrorException_WithPaa() {
        String uri = "http://mock-url/paa";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        HttpClientErrorException exception = new HttpClientErrorException(HttpStatus.BAD_REQUEST);

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryDigiSecRequest(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNull(response);
    }

    @Test
    public void testRetryDigiSecRequest_HttpClientErrorException_WithoutPaa() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        HttpClientErrorException exception = new HttpClientErrorException(HttpStatus.BAD_REQUEST);

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryDigiSecRequest(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNull(response);
    }

    @Test
    public void testRetryDigiSecRequest_ResourceAccessException_WithPaa() {
        String uri = "http://mock-url/paa";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        ResourceAccessException exception = new ResourceAccessException("Resource access error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryDigiSecRequest(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNull(response);
    }

    @Test
    public void testRetryDigiSecRequest_ResourceAccessException_WithoutPaa() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        ResourceAccessException exception = new ResourceAccessException("Resource access error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryDigiSecRequest(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNull(response);
    }

    @Test
    public void testRetryDigiSecRequest_RestClientException() {
        String uri = "http://mock-url";
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        RestClientException exception = new RestClientException("Rest client error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryDigiSecRequest(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNull(response);
    }


    @Test
    public void testSendRequestURI_Success_OK() throws Exception {
        URI uri = new URI("http://mock-url");
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        ResponseEntity<String> mockResponse = new ResponseEntity<>("mock-response", HttpStatus.OK);

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenReturn(mockResponse);

        ResponseEntity<?> response = serviceBase.sendRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testSendRequestURI_Success_Created() throws Exception {
        URI uri = new URI("http://mock-url");
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        ResponseEntity<String> mockResponse = new ResponseEntity<>("mock-response", HttpStatus.CREATED);

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenReturn(mockResponse);

        ResponseEntity<?> response = serviceBase.sendRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNotNull(response);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

//    @Test
//    void testSendRequestURI_HttpClientErrorException() throws Exception {
//        URI uri = new URI("http://mock-url");
//        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
//        HttpClientErrorException exception = new HttpClientErrorException(HttpStatus.BAD_REQUEST);
//
//        when(serviceBase.sendRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid")).thenThrow(exception);
//
//        HttpClientErrorException thrown = assertThrows(HttpClientErrorException.class, () -> {
//            serviceBase.sendRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");
//        });
//        assertEquals(HttpStatus.BAD_REQUEST, thrown.getStatusCode());
//    }
//
//    @Test
//    void testSendRequestURI_HttpServerErrorException() throws Exception {
//        URI uri = new URI("http://mock-url");
//        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
//        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
//
//        when(serviceBase.sendRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid")).thenThrow(exception);
//
//        HttpServerErrorException thrown = assertThrows(HttpServerErrorException.class, () -> {
//            serviceBase.sendRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");
//        });
//        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, thrown.getStatusCode());
//    }

    @Test
    public void testSendRequestURI_ResourceAccessException() throws Exception {
        URI uri = new URI("http://mock-url");
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        ResourceAccessException exception = new ResourceAccessException("Resource access error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.sendRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNull(response);
    }

    @Test
    public void testSendRequestURI_RestClientException() throws Exception {
        URI uri = new URI("http://mock-url");
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        RestClientException exception = new RestClientException("Rest client error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.sendRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNull(response);
    }

//    @Test
//    void testSendRequestURI_GenericException() throws Exception {
//        URI uri = new URI("http://mock-url");
//        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
//        RuntimeException exception = new RuntimeException("Unexpected error");
//
//        when(serviceBase.sendRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid")).thenThrow(exception);
//
//        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
//            serviceBase.sendRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");
//        });
//        assertEquals("Unexpected error", thrown.getMessage());
//    }

    @Test
    public void testRetryRequestURI_Success() throws Exception {
        URI uri = new URI("http://mock-url");
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        ResponseEntity<String> mockResponse = new ResponseEntity<>("mock-response", HttpStatus.OK);

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenReturn(mockResponse);

        ResponseEntity<?> response = serviceBase.retryRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testRetryRequestURI_HttpServerErrorException_NullStatusText() throws Exception {
        URI uri = new URI("http://mock-url");
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, null);

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        try {
            serviceBase.retryRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");
            fail("Expected HttpServerErrorException");
        } catch (HttpServerErrorException thrown) {
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, thrown.getStatusCode());
        }
    }

    @Test
    public void testRetryRequestURI_HttpServerErrorException_WithStatusText() throws Exception {
        URI uri = new URI("http://mock-url");
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Server Error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNull(response);
    }

    @Test
    public void testRetryRequestURI_HttpClientErrorException() throws Exception {
        URI uri = new URI("http://mock-url");
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        HttpClientErrorException exception = new HttpClientErrorException(HttpStatus.BAD_REQUEST);

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);
        ResponseEntity<?> response = serviceBase.retryRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");
        assertNull(response);
    }

    @Test
    public void testRetryRequestURI_ResourceAccessException() throws Exception {
        URI uri = new URI("http://mock-url");
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        ResourceAccessException exception = new ResourceAccessException("Resource access error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNull(response);
    }

    @Test
    public void testRetryRequestURI_RestClientException() throws Exception {
        URI uri = new URI("http://mock-url");
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        RestClientException exception = new RestClientException("Rest client error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        ResponseEntity<?> response = serviceBase.retryRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");

        assertNull(response);
    }

    @Test
    public void testRetryRequestURI_GenericException() throws Exception {
        URI uri = new URI("http://mock-url");
        HttpEntity<String> requestEntity = new HttpEntity<>("mock-body");
        RuntimeException exception = new RuntimeException("Unexpected error");

        when(restTemplate.exchange(uri, HttpMethod.POST, requestEntity, String.class)).thenThrow(exception);

        try {
            serviceBase.retryRequestURI(uri, requestEntity, String.class, HttpMethod.POST, "mock-cid");
            fail("Expected RuntimeException");
        } catch (RuntimeException thrown) {
            assertEquals("Unexpected error", thrown.getMessage());
        }
    }

    @Test
    public void testSendRequest_NullResponse() throws Exception {

        String uri = "http://mock-url";
        String cid = "cid";

        when(restTemplate.exchange(eq(uri), any(), any(), eq(String.class)))
                .thenReturn(null);

        ResponseEntity<?> response =
                serviceBase.sendRequest(uri, mockRequestEntity, String.class, HttpMethod.POST, cid);

        assertNull(response);
    }
    
//    @Test
//    public void testSendRequest_ReturnsFailureResponse() {
//
//        String uri = "http://mock-url";
//        String cid = "cid";
//
//        when(restTemplate.exchange(eq(uri), any(), any(), eq(String.class)))
//                .thenReturn(mockResponseEntityFailure);
//
//        ResponseEntity<?> response =
//                serviceBase.sendRequest(uri, mockRequestEntity, String.class, HttpMethod.POST, cid);
//
//        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
//    }
    
    @Test
    public void testSendRequestFDS_InvalidGrant() {

        String uri = "http://mock-url";

        HttpClientErrorException ex =
                HttpClientErrorException.create(
                        HttpStatus.BAD_REQUEST,
                        "Bad Request",
                        HttpHeaders.EMPTY,
                        "invalid_grant".getBytes(),
                        null
                );

        when(restTemplate.exchange(eq(uri), any(), any(), eq(String.class)))
                .thenThrow(ex);

        try {
            serviceBase.sendRequestFDS(uri, mockRequestEntity, String.class, HttpMethod.POST);
            fail();
        } catch (Exception e) {
            assertTrue(e instanceof HttpClientErrorException);
        }
    }
    
    @Test
    public void testSendDigiSecRequest_PaaPath() {

        String uri = "http://mock-url/paa";
        String cid = "cid";

        when(restTemplate.exchange(eq(uri), any(), any(), eq(String.class)))
                .thenReturn(null);

        ResponseEntity<?> response =
                serviceBase.sendDigiSecRequest(uri, mockRequestEntity, String.class, HttpMethod.POST, cid);

        assertNull(response);
    }
    
    @Test
    public void testSendRequestURI_RetryFlow() throws Exception {

        URI uri = new URI("http://mock-url");

        when(restTemplate.exchange(eq(uri), any(), any(), eq(String.class)))
                .thenReturn(null)
                .thenReturn(mockResponseEntitySuccess);

        ResponseEntity<?> response =
                serviceBase.sendRequestURI(uri, mockRequestEntity, String.class, HttpMethod.POST, "cid");

        assertNotNull(response);
    }
}
