package com.optum.providerpreferences.rs.handler;

import static com.optum.providerpreferences.rs.handler.Oauth2Handler.lockObjectMap;
import static com.optum.providerpreferences.rs.handler.Oauth2Handler.tokenMap;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.TokenAbst;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import sun.misc.Unsafe;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;

public class Oauth2HandlerTest {

    @InjectMocks
    private Oauth2Handler oauth2Handler;

    @Mock
    private RestTemplate restTemplate;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetOauthToken_Success() throws Exception {
        Oauth2Handler oauth2Handler = new Oauth2Handler();
        Oauth2Handler.TokenStore tokenStore = oauth2Handler.new TokenStore("http://mock-url", "mock-client-id", "mock-client-secret");
        tokenMap.put("PES", tokenStore);

        Token mockToken = new Token();
        mockToken.setAccessToken("mock-access-token");
        tokenStore.token = mockToken;
        tokenStore.lastTokenExpireTime = System.currentTimeMillis() + 600000; // Token valid for 10 minutes

        TokenAbst result = oauth2Handler.getOauthToken("mock-session", "PES");

        assertNotNull(result);
        assertEquals("mock-access-token", result.getAccessToken());
    }

//    @Test
//    public void testGetOauthToken_ExpiredToken() throws Exception {
//        Oauth2Handler oauth2Handler = new Oauth2Handler();
//        Oauth2Handler.TokenStore tokenStore = oauth2Handler.new TokenStore("http://mock-url", "mock-client-id", "mock-client-secret");
//        tokenMap.put("PES", tokenStore);
//        tokenStore.lastTokenExpireTime = System.currentTimeMillis() - 1000;
//
//        Field lockObjectMapField = Oauth2Handler.class.getDeclaredField("lockObjectMap");
//        lockObjectMapField.setAccessible(true);
//
//        Map<String, Object> lockObjectMap = new HashMap<>();
//        lockObjectMap.put("PES", new Object());
////        lockObjectMapField.set(oauth2Handler, lockObjectMap);
//
//        ResponseEntity<HashMap> mockResponse = mock(ResponseEntity.class);
//        HashMap<String, Object> responseBody = new HashMap<>();
//        responseBody.put("access_token", "new-access-token");
//        responseBody.put("expires_in", 3600);
//        when(mockResponse.getBody()).thenReturn(responseBody);
//
//        when(restTemplate.exchange(
//                eq("http://mock-url"),
//                eq(HttpMethod.POST),
//                any(HttpEntity.class),
//                eq(HashMap.class)
//        )).thenReturn(mockResponse);
//
//        TokenAbst result = oauth2Handler.getOauthToken("mock-session", "PES");
//
//        // Assert
//        assertNotNull(result);
//        assertEquals("new-access-token", ((Token) result).getAccessToken());
//    }

    @Test
    public void testGetOauthToken_Exception() {
        Oauth2Handler oauth2Handler = new Oauth2Handler();
        Oauth2Handler.TokenStore tokenStore = oauth2Handler.new TokenStore("http://mock-url", "mock-client-id", "mock-client-secret");
        tokenMap.put("PES", tokenStore);

        when(restTemplate.exchange(
                eq("http://mock-url"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(HashMap.class)
        )).thenThrow(new RuntimeException("Mocked Exception"));

        try {
            oauth2Handler.getOauthToken("mock-session", "PES");
            fail("Expected NullPointerException");
        } catch (NullPointerException e) {
            // expected
        } catch (OAuthProblemException | ApplicationException | ResourceAccessException | IOException e) {
            fail("Unexpected exception: " + e.getMessage());
        } catch (OAuthSystemException e) {
            assertTrue(e.getMessage().contains("Mocked Exception"));
        }
    }

    @Test
    public void testTokenAboutToExpire() {
        long currentTime = System.currentTimeMillis();
        long expireTime = currentTime + 5000; // 5 seconds left
        long lastTokenExpireTime = currentTime + 10000; // 10 seconds left

        boolean result = oauth2Handler.tokenAboutToExpire("mock-session", lastTokenExpireTime);

        assertTrue(result);
    }

    @Test
    public void testGetNewToken() throws Exception {
        // Arrange
        String sessionId = "mock-session";
        String serviceIndicator = "PES";
        Oauth2Handler.TokenStore tokenStore = oauth2Handler.new TokenStore("http://mock-url", "mock-client-id", "mock-client-secret");

        ResponseEntity<HashMap> mockResponse = mock(ResponseEntity.class);
        HashMap<String, Object> responseBody = new HashMap<>();
        responseBody.put("access_token", "new-access-token");
        responseBody.put("expires_in", 3600);
        when(mockResponse.getBody()).thenReturn(responseBody);

        when(restTemplate.exchange(
                eq("http://mock-url"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(HashMap.class)
        )).thenReturn(mockResponse);

        Oauth2Handler.TokenStore result = oauth2Handler.getNewToken(sessionId, serviceIndicator, tokenStore);

        assertNotNull(result.toString());
        assertNotNull(result.token);
        assertEquals("new-access-token", ((Token) result.token).getAccessToken());
        assertEquals(3600, result.expiresIn);
    }


//    @Test
//    void testGetOauthTokenRefresh() throws Exception {
//        // Arrange
//        String sessionId = "mock-session";
//        String serviceIndicator = "PES";
//
//        Oauth2Handler.TokenStore tokenStore = oauth2Handler.new TokenStore("http://mock-url", "mock-client-id", "mock-client-secret");
//        tokenStore.lastTokenExpireTime = 1000L;
//        tokenStore.expiresIn = 3600L;
//
//        Field lockObjectMapField = Oauth2Handler.class.getDeclaredField("lockObjectMap");
//        lockObjectMapField.setAccessible(true);
//        Map<String, Object> mockLockObjectMap = mock(Map.class);
//        Field theUnsafeField = Unsafe.class.getDeclaredField("theUnsafe");
//        theUnsafeField.setAccessible(true);
//        Unsafe unsafe = (Unsafe) theUnsafeField.get(null);
//        unsafe.putObjectVolatile(
//                Oauth2Handler.class,
//                unsafe.staticFieldOffset(lockObjectMapField),
//                mockLockObjectMap
//        );
//
//        Field tokenMapField = Oauth2Handler.class.getDeclaredField("tokenMap");
//        tokenMapField.setAccessible(true);
//        Map<String, Oauth2Handler.TokenStore> mockTokenMap = mock(Map.class);
//        tokenMapField.set(null, mockTokenMap);
//
//        when(mockTokenMap.get(serviceIndicator)).thenReturn(tokenStore);
//        when(mockLockObjectMap.get(serviceIndicator)).thenReturn(new Object());
//        doReturn(mock(TokenAbst.class)).when(oauth2Handler).getOauthToken(sessionId, serviceIndicator);
//
//        TokenAbst result = oauth2Handler.getOauthTokenRefresh(sessionId, serviceIndicator);
//        assertNull(result);
//    }
    
	@Test
	public void testGetTokenFromMap_FDSCloud() throws Exception {

		oauth2Handler.fdsTokenUrl = "url";
		oauth2Handler.fdsClientId = "id";
		oauth2Handler.fdsClientSecret = "secret";

		Oauth2Handler.TokenStore store = oauth2Handler.getTokenFromMap("session", "FDSCLOUD");

		assertNotNull(store);
	}

	@Test
	public void testGetTokenFromMap_PE() throws Exception {

		oauth2Handler.PeTokenUrl = "url";
		oauth2Handler.PeClientId = "id";
		oauth2Handler.PeClientSecret = "secret";

		Oauth2Handler.TokenStore store = oauth2Handler.getTokenFromMap("session", "PE");

		assertNotNull(store);
	}

	@Test(expected = ApplicationException.class)
	public void testGetTokenFromMap_NullConfig() throws Exception {

		// ✅ VERY IMPORTANT
		tokenMap.clear();

		oauth2Handler.stargateTokenUrl = null;
		oauth2Handler.stargateClientId = null;
		oauth2Handler.stargateClientSecret = null;

		oauth2Handler.getTokenFromMap("session", "PES");
	}

	@Test
	public void testGetOauthTokenRefresh() throws Exception {

		// ✅ Prepare token store
		Oauth2Handler.TokenStore store = oauth2Handler.new TokenStore("http://mock-url", "id", "secret");

		tokenMap.put("PES", store);
		lockObjectMap.put("PES", new Object());

		// ✅ MOCK RESPONSE
		ResponseEntity<HashMap> mockResponse = mock(ResponseEntity.class);

		HashMap<String, Object> body = new HashMap<>();
		body.put("access_token", "new-token");
		body.put("expires_in", 3600);

		when(mockResponse.getBody()).thenReturn(body);

		when(restTemplate.exchange(eq("http://mock-url"), eq(HttpMethod.POST), any(HttpEntity.class),
				eq(HashMap.class))).thenReturn(mockResponse);

		// ✅ ACT
		TokenAbst token = oauth2Handler.getOauthTokenRefresh("session", "PES");

		// ✅ ASSERT
		assertNotNull(token);
		assertEquals("new-token", ((Token) token).getAccessToken());
	}

	@Test
	public void testSetExpireTimeOfToken() {

		Oauth2Handler.TokenStore store = oauth2Handler.new TokenStore("url", "id", "secret");

		store.expiresIn = 10;

		oauth2Handler.setExpireTimeOfToken("session", "PES", store);

		assertTrue(store.lastTokenExpireTime > 0);
	}

}