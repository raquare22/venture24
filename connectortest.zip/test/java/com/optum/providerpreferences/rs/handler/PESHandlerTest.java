package com.optum.providerpreferences.rs.handler;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.PESHandler;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.pes.*;
import com.optum.providerpreferences.rs.utility.SanitizeUtil;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.checkerframework.checker.units.qual.K;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.springframework.http.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;

public class PESHandlerTest {

    @InjectMocks
    private PESHandler pesHandler;

    @Mock
    private HttpHeaders headers;
    PESHandler pesHandlerSpy = spy(new PESHandler());


    @Before
    public void setUp() throws OAuthProblemException, ApplicationException, OAuthSystemException, IOException {
        MockitoAnnotations.openMocks(this);

        doNothing().when(pesHandlerSpy).pesWebServicePrep();
        pesHandlerSpy.pesWebServicePrep();
    }

    @Test
    public void testGetTins_Success() throws Exception {
        PESTinRequest tinRequest = new PESTinRequest("corpMpin");
        tinRequest.setCorporateOwnerProviderId("test-tin");
        String cid = "test-cid";

        PESResponse mockResponse = new PESResponse();
        TinObject tb = new TinObject();
        Key key = new Key();
        key.setTaxIdNumber("123456789");
        key.setTaxIdTypeCode("EIN");
        mockResponse.setMeta(new Meta());
        tb.setKey(key);
        mockResponse.setData(List.of(tb));
        ResponseEntity<PESResponse> responseEntity = ResponseEntity.ok(mockResponse);

        doReturn(responseEntity).when(pesHandlerSpy).sendRequest(
                anyString(),
                any(HttpEntity.class),
                eq(PESResponse.class),
                eq(HttpMethod.POST),
                eq(cid)
        );

        HttpHeaders mockHeaders = mock(HttpHeaders.class);
        when(mockHeaders.isEmpty()).thenReturn(false);
        when(mockHeaders.getContentType()).thenReturn(MediaType.APPLICATION_JSON);

        try (MockedStatic<UriComponentsBuilder> mockedUriComponentsBuilder = Mockito.mockStatic(UriComponentsBuilder.class)) {
            UriComponentsBuilder mockBuilder = mock(UriComponentsBuilder.class);
            mockedUriComponentsBuilder.when(() -> UriComponentsBuilder.fromUriString(System.getenv("PES_TIN_URL")))
                    .thenReturn(mockBuilder);
            when(mockBuilder.toUriString()).thenReturn("mocked-uri");

            PESResponse result = pesHandlerSpy.getTins(tinRequest, cid);

            assertNotNull(result);
            verify(pesHandlerSpy, times(1)).sendRequest(anyString(), any(HttpEntity.class), eq(PESResponse.class), eq(HttpMethod.POST), eq(cid));
            mockedUriComponentsBuilder.verify(() -> UriComponentsBuilder.fromUriString(System.getenv("PES_TIN_URL")), times(1));
        }
    }

    @Test
    public void testGetTins_Exception() throws Exception {
        PESTinRequest tinRequest = new PESTinRequest("corpMpin");
        tinRequest.setCorporateOwnerProviderId("test-tin");
        String cid = "test-cid";

        doThrow(new RuntimeException("Mocked Exception")).when(pesHandlerSpy).sendRequest(
                anyString(),
                any(HttpEntity.class),
                eq(PESResponse.class),
                eq(HttpMethod.POST),
                eq(cid)
        );

        try {
            pesHandlerSpy.getTins(tinRequest, cid);
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            // expected
        }
    }

    @Test
    public void testGetTins_NullTinRequest() throws OAuthProblemException, ApplicationException, OAuthSystemException, IOException {
        PESTinRequest tinRequest = null;
        String cid = "test-cid";

        PESHandler pesHandlerSpy = spy(pesHandler);

        try {
            pesHandlerSpy.getTins(tinRequest, cid);
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("null"));
        }
    }

//    @Test
//    public void testPesWebServicePrep() throws Exception {
//        doNothing().when(pesHandlerSpy).setToken(any());
//        pesHandlerSpy.pesWebServicePrep();
//    }
}