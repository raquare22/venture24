package com.optum.providerpreferences.rs.handler;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import org.springframework.web.client.*;
import java.nio.charset.StandardCharsets;

@RunWith(MockitoJUnitRunner.class)
public class PEHandlerTest {

        private PEHandler handler;

        @Mock
        private RestTemplate restTemplate;

        @Mock
        private Oauth2Handler oauth2Handler;

        private final String uri = "http://example.com/api";

        @Before
        public void setUp() {
            handler = new PEHandler();
            handler.restTemplate = restTemplate;
            handler.oauth2handler = oauth2Handler;
            handler.numRetries = 2;
            handler.timeToWaitMs = 1;
        }

        @Test
        public void testSendRequestPaymentEngine_successFirstAttempt() {
            HttpEntity<String> entity = new HttpEntity<>("body");
            when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                    .thenReturn(ResponseEntity.ok("ok"));

            ResponseEntity<?> resp = handler.sendRequestPaymentEngine(uri, entity, HttpMethod.POST);
            assertNotNull(resp);
            assertEquals(HttpStatus.OK, resp.getStatusCode());
            assertEquals("ok", resp.getBody());
        }

        @Test
        public void testSendRequestPaymentEngine_retryThenSuccess() {
            HttpEntity<String> entity = new HttpEntity<>("body");
            // first call throws server error, second returns OK
            when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                    .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "server"))
                    .thenReturn(ResponseEntity.ok("recovered"));

            ResponseEntity<?> resp = handler.sendRequestPaymentEngine(uri, entity, HttpMethod.POST);
            assertNotNull(resp);
            assertEquals(HttpStatus.OK, resp.getStatusCode());
            assertEquals("recovered", resp.getBody());
        }

        @Test(expected = HttpClientErrorException.class)
        public void testSendRequestPaymentEngine_invalidGrant_throws() {
            HttpEntity<String> entity = new HttpEntity<>("body");
            HttpClientErrorException invalidGrant = new HttpClientErrorException(
                    HttpStatus.BAD_REQUEST,
                    "Bad Request",
                    "invalid_grant".getBytes(StandardCharsets.UTF_8),
                    StandardCharsets.UTF_8
            );

            when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                    .thenThrow(invalidGrant);

            handler.sendRequestPaymentEngine(uri, entity, HttpMethod.POST);
        }

        @Test(expected = NullPointerException.class)
        public void testSendRequestPaymentEngine_clientError_nonInvalidGrant_leadsToNullPointer() {
            HttpEntity<String> entity = new HttpEntity<>("body");
            HttpClientErrorException clientErr = new HttpClientErrorException(
                    HttpStatus.BAD_REQUEST,
                    "Bad Request",
                    "other_error".getBytes(StandardCharsets.UTF_8),
                    StandardCharsets.UTF_8
            );

            // every call returns the same client error (no invalid_grant), handler swallows and eventually NPE
            when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                    .thenThrow(clientErr);

            handler.sendRequestPaymentEngine(uri, entity, HttpMethod.POST);
        }

        @Test
        public void testRetryRequestPaymentEngine_resourceAccessException_returnsNull() {
            HttpEntity<String> entity = new HttpEntity<>("body");
            when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                    .thenThrow(new ResourceAccessException("io error"));

            ResponseEntity<?> resp = handler.retryRequestPaymentEngine(uri, entity, HttpMethod.POST);
            assertNull(resp);
        }

        @Test(expected = HttpServerErrorException.class)
        public void testRetryRequestPaymentEngine_serverErrorWithNullStatusText_throws() {
            HttpEntity<String> entity = new HttpEntity<>("body");
              HttpServerErrorException ex = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, null, null, null);
            when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                    .thenThrow(ex);

            handler.retryRequestPaymentEngine(uri, entity, HttpMethod.POST);
        }
    }
