package com.optum.providerpreferences.rs.handler;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.TokenAbst;
import com.optum.providerpreferences.rs.model.ndb.preferences.*;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import org.apache.logging.log4j.Logger;
import org.awaitility.reflect.WhiteboxImpl;
import org.junit.Before;
import org.junit.Test; 
import org.mockito.*;
import org.owasp.encoder.Encode;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

public class NDBHandlerTest {

    @InjectMocks
    private NDBHandler ndbHandler;

    NDBHandler ndbHandlerSpy = spy(new NDBHandler());

    @Mock
    private Oauth2Handler oauth2handler;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ObjectMapper mapper;

    @Mock
    private HttpHeaders headers;

    @Mock
    private Logger logger;

    @Before
    public void setUp() throws NoSuchFieldException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(oauth2handler, "stargateTokenUrl", "http://mock-url");
        ReflectionTestUtils.setField(oauth2handler, "stargateClientId", "mock-client-id");
        ReflectionTestUtils.setField(oauth2handler, "stargateClientSecret", "mock-client-secret");

        headers = new HttpHeaders();
        Field headersField = NDBHandler.class.getDeclaredField("headers");
        headersField.setAccessible(true);
        headersField.set(ndbHandlerSpy, headers);

        Logger mockLogger = mock(Logger.class);
        when(mockLogger.isErrorEnabled()).thenReturn(true);
    }

    @Test
    public void testNdbWebServicePrep_success() throws Exception {
        Token mockToken = new Token();
        mockToken.setAccessToken("mock-access-token");
        doReturn(null).doReturn(mockToken).when(ndbHandlerSpy).getOauth2handlerOauthToken(anyString(), anyString());

        ndbHandlerSpy.ndbWebServicePrep();

        assertEquals(MediaType.APPLICATION_JSON, headers.getContentType());
    }

//    @Test(expected = ApplicationException.class)
    public void testNdbWebServicePrep_failure() throws Exception {
        when(oauth2handler.getOauthToken("PDO", "NDB")).thenThrow(new IOException("Mock Exception"));
        ndbHandler.ndbWebServicePrep();
    }


//    @Test
    public void testGetProviderLetterPreferences_success() throws Exception {
        String cid = "test-cid";
        String ndbLetterPrefsURL = "http://test-url.com";
        ndbHandlerSpy.ndbLetterPrefsURL = ndbLetterPrefsURL;

        com.optum.providerpreferences.rs.model.ndb.preferences.RequestData requestData = new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setMessage("Success");
        responseHeader.setReturncode("0");
        RequestHeader requestHeader = new RequestHeader();
        requestHeader.setUserid("test-user");
        ResponseData responseData = new ResponseData();
        responseData.setProviderId("123");
        responseData.setProviderTIN("456");
        responseData.setProviderTINType("S");
        LetterPreferencesResponse mockResponse = new LetterPreferencesResponse();
        mockResponse.setResponseHeader(responseHeader);
        mockResponse.setRequestHeader(requestHeader);
        mockResponse.setRequest(requestData);
        mockResponse.setRequestResponse(responseData);
        ResponseEntity<LetterPreferencesResponse> responseEntity = ResponseEntity.ok(mockResponse);

        ReflectionTestUtils.setField(ndbHandlerSpy, "restTemplate", restTemplate);
        when(mapper.writeValueAsString(any(LetterPreferencesRequest.class))).thenReturn("mock-json");
        doNothing().when(ndbHandlerSpy).ndbWebServicePrep();
        when(restTemplate.exchange(
                eq(ndbLetterPrefsURL),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(LetterPreferencesResponse.class)
        )).thenReturn(responseEntity);

        try {
            ndbHandlerSpy.getProviderLetterPreferences(requestData, cid);
            fail("Expected ApplicationException was not thrown");
        } catch (ApplicationException e) {
            // Expected exception
        }
    }

    @Test(expected = ApplicationException.class)
    public void testGetProviderLetterPreferences_exception() throws Exception {
        String cid = "test-cid";
        String ndbLetterPrefsURL = "http://test-url.com";
        ndbHandler.ndbLetterPrefsURL = ndbLetterPrefsURL;

        com.optum.providerpreferences.rs.model.ndb.preferences.RequestData requestData = new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData();

        when(mapper.writeValueAsString(any(LetterPreferencesRequest.class))).thenThrow(new RuntimeException("Mock Exception"));

        ndbHandler.getProviderLetterPreferences(requestData, cid);
    }

    @Test
    public void testGetProviderData_Success() throws Exception {
        String cid = "test-cid";
        RequestData requestData = new RequestData();
        requestData.setCorpOwnerId("123");
        requestData.setTaxIdNumber("456");
        CorpMpinResponse mockResponse = new CorpMpinResponse();
        ResponseEntity<CorpMpinResponse> responseEntity = ResponseEntity.ok(mockResponse);

        ReflectionTestUtils.setField(ndbHandlerSpy, "ndbCorpMpinURL", "mock-client-secret");
        when(mapper.writeValueAsString(any(RequestData.class))).thenReturn("mock-json");
        doNothing().when(ndbHandlerSpy).ndbWebServicePrep();

        doReturn(responseEntity).when(ndbHandlerSpy).sendRequest(
                anyString(),
                any(HttpEntity.class),
                eq(CorpMpinResponse.class),
                eq(HttpMethod.POST),
                eq(cid)
        );

        CorpMpinResponse result = ndbHandlerSpy.getProviderData(requestData, cid);

        assertNotNull(result);
        assertEquals(mockResponse, result);
    }

    @Test(expected = RestClientException.class)
    public void testGetProviderData_Exception() throws Exception {
        String cid = "test-cid";
        RequestData requestData = new RequestData();
        requestData.setCorpOwnerId("123");
        requestData.setTaxIdNumber("456");
        CorpMpinResponse mockResponse = new CorpMpinResponse();
        ResponseEntity<CorpMpinResponse> responseEntity = ResponseEntity.ok(mockResponse);

        ReflectionTestUtils.setField(ndbHandlerSpy, "ndbCorpMpinURL", "mock-client-secret");
        when(mapper.writeValueAsString(any(RequestData.class))).thenReturn("mock-json");
        doNothing().when(ndbHandlerSpy).ndbWebServicePrep();

        doThrow(new RestClientException("Mock Exception")).when(ndbHandlerSpy).sendRequest(
                anyString(),
                any(HttpEntity.class),
                eq(CorpMpinResponse.class),
                eq(HttpMethod.POST),
                eq(cid)
        );
        ndbHandlerSpy.getProviderData(requestData, cid);
    }

    @Test
    public void testUpdateProviderLetterPreferences_Success() throws Exception {
        String cid = "test-cid";
        String ndbLetterPrefsURL = "http://test-url.com";
        ndbHandlerSpy.ndbLetterPrefsURL = ndbLetterPrefsURL;

        LetterPreferencesRequest request = new LetterPreferencesRequest();
        LetterPreferencesResponse mockResponse = new LetterPreferencesResponse();
        com.optum.providerpreferences.rs.model.ndb.preferences.ResponseHeader rh = new com.optum.providerpreferences.rs.model.ndb.preferences.ResponseHeader();
        rh.setMessage("Success");
        rh.setReturncode("9");

        mockResponse.setResponseHeader(rh);
        ResponseEntity<LetterPreferencesResponse> responseEntity = ResponseEntity.ok(mockResponse);

        when(mapper.writeValueAsString(any(LetterPreferencesRequest.class))).thenReturn("mock-json");
        doNothing().when(ndbHandlerSpy).ndbWebServicePrep();
        doReturn(responseEntity).when(ndbHandlerSpy).sendRequest(
                anyString(),
                any(HttpEntity.class),
                eq(LetterPreferencesResponse.class),
                eq(HttpMethod.POST),
                eq(request),
                eq(cid)
        );

        boolean result = ndbHandlerSpy.updateProviderLetterPreferences(request, "cmpin", "tin", cid);
        assertTrue(result);
    }


    @Test(expected = NullPointerException.class)
    public void testUpdateProviderLetterPreferences_Exception() throws Exception {
        String cid = "test-cid";
        String ndbLetterPrefsURL = "http://test-url.com";
        ndbHandlerSpy.ndbLetterPrefsURL = ndbLetterPrefsURL;

        LetterPreferencesRequest request = new LetterPreferencesRequest();
        LetterPreferencesResponse mockResponse = new LetterPreferencesResponse();
        com.optum.providerpreferences.rs.model.ndb.preferences.ResponseHeader rh = new com.optum.providerpreferences.rs.model.ndb.preferences.ResponseHeader();
        rh.setMessage("Success");
        rh.setReturncode("9");

        mockResponse.setResponseHeader(rh);
        ResponseEntity<LetterPreferencesResponse> responseEntity = ResponseEntity.ok(mockResponse);

        when(mapper.writeValueAsString(any(LetterPreferencesRequest.class))).thenReturn("mock-json");
        doNothing().when(ndbHandlerSpy).ndbWebServicePrep();
        doThrow(new NullPointerException()).when(ndbHandlerSpy).sendRequest(
                anyString(),
                any(HttpEntity.class),
                eq(LetterPreferencesResponse.class),
                eq(HttpMethod.POST),
                eq(request),
                eq(cid)
        );

        ndbHandlerSpy.updateProviderLetterPreferences(request, "cmpin", "tin", cid);
    }

    @Test
    public void testSendRequest_Success() throws Exception {
        String uri = "http://test-url.com";
        String cid = "test-cid";
        LetterPreferencesRequest request = new LetterPreferencesRequest();
        ResponseEntity<LetterPreferencesResponse> mockResponse = ResponseEntity.ok(new LetterPreferencesResponse());

        when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(LetterPreferencesResponse.class)))
                .thenReturn(mockResponse);

        ResponseEntity<?> response = ndbHandler.sendRequest(uri, new HttpEntity<>(request), LetterPreferencesResponse.class, HttpMethod.POST, request, cid);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(restTemplate, times(1)).exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(LetterPreferencesResponse.class));
    }

//    @Test
//    void testSendRequest_RetryLogic() throws Exception {
//        String uri = "http://test-url.com";
//        String cid = "test-cid";
//        LetterPreferencesRequest request = new LetterPreferencesRequest();
//        ResponseEntity<LetterPreferencesResponse> mockResponse = ResponseEntity.ok(new LetterPreferencesResponse());
//        TokenAbst mockToken = mock(TokenAbst.class);
//        mockToken.setAccessToken("new-mock-access-token");
//
////        ReflectionTestUtils.setField(ndbHandlerSpy, "restTemplate", restTemplate);
//        when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(LetterPreferencesResponse.class)))
//                .thenReturn(mockResponse).thenReturn(mockResponse);
////        doReturn(mockToken).when(ndbHandler).getOauth2handlerOauthTokenRefresh(anyString(), anyString());
//
//        ResponseEntity<?> response = ndbHandler.sendRequest(uri, new HttpEntity<>(request), LetterPreferencesResponse.class, HttpMethod.POST, request, cid);
//
//        assertNotNull(response);
////        assertEquals(HttpStatus.OK, response.getStatusCode());
////        verify(restTemplate, times(2)).exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(LetterPreferencesResponse.class));
//    }

//    @Test
//    void testSendRequest_Exception() throws Exception {
//        // Arrange
//        String uri = "http://test-url.com";
//        String cid = "test-cid";
//        LetterPreferencesRequest request = new LetterPreferencesRequest();
//
//        when(restTemplate.exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(LetterPreferencesResponse.class)))
//                .thenThrow(new IOException("Mock IOException"));
//
//        assertThrows(IOException.class, () -> ndbHandler.sendRequest(uri, new HttpEntity<>(request), LetterPreferencesResponse.class, HttpMethod.POST, request, cid));
//        verify(restTemplate, times(1)).exchange(eq(uri), eq(HttpMethod.POST), any(HttpEntity.class), eq(LetterPreferencesResponse.class));
//    }
    
    @Test
    public void testSendRequest_RetryFlow() throws Exception {

        String uri = "http://test-url";
        String cid = "cid";

        LetterPreferencesRequest request = new LetterPreferencesRequest();

        ResponseEntity<LetterPreferencesResponse> failResponse =
                new ResponseEntity<>(new LetterPreferencesResponse(), HttpStatus.INTERNAL_SERVER_ERROR);

        ResponseEntity<LetterPreferencesResponse> successResponse =
                new ResponseEntity<>(new LetterPreferencesResponse(), HttpStatus.OK);

        doReturn(failResponse)
                .doReturn(successResponse)
                .when(ndbHandlerSpy)
                .retryRequest(any(), any(), any(), any(), any());

        TokenAbst token = mock(TokenAbst.class);
        when(token.getAccessToken()).thenReturn("token");
        doReturn(token).when(ndbHandlerSpy)
                .getOauth2handlerOauthTokenRefresh(any(), any());

        ResponseEntity<?> result = ndbHandlerSpy.sendRequest(
                uri,
                new HttpEntity<>(request),
                LetterPreferencesResponse.class,
                HttpMethod.POST,
                request,
                cid
        );

        assertEquals(HttpStatus.OK, result.getStatusCode());
    }
    
    @Test
    public void testSendRequest_AllRetriesFail() throws Exception {

        String uri = "http://test-url";
        String cid = "cid";

        LetterPreferencesRequest request = new LetterPreferencesRequest();

        ResponseEntity<LetterPreferencesResponse> failResponse =
                new ResponseEntity<>(new LetterPreferencesResponse(), HttpStatus.INTERNAL_SERVER_ERROR);

        ResponseEntity<LetterPreferencesResponse> successResponse =
                new ResponseEntity<>(new LetterPreferencesResponse(), HttpStatus.OK);


        doReturn(failResponse)
                .when(ndbHandlerSpy)
                .retryRequest(any(), any(), any(), any(), any());

        TokenAbst token = mock(TokenAbst.class);
        when(token.getAccessToken()).thenReturn("token");
        doReturn(token).when(ndbHandlerSpy)
                .getOauth2handlerOauthTokenRefresh(any(), any());

        ResponseEntity<?> result = ndbHandlerSpy.sendRequest(
                uri,
                new HttpEntity<>(request),
                LetterPreferencesResponse.class,
                HttpMethod.POST,
                request,
                cid
        );

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
    }
    
    @Test(expected = NullPointerException.class)
    public void testSendRequest_NullResponse() throws Exception {

        String uri = "http://test-url";
        String cid = "cid";

        LetterPreferencesRequest request = new LetterPreferencesRequest();

        doReturn(null)
                .when(ndbHandlerSpy)
                .retryRequest(any(), any(), any(), any(), any());

        ndbHandlerSpy.sendRequest(
                uri,
                new HttpEntity<>(request),
                LetterPreferencesResponse.class,
                HttpMethod.POST,
                request,
                cid
        );
    }
    
    @Test
    public void testUpdateProviderLetterPreferences_FailureReturnFalse() throws Exception {

        String cid = "cid";

        LetterPreferencesRequest request = new LetterPreferencesRequest();

        // ✅ FIX: initialize nested data
        com.optum.providerpreferences.rs.model.ndb.preferences.RequestData innerReq =
                new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData();

        List<LetterType> letterTypeList = new ArrayList<>();

        LetterType letterType = new LetterType();
        letterType.setLetterType("TEST"); // or any dummy value

        letterTypeList.add(letterType);

        innerReq.setLetterTypeList(letterTypeList);
        innerReq.setMailPref("EMAIL");

        request.setRequest(innerReq);

        // ✅ FIX: set URL
        ReflectionTestUtils.setField(ndbHandlerSpy, "ndbLetterPrefsURL", "http://test-url");

        LetterPreferencesResponse response = new LetterPreferencesResponse();
        ResponseHeader header = new ResponseHeader();
        header.setReturncode("99"); // failure case
        header.setMessage("ERROR");
        response.setResponseHeader(header);

        ResponseEntity<LetterPreferencesResponse> entity =
                new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

        doReturn(entity).when(ndbHandlerSpy)
                .sendRequest(any(), any(), any(), any(), eq(request), eq(cid));

        boolean result = ndbHandlerSpy.updateProviderLetterPreferences(
                request, "m", "t", cid);

        assertFalse(result);
    }
    
    @Test
    public void testGetProviderLetterPreferences_RealSuccess() throws Exception {

        String cid = "cid";

        com.optum.providerpreferences.rs.model.ndb.preferences.RequestData req =
                new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData();

        LetterPreferencesResponse resp = new LetterPreferencesResponse();
        ResponseEntity<?> entity = ResponseEntity.ok(resp);

        // ✅ FIX: set URL (VERY IMPORTANT)
        ReflectionTestUtils.setField(ndbHandlerSpy, "ndbLetterPrefsURL", "http://test-url");

        doReturn(entity).when(ndbHandlerSpy)
                .sendRequest(any(), any(), any(), any(), any());

        doNothing().when(ndbHandlerSpy).ndbWebServicePrep();

        LetterPreferencesResponse result =
                ndbHandlerSpy.getProviderLetterPreferences(req, cid);

        assertNotNull(result);
    }
    
}