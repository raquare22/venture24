package com.optum.providerpreferences.rs.handler;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import org.json.JSONException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.owasp.encoder.Encode;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class FDSCloudHandlerTest {

    @InjectMocks
    private FDSCloudHandler fdsCloudHandler;

    @Mock
    private HttpHeaders headers;

    @Mock
    private Oauth2Handler oauth2handler;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFDSCloudGetRequest() throws Exception {
        String sessionId = "test-session-id";
        String sort = "createdOn";
        String cid = "test-cid";
        FDSCloudRequest fdsCloudRequest = new FDSCloudRequest();
        fdsCloudRequest.setRequest(Map.of("searchTerms", "test-search"));

        Token mockToken = new Token();
        mockToken.setAccessToken("mock-access-token");
        FDSCloudHandler fdsCloudHandlerSpy = spy(new FDSCloudHandler());
        FDSCloudGETResponse mockResponseBody = new FDSCloudGETResponse();

        doReturn(mockToken).when(fdsCloudHandlerSpy).getFDSCloudToken(sessionId);
        ResponseEntity<FDSCloudGETResponse> mockResponse = ResponseEntity.ok(mockResponseBody);
        doReturn(mockResponse).when(fdsCloudHandlerSpy).sendRequestURI(
                any(),
                any(),
                eq(FDSCloudGETResponse.class),
                eq(HttpMethod.GET),
                eq(Encode.forJava(cid))
        );
        ReflectionTestUtils.setField(fdsCloudHandlerSpy, "fdsCloudURL", "http://mock-fdscloud-url");

        FDSCloudGETResponse result = fdsCloudHandlerSpy.FDSCloudGetRequest(sessionId, fdsCloudRequest, sort, cid);
        assertNotNull(result);
        verify(fdsCloudHandlerSpy, times(1)).getFDSCloudToken(sessionId);

        //Throws exception - TEST
        ReflectionTestUtils.setField(fdsCloudHandlerSpy, "fdsCloudURL", "htaap://mock-fdscloud-url");
       
    }

    @Test
    public void testGetAvailableAutoenrolledForOptOut() throws Exception {
        String tin = "test-tin";
        String mpin = "test-mpin";
        String fileName = "test-file";
        String sessionId = "test-session-id";
        String cid = "test-cid";

        Token mockToken = new Token();
        mockToken.setAccessToken("mock-access-token");
        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument mockDocument = new OptOutFDSCloudDocument();
        mockDocument.setDocumentId("test-doc-id");
        mockDocument.setMetadata("{\"tin\":\"test-tin\",\"mpin\":\"test-mpin\",\"fileName\":\"test-file\"}");
        mockResponse.setDocuments(Collections.singletonList(mockDocument));

        FDSCloudHandler fdsCloudHandlerSpy = spy(new FDSCloudHandler());

        doReturn(mockToken).when(fdsCloudHandlerSpy).getFDSCloudToken(sessionId);
        doReturn(mockResponse).when(fdsCloudHandlerSpy).FDSCloudGetRequest(
                eq(sessionId),
                any(FDSCloudRequest.class),
                eq(""),
                eq(Encode.forJava(cid))
        );

        List<OptOutFDSCloudDocument> result = fdsCloudHandlerSpy.getAvailableAutoenrolledForOptOut(tin, mpin, fileName, sessionId, cid);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("test-doc-id", result.get(0).getDocumentId());

        //Throws exception - TEST
        doReturn(null).when(fdsCloudHandlerSpy).FDSCloudGetRequest(
                eq(sessionId),
                any(FDSCloudRequest.class),
                eq(""),
                eq(Encode.forJava(cid))
        );

        result = fdsCloudHandlerSpy.getAvailableAutoenrolledForOptOut(tin, mpin, fileName, sessionId, cid);
        assertNull(result);

    }

    @Test
    public void testFDSCloudPostRequest_success() throws ApplicationException {
        String sessionId = "test-session-id";
        String cid = "test-cid";
        FDSCloudRequest request = new FDSCloudRequest();
        request.setRequest(Map.of("key", "value"));

        OptOutFDSCloudPOSTResponse mockResponseBody = new OptOutFDSCloudPOSTResponse();
        mockResponseBody.setSearchTerms(Collections.singletonList("searchTerms"));
        mockResponseBody.setCreatedOn(123456789L);
        mockResponseBody.setAttachments(Collections.singletonList("attachment"));
        mockResponseBody.setDocumentId("test-document-id");
        ResponseEntity<OptOutFDSCloudPOSTResponse> mockResponse = ResponseEntity.ok(mockResponseBody);

        Token mockToken = new Token();
        mockToken.setAccessToken("mock-access-token");

        FDSCloudHandler fdsCloudHandlerSpy = spy(new FDSCloudHandler());

        doReturn(mockToken).when(fdsCloudHandlerSpy).getFDSCloudToken(sessionId);
        doReturn(mockResponse).when(fdsCloudHandlerSpy).sendRequest(
                any(),
                any(),
                eq(OptOutFDSCloudPOSTResponse.class),
                any(),
                eq(cid)
        );
        ReflectionTestUtils.setField(fdsCloudHandlerSpy, "fdsCloudURL", "http://mock-fdscloud-url/{spaceId}");
        ReflectionTestUtils.setField(fdsCloudHandlerSpy, "fdsCloudSpaceId", "12345");

        ResponseEntity<OptOutFDSCloudPOSTResponse> result = fdsCloudHandlerSpy.FDSCloudPostRequest(sessionId, request, cid);

        assertNotNull(result);
        assertEquals(mockResponseBody, result.getBody());
    }

    @Test
    public void testFDSCloudPostRequest_failure() throws ApplicationException {
        String sessionId = "test-session-id";
        String cid = "test-cid";
        FDSCloudRequest request = new FDSCloudRequest();
        request.setRequest(Map.of("key", "value"));

        OptOutFDSCloudPOSTResponse mockResponseBody = new OptOutFDSCloudPOSTResponse();
        ResponseEntity<OptOutFDSCloudPOSTResponse> mockResponse = ResponseEntity.ok(mockResponseBody);

        Token mockToken = new Token();
        mockToken.setAccessToken("mock-access-token");

        FDSCloudHandler fdsCloudHandlerSpy = spy(new FDSCloudHandler());

        doReturn(mockToken).when(fdsCloudHandlerSpy).getFDSCloudToken(sessionId);
        doReturn(mockResponse).when(fdsCloudHandlerSpy).sendRequest(
                any(),
                any(),
                eq(OptOutFDSCloudPOSTResponse.class),
                any(),
                eq(cid)
        );
        ReflectionTestUtils.setField(fdsCloudHandlerSpy, "fdsCloudURL", "http://mock-fdscloud-url/{spaceId}");
        ReflectionTestUtils.setField(fdsCloudHandlerSpy, "fdsCloudSpaceId", "12345");

        //Exception
        assertThrows(Exception.class, () -> {
            fdsCloudHandlerSpy.FDSCloudPostRequest(sessionId, request, cid);
        });
    }

    @Test
    public void testFDSCloudPutRequest_success() throws ApplicationException {
        String sessionId = "test-session-id";
        String cid = "test-cid";
        FDSCloudRequest request = new FDSCloudRequest();
        request.setDocumentId("12345");
        request.setRequest(Map.of("key", "value"));

        OptOutFDSCloudPOSTResponse mockResponseBody = new OptOutFDSCloudPOSTResponse();
        mockResponseBody.setSearchTerms(Collections.singletonList("searchTerms"));
        mockResponseBody.setCreatedOn(123456789L);
        mockResponseBody.setAttachments(Collections.singletonList("attachment"));
        mockResponseBody.setDocumentId("test-document-id");
        ResponseEntity<OptOutFDSCloudPOSTResponse> mockResponse = ResponseEntity.ok(mockResponseBody);

        Token mockToken = new Token();
        mockToken.setAccessToken("mock-access-token");

        FDSCloudHandler fdsCloudHandlerSpy = spy(new FDSCloudHandler());

        doReturn(mockToken).when(fdsCloudHandlerSpy).getFDSCloudToken(sessionId);
        doReturn(mockResponse).when(fdsCloudHandlerSpy).sendRequest(
                any(),
                any(),
                eq(OptOutFDSCloudPOSTResponse.class),
                any(),
                eq(cid)
        );
        ReflectionTestUtils.setField(fdsCloudHandlerSpy, "fdsCloudURL", "http://mock-fdscloud-url/{spaceId}");
        ReflectionTestUtils.setField(fdsCloudHandlerSpy, "fdsCloudSpaceId", "12345");

        ResponseEntity<OptOutFDSCloudPOSTResponse> result = fdsCloudHandlerSpy.FDSCloudPutRequest(sessionId, request, cid);

        assertNotNull(result);
        assertEquals(mockResponseBody, result.getBody());
    }


    @Test
    public void testEncodeToUTF_validString() {
        String input = "test string";
        String expected = "test+string";

        // Act
        String result = fdsCloudHandler.encodeToUTF(input);

        // Assert
        assertEquals(expected, result);
    }

    @Test
    public void testEncodeToUTF_emptyString() {
        String input = "";
        String expected = "";

        // Act
        String result = fdsCloudHandler.encodeToUTF(input);

        // Assert
        assertEquals(expected, result);
    }



//    @Test
//    void testGetFDSCloudToken_success() throws Exception {
////        String sessionId = "test-session-id";
//        Token mockToken = new Token();
//        mockToken.setAccessToken("mock-access-token");
//
//        doReturn(mockToken).when(oauth2handler).getOauthToken(any(), "FDSCLOUD");
//
//        Token result = fdsCloudHandler.getFDSCloudToken(sessionId);
//
//        assertNotNull(result);
//        assertEquals("mock-access-token", result.getAccessToken());
//        verify(oauth2handler, times(1)).getOauthToken(sessionId, "FDSCLOUD");
//    }
//
//    @Test
//    void testGetFDSCloudToken_failure() throws Exception {
////        String sessionId = "test-session-id";
//
//        doThrow(new IOException("Simulated IOException"))
//                .when(oauth2handler).getOauthToken(sessionId, "FDSCLOUD");
//
//        // Act & Assert
//        ApplicationException exception = assertThrows(ApplicationException.class, () -> {
//            fdsCloudHandler.getFDSCloudToken(sessionId);
//        });
//
//        assertTrue(exception.getMessage().contains("Failed to make FDS OAUTH service call"));
//        verify(oauth2handler, times(1)).getOauthToken(sessionId, "FDSCLOUD");
//    }
//
//    @Test
//    void testGetFDSCloudToken_nullToken() throws Exception {
////        String sessionId = "test-session-id";
//        Token mockToken = new Token(); // No access token set
//
//        doReturn(mockToken).when(oauth2handler).getOauthToken(sessionId, "FDSCLOUD");
//
//        // Act & Assert
//        assertThrows(NullPointerException.class, () -> {
//            fdsCloudHandler.getFDSCloudToken(sessionId);
//        });
//
//        verify(oauth2handler, times(1)).getOauthToken(sessionId, "FDSCLOUD");
//    }
}