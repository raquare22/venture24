package com.optum.providerpreferences.rs.handler;

import org.apache.http.ssl.SSLContexts;
import org.junit.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

public class RequestFactoryTest {

    @Test
    public void testRestTemplate_Success() {
        RequestFactory requestFactory = new RequestFactory();

        RestTemplate restTemplate = requestFactory.restTemplate();

        assertNotNull(restTemplate);
    }

    @Test
    public void testRestTemplate_NoSuchAlgorithmException() {
        try (MockedStatic<SSLContext> mockedSSLContext = Mockito.mockStatic(SSLContext.class)) {
            mockedSSLContext.when(() -> SSLContext.getInstance(anyString()))
                    .thenThrow(new NoSuchAlgorithmException());
            RequestFactory requestFactory = new RequestFactory();
            try{
                RestTemplate restTemplate = requestFactory.restTemplate();
                assertNotNull(restTemplate);
            } catch (Exception e) {
                System.out.println("Expected exception: sslContext is null");
            }

        }
    }

//    @Test
//    void testRestTemplate_KeyManagementException() {
//        try (MockedStatic<SSLContext> mockedSSLContext = Mockito.mockStatic(SSLContext.class)) {
//            mockedSSLContext.when(() -> SSLContext.getInstance(anyString()))
//                    .thenThrow(new KeyManagementException());
//            RequestFactory requestFactory = new RequestFactory();
//            try{
//                RestTemplate restTemplate = requestFactory.restTemplate();
//                assertNotNull(restTemplate);
//            } catch (Exception e) {
//                System.out.println("Expected exception: sslContext is null");
//            }
//
//        }
//    }
//
//    @Test
//    void testRestTemplate_KeyStoreException() {
//        try (MockedStatic<SSLContext> mockedSSLContext = Mockito.mockStatic(SSLContext.class)) {
//            mockedSSLContext.when(() -> SSLContext.getInstance(anyString()))
//                    .thenThrow(new KeyStoreException());
//            RequestFactory requestFactory = new RequestFactory();
//            try{
//                RestTemplate restTemplate = requestFactory.restTemplate();
//                assertNotNull(restTemplate);
//            } catch (Exception e) {
//                System.out.println("Expected exception: sslContext is null");
//            }
//
//        }
//    }
//
//    @Test
//    void testRestTemplate_SSLContextsCustomThrowsException() {
//        try (MockedStatic<SSLContexts> mockedSSLContexts = Mockito.mockStatic(SSLContexts.class)) {
//            mockedSSLContexts.when(SSLContexts::custom).thenThrow(new NoSuchAlgorithmException("Mocked exception"));
//
//            RequestFactory requestFactory = new RequestFactory();
//
//            RestTemplate restTemplate = requestFactory.restTemplate();
//            assertNotNull(restTemplate, "RestTemplate should not be null even if SSLContexts.custom() fails");
//        }
//    }

}