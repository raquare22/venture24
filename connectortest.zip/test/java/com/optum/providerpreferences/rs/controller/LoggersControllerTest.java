package com.optum.providerpreferences.rs.controller;

import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.optum.providerpreferences.rs.model.GenericResponse;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

public class LoggersControllerTest {

//    private MockMvc mockMvc;

    @InjectMocks
    private LoggersController loggersController;

    @Before
    public void setUp() {
        loggersController = new LoggersController();
//        mockMvc = MockMvcBuilders.standaloneSetup(loggersController).build();
    }

    @Test
    public void testHealthCheck() throws Exception {

        GenericResponse response = loggersController.healthCheck();


        assertTrue(response.getStatusCode().equals("200"));
//        mockMvc.perform(get("/api/loggers/v1/healthcheck"))
//                .andExpect(status().isOk())
//                .andExpect(content().string("{\"statusCode\":\"200\",\"statusMessage\":\"OK\"}"));
    }
}