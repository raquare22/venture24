package com.optum.providerpreferences.rs.controller;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.GenericResponse;
import com.optum.providerpreferences.rs.model.PaymentPreference;
import com.optum.providerpreferences.rs.service.PaymentPreferenceService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class PaymentPreferenceControllerTest {

    @Mock
    private PaymentPreferenceService paymentPreferenceService;

    @InjectMocks
    private PaymentPreferenceController controller;

    private HttpHeaders headers;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);

        // @InjectMocks does not trigger @Value injection/@PostConstruct, so seed config explicitly for unit tests.
        ReflectionTestUtils.setField(controller, "tpsPaymentCapacity", 60L);
        ReflectionTestUtils.setField(controller, "tpsPaymentRefillTokens", 60L);
        ReflectionTestUtils.setField(controller, "paymentPrefMinCapacity", 1L);
        ReflectionTestUtils.setField(controller, "paymentPrefMaxCapacity", 60L);
        ReflectionTestUtils.setField(controller, "paymentPrefMinRefillTokens", 1L);
        ReflectionTestUtils.setField(controller, "paymentPrefMaxRefillTokens", 60L);
        controller.initRateLimitBuckets();

        headers = new HttpHeaders();
        headers.add("uuid", "test-uuid");
        headers.add("optum-cid-ext", "test-cid");
    }

    @Test
    public void testGetPaymentPreference_Success_ExistingDoc() throws Exception {
        PaymentPreference pref = new PaymentPreference();
        pref.setTin("TIN");
        pref.setMpin("MPIN");
        when(paymentPreferenceService.getPaymentPreferenceByTinAndMpin("TIN", "MPIN")).thenReturn(pref);

        ResponseEntity<PaymentPreference> response = controller.getPaymentPreference(pref, headers, new MockHttpServletRequest(), "test-cid");
        assertEquals(200, response.getStatusCode().value());
        assertEquals(pref, response.getBody());
    }

    @Test
    public void testGetPaymentPreference_Success_NewDoc() throws Exception {
        PaymentPreference pref = new PaymentPreference();
        pref.setTin("TIN");
        pref.setMpin("MPIN");
        when(paymentPreferenceService.getPaymentPreferenceByTinAndMpin("TIN", "MPIN")).thenReturn(null);
        when(paymentPreferenceService.insertPaymentPreference(any(PaymentPreference.class))).thenReturn(pref);

        ResponseEntity<PaymentPreference> response = controller.getPaymentPreference(pref, headers, new MockHttpServletRequest(), "test-cid");
        assertEquals(200, response.getStatusCode().value());
        assertNotNull(response.getBody());
        assertEquals("TIN", response.getBody().getTin());
        assertEquals("MPIN", response.getBody().getMpin());
        assertEquals("VCP", response.getBody().getPaymentPref());
    }

    @Test
    public void testGetPaymentPreference_MissingTinOrMpin() throws Exception {
        PaymentPreference pref = new PaymentPreference();
        pref.setTin("");
        pref.setMpin("MPIN");
        ResponseEntity<PaymentPreference> response = controller.getPaymentPreference(pref, headers, new MockHttpServletRequest(), "test-cid");
        assertEquals(400, response.getStatusCode().value());

        pref.setTin("TIN");
        pref.setMpin("");
        response = controller.getPaymentPreference(pref, headers, new MockHttpServletRequest(), "test-cid");
        assertEquals(400, response.getStatusCode().value());
    }

    @Test
    public void testGetPaymentPreference_IllegalArgumentException() throws Exception {
        PaymentPreference pref = new PaymentPreference();
        pref.setTin("TIN");
        pref.setMpin("MPIN");
        when(paymentPreferenceService.getPaymentPreferenceByTinAndMpin(anyString(), anyString()))
                .thenThrow(new IllegalArgumentException("bad arg"));

        ResponseEntity<PaymentPreference> response = controller.getPaymentPreference(pref, headers, new MockHttpServletRequest(), "test-cid");
        assertEquals(400, response.getStatusCode().value());
    }

    @Test
    public void testGetPaymentPreference_ApplicationException() {
        PaymentPreference pref = new PaymentPreference();
        pref.setTin("TIN");
        pref.setMpin("MPIN");
        when(paymentPreferenceService.getPaymentPreferenceByTinAndMpin(anyString(), anyString()))
                .thenThrow(new RuntimeException("db error"));

        try {
            controller.getPaymentPreference(pref, headers, new MockHttpServletRequest(), "test-cid");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            // expected
        }
    }

    @Test
    public void testGetPaymentPreference_TooManyRequests() throws Exception {
        for (int i = 0; i < 61; i++) {
            controller.getPaymentPreference(new PaymentPreference() {{
                setTin("TIN");
                setMpin("MPIN");
            }}, headers, new MockHttpServletRequest(), "test-cid");
        }
        ResponseEntity<PaymentPreference> response = controller.getPaymentPreference(
                new PaymentPreference() {{
                    setTin("TIN");
                    setMpin("MPIN");
                }}, headers, new MockHttpServletRequest(), "test-cid");
        assertEquals(429, response.getStatusCode().value());
    }

    @Test
    public void testUpdatePaymentPreference_Success() {
        PaymentPreference pref = new PaymentPreference();
        pref.setTin("TIN");
        pref.setMpin("MPIN");
        pref.setPaymentpref("VCP");
        pref.setUpdatedBy("user");
        pref.setUpdatedByName("username");

        when(paymentPreferenceService.updatePaymentPreference(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(pref);

        ResponseEntity<GenericResponse> response = controller.updatePaymentPreference(pref, headers);
        assertEquals(200, response.getStatusCode().value());
        assertEquals("200", response.getBody().getStatusCode());
    }

    @Test
    public void testUpdatePaymentPreference_MissingFields() {
        PaymentPreference pref = new PaymentPreference();
        pref.setTin("");
        pref.setMpin("MPIN");
        pref.setPaymentpref("EFT");
        pref.setUpdatedBy("user");

        ResponseEntity<GenericResponse> response = controller.updatePaymentPreference(pref, headers);
        assertEquals(400, response.getStatusCode().value());

        pref.setTin("TIN");
        pref.setMpin("");
        response = controller.updatePaymentPreference(pref, headers);
        assertEquals(400, response.getStatusCode().value());

        pref.setMpin("MPIN");
        pref.setPaymentpref("");
        response = controller.updatePaymentPreference(pref, headers);
        assertEquals(400, response.getStatusCode().value());

        pref.setPaymentpref("EFT");
        pref.setUpdatedBy("");
        response = controller.updatePaymentPreference(pref, headers);
        assertEquals(400, response.getStatusCode().value());
    }

    @Test
    public void testUpdatePaymentPreference_Exception() {
        PaymentPreference pref = new PaymentPreference();
        pref.setTin("TIN");
        pref.setMpin("MPIN");
        pref.setPaymentpref("EFT");
        pref.setUpdatedBy("user");
        pref.setUpdatedByName("username");

        when(paymentPreferenceService.updatePaymentPreference(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenThrow(new RuntimeException("db error"));

        ResponseEntity<GenericResponse> response = controller.updatePaymentPreference(pref, headers);
        assertEquals(500, response.getStatusCode().value());
    }

    @Test
    public void testUpdatePaymentPreference_TooManyRequests() {
        PaymentPreference pref = new PaymentPreference();
        pref.setTin("TIN");
        pref.setMpin("MPIN");
        pref.setPaymentpref("EFT");
        pref.setUpdatedBy("user");
        pref.setUpdatedByName("username");

        for (int i = 0; i < 61; i++) {
            controller.updatePaymentPreference(pref, headers);
        }
        ResponseEntity<GenericResponse> response = controller.updatePaymentPreference(pref, headers);
        assertEquals(429, response.getStatusCode().value());
    }
    
	@Test(expected = ApplicationException.class)
	public void testGetPaymentPreference_ExceptionFlow() throws Exception {

		PaymentPreference pref = new PaymentPreference();
		pref.setTin("TIN");
		pref.setMpin("MPIN");

		when(paymentPreferenceService.getPaymentPreferenceByTinAndMpin(anyString(), anyString()))
				.thenThrow(new RuntimeException("error"));

		controller.getPaymentPreference(pref, headers, new MockHttpServletRequest(), "test-cid");
	}
	
	@Test
	public void testGetPaymentPreference_RateLimitImmediate() throws Exception {

		PaymentPreference pref = new PaymentPreference();
		pref.setTin("TIN");
		pref.setMpin("MPIN");

		// exhaust quickly
		for (int i = 0; i < 61; i++) {
			controller.getPaymentPreference(pref, headers, new MockHttpServletRequest(), "test-cid");
		}

		ResponseEntity<PaymentPreference> response = controller.getPaymentPreference(pref, headers,
				new MockHttpServletRequest(), "test-cid");

		assertEquals(HttpStatus.TOO_MANY_REQUESTS, response.getStatusCode());
	}
	
	@Test
	public void testUpdatePaymentPreference_Success_ResponseBody() {

		PaymentPreference pref = new PaymentPreference();
		pref.setTin("TIN");
		pref.setMpin("MPIN");
		pref.setPaymentpref("EFT");
		pref.setUpdatedBy("user");
		pref.setUpdatedByName("name");

		when(paymentPreferenceService.updatePaymentPreference(anyString(), anyString(), anyString(), anyString(),
				anyString())).thenReturn(pref);

		ResponseEntity<GenericResponse> response = controller.updatePaymentPreference(pref, headers);

		assertEquals("200", response.getBody().getStatusCode());
		assertEquals("Payment Preference updated successfully", response.getBody().getStatusMessage());
		
	}

}
