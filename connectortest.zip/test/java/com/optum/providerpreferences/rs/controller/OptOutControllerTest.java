package com.optum.providerpreferences.rs.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.kafka.KafkaProducer;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.GenericResponse;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinResponse;
import com.optum.providerpreferences.rs.service.AsyncComponent;
import com.optum.providerpreferences.rs.service.OptOutService;
import com.optum.providerpreferences.rs.service.ProviderPreferencesService;
import com.optum.providerpreferences.rs.utility.ProviderPreferencesUtil;
import io.github.bucket4j.Bucket;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.Collections;

public class OptOutControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ProviderPreferencesUtil provPrefUtil;

    @Mock
    private OptOutService optOutService;

    @Mock
    private ProviderPreferencesService providerPreferencesService;

    @Mock
    private AsyncComponent asyncComponent;

    @Mock
    private ObjectMapper mapper;

    @Mock
    private Bucket bucket1;

    @Mock
    private Bucket bucket2;

    @InjectMocks
    private OptOutController optOutController;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(optOutController).build();
    }

//    @Test
    public void testGetTinsByCorpMpin_Success() throws Exception {
        OptOutTinRequest tinRequest = new OptOutTinRequest();
        tinRequest.setCorporateMpin("12345");

        OptOutTinResponse tinResponse = new OptOutTinResponse(Collections.emptyList());
        when(bucket1.tryConsume(1)).thenReturn(true);
        when(optOutService.getTins(any(OptOutTinRequest.class), anyString())).thenReturn(tinResponse);

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

//        ResponseEntity<OptOutTinResponse> response = optOutController.getTinsByCorpMpin(tinRequest, headers);

        try (MockedStatic<KafkaProducer> kafkaProducerMockedStatic = mockStatic(KafkaProducer.class)) {
            kafkaProducerMockedStatic.when(KafkaProducer::getSetUp).thenReturn(false);

            // Execute test
            ResponseEntity<OptOutTinResponse> response = optOutController.getTinsByCorpMpin(tinRequest, headers);

            assertNotNull(response);
//            verify(digitalSecService, never()).getCorporatesByPasswordOwner(anyString(), any(), any());
        }

//        assertNotNull(response);
//        mockMvc.perform(post("/api/providers/v1/optout/tins")
//                        .contentType(MediaType.APPLICATION_JSON)
//                        .content(new ObjectMapper().writeValueAsString(tinRequest))
//                        .headers(headers))
//                .andExpect(status().isOk());
    }

    @Test
    public void testUpdateMultiDocuments_InvalidCategory() throws Exception {
        OptOutRequest optOutRequest = new OptOutRequest();
        optOutRequest.setCategories(Collections.singletonList("invalid-category"));

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        when(bucket2.tryConsume(1)).thenReturn(true);

        mockMvc.perform(post("/api/providers/v1/optout/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(optOutRequest))
                        .headers(headers))
                .andExpect(status().isBadRequest());
    }

//    @Test
    public void testUpdateMultiDocuments_InternalServerError() throws Exception {
        OptOutRequest optOutRequest = new OptOutRequest();
        optOutRequest.setCategories(Collections.singletonList("claims"));

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        when(bucket2.tryConsume(1)).thenReturn(false);

        mockMvc.perform(post("/api/providers/v1/optout/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(optOutRequest))
                        .headers(headers))
                .andExpect(status().isInternalServerError());
    }
}
