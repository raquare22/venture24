package com.optum.providerpreferences.rs.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

public class RootControllerTest {

//    private MockMvc mockMvc;

    @InjectMocks
    RootController rootController;

    @Before
    public void setUp() {
        rootController = new RootController();
//        mockMvc = MockMvcBuilders.standaloneSetup(rootController).build();
    }

    @Test
    public void testHealthCheck() throws Exception {
        String response = rootController.healthCheck();
        assertEquals("paperless-letters-connector is up and running", response);
//        mockMvc.perform(get("/"))
//                .andExpect(status().isOk())
//                .andExpect(content().string("paperless-letters-connector is up and running"));
    }
}