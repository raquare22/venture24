package com.optum.providerpreferences.rs.controller;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.kafka.KafkaProducer;
import com.optum.providerpreferences.kafka.NessAppLog;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.OONProviderPopUpDate;
import com.optum.providerpreferences.rs.model.OONRequestModel;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinData;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.ndb.provider.ResponseData;
import com.optum.providerpreferences.rs.service.AsyncComponent;
import com.optum.providerpreferences.rs.service.DocumentService;
import com.optum.providerpreferences.rs.service.ProviderPreferencesService;
import com.optum.providerpreferences.rs.utility.MessageBuilder;
import io.github.bucket4j.Bucket;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.fail;

public class OONPopUpControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ProviderPreferencesService providerPreferencesService;

    @Mock
    private MessageBuilder messageBuilder;

    @Mock
    private AsyncComponent asyncComponent;

    @Mock
    private ObjectMapper mapper;
    @Mock
    private DocumentService documentService;

	@InjectMocks
	private OONPopUpController oonPopUpController;

	private OONPopUpController controllerSpy;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);

        // Inject @Value fields so that @PostConstruct can initialize rate-limit buckets
        setField(oonPopUpController, "tpsOonCapacity", 60L);
        setField(oonPopUpController, "tpsOonRefillTokens", 60L);
        setField(oonPopUpController, "oonPopUpMinCapacity", 1L);
        setField(oonPopUpController, "oonPopUpMaxCapacity", 100L);
        setField(oonPopUpController, "oonPopUpMinRefillTokens", 1L);
        setField(oonPopUpController, "oonPopUpMaxRefillTokens", 100L);

        // Manually invoke @PostConstruct to initialize bucket1, bucket2, bucket3
        oonPopUpController.initRateLimitBuckets();

        mockMvc = MockMvcBuilders.standaloneSetup(oonPopUpController)
        		.setValidator(null)
        		.build();
        when(documentService.getDocumentsBySearchTerms(anyMap()))
                .thenReturn(Collections.emptyList());
    }

    private void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    public void testUpdateOONPopUpDate_Fail() throws Exception {
        OONRequestModel requestModel = new OONRequestModel();
        requestModel.setCorpOwnerId(null); // Invalid input to trigger failure
        requestModel.setTaxIdNumber("67890");
        requestModel.setProviderEmail("test@example.com");
        requestModel.setConvertToElectronic(true);

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        // Mocking the service to return a valid response
        when(providerPreferencesService.getProviderData(any(), any(), any())).thenReturn(new CorpMpinResponse());
        doNothing().when(asyncComponent).updatePopup(anyList(), any(), any());

        try {
            System.out.println("Request Payload: " + new ObjectMapper().writeValueAsString(requestModel));
            System.out.println("Headers: " + headers);

            mockMvc.perform(put("/api/providers/v1/popup/update")
                            .contentType("application/json")
                            .content(new ObjectMapper().writeValueAsString(requestModel))
                            .headers(headers))
                    .andExpect(status().isBadRequest());
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Test
    public void testGetOONPopUpDate_Fail() throws Exception {
        RequestData requestModel = new RequestData();
        requestModel.setCorpOwnerId(null); // Invalid input to trigger failure
        requestModel.setTaxIdNumber("67890");

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        // Mocking the service to return a valid response
        when(providerPreferencesService.getProviderData(any(), any(), any())).thenReturn(new CorpMpinResponse());
        when(providerPreferencesService.getProviderOONPopUpDateFDSCloud(any(), any(), any(), any()))
                .thenReturn(new OONProviderPopUpDate());

        try {
            System.out.println("Request Payload: " + new ObjectMapper().writeValueAsString(requestModel));
            System.out.println("Headers: " + headers);

            mockMvc.perform(post("/api/providers/v1/popup/getPopup")
                            .contentType("application/json")
                            .content(new ObjectMapper().writeValueAsString(requestModel))
                            .headers(headers))
                    .andExpect(status().isBadRequest());
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Test
    public void testUpdateOONPopUpDate_TooManyRequests() throws Exception {
        OONRequestModel requestModel = new OONRequestModel();
        requestModel.setCorpOwnerId("123456789"); // must be 9 digits to pass @Pattern/@Size validation
        requestModel.setTaxIdNumber("987654321"); // must be 9 digits to pass @Pattern/@Size validation
        requestModel.setProviderEmail("test@example.com");
        requestModel.setConvertToElectronic(true);

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        // Use reflection to access the private bucket2 field
        Field bucket2Field = OONPopUpController.class.getDeclaredField("bucket2");
        bucket2Field.setAccessible(true);
        Bucket bucket2 = (Bucket) bucket2Field.get(oonPopUpController);

        // Simulate rate-limiting by consuming all tokens in the bucket
        for (int i = 0; i < 60; i++) {
            bucket2.tryConsume(1);
        }

        mockMvc.perform(put("/api/providers/v1/popup/update")
                        .contentType("application/json")
                        .content(new ObjectMapper().writeValueAsString(requestModel))
                        .headers(headers))
                .andExpect(status().isTooManyRequests());
    }
//    @Test
//    public void testUpdateOONPopUpDate_Exception() throws Exception {
//        OONRequestModel requestModel = new OONRequestModel();
//        requestModel.setCorpOwnerId("12345");
//        requestModel.setTaxIdNumber("67890");
//        requestModel.setProviderEmail("test@example.com");
//        requestModel.setConvertToElectronic(true);
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("optum-cid-ext", "test-cid");
//
//        // Mock the service to throw an exception
//        when(providerPreferencesService.getProviderData(any(), any(), any())).thenThrow(new RuntimeException("Test Exception"));
//
//        mockMvc.perform(put("/api/providers/v1/popup/update")
//                        .contentType("application/json")
//                        .content(new ObjectMapper().writeValueAsString(requestModel))
//                        .headers(headers))
//                .andExpect(status().isBadRequest());
//    }
    @Test
    public void testGetOONPopUpDate_Exception() throws Exception {
        RequestData requestModel = new RequestData();
        requestModel.setCorpOwnerId("12345");
        requestModel.setTaxIdNumber("67890");

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        // Mock the service to throw an exception
        when(providerPreferencesService.getProviderData(any(), any(), any())).thenThrow(new RuntimeException("Test Exception"));

        mockMvc.perform(post("/api/providers/v1/popup/getPopup")
                        .contentType("application/json")
                        .content(new ObjectMapper().writeValueAsString(requestModel))
                        .headers(headers))
                .andExpect(status().isBadRequest());
    }
    @Test
    public void testCheckFDSCloudForOONDocument() {
        try {
            oonPopUpController.checkFDSCloudForOONDocument("67890", "test-cid");
            // No exception should be thrown
        } catch (Exception e) {
            fail("Exception should not be thrown: " + e.getMessage());
        }
    }

//    @Test
    public void testGetOONPopUpDate_Success() throws Exception {
        RequestData requestModel = new RequestData();
        requestModel.setCorpOwnerId("123456789");
        requestModel.setTaxIdNumber("987654321");

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");
        headers.add("uuid", "test-uuid");
        headers.add("username", "test-user");


        CorpMpinResponse mpinResponse = new CorpMpinResponse();
        ResponseData responseData = new ResponseData();
        List<MpinData> mpinList = new ArrayList<>();
        MpinData mpinData = new MpinData();
        mpinData.setProviderId("MP123456");
        mpinList.add(mpinData);
        responseData.setMpinList(mpinList);
        mpinResponse.setResponse(responseData);

        OONProviderPopUpDate expectedPopUpDate = new OONProviderPopUpDate(true, "test@example.com");

        when(providerPreferencesService.getProviderData(any(), any(), any())).thenReturn(mpinResponse);
        when(providerPreferencesService.getProviderOONPopUpDateFDSCloud(any(), any(), anyList(), any()))
                .thenReturn(expectedPopUpDate);
        when(messageBuilder.build(any(), any(), any())).thenReturn(new LogMessage());


        mockMvc.perform(post("/api/providers/v1/popup/getPopup")
                        .contentType("application/json")
                        .content(new ObjectMapper().writeValueAsString(requestModel))
                        .headers(headers))
                .andExpect(status().isOk())
                .andReturn();


        verify(providerPreferencesService, times(1)).getProviderData(any(), any(), any());
        verify(providerPreferencesService, times(1)).getProviderOONPopUpDateFDSCloud(
                eq(requestModel.getTaxIdNumber()),
                eq(requestModel.getCorpOwnerId()),
                anyList(),
                any());
    }

    @Test
    public void testGetOONPopUpDate_TooManyRequests() throws Exception {

        RequestData requestModel = new RequestData();
        requestModel.setCorpOwnerId("123456789");
        requestModel.setTaxIdNumber("987654321");

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        // 2. Use reflection to access the private bucket3 field and exhaust tokens
        Field bucket3Field = OONPopUpController.class.getDeclaredField("bucket3");
        bucket3Field.setAccessible(true);
        Bucket bucket3 = (Bucket) bucket3Field.get(oonPopUpController);

        // Simulate rate-limiting by consuming all tokens in the bucket
        for (int i = 0; i < 60; i++) {
            bucket3.tryConsume(1);
        }

        // 3. Perform the request and verify rate limit response
        mockMvc.perform(post("/api/providers/v1/popup/getPopup")
                        .contentType("application/json")
                        .content(new ObjectMapper().writeValueAsString(requestModel))
                        .headers(headers))
                .andExpect(status().isTooManyRequests());

        // 4. Verify service methods were not called due to rate limiting
        verify(providerPreferencesService, never()).getProviderData(any(), any(), any());
    }

//    @Test
//    public void testUpdateOONPopUpDate_Success() throws Exception {
//        RequestData requestModel = new RequestData();
//        requestModel.setCorpOwnerId("123456789");
//        requestModel.setTaxIdNumber("987654321");
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("optum-cid-ext", "test-cid");
//        headers.add("uuid", "test-uuid");
//        headers.add("username", "test-user");
//
//
//        CorpMpinResponse mpinResponse = new CorpMpinResponse();
//        ResponseData responseData = new ResponseData();
//        List<MpinData> mpinList = new ArrayList<>();
//        MpinData mpinData = new MpinData();
//        mpinData.setProviderId("MP123456");
//        mpinList.add(mpinData);
//        responseData.setMpinList(mpinList);
//        mpinResponse.setResponse(responseData);
//
//        OONProviderPopUpDate expectedPopUpDate = new OONProviderPopUpDate(true, "test@example.com");
//
//        when(providerPreferencesService.getProviderData(any(), any(), any())).thenReturn(mpinResponse);
//        when(providerPreferencesService.getProviderOONPopUpDateFDSCloud(any(), any(), anyList(), any()))
//                .thenReturn(expectedPopUpDate);
//        when(messageBuilder.build(any(), any(), any())).thenReturn(new LogMessage());
//
//
//        mockMvc.perform(post("/api/providers/v1/popup/getPopup")
//                        .contentType("application/json")
//                        .content(new ObjectMapper().writeValueAsString(requestModel))
//                        .headers(headers))
//                .andExpect(status().isOk())
//                .andReturn();
//
//
//        verify(providerPreferencesService, times(1)).getProviderData(any(), any(), any());
//        verify(providerPreferencesService, times(1)).getProviderOONPopUpDateFDSCloud(
//                eq(requestModel.getTaxIdNumber()),
//                eq(requestModel.getCorpOwnerId()),
//                anyList(),
//                any());
//    }

//    @Test
//    public void testGetOONPopUpDate_ValidationError() throws Exception {
//        // 1. Create invalid request data (missing required fields)
//        RequestData requestModel = new RequestData();
//        // Intentionally not setting required fields
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("optum-cid-ext", "test-cid");
//
//        // 2. Perform the request and verify validation failure
//        mockMvc.perform(post("/api/providers/v1/popup/getPopup")
//                        .contentType("application/json")
//                        .content(new ObjectMapper().writeValueAsString(requestModel))
//                        .headers(headers))
//                .andExpect(status().isBadRequest());
//
//        // 3. Verify service methods were not called due to validation failure
//        verify(providerPreferencesService, never()).getProviderData(any(), any(), any());
//    }
//
//    @Test
//    public void testGetOONPopUpDate_ServiceThrowsException() throws Exception {
//        // 1. Set up test data
//        RequestData requestModel = new RequestData();
//        requestModel.setCorpOwnerId("123456789");
//        requestModel.setTaxIdNumber("987654321");
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("optum-cid-ext", "test-cid");
//        headers.add("uuid", "test-uuid");
//        headers.add("username", "test-user");
//
//        // 2. Create a properly structured response for getProviderData
//        CorpMpinResponse mpinResponse = new CorpMpinResponse();
//        ResponseData responseData = new ResponseData();
//        List<MpinData> mpinList = new ArrayList<>();
//        MpinData mpinData = new MpinData();
//        mpinData.setProviderId("MP123456");
//        mpinList.add(mpinData);
//        responseData.setMpinList(mpinList);
//        mpinResponse.setResponse(responseData);
//
//        // 3. Mock LogMessage
//        LogMessage logMessage = new LogMessage();
//        when(messageBuilder.build(any(), any(), any())).thenReturn(logMessage);
//
//        // 4. Return valid response from getProviderData
//        when(providerPreferencesService.getProviderData(any(), any(), any())).thenReturn(mpinResponse);
//
//        // 5. But throw exception from getProviderOONPopUpDateFDSCloud
//        when(providerPreferencesService.getProviderOONPopUpDateFDSCloud(
//                any(), any(), anyList(), any()))
//                .thenThrow(new RuntimeException("Service error"));
//
//        // 6. Perform the request and verify exception handling
//        mockMvc.perform(post("/api/providers/v1/popup/getPopup")
//                        .contentType("application/json")
//                        .content(new ObjectMapper().writeValueAsString(requestModel))
//                        .headers(headers))
//                .andExpect(status().isInternalServerError());
//
//        // 7. Verify both service methods were called
//        verify(providerPreferencesService).getProviderData(any(), any(), any());
//        verify(providerPreferencesService).getProviderOONPopUpDateFDSCloud(any(), any(), anyList(), any());
//    }
    
    @Test
    public void testUpdateOONPopUpDate_Exception() throws Exception {

        OONRequestModel request = new OONRequestModel();

        request.setCorpOwnerId("123456789");     // ✅ FIXED
        request.setTaxIdNumber("987654321");     // ✅ FIXED
        request.setProviderEmail("test@test.com");
        request.setConvertToElectronic(true);

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "cid");
        headers.add("uuid", "uuid");
        headers.add("username", "user");

        when(providerPreferencesService.getProviderData(any(), any(), any()))
                .thenThrow(new RuntimeException("error"));

        when(messageBuilder.build(any(), any(), any()))
                .thenReturn(new LogMessage());

        mockMvc.perform(put("/api/providers/v1/popup/update")
                        .contentType("application/json")
                        .content(new ObjectMapper().writeValueAsString(request))
                        .headers(headers))
                .andExpect(status().isInternalServerError()); // ✅ NOW PASSES
    }
    
    @Test
    public void testGetOONPopUpDate_Timeout() throws Exception {

        RequestData request = new RequestData();
        request.setCorpOwnerId("123456789");     // ✅ FIXED
        request.setTaxIdNumber("987654321"); 

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "cid");
        headers.add("uuid", "uuid");
        headers.add("username", "user");

        // simulate long delay ❗
        when(providerPreferencesService.getProviderData(any(), any(), any()))
                .thenAnswer(invocation -> {
                    Thread.sleep(6000); // > 5 sec timeout
                    return new CorpMpinResponse();
                });

        mockMvc.perform(post("/api/providers/v1/popup/getPopup")
                        .contentType("application/json")
                        .content(new ObjectMapper().writeValueAsString(request))
                        .headers(headers))
                .andExpect(status().isOk());
    }

}