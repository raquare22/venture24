package com.optum.providerpreferences.rs.service;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.util.Collections;

import com.optum.digitalsecurity.model.request.User;
import com.optum.digitalsecurity.model.response.*;
import com.optum.providerpreferences.rs.handler.Oauth2Handler;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import org.springframework.web.util.UriComponentsBuilder;

public class DigitalSecurityServiceImplTest {

    DigitalSecurityServiceImpl digitalSecurityService;

    @Mock
    private Oauth2Handler oauth2handler;

    @Mock
    private ResponseEntity<ProviderProfile> responseEntity;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        digitalSecurityService = spy(new DigitalSecurityServiceImpl());
        digitalSecurityService.DigiSec_User_URL = "http://mock-url";
        digitalSecurityService.DigiSec_UserOrg_URL = "http://mock-url";
        digitalSecurityService.DigiSec_PAA_URL = "http://mock-url";
    }

//    @Test
//    public void testGetCorporatesByPasswordOwner_Success() throws Exception {
//        String optumUUID = "test-uuid";
//        String cid = "test-cid";
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("optum-cid-ext", cid);
//        LogMessage logMessage = new LogMessage();
//
//        // Create mock responses
//        ProviderProfile mockProfile = new ProviderProfile();
//        ProviderOrg mockOrg = new ProviderOrg();
//        mockOrg.setPaa(true);
//        mockOrg.setFirstName("John");
//        mockOrg.setLastName("Doe");
//        mockOrg.setUhcProviderId("12345");
//        mockOrg.setCorpMpin("67890");
//        mockOrg.setId("prov-id");
//        mockProfile.setProviderOrg(Collections.singletonList(mockOrg));
//
//        Token mockToken = new Token();
//        mockToken.setAccessToken("mock-access-token");
//        ResponseEntity<ProviderProfile> resp = new ResponseEntity<>(mockProfile, HttpStatus.OK);
//
//        doReturn(mockToken).when(digitalSecurityService).getDigiSecToken(any(), any());
//
//        doReturn(resp).when(digitalSecurityService).sendRequest(
//                anyString(),
//                any(HttpEntity.class),
//                eq(ProviderProfile.class),
//                eq(HttpMethod.POST),
//                anyString()
//        );
//
//        PDOCorporates result = digitalSecurityService.getCorporatesByPasswordOwner(optumUUID, headers, logMessage);
//
//        assertNotNull("Result should not be null", result);
//        assertEquals("UUID should match", optumUUID, result.getOptumUUID());
//        assertEquals("Should have 1 corporate", 1, result.getCorporates().size());
//
//        Corporate corporate = result.getCorporates().get(0);
//        assertEquals("Name should match", "John Doe", corporate.getCorporateName());
//        assertEquals("UHC ID should match", "12345", corporate.getUhcID());
//        assertEquals("MPIN should match", "67890", corporate.getMpin());
//    }

    @Test
    public void testGetCorporatesByPasswordOwner_Failure() throws Exception {
        // Mock input
        String optumUUID = "test-uuid";
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");
        LogMessage logMessage = new LogMessage();

//        Token mockToken = new Token();
//        mockToken.setAccessToken("mock-access-token");
//        doReturn(mockToken).when(digitalSecurityService).getDigiSecToken(any(), eq("DS"));

        // Call method and assert exception
        ApplicationException exception = assertThrows(ApplicationException.class, () -> {
            digitalSecurityService.getCorporatesByPasswordOwner(optumUUID, headers, logMessage);
        });

        assertEquals("WEB SERVICE CALL FAILURE - DIGITAL SECURITY CORPORATE CALL", exception.getMessage());
    }

//    @Test
    public void testGetProvidersByCorporate_Success() throws Exception {
        String uuid = "test-uuid";
        String uhcId = "test-uhc-id";
        String mpin = "test-mpin";
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");
        LogMessage logMessage = new LogMessage();

        OrgData mockOrgData = new OrgData();
        Tin mockTin = new Tin();
        MockedStatic<UriComponentsBuilder> mockedUriComponentsBuilder = mockStatic(UriComponentsBuilder.class);
        UriComponentsBuilder mockBuilder = mock(UriComponentsBuilder.class);

        mockedUriComponentsBuilder.when(() -> UriComponentsBuilder.fromUriString("DigiSec_UserOrg_URL"))
                .thenReturn(mockBuilder);
        mockOrgData.setTins(Collections.singletonList(mockTin));
        ResponseEntity<OrgData> mockResponse = new ResponseEntity<>(mockOrgData, HttpStatus.OK);

        digitalSecurityService = spy(DigitalSecurityServiceImpl.class);
        Token mockToken = new Token();
        mockToken.setAccessToken("mock-access-token");
        doReturn(mockToken).when(digitalSecurityService).getDigiSecToken(any(), eq("DS"));
        doReturn(mockResponse).when(digitalSecurityService).sendRequest(
                anyString(),
                any(),
                eq(OrgData.class),
                eq(HttpMethod.POST),
                anyString()
        );
        try{
            PDOTins result = digitalSecurityService.getProvidersByCorporate(uuid, uhcId, mpin, headers, logMessage);

            assertNotNull(result);
            assertEquals(uuid, result.getOptumUUID());
            assertEquals(uhcId, result.getUhcID());
            assertEquals(mpin, result.getMpin());
            assertEquals(1, result.getProviders().size());} catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Test
    public void testGetEmailsByCorporate_Success() throws Exception {
        String corporateMpin = "test-mpin";
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        Token mockToken = new Token();
        mockToken.setAccessToken("mock-access-token");

        User mockUser = new User();
        mockUser.setEmail("test@example.com");
        ResponseEntity<User> mockResponse = new ResponseEntity<>(mockUser, HttpStatus.OK);

        doReturn(mockToken).when(digitalSecurityService).getDigiSecToken(eq("DS_PAA"), anyString());
        doReturn(mockResponse).when(digitalSecurityService).sendDigiSecRequest(
                anyString(),
                any(),
                eq(User.class),
                eq(HttpMethod.POST),
                anyString()
        );

        ResponseEntity<User> response = digitalSecurityService.getEmailsByCorporate(corporateMpin, headers);

        assertNotNull(response);
//        assertNotNull(response.getBody());
//        assertEquals("test@example.com", response.getBody().getEmail());
    }

    @Test
    public void testGetEmailsByCorporate_Failure() throws Exception {
        String corporateMpin = "test-mpin";
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");
        try {
            ResponseEntity resp = digitalSecurityService.getEmailsByCorporate(corporateMpin, headers);
            assertNotNull(resp);
        } catch (Exception e) {

        }
    }
    
	@Test
	public void testGetCorporatesByPasswordOwner_SuccessFullFlow() throws Exception {

		String uuid = "test-uuid";

		HttpHeaders headers = new HttpHeaders();
		headers.add("optum-cid-ext", "cid");

		LogMessage logMessage = new LogMessage();

		// ✅ mock token
		Token token = new Token();
		token.setAccessToken("token");

		// ✅ mock data
		ProviderOrg org = new ProviderOrg();
		org.setPaa(true);
		org.setFirstName("John");
		org.setLastName("Doe");
		org.setCorpMpin("123");
		org.setUhcProviderId("456");
		org.setId("id1");

		ProviderProfile profile = new ProviderProfile();
		profile.setProviderOrg(Collections.singletonList(org));

		ResponseEntity<ProviderProfile> resp = new ResponseEntity<>(profile, HttpStatus.OK);

		doReturn(token).when(digitalSecurityService).getDigiSecToken(any(), any());

		doReturn(resp).when(digitalSecurityService).sendRequest(anyString(), any(HttpEntity.class),
				eq(ProviderProfile.class), eq(HttpMethod.POST), anyString());

		PDOCorporates result = digitalSecurityService.getCorporatesByPasswordOwner(uuid, headers, logMessage);

		assertNotNull(result);
		assertEquals(1, result.getCorporates().size());
	}

	@Test
	public void testGetProvidersByCorporate_FullSuccess() throws Exception {

		HttpHeaders headers = new HttpHeaders();
		headers.add("optum-cid-ext", "cid");

		LogMessage logMessage = new LogMessage();

		// ✅ mock token
		Token token = new Token();
		token.setAccessToken("token");

		// ✅ mock response
		Tin tin = new Tin();
		OrgData data = new OrgData();
		data.setTins(Collections.singletonList(tin));

		ResponseEntity<OrgData> resp = new ResponseEntity<>(data, HttpStatus.OK);

		doReturn(token).when(digitalSecurityService).getDigiSecToken(any(), any());

		doReturn(resp).when(digitalSecurityService).sendRequest(anyString(), any(), eq(OrgData.class),
				eq(HttpMethod.POST), anyString());

		PDOTins result = digitalSecurityService.getProvidersByCorporate("uuid", "uhc", "mpin", headers, logMessage);

		assertNotNull(result);
		assertEquals(1, result.getProviders().size());
	}

	@Test
	public void testGetDigiSecToken_Success() throws Exception {

		Token token = new Token();
		token.setAccessToken("token");

		doReturn(token).when(oauth2handler).getOauthToken(any(), any());

		ReflectionTestUtils.setField(digitalSecurityService, "oauth2handler", oauth2handler);

		Token result = digitalSecurityService.getDigiSecToken("session", "cid");

		assertNotNull(result);
	}

	@Test
	public void testGetDigiSecToken_Exception() throws Exception {

		when(oauth2handler.getOauthToken(any(), any())).thenThrow(new IOException()); // ✅ MATCHES catch block

		ReflectionTestUtils.setField(digitalSecurityService, "oauth2handler", oauth2handler);

		assertThrows(ApplicationException.class, () -> {
			digitalSecurityService.getDigiSecToken("s", "c");
		});
	}
}