package com.optum.providerpreferences.rs.service;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObj;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

public class AutoenrollmentServiceImplTest {

    @InjectMocks
    private AutoenrollmentServiceImpl autoenrollmentService;

    @Mock
    private FDSCloudHandler mockFdsCloudHandler;

    @Mock
    private ExecutorService mockExecutorService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

//    @Test
    public void testCreateAutoenrollmentDocumentsFDSCloud_Success() throws ApplicationException {
        AutoenrollmentRequest autoenrollRequest = new AutoenrollmentRequest();
        AutoenrollmentObj autoenrollObj = new AutoenrollmentObj();
        autoenrollObj.setTin("123456");
        autoenrollObj.setMpin("111111");
        autoenrollObj.setProviderEmailId("test@example.com");
        autoenrollObj.setFileName("TestFile");
        autoenrollRequest.setAutoenrollDocuments(Collections.singletonList(autoenrollObj));

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");
        OptOutFDSCloudPOSTResponse mockResponseBody = new OptOutFDSCloudPOSTResponse();
        mockResponseBody.setDocumentId("mockDocId");
        ResponseEntity<OptOutFDSCloudPOSTResponse> mockResponse = new ResponseEntity<>(mockResponseBody, HttpStatus.CREATED);

        when(mockFdsCloudHandler.FDSCloudPostRequest(any(), any(FDSCloudRequest.class), anyString()))
                .thenReturn(mockResponse);
        when(mockFdsCloudHandler.FDSCloudPutRequest(any(), any(FDSCloudRequest.class), anyString()))
                .thenReturn(mockResponse);
        doNothing().when(mockExecutorService).execute(any(Runnable.class));

        List<String> result = autoenrollmentService.createAutoenrollmentDocumentsFDSCloud(autoenrollRequest, headers);

        assertNotNull(result);
        assertEquals(0, result.size());
    }

//    @Test
    public void testFormatDate_ValidDate() {
        Date testDate = new Date(1672531200000L);
        String expectedDate = "2023-01-01T00:00:00.000Z";

        String formattedDate = autoenrollmentService.formatDate(testDate);

        assertEquals(expectedDate, formattedDate);
    }

    @Test
    public void testExistingEmailRequest_Run() throws ApplicationException {
        AutoenrollmentObj autoenrollRequest = new AutoenrollmentObj();
        autoenrollRequest.setTin("123456");
        autoenrollRequest.setMpin("111111");
        autoenrollRequest.setProviderEmailId("old@example.com");
        autoenrollRequest.setFileName("TestFile");

        FDSCloudRequest mockRequest = new FDSCloudRequest();
        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();

        OptOutFDSCloudDocument obj = new OptOutFDSCloudDocument();
        obj.setMetadata(AsyncComponentTest.getMetadata().toString());
        mockResponse.setDocuments(Collections.singletonList(obj));
        Map<String, Object> mockMetadata = new HashMap<>();
        mockMetadata.put("providerEmailId", "test@test.com");

        when(mockFdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(mockRequest);
        when(mockFdsCloudHandler.FDSCloudGetRequest(anyString(), eq(mockRequest), anyString(), anyString()))
                .thenReturn(mockResponse);
        when(mockFdsCloudHandler.getSearchTermsFromDocument(mockResponse.getDocuments().get(0))).thenReturn(mockMetadata);

        autoenrollmentService.autoenrollObjects = Collections.synchronizedList(new ArrayList<>());
        AutoenrollmentServiceImpl.existingEmailRequest existingEmailRequest = autoenrollmentService.new existingEmailRequest(autoenrollRequest);

        existingEmailRequest.run();

        assertEquals("test@test.com", autoenrollRequest.getProviderEmailId());
        assertEquals(1, autoenrollmentService.autoenrollObjects.size());
        assertTrue(autoenrollmentService.autoenrollObjects.contains(autoenrollRequest));
    }

    @Test
    public void testAutoenrollmentFDSCloudPostRequest_Run() throws ApplicationException {
        FDSCloudRequest mockRequest = new FDSCloudRequest();
        OptOutFDSCloudPOSTResponse mockResponseBody = new OptOutFDSCloudPOSTResponse();
        mockResponseBody.setDocumentId("mockDocId");

        ResponseEntity<OptOutFDSCloudPOSTResponse> mockResponse = new ResponseEntity<>(mockResponseBody, HttpStatus.CREATED);

        when(mockFdsCloudHandler.FDSCloudPostRequest(anyString(), eq(mockRequest), anyString()))
                .thenReturn(mockResponse);

        autoenrollmentService.docIdList = Collections.synchronizedList(new ArrayList<>());
        AutoenrollmentServiceImpl.autoenrollmentFDSCloudPostRequest postRequest = autoenrollmentService.new autoenrollmentFDSCloudPostRequest(mockRequest);

        postRequest.run();

        assertEquals(1, autoenrollmentService.docIdList.size());
        assertTrue(autoenrollmentService.docIdList.contains("mockDocId"));
    }

    @Test
    public void testAutoenrollmentFDSCloudPostRequest_Run_Failure() throws ApplicationException {
        FDSCloudRequest mockRequest = new FDSCloudRequest();
        OptOutFDSCloudPOSTResponse mockResponseBody = new OptOutFDSCloudPOSTResponse();
        mockResponseBody.setDocumentId("mockDocId");

        ResponseEntity<OptOutFDSCloudPOSTResponse> mockResponse_fail = new ResponseEntity<>(mockResponseBody, HttpStatus.BAD_REQUEST);

        when(mockFdsCloudHandler.FDSCloudPostRequest(anyString(), eq(mockRequest), anyString()))
                .thenReturn(mockResponse_fail);

        autoenrollmentService.docIdList = Collections.synchronizedList(new ArrayList<>());
        AutoenrollmentServiceImpl.autoenrollmentFDSCloudPostRequest postRequest = autoenrollmentService.new autoenrollmentFDSCloudPostRequest(mockRequest);

        postRequest.run();

        assertEquals(1, autoenrollmentService.docIdList.size());
        assertTrue(autoenrollmentService.docIdList.contains("mockDocId"));
    }
    
	@Test
	public void testCreateAutoenrollmentDocumentsFDSCloud_FullFlow() throws Exception {

		// ✅ Force synchronous execution
		ExecutorService executor = mock(ExecutorService.class);

		doAnswer(invocation -> {
			Runnable r = invocation.getArgument(0);
			r.run(); // ✅ executes immediately
			return null;
		}).when(executor).execute(any(Runnable.class));

		ReflectionTestUtils.setField(autoenrollmentService, "emailRequestExecutorService", executor);
		ReflectionTestUtils.setField(autoenrollmentService, "autoenrollmentPostExecutorService", executor);
		ReflectionTestUtils.setField(autoenrollmentService, "autoenrollmentGetExecutorService", executor);

		// ✅ input request
		AutoenrollmentObj obj = new AutoenrollmentObj();
		obj.setTin("123");
		obj.setMpin("456");
		obj.setProviderEmailId("old@mail.com");
		obj.setFileName("C1");

		AutoenrollmentRequest request = new AutoenrollmentRequest();
		request.setAutoenrollDocuments(Collections.singletonList(obj));

		HttpHeaders headers = new HttpHeaders();
		headers.add("optum-cid-ext", "cid");

		// ✅ mock GET response
		FDSCloudGETResponse getResp = new FDSCloudGETResponse();

		OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
		getResp.setDocuments(Collections.singletonList(doc));

		Map<String, Object> metadata = new HashMap<>();
		metadata.put("providerEmailId", "new@mail.com");

		when(mockFdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(new FDSCloudRequest());

		when(mockFdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString())).thenReturn(getResp);

		when(mockFdsCloudHandler.getSearchTermsFromDocument(any())).thenReturn(metadata);

		// ✅ mock POST response
		OptOutFDSCloudPOSTResponse postRespObj = new OptOutFDSCloudPOSTResponse();
		postRespObj.setDocumentId("doc123");

		ResponseEntity<OptOutFDSCloudPOSTResponse> postResp = new ResponseEntity<>(postRespObj, HttpStatus.CREATED);

		when(mockFdsCloudHandler.FDSCloudPostRequest(anyString(), any(), anyString())).thenReturn(postResp);

		when(mockFdsCloudHandler.FDSCloudPutRequest(anyString(), any(), anyString())).thenReturn(postResp);
		
		List<String> result = autoenrollmentService.createAutoenrollmentDocumentsFDSCloud(request, headers);

		// ✅ assertions
		assertNotNull(result);
		assertTrue(result.size() >= 1);
	}
}