package com.optum.providerpreferences.rs.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.handler.PESHandler;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinData;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.ndb.provider.ResponseData;
import com.optum.providerpreferences.rs.model.optout.*;
import com.optum.providerpreferences.rs.model.pes.Key;
import com.optum.providerpreferences.rs.model.pes.PESResponse;
import com.optum.providerpreferences.rs.model.pes.PESTinRequest;
import com.optum.providerpreferences.rs.model.pes.TinObject;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class OptOutServiceImplTest {

    @InjectMocks
    private OptOutServiceImpl optOutService;

    @Mock
    private NDBHandler ndbHandler;

    @Mock
    private PESHandler pesHandler;

    @Mock
    private FDSCloudHandler fdsCloudHandler;

    @Mock
    private ObjectMapper mapper;

    @Mock
    private DocumentService documentService;

    @Before
    public void setUp() throws OAuthProblemException, ApplicationException, OAuthSystemException, IOException {
        MockitoAnnotations.openMocks(this);
        doNothing().when(ndbHandler).ndbWebServicePrep();
        optOutService.mapper = mapper;
        optOutService.documentService = documentService;
    }

    @Test
    public void testGetOptOutAuditLog() throws ApplicationException {
        String sessionId = "test-session";
        FDSCloudRequest request = mock(FDSCloudRequest.class);
        FDSCloudGETResponse response = mock(FDSCloudGETResponse.class);

        when(fdsCloudHandler.FDSCloudGetRequest(sessionId, request, "", "")).thenReturn(response);
        
        FDSCloudGETResponse result = optOutService.getOptOutAuditLog(sessionId, request);

        assertNotNull(result);
        verify(fdsCloudHandler, times(1)).FDSCloudGetRequest(sessionId, request, "", "");
    }

    @Test
    public void testAddOptOutAuditLog() throws ApplicationException {
        String sessionId = "test-session";
        FDSCloudRequest request = mock(FDSCloudRequest.class);
        ResponseEntity<?> response = mock(ResponseEntity.class);

        when(fdsCloudHandler.FDSCloudPostRequest(sessionId, request, "")).thenReturn ((ResponseEntity<OptOutFDSCloudPOSTResponse>) response);
        ResponseEntity<?> result = optOutService.addOptOutAuditLog(sessionId, request);

        assertNotNull(result);
        verify(fdsCloudHandler, times(1)).FDSCloudPostRequest(sessionId, request, "");
    }

    @Test
    public void testUpdateOptOutDocuments() throws Exception {
        OptOutRequest optOutRequest = mock(OptOutRequest.class);
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        when(optOutRequest.getTin()).thenReturn("123456");
        when(optOutRequest.getProviderMpins()).thenReturn(Collections.singletonList("7890"));
        when(optOutRequest.getCategories()).thenReturn(Collections.singletonList("test-category"));

        Map<String, List<String>> result = optOutService.updateOptOutDocuments(optOutRequest, headers);

        assertNotNull(result);
        verify(ndbHandler, times(1)).ndbWebServicePrep();
    }


    @Test
    public void testUpdateOptOutDocuments_emptyMpinsList() throws Exception {
        OptOutRequest optOutRequest = new OptOutRequest();
        optOutRequest.setTin("123456");
        optOutRequest.setCorpMpin("corpMpin");
        optOutRequest.setProviderMpins(Collections.emptyList());
        optOutRequest.setCategories(Collections.singletonList("claims"));
        optOutRequest.setLastUpdatedBy("testUser");
        optOutRequest.setLastUpdatedById("testUserId");
        optOutRequest.setOptedOutDuration(30);

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        RequestData requestData = new RequestData();
        requestData.setTaxIdNumber("123456");
        requestData.setCorpOwnerId("corpMpin");

        CorpMpinResponse corpMpinResponse = new CorpMpinResponse();
        ResponseData responseData = new ResponseData();
        MpinData mpinData = new MpinData();
        mpinData.setProviderId("7890");
        responseData.setMpinList(Collections.singletonList(mpinData));
        corpMpinResponse.setResponse(responseData);
        Map<String, Object> res = new HashMap<>();
        res.put("test","method");
        Map<String, List<String>> mockDocumentIds = new HashMap<>();
        mockDocumentIds.put("doc123", Arrays.asList("123456", "987654321", "claims"));
        optOutService = spy(new OptOutServiceImpl());
        optOutService.ndbHandler = ndbHandler;
        optOutService.fdsCloudHandler = fdsCloudHandler;
        optOutService.mapper = mapper;

        when(ndbHandler.getProviderData(any(RequestData.class), anyString())).thenReturn(corpMpinResponse);
        when(ndbHandler.updateProviderLetterPreferences(any(), anyString(), anyString(), anyString())).thenReturn(true);
        doNothing().when(ndbHandler).ndbWebServicePrep();
        doAnswer(invocation -> {
            return null;
        }).when(fdsCloudHandler).FDSCloudPutRequest(anyString(), any(FDSCloudRequest.class), anyString());
        doReturn(mockDocumentIds).when(optOutService).getDocuments(any(List.class), any(List.class), anyString(), any());

        when(mapper.convertValue(any(), (TypeReference<Object>) any()))
                .thenReturn(res);


        Map<String, List<String>> result = optOutService.updateOptOutDocuments(optOutRequest, headers);

        assertNotNull(result);
        assertFalse(result.isEmpty());
        verify(ndbHandler, times(1)).getProviderData(any(RequestData.class), anyString());
        verify(fdsCloudHandler, atLeastOnce()).FDSCloudPutRequest(anyString(), any(FDSCloudRequest.class), anyString());
    }


    @Test
    public void testUpdateOptOutDocuments_emptyMpinsList_throwsException() throws Exception {
        OptOutRequest optOutRequest = new OptOutRequest();
        optOutRequest.setTin("123456");
        optOutRequest.setCorpMpin("corpMpin");
        optOutRequest.setProviderMpins(Collections.emptyList());
        optOutRequest.setCategories(Collections.singletonList("claims"));
        optOutRequest.setLastUpdatedBy("testUser");
        optOutRequest.setLastUpdatedById("testUserId");
        optOutRequest.setOptedOutDuration(30);

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        RequestData requestData = new RequestData();
        requestData.setTaxIdNumber("123456");
        requestData.setCorpOwnerId("corpMpin");

        CorpMpinResponse corpMpinResponse = new CorpMpinResponse();
        ResponseData responseData = new ResponseData();
        MpinData mpinData = new MpinData();
        mpinData.setProviderId("7890");
        responseData.setMpinList(Collections.singletonList(mpinData));
        corpMpinResponse.setResponse(responseData);

        //happy path
        when(ndbHandler.getProviderData(any(RequestData.class), anyString())).thenThrow(new ApplicationException("MOCKED ERROR"));
        when(ndbHandler.updateProviderLetterPreferences(any(), anyString(), anyString(), anyString())).thenReturn(true);
        doNothing().when(ndbHandler).ndbWebServicePrep();
        doAnswer(invocation -> {
            return null;
        }).when(fdsCloudHandler).FDSCloudPutRequest(anyString(), any(FDSCloudRequest.class), anyString());
        Map<String, Object> res = new HashMap<>();
        res.put("test","method");

        when(mapper.convertValue(any(), (TypeReference<Object>) any()))
                .thenReturn(res);

        try {
            optOutService.updateOptOutDocuments(optOutRequest, headers);
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            // expected
        }

    }

    @Test
    public void testPadWithLeadingZeros() throws ApplicationException {
        
        String result = optOutService.padWithLeadingZeros("123");
        assertEquals("000000123", result);

        result = optOutService.padWithLeadingZeros("123456789");
        assertEquals("123456789", result);

        try {
            optOutService.padWithLeadingZeros("12345678910");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            // expected
        }
    }

    @Test
    public void testCreateOptOutDocument() {
        List<String> requestData = Arrays.asList("123456", "7890", "test-classifier");
        String lastUpdatedBy = "test-user";
        String lastUpdatedById = "test-id";
        int optedOutDuration = -1;
        Map<String, Object> res = new HashMap<>();
        res.put("test","method");
        when(mapper.convertValue(any(), (TypeReference<Object>) any()))
                .thenReturn(res);

        Map<String, Object> result = optOutService.createOptOutDocument(requestData, lastUpdatedBy, lastUpdatedById, optedOutDuration);

        assertNotNull(result);
    }


    @Test
    public void testGetDocuments() throws Exception {
        // Arrange
        List<String> providerMpins = Arrays.asList("123456789", "987654321");
        List<String> categories = Arrays.asList("claims", "appeals");
        String tin = "123456";
        String cid = "test-cid";

        List<OptOutFDSCloudDocument> mockResponse = new ArrayList<>();
        OptOutFDSCloudDocument mockDocument = new OptOutFDSCloudDocument();
        mockDocument.setDocumentId("doc123");
        mockResponse.add(mockDocument);

        when(documentService.getDocumentsBySearchTerms(anyMap())).thenReturn(Collections.emptyList());
        when(fdsCloudHandler.getAvailableAutoenrolledForOptOut(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(mockResponse);

        Map<String, List<String>> result = optOutService.getDocuments(providerMpins, categories, tin, cid);

        // Assert
        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertTrue(result.containsKey("doc123"));
    }

    @Test
    public void testGetDocuments_throwsIOException() throws Exception {
        // Arrange
        List<String> providerMpins = Arrays.asList("123456789", "987654321");
        List<String> categories = Arrays.asList("claims", "appeals");
        String tin = "123456";
        String cid = "test-cid";

        when(documentService.getDocumentsBySearchTerms(anyMap())).thenReturn(Collections.emptyList());
        when(fdsCloudHandler.getAvailableAutoenrolledForOptOut(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenThrow(new IOException());
        try {
            optOutService.getDocuments(providerMpins, categories, tin, cid);
            fail("Expected Exception");
        } catch (Exception ignored) {
        }

    }

    @Test
    public void testGetClassifiersForCategory() {
        List<String> appealsClassifiers = optOutService.getClassifiersForCategory("appeals");
        assertNotNull(appealsClassifiers);
        assertFalse(appealsClassifiers.isEmpty());
        assertTrue(appealsClassifiers.contains("X0"));

        List<String> claimsClassifiers = optOutService.getClassifiersForCategory("claims");
        assertNotNull(claimsClassifiers);
        assertFalse(claimsClassifiers.isEmpty());
        assertTrue(claimsClassifiers.contains("C1"));

        List<String> overpaymentClassifiers = optOutService.getClassifiersForCategory("overpayment");
        assertNotNull(overpaymentClassifiers);
        assertFalse(overpaymentClassifiers.isEmpty());
        assertTrue(overpaymentClassifiers.contains("C5"));

        List<String> paymentClassifiers = optOutService.getClassifiersForCategory("payment");
        assertNotNull(paymentClassifiers);
        assertFalse(paymentClassifiers.isEmpty());
        assertTrue(paymentClassifiers.contains("E1"));

        List<String> priorauthClassifiers = optOutService.getClassifiersForCategory("priorauth");
        assertNotNull(priorauthClassifiers);
        assertFalse(priorauthClassifiers.isEmpty());
        assertTrue(priorauthClassifiers.contains("A1"));

        List<String> housecallsClassifiers = optOutService.getClassifiersForCategory("housecalls");
        assertNotNull(housecallsClassifiers);
        assertFalse(housecallsClassifiers.isEmpty());
        assertTrue(housecallsClassifiers.contains("H1"));

        List<String> invalidClassifiers = optOutService.getClassifiersForCategory("invalid-category");
        assertNotNull(invalidClassifiers);
        assertTrue(invalidClassifiers.isEmpty());
    }

    @Test
    public void testGetTins_success() throws ApplicationException, JsonProcessingException {
        // Arrange
        OptOutTinRequest optOutTinRequest = new OptOutTinRequest();
        optOutTinRequest.setCorporateMpin("123456");

        PESResponse mockResponse = new PESResponse();
        TinObject tinObject1 = new TinObject();
        Key key1 = new Key();
        key1.setTaxIdTypeCode("S");
        key1.setTaxIdNumber("123");
        tinObject1.setKey(key1);

        TinObject tinObject2 = new TinObject();
        Key key2 = new Key();
        key2.setTaxIdTypeCode("T");
        key2.setTaxIdNumber("321");
        tinObject2.setKey(key2);
        mockResponse.setData(Arrays.asList(tinObject1, tinObject2));

        when(pesHandler.getTins(any(PESTinRequest.class), anyString())).thenReturn(mockResponse);

        OptOutTinResponse result = optOutService.getTins(optOutTinRequest, "test-cid");

        assertNotNull(result);
        assertEquals(2, result.getTins().size());
    }

    @Test
    public void testGetTins_exception() throws ApplicationException, JsonProcessingException {
        // Arrange
        OptOutTinRequest optOutTinRequest = new OptOutTinRequest();
        optOutTinRequest.setCorporateMpin("123456");

        when(pesHandler.getTins(any(PESTinRequest.class), anyString())).thenThrow(new ApplicationException("Error retrieving TINs"));

        // Act & Assert
        try {
            optOutService.getTins(optOutTinRequest, "test-cid");
            fail("Expected ApplicationException");
        } catch (ApplicationException exception) {
            assertEquals("Error retrieving TINs", exception.getMessage());
        }
    }
}
