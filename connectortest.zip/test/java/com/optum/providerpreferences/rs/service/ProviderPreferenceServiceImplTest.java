package com.optum.providerpreferences.rs.service;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.ResolvedType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.digitalsecurity.model.request.User;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.model.OONProviderPopUpDate;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponse;
import com.optum.providerpreferences.rs.model.ndb.preferences.MailPref;
import com.optum.providerpreferences.rs.model.ndb.preferences.ResponseHeader;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.utility.ProviderPreferencesUtil.AutoEnrollment;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.ndb.preferences.ResponseData;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.utility.ProviderPreferencesUtil;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.text.ParseException;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;

public class ProviderPreferenceServiceImplTest {

    private static final Logger log = LoggerFactory.getLogger(ProviderPreferenceServiceImplTest.class);
    @Mock
    private NDBHandler ndbHandler;
    @Mock
    private ObjectMapper mapper;

    @Mock
    private FDSCloudHandler fdsCloudHandler;

    @Mock
    private ProviderPreferencesUtil provPrefUtil;
    @Mock
    private AsyncComponent asyncComponent;

    @InjectMocks
    private ProviderPreferenceServiceImpl providerPreferenceService;

    @Mock
    private DigitalSecurityService digitalSecService;

    @Mock
    DocumentService documentService;

    @Before
    public void setUp() throws ApplicationException {
        MockitoAnnotations.openMocks(this);
        when(documentService.getDocumentsBySearchTerms(anyMap()))
                .thenReturn(Collections.emptyList());
//        providerPreferenceService.mapper = mapper;
    }

//    @Test
//    void testGetProviderData_Success() throws Exception {
//        RequestData requestData = new RequestData("123456789", "111111111");
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("optum-cid-ext", "test-cid");
//        LogMessage logMessage = new LogMessage();
//        CorpMpinResponse mockResponse = new CorpMpinResponse();
////        providerPreferenceService = spy(providerPreferenceService);
////        providerPreferenceService.ndbHandler = ndbHandler;
//        when(ndbHandler.getProviderData(any(RequestData.class), anyString())).thenReturn(mockResponse);
//
//        CorpMpinResponse response = providerPreferenceService.getProviderData(requestData, headers, logMessage);
//
//        // Assert
//        assertNotNull(response);
//        verify(ndbHandler, times(1)).getProviderData(any(RequestData.class), anyString());
//    }

    @Test
    public void testGetProviderData_ThrowsException() throws Exception {
        RequestData requestData = new RequestData("123456789", "111111111");
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderData(any(RequestData.class), anyString()))
                .thenThrow(new ApplicationException("Error making service call to NDB"));

        try {
            providerPreferenceService.getProviderData(requestData, headers, logMessage);
            fail("Expected ApplicationException");
        } catch (ApplicationException exception) {
            assertEquals("Error making service call to NDB", exception.getMessage());
        }
    }

//    @Test
//    void testGetProviderPreferencesFDSCloud_Success() throws Exception {
//        String tin = "123456789";
//        String mpin = "111111111";
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("optum-cid-ext", "test-cid");
//        LogMessage logMessage = new LogMessage();
//
//
//        LetterPreferencesResponse mockResponse = new LetterPreferencesResponse();
//        List<MailPref> mailPrefList = new ArrayList<>();
//        MailPref mailPref = new MailPref();
//        mailPref.setLetterType("TestType");
//        mailPref.setMailingPref("E");
//        mailPrefList.add(mailPref);
//
//        ResponseData responseData = new ResponseData();
//        responseData.setLtrTypMailPrfList(mailPrefList);
//        responseData.setProviderId(mpin);
//        responseData.setProviderTIN(tin);
//
//        mockResponse.setRequestResponse(responseData);
//        when(ndbHandler.getProviderLetterPreferences(any(com.optum.providerpreferences.rs.model.ndb.preferences.RequestData.class), anyString()))
//                .thenReturn(mockResponse);
////        doReturn(mockResponse).when(ndbHandler).getProviderLetterPreferences(any(com.optum.providerpreferences.rs.model.ndb.preferences.RequestData.class), anyString());
//        when(provPrefUtil.padWithLeadingZeros(mpin)).thenReturn(mpin);
////        when(ndbHandler.getProviderLetterPreferences(any(com.optum.providerpreferences.rs.model.ndb.preferences.RequestData.class), anyString()))
////                .thenReturn(mockResponse);
//
//        ProviderPreferencesObj result = providerPreferenceService.getProviderPreferencesFDSCloud(tin, mpin, headers, logMessage);
//
//        assertNotNull(result);
//        assertEquals(tin, result.getCorporateTin());
//        assertFalse(result.getPreferenceTypes().isEmpty());
//        assertEquals("TestType", result.getPreferenceTypes().get(0).getClassifier());
//        assertEquals("E", result.getPreferenceTypes().get(0).getDeliveryMethod());
//        verify(ndbHandler, times(1)).getProviderLetterPreferences(any(), anyString());
//    }

    @Test
    public void testGetProviderPreferencesFDSCloud_Success_CUCUMBER() throws Exception {
        String tin = "123456789";
        String mpin = "111111111";
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");
        LogMessage logMessage = new LogMessage();
        logMessage.setUsername("CUCUMBERTEST");


        LetterPreferencesResponse mockResponse = new LetterPreferencesResponse();
        List<MailPref> mailPrefList = new ArrayList<>();
        MailPref mailPref = new MailPref();
        mailPref.setLetterType("TestType");
        mailPref.setMailingPref("E");
        mailPrefList.add(mailPref);

        ResponseData responseData = new ResponseData();
        responseData.setLtrTypMailPrfList(mailPrefList);
        responseData.setProviderId(mpin);
        responseData.setProviderTIN(tin);

        PreferenceType pt = new PreferenceType();
        pt.setClassifier("TestType");
        pt.setDeliveryMethod("E");
        pt.setLastUpdatedById("CUCUMBERTEST");
        pt.setDocumentId("123456789");
        pt.setDescription("Test Description");
        pt.setProviderName("Test Provider");
        pt.setActiveDate("2023-10-01T00:00:00.000Z");
        pt.setDateModified("2023-10-01T00:00:00.000Z");

        List<PreferenceType> prefTypeSubList = List.of(pt);
        CompletableFuture<List<PreferenceType>> mockFuture = CompletableFuture.completedFuture(prefTypeSubList);
        when(asyncComponent.getProviderPreferencesFDSCloudAsync(eq(tin), eq(mpin), eq(prefTypeSubList), anyString()))
                .thenReturn(mockFuture);
        mockResponse.setRequestResponse(responseData);
        when(ndbHandler.getProviderLetterPreferences(any(com.optum.providerpreferences.rs.model.ndb.preferences.RequestData.class), anyString()))
                .thenReturn(mockResponse);
        when(provPrefUtil.padWithLeadingZeros(mpin)).thenReturn(mpin);
        try {
            ProviderPreferencesObj result = providerPreferenceService.getProviderPreferencesFDSCloud(tin, mpin, headers, logMessage);
            assertNotNull(result);
            assertEquals(tin, result.getCorporateTin());
            assertFalse(result.getPreferenceTypes().isEmpty());
            assertEquals("TestType", result.getPreferenceTypes().get(0).getClassifier());
            assertEquals("E", result.getPreferenceTypes().get(0).getDeliveryMethod());
            verify(ndbHandler, times(1)).getProviderLetterPreferences(any(), anyString());
        } catch (ApplicationException e) {
            log.error("Error retrieving provider preferences: {}", e.getMessage());
        }

    }


    @Test
    public void testGetProviderPreferencesFDSCloud_ThrowsException() throws Exception {
        String tin = "123456789";
        String mpin = "111111111";
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");
        LogMessage logMessage = new LogMessage();
        logMessage.setUsername("CUCUMBERTEST");

        when(provPrefUtil.padWithLeadingZeros(mpin)).thenReturn(mpin);
        when(ndbHandler.getProviderLetterPreferences(any(), anyString()))
                .thenThrow(new ApplicationException("ERROR CALLING NDB"));

        try {
            providerPreferenceService.getProviderPreferencesFDSCloud(tin, mpin, headers, logMessage);
            fail("Expected ApplicationException");
        } catch (ApplicationException exception) {
            assertEquals("ERROR RETRIEVING PREFERENCES FOR MPIN", exception.getMessage());
        }
    }


    @Test
    public void testGetProviderOONPopUpDateFDSCloud_DocumentModifiedWithin24Hours() throws IOException, ApplicationException, ParseException {
        String tin = "123456789";
        String corpMpin = "987654321";
        List<String> mpins = Arrays.asList("111111111");
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument mockDocument = new OptOutFDSCloudDocument();
        mockDocument.setModifiedOn(System.currentTimeMillis()); // Modified within 24 hours
        mockResponse.setDocuments(Collections.singletonList(mockDocument));

        when(fdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(new FDSCloudRequest());
        when(fdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString())).thenReturn(mockResponse);

        OONProviderPopUpDate result = providerPreferenceService.getProviderOONPopUpDateFDSCloud(tin, corpMpin, mpins, headers);

        // Assert
        assertNotNull(result);
        assertFalse(result.isResponseFlag());
        assertNull(result.getProviderEmailId());
        verify(fdsCloudHandler, times(1)).FDSCloudGetRequest(anyString(), any(), anyString(), anyString());
    }


    @Test
    public void testGetProviderOONPopUpDateFDSCloud_NoDocumentsFound() throws IOException, ApplicationException, ParseException {
        String tin = "123456789";
        String corpMpin = "987654321";
        List<String> mpins = Arrays.asList("111111111");
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        mockResponse.setDocuments(Collections.emptyList());

        providerPreferenceService = spy(providerPreferenceService);
        when(fdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(new FDSCloudRequest());
        when(fdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString())).thenReturn(mockResponse);
        doReturn("A1").when(providerPreferenceService).checkNDBForDeliveryPreference(anyString(), anyString());
        doReturn("2023-10-01T00:00:00.000Z").when(providerPreferenceService).checkFDSCloudDocumentsForPopUpDate(anyMap(), anyString());

        OONProviderPopUpDate result = providerPreferenceService.getProviderOONPopUpDateFDSCloud(tin, corpMpin, mpins, headers);

        assertNotNull(result);
        assertTrue(result.isResponseFlag());
        assertNull(result.getProviderEmailId());
        verify(fdsCloudHandler, times(1)).FDSCloudGetRequest(anyString(), any(), anyString(), anyString());
    }



    @Test
    public void testGetProviderOONPopUpDateFDSCloud_NoDocumentsFound_NullPopupDate() throws IOException, ApplicationException, ParseException {
        String tin = "123456789";
        String corpMpin = "987654321";
        List<String> mpins = Arrays.asList("111111111");
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        mockResponse.setDocuments(Collections.emptyList());

        providerPreferenceService = spy(providerPreferenceService);
        when(fdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(new FDSCloudRequest());
        when(fdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString())).thenReturn(mockResponse);
        doReturn("A1").when(providerPreferenceService).checkNDBForDeliveryPreference(anyString(), anyString());
        doReturn(null).when(providerPreferenceService).checkFDSCloudDocumentsForPopUpDate(anyMap(), anyString());

        OONProviderPopUpDate result = providerPreferenceService.getProviderOONPopUpDateFDSCloud(tin, corpMpin, mpins, headers);

        assertNotNull(result);
        assertTrue(result.isResponseFlag());
//        assertNull(result.getProviderEmailId());
        verify(fdsCloudHandler, times(1)).FDSCloudGetRequest(anyString(), any(), anyString(), anyString());
    }



    @Test
    public void testCheckNDBForDeliveryPreference_Success() throws ApplicationException {
        String mpin = "123456789";
        String tin = "987654321";

        LetterPreferencesResponse mockResponse = new LetterPreferencesResponse();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setMessage("SUCCESSFUL");

        List<MailPref> mailPrefList = new ArrayList<>();
        MailPref mailPref = new MailPref();
        mailPref.setLetterType("C1");
        mailPref.setMailingPref("P");
        mailPrefList.add(mailPref);

        ResponseData reqResponse = new ResponseData();
        reqResponse.setProviderId(mpin);
        reqResponse.setProviderTIN(tin);
        reqResponse.setLtrTypMailPrfList(mailPrefList);

        mockResponse.setResponseHeader(responseHeader);
        mockResponse.setRequestResponse(reqResponse);
        when(ndbHandler.getProviderLetterPreferences(any(), anyString())).thenReturn(mockResponse);

        String result = providerPreferenceService.checkNDBForDeliveryPreference(mpin, tin);

        assertNotNull(result);
        verify(ndbHandler, times(1)).getProviderLetterPreferences(any(), anyString());
    }

    @Test
    public void testCheckNDBForDeliveryPreference_Failure() throws ApplicationException {
        String mpin = "123456789";
        String tin = "987654321";

        LetterPreferencesResponse mockResponse = new LetterPreferencesResponse();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setMessage(null);
        mockResponse.setResponseHeader(responseHeader);

        when(ndbHandler.getProviderLetterPreferences(any(), anyString())).thenReturn(mockResponse);

        try {
            providerPreferenceService.checkNDBForDeliveryPreference(mpin, tin);
            fail("Expected ApplicationException");
        } catch (ApplicationException exception) {
            assertEquals("ERROR CALLING NDB", exception.getMessage());
        }
    }

    @Test
    public void testCheckNDBForDeliveryPreference_ThrowsException() throws ApplicationException {
        String mpin = "123456789";
        String tin = "987654321";

        when(ndbHandler.getProviderLetterPreferences(any(), anyString()))
                .thenThrow(new ApplicationException("ERROR CALLING NDB"));

        try {
            providerPreferenceService.checkNDBForDeliveryPreference(mpin, tin);
            fail("Expected ApplicationException");
        } catch (ApplicationException exception) {
            assertEquals("ERROR CALLING NDB", exception.getMessage());
        }
    }


    @Test
    public void testCheckFDSCloudDocumentsForPopUpDate_Success_MultipleDocs() throws ApplicationException, IOException {
        Map<String, Object> metadataMap = new HashMap<>();
        metadataMap.put("tin", "123456789");
        metadataMap.put("mpin", "111111111");
        metadataMap.put("fileName", "TestFile");

        String cid = "test-cid";

        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument mockDocument1 = new OptOutFDSCloudDocument();
        Metadata metadata1 = new Metadata();
        metadata1.setLastOONPopUpDate("2023-10-01T00:00:00.000Z");
        mockDocument1.setMetadata(String.valueOf(metadata1));

        OptOutFDSCloudDocument mockDocument2 = new OptOutFDSCloudDocument();
        Metadata metadata2 = new Metadata();
        metadata2.setLastOONPopUpDate("2023-11-01T00:00:00.000Z");
        mockDocument2.setMetadata(String.valueOf(metadata2));

        mockResponse.setDocuments(Arrays.asList(mockDocument1, mockDocument2));

        when(mapper.readValue(anyString(), (Class<Metadata>) any())).thenReturn(metadata1);
        when(fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap)).thenReturn(null);
        when(fdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), eq(cid))).thenReturn(mockResponse);
        when(provPrefUtil.determineDocumentIndexCloud(anyList(), anyInt(), anyInt(), any(OffsetDateTime.class), eq(cid)))
                .thenReturn(new AutoEnrollment(true, 0));

        String result = providerPreferenceService.checkFDSCloudDocumentsForPopUpDate(metadataMap, cid);

        assertNotNull(result);
        assertEquals("2023-10-01T00:00:00.000Z", result);
        verify(fdsCloudHandler, times(1)).FDSCloudGetRequest(anyString(), any(), anyString(), eq(cid));
    }

    @Test
    public void testCheckFDSCloudDocumentsForPopUpDate_Success_SingleDoc() throws ApplicationException, IOException {
        Map<String, Object> metadataMap = new HashMap<>();
        metadataMap.put("tin", "123456789");
        metadataMap.put("mpin", "111111111");
        metadataMap.put("fileName", "TestFile");

        String cid = "test-cid";

        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument mockDocument1 = new OptOutFDSCloudDocument();
        Metadata metadata1 = new Metadata();
        metadata1.setLastOONPopUpDate("2023-10-01T00:00:00.000Z");
        mockDocument1.setMetadata(String.valueOf(metadata1));

        mockResponse.setDocuments(Collections.singletonList(mockDocument1));
        when(mapper.readValue(anyString(), (Class<Metadata>) any())).thenReturn(metadata1);
        when(fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap)).thenReturn(null);
        when(fdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), eq(cid))).thenReturn(mockResponse);
        when(provPrefUtil.determineDocumentIndexCloud(anyList(), anyInt(), anyInt(), any(OffsetDateTime.class), eq(cid)))
                .thenReturn(new AutoEnrollment(true, 0));

        String result = providerPreferenceService.checkFDSCloudDocumentsForPopUpDate(metadataMap, cid);

        assertNotNull(result);
        assertEquals("2023-10-01T00:00:00.000Z", result);
        verify(fdsCloudHandler, times(1)).FDSCloudGetRequest(anyString(), any(), anyString(), eq(cid));
    }


    @Test
    public void testCheckFDSCloudDocumentsForPopUpDate_NoDocuments() throws ApplicationException, IOException {
        Map<String, Object> metadataMap = new HashMap<>();
        metadataMap.put("tin", "123456789");
        metadataMap.put("mpin", "111111111");
        metadataMap.put("fileName", "TestFile");

        String cid = "test-cid";

        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        mockResponse.setDocuments(Collections.emptyList());

        when(fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap)).thenReturn(null);
        when(fdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), eq(cid))).thenReturn(mockResponse);

        String result = providerPreferenceService.checkFDSCloudDocumentsForPopUpDate(metadataMap, cid);

        // Assert
        assertNull(result);
        verify(fdsCloudHandler, times(1)).FDSCloudGetRequest(anyString(), any(), anyString(), eq(cid));
    }

//    @Test
//    void testCheckFDSCloudDocumentsForPopUpDate_ThrowsException() throws IOException, ApplicationException {
//        Map<String, Object> metadataMap = new HashMap<>();
//        metadataMap.put("tin", "123456789");
//        metadataMap.put("mpin", "111111111");
//        metadataMap.put("fileName", "TestFile");
//
//        String cid = "test-cid";
//
//        when(fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap)).thenReturn(null);
//        when(fdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), eq(cid)))
//                .thenThrow(new IOException("Error fetching documents"));
//
//        assertThrows(IOException.class, () -> {
//            providerPreferenceService.checkFDSCloudDocumentsForPopUpDate(metadataMap, cid);
//        });
//
//        verify(fdsCloudHandler, times(1)).FDSCloudGetRequest(anyString(), any(), anyString(), eq(cid));
//    }


    @Test
    public void testGetPAAEmailFromDigisec_Success() throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException {
        String corpMpin = "123456789";
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        User mockUser = new User();
        mockUser.setEmail("test@example.com");
        ResponseEntity<User> mockResponse = ResponseEntity.ok(mockUser);

        when(digitalSecService.getEmailsByCorporate(corpMpin, headers)).thenReturn(mockResponse);

        // Act
        String email = providerPreferenceService.getPAAEmailFromDigisec(corpMpin, headers);

        // Assert
        assertNotNull(email);
        assertEquals("test@example.com", email);
        verify(digitalSecService, times(1)).getEmailsByCorporate(corpMpin, headers);
    }

    @Test
    public void testGetPAAEmailFromDigisec_NullPointerException() throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException {
        String corpMpin = "123456789";
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        when(digitalSecService.getEmailsByCorporate(corpMpin, headers)).thenThrow(new NullPointerException("Null response"));

        String email = providerPreferenceService.getPAAEmailFromDigisec(corpMpin, headers);

        assertNull(email);
        verify(digitalSecService, times(1)).getEmailsByCorporate(corpMpin, headers);
    }

    @Test
    public void testGetPAAEmailFromDigisec_Exception() throws OAuthProblemException, ApplicationException, OAuthSystemException, IOException {
        String corpMpin = "123456789";
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        when(digitalSecService.getEmailsByCorporate(corpMpin, headers)).thenThrow(new IOException("Null response"));

        try {
            providerPreferenceService.getPAAEmailFromDigisec(corpMpin, headers);
            fail("Expected ApplicationException");
        } catch (ApplicationException result) {
            // expected
        }
    }
    
	@Test
	public void testGetProviderPreferencesFDSCloud_NormalSuccess() throws Exception {

		String tin = "123";
		String mpin = "456";

		HttpHeaders headers = new HttpHeaders();
		headers.add("optum-cid-ext", "cid");

		LogMessage log = new LogMessage(); // no username → normal path

		// ✅ NDB mock
		LetterPreferencesResponse resp = new LetterPreferencesResponse();

		ResponseHeader header = new ResponseHeader();
		header.setMessage("SUCCESSFUL");

		MailPref pref = new MailPref();
		pref.setLetterType("C1");
		pref.setMailingPref("E");

		ResponseData data = new ResponseData();
		data.setLtrTypMailPrfList(Collections.singletonList(pref));

		resp.setResponseHeader(header);
		resp.setRequestResponse(data);

		when(ndbHandler.getProviderLetterPreferences(any(), anyString())).thenReturn(resp);

		when(provPrefUtil.padWithLeadingZeros(any())).thenReturn(mpin);

		// ✅ async future
		PreferenceType pt = new PreferenceType();
		pt.setClassifier("C1");

		CompletableFuture<List<PreferenceType>> future = CompletableFuture.completedFuture(List.of(pt));

		when(asyncComponent.getProviderPreferencesFDSCloudAsync(any(), any(), any(), any())).thenReturn(future);

		ProviderPreferencesObj result = providerPreferenceService.getProviderPreferencesFDSCloud(tin, mpin, headers,
				log);

		assertNotNull(result);
		assertFalse(result.getPreferenceTypes().isEmpty());
	}

	@Test
	public void testGetProviderPreferencesFDSCloud_NotSuccessful() throws Exception {

		String tin = "123";
		String mpin = "456";

		HttpHeaders headers = new HttpHeaders();
		headers.add("optum-cid-ext", "cid");

		LogMessage log = new LogMessage();

		LetterPreferencesResponse resp = new LetterPreferencesResponse();

		ResponseHeader header = new ResponseHeader();
		header.setMessage("FAILED"); // ❌ not successful

		resp.setResponseHeader(header);

		when(provPrefUtil.padWithLeadingZeros(any())).thenReturn(mpin);
		when(ndbHandler.getProviderLetterPreferences(any(), anyString())).thenReturn(resp);

		assertThrows(ApplicationException.class, () -> {
			providerPreferenceService.getProviderPreferencesFDSCloud(tin, mpin, headers, log);
		});
	}

	@Test
	public void testCheckFDSCloudDocumentsForPopUpDate_NoValidIndex() throws Exception {

		Map<String, Object> metadata = new HashMap<>();
		String cid = "cid";

		FDSCloudGETResponse resp = new FDSCloudGETResponse();

		OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
		doc.setMetadata("{\"lastOONPopUpDate\":\"2023-01-01T00:00:00.000Z\"}");

		resp.setDocuments(List.of(doc));

		when(fdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(null);

		when(fdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString())).thenReturn(resp);

		Metadata meta = new Metadata();
		meta.setLastOONPopUpDate("2023-01-01T00:00:00.000Z");

		when(mapper.readValue(anyString(), eq(Metadata.class))).thenReturn(meta);

		// ✅ CRITICAL FIX
		when(provPrefUtil.determineDocumentIndexCloud(any(), anyInt(), anyInt(), any(), any()))
				.thenReturn(new ProviderPreferencesUtil.AutoEnrollment(true, -1));

		String result = providerPreferenceService.checkFDSCloudDocumentsForPopUpDate(metadata, cid);

		assertNull(result);
	}
}
