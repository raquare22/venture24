package com.optum.providerpreferences.rs.service;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.text.ParseException;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.model.OONRequestModel;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponse;
import com.optum.providerpreferences.rs.model.ndb.preferences.MailPref;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinData;
import com.optum.providerpreferences.rs.model.ndb.provider.ResponseData;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import org.jetbrains.annotations.NotNull;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.utility.ProviderPreferencesUtil;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class AsyncComponentTest {

    @Mock
    private ProviderPreferencesUtil mockProviderPreferencesUtil;

    @Mock
    private FDSCloudHandler mockFdsCloudHandler;

    @Mock
    private OptOutService mockOptOutService;
    
    @Mock
    ObjectMapper mapper;

    @Mock
    private NDBHandler mockNdbHandler;

    @Mock
    DocumentService documentService;;

//    @InjectMocks
    AsyncComponent asyncComponent;

    @Before
    public void setUp() throws ApplicationException {
        MockitoAnnotations.initMocks(this);
        asyncComponent = new AsyncComponent();
        asyncComponent.fdsCloudHandler = mockFdsCloudHandler;
        asyncComponent.provPrefUtil = mockProviderPreferencesUtil;
        asyncComponent.ndbHandler = mockNdbHandler;
        asyncComponent.optOutService = mockOptOutService;
        asyncComponent.mapper = mapper;
        asyncComponent.documentService = documentService;
        when(documentService.getDocumentsBySearchTerms(anyMap()))
                .thenReturn(Collections.emptyList());
        when(mapper.convertValue(any(), eq(Metadata.class))).thenAnswer(invocation -> {
            Metadata metadata = getMetadata();
            metadata.setTin("123456789");
            metadata.setMpin("111111111");
            return metadata;
        });
    }

    @Test
    public void testGetProviderPreferencesFDSCloudAsync_Success() throws Exception {
        String tin = "123456789";
        String mpin = "111111111";
        String cid = "test-cid";
        List<PreferenceType> preferenceTypeList = new ArrayList<>();
        PreferenceType prefType = new PreferenceType();
        prefType.setClassifier("TEST_CLASSIFIER");
        preferenceTypeList.add(prefType);
        Metadata metadata = getMetadata();

        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        doc.setModifiedOn(System.currentTimeMillis());
        doc.setMetadata(String.valueOf(metadata));
        mockResponse.setTotal_records("1");
        mockResponse.setCount("1");
        mockResponse.setDocuments(Collections.singletonList(doc));

        when(mockFdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString()))
                .thenReturn(mockResponse);
        when(mockProviderPreferencesUtil.determineDocumentIndexCloud(anyList(), anyInt(), anyInt(), any(OffsetDateTime.class), eq(cid)))
                .thenReturn(new ProviderPreferencesUtil.AutoEnrollment(true, 0));
        when(mapper.readValue(anyString(), (Class<Metadata>) any())).thenReturn(metadata);

        CompletableFuture<List<PreferenceType>> resultFuture = asyncComponent.getProviderPreferencesFDSCloudAsync(tin, mpin, preferenceTypeList, cid);

        assertNotNull(resultFuture);
        List<PreferenceType> result = resultFuture.get();
        assertEquals(1, result.size());
        assertEquals("TEST_CLASSIFIER", result.get(0).getClassifier());
    }

    @NotNull
    public static Metadata getMetadata() {
        Metadata metadata = new Metadata();
        metadata.setTin("123456789");
        metadata.setMpin("111111111");
        metadata.setProviderEmailId("dummyProviderEmailId@example.com");
        metadata.setFrequency("Monthly");
        metadata.setOkToChangePDOInd("Y");
        metadata.setAutoEdelUpdateInd("N");
        metadata.setLastOONPopUpDate("2023-10-01T00:00:00.000Z");
        metadata.setLastUpdatedBy("dummyUser");
        metadata.setLastUpdatedById("dummyUserId");
        metadata.setAutoOptOutInd("Y");
        metadata.setOptedOutDuration(30);
        metadata.setOptedOutDateTime("2023-10-01T12:00:00.000Z");
        metadata.setSubscribeToEmail("Y");
        return metadata;
    }

    @Test
    public void testGetProviderPreferencesFDSCloudAsync_2Documents() throws Exception {
        String tin = "123456789";
        String mpin = "111111111";
        String cid = "test-cid";
        List<PreferenceType> preferenceTypeList = new ArrayList<>();
        PreferenceType prefType = new PreferenceType();
        prefType.setClassifier("TEST_CLASSIFIER");
        preferenceTypeList.add(prefType);

        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        doc.setModifiedOn(System.currentTimeMillis());
        doc.setMetadata(String.valueOf(getMetadata()));
        mockResponse.setTotal_records("1");
        mockResponse.setCount("1");

        OptOutFDSCloudDocument doc2 = new OptOutFDSCloudDocument();
        doc2.setModifiedOn(System.currentTimeMillis());
        doc2.setMetadata(String.valueOf(getMetadata()));
        mockResponse.setTotal_records("2");
        mockResponse.setCount("2");
        mockResponse.setDocuments(Arrays.asList(doc,doc2));

        when(mockFdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString()))
                .thenReturn(mockResponse);
        when(mockProviderPreferencesUtil.determineDocumentIndexCloud(anyList(), anyInt(), anyInt(), any(OffsetDateTime.class), eq(cid)))
                .thenReturn(new ProviderPreferencesUtil.AutoEnrollment(true, 0));
        when(mapper.readValue(anyString(), (Class<Metadata>) any())).thenReturn(getMetadata());

        CompletableFuture<List<PreferenceType>> resultFuture = asyncComponent.getProviderPreferencesFDSCloudAsync(tin, mpin, preferenceTypeList, cid);

        assertNotNull(resultFuture);
    }

//    @Test
//    public void testUpdateProviderPreferencesFDSCloudAsync_Success() throws Exception {
//        ProviderPreferencesObj providerPreferences = new ProviderPreferencesObj();
//        providerPreferences.setCorporateName("Test Corp");
//        providerPreferences.setCorporateTin("123456789");
//        providerPreferences.setSelectedProviders(Collections.singletonList("111111111"));
//
//        PreferenceType preferenceType = new PreferenceType();
//        preferenceType.setClassifier("TEST_CLASSIFIER");
//        providerPreferences.setPreferenceTypes(Collections.singletonList(preferenceType));
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("optum-cid-ext", "test-cid");
//
//        doNothing().when(mockNdbHandler).ndbWebServicePrep();
//        doNothing().when(mockFdsCloudHandler).FDSCloudPostRequest(anyString(), any(), anyString());
//
//        asyncComponent.updateProviderPreferencesFDSCloudAsync(providerPreferences, headers);
//
//        verify(mockNdbHandler, times(1)).ndbWebServicePrep();
//        verify(mockFdsCloudHandler, atLeastOnce()).FDSCloudPostRequest(anyString(), any(), anyString());
//    }
//
//    @Test
//    public void testUpdateProviderPreferencesFDSCloudAsync_ExceptionHandling() throws Exception {
//        ProviderPreferencesObj providerPreferences = new ProviderPreferencesObj();
//        providerPreferences.setCorporateName("Test Corp");
//        providerPreferences.setCorporateTin("123456789");
//        providerPreferences.setSelectedProviders(Collections.singletonList("111111111"));
//
//        PreferenceType preferenceType = new PreferenceType();
//        preferenceType.setClassifier("TEST_CLASSIFIER");
//        providerPreferences.setPreferenceTypes(Collections.singletonList(preferenceType));
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("optum-cid-ext", "test-cid");
//
//        doThrow(new ApplicationException("Mock Exception")).when(mockNdbHandler).ndbWebServicePrep();
//
//        try {
//            asyncComponent.updateProviderPreferencesFDSCloudAsync(providerPreferences, headers);
//        } catch (ApplicationException e) {
//            assertEquals("Mock Exception", e.getMessage());
//        }
//
//    }


    @Test
    public void testLoopThroughSomeClassifiers_Success() throws Exception {
        String currentMpin = "123456789";
        String currentTin = "987654321";
        String cid = "test-cid";

        PreferenceType prefType = new PreferenceType();
        prefType.setClassifier("TEST_CLASSIFIER");
        prefType.setDeliveryMethod("EMAIL");

        List<PreferenceType> prefList = Collections.singletonList(prefType);

        FDSCloudRequest mockSearchTerms = mock(FDSCloudRequest.class);
        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        Metadata metadata = getMetadata();
        doc.setMetadata(String.valueOf(metadata));
        mockResponse.setTotal_records("1");
        mockResponse.setCount("1");
        mockResponse.setDocuments(Collections.singletonList(doc));
        asyncComponent = spy(new AsyncComponent());
        asyncComponent.fdsCloudHandler = mockFdsCloudHandler;
        asyncComponent.ndbHandler = mockNdbHandler;
        asyncComponent.provPrefUtil = mockProviderPreferencesUtil;
        asyncComponent.optOutService = mockOptOutService;
        asyncComponent.mapper = mapper;
        asyncComponent.documentService = documentService;

        when(mapper.readValue(anyString(), (Class<Metadata>) any())).thenReturn(metadata);
        when(mockProviderPreferencesUtil.determineDocumentIndexCloud(anyList(), anyInt(), anyInt(), any(OffsetDateTime.class), eq(cid)))
                .thenReturn(new ProviderPreferencesUtil.AutoEnrollment(true, 0));
        when(mockFdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(mockSearchTerms);
        when(mockFdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString())).thenReturn(mockResponse);
        doReturn(0).when(asyncComponent).getDocIndex(
                anyInt(),
                any(ProviderPreferencesUtil.AutoEnrollment.class),
                any(List.class),
                any(OffsetDateTime.class),
                anyString()
        );

        asyncComponent.loopThroughSomeClassifiers(currentMpin, currentTin, prefList, cid);

        verify(mockFdsCloudHandler, times(1)).createSearchTermsRequestFromMap(anyMap());
        verify(mockFdsCloudHandler, times(1)).FDSCloudGetRequest(anyString(), any(), anyString(), anyString());
    }

    @Test
    public void testLoopThroughSomeClassifiers_Success_() throws Exception {
        String currentMpin = "123456789";
        String currentTin = "987654321";
        String cid = "test-cid";

        PreferenceType prefType = new PreferenceType();
        prefType.setClassifier("TEST_CLASSIFIER");
        prefType.setDeliveryMethod("EMAIL");

        List<PreferenceType> prefList = Collections.singletonList(prefType);

        FDSCloudRequest mockSearchTerms = mock(FDSCloudRequest.class);
        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        Metadata metadata = getMetadata();
        doc.setMetadata(String.valueOf(metadata));
        mockResponse.setTotal_records("1");
        mockResponse.setCount("1");
        mockResponse.setDocuments(Collections.singletonList(doc));
        asyncComponent = spy(new AsyncComponent());
        asyncComponent.fdsCloudHandler = mockFdsCloudHandler;
        asyncComponent.ndbHandler = mockNdbHandler;
        asyncComponent.provPrefUtil = mockProviderPreferencesUtil;
        asyncComponent.optOutService = mockOptOutService;
        asyncComponent.mapper = mapper;
        asyncComponent.documentService = documentService;

        when(mapper.readValue(anyString(), (Class<Metadata>) any())).thenReturn(metadata);
        when(mockProviderPreferencesUtil.determineDocumentIndexCloud(anyList(), anyInt(), anyInt(), any(OffsetDateTime.class), eq(cid)))
                .thenReturn(new ProviderPreferencesUtil.AutoEnrollment(true, 0));
        when(mockFdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(mockSearchTerms);
        when(mockFdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString())).thenReturn(mockResponse);
        doReturn(-2).when(asyncComponent).getDocIndex(
                anyInt(),
                any(ProviderPreferencesUtil.AutoEnrollment.class),
                any(List.class),
                any(OffsetDateTime.class),
                anyString()
        );

        asyncComponent.loopThroughSomeClassifiers(currentMpin, currentTin, prefList, cid);

        verify(mockFdsCloudHandler, times(1)).createSearchTermsRequestFromMap(anyMap());
        verify(mockFdsCloudHandler, times(1)).FDSCloudGetRequest(anyString(), any(), anyString(), anyString());
    }


    @Test
    public void testLoopThroughAllClassifiers_Success() throws Exception {
        String currentMpin = "123456789";
        String currentTin = "987654321";
        String cid = "test-cid";

        PreferenceType masterPref = new PreferenceType();
        masterPref.setClassifier("MASTER_CLASSIFIER");
        masterPref.setDeliveryMethod("EMAIL");

        List<String> classifierList = Arrays.asList("CLASSIFIER_1", "CLASSIFIER_2", "CLASSIFIER_3");

        FDSCloudRequest mockSearchTerms = mock(FDSCloudRequest.class);
        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        Metadata metadata = getMetadata();
        doc.setMetadata(String.valueOf(metadata));
        mockResponse.setTotal_records("1");
        mockResponse.setCount("1");
        mockResponse.setDocuments(Collections.singletonList(doc));
        asyncComponent = spy(new AsyncComponent());
        asyncComponent.fdsCloudHandler = mockFdsCloudHandler;
        asyncComponent.ndbHandler = mockNdbHandler;
        asyncComponent.provPrefUtil = mockProviderPreferencesUtil;
        asyncComponent.optOutService = mockOptOutService;
        asyncComponent.mapper = mapper;
        asyncComponent.documentService = documentService;

        when(mapper.readValue(anyString(), (Class<Metadata>) any())).thenReturn(metadata);
        when(mockProviderPreferencesUtil.determineDocumentIndexCloud(anyList(), anyInt(), anyInt(), any(OffsetDateTime.class), eq(cid)))
                .thenReturn(new ProviderPreferencesUtil.AutoEnrollment(true, 0));
        when(mockFdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(mockSearchTerms);
        when(mockFdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString())).thenReturn(mockResponse);
        doReturn(0).when(asyncComponent).getDocIndex(
                anyInt(),
                any(ProviderPreferencesUtil.AutoEnrollment.class),
                any(List.class),
                any(OffsetDateTime.class),
                anyString()
        );
        CompletableFuture<List<String>> resultFuture = asyncComponent.loopThroughAllClassifiers(currentMpin, currentTin, masterPref, classifierList, cid);

        assertNotNull(resultFuture);
        List<String> result = resultFuture.get();
        assertEquals(classifierList.size(), result.size());
        verify(mockFdsCloudHandler, times(classifierList.size())).FDSCloudGetRequest(anyString(), any(), anyString(), anyString());
    }

    @Test
    public void testLoopThroughAllClassifiers_Success_docIndex() throws Exception {
        String currentMpin = "123456789";
        String currentTin = "987654321";
        String cid = "test-cid";

        PreferenceType masterPref = new PreferenceType();
        masterPref.setClassifier("MASTER_CLASSIFIER");
        masterPref.setDeliveryMethod("EMAIL");

        List<String> classifierList = Arrays.asList("CLASSIFIER_1", "CLASSIFIER_2", "CLASSIFIER_3");
        
        FDSCloudRequest mockSearchTerms = mock(FDSCloudRequest.class);
        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        Metadata metadata = getMetadata();
        doc.setMetadata(String.valueOf(metadata));
        mockResponse.setTotal_records("1");
        mockResponse.setCount("1");
        mockResponse.setDocuments(Collections.singletonList(doc));
        asyncComponent = spy(new AsyncComponent());
        asyncComponent.fdsCloudHandler = mockFdsCloudHandler;
        asyncComponent.ndbHandler = mockNdbHandler;
        asyncComponent.provPrefUtil = mockProviderPreferencesUtil;
        asyncComponent.optOutService = mockOptOutService;
        asyncComponent.mapper = mapper;
        asyncComponent.documentService = documentService;

        when(mapper.readValue(anyString(), (Class<Metadata>) any())).thenReturn(metadata);
        when(mockProviderPreferencesUtil.determineDocumentIndexCloud(anyList(), anyInt(), anyInt(), any(OffsetDateTime.class), eq(cid)))
                .thenReturn(new ProviderPreferencesUtil.AutoEnrollment(true, 0));
        when(mockFdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(mockSearchTerms);
        when(mockFdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString())).thenReturn(mockResponse);
        doReturn(-2).when(asyncComponent).getDocIndex(
                anyInt(),
                any(ProviderPreferencesUtil.AutoEnrollment.class),
                any(List.class),
                any(OffsetDateTime.class),
                anyString()
        );
        CompletableFuture<List<String>> resultFuture = asyncComponent.loopThroughAllClassifiers(currentMpin, currentTin, masterPref, classifierList, cid);

        assertNotNull(resultFuture);
        List<String> result = resultFuture.get();
        assertEquals(classifierList.size(), result.size());
        verify(mockFdsCloudHandler, times(classifierList.size())).FDSCloudGetRequest(anyString(), any(), anyString(), anyString());
    }

    @Test
    public void testLoopThroughAllClassifiers_ExceptionHandling() throws Exception {
        String currentMpin = "123456789";
        String currentTin = "987654321";
        String cid = "test-cid";

        PreferenceType masterPref = new PreferenceType();
        masterPref.setClassifier("MASTER_CLASSIFIER");
        masterPref.setDeliveryMethod("EMAIL");

        List<String> classifierList = Arrays.asList("CLASSIFIER_1", "CLASSIFIER_2", "CLASSIFIER_3");

        doThrow(new RuntimeException("Mock Exception")).when(mockFdsCloudHandler).FDSCloudGetRequest(anyString(), any(), anyString(), anyString());

        try {
            asyncComponent.loopThroughAllClassifiers(currentMpin, currentTin, masterPref, classifierList, cid);
            fail("Expected RuntimeException to be thrown");
        } catch (Exception e) {
//            assertTrue(e.getCause() instanceof RuntimeException);
//            assertEquals("Mock Exception", e.getCause().getMessage());
        }

        verify(mockFdsCloudHandler, times(1)).FDSCloudGetRequest(anyString(), any(), anyString(), anyString());
    }

    @Test
    public void testSendFDSCloudPostRequest_Success() throws ApplicationException {
        FDSCloudRequest postRequest = new FDSCloudRequest();
        String cid = "test-cid";

        when(mockFdsCloudHandler.FDSCloudPostRequest(anyString(), any(FDSCloudRequest.class), anyString()))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));

        asyncComponent.sendFDSCloudPostRequest(postRequest, cid);

        verify(mockFdsCloudHandler, times(1)).FDSCloudPostRequest(anyString(), eq(postRequest), eq(cid));
    }

    @Test
    public void testSendFDSCloudPostRequest_ExceptionHandling() throws ApplicationException {
        FDSCloudRequest postRequest = new FDSCloudRequest();
        String cid = "test-cid";

        doThrow(new RuntimeException("Mock Exception")).when(mockFdsCloudHandler).FDSCloudPostRequest(anyString(), any(), anyString());

        asyncComponent.sendFDSCloudPostRequest(postRequest, cid);

        verify(mockFdsCloudHandler, times(1)).FDSCloudPostRequest(anyString(), eq(postRequest), eq(cid));
    }

    @Test
    public void testSendFDSCloudPutRequest_Success() throws ApplicationException {
        FDSCloudRequest postRequest = new FDSCloudRequest();
        String cid = "test-cid";

        when(mockFdsCloudHandler.FDSCloudPutRequest(anyString(), any(FDSCloudRequest.class), anyString()))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));

        asyncComponent.sendFDSCloudPutRequest(postRequest, "docid", cid);

        verify(mockFdsCloudHandler, times(1)).FDSCloudPutRequest(anyString(), eq(postRequest), eq(cid));
    }

    @Test
    public void testSendFDSCloudPutRequest_ExceptionHandling() throws ApplicationException {
        FDSCloudRequest postRequest = new FDSCloudRequest();
        String cid = "test-cid";

        doThrow(new RuntimeException("Mock Exception")).when(mockFdsCloudHandler).FDSCloudPutRequest(anyString(), any(), anyString());

        asyncComponent.sendFDSCloudPutRequest(postRequest, "docid", cid);

        verify(mockFdsCloudHandler, times(1)).FDSCloudPutRequest(anyString(), eq(postRequest), eq(cid));
    }

    @Test
    public void testUpdateOptOutDocumentsVoid_Success() throws Exception {
        OptOutRequest optOutRequest = new OptOutRequest();
        optOutRequest.setCorpMpin("123456");
        optOutRequest.setTin("987654");
        optOutRequest.setLastUpdatedBy("TestUser");
        optOutRequest.setLastUpdatedById("TestUserId");
        optOutRequest.setOptedOutDuration(30);
        optOutRequest.setProviderMpins(Collections.emptyList());
        optOutRequest.setCategories(Arrays.asList("CATEGORY_1", "CATEGORY_2"));

        CorpMpinResponse corpMpinResponse = new CorpMpinResponse();
        ResponseData responseData = new ResponseData();
        MpinData mpinData = new MpinData();
        mpinData.setProviderId("7890");
        responseData.setMpinList(Collections.singletonList(mpinData));
        corpMpinResponse.setResponse(responseData);

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        Map<String, List<String>> mockDocumentIds = new HashMap<>();
        mockDocumentIds.put("DOC_ID_1", Arrays.asList("DATA_1", "DATA_2"));
        mockDocumentIds.put("DOC_ID_2", Arrays.asList("DATA_3", "DATA_4"));

        when(mockOptOutService.getDocuments(anyList(), anyList(), anyString(), anyString()))
                .thenReturn(mockDocumentIds);
        doNothing().when(mockOptOutService).updateDeliveryMethodNDB(anyList(), anyList(), anyString(), anyString());
        when(mockOptOutService.createOptOutDocument(anyList(), anyString(), anyString(), anyInt())).thenReturn( new HashMap<>());
        when(mockNdbHandler.getProviderData(any(), any())).thenReturn(corpMpinResponse);
        asyncComponent.updateOptOutDocumentsVoid(optOutRequest, headers, "test-cid");

        verify(mockOptOutService, times(1)).updateDeliveryMethodNDB(anyList(), anyList(), anyString(), anyString());
        verify(mockOptOutService, times(1)).getDocuments(anyList(), anyList(), anyString(), anyString());
        verify(mockOptOutService, times(mockDocumentIds.size())).createOptOutDocument(anyList(), anyString(), anyString(), anyInt());
    }

    @Test
    public void testUpdateOptOutDocumentsVoid_ExceptionHandling() throws Exception {
        OptOutRequest optOutRequest = new OptOutRequest();
        optOutRequest.setCorpMpin("123456");
        optOutRequest.setTin("987654");
        optOutRequest.setLastUpdatedBy("TestUser");
        optOutRequest.setLastUpdatedById("TestUserId");
        optOutRequest.setOptedOutDuration(30);
        optOutRequest.setProviderMpins(Arrays.asList("111111", "222222"));
        optOutRequest.setCategories(Arrays.asList("CATEGORY_1", "CATEGORY_2"));

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        when(mockOptOutService.getDocuments(anyList(), anyList(), anyString(), anyString()))
                .thenThrow(new ApplicationException("Mock Exception"));

        try {
            asyncComponent.updateOptOutDocumentsVoid(optOutRequest, headers, "test-cid");
            fail("Expected ApplicationException to be thrown");
        } catch (ApplicationException e) {
            assertEquals("Mock Exception", e.getMessage());
        }

        verify(mockOptOutService, times(1)).getDocuments(anyList(), anyList(), anyString(), anyString());
    }


    @Test
    public void testFormatDate() {
        Date date = new Date();

        String formattedDate = asyncComponent.formatDate(date);

        assertNotNull(formattedDate);
        assertTrue(formattedDate.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z"));
    }

    @Test
    public void testParseDateString_Valid() throws ParseException {
        String dateString = "2023-10-01T12:00:00.000Z";

        Date parsedDate = asyncComponent.parseDateString(dateString);

        assertNotNull(parsedDate);
    }

    @Test(expected = ParseException.class)
    public void testParseDateString_Invalid() throws ParseException {
        String invalidDateString = "invalid-date";

        asyncComponent.parseDateString(invalidDateString);
    }

    @Test
    public void testGetProviderPreferenceRequest() throws ParseException {
        OONRequestModel oonRequest = new OONRequestModel();
        oonRequest.setCorpOwnerId("CorpName");
        oonRequest.setTaxIdNumber("123456");
        oonRequest.setConvertToElectronic(true);
        oonRequest.setProviderEmail("test@example.com");

        List<String> classifiers = Arrays.asList("CLASSIFIER_1", "CLASSIFIER_2");

        ProviderPreferencesObj result = asyncComponent.getProviderPreferenceRequest(oonRequest, "MPIN123", classifiers);

        assertNotNull(result);
        assertEquals("CorpName", result.getCorporateName());
        assertEquals("123456", result.getCorporateTin());
        assertEquals(2, result.getPreferenceTypes().size());
    }

    @Test
    public void testGetProviderPreferenceRequest_FlagFalse() throws ParseException {
        OONRequestModel oonRequest = new OONRequestModel();
        oonRequest.setCorpOwnerId("CorpName");
        oonRequest.setTaxIdNumber("123456");
        oonRequest.setConvertToElectronic(false);
        oonRequest.setProviderEmail("test@example.com");

        List<String> classifiers = Arrays.asList("CLASSIFIER_1", "CLASSIFIER_2");

        ProviderPreferencesObj result = asyncComponent.getProviderPreferenceRequest(oonRequest, "MPIN123", classifiers);

        assertNotNull(result);
        assertEquals("CorpName", result.getCorporateName());
        assertEquals("123456", result.getCorporateTin());
        assertEquals(2, result.getPreferenceTypes().size());
    }

    @Test
    public void testGetMpinsFromResponse_Valid() throws ApplicationException {
        CorpMpinResponse response = new CorpMpinResponse();
        MpinData mpinData = new MpinData();
        mpinData.setProviderId("123");
        response.setResponse(new com.optum.providerpreferences.rs.model.ndb.provider.ResponseData());
        response.getResponse().setMpinList(Collections.singletonList(mpinData));

        when(mockProviderPreferencesUtil.padWithLeadingZeros("123")).thenReturn("00123");

        List<String> mpins = asyncComponent.getMpinsFromResponse(response);

        assertNotNull(mpins);
        assertEquals(1, mpins.size());
        assertEquals("00123", mpins.get(0));
    }

    @Test
    public void testGetMpinsFromResponse_NullResponse() throws ApplicationException {
        List<String> mpins = asyncComponent.getMpinsFromResponse(null);

        assertNull(mpins);
    }

    @Test
    public void testGetPrintDeliveryClassifier() {
        MailPref mailPref1 = new MailPref();
        mailPref1.setLetterType("C1");
        mailPref1.setMailingPref("P");
        MailPref mailPref2 = new MailPref();
        mailPref2.setLetterType("C2");
        mailPref2.setMailingPref("E");

        List<MailPref> mailPrefs = Arrays.asList(mailPref1, mailPref2);

        List<String> classifiers = asyncComponent.getPrintDeliveryClassifier(mailPrefs);

        assertNotNull(classifiers);
        assertEquals(1, classifiers.size());
        assertTrue(classifiers.contains("C1"));
    }


    @Test
    public void testUpdatePopup_Success() throws Exception {
        List<String> mpinList = Arrays.asList("MPIN1", "MPIN2");
        OONRequestModel oonRequest = new OONRequestModel();
        oonRequest.setTaxIdNumber("123456");
        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");
        asyncComponent = spy(new AsyncComponent());
        asyncComponent.ndbHandler = mockNdbHandler;
        asyncComponent.documentService = documentService;

        LetterPreferencesResponse mockResponse = new LetterPreferencesResponse();
        mockResponse.setRequestResponse(new com.optum.providerpreferences.rs.model.ndb.preferences.ResponseData());
        mockResponse.getRequestResponse().setLtrTypMailPrfList(Collections.emptyList());
        doNothing().when(mockNdbHandler).ndbWebServicePrep();
        doNothing().when(asyncComponent).updateProviderPreferencesFDSCloudAsync(any(), any());
        when(mockNdbHandler.getProviderLetterPreferences(any(), anyString())).thenReturn(mockResponse);

        asyncComponent.updatePopup(mpinList, oonRequest, headers);

        verify(mockNdbHandler, times(mpinList.size())).getProviderLetterPreferences(any(), anyString());
    }


    @Test
    public void testGetDocIndex_SingleDocument_ValidAutoEnrollment() throws IOException {
        int lenDocs = 1;
        ProviderPreferencesUtil.AutoEnrollment mockDoc0 = mock(ProviderPreferencesUtil.AutoEnrollment.class);
        List<OptOutFDSCloudDocument> mockResponse = mock(List.class);
        OffsetDateTime currentDate = OffsetDateTime.now();
        String cid = "test-cid";

        when(mockDoc0.isValidAutoEnrollment()).thenReturn(true);
        when(mockDoc0.isAutoEnrollment()).thenReturn(true);

        int docIndex = asyncComponent.getDocIndex(lenDocs, mockDoc0, mockResponse, currentDate, cid);

        assertEquals(0, docIndex);
    }

    @Test
    public void testGetDocIndex_SingleDocument_InvalidAutoEnrollment() throws IOException {
        int lenDocs = 1;
        ProviderPreferencesUtil.AutoEnrollment mockDoc0 = mock(ProviderPreferencesUtil.AutoEnrollment.class);
        List<OptOutFDSCloudDocument> mockResponse = mock(List.class);
        OffsetDateTime currentDate = OffsetDateTime.now();
        String cid = "test-cid";

        when(mockDoc0.isValidAutoEnrollment()).thenReturn(false);
        when(mockDoc0.isAutoEnrollment()).thenReturn(true);

        int docIndex = asyncComponent.getDocIndex(lenDocs, mockDoc0, mockResponse, currentDate, cid);

        assertEquals(-1, docIndex);
    }

    @Test
    public void testGetDocIndex_TwoDocuments() throws IOException {
        int lenDocs = 2;
        ProviderPreferencesUtil.AutoEnrollment mockDoc0 = mock(ProviderPreferencesUtil.AutoEnrollment.class);
        ProviderPreferencesUtil.AutoEnrollment mockDoc1 = mock(ProviderPreferencesUtil.AutoEnrollment.class);
        List<OptOutFDSCloudDocument> mockResponse = mock(List.class);
        OffsetDateTime currentDate = OffsetDateTime.now();
        String cid = "test-cid";

        when(mockProviderPreferencesUtil.determineDocumentIndexCloud(mockResponse, lenDocs, 1, currentDate, cid))
                .thenReturn(mockDoc1);
        when(mockProviderPreferencesUtil.determineMulti(mockDoc0, mockDoc1)).thenReturn(1);

        int docIndex = asyncComponent.getDocIndex(lenDocs, mockDoc0, mockResponse, currentDate, cid);

        assertEquals(1, docIndex);
    }

    @Test
    public void loopThroughSomeClassifiers_PassesSecondaryEmailsToBuilder() throws Exception {
        String currentMpin = "123456789";
        String currentTin = "987654321";
        String cid = "test-cid";

        PreferenceType prefType = new PreferenceType();
        prefType.setClassifier("TEST_CLASSIFIER");
        prefType.setDeliveryMethod("EMAIL");

        List<PreferenceType> prefList = Collections.singletonList(prefType);
        List<String> secondaryEmails = Arrays.asList("ops@example.com", "billing@example.org");
        prefType.setSecondaryProviderEmailIds(secondaryEmails);

        // Common FDS search stubs
        FDSCloudRequest mockSearchTerms = mock(FDSCloudRequest.class);
        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        Metadata metadata = getMetadata();
        doc.setMetadata(String.valueOf(metadata));
        mockResponse.setTotal_records("1");
        mockResponse.setCount("1");
        mockResponse.setDocuments(Collections.singletonList(doc));

        asyncComponent = spy(new AsyncComponent());
        asyncComponent.fdsCloudHandler = mockFdsCloudHandler;
        asyncComponent.ndbHandler = mockNdbHandler;
        asyncComponent.provPrefUtil = mockProviderPreferencesUtil;
        asyncComponent.optOutService = mockOptOutService;
        asyncComponent.mapper = mapper;
        asyncComponent.documentService = documentService;

        when(mapper.readValue(anyString(), (Class<Metadata>) any())).thenReturn(metadata);
        when(mockProviderPreferencesUtil.determineDocumentIndexCloud(anyList(), anyInt(), anyInt(), any(OffsetDateTime.class), eq(cid)))
                .thenReturn(new ProviderPreferencesUtil.AutoEnrollment(true, 0));
        when(mockFdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(mockSearchTerms);
        when(mockFdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString())).thenReturn(mockResponse);
        doReturn(0).when(asyncComponent).getDocIndex(anyInt(), any(ProviderPreferencesUtil.AutoEnrollment.class), any(List.class), any(OffsetDateTime.class), anyString());

		ArgumentCaptor<PreferenceType> prefCaptor = ArgumentCaptor.forClass(PreferenceType.class);

		when(mockProviderPreferencesUtil.createDocToSendCloud(prefCaptor.capture(), anyString(), anyString(), any(),
				any(), any())).thenReturn(new HashMap<>());

        when(mockProviderPreferencesUtil.padWithLeadingZeros(anyString())).thenAnswer(inv -> inv.getArgument(0));

        when(mockFdsCloudHandler.FDSCloudPutRequest(anyString(), any(FDSCloudRequest.class), anyString()))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));
        when(mockFdsCloudHandler.FDSCloudPostRequest(anyString(), any(FDSCloudRequest.class), anyString()))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));

        // Act
        asyncComponent.loopThroughSomeClassifiers(currentMpin, currentTin, prefList, cid);

        PreferenceType captured = prefCaptor.getValue();
		assertNotNull(captured);
		assertNotNull(captured.getSecondaryProviderEmailIds());
		assertEquals(secondaryEmails, captured.getSecondaryProviderEmailIds());

		verify(mockProviderPreferencesUtil, atLeastOnce()).createDocToSendCloud(any(PreferenceType.class), anyString(),
				anyString(), any(), any(), any());
    }
    
	@Test
	public void loopThroughSomeClassifiers_NullSecondaryEmails_PassesEmptyListToBuilder() throws Exception {
		String currentMpin = "123456789";
		String currentTin = "987654321";
		String cid = "test-cid";

		PreferenceType prefType = new PreferenceType();
		prefType.setClassifier("TEST_CLASSIFIER");
		prefType.setDeliveryMethod("EMAIL");

		List<PreferenceType> prefList = Collections.singletonList(prefType);
		List<String> secondaryEmails = null; 
		prefType.setSecondaryProviderEmailIds(Collections.emptyList());

		FDSCloudRequest mockSearchTerms = mock(FDSCloudRequest.class);
		FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
		OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
		Metadata metadata = getMetadata();
		doc.setMetadata(String.valueOf(metadata));
		mockResponse.setTotal_records("1");
		mockResponse.setCount("1");
		mockResponse.setDocuments(Collections.singletonList(doc));

		asyncComponent = spy(new AsyncComponent());
		asyncComponent.fdsCloudHandler = mockFdsCloudHandler;
		asyncComponent.ndbHandler = mockNdbHandler;
		asyncComponent.provPrefUtil = mockProviderPreferencesUtil;
		asyncComponent.optOutService = mockOptOutService;
		asyncComponent.mapper = mapper;
    asyncComponent.documentService = documentService;

		when(mapper.readValue(anyString(), (Class<Metadata>) any())).thenReturn(metadata);
		when(mockProviderPreferencesUtil.determineDocumentIndexCloud(anyList(), anyInt(), anyInt(),
				any(OffsetDateTime.class), eq(cid))).thenReturn(new ProviderPreferencesUtil.AutoEnrollment(true, 0));
		when(mockFdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(mockSearchTerms);
		when(mockFdsCloudHandler.FDSCloudGetRequest(anyString(), any(), anyString(), anyString()))
				.thenReturn(mockResponse);
		doReturn(0).when(asyncComponent).getDocIndex(anyInt(), any(ProviderPreferencesUtil.AutoEnrollment.class),
				any(List.class), any(OffsetDateTime.class), anyString());

		ArgumentCaptor<PreferenceType> prefCaptor = ArgumentCaptor.forClass(PreferenceType.class);
		when(mockProviderPreferencesUtil.createDocToSendCloud(prefCaptor.capture(), anyString(), anyString(), any(),
				any(), any())).thenReturn(new HashMap<>());

		when(mockProviderPreferencesUtil.padWithLeadingZeros(anyString())).thenAnswer(inv -> inv.getArgument(0));
		when(mockFdsCloudHandler.FDSCloudPutRequest(anyString(), any(FDSCloudRequest.class), anyString()))
				.thenReturn(new ResponseEntity<>(HttpStatus.OK));
		when(mockFdsCloudHandler.FDSCloudPostRequest(anyString(), any(FDSCloudRequest.class), anyString()))
				.thenReturn(new ResponseEntity<>(HttpStatus.OK));

		// Act
		asyncComponent.loopThroughSomeClassifiers(currentMpin, currentTin, prefList, cid);
		
		PreferenceType captured = prefCaptor.getValue();
		assertNotNull(captured);
		assertNotNull(captured.getSecondaryProviderEmailIds());
		assertTrue(captured.getSecondaryProviderEmailIds().isEmpty());
	}

}