package com.optum.providerpreferences.rs.service;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.mongo.document.DeliveryPreference;

@RunWith(MockitoJUnitRunner.class)
public class DocumentServiceImplTest {

	@Mock
	private MongoTemplate mongoTemplate;

	@InjectMocks
	private DocumentServiceImpl documentService;

	private DeliveryPreference document;

	@Before
	public void setUp() {
		document = new DeliveryPreference();
		document.setDocumentId("doc-123");
		document.setClassifier("A");
		document.setTin("123456789");
		document.setLob("Commercial");
		document.setDateCreated(new Date());
		document.setDateModified(new Date());
	}

	@Test
	public void createDocument_success() throws ApplicationException {
		when(mongoTemplate.insert(any(DeliveryPreference.class), any(String.class))).thenReturn(document);

		DeliveryPreference result = documentService.createDocument(document);

		assertNotNull(result);
		assertNotNull(result.getDocumentId());
		verify(mongoTemplate, times(1)).insert(any(DeliveryPreference.class), any(String.class));
	}

	@Test
	public void getDocumentById_success() throws ApplicationException {
		when(mongoTemplate.findOne(any(Query.class), eq(DeliveryPreference.class), any(String.class)))
				.thenReturn(document);

		DeliveryPreference result = documentService.getDocumentById("doc-123");

		assertNotNull(result);
		assertEquals("doc-123", result.getDocumentId());
	}

	@Test(expected = ApplicationException.class)
	public void getDocumentById_notFound() throws ApplicationException {
		when(mongoTemplate.findOne(any(Query.class), eq(DeliveryPreference.class), any(String.class)))
				.thenReturn(null);

		documentService.getDocumentById("doc-404");
	}

	@Test
	public void deleteDocument_success() throws ApplicationException {
		when(mongoTemplate.findOne(any(Query.class), eq(DeliveryPreference.class), any(String.class)))
				.thenReturn(document);

		documentService.deleteDocument("doc-123");
		verify(mongoTemplate, times(1)).remove(document, "deliveryPreference");
	}
	
	@Test(expected = ApplicationException.class)
	public void createDocument_exception() throws ApplicationException {
		when(mongoTemplate.insert(any(DeliveryPreference.class), anyString())).thenThrow(new RuntimeException());

		documentService.createDocument(document);
	}
	
	@Test
	public void updateDocument_success() throws ApplicationException {

		DeliveryPreference existing = new DeliveryPreference();
		existing.setId("1");
		DeliveryPreference updated = new DeliveryPreference();
		updated.setClassifier("NEW");
		when(mongoTemplate.findOne(any(Query.class), eq(DeliveryPreference.class), anyString())).thenReturn(existing);
		when(mongoTemplate.save(any(DeliveryPreference.class), anyString())).thenReturn(existing);
		DeliveryPreference result = documentService.updateDocument("1", updated);

		assertEquals("NEW", result.getClassifier());
		verify(mongoTemplate).save(any(DeliveryPreference.class), anyString());
	}
	
	@Test(expected = ApplicationException.class)
	public void updateDocument_notFound() throws ApplicationException {

	    when(mongoTemplate.findOne(any(Query.class), eq(DeliveryPreference.class), anyString()))
	            .thenReturn(null);

	    documentService.updateDocument("1", new DeliveryPreference());
	}
}