package com.optum.providerpreferences.rs.optout;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.PDOConstants;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.service.OptOutService;
import org.apache.logging.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.*;

public class SchedulerOptOutTest {

    @InjectMocks
    private SchedulerOptOut schedulerOptOut;

    @Mock
    private OptOutService optOutService;

    @Mock
    private FDSCloudHandler fdsCloudHandler;

    @Mock
    private NDBHandler ndbHandler;

    @Mock
    private Logger logger;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testRevertExpiredOptOutDocuments() throws Exception {
        // Arrange
        FDSCloudGETResponse mockResponse = mock(FDSCloudGETResponse.class);
        OptOutFDSCloudDocument mockDocument = mock(OptOutFDSCloudDocument.class);
        Map<String, Object> mockMetadata = new HashMap<>();
        mockMetadata.put(PDOConstants.MPIN, "12345");
        mockMetadata.put(PDOConstants.TIN, "67890");
        mockMetadata.put(PDOConstants.FILENAME, "testFile");

        when(mockResponse.getDocuments()).thenReturn(Collections.singletonList(mockDocument));
        when(mockDocument.getMetadata()).thenReturn("{\"mpin\":\"12345\",\"tin\":\"67890\",\"filename\":\"testFile\"}");
        when(fdsCloudHandler.getSearchTermsFromString(anyString())).thenReturn(mockMetadata);
        when(optOutService.getOptOutAuditLog(anyString(), any())).thenReturn(mockResponse);

        // Act
        schedulerOptOut.revertExpiredOptOutDocuments();

        // Assert
        verify(optOutService, times(1)).getOptOutAuditLog(anyString(), any());
        verify(ndbHandler, times(1)).updateProviderLetterPreferences(any(), eq("12345"), eq("67890"), anyString());
        verify(fdsCloudHandler, times(1)).FDSCloudPutRequest(anyString(), any(), anyString());
    }


}