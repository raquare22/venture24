package com.optum.providerpreferences.rs.mongo.document;

import static org.junit.Assert.*;
import java.util.Date;
import org.junit.Test;
import com.optum.providerpreferences.rs.mongo.document.DeliveryPreference;

public class DeliveryPreferenceTest {

	@Test
	public void testGettersAndSetters() {

		DeliveryPreference dp = new DeliveryPreference();

		Date now = new Date();

		dp.setId("1");
		dp.setClassifier("classifier");
		dp.setTin("tin");
		dp.setMpin("mpin");
		dp.setCorporateMpin("corpMpin");
		dp.setTinType("type");
		dp.setLob("lob");
		dp.setDescription("desc");
		dp.setDocumentId("docId");
		dp.setDeliveryMethod("EMAIL");
		dp.setOkToChangePdoInd("Y");
		dp.setSubscribeToEmail("Y");
		dp.setProviderEmailId("test@email.com");
		dp.setDateCreated(now);
		dp.setDateModified(now);

		assertEquals("1", dp.getId());
		assertEquals("classifier", dp.getClassifier());
		assertEquals("tin", dp.getTin());
		assertEquals("mpin", dp.getMpin());
		assertEquals("corpMpin", dp.getCorporateMpin());
		assertEquals("type", dp.getTinType());
		assertEquals("lob", dp.getLob());
		assertEquals("desc", dp.getDescription());
		assertEquals("docId", dp.getDocumentId());
		assertEquals("EMAIL", dp.getDeliveryMethod());
		assertEquals("Y", dp.getOkToChangePdoInd());
		assertEquals("Y", dp.getSubscribeToEmail());
		assertEquals("test@email.com", dp.getProviderEmailId());
		assertEquals(now, dp.getDateCreated());
		assertEquals(now, dp.getDateModified());
	}

	@Test
	public void testNullValues() {

		DeliveryPreference dp = new DeliveryPreference();

		dp.setId(null);

		assertNull(dp.getId());
	}
}
