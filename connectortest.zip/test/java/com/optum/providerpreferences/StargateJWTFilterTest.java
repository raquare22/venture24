package com.optum.providerpreferences;

import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.mockito.*;

import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

import static org.mockito.Mockito.*;

public class StargateJWTFilterTest {

	@InjectMocks
	private StargateJWTFilter filter;

	@Mock
	private StargateJWTValidator validator;

	@Mock
	private HttpServletRequest request;

	@Mock
	private HttpServletResponse response;

	@Mock
	private FilterChain chain;

	@Before
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}

	// ✅ 1. Filter disabled → should skip everything
	@Test
	public void testFilterDisabled() throws Exception {

		ReflectionTestUtils.setField(filter, "isFilterEnabled", false);

		filter.doFilter(request, response, chain);

		verify(chain).doFilter(request, response);
		verifyNoInteractions(validator);
	}

	// ✅ 2. Logger endpoint → should skip validation
	@Test
	public void testLoggerURI() throws Exception {

		ReflectionTestUtils.setField(filter, "isFilterEnabled", true);

		when(request.getRequestURI()).thenReturn("/api/loggers/v1/test");

		filter.doFilter(request, response, chain);

		verify(chain).doFilter(request, response);
		verifyNoInteractions(validator);
	}

	// ✅ 3. Missing JWT → 401
	@Test
	public void testMissingJWT() throws Exception {

		ReflectionTestUtils.setField(filter, "isFilterEnabled", true);

		when(request.getRequestURI()).thenReturn("/api/test");
		when(request.getHeader("JWT")).thenReturn(null);

		filter.doFilter(request, response, chain);

		verify(response).sendError(HttpServletResponse.SC_UNAUTHORIZED, "JWT missing in request header.");
		verify(chain, never()).doFilter(any(), any());
	}

	// ✅ 4. Valid JWT → validator called + chain continues
	@Test
	public void testValidJWT() throws Exception {

		ReflectionTestUtils.setField(filter, "isFilterEnabled", true);

		when(request.getRequestURI()).thenReturn("/api/test");
		when(request.getHeader("JWT")).thenReturn("valid.jwt");

		doNothing().when(validator).validateJWT(anyString());

		filter.doFilter(request, response, chain);

		verify(validator).validateJWT("valid.jwt");
		verify(chain).doFilter(request, response);
	}

	// ✅ 5. Invalid JWT → IllegalArgumentException → 401
	@Test
	public void testInvalidJWT() throws Exception {

		ReflectionTestUtils.setField(filter, "isFilterEnabled", true);

		when(request.getRequestURI()).thenReturn("/api/test");
		when(request.getHeader("JWT")).thenReturn("invalid.jwt");

		doThrow(new IllegalArgumentException("bad token")).when(validator).validateJWT(anyString());

		filter.doFilter(request, response, chain);

		verify(response).sendError(eq(HttpServletResponse.SC_UNAUTHORIZED), contains("Invalid JWT"));
		verify(chain, never()).doFilter(any(), any());
	}

	// ✅ 6. Generic Exception → 500
	@Test
	public void testGenericException() throws Exception {

		ReflectionTestUtils.setField(filter, "isFilterEnabled", true);

		when(request.getRequestURI()).thenReturn("/api/test");
		when(request.getHeader("JWT")).thenReturn("error.jwt");

		doThrow(new RuntimeException("something wrong")).when(validator).validateJWT(anyString());

		filter.doFilter(request, response, chain);

		verify(response).sendError(eq(HttpServletResponse.SC_INTERNAL_SERVER_ERROR),
				eq("An unexpected error occurred.")
		);
		verify(chain, never()).doFilter(any(), any());
	}
}