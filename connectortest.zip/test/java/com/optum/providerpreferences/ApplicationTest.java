package com.optum.providerpreferences;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.handler.RequestFactory; // Added import for RequestFactory

public class ApplicationTest {

    @Test
    public void testGetMapper() {
        Application application = new Application();
        ObjectMapper mapper = application.getMapper();
        assertNotNull("ObjectMapper bean should not be null", mapper);
    }

//    @Test
//    public void testGetRestTemplate() {
//        Application application = new Application();
//        RestTemplate restTemplate = application.getRestTemplate();
//        assertNotNull("RestTemplate bean should not be null", restTemplate);
//    }

    @Test
    public void testGetHttpHeaders() {
        Application application = new Application();
        HttpHeaders httpHeaders = application.getHttpHeaders();
        assertNotNull("HttpHeaders bean should not be null", httpHeaders);
    }

//    @Test
//    public void testGetRequestFactory() {
//        Application application = new Application();
//        RequestFactory requestFactory = application.getRequestFactory();
//        assertNotNull("RequestFactory bean should not be null", requestFactory);
//    }
}