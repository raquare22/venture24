package com.optum.providerpreferences;

import org.junit.Test;
import org.mockito.Mockito;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class HeaderFilterTest {

    @Test
    public void testHeaderFilterTest() throws IOException, ServletException {

        //creating mock for request, response, and filterChain
        ServletRequest request = Mockito.mock(ServletRequest.class);
        HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
        FilterChain filterChain = Mockito.mock(FilterChain.class);

        //instance of HeaderFilter Class
        HeaderFilter headerFilter = new HeaderFilter();
        headerFilter.doFilter(request, response, filterChain);

        //verifying that desired header values are set
        Mockito.verify(response).setHeader("X-Frame-Options", "DENY");
        Mockito.verify(response).setHeader("X-XSS-Protection", "1; mode=block");
        Mockito.verify(response).setHeader("X-Content-Type-Options", "nosniff");
        Mockito.verify(response).setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");
        Mockito.verify(response).setHeader("Referrer-Policy", "no-referrer");
        Mockito.verify(response).setHeader("Permissions-Policy", "geolocation=(self");
        Mockito.verify(response).setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        Mockito.verify(response).setHeader("Pragma", "no-cache");
        Mockito.verify(response).setHeader("Expires", "0");

        //verifying that filterChain is called
        Mockito.verify(filterChain).doFilter(request, response);
    }
}
