package com.optum.providerpreferences.controller;

import com.optum.providerpreferences.rs.controller.PaymentPreferenceController;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.GenericResponse;
import com.optum.providerpreferences.rs.model.PaymentPreference;
import com.optum.providerpreferences.rs.service.PaymentPreferenceService;
import io.github.bucket4j.Bucket;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;

@RunWith(MockitoJUnitRunner.class)
public class PaymentPrefControllerTest {

    @InjectMocks
    PaymentPreferenceController paymentPreferenceController;
    
    @Mock
    private PaymentPreferenceService paymentPreferenceService;

    private Bucket bucket1;
    private Bucket bucket2;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        bucket1 = mock(Bucket.class);
        bucket2 = mock(Bucket.class);
        when(bucket1.tryConsume(1)).thenReturn(true);
        when(bucket2.tryConsume(1)).thenReturn(true);
        setPrivateField(paymentPreferenceController, "bucket1", bucket1);
        setPrivateField(paymentPreferenceController, "bucket2", bucket2);
    }

    private void setPrivateField(Object target, String fieldName, Object value) {
        try {
            Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Exception e) {
            throw new RuntimeException("Failed to set field: " + fieldName, e);
        }
    }

    @Test
    public void testGetPaymentPreference_InvalidRequest() throws ApplicationException {
      
        PaymentPreference preference = new PaymentPreference();
        preference.setMpin("294321");
        HttpHeaders headers = new HttpHeaders();
        headers.add("uuid", "test-uuid");

        String optumCidExt = "test-cid";
        ResponseEntity<PaymentPreference> response = paymentPreferenceController.getPaymentPreference(preference, headers, null, optumCidExt);
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }
    
    @Test
    public void testUpdatePaymentPreference_Success() {
        // Arrange
        PaymentPreference request = new PaymentPreference();
        request.setTin("123456");
        request.setMpin("654321");
        request.setPaymentpref("test-pref");
        request.setUpdatedBy("test-user");
        request.setUpdatedByName("test-name");

        HttpHeaders headers = new HttpHeaders();
        headers.add("uuid", "test-uuid");
        headers.add("optum-cid-ext", "test-cid");

        when(paymentPreferenceService.updatePaymentPreference(
                request.getTin(), request.getMpin(), request.getPaymentPref(), request.getUpdatedBy(), request.getUpdatedByName()))
                .thenReturn(new PaymentPreference());

        
        ResponseEntity<GenericResponse> response = paymentPreferenceController.updatePaymentPreference(request, headers);

        
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("200", response.getBody().getStatusCode());
        assertEquals("Payment Preference updated successfully", response.getBody().getStatusMessage());

        verify(paymentPreferenceService, times(1)).updatePaymentPreference(
                request.getTin(), request.getMpin(), request.getPaymentPref(), request.getUpdatedBy(), request.getUpdatedByName());
    }

    @Test
    public void testUpdatePaymentPreference_InvalidRequest() {
        
        PaymentPreference request = new PaymentPreference(); // Missing required fields
        HttpHeaders headers = new HttpHeaders();

        
        ResponseEntity<GenericResponse> response = paymentPreferenceController.updatePaymentPreference(request, headers);

      
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("400", response.getBody().getStatusCode());
        assertEquals("Invalid request", response.getBody().getStatusMessage());

        verifyNoInteractions(paymentPreferenceService);
    }

}
