package com.optum.digitalsecurity.model.request;

public class Tin {

}
