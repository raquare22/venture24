package com.optum.digitalsecurity.model.response;

import java.util.List;

public class PDOTins {
	private String optumUUID;
	private String uhcID;
	private String mpin;
	private List<PDOProvTin> providers;
	    
		public String getOptumUUID() {
			return optumUUID;
		}
		public void setOptumUUID(String optumUUID) {
			this.optumUUID = optumUUID;
		}
		public String getUhcID() {
			return uhcID;
		}
		public void setUhcID(String uhcID) {
			this.uhcID = uhcID;
		}
		public String getMpin() {
			return mpin;
		}
		public void setMpin(String mpin) {
			this.mpin = mpin;
		}
		public List<PDOProvTin> getProviders() {
			return providers;
		}
		public void setProviders(List<PDOProvTin> providers) {
			this.providers = providers;
		}
}
