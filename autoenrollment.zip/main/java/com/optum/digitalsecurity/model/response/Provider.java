package com.optum.digitalsecurity.model.response;

public class Provider {
		private String firstName;
		private String lastName;
		private String providerMpin;
		public Provider(String firstName, String lastName, String providerMpin) {
			super();
			this.setFirstName(firstName);
			this.setLastName(lastName);
			this.setProviderMpin(providerMpin);
		}
		public Provider() {
			
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getProviderMpin() {
			return providerMpin;
		}
		public void setProviderMpin(String providerMpin) {
			this.providerMpin = providerMpin;
		}
	    
}
