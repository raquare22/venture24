package com.optum.digitalsecurity.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Tin {
		@JsonProperty("tin")
	    private String theTin;
	    private boolean allPermission;
	    private List<Permission> permission;
		public Tin(String tin, boolean allPermission, List<Permission> permission) {
			this.theTin = tin;
			this.allPermission = allPermission;
			this.permission = permission;
		}
		
		public Tin() {
			
		}
		
		public String getTin() {
			return theTin;
		}
		public void setTin(String tin) {
			this.theTin = tin;
		}
		public boolean isAllPermission() {
			return allPermission;
		}
		public void setAllPermission(boolean allPermission) {
			this.allPermission = allPermission;
		}
		public List<Permission> getPermission() {
			return permission;
		}
		public void setPermission(List<Permission> permission) {
			this.permission = permission;
		}
	    
}
