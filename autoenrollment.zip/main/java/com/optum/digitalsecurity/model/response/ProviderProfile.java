package com.optum.digitalsecurity.model.response;

import java.util.List;

public class ProviderProfile {


	private String uuid;
	private Demographics demographics;
	private List<JobFunction> jobFunction;
	private List<ProviderOrg> providerOrg;
	private List<NonProviderOrg> nonProviderOrg;
    
	public ProviderProfile(String uuid, Demographics demographics, List<JobFunction> jobFunction,
			List<ProviderOrg> providerOrg, List<NonProviderOrg> nonProviderOrg) {
		super();
		this.uuid = uuid;
		this.demographics = demographics;
		this.jobFunction = jobFunction;
		this.providerOrg = providerOrg;
		this.nonProviderOrg = nonProviderOrg;
	}
	
	public ProviderProfile() {
		
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public Demographics getDemographics() {
		return demographics;
	}

	public void setDemographics(Demographics demographics) {
		this.demographics = demographics;
	}

	public List<JobFunction> getJobFunction() {
		return jobFunction;
	}

	public void setJobFunction(List<JobFunction> jobFunction) {
		this.jobFunction = jobFunction;
	}

	public List<ProviderOrg> getProviderOrg() {
		return providerOrg;
	}

	public void setProviderOrg(List<ProviderOrg> providerOrg) {
		this.providerOrg = providerOrg;
	}

	public List<NonProviderOrg> getNonProviderOrg() {
		return nonProviderOrg;
	}

	public void setNonProviderOrg(List<NonProviderOrg> nonProviderOrg) {
		this.nonProviderOrg = nonProviderOrg;
	}
    
}
