package com.optum.digitalsecurity.model.response;

public class ProviderOrg {
	
		public String id;
	 	public String corpMpin;
		public String uhcProviderId;
	    public String firstName;
	    public String lastName;
	    public boolean paa;
	    public boolean ia;
	    
	    public ProviderOrg(String provId, String corpMpin, String uhcProviderId, String firstName, String lastName, boolean paa,
				boolean ia) {
			super();
			this.id = provId;
			this.corpMpin = corpMpin;
			this.uhcProviderId = uhcProviderId;
			this.firstName = firstName;
			this.lastName = lastName;
			this.paa = paa;
			this.ia = ia;
		}
	    
	    public ProviderOrg() {
	    	
	    }

		public String getCorpMpin() {
			return corpMpin;
		}

		public String getId() {
			return id;
		}

		public void setId(String Id) {
			this.id = Id;
		}

		public void setCorpMpin(String corpMpin) {
			this.corpMpin = corpMpin;
		}

		public String getUhcProviderId() {
			return uhcProviderId;
		}

		public void setUhcProviderId(String uhcProviderId) {
			this.uhcProviderId = uhcProviderId;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public boolean isPaa() {
			return paa;
		}

		public void setPaa(boolean paa) {
			this.paa = paa;
		}

		public boolean isIa() {
			return ia;
		}

		public void setIa(boolean ia) {
			this.ia = ia;
		}
	    
}
