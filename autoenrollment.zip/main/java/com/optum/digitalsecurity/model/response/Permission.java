package com.optum.digitalsecurity.model.response;

public class Permission {
	private String code;
	private String subCode;
	private String codeDesc;
	private String subCodeDesc;
	    
		public Permission(String code, String subCode, String codeDesc, String subCodeDesc) {
			super();
			this.setCode(code);
			this.setSubCode(subCode);
			this.setCodeDesc(codeDesc);
			this.setSubCodeDesc(subCodeDesc);
		}
		public Permission() {
			
		}
		public String getSubCode() {
			return subCode;
		}
		public void setSubCode(String subCode) {
			this.subCode = subCode;
		}
		public String getCodeDesc() {
			return codeDesc;
		}
		public void setCodeDesc(String codeDesc) {
			this.codeDesc = codeDesc;
		}
		public String getSubCodeDesc() {
			return subCodeDesc;
		}
		public void setSubCodeDesc(String subCodeDesc) {
			this.subCodeDesc = subCodeDesc;
		}
		public String getCode() {
			return code;
		}
		public void setCode(String code) {
			this.code = code;
		}
}
