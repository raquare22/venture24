package com.optum.digitalsecurity.model.response;

import java.util.List;

public class ProvTin {
	private String uuid;
	private String corpMpin;
	private String tin;
	private List<Provider> provider;
    
	public ProvTin(String uuid, String corpMpin, String tin, List<Provider> provider) {
		super();
		this.setUuid(uuid);
		this.setCorpMpin(corpMpin);
		this.setTin(tin);
		this.setProvider(provider);
	}

	public List<Provider> getProvider() {
		return provider;
	}

	public void setProvider(List<Provider> provider) {
		this.provider = provider;
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getCorpMpin() {
		return corpMpin;
	}

	public void setCorpMpin(String corpMpin) {
		this.corpMpin = corpMpin;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
    
}
