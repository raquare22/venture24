package com.optum.digitalsecurity.model.response;

public class Corporate {
	 	public String uhcID;
	    public String mpin;
	    public String corporateName;
	    public String provId;
	    
		public String getUhcID() {
			return uhcID;
		}
		public void setUhcID(String uhcID) {
			this.uhcID = uhcID;
		}
		public String getMpin() {
			return mpin;
		}
		public void setMpin(String mpin) {
			this.mpin = mpin;
		}
		public String getCorporateName() {
			return corporateName;
		}
		public void setCorporateName(String corporateName) {
			this.corporateName = corporateName;
		}
		public String getProvId() {
			return provId;
		}
		public void setProvId(String provId) {
			this.provId = provId;
		}
	    
}
