package com.optum.digitalsecurity.model.response;

public class PDOProvTin {
	
	private String tin;

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}
}
