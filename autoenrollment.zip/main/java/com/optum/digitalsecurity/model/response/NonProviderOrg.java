package com.optum.digitalsecurity.model.response;

public class NonProviderOrg {
	private String irsOrgId;
	private String corpName;
	private boolean paa;
    
	public NonProviderOrg(String irsOrgId, String corpName, boolean paa) {
		super();
		this.setIrsOrgId(irsOrgId);
		this.setCorpName(corpName);
		this.setPaa(paa);
	}
	
	public NonProviderOrg() {
		
	}

	public String getIrsOrgId() {
		return irsOrgId;
	}

	public void setIrsOrgId(String irsOrgId) {
		this.irsOrgId = irsOrgId;
	}

	public String getCorpName() {
		return corpName;
	}

	public void setCorpName(String corpName) {
		this.corpName = corpName;
	}

	public boolean isPaa() {
		return paa;
	}

	public void setPaa(boolean paa) {
		this.paa = paa;
	}
}


