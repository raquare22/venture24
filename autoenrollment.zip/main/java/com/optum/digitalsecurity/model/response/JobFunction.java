package com.optum.digitalsecurity.model.response;

public class JobFunction {
	 	private String code;
	 	private String desc;
	 	private String npi;
		public JobFunction(String code, String desc, String npi) {
			super();
			this.setCode(code);
			this.setDesc(desc);
			this.setNpi(npi);
		}
		public JobFunction() {
			
		}
		public String getCode() {
			return code;
		}
		public void setCode(String code) {
			this.code = code;
		}
		public String getDesc() {
			return desc;
		}
		public void setDesc(String desc) {
			this.desc = desc;
		}
		public String getNpi() {
			return npi;
		}
		public void setNpi(String npi) {
			this.npi = npi;
		}
}
