package com.optum.digitalsecurity.model.response;

import java.util.List;

public class OrgData {

	 	private String id;
	 	private String corpMpin;
	 	private List<Tin> tins;
	    
		public OrgData(String id, String corpMpin, List<Tin> tins) {
			this.id = id;
			this.corpMpin = corpMpin;
			this.tins = tins;
		}
		
		public OrgData() {
			
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getCorpMpin() {
			return corpMpin;
		}

		public void setCorpMpin(String corpMpin) {
			this.corpMpin = corpMpin;
		}

		public List<Tin> getTins() {
			return tins;
		}

		public void setTins(List<Tin> tins) {
			this.tins = tins;
		}
}
