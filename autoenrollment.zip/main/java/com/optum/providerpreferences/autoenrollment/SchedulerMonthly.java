package com.optum.providerpreferences.autoenrollment;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.service.OptOutServiceImpl;
import com.optum.providerpreferences.autoenrollment.config.SchedulerConfig;

@Component
@ConfigurationProperties(prefix = "spring.datasource")
@ConditionalOnProperty(name = "SCHEDULER_AUTO_ENROLLMENT", havingValue = "true")
public final class SchedulerMonthly {
	
	private static Logger logger = LogManager.getLogger(SchedulerMonthly.class);
	private static final String DIRECTORY_LISTING = "directoryListing";
	private static final String CHANNEL_SFTP = "channelSftp";
	private static final String SFTP_SESSION = "sftpSession";
	private static final String CHANNEL = "channel";
	private static final String FILE_EXTENSION = ".json";
	
	private static final String PRUN_HOST = "prunhost";
	private static final String PRUN_USERNAME = "userName";
	private static final String PRUN_KEY = "prunPassword";
	private static final String LOCAL_DIRECTORY_STRING = "localDirectory";

	private static final String MISSING_SFTP = "Scheduler : processFiles - Missing some of the sftp credentials";
	private static final String PROCESSFILES_EXCEPTION = "Exception while processFiles  {}={}, {}={}, {}={}, {}={}, {}={} {}";

	private static final int SPLIT_PER_MB_SIZE_DEFAULT = 20;
	private static final int MAX_BYTES_NEWLINE_WITHIN_DEFAULT = 256;

	public static Set<String> tinsUpdatedEmail = new HashSet<>();
	public static Set<String> tinsWithoutEmail = new HashSet<>();
    public static AtomicInteger getCount = new AtomicInteger(0);
    public static AtomicInteger postCount = new AtomicInteger(0);
    public static AtomicInteger emailCount = new AtomicInteger(0);
    public static AtomicInteger emailNotFound = new AtomicInteger(0);
    static AtomicInteger lastSchedulerCount = new AtomicInteger(0);
    
    public static String currentFileName; 
    
    public static Scheduler scheduler = new Scheduler();

	static AtomicBoolean lock = new AtomicBoolean(false);
	
	@Autowired
	FDSHandler fdsHandler;


	@Autowired
	OptOutServiceImpl optOutService;

	public static final String LOCAL_DIRECTORY;
	static {
		//		String path = String.join(File.separator, System.getProperty("user.home"), "auto_enrollment");
//		if (path.contains("?")) {
		String path = "/ingest/auto_enrollment";
//		}
		File directory = new File(path);
		directory.mkdir();
		LOCAL_DIRECTORY = path;
	}

	//SCHEDULER_MONTHLY_EMAIL_CHECK_CRON
	@Scheduled(cron = "${SCHEDULER_MONTHLY_EMAIL_CHECK_CRON}")
	public static void SchedulerEmailCheck() {
		logger.info("SchedulerEmailCheck: Start");
		executeScheduledJob("EmailCheck",
			SchedulerConfig.PRUN_EMAIL_CHECK_WORKING_DIRECTORY,
			SchedulerConfig.PRUN_EMAIL_CHECK_DESTINATION_DIRECTORY,
			SchedulerConfig.PRUN_EMAIL_CHECK_ARCHIVE_DIRECTORY);
	}

	public static void EmailCheckManual() {
		logger.info("SchedulerEmailCheck: Manual Start");
		executeScheduledJob("Manual EmailCheck",
			SchedulerConfig.PRUN_EMAIL_CHECK_WORKING_DIRECTORY,
			SchedulerConfig.PRUN_EMAIL_CHECK_DESTINATION_DIRECTORY,
			SchedulerConfig.PRUN_EMAIL_CHECK_ARCHIVE_DIRECTORY);
	}

	private static void executeScheduledJob(String identifier,String prunWorkingDirectory, String prunDestinationDirectory, String prunArchiveDirectory) {
		

		try {
			if (lock.get()) { 
				if (lastSchedulerCount.get() != 0 && postCount.get() != 0 && lastSchedulerCount.get() == postCount.get()) {
					if (lastSchedulerCount.get() == getCount.get()) {
						logger.warn("Counts matched, restarting scheduler, getCount={}, postCount={}", getCount, postCount);
					}
					else {
						logger.warn("Counts got stuck, restarting scheduler, getCount={}, postCount={}", getCount, postCount);
					}
					lock.set(false);
					getCount.set(0);
				    postCount.set(0);
				    emailCount.set(0);
					tinsWithoutEmail.clear();
					tinsUpdatedEmail.clear();
				    lastSchedulerCount.set(0);
				}
				else {
					logger.info("Counts do not match, still processing posts, lastSchedulerCount={},  getCount={}, postCount={}",lastSchedulerCount, getCount, postCount);
				}
			}
			
			if (lock.get()) {
				logger.info("Skipping {}: Scheduler already locked and running", identifier);
				return;
			}
			
			lock.set(true);

			if (SftpUtil.exceptionForMissingLoginCredential(
					SchedulerConfig.prunHost, SchedulerConfig.prunUserName,
					SchedulerConfig.prunKey, prunWorkingDirectory)) {
				logger.warn("Scheduler : pollCSVFiles - Missing some of the sftp credentials");
				lock.set(false);
				return;
			}
			if (!SftpUtil.createNewDirectoryAndMoveFiles(
					logger,
					prunWorkingDirectory,
					prunDestinationDirectory,
					prunWorkingDirectory,
					prunDestinationDirectory,
					SchedulerConfig.prunUserName,
					SchedulerConfig.prunKey,
					SchedulerConfig.prunHost,
					FILE_EXTENSION,
					SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE,
					SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN,
					SPLIT_PER_MB_SIZE_DEFAULT,
					MAX_BYTES_NEWLINE_WITHIN_DEFAULT,
					"", // fileToMove
					SchedulerMonthly::splitFiles
			)) {
				logger.info("Done {} Scheduler; No work to do", identifier);
				lock.set(false);
				return;
			}

			processFiles(prunDestinationDirectory, prunWorkingDirectory, prunDestinationDirectory, prunDestinationDirectory, prunArchiveDirectory);
		} catch (IOException e) {
			logger.error("pollCSVFiles {}={}, {}={}, {}={}, {}={} {}", PRUN_HOST,SchedulerConfig.prunHost,
				PRUN_USERNAME,SchedulerConfig.prunUserName, PRUN_KEY,SchedulerConfig.prunKey,
					prunWorkingDirectory, prunWorkingDirectory, ExceptionUtils.getStackTrace(e));
		} finally {
			lastSchedulerCount.set(postCount.get());
			logger.info("Done {} Scheduler", identifier);
		}
		
	}

	protected static void splitFiles(String prunDestinationDirectory, int splitPerMbSize, int maxBytesNewLineWithin, Map<String, Long> splitFileMap) {
		try {
			String destinationPath = prunDestinationDirectory;
			logger.info("Start of splitFiles: splitFileMap={}, destinationPath={}", splitFileMap, destinationPath);
			if (! SftpUtil.exceptionForMissingLoginCredential(
					SchedulerConfig.prunHost, SchedulerConfig.prunUserName, SchedulerConfig.prunKey, destinationPath)) {
				checkAndSplit(destinationPath, splitPerMbSize, maxBytesNewLineWithin, splitFileMap);
			}
		} catch (IOException e) {
			logger.error("Exception splitFiles: {}={}, {}={}, {}={}, {}={}, {}={} {}", PRUN_HOST,
				SchedulerConfig.prunHost, PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY,
				SchedulerConfig.prunKey, prunDestinationDirectory,
				prunDestinationDirectory, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
				ExceptionUtils.getStackTrace(e));
		}
	}

	protected static void checkAndSplit(String destinationPath, int splitPerMbSize, int maxBytesNewLineWithin, Map<String, Long> fileSizeMap) {
		Map<String, Object> sftpResult = null;
		try {
			sftpResult = SftpUtil.sftpDirectory(
				SchedulerConfig.prunUserName,
				SchedulerConfig.prunKey,
				SchedulerConfig.prunHost,
				destinationPath);
			for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING)) {
				String fileName = entry.getFilename();
				if (fileName.endsWith(FILE_EXTENSION)) {
					Long fileSize = fileSizeMap.get(fileName);
					if (fileSize == null) {
						continue;
					}
					String localFile = LOCAL_DIRECTORY + File.separator + fileName;
					logger.info("Splitting file={}, size={}, destinationPath={}, localFile={}", fileName, fileSize, destinationPath, localFile);
					SftpUtil.copyFileToLocal(destinationPath, LOCAL_DIRECTORY, fileName, sftpResult);

					List<Path> pathList = splitJsonFile(localFile, splitPerMbSize, maxBytesNewLineWithin, LOCAL_DIRECTORY);
					if (! pathList.isEmpty()) {
						for (Path path : pathList) {
							logger.info("Copying file from local to server: file={}", path.toFile().getPath());
							SftpUtil.movefileFromlocalToServer(path.toFile().getPath(), sftpResult, destinationPath);
							SftpUtil.checkFileExistsOrNot(path.toFile().getName(), LOCAL_DIRECTORY);
						}
						SftpUtil.removeFileFromServer(sftpResult, destinationPath, fileName);
						SftpUtil.checkFileExistsOrNot(fileName, LOCAL_DIRECTORY);
					}
				}
			}
		}
		catch (IOException | JSchException | SftpException  e) {
			logger.error("Exception while processFiles  {}={}, {}={}, {}={}, {}={},{}={} {}", PRUN_HOST,
					SchedulerConfig.prunHost, PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY,
					SchedulerConfig.prunKey, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
					"destinationPath", destinationPath, ExceptionUtils.getStackTrace(e));
		} finally {
			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
						(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
				logger.info("Processing Files finally method -sftp connection closed");
				logger.info("End of Scheduler : processFiles");
			}
		}
	}

	private static List<Path> splitJsonFile(String fileName, int splitPerMbSize, int maxBytesNewLineWithin, String localDirectory) throws IOException {
		List<Path> splitFiles = new ArrayList<>();

		//get just the file name from the path
		String[] temp = fileName.split(File.separator);
		String file_name = temp[temp.length - 1].replace(FILE_EXTENSION, "");

		if (splitPerMbSize <= 0) {
			return splitFiles;
		}
		long sourceSize;
		Path fileNamePath = Paths.get(fileName);
		try {
			sourceSize = Files.size(fileNamePath);
		} catch (IOException e) {
			logger.error("Exception file.size: fileName={}; {}", fileName, ExceptionUtils.getStackTrace(e));
			return splitFiles;
		}

		final long bytesPerSplit = 1024L * 1024L * splitPerMbSize;
		if (sourceSize < bytesPerSplit) {
			logger.info("Not splitting: fileName={}, sourceSize={}, bytesPerSplit={}", fileName, sourceSize, bytesPerSplit);
			return splitFiles;
		}
		logger.info("Splitting: fileName={}, sourceSize={}, bytesPerSplit={}", fileName, sourceSize, bytesPerSplit);
		int chunkSize = 10000000; // Specify the desired chunk size

		try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
			int fileCounter = 1;
			int character;
			StringBuilder jsonChunk = new StringBuilder();
			int openBracesCount = 0;
			int closeBracesCount = 0;
			int charCount = 0;

			while ((character = reader.read()) != -1) {

				if ((char) character == '{') {
					openBracesCount++;
				}
				if ((char) character == '}') {
					closeBracesCount++;
				}
				if(charCount == 0 && (char) character == ',') {
					jsonChunk.append('[');
					continue;
				}

				jsonChunk.append((char)character);
				charCount++;

				if (openBracesCount == closeBracesCount && charCount >= chunkSize){
					//Close the json array with ']' and reset the counter for the next file
					jsonChunk.append(']');
					splitFiles.add(saveChunkToFile(jsonChunk.toString(), fileCounter, file_name));
					charCount = 0;
					fileCounter++;
					jsonChunk = new StringBuilder();
					logger.info("File successfully split: fileName={}", fileName);
				}
			}

			if (jsonChunk.length() > 0) {
				jsonChunk.append("}");
				splitFiles.add(saveChunkToFile(jsonChunk.toString(), fileCounter, file_name));
			}
			}catch (IOException e) {
			logger.error("Exception in Splitting Json Files : Exception = {} ", e.getMessage());
		}
        return splitFiles;
    }

	private static Path saveChunkToFile(String chunk, int fileCounter, String file_name) {
		String filename = LOCAL_DIRECTORY + File.separator + file_name + "_chunk" + fileCounter + ".json";
		try (FileWriter writer = new FileWriter(filename)) {
			writer.write(chunk);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return Paths.get(filename);
	}

	@SuppressWarnings("unchecked")
	private static void processFiles(String prunDestinationDirectory, String fixedWorkingDirectory, String fixedDestinationDirectory, String directoryFromEnv, String directoryToEnv) {
		logger.info("Start of EmailCheck Scheduler : processFiles : Directory={}", prunDestinationDirectory);
		logger.info("lastSchedulerCount={}, postCount={}, emailCheck size={}, getCount size={}, postCount size={}", 
				lastSchedulerCount, postCount, emailCount, getCount, postCount);
		Map<String, Object> sftpResult = null;
		try {
			String destinationPath = prunDestinationDirectory;
			if (!SftpUtil.exceptionForMissingLoginCredential(SchedulerConfig.prunHost,SchedulerConfig.prunUserName,SchedulerConfig.prunKey, destinationPath)) {

				sftpResult = SftpUtil.sftpDirectory(SchedulerConfig.prunUserName,SchedulerConfig.prunKey,SchedulerConfig.prunHost, destinationPath);
				for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING)) {
					try {
						String fileName = entry.getFilename();

						if (fileName.endsWith(FILE_EXTENSION)) {
							logger.info("Processing File {}", fileName);

							List<String> data = extractCSV(fileName, destinationPath, fixedWorkingDirectory, fixedDestinationDirectory, directoryFromEnv, directoryToEnv, fileName);

							SchedulerAutoEnrollment.currentFileName = fileName;

							SftpUtil.readFileSendAutoEnroCloud(data);
							// !! ADD THE PUT CALL STEP TO UPDATE THE EMAILS IN FDS CLOUD

							logger.info("Process finished for file {}, tins without email={}, tins with updated email={}, blank emails={}, emails updated={}", fileName, tinsWithoutEmail.size(), tinsUpdatedEmail.size(), emailNotFound.get(), emailCount.get());
							logger.info("data list size={}, getCount={}, "
									+ "postCount={}",
									data.size(), getCount, postCount);
							String csvFileName = fileName.replace(FILE_EXTENSION, ".csv");
							SftpUtil.createNewDirectoryAndMoveFiles(
								logger,
								fixedWorkingDirectory,
								fixedDestinationDirectory,
								directoryFromEnv,
								directoryToEnv,
									SchedulerConfig.prunUserName,
									SchedulerConfig.prunKey,
									SchedulerConfig.prunHost,
								FILE_EXTENSION,
									SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE,
									SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN,
								SPLIT_PER_MB_SIZE_DEFAULT,
								MAX_BYTES_NEWLINE_WITHIN_DEFAULT,
								csvFileName,
								SchedulerMonthly::splitFiles
							);
						}
						getCount.set(0);
					    postCount.set(0);
					    emailCount.set(0);
						emailNotFound.set(0);
						tinsWithoutEmail.clear();
						tinsUpdatedEmail.clear();
					} catch (IOException | ApplicationException | JSchException | SftpException e) {
						logger.error("Exception while processFiles  {}={}, {}={}, {}={}, {}={},{}={} {}", PRUN_HOST,
								SchedulerConfig.prunHost, PRUN_USERNAME,SchedulerConfig.prunUserName, PRUN_KEY,
								SchedulerConfig.prunKey, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
								"destinationPath", destinationPath, ExceptionUtils.getStackTrace(e));
					} 
				} 
				
			} else {
				logger.warn(MISSING_SFTP);
			}
		} catch (IOException | JSchException | SftpException e) {
			logger.error(PROCESSFILES_EXCEPTION, PRUN_HOST,
					SchedulerConfig.prunHost, PRUN_USERNAME,SchedulerConfig.prunUserName, PRUN_KEY,
					SchedulerConfig.prunKey, prunDestinationDirectory,
					prunDestinationDirectory, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
					ExceptionUtils.getStackTrace(e));
		}
		finally {
			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
						(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
				logger.info("Processing Files finally method -sftp connection closed");
				logger.info("End of Scheduler : processFiles");
			}
		}
	}
	
	private static List<String> extractCSV(String fileName, String destinationPath, String fixedWorkingDirectory, String fixedDestinationDirectory, String directoryFromEnv, String directoryToEnv, String fileToMove) throws ApplicationException, FileNotFoundException, SftpException, JSchException {
		List<String> extractedData = null;
		logger.info("In extractCSV: fileName={}, destinationPath={}", fileName, destinationPath);
		Map<String, Object> extractSftpResult = SftpUtil.sftpDirectory(SchedulerConfig.prunUserName,SchedulerConfig.prunKey,SchedulerConfig.prunHost, destinationPath);
		for (int i = 0; i < 5; i++ ) {
			try {
				extractedData = SftpUtil.readFileStoreDataEmailCheck(destinationPath, LOCAL_DIRECTORY, fileName, extractSftpResult, false, fixedWorkingDirectory, fixedDestinationDirectory, directoryFromEnv, directoryToEnv, fileToMove);
				return extractedData;
			}
			catch (SftpException e) {
				logger.error("SFTP failure, retry {}, fileName={}, destinationPath={}, exception={}", i, fileName, destinationPath, e.getStackTrace());
				extractSftpResult = SftpUtil.sftpDirectory(SchedulerConfig.prunUserName,SchedulerConfig.prunKey,SchedulerConfig.prunHost, destinationPath);
				continue;
			}
		}
		if (extractedData == null) {
			throw new SftpException(4, "Complete SFTP connection failure for filename " + fileName);
		}
		return extractedData;
	}

}
