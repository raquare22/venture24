package com.optum.providerpreferences.autoenrollment;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class TimeUtils {
    private static final ZoneId BUSINESS_ZONE = ZoneId.of("America/New_York");
    private static final LocalTime BUSINESS_START = LocalTime.of(6, 0); // 6:00 AM
    private static final LocalTime BUSINESS_END = LocalTime.of(23, 59);  // 11:59 PM

    public static boolean isWithinBusinessHours() {
        ZonedDateTime now = ZonedDateTime.now(BUSINESS_ZONE);
        DayOfWeek dayOfWeek = now.getDayOfWeek();

        // Check if it's a weekday
        if (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY) {
            return false;
        }

        // Check if the time is within business hours
        LocalTime currentTime = now.toLocalTime();
        return !currentTime.isBefore(BUSINESS_START) && !currentTime.isAfter(BUSINESS_END);
    }
}
