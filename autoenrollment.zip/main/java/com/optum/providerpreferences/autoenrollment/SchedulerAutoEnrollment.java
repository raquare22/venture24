package com.optum.providerpreferences.autoenrollment;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.service.OptOutServiceImpl;
import com.optum.providerpreferences.autoenrollment.config.SchedulerConfig;

@Component
@ConfigurationProperties(prefix = "spring.datasource")
@ConditionalOnProperty(name = "SCHEDULER_AUTO_ENROLLMENT", havingValue = "true")
public final class SchedulerAutoEnrollment {

//	private SchedulerAutoEnrollment() {
//		//private constructor to hide public one
//	}
	private static Logger logger = LogManager.getLogger(SchedulerAutoEnrollment.class);
	private static final String DIRECTORY_LISTING = "directoryListing";
	private static final String CHANNEL_SFTP = "channelSftp";
	private static final String SFTP_SESSION = "sftpSession";
	private static final String CHANNEL = "channel";
	private static final String FILE_EXTENSION = ".csv";

	private static final String PRUN_HOST = "prunhost";
	private static final String PRUN_USERNAME = "userName";
	private static final String PRUN_KEY = "prunPassword";
	private static final String LOCAL_DIRECTORY_STRING = "localDirectory";
		
	private static final String MISSING_SFTP = "Scheduler : processFiles - Missing some of the sftp credentials";
	private static final String PROCESSFILES_EXCEPTION = "Exception while processFiles  {}={}, {}={}, {}={}, {}={}, {}={} {}";

	private static final int SPLIT_PER_MB_SIZE_DEFAULT = 20;
	private static final int MAX_BYTES_NEWLINE_WITHIN_DEFAULT = 256;
	
    public static AtomicInteger getCount = new AtomicInteger(0);
    public static AtomicInteger postCount = new AtomicInteger(0);
    public static AtomicInteger emailCount = new AtomicInteger(0);
    public static AtomicInteger emailNotFound = new AtomicInteger(0);
    static AtomicInteger lastSchedulerCount = new AtomicInteger(0);
    
    public static String currentFileName; 
    
    public static Scheduler scheduler = new Scheduler();

	static AtomicBoolean lock = new AtomicBoolean(false);
	
	@Autowired
	FDSHandler fdsHandler;

	@Autowired
	NDBHandler ndbHandler;

	@Autowired
	OptOutServiceImpl optOutService;

	private static final String LOCAL_DIRECTORY;
	static {
//		String path = String.join(File.separator, System.getProperty("user.home"), "auto_enrollment");
//		if (path.contains("?")) {
		String path = "/ingest/auto_enrollment";
//		}
		File directory = new File(path);
		directory.mkdir();
		LOCAL_DIRECTORY = path;
	}

	// Pickup dropped files:
	// PRUN_AUTOENROLLMENT_WORKING_DIRECTORY=/dropzone/prod/autoenrollment
	// Partition CSV, if needed, and move to following for processFiles:
	// PRUN_AUTOENROLLMENT_DESTINATION_DIRECTORY=/dropzone/prod/autoenrollment/processFiles
	// When processFiles completes move to:
	// PRUN_AUTOENROLLMENT_ARCHIVE_DIRECTORY=/dropzone/prod/autoenrollment/processed

	// default = "0 0,15,30,45 0-6,20-23 * * MON-FRI")
	@Scheduled(cron = "${SCHEDULER_AUTO_ENROLLMENT_WEEKDAY_CRON}")
	public static void pollCSVFilesWeekdays() {
		if (TimeUtils.isWithinBusinessHours()) {
			logger.info("Skipping execution of pollCSVFilesWeekdays during business hours.");
			return;
		}
		executeScheduledJob("Weekday",
			SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY,
			SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY,
			SchedulerConfig.PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY);
	}

	// default = "0 0,15,30,45 0-23 * * SAT,SUN"
	@Scheduled(cron = "${SCHEDULER_AUTO_ENROLLMENT_WEEKEND_CRON}")
	public static void pollCSVFilesWeekends() {
		executeScheduledJob("Weekend",
			SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY,
			SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY,
			SchedulerConfig.PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY);
	}

	@Scheduled(cron = "${SCHEDULER_DAILY_ONESHOT_NDB_CRON}")
	public static void pollCSVFilesOneshotNDB() {
		if (TimeUtils.isWithinBusinessHours()) {
			logger.info("Skipping execution of pollCSVFilesOneshotNDB during business hours.");
			return;
		}
		executeScheduledJob("OneshotNDB",
			SchedulerConfig.PRUN_ONESHOT_NDB_WORKING_DIRECTORY,
			SchedulerConfig.PRUN_ONESHOT_NDB_DESTINATION_DIRECTORY,
			SchedulerConfig.PRUN_ONESHOT_NDB_ARCHIVE_DIRECTORY);
	}

	@Scheduled(cron = "${SCHEDULER_WEEKEND_ONESHOT_NDB_CRON}")
	public static void pollCSVFilesOneshotNDBWeekend() {
		executeScheduledJob("OneshotNDB",
			SchedulerConfig.PRUN_ONESHOT_NDB_WORKING_DIRECTORY,
			SchedulerConfig.PRUN_ONESHOT_NDB_DESTINATION_DIRECTORY,
			SchedulerConfig.PRUN_ONESHOT_NDB_ARCHIVE_DIRECTORY);
	}

//	@Scheduled(cron = "${SCHEDULER_AUTO_ENROLLMENT_CHECK_CRON}")
//	public void checkCSVDaily() {
//		if (!lock.get()) { 
//			executeScheduledCheck(PRUN_DESTINATION_PROCESSED_DIRECTORY);
//		}
//	}
	
//	@Scheduled(cron = "${SCHEDULER_DAILY_AUTO_ENROLLMENT_CRON}")
	public static void pollDailyProcess() {
		scheduler.pollCSVFiles();
	}
	
	private void executeScheduledCheck(String dirToCheck) {
		if (TimeUtils.isWithinBusinessHours()) {
			logger.info("Stopping executeScheduledCheck as it's now within business hours.");
			return;
		}
		try {
			scheduler.scheduledCheckAutoenrollment(dirToCheck);
		}
		catch (Exception e ){
			logger.info(dirToCheck);
		}
	}
	public static void pollCSVFilesManual() {
		if (TimeUtils.isWithinBusinessHours()) {
			logger.info("Stopping pollCSVFilesManual as it's now within business hours.");
			return;
		}
		executeScheduledJob("Manual",
			SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY,
			SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY,
			SchedulerConfig.PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY);
	}

	private static void executeScheduledJob(String identifier,String prunWorkingDirectory, String prunDestinationDirectory, String prunArchiveDirectory) {
		

		try {
			if (lock.get()) { 
				if (lastSchedulerCount.get() != 0 && postCount.get() != 0 && lastSchedulerCount.get() == postCount.get()) {
					if (lastSchedulerCount.get() == getCount.get()) {
						logger.warn("Counts matched, restarting scheduler, getCount={}, postCount={}", getCount, postCount);
					}
					else {
						logger.warn("Counts got stuck, restarting scheduler, getCount={}, postCount={}", getCount, postCount);
					}
					lock.set(false);
					getCount.set(0);
				    postCount.set(0);
				    emailCount.set(0);
				    lastSchedulerCount.set(0);
				}
//				 if iterating through files, may not need this check anymore
				else {
					logger.info("Counts do not match, still processing posts, lastSchedulerCount={},  getCount={}, postCount={}",lastSchedulerCount, getCount, postCount);
				}
			}
			
			if (lock.get()) {
				logger.info("Skipping {}: Scheduler already locked and running", identifier);
				return;
			}
			
			lock.set(true);

			if (TimeUtils.isWithinBusinessHours()) {
				logger.info("Stopping {} Scheduler as it's now within business hours.", identifier);
				return;
			}
//			logger.info("Start {} Scheduler", identifier);
			if (SftpUtil.exceptionForMissingLoginCredential(
					SchedulerConfig.prunHost, SchedulerConfig.prunUserName,
					SchedulerConfig.prunKey, prunWorkingDirectory)) {
				logger.warn("Scheduler : pollCSVFiles - Missing some of the sftp credentials");
				lock.set(false);
				return;
			}
			if (!SftpUtil.createNewDirectoryAndMoveFiles(
					logger,
					prunWorkingDirectory,
					prunDestinationDirectory,
					prunWorkingDirectory,
					prunDestinationDirectory,
					SchedulerConfig.prunUserName,
					SchedulerConfig.prunKey,
					SchedulerConfig.prunHost,
					FILE_EXTENSION,
					SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE,
					SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN,
					SPLIT_PER_MB_SIZE_DEFAULT,
					MAX_BYTES_NEWLINE_WITHIN_DEFAULT,
					"", // fileToMove
					SchedulerAutoEnrollment::splitFiles
			)) {
				logger.info("Done {} Scheduler; No work to do", identifier);
				lock.set(false);
				return;
			}
			
			processFiles(prunDestinationDirectory,prunWorkingDirectory, prunDestinationDirectory, prunDestinationDirectory, prunArchiveDirectory);
		} catch (IOException e) {
			logger.error("pollCSVFiles {}={}, {}={}, {}={}, {}={} {}", PRUN_HOST, Encode.forJava(SchedulerConfig.prunHost),
				PRUN_USERNAME, Encode.forJava(SchedulerConfig.prunUserName), PRUN_KEY, Encode.forJava(SchedulerConfig.prunKey),
					prunWorkingDirectory, prunWorkingDirectory, ExceptionUtils.getStackTrace(e));
		} finally {
			lastSchedulerCount.set(postCount.get());
			logger.info("Done {} Scheduler", identifier);
		}
		
	}
	
	@SuppressWarnings("unchecked") // Thursday before processsing
//	@Scheduled(cron = "${SCHEDULER_RETRY_CRON}")
	public static void pollRetry() {
		if (TimeUtils.isWithinBusinessHours()) {
			logger.info("Stopping pollRetry as it's now within business hours.");
			return;
		}
		if (lock.get()) {
			return;
		}
		else {
			try {
				if (!SftpUtil.exceptionForMissingLoginCredential(
						SchedulerConfig.prunHost, SchedulerConfig.prunUserName,
						SchedulerConfig.prunKey, SchedulerConfig.retryWorkingDirec)) {
					processRetry();
				} else {
					logger.warn("Scheduler : pollCSVFiles - Missing some of the sftp credentials");
				}
			} catch (IOException e) {
				logger.error("pollCSVFiles  {}={}, {}={}, {}={}, {}={} {}", PRUN_HOST, SchedulerConfig.prunHost,
						PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY, SchedulerConfig.prunKey,
						"retryWorkingDirec", SchedulerConfig.retryWorkingDirec, ExceptionUtils.getStackTrace(e));
			}
			finally {
				lock.set(false);
			}
		}

	}
	
	private static void processRetry() {

		if (TimeUtils.isWithinBusinessHours()) {
			logger.info("Stopping processRetry as it's now within business hours.");
			return;
		}

		Map<String, Object> sftpResult = null;
		
		try {
			lock.set(true);
			
			if (SftpUtil.exceptionForMissingLoginCredential(
					SchedulerConfig.prunHost, SchedulerConfig.prunUserName,
					SchedulerConfig.prunKey, SchedulerConfig.retryWorkingDirec)) {
				logger.warn(MISSING_SFTP);
				throw new IOException();
			}
			//retryProcessedDirec
			
			sftpResult = SftpUtil.sftpDirectory(SchedulerConfig.prunUserName, SchedulerConfig.prunKey,
					SchedulerConfig.prunHost, SchedulerConfig.retryWorkingDirec);
			 
			for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult
					.get(DIRECTORY_LISTING)) {
				try {

						String fileName = entry.getFilename();
						if (fileName.endsWith(FILE_EXTENSION)) {
							
							logger.info("Processing File {}", fileName);
							List<String> data = SftpUtil.readRetryData(SchedulerConfig.retryWorkingDirec,
									LOCAL_DIRECTORY, fileName, sftpResult, true);
							
							String originPath = String.join(File.separator, SchedulerConfig.retryWorkingDirec, fileName);
							String destPath = String.join(File.separator, SchedulerConfig.retryProcessedDirec, fileName);
							SftpUtil.rename((ChannelSftp) sftpResult.get(CHANNEL_SFTP), originPath, destPath, true);
							
						}
					
				} catch (IOException | ApplicationException e) {
					logger.error("Exception while processFiles  {}={}, {}={}, {}={}, {}={}, {}={}, {}", PRUN_HOST,
							SchedulerConfig.prunHost, PRUN_USERNAME,SchedulerConfig.prunUserName, PRUN_KEY,
							SchedulerConfig.prunKey, SchedulerConfig.retryWorkingDirec,
							SchedulerConfig.retryWorkingDirec, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
							ExceptionUtils.getStackTrace(e));
				} 
			} 
		} catch (IOException | JSchException | SftpException e) {
			lock.set(false);

			logger.error(PROCESSFILES_EXCEPTION, PRUN_HOST,
					SchedulerConfig.prunHost, PRUN_USERNAME,SchedulerConfig.prunUserName, PRUN_KEY,
					SchedulerConfig.prunKey, SchedulerConfig.retryWorkingDirec,
					SchedulerConfig.retryWorkingDirec, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
					ExceptionUtils.getStackTrace(e));
		}
		finally {
			lock.set(false);

			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
						(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
			}
		}
		
		
	}

	protected static void splitFiles(String prunDestinationDirectory, int splitPerMbSize, int maxBytesNewLineWithin, Map<String, Long> splitFileMap) {
		if (TimeUtils.isWithinBusinessHours()) {
				logger.info("Stopping splitFiles as it's now within business hours.");
				return;
			}
		try {
			String destinationPath = prunDestinationDirectory;
			logger.info("Start of splitFiles: splitFileMap={}, destinationPath={}", splitFileMap, destinationPath);
			if (! SftpUtil.exceptionForMissingLoginCredential(
					SchedulerConfig.prunHost, SchedulerConfig.prunUserName, SchedulerConfig.prunKey, destinationPath)) {
				checkAndSplit(destinationPath, splitPerMbSize, maxBytesNewLineWithin, splitFileMap);
			}
		} catch (IOException e) {
			logger.error("Exception splitFiles: {}={}, {}={}, {}={}, {}={}, {}={} {}", PRUN_HOST,
				SchedulerConfig.prunHost, PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY,
				SchedulerConfig.prunKey, prunDestinationDirectory,
				prunDestinationDirectory, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
				ExceptionUtils.getStackTrace(e));
		}
	}

	protected static void checkAndSplit(String destinationPath, int splitPerMbSize, int maxBytesNewLineWithin, Map<String, Long> fileSizeMap) {
		if (TimeUtils.isWithinBusinessHours()) {
			logger.info("Stopping checkAndSplit as it's now within business hours.");
			return;
		}
		Map<String, Object> sftpResult = null;
		try {
			sftpResult = SftpUtil.sftpDirectory(
				SchedulerConfig.prunUserName,
				SchedulerConfig.prunKey,
				SchedulerConfig.prunHost,
				destinationPath);
			for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING)) {
				String fileName = entry.getFilename();
				if (fileName.endsWith(FILE_EXTENSION)) {
					Long fileSize = fileSizeMap.get(fileName);
					if (fileSize == null) {
						continue;
					}
					String localFile = LOCAL_DIRECTORY + File.separator + fileName;
					logger.info("Splitting file={}, size={}, destinationPath={}, localFile={}", fileName, fileSize, destinationPath, localFile);
					SftpUtil.copyFileToLocal(destinationPath, LOCAL_DIRECTORY, fileName, sftpResult);
					List<Path> pathList = SftpUtil.splitFilePerMbPerNewLine(localFile, splitPerMbSize, maxBytesNewLineWithin, LOCAL_DIRECTORY, false, FILE_EXTENSION);					if (! pathList.isEmpty()) {
						for (Path path : pathList) {
							logger.info("Copying file from local to server: file={}", path.toFile().getPath());
							SftpUtil.movefileFromlocalToServer(path.toFile().getPath(), sftpResult, destinationPath);
							SftpUtil.checkFileExistsOrNot(path.toFile().getName(), LOCAL_DIRECTORY);
						}
						SftpUtil.removeFileFromServer(sftpResult, destinationPath, fileName);
						SftpUtil.checkFileExistsOrNot(fileName, LOCAL_DIRECTORY);
					}
				}
			}
		}
		catch (IOException | JSchException | SftpException  e) {
			logger.error("Exception while processFiles  {}={}, {}={}, {}={}, {}={},{}={} {}", PRUN_HOST,
					SchedulerConfig.prunHost, PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY,
					SchedulerConfig.prunKey, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
					"destinationPath", destinationPath, ExceptionUtils.getStackTrace(e));
		} finally {
			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
						(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
				logger.info("Processing Files finally method -sftp connection closed");
				logger.info("End of Scheduler : processFiles");
			}
		}
	}
	private static String stoppedFileName = null;

	@SuppressWarnings("unchecked")
	private static void processFiles(String prunDestinationDirectory, String fixedWorkingDirectory, String fixedDestinationDirectory, String directoryFromEnv, String directoryToEnv) {
		logger.info("Start of Scheduler : processFiles");
		logger.info("lastSchedulerCount={}, postCount={}, emailCheck size={}, getCount size={}, postCount size={}", 
				lastSchedulerCount, postCount, emailCount, getCount, postCount);

		if (TimeUtils.isWithinBusinessHours()) {
			logger.info("Stopping processFiles as it's now within business hours.");
			if (stoppedFileName != null) {
				logger.info("Processing stopped for file: {}", stoppedFileName);
			}
			return;
		}

		Map<String, Object> sftpResult = null;
		try {
			String destinationPath = prunDestinationDirectory;
			if (!SftpUtil.exceptionForMissingLoginCredential(SchedulerConfig.prunHost,SchedulerConfig.prunUserName, SchedulerConfig.prunKey, destinationPath)) {
				
				sftpResult = SftpUtil.sftpDirectory(SchedulerConfig.prunUserName, SchedulerConfig.prunKey,SchedulerConfig.prunHost, destinationPath);
				for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING)) {
					try {
						String fileName = entry.getFilename();

						if (fileName.endsWith(FILE_EXTENSION)) {
							logger.info("Processing File {}", fileName);
							List<String> data = extractCSV(fileName, destinationPath);
							if (TimeUtils.isWithinBusinessHours()) {
								stoppedFileName = fileName;
								logger.info("Stopping processFiles as it's now within business hours. Stopped at file: {}", fileName);
								return;
							}
							try {
                                assert data != null;
                                logger.info("data list size={}, emailCheck={}, getCount={}, postCount={}, emailNotFound={}",
										data.size(), emailCount, getCount, postCount, emailNotFound);
							} catch (NullPointerException e) {
								logger.error("Data is null for file: {}", fileName, e);
							}
							SchedulerAutoEnrollment.currentFileName = fileName;
							SftpUtil.readFileSendAutoEnroCloud(data);
							logger.info("data list size={}, "
									+ "emailCheck={}, getCount={}, "
									+ "postCount={}, emailNotFound={}", 
									data.size(), emailCount, getCount, postCount, emailNotFound);
							SftpUtil.createNewDirectoryAndMoveFiles(
									logger,
									fixedWorkingDirectory,
									fixedDestinationDirectory,
									directoryFromEnv,
									directoryToEnv,
									SchedulerConfig.prunUserName,
									SchedulerConfig.prunKey,
									SchedulerConfig.prunHost,
									FILE_EXTENSION,
									SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE,
									SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN,
									SPLIT_PER_MB_SIZE_DEFAULT,
									MAX_BYTES_NEWLINE_WITHIN_DEFAULT,
									fileName,
									SchedulerAutoEnrollment::splitFiles
							);
						}
						// Scheduled check after large oneshots, currently commented out and is being done manually for monitoring
//						scheduler.scheduledCheckAutoenrollment(String.join(destinationPath));
						getCount.set(0);
					    postCount.set(0);
					    emailCount.set(0);

					} catch (IOException | ApplicationException | JSchException | SftpException e) {
						logger.error("Exception while processFiles  {}={}, {}={}, {}={}, {}={},{}={} {}", PRUN_HOST,
								SchedulerConfig.prunHost, PRUN_USERNAME,SchedulerConfig.prunUserName, PRUN_KEY,
								SchedulerConfig.prunKey, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
								"destinationPath", destinationPath, ExceptionUtils.getStackTrace(e));
					} 
				} 
				
			} else {
				logger.warn(MISSING_SFTP);
			}
		} catch (IOException | JSchException | SftpException e) {
			logger.error(PROCESSFILES_EXCEPTION, PRUN_HOST,
					SchedulerConfig.prunHost, PRUN_USERNAME,SchedulerConfig.prunUserName, PRUN_KEY,
					SchedulerConfig.prunKey, prunDestinationDirectory,
					prunDestinationDirectory, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
					ExceptionUtils.getStackTrace(e));
		}
		finally {
			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
						(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
				logger.info("Processing Files finally method -sftp connection closed");
				logger.info("End of Scheduler : processFiles");
			}
		}
	}
	
	private static List<String> extractCSV(String fileName, String destinationPath) throws ApplicationException, FileNotFoundException, SftpException, JSchException {
		if (TimeUtils.isWithinBusinessHours()) {
			logger.info("Stopping extractCSV as it's now within business hours.");
			return null;
		}
		List<String> extractedData = null;
		Map<String, Object> extractSftpResult = SftpUtil.sftpDirectory(SchedulerConfig.prunUserName, SchedulerConfig.prunKey,SchedulerConfig.prunHost, destinationPath);
		for (int i = 0; i < 5; i++ ) {
			try {
				extractedData = SftpUtil.readFileStoreData(destinationPath, LOCAL_DIRECTORY, fileName, extractSftpResult, false);
				return extractedData;
			}
			catch (SftpException e) {
				logger.error("SFTP failure, retry {}, fileName={}, destinationPath={}, exception={}", i, fileName, destinationPath, e.getStackTrace());
				extractSftpResult = SftpUtil.sftpDirectory(SchedulerConfig.prunUserName, SchedulerConfig.prunKey,SchedulerConfig.prunHost, destinationPath);
				continue;
			}
		}
		if (extractedData == null) {
			throw new SftpException(4, "Complete SFTP connection failure for filename " + fileName);
		}
		return extractedData;
	}

}
