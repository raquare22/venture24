package com.optum.providerpreferences.autoenrollment;

import com.jcraft.jsch.*;
import com.optum.providerpreferences.autoenrollment.config.SchedulerConfig;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.service.OptOutServiceImpl;
import com.optum.providerpreferences.rs.model.PaymentPreference;
import com.optum.providerpreferences.rs.service.PaymentPreferenceServiceImpl;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

@Component
@ConfigurationProperties(prefix = "spring.datasource")
@ConditionalOnProperty(name = "SCHEDULER_MEMBER_PAYMENT_PREFERENCE", havingValue = "true")
public class SchedulerMemberPaymentPreference {

    private static Logger logger = LogManager.getLogger(SchedulerMemberPaymentPreference.class);
    private static final String DIRECTORY_LISTING = "directoryListing";
    private static final String CHANNEL_SFTP = "channelSftp";
    private static final String SFTP_SESSION = "sftpSession";
    private static final String CHANNEL = "channel";
    private static final String FILE_EXTENSION = ".csv";

    private static final String PRUN_HOST = "prunhost";
    private static final String PRUN_USERNAME = "userName";
    private static final String PRUN_KEY = "prunPassword";
    private static final String LOCAL_DIRECTORY_STRING = "localDirectory";

    private static final String MISSING_SFTP = "Scheduler : processFiles - Missing some of the sftp credentials";
    private static final String PROCESSFILES_EXCEPTION = "Exception while processFiles  {}={}, {}={}, {}={}, {}={}, {}={} {}";

    private static final int SPLIT_PER_MB_SIZE_DEFAULT = 20;
    private static final int MAX_BYTES_NEWLINE_WITHIN_DEFAULT = 256;

    public static AtomicInteger getCount = new AtomicInteger(0);
    public static AtomicInteger postCount = new AtomicInteger(0);
    public static AtomicInteger emailCount = new AtomicInteger(0);
    static AtomicInteger lastSchedulerCount = new AtomicInteger(0);

    public static String currentFileName;

    public static Scheduler scheduler = new Scheduler();
    private static String stoppedFileName = null;

    static AtomicBoolean lock = new AtomicBoolean(false);

    @Autowired
    private static PaymentPreferenceServiceImpl paymentPreferenceService;

    @Autowired
    FDSHandler fdsHandler;

    @Autowired
    NDBHandler ndbHandler;

    @Autowired
    OptOutServiceImpl optOutService;

    private static final String LOCAL_DIRECTORY;
    static {
        String path = String.join(File.separator, System.getProperty("user.home"), "auto_enrollment");
        if (path.contains("?")) {
            path = "/home/jboss/auto_enrollment";
        }
        File directory = new File(path);
        directory.mkdir();
        LOCAL_DIRECTORY = path;
    }

    @Scheduled(cron = "${SCHEDULER_MEMBER_PAYMENT_PREFERENCE_WEEKDAY_CRON}")
    public static void SchedulerMemberPayment() {
        if (TimeUtils.isWithinBusinessHours()) {
            logger.info("Skipping execution of SchedulerMemberPaymentPreference during business hours.");
            return;
        }
        executeScheduledJob("MemberPaymentPref-Weekday",
            SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_WORKING_DIRECTORY,
            SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_DESTINATION_DIRECTORY,
            SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_ARCHIVE_DIRECTORY);
    }

    private static void executeScheduledJob(String identifier,String prunWorkingDirectory, String prunDestinationDirectory, String prunArchiveDirectory) {


        try {
            if (lock.get()) {
                logger.info("Skipping {}: Scheduler already locked and running", identifier);
                return;
            }

            lock.set(true);

            if (TimeUtils.isWithinBusinessHours()) {
                logger.info("Stopping {} Scheduler as it's now within business hours.", identifier);
                return;
            }
//			logger.info("Start {} Scheduler", identifier);
            if (SftpUtil.exceptionForMissingLoginCredential(
                    SchedulerConfig.prunHost, SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey, prunWorkingDirectory)) {
                logger.warn("Scheduler : pollCSVFiles - Missing some of the sftp credentials");
                lock.set(false);
                return;
            }
            if (!SftpUtil.createNewDirectoryAndMoveFiles(
                    logger,
                    prunWorkingDirectory,
                    prunDestinationDirectory,
                    prunWorkingDirectory,
                    prunDestinationDirectory,
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.prunHost,
                    FILE_EXTENSION,
                    SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE,
                    SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN,
                    SPLIT_PER_MB_SIZE_DEFAULT,
                    MAX_BYTES_NEWLINE_WITHIN_DEFAULT,
                    "",
                    SchedulerAutoEnrollment::splitFiles //reusing the same splitFiles method since SchedulerMemberPaymentPreference also accepts csv
            )){
                logger.info("Done {} Scheduler; No work to do", identifier);
                lock.set(false);
                return;
            }
            processFiles(prunDestinationDirectory,prunWorkingDirectory, prunDestinationDirectory, prunDestinationDirectory, prunArchiveDirectory);
        } catch (IOException e) {
            logger.error("pollCSVFiles {}={}, {}={}, {}={}, {}={} {}", PRUN_HOST,SchedulerConfig.prunHost,
                    PRUN_USERNAME,SchedulerConfig.prunUserName, PRUN_KEY,SchedulerConfig.prunKey,
                    prunWorkingDirectory, prunWorkingDirectory, ExceptionUtils.getStackTrace(e));
        } finally {
            lastSchedulerCount.set(postCount.get());
            logger.info("Done {} Scheduler", identifier);
        }

    }

    private static void processFiles(String prunDestinationDirectory, String fixedWorkingDirectory, String fixedDestinationDirectory, String directoryFromEnv, String directoryToEnv) {
        logger.info("Start of Scheduler : processFiles");
        logger.info("lastSchedulerCount={}, postCount={}, emailCheck size={}, getCount size={}, postCount size={}",
                lastSchedulerCount, postCount, emailCount, getCount, postCount);

        if (TimeUtils.isWithinBusinessHours()) {
            logger.info("Stopping processFiles as it's now within business hours.");
            if (stoppedFileName != null) {
                logger.info("Processing stopped for file: {}", stoppedFileName);
            }
            return;
        }

        Map<String, Object> sftpResult = null;
        try {
            if (!SftpUtil.exceptionForMissingLoginCredential(
                    SchedulerConfig.prunHost, SchedulerConfig.prunUserName, SchedulerConfig.prunKey, prunDestinationDirectory)) {

                sftpResult = SftpUtil.sftpDirectory(
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.prunHost,
                    prunDestinationDirectory);
                for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING)) {
                    try {
                        String fileName = entry.getFilename();

                        if (fileName.endsWith(FILE_EXTENSION)) {
                            logger.info("Processing File {}", fileName);
                            List<String> data = extractCSV(fileName, prunDestinationDirectory);
                            if (TimeUtils.isWithinBusinessHours()) {
                                stoppedFileName = fileName;
                                logger.info("Stopping processFiles as it's now within business hours. Stopped at file: {}", fileName);
                                return;
                            }
                            try {
                                assert data != null;
                                logger.info("data list size={}",
                                        data.size());
                            } catch (NullPointerException e) {
                                logger.error("Data is null for file: {}", fileName, e);
                            }
                            SchedulerMemberPaymentPreference.currentFileName = fileName;
                            processMemberPaymentPreferenceData(data);
                            SftpUtil.createNewDirectoryAndMoveFiles(
                                    logger,
                                    fixedWorkingDirectory,
                                    fixedDestinationDirectory,
                                    directoryFromEnv,
                                    directoryToEnv,
                                    SchedulerConfig.prunUserName,
                                    SchedulerConfig.prunKey,
                                    SchedulerConfig.prunHost,
                                    FILE_EXTENSION,
                                    SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE,
                                    SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN,
                                    SPLIT_PER_MB_SIZE_DEFAULT,
                                    MAX_BYTES_NEWLINE_WITHIN_DEFAULT,
                                    fileName,
                                    SchedulerAutoEnrollment::splitFiles
                            );
                        }
                        getCount.set(0);
                        postCount.set(0);
                        emailCount.set(0);

                    } catch (IOException | ApplicationException | JSchException | SftpException e) {
                        logger.error("Exception while processFiles  {}={}, {}={}, {}={}, {}={},{}={} {}", PRUN_HOST,
                               SchedulerConfig.prunHost, PRUN_USERNAME,SchedulerConfig.prunUserName, PRUN_KEY,
                               SchedulerConfig.prunKey, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
                                "destinationPath", prunDestinationDirectory, ExceptionUtils.getStackTrace(e));
                    }
                }

            } else {
                logger.warn(MISSING_SFTP);
            }
        } catch (IOException | JSchException | SftpException e) {
            logger.error(PROCESSFILES_EXCEPTION, PRUN_HOST,
                   SchedulerConfig.prunHost, PRUN_USERNAME,SchedulerConfig.prunUserName, PRUN_KEY,
                   SchedulerConfig.prunKey, "MEMBER_PAYMENT_PREFERENCE_DESTINATION_DIRECTORY",
                    prunDestinationDirectory, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
                    ExceptionUtils.getStackTrace(e));
        }
        finally {
            if (sftpResult != null) {
                SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
                        (Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
                logger.info("Processing Files finally method -sftp connection closed");
                logger.info("End of Scheduler : processFiles");
            }
        }
    }

    private static void processMemberPaymentPreferenceData(List<String> data) {
        if (data == null || data.isEmpty()) {
            logger.warn("No data to process for Member Payment Preference");
            return;
        }
        for (String line : data) {
            try {
                // Assuming CSV format: tin,mpin,corporateMpin,paymentPref,accountNumber,updatedBy
                String[] tokens = line.split(",", -1);
                if (tokens.length < 6) {
                    logger.warn("Skipping invalid line: {}", line);
                    continue;
                }
                String tin = tokens[0].trim();
                String mpin = tokens[1].trim();
                String corporateMpin = tokens[2].trim();
                String paymentPref = tokens[3].trim();
                String accountNumber = tokens[4].trim();
                String updatedBy = tokens[5].trim();

                PaymentPreference record = paymentPreferenceService.getPaymentPreferenceByTinAndMpin(tin, mpin);

                if (record == null) {
                    PaymentPreference newPref = new PaymentPreference();
                    newPref.setTin(tin);
                    newPref.setMpin(mpin);
                    newPref.setCorporateMpin(corporateMpin);
                    newPref.setPaymentpref(paymentPref);
                    newPref.setAccountNumber(accountNumber);
                    newPref.setUpdatedBy("");
                    newPref.setDateCreated(new java.util.Date());
                    newPref.setDateModified(new java.util.Date());
                    paymentPreferenceService.insertPaymentPreference(newPref);
                    logger.info("Inserted new PaymentPreference for tin={}, mpin={}", Encode.forJava(tin), Encode.forJava(mpin));
                } else {
                    if (record.getUpdatedBy() == null || record.getUpdatedBy().isEmpty()) {
                        paymentPreferenceService.updatePaymentPreference(tin, mpin, paymentPref, "");
                        logger.info("Updated PaymentPreference for tin={}, mpin={}", Encode.forJava(tin), Encode.forJava(mpin));
                    } else {
                        logger.info("Skipped update for tin={}, mpin={} as updatedBy is not blank", Encode.forJava(tin), Encode.forJava(mpin));
                    }
                }
            } catch (Exception e) {
                logger.error("Error processing line: {} Exception: {}", line, e.getMessage());
            }
        }
    }

    private static List<String> extractCSV(String fileName, String destinationPath) throws ApplicationException, FileNotFoundException, SftpException, JSchException {
        if (TimeUtils.isWithinBusinessHours()) {
            logger.info("Stopping extractCSV as it's now within business hours.");
            return null;
        }
        List<String> extractedData = null;
        Map<String, Object> extractSftpResult = SftpUtil.sftpDirectory(
            SchedulerConfig.prunUserName,
            SchedulerConfig.prunKey,
            SchedulerConfig.prunHost,
            destinationPath);
        for (int i = 0; i < 5; i++ ) {
            try {
                extractedData = SftpUtil.readFileStoreMemberPaymentData(destinationPath, LOCAL_DIRECTORY, fileName, extractSftpResult, false);
                return extractedData;
            }
            catch (SftpException e) {
                logger.error("SFTP failure, retry {}, fileName={}, destinationPath={}, exception={}", i, fileName, destinationPath, e.getStackTrace());
                extractSftpResult = SftpUtil.sftpDirectory(
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.prunHost,
                    destinationPath);
                continue;
            }
        }
        if (extractedData == null) {
            throw new SftpException(4, "Complete SFTP connection failure for filename " + fileName);
        }
        return extractedData;
    }
    
}
