package com.optum.providerpreferences.autoenrollment;

import java.io.*;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.optum.providerpreferences.rs.handler.PESCorpMpinHandler;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.service.ProviderPreferenceServiceImpl;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.optum.digitalsecurity.model.request.User;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.Oauth2Handler;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObj;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.service.AutoenrollmentServiceImpl;
import com.optum.providerpreferences.rs.service.DigitalSecurityServiceImpl;
import com.optum.providerpreferences.autoenrollment.config.SchedulerConfig;

import static com.optum.providerpreferences.autoenrollment.SchedulerMonthly.*;

@Component
public final class SftpUtil {
	
	private SftpUtil() {
		//private constructor to hide public one
	}

	private static final Logger LOGGER = LogManager.getLogger(SftpUtil.class);


	private static final int SFTP_PORT = 22;
	public static final String INGEST_PATH_PROPERTY_NAME = "INGEST_ROOT";
	private static final String LETTER_TYPE = "LETTER TYPE";
	private static final String DIRECTORY_LISTING = "directoryListing";
	private static final String CHANNEL_SFTP = "channelSftp";
	private static final String SFTP_SESSION = "sftpSession";
	private static final String CHANNEL = "channel";
	private static final String FILE_NAME = "fileName";
	private static final String MAX_TRIES = "maxTries";
	private static final String RETRY_TIME_SECS = "retryTimeSecs";
	private static final String SFTP_HOST = "sftpHost";
	private static final String SFTP_USER = "sftpUSER";
	private static final String SFTP_RESULT = "sftpResult";
	private static final String TARGET_DIR = "targetDir";
	private static final String ARCHIVE_DIR = "archiveDir";
	private static final String COMMA_DELIMITER = ",";
	private static final String FILE_EXTENSION = ".csv";
	private static final String MPIN = "MPIN";
	private static final String TAX_ID = "TAX ID";
	private static final String ENROLLMENT = "ENROLLMENT";
	private static final String ACTIVE = "ACTIVE";
	private static final String ACCOUNT_NUMBER = "ACCOUNT NUMBER";
	private static final String TIN = "tin";
	private static final String LETTERTYPE = "LETTER TYPE";
	private static final String DOC_ID = "DOC ID";
	private static final String CORPORATE_MPIN = "CORP MPIN";
	private static final String SHELL_COMMAND = "sudo -s";
	private static final String THREADING_FAILED = "Threading failed, error={}";
	private static final String AUTOENROLL_SEND_FAILURE = "sftpFileStream -> Error sending autoenrollment docs, error={}";
	private static final String READ_FILE_ERROR = "readFile  {}={}, {}={}, {}={}, {}={} {}";
	
	static String destDir="DestinationDirectory";
	static String localDir="LocalDirectory";
	
	private static final List<String> headers = new ArrayList<>();
	
	private static List<String> records = null;
	private static List<FDSCloudRequest> missingDocList = null;
	private static AutoenrollmentRequest autoEnrollReq = null;
	private static List<AutoenrollmentObj> resendAEList = null;
    private static Integer sftpBlankEmails = 0;
    private static Set<String> sftpIndividualMpins = new LinkedHashSet();
	
	static ObjectMapper mapper = new ObjectMapper();

	static String readFileVal="readFile -> Failed validation: invalidValue={}, fullRecord={}";

	static FDSCloudHandler fdsCloudHandler;
	static PESCorpMpinHandler PESCorpMpinHandler;
	static AutoenrollmentServiceImpl autoenrollmentServiceImpl;
	static DigitalSecurityServiceImpl digitalSecurityServiceImpl;
	static ProviderPreferenceServiceImpl providerPreferenceServiceImpl;

	@Autowired
	public void setDigitalSecurityServiceImpl(DigitalSecurityServiceImpl service) {
		SftpUtil.digitalSecurityServiceImpl = service;
	}

	@Autowired
	public void setAutoenrollmentServiceImpl(AutoenrollmentServiceImpl service) {
		SftpUtil.autoenrollmentServiceImpl = service;
	}

	@Autowired
	public void setDPESCorpMpinHandler(PESCorpMpinHandler service) {
		SftpUtil.PESCorpMpinHandler = service;
	}

	@Autowired
	public void setFdsCloudHandler(FDSCloudHandler service) {
		SftpUtil.fdsCloudHandler = service;
	}

	@Autowired
	public void setProviderPreferenceServiceImpl(ProviderPreferenceServiceImpl service) {
		SftpUtil.providerPreferenceServiceImpl = service;
	}

	private static ExecutorService digiSecGetExecutorService = Executors.newFixedThreadPool(ApplicationUtil.parseWithDefault(SchedulerConfig.THREADS_DIGISEC_GET, ApplicationUtil.THREADS_DIGISEC_GET_DEFAULT));
	private static ExecutorService sendGetExecutorService = Executors.newFixedThreadPool(ApplicationUtil.parseWithDefault(SchedulerConfig.THREADS_FDSCLOUD_GET, ApplicationUtil.THREADS_FDSCLOUD_GET_DEFAULT));
	private static ExecutorService EmailCheckExecutorService = Executors.newFixedThreadPool(ApplicationUtil.parseWithDefault(SchedulerConfig.THREADS_PES_GET, ApplicationUtil.THREAD_COUNT_PES_DEFAULT));

	@SuppressWarnings("unchecked")
	public static Map<String, Object> sftpDirectory(String sftpUSER, String sftpPASS, String sftpHost,
			String sftpWorkingDir) throws JSchException, SftpException {
		Map<String, Object> result = new HashMap<>();
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Skipping sftpDirectory execution during business hours.");
			return Collections.emptyMap(); // Return an empty result or handle as per your requirements
		}

		Session sftpSession;
		Channel channel;
		ChannelSftp channelSftp;
		sftpSession = createSession(sftpUSER, sftpPASS, sftpHost, SFTP_PORT);
		channel = createSFTPChannel(sftpSession);
		channelSftp = (ChannelSftp) channel;
		try {
			channelSftp.cd(sftpWorkingDir);
		} catch (SftpException e) {
			LOGGER.error("processSFTPDirectory Failure: cd to sftpWorkingDir: {}, errMsg={}", sftpWorkingDir,
					e.getMessage());
//			throw e;
		}

		Comparator<ChannelSftp.LsEntry> c = Comparator.comparingInt((ChannelSftp.LsEntry o) -> o.getAttrs().getMTime());
		ArrayList<ChannelSftp.LsEntry> directoryListing = new ArrayList<ChannelSftp.LsEntry>(
				channelSftp.ls(channelSftp.pwd()));
		directoryListing.sort(c);
		result.put(DIRECTORY_LISTING, directoryListing);
		result.put(CHANNEL_SFTP, channelSftp);
		result.put(SFTP_SESSION, sftpSession);
		result.put(CHANNEL, channel);
		return result;
	}
	

	public static boolean exceptionForMissingLoginCredential(String sftpHost, String sftpUSER, String sftpPASS,
			String sftpWorkingDir) throws IOException {

		if (isMissingLoginCredential(sftpHost, sftpUSER, sftpPASS, sftpWorkingDir)) {
			LOGGER.info("runCsvSFTPMonitor Login credentials must be supplied ; not able to login to SFTP host={}",
					sftpHost);
			throw new IOException("Missing login credentials host=" + sftpHost);
		}
		return false;

	}

	public static boolean isMissingLoginCredential(String sftpHost, String sftpUSER, String sftpPASS,
			String sftpWorkingDir) {
		return StringUtils.isEmpty(sftpHost) || StringUtils.isEmpty(sftpUSER) || StringUtils.isEmpty(sftpPASS)
				|| StringUtils.isEmpty(sftpWorkingDir);
	}

	public static void closeSFTPChannel(ChannelSftp channelSftp, Session sftpSession, Channel channel) {
		if (channelSftp != null && channelSftp.isConnected()) {
			try {
				channel.disconnect();
				channelSftp.disconnect();
				channelSftp.quit();
				if (sftpSession == null || !sftpSession.isConnected()) {
					sftpSession = channelSftp.getSession();
				}
				sftpSession.disconnect();
			} catch (JSchException e) {
				LOGGER.error("closeSFTPChannel IOException Error Message {}", ExceptionUtils.getStackTrace(e));
			}
		}
	}

	public static void moveFileFromSFTPDirToArchive(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort,
			String fromDir, String archiveDir, String fileName, int maxTries, long retryTimeSecs)
			throws JSchException, SftpException {

		Session sftpSession = null;
		ChannelSftp channel = null;
		for (int tries = 0; tries < maxTries; tries++) {
			try {
				LOGGER.info("sftp tries {}, fromDir {}, archiveDir {}, fileName {}", tries + 1, fromDir, archiveDir,
						fileName);
				sftpSession = createSession(sftpUSER, sftpPASS, sftpHost, sftpPort);
				channel = (ChannelSftp) createSFTPChannel(sftpSession);
				moveFileToLocation(channel, fromDir, archiveDir, fileName);
				break;
			} catch (JSchException e) {
				if (tries >= maxTries - 1) {
					LOGGER.error(
							"moveFileFromSFTPDirToArchive {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={} {}",
							SFTP_USER, sftpUSER, SFTP_HOST, sftpHost, SFTP_PORT, sftpPort, "fromDir", fromDir,
							ARCHIVE_DIR, archiveDir, FILE_NAME, fileName, MAX_TRIES, maxTries, RETRY_TIME_SECS,
							retryTimeSecs, ExceptionUtils.getStackTrace(e));
					throw e;
				}
			} catch (SftpException e) {
				if (tries >= maxTries - 1) {
					LOGGER.error(
							"moveFileFromSFTPDirToArchive: {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={} {}",
							SFTP_USER, sftpUSER, SFTP_HOST, sftpHost, SFTP_PORT, sftpPort, "fromDir", fromDir,
							ARCHIVE_DIR, archiveDir, FILE_NAME, fileName, MAX_TRIES, maxTries, RETRY_TIME_SECS,
							retryTimeSecs, ExceptionUtils.getStackTrace(e));
					throw new SftpException(e.id, "sftp exception", e);
				}
			} finally {
				if (channel != null) {
					channel.disconnect();
					channel.quit();
				}
				if (sftpSession != null) {
					sftpSession.disconnect();
				}
				retryWaitHelper(archiveDir, fileName, retryTimeSecs);
			}
		}

	}

	public static void retryWaitHelper(String archiveDir, String fileName,  long retryTimeSecs) {
	try {
		TimeUnit.SECONDS.sleep(retryTimeSecs);
	} catch (InterruptedException e) {
		LOGGER.warn("moveFileFromSFTPDirToArchive; Time delay interrupted {}={}, {}={}", ARCHIVE_DIR,
				archiveDir, FILE_NAME, fileName);
		Thread.currentThread().interrupt();
	}
	}
	public static Session createSession(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort)
			throws JSchException {
		Session sftpSession;
		JSch jsch = new JSch();
		sftpSession = jsch.getSession(sftpUSER, sftpHost, sftpPort);
		sftpSession.setPassword(sftpPASS);
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		sftpSession.setConfig(config);
		sftpSession.connect();
		return sftpSession;
	}

	public static Channel createSFTPChannel(Session sftpSession) throws JSchException {
		Channel channel = sftpSession.openChannel("sftp");
		try {
			channel.connect();
		} catch (JSchException e) {
			String stackTrace= ExceptionUtils.getStackTrace(e);
			LOGGER.error("createSFTPChannel -> Error connecting channel, error={}", stackTrace);
		}
		return channel;
	}

	private static void moveFileToLocation(ChannelSftp channel, String fromDir, String targetDir, String fileName)
			throws SftpException {
		channel.cd(fromDir);
		if (channel.get(fileName) != null) {
			channel.rename(fromDir + File.pathSeparator + fileName, targetDir + File.pathSeparator + fileName);
			channel.chmod(640, targetDir + File.pathSeparator + fileName);
			channel.cd(fromDir);
		}

	}

	public static void removeFileFromSFTPLocation(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort,
			String targetDir, String fileName) throws JSchException, SftpException {
		Session sftpSession = null;
		ChannelSftp channel = null;
		try {
			sftpSession = createSession(sftpUSER, sftpPASS, sftpHost, sftpPort);
			channel = (ChannelSftp) createSFTPChannel(sftpSession);
			channel.cd(targetDir);
			removeFileInSFTPLocation(channel, targetDir, fileName);
		} catch (JSchException | SftpException e) {
			LOGGER.error("removeFileFromSFTPLocation {}={}, {}={}, {}={}, {}={}, {}={} {}", SFTP_USER, sftpUSER,
					SFTP_HOST, sftpHost, SFTP_PORT, sftpPort, TARGET_DIR, targetDir, FILE_NAME, fileName,
					ExceptionUtils.getStackTrace(e));
		} finally {

			if (channel != null) {
				channel.disconnect();
				channel.quit();
			}
			if (sftpSession != null) {
				sftpSession.disconnect();
			}
		}
	}

	private static void removeFileInSFTPLocation(ChannelSftp channel, String location, String fileName)
			throws SftpException {
		removeFileInSFTPLocation(channel, location + File.separator + fileName);
	}

	public static void removeFileInSFTPLocation(ChannelSftp channel, String fileNameWithPath) throws SftpException {
		channel.rm(fileNameWithPath);
	}

	public static void copyFileToArchive(String workingDir, String destination, String localDirectory, String filename,
			Map<String, Object> sftpResult) throws FileNotFoundException, SftpException {

		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);

		validateDirectory(sftpChannel, destination);

		try {
			moveFilefromsftpTolocalToArchive(sftpChannel, filename, workingDir, localDirectory, destination);
		} catch (SftpException e) {
			LOGGER.error("copyFileToArchive {}={}, {}={}, {}={}, {}={}, {}={} {}", "WorkingDirectory", workingDir,
					destDir, destination, localDir, localDirectory, FILE_NAME, filename, "SFTP",
					sftpResult, ExceptionUtils.getStackTrace(e));
			String stackTrace=ExceptionUtils.getStackTrace(e);
			LOGGER.error("copyfileToArchive Unable to copy file{}", stackTrace);
		}
	}

	private static void validateDirectory(ChannelSftp sftpChannel, String destination) throws SftpException {

		String folderName = createDateintoString();
		SftpATTRS attrs = null;
		try {
			sftpChannel.cd(destination);
			attrs = sftpChannel.stat(destination + File.separator + folderName);
		} catch (SftpException e) {
			LOGGER.error("validateDirectory not found {}={}, {}={}, {}={} {}", "sftpChannel", sftpChannel,
					destDir, destination, "folderName", folderName, ExceptionUtils.getStackTrace(e));
		}

		if (attrs != null) {
			LOGGER.info("Directory exists Dir{}", attrs.isDir());
		} else {
			LOGGER.info("Creating dir{}", folderName);
			sftpChannel.mkdir(folderName);
		}

	}

	private static final List<SimpleDateFormat> SIMPLE_DATE_FORMAT = Collections
			.singletonList(new SimpleDateFormat("yyyyMMdd"));

	public static String createDateintoString() {
		return SIMPLE_DATE_FORMAT.get(0).format(new Date());
	}

	private static void moveFilefromsftpTolocalToArchive(ChannelSftp sftpChannel, String filename, String workingDir,
			String localDirectory, String destination) throws SftpException, FileNotFoundException {
		LOGGER.info(
				"moveFilefromsftpTolocalToArchive  sftpChannel{}, filename{}, workingDir{},localDirectory{},destination{}",
				sftpChannel, filename, workingDir, localDirectory, destination);

		sftpChannel.get(workingDir + File.separator + filename, localDirectory);
		File localFile = new File(localDirectory + File.separator + filename);
		sftpChannel.cd(destination + File.separator);
		String direc=destination + File.separator;
		LOGGER.info("cd into this directory {}", direc);
		try (FileInputStream localStream = new FileInputStream(localFile)){
			sftpChannel.put(localStream, localFile.getName());
		}
		catch (IOException e ){
			LOGGER.error("moveFilefromsftpTolocalToArchive -> Error moving file to archive, error={}", e.getMessage());
		}
	}

	private static final Map<Integer, Predicate<String>> predicateMap;
	static {
		predicateMap = new HashMap<>();
		predicateMap.put(0, x -> x.length() == 9);
		predicateMap.put(1, x -> x.length() == 9);
		predicateMap.put(2, x -> x.length() == 2);
		predicateMap.put(3, x -> x.length() == 9);

	}

	private static final Map<Integer, Predicate<String>> predicateMapEmailCheck;
	static {
		predicateMapEmailCheck = new HashMap<>();
		predicateMapEmailCheck.put(0, x -> x.length() == 9);
		predicateMapEmailCheck.put(1, x -> x.length() == 9);
		predicateMapEmailCheck.put(2, x -> x.length() == 2);
		predicateMapEmailCheck.put(3, x -> x.length() == 36);

	}

	private static final Map<Integer, Predicate<String>> predicateMapMemberPaymentPreference;
	static {
		predicateMapMemberPaymentPreference = new HashMap<>();
		predicateMapMemberPaymentPreference.put(0, x -> x.length() == 9);
		predicateMapMemberPaymentPreference.put(1, x -> x.length() == 9);
		predicateMapMemberPaymentPreference.put(2, x -> x.length() <= 10); //TODO: specify "enrollment" length
		predicateMapMemberPaymentPreference.put(3, x -> x.length() <= 10); //TODO: specify "active" length
		predicateMapMemberPaymentPreference.put(4, x -> x.length() <= 4);

	}

	public static List<String> readFile(String destination, String localDirectory, String filename,
			Map<String, Object> sftpResult) throws FileNotFoundException, SftpException {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping readFile as it's now within business hours.");
			return Collections.emptyList();
		}

		headerValidation();
		copyFileToLocal(destination, localDirectory, filename, sftpResult);

		List<String> records = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(localDirectory + File.separator + filename)))) {
			String line;
			while ((line = br.readLine()) != null) {

				String[] values = line.split(COMMA_DELIMITER);
				boolean allFieldsGood = true;
				for (int i = 0; i < values.length; i++) {
					if (!predicateMap.getOrDefault(i, x -> true).test(values[i].trim())) {
						if(!headers.contains(values[i].trim())) {
							String value=values[i].trim();
							LOGGER.error(readFileVal, value);
						}
						allFieldsGood = false;
					}
				}
				if (allFieldsGood && values.length > 1) {
					records.add(values[1].trim());
				}

			}
		} catch (IOException e) {
			LOGGER.error(READ_FILE_ERROR, destDir, destination,
					localDir, localDirectory, FILE_NAME, filename, SFTP_RESULT, sftpResult,
			ExceptionUtils.getStackTrace(e));
		}
		return records;
	}
	

	// extracts records, grabs corresponding email, sends back to write CSV. 
	public static List<String> readFileStoreData(String destination, String localDirectory, String filename,
			Map<String, Object> sftpResult, Boolean isDailyScheduler) throws FileNotFoundException, SftpException, ApplicationException {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping readFileStoreData as it's now within business hours.");
			return Collections.emptyList();
		}

		records = Collections.synchronizedList(new ArrayList<String>());
		
		if (digiSecGetExecutorService.isShutdown()) {
			digiSecGetExecutorService = Executors.newFixedThreadPool(Integer.parseInt(SchedulerConfig.THREADS_DIGISEC_GET));
		}
		headerValidation();
		if (isDailyScheduler) {
			copyFileToLocalNoDate(destination, localDirectory, filename, sftpResult);
		}
		else {
			copyFileToLocal(destination, localDirectory, filename, sftpResult);
		}
			List<List<String>> recordLines = new ArrayList<List<String>>();
			try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(localDirectory + File.separator + filename)))) {
				recordLines = parseBufferReader(br);
				
				Token token = digitalSecurityServiceImpl.getDigiSecToken("autoenrollmentPAAEmail");	
				LOGGER.info("Processing count={}", recordLines.size());
				for (List<String> record : recordLines) {
					String letterType = record.get(2).trim();
					String email = null;
					if (letterType.equals("E2")) {
						email = getEmailFromFdsCloudForCategory(record.get(0).trim(), record.get(1).trim(), "P1");
					} else if (letterType.equals("E3")) {
						email = getEmailFromFdsCloudForCategory(record.get(0).trim(), record.get(1).trim(), "P2");
					} else if (letterType.equals("E4")) {
						email = getEmailFromFdsCloudForCategory(record.get(0).trim(), record.get(1).trim(), "P8");
					}

					if (email != null && !email.isEmpty()) {
						record.add(email);
						records.add(String.join(",", record));
					} else {
						digiSecGetExecutorService.execute(new getDigiSecEmailRequest(record));
					}
				}
				serviceDigiSecGetShutdown();
				
			} catch (IOException e) {
				LOGGER.error(READ_FILE_ERROR, destDir, destination,
						localDir, localDirectory, FILE_NAME, filename, SFTP_RESULT, sftpResult,
				ExceptionUtils.getStackTrace(e));
			}
	        catch (Exception e) {
	        	LOGGER.error("readFileStoreData -> error processing data, error={}", ExceptionUtils.getStackTrace(e));
	        }
			
		LOGGER.info("readFileStoreData -> DigiSec emails found, updatedCount={}", records.size());
		

		return records;
	}

	public static String getEmailFromFdsCloudForCategory(String mpin, String tin, String category) {
		try {
			Metadata metadata = new Metadata();
			metadata.setMpin(mpin);
			metadata.setTin(tin);
			metadata.setFileName(category);
			metadata.setDeliveryMethod("E");

			FDSCloudRequest fdsCloudRequest = fdsCloudHandler.createSearchTermsRequestFromMap(mapper.convertValue(metadata, new TypeReference<Map<String, Object>>() {}));
			FDSCloudGETResponse getDocResponse = fdsCloudHandler.FDSCloudGetRequest("getLoadTestCloud", fdsCloudRequest);

			if (getDocResponse != null && !getDocResponse.getDocuments().isEmpty()) {
				Map<String, Object> document = fdsCloudHandler.getSearchTermsFromDocument(getDocResponse.getDocuments().get(0));
				String email = document.get("providerEmailId").toString();
				String deliveryMethod = document.get("deliveryMethod").toString();
				if (!email.isEmpty() && "E".equals(deliveryMethod)) {
					return email;
				}
			}
		} catch (Exception e) {
			LOGGER.error("getEmailFromFdsCloudForCategory -> error retrieving email from FDS Cloud, mpin={}, tin={}, category={}, error={}", mpin, tin, category, ExceptionUtils.getStackTrace(e));
		}
		return null;
	}

	public static List<String> readFileStoreDataEmailCheck(String destination, String localDirectory, String filename,
														   Map<String, Object> sftpResult, Boolean isDailyScheduler, String fixedWorkingDirectory, String fixedDestinationDirectory, String directoryFromEnv, String directoryToEnv, String fileToMove) throws FileNotFoundException, SftpException, ApplicationException {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping readFileStoreDataEmailCheck as it's now within business hours.");
			return Collections.emptyList();
		}
        records = Collections.synchronizedList(new ArrayList<>());
		if (digiSecGetExecutorService.isShutdown()) {
			digiSecGetExecutorService = Executors.newFixedThreadPool(Integer.parseInt(SchedulerConfig.THREADS_DIGISEC_GET));
		}
		headerValidationEmailCheck();
		if (Boolean.TRUE.equals(isDailyScheduler)) {
			copyFileToLocalNoDate(destination, localDirectory, filename, sftpResult);
		}
		else {
			copyFileToLocal(destination, localDirectory, filename, sftpResult);
		}
		List<List<String>> recordLines;

		LOGGER.info("In readFileStoreDataEmailCheck : Sending file for json to csv conversion");
		String csvFilePath = jsonFileToCsv(localDirectory, filename, fixedWorkingDirectory, fixedDestinationDirectory, directoryFromEnv, directoryToEnv, fileToMove);
		Path csvPath = Paths.get(csvFilePath);
		SftpUtil.movefileFromlocalToServer(csvPath.toFile().getPath(), sftpResult, destination);
		LOGGER.info("In readFileStoreDataEmailCheck : Csv file uploaded to server");

		try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(csvFilePath)))) {
			recordLines = parseBufferReaderEmailCheck(br);
			PESCorpMpinHandler.getPESToken();
			LOGGER.info("Processing count={}", recordLines.size());
			if (EmailCheckExecutorService.isShutdown()) {
				EmailCheckExecutorService = Executors.newFixedThreadPool(Integer.parseInt(SchedulerConfig.THREADS_PES_GET));
			}
			for (List<String> record : recordLines) {
				EmailCheckExecutorService.execute(new getPESCorpMpinRequest(record));
			}
			servicePESGetShutdown();
		} catch (IOException e) {
			LOGGER.error(READ_FILE_ERROR, destDir, destination,
					localDir, localDirectory, FILE_NAME, filename, SFTP_RESULT, sftpResult,
					ExceptionUtils.getStackTrace(e));
		}
		catch (Exception e) {
			LOGGER.error("readFileStoreData -> error processing data, error={}", ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("readFileStoreData -> DigiSec emails found, updatedCount={}", records.size());
		return records;
	}


	public static List<String> readFileStoreMemberPaymentData(String destination, String localDirectory, String filename,
															  Map<String, Object> sftpResult, Boolean isDailyScheduler) throws FileNotFoundException, SftpException, ApplicationException {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping readFileStoreMemberPaymentData as it's now within business hours.");
			return Collections.emptyList();
		}

		records = Collections.synchronizedList(new ArrayList<String>());

		headerValidationMemberPaymentPreference();
		copyFileToLocal(destination, localDirectory, filename, sftpResult);

		List<List<String>> recordLines = new ArrayList<List<String>>();
		try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(localDirectory + File.separator + filename)))) {
			recordLines = parseBufferReaderPaymentPreference(br);

			LOGGER.info("Processing count={}", recordLines.size());
			for (List<String> record : recordLines) {
				records.add(String.join(",", record));
			}
		} catch (IOException e) {
			LOGGER.error(READ_FILE_ERROR, destDir, destination,
					localDir, localDirectory, FILE_NAME, filename, SFTP_RESULT, sftpResult,
					ExceptionUtils.getStackTrace(e));
		}
		catch (Exception e) {
			LOGGER.error("readFileStoreMemberPaymentData -> error processing data, error={}", ExceptionUtils.getStackTrace(e));
		}

		return records;
	}


	public static List<String> readRetryData(String destination, String localDirectory, String filename,
			Map<String, Object> sftpResult, Boolean isDailyScheduler) throws FileNotFoundException, SftpException, ApplicationException {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping readRetryData as it's now within business hours.");
			return Collections.emptyList();
		}
		records = Collections.synchronizedList(new ArrayList<String>());
		copyFileToLocalNoDate(destination, localDirectory, filename, sftpResult);
		
		
		List<List<String>> recordLines = new ArrayList<List<String>>();
		try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(localDirectory + File.separator + filename)))) {
			System.out.println(br.readLine());
			recordLines = parseRetryReader(br);

			
		} catch (IOException e) {
			LOGGER.error(READ_FILE_ERROR, destDir, destination,
					localDir, localDirectory, FILE_NAME, filename, SFTP_RESULT, sftpResult,
			ExceptionUtils.getStackTrace(e));
		}
        catch (Exception e) {
        	LOGGER.error("readRetryData -> error processing retry data, error={}", ExceptionUtils.getStackTrace(e));
        }
		return records;
	}
	

	
public static List<String> readFileSendAutoEnroCloud(List<String> recordList) {
	if (TimeUtils.isWithinBusinessHours()) {
		LOGGER.info("Stopping readFileSendAutoEnroCloud as it's now within business hours.");
		return Collections.emptyList();
	}
		
		HttpHeaders httpHeaders = new HttpHeaders(); 
		AutoenrollmentRequest autoEnrollReq = new AutoenrollmentRequest();
		List<AutoenrollmentObj> autoEnrollList = Collections.synchronizedList(new ArrayList<>());
		
		for (String record : recordList) {
			AutoenrollmentObj autoEnrollObj = new AutoenrollmentObj();
			if (record == null) {
				continue;
			}
			String[] values = record.split(COMMA_DELIMITER);
			
			autoEnrollObj.setMpin(values[0].trim());
			autoEnrollObj.setTin(values[1].trim());
			autoEnrollObj.setFileName(values[2].trim()); 			
			try {
				autoEnrollObj.setProviderEmailId(values[4].trim());
			}
			catch (ArrayIndexOutOfBoundsException e) {
				autoEnrollObj.setProviderEmailId("");
			}
			
			autoEnrollList.add(autoEnrollObj);
		}
		autoEnrollReq.setAutoenrollDocuments(autoEnrollList);
		
		List<String> response = Collections.synchronizedList(new ArrayList<String>());
		try {
			response = autoenrollmentServiceImpl.createAutoenrollmentDocumentsFDSCloud(autoEnrollReq, httpHeaders);

		} catch (ApplicationException e) {
			LOGGER.error(AUTOENROLL_SEND_FAILURE, e.getMessage());
		}
		catch (Exception e) {
        	throw e;
        }
		LOGGER.info("readFileSendAutoEnroCloud -> processed Autoenrollment, file={}", SchedulerAutoEnrollment.currentFileName);
		
		return response;
	}

public static List<String> checkAutoenrollmentSetup(String sftpUSER, String sftpPASS, String sftpHost, String checkDir, String checkFileName) throws IOException, ApplicationException, JSchException        {
	if (TimeUtils.isWithinBusinessHours()) {
		LOGGER.info("Stopping checkAutoenrollmentSetup as it's now within business hours.");
		return Collections.emptyList();
	}
	
	if (sendGetExecutorService.isShutdown()) {
		sendGetExecutorService = Executors.newFixedThreadPool(Integer.parseInt(SchedulerConfig.THREADS_FDSCLOUD_GET));
	}
	if (digiSecGetExecutorService.isShutdown()) {
		digiSecGetExecutorService = Executors.newFixedThreadPool(Integer.parseInt(SchedulerConfig.THREADS_DIGISEC_GET));
	}
	
	List<FDSCloudRequest> docIdList = Collections.synchronizedList(new ArrayList<FDSCloudRequest>());
	
	ChannelSftp channelSftp= sftpFileHelper(sftpUSER, sftpPASS, sftpHost);	
	
	try (InputStream fileStream = channelSftp.get(checkDir + "/" + checkFileName)) {
		channelSftp.cd(checkDir);
		
		Integer fileRowCount = 0;
		LOGGER.info("Grabbing file={}", checkDir + "/" + checkFileName);
		
		try (BufferedReader getReadFile = new BufferedReader(new InputStreamReader(fileStream))) {
			docIdList = checkAutoenrollmentGET(getReadFile, fileStream, fileRowCount);
		} catch (IOException  e) {
			String getTrace=(ExceptionUtils.getStackTrace(e));
			LOGGER.error("readLoadTest Error, error={}", getTrace);
		}
		catch (Exception e) {
        	throw e;
        }
		
		
	} catch (SftpException e) {
		LOGGER.error("Load Test dir not found, loadTestDir={}", checkDir);
	}
	catch (Exception e) {
    	throw e;
    }
	
	List<String> searchTermResp = new ArrayList<String>();	
	if (!docIdList.equals(null) && docIdList.size() > 0) {
		for(FDSCloudRequest req: docIdList) {
			searchTermResp.add(fdsCloudHandler.encodeToUTF(req.getRequest().get("searchTerms").toString())); 
		}
	}
	else {
		
	}
	
	return searchTermResp;
}
	public static List<FDSCloudRequest> checkAutoenrollmentGET(BufferedReader readFile, InputStream fileStream, Integer fileRowCount) throws IOException, ApplicationException {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping checkAutoenrollmentGET as it's now within business hours.");
			return Collections.emptyList();
		}
		String line;
		HttpHeaders httpHeaders = new HttpHeaders(); 
//		List<FDSCloudRequest> fdsCloudList = new ArrayList<>();
		autoEnrollReq = new AutoenrollmentRequest();
		resendAEList = Collections.synchronizedList(new ArrayList<AutoenrollmentObj>());
		records = Collections.synchronizedList(new ArrayList<String>());
		List<AutoenrollmentObj> autoEnrollList = Collections.synchronizedList(new ArrayList<AutoenrollmentObj>());
		
		while ((line = readFile.readLine()) != null) {
			if (line.contains("MPIN") || line.contains("TIN") || line.contains("LETTER")) {
				continue;
			}
			AutoenrollmentObj metadata = new AutoenrollmentObj();
			
			String[] values = line.split(COMMA_DELIMITER);
			
			metadata.setMpin(values[0].trim());
			metadata.setTin(values[1].trim());
			metadata.setFileName(values[2].trim());
			metadata.setCorpMpin(values[0].trim());
			
			try {
				metadata.setCorpMpin(values[3].trim());
			}
			catch (ArrayIndexOutOfBoundsException e) {
				LOGGER.warn("checkAutoenrollmentGET -> Corporate MPIN null, replacing with providerMpin={}, record={}",values[0].trim(), line);
			}
			autoEnrollList.add(metadata);
		}
		
		
		missingDocList = Collections.synchronizedList(new ArrayList<FDSCloudRequest>());
		try {
			Token token = fdsCloudHandler.getFDSCloudToken("checkAutoenrollment");
			// get all the documents, replace the email in subsequent put

			for (AutoenrollmentObj request : autoEnrollList) {
				sendGetExecutorService.execute(new sendFDSCloudGetRequest(request));
			}
			serviceSendGetShutdown();
			LOGGER.info("DigiSec PAA complete, currentFileName={}, resendAEList={}, missingDocList={}, requestedList={}", SchedulerAutoEnrollment.currentFileName, resendAEList.size(), missingDocList.size(), autoEnrollList.size());
			
		}
		catch (Exception e) {
			LOGGER.error("Error processing sendFDSCloudGetRequest, error={}", ExceptionUtils.getStackTrace(e));
        	throw e;
        }
		
		if(resendAEList.size() > 0) {
			
			// updates records
			
			LOGGER.info("Resending {} records -> DigiSec", resendAEList.size());
			Token token = digitalSecurityServiceImpl.getDigiSecToken("autoenrollmentPAAEmail");	
			
			processResendAEList();
			
			serviceDigiSecGetShutdown();
			
			LOGGER.info("Sending {} records -> AutoEnrollment POST, currentFileName: {}", records.size(), SchedulerAutoEnrollment.currentFileName);
			List<String> response = readFileSendAutoEnroCloud(records);
			LOGGER.info("Sent {} records -> Completed check", response.size());
		}
		
		LOGGER.info("SFTP Unique MPINs with no email: {}, currentFileName: {}", sftpIndividualMpins.size(), SchedulerAutoEnrollment.currentFileName);
		LOGGER.info("SFTP Blank emails found: {}", sftpBlankEmails);
		return missingDocList; 
		
	}



	public static void copyFileToLocal(String destination, String localDirectory, String filename,
			Map<String, Object> sftpResult) throws SftpException {

		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);

		copyFilefromsftpTolocal(sftpChannel, filename, localDirectory,
				destination);
	}
	
	public static void copyFileToLocalNoDate(String destination, String localDirectory, String filename,
			Map<String, Object> sftpResult) throws SftpException {

		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);

		copyFilefromsftpTolocal(sftpChannel, filename, localDirectory,
				destination);
	}

	private static void copyFilefromsftpTolocal(ChannelSftp sftpChannel, String filename, String localDirectory,
			String sftpDirectory) throws SftpException {
		checkFileExistsOrNot(filename, localDirectory);
		LOGGER.info("Destination = {}", sftpDirectory + File.separator + filename);
		LOGGER.info("local = {}",  localDirectory);
		sftpChannel.get(sftpDirectory + File.separator + filename, localDirectory);

	}

	public static void checkFileExistsOrNot(String filename, String localDirectory) {
		try {
			if (Files.deleteIfExists(Paths.get(localDirectory + File.separator + filename))) {
				LOGGER.info("File Deleted: FileName={}, Directory={}", filename, localDirectory);
			}
		} catch (IOException e) {
			LOGGER.error("checkFileExistsOrNot  {}={}, {}={} {}", localDir, localDirectory, FILE_NAME,
					filename, ExceptionUtils.getStackTrace(e));
		}
	}

	public static void writeInCSVFile(Collection<String> completeData, String localDirectory) throws IOException {

		String result = completeData.stream().map(String::valueOf).collect(Collectors.joining("\n"));
		checkFileExistsOrNot(createDateintoString() + FILE_EXTENSION, localDirectory);

		try (FileWriter writer = new FileWriter(
				localDirectory + File.separator + createDateintoString() + "_PAAEmails" + FILE_EXTENSION)) {
			writer.write(result);
		} catch (IOException e) {
			LOGGER.error("writeInCSVFile  {}={}, {}={} {}", "completeData", completeData, localDir,
					localDirectory, ExceptionUtils.getStackTrace(e));
		}
	}

	public static void movefileFromlocalToServer(String localFilePath, Map<String, Object> sftpResult,
			String destination) throws SftpException, FileNotFoundException {
		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);
		File localFile = new File(localFilePath);
		
		LOGGER.info("currentFileName:  " + destination + File.separator);
		sftpChannel.cd(destination + File.separator);
		try (FileInputStream localStream = new FileInputStream(localFile)){
			sftpChannel.put(localStream, localFile.getName());
		}
		
		catch (IOException e ){
			LOGGER.error("movefileFromlocalToServer -> Error moving file to server, error={}", e.getMessage());
		}
	}

	public static void readFileFromServer(String destination, Map<String, Object> sftpResult, String workingDir) throws SftpException {
		readFileFromServer(destination, sftpResult, workingDir, false, "");
	}

	public static String readFileFromServer(String destination, Map<String, Object> sftpResult, String workingDir, boolean forceDelete, String fileToMove) throws SftpException {
		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);
		sftpChannel.cd(destination);

		@SuppressWarnings("unchecked")
		List<ChannelSftp.LsEntry> listFiles = (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING);
		for (ChannelSftp.LsEntry entry : listFiles) {
			String fileName = entry.getFilename();
			if (fileName.equals(fileToMove)) {
				String originalPath = workingDir + File.separator + fileName;
				String newPath = String.join(File.separator, destination, fileName);
				Boolean renameSuccess = rename(sftpChannel, originalPath, newPath, forceDelete);
				if (!renameSuccess) {
					return originalPath;
				}
				break;
			}
		}
		return "";
	}

	protected static Boolean rename(ChannelSftp sftpChannel, String originalPath, String newPath, boolean forceDelete) {
		try {
			sftpChannel.rename(originalPath, newPath);
			sftpChannel.stat(newPath);
		} catch(SftpException e) {
			LOGGER.error("Exception rename: originalPath={}, newPath={}, error={}", originalPath, newPath, e.getMessage());
			if (e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE) {
				Boolean retryCheck = retryRename(sftpChannel, originalPath, newPath);
				if (!retryCheck) {
					return retryCheck;
				}
			}
		}
		if (forceDelete) {
			try {  
				sftpChannel.rm(originalPath);
				LOGGER.error("ERROR: Removed originalPath={}", originalPath);
			} catch(SftpException e) {
				return retryRemove(sftpChannel, originalPath);
			}
		}
		return true;
	}
	
	protected static Boolean retryRename(ChannelSftp channel, String originalPath, String newPath) {
		for(int i = 0 ; i < 5; i++) {
			LOGGER.warn("LOOPING retryRename try: {}, originalPath:{}, newPath: {}", i, originalPath, newPath);
			try {
				channel.rename(originalPath, newPath);
				channel.stat(newPath);
				return true;
			}
			catch (SftpException e) {
				LOGGER.warn("rename -> Rename failure, retrying originalPath:{}, newPath: {}", originalPath, newPath);
			}
		}
		return false;
	}
	
	protected static Boolean retryRemove(ChannelSftp channel, String path) {
		for(int i = 0 ; i < 5; i++) {
			LOGGER.warn("LOOPING retryRemove try: {}, path: {}", i, path);
			try {
				channel.stat(path);
				channel.rm(path);
			}
			catch (SftpException e) {
				if (e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE) {
					return true; 
				}
				LOGGER.warn("rename -> Remove failure, retrying path: {}", path);
			}
		}
		return false;
	}

	public static Boolean validateEmail(String email) {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping validateEmail as it's now within business hours.");
			return false;
		}
		
		EmailValidator emailValidator = EmailValidator.getInstance();		
		return emailValidator.isValid(email);

	}

	public static void headerValidation() {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping headerValidation as it's now within business hours.");
			return;
		}
		headers.add(MPIN);
		headers.add(TAX_ID);
		headers.add(LETTERTYPE);
		headers.add(CORPORATE_MPIN);
	}

	public static void headerValidationEmailCheck(){
		headers.add(MPIN);
		headers.add(TAX_ID);
		headers.add(LETTERTYPE);
		headers.add(DOC_ID);
	}

	public static void headerValidationMemberPaymentPreference(){
		headers.add(TAX_ID);
		headers.add(MPIN);
		headers.add(ENROLLMENT);
		headers.add(ACTIVE);
		headers.add(ACCOUNT_NUMBER);
	}
	
	public static ChannelSftp sftpFileHelper(String sftpUSER, String sftpPASS, String sftpHost) throws JSchException {
		Session sftpSession;
		Channel channel;
		sftpSession = createSession(sftpUSER, sftpPASS, sftpHost, SFTP_PORT);
		channel = createSFTPChannel(sftpSession);
		return (ChannelSftp) channel;
	}

	public static void removeFileFromServer(Map<String, Object> sftpResult,
			String destination, String fileName) throws SftpException {
		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);
		sftpChannel.rm(destination + File.separator + fileName);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Removed file from server: file={}", destination + File.separator + fileName);
		}
	}

	public static Map<String, Long> readFileFromServerCheckSize(String destination, Map<String, Object> sftpResult, String workingDir, String fileType, String fileToMove)
			throws SftpException {
		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);
		sftpChannel.cd(destination);
		Map<String, Long> fileSizeMap = new HashMap<>();
		List<ChannelSftp.LsEntry> listFiles = (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING);
		for (ChannelSftp.LsEntry entry : listFiles) {
			String fileName = entry.getFilename();
			if (fileName.endsWith(fileType)) {
				fileSizeMap.put(fileName, entry.getAttrs().getSize());
				String originalPath = workingDir + File.separator + fileName;
				String newPath = String.join(File.separator, destination, fileName);
				sftpChannel.rename(originalPath, newPath);
			}
		}
		return fileSizeMap;
	}

	protected static Map<String, Long> getFilesToSplit(int splitPerMbSize, Map<String, Long> fileSizeMap) {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping getFilesToSplit as it's now within business hours.");
			return Collections.emptyMap();
		}
		Long fileSize;
		Map<String, Long> fileSplitMap = new HashMap<String, Long>();
		final long bytesPerSplit = 1024L * 1024L * splitPerMbSize;
		for (Map.Entry<String, Long> entry : fileSizeMap.entrySet()) {
			fileSize = entry.getValue();
			if (fileSize != null && fileSize >= bytesPerSplit) {
				fileSplitMap.put(entry.getKey(), fileSize);
			}
		}
		return fileSplitMap;
	}

	// If the file was not fully split i.e had an IOException it deletes any split file and returns empty List<Path>
	public static List<Path> splitFilePerMbPerNewLine(final String fileName, final int splitPerMbSize, int maxBytesNewLineWithin, String toDir, boolean delete, String fileType) {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping splitFilePerMbPerNewLine as it's now within business hours.");
			return Collections.emptyList();
		}
		List<Path> splitFiles = new ArrayList<>();
		if (splitPerMbSize <= 0) {
			return splitFiles;
		}

		long sourceSize;
		Path fileNamePath = Paths.get(fileName);
		try {
			sourceSize = Files.size(fileNamePath);
		} catch (IOException e) {
			LOGGER.error("Exception file.size: fileName={}; {}", fileName, ExceptionUtils.getStackTrace(e));
			return splitFiles;
		}

		final long bytesPerSplit = 1024L * 1024L * splitPerMbSize;
		if (sourceSize < bytesPerSplit) {
			LOGGER.info("Not splitting: fileName={}, sourceSize={}, bytesPerSplit={}", fileName, sourceSize, bytesPerSplit);
			return splitFiles;
		}
		LOGGER.info("Splitting: fileName={}, sourceSize={}, bytesPerSplit={}", fileName, sourceSize, bytesPerSplit);

		int i = 0;
		long offset = 0;
		long numSplits = sourceSize / bytesPerSplit;
		long remainingBytes = sourceSize % bytesPerSplit;
		long writtenByteSize = 0;
		long sourceSizeOrig = sourceSize;
		long writtenByteSizeTotal = 0;
		LOGGER.info("fileName={}, sourceSize={}, bytesPerSplit={}, numSplits={}, remainingBytes={}, splitPerMbSize={}, maxBytesNewLineWithin={}, toDir={}, delete={}",
				fileName, sourceSize, bytesPerSplit, numSplits, remainingBytes, splitPerMbSize, maxBytesNewLineWithin, toDir, delete);
		try {
			try (RandomAccessFile sourceFile = new RandomAccessFile(fileName, "r");
				FileChannel sourceChannel = sourceFile.getChannel()) {
				while (numSplits > 0) {
					LOGGER.info("PRE: fileName={}, i={}, sourceSize={}, offset={}, bytesPerSplit={}, numSplits={}, remainingBytes={}, writtenByteSize={}, writtenByteSizeTotal={}",
							fileName, i, sourceSize, offset, bytesPerSplit, numSplits, remainingBytes, writtenByteSize, writtenByteSizeTotal);
					writtenByteSize = writePartToSplitFile(fileName, ++i, offset, bytesPerSplit, maxBytesNewLineWithin, sourceChannel, splitFiles, toDir, false, fileType);
					writtenByteSizeTotal = writtenByteSizeTotal + writtenByteSize;
					sourceSize = sourceSize - writtenByteSize;
					offset = offset + writtenByteSize;
					numSplits = sourceSize / bytesPerSplit;
					remainingBytes = sourceSize % bytesPerSplit;
					LOGGER.info("POST: fileName={}, i={}, sourceSize={}, offset={}, bytesPerSplit={}, numSplits={}, remainingBytes={}, writtenByteSize={}, writtenByteSizeTotal={}",
						fileName, i, sourceSize, offset, bytesPerSplit, numSplits, remainingBytes, writtenByteSize, writtenByteSizeTotal);
				}
				if (remainingBytes > 0) {
					writtenByteSize = writePartToSplitFile(fileName,  ++i, offset, remainingBytes, maxBytesNewLineWithin, sourceChannel, splitFiles, toDir, true, fileType);
					writtenByteSizeTotal = writtenByteSizeTotal + writtenByteSize;
				}
			}
		} catch(IOException e) {
			LOGGER.error("Exception while splitting fileName={}: Backing out any splitFiles={}; msg={}", fileName,  splitFiles, e.getMessage());
			return backoutSplit(splitFiles);
		}
		if (sourceSizeOrig != writtenByteSizeTotal) {
			LOGGER.error("Done: Backing out any splitFiles; Bytes written splitFiles mismatch; fileName={}, sourceSizeOrig={}, writtenByteSizeTotal={}",
				fileName, sourceSizeOrig, writtenByteSizeTotal);
			return backoutSplit(splitFiles);
		} else {
			LOGGER.info("Done: fileName={}, sourceSizeOrig={}, writtenByteSizeTotal={}, splitFiles.size={}", fileName, sourceSizeOrig, writtenByteSizeTotal, splitFiles.size());
		}
		if (delete) {
			deleteFile(fileNamePath);
			LOGGER.info("Deleted original unsplit file={}", fileNamePath);
		}
		return splitFiles;
	}

	protected static long writePartToSplitFile(String origFile, int i, long offset, long bytesPerSplit, int maxBytesNewLineWithin, FileChannel sourceChannel,
			List<Path> splitFiles, String toDir, boolean remaining, String fileType) throws IOException {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping writePartToSplitFile as it's now within business hours.");
			return 0;
		}
		LOGGER.info("origFile={}, i={}, offset={}, bytesPerSplit={}, remaining={}", origFile, i, offset, bytesPerSplit, remaining);
		File origFileName = new File(origFile);
		Path fileName = Paths.get(toDir + File.separator + origFileName.getName() + "." + i + fileType);
		if (! remaining) {
			ByteBuffer buf = ByteBuffer.allocate(maxBytesNewLineWithin);
			LOGGER.info("origFile={}, fileName={}, i={}, offset={}, bytesPerSplit={}, newOffset={}",
				origFile, fileName, i, offset, bytesPerSplit, offset + bytesPerSplit - maxBytesNewLineWithin);
			int noOfBytesRead = sourceChannel.read(buf, offset + bytesPerSplit - maxBytesNewLineWithin);
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("origFile={}, i={}, noOfBytesRead={}, fileContent=<{}>", origFile, i, noOfBytesRead, new String(buf.array(), StandardCharsets.UTF_8));
			}
			boolean foundNewLine = false;
			for (int index = maxBytesNewLineWithin - 1; index >= 0; index--) {
				byte currentByte = buf.get(index);
				if (currentByte == '\n') {
					LOGGER.info("NEWLINE found: origFile={}, i={}, offset={}, bytesPerSplit={}, index={}", origFile, i, offset, bytesPerSplit, index);
					foundNewLine = true;
					break;
				}
				bytesPerSplit--;
			}
			LOGGER.info("origFile={}, i={}, offset={}, bytesPerSplit={}, foundNewLine={},", origFile, i, offset, bytesPerSplit, foundNewLine);
		}
		try (RandomAccessFile toFile = new RandomAccessFile(fileName.toFile(), "rw");
				FileChannel toChannel = toFile.getChannel()) {
			sourceChannel.position(offset);
			toChannel.transferFrom(sourceChannel, 0, bytesPerSplit);
		}
		splitFiles.add(fileName);
		return bytesPerSplit;
	}

	protected static List<Path> backoutSplit(List<Path> splitFiles) {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping backoutSplit as it's now within business hours.");
			return Collections.emptyList();
		}
		LOGGER.warn("Backing out splitFile={}", splitFiles);
		for (Path path : splitFiles) {
			if (deleteFile(path)) {
				LOGGER.warn("Deleted splitFile={}", path);
			}
		}
		return new ArrayList<>();
	}

	protected static boolean deleteFile(Path path) {
		try {
			Files.delete(path);
			return true;
		} catch (IOException e) {
			LOGGER.error("Exception: Could not delete path={}; msg={}", path, e.getMessage());
			return false;
		}
	}

    /**
     * Utility method to create a new directory and move files between SFTP locations.
     * Handles both splitting and moving logic for both SchedulerAutoEnrollment and SchedulerMonthly.
     */
    public static boolean createNewDirectoryAndMoveFiles(
            Logger logger,
            String fixedWorkingDirectory,
            String fixedDestinationDirectory,
            String directoryFromEnv,
            String directoryToEnv,
            String prunUserName,
            String prunKey,
            String prunHost,
            String fileExtension,
            String splitCsvPerMaxMbSizeEnv,
            String splitMaxBytesNewLineWithinEnv,
            int splitPerMbSizeDefault,
            int maxBytesNewLineWithinDefault,
            String fileToMove,
            SplitFilesHandler splitFilesHandler
    ) {
        logger.info("createNewDirectoryAndMoveFiles: directoryFromEnv={}, directoryToEnv={}", directoryFromEnv, directoryToEnv);
        Map<String, Object> sftpResult = null;
        String directoryFrom = directoryFromEnv;
        try {
            if (!fixedWorkingDirectory.equals(directoryFromEnv)) {
                String directoryTo = directoryToEnv;
                sftpResult = SftpUtil.sftpDirectory(prunUserName, prunKey, prunHost, directoryFrom);
                logger.info("createNewDirectoryAndMoveFiles: {} != {}; directoryFrom={}, directoryTo={}", fixedWorkingDirectory, directoryFromEnv, directoryFrom, directoryTo);
                String renameSuccess = SftpUtil.readFileFromServer(directoryTo, sftpResult, directoryFrom, true, fileToMove);
                if (!renameSuccess.equals("")) {
                    String[] resendSplit = renameSuccess.split(File.separator); // originalPath + fileName with / separator
                    SftpUtil.removeFileFromSFTPLocation(prunUserName, prunKey,
                            prunHost, Integer.parseInt(SchedulerConfig.prunPort), resendSplit[0], resendSplit[1]);
                }
                return true;
            }

            logger.info("createNewDirectoryAndMoveFiles: {} == {}; directoryFrom={}, directoryTo={}", fixedWorkingDirectory, directoryFromEnv, directoryFrom, directoryToEnv);
            sftpResult = SftpUtil.sftpDirectory(prunUserName, prunKey, prunHost, directoryFrom);
            int splitPerMbSize = splitPerMbSizeDefault;
            int maxBytesNewLineWithin = maxBytesNewLineWithinDefault;
            try {
                splitPerMbSize = Integer.parseInt(splitCsvPerMaxMbSizeEnv);
                maxBytesNewLineWithin = Integer.parseInt(splitMaxBytesNewLineWithinEnv);
            } catch(NumberFormatException e) {
                logger.error("Exception: Defaulting splitPerMbSize={}, maxBytesNewLineWithin={}; {}", splitPerMbSize, maxBytesNewLineWithin, e.getMessage());
            }
            Map<String, Long> fileSizeMap = SftpUtil.readFileFromServerCheckSize(directoryToEnv, sftpResult, directoryFrom, fileExtension, "");
            if (fileSizeMap.isEmpty()) {
                return false;
            }
            Map<String, Long> splitFileMap = SftpUtil.getFilesToSplit(splitPerMbSize, fileSizeMap);
            if (!splitFileMap.isEmpty() && splitFilesHandler != null) {
                splitFilesHandler.splitFiles(fixedDestinationDirectory, splitPerMbSize, maxBytesNewLineWithin, splitFileMap);
            }
            return true;
        } catch (JSchException | SftpException e) {
            logger.error("createNewDirectoryAndMoveFiles: {}={}, {}={}, {}={}, {}={} {}", "PRUN_HOST", "***",
                "PRUN_USERNAME", "***", "PRUN_KEY", "***",
                directoryFromEnv, directoryFrom, ExceptionUtils.getStackTrace(e));
            return false;
        } finally {
            if (sftpResult != null) {
                SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get("channelSftp"), (Session) sftpResult.get("sftpSession"), (Channel) sftpResult.get("channel"));
                logger.info("End of createNewDirectoryAndMoveFiles: finally method - sftp connection closed");
            }
        }
    }

    // Handler interface for splitting files, to be implemented by the caller
    public interface SplitFilesHandler {
        void splitFiles(String prunDestinationDirectory, int splitPerMbSize, int maxBytesNewLineWithin, Map<String, Long> splitFileMap);
    }

	public static class getDigiSecEmailRequest implements Runnable{
		List<String> record;
		
		public getDigiSecEmailRequest(List<String> record) {
			this.record = record;
		}
		
		@Override
		public void run() {
			if (TimeUtils.isWithinBusinessHours()) {
				LOGGER.info("getDigiSecEmailRequest Task interrupted due to business hours.");
				return;
			}
			List<String> emailRecord = new ArrayList<String>(record);
			try {
				String email = "";
				HttpHeaders httpHeaders = new HttpHeaders();
				try {
					// thread this

					if (!record.get(3).equals(null) && !record.get(3).equals("")) {
						ResponseEntity<User> emailResponse = digitalSecurityServiceImpl.getEmailsByCorporate(record.get(3).trim(), httpHeaders);
						if (emailResponse != null && 
								emailResponse.getBody() != null &&
								emailResponse.getBody().getEmail() != null &&
								emailResponse.toString().contains("email")) {
							email = emailResponse.getBody().getEmail().toString();

							if (!validateEmail(email)) {
								LOGGER.info("digitalSecurityServiceImpl -> Invalid email found: {}, dataline mpin|tin|fileName|corpMpin|email={},{},{},{},{}",
										email, record.get(0), record.get(1),  record.get(2), record.get(3).trim(), email);
							}
						}
						else {
							email = "";
							SchedulerAutoEnrollment.emailNotFound.incrementAndGet();
							
// 							LOGGER.warn("Email not found request={}", record.toString());
						}
					}
					else {
						LOGGER.info("Skipping record={}", record.toString());
					}
					
				}

				catch (OAuthProblemException | OAuthSystemException | ApplicationException | HttpClientErrorException e) {
					LOGGER.warn("readFile -> Digital Security email call failed, email left as blank String"); 
				}
				catch (Exception e) {
					throw e;
				}
				
				
				emailRecord.add(email); 
				records.add(String.join(",", emailRecord));

			}	

			catch (Exception e) {
				 LOGGER.error("getDigiSecEmailRequest -> Error getting PAA email, record={}, error={}", emailRecord.toString(), ExceptionUtils.getStackTrace(e));
			}
			if (SchedulerAutoEnrollment.emailCount.incrementAndGet() % Integer.parseInt(SchedulerConfig.THREAD_COUNT_HEALTHCHECK) == 0) {
				LOGGER.info("getDigiSecEmailRequest emailCount={}", SchedulerAutoEnrollment.emailCount);
			}
		}
		
	}

	
	public static class sendFDSCloudGetRequest implements Runnable{
		AutoenrollmentObj request;
		
		public sendFDSCloudGetRequest(AutoenrollmentObj request) {
			this.request = request;
		}
		
		@Override
		public void run() {
			if (TimeUtils.isWithinBusinessHours()) {
				LOGGER.info("sendFDSCloudGetRequest Task interrupted due to business hours.");
				return;
			}
			try {
				Metadata metadata = new Metadata();
				
				metadata.setMpin(request.getMpin());
				metadata.setTin(request.getTin());
				metadata.setFileName(request.getFileName());
//				metadata.setProviderEmailId(request.getProviderEmailId());
				
				Map<String, Object> metadataMap = mapper.convertValue(metadata, new TypeReference<Map<String, Object>>() {});
				metadataMap.put("okTochangePDOInd", "N");
				

				FDSCloudRequest fdsCloudRequest = fdsCloudHandler.createSearchTermsRequestFromMap(mapper.convertValue(metadata, new TypeReference<Map<String, Object>>() {}));
				
				FDSCloudGETResponse getDocResponse = fdsCloudHandler.FDSCloudGetRequest("getLoadTestCloud", fdsCloudRequest);
								
				if (getDocResponse.getDocuments().size() == 0) {
					missingDocList.add(fdsCloudRequest);
					LOGGER.warn("GET DOCUMENT not found, request={}", request.toString());
					
					resendAEList.add(request);
					
				}
				else {
					if (fdsCloudHandler.getSearchTermsFromDocument(
							getDocResponse.getDocuments()
							.get(0))
							.get("providerEmailId").toString().isEmpty()) {
	           	 		sftpIndividualMpins.add(metadataMap.get("mpin").toString());
//	           	 		sftpBlankEmails += 1;
	           	 	}
				}
				
			}	

			catch (Exception e) {
				
				LOGGER.error("sendFDSCloudGetRequest -> error sending FDSCloud GET, tin={}, mpin={}, fileName={}, error={}", request.getTin(), request.getMpin(), request.getFileName(), ExceptionUtils.getStackTrace(e));
			}
			if (SchedulerAutoEnrollment.getCount.incrementAndGet() % Integer.parseInt(SchedulerConfig.THREAD_COUNT_HEALTHCHECK) == 0) {
				LOGGER.warn("existingEmailRequest getCount={}", SchedulerAutoEnrollment.getCount);
			}
		}
	}

	public static class getPESCorpMpinRequest implements Runnable{
		List<String> record;

		public getPESCorpMpinRequest(List<String> record) {
			this.record = record;
		}

		@Override
		public void run() {
			if (TimeUtils.isWithinBusinessHours()) {
				LOGGER.info("getPESCorpMpinRequest Task interrupted due to business hours.");
				return;
			}
			List<String> newRecord = new ArrayList<>(record);
			HttpHeaders httpHeaders = new HttpHeaders();
			String corpMpin =  "";
			String email = "";

			//fetching CORPMPIN
			try{
				if (!record.get(1).equals(null) && !record.get(1).isEmpty()) {
					corpMpin = PESCorpMpinHandler.getCorpMpin(record.get(1).trim());
				}
				else {
					LOGGER.info("no tin found, Skipping record={}", record);
				}

			}
			catch ( ApplicationException | HttpClientErrorException e) {
				LOGGER.warn("PES corpMpin call failed, left as blank String, error={} {}", e.getMessage(), ExceptionUtils.getStackTrace(e));
			}
			catch (Exception e) {
				LOGGER.error("getPESCorpMpinRequest -> Error getting corpMpin, record={}, error={}", newRecord, ExceptionUtils.getStackTrace(e));
			}

			newRecord.add(corpMpin);

			//fetching EMAIL
			try{
				if (!corpMpin.isEmpty()) {
					ResponseEntity<User> emailResponse = digitalSecurityServiceImpl.getEmailsByCorporate(corpMpin, httpHeaders);
					if (emailResponse != null &&
							emailResponse.getBody() != null &&
							emailResponse.getBody().getEmail() != null &&
							emailResponse.toString().contains("email")) {

						email = emailResponse.getBody().getEmail();
						if (!validateEmail(email)) {
							LOGGER.info("digitalSecurityServiceImpl -> Invalid email found: {}, dataline mpin|tin|fileName|corpMpin={},{},{},{}",
									email, record.get(0), record.get(1),  record.get(2), Encode.forJava(corpMpin));
						}
					}
					else {
						SchedulerMonthly.emailNotFound.incrementAndGet();
						tinsWithoutEmail.add(record.get(1).trim());
					}
				}
				else {
					LOGGER.info("no corpmpin found, Skipping record={}", record);
					SchedulerMonthly.emailNotFound.incrementAndGet();
					tinsWithoutEmail.add(record.get(1).trim());
				}
			}
			catch (OAuthProblemException | OAuthSystemException | ApplicationException | HttpClientErrorException e) {
				LOGGER.warn("readFile -> Digital Security email call failed, email left as blank String  {}", ExceptionUtils.getStackTrace(e));
			}
			catch (Exception e) {
				LOGGER.error("getPESCorpMpinRequest -> Error getting email, record={}, error={}", Encode.forJava(newRecord.toString()), ExceptionUtils.getStackTrace(e));
			}

			newRecord.add(email);
			LOGGER.info("Missing Email Update Record  : {}", Encode.forJava(newRecord.toString()));

			//UPDATE EMAIL
			ProviderPreferencesObj providerPreferences = new ProviderPreferencesObj();
			try {
				if (!email.isEmpty()) {
					SchedulerMonthly.emailCount.incrementAndGet();
					SchedulerMonthly.tinsUpdatedEmail.add(record.get(1).trim());

					ArrayList<String> selectedProviders = new ArrayList<>();
					selectedProviders.add(record.get(0));
					ArrayList<PreferenceType> preferenceTypes = new ArrayList<>();
					PreferenceType preferenceType = new PreferenceType();
					preferenceType.setClassifier(record.get(2));
					preferenceType.setProviderEmailId(email);
					preferenceTypes.add(preferenceType);
					providerPreferences.setCorporateTin(record.get(1));
					providerPreferences.setSelectedProviders(selectedProviders);
					providerPreferences.setPreferenceTypes(preferenceTypes);

					providerPreferenceServiceImpl.updateProviderPreferencesFDSCloud(providerPreferences, httpHeaders);
				}
			}
			catch (Exception e) {
				LOGGER.error("getPESCorpMpinRequest -> Error updating fdscloud, providerPreferencesObject={}, error={}", providerPreferences, ExceptionUtils.getStackTrace(e));
			}
			records.add(String.join(",", newRecord));
		}
	}

	private static List<List<String>> parseRetryReader(BufferedReader br) throws ApplicationException, IOException {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping parseRetryReader as it's now within business hours.");
			return Collections.emptyList();
		}
		String line;
		List<List<String>> exportBufferLines = new ArrayList<List<String>>();
			try {
				while ((line = br.readLine()) != null) {

					Map<String, Object> values = retryLineFormat(line);
					 
					FDSCloudRequest retryPostReq = new FDSCloudRequest();
					retryPostReq.setRequest(values);
					
					Gson gson = new Gson();
                	String requestString = gson.toJson(retryPostReq.getRequest());
					LOGGER.info("Retry Resend FDS Cloud -> request={}", requestString);
					
					fdsCloudHandler.FDSCloudPostRequest("retryFDSCloud", retryPostReq);

					
			}
			} catch (ApplicationException | IOException e) {
				throw e; 
			}
			
		return exportBufferLines;
	
		
	}
	
	private static Map<String, Object> retryLineFormat(String line) {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping retryLineFormat as it's now within business hours.");
			return Collections.emptyMap();
		}
		Map<String, Object> exportMap = new HashMap<String, Object>();
		
		line = line.replace("\"\"", "");
		String[] exportLine = line.split("}}");
		exportLine = exportLine[0].split("-> ");
		exportLine = exportLine[1].split("\\{");
		exportLine = exportLine[1].split(COMMA_DELIMITER);
		
		for (String field : exportLine) {
			String[] tempField = field.split(":");
			exportMap.put(tempField[0], tempField[1]);
		}
		
	
//		[0].split("-> ")[1].split("{")[1].split(COMMA_DELIMITER);
		
		return exportMap;
	}
	
	private static List<List<String>> parseBufferReader(BufferedReader br) throws IOException {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping parseBufferReader as it's now within business hours.");
			return Collections.emptyList();
		}
		String line;
		List<List<String>> exportBufferLines = new ArrayList<List<String>>();
			try {
				while ((line = br.readLine()) != null) {
					if (line.contains("MPIN") || line.contains("TIN") || line.contains("LETTER")) {
						continue;
					}
					String[] values = line.split(COMMA_DELIMITER);
					
					List<String> recordLine = new ArrayList<String>();
					boolean allFieldsGood = validateBuffer(values, line);
					if (allFieldsGood && values.length > 1) {
						
						recordLine.add(values[0].trim()); // MPIN
						recordLine.add(values[1].trim()); // TIN
						recordLine.add(values[2].trim()); // FILENAME
						try {
							recordLine.add(values[3].trim()); // CORPMPIN
						}
						catch (ArrayIndexOutOfBoundsException e) {
							LOGGER.warn("readFileStoreData -> Corporate MPIN null, replacing with providerMpin={}, record={}",values[0].trim(), line);
							recordLine.add(values[0].trim());
						}
						exportBufferLines.add(recordLine);
					}
//					LOGGER.info("Adding record={}", recordLine.toString());
			}
			} catch (IOException e) {
				throw e; 
			}
			
		return exportBufferLines;
	}

	private static List<List<String>> parseBufferReaderEmailCheck(BufferedReader br) throws IOException {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping parseBufferReaderEmailCheck as it's now within business hours.");
			return Collections.emptyList();
		}
		String line;
		List<List<String>> exportBufferLines = new ArrayList<List<String>>();
		try {
			while ((line = br.readLine()) != null) {
				if (line.contains("MPIN") || line.contains("TAX") || line.contains("LETTER") || line.contains("DOC")) {
					continue;
				}
				String[] values = line.split(COMMA_DELIMITER);

				List<String> recordLine = new ArrayList<String>();
				boolean allFieldsGood = validateBufferEmailCheck(values, line);
				if (allFieldsGood && values.length > 1) {

					recordLine.add(values[0].trim()); // MPIN
					recordLine.add(values[1].trim()); // TIN
					recordLine.add(values[2].trim()); // FILENAME
					recordLine.add(values[3].trim()); // DOC ID
					exportBufferLines.add(recordLine);
					LOGGER.info("parseBufferReaderEmailCheck : Validation Complete");
				}
			}
		} catch (IOException e) {
			throw e;
		}
		return exportBufferLines;

	}

	private static List<List<String>> parseBufferReaderPaymentPreference(BufferedReader br) throws IOException {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping parseBufferReader-PaymentPreference as it's now within business hours.");
			return Collections.emptyList();
		}
		String line;
		List<List<String>> exportBufferLines = new ArrayList<List<String>>();
		try {
			while ((line = br.readLine()) != null) {
				if (line.contains("MPIN") || line.contains("TIN") || line.contains("ENROLLMENT") || line.contains("ACTIVE") || line.contains("ACCOUNT")) {
					continue;
				}
				String[] values = line.split(COMMA_DELIMITER);

				List<String> recordLine = new ArrayList<String>();
				boolean allFieldsGood = validateBufferMemberPaymentPreference(values, line);
				if (allFieldsGood && values.length > 1) {

					recordLine.add(values[0].trim()); // tin
					recordLine.add(values[1].trim()); // mpin
					recordLine.add(values[2].trim()); // ENROLLMENT
					recordLine.add(values[3].trim()); // ACTIVE
					recordLine.add(values[4].trim()); // ACC. NUMBER
					LOGGER.info("parseBufferReaderPaymentPreference : Validation Complete");
					exportBufferLines.add(recordLine);
				}
			}
		} catch (IOException e) {
			throw e;
		}

		return exportBufferLines;
	}

	private static Boolean validateBuffer(String[] values, String line) {
		boolean validation = true;
		for (int i = 0; i < values.length; i++) {
			if (!predicateMap.getOrDefault(i, x -> true).test(values[i].trim())) {
				if(!headers.contains(values[i].trim())) {
					String value=values[i].trim();
					LOGGER.error(readFileVal, value, line);
				}
				else {
					continue;
				}
				validation = false;
				continue;
			}
		}
		return validation;
	}

	private static Boolean validateBufferEmailCheck(String[] values, String line) {
		boolean validation = true;
		for (int i = 0; i < values.length; i++) {
			if (!predicateMapEmailCheck.getOrDefault(i, x -> true).test(values[i].trim())) {
				if(!headers.contains(values[i].trim())) {
					String value=values[i].trim();
					LOGGER.error(readFileVal, value, line);
				}
				else {
					continue;
				}
				validation = false;
				continue;
			}
		}
		return validation;
	}

	private static Boolean validateBufferMemberPaymentPreference(String[] values, String line) {
		boolean validation = true;
		for (int i = 0; i < values.length; i++) {
			if (!predicateMapMemberPaymentPreference.getOrDefault(i, x -> true).test(values[i].trim())) {
				if(!headers.contains(values[i].trim())) {
					String value=values[i].trim();
					LOGGER.error(readFileVal, value, line);
				}
				else {
					continue;
				}
				validation = false;
				continue;
			}
		}
		return validation;
	}

	private static void serviceDigiSecGetShutdown() {
		digiSecGetExecutorService.shutdown();
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping serviceDigiSecGetShutdown as it's now within business hours.");
			return;
		}
		try { 
			digiSecGetExecutorService.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			LOGGER.error(THREADING_FAILED, ExceptionUtils.getStackTrace(e));
		}
        catch (Exception e) {
        	throw e;
        }
	}

	private static void servicePESGetShutdown() {
		EmailCheckExecutorService.shutdown();

		try {
			EmailCheckExecutorService.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			LOGGER.error(THREADING_FAILED, ExceptionUtils.getStackTrace(e));
		}
		catch (Exception e) {
			throw e;
		}
	}
	
	private static void serviceSendGetShutdown() {
		sendGetExecutorService.shutdown();
		
		try { 
			sendGetExecutorService.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			LOGGER.error(THREADING_FAILED, ExceptionUtils.getStackTrace(e));
		}
	}
	
	private static void processResendAEList() {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping processFiles as it's now within business hours.");
			return;
		}
		for (AutoenrollmentObj record : resendAEList) {
			//MPIN, TIN, FILENAME, CORPMPIN
			String mpin = !record.getMpin().equals(null) ? record.getMpin() : "";
			String tin = !record.getTin().equals(null) ? record.getTin() : "";
			String fileName = !record.getFileName().equals(null) ? record.getFileName() : "";
			String corpMpin = !record.getCorpMpin().equals(null) ? record.getCorpMpin() : "";
			List<String> retryAuto = Arrays.asList(mpin, tin, fileName, corpMpin);
			digiSecGetExecutorService.execute(new getDigiSecEmailRequest(retryAuto));
		}
	}

	public static String jsonFileToCsv(String workingDir, String jsonFileName, String fixedWorkingDirectory, String fixedDestinationDirectory, String directoryFromEnv, String directoryToEnv, String fileToMove) {
		String csvFilepath = workingDir + File.separator + jsonFileName.split(".json")[0] + ".csv";
		try {
			LOGGER.info("Entering : JSON file to CSV conversion process for filename : {}", jsonFileName);

			BufferedReader reader = new BufferedReader(new FileReader(workingDir + File.separator + jsonFileName));
			StringBuilder jsonContent = new StringBuilder();
			String line;
			while ((line = reader.readLine()) != null) {
				jsonContent.append(line);
			}
			reader.close();

			ObjectMapper objectMapper = new ObjectMapper();
			ArrayNode jsonArray = (ArrayNode) objectMapper.readTree(jsonContent.toString());

			FileWriter csvWriter = new FileWriter(csvFilepath);
			csvWriter.append("MPIN,TAX ID,LETTER TYPE, DOC ID\n");
			for (int i = 0; i < jsonArray.size(); i++) {
				JSONObject temp = new JSONObject(jsonArray.get(i).toString());

				JSONObject record = temp.getJSONObject("ST");
				String tin = record.get(TIN).toString();
				String mpin = record.get("mpin").toString();
				String filePath = record.getString(FILE_NAME);
				String docId = temp.getString("docId");
				csvWriter.append(String.format("%s,%s,%s,%s\n", mpin, tin, filePath, docId));
			}
			csvWriter.flush();
			csvWriter.close();

            LOGGER.info("Monthly Email Check : JSON file to CSV conversion complete : CSV file saved at {}", csvFilepath);
            LOGGER.info("Moving .json file: {} to /processed", jsonFileName);
			SftpUtil.createNewDirectoryAndMoveFiles(
				LOGGER,
				fixedWorkingDirectory,
				fixedDestinationDirectory,
				directoryFromEnv,
				directoryToEnv,
					SchedulerConfig.prunUserName,
					SchedulerConfig.prunKey,
					SchedulerConfig.prunHost,
				".json",
					SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE,
					SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN,
				20,
				256,
				fileToMove,
				null
			);
		} catch (Exception e) {
			LOGGER.error("Error at Monthly Email Check : Cannot Convert JSON file to CSV : Exception = {} ", e.getMessage());
		}
		return csvFilepath;
	}
	
}
