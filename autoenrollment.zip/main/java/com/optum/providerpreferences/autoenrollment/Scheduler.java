package com.optum.providerpreferences.autoenrollment;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.optum.providerpreferences.autoenrollment.config.SchedulerConfig;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.service.OptOutServiceImpl;

@Component
@ConfigurationProperties(prefix = "spring.datasource")
@ConditionalOnProperty(name = "SCHEDULER_AUTO_ENROLLMENT", havingValue = "false")
public final class Scheduler {

	public Scheduler() {
		//private constructor to hide public one
	}
	private static Logger logger = LogManager.getLogger(Scheduler.class);
	private static final String DIRECTORY_LISTING = "directoryListing";
	private static final String CHANNEL_SFTP = "channelSftp";
	private static final String SFTP_SESSION = "sftpSession";
	private static final String CHANNEL = "channel";
	private static final String FILE_EXTENSION = ".csv";
	private static final String PRUN_WORKING_DIRECTORY = "workingDirectory";
	private static final String PRUN_HOST = "prunhost";
	private static final String PRUN_USERNAME = "userName";
	private static final String PRUN_KEY = "prunPassword";
	private static final String PRUN_DESTINATION_DIRECTORY = "destinationDirectory";
	private static final String COUNT_CHECK = "data list size={}, emailCheck={}, getCount={}, postCount={}, emailNotFound={}";
	private static final String PROCESSFILES_EXCEPTION = "Exception while processFiles  {}={}, {}={}, {}={}, {}={}, {}={} {}";
	private static final String LOCAL_DIRECTORY_STRING = "slocalDirectory";
	private static final String MISSING_SFTP = "Scheduler : processFiles - Missing some of the sftp credentials";
	
	private static List<String> loadTestTimes = new ArrayList<String>();
	private static List<String> docIdList = new ArrayList<String>();
	private static List<String> missingDocIdList = new ArrayList<String>();
	
	@Autowired
	FDSHandler fdsHandler;
	
	@Autowired
	NDBHandler ndbHandler;
	
	@Autowired
	OptOutServiceImpl optOutService;

	private static AtomicBoolean lock = new AtomicBoolean(false);


	private static final String LOCAL_DIRECTORY;
	static {
		String path = String.join(File.separator, System.getProperty("user.home"), "auto_enrollment");
		if (path.contains("?")) {
			path = "/home/jboss/auto_enrollment";
		}
		File directory = new File(path);
		directory.mkdir();
		LOCAL_DIRECTORY = path;
	}
	

	@SuppressWarnings("unchecked") // Thursday before processsing
//	 @Scheduled(cron = "0 */3 * * * ?")
//	 @Scheduled(cron = "0 0 6 * * ?")

	public static void pollCSVFiles() {
		logger.info("Start of Scheduler : pollCSVFiles");
		if (lock.get()) {
			logger.info("Skipping {}: Scheduler already locked and running");
			return;
		}
		else {
			try {
				if (!SftpUtil.exceptionForMissingLoginCredential(
						SchedulerConfig.prunHost,
						SchedulerConfig.prunUserName,
						SchedulerConfig.prunKey,
						SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY)) {
					createNewDirectory();
					processFiles();
				} else {
					logger.warn("Scheduler : pollCSVFiles - Missing some of the sftp credentials");
				}
			} catch (IOException e) {
				logger.error("pollCSVFiles  {}={}, {}={}, {}={}, {}={} {}", PRUN_HOST, SchedulerConfig.prunHost,
						PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY, SchedulerConfig.prunKey,
						PRUN_WORKING_DIRECTORY, SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY, ExceptionUtils.getStackTrace(e));
			}
			finally {
				lock.set(false);
			}
		}

	}

	// moves files to processFiles
	private static void createNewDirectory() {
		Map<String, Object> sftpResult = null;
		try {
			sftpResult = SftpUtil.sftpDirectory(
				SchedulerConfig.prunUserName,
				SchedulerConfig.prunKey,
				SchedulerConfig.prunHost,
				SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY);

			SftpUtil.readFileFromServer(
				SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY,
				sftpResult,
				SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY);
		} catch (JSchException | SftpException e) {
			logger.error("createNewDirectory  {}={}, {}={}, {}={}, {}={} {}", PRUN_HOST, SchedulerConfig.prunHost,
					PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY, SchedulerConfig.prunKey,
					PRUN_WORKING_DIRECTORY, SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY, ExceptionUtils.getStackTrace(e));
		} finally {
			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
						(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
			}
		}
	}

	@SuppressWarnings("unchecked") // Thursday, 2 hour gap for poll
	public static void processFiles() {
		Map<String, Object> sftpResult = null;
		try {
			lock.set(true);

			if (SftpUtil.exceptionForMissingLoginCredential(
					SchedulerConfig.prunHost,
					SchedulerConfig.prunUserName,
					SchedulerConfig.prunKey,
					SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY)) {
				logger.warn(MISSING_SFTP);
				throw new IOException();
			}

			sftpResult = SftpUtil.sftpDirectory(
				SchedulerConfig.prunUserName,
				SchedulerConfig.prunKey,
				SchedulerConfig.prunHost,
				SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY);

			for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING)) {
				try {
					String fileName = entry.getFilename();
					if (fileName.endsWith(FILE_EXTENSION) && !fileName.contains("PAA")) {
						SchedulerAutoEnrollment.getCount.set(0);
						SchedulerAutoEnrollment.postCount.set(0);
						SchedulerAutoEnrollment.emailCount.set(0);
						SchedulerAutoEnrollment.lastSchedulerCount.set(0);
						SchedulerAutoEnrollment.emailNotFound.set(0);

						loadTestTimes = new ArrayList<String>();
						logger.info("Processing File {}", fileName);
						List<String> data = SftpUtil.readFileStoreData(
							SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY,
							LOCAL_DIRECTORY, fileName, sftpResult, true);
						docIdList = SftpUtil.readFileSendAutoEnroCloud(data);

						logger.info(COUNT_CHECK,
								data.size(), SchedulerAutoEnrollment.emailCount, SchedulerAutoEnrollment.getCount, SchedulerAutoEnrollment.postCount, SchedulerAutoEnrollment.emailNotFound);

						String originPath = String.join(File.separator, SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY, fileName);
						String destPath = String.join(File.separator, SchedulerConfig.PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY, fileName);
						SftpUtil.rename((ChannelSftp) sftpResult.get(CHANNEL_SFTP), originPath, destPath, true);
					}
				} catch (IOException | ApplicationException e) {
					logger.error("Exception while processFiles  {}={}, {}={}, {}={}, {}={}, {}={}, {}", PRUN_HOST,
							SchedulerConfig.prunHost, PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY,
							SchedulerConfig.prunKey, PRUN_DESTINATION_DIRECTORY,
							SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
							ExceptionUtils.getStackTrace(e));
				}
			}
		} catch (IOException | JSchException | SftpException e) {
			lock.set(false);

			logger.error(PROCESSFILES_EXCEPTION, PRUN_HOST,
					SchedulerConfig.prunHost, PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY,
					SchedulerConfig.prunKey, PRUN_DESTINATION_DIRECTORY,
					SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
					ExceptionUtils.getStackTrace(e));
		}
		finally {
			lock.set(false);

			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
						(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
				if (docIdList.size() > 0) {
					logger.info("processFiles -> Total {} documents inserted", docIdList.size());
					docIdList = new ArrayList<String>();
				}
				else {
					logger.info("processFiles -> No work to be done");
				}
			}
		}
	}
	
	private static void writeCSV(String fileName, Set<String> data, Map<String, Object> sftpRes, String directory) throws FileNotFoundException, SftpException, IOException{
		SftpUtil.writeInCSVFile(data, LOCAL_DIRECTORY);
		String createdCsv = LOCAL_DIRECTORY + File.separator
				+ SftpUtil.createDateintoString() + fileName + FILE_EXTENSION;
		SftpUtil.movefileFromlocalToServer(createdCsv, sftpRes,
				directory);
	}
	
	public static Set<String> checkAutoenrollment() {
		Set<String> missingData = new LinkedHashSet<>();

		SchedulerAutoEnrollment.getCount.set(0);
		SchedulerAutoEnrollment.postCount.set(0);
		SchedulerAutoEnrollment.emailCount.set(0);
		SchedulerAutoEnrollment.lastSchedulerCount.set(0);
		SchedulerAutoEnrollment.emailNotFound.set(0);

		Map<String, Object> sftpResult = null;

		try {
			String destinationPath = SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY;
			if (SftpUtil.exceptionForMissingLoginCredential(
					SchedulerConfig.prunHost,
					SchedulerConfig.prunUserName,
					SchedulerConfig.prunKey,
					destinationPath)) {
				logger.warn(MISSING_SFTP);
				return missingData;
			}

			sftpResult = SftpUtil.sftpDirectory(
				SchedulerConfig.prunUserName,
				SchedulerConfig.prunKey,
				SchedulerConfig.prunHost,
				destinationPath);

			for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING)) {
				try {
					SchedulerAutoEnrollment.getCount.set(0);
					SchedulerAutoEnrollment.postCount.set(0);
					SchedulerAutoEnrollment.emailCount.set(0);
					SchedulerAutoEnrollment.lastSchedulerCount.set(0);
					String fileName = entry.getFilename();
					if (fileName.endsWith(FILE_EXTENSION)) {
						loadTestTimes = new ArrayList<String>();
						logger.info("Processing File {}", fileName);
						SchedulerAutoEnrollment.currentFileName = fileName;

						loadTestTimes.add("autoEnroStart: ".concat(ZonedDateTime.now(ZoneOffset.UTC).toString()));

						missingDocIdList = SftpUtil.checkAutoenrollmentSetup(
							SchedulerConfig.prunUserName,
							SchedulerConfig.prunKey,
							SchedulerConfig.prunHost,
							destinationPath, fileName);
						loadTestTimes.add("autoEnroEnd: ".concat(ZonedDateTime.now(ZoneOffset.UTC).toString()));

						missingData.addAll(missingDocIdList);

						SftpUtil.removeFileFromSFTPLocation(
							SchedulerConfig.prunUserName,
							SchedulerConfig.prunKey,
							SchedulerConfig.prunHost,
							Integer.parseInt(SchedulerConfig.prunPort),
							destinationPath, fileName);

						logger.info(COUNT_CHECK,
								missingData.size(), SchedulerAutoEnrollment.emailCount, SchedulerAutoEnrollment.getCount, SchedulerAutoEnrollment.postCount, SchedulerAutoEnrollment.emailNotFound);
					}
				} catch (IOException | ApplicationException e) {
					logger.error("Exception while processFiles  {}={}, {}={}, {}={}, {}={}, {}={},{}={} {}", PRUN_HOST,
							SchedulerConfig.prunHost, PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY,
							SchedulerConfig.prunKey, PRUN_DESTINATION_DIRECTORY,
							SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
							"destinationPath", destinationPath, ExceptionUtils.getStackTrace(e));
				}
			}
		} catch (IOException | JSchException | SftpException e) {
			logger.error(PROCESSFILES_EXCEPTION, PRUN_HOST,
					SchedulerConfig.prunHost, PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY,
					SchedulerConfig.prunKey, PRUN_DESTINATION_DIRECTORY,
					SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
					ExceptionUtils.getStackTrace(e));
		}
		finally {
			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
						(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
				if (docIdList.size() > 0) {
					logger.info("checkAutoenrollment -> Total {} documents inserted", docIdList.size());
					docIdList = new ArrayList<String>();
				}
			}
		}
		return missingData;
	}

	public static Set<String> scheduledCheckAutoenrollment(String dirToCheck) {
		Set<String> missingData = new LinkedHashSet<>();

		SchedulerAutoEnrollment.getCount.set(0);
		SchedulerAutoEnrollment.postCount.set(0);
		SchedulerAutoEnrollment.emailCount.set(0);
		SchedulerAutoEnrollment.lastSchedulerCount.set(0);
		SchedulerAutoEnrollment.emailNotFound.set(0);

		try {
			String destinationPath = dirToCheck;

			Map<String, Object> sftpResult = null;
			if (!SftpUtil.exceptionForMissingLoginCredential(SchedulerConfig.prunHost, SchedulerConfig.prunUserName, SchedulerConfig.prunKey, destinationPath)) {
				logger.warn(MISSING_SFTP);
				return missingData;
			}

			try {
				sftpResult = SftpUtil.sftpDirectory(SchedulerConfig.prunUserName, SchedulerConfig.prunKey, SchedulerConfig.prunHost, destinationPath);
				for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING)) {
					SchedulerAutoEnrollment.getCount.set(0);
					SchedulerAutoEnrollment.postCount.set(0);
					SchedulerAutoEnrollment.emailCount.set(0);
					SchedulerAutoEnrollment.lastSchedulerCount.set(0);
					String fileName = entry.getFilename();
					if (fileName.endsWith(FILE_EXTENSION) && !fileName.contains("checked") && !fileName.equals(".") && !fileName.equals("..")) {

						SchedulerAutoEnrollment.currentFileName = fileName;
						loadTestTimes = new ArrayList<String>();
						logger.info("Checking File {}", fileName);

						missingDocIdList = SftpUtil.checkAutoenrollmentSetup(SchedulerConfig.prunUserName, SchedulerConfig.prunKey, SchedulerConfig.prunHost, destinationPath, fileName);
						loadTestTimes.add("autoEnroEnd: ".concat(ZonedDateTime.now(ZoneOffset.UTC).toString()));

						missingData.addAll(missingDocIdList);

						String originPath = String.join(File.separator, destinationPath, fileName);
						String destPath = String.join(File.separator, destinationPath, fileName.replace(FILE_EXTENSION, "_checked").concat(FILE_EXTENSION));
						SftpUtil.rename((ChannelSftp) sftpResult.get(CHANNEL_SFTP), originPath, destPath, true);

						logger.info(COUNT_CHECK,
								missingData.size(), SchedulerAutoEnrollment.emailCount, SchedulerAutoEnrollment.getCount, SchedulerAutoEnrollment.postCount, SchedulerAutoEnrollment.emailNotFound);
					}
				}
			} catch (IOException | JSchException | SftpException | ApplicationException e) {
				logger.error("Exception while processFiles  {}={}, {}={}, {}={}, {}={}, {}={},{}={} {}", PRUN_HOST,
						SchedulerConfig.prunHost, PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY,
						SchedulerConfig.prunKey, PRUN_DESTINATION_DIRECTORY,
						SchedulerConfig.PRUN_DESTINATION_PROCESSED_DIRECTORY, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
						"destinationPath", destinationPath, ExceptionUtils.getStackTrace(e));
			} finally {
				if (sftpResult != null) {
					SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
							(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));

					if (docIdList.size() > 0) {
						logger.info("scheduledCheckAutoenrollment -> Total {} documents inserted", docIdList.size());
					}
				}
			}

		} catch (IOException e) {
			logger.error(PROCESSFILES_EXCEPTION, PRUN_HOST,
					SchedulerConfig.prunHost, PRUN_USERNAME, SchedulerConfig.prunUserName, PRUN_KEY,
					SchedulerConfig.prunKey, PRUN_DESTINATION_DIRECTORY,
					SchedulerConfig.PRUN_DESTINATION_PROCESSED_DIRECTORY, LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
					ExceptionUtils.getStackTrace(e));
		}
		return missingData;
	}
}

