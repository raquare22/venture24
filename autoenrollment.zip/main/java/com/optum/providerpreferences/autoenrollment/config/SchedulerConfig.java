package com.optum.providerpreferences.autoenrollment.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SchedulerConfig {

    public static String SPLIT_CSV_PER_MAX_MB_SIZE;
    public static String SPLIT_MAX_BYTES_NEW_LINE_WITHIN;
    public static String prunHost;
    public static String prunUserName;
    public static String prunKey;
    public static String PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY;
    public static String PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY;
    public static String PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY;
    public static String PRUN_ONESHOT_NDB_WORKING_DIRECTORY;
    public static String PRUN_ONESHOT_NDB_DESTINATION_DIRECTORY;
    public static String PRUN_ONESHOT_NDB_ARCHIVE_DIRECTORY;
    public static String retryWorkingDirec;
    public static String retryProcessedDirec;
    public static String PRUN_DESTINATION_PROCESSED_DIRECTORY;
    public static String PRUN_EMAIL_HOST;
    public static String prunEmailFrom;
    public static String prunEmailMessage;
    public static String prunEmailTo;
    public static String prunEmailSubject;
    public static String prunEmailToPODM;
    public static String MEMBER_PAYMENT_PREFERENCE_WORKING_DIRECTORY;
    public static String MEMBER_PAYMENT_PREFERENCE_DESTINATION_DIRECTORY;
    public static String MEMBER_PAYMENT_PREFERENCE_ARCHIVE_DIRECTORY;
    public static String PRUN_WORKINGDIR_LOADTEST;
    public static String prunPort;
    public static String THREADS_DIGISEC_GET;
    public static String THREADS_FDSCLOUD_GET;
    public static String THREADS_PES_GET;
    public static String THREAD_COUNT_HEALTHCHECK;
    public static String PRUN_EMAIL_CHECK_WORKING_DIRECTORY;
    public static String PRUN_EMAIL_CHECK_DESTINATION_DIRECTORY;
    public static String PRUN_EMAIL_CHECK_ARCHIVE_DIRECTORY;


    @Value("${PRUN_EMAIL_CHECK_WORKING_DIRECTORY}")
    public void setPrunEmailCheckWorkingDirectory(String value) {
        PRUN_EMAIL_CHECK_WORKING_DIRECTORY = value;
    }

    @Value("${PRUN_EMAIL_CHECK_DESTINATION_DIRECTORY}")
    public void setPrunEmailCheckDestinationDirectory(String value) {
        PRUN_EMAIL_CHECK_DESTINATION_DIRECTORY = value;
    }

    @Value("${PRUN_EMAIL_CHECK_ARCHIVE_DIRECTORY}")
    public void setPrunEmailCheckArchiveDirectory(String value) {
        PRUN_EMAIL_CHECK_ARCHIVE_DIRECTORY = value;
    }

    @Value("${PRUN_WORKINGDIR_LOADTEST}")
    public void setWorkingDirecLoadTest(String value) {
        PRUN_WORKINGDIR_LOADTEST = value;
    }

    @Value("${PRUN_PORT}")
    public void setPrunPort(String value) {
        prunPort = value;
    };

    @Value("${PRUN_EMAIL_FROM}")
    public void setPrunEmailFrom(String value) {
        prunEmailFrom = value;
    }

    @Value("${PRUN_EMAIL_MSG}")
    public void setPrunEmailMessage(String value) {
        prunEmailMessage = value;
    }

    @Value("${PRUN_EMAIL_TO}")
    public void setPrunEmailTo(String value) {
        prunEmailTo = value;
    }

    @Value("${PRUN_EMAIL_SUBJECT}")
    public void setPrunEmailSubject(String value) {
        prunEmailSubject = value;
    }

    @Value("${PRUN_EMAIL_TO_PODM}")
    public void setPrunEmailToPODM(String value) {
        prunEmailToPODM = value;
    }


    @Value("${PRUN_EMAIL_HOST}")
    public void setPrunEmailHost(String value) {
        PRUN_EMAIL_HOST = value;
    }

    @Value("${SPLIT_CSV_PER_MAX_MB_SIZE}")
    public void setSplitCsvPerMaxMbSize(String value) {
        SPLIT_CSV_PER_MAX_MB_SIZE = value;
    }

    @Value("${SPLIT_MAX_BYTES_NEW_LINE_WITHIN}")
    public void setSplitMaxBytesNewLineWithin(String value) {
        SPLIT_MAX_BYTES_NEW_LINE_WITHIN = value;
    }

    @Value("${PRUN_HOST}")
    public void setPrunHost(String value) {
        prunHost = value;
    }

    @Value("${PRUN_USERNAME}")
    public void setPrunUserName(String value) {
        prunUserName = value;
    }

    @Value("${PRUN_PASSWORD}")
    public void setPrunKey(String value) {
        prunKey = value;
    }

    @Value("${MEMBER_PAYMENT_PREFERENCE_WORKING_DIRECTORY}")
    public void setMemberPaymentPreferenceWorkingDirectory(String value) {
        MEMBER_PAYMENT_PREFERENCE_WORKING_DIRECTORY = value;
    }

    @Value("${MEMBER_PAYMENT_PREFERENCE_DESTINATION_DIRECTORY}")
    public void setMemberPaymentPreferenceDestinationDirectory(String value) {
        MEMBER_PAYMENT_PREFERENCE_DESTINATION_DIRECTORY = value;
    }

    @Value("${MEMBER_PAYMENT_PREFERENCE_ARCHIVE_DIRECTORY}")
    public void setMemberPaymentPreferenceArchiveDirectory(String value) {
        MEMBER_PAYMENT_PREFERENCE_ARCHIVE_DIRECTORY = value;
    }

    @Value("${PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY}")
    public void setPrunAutoEnrollmentWorkingDirectory(String value) {
        PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY = value;
    }

    @Value("${PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY}")
    public void setPrunAutoEnrollmentDestinationDirectory(String value) {
        PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY = value;
    }

    @Value("${PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY}")
    public void setPrunAutoEnrollmentArchiveDirectory(String value) {
        PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY = value;
    }

    @Value("${PRUN_ONESHOT_NDB_WORKING_DIRECTORY}")
    public void setPrunOneshotNdbWorkingDirectory(String value) {
        PRUN_ONESHOT_NDB_WORKING_DIRECTORY = value;
    }

    @Value("${PRUN_ONESHOT_NDB_DESTINATION_DIRECTORY}")
    public void setPrunOneshotNdbDestinationDirectory(String value) {
        PRUN_ONESHOT_NDB_DESTINATION_DIRECTORY = value;
    }

    @Value("${PRUN_ONESHOT_NDB_ARCHIVE_DIRECTORY}")
    public void setPrunOneshotNdbArchiveDirectory(String value) {
        PRUN_ONESHOT_NDB_ARCHIVE_DIRECTORY = value;
    }

    @Value("${RETRY_WORKING_DIRECTORY}")
    public void setRetryWorkingDirec(String value) {
        retryWorkingDirec = value;
    }

    @Value("${RETRY_PROCESSED_DIRECTORY}")
    public void setRetryProcessedDirec(String value) {
        retryProcessedDirec = value;
    }

    @Value("${PRUN_DESTINATION_PROCESSED_DIRECTORY}")
    public void setPrunDestinationProcessedDirectory(String value) {
        PRUN_DESTINATION_PROCESSED_DIRECTORY = value;
    }

    @Value("${THREADS_DIGISEC_GET}")
    public void setThreadsDigiSecGet(String value) {
        THREADS_DIGISEC_GET = value;
    }

    @Value("${THREADS_FDSCLOUD_GET}")
    public void setThreadsFdsCloudGet(String value) {
        THREADS_FDSCLOUD_GET = value;
    }

    @Value("${THREADS_PES_GET}")
    public void setThreadsPesGet(String value) {
        THREADS_PES_GET = value;
    }

    @Value("${THREAD_COUNT_HEALTHCHECK}")
    public void setThreadCountHealthCheck(String value) {
        THREAD_COUNT_HEALTHCHECK = value;
    }
}