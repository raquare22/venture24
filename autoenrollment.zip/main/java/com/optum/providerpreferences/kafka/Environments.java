package com.optum.providerpreferences.kafka;

public enum Environments {
	LOCAL("local"),
	DEV("dev"),
	STAGE("stage"),
	PROD("prod");

	private final String env;

	Environments(String env) {
		this.env = env;
	}

	public String getEnv() {
		return env;
	}
}
