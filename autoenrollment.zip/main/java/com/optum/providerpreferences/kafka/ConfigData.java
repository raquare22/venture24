package com.optum.providerpreferences.kafka;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class ConfigData {
	
	 public static String brokers;
	 public static String topic;
	 public static String location;
	 public static String pvFileLoc;
	 public static String pw;
	 public static String askId;
	 public static String appName;
	 public static String vendor;
	 public static String product;
	 public static String producerType;
	 
	@Value("${nk.brokers}")
	public  void setBrokers(String brokers) {
		ConfigData.brokers = brokers;
	}
	@Value("${nk.topic}")
	public  void setTopic(String topic) {
		ConfigData.topic = topic;
	}
	@Value("${nk.location}")
	public  void setLocation(String location) {
		ConfigData.location = location;
	}
	@Value("${nk.pvFileLoc}")
	public  void setPvFileLoc(String pvFileLoc) {
		ConfigData.pvFileLoc = pvFileLoc;
	}
	@Value("${nk.pw}")
	public  void setPw(String pw) {
		ConfigData.pw = pw;
	}
	@Value("${nk.askId}")
	public  void setAskId(String askId) {
		ConfigData.askId = askId;
	}
	@Value("${nk.appName}")
	public  void setAppName(String appName) {
		ConfigData.appName = appName;
	}
	@Value("${nk.vendor}")
	public  void setVendor(String vendor) {
		ConfigData.vendor = vendor;
	}
	@Value("${nk.product}")
	public void setProduct(String product) {
		ConfigData.product = product;
	}
	@Value("${nk.producerType}")
	public  void setProducerType(String producerType) {
		ConfigData.producerType = producerType;
	}


	public String getBrokers() {
		return brokers;
	}

	public String getTopic() {
		return topic;
	}

	public String getLocation() {
		return location;
	}

	public String getPvFileLoc() {
		return pvFileLoc;
	}

	public String getPw() {
		return pw;
	}

	public String getAskId() {
		return askId;
	}

	public String getAppName() {
		return appName;
	}

	public String getVendor() {
		return vendor;
	}

	public String getProduct() {
		return product;
	}

	public String getProducerType() {
		return producerType;
	}
}