package com.optum.providerpreferences.kafka;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.optum.eis.event.model.environment;
import com.optum.eis.event.model.logClass;
import com.optum.eis.event.model.outcome;
import com.optum.eis.event.model.severity;

import com.optum.eis.kraken.core.constants.RequiredFieldsConstants;
import com.optum.eis.kraken.core.util.IpAddressUtil;
import com.optum.eis.kraken.kafka.producers.NessKafkaAsyncProducer;
import com.optum.eis.kraken.core.NessLog;

public class NessAppLog {
	private static final Logger LOGGER = LogManager.getLogger(NessAppLog.class);

	protected static final Properties requiredFields = getNewRequiredFields();

	protected static KafkaPublisher kafkaPublisher;
	protected static KafkaProducer kafkaProducer;
	protected static NessKafkaAsyncProducer kafkaAsyncProducer;
	protected static environment applicationEnvironment;
	protected static boolean shutdown = false;

	private NessAppLog() {}

	protected static Properties getNewRequiredFields() {
		Map<String, environment> applicationEnvironmentMap = new HashMap<>();
		applicationEnvironmentMap.put("prod", environment.PROD);
		applicationEnvironmentMap.put("stage", environment.STAGE);
		applicationEnvironmentMap.put("dev", environment.DEV);
		applicationEnvironmentMap.put("local", environment.TEST);
		Properties requiredFields = new Properties();
		String askId = ConfigData.askId;
		String appName = ConfigData.appName;
		String vendor = ConfigData.vendor;
		String product = ConfigData.product;
		requiredFields.put(RequiredFieldsConstants.APPLICATION_ASK_ID, askId);
		requiredFields.put(RequiredFieldsConstants.APPLICATION_NAME, appName);
		requiredFields.put(RequiredFieldsConstants.DEVICE_VENDOR, vendor);
		requiredFields.put(RequiredFieldsConstants.DEVICE_PRODUCT, product);
		try {
			InetAddress inetAddress = InetAddress.getLocalHost();
			requiredFields.put(RequiredFieldsConstants.DEVICE_HOSTNAME, inetAddress.getHostName());
			requiredFields.put(RequiredFieldsConstants.DEVICE_IP4, IpAddressUtil.convert(inetAddress.getHostAddress()));
		} catch (UnknownHostException e) {
			LOGGER.warn("Unknown localHost: {}", e.getMessage());
		}

		if (! KafkaProducer.getSetUp()) {
			LOGGER.warn("SETUP: OFF");
			kafkaPublisher = null;
			kafkaAsyncProducer = null;
			return requiredFields;
		}

		String producerType = ConfigData.producerType;
		if (producerType == null || producerType.equals("sync")) {
			kafkaPublisher = new KafkaPublisher();
			kafkaAsyncProducer = null;
			LOGGER.warn("SETUP: Using kafkaPublisher");
		} else {
			kafkaProducer = new KafkaProducer();
			kafkaAsyncProducer = kafkaProducer.getNewNessKafkaAsyncProducer();
			kafkaPublisher = null;
			LOGGER.warn("SETUP: Using kafkaAsyncProducer");
		}
		return requiredFields;
	}

	protected static NessLog.NessLogBuilder getNessLogBuilder() {
		return new NessLog.NessLogBuilder()
				.setRequiredFields(requiredFields)
				.setReceivedTime(System.currentTimeMillis())
				.setApplicationEnvironment(applicationEnvironment)
				.setSeverity(severity.INFO)
				.setLogClass(logClass.SECURITY_AUDIT);
	}

	public static void startup() {
		NessLog nessLog = getNessLogBuilder().setMsg("SystemStart:SUCCESS").buildLog();
		LOGGER.info("{}", nessLog.getLog());
		publishLog(nessLog);
	}

	public static void shutdown() {
		NessLog nessLog = getNessLogBuilder().setMsg("SystemStop:SUCCESS").buildLog();
		LOGGER.info("{}", nessLog.getLog());
		publishLog(nessLog);
		shutdown = true;
		LOGGER.warn("SHUTDOWN: true");
		if (kafkaPublisher != null) {
			LOGGER.warn("Closing the kafkaPublisher");
			kafkaPublisher.closeNessProducer();
			LOGGER.warn("Deleting the streamFile");
			kafkaPublisher.getKafkaProducer().deleteStreamFile();
		}
		else
		if (kafkaAsyncProducer != null) {
			LOGGER.warn("Closing the kafkaAsyncProducer");
			kafkaAsyncProducer.closeNessAsyncProducer();
			LOGGER.warn("Deleting the streamFile");
			kafkaProducer.deleteStreamFile();
		}
	}

	public static void createHttpLogEvent(HttpHeaders headers, String message, String response) {
		createHttpLogEvent(headers, message, response, true);
	}

	public static void createHttpLogEvent(HttpHeaders headers, String message, String response, boolean success) {
		NessLog.NessLogBuilder logBuilder = getNessLogBuilder().setMsg("Message received: " + message);
		if (success) {
			logBuilder.setOutcome(outcome.SUCCESS);
			logBuilder.setReason("responseSize=" + response.length());
		} else {
			logBuilder.setOutcome(outcome.FAILURE);
			logBuilder.setReason("response=" + response);
		}

		InetSocketAddress host = headers.getHost();
		if (host != null) {
			logBuilder.setSourceHostHostname(host.getHostName());
			logBuilder.setSourceHostPort(host.getPort());
		}
		NessLog nessLog = logBuilder.buildLog();
		LOGGER.debug("{}", nessLog.getLog());
		publishLog(nessLog);
	}

	public static void createHttpLogEvent(HttpHeaders headers, String message, ResponseEntity<?> responseEntity) {
		NessLog.NessLogBuilder logBuilder = getNessLogBuilder().setMsg("Message received: " + message);
		if (responseEntity != null && responseEntity.getStatusCode().is2xxSuccessful()) {
			logBuilder.setOutcome(outcome.SUCCESS);
			logBuilder.setReason("responseSize=" + Integer.toString(responseEntity.toString().length()));
		} else {
			logBuilder.setOutcome(outcome.FAILURE);
			String responseEntityString = responseEntity != null ? responseEntity.getStatusCode().toString() : "NULL";
			logBuilder.setReason("response=" + responseEntityString);
		}
		InetSocketAddress host = headers.getHost();
		if (host != null) {
			logBuilder.setSourceHostHostname(host.getHostName());
			logBuilder.setSourceHostPort(host.getPort());
		}
		NessLog nessLog = logBuilder.buildLog();
		LOGGER.debug("{}", nessLog.getLog());
		publishLog(nessLog);
	}

	protected static void publishLog(NessLog nessLog ) {
		if (shutdown) {
			LOGGER.warn("SHUTDOWN: return");
			return;
		}
		if (kafkaPublisher != null) {
			kafkaPublisher.publishToKafka(nessLog);
		}
		else
		if (kafkaAsyncProducer != null) {
			kafkaAsyncProducer.publishNessLogsAsync(nessLog);
		}
	}
}