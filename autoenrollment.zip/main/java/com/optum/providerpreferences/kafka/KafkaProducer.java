package com.optum.providerpreferences.kafka;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.optum.eis.kraken.core.exceptions.NessLoggerValidationException;
import com.optum.eis.kraken.kafka.producers.NessKafkaAsyncProducer;
import com.optum.eis.kraken.kafka.producers.NessKafkaProducer;

public class KafkaProducer {
	private static final Logger LOGGER = LogManager.getLogger(KafkaProducer.class);

	private static final String NULL = "NULL";
	private static final String NOT_NULL = "! NULL";

	private static boolean setUp = true;

	protected NessKafkaProducer nessKafkaProducer = null;
	protected NessKafkaAsyncProducer nessKafkaAsyncProducer = null;

	private File streamFile = null;

	public static void setUpOff() {
		setUp = false;
	}

	public static boolean getSetUp() {
		return setUp;
	}

	public NessKafkaProducer getNessKafkaProducer() {
		return nessKafkaProducer == null ? getNewNessKafkaProducer() : nessKafkaProducer;
	}

	public NessKafkaProducer getNewNessKafkaProducer()
	{
		String nkBrokers = ConfigData.brokers;
		String nkTopic = ConfigData.topic;
		String nkLoc = ConfigData.location;
		String nkPvFileLoc = ConfigData.pvFileLoc;
		streamFile = getNessKafkaKeystoreFile(nkLoc, nkPvFileLoc);
		nkLoc = streamFile != null ? streamFile.getAbsolutePath() :  null;
		String nkPw = ConfigData.pw;
		String askId = ConfigData.askId;
		if (nkBrokers == null || nkTopic == null || nkLoc == null || nkPvFileLoc == null || nkPw == null || askId == null) {
			LOGGER.error("SETUP Sync Failed: nkBrokers={}, nkTopic={}, nkLoc={}, nkPvFileLoc={}, nkPw={}, askId={}",
				nkBrokers, nkTopic, nkLoc, nkPvFileLoc, nkPw == null ? NULL : NOT_NULL, askId);
			return null;
		}
		nessKafkaProducer = getNewNessKafkaSyncProducer(nkBrokers, nkTopic, nkLoc, nkPw, askId);
		return nessKafkaProducer;
	}

	public NessKafkaAsyncProducer getNewNessKafkaAsyncProducer()
	{
		String nkBrokers = ConfigData.brokers;
		String nkTopic = ConfigData.topic;
		String nkLoc = ConfigData.location;
		String nkPvFileLoc = ConfigData.pvFileLoc;
		streamFile = getNessKafkaKeystoreFile(nkLoc, nkPvFileLoc);
		nkLoc = streamFile != null ? streamFile.getAbsolutePath() : null;
		String nkPw = ConfigData.pw;
		String askId = ConfigData.askId;
		if (nkBrokers == null || nkTopic == null || nkLoc == null || nkPvFileLoc == null || nkPw == null || askId == null) {
			LOGGER.error("SETUP Async Failed: nkBrokers={}, nkTopic={}, nkLoc={}, nkPvFileLoc={}, nkPw={}, askId={}",
				nkBrokers, nkTopic, nkLoc, nkPvFileLoc, nkPw == null ? NULL : NOT_NULL, askId);
			return null;
		}
		nessKafkaAsyncProducer = getNewNessKafkaAsyncProducer(nkBrokers, nkTopic, nkLoc, nkPw, askId);
		return nessKafkaAsyncProducer;
	}

	protected void deleteStreamFile() {
		if (streamFile != null && streamFile.delete()) {
			LOGGER.warn("Deleted streamFile");
		}
	}

	protected static File createFileFromStream(InputStream in, String nkPvFileLoc) throws IOException {
		final File fileLoc = new File(nkPvFileLoc + "/cert.jks");
		try (FileOutputStream out = new FileOutputStream(fileLoc)) {
			IOUtils.copy(in, out);
		}
		return fileLoc;
	}

	protected File getNessKafkaKeystoreFile(String nkLoc, String nkPvFileLoc) {
		InputStream in = null;
		try {
			in = this.getClass().getClassLoader().getResource(nkLoc).openStream();
			streamFile = createFileFromStream(in, nkPvFileLoc);
			streamFile.deleteOnExit();
		} catch (NullPointerException | IOException e) {
			LOGGER.error("SETUP Failed: nkLoc={}, nkPvFileLoc={}, e={}", nkLoc, nkPvFileLoc, e.getMessage());
		} finally {
			if (in != null ) {
				try {
					in.close();
				} catch (IOException e) {
					LOGGER.error("SETUP close failure: e={}", e.getMessage());
				}
			}
		}
		return streamFile;
	}

	protected NessKafkaProducer getNewNessKafkaSyncProducer(String nkBrokers, String nkTopic, String nkLoc, String nkPw, String askId)
	{
		try {
			NessKafkaProducer.NessKafkaProducerBuilder nessKafkaProducerBuilder =
					new NessKafkaProducer.NessKafkaProducerBuilder()
					.setKafkaBrokerList(nkBrokers)
					.setKafkaTopic(nkTopic)
					.setKafkaKeystoreLocation(nkLoc)
					.setKafkaKeystorePassword(nkPw)
					.setKafkaKeyPassword(nkPw)
					.setKafkaClientId(askId)
					.<String, String>setKafkaProperty("ssl.endpoint.identification.algorithm","https")
					.setKafkaProtocol("SSL");
			LOGGER.warn("SETUP Sync Success: nkBrokers={}, nkTopic={}, nkLoc={}, nkPw={}, askId={}", nkBrokers, nkTopic, nkLoc, nkPw == null ? NULL : NOT_NULL, askId);
			return nessKafkaProducerBuilder.buildNessProducer();
		} catch (NessLoggerValidationException e) {
			LOGGER.error("SETUP Sync Failed: e={}", e.getMessage());
			return null;
		}
	}

	protected NessKafkaAsyncProducer getNewNessKafkaAsyncProducer(String nkBrokers, String nkTopic, String nkLoc, String nkPw, String askId)
	{
		try {
			NessKafkaAsyncProducer.NessKafkaAsyncProducerBuilder nessKafkaProducerBuilder =
					new NessKafkaAsyncProducer.NessKafkaAsyncProducerBuilder()
					.setKafkaBrokerList(nkBrokers)
					.setKafkaTopic(nkTopic)
					.setKafkaKeystoreLocation(nkLoc)
					.setKafkaKeystorePassword(nkPw)
					.setKafkaKeyPassword(nkPw)
					.setKafkaClientId(askId)
					.<String, String>setKafkaProperty("ssl.endpoint.identification.algorithm","https")
					.setKafkaProtocol("SSL");
			LOGGER.warn("SETUP Async Success: nkBrokers={}, nkTopic={}, nkLoc={}, nkPw={}, askId={}", nkBrokers, nkTopic, nkLoc, nkPw == null ? NULL : NOT_NULL, askId);
			return nessKafkaProducerBuilder.buildNessAsyncProducer();
		} catch (NessLoggerValidationException e) {
			LOGGER.error("SETUP Async Failed: e={}", e.getMessage());
			return null;
		}
	}
}