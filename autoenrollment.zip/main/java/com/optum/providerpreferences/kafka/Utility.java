package com.optum.providerpreferences.kafka;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;

import java.util.function.Function;

public final class Utility {
	@Value("${spring.profiles.active}")
	private static String activeProfile;

	private static final Logger LOGGER = LogManager.getLogger(Utility.class);
	private static final String LOCAL = "local";

	public static String getEnvironment() {
		String env = activeProfile;
		LOGGER.warn("env={}", env);
		if(env == null) {
			return LOCAL;
		}
		for(Environments envs : Environments.values()) {
			if(envs.getEnv().equals(env)) {
				return env;
			}
		}
		return LOCAL;
	}
}
