package com.optum.providerpreferences.kafka;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.optum.eis.kraken.core.NessLog;
import com.optum.eis.kraken.core.exceptions.NessLoggerValidationException;
import com.optum.eis.kraken.kafka.producers.NessKafkaProducer;

public class KafkaPublisher {
	private static final Logger LOGGER = LogManager.getLogger(KafkaPublisher.class);

	private static KafkaProducer kafkaProducer;

	private static final NessKafkaProducer nessKafkaProducer = getNessKafkaProducer();

	private static NessKafkaProducer getNessKafkaProducer() {
		kafkaProducer = new KafkaProducer();
		return kafkaProducer.getNessKafkaProducer();
	}

	protected KafkaProducer getKafkaProducer() {
		return kafkaProducer;
	}

	public void publishToKafka(NessLog log)
	{
		if (nessKafkaProducer == null) {
			return;
		}
		try {
			nessKafkaProducer.publishNessLogs(log);
		} catch(NessLoggerValidationException e) {
			LOGGER.error("Publish error: {}", e.getMessage());
		}
	}

	public void closeNessProducer() {
		if (nessKafkaProducer == null) {
			return;
		}
		nessKafkaProducer.closeNessProducer();
	}
}