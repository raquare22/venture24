package com.optum.providerpreferences;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AppListener implements ApplicationListener<ContextClosedEvent>{
    private static final Logger LOGGER = LogManager.getLogger(AppListener.class);

    protected static boolean shutdown = false;

    @Override
    public void onApplicationEvent(ContextClosedEvent event) {
        LOGGER.warn("SHUTDOWN: event.getSource={}, shutdown={}", event.getSource(), shutdown);
        if (! shutdown) {
            shutdown = true;
        }
        LOGGER.warn("SHUTDOWN: complete");
    }
}