package com.optum.providerpreferences.rs.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.autoenrollment.EmailUtils;
import com.optum.providerpreferences.autoenrollment.SftpUtil;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.handler.PESHandler;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPutResponse;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.FDSResponse;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesRequest;
import com.optum.providerpreferences.rs.model.ndb.preferences.RequestHeader;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinData;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.optout.OptOutAuditMetadata;
import com.optum.providerpreferences.rs.model.optout.OptOutAuditUpdate;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinResponse;
import com.optum.providerpreferences.rs.model.pes.PESResponse;
import com.optum.providerpreferences.rs.model.pes.PESTinRequest;
import com.optum.providerpreferences.rs.model.pes.TinObject;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import com.optum.providerpreferences.rs.utility.ClassifierDescription;
import org.springframework.beans.factory.annotation.Value;

@Service
public class OptOutServiceImpl implements OptOutService {

	@Autowired
	FDSHandler fdsHandler;

	@Autowired
	NDBHandler ndbHandler;
	
	@Autowired
	PESHandler pesHandler;
	
	@Autowired
	ObjectMapper mapper;
	
	@Autowired
	FDSCloudHandler fdsCloudHandler;

	@Value("${PRUN_OPTOUT_EXPIRE_EMAIL_SUBJECT}")
	protected String PRUN_OPTOUT_EXPIRE_EMAIL_SUBJECT;

	@Value("${PRUN_OPTOUT_EXPIRE_EMAIL_MSG}")
	protected String PRUN_OPTOUT_EXPIRE_EMAIL_MSG;

	@Value("${PRUN_EMAIL_SUBJECT_PODM}")
	protected String PRUN_EMAIL_SUBJECT_PODM;

	@Value("${PRUN_EMAIL_MSG_PODM}")
	protected String PRUN_EMAIL_MSG_PODM;

	@Value("${SPACE_ID}")
	protected String SPACE_ID;
	
	private ApplicationUtil app = new ApplicationUtil();


	private static final Logger LOGGER = LogManager.getLogger(OptOutServiceImpl.class);
	
	private static final String SESSION_ID_ALL = "allUpdate";
	
	public FDSCloudGETResponse getOptOutAuditLog(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException{
		
		FDSCloudGETResponse response = fdsCloudHandler.FDSCloudGetRequest(sessionId, fdsCloudRequest);
		
		return response;
		
	}
	
	public OptOutFDSCloudDocument getFDSCloudDocument(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException, IOException{
		
		String documentId = fdsCloudRequest.getDocumentId();
		OptOutFDSCloudDocument response = fdsCloudHandler.FDSCloudGetDocument(sessionId, documentId);
		
		return response;
		
	}
	
	public ResponseEntity<OptOutFDSCloudPOSTResponse> addOptOutAuditLog(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException{
		
		ResponseEntity<OptOutFDSCloudPOSTResponse> response = fdsCloudHandler.FDSCloudPostRequest(sessionId, fdsCloudRequest);
		
		return response;
	}
	
	public ResponseEntity<OptOutFDSCloudPOSTResponse> FDSCloudPut(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException{
		
		ResponseEntity<OptOutFDSCloudPOSTResponse> response = fdsCloudHandler.FDSCloudPutRequest(sessionId, fdsCloudRequest);
		
		return response;
	}
	
	public Map<String, Boolean> FDSCloudDelete(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException{
		
		String documentId = fdsCloudRequest.getRequest().get("documentId").toString();
		Map<String, Boolean> response = fdsCloudHandler.FDSCloudDelete(sessionId, documentId);
		
		return response;
		
	}

	public FDSMultiPutResponse updateOptOutDocuments(OptOutRequest optOutRequest, HttpHeaders headers)
			throws ApplicationException, OAuthProblemException, OAuthSystemException,
			IOException {
		/**
		 * 1. get tin 2. get mpins from tin 3. loop through mpins and letter types 3a.
		 * update NDB 3b. search FDS to get documentId 4. use multi put to update all
		 * documents at once 5. send email to PODM with tin
		 */

		String corpMpin = optOutRequest.getCorpMpin();
		String tin = optOutRequest.getTin();
		String lastUpdatedBy = optOutRequest.getLastUpdatedBy();
		String lastUpdatedById = optOutRequest.getLastUpdatedById();
		int optedOutDuration = optOutRequest.getOptedOutDuration();
		ndbHandler.ndbWebServicePrep();
		List<String> providerMpins = optOutRequest.getProviderMpins();

		if (providerMpins == null || providerMpins.isEmpty()) {
			RequestData request = new RequestData();
			request.setTaxIdNumber(tin);
			request.setCorpOwnerId(corpMpin);

			CorpMpinResponse corpMpinResponse = null;

			try {
				corpMpinResponse = ndbHandler.getProviderData(request);
			} catch (ApplicationException | IOException | OAuthSystemException | OAuthProblemException | RestClientException e) {
				LOGGER.error("Error retrieving Provider Data from NDB, error={}", ExceptionUtils.getStackTrace(e));
				throw new ApplicationException("Error making service call to NDB");
			}

			Objects.requireNonNull(corpMpinResponse);

			providerMpins = new ArrayList<>();
			for (MpinData mpinData : corpMpinResponse.getResponse().getMpinList()) {
				providerMpins.add(padWithLeadingZeros(mpinData.getProviderId()));
			}

		}

		List<String> documentIds= getDocumentsFromFDS(providerMpins, tin, headers);

		Document document = createOptOutDocument(lastUpdatedBy, lastUpdatedById, optedOutDuration);
		Metadata docMetadata = document.getMetadata();
		String documentIdList = String.join(",", documentIds);

		LOGGER.info("Sending PUT request to multi update FDS documents, documentIdList={}, document={}", documentIdList,
				document);

		MultiValueMap<String, Object> parts = new LinkedMultiValueMap<>();
		parts.add("documentIdList", documentIdList);
		parts.add("documents", document);

		FDSMultiPutResponse fdsMultiPutResponse = null;

		try {
			fdsMultiPutResponse = fdsHandler.updateMultiDocuments(parts, headers, "OPTOUT");
		} catch (Exception e) {
			LOGGER.error("Error updating multi documents, documentIds={}, err=", documentIdList, e);
			throw e;
		}
		
		// Opt Out Audit log - Start
		List<String> failedDocs = new ArrayList<String>();
		
		for (String doc : documentIds) {
			if (!fdsMultiPutResponse.getUpdated().contains(doc)) {
				failedDocs.add(doc);
			}
		}
		
		OptOutRequest optOutAuditRequest = new OptOutRequest();
		optOutAuditRequest.setTin(tin);
		optOutAuditRequest.setCorpMpin(corpMpin);
		optOutAuditRequest.setOptedOutDuration(optedOutDuration);
		optOutAuditRequest.setLastUpdatedBy(lastUpdatedBy);
		optOutAuditRequest.setLastUpdatedById(lastUpdatedById);
		
		OptOutAuditUpdate optOutAuditUpdate = new OptOutAuditUpdate();
		
		optOutAuditUpdate.setDeliveryMethod(docMetadata.getDeliveryMethod());
		optOutAuditUpdate.setOkToChangePDOInd(docMetadata.getOkToChangePDOInd());
		optOutAuditUpdate.setAutoEdelUpdateInd(docMetadata.getAutoEdelUpdateInd());
		
		optOutAuditUpdate.setLastUpdatedBy(docMetadata.getLastUpdatedBy());
		optOutAuditUpdate.setLastUpdatedById(docMetadata.getLastUpdatedById());
		optOutAuditUpdate.setAutoOptOutInd(docMetadata.getAutoOptOutInd());
		
		optOutAuditUpdate.setOptedOutDuration(docMetadata.getOptedOutDuration());
		optOutAuditUpdate.setOptedOutDateTime(docMetadata.getOptedOutDateTime());
		optOutAuditUpdate.setExpiryDate(docMetadata.getExpiryDate());
		optOutAuditUpdate.setExpiryDateEpoch(docMetadata.getExpiryDateEpoch());
		
		
		OptOutAuditMetadata auditMetadata = new OptOutAuditMetadata();
		auditMetadata.setRecordType("OptOutAuditLog");
		auditMetadata.setDocumentIds(documentIds);
		auditMetadata.setUpdated(fdsMultiPutResponse.getUpdated());
		auditMetadata.setFailedDocumentIds(failedDocs);
		auditMetadata.setOptOutRequest(optOutAuditRequest);
		auditMetadata.setOptOutUpdate(optOutAuditUpdate);
		
		FDSCloudRequest fdsCloudRequest = new FDSCloudRequest();
		Map<String, Object> mapRequest = mapper.convertValue(auditMetadata, new TypeReference<Map<String, Object>>() {});
		fdsCloudRequest.setRequest(mapRequest);
		ResponseEntity<OptOutFDSCloudPOSTResponse> auditLogResponse = addOptOutAuditLog("OptOutAuditLog", fdsCloudRequest);
		
		LOGGER.info("updateOptOutDocuments -> {} response received for OptOutAuditLog", auditLogResponse.getStatusCode());
		
		// Opt Out Audit Log - End
		
		try {
			EmailUtils.sendEmailWithoutAttachment(tin,SftpUtil.createDateintoString(), PRUN_EMAIL_SUBJECT_PODM, PRUN_EMAIL_MSG_PODM);
		} catch (Exception e) {
			LOGGER.error("Error while sending email to PODM, Tin={}, err=", Encode.forJava(tin), e);
		}

		return fdsMultiPutResponse;
	}
	
	public List<String> getDocumentsFromFDS(List<String> providerMpins, String tin, HttpHeaders headers) throws RestClientException, NullPointerException, ApplicationException, OAuthProblemException, OAuthSystemException, IOException {
		
		List<String> documentIds = new ArrayList<>();

		for (String currentMpin : providerMpins) {
			for (String classifier : ClassifierDescription.classifierDescriptionHash.keySet()) {


				// update NDB
				LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
				webRequest.setRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(
						currentMpin, tin, "U", "P", classifier));
				webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));

				try {
					ndbHandler.updateProviderLetterPreferences(webRequest, currentMpin, tin);
				} catch (JsonProcessingException e) {

					LOGGER.error("ERROR UPDATING TO NDB, mpin={}, tin={}, error={}", Encode.forJava(currentMpin), Encode.forJava(tin), ExceptionUtils.getStackTrace(e));
					throw e;
				}

				// get FDS document ID and add to documentIds list

				FDSResponse sortedDocs = null;
				try {
					sortedDocs = fdsHandler.getAutoEnrollDocumentListSortCreated(tin, currentMpin, classifier,
							headers.getFirst("sm_serversessionid"));
				} catch (IOException | OAuthProblemException | OAuthSystemException e) {
					LOGGER.error("Error retrieving document from FDS, tin={}, mpin={}, classifier={}, e={}", Encode.forJava(tin),
					Encode.forJava(currentMpin), classifier, ExceptionUtils.getStackTrace(e));
					throw e;
				}
				if (sortedDocs != null && !sortedDocs.getDocuments().isEmpty()) {
					documentIds.add(sortedDocs.getDocuments().get(0).getId());
				}

			}
		}

		return documentIds;
	}
	
	
	public OptOutTinResponse getTins(OptOutTinRequest optOutTinRequest) throws ApplicationException, JsonProcessingException {
		
		try {
			
			PESTinRequest request = new PESTinRequest(optOutTinRequest.getCorporateMpin());
			
			PESResponse response = pesHandler.getTins(request);
			
			final Predicate<TinObject> valueNotNullOrEmpty = e -> e != null && e.getKey() != null && !StringUtils.isEmpty(e.getKey().getTaxIdNumber());
			
			List<String> tins = Optional.ofNullable(response.getData())
					.orElseGet(Collections::emptyList)
					.stream()
					.filter(valueNotNullOrEmpty)
					.map(tinObj -> tinObj.getKey().getTaxIdNumber())
					.collect(Collectors.toList());			
			
			LOGGER.info("tins retrieved from pes for corpMpin={}, tins={}", Encode.forJava(optOutTinRequest.getCorporateMpin()), tins);
			
			return new OptOutTinResponse(tins);

		} catch (Exception e) {
			LOGGER.error("Error retrieving tins from PES API, e={}", ExceptionUtils.getStackTrace(e));
			throw e;
		}
		
		
		
	}
	
	
	public void revertExpiredOptOutDocuments(String mpin) {
		LOGGER.info("revertExpiredOptOutDocuments -- START");
		
		// get all optOutDocuments with expiryDate < currentDate
		try {
			
			// pass in an mpin so GET request doesn't time out, or for testing purposes, if null then it won't search for mpin
			// also for passing in mpin from cucumber test
			FDSResponse fdsResponse = fdsHandler.getOptOutDocuments("GET_OPTOUT_DOCS", mpin);
			
			Set<String> tinsList = new HashSet<>();
			
			for (Document doc : fdsResponse.getDocuments()) {
				
				Metadata metadata = doc.getMetadata();
				
				Instant expiryDate = parseExpiryDate(metadata.getExpiryDate());
				
				if (expiryDate.compareTo(new Date().toInstant()) <= 0) {

					ndbHandler.ndbWebServicePrep();
					// update NDB
					LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
					webRequest.setRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(
							metadata.getMpin(), metadata.getTin(), "U", "E", metadata.getFileName()));
					webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));

					try {
						ndbHandler.updateProviderLetterPreferences(webRequest, metadata.getMpin(), metadata.getTin());
					} catch (JsonProcessingException e) {

						LOGGER.error("ERROR UPDATING TO NDB, mpin={}, tin={}, error={}", metadata.getMpin(), metadata.getTin(), ExceptionUtils.getStackTrace(e));
						return;
					}
					
					// update FDS				
					metadata.setDeliveryMethod("E");
			        metadata.setOkToChangePDOInd("N");
			        metadata.setAutoOptOutInd("N");
			        metadata.setProviderEmailId("");
			        metadata.setExpiryDate("");
			        metadata.setLastUpdatedBy("");
			        metadata.setLastUpdatedById("");
			        metadata.setOptedOutDateTime("");
			        metadata.setOptedOutDuration(null);
					
					MultiValueMap<String, Document> docsMapToSend = new LinkedMultiValueMap<>();
					docsMapToSend.add("documents", doc);
					HttpHeaders headers = new HttpHeaders();
					
					try {
                        fdsHandler.callFDSPutDocument(docsMapToSend, headers, doc.getId(), SESSION_ID_ALL);
                    } catch (RestClientException| JsonProcessingException e) {
                    	LOGGER.error("ERROR UPDATING DOCUMENT ID, documentID={}", doc.getId());
                        return;
                    }
					
					// add tin to set
					tinsList.add(metadata.getTin());
				}
			}
			
			// send email to PODM
			if (!tinsList.isEmpty()) {
				String tins = String.join(", ", tinsList);
				EmailUtils.sendEmailWithoutAttachment(tins, SftpUtil.createDateintoString(), PRUN_OPTOUT_EXPIRE_EMAIL_SUBJECT, PRUN_OPTOUT_EXPIRE_EMAIL_MSG);
			}
			
			
		} catch (Exception e) {
			LOGGER.error("revertExpiredOptOutDocuments -> Error reverting expired opt out documents, error={}", ExceptionUtils.getStackTrace(e));
		}
	}

	private Document createOptOutDocument(String lastUpdatedBy, String lastUpdatedById, int optedOutDuration) {
		Document document = new Document();

		Metadata metadata = new Metadata();
		metadata.setLastUpdatedBy(lastUpdatedBy);
		metadata.setLastUpdatedById(lastUpdatedById);
		metadata.setOptedOutDuration(optedOutDuration);

		Calendar cal = Calendar.getInstance();
		metadata.setOptedOutDateTime(formatDate(cal.getTime()));

		if (optedOutDuration == 9999) {
			metadata.setExpiryDate("9999-12-31T23:59:59.000Z");
			metadata.setExpiryDateEpoch(Long.valueOf("253402300799000"));
			
		} else {
			cal.add(Calendar.DATE, optedOutDuration);
			metadata.setExpiryDate(formatDate(cal.getTime()));
			metadata.setExpiryDateEpoch(cal.getTimeInMillis());
		}
		
		// hardcoded values
		metadata.setDeliveryMethod("P");
		metadata.setOkToChangePDOInd("Y");
		metadata.setAutoEdelUpdateInd("Y");
		metadata.setAutoOptOutInd("Y");
		
		document.setMetadata(metadata);
		document.setSpaceId(SPACE_ID);

		return document;
	}
	

	private String padWithLeadingZeros(String currentMpin) throws ApplicationException {
		int currentMpinLength = currentMpin.length();
		String stringOfZeros = "";
		if (currentMpinLength == 9) {
			return currentMpin;
		} else if (currentMpinLength < 9) {
			int numberOfZerosNeeded = 9 - currentMpinLength;
			for (int i = 0; i < numberOfZerosNeeded; i++) {
				stringOfZeros += "0";
			}
			currentMpin = stringOfZeros + currentMpin;
			return currentMpin;
		} else {
			LOGGER.error("MPIN longer than 9 digits, mpin={}", currentMpin);
			throw new ApplicationException("MPIN longer than 9 digits");
		}

	}

	private synchronized String formatDate(Date date) {
		SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		return isoDateFormat.format(date);
	}
	
	private Instant parseExpiryDate(String date) {
		DateTimeFormatter formatter = new DateTimeFormatterBuilder()
        		.appendPattern("[yyyy-MM-dd'T'HH:mm:ss.SSS'Z']")
                .appendPattern("[yyyy-MM-dd'T'HH:mm:ss.SSSxx]")
                .parseDefaulting(ChronoField.MONTH_OF_YEAR, 01)
                     .parseDefaulting(ChronoField.DAY_OF_MONTH, 01)
                     .parseDefaulting(ChronoField.HOUR_OF_DAY, 0)
                     .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 00)
                     .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 00)
                     .toFormatter();
		return LocalDateTime.parse(date, formatter).atZone(ZoneId.of("UTC")).toInstant();
	}
	

}
