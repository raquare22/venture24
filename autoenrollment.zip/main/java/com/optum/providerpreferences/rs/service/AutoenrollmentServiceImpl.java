package com.optum.providerpreferences.rs.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Value;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

//import com.optum.providerpreferences.autoenrollment.JobController;
import com.optum.providerpreferences.autoenrollment.TimeUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.autoenrollment.SchedulerAutoEnrollment;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentAuditLog;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObj;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPostResponse;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import com.optum.providerpreferences.rs.utility.ClassifierDescription;


@Service
public class AutoenrollmentServiceImpl implements AutoenrollmentService {

	@Autowired
	FDSHandler fdsHandler;

	@Autowired
	FDSCloudHandler fdsCloudHandler;

	@Autowired
	ObjectMapper mapper;
	
	private static final Logger LOGGER = LogManager.getLogger(AutoenrollmentServiceImpl.class);
	

    private static final String SESSION_ID_SPECIFIC = "specificUpdate";
	@Value("${THREADS_FDSCLOUD_GET}")
	protected String THREADS_FDSCLOUD_GET;

	@Value("${THREADS_FDSCLOUD_POST}")
	protected String THREADS_FDSCLOUD_POST;

	@Value("${THREAD_COUNT_HEALTHCHECK}")
	protected String THREAD_COUNT_HEALTHCHECK;

    private static String AUTO_ENROLL_AUDIT_LOG = "AutoEnrollAuditLog";
	private ExecutorService emailRequestExecutorService = Executors.newFixedThreadPool(
			ApplicationUtil.parseWithDefault(THREADS_FDSCLOUD_GET, ApplicationUtil.THREADS_FDSCLOUD_GET_DEFAULT));
	private ExecutorService autoenrollmentPostExecutorService = Executors.newFixedThreadPool(
			ApplicationUtil.parseWithDefault(THREADS_FDSCLOUD_GET, ApplicationUtil.THREADS_FDSCLOUD_POST_DEFAULT));
	private ExecutorService autoenrollmentGetExecutorService = Executors.newFixedThreadPool(
			ApplicationUtil.parseWithDefault(THREADS_FDSCLOUD_GET, ApplicationUtil.THREADS_FDSCLOUD_GET_DEFAULT));

    private List<AutoenrollmentObj> autoenrollObjects= null; 
    private List<String> docIdList = null;
    private List<FDSCloudRequest> errorList =null;
    private Integer blankEmails = 0;
    private Set<String> individualMpins = new LinkedHashSet();
	
	public List<String> createAutoenrollmentDocumentsFDSCloud(AutoenrollmentRequest autoenrollRequest, HttpHeaders headers) throws ApplicationException {
		// adding the existing emails check prior to sending to FDS 
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping createAutoenrollmentDocumentsFDSCloud as it's now within business hours.");
			return Collections.emptyList();
		}
		if (emailRequestExecutorService.isShutdown()) {
			emailRequestExecutorService = Executors.newFixedThreadPool(
					ApplicationUtil.parseWithDefault(THREADS_FDSCLOUD_GET, ApplicationUtil.THREADS_FDSCLOUD_GET_DEFAULT));
		}
		if (autoenrollmentPostExecutorService.isShutdown()) {
			autoenrollmentPostExecutorService = Executors.newFixedThreadPool(
					ApplicationUtil.parseWithDefault(THREADS_FDSCLOUD_POST, ApplicationUtil.THREADS_FDSCLOUD_POST_DEFAULT));
		}
		if (autoenrollmentGetExecutorService.isShutdown()) {
			autoenrollmentGetExecutorService = Executors.newFixedThreadPool(
					ApplicationUtil.parseWithDefault(THREADS_FDSCLOUD_GET, ApplicationUtil.THREADS_FDSCLOUD_GET_DEFAULT));
		}
		autoenrollObjects = Collections.synchronizedList(new ArrayList<AutoenrollmentObj>());
		docIdList = Collections.synchronizedList(new ArrayList<String>());
		errorList = Collections.synchronizedList(new ArrayList<FDSCloudRequest>());
		
		LOGGER.info("createAutoenrollmentDocuments --> Checking for existing emails");
		
		Token token = fdsCloudHandler.getFDSCloudToken("autoenrollmentRun");
		
		for (AutoenrollmentObj request : autoenrollRequest.getAutoenrollDocuments()) {
                emailRequestExecutorService.execute(new existingEmailRequest(request));
		}
//		LOGGER.info("existingEmailRequest -> Existing emails found, processedCount={}", autoenrollObjects.size());
		
 		emailRequestExecutorService.shutdown();
		
		try { 
			emailRequestExecutorService.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			LOGGER.error("Threading failed, error={}", ExceptionUtils.getStackTrace(e));
		}
		
//		return fdsMultiResp;
		
		LOGGER.info("createAutoenrollmentDocuments --> Generating autoenrollment documents - {} records, currentFileName: {}", autoenrollObjects.size(), SchedulerAutoEnrollment.currentFileName);
				
		
//		ResponseEntity<OptOutFDSCloudPOSTResponse> FDSCloudPostRequest
		List<FDSCloudRequest> postRequestList = Collections.synchronizedList(new ArrayList<FDSCloudRequest>());
		for (AutoenrollmentObj autoenrollObj : autoenrollObjects) {
			
			FDSCloudRequest postRequest = new FDSCloudRequest();
			Metadata metadata = new Metadata();
			
			
			metadata.setTin(autoenrollObj.getTin());
			metadata.setMpin(autoenrollObj.getMpin());
			metadata.setProviderEmailId(autoenrollObj.getProviderEmailId());
			
			String fileName = autoenrollObj.getFileName();
			metadata.setFileName(fileName);
			metadata.setFileType(ClassifierDescription.getClassifierDescription(fileName));
			
			// Update: if there is no autoenrollment date passed through, set to server date. 
			// else, take activeDate in request
			if (autoenrollObj.getActiveDate() == null) {
//				LOGGER.info("Active date is null, using server date");
				Calendar cal = Calendar.getInstance();
				metadata.setActiveDate(formatDate(cal.getTime()));
			}
			else {
				metadata.setActiveDate(autoenrollObj.getActiveDate());
			}
			
			// constant values
			metadata.setFrequency("D");
			metadata.setDeliveryMethod("E");
			metadata.setAutoEdelUpdateInd(autoenrollObj.getAutoEdelUpdateInd());
			metadata.setOkToChangePDOInd("N");
			
//			LOGGER.info("Adding: metadata={}", metadata);
			
			Map<String, Object> metadataMap = fdsCloudHandler.createMapFromPOJO(metadata);
			postRequest.setRequest(metadataMap);

			postRequestList.add(postRequest);

		}
        
		AutoenrollmentAuditLog auditLog = new AutoenrollmentAuditLog();
		auditLog.setRecordType(AUTO_ENROLL_AUDIT_LOG);
		auditLog.setCountToInsert(autoenrollObjects.size());
		auditLog.setStatus("COMPLETED");
		
		FDSCloudRequest fdsCloudRequest = new FDSCloudRequest();
		Map<String, Object> mapRequest = mapper.convertValue(auditLog, new TypeReference<Map<String, Object>>() {});
		fdsCloudRequest.setRequest(mapRequest);
		
		ResponseEntity<OptOutFDSCloudPOSTResponse> auditLogResponse = fdsCloudHandler.FDSCloudPostRequest(AUTO_ENROLL_AUDIT_LOG, fdsCloudRequest);
		String auditDocId = auditLogResponse.getBody().getDocumentId();
		LOGGER.info("Autoenrollment audit log added, documentId={}", auditDocId);

        LOGGER.info("postRequestList size={}, file={}", postRequestList.size(), SchedulerAutoEnrollment.currentFileName);
        
        for (FDSCloudRequest request : postRequestList) {
        	
    		try {
    			autoenrollmentPostExecutorService.execute(new autoenrollmentFDSCloudPostRequest(request));
    			
    		} catch (Exception e) {
    			errorList.add(request);
    			String str=ExceptionUtils.getStackTrace(e);
    			LOGGER.error("Error creating multi documents, err={}.", str);
    			continue;
    		}
        	
        }
//        auditLog.setInserted(docIdList);
//		auditLog.setErrors(errorList);
		if (errorList.size() > 0) {
			auditLog.setStatus("ERROR");
		}
		ResponseEntity<OptOutFDSCloudPOSTResponse> auditResponse = updateLog(auditLog, auditDocId);
		
		LOGGER.info("Audit Log {} response, docId={}", auditResponse.getStatusCode().value(), auditDocId);
		autoenrollObjects = null;
		postRequestList = null;
		LOGGER.info("Unique MPINs with no email: {}, currentFileName: {}", individualMpins.size(), SchedulerAutoEnrollment.currentFileName);
		LOGGER.info("Blank emails found: {}", blankEmails);
        return docIdList;
		
	}
	
	private ResponseEntity<OptOutFDSCloudPOSTResponse> updateLog(AutoenrollmentAuditLog log, String docId) throws ApplicationException{
		FDSCloudRequest fdsCloudPutRequest = new FDSCloudRequest();

		fdsCloudPutRequest.setDocumentId(docId);
		
		Map<String, Object> mapPutRequest = mapper.convertValue(log, new TypeReference<Map<String, Object>>() {});
		fdsCloudPutRequest.setRequest(mapPutRequest);
		
		ResponseEntity<OptOutFDSCloudPOSTResponse> auditLogPutResponse = fdsCloudHandler.FDSCloudPutRequest("UpdateAutoEnrollAuditLog", fdsCloudPutRequest);
		
		return auditLogPutResponse;
	}
	
	private synchronized String formatDate(Date date) {
		SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		return isoDateFormat.format(date);
	}
	
	public class existingEmailRequest implements Runnable{
		AutoenrollmentObj autoenrollRequest;
		
		public existingEmailRequest(AutoenrollmentObj autoenrollRequest) {
			this.autoenrollRequest = autoenrollRequest;
		}
		
		@Override
		public void run() {
			if (TimeUtils.isWithinBusinessHours()) {
				LOGGER.info("existingEmailRequest Task interrupted due to business hours.");
				return;
			}
			try {
				String autoEdelUpdateInd = "Y";
				String sessionId = "AutoEnrollment_existingEmail";
		    	Map<String, Object> requestMap = new HashMap<String, Object>();
		    	
		    	requestMap.put("tin", autoenrollRequest.getTin());
		    	requestMap.put("mpin", autoenrollRequest.getMpin());
		    	requestMap.put("deliveryMethod", "E");
//		    	requestMap.put("okToChangePDOInd", "Y");
		    	requestMap.put("fileName", autoenrollRequest.getFileName());
		    	
		    	FDSCloudRequest fdsCloudRequest = fdsCloudHandler.createSearchTermsRequestFromMap(requestMap);
		    	
		    	FDSCloudGETResponse response = fdsCloudHandler.FDSCloudGetRequest(sessionId, fdsCloudRequest);
		    	
                if (response.getDocuments().size() > 0) {
	           	 	Map<String, Object> metadataMap = fdsCloudHandler.getSearchTermsFromDocument(response.getDocuments().get(0)); 

//	           	 String mostRecentEmail = metadataMap.get("providerEmailId").toString();
	           	 String mostRecentEmail = "";
	           	 	if (checkIfExist(metadataMap, "providerEmailId")) {
	           	 		mostRecentEmail = metadataMap.get("providerEmailId").toString();	
	           	 		autoEdelUpdateInd = "N";
	           	 	}
	           	 	
	           	 	autoEdelUpdateInd = autoEdelCheck(mostRecentEmail);
		           	 if (!autoenrollRequest.getProviderEmailId().equals(mostRecentEmail) && !mostRecentEmail.equals("")) {
//		           		 LOGGER.info("Replaced emails, givenEmail={}, emailInFDS={}", autoenrollRequest.getProviderEmailId(), mostRecentEmail);
		           		autoenrollRequest.setProviderEmailId(mostRecentEmail);
		           		
		           	 }
		          

	            }
                
                
           	 if (autoenrollRequest.getProviderEmailId().equals("")) {
           	 		individualMpins.add(autoenrollRequest.getMpin());
           	 		blankEmails ++;
           	 	}
	           	autoenrollRequest.setAutoEdelUpdateInd(autoEdelUpdateInd);
                autoenrollObjects.add(autoenrollRequest);
//                LOGGER.info("Added request={}", autoenrollRequest.toString());
			}	

			catch (Exception e) {
				LOGGER.error("Error getting existing email, error={}", ExceptionUtils.getStackTrace(e));
			}
			if (SchedulerAutoEnrollment.getCount.incrementAndGet() % ApplicationUtil.parseWithDefault(THREAD_COUNT_HEALTHCHECK, ApplicationUtil.THREAD_COUNT_HEALTHCHECK_DEFAULT) == 0) {
				LOGGER.warn("existingEmailRequest getCount={}", SchedulerAutoEnrollment.getCount);
			}
		}
		
	}
	
	public String autoEdelCheck (String mostRecentEmail) {
		if (TimeUtils.isWithinBusinessHours()) {
			LOGGER.info("Stopping autoEdelCheck as it's now within business hours.");
			return "Y";
		}
		if (!mostRecentEmail.trim().isEmpty() || !mostRecentEmail.trim().equals("")) {
			return "N";
		}
		return "Y";
		
	}
	
	
	public class autoenrollmentFDSCloudPostRequest implements Runnable{
		FDSCloudRequest request;
		public autoenrollmentFDSCloudPostRequest(FDSCloudRequest request) {
			this.request = request;
		}
		
		@Override
		public void run() {
			if (TimeUtils.isWithinBusinessHours()) {
				LOGGER.info("autoenrollmentFDSCloudPostRequest Task interrupted due to business hours.");
				return;
			}
//			LOGGER.info("autoenrollmentFDSCloudPostRequest -> Sending request={}", request.toString());
			try {
				ResponseEntity<OptOutFDSCloudPOSTResponse> response = fdsCloudHandler.FDSCloudPostRequest("autoenrollmentPOST", request);
				if(response.getStatusCode().equals(HttpStatus.CREATED) ) {
//				if (!response.getBody()) { 
					String docId = response.getBody().getDocumentId();
					docIdList.add(docId);
//					LOGGER.info("Added docId {} to docList", docId);
				}
				else {
					LOGGER.warn("Request failed with status code {}, request={}", response.getStatusCode(),  request.getRequest().toString(), Encode.forJava(String.valueOf(response.getBody())));
					ResponseEntity<OptOutFDSCloudPOSTResponse> retryresponse = fdsCloudHandler.FDSCloudPostRequest("autoenrollmentPOSTretry", request);
					if (!response.getBody().getDocumentId().equals("")) {
						String docId = retryresponse.getBody().getDocumentId();
						docIdList.add(docId);
						LOGGER.info("Retry added docId {} to docList", docId);
					}
					else {
						LOGGER.error("Autoenrollment retry failed for request={}", request.getRequest().toString());
					}

				}
			}	

			catch (ApplicationException e) {
				LOGGER.error("Error processing load test, error={}", ExceptionUtils.getStackTrace(e));
			}
			SchedulerAutoEnrollment.postCount.getAndIncrement();
//			if (SchedulerAutoEnrollment.postCount.incrementAndGet() > SchedulerAutoEnrollment.getCount.get()) {
//				LOGGER.warn("autoenrollmentFDSCloudPostRequest -> POST count is too high, something is wrong, request={}", request.toString());
//			}
				
		}
		
	}
	
	public Boolean checkIfExist(Map<String, Object> map, String fieldCheck) {
		Boolean check = false;
			
		if (!map.get(fieldCheck).equals(null) ) {
			check = true;
		}
		return check;
	}
	
}
