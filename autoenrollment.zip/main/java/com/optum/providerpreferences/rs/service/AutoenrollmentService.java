package com.optum.providerpreferences.rs.service;

import java.util.List;

import org.springframework.http.HttpHeaders;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPostResponse;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPutResponse;

public interface AutoenrollmentService {

	public List<String> createAutoenrollmentDocumentsFDSCloud(AutoenrollmentRequest autoenrollRequest, HttpHeaders headers) throws ApplicationException;
}
