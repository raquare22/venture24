package com.optum.providerpreferences.rs.service;

import java.io.IOException;
import java.util.Map;

import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPutResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinResponse;

public interface OptOutService {
	
	public FDSMultiPutResponse updateOptOutDocuments(OptOutRequest optOutRequest, HttpHeaders headers) throws ApplicationException, JsonProcessingException, OAuthProblemException, OAuthSystemException, IOException;

	public OptOutTinResponse getTins(OptOutTinRequest optOutTinRequest) throws ApplicationException, JsonProcessingException;
	
	public FDSCloudGETResponse getOptOutAuditLog(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException;
	
	public OptOutFDSCloudDocument getFDSCloudDocument(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException, IOException;
	
	public ResponseEntity<OptOutFDSCloudPOSTResponse> addOptOutAuditLog(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException;
	
	public ResponseEntity<OptOutFDSCloudPOSTResponse> FDSCloudPut(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException;
	
	
	public Map<String, Boolean> FDSCloudDelete(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException; 
}
