package com.optum.providerpreferences.rs.service;

import java.io.IOException;

import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.optum.digitalsecurity.model.request.User;
import com.optum.digitalsecurity.model.response.PDOCorporates;
import com.optum.digitalsecurity.model.response.PDOTins;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.logging.LogMessage;

public interface DigitalSecurityService {

	
	PDOCorporates getCorporatesByPasswordOwner(String optumUUID, HttpHeaders headers, LogMessage logMessage)
            throws JsonParseException, JsonMappingException, IOException, ApplicationException, OAuthSystemException, OAuthProblemException;
	
	PDOTins getProvidersByCorporate(String uuid, String uhcId, String mpin, HttpHeaders headers, LogMessage logMessage)
            throws JsonParseException, JsonMappingException, IOException, ApplicationException;
	
	ResponseEntity<User> getEmailsByCorporate(String corporateMpin, HttpHeaders headers)
            throws JsonParseException, JsonMappingException, IOException, ApplicationException, OAuthSystemException, OAuthProblemException;
    
}
