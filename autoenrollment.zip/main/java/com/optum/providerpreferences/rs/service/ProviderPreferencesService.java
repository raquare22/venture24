package com.optum.providerpreferences.rs.service;

import java.io.IOException;
import java.text.ParseException;

import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.springframework.http.HttpHeaders;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;

public interface ProviderPreferencesService
{
    PasswordOwner getProvidersByCorporate(String uuid, String uhcId, String mpin, HttpHeaders headers, LogMessage logMessage)
            throws IOException, ApplicationException;

    ProviderPreferencesObj getProviderPreferences(String tin, String mpin, HttpHeaders headers, LogMessage logMessage)
            throws IOException, ApplicationException, OAuthSystemException, OAuthProblemException;

    CorpMpinResponse getProviderData(com.optum.providerpreferences.rs.model.ndb.provider.RequestData request, HttpHeaders headers, LogMessage logMessage)
            throws JsonProcessingException, ApplicationException;
    
    void updateProviderPreferences(ProviderPreferencesObj providerPreferences, HttpHeaders headers) 
    		throws IOException, ApplicationException, OAuthProblemException, OAuthSystemException, ParseException;
    
    ProviderPreferencesObj getProviderPreferencesFDSCloud(String tin, String mpin, HttpHeaders headers, LogMessage logMessage)
            throws IOException, ApplicationException, OAuthSystemException, OAuthProblemException;

    void updateProviderPreferencesFDSCloud(ProviderPreferencesObj providerPreferences, HttpHeaders headers) 
    		throws IOException, ApplicationException, OAuthProblemException, OAuthSystemException, ParseException;
    
}
