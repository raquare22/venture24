/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.service;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.CACFHandler;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.handler.LinkSecurityHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.PasswordOwnerInfo;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.FDSResponse;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.linksecurity.User;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesRequest;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponse;
import com.optum.providerpreferences.rs.model.ndb.preferences.MailPref;
import com.optum.providerpreferences.rs.model.ndb.preferences.RequestHeader;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import com.optum.providerpreferences.rs.utility.ClassifierDescription;
import com.optum.providerpreferences.rs.utility.Converter;
import com.optum.providerpreferences.rs.utility.PasswordOwnerUtil;

/**
 * This handler contains the main implementation methods for API resources.
 * 
 * @author Provider Paperless Letters
 */
@Service
public class ProviderPreferenceServiceImpl implements ProviderPreferencesService
{

    private ObjectMapper mapper = new ObjectMapper();

    @Autowired
    private NDBHandler ndbHandler;

    @Autowired
    private CACFHandler cacf;

    @Autowired
    private FDSHandler fdsHandler;

    @Autowired
    private FDSCloudHandler fdsCloudHandler;

    private PasswordOwnerUtil pwUtil;

    private ApplicationUtil app = new ApplicationUtil();

    private static final Logger logger = LogManager.getLogger(ProviderPreferenceServiceImpl.class);
    
    private static final String SESSION_ID_ALL = "allUpdate";

    private static final String SESSION_ID_SPECIFIC = "specificUpdate";

    @Value("${SPACE_ID}")
    protected String SPACE_ID;


    public ProviderPreferencesObj getProviderPreferences(String tin, String mpin, HttpHeaders headers, LogMessage logMessage) throws ApplicationException
    {
        try
        {
            mpin = padWithLeadingZeros(mpin);
        }
        catch (ApplicationException e)
        {
            logger.error("ERROR PADDING MPIN WITH LEADING ZEROS, error={}", e);
            throw e;
        }
       
        try
        {
            logger.info("Getting preferences by TIN, session={}", Encode.forJava(headers.getFirst("sm_serversessionid")));

            ProviderPreferencesObj providerPreferences = new ProviderPreferencesObj();
            List<PreferenceType> preferenceTypeList = new ArrayList<>();

            /*
             * Need a technical US for using Java Futures for the below sequential webService calls 2/1
             */

            /* Call NDB to retrieve letter preferences */
            logger.info("Calling NDB Letter Preferences, session={}", Encode.forJava(headers.getFirst("sm_serversessionid")));
            LetterPreferencesResponse ndbLetterPreferencesResponse = null;
            
            if(logMessage.getUsername() != null && logMessage.getUsername().equals("CUCUMBERTEST")) {
                PreferenceType preferenceType = new PreferenceType();          
                preferenceType.setClassifier(logMessage.getActor());
                preferenceType.setDeliveryMethod("E");
                preferenceTypeList.add(preferenceType);
            }
         else {
              
              try
              {
                  ndbLetterPreferencesResponse =
                          ndbHandler.getProviderLetterPreferences(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(mpin, tin, "I"));
              }
              catch (ApplicationException e)
              {
                  logger.error("ERROR CALLING NDB GET PREFS, error={}", e);
                  throw new ApplicationException("ERROR CALLING NDB");
              }

              if (ndbLetterPreferencesResponse.getResponseHeader().getMessage() == null)
              {
                  logger.error("NDB RESPONSE MESSAGE IS NULL - ERROR");
                  throw new ApplicationException("ERROR CALLING NDB");
              }
              if (!(ndbLetterPreferencesResponse.getResponseHeader().getMessage().equals("SUCCESSFUL")))
              {
                  logger.error("Error with web service call to NDB Letter Preferences - POST, message={}", Encode.forJava(ndbLetterPreferencesResponse.getResponseHeader().getMessage()));
                  throw new ApplicationException("ERROR CALLING NDB");
              }
              for (MailPref pref : ndbLetterPreferencesResponse.getRequestResponse().getLtrTypMailPrfList())
              {
                  PreferenceType preferenceType = new PreferenceType();
                  preferenceType.setClassifier(pref.getLetterType());
                  preferenceType.setDeliveryMethod(pref.getMailingPref());
                  preferenceTypeList.add(preferenceType);
              }
            }

            /* Call FDS List Documents to retrieve preferences */
            logger.info("Calling FDS Get Documents, session={}",Encode.forJava(headers.getFirst("sm_serversessionid")));
            FDSResponse fdsResponse = fdsHandler.getDocumentList(tin, mpin, null, headers.getFirst("sm_serversessionid"));

            logger.info("FDS Response Recieved");
            
            if (!(fdsResponse.getDocuments().isEmpty()))
            {
                providerPreferences.setCorporateName(fdsResponse.getDocuments().get(0).getMetadata().getProviderName());
            }

            /* Aggregate response */

            logger.info("Building provider preferences with data from NDB and FDS");

            for (PreferenceType prefType : preferenceTypeList)
            {
                prefType.setDescription(ClassifierDescription.getClassifierDescription(Converter.convertNullToString(prefType.getClassifier().toUpperCase())));
                prefType.setLob(ClassifierDescription.getLob(Converter.convertNullToString(prefType.getClassifier().toUpperCase())));
                FDSResponse sortedDocs = fdsHandler.getDocumentListSortCreated(tin, mpin, prefType.getClassifier(), headers.getFirst("sm_serversessionid"));
                
                int lenSortedDocs = sortedDocs.getDocuments().size();
                
                if (lenSortedDocs > 0) {
                	
                	int docIndex = -1;
                	OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);
                	
                	AutoEnrollment doc0 = determineDocumentIndex(sortedDocs.getDocuments(), lenSortedDocs, 0, currentDate);
                	AutoEnrollment doc1;
                	
                	if (lenSortedDocs == 1) {               		
                		if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {  // document is pre-autoenrollment doc or autoenrollment doc and its past active date
                			docIndex = 0;
                		}
                		
                	} else {
                		// there are 2 documents found, if its past active date take the autoenrollment doc, if not then take the most recent updated doc
                		doc1 = determineDocumentIndex(sortedDocs.getDocuments(), lenSortedDocs, 1, currentDate);
    					docIndex = determineMulti(doc0, doc1);
                	}
                	
                	if (docIndex >= 0) {
                		//converting response optoutcloud
                		Document doc = sortedDocs.getDocuments().get(docIndex);
                    	prefType.setDocumentId(doc.getId());
                        prefType.setProviderEmailId(doc.getMetadata().getProviderEmailId());
                        prefType.setFrequency(doc.getMetadata().getFrequency());
                        prefType.setOkToChangePDOInd(doc.getMetadata().getOkToChangePDOInd());
                        prefType.setAutoEdelUpdateInd((doc.getMetadata().getAutoEdelUpdateInd()));
                        
                        prefType.setLastUpdatedBy(doc.getMetadata().getLastUpdatedBy());
                        prefType.setAutoOptOutInd(doc.getMetadata().getAutoOptOutInd());
                        prefType.setOptedOutDuration(doc.getMetadata().getOptedOutDuration());
                        prefType.setOptedOutDateTime(doc.getMetadata().getOptedOutDateTime());
                        
                        if (doc.getMetadata().getOptedOutDuration() != null 
                        		&& doc.getMetadata().getOptedOutDateTime() != null   
                        		&& (doc.getMetadata().getExpiryDate() == null 
                        		|| doc.getMetadata().getExpiryDate().isEmpty() 
                        		|| doc.getMetadata().getExpiryDate().length() < "2020-05-01T04:00:00.000Z".length())) {
                        	if (doc.getMetadata().getOptedOutDuration() == 9999) {
                        		prefType.setExpiryDate("9999-12-31T23:59:59.000Z");
                        	}
                        	else {
                        		Calendar cal = Calendar.getInstance();
                        		Date optOutDate = parseDateString(doc.getMetadata().getOptedOutDateTime());
                            	cal.setTime(optOutDate);
                            	cal.add(Calendar.DATE, doc.getMetadata().getOptedOutDuration());
                            	prefType.setExpiryDate(formatDate(cal.getTime()));
                        	}
                        }
                        else {
                        	prefType.setExpiryDate(doc.getMetadata().getExpiryDate());
                        }
                	}
                	
                }
                
            }

            providerPreferences.setCorporateTin(tin);
            providerPreferences.setPreferenceTypes(preferenceTypeList);
            logger.info("returnedProviderPreferences={}", providerPreferences);
            return providerPreferences;
        } catch (ApplicationException | ParseException | IOException | OAuthSystemException| OAuthProblemException| RestClientException| NullPointerException e) {
            logger.error("ERROR RETRIEVING PREFERENCES FOR MPIN, mpin={}, error={}",Encode.forJava(mpin) ,e);
            throw new ApplicationException("ERROR RETRIEVING PREFERENCES FOR MPIN");
        }
    }


    public PasswordOwner getProvidersByCorporate(String uuid, String uhcId, String mpin, HttpHeaders headers, LogMessage logMessage)
            throws ApplicationException, JsonProcessingException
    {
        cacf = new CACFHandler();

        logMessage.setDetail("Session-" + headers.getFirst("sm_serversessionid") + ": Getting TIN's by MPIN");
        logger.info(logMessage.toString());

        return cacf.getTaxIDNumbers(uuid, uhcId, mpin, headers.getFirst("sm_serversessionid"));

    }

        
        public CorpMpinResponse getProviderData(RequestData request, HttpHeaders headers, LogMessage logMessage) throws ApplicationException
    {
        logger.info("Getting Provider Data from NDB, session={}",Encode.forJava(headers.getFirst("sm_serversessionid")));
        

        try
        {
            return ndbHandler.getProviderData(request);
        }
        catch (ApplicationException | IOException| OAuthSystemException| OAuthProblemException| RestClientException e)
        {
            logger.error("Error retrieving Provider Data from NDB, error={}", e);
            throw new ApplicationException("Error making service call to NDB");
        }

    }
    
    public ProviderPreferencesObj getProviderPreferencesFDSCloud(String tin, String mpin, HttpHeaders headers, LogMessage logMessage) throws ApplicationException, JsonParseException, JsonMappingException, IOException
    {
        try
        {
            mpin = padWithLeadingZeros(mpin);
        }
        catch (ApplicationException e)
        {
            logger.error("ERROR PADDING MPIN WITH LEADING ZEROS, error={}", e);
            throw e;
        }
       
        try
        {
           
            fdsCloudHandler = new FDSCloudHandler();

            logger.info("Getting preferences by TIN, session={}", Encode.forJava(headers.getFirst("sm_serversessionid")));

            ProviderPreferencesObj providerPreferences = new ProviderPreferencesObj();
            List<PreferenceType> preferenceTypeList = new ArrayList<>();

            /*
             * Need a technical US for using Java Futures for the below sequential webService calls 2/1
             */

            /* Call NDB to retrieve letter preferences */
            logger.info("Calling NDB Letter Preferences, session={}", Encode.forJava(headers.getFirst("sm_serversessionid")));
            LetterPreferencesResponse ndbLetterPreferencesResponse = null;
            
            if(logMessage.getUsername() != null && logMessage.getUsername().equals("CUCUMBERTEST")) {
                PreferenceType preferenceType = new PreferenceType();          
                preferenceType.setClassifier(logMessage.getActor());
                preferenceType.setDeliveryMethod("E");
                preferenceTypeList.add(preferenceType);
            }
            else {
              
              try
              {
                  ndbLetterPreferencesResponse =
                          ndbHandler.getProviderLetterPreferences(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(mpin, tin, "I"));
              }
              catch (ApplicationException e)
              {
                  logger.error("ERROR CALLING NDB GET PREFS, error={}", e);
                  throw new ApplicationException("ERROR CALLING NDB");
              }

              if (ndbLetterPreferencesResponse.getResponseHeader().getMessage() == null)
              {
                  logger.error("NDB RESPONSE MESSAGE IS NULL - ERROR");
                  throw new ApplicationException("ERROR CALLING NDB");
              }
              if (!(ndbLetterPreferencesResponse.getResponseHeader().getMessage().equals("SUCCESSFUL")))
              {
                  logger.error("Error with web service call to NDB Letter Preferences - POST, message={}", Encode.forJava(ndbLetterPreferencesResponse.getResponseHeader().getMessage()));
                  throw new ApplicationException("ERROR CALLING NDB");
              }
              for (MailPref pref : ndbLetterPreferencesResponse.getRequestResponse().getLtrTypMailPrfList())
              {
                  PreferenceType preferenceType = new PreferenceType();
                  preferenceType.setClassifier(pref.getLetterType());
                  preferenceType.setDeliveryMethod(pref.getMailingPref());
                  preferenceTypeList.add(preferenceType);
              }
            }

            for (PreferenceType prefType : preferenceTypeList)
            {
                prefType.setDescription(ClassifierDescription.getClassifierDescription(Converter.convertNullToString(prefType.getClassifier().toUpperCase())));
                prefType.setLob(ClassifierDescription.getLob(Converter.convertNullToString(prefType.getClassifier().toUpperCase())));
                

                Map<String, Object> metadataMap=new HashMap<>();
                metadataMap.put("tin", tin);
                metadataMap.put("mpin", mpin);
                metadataMap.put("fileName", prefType.getClassifier());
                FDSCloudRequest searchTerms=fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap);
                FDSCloudGETResponse sortedDocs=fdsCloudHandler.FDSCloudGetRequest("testId", searchTerms);
                int lenSortedDocs = sortedDocs.getDocuments().size();
                
                if (lenSortedDocs > 0) {
                	
                	int docIndex = -1;
                	OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);
                	
                	AutoEnrollment doc0 = determineDocumentIndexCloud(sortedDocs.getDocuments(), lenSortedDocs, 0, currentDate);
                	AutoEnrollment doc1;
                	
                	if (lenSortedDocs == 1) {               		
                		if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {  // document is pre-autoenrollment doc or autoenrollment doc and its past active date
                			docIndex = 0;
                		}
                		
                	} else {
                		// there are 2 documents found, if its past active date take the autoenrollment doc, if not then take the most recent updated doc
                		doc1 = determineDocumentIndexCloud(sortedDocs.getDocuments(), lenSortedDocs, 1, currentDate);
    					docIndex = determineMulti(doc0, doc1);
                	}
                	
                	if (docIndex >= 0) {
                		OptOutFDSCloudDocument doc = sortedDocs.getDocuments().get(docIndex);
                		String metaDataString=doc.getMetadata();
                		Metadata metadataObj = mapper.readValue(metaDataString, Metadata.class);
                		
                		// metadataObj.getprovider
                		prefType.setDocumentId(doc.getDocumentId());
                        prefType.setProviderEmailId(metadataObj.getProviderEmailId());
                        prefType.setFrequency(metadataObj.getFrequency());
                        prefType.setOkToChangePDOInd(metadataObj.getOkToChangePDOInd());
                        prefType.setAutoEdelUpdateInd((metadataObj.getAutoEdelUpdateInd()));
                        
                        prefType.setLastUpdatedBy(metadataObj.getLastUpdatedBy());
                        prefType.setAutoOptOutInd(metadataObj.getAutoOptOutInd());
                        prefType.setOptedOutDuration(metadataObj.getOptedOutDuration());
                        prefType.setOptedOutDateTime(metadataObj.getOptedOutDateTime());
                        
                        if (metadataObj.getOptedOutDuration() != null 
                        		&& metadataObj.getOptedOutDateTime() != null   
                        		&& metadataObj.getExpiryDate() == null 
                        		|| (metadataObj.getExpiryDate() != null && (metadataObj.getExpiryDate().isEmpty() 
                        		|| metadataObj.getExpiryDate().length() < "2020-05-01T04:00:00.000Z".length()))) {
                        	if (metadataObj.getOptedOutDuration() == 9999) {
                        		prefType.setExpiryDate("9999-12-31T23:59:59.000Z");
                        	}
                        	else {
                        		Calendar cal = Calendar.getInstance();
                        		Date optOutDate = parseDateString(metadataObj.getOptedOutDateTime());
                            	cal.setTime(optOutDate);
                            	cal.add(Calendar.DATE, metadataObj.getOptedOutDuration());
                            	prefType.setExpiryDate(formatDate(cal.getTime()));
                        	}
                        }
                        else {
                        	prefType.setExpiryDate(metadataObj.getExpiryDate());
                        }
                	}
                	
                }
                
            }

            providerPreferences.setCorporateTin(tin);
            providerPreferences.setPreferenceTypes(preferenceTypeList);
            logger.info("returnedProviderPreferences={}", providerPreferences);
            return providerPreferences;
        } catch (ApplicationException | ParseException | RestClientException| NullPointerException e) {
            logger.error("ERROR RETRIEVING PREFERENCES FOR MPIN, mpin={}, error={}",Encode.forJava(mpin) ,e);
            throw new ApplicationException("ERROR RETRIEVING PREFERENCES FOR MPIN");
        }
    }
    
 
    public void updateProviderPreferences(ProviderPreferencesObj providerPreferences, HttpHeaders headers) 
    		throws IOException, ApplicationException, OAuthProblemException, OAuthSystemException, ParseException {
    	logger.info("updateProviderPreferences --> providerPreferences={}, headers={}", Encode.forJava(providerPreferences.toString()), Encode.forJava(headers.toString()));
    	
    	headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
     
        try {
        	
        	
            
            if (providerPreferences.getPreferenceTypes().size() == 1 && providerPreferences.getPreferenceTypes().get(0).getClassifier().equalsIgnoreCase("ALL")) {
                // update all letter types to same prefs
                PreferenceType masterPref = providerPreferences.getPreferenceTypes().get(0);

                // get oauth tokens and start timer
                long startTime = System.currentTimeMillis();
                ndbHandler.ndbWebServicePrep();
                
                // FOR EVERY PROVIDER....
                for (String currentMpin : providerPreferences.getSelectedProviders()) {
                    currentMpin = padWithLeadingZeros(currentMpin);
                    String currentTin = padWithLeadingZeros(providerPreferences.getCorporateTin());

                    // FOR EVERY CLASSIFIER FOR THE CURRENT PROVIDER...
                    for (String classifier : ClassifierDescription.classifierDescriptionHash.keySet())
                    {
                        // UPDATE NDB FOR EVERY CLASSIFIER FOR CURRENT PROVIDER

                        LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
                        webRequest.setRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(currentMpin, currentTin, "U",
                                masterPref.getDeliveryMethod(), classifier));
                        webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));

                        try {
                            ndbHandler.updateProviderLetterPreferences(webRequest, currentMpin, currentTin);
                        } catch (JsonProcessingException e) {
                            logger.warn("ERROR UPDATING TO NDB, mpin={}, tin={}, error={}", Encode.forJava(currentMpin), Encode.forJava(currentTin), e);
                            
                        }

                        // UPDATE FDS FOR EVERY CLASSIFIER FOR CURRENT PROVIDER
                        // get the current document in fds for the classifier, mpin, and tin

                        FDSResponse response = fdsHandler.getDocumentListSortCreated(currentTin, currentMpin, classifier, SESSION_ID_ALL);

                        // build document to add/update
                        MultiValueMap<String, Document> docsMapToSend = new LinkedMultiValueMap<>();
                        Document docToSend;
                        String docId;
                        String activeDateStr;

                        int lenDocs = response.getDocuments().size();
                        
                        if (lenDocs > 0) {
                        	int docIndex = -1;
                        	OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);
                        	
                        	AutoEnrollment doc0 = determineDocumentIndex(response.getDocuments(), lenDocs, 0, currentDate);
                        	AutoEnrollment doc1;
                        	
                        	if (lenDocs == 1) {
                        		// only 1 document
                        		if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {  // document is pre-autoenrollment doc or autoenrollment doc and its past active date
                        			docIndex = 0;
                        		} else if (doc0.isAutoEnrollment && !doc0.isValidAutoEnrollment()) {
                        			docIndex = -2;
                        		}
                        		
                        	} else {
                        		// 2 documents, pick the autoenrollment one if after active date, pick pre-autoenrollment one if before active date
                        		doc1 = determineDocumentIndex(response.getDocuments(), lenDocs, 1, currentDate);
            					docIndex = determineMulti(doc0, doc1);
                        	}

                        	if (docIndex >= 0) {
                        		// creating docToSend
                        		docId = response.getDocuments().get(docIndex).getId();
                        		// get activeDate from existing document
                        		activeDateStr = response.getDocuments().get(docIndex).getMetadata().getActiveDate();
                        		//this creates the metadata
                        		docToSend = createDocToSendWithClassifier(masterPref, padWithLeadingZeros(currentMpin), currentTin, docId, activeDateStr, classifier);
//                        		docToSend.setSpaceId(SPACE_ID);
//                        		docsMapToSend.add("documents", docToSend);
                        		
                                try {
                                    fdsHandler.callFDSPutDocument(docsMapToSend, headers, docId, SESSION_ID_ALL);
                                } catch (RestClientException| JsonProcessingException e) {
                                	Gson gson = new Gson();
                                	String requestString = gson.toJson(docToSend.getMetadata());
                                	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", docToSend.getId(), requestString);
                                    continue;
                                }
                        	}
                        	
                        	if (docIndex == -2) {
                        		// no pre-autoenrollment document in FDS, must create with null docId and null activeDate
                        		docToSend = createDocToSendWithClassifier(masterPref, padWithLeadingZeros(currentMpin), currentTin, null, null, classifier);
                            	docToSend.setSpaceId(SPACE_ID);
                            	docsMapToSend.add("documents", docToSend);

                            	try {
                                    fdsHandler.callFDSPostDocument(docsMapToSend, headers, SESSION_ID_ALL);
                            	} catch (IOException| OAuthSystemException| OAuthProblemException| ApplicationException e) {
                                	logger.warn("ERROR ADDING TEST DOCUMENT FOR MPIN: {}", Encode.forJava(docToSend.getMetadata().getMpin()));
                                }
                        		
                        	}
                        	
                        } else {
                        	// no document in FDS, must create with null docId
                        	// send null activeDate because we should never create a record in FDS with activeDate
                        	docToSend = createDocToSendWithClassifier(masterPref, padWithLeadingZeros(currentMpin), currentTin, null, null, classifier);
                        	docToSend.setSpaceId(SPACE_ID);
                        	docsMapToSend.add("documents", docToSend);

                            try {
                                fdsHandler.callFDSPostDocument(docsMapToSend, headers, SESSION_ID_ALL);
                            } catch (IOException | OAuthSystemException | OAuthProblemException e) {
                                logger.warn("ERROR ADDING DOCUMENT FOR MPIN, metadata={}, error={} " + Encode.forJava(docToSend.getMetadata().getMpin()), e);
                                continue;
                            }

                        }
                    }

                }

            } else {
                // update the specific preferences passed in
                List<PreferenceType> prefList = providerPreferences.getPreferenceTypes();

                // get oauth tokens and start timer
                long startTime = System.currentTimeMillis();
                ndbHandler.ndbWebServicePrep();

                // FOR EVERY PROVIDER....
                for (String currentMpin : providerPreferences.getSelectedProviders()) {
                    currentMpin = padWithLeadingZeros(currentMpin);
                    String currentTin = padWithLeadingZeros(providerPreferences.getCorporateTin());


                    // FOR EVERY SPECIFIC PREFERENCE FOR CURRENT PROVIDER
                    for (PreferenceType currentPref : prefList) {
                        // UPDATE NDB FOR EVERY CLASSIFIER FOR CURRENT PROVIDER
                        LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
                        webRequest.setRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(currentMpin, currentTin, "U",
                                currentPref.getDeliveryMethod(), currentPref.getClassifier()));
                        webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));

                        try {
                            ndbHandler.updateProviderLetterPreferences(webRequest, currentMpin, currentTin);
                        } catch (JsonProcessingException e) {
                            logger.warn("ERROR UPDATING TO NDB, error={}", e);
//                            throw e;
                        }

                        // UPDATE FDS FOR EVERY CLASSIFIER FOR CURRENT PROVIDER

                        // get the current document in fds for the classifier, mpin, and tin
                        
                        FDSResponse response = fdsHandler.getDocumentListSortCreated(currentTin, currentMpin, currentPref.getClassifier(), SESSION_ID_SPECIFIC);

                        // build document to add/update
                        MultiValueMap<String, Document> docsMapToSend = new LinkedMultiValueMap<>(); 
                        Document docToSend;
                        String docId;
                        String activeDateStr;

                        int lenDocs = response.getDocuments().size();
                        
                        if (lenDocs > 0) {
                        	int docIndex = -1;
                        	OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);
                        	
                        	AutoEnrollment doc0 = determineDocumentIndex(response.getDocuments(), lenDocs, 0, currentDate);
                        	AutoEnrollment doc1;
                        	
                        	if (lenDocs == 1) {
                        		// only 1 document
                        		if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {  // document is pre-autoenrollment doc or autoenrollment doc and its past active date
                        			docIndex = 0;
                        		} else if (doc0.isAutoEnrollment && !doc0.isValidAutoEnrollment()) {
                        			docIndex = -2;
                        		}
                        		
                        	} else {
                        		// 2 documents, pick the autoenrollment one if after active date, pick pre-autoenrollment one if before active date
                        		doc1 = determineDocumentIndex(response.getDocuments(), lenDocs, 1, currentDate);
            					docIndex = determineMulti(doc0, doc1);
                        	}

                        	if (docIndex >= 0) {
                        		// creating docToSend
                        		docId = response.getDocuments().get(docIndex).getId();
                        		// getting activeDate from existing document
                        		activeDateStr = response.getDocuments().get(docIndex).getMetadata().getActiveDate();
                        		docToSend = createDocToSend(currentPref, padWithLeadingZeros(currentMpin), currentTin, docId, activeDateStr);
                        		docToSend.setSpaceId(SPACE_ID);
                        		docsMapToSend.add("documents", docToSend);
                        		
                                try {
                                    fdsHandler.callFDSPutDocument(docsMapToSend, headers, docId, SESSION_ID_ALL);
                                } catch (RestClientException| JsonProcessingException e) {
                                	Gson gson = new Gson();
                                	String requestString = gson.toJson(docToSend.getMetadata());
                                	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", docToSend.getId(), requestString);
                                    continue;
                                }
                        	}
                        	
                        	if (docIndex == -2) {
                        		// no pre-autoenrollment document in FDS, must create with null docId and null activeDate
                        		docToSend = createDocToSend(currentPref, padWithLeadingZeros(currentMpin), currentTin, null, null);
                            	docToSend.setSpaceId(SPACE_ID);
                            	docsMapToSend.add("documents", docToSend);

                            	try {
                                    fdsHandler.callFDSPostDocument(docsMapToSend, headers, SESSION_ID_ALL);
                                } catch (IOException | OAuthSystemException | OAuthProblemException | ApplicationException e) {
                                	logger.warn("ERROR ADDING TEST DOCUMENT FOR MPIN={}", Encode.forJava(docToSend.getMetadata().getMpin()));
                                }
                        		
                        	}
                        	
                        } else {
                        	// no document in FDS, must create with null docId
                        	// send null activeDateStr because we should never create a document with activeDate
                        	docToSend = createDocToSend(currentPref, padWithLeadingZeros(currentMpin), currentTin, null, null);
                        	docToSend.setSpaceId(SPACE_ID);
                        	docsMapToSend.add("documents", docToSend);

                            try {
                                fdsHandler.callFDSPostDocument(docsMapToSend, headers, SESSION_ID_ALL);
                            } catch (IOException | OAuthSystemException | OAuthProblemException  e) {
                                logger.warn("ERROR ADDING DOCUMENT FOR MPIN, metadata={}, error={} ", Encode.forJava(docToSend.getMetadata().getMpin()), e);
                                continue;
                            }

                        }
                    }

                }

            }

        } catch (ApplicationException | OAuthProblemException | OAuthSystemException | ParseException e) {
        	logger.error("FATAL ERROR while updating provider preferences, providerPreferences={}, error={}", Encode.forJava(providerPreferences.toString()), e);
        	throw e;

        }
    	
    }
    
    public void updateProviderPreferencesFDSCloud(ProviderPreferencesObj providerPreferences, HttpHeaders headers) 
    		throws IOException, ApplicationException, OAuthProblemException, OAuthSystemException, ParseException {
    	logger.info("updateProviderPreferences --> providerPreferences={}, headers={}", Encode.forJava(providerPreferences.toString()), Encode.forJava(headers.toString()));
    	
    	headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
     
        try {
        	
        	
        	fdsCloudHandler = new FDSCloudHandler();

            if (providerPreferences.getPreferenceTypes().size() == 1 && providerPreferences.getPreferenceTypes().get(0).getClassifier().equalsIgnoreCase("ALL")) {
                // update all letter types to same prefs
                PreferenceType masterPref = providerPreferences.getPreferenceTypes().get(0);

                // get oauth tokens and start timer
                long startTime = System.currentTimeMillis();
                ndbHandler.ndbWebServicePrep();
                
                // FOR EVERY PROVIDER....
                for (String currentMpin : providerPreferences.getSelectedProviders()) {
                    currentMpin = padWithLeadingZeros(currentMpin);
                    String currentTin = padWithLeadingZeros(providerPreferences.getCorporateTin());

                    // FOR EVERY CLASSIFIER FOR THE CURRENT PROVIDER...
                    for (String classifier : ClassifierDescription.classifierDescriptionHash.keySet())
                    {
                        // UPDATE NDB FOR EVERY CLASSIFIER FOR CURRENT PROVIDER

                        LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
                        webRequest.setRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(currentMpin, currentTin, "U",
                                masterPref.getDeliveryMethod(), classifier));
                        webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));

                        try {
                            ndbHandler.updateProviderLetterPreferences(webRequest, currentMpin, currentTin);
                        } catch (JsonProcessingException e) {
                            logger.error("ERROR UPDATING TO NDB, mpin={}, tin={}, error={}", Encode.forJava(currentMpin), Encode.forJava(currentTin), e);
                            throw e;
                        }

                        // UPDATE FDS FOR EVERY CLASSIFIER FOR CURRENT PROVIDER
                        // get the current document in fds for the classifier, mpin, and tin

                        Map<String, Object> metadataMap = new HashMap<>();
                        metadataMap.put("tin", currentTin);
                        metadataMap.put("mpin", currentMpin);
                        metadataMap.put("fileName", classifier);
                        FDSCloudRequest searchTerms=fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap);
    	                FDSCloudGETResponse response=fdsCloudHandler.FDSCloudGetRequest("testId", searchTerms);
                        // build document to add/update
                        Map<String, Object> docToSend;
            			FDSCloudRequest postRequest = new FDSCloudRequest();

            			
                        String docId;
                        String activeDateStr;

                        int lenDocs = response.getDocuments().size();
                        
                        if (lenDocs > 0) {
                        	int docIndex = -1;
                        	OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);
                        	
                        	AutoEnrollment doc0 = determineDocumentIndexCloud(response.getDocuments(), lenDocs, 0, currentDate);
                        	AutoEnrollment doc1;
                        	
                        	if (lenDocs == 1) {
                        		// only 1 document
                        		if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {  // document is pre-autoenrollment doc or autoenrollment doc and its past active date
                        			docIndex = 0;
                        		} else if (doc0.isAutoEnrollment && !doc0.isValidAutoEnrollment()) {
                        			docIndex = -2;
                        		}
                        		
                        	} else {
                        		// 2 documents, pick the autoenrollment one if after active date, pick pre-autoenrollment one if before active date
                        		doc1 = determineDocumentIndexCloud(response.getDocuments(), lenDocs, 1, currentDate);
            					docIndex = determineMulti(doc0, doc1);
                        	}

                        	if (docIndex >= 0) {
                        		docId = response.getDocuments().get(docIndex).getDocumentId();
    	                		OptOutFDSCloudDocument doc = response.getDocuments().get(docIndex);
    	                		Metadata metadataObj = mapper.readValue(doc.getMetadata(), Metadata.class);
    	                		activeDateStr = metadataObj.getActiveDate();    	            

                        		docToSend = createDocToSendWithClassifierCloud(masterPref, padWithLeadingZeros(currentMpin), currentTin, docId, activeDateStr, classifier);
                        		postRequest.setRequest(docToSend);
                        		postRequest.setDocumentId(docId);

                        		//fds cloud request
                                try {
                                	fdsCloudHandler.FDSCloudPutRequest(SESSION_ID_ALL, postRequest);
                                } catch (Exception e) {
                                	Gson gson = new Gson();
                                	String requestString = gson.toJson(postRequest.getRequest());
                                	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", doc.getDocumentId(), requestString);
                                    continue;
                                }
                        	}
                        	
                        	if (docIndex == -2) {
                        		// no pre-autoenrollment document in FDS, must create with null docId and null activeDate
                        		docToSend = createDocToSendWithClassifierCloud(masterPref, padWithLeadingZeros(currentMpin), currentTin, null, null, classifier);
                    			postRequest.setRequest(docToSend);

                            	try {
                            		fdsCloudHandler.FDSCloudPostRequest(SESSION_ID_ALL, postRequest);
                            	} catch (Exception e) {
                            		Gson gson = new Gson();
                                	String requestString = gson.toJson(postRequest.getRequest());
                                	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", null, requestString);
                                	continue;
                                }
                        		
                        	}
                        	
                        } else {

                        	docToSend = createDocToSendWithClassifierCloud(masterPref, padWithLeadingZeros(currentMpin), currentTin, null, null, classifier);
                    		postRequest.setRequest(docToSend);

                            try {
                            	fdsCloudHandler.FDSCloudPostRequest(SESSION_ID_ALL, postRequest);
                            } 
                        	catch (Exception e) {
                        		Gson gson = new Gson();
                            	String requestString = gson.toJson(postRequest.getRequest());
                            	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", null, requestString);
                                continue;
                            }

                        }
                    }

                }

            } else {
                // update the specific preferences passed in
                List<PreferenceType> prefList = providerPreferences.getPreferenceTypes();

                // get oauth tokens and start timer
                long startTime = System.currentTimeMillis();
                ndbHandler.ndbWebServicePrep();

                // FOR EVERY PROVIDER....
                for (String currentMpin : providerPreferences.getSelectedProviders()) {
                    currentMpin = padWithLeadingZeros(currentMpin);
                    String currentTin = padWithLeadingZeros(providerPreferences.getCorporateTin());


                    // FOR EVERY SPECIFIC PREFERENCE FOR CURRENT PROVIDER
                    for (PreferenceType currentPref : prefList) {
                        // UPDATE NDB FOR EVERY CLASSIFIER FOR CURRENT PROVIDER
                        LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
                        webRequest.setRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(currentMpin, currentTin, "U",
                                currentPref.getDeliveryMethod(), currentPref.getClassifier()));
                        webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));

                        try {
                            ndbHandler.updateProviderLetterPreferences(webRequest, currentMpin, currentTin);
                        } catch (JsonProcessingException e) {
                            logger.warn("ERROR UPDATING TO NDB, error={}", e);
//                            throw e;
                        }

                        // UPDATE FDS FOR EVERY CLASSIFIER FOR CURRENT PROVIDER

                        // get the current document in fds for the classifier, mpin, and tin


                        Map<String, Object> metadataMap = new HashMap<>();
                        metadataMap.put("tin", currentTin);
                        metadataMap.put("mpin", currentMpin);
                        metadataMap.put("fileName", currentPref.getClassifier());
                        FDSCloudRequest searchTerms=fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap);
    	                FDSCloudGETResponse response=fdsCloudHandler.FDSCloudGetRequest("testId", searchTerms);
                        // build document to add/update
                        Map<String, Object> docToSend;
            			FDSCloudRequest postRequest = new FDSCloudRequest();

                        String docId;
                        String activeDateStr;
                        String subscribeToEmail;

                        int lenDocs = response.getDocuments().size();
                        
                        if (lenDocs > 0) {
                        	int docIndex = -1;
                        	OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);
                        	
                        	AutoEnrollment doc0 = determineDocumentIndexCloud(response.getDocuments(), lenDocs, 0, currentDate);
                        	AutoEnrollment doc1;
                        	
                        	if (lenDocs == 1) {
                        		// only 1 document
                        		if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {  // document is pre-autoenrollment doc or autoenrollment doc and its past active date
                        			docIndex = 0;
                        		} else if (doc0.isAutoEnrollment && !doc0.isValidAutoEnrollment()) {
                        			docIndex = -2;
                        		}
                        		
                        	} else {
                        		// 2 documents, pick the autoenrollment one if after active date, pick pre-autoenrollment one if before active date
                        		doc1 = determineDocumentIndexCloud(response.getDocuments(), lenDocs, 1, currentDate);
            					docIndex = determineMulti(doc0, doc1);
                        	}

                        	if (docIndex >= 0) {
                        		docId = response.getDocuments().get(docIndex).getDocumentId();
    	                		OptOutFDSCloudDocument doc = response.getDocuments().get(docIndex);
    	                		Metadata metadataObj = mapper.readValue(doc.getMetadata(), Metadata.class);
                                subscribeToEmail= metadataObj.getSubscribeToEmail();
                                activeDateStr=metadataObj.getActiveDate();

                        		docToSend = createDocToSendCloud(currentPref, padWithLeadingZeros(currentMpin), currentTin, docId, activeDateStr,subscribeToEmail);

                        		postRequest.setRequest(docToSend);
                        		postRequest.setDocumentId(docId);

                                try {
                                	fdsCloudHandler.FDSCloudPutRequest(SESSION_ID_ALL, postRequest);
                                } catch (Exception e) {
                                	Gson gson = new Gson();
                                	String requestString = gson.toJson(postRequest.getRequest());
                                	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", doc.getDocumentId(), requestString);
                                    continue;
                                }
                        	}
                        	
                        	if (docIndex == -2) {
                        		// no pre-autoenrollment document in FDS, must create with null docId and null activeDate                    
                        		docToSend = createDocToSendCloud(currentPref, padWithLeadingZeros(currentMpin), currentTin, null, null, null);

                    			postRequest.setRequest(docToSend);
                    			

                            	try {
                            		fdsCloudHandler.FDSCloudPostRequest(SESSION_ID_ALL, postRequest);
                                } catch (Exception e) {
                                	Gson gson = new Gson();
                                	String requestString = gson.toJson(postRequest.getRequest());
                                	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", null, requestString);
                                	continue;
                                }
                        		
                        	}
                        	
                        } else {
                        	// no document in FDS, must create with null docId
                        	// send null activeDateStr because we should never create a document with activeDate
                         	docToSend = createDocToSendCloud(currentPref, padWithLeadingZeros(currentMpin), currentTin, null, null, null);
                         	postRequest.setRequest(docToSend);
                     
                            try {
                            	fdsCloudHandler.FDSCloudPostRequest(SESSION_ID_ALL, postRequest);
                            } catch (Exception  e) {
                            	Gson gson = new Gson();
                            	String requestString = gson.toJson(postRequest.getRequest());
                            	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", null, requestString);
                                continue;
                            }

                        }
                    }

                }

            }

        } catch (ApplicationException | ParseException e) {
        	logger.error("FATAL ERROR while updating provider preferences, providerPreferences={}, error={}", Encode.forJava(providerPreferences.toString()), e);
//        	throw e;

        }
    	
    }
    
    private Document createDocToSend(PreferenceType masterPref, String mpin, String tin, String docId, String activeDateStr) throws ParseException {
    	
    	Document docToSend = new Document();
    	Metadata metadata = new Metadata();
    	
    	if (docId != null) {
    		docToSend.setId(docId);
    	}
    	if (masterPref.getActiveDate() != null) {
    		// if PUT request contains activeDate
    		// this will most likely never happen (scenario 1)
    		metadata.setActiveDate(masterPref.getActiveDate());
    	} else {
    		// get activeDateStr from existing document (scenario 2)
    		// if its null then that means the existing record doesn't have activeDate so it doesn't need it (scenario 3)
    		if (activeDateStr != null) {
    			metadata.setActiveDate(activeDateStr);
    		}
    	}
        metadata.setDeliveryMethod(masterPref.getDeliveryMethod());
        metadata.setFileName(masterPref.getClassifier());
        metadata.setFileType(ClassifierDescription.getClassifierDescription(masterPref.getClassifier()));
        metadata.setFrequency(masterPref.getFrequency());
        metadata.setMpin(mpin);
        metadata.setProviderEmailId(masterPref.getProviderEmailId());
        metadata.setProviderName(masterPref.getProviderName());
        metadata.setTin(tin);
        metadata.setAutoEdelUpdateInd(masterPref.getAutoEdelUpdateInd());
        metadata.setOkToChangePDOInd(masterPref.getOkToChangePDOInd());
        
        // TODO: add lastUpdatedById for optumUUID
        metadata.setLastUpdatedBy(masterPref.getLastUpdatedBy());
        metadata.setAutoOptOutInd(masterPref.getAutoOptOutInd());
        metadata.setOptedOutDuration(masterPref.getOptedOutDuration());
        metadata.setOptedOutDateTime(masterPref.getOptedOutDateTime());
        
        if (masterPref.getOptedOutDuration() != null 
        		&& masterPref.getOptedOutDateTime() != null   
        		&& (masterPref.getExpiryDate() == null 
        		|| masterPref.getExpiryDate().isEmpty() 
        		|| masterPref.getExpiryDate().length() < "2020-05-01T04:00:00.000Z".length())) {
        	if (masterPref.getOptedOutDuration() == 9999) {
        		metadata.setExpiryDate("9999-12-31T23:59:59.000Z");
        	}
        	else {
        		Calendar cal = Calendar.getInstance();
        		Date optOutDate = parseDateString(masterPref.getOptedOutDateTime());
            	cal.setTime(optOutDate);
            	cal.add(Calendar.DATE, masterPref.getOptedOutDuration());
            	metadata.setExpiryDate(formatDate(cal.getTime()));
        	}
        }
        else {
        	metadata.setExpiryDate(masterPref.getExpiryDate());
        }

        docToSend.setMetadata(metadata);

        return docToSend;
    	
    }
    
 private Map<String, Object> createDocToSendCloud(PreferenceType masterPref, String mpin, String tin, String docId, String activeDateStr, String subscribeToEmail) throws ParseException {
	
	Document docToSend = new Document();
 	Metadata metadata = new Metadata();
 	
 	if (docId != null) {
 		docToSend.setId(docId);
 	}
 	if (masterPref.getActiveDate() != null) {
 		// if PUT request contains activeDate
 		// this will most likely never happen (scenario 1)
 		metadata.setActiveDate(masterPref.getActiveDate());
 	} else {
 		// get activeDateStr from existing document (scenario 2)
 		// if its null then that means the existing record doesn't have activeDate so it doesn't need it (scenario 3)
 		if (activeDateStr != null) {
 			metadata.setActiveDate(activeDateStr);
 		}
 	}
     if(masterPref.getSubscribeToEmail()!= null){
         metadata.setSubscribeToEmail(masterPref.getSubscribeToEmail());
     }
     else{
         if(subscribeToEmail!=null){
             metadata.setSubscribeToEmail(subscribeToEmail);
         }
         else{
             metadata.setSubscribeToEmail("Y");
         }
     }
     metadata.setDeliveryMethod(masterPref.getDeliveryMethod());
     metadata.setFileName(masterPref.getClassifier());
     metadata.setFileType(ClassifierDescription.getClassifierDescription(masterPref.getClassifier()));
     metadata.setFrequency(masterPref.getFrequency());
     metadata.setMpin(mpin);
     metadata.setProviderEmailId(masterPref.getProviderEmailId());
     metadata.setProviderName(masterPref.getProviderName());
     metadata.setTin(tin);
     metadata.setAutoEdelUpdateInd(masterPref.getAutoEdelUpdateInd());
     metadata.setOkToChangePDOInd(masterPref.getOkToChangePDOInd());
     
     // TODO: add lastUpdatedById for optumUUID
     metadata.setLastUpdatedBy(masterPref.getLastUpdatedBy());
     metadata.setAutoOptOutInd(masterPref.getAutoOptOutInd());
     metadata.setOptedOutDuration(masterPref.getOptedOutDuration());
     metadata.setOptedOutDateTime(masterPref.getOptedOutDateTime());
     
     if (masterPref.getOptedOutDuration() != null 
     		&& masterPref.getOptedOutDateTime() != null   
     		&& (masterPref.getExpiryDate() == null 
     		|| masterPref.getExpiryDate().isEmpty() 
     		|| masterPref.getExpiryDate().length() < "2020-05-01T04:00:00.000Z".length())) {
     	if (masterPref.getOptedOutDuration() == 9999) {
     		metadata.setExpiryDate("9999-12-31T23:59:59.000Z");
     	}
     	else {
     		Calendar cal = Calendar.getInstance();
     		Date optOutDate = parseDateString(masterPref.getOptedOutDateTime());
         	cal.setTime(optOutDate);
         	cal.add(Calendar.DATE, masterPref.getOptedOutDuration());
         	metadata.setExpiryDate(formatDate(cal.getTime()));
     	}
     }
     else {
     	metadata.setExpiryDate(masterPref.getExpiryDate());
     }

     docToSend.setMetadata(metadata);

     return mapper.convertValue(metadata, new TypeReference<Map<String, Object>>() {});
     	
    }
 private Document createDocToSendWithClassifier(PreferenceType masterPref, String mpin, String tin, String docId, String activeDateStr, String classifier) throws ParseException {
    	
    	Document docToSend = new Document();
    	
    	FDSCloudRequest cloudRequest = new FDSCloudRequest();
    	Metadata metadata = new Metadata();
    	
    	if (docId != null) {
    		docToSend.setId(docId);
    	}
    	if (masterPref.getActiveDate() != null) {
    		// if PUT request contains activeDate
    		// this will most likely never happen (scenario 1)
    		metadata.setActiveDate(masterPref.getActiveDate());
    	} else {
    		// get activeDateStr from existing document (scenario 2)
    		// if its null then that means the existing record doesn't have activeDate so it doesn't need it (scenario 3)
    		if (activeDateStr != null) {
    			metadata.setActiveDate(activeDateStr);
    		}
    	}
        metadata.setDeliveryMethod(masterPref.getDeliveryMethod());
        metadata.setFileName(classifier);
        metadata.setFileType(ClassifierDescription.getClassifierDescription(classifier));
        metadata.setFrequency(masterPref.getFrequency());
        metadata.setMpin(mpin);
        metadata.setProviderEmailId(masterPref.getProviderEmailId());
        metadata.setProviderName(masterPref.getProviderName());
        metadata.setTin(tin);
        metadata.setAutoEdelUpdateInd(masterPref.getAutoEdelUpdateInd());
        metadata.setOkToChangePDOInd(masterPref.getOkToChangePDOInd());
        
        metadata.setLastUpdatedBy(masterPref.getLastUpdatedBy());
        metadata.setLastUpdatedById(masterPref.getLastUpdatedById());
        metadata.setAutoOptOutInd(masterPref.getAutoOptOutInd());
        metadata.setOptedOutDuration(masterPref.getOptedOutDuration());
        metadata.setOptedOutDateTime(masterPref.getOptedOutDateTime());
        
        if (masterPref.getOptedOutDuration() != null 
        		&& masterPref.getOptedOutDateTime() != null   
        		&& (masterPref.getExpiryDate() == null 
        		|| masterPref.getExpiryDate().isEmpty() 
        		|| masterPref.getExpiryDate().length() < "2020-05-01T04:00:00.000Z".length())) {
        	if (masterPref.getOptedOutDuration() == 9999) {
        		metadata.setExpiryDate("9999-12-31T23:59:59.000Z");
        	}
        	else {
        		Calendar cal = Calendar.getInstance();
        		Date optOutDate = parseDateString(masterPref.getOptedOutDateTime());
            	cal.setTime(optOutDate);
            	cal.add(Calendar.DATE, masterPref.getOptedOutDuration());
            	metadata.setExpiryDate(formatDate(cal.getTime()));
        	}
        }
        else {
        	metadata.setExpiryDate(masterPref.getExpiryDate());
        }
        
        docToSend.setMetadata(metadata);

        return docToSend;
    	
    }

 private Map<String, Object> createDocToSendWithClassifierCloud(PreferenceType masterPref, String mpin, String tin, String docId, String activeDateStr, String classifier) throws ParseException {
	
	Document docToSend = new Document();
	Metadata metadata = new Metadata();
	
	if (docId != null) {
		docToSend.setId(docId);
	}
	if (masterPref.getActiveDate() != null) {
		// if PUT request contains activeDate
		// this will most likely never happen (scenario 1)
		metadata.setActiveDate(masterPref.getActiveDate());
	} else {
		// get activeDateStr from existing document (scenario 2)
		// if its null then that means the existing record doesn't have activeDate so it doesn't need it (scenario 3)
		if (activeDateStr != null) {
			metadata.setActiveDate(activeDateStr);
		}
	}
    metadata.setDeliveryMethod(masterPref.getDeliveryMethod());
    metadata.setFileName(classifier);
    metadata.setFileType(ClassifierDescription.getClassifierDescription(classifier));
    metadata.setFrequency(masterPref.getFrequency());
    metadata.setMpin(mpin);
    metadata.setProviderEmailId(masterPref.getProviderEmailId());
    metadata.setProviderName(masterPref.getProviderName());
    metadata.setTin(tin);
    metadata.setAutoEdelUpdateInd(masterPref.getAutoEdelUpdateInd());
    metadata.setOkToChangePDOInd(masterPref.getOkToChangePDOInd());
    
    metadata.setLastUpdatedBy(masterPref.getLastUpdatedBy());
    metadata.setLastUpdatedById(masterPref.getLastUpdatedById());
    metadata.setAutoOptOutInd(masterPref.getAutoOptOutInd());
    metadata.setOptedOutDuration(masterPref.getOptedOutDuration());
    metadata.setOptedOutDateTime(masterPref.getOptedOutDateTime());
    
    if (masterPref.getOptedOutDuration() != null 
    		&& masterPref.getOptedOutDateTime() != null   
    		&& (masterPref.getExpiryDate() == null 
    		|| masterPref.getExpiryDate().isEmpty() 
    		|| masterPref.getExpiryDate().length() < "2020-05-01T04:00:00.000Z".length())) {
    	if (masterPref.getOptedOutDuration() == 9999) {
    		metadata.setExpiryDate("9999-12-31T23:59:59.000Z");
    	}
    	else {
    		Calendar cal = Calendar.getInstance();
    		Date optOutDate = parseDateString(masterPref.getOptedOutDateTime());
        	cal.setTime(optOutDate);
        	cal.add(Calendar.DATE, masterPref.getOptedOutDuration());
        	metadata.setExpiryDate(formatDate(cal.getTime()));
    	}
    }
    else {
    	metadata.setExpiryDate(masterPref.getExpiryDate());
    }
    
   
    docToSend.setMetadata(metadata);

    return mapper.convertValue(metadata, new TypeReference<Map<String, Object>>() {});
}


	
	private synchronized String formatDate(Date date) {
		SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		return isoDateFormat.format(date);
	}
	
	private synchronized Date parseDateString(String date) throws ParseException {
		SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		return isoDateFormat.parse(date);
	}
    
    
    private String padWithLeadingZeros(String currentMpin) throws ApplicationException
    {
        int currentMpinLength = currentMpin.length();
        String stringOfZeros = "";
        if (currentMpinLength == 9)
        {
            return currentMpin;
        }
        else if (currentMpinLength < 9)
        {
            int numberOfZerosNeeded = 9 - currentMpinLength;
            for (int i = 0; i < numberOfZerosNeeded; i++)
            {
                stringOfZeros += "0";
            }
            currentMpin = stringOfZeros + currentMpin;
            return currentMpin;
        }
        else
        {
            logger.error("MPIN longer than 9 digits, mpin={}", Encode.forJava(currentMpin));
            throw new ApplicationException("MPIN longer than 9 digits");
        }

    }
    
	protected AutoEnrollment determineDocumentIndex(List<Document> documentList, int documentCount, int index, OffsetDateTime currentDate) throws AssertionError {
 		logger.info("Entering determineDocumentIndex: documentCount={}, index={}", documentCount, index);
 		
 		String documents=printDocument(documentList.get(index).getMetadata());
 		// PDO have the assumption that a maximum of 2 documents will exist for a given MPIN/TIN/LetterType combination
 		// them being the AutoEnrollment and the pre-AutoEnrollment records.
 		// The niche scenario occurs where a preference only has an AutoEnrollment record with no pre-AutoEnrollment record for
 		// it will create a new pre-AutoEnrollment record to store client changes between now and AutoEnrollment date.
 		// Thus if we have > 2 records they will be ignore.
 		
 		String activeDateStr = documentList.get(index).getMetadata().getActiveDate();
 		if (activeDateStr == null || activeDateStr.isEmpty()) {
 			logger.info("AutoEnrollment not found: documentCount={}, index={}, {}",
 					documentCount, index, documents);
 			return this.new AutoEnrollment(false, index);
 		}

 		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"); 		
 		OffsetDateTime activeDate = null;
 		try {
 			activeDate = OffsetDateTime.parse(activeDateStr, df);
 		} catch(AssertionError e) {
 			logger.error("checkDocumentIndex: ZonedDateTime; {}: {}", printDocument(documentList.get(index).getMetadata()), e);
 			return this.new AutoEnrollment(true, -1);
 		}
 		if (currentDate.isAfter(activeDate)) {
 			logger.info("AutoEnrollment active: documentCount={}, index={}, {}",
 					documentCount, index, documents);
 			return this.new AutoEnrollment(true, index);
 		}
 		logger.info("AutoEnrollment not active: documentCount={}, index={}, {}",
 				documentCount, index, documents);
 		return this.new AutoEnrollment(true, -1);
 	}
    
	protected AutoEnrollment determineDocumentIndexCloud(List<OptOutFDSCloudDocument> documentList, int documentCount, int index, OffsetDateTime currentDate) throws AssertionError, IOException {
 		logger.info("Entering determineDocumentIndex: documentCount={}, index={}", documentCount, index);
 		
 		String metadataStr = documentList.get(index).getMetadata();
 		// PDO have the assumption that a maximum of 2 documents will exist for a given MPIN/TIN/LetterType combination
 		// them being the AutoEnrollment and the pre-AutoEnrollment records.
 		// The niche scenario occurs where a preference only has an AutoEnrollment record with no pre-AutoEnrollment record for
 		// it will create a new pre-AutoEnrollment record to store client changes between now and AutoEnrollment date.
 		// Thus if we have > 2 records they will be ignore.
 		Metadata metadata;
 		try {
			metadata = mapper.readValue(metadataStr, Metadata.class);
		} catch (IOException e) {
			logger.error("Unable to parse metadata string");
			throw e;
		}
 		 		
 		String activeDateStr = metadata.getActiveDate();
 		
 		if (activeDateStr == null || activeDateStr.isEmpty()) {
 			logger.info("AutoEnrollment not found: documentCount={}, index={}, {}",
 					documentCount, index, metadataStr);
 			return this.new AutoEnrollment(false, index);
 		}

 		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"); 		
 		OffsetDateTime activeDate = null;
 		try {
 			activeDate = OffsetDateTime.parse(activeDateStr, df);
 		} catch(AssertionError e) {
 			logger.error("checkDocumentIndex: ZonedDateTime; {}: {}",activeDateStr, e.getMessage());
 			return this.new AutoEnrollment(true, -1);
 		}
 		if (currentDate.isAfter(activeDate)) {
 			logger.info("AutoEnrollment active: documentCount={}, index={}, {}",
 					documentCount, index, metadataStr);
 			return this.new AutoEnrollment(true, index);
 		}
 		logger.info("AutoEnrollment not active: documentCount={}, index={}, {}",
 				documentCount, index, metadataStr);
 		return this.new AutoEnrollment(true, -1);
 	}
	
	protected int determineMulti(AutoEnrollment autoEnrollment0, AutoEnrollment autoEnrollment1) {
 		if (autoEnrollment0.isValidAutoEnrollment()) {
 			return 0;
 		}
 		if (autoEnrollment1.isValidAutoEnrollment()) {
 			return 1;
 		}
 		if (! autoEnrollment0.isAutoEnrollment()) {
 			return 0;
 		}
 		if (! autoEnrollment1.isAutoEnrollment()) {
 			return 1;
 		}
 		return -1;
 	}
    
	protected String printDocument(Metadata metadata) {
		return "providerEmailId = " + metadata.getProviderEmailId() + ", mpin = " + metadata.getMpin() + ", fileName= " + metadata.getFileName();
	}
    
    public class AutoEnrollment {
    	
    	private boolean isAutoEnrollment;
    	private int index;
    	
    	public AutoEnrollment(Boolean isAutoEnrollment, int index) {
    		this.isAutoEnrollment = isAutoEnrollment;
    		this.index = index;
		}
    	
    	boolean isAutoEnrollment() { return isAutoEnrollment; }

 		public boolean isValidAutoEnrollment() {
 			return isAutoEnrollment && index != -1;
 		}

    }

}
