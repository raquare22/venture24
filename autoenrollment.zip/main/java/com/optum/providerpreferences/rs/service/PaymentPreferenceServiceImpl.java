package com.optum.providerpreferences.rs.service;

import com.optum.providerpreferences.rs.model.PaymentPreference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.List;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

@Service
public class PaymentPreferenceServiceImpl implements PaymentPreferenceService{

    static final Logger logger = LoggerFactory.getLogger(PaymentPreferenceServiceImpl.class);
    private static final String ID = "id";
    private static final String PAYMENT_PREFERENCE_COLLECTION = "paymentPreference";

    @Autowired
    MongoTemplate mongoTemplate;

    @Value("${MONGO_QUERY_MAX_MILLIS:90000}")
    String mongoQueryMaxMillis;

    public void setMongoQueryMaxMillis(String mongoQueryMaxMillis) {
        this.mongoQueryMaxMillis = mongoQueryMaxMillis;
    }

    @Override
    public PaymentPreference insertPaymentPreference(PaymentPreference doc) {
        logger.debug("Entering insertPaymentPreference");
        MongoOperations op = mongoTemplate;
        PaymentPreference insertedDoc = null;
        String id = doc.getId();
        if (id == null || id.isEmpty()) {
            // document doesn't exist, insert
            insertedDoc = op.insert(doc, PAYMENT_PREFERENCE_COLLECTION);
            return insertedDoc;
        } else {
            // check document already exists in collection
            PaymentPreference document = mongoTemplate.findOne(query(where("id").is(id)), PaymentPreference.class, PAYMENT_PREFERENCE_COLLECTION);
            if (document != null) {
                mongoTemplate.save(doc, PAYMENT_PREFERENCE_COLLECTION);
                return doc;
            } else {
                insertedDoc = op.insert(doc, PAYMENT_PREFERENCE_COLLECTION);
                return insertedDoc;
            }
        }
    }

    @Override
    public PaymentPreference getPaymentPreference(String id) {
        logger.debug("Entering getPaymentPreference");
        PaymentPreference retVal = mongoTemplate.findOne(query(where(ID).is(id)), PaymentPreference.class, PAYMENT_PREFERENCE_COLLECTION);
        logger.debug("Leaving getPaymentPreference");
        return retVal;
    }

    @Override
    public void deletePaymentPreference(String id) {
        logger.debug("Entering deletePaymentPreference with id: {}", id);
        mongoTemplate.remove(query(where("id").is(id)), PaymentPreference.class, PAYMENT_PREFERENCE_COLLECTION);
        logger.debug("Exiting deletePaymentPreference with id: {}", id);
    }

    @Override
    public List<PaymentPreference> getPaymentPreferenceList(List<String> ids) {
        logger.debug("Entering getPaymentPreferenceList");
        List<PaymentPreference> retVal = mongoTemplate.find(query(where(ID).in(ids)), PaymentPreference.class, PAYMENT_PREFERENCE_COLLECTION);
        logger.debug("Leaving getPaymentPreferenceList");
        return retVal;
    }

    @Override
    public List<PaymentPreference> insertMultiPaymentPreferences(List<PaymentPreference> paymentPreferenceList) {
        logger.debug("Entering insertMultiPaymentPreferences");
        List<PaymentPreference> insertedDocs = (List<PaymentPreference>) mongoTemplate.insert(paymentPreferenceList, PAYMENT_PREFERENCE_COLLECTION);
        logger.debug("Exiting insertMultiPaymentPreferences");
        return insertedDocs;
    }

    @Override
    public PaymentPreference getPaymentPreferenceByTinAndMpin(String tin, String mpin) {
        logger.debug("Entering getPaymentPreferenceByTinAndMpin");
        PaymentPreference retVal = mongoTemplate.findOne(query(where("tin").is(tin).and("mpin").is(mpin)), PaymentPreference.class, PAYMENT_PREFERENCE_COLLECTION);
        logger.debug("Leaving getPaymentPreferenceByTinAndMpin");
        return retVal;
    }

    @Override
    public PaymentPreference updatePaymentPreference(String tin, String mpin, String paymentPref, String updatedBy) {
        logger.debug("Entering updatePaymentPreference");
        PaymentPreference doc = mongoTemplate.findOne(query(where("tin").is(tin).and("mpin").is(mpin)), PaymentPreference.class, PAYMENT_PREFERENCE_COLLECTION);
        if (doc != null) {
            doc.setPaymentpref(paymentPref);
            doc.setUpdatedBy(updatedBy);
            doc.setDateModified(new java.util.Date());
            mongoTemplate.save(doc, PAYMENT_PREFERENCE_COLLECTION);
            logger.debug("Exiting updatePaymentPreference");
        } else {
            logger.warn("No document found with tin: {} and mpin: {}", Encode.forJava(tin), Encode.forJava(mpin));
        }
        return doc;
    }
}