/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.exception;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This class is used to map error responses when an exception is thrown.
 * 
 * @author Provider Paperless Letters
 */
@Provider
public class GeneralExceptionMapper implements ExceptionMapper<Throwable>
{

    private static final Logger logger = LogManager.getLogger(GeneralExceptionMapper.class);

    public Response toResponse(Throwable e)
    {

        String message = e.getMessage();

        logger.error(message);

        if (e instanceof ApplicationException)
        {
            ErrorResponse errorResponse = new ErrorResponse("400", message);

            return Response.status(Response.Status.BAD_REQUEST).type(MediaType.APPLICATION_JSON).entity(errorResponse).build();
        }

        else
        {
            ErrorResponse errorResponse = new ErrorResponse("500", "Provider Preferences Internal Process Issue");

            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).type(MediaType.APPLICATION_JSON).entity(errorResponse).build();
        }
    }
}