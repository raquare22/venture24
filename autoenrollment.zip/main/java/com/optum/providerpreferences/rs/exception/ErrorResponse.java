/**
 *  Copyright Optum Services Inc., 2017. All rights reserved.
 *  This software and documentation contain confidential and proprietary information owned by Optum Services Inc.,
 *  Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.exception;

/**
 * This class models the error response JSON to be returned.
 * 
 * @author Provider Paperless Letters
 *
 */
public class ErrorResponse {

	private String errorCode;
	private String errorMessage;

	public ErrorResponse(String errorCode, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
}
