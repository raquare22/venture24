package com.optum.providerpreferences.rs.model.ndb.preferences;

import java.util.List;

public class ResponseData
{
    private String providerId;

    private String providerTIN;

    private String providerTINType;

    private List<MailPref> ltrTypMailPrfList;

    public ResponseData()
    {
    }

    public ResponseData(String providerId, String providerTIN, String providerTINType, List<MailPref> ltrTypMailPrfList)
    {
        super();
        this.providerId = providerId;
        this.providerTIN = providerTIN;
        this.providerTINType = providerTINType;
        this.ltrTypMailPrfList = ltrTypMailPrfList;
    }

    public String getProviderId()
    {
        return providerId;
    }

    public void setProviderId(String providerId)
    {
        this.providerId = providerId;
    }

    public String getProviderTIN()
    {
        return providerTIN;
    }

    public void setProviderTIN(String providerTIN)
    {
        this.providerTIN = providerTIN;
    }

    public String getProviderTINType()
    {
        return providerTINType;
    }

    public void setProviderTINType(String providerTINType)
    {
        this.providerTINType = providerTINType;
    }

    public List<MailPref> getLtrTypMailPrfList()
    {
        return ltrTypMailPrfList;
    }

    public void setLtrTypMailPrfList(List<MailPref> ltrTypMailPrfList)
    {
        this.ltrTypMailPrfList = ltrTypMailPrfList;
    }

}
