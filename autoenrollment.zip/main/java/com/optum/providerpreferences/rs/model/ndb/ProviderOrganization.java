/**
 *  Copyright Optum Services Inc., 2017. All rights reserved.
 *  This software and documentation contain confidential and proprietary information owned by Optum Services Inc.,
 *  Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model.ndb;

public class ProviderOrganization {

	private String uhcId;
	private String respOrgName;

	public String getUhcId() {
		return uhcId;
	}

	public void setUhcId(String uhcId) {
		this.uhcId = uhcId;
	}

	public String getRespOrgName() {
		return respOrgName;
	}

	public void setRespOrgName(String respOrgName) {
		this.respOrgName = respOrgName;
	}

	@Override
	public String toString() {
		return "ProviderOrganization [uhcId=" + uhcId + ", respOrgName=" + respOrgName + "]";
	}

}
