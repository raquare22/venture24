package com.optum.providerpreferences.rs.model.linksecurity;

public class PSMRequest {

	private String optumUuid;
	private String source;
	private boolean verifySource;

	public String getOptumUuid() {
		return optumUuid;
	}
	
	public void setOptumUuid(String optumUuid) {
		this.optumUuid = optumUuid;
	}
	
	public String getSource() {
		return source;
	}
	
	public void setSource(String source) {
		this.source = source;
	}

	public boolean isVerifySource() {
		return verifySource;
	}

	public void setVerifySource(boolean verifySource) {
		this.verifySource = verifySource;
	}

}
