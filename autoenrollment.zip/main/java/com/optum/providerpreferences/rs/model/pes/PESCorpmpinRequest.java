package com.optum.providerpreferences.rs.model.pes;

public class PESCorpmpinRequest {

    private String taxIdNumber;
    private String appName;
    private String attributeSet;
    private String count;


    public PESCorpmpinRequest(String tin) {
        this.appName = "PDO";
        this.attributeSet = "summary_0002";
        this.count = "1";
        this.taxIdNumber = tin;
    }

    public String getTaxIdNumber() { return taxIdNumber; }
    public void setTaxIdNumber(String taxIdNumber) {
        this.taxIdNumber = taxIdNumber;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) { this.appName = appName;}

    public String getAttributeSet() {
        return attributeSet;
    }

    public void setAttributeSet(String attributeSet) {
        this.attributeSet = attributeSet;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
    @Override
    public String toString() {
        return "PESCorpmpinRequest = [ taxIdNumber: " + this.taxIdNumber + ", appName: " + this.appName +
                ", attributeSet: " + this.attributeSet + ", count: " + this.count + " ]";
    }
}