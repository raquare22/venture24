/**
 *  Copyright Optum Services Inc., 2017. All rights reserved.
 *  This software and documentation contain confidential and proprietary information owned by Optum Services Inc.,
 *  Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model.logging;

import java.net.InetAddress;
import java.net.UnknownHostException;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class LogMessage {
	
	@JsonProperty("LOGTYPE")
	private static final String logType = "SECURITY_AUDIT";
	@JsonProperty("SRC_IP")
	private String srcIp;
	@JsonProperty("ACTOR_IP")
	private String actorIp;
	@JsonProperty("ACTOR")
	private String actor;
	@JsonProperty("DETAIL")
	private String detail;
	@JsonProperty("USERNAME")
	private String username; 

	public String getLogtype() {
		return logType;
	}
	
	public String getSrcIp() {
		InetAddress ip = null;
		try {
			ip = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			return srcIp;
		}
		return ip.getHostAddress();
	}
	
	public String getActorIp() {
		return actorIp;
	}
	
	public void setActorIp(String actorIp) {
		this.actorIp = actorIp;
	}
	
	public String getActor() {
		return actor;
	}
	
	public void setActor(String actor) {
		this.actor = actor;
	}
	
	public String getDetail() {
		return detail;
	}
	
	public void setDetail(String detail) {
		this.detail = detail;
	} 
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}
