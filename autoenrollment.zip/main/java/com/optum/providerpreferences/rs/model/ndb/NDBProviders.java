/**
 *  Copyright Optum Services Inc., 2017. All rights reserved.
 *  This software and documentation contain confidential and proprietary information owned by Optum Services Inc.,
 *  Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model.ndb;

import java.util.ArrayList;
import java.util.List;

public class NDBProviders {

	private List<NDBProvider> providerList;
	private String statusCode;
	private String statusMessage;

	public List<NDBProvider> getProviderList() {
		if (providerList == null) {

			providerList = new ArrayList<>();
		}
		return providerList;
	}

	public void setProviderList(List<NDBProvider> providerList) {
		this.providerList = providerList;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

}
