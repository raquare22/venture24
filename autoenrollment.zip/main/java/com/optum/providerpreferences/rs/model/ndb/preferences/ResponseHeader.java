package com.optum.providerpreferences.rs.model.ndb.preferences;

public class ResponseHeader
{
    private String returncode;

    private String message;

    public ResponseHeader()
    {
    }

    public ResponseHeader(String returncode, String message)
    {
        super();
        this.returncode = returncode;
        this.message = message;
    }

    public String getReturncode()
    {
        return returncode;
    }

    public void setReturncode(String returncode)
    {
        this.returncode = returncode;
    }

    public String getMessage()
    {
        return message;
    }

    public void setMessage(String message)
    {
        this.message = message;
    }
}
