package com.optum.providerpreferences.rs.model.optout;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;

public class OptOutFDSCloudPOSTResponse {

	private String documentId;
	private String spaceId;
	private String metadata;
	
	private List<String> searchTerms;
	private Long createdOn;
	private Long modifiedOn; 
	
	private String createdBy;
	private String modifiedBy; 
	private List<Object> attachments;
	
	
	public String getDocumentId() {
		if(documentId == null) {
			documentId = "";
		}
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getSpaceId() {
		return spaceId;
	}
	public void setSpaceId(String spaceId) {
		this.spaceId = spaceId;
	}
	public String getMetadata() {
		return metadata;
	}
	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}
	public List<String> getSearchTerms() {
        if (searchTerms == null)
        {
        	searchTerms = new ArrayList<>();
        }
        return searchTerms;
	}
	public void setSearchTerms(List<String> searchTerms) {
		this.searchTerms = searchTerms;
	}
	public Long getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Long createdOn) {
		this.createdOn = createdOn;
	}
	public Long getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Long modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public List<Object> getAttachments() {
        if (attachments == null)
        {
        	attachments = new ArrayList<>();
        }
		return attachments;
	}
	public void setAttachments(List<Object> attachments) {
		this.attachments = attachments;
	}
	@Override
	public String toString() {
		String jsonString = new JSONObject()
				.put("documentId", documentId)
				.put("spaceId", spaceId)
				.put("metadata", metadata)
				
				.put("searchTerms", searchTerms.toString())
				.put("createdOn", createdOn)
				.put("modifiedOn", modifiedOn)
				
				.put("createdBy", createdBy)
				.put("modifiedBy", modifiedBy)
				.put("attachments", attachments.toString())
				.toString();
		
		return jsonString;
	}

	
	
	
	
	
}
