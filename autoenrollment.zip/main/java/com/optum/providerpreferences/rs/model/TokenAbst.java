/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public abstract class TokenAbst
{
	@JsonProperty("access_token")
    String accessToken;

    public String getAccessToken()
    {
        return accessToken;
    }

    public void setAccessToken(String accessToken)
    {
        this.accessToken = accessToken;
    }

}
