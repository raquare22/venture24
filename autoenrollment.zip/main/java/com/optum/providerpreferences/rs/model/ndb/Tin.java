/**
 *  Copyright Optum Services Inc., 2017. All rights reserved.
 *  This software and documentation contain confidential and proprietary information owned by Optum Services Inc.,
 *  Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model.ndb;

public class Tin {

	private String tin;
	private String tinType;
	private String providerType;
	private String corpTINFlag;

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getTinType() {
		return tinType;
	}

	public void setTinType(String tinType) {
		this.tinType = tinType;
	}

	public String getProviderType() {
		return providerType;
	}

	public void setProviderType(String providerType) {
		this.providerType = providerType;
	}

	public String getCorpTINFlag() {
		return corpTINFlag;
	}

	public void setCorpTINFlag(String corpTINFlag) {
		this.corpTINFlag = corpTINFlag;
	}

}
