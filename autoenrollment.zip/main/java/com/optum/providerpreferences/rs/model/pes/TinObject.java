package com.optum.providerpreferences.rs.model.pes;

public class TinObject {
	
	private Key key;

	public Key getKey() {
		return key;
	}

	public void setKey(Key key) {
		this.key = key;
	}
	
	@Override
	public String toString() {
		return "{ key: {" + key.toString() + "} }";
	}
}
