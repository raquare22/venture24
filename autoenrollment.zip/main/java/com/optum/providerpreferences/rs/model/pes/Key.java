package com.optum.providerpreferences.rs.model.pes;

public class Key {
	
	private String taxIdNumber;
	private String taxIdTypeCode;
	
	public String getTaxIdNumber() {
		return taxIdNumber;
	}
	public void setTaxIdNumber(String taxIdNumber) {
		this.taxIdNumber = taxIdNumber;
	}
	public String getTaxIdTypeCode() {
		return taxIdTypeCode;
	}
	public void setTaxIdTypeCode(String taxIdTypeCode) {
		this.taxIdTypeCode = taxIdTypeCode;
	}
	
	@Override
	public String toString() {
		return "taxIdNumber: " + this.taxIdNumber + ", taxIdTypeCode: " + this.taxIdTypeCode;
	}
	
	

}
