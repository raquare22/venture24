/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class PasswordOwnerInfo
{

    private String tin;

    private String uhcID;

    private String mpin;

    private String providerName;

    private String corporateName;

    private String organizationName;

    public PasswordOwnerInfo()
    {
    	//empty constructor
    }

    public String getTin()
    {
        return tin;
    }

    public void setTin(String tin)
    {
        this.tin = tin;
    }

    public String getUhcID()
    {
        return uhcID;
    }

    public void setUhcID(String uhcID)
    {
        this.uhcID = uhcID;
    }

    public String getMpin()
    {
        return mpin;
    }

    public void setMpin(String mpin)
    {
        this.mpin = mpin;
    }

    public String getProviderName()
    {
        return providerName;
    }

    public void setProviderName(String providerName)
    {
        this.providerName = providerName;
    }

    public String getCorporateName()
    {
        return corporateName;
    }

    public void setCorporateName(String corporateName)
    {
        this.corporateName = corporateName;
    }

    public String getOrganizationName()
    {
        return organizationName;
    }

    public void setOrganizationName(String organizationName)
    {
        this.organizationName = organizationName;
    }

}
