package com.optum.providerpreferences.rs.model.optout;

import java.util.ArrayList;
import java.util.List;

public class OptOutAuditMetadata {
	
	private String recordType; 
	private OptOutRequest optOutRequest;
	private OptOutAuditUpdate optOutUpdate;
	private List<String> documentIds;
	private List<String> updated;
	private List<String> failedDocumentIds;
	
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	public OptOutRequest getOptOutRequest() {
        if (optOutRequest == null)
        {
        	optOutRequest = new OptOutRequest();
        }
		return optOutRequest;
	}
	public void setOptOutRequest(OptOutRequest optOutRequest) {
		this.optOutRequest = optOutRequest;
	}
	public OptOutAuditUpdate getOptOutUpdate() {
        if (optOutUpdate == null)
        {
        	optOutUpdate = new OptOutAuditUpdate();
        }
		return optOutUpdate;
	}
	public void setOptOutUpdate(OptOutAuditUpdate optOutUpdate) {
		this.optOutUpdate = optOutUpdate;
	}
	public List<String> getDocumentIds() {
        if (documentIds == null)
        {
        	documentIds = new ArrayList<>();
        }
        return documentIds;
	}
	public void setDocumentIds(List<String> documentIds) {
		this.documentIds = documentIds;
	}
	public List<String> getUpdated() {
        if (updated == null)
        {
        	updated = new ArrayList<>();
        }
        return updated;
	}
	public void setUpdated(List<String> updated) {
		this.updated = updated;
	}
	public List<String> getFailedDocumentIds() {
        if (failedDocumentIds == null)
        {
        	failedDocumentIds = new ArrayList<>();
        }
		return failedDocumentIds;
	}
	public void setFailedDocumentIds(List<String> failedDocumentIds) {
		this.failedDocumentIds = failedDocumentIds;
	}
	@Override
	public String toString() {
		return "OptOutFDSCloudPOSTMetadata [recordType=" + recordType + ", optOutRequest=" + optOutRequest
				+ ", optOutUpdate=" + optOutUpdate + ", documentIds=" + documentIds + ", updated=" + updated
				+ ", failedDocumentIds=" + failedDocumentIds + "]";
	}
	
	

}
