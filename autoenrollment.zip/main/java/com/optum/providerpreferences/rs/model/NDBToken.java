/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class NDBToken extends TokenAbst
{
	@JsonProperty("access_token")
    private String accessToken;

	@JsonProperty("token_type")
    private String tokenType;

	@JsonProperty("expires_in")
    private String expiresIn;

    private String scope;

    @Override
    public String getAccessToken()
    {
        return accessToken;
    }

    @Override
    public void setAccessToken(String accessToken)
    {
        this.accessToken = accessToken;
    }

    public String getTokenType()
    {
        return tokenType;
    }

    public void setTokenType(String tokenType)
    {
        this.tokenType = tokenType;
    }

    public String getExpiresIn()
    {
        return expiresIn;
    }

    public void setExpiresIn(String expiresIn)
    {
        this.expiresIn = expiresIn;
    }

    public String getScope()
    {
        return scope;
    }

    public void setScope(String scope)
    {
        this.scope = scope;
    }

    @Override
    public String toString()
    {
        return "Token [access_token=" + accessToken + ", token_type=" + tokenType + ", expires_in=" + expiresIn + ", scope=" + scope + "]";
    }

}
