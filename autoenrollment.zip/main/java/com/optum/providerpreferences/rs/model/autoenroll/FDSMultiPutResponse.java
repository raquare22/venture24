package com.optum.providerpreferences.rs.model.autoenroll;

import java.util.List;

public class FDSMultiPutResponse {
	
	private List<String> updated;
	
	private List<String> notfound;

	public List<String> getUpdated() {
		return updated;
	}

	public void setUpdated(List<String> updated) {
		this.updated = updated;
	}

	public List<String> getNotfound() {
		return notfound;
	}

	public void setNotfound(List<String> notfound) {
		this.notfound = notfound;
	}

	@Override
	public String toString() {
		return "updated: " + updated + " ; notfound: " + notfound;
	}

}
