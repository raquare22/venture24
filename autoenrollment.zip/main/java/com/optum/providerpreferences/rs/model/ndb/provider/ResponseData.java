package com.optum.providerpreferences.rs.model.ndb.provider;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ResponseData
{
    private List<MpinData> mpinList;

    public List<MpinData> getMpinList()
    {
        return mpinList;
    }

    public void setMpinList(List<MpinData> mpinList)
    {
        this.mpinList = mpinList;
    }

}
