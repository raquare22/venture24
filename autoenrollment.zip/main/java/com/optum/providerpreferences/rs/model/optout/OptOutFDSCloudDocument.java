package com.optum.providerpreferences.rs.model.optout;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class OptOutFDSCloudDocument {
	
	private String documentId;
	private Object searchTerms;
	private String spaceId;
	private Long modifiedOn;
	private String modifiedBy;
	
	private String createdBy;
	private Long createdOn;
	private String metadata;	

	private Long expiryDate;
	private String externalId; 
	private List<Object> attachments;
	private String workflow; 
	private String accessToken;
	
	private String status; 
	private String transactionId;
	private String onPremSpaceId; 
	private String onPremRecordType;
	
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public Object getSearchTerms() {
		return searchTerms;
	}
	public void setSearchTerms(Object searchTerms) {
		this.searchTerms = searchTerms;
	}
	public String getSpaceId() {
		return spaceId;
	}
	public void setSpaceId(String spaceId) {
		this.spaceId = spaceId;
	}
	public Long getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Long modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Long getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Long createdOn) {
		this.createdOn = createdOn;
	}
	public String getMetadata() {
		return metadata;
	}
	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}
//	public Metadata getMetadataObj() {
//		return metadataM;
//	}
//	public void setMetadataObj(String metadata) {
//		this.metadata = metadata;
//	}
	public Long getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Long expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getExternalId() {
		return externalId;
	}
	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}
	public List<Object> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<Object> attachments) {
		this.attachments = attachments;
	}
	public String getWorkflow() {
		return workflow;
	}
	public void setWorkflow(String workflow) {
		this.workflow = workflow;
	}
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public String getOnPremSpaceId() {
		return onPremSpaceId;
	}
	public void setOnPremSpaceId(String onPremSpaceId) {
		this.onPremSpaceId = onPremSpaceId;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getOnPremRecordType() {
		return onPremRecordType;
	}
	public void setOnPremRecordType(String onPremRecordType) {
		this.onPremRecordType = onPremRecordType;
	}
	
	@Override
	public String toString() {
		return "OptOutFDSCloudDocument [documentId=" + documentId + ", searchTerms=" + searchTerms + ", spaceId="
				+ spaceId + ", modifiedOn=" + modifiedOn + ", modifiedBy=" + modifiedBy + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", metadata=" + metadata + ", expiryDate=" + expiryDate + ", externalId="
				+ externalId + ", attachments=" + attachments + ", workflow=" + workflow + ", accessToken="
				+ accessToken + "]";
	}
	
	

	
	
	
	 
	
}