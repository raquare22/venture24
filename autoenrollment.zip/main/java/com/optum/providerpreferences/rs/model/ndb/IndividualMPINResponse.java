package com.optum.providerpreferences.rs.model.ndb;

import com.optum.providerpreferences.rs.model.GenericResponse;

public class IndividualMPINResponse extends GenericResponse
{
    public IndividualMPINResponse(String code, String message)
    {
        super(code, message);
    }
}
