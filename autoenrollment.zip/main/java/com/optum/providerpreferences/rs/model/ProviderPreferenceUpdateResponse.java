/**
 *  Copyright Optum Services Inc., 2017. All rights reserved.
 *  This software and documentation contain confidential and proprietary information owned by Optum Services Inc.,
 *  Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ProviderPreferenceUpdateResponse extends GenericResponse {

}
