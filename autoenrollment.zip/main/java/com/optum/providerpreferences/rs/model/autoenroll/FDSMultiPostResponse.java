package com.optum.providerpreferences.rs.model.autoenroll;

import java.util.List;

public class FDSMultiPostResponse {
	
	private List<String> inserted;

	public List<String> getInserted() {
		return inserted;
	}

	public void setInserted(List<String> inserted) {
		this.inserted = inserted;
	}

	@Override
	public String toString() {
		return "inserted: " + inserted;
	}

}
