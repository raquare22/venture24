/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model.fds;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class Metadata
{

    private String tin;

    private String mpin;

    private String providerName;

    /* TODO Change to classifier */
    private String fileName;

    /* TODO Change to description */
    private String fileType;

    private String providerEmailId;

    private String frequency;

    private String deliveryMethod;

    private String okToChangePDOInd;

    private String autoEdelUpdateInd;
    
    private String activeDate;
    
    private String lastUpdatedBy; 
    
    private String lastUpdatedById;
    
    private String autoOptOutInd;
    
    private Integer optedOutDuration;
    
    private String optedOutDateTime;
    
    private String expiryDate;

    private Long expiryDateEpoch;

    private String subscribeToEmail;


    public String getSubscribeToEmail() {
        return subscribeToEmail;
    }

    public void setSubscribeToEmail(String subscribeToEmail) {
        this.subscribeToEmail = subscribeToEmail;
    }


    public String getLastUpdatedById() {
		return lastUpdatedById;
	}

	public void setLastUpdatedById(String lastUpdatedById) {
		this.lastUpdatedById = lastUpdatedById;
	}

	public String getTin()
    {
        return tin;
    }

    public void setTin(String tin)
    {
        this.tin = tin;
    }

    public String getProviderName()
    {
        return providerName;
    }

    public void setProviderName(String providerName)
    {
        this.providerName = providerName;
    }

    public String getFileName()
    {
        return fileName;
    }

    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }

    public String getFileType()
    {
        return fileType;
    }

    public void setFileType(String fileType)
    {
        this.fileType = fileType;
    }

    public String getProviderEmailId()
    {
        return providerEmailId;
    }

    public void setProviderEmailId(String providerEmailId)
    {
        this.providerEmailId = providerEmailId;
    }

    public String getFrequency()
    {
        return frequency;
    }

    public void setFrequency(String frequency)
    {
        this.frequency = frequency;
    }

    public String getDeliveryMethod()
    {
        return deliveryMethod;
    }

    public void setDeliveryMethod(String deliveryMethod)
    {
        this.deliveryMethod = deliveryMethod;
    }

    public String getMpin()
    {
        return mpin;
    }

    public void setMpin(String mpin)
    {
        this.mpin = mpin;
    }

    public String getOkToChangePDOInd()
    {
        return okToChangePDOInd;
    }

    public void setOkToChangePDOInd(String okToChangePDOInd)
    {
        this.okToChangePDOInd = okToChangePDOInd;
    }

    public String getAutoEdelUpdateInd()
    {
        return autoEdelUpdateInd;
    }

    public void setAutoEdelUpdateInd(String autoEdelUpdateInd)
    {
        this.autoEdelUpdateInd = autoEdelUpdateInd;
    }
    

    public String getActiveDate() {
		return activeDate;
	}

	public void setActiveDate(String activeDate) {
		this.activeDate = activeDate;
	}
	
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getAutoOptOutInd() {
		return autoOptOutInd;
	}

	public void setAutoOptOutInd(String autoOptOutInd) {
		this.autoOptOutInd = autoOptOutInd;
	}

	public Integer getOptedOutDuration() {
		return optedOutDuration;
	}

	public void setOptedOutDuration(Integer optedOutDuration) {
		this.optedOutDuration = optedOutDuration;
	}
	
	public String getOptedOutDateTime() {
		return optedOutDateTime;
	}

	public void setOptedOutDateTime(String optedOutDateTime) {
		this.optedOutDateTime = optedOutDateTime;
	}	

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Long getExpiryDateEpoch() {
		return expiryDateEpoch;
	}

	public void setExpiryDateEpoch(Long expiryDateEpoch) {
		this.expiryDateEpoch = expiryDateEpoch;
	}

	@Override
	public String toString() {
		return "Metadata [tin=" + tin + ", mpin=" + mpin + ", providerName=" + providerName + ", fileName=" + fileName
				+ ", fileType=" + fileType + ", providerEmailId=" + providerEmailId + ", frequency=" + frequency
				+ ", deliveryMethod=" + deliveryMethod + ", okToChangePDOInd=" + okToChangePDOInd
				+ ", autoEdelUpdateInd=" + autoEdelUpdateInd + ", activeDate=" + activeDate + ", lastUpdatedBy="
				+ lastUpdatedBy + ", autoOptOutInd=" + autoOptOutInd + ", optedOutDuration=" + optedOutDuration
				+ ", optedOutDateTime=" + optedOutDateTime + ", expiryDate=" + expiryDate + "]";
	}




}
