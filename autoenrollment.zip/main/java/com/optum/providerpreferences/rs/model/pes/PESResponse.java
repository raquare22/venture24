package com.optum.providerpreferences.rs.model.pes;

import java.util.List;

public class PESResponse {
	private Meta meta;
	
	private List<TinObject> data;
	
	public Meta getMeta() {
		return meta;
	}
	public void setMeta(Meta meta) {
		this.meta = meta;
	}
	public List<TinObject> getData() {
		return data;
	}
	public void setData(List<TinObject> data) {
		this.data = data;
	}
	
	@Override
	public String toString() {
		return "PESResponse: [ meta: { " + this.meta.toString() + " }, data: " + this.data.toString() + " ]";
	}
	

}
