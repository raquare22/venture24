/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model.ndb;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Corporate
{

    private String name;
    
	@JsonProperty("all_tins")
    private String allTins;

    private String mpin;

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getAllTins()
    {
        return allTins;
    }

    public void setAllTins(String allTins)
    {
        this.allTins = allTins;
    }

    public String getMpin()
    {
        return mpin;
    }

    public void setMpin(String mpin)
    {
        this.mpin = mpin;
    }

    @Override
    public String toString()
    {
        return "Corporate [name=" + name + ", mpin=" + mpin + "]";
    }

}
