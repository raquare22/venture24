package com.optum.providerpreferences.rs.model.ndb;

public class IndividualMPINRequest
{

}
