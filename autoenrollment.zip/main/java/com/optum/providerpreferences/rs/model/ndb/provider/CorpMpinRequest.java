package com.optum.providerpreferences.rs.model.ndb.provider;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CorpMpinRequest
{
    private RequestHeader requestHeader;

    private RequestData requestData;

    public RequestHeader getRequestHeader()
    {
        return requestHeader;
    }

    public void setRequestHeader(RequestHeader requestHeader)
    {
        this.requestHeader = requestHeader;
    }

    public RequestData getRequestData()
    {
        return requestData;
    }

    public void setRequestData(RequestData requestData)
    {
        this.requestData = requestData;
    }

}
