package com.optum.providerpreferences.rs.model.linksecurity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class User
{

    // This is actually uhcID in getCorporates
    private String userAcctSeqNbr;

    private String b2cUserId;

    private String accessProfile;

    private String statusCode;

    private String statusDesc;

    private String accountType;

    private String accountDesc;

    private String dept;

    private String orgType;

    private String title;

    private String state;

    private String zipCode;

    private String roleId;

    private String roleDesc;

    private String respOrgMpin;

    private boolean hasAccessProfiles;

    public User()
    {
        super();
    }

    public User(String userAcctSeqNbr, String b2cUserId, String accessProfile, String statusCode, String statusDesc, String accountType, String accountDesc,
            String dept, String orgType, String title, String state, String zipCode, String roleId, String roleDesc, String respOrgMpin,
            String hasAccessProfiles)
    {
        super();
        this.userAcctSeqNbr = userAcctSeqNbr;
        this.b2cUserId = b2cUserId;
        this.accessProfile = accessProfile;
        this.statusCode = statusCode;
        this.statusDesc = statusDesc;
        this.accountType = accountType;
        this.accountDesc = accountDesc;
        this.dept = dept;
        this.orgType = orgType;
        this.title = title;
        this.state = state;
        this.zipCode = zipCode;
        this.roleId = roleId;
        this.roleDesc = roleDesc;
        this.respOrgMpin = respOrgMpin;
        if ("true".equalsIgnoreCase(hasAccessProfiles))
        {
            this.hasAccessProfiles = true;
        }
        else
        {
            this.hasAccessProfiles = false;
        }
    }

    public String getUserAcctSeqNbr()
    {
        return userAcctSeqNbr;
    }

    public void setUserAcctSeqNbr(String userAcctSeqNbr)
    {
        this.userAcctSeqNbr = userAcctSeqNbr;
    }

    public String getB2cUserId()
    {
        return b2cUserId;
    }

    public void setB2cUserId(String b2cUserId)
    {
        this.b2cUserId = b2cUserId;
    }

    public String getAccessProfile()
    {
        return accessProfile;
    }

    public void setAccessProfile(String accessProfile)
    {
        this.accessProfile = accessProfile;
    }

    public String getStatusCode()
    {
        return statusCode;
    }

    public void setStatusCode(String statusCode)
    {
        this.statusCode = statusCode;
    }

    public String getStatusDesc()
    {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc)
    {
        this.statusDesc = statusDesc;
    }

    public String getAccountType()
    {
        return accountType;
    }

    public void setAccountType(String accountType)
    {
        this.accountType = accountType;
    }

    public String getAccountDesc()
    {
        return accountDesc;
    }

    public void setAccountDesc(String accountDesc)
    {
        this.accountDesc = accountDesc;
    }

    public String getDept()
    {
        return dept;
    }

    public void setDept(String dept)
    {
        this.dept = dept;
    }

    public String getOrgType()
    {
        return orgType;
    }

    public void setOrgType(String orgType)
    {
        this.orgType = orgType;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getState()
    {
        return state;
    }

    public void setState(String state)
    {
        this.state = state;
    }

    public String getZipCode()
    {
        return zipCode;
    }

    public void setZipCode(String zipCode)
    {
        this.zipCode = zipCode;
    }

    public String getRoleId()
    {
        return roleId;
    }

    public void setRoleId(String roleId)
    {
        this.roleId = roleId;
    }

    public String getRoleDesc()
    {
        return roleDesc;
    }

    public void setRoleDesc(String roleDesc)
    {
        this.roleDesc = roleDesc;
    }

    public String getRespOrgMpin()
    {
        return respOrgMpin;
    }

    public void setRespOrgMpin(String respOrgMpin)
    {
        this.respOrgMpin = respOrgMpin;
    }

    public boolean isHasAccessProfiles()
    {
        return hasAccessProfiles;
    }

    public void setHasAccessProfiles(boolean hasAccessProfiles)
    {
        this.hasAccessProfiles = hasAccessProfiles;
    }

    public void setHasAccessProfiles(String hasAccessProfiles)
    {
        if ("true".equalsIgnoreCase(hasAccessProfiles))
        {
            this.hasAccessProfiles = true;
        }
        else
        {
            this.hasAccessProfiles = false;
        }
    }

}
