package com.optum.providerpreferences.rs.model.fds;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;

@JsonInclude(Include.NON_NULL)
public class FDSCloudGETResponse {

	private String total_records;		
	private String count;
	private String start; 
	private List<OptOutFDSCloudDocument> documents;
	private String zonedDateTime;
	private String message;
	private String details; 
	
	public String getTotal_records() {
		return total_records;
	}
	public void setTotal_records(String total_records) {
		this.total_records = total_records;
	}
	public String getCount() {		
		return count;		
	}		
	public void setCount(String count) {		
		this.count = count;		
	}
	
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public List<OptOutFDSCloudDocument> getDocuments() {		
       if (documents == null)		
       {		
           documents = new ArrayList<>();		
       }		
       return documents;		
	}		
	public void setDocuments(List<OptOutFDSCloudDocument> documents) {		
		this.documents = documents;		
	}
	public String getZonedDateTime() {
		return zonedDateTime;
	}
	public void setZonedDateTime(String zonedDateTime) {
		this.zonedDateTime = zonedDateTime;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	@Override
	public String toString() {
		return "FDSCloudGETResponse [total_records=" + total_records + ", count=" + count + ", start=" + start
				+ ", documents=" + documents + ", zonedDateTime=" + zonedDateTime + ", message=" + message
				+ ", details=" + details + "]";
	}
	
	
}

