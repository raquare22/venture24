/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Token extends TokenAbst
{
	@JsonProperty("access_token")
    private String accessToken;
	
	@JsonProperty("refresh_token")
    private String refreshToken;

	@JsonProperty("token_type")
    private String tokenType;
	
	@JsonProperty("expires_in")
    private String expiresIn;

	@JsonProperty("created_at")
    private String createdAt;

    @Override
    public String getAccessToken()
    {
        return accessToken;
    }

    @Override
    public void setAccessToken(String accessToken)
    {
        this.accessToken = accessToken;
    }

    public String getRefreshToken()
    {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken)
    {
        this.refreshToken = refreshToken;
    }

    public String getTokenType()
    {
        return tokenType;
    }

    public void setTokenType(String tokenType)
    {
        this.tokenType = tokenType;
    }

    public String getExpiresIn()
    {
        return expiresIn;
    }

    public void setExpiresIn(String expiresIn)
    {
        this.expiresIn = expiresIn;
    }

    public String getCreatedAt()
    {
        return createdAt;
    }

    public void setCreatedAt(String createdAt)
    {
        this.createdAt = createdAt;
    }

    @Override
    public String toString()
    {
        return "Token [access_token=" + accessToken + ", refresh_token=" + refreshToken + ", token_type=" + tokenType + ", expires_in=" + expiresIn
                + ", created_at=" + createdAt + "]";
    }

}
