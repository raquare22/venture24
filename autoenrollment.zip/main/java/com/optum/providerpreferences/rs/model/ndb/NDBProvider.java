/**
 *  Copyright Optum Services Inc., 2017. All rights reserved.
 *  This software and documentation contain confidential and proprietary information owned by Optum Services Inc.,
 *  Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model.ndb;

public class NDBProvider {

	private String name;
	private String mpin;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		this.mpin = mpin;
	}

}
