package com.optum.providerpreferences.rs.model.ndb.provider;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class RequestData
{
    private String taxIdNumber;

    private String corpOwnerId;

    public RequestData()
    {
    }

    public RequestData(String taxIdNumber, String corpOwnerId)
    {
        super();
        this.taxIdNumber = taxIdNumber;
        this.corpOwnerId = corpOwnerId;
    }

    public String getTaxIdNumber()
    {
        return taxIdNumber;
    }

    public void setTaxIdNumber(String taxIdNumber)
    {
        this.taxIdNumber = taxIdNumber;
    }

    public String getCorpOwnerId()
    {
        return corpOwnerId;
    }

    public void setCorpOwnerId(String corpOwnerId)
    {
        this.corpOwnerId = corpOwnerId;
    }

}
