package com.optum.providerpreferences.rs.model.ndb.provider;

public class MpinData
{
    private String taxIdTypeCode;

    private String providerId;

    private String provFstNm;

    private String provLstNm;

    private String epsCd;

    public String getTaxIdTypeCode()
    {
        return taxIdTypeCode;
    }

    public void setTaxIdTypeCode(String taxIdTypeCode)
    {
        this.taxIdTypeCode = taxIdTypeCode;
    }

    public String getProviderId()
    {
        return providerId;
    }

    public void setProviderId(String providerId)
    {
        this.providerId = providerId;
    }

    public String getProvFstNm()
    {
        return provFstNm;
    }

    public void setProvFstNm(String provFstNm)
    {
        this.provFstNm = provFstNm;
    }

    public String getProvLstNm()
    {
        return provLstNm;
    }

    public void setProvLstNm(String provLstNm)
    {
        this.provLstNm = provLstNm;
    }

    public String getEpsCd()
    {
        return epsCd;
    }

    public void setEpsCd(String epsCd)
    {
        this.epsCd = epsCd;
    }

}
