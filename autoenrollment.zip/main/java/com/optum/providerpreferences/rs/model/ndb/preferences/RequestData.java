package com.optum.providerpreferences.rs.model.ndb.preferences;

import java.util.ArrayList;

import java.util.Collections;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class RequestData
{
    private String submitterIdNumber = "";

    private String functionCode = "";

    private String providerId = "";

    private String providerTIN = "";

    private String providerTINType = "";

    private String tinPrefix = "";

    private String tinSuffix = "0";

    private String uhcid = "";

    private String div = "";

    private List<LetterType> letterTypeList;

    private String mailPref;

    public RequestData()
    {
    }

    public RequestData(String providerId, String providerTIN, String functionCode, String mailPref, String classifier)
    {
        super();
        this.submitterIdNumber = "PDO";
        this.providerId = providerId;
        this.providerTIN = providerTIN;
        this.functionCode = functionCode;
        this.mailPref = mailPref;
        this.providerTINType = "T";
        this.uhcid = "0";
        this.letterTypeList = Collections.singletonList(new LetterType(classifier));
    }

    public RequestData(String providerId, String providerTIN, String functionCode)
    {
        super();
        this.providerId = providerId;
        this.providerTIN = providerTIN;
        this.functionCode = functionCode;
        this.submitterIdNumber = "PDO";
    }

    public RequestData(String functionCode, String providerId, String providerTIN, String providerTINType, String tinPrefix, String tinSuffix, String uhcid,
            String div, List<LetterType> letterTypeList, String mailPref)
    {
        super();
        this.functionCode = functionCode;
        this.providerId = providerId;
        this.providerTIN = providerTIN;
        this.providerTINType = providerTINType;
        this.tinPrefix = tinPrefix;
        this.tinSuffix = tinSuffix;
        this.uhcid = uhcid;
        this.div = div;
        this.letterTypeList = letterTypeList;
        this.mailPref = mailPref;
        this.submitterIdNumber = "PDO";
    }

    public RequestData(UILetterPreferencesRequest request, String functionCode)
    {
        this.providerId = request.getProviderId();
        this.providerTIN = request.getProviderTIN();
        this.functionCode = functionCode;
    }

    public String getFunctionCode()
    {
        return functionCode;
    }

    public void setFunctionCode(String functionCode)
    {
        this.functionCode = functionCode;
    }

    public String getProviderId()
    {
        return providerId;
    }

    public void setProviderId(String providerId)
    {
        this.providerId = providerId;
    }

    public String getProviderTIN()
    {
        return providerTIN;
    }

    public void setProviderTIN(String providerTIN)
    {
        this.providerTIN = providerTIN;
    }

    public String getProviderTINType()
    {
        return providerTINType;
    }

    public void setProviderTINType(String providerTINType)
    {
        this.providerTINType = providerTINType;
    }

    public String getTinPrefix()
    {
        return tinPrefix;
    }

    public void setTinPrefix(String tinPrefix)
    {
        this.tinPrefix = tinPrefix;
    }

    public String getTinSuffix()
    {
        return tinSuffix;
    }

    public void setTinSuffix(String tinSuffix)
    {
        this.tinSuffix = tinSuffix;
    }

    public String getUhcid()
    {
        return uhcid;
    }

    public void setUhcid(String uhcid)
    {
        this.uhcid = uhcid;
    }

    public String getDiv()
    {
        return div;
    }

    public void setDiv(String div)
    {
        this.div = div;
    }

    public List<LetterType> getLetterTypeList()
    {
        if (this.letterTypeList == null)
        {
            return new ArrayList<>();
        }
        return letterTypeList;
    }

    public void setLetterTypeList(List<LetterType> letterTypeList)
    {
        this.letterTypeList = letterTypeList;
    }

    public String getMailPref()
    {
        return mailPref;
    }

    public void setMailPref(String mailPref)
    {
        this.mailPref = mailPref;
    }

    public String getSubmitterIdNumber()
    {
        return submitterIdNumber;
    }

    public void setSubmitterIdNumber(String submitterIdNumber)
    {
        this.submitterIdNumber = submitterIdNumber;
    }

}
