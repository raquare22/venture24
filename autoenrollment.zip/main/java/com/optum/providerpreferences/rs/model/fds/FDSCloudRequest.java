package com.optum.providerpreferences.rs.model.fds;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class FDSCloudRequest {
	
	private Map<String, Object> request;
	private String documentId;

	public Map<String, Object> getRequest() {
        if (request == null)
        {
        	request = new HashMap<>();
        }
		return request;
	}

	public void setRequest(Map<String, Object> request) {
		this.request = request;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	@Override
	public String toString() {
		return "FDSCloudRequest [request=" + request + ", documentId=" + documentId + "]";
	}
	
	
}
