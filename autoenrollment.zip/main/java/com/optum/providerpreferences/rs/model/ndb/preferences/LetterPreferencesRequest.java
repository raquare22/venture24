package com.optum.providerpreferences.rs.model.ndb.preferences;

public class LetterPreferencesRequest
{
    RequestHeader requestHeader;

    RequestData request;

    public LetterPreferencesRequest(RequestHeader requestHeader, RequestData request)
    {
        super();
        this.requestHeader = requestHeader;
        this.request = request;
    }

    public LetterPreferencesRequest()
    {
        super();
    }

    public RequestHeader getRequestHeader()
    {
        return requestHeader;
    }

    public void setRequestHeader(RequestHeader requestHeader)
    {
        this.requestHeader = requestHeader;
    }

    public RequestData getRequest()
    {
        return request;
    }

    public void setRequest(RequestData request)
    {
        this.request = request;
    }

    @Override
    public String toString()
    {
        return "LetterPreferencesRequest [requestHeader=" + requestHeader + ", request=" + request + "]";
    }

}
