/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model.fds;

import java.util.ArrayList;
import java.util.List;

public class FDSResponse
{

    private List<Document> documents;

    public List<Document> getDocuments()
    {
        if (documents == null)
        {
            documents = new ArrayList<>();
        }
        return documents;
    }

    public void setDocuments(List<Document> documents)
    {
        this.documents = documents;
    }
    
    @Override
    public String toString() {
    	return "documents: " + this.documents;
    }

}
