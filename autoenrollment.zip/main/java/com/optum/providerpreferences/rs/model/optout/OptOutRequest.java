package com.optum.providerpreferences.rs.model.optout;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class OptOutRequest {
	
	private String tin;
	
	private String lastUpdatedBy;
	
	private String lastUpdatedById;
	
	private int optedOutDuration;
	
	private String corpMpin;
	
	private List<String> providerMpins;
	
	public List<String> getProviderMpins() {
		return providerMpins;
	}

	public void setProviderMpins(List<String> providerMpins) {
		this.providerMpins = providerMpins;
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getLastUpdatedById() {
		return lastUpdatedById;
	}

	public void setLastUpdatedById(String lastUpdatedById) {
		this.lastUpdatedById = lastUpdatedById;
	}

	public int getOptedOutDuration() {
		return optedOutDuration;
	}

	public void setOptedOutDuration(int optedOutDuration) {
		this.optedOutDuration = optedOutDuration;
	}
	
	public String getCorpMpin() {
		return corpMpin;
	}

	public void setCorpMpin(String corpMpin) {
		this.corpMpin = corpMpin;
	}

	@Override
	public String toString() {
		return "OptOutRequest=[ tin: " + this.tin + ", corpMpin: " + this.corpMpin + ", providerMpins: " + this.providerMpins + ", lastUpdatedBy: " + this.lastUpdatedBy + ", lastUpdatedById" + this.lastUpdatedById
				+ ", optedOutDuration: " + this.optedOutDuration + " ]";
	}
}
