package com.optum.providerpreferences.rs.model.ndb.preferences;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_NULL)
public class LetterType
{
	@JsonProperty("letterType")
    private String letterTypeStr;

    public LetterType()
    {
    }

    public LetterType(String x)
    {
        this.letterTypeStr = x;
    }

    public String getLetterType()
    {
        return letterTypeStr;
    }

    public void setLetterType(String letterType)
    {
        this.letterTypeStr = letterType;
    }
}
