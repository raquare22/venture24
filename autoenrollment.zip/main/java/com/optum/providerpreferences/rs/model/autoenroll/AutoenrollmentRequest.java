package com.optum.providerpreferences.rs.model.autoenroll;

import java.util.List;

public class AutoenrollmentRequest {
	
	private List<AutoenrollmentObj> autoenrollDocuments;

	public List<AutoenrollmentObj> getAutoenrollDocuments() {
		return autoenrollDocuments;
	}

	public void setAutoenrollDocuments(List<AutoenrollmentObj> autoenrollDocuments) {
		this.autoenrollDocuments = autoenrollDocuments;
	}
	
}
