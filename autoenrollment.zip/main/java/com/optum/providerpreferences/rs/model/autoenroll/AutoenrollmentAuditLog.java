package com.optum.providerpreferences.rs.model.autoenroll;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;

@JsonInclude(Include.NON_NULL)
public class AutoenrollmentAuditLog {
	
	private String recordType; 
	private List<Document> autoenrollDocuments;
	private long countToInsert;
	private List<String> inserted;
	private List<FDSCloudRequest> errors;
	private String status;
	
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	public List<Document> getAutoenrollDocuments() {
	    if (autoenrollDocuments == null)
	    {
	    	autoenrollDocuments = new ArrayList<Document>();
	    }
		return autoenrollDocuments;
	}
	public void setAutoenrollDocuments(List<Document> autoenrollDocuments) {
		this.autoenrollDocuments = autoenrollDocuments;
	}
	public long getCountToInsert() {
		return countToInsert;
	}
	public void setCountToInsert(long countToInsert) {
		this.countToInsert = countToInsert;
	}
	public List<String> getInserted() {
	    if (inserted == null)
	    {
	    	inserted = new ArrayList<String>();
	    }
		return inserted;
	}
	public void setInserted(List<String> inserted) {		
		this.inserted = inserted;
	}
	public List<FDSCloudRequest> getErrors() {
	    if (errors == null)
	    {
	    	errors = new ArrayList<FDSCloudRequest>();
	    }
		return errors;
	}
	public void setErrors(List<FDSCloudRequest> errors) {
		this.errors = errors;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "AutoenrollmentAuditLog [recordType=" + recordType + ", autoenrollDocuments=" + autoenrollDocuments
				+ ", countToInsert=" + countToInsert + ", inserted=" + inserted + ", status=" + status + "]";
	}

	
}
