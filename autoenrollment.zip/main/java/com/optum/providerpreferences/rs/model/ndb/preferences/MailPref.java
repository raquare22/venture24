package com.optum.providerpreferences.rs.model.ndb.preferences;

public class MailPref
{
    private String letterType;

    private String mailingPref;

    public MailPref()
    {
    }

    public MailPref(String letterType, String mailingPref)
    {
        super();
        this.letterType = letterType;
        this.mailingPref = mailingPref;
    }

    public String getLetterType()
    {
        return letterType;
    }

    public void setLetterType(String letterType)
    {
        this.letterType = letterType;
    }

    public String getMailingPref()
    {
        return mailingPref;
    }

    public void setMailingPref(String mailingPref)
    {
        this.mailingPref = mailingPref;
    }

}
