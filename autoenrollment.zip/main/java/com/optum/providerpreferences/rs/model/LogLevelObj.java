package com.optum.providerpreferences.rs.model;

import com.fasterxml.jackson.annotation.JsonInclude;

public class LogLevelObj {
	
	@JsonInclude
	private String logLevel;
	
	@JsonInclude
	private String packageName;

	public String getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	
	@Override
	public String toString() {
		return "logLevel: " + this.logLevel + ", packageName: " + this.packageName;
	}

}
