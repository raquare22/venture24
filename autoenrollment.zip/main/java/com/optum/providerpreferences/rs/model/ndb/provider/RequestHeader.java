package com.optum.providerpreferences.rs.model.ndb.provider;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class RequestHeader
{
    private String applicationId;

    private String clientId;

    private String subscriber;

    private String callingEntity;

    private String userId;

    private String userOfficeCode;

    private String lastUpdateTypeCode;

    public String getApplicationId()
    {
        return applicationId;
    }

    public void setApplicationId(String applicationId)
    {
        this.applicationId = applicationId;
    }

    public String getClientId()
    {
        return clientId;
    }

    public void setClientId(String clientId)
    {
        this.clientId = clientId;
    }

    public String getSubscriber()
    {
        return subscriber;
    }

    public void setSubscriber(String subscriber)
    {
        this.subscriber = subscriber;
    }

    public String getCallingEntity()
    {
        return callingEntity;
    }

    public void setCallingEntity(String callingEntity)
    {
        this.callingEntity = callingEntity;
    }

    public String getUserId()
    {
        return userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public String getUserOfficeCode()
    {
        return userOfficeCode;
    }

    public void setUserOfficeCode(String userOfficeCode)
    {
        this.userOfficeCode = userOfficeCode;
    }

    public String getLastUpdateTypeCode()
    {
        return lastUpdateTypeCode;
    }

    public void setLastUpdateTypeCode(String lastUpdateTypeCode)
    {
        this.lastUpdateTypeCode = lastUpdateTypeCode;
    }
}
