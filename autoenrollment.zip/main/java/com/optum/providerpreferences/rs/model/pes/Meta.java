package com.optum.providerpreferences.rs.model.pes;

public class Meta {

	private String transactionId;
	private String pageOffset;
	private String pageLimit;
	private String totalRecordCount;
	private String elapsedTimeMilliseconds;
	private String supportContact;
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getPageOffset() {
		return pageOffset;
	}
	public void setPageOffset(String pageOffset) {
		this.pageOffset = pageOffset;
	}
	public String getPageLimit() {
		return pageLimit;
	}
	public void setPageLimit(String pageLimit) {
		this.pageLimit = pageLimit;
	}
	public String getTotalRecordCount() {
		return totalRecordCount;
	}
	public void setTotalRecordCount(String totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}
	public String getElapsedTimeMilliseconds() {
		return elapsedTimeMilliseconds;
	}
	public void setElapsedTimeMilliseconds(String elapsedTimeMilliseconds) {
		this.elapsedTimeMilliseconds = elapsedTimeMilliseconds;
	}
	public String getSupportContact() {
		return supportContact;
	}
	public void setSupportContact(String supportContact) {
		this.supportContact = supportContact;
	}
	
	@Override
	public String toString() {
		return "transactionId: " + this.transactionId + ", pageOffset: " + this.pageOffset + ", pageLimit: " + this.pageLimit + ", totalRecordCount: " + this.totalRecordCount
				+ ", elapsedTimeMilliseconds: " + this.elapsedTimeMilliseconds + ", supportContact: " + this.supportContact;
	}
}
