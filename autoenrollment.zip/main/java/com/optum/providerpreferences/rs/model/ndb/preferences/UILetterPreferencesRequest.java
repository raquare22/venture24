package com.optum.providerpreferences.rs.model.ndb.preferences;

public class UILetterPreferencesRequest
{
    private String providerId;

    private String providerTIN;

    public UILetterPreferencesRequest()
    {
    }

    public UILetterPreferencesRequest(String providerId, String providerTIN)
    {
        super();
        this.providerId = providerId;
        this.providerTIN = providerTIN;
    }

    public String getProviderId()
    {
        return providerId;
    }

    public void setProviderId(String providerId)
    {
        this.providerId = providerId;
    }

    public String getProviderTIN()
    {
        return providerTIN;
    }

    public void setProviderTIN(String providerTIN)
    {
        this.providerTIN = providerTIN;
    }

}
