/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class PasswordOwner
{

    private String optumUUID;

    private String uhcID;

    private String mpin;

    private String tin;

    @JsonInclude(Include.NON_EMPTY)
    private List<PasswordOwnerInfo> providers;

    @JsonInclude(Include.NON_EMPTY)
    private List<PasswordOwnerInfo> corporates;

    public PasswordOwner()
    {
    	//empty constructor 
    }

    public String getOptumUUID()
    {
        return optumUUID;
    }

    public void setOptumUUID(String optumUUID)
    {
        this.optumUUID = optumUUID;
    }

    public String getUhcID()
    {
        return uhcID;
    }

    public void setUhcID(String uhcID)
    {
        this.uhcID = uhcID;
    }

    public String getMpin()
    {
        return mpin;
    }

    public void setMpin(String mpin)
    {
        this.mpin = mpin;
    }

    public String getTin()
    {
        return tin;
    }

    public void setTin(String tin)
    {
        this.tin = tin;
    }

    public List<PasswordOwnerInfo> getProviders()
    {

        if (providers == null)
        {

            providers = new ArrayList<>();
        }
        return providers;
    }

    public void setProviders(List<PasswordOwnerInfo> providers)
    {
        this.providers = providers;
    }

    public List<PasswordOwnerInfo> getCorporates()
    {

        if (corporates == null)
        {

            corporates = new ArrayList<>();
        }
        return corporates;
    }

    public void setCorporates(List<PasswordOwnerInfo> corporates)
    {
        this.corporates = corporates;
    }

}
