package com.optum.providerpreferences.rs.model.linksecurity;

import java.util.ArrayList;
import java.util.List;

public class PSMResponse {

	private String result;
	private String message;
	private String optumUuid;
	private List<User> users;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getOptumUuid() {
		return optumUuid;
	}

	public void setOptumUuid(String optumUuid) {
		this.optumUuid = optumUuid;
	}

	public List<User> getUsers() {
		if (users == null) {
			users = new ArrayList<>();
		}
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

}
