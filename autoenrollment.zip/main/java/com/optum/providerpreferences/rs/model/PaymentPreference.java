package com.optum.providerpreferences.rs.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.util.Date;

@Document(collection = "paymentPreference")
public class PaymentPreference implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;
    private String tin;
    private String mpin;
    private String corporateMpin;
    private String paymentPref;
    private String accountNumber;
    private String updatedBy;

    @JsonIgnore
    private Date dateCreated;

    @JsonIgnore
    private Date dateModified;

    private String revisions;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTin() {
        return tin;
    }
    public void setTin(String tin) {
        this.tin = tin;
    }
    public String getMpin() {
        return mpin;
    }
    public void setMpin(String mpin) {
        this.mpin = mpin;
    }
    public String getPaymentPref() {
        return paymentPref;
    }
    public void setPaymentpref(String paymentPref) {
        this.paymentPref = paymentPref;
    }

    public String getAccountNumber() {
        return accountNumber;
    }
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Date getDateCreated() {
        return dateCreated==null?null:(Date)dateCreated.clone();
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated==null?null:(Date)dateCreated.clone();
    }

    public Date getDateModified() {
        return dateModified==null?null:(Date)dateModified.clone();
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified==null?null:(Date)dateModified.clone();
    }

    public String getRevisions() {
        return revisions;
    }
    public void setRevisions(String revisions) {
        this.revisions = revisions;
    }

    public String getCorporateMpin() {
        return corporateMpin;
    }

    public void setCorporateMpin(String corporateMpin) {
        this.corporateMpin = corporateMpin;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public String toString() {
        return "PaymentPreference [id=" + id + ", tin=" + tin + ", mpin=" + mpin + ", paymentPref=" + paymentPref +
                ", accountNumber=" + accountNumber + ", updatedBy=" + updatedBy + ", dateCreated=" + dateCreated + ", dateModified=" + dateModified +
                ", corporateMpin=" + corporateMpin +
                ", revisions=" + revisions + "]";
    }
}
