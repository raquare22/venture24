package com.optum.providerpreferences.rs.model.pes;

public class PESTinRequest {
	
	private String applicationName;
	private String pageOffset;
	private String statusCode;
	private String corporateOwnerProviderId;
	
	
	public PESTinRequest(String corpMpin) {
		this.applicationName = "fds.paperless.pdo";
		this.pageOffset = "0";
		this.statusCode = "Active";
		this.corporateOwnerProviderId = corpMpin;
	}
	
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	public String getPageOffset() {
		return pageOffset;
	}
	public void setPageOffset(String pageOffset) {
		this.pageOffset = pageOffset;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getCorporateOwnerProviderId() {
		return corporateOwnerProviderId;
	}
	public void setCorporateOwnerProviderId(String corporateOwnerProviderId) {
		this.corporateOwnerProviderId = corporateOwnerProviderId;
	}
	
	@Override
	public String toString() {
		return "PESTinRequest = [ applicationName: " + this.applicationName + ", pageOffset: " + this.pageOffset + ", statusCode: " + this.statusCode + ", corporateOwnerProviderId: " + this.corporateOwnerProviderId + " ]";
	}

}
