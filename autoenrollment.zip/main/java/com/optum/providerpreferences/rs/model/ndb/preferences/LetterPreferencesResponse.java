package com.optum.providerpreferences.rs.model.ndb.preferences;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@JsonInclude(Include.NON_NULL)
public class LetterPreferencesResponse
{
    ResponseHeader responseHeader;

    RequestHeader requestHeader;

    RequestData request;

    ResponseData requestResponse;

    public LetterPreferencesResponse()
    {
        
    }
    
    public LetterPreferencesResponse(ResponseHeader responseHeader, RequestHeader requestHeader, RequestData request, ResponseData requestResponse)
    {
        super();
        this.responseHeader = responseHeader;
        this.requestHeader = requestHeader;
        this.request = request;
        this.requestResponse = requestResponse;
    }

    public ResponseHeader getResponseHeader()
    {
        return responseHeader;
    }

    public void setResponseHeader(ResponseHeader responseHeader)
    {
        this.responseHeader = responseHeader;
    }

    public RequestHeader getRequestHeader()
    {
        return requestHeader;
    }

    public void setRequestHeader(RequestHeader requestHeader)
    {
        this.requestHeader = requestHeader;
    }

    public RequestData getRequest()
    {
        return request;
    }

    public void setRequest(RequestData request)
    {
        this.request = request;
    }

    public ResponseData getRequestResponse()
    {
        return requestResponse;
    }

    public void setRequestResponse(ResponseData requestResponse)
    {
        this.requestResponse = requestResponse;
    }

    @Override
    public String toString()
    {
        ObjectMapper mapper = new ObjectMapper();
        try
        {
            return mapper.writeValueAsString(this);
        }
        catch (JsonProcessingException e)
        {
            return super.toString();
        }
    }

}
