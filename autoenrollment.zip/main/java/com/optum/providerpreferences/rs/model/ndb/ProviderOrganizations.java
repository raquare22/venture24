/**
 *  Copyright Optum Services Inc., 2017. All rights reserved.
 *  This software and documentation contain confidential and proprietary information owned by Optum Services Inc.,
 *  Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model.ndb;

import java.util.ArrayList;
import java.util.List;

public class ProviderOrganizations {

	private List<ProviderOrganization> respOrgs;
	private String optumUUId;
	private String statusCode;
	private String statusMessage;

	public List<ProviderOrganization> getRespOrgs() {
		if (respOrgs == null) {
			respOrgs = new ArrayList<>();
		}
		return respOrgs;
	}

	public void setRespOrgs(List<ProviderOrganization> respOrgs) {
		this.respOrgs = respOrgs;
	}

	public String getOptumUUId() {
		return optumUUId;
	}

	public void setOptumUUId(String optumUUId) {
		this.optumUUId = optumUUId;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	@Override
	public String toString() {
		return "ProviderOrganizations [respOrgs=" + respOrgs + ", optumUUId=" + optumUUId + ", statusCode=" + statusCode
				+ ", statusMessage=" + statusMessage + "]";
	}	

}
