/**
 *  Copyright Optum Services Inc., 2017. All rights reserved.
 *  This software and documentation contain confidential and proprietary information owned by Optum Services Inc.,
 *  Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.model.ndb;

import java.util.ArrayList;
import java.util.List;

public class CorporateEntities {

	private List<String> privileges;
	private List<Corporate> corporates;
	private String statusCode;
	private String statusMessage;

	public List<String> getPrivileges() {

		if (privileges == null) {
			privileges = new ArrayList<>();
		}
		return privileges;
	}

	public void setPrivileges(List<String> privileges) {
		this.privileges = privileges;
	}

	public List<Corporate> getCorporates() {
		if (corporates == null) {

			corporates = new ArrayList<>();
		}
		return corporates;
	}

	public void setCorporates(List<Corporate> corporates) {
		this.corporates = corporates;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

}
