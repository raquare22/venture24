package com.optum.providerpreferences.rs.model.optout;

public class OptOutFDSCloudPOSTRequest {
	
	private String space_id; 
	private OptOutAuditMetadata metadata;
	
	public String getSpace_id() {
		return space_id;
	}
	public void setSpace_id(String space_id) {
		this.space_id = space_id;
	}
	public OptOutAuditMetadata getMetadata() {
		return metadata;
	}
	public void setMetadata(OptOutAuditMetadata metadata) {
		this.metadata = metadata;
	}
	
	
}
