package com.optum.providerpreferences.rs.handler;

import java.beans.Encoder;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.NDBToken;
import com.optum.providerpreferences.rs.model.pes.PESResponse;
import com.optum.providerpreferences.rs.model.pes.PESTinRequest;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;

@Component
public class PESHandler extends ServiceBase {
	
	private static final Logger logger = LogManager.getLogger(PESHandler.class);
	
	@Autowired
    private RestTemplate client;

    @Autowired
    private HttpHeaders headers;

	@Value("${PES_TIN_URL}")
	protected String pesTinUrl;

    private ApplicationUtil app = new ApplicationUtil();
    
    private NDBToken token = null;
	
	
	
	public PESResponse getTins(PESTinRequest tinRequest) throws ApplicationException {
		logger.info("PESHandler --> ENTER getTins, tinRequest={}", tinRequest);
		
		try {
			
			pesWebServicePrep();
			
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(pesTinUrl);

			HttpEntity<PESTinRequest> requestEntity = new HttpEntity<>(tinRequest, headers);
	        String uri = builder.toUriString();
	        logger.info("Sending request to PES - get tins, requestEntity={}, uri={}", Encode.forJava(requestEntity.toString()), Encode.forJava(uri));
	        ResponseEntity<PESResponse> response = (ResponseEntity<PESResponse>) sendRequest(uri, requestEntity, PESResponse.class, HttpMethod.POST);
	        logger.info("Response received from PES - get tins");
	        String success=app.rerSuccess("PES tins response={}");
	        logger.info(success, Encode.forJava(String.valueOf(response.getBody())));
	        return response.getBody();
			
		} catch (Exception e) {
			throw new ApplicationException(e.toString());
		}
	}
	
	
    public NDBToken getToken()
    {
        return token;
    }

    public void setToken(NDBToken token)
    {
        this.token = token;
    }
	
	public void pesWebServicePrep() throws IOException, OAuthSystemException, OAuthProblemException, ApplicationException {
        try
        {
            setToken((NDBToken) oauth2handler.getOauthToken("PDO", "PES"));
            
            int retryCount = numRetries;
            while (token == null && (retryCount-- > 0)) {
				
            	logger.info("retryCount={}", retryCount);
				logger.info("time to wait={}", timeToWaitMsArr[retryCount]);
				
				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				setToken((NDBToken) oauth2handler.getOauthToken("PDO", "PES"));
				logger.warn("NDB token request retry: retryCount={}", retryCount);
			}
            
        }
        catch (IOException | OAuthSystemException | OAuthProblemException | ApplicationException e)
        {
            logger.error("Could not retrieve OAuth Token - NDB, error:{}.", ExceptionUtils.getStackTrace(e));
            throw e;
        }
        headers.set("Authorization", "bearer " + getToken().getAccessToken());
        headers.setContentType(MediaType.APPLICATION_JSON);
	}

}
