/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.handler;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.NDBToken;
import com.optum.providerpreferences.rs.model.TokenAbst;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesRequest;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinRequest;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
/**
 * This handler contains methods to call UPM/AE web services.
 * 
 * @author Provider Paperless Letters
 */
@Component
public class NDBHandler extends ServiceBase
{

    @Autowired
    RestTemplate client;

    @Autowired
    private HttpHeaders headers = new HttpHeaders();

    @Autowired
    private ObjectMapper mapper = new ObjectMapper();

    private static final Logger logger = LogManager.getLogger(NDBHandler.class);

    private NDBToken token = null;
    
    private ApplicationUtil app = new ApplicationUtil();

    @Value("${NDB_LETTER_PREFS}")
    protected String ndbLetterPrefsURL;

    @Value("${NDB_CORP_MPIN_URL}")
    protected String ndbCorpMpinURL;


    public LetterPreferencesResponse getProviderLetterPreferences(com.optum.providerpreferences.rs.model.ndb.preferences.RequestData requestData)
            throws ApplicationException

    {
        try
        {
            ndbWebServicePrep();

            LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
            webRequest.setRequest(requestData);
            webRequest.setRequestHeader(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestHeader("PDO", "PDO", "938", "0"));

            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(ndbLetterPrefsURL);
            HttpEntity<String> requestEntity = new HttpEntity<>(mapper.writeValueAsString(webRequest), headers);

            logger.info("Sending request to NDB - Provider Preferences");
            logger.info(Encode.forJava(requestEntity.getBody()));
            String uri = builder.toUriString();
            ResponseEntity<LetterPreferencesResponse> webResponse = (ResponseEntity<LetterPreferencesResponse>) sendRequest(uri, requestEntity, LetterPreferencesResponse.class, HttpMethod.POST);
            logger.info("Response received from NDB - Provider Preferences");
            String success=app.rerSuccess("Response={}");
            logger.info(success, Encode.forJava(String.valueOf(webResponse.getBody())));
            return webResponse.getBody();
        }
        catch (Exception e)
        {
            logger.error(app.rerFailure("Failed to make NDB web service call - Provider Preferences, error={}"), e);
            throw new ApplicationException(e.toString());
        }
    }

    /**
     * Retrieves Provider data based on a tin and an mpin
     * 
     * @param requestData
     * @return
     * @throws ApplicationException
     */
    public CorpMpinResponse getProviderData(com.optum.providerpreferences.rs.model.ndb.provider.RequestData requestData) 
    		throws ApplicationException, IOException, OAuthSystemException, OAuthProblemException, RestClientException
    {

        ndbWebServicePrep();

        CorpMpinRequest request = new CorpMpinRequest();
        com.optum.providerpreferences.rs.model.ndb.provider.RequestHeader headerData = new com.optum.providerpreferences.rs.model.ndb.provider.RequestHeader();
        headerData.setApplicationId("Paperless");
        headerData.setClientId("PDO");
        headerData.setSubscriber("Paperless");
        headerData.setCallingEntity("");
        headerData.setUserId("PDO");
        headerData.setUserOfficeCode("938");
        headerData.setLastUpdateTypeCode("lastUpdateTypeCode");

        request.setRequestHeader(headerData);
        request.setRequestData(requestData);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(ndbCorpMpinURL);
        HttpEntity<CorpMpinRequest> requestEntity;
        ResponseEntity<CorpMpinResponse> response = null;
        requestEntity = new HttpEntity<>(request, headers);
        logger.info("Sending request to NDB - Corporate Mpin");
        String uri = builder.toUriString();
        logger.info("URL={}", uri);

        try {
            response = (ResponseEntity<CorpMpinResponse>) sendRequest(uri, requestEntity, CorpMpinResponse.class, HttpMethod.POST);
        } catch (RestClientException | NullPointerException e) {
        	logger.error(app.rerFailure("Failed to make NDB web service call - Corporate Mpin, error={}"), e);
        	throw e;
        }
        String success=app.rerSuccess("Response recieved from NDB - Corporate Mpin");
        logger.info(success);

        return response.getBody();
    }
    
    
    public boolean updateProviderLetterPreferences(LetterPreferencesRequest request, String currentMpin, String currentTin) 
    		throws JsonProcessingException, ApplicationException, OAuthProblemException, OAuthSystemException, IOException 
    {
        try
        {
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(ndbLetterPrefsURL);
            HttpEntity<String> requestEntity = new HttpEntity<>(mapper.writeValueAsString(request), headers);
            logger.info("NDBrequest={}", Encode.forJava(requestEntity.toString()));
            logger.info("Sending request to NDB -  Update Provider Preferences");
            
            ResponseEntity<LetterPreferencesResponse> webResponse = (ResponseEntity<LetterPreferencesResponse>) sendRequest(

            		builder.toUriString(), requestEntity, LetterPreferencesResponse.class, HttpMethod.POST, request);
            
            Objects.requireNonNull(webResponse);
            
            if (webResponse.getBody().getResponseHeader().getReturncode().equals("99")) {
            	
            }
            
            logger.info(app.rerSuccess("Response received from NDB - Update Provider Preferences"));
            logger.info("NDBresponse={}, statusCode={}", Encode.forJava(webResponse.getBody().toString()), webResponse.getStatusCode().toString());

            if (webResponse.getBody().getResponseHeader().getReturncode().equals("99") || !webResponse.getStatusCode().equals(HttpStatus.OK) && !webResponse.getBody().getResponseHeader().getMessage().equalsIgnoreCase("ALREADY EXIST IN DB"))
            {
            	String failure=app.rerFailure("Failed to make update call to NDB, returncode={} -> mpin, tin, fileName, deliveryMethod -> {},{},{},{}");
            	logger.error(failure, Encode.forJava(webResponse.getBody().getResponseHeader().getReturncode()), Encode.forJava(currentMpin), Encode.forJava(currentTin), request.getRequest().getLetterTypeList().get(0), Encode.forJava(request.getRequest().getMailPref()));
                return false;
            }
        }
        catch (JsonProcessingException | NullPointerException e)
        {
            logger.error(app.rerFailure("Failed to make NDB web service call - Update Provider Preferences, error={}"), e);
            throw e;
        }
        return true;
    }

    public boolean updateProviderLetterPreferences(List<LetterPreferencesRequest> requestList) 
    		throws IOException, OAuthSystemException, OAuthProblemException, ApplicationException
    {
        try
        {
            ndbWebServicePrep();

            for (LetterPreferencesRequest currentRequest : requestList)
            {
                logger.info("UPDATING LETTER TYPE, letterType={}",currentRequest.getRequest().getLetterTypeList().get(0).getLetterType());
                logger.info("Temp update request, request={}", currentRequest);
                UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(ndbLetterPrefsURL);
                HttpEntity<String> requestEntity = new HttpEntity<>(mapper.writeValueAsString(currentRequest), headers);
                logger.info("Sending request to NDB -  Update Provider Preferences");
                ResponseEntity<LetterPreferencesResponse> webResponse =
                        client.exchange(builder.toUriString(), HttpMethod.POST, requestEntity, LetterPreferencesResponse.class);
                String success=app.rerSuccess("Response received from NDB - Update Provider Preferences");
                logger.info(success);
                
                String webStatusCode=webResponse.getStatusCode().toString();
                logger.info("Response Status={}", webStatusCode);
                if (!webResponse.getStatusCode().equals(HttpStatus.OK)&&!webResponse.getBody().getResponseHeader().getMessage().equalsIgnoreCase("ALREADY EXIST IN DB"))
                {
                    	String error=app.rerFailure("Failed to make update call to NDB for MPIN, mpin={}");
                        logger.error(error, currentRequest.getRequest().getProviderId());
                        return false;

                }

            }

        }
        catch (IOException | OAuthSystemException| OAuthProblemException | ApplicationException e)
        {
            logger.error(app.rerFailure("Failed to make NDB web service call - Update Provider Preferences, error={}"), e);
        }
        return true;

    }

    public void ndbWebServicePrep() 
    		throws IOException, OAuthSystemException, OAuthProblemException, ApplicationException
    {
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd").format(new Date());
        try
        {
            setToken((NDBToken) oauth2handler.getOauthToken("PDO", "NDB"));
            
            int retryCount = numRetries;
            while (token == null && (retryCount-- > 0)) {
				
            	logger.info("retryCount={}", retryCount);
				logger.info("time to wait={}", timeToWaitMsArr[retryCount]);
				
				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				setToken((NDBToken) oauth2handler.getOauthToken("PDO", "NDB"));
				logger.warn("NDB token request retry: retryCount={}", retryCount);
			}
            
        }
        catch (IOException | OAuthSystemException | OAuthProblemException | ApplicationException e)
        {
            logger.error("Could not retrieve OAuth Token - NDB, error:{}.", ExceptionUtils.getStackTrace(e));
            throw e;
        }

        headers.set("Authorization", "Bearer " + getToken().getAccessToken());
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("timestamp", timeStamp);
        headers.set("actor", "test");
        headers.set("scope", "read");

    }

    public NDBToken getToken()
    {
        return token;
    }

    public void setToken(NDBToken token)
    {
        this.token = token;
    }
    
    public ResponseEntity<?> sendRequest(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod, LetterPreferencesRequest request) 
    		throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException 
    {
		
		ResponseEntity<?> responseEntity = null;
		HttpEntity<?> reqEntity = requestEntity;
		
		try {
			
			responseEntity = retryRequest(uri, reqEntity, clazz, httpMethod);

			if (responseEntity != null && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				logger.info("sendRequestNDB -> Request successful: responseEntity={}", Encode.forJava(responseEntity.toString()));
				return responseEntity;
			}
			
			logger.info("sendRequestNDB -> First request failed, retrying");
			
			int retryCount = numRetries;
			while ((responseEntity == null || !HttpStatus.OK.equals(responseEntity.getStatusCode())) && (retryCount-- > 0)) {
				
				logger.info("sendRequestNDB -> retryCount={}", retryCount);
				logger.info("sendRequestNDB -> time to wait={}", timeToWaitMsArr[retryCount]);
				
				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				
				TokenAbst newToken;
				newToken = oauth2handler.getOauthTokenRefresh("PDO", "NDB");
				logger.info("sendRequestNDB -> Request entity change, requestEntity={}", Encode.forJava(reqEntity.toString()));

				headers.set("Authorization", "Bearer " + newToken.getAccessToken());

				headers.setContentType(MediaType.APPLICATION_JSON);
				logger.info("sendRequestNDB -> New access token added to requestEntity, newToken={}, requestEntity={}", Encode.forJava(newToken.toString()), Encode.forJava(reqEntity.toString()));
				
				reqEntity = new HttpEntity<String>(mapper.writeValueAsString(request), headers);
				
				logger.info("sendRequestNDB -> Calling retryRequest, uri={}, reqEntity={}", Encode.forJava(uri), Encode.forJava(reqEntity.toString()));

				responseEntity = retryRequest(uri, reqEntity, clazz, httpMethod);
				logger.warn("sendRequestNDB -> Request retry: requestBody={}, retryCount={}", Encode.forJava(reqEntity.toString()), retryCount);
			}
			
			// if responseEntity is null, throw a NullPointerException
			Objects.requireNonNull(responseEntity);
			
			if (!HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				logger.error("sendRequestNDB -> Request failed after retries with error code={}, request={}", responseEntity.getStatusCode(), Encode.forJava(reqEntity.toString()));
				return responseEntity;
			}

			logger.info("sendRequestNDB -> Request successful after retries statusCode={}, responseBody={}", responseEntity.getStatusCode(), Encode.forJava(String.valueOf(responseEntity.getBody())));
			return responseEntity;
		}
		catch (ApplicationException | OAuthProblemException | OAuthSystemException | IOException e) {
			logger.error("sendRequestNDB -> ERROR DURING SERVICE CALL: uri={}, request={}, reqEntity={}, error={}", Encode.forJava(uri), request, Encode.forJava(reqEntity.toString()), e);
			throw(e);
		}
		
	}
 

}
