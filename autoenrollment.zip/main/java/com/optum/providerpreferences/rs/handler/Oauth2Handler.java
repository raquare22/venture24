/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.handler;

import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.TokenAbst;
import org.apache.oltu.oauth2.client.OAuthClient;
import org.apache.oltu.oauth2.client.URLConnectionClient;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.client.response.OAuthJSONAccessTokenResponse;
import org.apache.oltu.oauth2.common.OAuth;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.oltu.oauth2.common.message.types.GrantType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import org.springframework.http.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.NDBToken;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.TokenAbst;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

/**
 * This handler is used to retrieve OAuth tokens through HTTP calls or cache.
 * 
 * @author Provider Paperless Letters
 */
@Service
public class Oauth2Handler
{

    private static final Logger logger = LogManager.getLogger(Oauth2Handler.class);

    protected long timeLeftBeforeTokenExpiresSecs = 300;

    @Value("${STARGATE_TOKEN_URL}")
    protected String stargateTokenUrl;

    @Value("${STARGATE_CLIENT_ID}")
    protected String stargateClientId;

    @Value("${STARGATE_CLIENT_SECRET}")
    protected String stargateClientSecret;

    @Value("${FDSCLOUD_TOKEN_URL}")
    protected String fdsTokenUrl;

    @Value("${FDSCLOUD_CLIENT_ID}")
    protected String fdsClientId;

    @Value("${FDSCLOUD_CLIENT_SECRET}")
    protected String fdsClientSecret;

    @Value("${PES_CORPMPIN_CLIENT_ID}")
    protected String pesCorpMpinClientId;

    @Value("${PES_CORPMPIN_CLIENT_SECRET}")
    protected String pesCorpMpinClientSecret;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    ObjectMapper mapper = new ObjectMapper();

    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
    private static final Oauth2Handler oauth2Handler = new Oauth2Handler();
    private static final Map<String, Object> lockObjectMap = new HashMap<>();
    protected static Map<String, TokenStore> tokenMap = new HashMap<>();

    public static Oauth2Handler getInstance() {
        return oauth2Handler;
    }

    /**
     * Get an Oauth Token based on sessionId and a serviceIndicator. Use Cases: Link Services: "LINK" Federation Secure Cloud APIs: "FDS" AE Services: "PSM"
     * **Must use these values as they are used to retrieve specific environment variables**
     * 
     * @param sessionId
     * @param serviceIndicator
     * @return
     * @throws Exception
     * @throws ApplicationException
     */
    @NotNull
    public TokenAbst getOauthToken(String sessionId, String serviceIndicator) throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException {
        TokenStore tokenStore = getTokenFromMap(sessionId, serviceIndicator);
        if (tokenAboutToExpire(sessionId, tokenStore.lastTokenExpireTime)) {
            getSyncToken(sessionId, serviceIndicator);
        } else {
        }
        return tokenStore.token;
    }

    @NotNull
    public TokenAbst getOauthTokenRefresh(String sessionId, String serviceIndicator) throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException {
//        logger.info("getOauthTokenRefresh -> Entering sessionId={}, serviceIndicator={}", sessionId, serviceIndicator);
        synchronized(lockObjectMap.get(serviceIndicator)) {
            TokenStore tokenStore = getTokenFromMap(sessionId, serviceIndicator);
            tokenStore.lastTokenExpireTime = 0L;
            tokenStore.expiresIn = 0L;
            tokenMap.put(serviceIndicator, tokenStore);
            return getOauthToken(sessionId, serviceIndicator);
        }
    }

//    public static void setTimeLeftBeforeTokenExpires(Long timeLeftBeforeTokenExpires) {
//        timeLeftBeforeTokenExpiresSecs = timeLeftBeforeTokenExpires;
//        logger.warn("TIME_LEFT_BEFORE_TOKEN_EXPIRES_SECS={}", timeLeftBeforeTokenExpiresSecs);
//    }

    protected TokenStore getTokenFromMap(String sessionId, String serviceIndicator) throws ApplicationException {
        TokenStore tokenStore = tokenMap.get(serviceIndicator);
        if (tokenStore == null) {
            lockObjectMap.put(serviceIndicator, new Object());
            synchronized(this) {
                if (tokenMap.get(serviceIndicator) != null) {
                    logger.warn("synchronized tokenMap != null; sessionId={}, serviceIndicator={}", Encode.forJava(sessionId), serviceIndicator);
                    return tokenMap.get(serviceIndicator);
                }
                String tokenURL = "";
                String clientId = "";
                String clientSecret = "";

                switch(serviceIndicator) {
                    case "NDB":
                    case "PES":
                    case "LINK":
                    case "PES_CORPMPIN":
                        tokenURL = stargateTokenUrl;
                        clientId = pesCorpMpinClientId;
                        clientSecret = pesCorpMpinClientSecret;
                        break;
                    case "DS":
                        tokenURL = stargateTokenUrl;
                        clientId = stargateClientId;
                        clientSecret = stargateClientSecret;
                        break;
                    case "FDSCLOUD":
                        tokenURL = fdsTokenUrl;
                        clientId = fdsClientId;
                        clientSecret = fdsClientSecret;
                        break;
                    default:
                        tokenURL = stargateTokenUrl;
                        clientId = stargateClientId;
                        clientSecret = stargateClientSecret;

                }

                logger.info("tokenUrl={}, clientId={}", Encode.forJava(tokenURL), clientId);
                if (tokenURL == null || clientId == null || clientSecret == null) {
                    throw new ApplicationException("System environment variable(s) are not valid; sessionId=" + sessionId
                       + ", serviceIndicator=" + serviceIndicator + ", tokenURL=" + tokenURL + ", clientId=" + clientId
                       + ", clientSecret=" + clientSecret);
                }
            tokenURL = tokenURL.trim();
            tokenStore = new TokenStore(tokenURL, clientId, clientSecret);
            tokenMap.put(serviceIndicator, tokenStore);
            logger.info("Added sessionId={}, serviceIndicator={} to tokenMap with null token", Encode.forJava(sessionId), serviceIndicator);
            }
        }
        return tokenStore;
	}

    protected TokenStore getNewToken(String sessionId, String serviceIndicator, TokenStore tokenStore)
      throws OAuthProblemException, OAuthSystemException, IOException {

//        logger.info("Calling OAuth Service - API");
        GrantType grant = serviceIndicator.equalsIgnoreCase("fdscloud") ? GrantType.AUTHORIZATION_CODE : GrantType.CLIENT_CREDENTIALS;
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(tokenStore.clientId, tokenStore.clientSecret);
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        body.add("grant_type", grant.toString());
        HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(body, headers);

        ResponseEntity<HashMap> response = null;

        response = restTemplate.exchange(tokenStore.tokenURL, HttpMethod.POST,requestEntity, HashMap.class);

        HashMap<String,Object> responseBody = response.getBody();


        Token token  = new Token();
        if(responseBody != null)
        {
            token.setAccessToken((String) responseBody.get("access_token"));
            int expire = (int) responseBody.get("expires_in");
            tokenStore.expiresIn = expire;
        }
        tokenStore.token = token;
        return tokenStore;
    }

    protected void getSyncToken(String sessionId, String serviceIndicator) throws OAuthProblemException, OAuthSystemException, IOException {
        synchronized(lockObjectMap.get(serviceIndicator)) {
            TokenStore tokenStore = tokenMap.get(serviceIndicator);
            if (tokenAboutToExpire(sessionId, tokenStore.lastTokenExpireTime)) {
//                logger.info("getSyncToken --> Get new accessToken: sessionId={}, serviceIndicator={}", sessionId, serviceIndicator);
                setExpireTimeOfToken(sessionId, serviceIndicator, getNewToken(sessionId, serviceIndicator, tokenStore));
//                logger.info("getSyncToken --> tokenMap: new accessToken; sessionId={}, serviceIndicator={}, tokenStore={}", sessionId, serviceIndicator, tokenStore);
                tokenMap.put(serviceIndicator, tokenStore);
            }
        }
    }

    protected boolean tokenAboutToExpire(String sessionId, long lastTokenExpireTime) {
        long diff = lastTokenExpireTime - System.currentTimeMillis();
//        logger.info("tokenAboutToExpire -- sessionId={}, lastTokenExpireTime={}, now={}, diff={}, timeLeft={}", sessionId, lastTokenExpireTime, System.currentTimeMillis(), diff, timeLeftBeforeTokenExpiresSecs * 1000);
        return diff < timeLeftBeforeTokenExpiresSecs * 1000;

    }

    protected void setExpireTimeOfToken(String sessionId, String serviceIndicator, TokenStore tokenStore) {
//        logger.info("setExpireTimeOfToken --> Entering sessionId={}, serviceIndicator={}, tokenStore={}", sessionId, serviceIndicator, tokenStore);
        tokenStore.lastTokenExpireTime = System.currentTimeMillis() + (tokenStore.expiresIn * 1000L);
//        logger.info("setExpireTimeOfToken --> Exiting sessionId={}, serviceIndicator={}, tokenStore={}, tokenStore.lastTokenExpireTime={}", sessionId, serviceIndicator, tokenStore, tokenStore.lastTokenExpireTime);
    }

    private TokenAbst tokenSwitch(String serviceIndicator, OAuthJSONAccessTokenResponse response) throws IOException {
        return serviceIndicator.equals("NDB") || serviceIndicator.equals("PES") ? mapper.readValue(response.getBody(), NDBToken.class) : mapper.readValue(response.getBody(), Token.class);
    }

        public class TokenStore {
            String tokenURL;
            String clientId;
            String clientSecret;
            long lastTokenExpireTime;
            long expiresIn;
            TokenAbst token;
            public TokenStore(String tokenURL, String clientId, String clientSecret, long lastTokenExpireTime) {
                this.tokenURL = tokenURL;
                this.clientId = clientId;
                this.clientSecret= clientSecret;
                this.lastTokenExpireTime = lastTokenExpireTime;
                token = null;
            }
            public TokenStore(String tokenURL, String clientId, String clientSecret) {
                this(tokenURL, clientId, clientSecret, 0L);
            }
            @Override
            public String toString() {
                return "TokenStore [tokenURL=" + tokenURL + ", clientId=" + clientId + ", clientSecret=" + clientSecret + ", lastTokenExpireTime="
                        + format(lastTokenExpireTime) + ", expiresIn=" + expiresIn + ", token=" + token +  "]";
            }
            protected synchronized String format(long lastTokenExpireTime) {
                return sdf.format(lastTokenExpireTime);
            }
        }

        protected static Long sanitizetimeLeftBeforeTokenExpires(Long timeLeftBeforeTokenExpires) {
            return timeLeftBeforeTokenExpires;
        }
    }
