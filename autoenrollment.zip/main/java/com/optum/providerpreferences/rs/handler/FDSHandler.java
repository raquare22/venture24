/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.handler;
import java.io.IOException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.util.UriComponentsBuilder;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObj;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPostResponse;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPutResponse;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSResponse;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;

/**
 * This handler contains methods used to update, add, and get documents in FDS.
 * 
 * @author Provider Paperless Letters
 */

@Component
public class FDSHandler extends ServiceBase
{
    ObjectMapper tempMapper = new ObjectMapper();
    @Autowired
    private HttpHeaders headers = new HttpHeaders();

    @Autowired
    private Oauth2Handler oauth2handler = Oauth2Handler.getInstance();

    @Value("${FDSCLOUD_SPACEID}")
    protected String fdsCloudSpaceId;

    @Value("${FDSCLOUD_URL}")
    protected String fdsCloudURL;
    
    private ApplicationUtil app = new ApplicationUtil();
    private static final  Logger logger = LogManager.getLogger(FDSHandler.class);
    String oauthSuccess=app.rerSuccess("Response received from FDS - OAUTH Service");
    String oauthFailure="Failed to make FDS OAUTH service call: ";
    
    String updateSuccess=app.rerSuccess("Response revieved from FDS - Update Document");
    
    String addSuccess=app.rerSuccess("Response received from FDS - Add Document");
    
    String getDocuments=app.rerSuccess("Response recieved from FDS - Get Documents");
	
    String failedDocuments=app.rerFailure("Failed to make FDS OAUTH Web Service Call - Get Documents");
    String failedGetDocuments = app.rerFailure("Failed to make FDS web service call - Get Documents, e={}");
    
    String errorMap=app.rerFailure("tempMapper error for documents, requestEntity={}, error={}");
    String oauthfdsRequest="Sending request to FDS - OAUTH Service";
    
    String auth="Authorization";
    
    String bearer="Bearer ";
    
    String fdsURL="FDS_GET_URL";
    
    String fdsRequest="FDSrequest={}";
    
    String fdsCallFail="Failed to make FDS web service call: ";
    
    String spaceID="SPACE_ID";
    
    String lowerspaceId="space_id";
    
    String goTofdsForDocuments="Going to FDS for Documents with URI: {}";
    String requestDocuments="Sending request to FDS - Get Documents";
    
    String updateRequest="Sending request to FDS - Update Document";
    
    String documents="documents";
    
    String metaFile="metadata.fileName";
    
    String metaMPIN="metadata.mpin";
    
    String deliveryMethod = "metadata.deliveryMethod";
    
    String metaTIN="metadata.tin";
    
    String sortOrder="sortorder";
    
    /**
     * @param tin
     *            -- tax id of provider
     * @param fileName
     *            -- optional parameter to find a more specific document
     * @param sessionId
     * @return FDSResponse of all Documents meeting parameters
     * @throws JsonParseException
     * @throws JsonMappingException
     * @throws IOException
     * @throws OAuthSystemException
     * @throws OAuthProblemException
     * @throws ApplicationException
     */
    public FDSResponse getDocumentList(String tin, String mpin, String fileName, String sessionId) 
    		throws ApplicationException, IOException, OAuthSystemException, OAuthProblemException, RestClientException, NullPointerException
    {
        Token token = null;
        try
        {
            logger.info(oauthfdsRequest);
            token = (Token) oauth2handler.getOauthToken(sessionId, "FDS");
            logger.info(oauthSuccess);
        }
        catch (IOException | OAuthSystemException | OAuthProblemException e)
        {
            logger.error(failedDocuments);
            throw new ApplicationException(oauthFailure + e.toString());
        }
        try
        {
            String spaceId =fdsCloudSpaceId;
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL).queryParam(metaTIN, tin)
                    .queryParam(metaMPIN, mpin).queryParam(lowerspaceId, spaceId);
            logger.info(goTofdsForDocuments, Encode.forJava(builder.toString()));
            
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            headers.set(auth, bearer + token.getAccessToken());
            
            HttpEntity<String> entity = new HttpEntity<>(headers);
            logger.info(requestDocuments);
            
            ResponseEntity<FDSResponse> response = (ResponseEntity<FDSResponse>) sendRequestFDS(builder.toUriString(), entity, FDSResponse.class, HttpMethod.GET);
            
            if (response != null) {
            	logger.info(getDocuments);
                return response.getBody();
            } else {
            	return new FDSResponse();
            }
            
        }
        catch (Exception e)
        {
            logger.error(app.rerFailure("Failed to make FDS web service call - Get Documents"));
            throw new ApplicationException("Failed to make FDS web service call: {}" + e.toString());
        }
    }

    public FDSResponse getDocumentList(String tin, String mpin, String fileName, String sessionId, Token token) 
    		throws RestClientException
    {
        try
        {
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL).queryParam(metaTIN, tin)
                    .queryParam(metaMPIN, mpin).queryParam(lowerspaceId,fdsCloudSpaceId);
            if (fileName != null && !fileName.equals(""))
            {
                builder.queryParam(metaFile, fileName);
            }
            logger.info(goTofdsForDocuments,builder);
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            headers.set(auth, bearer + token.getAccessToken());
            HttpEntity<String> entity = new HttpEntity<>(headers);
            logger.info(requestDocuments);
            ResponseEntity<FDSResponse> response = (ResponseEntity<FDSResponse>) sendRequestFDS(builder.toUriString(), entity, FDSResponse.class, HttpMethod.GET);
            if (response != null) {
            	logger.info(getDocuments);
                return response.getBody();
            } else {
            	return new FDSResponse();
            }
            
        }
        catch (Exception e)
        {
            logger.error(app.rerFailure("Error processing documents, error={}"), e);
            throw e;
        }
    }

    private void validateMpin(String mpin) throws ApplicationException {
        if (mpin == null || !mpin.matches("^[0-9]{9}$")) {
            throw new ApplicationException("Invalid mpin value");
        }
    }

    private void validateTin(String tin) throws ApplicationException {
        if (tin == null || !tin.matches("^[0-9]{9}$")) {
            throw new ApplicationException("Invalid tin value");
        }
    }

    
    public FDSResponse getAutoEnrollDocumentListSortCreated(String tin, String mpin, String fileName, String sessionId) 
    		throws  ApplicationException, IOException, OAuthSystemException, OAuthProblemException, RestClientException, NullPointerException
    {
        Token token = null;
        try
        {
            logger.info(oauthfdsRequest);
            token = (Token) oauth2handler.getOauthToken(sessionId, "FDS");
            logger.info(oauthSuccess);
        }
        catch (Exception e)
        {
            logger.error(failedDocuments);
            throw new ApplicationException(oauthFailure + e.toString());
        }
        try
        {
            validateTin(tin);
            validateMpin(mpin);
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL)
         			.queryParam("metadata.tin", tin)
                    .queryParam(metaMPIN, mpin)
                    .queryParam(deliveryMethod, "E")
                    .queryParam("metadata.autoEdelUpdateInd", "Y")
                    .queryParam("metadata.fileName", fileName)
                    .queryParam(lowerspaceId,fdsCloudSpaceId)
                    .queryParam("sortorder", "desc");
            
            logger.info("Going to FDS for Documents with URI={}", Encode.forJava(builder.toUriString()));

            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            headers.set(auth, bearer + token.getAccessToken());
            HttpEntity<String> entity = new HttpEntity<String>(headers);

            logger.info(requestDocuments);
            ResponseEntity<FDSResponse> response = (ResponseEntity<FDSResponse>) sendRequestFDS(builder.toUriString(), entity, FDSResponse.class, HttpMethod.GET);
            
            if (response != null) {
            	logger.info(getDocuments);
                return response.getBody();
            } else {
            	return new FDSResponse();
            }
            
        }
        catch (Exception e)
        {
            logger.error(failedGetDocuments, e);
            throw new ApplicationException(fdsCallFail + e.toString());
        }

    }
    
    
    public FDSResponse getOptOutDocuments(String sessionId, String mpin) throws ApplicationException, IOException, OAuthSystemException, OAuthProblemException, RestClientException, NullPointerException {
    	Token token = null;
        try
        {
            logger.info(oauthfdsRequest);
            token = (Token) oauth2handler.getOauthToken(sessionId, "FDS");
            logger.info(oauthSuccess);
        }
        catch (Exception e)
        {
            logger.error(failedDocuments);
            throw new ApplicationException(oauthFailure + e.toString());
        }
        try
        {
            
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL)
                    .queryParam(deliveryMethod, "P")
                    .queryParam("metadata.autoOptOutInd", "Y")
                    .queryParam(lowerspaceId,fdsCloudSpaceId);
            
            if (mpin != null) {
            	builder.queryParam(metaMPIN, mpin);
            }
            
            logger.info("Going to FDS for Opt Out Documents with URI={}", builder.toUriString());

            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            headers.set(auth, bearer + token.getAccessToken());
            HttpEntity<String> entity = new HttpEntity<String>(headers);

            logger.info(requestDocuments);
            ResponseEntity<FDSResponse> response = (ResponseEntity<FDSResponse>) sendRequestFDS(builder.toUriString(), entity, FDSResponse.class, HttpMethod.GET);
            
            if (response != null) {
            	logger.info(getDocuments);
                return response.getBody();
            } else {
            	return new FDSResponse();
            }
            
        }
        catch (Exception e)
        {
            logger.error(failedGetDocuments, e);
            throw new ApplicationException(fdsCallFail + e.toString());
        }
    }
    
    
  
    
    public FDSResponse getDocumentListSortCreated(String tin, String mpin, String fileName, String sessionId) 
    		throws  ApplicationException, IOException, OAuthSystemException, OAuthProblemException, RestClientException, NullPointerException
    {
        Token token = null;
        try
        {
            logger.info(oauthfdsRequest);
            token = (Token) oauth2handler.getOauthToken(sessionId, "FDS");
            logger.info(oauthSuccess);
        }
        catch (Exception e)
        {
            logger.error(failedDocuments);
            throw new ApplicationException(oauthFailure + e.toString());
        }
        try
        {
            String spaceId =fdsCloudSpaceId;
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL).queryParam(metaTIN, tin)
                    .queryParam(metaMPIN, mpin).queryParam(lowerspaceId, spaceId).queryParam("sortby", "updated-date").queryParam(sortOrder, "desc");
            
            if (fileName != null && !fileName.equals(""))
            {
                builder.queryParam(metaFile, fileName);
            }
            
            logger.info(goTofdsForDocuments, Encode.forJava(builder.toUriString()));
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            headers.set(auth, bearer + token.getAccessToken());
            HttpEntity<String> entity = new HttpEntity<>(headers);
            logger.info(requestDocuments);
            ResponseEntity<FDSResponse> response = (ResponseEntity<FDSResponse>) sendRequestFDS(builder.toUriString(), entity, FDSResponse.class, HttpMethod.GET);
            
            if (response != null) {
            	logger.info(getDocuments);
                return response.getBody();
            } else {
            	return new FDSResponse();
            }
            
        }
        catch (Exception e)
        {
            logger.error(failedGetDocuments, e);
            throw new ApplicationException(fdsCallFail + e.toString());
        }
    }
    
    // ------------------------- ADD DOCUMENTS TO FDS BACKEND ---------------------------//
    public ResponseEntity<Document> callFDSPostDocument(MultiValueMap<String, Document> parts, HttpHeaders headers, String sessionId)
            throws IOException, OAuthSystemException, OAuthProblemException, ApplicationException 
    {
    	
    	Token token = null;
        try
        {
            logger.info(oauthfdsRequest);
            token = (Token) oauth2handler.getOauthToken(sessionId, "FDS"); 
            logger.info(oauthSuccess);
        }
        catch (IOException | OAuthSystemException | OAuthProblemException e)
        {
            logger.error(failedDocuments);
            throw new ApplicationException(oauthFailure + e.toString());
        }
    	
        ResponseEntity<Document> response = null;
    	headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set(auth, bearer + token.getAccessToken());
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL);
        HttpEntity<MultiValueMap<String, Document>> requestEntity = new HttpEntity<>(parts, headers);
        logger.info("FDSrequest= {}", Encode.forJava(requestEntity.toString()));
        logger.info("Sending request to FDS - Add Document");
        try
        {
        	response = (ResponseEntity<Document>) sendRequestFDS(builder.toUriString(), requestEntity, Document.class, HttpMethod.POST);
        }
        catch (ResourceAccessException e)
        {
            logger.error("SOCKET EXCEPTION CAUGHT - RETRYING THE ADDING OF DOCUMENT, document={}, error=", Encode.forJava(requestEntity.getBody().get(documents).toString()),e);
            response = (ResponseEntity<Document>) sendRequestFDS(builder.toUriString(), requestEntity, Document.class, HttpMethod.POST);
        }
        catch (HttpServerErrorException e)
        {
            logger.error("TIMEOUT EXCEPTION CAUGHT - RETRYING THE ADDING OF DOCUMENT, erro={} ", ExceptionUtils.getStackTrace(e));
            response = (ResponseEntity<Document>) sendRequestFDS(builder.toUriString(), requestEntity, Document.class, HttpMethod.POST);
        }
        catch (Exception e)
        {
            logger.error(app.rerFailure("Failed to make FDS web service call - Add Document, error={}"), e);
            throw e;
        }
        logger.info(addSuccess);
        return response;
    }
    
    
 // --------------------------UPDATE DOCUMENTS METHODS ------------------------------- //
    public void updateDocuments(List<Document> fdsDocList, String sessionId) 
    		throws  IOException, OAuthSystemException, OAuthProblemException, ApplicationException
    {
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        logger.info("USING SPACE ID, spaceID={}",fdsCloudSpaceId);
        logger.info("NUMBER OF DOCUMENTS TO BE SENT TO FDS FOR UPDATE/ADDITION, size={}", fdsDocList.size());
        Token token = (Token) oauth2handler.getOauthToken(sessionId, "FDS");
        for (Document docToSend : fdsDocList)
        {
        	
        	String docToSendString=tempMapper.writeValueAsString(docToSend);
            logger.info("DOCUMENT BEING SENT, docToSend={}", docToSendString);
            logger.info("DOCUMENT ID, documentId={}", docToSend.getId());
            MultiValueMap<String, Document> docsMapToSend = new LinkedMultiValueMap<>();
            docsMapToSend.add(documents, docToSend);
            if (docToSend.getId() == null || ("").equals(docToSend.getId()))
            {
                logger.info("ATTEMPTING TO ADD DOCUMENT - NO DOCUMENT ID FOUND");
                ResponseEntity<Document> addResponse = callFDSPostDocument(docsMapToSend, headers, sessionId, token);
                if (!addResponse.getStatusCode().equals(HttpStatus.OK))
                {
                	String docsToSendString=tempMapper.writeValueAsString(docToSend);
                    logger.error("ERROR ADDING THE DOCUMENT, docToSend={}", docsToSendString);
                    callFDSPostDocument(docsMapToSend, headers, sessionId, token);
                    // ADD TO ERROR QUEUE? RETRY?
                }
            }
            else
            {
                logger.info("DOCUMENT ID FOUND -- UPDATING PREFERENCES");
                ResponseEntity<Document> updateResponse = callFDSPutDocument(docsMapToSend, headers, docToSend.getId(), "", token);
                if (!updateResponse.getStatusCode().equals(HttpStatus.OK))
                {
                	String formatDocToSend=tempMapper.writeValueAsString(docToSend);
                    logger.error("ERROR UPDATING THE DOCUMENT, RETRYING, docToSend={}", formatDocToSend);
                    callFDSPutDocument(docsMapToSend, headers, docToSend.getId(), "", token);
                }
            }
        }
    }
    
    
 // ------------------------- ADD DOCUMENTS TO FDS BACKEND ---------------------------//
    public ResponseEntity<Document> callFDSPostDocument(MultiValueMap<String, Document> parts, HttpHeaders headers, String sessionId, Token token)
        
    {
        ResponseEntity<Document> response = null;
    	headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set(auth, bearer + token.getAccessToken());
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL);
        HttpEntity<MultiValueMap<String, Document>> requestEntity = new HttpEntity<>(parts, headers);
        logger.info(fdsRequest, Encode.forJava(requestEntity.toString()));
        logger.info("Sending request to FDS - Add Document");
        try
        {
        	response = (ResponseEntity<Document>) sendRequestFDS(builder.toUriString(), requestEntity, Document.class, HttpMethod.POST);
        }
        catch (ResourceAccessException e)
        {
            logger.error(app.rerFailure("SOCKET EXCEPTION CAUGHT - RETRYING THE ADDING OF DOCUMENT, document={}, error={}"), Encode.forJava(requestEntity.getBody().get(documents).toString()),e);
            response = (ResponseEntity<Document>) sendRequestFDS(builder.toUriString(), requestEntity, Document.class, HttpMethod.POST);
        }
        catch (HttpServerErrorException e)
        {
            logger.error(app.rerFailure("TIMEOUT EXCEPTION CAUGHT - RETRYING THE ADDING OF DOCUMENT, error={}"), e);
            response = (ResponseEntity<Document>) sendRequestFDS(builder.toUriString(), requestEntity, Document.class, HttpMethod.POST);
        }
        catch (Exception e)
        {
            logger.error(app.rerFailure("Failed to make FDS web service call - Add Document, error={}"), e);
            throw e;
        }
        logger.info(addSuccess);
        return response;
    }
    
    
 // ------------------------- UPDATE DOCUMENTS IN FDS BACKEND ---------------------------//
    
    public ResponseEntity<Document> callFDSPutDocument(MultiValueMap<String, Document> parts, HttpHeaders headers, String documentId, String sessionId) 
    		throws RestClientException, JsonProcessingException, ApplicationException {
    	
    	Token token = null;
        try
        {
            logger.info(oauthfdsRequest);
            token = (Token) oauth2handler.getOauthToken(sessionId, "FDS");
            logger.info(oauthSuccess);
        }
        catch (IOException | OAuthSystemException | OAuthProblemException e)
        {
            logger.error(failedDocuments);
            throw new ApplicationException(oauthFailure + e.toString());
        }
        
        ResponseEntity<Document> response = null;
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.set(auth, bearer + token.getAccessToken());
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL);
        HttpEntity<MultiValueMap<String, Document>> requestEntity = new HttpEntity<>(parts, headers);
        logger.info(fdsRequest, Encode.forJava(requestEntity.toString()));
        logger.info(updateRequest);
        
        String uri = builder.toUriString() + "/" + documentId;
        try
        {
            logger.info("FDSRequest - Update Document, uri={}, requestHeader={}, requestBody={}", Encode.forJava(uri), Encode.forJava(requestEntity.getHeaders().toString()), Encode.forJava(requestEntity.getBody().toString()));
            response = (ResponseEntity<Document>) sendRequestFDS(uri, requestEntity, Document.class, HttpMethod.PUT);
        }
        catch (ResourceAccessException e)
        {
            try {
            	logger.error(app.rerFailure("SOCKET EXCEPTION CAUGHT - RETRYING THE UPDATE, document={}, error={}"), Encode.forJava(tempMapper.writeValueAsString(requestEntity.getBody().get(documents))), e);
            }
            catch (JsonProcessingException f) {
            	logger.error(errorMap, Encode.forJava(requestEntity.getBody().get(documents).toString()), f);
            }
            response = (ResponseEntity<Document>) sendRequestFDS(uri, requestEntity, Document.class, HttpMethod.PUT);
        }
        catch (HttpServerErrorException e)
        {
            try {
            	logger.error(app.rerFailure("TIMEOUT EXCEPTION CAUGHT - RETRYING THE UPDATE OF DOCUMENT, documents={}, error={}"), Encode.forJava(tempMapper.writeValueAsString(requestEntity.getBody().get(documents))), e);
            }
            catch (JsonProcessingException f) {
            	logger.error(errorMap, Encode.forJava(requestEntity.getBody().get(documents).toString()), f);
            }
            response = (ResponseEntity<Document>) sendRequestFDS(uri, requestEntity, Document.class, HttpMethod.PUT);
        }
        catch (Exception e)
        {
            logger.error(app.rerFailure("Failed to make FDS web service call - Update Document, error={}"), e);
            throw e;
        }
        logger.info(updateSuccess);
        return response;
        
    	
    }
    
    
    public FDSMultiPutResponse updateMultiDocuments(MultiValueMap<String, Object> parts, HttpHeaders headers, String sessionId) throws RestClientException, ApplicationException {
    	
    	Token token = null;
        try
        {
            logger.info(oauthfdsRequest);
            token = (Token) oauth2handler.getOauthToken(sessionId, "FDS");
            logger.info(oauthSuccess);
        }
        catch (IOException | OAuthSystemException | OAuthProblemException e)
        {
            logger.error(app.rerFailure("Failed to make FDS OAUTH Web Service Call - Update Multi Documents"));
            throw new ApplicationException(oauthFailure + e.toString());
        }
        
        ResponseEntity<FDSMultiPutResponse> response = null;

        headers.set(auth, bearer + token.getAccessToken());

        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL);
        
        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(parts, headers);
        logger.info(fdsRequest, Encode.forJava(requestEntity.toString()));
        logger.info(updateRequest);
        try
        {
        	String buildString=builder.toUriString();
            logger.info("FDSRequest - Update Multi Documents, uri={}, requestHeader={}, requestBody={}", buildString, Encode.forJava(requestEntity.getHeaders().toString()), Encode.forJava(String.valueOf(requestEntity.getBody())));
            response = (ResponseEntity<FDSMultiPutResponse>) sendRequestAutoEnrollment(builder.toUriString(), requestEntity, FDSMultiPutResponse.class, HttpMethod.PUT);
        } catch (Exception e) {
            logger.error(app.rerFailure("Failed to make FDS web service call - Update Multi Documents, error={}"), e);
            throw e;
        }
        
        return response.getBody();
    	
    	
    }
    
    public FDSMultiPostResponse createMultiDocuments(MultiValueMap<String, Object> parts, HttpHeaders headers, String sessionId) throws RestClientException, ApplicationException {
    	
    	Token token = null;
        try
        {
            logger.info(oauthfdsRequest);
            token = (Token) oauth2handler.getOauthToken(sessionId, "FDS");
            logger.info(oauthSuccess);
        }
        catch (IOException | OAuthSystemException | OAuthProblemException e)
        {
            logger.error(app.rerFailure("Failed to make FDS OAUTH Web Service Call - POST MULTI DOCUMENTS"));
            throw new ApplicationException(oauthFailure + e.toString());
        }
        
        ResponseEntity<FDSMultiPostResponse> response = null;
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.set(auth, bearer + token.getAccessToken());
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL);
        
        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(parts, headers);
        logger.info(fdsRequest, Encode.forJava(requestEntity.toString()));
        logger.info("Sending request to FDS - POST Multi Document");
        try
        {
        	String buildString=builder.toUriString();
            logger.info("FDSRequest - Create Document, uri={}, requestHeader={}, requestBody={}", buildString, Encode.forJava(requestEntity.getHeaders().toString()), Encode.forJava(String.valueOf(requestEntity.getBody())));
            response = (ResponseEntity<FDSMultiPostResponse>) sendRequestAutoEnrollment(builder.toUriString(), requestEntity, FDSMultiPostResponse.class, HttpMethod.POST);
        } catch (Exception e) {
            logger.error(app.rerFailure("Failed to make FDS web service call - POST MULTI DOCUMENTS, error={}"), e);
            throw e;
        }
        
        return response.getBody();
    	
    	
    }
    public ResponseEntity<Document> callFDSPutDocument(MultiValueMap<String, Document> parts, HttpHeaders headers, String documentId, String sessionId,
            Token token) throws RestClientException, JsonProcessingException
    {
    	
        ResponseEntity<Document> response = null;
        headers.set(auth, bearer + token.getAccessToken());
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL);
        HttpEntity<MultiValueMap<String, Document>> requestEntity = new HttpEntity<>(parts, headers);
        logger.info(fdsRequest, Encode.forJava(requestEntity.toString()));
        logger.info(updateRequest);
        
        String uri = builder.toUriString() + "/" + documentId;
        try
        {
            logger.info("FDSRequest - Update Document, uri={}, requestHeader={}, requestBody={}", Encode.forJava(uri), Encode.forJava(requestEntity.getHeaders().toString()), Encode.forJava(String.valueOf(requestEntity.getBody())));
            response = (ResponseEntity<Document>) sendRequestFDS(uri, requestEntity, Document.class, HttpMethod.PUT);
        }
        catch (ResourceAccessException e)
        {
            try {
            	logger.error(app.rerFailure("SOCKET EXCEPTION CAUGHT - RETRYING THE UPDATE, document={}, error={}"), Encode.forJava(tempMapper.writeValueAsString(requestEntity.getBody().get(documents))), e);
            }
            catch (JsonProcessingException f) {
            	logger.error(errorMap, Encode.forJava(requestEntity.getBody().get(documents).toString()), f);
            }
            response = (ResponseEntity<Document>) sendRequestFDS(uri, requestEntity, Document.class, HttpMethod.PUT);
        }
        catch (HttpServerErrorException e)
        {
            try {
            	logger.error(app.rerFailure("TIMEOUT EXCEPTION CAUGHT - RETRYING THE UPDATE OF DOCUMENT, documents={}, error={}"), Encode.forJava(tempMapper.writeValueAsString(requestEntity.getBody().get(documents))), e);
            }
            catch (JsonProcessingException f) {
            	logger.error(errorMap, Encode.forJava(requestEntity.getBody().get(documents).toString()), f);
            }
            response = (ResponseEntity<Document>) sendRequestFDS(uri, requestEntity, Document.class, HttpMethod.PUT);
        }
        catch (Exception e)
        {
            logger.error(app.rerFailure("Failed to make FDS web service call - Update Document, error={}"), e);
            throw e;
        }
        logger.info(updateSuccess);
        return response;
    }
    
    
    public FDSResponse getDocumentListSortCreated(String tin, String mpin, String fileName, String sessionId, Token token) throws RestClientException
    {
        try
        {
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL).queryParam(metaTIN, tin)
                    .queryParam(metaMPIN, mpin).queryParam(lowerspaceId,fdsCloudSpaceId).queryParam("sortby", "updated-date").queryParam(sortOrder, "desc");
            if (fileName != null && !fileName.equals(""))
            {
                builder.queryParam(metaFile, fileName);
            }
            logger.info(goTofdsForDocuments, builder);
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            headers.set(auth, bearer + token.getAccessToken());
            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<FDSResponse> response = (ResponseEntity<FDSResponse>) sendRequestFDS(builder.toUriString(), entity, FDSResponse.class, HttpMethod.GET);
            logger.info(getDocuments);
            return response.getBody();
        }
        catch (Exception e)
        {
            logger.error(app.rerFailure("Error processing documents, error={}"), e);
            throw e;
        }
    }
 
    public AutoenrollmentRequest getExistingFDSEmails(AutoenrollmentRequest autoenrollRequest) throws ApplicationException, RestClientException {
    	
    	 Token token = null;
    	 String sessionId = "AutoEnrollment_existingEmail";
    	 List<AutoenrollmentObj> updatedDocList = new ArrayList<>();
         
         try {
         	
         	for (AutoenrollmentObj doc : autoenrollRequest.getAutoenrollDocuments()) {
                try
                {
                    logger.info(oauthfdsRequest);
                    token = (Token) oauth2handler.getOauthToken(sessionId, "FDS");
                    logger.info(oauthSuccess);
                }
                catch (IOException | OAuthSystemException | OAuthProblemException e)
                {
                    logger.error(app.rerFailure("Failed to make FDS OAUTH Web Service Call - Get Existing FDS Emails"));
                    throw new ApplicationException(oauthFailure + e.toString());
                }
         		
         		try { 
             		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL)
                 			.queryParam(metaTIN, doc.getTin())
                            .queryParam(metaMPIN, doc.getMpin())
                            .queryParam("metadata.deliveryMethod", "E")
                            .queryParam("metadata.autoEdelUpdateInd", "N")
                            .queryParam(metaFile, doc.getFileName())
                            .queryParam(lowerspaceId,fdsCloudSpaceId)
                            .queryParam(sortOrder, "desc");
                     logger.info(goTofdsForDocuments, builder);
                     headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
                     headers.set(auth, bearer + token.getAccessToken());
                     HttpEntity<String> entity = new HttpEntity<>(headers);
                     logger.info(requestDocuments);
                     ResponseEntity<FDSResponse> response = (ResponseEntity<FDSResponse>) sendRequestFDS(builder.toUriString(), entity, FDSResponse.class, HttpMethod.GET);
                     logger.info(getDocuments);
                     
                     if (!response.getBody().getDocuments().isEmpty()) {
                    	 String mostRecentEmail = response.getBody().getDocuments().get(0).getMetadata().getProviderEmailId(); 
                    	 if (!doc.getProviderEmailId().equals(mostRecentEmail)) {
                    		 logger.info("Replaced emails, givenEmail={}, emailInFDS={}", doc.getProviderEmailId(), mostRecentEmail);
                    		 doc.setProviderEmailId(mostRecentEmail);
                    	 }
                     }
         		}
                catch (IndexOutOfBoundsException e) {
                	 logger.warn("No records found for existing email, using givenEmail={}", doc.getProviderEmailId());
                     updatedDocList.add(doc); 
                	 continue;
                 }
                updatedDocList.add(doc); 
                 
         	}
         	
         }
         catch (Exception e)
         {
             logger.error(app.rerFailure("Failed to make FDS web service call - Get Existing FDS Emails, trace=\n" + e.getStackTrace()));
             throw new ApplicationException(fdsCallFail + e.toString());
         }
        autoenrollRequest.setAutoenrollDocuments(updatedDocList);
    	return autoenrollRequest;
    }
    public  List<Document> getDocById(List<String> docIds) throws ApplicationException, RestClientException {
    	
   	 Token token = null;
   	 String sessionId = "AutoEnrollment_Id";
   	 List<Document> fdsResponses = new ArrayList<>();
   	 
        try
        {
            logger.info(oauthfdsRequest);
            token = (Token) oauth2handler.getOauthToken(sessionId, "FDS");
            logger.info(oauthSuccess);
        }
        catch (IOException | OAuthSystemException | OAuthProblemException e)
        {
            logger.error(app.rerFailure("Failed to make FDS OAUTH Web Service Call - Get Document by Id"));
            throw new ApplicationException(oauthFailure + e.toString());
        }
        
        try {
       	 for (String docId: docIds) {
             	
          		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL)
             			.queryParam("id", docId);
                 logger.info(goTofdsForDocuments, builder);
                 headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
                 headers.set(auth, bearer + token.getAccessToken());
                 HttpEntity<String> entity = new HttpEntity<>(headers);
                 logger.info("Sending request to FDS - Get Document by Id");
                 ResponseEntity<Document> response = (ResponseEntity<Document>) sendRequestFDS(builder.toUriString(), entity, Document.class, HttpMethod.GET);
                 logger.info(getDocuments);
                 fdsResponses.add(response.getBody());
       	 }
            return fdsResponses;
        	
        }
        catch (Exception e)
        {
            logger.error(app.rerFailure("Failed to make FDS web service call - Get Document by Id"));
            throw new ApplicationException(fdsCallFail + e.toString());
        
}
}
}