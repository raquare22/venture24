package com.optum.providerpreferences.rs.handler;


import org.apache.cxf.jaxrs.utils.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.client.*;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPostResponse;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;

import kong.unirest.HttpRequestWithBody;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;

public class ServiceBase {

	protected int numRetries = 6;
	protected long[] timeToWaitMsArr = {60000, 30000, 5000, 1000, 500, 50, 20};
	protected int numRetriesAutoEnroll = 12;
	protected long[] timeToWaitMsArrAutoEnroll = {60000*60, 60000*30, 60000*60, 60000*30, 60000*20, 60000*10, 60000, 30000, 5000, 1000, 500, 50, 20};
	

	private static final Logger LOGGER = LogManager.getLogger(ServiceBase.class);
	
	public static final String HEADER_ACCEPT = "Accept";
	
	private ApplicationUtil app = new ApplicationUtil();

    @Autowired
    private RestTemplate restTemplate;

	@Autowired
	RestTemplate restTemplateAutoEnroll;

	@Autowired
	protected Oauth2Handler oauth2handler;

    private static String successRequest = "Request successful after retries statusCode={}, responseBody={}";
    private static String exceptionRequest = "sendRequest caught exception, throwing error not retrying: uri={}, responseEntity={}, error={}";
    private static String requestRetry = "Request retry: requestBody={}, retryCount={}";
    private static String successRequest2 = "Request successful: responseEntity={}";
    private static String firstRequestFail = "First request failed, retrying";
    private static String retryCountStr = "retryCount={}";
    private static String timeToWait = "time to wait={}";
    private static String requestFailed = "Request failed after retries with error code={}, request={}";
	private static String requestFailedD = "lezp Request failed after retries with error code={}, request={} responsebody={}, responsebody={}";
	private static String serviceCallError = "ERROR DURING SERVICE CALL: uri={}, requestEntity={}, error=";
	private static String serviceCallError2 = "ERROR DURING SERVICE CALL: uri={}, requestEntity={}, error={}";
	private static String auth="Authorization";
    private static String bearer="Bearer ";
    private static String oauthFailure="Failed to make FDS OAUTH service call: ";
    private static Integer created = HttpStatus.CREATED.value();
    private static Integer ok = HttpStatus.OK.value();
    private static Integer unauthorized = HttpStatus.UNAUTHORIZED.value();
    private static String INVALID_GRANT = "invalid_grant";
    private static String DOCUMENT_NOT_FOUND = "document not found";
    private static String DETAILS = "details";
    private static String SEND_REQUEST_LOG = "sendRequest caught exception, retrying: uri={}, responseEntity={}, error={}.";
	
	public ResponseEntity<?> sendRequest(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod) throws ApplicationException {
		
		ResponseEntity<?> responseEntity = null;
		
		try {
			
			responseEntity = retryRequest(uri, requestEntity, clazz, httpMethod);

			if (responseEntity != null && (HttpStatus.OK.equals(responseEntity.getStatusCode()) || HttpStatus.CREATED.equals(responseEntity.getStatusCode()))) {
//				LOGGER.info(successRequest2, responseEntity);
				return responseEntity;
			}
			
			LOGGER.info(firstRequestFail);
			
			int retryCount = numRetries;
			while ((responseEntity == null || !HttpStatus.OK.equals(responseEntity.getStatusCode()) || !HttpStatus.CREATED.equals(responseEntity.getStatusCode())) && (retryCount-- > 0)) {
				
				LOGGER.info(retryCountStr, retryCount);
				LOGGER.info(timeToWait, timeToWaitMsArr[retryCount]);
				
				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				responseEntity = retryRequest(uri, requestEntity, clazz, httpMethod);
				LOGGER.warn(requestRetry, Encode.forJava(requestEntity.toString()), retryCount);
			}
			
			// if responseEntity is null, throw a NullPointerException
			Objects.requireNonNull(responseEntity);
			
			if (!HttpStatus.OK.equals(responseEntity.getStatusCode()) || !HttpStatus.CREATED.equals(responseEntity.getStatusCode())) {
				LOGGER.warn(requestFailed, responseEntity.getStatusCode(), Encode.forJava(requestEntity.toString()));
				return responseEntity;
			}

//			LOGGER.info(successRequest, responseEntity.getStatusCode(), responseEntity.getBody());
			return responseEntity;
		}
		catch (Exception e) {
			LOGGER.warn(serviceCallError, Encode.forJava(uri), Encode.forJava(requestEntity.toString()), ExceptionUtils.getStackTrace(e));
		}
		return responseEntity;
		
	}
	
	public ResponseEntity<?> sendDigiSecRequest(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod) {
		
		List<HttpStatus> digiSecPass = new ArrayList<HttpStatus>();
		digiSecPass.add(HttpStatus.OK);
		digiSecPass.add(HttpStatus.CREATED);
		digiSecPass.add(HttpStatus.BAD_REQUEST);
		
		ResponseEntity<?> responseEntity = null;
		
		try {
			
			responseEntity = retryDigiSecRequest(uri, requestEntity, clazz, httpMethod);

			if ((responseEntity == null && uri.contains("paa")) ||
				(responseEntity != null && digiSecPass.contains(responseEntity.getStatusCode()))) {
//				LOGGER.info(successRequest2, responseEntity);
				return responseEntity;
			}
			
			LOGGER.info(firstRequestFail);
			
			int retryCount = numRetries;
			
			while ((responseEntity == null && !uri.contains("paa")) || 
					(responseEntity != null && !digiSecPass.contains(responseEntity.getStatusCode()) && (retryCount-- > 0))
					 ) {
				
				LOGGER.info(retryCountStr, retryCount);
				LOGGER.info(timeToWait, timeToWaitMsArr[retryCount]);
				
				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				responseEntity = retryDigiSecRequest(uri, requestEntity, clazz, httpMethod);
				LOGGER.warn(requestRetry, requestEntity.toString(), retryCount);
			}
			
			if (checkDigiSecResponseEntity(responseEntity, digiSecPass, uri))  {
				String statusCode = responseEntity != null ? responseEntity.getStatusCode().toString() : "no Status code";
				LOGGER.error(requestFailed, statusCode, Encode.forJava(requestEntity.toString()));
				return responseEntity;
			}

//			LOGGER.info(successRequest, responseEntity.getStatusCode(), responseEntity.getBody());
			return responseEntity;
		}
		catch (ResourceAccessException | HttpServerErrorException e) {
			LOGGER.error(serviceCallError, Encode.forJava(uri), Encode.forJava(requestEntity.toString()), ExceptionUtils.getStackTrace(e));
			throw(e);
		}
		
	}

	public ResponseEntity<?> sendRequestFDS(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod) {
		
		ResponseEntity<?> responseEntity = null;
		
		try {
			
			responseEntity = retryRequestFDS(uri, requestEntity, clazz, httpMethod);

			if (checkFDSResponseEntity(responseEntity)) {
//				LOGGER.info(successRequest2, responseEntity);
				return responseEntity;
			}
			
			LOGGER.info(firstRequestFail);
			
			int retryCount = numRetries;
			while (!checkFDSResponseEntity(responseEntity) && (retryCount-- > 0)) {
				
				LOGGER.info(retryCountStr, retryCount);
				LOGGER.info(timeToWait, timeToWaitMsArr[retryCount]);
				
				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				responseEntity = retryRequestFDS(uri, requestEntity, clazz, httpMethod);
				LOGGER.warn(requestRetry, Encode.forJava(requestEntity.toString()), retryCount);
			}
			
			// if responseEntity is null, throw a NullPointerException
			Objects.requireNonNull(responseEntity);
			
			if (!HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				LOGGER.error(requestFailed, responseEntity.getStatusCode(), Encode.forJava(requestEntity.toString()));
				return responseEntity;
			}

//			LOGGER.info(successRequest, responseEntity.getStatusCode(), responseEntity.getBody());
			return responseEntity;
		} catch (HttpClientErrorException e) {
			Token token = null;
			if (e.getStatusCode().equals(HttpStatus.BAD_REQUEST) && e.getResponseBodyAsString().contains(INVALID_GRANT)) {
				try {
					LOGGER.info("Token expired, retrying token call");
		            token = (Token) oauth2handler.getOauthToken("FDS_OAUTH_RETRY", "FDSCLOUD");
		            HttpHeaders oldHeaders = requestEntity.getHeaders();
		            HttpHeaders headers = new HttpHeaders();
		            headers.putAll(oldHeaders);
		            headers.set(auth, bearer + token.getAccessToken());
		            HttpEntity<?> newRequest = new HttpEntity(requestEntity.getBody(), headers);
					return sendRequestFDS(uri, newRequest, clazz, httpMethod);
				} catch (ApplicationException | IOException | OAuthSystemException | OAuthProblemException | NullPointerException ex) {
					throw(e);
				}
			} else {
				throw(e);
			}
		} catch (Exception e) {
			LOGGER.error(serviceCallError, Encode.forJava(uri), Encode.forJava(requestEntity.toString()), ExceptionUtils.getStackTrace(e));
			throw(e);
		}
		
	}

	
	public ResponseEntity<?> sendRequestAutoEnrollment(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod) throws ApplicationException {
//		LOGGER.info("ENTER -- sendRequestAutoEnrollment");
		
		ResponseEntity<?> responseEntity = null;
		
		try {
			
			responseEntity = retryRequestAutoEnroll(uri, requestEntity, clazz, httpMethod);

			if (responseEntity != null && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
//				LOGGER.info(successRequest2, responseEntity);
				return responseEntity;
			} 
			LOGGER.info(firstRequestFail);
			
			int retryCount = numRetriesAutoEnroll;
			while ((responseEntity == null || !HttpStatus.OK.equals(responseEntity.getStatusCode())) && (retryCount-- > 0)) {
				
				LOGGER.info(retryCountStr, retryCount);
				// extended time for autoenrollment
				LOGGER.info(timeToWait, timeToWaitMsArrAutoEnroll[retryCount]);
				
				try {
					synchronized(this) {
						this.wait(timeToWaitMsArrAutoEnroll[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				
				responseEntity = retryRequestAutoEnroll(uri, requestEntity, clazz, httpMethod);
				LOGGER.warn(requestRetry, requestEntity.toString(), retryCount);
			}
			
			// if responseEntity is null, throw a NullPointerException
			Objects.requireNonNull(responseEntity);
			if (!HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				LOGGER.error(requestFailed, responseEntity.getStatusCode(), Encode.forJava(requestEntity.toString()));
				return responseEntity;
			}

//			LOGGER.info(successRequest, responseEntity.getStatusCode(), responseEntity.getBody());
			return responseEntity;
		} catch (HttpClientErrorException e) {
			Token token = null;
			
			if (!e.getStatusCode().equals(HttpStatus.BAD_REQUEST) && !e.getResponseBodyAsString().contains(INVALID_GRANT)) {
				throw e;
			}
			try {
				LOGGER.info("Token expired, retrying token call");
	            token = (Token) oauth2handler.getOauthToken("FDS_OAUTH_RETRY", "FDS");
	            HttpHeaders oldHeaders = requestEntity.getHeaders();
	            HttpHeaders headers = new HttpHeaders();
	            headers.putAll(oldHeaders);
	            headers.set(auth, bearer + token.getAccessToken());
	            HttpEntity<?> newRequest = new HttpEntity(requestEntity.getBody(), headers);
				return sendRequestFDS(uri, newRequest, clazz, httpMethod);
			} catch (ApplicationException | IOException | OAuthSystemException | OAuthProblemException | NullPointerException ex) {
				throw(e);
			}
		} catch (Exception e) {
			LOGGER.error(serviceCallError, Encode.forJava(uri), Encode.forJava(requestEntity.toString()), ExceptionUtils.getStackTrace(e));
			throw(e);
		}
		
	}
	
	public HttpResponse<JsonNode> sendUnirestRequest(HttpRequestWithBody requestEntity) throws ApplicationException {
//		LOGGER.info("ENTER -- sendUnirestRequest");
		
		HttpResponse<JsonNode> responseEntity;
		
		try {
			
			responseEntity = retryUnirestRequest(requestEntity);
			
			if (checkUnirestResponseEntity(responseEntity)) {
//				LOGGER.info(successRequest2, responseEntity.getBody());
				return responseEntity;
			} 
			
			LOGGER.info(firstRequestFail);
			
			int retryCount = numRetries;
			while ((responseEntity == null || checkUnirestResponseEntity(responseEntity)) && (retryCount-- > 0)) {
				
				if (responseEntity != null && unauthorized.equals(responseEntity.getStatus()) && responseEntity.getBody().toString().contains("Expired JWT")) {
					Token refreshToken = new Token();
		            try {
		            	refreshToken = (Token) oauth2handler.getOauthTokenRefresh("retryUnirestRequest", "FDSCLOUD");
		            }
		            catch (IOException | OAuthSystemException | OAuthProblemException e)
		            {
		                LOGGER.error("sendRequestAutoEnrollment");
		                throw new ApplicationException(oauthFailure + e.toString());
		            }
		            
					//add token to header
		            requestEntity.headerReplace("fds-authorization", refreshToken.getAccessToken());
				}
				
				LOGGER.info(retryCountStr, retryCount);
				LOGGER.info(timeToWait, timeToWaitMsArr[retryCount]);
				
				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				
				responseEntity = retryUnirestRequest(requestEntity);
				LOGGER.warn(requestRetry, requestEntity.toString(), retryCount);
			}
			
//			 if responseEntity is null, throw a NullPointerException
			Objects.requireNonNull(responseEntity);
			
			if (!ok.equals(responseEntity.getStatus()) && !created.equals(responseEntity.getStatus()) && 
					(responseEntity != null && 
					!responseEntity.getBody().getObject().get(DETAILS).toString().toLowerCase().contains(DOCUMENT_NOT_FOUND))
					) {
				LOGGER.warn(requestFailedD, responseEntity.getStatus(), requestEntity, responseEntity.getBody().toString() + "Resppmse emtity = "+ responseEntity.toString());
				return responseEntity;
			}

//			LOGGER.info(successRequest, responseEntity.getStatus(), responseEntity.getBody());
			return responseEntity;
		}
		catch (Exception e) {
			LOGGER.warn(serviceCallError2, requestEntity.getUrl(), requestEntity.toString(), ExceptionUtils.getStackTrace(e));
			responseEntity = null;
			return responseEntity;
		}
		
	}
	
	public HttpResponse<JsonNode> retryUnirestRequest(HttpRequestWithBody requestEntity){
		
		HttpResponse<JsonNode> retryResponse = null;
		try {
			retryResponse = requestEntity.asJson();
		} catch (ResourceAccessException | HttpClientErrorException | HttpServerErrorException e) {
			LOGGER.warn("sendUnirestRequest caught exception, retrying: uri={}, responseEntity={}, error={}.", requestEntity.getUrl(), retryResponse, e.getMessage());
		} catch (RestClientException e) {
			LOGGER.warn(exceptionRequest, requestEntity.getUrl(), retryResponse, ExceptionUtils.getStackTrace(e));
		} catch (Exception e) {
			LOGGER.warn(exceptionRequest, requestEntity.getUrl(), retryResponse, ExceptionUtils.getStackTrace(e));
		}
		
		return retryResponse;
		
	}
	
	public ResponseEntity<?> retryRequest(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod){
		
		ResponseEntity<?> retryResponse = null;
		try {
			validateUri(uri);
			retryResponse = restTemplate.exchange(uri, httpMethod, requestEntity, clazz);
		} catch (HttpServerErrorException e) {
			// If PES API receives invalid corporateMpin, then it returns 500 null, and should not be retried
			if (e.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR) && e.getStatusText() == null) {
				LOGGER.error(exceptionRequest, Encode.forJava(uri), retryResponse, ExceptionUtils.getStackTrace(e));
				throw(e);
			} else {
				LOGGER.error(SEND_REQUEST_LOG, Encode.forJava(uri), retryResponse, ExceptionUtils.getStackTrace(e));
			}
		} catch (ResourceAccessException | HttpClientErrorException e) {
			LOGGER.warn(SEND_REQUEST_LOG, Encode.forJava(uri), retryResponse, e.getMessage());
		} catch (RestClientException e) {
			LOGGER.error(exceptionRequest, Encode.forJava(uri), retryResponse, ExceptionUtils.getStackTrace(e));
		} catch (Exception e) {
			LOGGER.error(exceptionRequest, Encode.forJava(uri), retryResponse, ExceptionUtils.getStackTrace(e));
			throw(e);
		}
		
		return retryResponse;
		
	}
	
	public ResponseEntity<?> retryRequestFDS(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod){
		
		ResponseEntity<?> retryResponse = null;
		try {
//			validateUri(uri);
			String sanitizedUri = org.owasp.encoder.Encode.forUriComponent(uri);
			retryResponse = restTemplate.exchange(sanitizedUri, httpMethod, requestEntity, clazz);
		} catch (HttpServerErrorException e) {
			// If PES API receives invalid corporateMpin, then it returns 500 null, and should not be retried
			if (e.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR) && e.getStatusText() == null) {
				LOGGER.error(exceptionRequest, Encode.forJava(uri), retryResponse, ExceptionUtils.getStackTrace(e));
				throw(e);
			} else {
				LOGGER.error(SEND_REQUEST_LOG, Encode.forJava(uri), retryResponse, ExceptionUtils.getStackTrace(e));
			}
		} catch (HttpClientErrorException e) {
			if (e.getStatusCode().equals(HttpStatus.BAD_REQUEST) && e.getResponseBodyAsString().contains(INVALID_GRANT)) {
				LOGGER.error("sendRequest caught invalid_grant exception, oauth token expired, retrying: uri={}, responseEntity={}, error={}.",
						Encode.forJava(uri), retryResponse, ExceptionUtils.getStackTrace(e));
				throw(e);
			} else {
				LOGGER.error(SEND_REQUEST_LOG, Encode.forJava(uri), retryResponse, ExceptionUtils.getStackTrace(e));
			}
		} catch (ResourceAccessException e) {
			LOGGER.error(SEND_REQUEST_LOG, Encode.forJava(uri), retryResponse, ExceptionUtils.getStackTrace(e));
		} catch (RestClientException e) {
			LOGGER.error(exceptionRequest, Encode.forJava(uri), retryResponse, ExceptionUtils.getStackTrace(e));
		} catch (Exception e) {
			LOGGER.error(exceptionRequest, Encode.forJava(uri), retryResponse, ExceptionUtils.getStackTrace(e));
			throw(e);
		}
		
		return retryResponse;
		
	}
	
	public ResponseEntity<?> retryRequestAutoEnroll(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod){
		
		ResponseEntity<?> retryResponse = null;
		try {
			retryResponse = restTemplateAutoEnroll.exchange(uri, httpMethod, requestEntity, clazz);
			
		} catch (HttpServerErrorException e ) {
			LOGGER.error("Error gateway check, error={}", e.getStatusCode());
			if (e.getStatusCode().equals(HttpStatus.GATEWAY_TIMEOUT)) {
				List<String> gatewayInserted = new ArrayList<String>();
				gatewayInserted.add("Documents sent to FDS to be processed");
				FDSMultiPostResponse gatewayResponse = new FDSMultiPostResponse();
				gatewayResponse.setInserted(gatewayInserted);
				retryResponse = new ResponseEntity<>(gatewayResponse, HttpStatus.OK);
				return retryResponse;
			}
			else {
				LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
				throw(e);
			}
		} catch (HttpClientErrorException e) {
			if (e.getStatusCode().equals(HttpStatus.BAD_REQUEST) && e.getResponseBodyAsString().contains(INVALID_GRANT)) {
				LOGGER.error("sendRequest caught invalid_grant exception, oauth token expired, retrying: uri={}, responseEntity={}, error={}.",
						uri, retryResponse, ExceptionUtils.getStackTrace(e));
				throw(e);
			} else {
				LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, ExceptionUtils.getStackTrace(e));
			}
		} catch (ResourceAccessException e) {
			LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, ExceptionUtils.getStackTrace(e));
		} catch (RestClientException e) {
			LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
			throw(e);
		} catch (Exception e) {
			LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
			throw(e);
		}
		
		return retryResponse;
		
	}
	
	public ResponseEntity<?> retryDigiSecRequest(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod){
		
		ResponseEntity<?> retryResponse = null;
		try {
			retryResponse = restTemplate.exchange(uri, httpMethod, requestEntity, clazz);
		} catch (HttpClientErrorException e) {
			// If PES API receives invalid corporateMpin, then it returns 500 null, and should not be retried
			if (e.getStatusCode().equals(HttpStatus.BAD_REQUEST) || uri.contains("paa")) {
//				LOGGER.warn("sendRequest caught exception, not retrying: uri={}, responseEntity={}, error={}.", uri, retryResponse, e.getMessage());
				return retryResponse;
			} 
			LOGGER.error("HttpClientErrorException -> sendRequest caught exception, retrying: uri={}, requestEntity={}, responseEntity={}, error={}.", uri, requestEntity.getBody().toString(), retryResponse, e.getMessage());
		}  catch (ResourceAccessException e) {
			if (uri.contains("paa")) {
				return retryResponse;
			}
			LOGGER.error("ResourceAccessException -> sendRequest caught exception, retrying: uri={}, requestEntity={}, responseEntity={}, error={}.", uri, requestEntity.getBody().toString(), retryResponse, e.getMessage());
		} catch (RestClientException e) {
			if (uri.contains("paa")) {
				return retryResponse;
			}
			LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
			
		} catch (Exception e) {
			if (uri.contains("paa")) {
				return retryResponse;
			}
			LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
			throw(e);

		}
		
		return retryResponse;
		
	}
	
	private static Boolean checkDigiSecResponseEntity(ResponseEntity<?> responseEntity, List<HttpStatus> digiSecPass, String uri) {
		if ((responseEntity == null && !uri.contains("paa")) || 
		(responseEntity != null && !digiSecPass.contains(responseEntity.getStatusCode()))) {
			return true;
		}
		return false;
	}
	
	private static Boolean checkFDSResponseEntity(ResponseEntity<?> responseEntity) {
		if (responseEntity != null && (HttpStatus.OK.equals(responseEntity.getStatusCode()) || HttpStatus.CREATED.equals(responseEntity.getStatusCode()))) {
			return true;
		}
		return false;
	}
	
	private static Boolean checkUnirestResponseEntity(HttpResponse<JsonNode> responseEntity) {
		if (responseEntity != null && (ok.equals(responseEntity.getStatus()) || created.equals(responseEntity.getStatus()))) {
			return true;
		}
		else if ((responseEntity != null && responseEntity.getBody() != null && responseEntity.getBody().getObject().get(DETAILS) != null && 
				responseEntity.getBody().getObject().get(DETAILS).toString().toLowerCase().contains(DOCUMENT_NOT_FOUND))) {
			return true;
		}
		return false;
	}

	private void validateUri(String userUri){
		URI uri;
		try {
			uri = new URI(userUri);
		//Only http/https
		String scheme = uri.getScheme();
		if (scheme == null ||
				(!scheme.equalsIgnoreCase("http") && !scheme.equalsIgnoreCase("https"))) {
			throw new IllegalArgumentException("Only HTTP and HTTPS are allowed");
		}

		String host = uri.getHost();
		if (host == null) {
			throw new IllegalArgumentException("URL must have a valid host");
		}

			InetAddress inetAddress = InetAddress.getByName(host);
		if (inetAddress.isAnyLocalAddress() || inetAddress.isLoopbackAddress() || inetAddress.isSiteLocalAddress() || isPrivateIPv6(inetAddress)){
			throw new IllegalArgumentException("Requests to internal network address are blocked");
		}
		} catch (URISyntaxException | IllegalArgumentException | IOException e) {
			throw new IllegalArgumentException("Invalid URL: " + e.getMessage());
		}
	}

	private boolean isPrivateIPv6(InetAddress inetAddress) {
		return inetAddress.getHostAddress().startsWith("fd") || inetAddress.getHostAddress().startsWith("fe80:");
	}

}