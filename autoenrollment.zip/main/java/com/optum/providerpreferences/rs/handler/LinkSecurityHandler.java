/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.handler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.linksecurity.PSMRequest;
import com.optum.providerpreferences.rs.model.linksecurity.PSMResponse;
import com.optum.providerpreferences.rs.model.linksecurity.User;

/**
 * This handler is used to call Link Security GetUserProfiles service to retrieve a summary of a user’s security profile
 * 
 * @author Provider Paperless Letters
 */
@Component
public class LinkSecurityHandler extends ServiceBase
{

    @Autowired
    HttpHeaders headers = new HttpHeaders();

    @Value("${PSM_URL}")
    private String PSM_URL;

    private static final Logger logger = LogManager.getLogger(LinkSecurityHandler.class);

    /**
     * Makes RESTful API call to Link Security 'profiles' endpoint
     * 
     * @param optumUUID
     * @param sessionId
     * @return List of User Profiles
     * @throws ApplicationException
     */
    public List<User> getUserProfiles(String optumUUID, String sessionId) throws ApplicationException
    {

        Token token = null;
        try
        {
            token = (Token) oauth2handler.getOauthToken(sessionId, "PSM");
        }
        catch (Exception e)
        {
            logger.error("Failed to retrieve OAuth Token for LINK/PSM");
            throw new ApplicationException("Failed to retrieve OAuth Token for LINK/PSM");
        }
         UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(PSM_URL);

        headers.set("Authorization", "Bearer " + token.getAccessToken());
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        PSMRequest request = new PSMRequest();
        request.setOptumUuid(optumUUID);
        request.setSource("NDB");
        request.setVerifySource(false);

        HttpEntity<PSMRequest> requestEntity = new HttpEntity<>(request, headers);

        logger.info("Sending request to PSM - User Profiles");
        ResponseEntity<PSMResponse> response = null;
        try
        {
            response = (ResponseEntity<PSMResponse>) sendRequest(builder.toUriString(), requestEntity, PSMResponse.class, HttpMethod.POST);
        }
        catch (Exception e)
        {
            logger.error("ERROR WITH PSM - USER PROFILES WEB SERVICE CALL");
            throw new ApplicationException("WEB SERVICE CALL FAILURE - PSM USER PROFILES");
        }
        logger.info("Response recieved from PSM - User Profiles");
        List<User> users = response.getBody().getUsers();
        List<User> updatedUsers = new ArrayList<>();

        for (int i = 0; i < users.size(); i++)
        {
            // Add additional ("TE").equals(users.get(i).getAccountType()) for
            // testing
            if (("PO").equals(users.get(i).getAccountType()) && ("A").equals(users.get(i).getStatusCode()) && users.get(i).getRespOrgMpin() != null)
            {
                updatedUsers.add(users.get(i));
            }
        }

        if (updatedUsers.isEmpty())
        {
            logger.error("No users found for given UUID - LINK/PSM");
            throw new ApplicationException("Error: LINK PSM.  No users found for given UUID");
        }

        return updatedUsers;
    }

}
