package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.pes.PESCorpmpinRequest;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import java.io.IOException;
import java.util.Objects;

@Component
public class PESCorpMpinHandler extends ServiceBase{
    private static final Logger logger = LoggerFactory.getLogger(PESCorpMpinHandler.class);

    @Autowired
    HttpHeaders headers;

    @Autowired
    RestTemplate client;

    @Value("${PES_CORPMPIN_CALL_URL}")
    protected String pesCorpMpinUrl;

    private Token token = null;

    public Token getToken()
    {
        return token;
    }

    public void setToken(Token token)
    {
        this.token = token;
    }

    public String getCorpMpin(String tin) throws ApplicationException {
        logger.info("PESCorpMpinHandler --> ENTER getCorpMpin");

        try {

            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(pesCorpMpinUrl);
            String uri = builder.toUriString();

            PESCorpmpinRequest corpmpinrequest = new PESCorpmpinRequest(tin);
            LinkedMultiValueMap<String, String> searchParams = new LinkedMultiValueMap<>();
            searchParams.add("tax-id-nbr", corpmpinrequest.getTaxIdNumber());
            searchParams.add("app-nm", corpmpinrequest.getAppName());
            searchParams.add("attribute-set", corpmpinrequest.getAttributeSet());
            searchParams.add("count", corpmpinrequest.getCount());

            HttpEntity<?> requestEntity = new HttpEntity<>(searchParams, headers);
            logger.info("Sending request to PES - requestEntity={}, uri={}", Encode.forJava(requestEntity.toString()), uri);

            ResponseEntity<String> response = (ResponseEntity<String>) sendRequest(uri, requestEntity, String.class, HttpMethod.POST);

            String corpmpin = xmlResponseParser(Objects.requireNonNull(response.getBody()));
            logger.info("corpmpin={}", Encode.forJava(corpmpin));
            logger.info("PESCorpMpinHandler --> EXIT getCorpMpin");
            return corpmpin;

        } catch (Exception e) {
            throw new ApplicationException(e.toString());
        }

    }

    public String xmlResponseParser(String response){
        String corpMPIN = null;
        if(response.contains("<corpMPIN>")){
            corpMPIN = response.substring(response.indexOf("<corpMPIN>")+10,response.indexOf("</corpMPIN>"));
        }
        return corpMPIN;
    }

    public void getPESToken() throws IOException, OAuthSystemException, OAuthProblemException, ApplicationException {
        try
        {
            setToken((Token)oauth2handler.getOauthToken("PDO", "PES_CORPMPIN"));

            int retryCount = numRetries;
            while (token == null && (retryCount-- > 0)) {

                logger.info("retryCount={}", retryCount);
                logger.info("time to wait={}", timeToWaitMsArr[retryCount]);

                try {
                    synchronized(this) {
                        this.wait(timeToWaitMsArr[retryCount]);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                setToken((Token) oauth2handler.getOauthToken("PDO", "PES_CORPMPIN"));
                logger.warn("NDB token request retry: retryCount={}", retryCount);
            }

        }
        catch (IOException | OAuthSystemException | OAuthProblemException | ApplicationException e)
        {
            logger.error("Could not retrieve OAuth Token - PES_CORPMPIN, error:{}.", ExceptionUtils.getStackTrace(e));
            throw e;
        }
        headers.set("Authorization", "bearer " + getToken().getAccessToken());
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
    }

}