package com.optum.providerpreferences.rs.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPutResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinResponse;
import com.optum.providerpreferences.rs.service.OptOutService;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;

@RestController
@RequestMapping("/api/optout/v1")
public class OptOutController {

	@Autowired
	OptOutService optOutService;
	
    @Autowired
    FDSHandler fdsHandler;
    
    @Autowired
    ObjectMapper mapper;
    
    private ApplicationUtil app = new ApplicationUtil();

    private static final Logger LOGGER = LogManager.getLogger(OptOutController.class);


    @PostMapping(path = "/tins")
    @ResponseBody
    public OptOutTinResponse getTinsByCorpMpin(@RequestBody OptOutTinRequest tinRequest) throws ApplicationException {
    	LOGGER.info("Invoking getTinsFromCorpMpin, optOutTinRequest={}", Encode.forJava(tinRequest.toString()));
    	
    	try {
    		return optOutService.getTins(tinRequest);
    	} catch (Exception e) {
    		LOGGER.error("Error getting tins from corpMpin, pesTinRequest={}, error={}", Encode.forJava(tinRequest.toString()), ExceptionUtils.getStackTrace(e));
    		throw new ApplicationException("Error at getTinsByCorpMpin: " + e.toString());
    	}
    }
    
    
    @PostMapping(path = "/update")
    @ResponseBody
    public FDSMultiPutResponse updateMultiDocuments(@RequestBody OptOutRequest optOutRequest, @RequestHeader HttpHeaders headers, HttpServletRequest requestContext) throws ApplicationException {
    	LOGGER.info("Invoking updateMultiDocuments, optOutRequest={}, headers={}", Encode.forJava(optOutRequest.toString()), Encode.forJava(headers.toString()));
    	
    	try {
        	return optOutService.updateOptOutDocuments(optOutRequest, headers);    		
    	} catch (Exception e) {

    		LOGGER.error("Error updating opt out documents, e={}", ExceptionUtils.getStackTrace(e));
    		throw new ApplicationException("Error at updateMultiDocuments: " + e.toString());
    	}
    	
    }
    
    @PostMapping(path = "/getCloud")
    @ResponseBody
    public FDSCloudGETResponse getFDSCloudDocument(@RequestBody FDSCloudRequest fdsCloudRequest, @RequestHeader HttpHeaders headers, HttpServletRequest requestContext) throws ApplicationException {
    	LOGGER.info("Invoking getFDSCloudDocument, fdsCloudRequest={}, headers={}", Encode.forJava(fdsCloudRequest.toString()), Encode.forJava(headers.toString()));
    	
    	
    	FDSCloudGETResponse response = new FDSCloudGETResponse();
		
		if (!Optional.ofNullable(fdsCloudRequest.getRequest().get("searchTerms")).equals(null)) {
			response = optOutService.getOptOutAuditLog("FDSCloudGET", fdsCloudRequest);
		}
		
		return response;
    	
    }
    
    @PostMapping(path = "/getCloudDocument")
    @ResponseBody
    public OptOutFDSCloudDocument getFDSCloudDocumentId(@RequestBody FDSCloudRequest fdsCloudRequest, @RequestHeader HttpHeaders headers, HttpServletRequest requestContext) throws ApplicationException, IOException {
    	LOGGER.info("Invoking getFDSCloudDocumentId, fdsCloudRequest={}, headers={}", Encode.forJava(fdsCloudRequest.toString()), Encode.forJava(headers.toString()));
    	
    	
    	OptOutFDSCloudDocument response = new OptOutFDSCloudDocument();
		
    	if (!Optional.ofNullable(fdsCloudRequest.getRequest()).equals(null) && !Optional.ofNullable(fdsCloudRequest.getDocumentId()).equals(null)) {
			response = optOutService.getFDSCloudDocument("FDSCloudGETDocumentId", fdsCloudRequest);
		}
		
		return response;
    	
    }
    
    
    
    @PostMapping(path = "/addCloud")
    @ResponseBody
    public Map<String, Object> addFDSCloudDocument(@RequestBody FDSCloudRequest fdsCloudRequest, @RequestHeader HttpHeaders headers, HttpServletRequest requestContext) throws ApplicationException {
    	LOGGER.info("Invoking addFDSCloudDocument, fdsCloudRequest={}, headers={}", Encode.forJava(fdsCloudRequest.toString()), Encode.forJava(headers.toString()));
    	
    	
    	Map<String, Object> responseMap = new HashMap<String, Object>();	
		
		if (!Optional.ofNullable(fdsCloudRequest.getRequest()).equals(null)) {
			ResponseEntity<OptOutFDSCloudPOSTResponse> response = optOutService.addOptOutAuditLog("FDSCloudPOST", fdsCloudRequest);
			try {
				responseMap = mapper.readValue(response.getBody().toString(), Map.class);
			}
			catch (IOException e) {
				LOGGER.error("addFDSCloudDocument -> Error updating record {}, error={}", Encode.forJava(fdsCloudRequest.getDocumentId()), ExceptionUtils.getStackTrace(e));
				responseMap.put("error", e.getMessage());
			}
		}
		
		return responseMap;
    	
    }
    
    @PostMapping(path = "/updateCloud")
    @ResponseBody
    public Map<String, Object> updateFDSCloudDocument(@RequestBody FDSCloudRequest fdsCloudRequest, @RequestHeader HttpHeaders headers, HttpServletRequest requestContext) throws ApplicationException {
    	LOGGER.info("Invoking updateFDSCloudDocument, fdsCloudRequest={}, headers={}", Encode.forJava(fdsCloudRequest.toString()), Encode.forJava(headers.toString()));
    	
		Map<String, Object> responseMap = new HashMap<String, Object>();
		// needs request and documentId to update
		
		if (!Optional.ofNullable(fdsCloudRequest.getRequest()).equals(null) && !Optional.ofNullable(fdsCloudRequest.getDocumentId()).equals(null)) {
			ResponseEntity<OptOutFDSCloudPOSTResponse> response = optOutService.FDSCloudPut("testFDSCloudPUT", fdsCloudRequest);
			try {
				responseMap = mapper.readValue(response.getBody().toString(), Map.class);
			}
			catch (IOException e) {
				LOGGER.error("updateFDSCloudDocument -> Error updating record {}, error={}", Encode.forJava(fdsCloudRequest.getDocumentId()), ExceptionUtils.getStackTrace(e));
				responseMap.put("error", e.getMessage());
			}
		}
		
		return responseMap;
    	
    }
    
    @PostMapping(path = "/deleteCloud")
    @ResponseBody
    public String deleteFDSCloudDocument(@RequestBody FDSCloudRequest fdsCloudRequest, @RequestHeader HttpHeaders headers, HttpServletRequest requestContext) throws ApplicationException {
    	LOGGER.info("Invoking deleteFDSCloudDocument, fdsCloudRequest={}, headers={}", Encode.forJava(fdsCloudRequest.toString()), Encode.forJava(headers.toString()));
    	
    	
		String responseString = "deleteFDSCloudDocument -> Error adding document to FDS Cloud";		
		
		if (!Optional.ofNullable(fdsCloudRequest.getRequest()).equals(null)) {
			Map<String, Boolean> response = optOutService.FDSCloudDelete("testFDSCloudDELETE", fdsCloudRequest);
			responseString = response.toString();
		}
		
		return responseString;
    	
    }

}
