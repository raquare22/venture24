package com.optum.providerpreferences.rs.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RootController {

    @GetMapping("/")
    public String healthCheck() {
        return String.format("paperless-letters-connector-autoenrollment is up and running");
    }



}