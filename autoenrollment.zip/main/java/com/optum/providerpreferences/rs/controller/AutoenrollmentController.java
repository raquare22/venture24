package com.optum.providerpreferences.rs.controller;

import java.util.Set;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.optum.providerpreferences.autoenrollment.Scheduler;
import com.optum.providerpreferences.autoenrollment.SchedulerAutoEnrollment;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPostResponse;
import com.optum.providerpreferences.rs.service.AutoenrollmentService;


@RestController
@RequestMapping("/api/autoenroll/v1")
public class AutoenrollmentController {
    
	@Autowired
	AutoenrollmentService autoenrollService;
	
    @Autowired
    FDSHandler fdsHandler;
    
    private static final Logger LOGGER = LogManager.getLogger(AutoenrollmentController.class);
    static Scheduler scheduler = new Scheduler();
    static SchedulerAutoEnrollment schedulerAutoEnro = new SchedulerAutoEnrollment();
    
    @PostMapping(path = "/check")
    @ResponseBody
    public static Set<String> checkAutoenrollment() throws ApplicationException {
    	try {
        	return scheduler.checkAutoenrollment();    		
    	} catch (Exception e) {
    		throw new ApplicationException("Error at checkAutoenrollment" + ExceptionUtils.getStackTrace(e));
    	}
    	
    }
    
    @PostMapping(path = "/start")
    @ResponseBody
    public static void startAutoenrollment() throws ApplicationException {
    	try {
        	schedulerAutoEnro.pollCSVFilesManual();    		
    	} catch (Exception e) {
    		throw new ApplicationException("Error at checkAutoenrollment" + ExceptionUtils.getStackTrace(e));
    	}
    	
    }
    
    
   
	
}
