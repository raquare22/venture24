package com.optum.providerpreferences.rs.controller;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.optum.digitalsecurity.model.request.User;
import com.optum.digitalsecurity.model.response.PDOCorporates;
import com.optum.digitalsecurity.model.response.PDOTins;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.GenericResponse;
import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.service.DigitalSecurityService;
import com.optum.providerpreferences.rs.service.ProviderPreferencesService;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import com.optum.providerpreferences.rs.utility.MessageBuilder;

@PropertySource(value = "classpath:application.properties", ignoreResourceNotFound = true)
@RestController

@ConditionalOnProperty(name = "feature.toggle.FDSCloud", havingValue = "true")
@RequestMapping("/api/providers/v1/")
public class ProvPrefFDSCloudController {

	  	@Autowired
	    DigitalSecurityService digitalSecService;
	    
	    @Autowired
	    ProviderPreferencesService providerPreferencesService;

	    @Autowired
	    MessageBuilder messageBuilder;
	    
	    private ApplicationUtil app = new ApplicationUtil();
	    
	    String username="username";

	    private static final  Logger logger = LogManager.getLogger(ProvPrefFDSCloudController.class);
	    
	    /*
	     * An endpoint for the PDO UI (ppl client) to call to log to splunk
	     */
	    @PostMapping(path = "/log", consumes = "application/json")
	    public GenericResponse log(@RequestBody Map<String, String> logMap) {
	    	String logMsg = logMap.get("log");
	    	String timestamp = logMap.get("timestamp");
	    	
	    	if (logMsg == null || logMsg.isEmpty()) {
	    		return new GenericResponse("400", "Null or empty log message");
	    	}
	    	
	    	logger.info("PPL CLIENT -- {}, timestamp: {}", Encode.forJava(logMsg), Encode.forJava(timestamp));
	    	return new GenericResponse("200", "Log message received: " + logMsg);
	    }
	    
	    @PostMapping(path = "/emails")
	    @ResponseBody
	    public ResponseEntity<User> getEmails(@RequestBody Map<String, String> req, @RequestHeader HttpHeaders headers, HttpServletRequest requestContext) throws ApplicationException {
	   	 logger.info("Invoking getEmails, req={}, headers={}", Encode.forJava(req.toString()), Encode.forJava(headers.toString()));
	   	 ResponseEntity<User> response = null; 
	    	try {
	    		response = digitalSecService.getEmailsByCorporate(req.get("corpMpin").toString(), headers);
	        	return response;   
	    	}
	        catch (ApplicationException | HttpClientErrorException e) {
	        	logger.warn("getEmailsByCorporate -> could not find email, error={}", e.getMessage());
	        	return response;
	        }
	    	catch (Exception e) {
	    		throw new ApplicationException("Error at getEmails" + ExceptionUtils.getStackTrace(e));
	    	}
	    }
	   
	    /**
	     * This resource gives a list of corporate entities associated with a given OptumUUID.
	     * 
	     * @param providers
	     * @param headers
	     * @return
	     * @throws JsonParseException
	     * @throws JsonMappingException
	     * @throws IOException
	     * @throws ApplicationException
	     * @throws OAuthProblemException
	     * @throws OAuthSystemException
	     */
	    @PostMapping(path = "/corporates")
	    @ResponseBody
	    public PDOCorporates getCorporatesByPasswordOwner(@RequestBody PasswordOwner providers, @RequestHeader HttpHeaders headers,
	            HttpServletRequest requestContext) throws ApplicationException, IOException, OAuthSystemException, OAuthProblemException
	    {
	        logger.info("Invoking getCorporatesByPasswordOwner");
	        logger.info("CORPORATES REQUEST, UUID={}", Encode.forJava(providers.getOptumUUID()));
	        
	        PDOCorporates response = digitalSecService.getCorporatesByPasswordOwner(providers.getOptumUUID(), headers,
	                messageBuilder.build(requestContext.getRemoteAddr(), headers.getFirst("uuid"), headers.getFirst(username)));
	        
	        logger.info("Returning response - '/corporates'");
	        logger.info("\n" + "CORPORATES RESPONSE: \n" + 
	        "UUID: " + Encode.forJava(providers.getOptumUUID()) + " \n" +
	        "OptumID: " + Encode.forJava(headers.getFirst(username)) + " \n" +
	        "UhcID: " + Encode.forJava(response.getCorporates().get(0).getUhcID()) + " \n" +
	        "Provider MPIN: " + Encode.forJava(response.getCorporates().get(0).getMpin()) + " \n" +
	        "Corporate Name: "  + Encode.forJava(response.getCorporates().get(0).getCorporateName())+ " \n");

	        logger.info("CORPORATES RESPONSE, UUID={}, OptumID={}, providerId={}, UhcID={}, ProviderMPIN={}, CorporateName={}", 
	                Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
	                response.getCorporates().get(0).getProvId(),
	                response.getCorporates().get(0).getUhcID(),
	                response.getCorporates().get(0).getMpin(),
	                response.getCorporates().get(0).getCorporateName());

	        return response;
	    }

	    /**
	     * This resource gives the list of TIN's associated with a given mpin.
	     * 
	     * @param providers
	     * @return
	     * @throws IOException
	     * @throws JsonParseException
	     * @throws ApplicationException
	     */
	    @PostMapping(path = "/tins")
	    @ResponseBody
	    public PDOTins getProvidersByCorporate(@RequestBody PasswordOwner providers, @RequestHeader HttpHeaders headers, HttpServletRequest requestContext)
	            throws IOException, ApplicationException
	    {
	        logger.info("Invoking getProvidersByCorporate");
	        logger.info("TINS REQUEST, UUID={}, UhcID={}, CorporateMPIN={}", 
	            Encode.forJava(providers.getOptumUUID()), Encode.forJava(providers.getUhcID()), Encode.forJava(providers.getMpin()));

	        PDOTins response = digitalSecService.getProvidersByCorporate(providers.getOptumUUID(), providers.getUhcID(), providers.getMpin(),
	                headers, messageBuilder.build(requestContext.getRemoteAddr(), headers.getFirst("uuid"), headers.getFirst(username)));
	        
	        logger.info("Returning response - '/tins'");


	        // //Getting first tin only to know if tins are returned under corporate mpin in the request
	       List<String> tinList = new ArrayList<String>();
	       for (int i =0; i < response.getProviders().size(); i++) {
	    	   tinList.add(response.getProviders().get(i).getTin());
	       }
	        logger.info("TINS RESPONSE, UUID={}, OptumId={}, UhcID={}, CorporateMPIN={}, ProviderTIN={}", 
	            Encode.forJava(providers.getOptumUUID()),Encode.forJava(headers.getFirst(username)), Encode.forJava(providers.getUhcID()), Encode.forJava(providers.getMpin()),tinList);
	        return response;
	    }

	    /**
	     * This resource gives the provider preferences associated with a given TIN.
	     * 
	     * @param providerInfo
	     * @return
	     * @throws JsonParseException
	     * @throws JsonMappingExceptionØ
	     * @throws IOException
	     * @throws ServiceException_Exception
	     * @throws ApplicationException
	     * @throws OAuthProblemException
	     * @throws OAuthSystemException
	     * @throws ParseException
	     */
	    @PostMapping(path = "/preferences")
	    @ResponseBody
	    public ProviderPreferencesObj getFileTypesByProviderMpin(@RequestBody PasswordOwner providers, @RequestHeader HttpHeaders headers,
	            HttpServletRequest requestContext) throws ApplicationException
	    {
	        try
	        {
	            logger.info("Invoking getProviderPreferences - POST");

	            logger.info("PREFERENCES POST REQUEST, UUID={}, OptumID={}, ProviderTIN={}, ProviderMPIN={}", 
	            Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)), Encode.forJava(providers.getTin()), Encode.forJava(providers.getMpin()));
	            
	            ProviderPreferencesObj response = providerPreferencesService.getProviderPreferencesFDSCloud(providers.getTin(), providers.getMpin(), headers,
	                    messageBuilder.build(requestContext.getRemoteAddr(), headers.getFirst("uuid"), headers.getFirst(username)));
	            
	            //getting first provider and preference to make sure preferences are returned
	            logger.info("Returning POST response - '/preferences'");
	            String responseFormat=response.getPreferenceTypes().toString();
	            logger.info("PREFERENCES POST RESPONSE, UUID={}, OptumID={}, ProviderTIN={}, ProviderMPIN={}, PreferenceType={}", 
	            		Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
	            		Encode.forJava(response.getCorporateTin()), Encode.forJava(providers.getMpin()),
	            		responseFormat);

	            return response;
	        }
	        catch (Exception e)
	        {
	            logger.error("ApplicationException={}", ExceptionUtils.getStackTrace(e));
	            throw new ApplicationException("Error at getFileTypesByProviderMpin" + e.toString());
	        }
	    }

	    /**
	     * This resource is used to update all provider preference documents associated with a given TIN.
	     * 
	     * @param providerPreferences
	     * @return
	     * @throws IOException
	     * @throws JsonMappingException
	     * @throws JsonParseException
	     * @throws com.uhc.upm3.provider.updateletterpreferences.v3.ServiceException_Exception
	     * @throws ServiceException_Exception
	     * @throws ParseException
	     * @throws ApplicationException
	     * @throws OAuthProblemException
	     * @throws OAuthSystemException
	     */
	    @PutMapping(path = "/preferences")
	    @ResponseBody
	    public ResponseEntity<GenericResponse> updateFileTypesByProviderTin(@RequestBody ProviderPreferencesObj providerPreferences, @RequestHeader HttpHeaders headers,
	            HttpServletRequest requestContext) throws IOException, ParseException, ApplicationException, 
	    		OAuthSystemException, OAuthProblemException
	    {
	        logger.info("PREFERENCES PUT REQUEST, UUID={}, OptumID={}, ProviderTIN={}, ProviderMPIN={}, PreferenceType={}", 
	              Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
	              Encode.forJava(providerPreferences.getCorporateTin()), Encode.forJava(providerPreferences.getSelectedProviders().toString()), Encode.forJava(providerPreferences.getPreferenceTypes().toString()));
	      
	        try {
	    	  
	    	    providerPreferencesService.updateProviderPreferencesFDSCloud(providerPreferences, headers);
	    	  
	        } catch (Exception e) {
	    	    logger.warn("Failed to update provider preferences, UUID={}, OptumID={}, ProviderPreferenceObj={}, error={}",
	    			    Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
	    			    Encode.forJava(providerPreferences.toString()), e.toString());
	    	    return new ResponseEntity<GenericResponse>(new GenericResponse("500", "Error updating preferences"), HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	        String res=app.rerSuccess("Returning PUT response - '/preferences'");
	        logger.info(res);

	        return new ResponseEntity<GenericResponse>(new GenericResponse("200", "Preferences updated"), HttpStatus.OK);
	    }

	    /**
	     * This service retrieves Provider Data for the given Corporate MPIN and Tax ID
	     * 
	     * @param request
	     * @param headers
	     * @param requestContext
	     * @return
	     * @throws JsonParseException
	     * @throws JsonMappingException
	     * @throws IOException
	     * @throws ServiceException_Exception
	     * @throws ParseException
	     * @throws ApplicationException
	     * @throws OAuthSystemException
	     * @throws OAuthProblemException
	     */
	    @PostMapping(path = "/mpins")
	    @ResponseBody
	    public CorpMpinResponse getProviderData(@RequestBody com.optum.providerpreferences.rs.model.ndb.provider.RequestData request,
	            @RequestHeader HttpHeaders headers, HttpServletRequest requestContext)
	            throws IOException, ApplicationException
	    {
	        logger.info("Invoking getProviderData");
	        logger.info("\n" + "MPINS REQUEST: \n" + 
	        "UUID: " + Encode.forJava(headers.getFirst("uuid")) + " \n" +
	        "OptumID: " + Encode.forJava(headers.getFirst(username)) + " \n" +
	        "Provider Tax ID/TIN: " + Encode.forJava(request.getTaxIdNumber()) + " \n" +
	        "Corporate Owner ID: " + Encode.forJava(request.getCorpOwnerId()));

	        logger.info("MPINS REQUEST, UUID={}, OptumID={}, ProviderTIN={}, CorporateOwnerID={}", 
	                Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
	                Encode.forJava(request.getTaxIdNumber()),Encode.forJava(request.getCorpOwnerId()));

	        CorpMpinResponse response = providerPreferencesService.getProviderData(request, headers,
	                messageBuilder.build(requestContext.getRemoteAddr(), headers.getFirst("uuid"), headers.getFirst(username)));
	        
	        //logging only the first two mpins to make sure mpins are returned
	        logger.info("Returning response - '/mpins'");

	        logger.info("MPINS RESPONSE, UUID={}, OptumID={}, ProviderTIN={}, CorporateOwnerID={}, providerMPINs={}", 
	                Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
	                Encode.forJava(request.getTaxIdNumber()), Encode.forJava(request.getCorpOwnerId()), response.getResponse().getMpinList().get(0).getProviderId());

	        return response;
	    }
}