package com.optum.providerpreferences.rs.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.optum.digitalsecurity.model.response.Demographics;
import com.optum.digitalsecurity.model.response.JobFunction;
import com.optum.digitalsecurity.model.response.NonProviderOrg;
import com.optum.digitalsecurity.model.response.OrgData;
import com.optum.digitalsecurity.model.response.Permission;
import com.optum.digitalsecurity.model.response.ProvTin;
import com.optum.digitalsecurity.model.response.Provider;
import com.optum.digitalsecurity.model.response.ProviderOrg;
import com.optum.digitalsecurity.model.response.ProviderProfile;
import com.optum.digitalsecurity.model.response.Tin;
import com.optum.providerpreferences.rs.model.GenericResponse;

@RestController
@RequestMapping("/api/providers/v1")
public class DigitalSecurityController {
	
String num="002056499";

 @PostMapping(value = "/user", consumes = "application/json")
 public ProviderProfile getProvider(@RequestBody Map<String, String> req) {
	 
	
	 
	 String uuid = req.get("uuid");
	 Demographics demographics= new Demographics( "Tim", "Cook", "tim_cook@test.com", "123-456-7890", "007");
	 List<JobFunction> jobFunction = new ArrayList<>();
	 JobFunction jf = new JobFunction("sampleCode", "codeDesc", "samplenpi");
	 jobFunction.add(jf);

	 List<ProviderOrg> providerData = new ArrayList<>();
	 ProviderOrg provObj = new ProviderOrg( "1234", num, "42936", "CAILLET", "FRANK", true,false);
	 ProviderOrg provObj1 = new ProviderOrg( "4567", num, "42935", "CAILLET1", "FRANK1", false,false);
	 ProviderOrg provObj2 = new ProviderOrg( "7890", num, "42934", "", "", true,false);
	 ProviderOrg provObj3 = new ProviderOrg( "4321", num, "42934", "", "Frank2", true,false);
	 providerData.add(provObj);
	 providerData.add(provObj1);
	 providerData.add(provObj2);
	 providerData.add(provObj3);
	 List<NonProviderOrg> nonProviderOrg = new ArrayList<>();
	 NonProviderOrg nonProvOrg = new NonProviderOrg("sampleIrsOrgId", "CAILLET FRANK", true);
	 nonProviderOrg.add(nonProvOrg);
	 return new ProviderProfile(uuid, demographics, jobFunction, providerData, nonProviderOrg);
	 
 }
 @PostMapping(value = "/org", consumes = "application/json")
 public OrgData getOrgData(@RequestBody Map<String, String> req) {
	 String uuid = req.get("uuid");
	 String corpMpin = req.get("corpMpin");
	 List<Tin> tins = new ArrayList<>();
	 List<Permission> permission = new ArrayList<>();
	 Permission perObj = new Permission("sampleCode", "sampleSubCode", "sampleCodeDesc", "SampleSubCodeDesc");
	 permission.add(perObj);
	 Tin tinObj = new Tin("261531455", true,permission);
	 Tin tinObj2 = new Tin("261531454", true,permission);
	 tins.add(tinObj);
	 tins.add(tinObj2);
	 return new OrgData(uuid,corpMpin,tins);
 }
 
 @PostMapping(value = "/tin", consumes = "application/json")
 public ProvTin getTinData(@RequestBody Map<String, String> req) {
	 String uuid = req.get("uuid");
	 String corpMpin = req.get("corpMpin");
	 String tin = req.get("tin");
	 List<Provider> provider = new ArrayList<>();
	 Provider prov = new Provider( "Tim", "Cook", num);
	 provider.add(prov);
	 return new ProvTin(uuid, corpMpin, tin,provider);
 }
 
}
