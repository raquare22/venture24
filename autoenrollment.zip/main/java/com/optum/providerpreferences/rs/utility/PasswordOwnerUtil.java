package com.optum.providerpreferences.rs.utility;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.PasswordOwnerInfo;
import com.optum.providerpreferences.rs.model.linksecurity.User;

public class PasswordOwnerUtil
{
    private static final Logger logger = LogManager.getLogger(PasswordOwnerUtil.class);

    public PasswordOwner compilePasswordOwnerInfo(String optumUUID, List<PasswordOwnerInfo> usersPasswordOwnerInfo, List<User> profiles, String sessionId)
            throws ApplicationException
    {
        logger.info("Compiling password owner info");
        
        PasswordOwner passwordOwner = new PasswordOwner();
        passwordOwner.setOptumUUID(optumUUID);

        for (PasswordOwnerInfo passwordOwnerInfo : usersPasswordOwnerInfo)
        {
            for (User user : profiles)
            {
                if (user.getUserAcctSeqNbr().equals(passwordOwnerInfo.getUhcID()) && user.getRespOrgMpin().equals(passwordOwnerInfo.getMpin()))
                {
                    passwordOwner.getCorporates().add(passwordOwnerInfo);
                }
            }
        }

        if (passwordOwner.getCorporates().isEmpty())
        {
            logger.error("No Corporates for given UUID");
            throw new ApplicationException("Error: LINK Corporates");
        }

        return passwordOwner;
    }
}
