package com.optum.providerpreferences.rs.utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;


public class ApplicationUtil {

	public static final int THREADS_FDSCLOUD_GET_DEFAULT = 18;
	public static final int THREADS_DIGISEC_GET_DEFAULT = 2;
	public static final int THREADS_FDSCLOUD_POST_DEFAULT = 32;
	public static final int THREADS_FDSCLOUD_PUT_DEFAULT = 32;
	public static final int THREAD_COUNT_HEALTHCHECK_DEFAULT = 1000;
	public static final int PDO_CONNECT_TIMEOUT_DEFAULT = 5000;
	public static final int THREAD_COUNT_PES_DEFAULT = 1000;
	public static final int PDO_READ_TIMEOUT_DEFAULT = 5000;

	public static Boolean isNotNull(Object o) {
		return (o != null) ? true : false;
	}

	public static String getServerDate() {
		TimeZone tz = TimeZone.getTimeZone("UTC");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"); // Quoted "Z" to indicate UTC, no timezone offset
		df.setTimeZone(tz);
		return df.format(new Date());
	}

	public String rerSuccess(String message) {
		message += ", RERstatus=SUCCESS";
		return message;
	}

	public  String rerFailure(String message) {
		message += ", RERstatus=FAILURE";
		return message;
	}

	public static int parseWithDefault(String number, int defaultVal) {
		try {
			return Integer.parseInt(number);
		} catch (NumberFormatException e) {
			return defaultVal;
		}
	}
}
