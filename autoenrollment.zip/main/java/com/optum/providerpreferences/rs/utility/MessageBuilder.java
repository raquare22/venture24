/**
 *  Copyright Optum Services Inc., 2017. All rights reserved.
 *  This software and documentation contain confidential and proprietary information owned by Optum Services Inc.,
 *  Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.utility;

import org.springframework.stereotype.Component;

import com.optum.providerpreferences.rs.model.logging.LogMessage;

/**
 * This utility is used to construct security audit formatted logs.
 * 
 * @author Provider Paperless Letters
 *
 */
@Component
public class MessageBuilder {

	public LogMessage build(String actorIp, String actor, String username) {

		LogMessage logMessage = new LogMessage();
		logMessage.setActorIp(actorIp);
		logMessage.setActor(actor);
		logMessage.setUsername(username);

		return logMessage;
	}

}
