package com.optum.providerpreferences.rs.utility;

public final class Constants
{
	private Constants() {
	      //private constructor added to solve Sonar "Add a private constructor to hide the implicit public one"
	   }
    public static final String UPDATE_PREFS_QUEUE = "update-prefs-amq";

    public static final String USERNAME = "admin";

}
