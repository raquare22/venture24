/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.Metadata;

/**
 * This utility is used to format preferences metadata to be stored in FDS.
 * 
 * @author Provider Paperless Letters
 */
public final class Converter
{
	private Converter() {
		//private constructor added to solve Sonar "Add a private constructor to hide the implicit public one"
	}
    public static String convertNullToString(String value)
    {
        return (value == null ? "" : value.trim());
    }

    public static Date convertStringToDate(String dateString) throws ParseException
    {

        SimpleDateFormat formatter = new SimpleDateFormat("E MMMM dd HH:mm:ss z yyyy");
        
        return formatter.parse(dateString);

    }
}
