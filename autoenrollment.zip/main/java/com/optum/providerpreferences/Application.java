/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.handler.RequestFactory;


@EnableAutoConfiguration
@SpringBootApplication
@EnableScheduling
public class Application
{

    private static Logger logger = LogManager.getLogger(Application.class);

    @Bean
    public ObjectMapper getMapper()
    {
        return new ObjectMapper();
    }

    @Bean
    public HttpHeaders getHttpHeaders()
    {
        return new HttpHeaders();
    }


    public static void main(String[] args)
    {        
        logger.info("COMMIT MESSAGE FOR HEADER SIZE ISSUE -- 01/09/19");
        SpringApplication application = new SpringApplication(Application.class);
        application.addListeners(new AppListener());
        application.run(args);
    }
}
