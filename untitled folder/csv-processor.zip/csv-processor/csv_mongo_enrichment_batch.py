import csv
import os
from datetime import datetime
import sys
from pymongo import MongoClient

# ---- CONFIG ----
MONGO_URI = os.getenv("MONGO_URI_PRD")
COLLECTION_NAME = 'document'
SPACE_ID = 20603   # update if needed
BATCH_SIZE = 500   # adjust based on performance

#---- CONNECT ----
client = MongoClient(MONGO_URI)
db_name = client['rulesEngineStore'] #"rulesEngineStore"
collection = db_name[COLLECTION_NAME] #client[db_name][COLLECTION_NAME]

# ---- INPUT ARGUMENT ----
if len(sys.argv) < 2:
    print("Usage: python script.py <input_csv>")
    sys.exit(1)

INPUT_FILE = sys.argv[1]


# ---- EXTRACT PATH INFO ----
input_dir = os.path.dirname(INPUT_FILE)
base_name = os.path.basename(INPUT_FILE)
name, ext = os.path.splitext(base_name)

# ---- CREATE OUTPUT DIRECTORY ----
output_dir = os.path.join(input_dir, "output")
os.makedirs(output_dir, exist_ok=True)

# ---- GENERATE TIMESTAMP ----
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

# ---- FINAL OUTPUT PATH ----
OUTPUT_FILE = os.path.join(
    output_dir,
    f"{name}_updated_{timestamp}{ext}"
)

print(f"📥 Input file : {INPUT_FILE}")
print(f"📤 Output file: {OUTPUT_FILE}")

# ---- READ CSV ----
with open(INPUT_FILE, mode="r", newline='', encoding="utf-8") as infile:
    reader = csv.DictReader(infile)
    reader.fieldnames = [h.strip() for h in reader.fieldnames]
    rows = list(reader)

# ---- PREP OUTPUT FIELDS ----
new_columns = ["mongo_id", "fdsCloudAttachmentId", "fdsCloudDocumentId"]

# Add only missing columns
for col in new_columns:
    if col not in rows[0]:   # check first row keys
        for row in rows:
            row[col] = ""

# Ensure output fields include them (without duplicates)
output_fields = list(rows[0].keys())

# ---- PROCESS IN BATCHES ----
for i in range(0, len(rows), BATCH_SIZE):
    batch = rows[i:i + BATCH_SIZE]

    # Build query
    or_conditions = []
    for row in batch:
        tin = row["TIN"].strip()
        chk = row["CHK_TRAC_NBR"].strip()

        or_conditions.append({
            "metadata.tin": tin,
            "metadata.CheckTraceNumber": chk
        })

    query = {
        "spaceId": SPACE_ID,
        "$or": or_conditions,
        "status": "AVAILABLE",
        "metadata.docLibAPIResponse": True
    }

    docs = list(collection.find(query))

    # Build lookup map
    lookup = {
        (doc["metadata"]["tin"], doc["metadata"]["CheckTraceNumber"]): doc
        for doc in docs
    }

    # Map results back
    for row in batch:
        key = (row["TIN"].strip(), row["CHK_TRAC_NBR"].strip())
        doc = lookup.get(key)

        if doc:
            row["mongo_id"] = str(doc["_id"])
            row["fdsCloudAttachmentId"] = doc.get("fdsAttachmentId")
            row["fdsCloudDocumentId"] = doc.get("fdsDocumentId")
        else:
            row["mongo_id"] = ""
            row["fdsCloudAttachmentId"] = ""
            row["fdsCloudDocumentId"] = ""

    print(f"✅ Processed batch {i // BATCH_SIZE + 1}")

# ---- WRITE OUTPUT ----
with open(OUTPUT_FILE, mode="w", newline='', encoding="utf-8") as outfile:
    writer = csv.DictWriter(outfile, fieldnames=output_fields)
    writer.writeheader()
    writer.writerows(rows)

print(f"\n✅ Completed! Output written to: {OUTPUT_FILE}")