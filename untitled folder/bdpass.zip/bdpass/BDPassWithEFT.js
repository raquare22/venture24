function bdPassDownload(spaceId, startTimeStamp, endTimeStamp) {
  db.getCollection("document")
    .find({
      spaceId: spaceId,
      dateCreated: {
        $gte: ISODate(startTimeStamp),
        $lt: ISODate(endTimeStamp),
      },
    })
    .forEach(function (doc) {
      var dateObj = doc.dateCreated;
      var dateStr = dateObj.toString();
      var date = dateStr.substring(4, 10);
      var fullDate = date + formatAMPM(dateObj);
      print(
        '{"record":{"dateCreated":"' +
          fullDate +
          '","metadata":{"category":"' +
          doc.metadata.fileDescription +
          '","corporateMpin":"' +
          doc.metadata.corporateMpin +
          '","emailAlertReq":"' +
          doc.metadata.emailAlertReq +
          '","filePath":"' +
          doc.metadata.filePath +
          '","mpin":"' +
          doc.metadata.mpin +
          '","originalPrintTrail":"' +
          doc.metadata.originalPrintTrail +
          '","subCategory":"' +
          doc.metadata.subCategory +
          '","tin":"' +
          doc.metadata.tin +
          '","EFT_Ind":"' +
          doc.metadata.EFT_Ind +
          '"},"spaceId":{"$numberInt":' +
          doc.spaceId +
          '},"status":"' +
          doc.status +
          '"}}'
      );
    });
}

function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var seconds = date.getSeconds();
  var year = date.getFullYear();
  var ampm = hours >= 12 ? "PM" : "AM";
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? "0" + minutes : minutes;
  var strTime =
    ", " + year + " " + hours + ":" + minutes + ":" + seconds + " " + ampm;
  return strTime;
}

function getPreviousDay(date, freqDays) {
  const previous = new Date(date.getTime());
  previous.setDate(date.getDate() - freqDays);

  return previous;
}

function main(spaceId, freqDays) {
  const startDate = getPreviousDay(new Date(), freqDays);
  const endDate = new Date();
  const time = "T00:00:00.000Z";
  const startTimeStamp = startDate.toISOString().split("T")[0] + time;
  const endTimeStamp = endDate.toISOString().split("T")[0] + time;
  bdPassDownload(spaceId, startTimeStamp, endTimeStamp);
}

//start of script.
main(spaceId, freqDays);
