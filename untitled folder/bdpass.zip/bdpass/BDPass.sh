DATABASE=rulesEngineStore
COLLECTION=document
MONGO_HOST_URL="[REDACTED]"
MONGO_PORT=27017
MONGO_USER_NAME="ppl-prun-prod-rw"
MONGO_USER_PASSWORD="gWckNQPfwA"
freqDays=1
date=$(date '+%Y-%m-%d')
mkdir BDPassReport;
BDPassReport="BDPassReport";
mkdir $PWD/$BDPassReport/$date
#without EFT
spaceIds=(8889 8935 8936 8937 8938 10103 10503 10603 10703)
for i in ${spaceIds[@]}; do
    echo ${i}
    mongo $MONGO_HOST_URL --eval "spaceId=${i}, freqDays=$freqDays" BDPassWithoutEFT.js|grep "record" >> $PWD/$BDPassReport/$date/BDPass_${i}_$date.txt &
done

#with EFT
spaceIdsEFT=(10074 10075 10303 10403)
for j in ${spaceIdsEFT[@]}; do
    echo ${j}
    mongo $MONGO_HOST_URL --eval "spaceId=${j}, freqDays=$freqDays" BDPassWithEFT.js|grep "record" >> $PWD/$BDPassReport/$date/BDPass_${j}_$date.txt &
done