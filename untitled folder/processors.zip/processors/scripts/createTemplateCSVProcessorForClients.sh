#!/usr/bin/env bash

function prop {
    grep "^\\s*${1}=" createTemplateProcessor.properties | cut -d'=' -f2
}

function setEnvironment {

	if [[ -z "$*" ]]; then
		read -p "Enter environment (local, dev, qa, stage or prod): " ENVIRO
		read -p "Enter client (UNET, COSMOS, NextGen, 1Click, CCSManual, PaymentEngPRA, UHCWest, COSMOSDoc1, COSMOSPRACompanion, CheckWritePRA, ODAR, CSP-PRA, ETS_Appeals): " inpClientName
		ACKNOWLEDGE_PROMPTS=true
	else
		ACKNOWLEDGE_PROMPTS=$1
		ENVIRO=$2
		inpClientName=$3
		if [[ ( $inpClientName == COSMOSPRACompanion) ]]; then
			TEMPLATEID=$4
		else
			TEMPLATE=$4
			HTTP_METHOD=$5
		fi
		shift "$#"
	fi

	if [[ ( $ENVIRO == local || $ENVIRO == dev || $ENVIRO == qa || $ENVIRO == stage || $ENVIRO == stage-blue|| $ENVIRO == prod) && ( $inpClientName == UNET || $inpClientName == COSMOS || $inpClientName == NextGen || $inpClientName == 1Click || $inpClientName == CCSManual || $inpClientName == PaymentEngPRA || $inpClientName == UHCWest || $inpClientName == COSMOSDoc1 || $inpClientName == COSMOSPRACompanion || $inpClientName == CheckWritePRA || $inpClientName == CSP-PRA || $inpClientName == ODAR || $inpClientName == ETS_Appeals) ]]; then
		HOST_URL=$(prop ${ENVIRO}.HOST_URL)
		HOST_URL_service=$(prop ${ENVIRO}.HOST_URL_service)
		inpSpaceId=$(prop ${ENVIRO}.${inpClientName}.inpSpaceId)
		includeFileNameRegExPattern=$(prop ${ENVIRO}.${inpClientName}.includeFileNameRegExPattern)
		excludeFileNameRegExPattern=$(prop ${ENVIRO}.${inpClientName}.excludeFileNameRegExPattern)
		delimit=$(prop ${ENVIRO}.${inpClientName}.delimit)
		priority=$(prop ${inpClientName}.priority)
		companionTRL=$([[ $(prop ${ENVIRO}.${inpClientName}.companionTRL) == true ]] && echo true || echo false)
		ftpRootdir_CSV=$(prop ${ENVIRO}.${inpClientName}.ftpRootdir_CSV)
		ftpArchivedir_CSV=$(prop ${ENVIRO}.${inpClientName}.ftpArchivedir_CSV)
		clientName=$(prop ${ENVIRO}.${inpClientName}.clientName)
		if [[ ( $inpClientName == COSMOSPRACompanion) ]]; then
			HOST_URL_CSV=$(prop ${ENVIRO}.HOST_URL)
			SFTP_HOST_CSV=$(prop ${ENVIRO}.SFTP_HOST)
			SFTP_USER_CSV=$(prop ${ENVIRO}.SFTP_USER)
			SFTP_PASSWORD_CSV=$(prop ${ENVIRO}.SFTP_PASSWORD)
			HTTP_METHOD="POST"
			TEMPLATE_DEF=""
			if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
      TEMPLATEID="checkWritePRACompanion";
			fi
		else
			HOST_URL_CSV=$(prop ${ENVIRO}.HOST_URL_CSV)
			SFTP_HOST_CSV=$(prop ${ENVIRO}.SFTP_HOST_CSV)
			SFTP_USER_CSV=$(prop ${ENVIRO}.SFTP_USER_CSV)
			SFTP_PASSWORD_CSV=$(prop ${ENVIRO}.SFTP_PASSWORD_CSV)
			echo
			if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
			HTTP_METHOD="PUT"
			TEMPLATE="csv_json_template.hbs";
			fi
			HTTP_METHOD=${HTTP_METHOD:=PUT}
			TEMPLATE="/usr/local/src/fds_paperless/curl/processors/elgs/csv_json_template.hbs"
			TEMPLATE_DEF=`cat $TEMPLATE`
		fi
	else
		echo "Try again"
		exit 0
	fi

	echo
	echo "Host URL: $HOST_URL"
	echo "Host CSV URL: $HOST_URL_CSV"
	echo "inpSpaceId: $inpSpaceId"
	echo "Sftp host name: $SFTP_HOST_CSV"
	echo "ftpRootdir: $ftpRootdir_CSV"
	echo "ftpAckdir: $ftpAckdir_CSV"
	echo "ftpArchivedir: $ftpArchivedir_CSV"
	echo "sftp user name: $SFTP_USER_CSV"
	echo "sftp password: $SFTP_PASSWORD_CSV"
	echo "Http Method: " $HTTP_METHOD
	echo "template def: " $TEMPLATE_DEF
	echo "template id: " $TEMPLATEID
	echo "includeFileNameRegExPattern: " $includeFileNameRegExPattern
	echo "excludeFileNameRegExPattern: " $excludeFileNameRegExPattern
	echo "delimit: " $delimit
	echo "companionTRL: " $companionTRL
	echo "clientName : " $clientName
}

setEnvironment $*
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Press Enter to continue"
fi

echo "Running POST processor to $ENVIRO"

NEW_PROCESSOR_NAME=$(cat /dev/urandom | LC_CTYPE=C tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1)
PROCESSOR='{
				"name": "'"$NEW_PROCESSOR_NAME"'",
				"start_date" : "2017-02-01T06:00:00-06:00",
				"end_date" : "2025-02-01T06:00:00-06:00",
				"lastRun"  : "2017-02-01T06:00:00-06:00",
				"lastCleanUpRun" : "2099-02-01T06:00:00-06:00",
				"locked" : "false",
				"processorType" : "CsvSftp",
				"process": {
					"process_key": "csvSftpProcess",
					"config": {
						"space_id" : '$inpSpaceId',
						"host_name_source" : "'"$SFTP_HOST_CSV"'",
						"host_name_destination" : "'"$SFTP_HOST_CSV"'",
						"ftp_rootdir" : "'"$ftpRootdir_CSV"'",
						"ftp_archivedir" : "'"$ftpArchivedir_CSV"'",
						"username_destination" : "'"$SFTP_USER_CSV"'",
						"username_source" : "'"$SFTP_USER_CSV"'",
						"pw_source" : "'"$SFTP_PASSWORD_CSV"'",
						"pw_destination" : "'"$SFTP_PASSWORD_CSV"'",
						"interval" : "30",
						"cleanup_interval" : "120",
						"fdsHttpMethod" : "'"$HTTP_METHOD"'",
						"fdsDocumentUrl" : "'"$HOST_URL_CSV/v2/documents"'",
						"includeFileNameRegExPattern" : "'"$includeFileNameRegExPattern"'",
						"excludeFileNameRegExPattern" : "'"$excludeFileNameRegExPattern"'",
						"delimit" : "'"$delimit"'",
						"companionTRL" : "'"$companionTRL"'",
						"clientName" : "'"$clientName"'"
					},
					"processorRecordType" : "processor",
					"priority" : '$priority'
				}
			}'

echo $PROCESSOR

POST_RESULT=`curl -verbose -X POST -k "$HOST_URL_service/api/services/v1/csvProcessor/"  --header "Content-Type: application/json" -d "$PROCESSOR"`

jq . <<< $POST_RESULT
echo