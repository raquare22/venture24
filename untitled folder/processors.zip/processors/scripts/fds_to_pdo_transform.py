import json
from datetime import datetime, timezone

# Convert epoch to Mongo date format
def convert_epoch(ms):
    if not ms or ms == 0:
        return None
    
    dt = datetime.fromtimestamp(ms / 1000, tz=timezone.utc)
    
    return {
        "$date": dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    }

def transform_record(record):
    source = record

    # Parse metadata (string → dict)
    metadata_str = source.get("metadata", "{}")
    try:
        metadata = json.loads(metadata_str)
    except json.JSONDecodeError:
        metadata = {}

    # searchTerms already dict
    search_terms = source.get("searchTerms", {})

    # Start building output
    output = {}

    # Merge fields
    output.update(metadata)
    output.update(search_terms)

    # Add date fields
    output["dateCreated"] = convert_epoch(source.get("createdOn"))
    output["dateModified"] = convert_epoch(source.get("modifiedOn"))

    return output

def main():
    input_file = "input.json"
    output_file = "output.json"

    try:
        with open(input_file, "r") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        print("Invalid JSON in input file:", e)
        return

    # Handle both list or single object
    records = data if isinstance(data, list) else [data]

    result = []

    for record in records:
        transformed = transform_record(record)
        result.append(transformed)

    # Write output as JSON array
    with open(output_file, "w") as f:
        json.dump(result, f, indent=4)

    print(f"Transformation complete. Output saved to {output_file}")

if __name__ == "__main__":
    main()
