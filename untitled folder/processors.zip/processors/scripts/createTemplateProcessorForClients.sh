#!/usr/bin/env bash

function prop {
    grep "^\\s*${1}=" createTemplateProcessor.properties | cut -d'=' -f2
}

if [[ -z "$*" ]]; then
	read -p "Enter environment (local or dev or qa or stage or prod): " ENVIRO

	echo
	read -p "Enter client (UNET or COSMOS or NextGen or 1Click or CCSManual or PaymentEngPRA or COSMOSDoc1 or CheckWritePRA or CheckWritePRA_CDC or UHCWest or CSP-PRA or ODAR or MR_Appeals or ETS_Appeals or USP-PRA or USP-claims or CSP-Claims or NGS_Appeals or HouseCalls or NGS-Claims or PECOSMOSPRA): " inpClientName
	ACKNOWLEDGE_PROMPTS=true
else
	ACKNOWLEDGE_PROMPTS=$1
	ENVIRO=$2
	inpClientName=$3
	shift "$#"
fi

if [[ ( $ENVIRO == local || $ENVIRO == dev || $ENVIRO == qa || $ENVIRO == stage || $ENVIRO == prod) && ( $inpClientName == UNET || $inpClientName == COSMOS || $inpClientName == NextGen || $inpClientName == 1Click || $inpClientName == CCSManual || $inpClientName == CheckWritePRA || $inpClientName == CheckWritePRA_CDC || $inpClientName == PaymentEngPRA || $inpClientName == COSMOSDoc1 || $inpClientName == UHCWest ||  $inpClientName == CSP-PRA || $inpClientName == UNETProdTest || $inpClientName == ODAR || $inpClientName == MR_Appeals|| $inpClientName == ETS_Appeals || $inpClientName == NGS_Appeals ||  $inpClientName ==  USP-PRA ||  $inpClientName ==  USP-claims ||  $inpClientName ==  CSP-Claims || $inpClientName = HouseCalls || $inpClientName = NGS_Claims || $inpClientName == PECOSMOSPRA) ]]; then
	HOST_URL=$(prop ${ENVIRO}.HOST_URL)
	HOST_URL_service=$(prop ${ENVIRO}.HOST_URL_service)
	inpSpaceId=$(prop ${ENVIRO}.${inpClientName}.inpSpaceId)
	SFTP_HOST=$(prop ${ENVIRO}.SFTP_HOST)
	ftpRootdir=$(prop ${ENVIRO}.${inpClientName}.ftpRootdir)
	ftpAckdir=$(prop ${ENVIRO}.${inpClientName}.ftpAckdir)
	ftpArchivedir=$(prop ${ENVIRO}.${inpClientName}.ftpArchivedir)
	SFTP_USER=$(prop ${ENVIRO}.SFTP_USER)
	SFTP_PASSWORD=$(prop ${ENVIRO}.SFTP_PASSWORD)
	templateRecordType=$(prop ${inpClientName}.templateRecordType)
	requiredFieldProcessing=$(prop ${inpClientName}.requiredFieldProcessing)
	priority=$(prop ${inpClientName}.priority)
	generateSingleAckSummaryFile=$(prop ${inpClientName}.generateSingleAckSummaryFile)
	resolveIncompleteProcessorTransactionInterval=$(prop ${inpClientName}.resolveIncompleteProcessorTransactionInterval)
	ackWithErrorsOnlyFile=$(prop ${inpClientName}.ackWithErrorsOnlyFile)
	addProcessorTransactionMetadata=$(prop ${inpClientName}.addProcessorTransactionMetadata)
	clientName=$(prop ${ENVIRO}.${inpClientName}.clientName)
	templateRecordType=$(prop ${inpClientName}.templateRecordType)
	zipFilePattern=$(prop ${inpClientName}.zipFilePattern)
else
	echo "Try again"
	exit 0
fi

if [[ $ACKNOWLEDGE_PROMPTS == true && $inpClientName == CSP-PRA ]]; then
read -p "is it CSP 835 yes or no:" COMP
fi
if [[ $COMP == yes ]]; then
    clientName=$(prop ${ENVIRO}.CSP-PRA835.clientName)
    zipFilePattern=$(prop CSP-PRA835.zipFilePattern)
fi

config='
      "config": {
			"space_id": "'"$inpSpaceId"'",
			"host_name_source": '$SFTP_HOST',
			"host_name_destination": '$SFTP_HOST',
			"ftp_rootdir": '$ftpRootdir',
			"ftp_ackdir": '$ftpAckdir',
			"ftp_archivedir": '$ftpArchivedir',
			"username_destination": '$SFTP_USER',
			"username_source": '$SFTP_USER',
			"pw_source": '$SFTP_PASSWORD',
			"pw_destination": '$SFTP_PASSWORD',
			"interval": "30",
			"cleanup_interval": "5",
			"templateRecordType": '$templateRecordType',
			"clientName" : '$clientName',
			"requiredFieldProcessing": '$requiredFieldProcessing',
			"generateSingleAckSummaryFile": '$generateSingleAckSummaryFile',
			"resolveIncompleteProcessorTransactionInterval" : '$resolveIncompleteProcessorTransactionInterval',
			"ackWithErrorsOnlyFile" : '$ackWithErrorsOnlyFile',
			"addProcessorTransactionMetadata" : '$addProcessorTransactionMetadata',
			"zipFilePattern" : '$zipFilePattern'
		}'

echo
echo "Host URL: $HOST_URL"
echo "inpSpaceId: $inpSpaceId"
echo "Sftp host name: $SFTP_HOST"
echo "ftpRootdir: $ftpRootdir"
echo "ftpAckdir: $ftpAckdir"
echo "ftpArchivedir: $ftpArchivedir"
echo "sftp user name: $SFTP_USER"
echo "sftp password: $SFTP_PASSWORD"
echo "templateRecordType: $templateRecordType"
echo "clientName: $clientName"
echo "Required Field Processing flag: $requiredFieldProcessing"
echo "generateSingleAckSummaryFile flag: $generateSingleAckSummaryFile"
echo "ackWithErrorsOnlyFile flag: $ackWithErrorsOnlyFile"
echo "addProcessorTransactionMetadata flag: $addProcessorTransactionMetadata"
echo "zipFilePattern: $zipFilePattern"

echo
echo "config: $config"

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Create Template Processor for $inpClientName in $ENVIRO (continue): continue"
fi

echo
echo "Running POST processor to $ENVIRO"
NEW_PROCESSOR_NAME=$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 32)
PROCESSOR='{
		  "name":"'"$NEW_PROCESSOR_NAME"'",
		  "priority":'$priority',
		  "start_date":"2017-02-01T06:00:00-06:00",
		  "end_date":"2025-02-01T06:00:00-06:00",
		  "cleanupWorkflow" : "cleanupFilesCreateACKProcess",
		  "process":{
		    "process_key":"sftpUnzipProcess",
        "config": {
          "space_id": "'"$inpSpaceId"'",
          "host_name_source": "'"$SFTP_HOST"'",
          "host_name_destination": "'"$SFTP_HOST"'",
          "ftp_rootdir": "'"$ftpRootdir"'",
          "ftp_ackdir": "'"$ftpAckdir"'",
          "ftp_archivedir": "'"$ftpArchivedir"'",
          "username_destination": "'"$SFTP_USER"'",
          "username_source": "'"$SFTP_USER"'",
          "pw_source": "'"$SFTP_PASSWORD"'",
          "pw_destination": "'"$SFTP_PASSWORD"'",
          "interval": "30",
          "cleanup_interval": "5",
          "templateRecordType" : "'"$templateRecordType"'",
          "clientName" : "'"$clientName"'",
          "requiredFieldProcessing": '$requiredFieldProcessing',
          "generateSingleAckSummaryFile": '$generateSingleAckSummaryFile',
          "resolveIncompleteProcessorTransactionInterval" : '$resolveIncompleteProcessorTransactionInterval',
          "ackWithErrorsOnlyFile" : '$ackWithErrorsOnlyFile',
          "addProcessorTransactionMetadata" : '$addProcessorTransactionMetadata',
          "zipFilePattern" : "'"$zipFilePattern"'"
        }
		  },
        "processorRecordType" : "processor",
        "configSpaceId" : '$inpSpaceId',
        "status":"NEW"
		}'

echo
echo $PROCESSOR

POST_RESULT=`curl -verbose -X POST -k "$HOST_URL_service/api/services/v1/processor"  --header "Content-Type: application/json" -d "$PROCESSOR"`

echo $POST_RESULT
jq . <<< $POST_RESULT
