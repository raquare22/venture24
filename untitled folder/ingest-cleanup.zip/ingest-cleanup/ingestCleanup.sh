#!/bin/bash

## Openshift version
#date7=$(date --date="10 days ago" +%Y-%m-%d)
#date30=$(date --date="30 days ago" +%Y-%m-%d)

## mac version
# date7=$(date -v-7d +%Y-%m-%d)
# date30=$(date -v-30d +%Y-%m-%d)
#echo "$date7"
#echo "$date30"

cd /ingest

#touch -d "30 days ago" /cleanuptesting/start_date
#touch -d "10 days ago" /cleanuptesting/end_date


# exclude /ingest/config and /ingest/msg_srv
# find $d -newermt $date30 ! -newermt $date7 -exec rm -rdf {} \;
find . -type d \( -path ./msg_srv -o -path ./config  \) -prune -o -mtime +10 -mtime -30 -exec rm -rdf {} \;

echo "done"

exit