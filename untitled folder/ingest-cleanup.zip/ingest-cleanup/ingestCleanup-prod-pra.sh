#!/bin/bash

cd /ingest

# exclude /ingest/config and /ingest/msg_srv
find . -type d \( -path ./msg_srv -o -path ./config  \) -prune -o -mtime +7 -mtime -30 -exec rm -r {} \;

echo "done"

exit