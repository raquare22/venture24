package com.optum.fds.paperless.util;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.exception.OutOfRetriesException;
import com.optum.fds.paperless.java.delegate.docvault.RetryOnExceptionHandler;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class ServiceUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceUtil.class);

    @Value("${ELGSOauthUrl}")
    private String elgsOauthUrl;

    @Value("${ELGSClientId}")
    private String elgsClientId;

    @Value("${ELGSClientSecret}")
    private String elgsClientSecret;

    @Value("${OCMNotificationUrl}")
    private String ocmNotificationUrl;

    @Value("${ELGSNotificationUrl}")
    private String elgsNotificationUrl;

    @Value("${ELGSSpaceIdList}")
    private List<Integer> elgsSpaceIdList;

    @Value("${OCMSpaceId}")
    private Integer ocmSpaceId;

    @Autowired
    private OauthManagerUtil oauthManagerUtil;

    @Autowired
    DocumentMetaDataService documentMetaDataService;

    @Autowired
    private RestTemplate restTemplate;

    public void sendMetadataValidationNotification(List<Map<String, Object>> errorList, DocumentMetaData document, org.bson.Document metadata, String doc360DocumentId, Integer spaceId) {
        LOGGER.info("Sending metadata validation notification for documentId = {}", Encode.forJava(document.getId()));

        String requestJson = "";
        String url = "";
        Map<String, Object> requestMap = new HashMap<>();
        requestMap.put("metadata", metadata);
        requestMap.put("document", document);
        requestMap.put("errorList", errorList);

        if (elgsSpaceIdList.contains(spaceId)) {
            requestJson  = TemplateFactory.getInstance("sendMetadataValidationNotificationELGS").convertWithTemplate(requestMap);
            url = elgsNotificationUrl;
        }
        else if (ocmSpaceId.equals(spaceId)) {
            requestJson = TemplateFactory.getInstance("sendMetadataValidationNotificationOCM").convertWithTemplate(requestMap);
            url = ocmNotificationUrl;
        }
        try {
            // get stargate token
            String token = oauthManagerUtil.getOauthToken("tokenStargateELGS", elgsClientId, elgsClientSecret, "client_credentials", elgsOauthUrl, false, null);
            ResponseEntity<String> response = postELGSWithRetry(token, requestJson, doc360DocumentId, url);


            LOGGER.info("Metadata validation API HTTPStatus={}", response.getStatusCode());

            if (response.getStatusCode().is2xxSuccessful()) {
                LOGGER.info("Metadata validation notification sent successfully for documentId = {}", Encode.forJava(document.getId()));
                Map<String, Object> updateMap = Map.of(Workflow.ELGS_NOTIFICATION_SENT, true);
                documentMetaDataService.saveDocumentMetaDataMulti(List.of(document.getId()), updateMap);

            }
        } catch (Exception e) {
            LOGGER.error("Exception sending metadata validation notification, e={}", ExceptionUtils.getStackTrace(e));
        }
    }

    public ResponseEntity<String> postELGSWithRetry(String accessToken, String requestJson, String docId, String url) throws OutOfRetriesException {
        ResponseEntity<String> response = null;

        var numRetries = 3;
        var timeToWaitMS = 500L;

        var retryHandler = new RetryOnExceptionHandler(numRetries, timeToWaitMS);
        String msg;
        while (retryHandler.shouldRetry()) {
            try {
                try {
                    if (retryHandler.isRetry()) {
                        String newToken = oauthManagerUtil.getOauthToken("tokenStargateELGS", elgsClientId, elgsClientSecret, "client_credentials", elgsOauthUrl, true, null);
                        String newAccessToken = "Bearer " + newToken;
                        LOGGER.info("postELGSWithRetry retrying elgs call with new token");
                        response = postELGSRequest(newAccessToken, requestJson, url);
                    } else {
                        response = postELGSRequest(accessToken, requestJson, url);
                    }
                    break;
                } catch (HttpClientErrorException.Unauthorized e) {
                    LOGGER.error("postELGSWithRetry HttpClientErrorException Unauthorized for documentId={}, responseBody={}, statusCode={}",
                            SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(docId), e.getResponseBodyAsString(), e.getStatusCode());
                    retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
                    retryHandler.exceptionOccurred();
                }catch (HttpClientErrorException e) {
                    LOGGER.error("postELGSWithRetry HttpClientErrorException for documentId={}, responseBody={}, statusCode={}",
                            SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(docId), e.getResponseBodyAsString(), e.getStatusCode());
                    //later check for codeQL for docId
                    return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
                } catch (HttpServerErrorException e) {
                    if (e instanceof HttpServerErrorException.GatewayTimeout || e instanceof HttpServerErrorException.BadGateway) {
                        LOGGER.error("postELGSWithRetry HttpClientErrorException for documentId={}, responseBody={}, statusCode={}",
                                SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(docId),
                                e.getResponseBodyAsString(), e.getStatusCode() );
                        retryHandler.exceptionOccurred();
                    }
                    else {
                        LOGGER.error("postELGSWithRetry HttpServerErrorException for documentId={}, responseBody={}, statusCode={}",
                                SanitizeUtil.sanitizeAlphaNumericStringWithHyphen(docId), e.getClass().getSimpleName(), e.getStatusCode());
                        return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
                    }
                } catch (RestClientException e) {
                    LOGGER.error("postELGSWithRetry RestClientException for document and exception, err={} ",
                            ExceptionUtils.getStackTrace(e));
                    retryHandler.exceptionOccurred();
                }
            } catch (com.optum.fds.paperless.java.delegate.docvault.OutOfRetriesException e) {
                msg = String.format(
                        "postELGSWithRetryRestClientException to endpoint %s and exhausted %s retries with retry time %s millis ",
                        url, retryHandler.getNumRetries(), retryHandler.getTimeToWaitMS());
                LOGGER.error(msg);
                throw new OutOfRetriesException(msg);
            }
        }
        return response;
    }


    public ResponseEntity<String> postELGSRequest(String token, String requestStr, String url) {
        var headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("accept", "application/json");
        headers.set("Authorization", token);
        HttpEntity<String> request = new HttpEntity<>(requestStr, headers);
        LOGGER.info("Send to ELGS metadata validation api, url={}, requestJson={}", url, SanitizeUtil.sanitizeString(requestStr));
        return restTemplate.postForEntity(url, request, String.class);
    }

}
