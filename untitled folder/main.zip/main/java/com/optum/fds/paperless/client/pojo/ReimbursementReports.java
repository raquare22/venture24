package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ReimbursementReports extends ClientMetadata {

    private static final long serialVersionUID = 4277217829493684690L;

    @JsonProperty("fdsCloudSpaceId")
    @JsonAlias("u_space_id")
    private String fdsCloudSpaceId;

    @JsonProperty("fdsCloudDocumentId")
    @JsonAlias("u_document_id")
    private String fdsCloudDocumentId;

    @JsonProperty("fdsCloudAttachmentId")
    @JsonAlias("u_attach_id")
    private String fdsCloudAttachmentId;

    @JsonProperty("cloudStorageProvider")
    @JsonAlias("u_cloud_stor_prov")
    private String cloudStorageProvider;

    // fileName is inherited from ClientMetadata (already mapped with alias u_filename).

    @JsonProperty("externalId")
    @JsonAlias("u_ext_id")
    private String externalId;

    @JsonProperty("attachmentExternalId")
    @JsonAlias("u_attch_ext_id")
    private String attachmentExternalId;

    @JsonProperty("attachmentModifiedBy")
    @JsonAlias("u_attach_update_user")
    private String attachmentModifiedBy;

    @JsonProperty("documentModifiedBy")
    @JsonAlias("u_doc_update_user")
    private String documentModifiedBy;

    @JsonProperty("version")
    @JsonAlias("u_ver")
    private String version;

    @JsonProperty("bucket")
    @JsonAlias("u_bucket")
    private String bucket;

    @JsonProperty("key")
    @JsonAlias("u_key")
    private String key;

    @JsonProperty("author")
    @JsonAlias("u_author")
    private String author;

    @JsonProperty("isMerged")
    @JsonAlias("u_is_merged")
    private String isMerged;

    @JsonProperty("emailAlertReq")
    @JsonAlias("u_email_alert_req")
    private String emailAlertReq;

    @JsonProperty("docLibUploadDate")
    @JsonAlias("u_doc_vault_upload_dt")
    private Date docLibUploadDate;

    @JsonProperty("notificationRequired")
    @JsonAlias("u_notification_req")
    private String notificationRequired;

    @JsonProperty("organization")
    @JsonAlias("u_org")
    private String organization;

    @JsonProperty("testHarness")
    @JsonAlias("u_test_harness")
    private String testHarness;

    @JsonProperty("subCategory")
    @JsonAlias("u_sub_category")
    private String subCategory;

    @JsonProperty("tin")
    @JsonAlias("u_tin")
    private String tin;

    @JsonProperty("parentId")
    @JsonAlias("u_parent_id")
    private String parentId;

    @JsonProperty("optionalMetadata")
    @JsonAlias("u_optional_metadata")
    private String optionalMetadata;

    @JsonProperty("isAvailable")
    @JsonAlias("u_isavailable")
    private String isAvailable;

    @JsonProperty("attachmentModifiedDate")
    @JsonAlias("u_attach_update_dt")
    private Date attachmentModifiedDate;

    @JsonProperty("virusScanStatus")
    @JsonAlias("u_virus_scan_status")
    private String virusScanStatus;

    @JsonProperty("workflow")
    @JsonAlias("u_workflow")
    private String workflow;

    @JsonProperty("virusScanTime")
    @JsonAlias("u_virus_scan_time")
    private Date virusScanTime;

    @JsonProperty("childId")
    @JsonAlias("u_child_id")
    private String childId;

    public ReimbursementReports() {
        this.category = "Payment Document";
        this.fileType = "Letter";
        this.tenant = "Link";
        this.fileDescription = "Provider Remittance Advice";
        this.createApplication = "USP-COM-PRS";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.privilege = "Claim Status";
        this.subCategory = "PR";
        this.setFilePath("Reimbursement");
    }

    public String getFdsCloudSpaceId() {
        return fdsCloudSpaceId;
    }

    public void setFdsCloudSpaceId(String fdsCloudSpaceId) {
        this.fdsCloudSpaceId = fdsCloudSpaceId;
    }

    public String getFdsCloudDocumentId() {
        return fdsCloudDocumentId;
    }

    public void setFdsCloudDocumentId(String fdsCloudDocumentId) {
        this.fdsCloudDocumentId = fdsCloudDocumentId;
    }

    public String getFdsCloudAttachmentId() {
        return fdsCloudAttachmentId;
    }

    public void setFdsCloudAttachmentId(String fdsCloudAttachmentId) {
        this.fdsCloudAttachmentId = fdsCloudAttachmentId;
    }

    public String getCloudStorageProvider() {
        return cloudStorageProvider;
    }

    public void setCloudStorageProvider(String cloudStorageProvider) {
        this.cloudStorageProvider = cloudStorageProvider;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getAttachmentExternalId() {
        return attachmentExternalId;
    }

    public void setAttachmentExternalId(String attachmentExternalId) {
        this.attachmentExternalId = attachmentExternalId;
    }

    public String getAttachmentModifiedBy() {
        return attachmentModifiedBy;
    }

    public void setAttachmentModifiedBy(String attachmentModifiedBy) {
        this.attachmentModifiedBy = attachmentModifiedBy;
    }

    public String getDocumentModifiedBy() {
        return documentModifiedBy;
    }

    public void setDocumentModifiedBy(String documentModifiedBy) {
        this.documentModifiedBy = documentModifiedBy;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getBucket() {
        return bucket;
    }

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIsMerged() {
        return isMerged;
    }

    public void setIsMerged(String isMerged) {
        this.isMerged = isMerged;
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        this.emailAlertReq = emailAlertReq;
    }

    public Date getDocLibUploadDate() {
        return docLibUploadDate;
    }

    public void setDocLibUploadDate(Date docLibUploadDate) {
        this.docLibUploadDate = docLibUploadDate;
    }

    public String getNotificationRequired() {
        return notificationRequired;
    }

    public void setNotificationRequired(String notificationRequired) {
        this.notificationRequired = notificationRequired;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getTestHarness() {
        return testHarness;
    }

    public void setTestHarness(String testHarness) {
        this.testHarness = testHarness;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getOptionalMetadata() {
        return optionalMetadata;
    }

    public void setOptionalMetadata(String optionalMetadata) {
        this.optionalMetadata = optionalMetadata;
    }

    public String getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(String isAvailable) {
        this.isAvailable = isAvailable;
    }

    public Date getAttachmentModifiedDate() {
        return attachmentModifiedDate;
    }

    public void setAttachmentModifiedDate(Date attachmentModifiedDate) {
        this.attachmentModifiedDate = attachmentModifiedDate;
    }

    public String getVirusScanStatus() {
        return virusScanStatus;
    }

    public void setVirusScanStatus(String virusScanStatus) {
        this.virusScanStatus = virusScanStatus;
    }

    public String getWorkflow() {
        return workflow;
    }

    public void setWorkflow(String workflow) {
        this.workflow = workflow;
    }

    public Date getVirusScanTime() {
        return virusScanTime;
    }

    public void setVirusScanTime(Date virusScanTime) {
        this.virusScanTime = virusScanTime;
    }

    public String getChildId() {
        return childId;
    }

    public void setChildId(String childId) {
        this.childId = childId;
    }

    @Override
    @JsonAlias("u_doc_sent_to")
    public void setDocSentTo(String docSentTo) {
        super.setDocSentTo(docSentTo);
    }

    @Override
    @JsonAlias("u_corp_mpin")
    public void setCorporateMpin(String corporateMpin) {
        super.setCorporateMpin(corporateMpin);
    }

    public enum ErrorMsg implements ErrorMessage {
        u_tin(12, "Missing or invalid data: u_tin");

        private final int errorCode;
        private final String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }


        @Override
        public int getErrorCode() {
            return errorCode;
        }

        @Override
        public String getErrorMessage() {
            return errorMessage;
        }
    }

    @Override
    @JsonAlias("u_expiry_dt")
    public void setExpiryDate(String expiryDate) {
        super.setExpiryDate(expiryDate);
    }
}
