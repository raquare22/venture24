package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.CustomizeDateDeserializer;
import com.optum.fds.paperless.client.ErrorMessage;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;

import static com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil.normalizeMemberName;

public class PriorAuth1ClickDoc360 extends ClientMetadata {

    private static final long serialVersionUID = 1L;

    private static final String CATEGORY = "Prior Auth Notification";
    private static final String FILE_TYPE = "Letter";
    private static final String TENANT = "Link";
    private static final String CREATE_APPLICATION = "1Click";
    private static final String EMPTY = "";
    private static final String DEFAULT_PRIVILEGE = "Notification/Prior Authorization Status Inquiry/Update";
    private static final String DEFAULT_SUBCATEGORY = "ZZ";

    @JsonProperty("subCategory")
    @JsonAlias("u_sub_category")
    private String subCategory;

    @JsonProperty("npi")
    @JsonAlias("u_npi")
    private String npi;

    @JsonProperty("tin")
    @JsonAlias("u_tin")
    private String tin;

    @JsonProperty("mpin")
    @JsonAlias("u_mpin")
    private String mpin="";

    @JsonProperty("emailAlertReq")
    @JsonAlias("u_email_alert_req")
    private String emailAlertReq="Y";

    @JsonProperty("dateOfService")
    @JsonAlias("u_dos_dt")
    @JsonDeserialize(using = CustomizeDateDeserializer.class)
    @CustomDateFormat(dateFormat = "MM/dd/yyyy") // 6/14/2018
    private Date dateOfService;

    @JsonProperty("RELATEDID")
    @JsonAlias("u_rel_ltr_id")
    private String RELATEDID;

    @JsonProperty("NotificationNumber")
    @JsonAlias("u_ntfy_nbr")
    private String notificationNumber;

    @JsonProperty("MemberID")
    @JsonAlias("u_mbr_id")
    private String memberId;

    @JsonProperty("providerName")
    @JsonAlias("u_phy_nm")
    private String providerName;

    @JsonProperty("MemberFirstName")
    @JsonAlias("u_mbr_fst_nm")
    private String memberFirstName;

    @JsonProperty("MemberLastName")
    @JsonAlias("u_mbr_lst_nm")
    private String memberLastName;

    @JsonProperty("memberName")
    private String memberName;

    @JsonProperty("LetterHistoryID")
    @JsonAlias("u_ltr_hist_id")
    private String LetterHistoryID;

    @JsonProperty("CONFIGKEY")
    @JsonAlias("u_config_key")
    private String CONFIGKEY;

    @JsonProperty("PassThruData")
    @JsonAlias("u_pass_thru_data")
    private String PassThruData;

    @JsonProperty("OriginPrintTrail")
    @JsonAlias("u_trl_id")
    private String originalPrintTrail;

    @JsonProperty("MailToAddress1")
    @JsonAlias("u_phy_nm")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    @JsonAlias("u_adr1")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    @JsonAlias("u_adr2")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    @JsonAlias("u_cty")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    @JsonAlias("u_st")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    @JsonAlias("u_zip")
    private String MailToAddress6;

    public PriorAuth1ClickDoc360(){
        this.category = CATEGORY;
        this.fileType = FILE_TYPE;
        this.tenant = TENANT;
        this.createApplication = CREATE_APPLICATION;
        this.docSentTo = EMPTY;
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = EMPTY;
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.privilege = DEFAULT_PRIVILEGE;
        this.subCategory = DEFAULT_SUBCATEGORY;
        PriorAuth1Click.Subcategory subCat = PriorAuth1Click.Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = DEFAULT_SUBCATEGORY;
            this.setFilePath(PriorAuth1ClickDoc360.Subcategory.ZZ.getFilePath());
        } else {
            this.subCategory = subCategory;
            PriorAuth1ClickDoc360.Subcategory subCat = null;
            try {
                subCat = PriorAuth1ClickDoc360.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = PriorAuth1ClickDoc360.Subcategory.ZZ;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        if (mpin != null && !mpin.isEmpty()) {
            String paddedMpin = StringUtils.leftPad(mpin, 9, '0');
            this.mpin = paddedMpin;
        }
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()){
            this.emailAlertReq = emailAlertReq;
        }
    }

    public Date getDateOfService() {
        return dateOfService;
    }

    public void setDateOfService(Date dateOfService) {
        this.dateOfService = dateOfService;
    }

    public String getRELATEDID() {
        return RELATEDID;
    }

    public void setRELATEDID(String RELATEDID) {
        this.RELATEDID = RELATEDID;
    }

    public String getNotificationNumber() {
        return notificationNumber;
    }

    public void setNotificationNumber(String notificationNumber) {
        this.notificationNumber = notificationNumber;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMemberFirstName() {
        return memberFirstName;
    }

    public void setMemberFirstName(String memberFirstName) {
        this.memberFirstName = memberFirstName;
    }

    public String getMemberLastName() {
        return memberLastName;
    }

    public void setMemberLastName(String memberLastName) {
        this.memberLastName = memberLastName;
        this.memberName = normalizeMemberName(this.memberFirstName, this.memberLastName);
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getLetterHistoryID() {
        return LetterHistoryID;
    }

    public void setLetterHistoryID(String letterHistoryID) {
        LetterHistoryID = letterHistoryID;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String CONFIGKEY) {
        this.CONFIGKEY = CONFIGKEY;
    }

    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String passThruData) {
        PassThruData = passThruData;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String mailToAddress1) {
        MailToAddress1 = mailToAddress1;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String mailToAddress2) {
        MailToAddress2 = mailToAddress2;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String mailToAddress3) {
        MailToAddress3 = mailToAddress3;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String mailToAddress4) {
        MailToAddress4 = mailToAddress4;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String mailToAddress5) {
        MailToAddress5 = mailToAddress5;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String mailToAddress6) {
        MailToAddress6 = mailToAddress6;
    }

    public String getNpi() { return npi; }

    public void setNpi(String npi) { this.npi = npi; }

    public enum ErrorMsg implements ErrorMessage {
        u_doc_creation_dt (12, "Missing or invalid data: u_doc_creation_dt"),
        u_sub_category (12, "Missing or invalid data: u_sub_category"),
        u_mpin (12,"Missing or invalid data: u_mpin"),
        u_email_alert_req (12, "Missing or invalid data: u_email_alert_req"),
        u_dos_dt (12, "Missing or invalid data: u_dos_dt"),
        u_rel_ltr_id (12, "Missing or invalid data: u_rel_ltr_id"),
        u_ntfy_nbr (12, "Missing or invalid data: u_ntfy_nbr "),
        u_tin(12, "Missing or invalid data: u_tin"),
        u_ltr_hist_id (22, "Missing or invalid data: u_ltr_hist_id(SEVERE)"),
        u_config_key (22, "Missing or invalid data: u_config_key(SEVERE)"),
        u_pass_thru_data (22, "Missing or invalid data: u_pass_thru_data(SEVERE)"),
        u_trl_id (22, "Missing or invalid data: u_trl_id(SEVERE)"),
        u_phy_nm (22, "Missing or invalid data: u_phy_nm(SEVERE)"),
        u_adr1 (22, "Missing or invalid data: u_adr1(SEVERE)"),
        u_cty (22, "Missing or invalid data: u_cty(SEVERE)"),
        u_st (22, "Missing or invalid data: u_st(SEVERE)"),
        u_zip (22, "Missing or invalid data: u_zip(SEVERE)");


        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }
        public String getErrorMessage() {
            return errorMessage;
        }

    }

    public enum Subcategory {

        // PriorAuth1Click
        A1 ("A1", "Commercial Prior Auth/Approved"),
        A2 ("A2", "Commercial Prior Auth/Denied"),
        A3 ("A3", "Commercial Prior Auth/Lack of Information"),
        A4 ("A4", "Medicare Prior Auth/Approved"),
        A5 ("A5", "Medicare Prior Auth/Denied"),
        A6 ("A6", "Medicare Prior Auth/Lack of Information"),
        A7 ("A7", "UHC West Prior Auth/Approved"),
        A8 ("A8", "UHC West Prior Auth/Denied"),
        A9 ("A9", "UHC West Prior Auth/Lack of Information"),
        N1 ("N1", "Community Plan Prior Auth/Approved"),
        N2 ("N2", "Community Plan Prior Auth/Denied"),
        N3 ("N3", "Community Plan Prior Auth/Lack of Information"),
        ZZ ("ZZ", "Misc. Prior Auth/Other");

        private String subCat;
        private String filePath;

        Subcategory(String subCat, String filePath){
            this.subCat = subCat;
            this.filePath = filePath;
        }
        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }
}
