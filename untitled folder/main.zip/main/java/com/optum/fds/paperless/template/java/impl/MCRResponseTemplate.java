package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.list.mutable.FastList;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class MCRResponseTemplate extends TemplateHandler {

    @Override
    public String convertWithTemplate(String jsonString) {
        var st = this.templateLoader.getTemplate(Templates.MCR_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<MCRResponseTemplate.Params>newList();
        var counter = new Counter();

        for (var documentMetaData : documentMetaDataList) {
            var metaData = documentMetaData.getMetadata();

            var createApplication = metaData.getString(Workflow.CREATE_APPLICATION);
            var docLibUploadDate = metaData.getString(Workflow.METADATA_DOCLIB_UPLOAD_DATE);

            var passThruData = metaData.getString(Workflow.PASS_THRU_DATA);
            var deliveryMethod = metaData.getString(Workflow.E_DELIVERY_ERROR);
            var providerEmailId = metaData.getString(Workflow.PROVIDER_EMAIL_ID);

            var dateEmailSent = "";
            if (metaData.getString(Workflow.DATE_EMAIL_SENT) != null
                    && metaData.getString(Workflow.DATE_EMAIL_SENT) != "")
                dateEmailSent = dateEmailSentFormat(metaData.getString(Workflow.DATE_EMAIL_SENT));

            paramsList.add(new MCRResponseTemplate.Params(createApplication, docLibUploadDate, passThruData,
                    deliveryMethod, providerEmailId, dateEmailSent));

        }

        counter.add(paramsList.size());
        Date date = new Date();
        return st.add("list", paramsList)
                .add("counter", counter.toString())
                .add("date", date)
                .render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        var st = this.templateLoader.getTemplate(Templates.MCR_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<MCRResponseTemplate.Params>newList();
        var counter = new Counter();

        for (var documentMetaData : documentMetaDataList) {
            var metaData = documentMetaData.getMetadata();

            var createApplication = metaData.getString(Workflow.CREATE_APPLICATION);

            String docLibUploadDate = "yyyyMMddHHmm";

            var passThruData = metaData.getString(Workflow.PASS_THRU_DATA);
            var deliveryMethod = metaData.getString(Workflow.E_DELIVERY_ERROR);
            var providerEmailId = metaData.getString(Workflow.PROVIDER_EMAIL_ID);

            var dateEmailSent = "";
            if (metaData.getString(Workflow.DATE_EMAIL_SENT) != null
                    && metaData.getString(Workflow.DATE_EMAIL_SENT) != "")
                dateEmailSent = dateEmailSentFormat(metaData.getString(Workflow.DATE_EMAIL_SENT));
            paramsList.add(new MCRResponseTemplate.Params(createApplication, docLibUploadDate, passThruData,
                    deliveryMethod, providerEmailId, dateEmailSent));

        }

        counter.add(paramsList.size());
        Date date = new Date();
        return st.add("list", paramsList)
                .add("counter", counter.toString())
                .add("date", date)
                .render();
    }

    private String dateEmailSentFormat(String string) {
        SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        SimpleDateFormat targetFormat = new SimpleDateFormat("yyyyMMdd'T'HH:mm:ss.SSS'Z'");
        Date date = null;
        try {
            date = originalFormat.parse(string);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        String formattedDate = targetFormat.format(date);
        return formattedDate;
    }

    static class Params {
        private final String createApplication;
        private final String docLibUploadDate;
        private final String passThruData;
        private final String deliveryError;
        private final String providerEmailId;
        private final String dateEmailSent;

        public Params(String createApplication, String docLibUploadDate, String passThruData, String deliveryError,
                      String providerEmailId, String dateEmailSent) {

            this.createApplication = createApplication;
            this.docLibUploadDate = docLibUploadDate;
            this.passThruData = passThruData != null ? passThruData : " ";
            this.deliveryError = deliveryError != null ? deliveryError : " ";
            this.providerEmailId = providerEmailId != null ? providerEmailId : " ";
            this.dateEmailSent = dateEmailSent != "" ? dateEmailSent : " ";
        }

        public String getCreateApplication() {
            return createApplication;
        }

        public String getDocLibUploadDate() {
            return docLibUploadDate;
        }

        public String getPassThruData() {
            return passThruData;
        }

        public String getDeliveryError() {
            return deliveryError;
        }

        public String getProviderEmailId() {
            return providerEmailId;
        }

        public String getDateEmailSent() {
            return dateEmailSent;
        }
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        return null;
    }
}