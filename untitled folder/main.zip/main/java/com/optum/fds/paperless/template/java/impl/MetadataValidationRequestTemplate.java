package com.optum.fds.paperless.template.java.impl;
import java.io.IOException;

import java.util.List;
import java.util.Map;


import com.google.gson.Gson;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;

import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class MetadataValidationRequestTemplate extends TemplateHandler {

    @Value("${ELGSSpaceIdList}")
    private List<Integer> elgsSpaceIdList;

    @Value("${OCMSpaceId}")
    private Integer ocmSpaceId;

    private static final Logger LOGGER = LoggerFactory.getLogger(MetadataValidationRequestTemplate.class);

    @Override
    public String convertWithTemplate(String jsonString) {
        DocumentMetaData document;

        try {
            document = WorkFlowUtil.readDocumentFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return convertWithTemplate(document);
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {

        return null;
    }


    @Override
    public String convertWithTemplate(Object pojo) {
        var st = this.templateLoader.getTemplate(Templates.SEND_METADATA_VALIDATION_NOTIFICATION_ELGS);

        Map<String, Object> map = (Map<String, Object>) pojo;

        DocumentMetaData document = (DocumentMetaData) map.get("document");
        org.bson.Document metadata = (org.bson.Document) map.get("metadata");
        List<String> errorList = (List<String>) map.get("errorList");
        String doc360DocumentId = (String) map.get("doc360DocumentId");
        Integer spaceId = document.getSpaceId();

            if (elgsSpaceIdList != null && elgsSpaceIdList.contains(spaceId)) {
                st = st;
            } else if (ocmSpaceId != null && ocmSpaceId.equals(spaceId)) {
                st = this.templateLoader.getTemplate(
                        Templates.SEND_METADATA_VALIDATION_NOTIFICATION_OCM);
            }

        String errorListStr = new Gson().toJson(errorList);


        return st.add("errorListJson", errorListStr).add("document", document)
                .add("metadata", metadata)
                .add("doc360DocumentId", doc360DocumentId)
                .render();
    }


}
