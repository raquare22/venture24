package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

import static com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil.normalizePipeDelimitedValue;

public class NicePRA extends ClientMetadata {

    private static final long serialVersionUID = 1L;
    private static final String DEFAULT_CATEGORY = "Payment Document";
    private static final String DEFAULT_FILE_TYPE = "Letter";
    private static final String DEFAULT_TENANT = "Link";
    private static final String DEFAULT_FILE_DESCRIPTION = "Nice Payment Advice";
    private static final String DEFAULT_CREATE_APPLICATION = "NICE-PRA";
    private static final String DEFAULT_SUBCATEGORY = "PR";
    private static final String DEFAULT_PRIVILEGE = "Claim Status";
    private static final String DEFAULT_DOC_SENT_TO = "";
    private static final boolean DEFAULT_SEND_TO_DOC_VAULT = false;
    private static final boolean DEFAULT_SEND_TO_SHUTTERFLY = false;
    private static final boolean DEFAULT_POST_CARD_IND = true;
    private static final boolean DEFAULT_SEND_EMAIL_NOTIFICATIONS = false;
    private static final boolean DEFAULT_SEND_PEN_API_REQUEST = false;
    private static final String DEFAULT_PROVIDER_EMAIL_ID = "";

    @JsonProperty("tin")
    @JsonAlias("u_tin")
    private String tin;

    @JsonProperty("mpin")
    @JsonAlias("u_mpin")
    private String mpin = "";

    @JsonProperty("emailAlertReq")
    @JsonAlias("u_email_alert_req")
    private String emailAlertReq = "Y";

    @JsonProperty("EFT_Ind")
    @JsonAlias("u_eft_ind")
    private String EFT_Ind;

    @JsonProperty("physicianName")
    @JsonAlias("u_payment_nm")
    private String physicianName;

    @JsonProperty("CheckTraceNumber")
    @JsonAlias("u_payment_nbr")
    private String CheckTraceNumber;

    @JsonProperty("DefaultUsed")
    private String DefaultUsed;

    @JsonProperty("CheckAmt")
    @JsonAlias("u_payment_amt")
    private String CheckAmt;

    @JsonProperty("CONFIGKEY")
    @JsonAlias("u_config_key")
    private String CONFIGKEY;

    @JsonProperty("originalPrintTrail")
    @JsonAlias("u_trl_id")
    private String originalPrintTrail;

    @JsonProperty("PassThruData")
    @JsonAlias("u_pass_thru_data")
    private String PassThruData;

    @JsonProperty("subCategory")
    @JsonAlias("u_sub_category")
    private String subCategory;

    @JsonProperty("paymentNumber")
    @JsonAlias("u_vendor_pay_id")
    private String paymentNumber;

    @JsonProperty("MailToAddress1")
    @JsonAlias("u_mail_to_adr1")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    @JsonAlias("u_mail_to_adr2")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    @JsonAlias("u_mail_to_adr3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    @JsonAlias("u_mail_to_adr4")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    @JsonAlias("u_mail_to_adr5")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    @JsonAlias("u_mail_to_adr6")
    private String MailToAddress6;

    @JsonProperty("npi")
    @JsonAlias("u_npi")
    private String npi;

    @JsonProperty("multClaimNumber")
    @JsonAlias("u_clm_nbr")
    private String multClaimNumber;

    @JsonProperty("multMemberId")
    @JsonAlias("u_mbr_id")
    private String multMemberId;

    @JsonProperty("multPatientAccountNumber")
    @JsonAlias("u_patient_acct_nbr")
    private String multiPatientNumber;



    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        this.mpin = mpin;
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        this.emailAlertReq = emailAlertReq;
    }

    public String getEFT_Ind() {
        return EFT_Ind;
    }

    public void setEFT_Ind(String EFT_Ind) {
        this.EFT_Ind = EFT_Ind;
    }

    public String getPhysicianName() {
        return physicianName;
    }

    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public String getCheckTraceNumber() {
        return CheckTraceNumber;
    }

    public void setCheckTraceNumber(String checkTraceNumber) {
        CheckTraceNumber = checkTraceNumber;
    }

    public String getDefaultUsed() {
        return DefaultUsed;
    }

    public void setDefaultUsed(String defaultUsed) {
        DefaultUsed = defaultUsed;
    }

    public String getCheckAmt() {
        return CheckAmt;
    }

    public void setCheckAmt(String checkAmt) {
        CheckAmt = checkAmt;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String CONFIGKEY) {
        this.CONFIGKEY = CONFIGKEY;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String passThruData) {
        PassThruData = passThruData;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "PR";
            this.setFilePath(NicePRA.Subcategory.PR.getFilePath());
        } else {
            this.subCategory = subCategory;
            NicePRA.Subcategory subCat = null;
            try {
                subCat = NicePRA.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = NicePRA.Subcategory.PR;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }

    public String getPaymentNumber() {
        return paymentNumber;
    }

    public void setPaymentNumber(String paymentNumber) {
        this.paymentNumber = paymentNumber;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String mailToAddress1) {
        MailToAddress1 = mailToAddress1;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String mailToAddress2) {
        MailToAddress2 = mailToAddress2;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String mailToAddress3) {
        MailToAddress3 = mailToAddress3;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String mailToAddress4) {
        MailToAddress4 = mailToAddress4;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String mailToAddress5) {
        MailToAddress5 = mailToAddress5;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String mailToAddress6) {
        MailToAddress6 = mailToAddress6;
    }

    public String getNpi() {
        return npi;
    }

    public void setNpi(String npi) {
        this.npi = npi;
    }

    public String getMultMemberId() {
        return multMemberId;
    }

    @JsonSetter("multMemberId")
    @JsonAlias("u_mbr_id")
    public void setMultMemberId(Object raw) {
        this.multMemberId = normalizePipeDelimitedValue(raw);
    }

    public String getMultClaimNumber() {
        return multClaimNumber;
    }

    @JsonSetter("multClaimNumber")
    @JsonAlias("u_clm_nbr")
    public void setMultClaimNumber(Object raw) {
        this.multClaimNumber = normalizePipeDelimitedValue(raw);
    }

    public String getMultiPatientNumber() {
        return multiPatientNumber;
    }

    @JsonSetter("multPatientAccountNumber")
    @JsonAlias("u_patient_acct_nbr")
    public void setMultiPatientNumber(Object raw) {
        this.multiPatientNumber = normalizePipeDelimitedValue(raw);
        }

    public NicePRA() {
        this.category = DEFAULT_CATEGORY;
        this.fileType = DEFAULT_FILE_TYPE;
        this.tenant = DEFAULT_TENANT;
        this.fileDescription = DEFAULT_FILE_DESCRIPTION;
        this.createApplication = DEFAULT_CREATE_APPLICATION;
        this.docSentTo = DEFAULT_DOC_SENT_TO;
        this.sendToDocVault = DEFAULT_SEND_TO_DOC_VAULT;
        this.sendToShutterfly = DEFAULT_SEND_TO_SHUTTERFLY;
        this.providerEmailId = DEFAULT_PROVIDER_EMAIL_ID;
        this.postCardInd = DEFAULT_POST_CARD_IND;
        this.dateEmailSent = null;
        this.sendEmailNotifications = DEFAULT_SEND_EMAIL_NOTIFICATIONS;
        this.sendPENAPIRequest = DEFAULT_SEND_PEN_API_REQUEST;
        this.subCategory = DEFAULT_SUBCATEGORY;
        this.privilege = DEFAULT_PRIVILEGE;
        this.mpin = "";
        this.emailAlertReq = "Y";
    }

    public enum ErrorMsg implements ErrorMessage {

        u_tin(22, "Missing or invalid data: u_tin"),
        u_mpin(22, "Missing or invalid data: u_mpin"),
        u_email_alert_req(12, "Missing or invalid data: u_email_alert_req"),
        u_eft_ind(22, "Missing or invalid data: u_eft_ind"),
        u_payment_nbr(12, "Missing or invalid data: u_payment_nbr"),
        u_config_key(22, "Missing or invalid data: u_config_key (SEVERE)"),
        u_trl_id(22, "Missing or invalid data: u_trl_id (SEVERE)"),
        u_pass_thru_data(22, "Missing or invalid data: u_pass_thru_data (SEVERE)"),
        u_sub_category(12, "Missing or invalid data: u_sub_category"),
        u_mail_to_adr1(22, "Missing or invalid data: u_mail_to_adr1 (SEVERE)"),
        u_mail_to_adr2(22, "Missing or invalid data: u_mail_to_adr2 (SEVERE)"),
        u_doc_creation_dt(12, "Missing or invalid data: u_doc_creation_dt");

        private final int errorCode;
        private final String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }
    public enum Subcategory {

        P5 ("P5", "UHC West Payment Packages/Detailed Pmt Docs"),
        PR ("PR", "Other PRAs/Other");

        private String subCat;
        private String filePath;

        Subcategory(String subCat, String filePath){
            this.subCat = subCat;
            this.filePath = filePath;
        }
        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }
 }
