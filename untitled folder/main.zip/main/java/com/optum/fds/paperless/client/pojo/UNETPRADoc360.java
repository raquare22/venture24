package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

import static com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil.normalizePipeDelimitedValue;


@JsonIgnoreProperties(ignoreUnknown = true)
public class UNETPRADoc360 extends ClientMetadata {

    private static final long serialVersionUID = 7451096330427761820L;

    @JsonProperty("tin")
    @JsonAlias({"u_master_tin", "u_tin"})
    private String tin;

    @JsonProperty("mpin")
    @JsonAlias("u_indiv_prov_mpin")
    private String mpin = "";

    @JsonProperty("emailAlertReq")
    @JsonAlias("u_email_alert_req")
    private String emailAlertReq = "Y";

    @JsonProperty("EFT_Ind")
    @JsonAlias("u_eft_ind")
    private String EFT_Ind;

    @JsonProperty("835_Ind")
    @JsonAlias("u_835_ind")
    private String Ind_835;

    @JsonProperty("physicianName")
    @JsonAlias("u_phy_nm")
    private String physicianName;

    @JsonProperty("CheckTraceNumber")
    @JsonAlias({"u_check_nbr", "u_chk_nbr"})
    private String CheckTraceNumber;

    @JsonProperty("multClaimNumber")
    @JsonAlias("u_clm_nbr")
    private String multClaimNumber;

    @JsonProperty("multMemberId")
    @JsonAlias({"u_member_id", "u_mbr_id"})
    private String multMemberId;

    @JsonProperty("DefaultUsed")
    private String DefaultUsed;

    @JsonProperty("CheckAmt")
    @JsonAlias("u_chk_amt")
    private String CheckAmt;

    @JsonProperty("CONFIGKEY")
    @JsonAlias("u_config_key")
    private String CONFIGKEY;

    @JsonProperty("originalPrintTrail")
    @JsonAlias("u_trl_id")
    private String originalPrintTrail;

    @JsonProperty("PassThruData")
    @JsonAlias("u_pass_thru_data")
    private String PassThruData;

    @JsonProperty("MailToAddress1")
    @JsonAlias("u_mail_to_adr1")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    @JsonAlias("u_mail_to_adr2")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    @JsonAlias("u_mail_to_adr3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    @JsonAlias("u_mail_to_adr4")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    @JsonAlias("u_mail_to_adr5")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    @JsonAlias("u_mail_to_adr6")
    private String MailToAddress6;

    @JsonProperty("subCategory")
    @JsonAlias("u_sub_category")
    protected String subCategory;

    @JsonProperty("NPI")
    @JsonAlias("u_npi")
    private String npi;

    @JsonProperty("paymentNumber")
    @JsonAlias("u_vendor_pay_id")
    private String paymentNumber;

    @JsonProperty("multPatientAccountNumber")
    @JsonAlias("u_patient_acct_nbr")
    private String multPatientAccountNumber;

    public UNETPRADoc360() {
        this.category = "Payment Document";
        this.fileType = "Letter";
        this.tenant = "Link";
        this.fileDescription = "Provider Remittance Advice";
        this.createApplication = "PmntEng";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.privilege = "Claim Status";
        this.subCategory = "PR";
        Subcategory subCat = Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        if (mpin != null) {
            this.mpin = mpin;
        }
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()) {
            this.emailAlertReq = emailAlertReq;
        }
    }

    public String getEFT_Ind() {
        return EFT_Ind;
    }

    public void setEFT_Ind(String eFT_Ind) {
        EFT_Ind = eFT_Ind;
    }

    public String getInd_835() {
        return Ind_835;
    }

    public void setInd_835(String ind_835) {
        Ind_835 = ind_835;
    }

    public String getPhysicianName() {
        return physicianName;
    }

    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public String getCheckTraceNumber() {
        return CheckTraceNumber;
    }

    public void setCheckTraceNumber(String checkTraceNumber) {
        CheckTraceNumber = checkTraceNumber;
    }

    public String getMultClaimNumber() {
        return multClaimNumber;
    }

    @JsonSetter("multClaimNumber")
    @JsonAlias("u_clm_nbr")
    public void setMultClaimNumber(Object raw) {
        this.multClaimNumber = normalizePipeDelimitedValue(raw);
    }

    public String getMultMemberId() {
        return multMemberId;
    }

    @JsonSetter("multMemberId")
    @JsonAlias({"u_member_id", "u_mbr_id"})
    public void setMultMemberId(Object raw) {
        this.multMemberId = normalizePipeDelimitedValue(raw);
    }


    public String getMemberId() {
        return multMemberId;
    }

    public void setMemberId(String memberId) {
        this.multMemberId = memberId;
    }

    public String getDefaultUsed() {
        return DefaultUsed;
    }

    public void setDefaultUsed(String defaultUsed) {
        DefaultUsed = defaultUsed;
    }

    public String getCheckAmt() {
        return CheckAmt;
    }

    public void setCheckAmt(String checkAmt) {
        CheckAmt = checkAmt;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String cONFIGKEY) {
        CONFIGKEY = cONFIGKEY;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String passThruData) {
        PassThruData = passThruData;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String mailToAddress1) {
        MailToAddress1 = mailToAddress1;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String mailToAddress2) {
        MailToAddress2 = mailToAddress2;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String mailToAddress3) {
        MailToAddress3 = mailToAddress3;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String mailToAddress4) {
        MailToAddress4 = mailToAddress4;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String mailToAddress5) {
        MailToAddress5 = mailToAddress5;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String mailToAddress6) {
        MailToAddress6 = mailToAddress6;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        if (subCategory == null || subCategory.isEmpty()) {
            this.subCategory = "PR";
            this.setFilePath(Subcategory.PR.getFilePath());
        } else {
            this.subCategory = subCategory;
            Subcategory subCat;
            try {
                subCat = Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = Subcategory.PR;
            }
            this.setFilePath(subCat.getFilePath());
        }

        if (this.getExpiryDate() != null && this.getExpiryDate().length() == 7) {
            this.setExpiryDate(this.vcpExpiryDateFormat(this.getExpiryDate(), this.subCategory));
        }
    }

    public String getNpi() {
        return npi;
    }

    public void setNpi(String npi) {
        this.npi = npi;
    }

    public String getPaymentNumber() {
        return paymentNumber;
    }

    public void setPaymentNumber(String paymentNumber) {
        this.paymentNumber = paymentNumber;
    }

    public String getMultPatientAccountNumber() {
        return multPatientAccountNumber;
    }

    @JsonSetter("multPatientAccountNumber")
    @JsonAlias("u_patient_acct_nbr")
    public void setMultPatientAccountNumber(Object raw) {
        this.multPatientAccountNumber = normalizePipeDelimitedValue(raw);
    }

    public enum ErrorMsg implements ErrorMessage {
        u_eft_ind (22, "Missing or invalid data: EFT_Ind(SEVERE)"),
        u_config_key (22, "Missing or invalid data: CONFIGKEY(SEVERE)"),
        u_trl_id (22, "Missing or invalid data: originalPrintTrail(SEVERE)"),
        u_pass_thru_data (22, "Missing or invalid data: PassThruData(SEVERE)"),
        u_mail_to_adr1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"),
        u_mail_to_adr3 (22, "Missing or invalid data: MailToAddress3(SEVERE)"),
        u_tin_22 (22, "Missing or invalid data: tin(SEVERE)"),

        u_indiv_prov_mpin (12, "Missing or invalid data: mpin"),
        u_email_alert_req (12, "Missing or invalid data: emailAlertReq"),
        u_check_nbr (12, "Missing or invalid data: CheckTraceNumber"),
        u_chk_nbr (12, "Missing or invalid data: CheckTraceNumber"),
        u_clm_nbr (12, "Missing or invalid data: multClaimNumber"),
        u_sub_category (12, "Missing or invalid data: subCategory"),
        u_doc_creation_dt (12, "Missing or invalid data: createdDate"),
        u_tin_12 (12, "Missing or invalid data: tin");

        private final int errorCode;
        private final String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }

    public enum Subcategory {

        P1 ("P1", "Commercial/Detailed PRAs"),
        P2 ("P2", "Commercial/Virtual Card Payments and Info Only PRAs"),
        P8 ("P8", "Commercial/Zero-Dollar PRAs"),
        P9 ("P9", "Medicare/Zero-Dollar PRAs"),
        P0 ("P0", "Community Plan/Zero-Dollar PRAs"),
        E1 ("E1", "Other/Zero-Dollar PRAs"),
        PR ("PR", "Other PRAs/Other");

        private final String subCat;
        private final String filePath;

        Subcategory(String subCat, String filePath) {
            this.subCat = subCat;
            this.filePath = filePath;
        }

        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }
}


