package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentEngine835Files extends ClientMetadata {

	private static final long serialVersionUID = 1L;

	@JsonProperty("claimNumber")
	@JsonAlias("u_clm_nbr")
	private String claimNumber;

	@JsonProperty("checkAmt")
	@JsonAlias("u_chk_amnt")
	private String checkAmt;

	@JsonProperty("checkTraceNumber")
	@JsonAlias("u_chk_trace_nbr")
	private String checkTraceNumber;

	@JsonProperty("providerName")
	@JsonAlias("u_physician_nm")
	private String providerName;

	@JsonProperty("memberId")
	@JsonAlias("u_mbr_id")
	private String memberId;

	@JsonProperty("npi")
	@JsonAlias("u_npi")
	private String npi;

	@JsonProperty("paymentNumber")
	@JsonAlias("u_vendor_pay_id")
	private String paymentNumber;

	@JsonProperty("primaryId")
	@JsonAlias("u_pay_id")
	private String primaryId;

	@JsonProperty("patientAccountNumber")
	@JsonAlias("u_patient_acct_nbr")
	private String patientAccountNumber;

	@JsonProperty("tin")
	@JsonAlias("u_tin")
	private String tin;

	@JsonProperty("subCategory")
	@JsonAlias("u_sub_category")
	private String subCategory;

	public PaymentEngine835Files() {

		this.category = "835 Files";
		this.fileType = "835 Files";
		this.fileDescription = "835 Files";
		this.tenant = "Link";

		this.createApplication = "PaymentEngine";
		this.privilege = "Claim Status";

		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;

		this.setFilePath("PaymentEngine835Files");
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getCheckAmt() {
		return checkAmt;
	}

	public void setCheckAmt(String checkAmt) {
		this.checkAmt = checkAmt;
	}

	public String getCheckTraceNumber() {
		return checkTraceNumber;
	}

	public void setCheckTraceNumber(String checkTraceNumber) {
		this.checkTraceNumber = checkTraceNumber;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getNpi() {
		return npi;
	}

	public void setNpi(String npi) {
		this.npi = npi;
	}

	public String getPaymentNumber() {
		return paymentNumber;
	}

	public void setPaymentNumber(String paymentNumber) {
		this.paymentNumber = paymentNumber;
	}

	public String getPrimaryId() {
		return primaryId;
	}

	public void setPrimaryId(String primaryId) {
		this.primaryId = primaryId;
	}

	public String getPatientAccountNumber() {
		return patientAccountNumber;
	}

	public void setPatientAccountNumber(String patientAccountNumber) {
		this.patientAccountNumber = patientAccountNumber;
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public enum ErrorMsg implements ErrorMessage {

		u_tin(12, "Missing or invalid data: u_tin");

		private final int errorCode;
		private final String errorMessage;

		ErrorMsg(int code, String message) {
			this.errorCode = code;
			this.errorMessage = message;
		}

		@Override
		public int getErrorCode() {
			return errorCode;
		}

		@Override
		public String getErrorMessage() {
			return errorMessage;
		}
	}
}