package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;
import com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil;


@JsonIgnoreProperties(ignoreUnknown = true)
public class ODARDoc360 extends ClientMetadata {

    private static final long serialVersionUID = -8737265368684222974L;

    @JsonProperty("subCategory")
    @JsonAlias("u_sub_category")
    protected String subCategory;

    @JsonProperty("tin")
    @JsonAlias("u_tin")
    private String tin;

    @JsonProperty("mpin")
    @JsonAlias("u_mpin")
    private String mpin = "";

    @JsonProperty("emailAlertReq")
    @JsonAlias("u_email_alert_req")
    private String emailAlertReq = "N";

    @JsonProperty("multDivisionCode")
    private String multDivisionCode;

    @JsonProperty("patientAccountNumber")
    @JsonAlias("u_ptnt_acct_nbr")
    private String patientAccountNumber;

    @JsonProperty("physicianName")
    @JsonAlias("u_phy_nm")
    private String physicianName;

    @JsonProperty("memberName")
    private String memberName;

    @JsonProperty("memberFirstName")
    @JsonAlias("u_mbr_fst_nm")
    private String memberFirstName;

    @JsonProperty("memberLastName")
    @JsonAlias("u_mbr_lst_nm")
    private String memberLastName;

    @JsonProperty("multCheckNumber")
    @JsonAlias("u_chk_nbr")
    private String multCheckNumber;

    @JsonProperty("letterGroupId")
    @JsonAlias("u_ltr_grp_id")
    private String letterGroupId;

    @JsonProperty("multClaimNumber")
    @JsonAlias("u_clm_nbr")
    private String multClaimNumber;

    @JsonProperty("source")
    @JsonAlias("u_source")
    private String source;

    @JsonProperty("letterType")
    private String letterType;

    @JsonProperty("facilityType")
    private String facilityType;

    @JsonProperty("CONFIGKEY")
    @JsonAlias("u_config_key")
    private String CONFIGKEY;

    @JsonProperty("originalPrintTrail")
    @JsonAlias("u_trl_id")
    private String originalPrintTrail;

    @JsonProperty("PassThruData")
    @JsonAlias("u_pass_thru_data")
    private String passThruData;

    @JsonProperty("MailToAddress1")
    @JsonAlias("u_mail_to_adr1")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    @JsonAlias("u_mail_to_adr2")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    @JsonAlias("u_mail_to_adr3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    @JsonAlias("u_mail_to_adr4")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    @JsonAlias("u_mail_to_adr5")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    @JsonAlias("u_mail_to_adr6")
    private String MailToAddress6;

    @JsonProperty("memberId")
    @JsonAlias("u_mbr_id")
    private String memberId;

    @JsonProperty("attachmentControlId")
    @JsonAlias("u_attch_ctl_id")
    private String attachmentControlId;

    @JsonProperty("providerId")
    @JsonAlias("u_attch_prov_id")
    private String providerId;

    @JsonProperty("batchId")
    @JsonAlias("u_batch_id")
    private String batchId;

    @JsonProperty("dccNumber")
    @JsonAlias("u_dcc_nbr")
    private String dccNumber;

    @JsonProperty("div")
    @JsonAlias("u_div")
    private String div;

    @JsonProperty("payloc")
    @JsonAlias("u_payloc_engine")
    private String payloc;

    @JsonProperty("policyGroupNumber")
    @JsonAlias("u_pol_grp_nbr")
    private String policyGroupNumber;

    @JsonProperty("policyId")
    @JsonAlias("u_pol_nbr")
    private String policyId;

    @JsonProperty("receivedDate")
    @JsonAlias("u_received_dt")
    private String receivedDate;

    @JsonProperty("saOI")
    @JsonAlias("u_sa_oi")
    private String saOI;

    @JsonProperty("sequenceNumber")
    @JsonAlias("u_seq_nbr")
    private String sequenceNumber;

    @JsonProperty("sortType")
    @JsonAlias("u_srt_typ")
    private String sortType;

    @JsonProperty("state")
    @JsonAlias("u_st")
    private String state;

    @JsonProperty("stateCode")
    @JsonAlias("u_st_cd")
    private String stateCode;

    @JsonProperty("queue")
    @JsonAlias("u_queue")
    private String queue;

    @JsonProperty("docCategoryCode")
    @JsonAlias("u_doc_catgy_cd")
    private String docCategoryCode;

    @JsonProperty("docSourceCode")
    @JsonAlias("u_doc_src_cd")
    private String docSourceCode;

    @JsonProperty("docSubTypeCode")
    @JsonAlias("u_doc_sub_typ_cd")
    private String docSubTypeCode;

    @JsonProperty("docTypeCode")
    @JsonAlias("u_doc_typ_cd")
    private String docTypeCode;

    @JsonProperty("emailAddress")
    @JsonAlias("u_email_addr")
    private String emailAddress;

    @JsonProperty("globalDocId")
    @JsonAlias("u_gbl_doc_id")
    private String globalDocId;

    @JsonProperty("intakeChannel")
    @JsonAlias("u_int_chnl")
    private String intakeChannel;

    public ODARDoc360() {
        this.category = "Overpayment Documents";
        this.fileType = "Letter";
        this.tenant = "Link";
        this.fileDescription = "Overpayment Document";
        this.createApplication = "ODAR";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.privilege = "Claim Status";
        setSubCategory("OP");
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        if (subCategory == null || subCategory.isEmpty()) {
            this.subCategory = "OP";
            this.setFilePath(ODAR.Subcategory.OP.getFilePath());
        } else {
            this.subCategory = subCategory;
            ODAR.Subcategory subCat;
            try {
                subCat = ODAR.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = ODAR.Subcategory.OP;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }


    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        if (mpin != null) {
            this.mpin = mpin;
        }
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()) {
            this.emailAlertReq = emailAlertReq;
        }
    }

    public String getMultDivisionCode() {
        return multDivisionCode;
    }

    public void setMultDivisionCode(String multDivisionCode) {
        this.multDivisionCode = multDivisionCode;
    }

    public String getPatientAccountNumber() {
        return patientAccountNumber;
    }

    public void setPatientAccountNumber(String patientAccountNumber) {
        this.patientAccountNumber = patientAccountNumber;
    }

    public String getPhysicianName() {
        return physicianName;
    }

    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public String getMultCheckNumber() {
        return multCheckNumber;
    }

    public void setMultCheckNumber(String multCheckNumber) {
        this.multCheckNumber = NormalizeUtil.normalizePipeDelimitedValue(multCheckNumber);
    }

    public String getLetterGroupId() {
        return letterGroupId;
    }

    public void setLetterGroupId(String letterGroupId) {
        this.letterGroupId = letterGroupId;
    }

    public String getMultClaimNumber() {
        return multClaimNumber;
    }

    public void setMultClaimNumber(String multClaimNumber) {
        this.multClaimNumber = NormalizeUtil.normalizePipeDelimitedValue(multClaimNumber);
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getLetterType() {
        return letterType;
    }

    public void setLetterType(String letterType) {
        this.letterType = letterType;
    }

    public String getFacilityType() {
        return facilityType;
    }

    public void setFacilityType(String facilityType) {
        this.facilityType = facilityType;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String CONFIGKEY) {
        this.CONFIGKEY = CONFIGKEY;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getPassThruData() {
        return passThruData;
    }

    public void setPassThruData(String passThruData) {
        this.passThruData = passThruData;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String mailToAddress1) {
        this.MailToAddress1 = mailToAddress1;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String mailToAddress2) {
        this.MailToAddress2 = mailToAddress2;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String mailToAddress3) {
        this.MailToAddress3 = mailToAddress3;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String mailToAddress4) {
        this.MailToAddress4 = mailToAddress4;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String mailToAddress5) {
        this.MailToAddress5 = mailToAddress5;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String mailToAddress6) {
        this.MailToAddress6 = mailToAddress6;
    }

    public String getMemberFirstName() {
        return memberFirstName;
    }

    public void setMemberFirstName(String memberFirstName) {
        this.memberFirstName = memberFirstName;
        this.memberName = NormalizeUtil.normalizeMemberName(this.memberFirstName, this.memberLastName);
    }

    public String getMemberLastName() {
        return memberLastName;
    }

    public void setMemberLastName(String memberLastName) {
        this.memberLastName = memberLastName;
        this.memberName = NormalizeUtil.normalizeMemberName(this.memberFirstName, this.memberLastName);
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getAttachmentControlId() {
        return attachmentControlId;
    }

    public void setAttachmentControlId(String attachmentControlId) {
        this.attachmentControlId = attachmentControlId;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getDccNumber() {
        return dccNumber;
    }

    public void setDccNumber(String dccNumber) {
        this.dccNumber = dccNumber;
    }

    public String getDiv() {
        return div;
    }

    public void setDiv(String div) {
        this.div = div;
    }

    public String getPayloc() {
        return payloc;
    }

    public void setPayloc(String payloc) {
        this.payloc = payloc;
    }

    public String getPolicyGroupNumber() {
        return policyGroupNumber;
    }

    public void setPolicyGroupNumber(String policyGroupNumber) {
        this.policyGroupNumber = policyGroupNumber;
    }

    public String getPolicyId() {
        return policyId;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    public String getReceivedDate() {
        return receivedDate;
    }

    public void setReceivedDate(String receivedDate) {
        this.receivedDate = receivedDate;
    }

    public String getSaOI() {
        return saOI;
    }

    public void setSaOI(String saOI) {
        this.saOI = saOI;
    }

    public String getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getSortType() {
        return sortType;
    }

    public void setSortType(String sortType) {
        this.sortType = sortType;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getQueue() {
        return queue;
    }

    public void setQueue(String queue) {
        this.queue = queue;
    }

    public String getDocCategoryCode() {
        return docCategoryCode;
    }

    public void setDocCategoryCode(String docCategoryCode) {
        this.docCategoryCode = docCategoryCode;
    }

    public String getDocSourceCode() {
        return docSourceCode;
    }

    public void setDocSourceCode(String docSourceCode) {
        this.docSourceCode = docSourceCode;
    }

    public String getDocSubTypeCode() {
        return docSubTypeCode;
    }

    public void setDocSubTypeCode(String docSubTypeCode) {
        this.docSubTypeCode = docSubTypeCode;
    }

    public String getDocTypeCode() {
        return docTypeCode;
    }

    public void setDocTypeCode(String docTypeCode) {
        this.docTypeCode = docTypeCode;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getGlobalDocId() {
        return globalDocId;
    }

    public void setGlobalDocId(String globalDocId) {
        this.globalDocId = globalDocId;
    }

    public String getIntakeChannel() {
        return intakeChannel;
    }

    public void setIntakeChannel(String intakeChannel) {
        this.intakeChannel = intakeChannel;
    }


    public enum ErrorMsg implements ErrorMessage {
        u_tin(12, "Missing or invalid data: u_tin"),
        u_mpin(12, "Missing or invalid data: u_mpin"),
        u_email_alert_req(12, "Missing or invalid data: u_email_alert_req"),
        u_ltr_grp_id(12, "Missing or invalid data: u_ltr_grp_id"),
        u_source(12, "Missing or invalid data: u_source"),
        letterType(12, "Missing or invalid data: letterType"),
        facilityType(12, "Missing or invalid data: facilityType"),
        u_pass_thru_data(12, "Missing or invalid data: u_pass_thru_data"),
        u_sub_category(12, "Missing or invalid data: u_sub_category"),
        u_orig_creation_date(12, "Missing or invalid data: u_orig_creation_date"),
        u_config_key(22, "Missing or invalid data: u_config_key"),
        u_trl_id(22, "Missing or invalid data: u_trl_id"),
        u_mail_to_adr1(22, "Missing or invalid data: u_mail_to_adr1"),
        u_mail_to_adr2(22, "Missing or invalid data: u_mail_to_adr2"),
        u_mail_to_adr4(22, "Missing or invalid data: u_mail_to_adr4");

        private final int errorCode;
        private final String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }
}
