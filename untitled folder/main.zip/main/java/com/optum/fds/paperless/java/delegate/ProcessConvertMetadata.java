package com.optum.fds.paperless.java.delegate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.file.metadata.PostCardInd;
import com.optum.fds.paperless.mongo.file.metadata.ProcessFileTask;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorError;
import com.optum.fds.paperless.mongo.processors.ProcessorErrorCode;
import com.optum.fds.paperless.util.ServiceUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.flowable.engine.delegate.DelegateExecution;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service("ProcessConvertMetadata")
public class ProcessConvertMetadata extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessConvertMetadata.class);
    private static final DateTimeFormatter UTC_FORMATTER = new DateTimeFormatterBuilder().appendInstant(3).toFormatter();

    private static final List<String> REQ_VARS = Arrays.asList(
            Workflow.JSON_FILE, Workflow.CLIENT_NAME, Workflow.SPACE_ID
    );
    private static final String CREATED_DATE = "createdDate";

    @Value("${ELGSSpaceIdList}")
    private List<Integer> elgsSpaceIdList;

    @Value("${OCMSpaceId}")
    private Integer ocmSpaceId;

    @Autowired
    private ServiceUtil serviceUtil;

    @Autowired
    DocumentMetaDataService documentMetaDataService;

    @Autowired
    ObjectMapper mapper;

    @Autowired
    PostCardInd postCardInd;

    private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    private static final Gson gson = new GsonBuilder().setDateFormat(DATE_FORMAT).create();

    protected String schemaFileBasePath = File.separator + "schemas" + File.separator;

    @Override
    @SuppressWarnings("unchecked")
    protected void doExecute(DelegateExecution execution) {
        String clientName = execution.getVariable(Workflow.CLIENT_NAME, String.class);
        Integer spaceId = execution.getVariable(Workflow.SPACE_ID, Integer.class);
        String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
        Boolean metadataValidationNotification = execution.getVariable(Workflow.METADATA_VALIDATION_NOTIFICATION, Boolean.class);
        List<DocumentMetaData> documentList = null;
        try {
            documentList = WorkFlowUtil.readDocumentsFromJsonFile(jsonFile);
        } catch (IOException e) {
            LOGGER.error("doExecute Unable to get DocumentMetadata from file, {}={} {}",
                    "jsonFile", jsonFile,
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("ProcessConvertMetadata-->doExecute-->Unable to get DocumentMetadata", WorkFlowUtil.getStackTrace(e));
            return;
        }
        List<String> updatedDocs = new ArrayList<>();
        Schema jsonSchema = loadJSONSchema(clientName);
        if (jsonSchema == null) {
            LOGGER.error("doExecute -- JSON schema is null/invalid for clientName={}, skipping metadata conversion", clientName);
            addErrorMsg("ProcessConvertMetadata-->doExecute-->JSON schema is null for clientName=" + clientName, "Cannot perform metadata conversion without a valid JSON schema");
            return;
        }
        for (DocumentMetaData docMetaData : documentList) {
            try {
                LOGGER.info("doExecute -- Processing metadata for docId={}, clientName={}, spaceId={}", docMetaData.getId(), clientName, spaceId);
                if (docMetaData.getId() != null && docMetaData.getMetadata() != null) {
                    DocumentMetaData updatedDoc = convertAndValidateMetadata(docMetaData, clientName, jsonSchema);
                    LOGGER.info("updatedDoc={}",  updatedDoc);

                    if (updatedDoc != null) {
                        updatedDocs.add(updatedDoc.getId());
                        List<Map<String, Object>> errorList = updatedDoc.getMetadata().get("errorList", List.class);
                        if (Boolean.TRUE.equals(metadataValidationNotification)
                                && hasNotifyableErrors(errorList)) {

                            if (elgsSpaceIdList.contains(spaceId) || ocmSpaceId.equals(spaceId)) {
                                serviceUtil.sendMetadataValidationNotification(
                                        errorList,
                                        updatedDoc,
                                        updatedDoc.getMetadata(),
                                        updatedDoc.getDoc360DocumentId(),
                                        spaceId
                                );
                            }
                        }
                    }
                    LOGGER.info("doExecute -- Successfully converted metadata for docId={}, clientName={}, spaceId={}", docMetaData.getId(), clientName, spaceId);
                }
            } catch (Exception e) {
                LOGGER.error("doExecute -- Error converting metadata for docId={}, clientName={}, err={}", docMetaData.getId(), clientName, ExceptionUtils.getStackFrames(e));

            }
        }
        execution.setTransientVariable("convertedDocs", updatedDocs);
        LOGGER.info("doExecute -- Completed processing metadata for clientName={}, spaceId={}, convertedDocIDs={}", clientName, spaceId, updatedDocs);

    }

    protected Document flattenMetadata(Document metadata) {
        // Copy all the metadata from original metadata and remove attributes list
        Document flattened = new Document(metadata);
        flattened.remove("attributes");

        // Loop through attributes list and extract the physicalName and value and put in the flattened metadata
        Optional.ofNullable((List<?>) metadata.get("attributes"))
                .ifPresent(attrs -> attrs.stream()
                        .filter(attr -> attr instanceof Map )
                        .map(attr -> (Map) attr)
                        .filter(attrDoc -> StringUtils.isNotEmpty((String) attrDoc.get("physicalName")))
                        .forEach(attrDoc -> flattened.put(
                                (String) attrDoc.get("physicalName"),
                                attrDoc.get("value")
                        )));

        return flattened;
    }


    protected DocumentMetaData convertAndValidateMetadata(DocumentMetaData documentMetaData, String clientName, Schema jsonSchema) throws JsonProcessingException {
        String docId = documentMetaData.getId();
        Set<String> errorList = new HashSet<>();
        org.bson.Document metadata = documentMetaData.getMetadata();
        
        String createdDate = UTC_FORMATTER.format(Instant.now().truncatedTo(ChronoUnit.MILLIS));
        
        if(!metadata.containsKey(CREATED_DATE) || metadata.get(CREATED_DATE).equals("")) {
             metadata.append(CREATED_DATE, createdDate);
        }
        
        org.bson.Document flattenedMetadata = flattenMetadata(metadata);
        org.bson.Document updatedMetadata = convertMetadata(documentMetaData.getId(), flattenedMetadata, clientName, errorList, jsonSchema);
        updatedMetadata.putIfAbsent(CREATED_DATE, createdDate);
        documentMetaData.setMetadata(updatedMetadata);
        documentMetaData.setStatus(getDocumentStatus(errorList));
        
        return documentMetaDataService.saveDocMetaDataWithRevisions(documentMetaData, docId);
    }

    protected Schema loadJSONSchema(String clientName) {
        try {
            JSONTokener tokener = getClientSchema(clientName);
            if (tokener == null) {
                LOGGER.error("jsonSchema does not exist clientName={}", clientName);
                return null;
            }
            JSONObject jsonSchema = new JSONObject(tokener);
            SchemaLoader loader = SchemaLoader.builder().schemaJson(jsonSchema).build();
            return loader.load().build();
        } catch (Exception e) {
            LOGGER.error("loadTokener -- Error loading json schema for clientName={}, err={}", clientName, ExceptionUtils.getStackFrames(e));
            return null;
        }
    }


    protected org.bson.Document convertMetadata(String docId, org.bson.Document clientMetadata, String clientName, Set<String> errors, Schema jsonSchema) throws JsonProcessingException {
        JSONObject clientJsonObj = new JSONObject(clientMetadata.toJson());
        LOGGER.debug("convertMetadata -- client json clientName={}, docId={}, object={}", clientName, docId, clientJsonObj);
        try {
            jsonSchema.validate(clientJsonObj);
        } catch (org.everit.json.schema.ValidationException e) {
            @SuppressWarnings("rawtypes")
            Class enumClass = getErrEnumFromClientName(clientName);
            for (String errMsg : e.getAllMessages()) {
                getErrors(errMsg, errors, enumClass);
            }
        } catch (Exception e) {
            LOGGER.error("convertMetadata -- Error validating json schema for docId={}, clientName={}, err={}", docId, clientName, ExceptionUtils.getStackFrames(e));
        }
        LOGGER.debug("convertMetadata -- clientName={}, docId={}, errors={}", docId, clientName, errors);
        ClientMetadata convertedMetadata = (ClientMetadata) mapper.readValue(clientJsonObj.toString(), getClassFromClientName(clientName));
        convertedMetadata.setPostCardInd(postCardInd.getPostCardInd(clientName));
        if (!errors.isEmpty()) {
            convertedMetadata.setErrorList(errors.stream().toList());
        }
        String convertedMetadataJson = gson.toJson(convertedMetadata);
        JSONObject convertedMetadatajsonObj = new JSONObject( convertedMetadataJson );
        return org.bson.Document.parse(convertedMetadatajsonObj.toString());
    }

    public MetaDataStatus getDocumentStatus(Set<String> errors) {
        if (errors == null || errors.isEmpty()) {
            return MetaDataStatus.AVAILABLE;
        } else if (!errors.isEmpty() && checkSevereError(errors)) {
            return MetaDataStatus.SEVERE_ERROR;
        } else {
            return MetaDataStatus.AVAILABLE;
        }
    }

    public boolean checkSevereError(Set<String> errors) {
        for (String error : errors) {
            if (error.contains("SEVERE")){
                return true;
            }
        }
        return false;
    }

    public JSONTokener getClientSchema(String clientName) {
        InputStream schemaStream = ProcessConvertMetadata.class.getResourceAsStream(schemaFileBasePath + clientName + "_client_schema.json");
        if (schemaStream != null) {
            return new JSONTokener(schemaStream);
        }
        return null;
    }

    @SuppressWarnings("rawtypes")
    public Class getErrEnumFromClientName(String clientName) {
        String enumName = "com.optum.fds.paperless.client.pojo." + clientName + "$ErrorMsg";
        try {
            return Class.forName(enumName);
        } catch (ClassNotFoundException e) {
            LOGGER.error("getClassFromClientName -- ErrorMsg enum not found for client={}, err={}", clientName, ExceptionUtils.getStackFrames(e));
            return null;
        }
    }

    public Class getClassFromClientName(String clientName) {
        String className = "com.optum.fds.paperless.client.pojo." + clientName;
        try {
            return Class.forName(className);
        } catch (ClassNotFoundException e) {
            LOGGER.error("getClassFromClientName -- class not found for client={}, err={}", clientName, ExceptionUtils.getStackFrames(e));
            return null;
        }
    }


    @SuppressWarnings("rawtypes")
    public void getErrors(String errMsg, Set<String> errors, Class enumClass) {

        ErrorMessage err = null;
        String key = "";
        // #: required key [SubCategory] not found
        // #/DATEOFSERVICE: subject must not be valid against schema "enum":["00000000"]
        // #/CreatingApp: expected minLength: 1, actual: 0
        // #/isPrintSuppressed: blah is not a valid enum value

        if (errMsg.contains("[") && errMsg.contains("required key")) {
            key = errMsg.substring(errMsg.indexOf("[")+1, errMsg.indexOf("]"));
        } else if (errMsg.contains("minLength") || errMsg.contains("enum")) {
            key = errMsg.substring(errMsg.indexOf("#/")+2, errMsg.indexOf(":"));
        }

        try {
            err = (ErrorMessage) Enum.valueOf(enumClass, key.replaceAll("\\s",""));
            LOGGER.debug("getErrors -- errorCode={}, errorMessage={}", err.getErrorCode(), err.getErrorMessage());
            errors.add(err.getErrorMessage());
        } catch (Exception e) {
            LOGGER.info("No enum value for key={}", key);

        }
    }


    private boolean hasNotifyableErrors(List<Map<String, Object>> errorList) {
        return errorList != null && !errorList.isEmpty();
    }
    

}
