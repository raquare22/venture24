package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CSPPRADoc360 extends ClientMetadata {

    private static final long serialVersionUID = -3186350509488916131L;


    @JsonProperty("tin")
    @JsonAlias("u_tin")
    private String tin;


    @JsonProperty("mpin")
    private String mpin = "";

    @JsonProperty("npi")
    @JsonAlias("u_prov_npi")
    private String npi;

    @JsonProperty("physicianName")
    @JsonAlias("u_payee_nm")
    private String physicianName;

    @JsonProperty("CheckTraceNumber")
    @JsonAlias("u_chk_nbr")
    private String CheckTraceNumber;

    @JsonProperty("multClaimNumber")
    @JsonAlias("u_clm_nbr")
    private String multClaimNumber;

    @JsonProperty("originalPrintTrail")
    @JsonAlias("u_trl_id")
    private String originalPrintTrail;

    @JsonProperty("paymentNumber")
    @JsonAlias("u_vendor_pay_id")
    private String paymentNumber;

    @JsonProperty("emailAlertReq")
    private String emailAlertReq= "Y";

    @JsonProperty("EFT_Ind")
    private String EFT_Ind;

    @JsonProperty("835_Ind")
    private String Ind_835;

    @JsonProperty("multMemberId")
    private String multMemberId;

    @JsonProperty("multSubscriberId")
    private String multSubscriberId;

    @JsonProperty("checkAmt")
    private String checkAmt;

    @JsonProperty("CONFIGKEY")
    private String CONFIGKEY;

    @JsonProperty("PassThruData")
    private String PassThruData;

    @JsonProperty("MailToAddress1")
    private String MailToAddress1;


    @JsonProperty("MailToAddress2")
    private String MailToAddress2;


    @JsonProperty("MailToAddress3")
    private String MailToAddress3;


    @JsonProperty("MailToAddress4")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    private String MailToAddress6;

    @JsonProperty("subCategory")
    protected String subCategory;



    public CSPPRADoc360(){
        this.category="Payment Document";
        this.fileType="Advice";
        this.tenant = "Link";
        this.fileDescription = "Payment Document";
        this.createApplication = "CSP-PRA";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.privilege = "Claim Status";
        this.subCategory = "PR";
        CSPPRA.Subcategory subCat = CSPPRA.Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }


    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        if(mpin != null){
            this.mpin = mpin;
        }
    }

    public String getNpi() {
        return npi;
    }

    public void setNpi(String npi) {
        this.npi = npi;
    }

    public String getPhysicianName() {
        return physicianName;
    }

    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public String getCheckTraceNumber() {
        return CheckTraceNumber;
    }

    public void setCheckTraceNumber(String checkTraceNumber) {
        CheckTraceNumber = checkTraceNumber;
    }

    public String getMultClaimNumber() {
        return multClaimNumber;
    }

    public void setMultClaimNumber(String multClaimNumber) {
        this.multClaimNumber = multClaimNumber;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getPaymentNumber() {
        return paymentNumber;
    }

    public void setPaymentNumber(String paymentNumber) {
        this.paymentNumber = paymentNumber;
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        if(emailAlertReq != null && !emailAlertReq.isEmpty()){
            this.emailAlertReq = emailAlertReq;
        }

    }

    public String getPrivilege(){
        return privilege;
    }

    public void setPrivilege(String privilege){
        this.privilege = privilege;
    }

    public String getEFT_Ind() {
        return EFT_Ind;
    }

    public void setEFT_Ind(String eFT_Ind) {
        this.EFT_Ind = eFT_Ind;
    }

    public String getInd_835() {
        return Ind_835;
    }

    public void setInd_835(String ind_835) {
        this.Ind_835 = ind_835;
    }

    public String getMultMemberId() {
        return multMemberId;
    }

    public void setMultMemberId(String multMemberId) {
        this.multMemberId = multMemberId;
    }

    public String getMultSubscriberId() {
        return multSubscriberId;
    }

    public void setMultSubscriberId(String multSubscriberId) {
        this.multSubscriberId = multSubscriberId;
    }

    public String getCheckAmt() {
        return checkAmt;
    }

    public void setCheckAmt(String checkAmt) {
        this.checkAmt = checkAmt;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String cONFIGKEY) {
        this.CONFIGKEY = cONFIGKEY;
    }

    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String passThruData) {
        PassThruData = passThruData;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String mailToAddress1) {
        MailToAddress1 = mailToAddress1;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String mailToAddress2) {
        MailToAddress2 = mailToAddress2;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String mailToAddress3) {
        MailToAddress3 = mailToAddress3;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String mailToAddress4) {
        MailToAddress4 = mailToAddress4;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String mailToAddress5) {
        MailToAddress5 = mailToAddress5;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String mailToAddress6) {
        MailToAddress6 = mailToAddress6;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "PR";
            this.setFilePath(CSPPRA.Subcategory.PR.getFilePath());
        } else{
            this.subCategory =subCategory;
            CSPPRA.Subcategory subCat;
            try{
                subCat = CSPPRA.Subcategory.valueOf(this.subCategory);

            }catch (Exception e){
                subCat = CSPPRA.Subcategory.PR;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }


    @Override
    public void setExpiryDate(String expiryDate) {
        if (expiryDate != null && expiryDate.length() == 7 && this.subCategory != null) {
            this.expiryDate = this.vcpExpiryDateFormat(expiryDate, this.subCategory);
        } else {
            this.expiryDate = expiryDate;
        }
    }

    public enum ErrorMsg implements ErrorMessage {
        u_tin(22,"Missing or invalid data: tin(SEVERE)"),
        u_clm_nbr(12,"Missing or invalid data: claimNumber"),
        u_orig_creation_date(12,"Missing or invalid data: createdDate"),
        u_trl_id(22,"Missing or invalid data: originalPrintTrail(SEVERE)"),

        mpin(22, "Missing or invalid data: mpin(SEVERE)"),
        subCategory(12, "Missing or invalid data: subCategory"),
        isPrintSuppressed (12,"Missing or invalid data: isPrintSuppressed"),

        CONFIGKEY (22, "Missing or invalid data: CONFIGKEY(SEVERE)"),
        PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"),

        MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"),
        MailToAddress3 (22, "Missing or invalid data: MailToAddress3(SEVERE)");



        private final int errorCode;
        private final String errorMessage;

        ErrorMsg(int code , String message){
            this.errorCode=code;
            this.errorMessage=message;
        }
        public int getErrorCode(){
            return errorCode;
        }

        public String getErrorMessage(){
            return errorMessage;
        }
    }
}
