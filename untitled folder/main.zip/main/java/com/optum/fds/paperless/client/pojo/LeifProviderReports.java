package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LeifProviderReports extends ClientMetadata {

	private static final long serialVersionUID = 4277217829493684690L;

	@JsonProperty("fdsCloudSpaceId")
	@JsonAlias("u_space_id")
	private String fdsCloudSpaceId;

    @JsonProperty("emailAlertReq")
    private String emailAlertReq = "N";

	@JsonProperty("fdsCloudDocumentId")
	@JsonAlias("u_document_id")
	private String fdsCloudDocumentId;

	@JsonProperty("fdsCloudAttachmentId")
	@JsonAlias("u_attach_id")
	private String fdsCloudAttachmentId;

	@JsonProperty("parentId")
	@JsonAlias("u_parent_id")
	private String parentId;

	@JsonProperty("optionalMetadata")
	@JsonAlias("u_optional_metadata")
	private String optionalMetadata;

	@JsonProperty("cloudStorageProvider")
	@JsonAlias("u_cloud_stor_prov")
	private String cloudStorageProvider;

	@JsonProperty("isAvailable")
	@JsonAlias("u_isavailable")
	private String isAvailable;

	@JsonProperty("externalId")
	@JsonAlias("u_ext_id")
	private String externalId;

	@JsonProperty("attachmentExternalId")
	@JsonAlias("u_attch_ext_id")
	private String attachmentExternalId;

	@JsonProperty("attachmentModifiedBy")
	@JsonAlias("u_attach_update_user")
	private String attachmentModifiedBy;

	@JsonProperty("attachmentModifiedDate")
	@JsonAlias("u_attach_update_dt")
	private Date attachmentModifiedDate;

	@JsonProperty("documentModifiedBy")
	@JsonAlias("u_doc_update_user")
	private String documentModifiedBy;

	@JsonProperty("documentUploadDate")
	@JsonAlias("u_doc_update_dt")
	private Date documentUploadDate;

	@JsonProperty("version")
	@JsonAlias("u_ver")
	private String version;

	@JsonProperty("bucket")
	@JsonAlias("u_bucket")
	private String bucket;

	@JsonProperty("virusScanStatus")
	@JsonAlias("u_virus_scan_status")
	private String virusScanStatus;

	@JsonProperty("key")
	@JsonAlias("u_key")
	private String key;

	@JsonProperty("author")
	@JsonAlias("u_author")
	private String author;

	@JsonProperty("workflow")
	@JsonAlias("u_workflow")
	private String workflow;

	@JsonProperty("isMerged")
	@JsonAlias("u_is_merged")
	private String isMerged;

	@JsonProperty("virusScanTime")
	@JsonAlias("u_virus_scan_time")
	private Date virusScanTime;

	@JsonProperty("childId")
	@JsonAlias("u_child_id")
	private String childId;

	@JsonProperty("organization")
	@JsonAlias("u_org")
	private String organization;

	@JsonProperty("tin")
	@JsonAlias("u_tin")
	private String tin;

	@JsonProperty("caseId")
	@JsonAlias("u_case_id")
	private String caseId;

	@JsonProperty("CheckAmt")
	@JsonAlias("u_chk_amnt")
	private String CheckAmt;

	@JsonProperty("CheckTraceNumber")
	@JsonAlias("u_chk_id")
	private String CheckTraceNumber;

	@JsonProperty("claimNumber")
	@JsonAlias("u_clm_nbr")
	private String claimNumber;

	@JsonProperty("dateOfService")
	@JsonAlias("u_srvc_dt")
	private String dateOfService;

	@JsonProperty("memberName")
	@JsonAlias("u_mbr_nm")
	private String memberName;

	@JsonProperty("memberId")
	@JsonAlias("u_mbr_id")
	private String memberId;

	@JsonProperty("notificationId")
	@JsonAlias("u_ntfy_id")
	private String notificationId;

	@JsonProperty("patientAccountNumber")
	@JsonAlias("u_patient_acct_nbr")
	private String patientAccountNumber;

	@JsonProperty("providerName")
	@JsonAlias("u_phy_nm")
	private String providerName;

	@JsonProperty("policyNumber")
	@JsonAlias("u_pol_nbr")
	private String policyNumber;

	@JsonProperty("source")
	@JsonAlias("u_source")
	private String source;

	@JsonProperty("sourceCreatedDate")
	@JsonAlias("u_src_created_dt")
	private String sourceCreatedDate;

	public LeifProviderReports() {

		this.category = "Provider Reports";
		this.fileType = "Report";
		this.tenant = "Link";

		this.fileDescription = "Leif Provider Reports";
		this.createApplication = "Doc360";

		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;

		this.providerEmailId = "";
		this.postCardInd = true;

		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;

		this.privilege = "Patient Eligibility and Benefits";

		this.setFilePath("LeifProviderReports");
	}

	public String getFdsCloudSpaceId() {
		return fdsCloudSpaceId;
	}

	public void setFdsCloudSpaceId(String fdsCloudSpaceId) {
		this.fdsCloudSpaceId = fdsCloudSpaceId;
	}

	public String getFdsCloudDocumentId() {
		return fdsCloudDocumentId;
	}

	public void setFdsCloudDocumentId(String fdsCloudDocumentId) {
		this.fdsCloudDocumentId = fdsCloudDocumentId;
	}

	public String getFdsCloudAttachmentId() {
		return fdsCloudAttachmentId;
	}

	public void setFdsCloudAttachmentId(String fdsCloudAttachmentId) {
		this.fdsCloudAttachmentId = fdsCloudAttachmentId;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getOptionalMetadata() {
		return optionalMetadata;
	}

	public void setOptionalMetadata(String optionalMetadata) {
		this.optionalMetadata = optionalMetadata;
	}

	public String getCloudStorageProvider() {
		return cloudStorageProvider;
	}

	public void setCloudStorageProvider(String cloudStorageProvider) {
		this.cloudStorageProvider = cloudStorageProvider;
	}

	public String getIsAvailable() {
		return isAvailable;
	}

	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getAttachmentExternalId() {
		return attachmentExternalId;
	}

	public void setAttachmentExternalId(String attachmentExternalId) {
		this.attachmentExternalId = attachmentExternalId;
	}

	public String getAttachmentModifiedBy() {
		return attachmentModifiedBy;
	}

	public void setAttachmentModifiedBy(String attachmentModifiedBy) {
		this.attachmentModifiedBy = attachmentModifiedBy;
	}

	public Date getAttachmentModifiedDate() {
		return attachmentModifiedDate;
	}

	public void setAttachmentModifiedDate(Date attachmentModifiedDate) {
		this.attachmentModifiedDate = attachmentModifiedDate;
	}

	public String getDocumentModifiedBy() {
		return documentModifiedBy;
	}

	public void setDocumentModifiedBy(String documentModifiedBy) {
		this.documentModifiedBy = documentModifiedBy;
	}

	public Date getDocumentUploadDate() {
		return documentUploadDate;
	}

	public void setDocumentUploadDate(Date documentUploadDate) {
		this.documentUploadDate = documentUploadDate;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getBucket() {
		return bucket;
	}

	public void setBucket(String bucket) {
		this.bucket = bucket;
	}

	public String getVirusScanStatus() {
		return virusScanStatus;
	}

	public void setVirusScanStatus(String virusScanStatus) {
		this.virusScanStatus = virusScanStatus;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getWorkflow() {
		return workflow;
	}

	public void setWorkflow(String workflow) {
		this.workflow = workflow;
	}

	public String getIsMerged() {
		return isMerged;
	}

	public void setIsMerged(String isMerged) {
		this.isMerged = isMerged;
	}

	public Date getVirusScanTime() {
		return virusScanTime;
	}

	public void setVirusScanTime(Date virusScanTime) {
		this.virusScanTime = virusScanTime;
	}

	public String getChildId() {
		return childId;
	}

	public void setChildId(String childId) {
		this.childId = childId;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getCheckAmt() {
		return CheckAmt;
	}

	public void setCheckAmt(String checkAmt) {
		this.CheckAmt = checkAmt;
	}

	public String getCheckTraceNumber() {
		return CheckTraceNumber;
	}

	public void setCheckTraceNumber(String checkTraceNumber) {
		this.CheckTraceNumber = checkTraceNumber;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getDateOfService() {
	    return dateOfService;
	}

	public void setDateOfService(String dateOfService) {
	    this.dateOfService = dateOfService;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public String getPatientAccountNumber() {
		return patientAccountNumber;
	}

	public void setPatientAccountNumber(String patientAccountNumber) {
		this.patientAccountNumber = patientAccountNumber;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        this.emailAlertReq = emailAlertReq;
    }

    public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSourceCreatedDate() {
		return sourceCreatedDate;
	}

	public void setSourceCreatedDate(String sourceCreatedDate) {
		this.sourceCreatedDate = sourceCreatedDate;
	}

	public enum ErrorMsg implements ErrorMessage {

		u_tin(22, "Missing or invalid data: u_tin"),
        u_category(22, "Missing or invalid data: u_category"),
        u_crprt_mpin(22, "Missing or invalid data: u_crprt_mpin"),
        u_create_app(22, "Missing or invalid data: u_create_app"),
        file_path(22, "Missing or invalid data: file_path"),
        file_typ(22, "Missing or invalid data: file_typ"),
        u_privilege(22, "Missing or invalid data: u_privilege"),
        u_tenant(22, "Missing or invalid data: u_tenant"),
        u_filename(22, "Missing or invalid data: u_filename");

		private final int errorCode;
		private final String errorMessage;

		ErrorMsg(int code, String message) {
			this.errorCode = code;
			this.errorMessage = message;
		}

		@Override
		public int getErrorCode() {
			return errorCode;
		}

		@Override
		public String getErrorMessage() {
			return errorMessage;
		}
	}
}