
# ==========================
# Fetch all the mpins associated to mentioned taxIdNumber and corpOwnerId. Saves the mpins in json file
# ==========================

import requests
import json

# ==========================
# Configuration
# ==========================

TOKEN_URL = "https://gateway-dmz.optum.com/auth/oauth2/cached/token"
MPIN_URL = "https://gateway.optum.com/api/pdr/pdo/v1/mpins"

CLIENT_ID = "Add client_id value"
CLIENT_SECRET = "Add client_secret value"
GRANT_TYPE = "client_credentials"  # update if different

REQUEST_BODY = {
    "taxIdNumber": "Add taxId",
    "corpOwnerId": "Add corporateMpin"
}

# ==========================
# Get Access Token
# ==========================

token_payload = {
    "client_id": CLIENT_ID,
    "client_secret": CLIENT_SECRET,
    "grant_type": GRANT_TYPE
}

token_headers = {
    "Content-Type": "application/x-www-form-urlencoded"
}

token_response = requests.post(
    TOKEN_URL,
    data=token_payload,
    headers=token_headers,
    timeout=30
)

token_response.raise_for_status()

token_json = token_response.json()

access_token = token_json["access_token"]

print("Successfully retrieved access token")

# ==========================
# Call MPIN Endpoint
# ==========================

api_headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

response = requests.post(
    MPIN_URL,
    headers=api_headers,
    json=REQUEST_BODY,
    timeout=30
)

response.raise_for_status()

response_json = response.json()

# ==========================
# Extract Provider IDs
# ==========================

provider_ids = [
    str(item.get("providerId")).zfill(9)
    for item in response_json.get("response", {}).get("mpinList", [])
    if item.get("providerId")
]

print(f"Found {len(provider_ids)} provider IDs")

for provider_id in provider_ids:
    print(provider_id)

# ==========================
# Save as JSON
# ==========================

output_data = {
    "providerIds": provider_ids
}

with open("provider_ids.json", "w") as f:
    json.dump(output_data, f, indent=4)

print("Provider IDs saved to provider_ids.json")
