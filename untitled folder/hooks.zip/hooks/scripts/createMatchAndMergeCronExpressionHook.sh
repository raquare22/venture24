#!/bin/bash

function prop {
    grep "^\\s*${1}=" elgsHook.properties|cut -d'=' -f2-
}

proccessName=MatchAndMergeDocument
inpClientName=CheckWritePRA

if [[ -z "$*" ]]; then
	echo
	read -p "Enter environment (local or dev or qa or stage or prod:) " inpEnvironment
	inResponseTemplateName="mergedMetaDataTemplate"
	companionTemplateName="CosmosPRACompanion"
	ACKNOWLEDGE_PROMPTS=true
else
	ACKNOWLEDGE_PROMPTS=$1
	inpEnvironment=$2
	inResponseTemplateName=$3
	companionTemplateName=$4
	shift "$#"
fi

if [[ ( $inpEnvironment == local || $inpEnvironment == dev || $inpEnvironment == qa || $inpEnvironment == stage || $inpEnvironment == prod ) && ( -n "$inResponseTemplateName" ) ]]; then
	searchCriteria=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.searchCriteria)
	searchWindow=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.searchWindow)
	matchCriteria=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.matchCriteria)
	cronExpression=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.cronExpression)
	HOST_URL=$(prop ${inpEnvironment}.HOST_URL)
	spaceId=$(prop ${inpEnvironment}.${inpClientName}.spaceId)
else
	echo
	echo "Try again"
	exit 0
fi

echo
echo "inpEnvironment: $inpEnvironment"
echo "inpResponseTemplateName: $inResponseTemplateName"
echo "companionTemplateName: $companionTemplateName"
echo "searchCriteria: $searchCriteria"
echo "searchWindow: $searchWindow"
echo "cronExpression: $cronExpression"
echo "matchCriteria: $matchCriteria"
echo "Host URL: $HOST_URL"

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Create Match and Merge Document CronExpression Hook (continue): continue"
fi

echo
echo "Creating Hook in spaceId: " $spaceId


hookName='CreateMatchandMergeDocument'$inpClientName'CronExpressionHook'

POSTPAYLOAD='{
  "hook" : {
          "name" : "'"${hookName}"'",
          "hook_type" : "cron",
          "hook_object" : "cronObject",
          "action" : {
            "type" : "workflow",
            "config" : {
              "process_key" : "matchAndMergeDocumentsFromDbProcess",
              "search_criteria" : "'"${searchCriteria}"'",
              "search_window" : "'"${searchWindow}"'",
              "match_criteria" : "'"${matchCriteria}"'",
              "template_name" : "'"${inResponseTemplateName}"'",
              "companion_template_name" : "'"${companionTemplateName}"'",
              "grant_type" : "authorization_code",
              "fdsAuthUrl" : "'"${HOST_URL/v2/oauth2/token.json}"'",
              "environment" : "'"${inpEnvironment}"'",
              "document_update_flag_value" : true,
              "document_update_flag_path" : "merged"
            }
          }
  },
    "hookRecordType" : "hook",
    "method" : "cron",
    "spaceId" : '${spaceId}',
    "target" : "hooks",
    "executionOrder" : 0,
    "locked" : false,
    "name" : "'"${hookName}"'",
    "status" : "AVAILABLE"
}'


POST_RESULT=`curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD}"`
echo
echo $POST_RESULT

echo
jq . <<< $POST_RESULT

