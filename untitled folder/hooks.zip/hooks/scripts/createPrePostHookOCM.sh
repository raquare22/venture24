#!/bin/bash

function prop {
    grep "^\\s*${1}=" elgsHook.Properties|cut -d'=' -f2-
}

function string_replace {
    echo "${1/\*/$2}"
}

hookName=LinkPreferencesV2

if [[ -z "$*" ]]; then
	echo
	read -p "Enter environment (local or dev or qa or stage or prod): " ENVIRO
	echo
	read -p "Enter client (OCM): " inpClientName
	ACKNOWLEDGE_PROMPTS=true
else
	ACKNOWLEDGE_PROMPTS=$1
	if [[ $ACKNOWLEDGE_PROMPTS == false ]]; then
		COMP="yes"
		CHOICE="no"
	fi
	FILE_NAME=$2
	ENVIRO=$3
	inpClientName=$4
	shift "$#"
fi

if [[ ( $ENVIRO == local || $ENVIRO == dev || $ENVIRO == qa || $ENVIRO == stage || $ENVIRO == prod) && ( $inpClientName == OCM) ]]; then
	HOST_URL=$(prop ${ENVIRO}.HOST_URL)
	inpSpaceId=$(prop ${ENVIRO}.${inpClientName}.spaceId)
	providerSpaceId=$(prop ${ENVIRO}.${hookName}.spaceId)
	criteria=$(prop ${inpClientName}.retrieveProviderEmailAddress.criteria)
	skipEFTIND=$(prop ${ENVIRO}.${inpClientName}.skipEFTIndFlag)
	provHostUrl=$(prop ${ENVIRO}.CorporateMPIN.provHostUrl)
	provSearchUrl=$(prop ${ENVIRO}.CorporateMPIN.provSearchUrl)
	searchWindow=$(prop ${ENVIRO}.CorporateMPIN.searchWindow)
	searchCriteria=$(prop ${ENVIRO}.PrePostHook.searchCriteria)
	PesClientAppId=$(prop ${ENVIRO}.PesClientAppId)
	PesClientSecret=$(prop ${ENVIRO}.PesClientSecret)
	fdsCloudAuthUrl=$(prop ${ENVIRO}.fdsCloudAuthUrl)
	fdsCloudGetDocumentUrl=$(prop ${ENVIRO}.fdsCloudGetDocumentUrl)
	rules=$(prop ${inpClientName}.rules)
	validateCorprateMPIN=$([ $(prop ${ENVIRO}.${inpClientName}.validateCorprateMPIN) == true ] && echo "true" || echo "false")
else
	echo "Try again"
	exit 0
fi

searchCriteria=$(string_replace "$searchCriteria" "$inpSpaceId")
appName=${inpClientName}
fdsAuthUrl=$provHostUrl/auth/oauth2/token
fdsCloud_AuthUrl=$fdsCloudAuthUrl
grant_type=client_credentials
attributeSet=summary_0001
count=1

inpNewFileName=test1.doc

HookName=preposthook

echo
echo "PesClientSecret: $PesClientSecret"
echo "PesClientAppId: $PesClientAppId"
echo "searchCriteria: $searchCriteria"
echo "fdsCloudAuthUrl: $fdsCloud_AuthUrl"
echo "fdsCloudGetDocumentUrl: $fdsCloudGetDocumentUrl"
echo "Host URL: $HOST_URL"
echo "inpSpaceId: $inpSpaceId"
echo "criteria:$criteria"
echo "skipEFTIND:$skipEFTIND"

GET_RESULT=`curl -verbose -X GET -k "$HOST_URL/api/services/v1/hooks?name=$HookName&spaceId=$inpSpaceId"`
echo "GET_RESULT:  " $GET_RESULT
jq . <<< $GET_RESULT
 echo 'List of available hook IDs'
echo "$GET_RESULT" | jq -r '.response[]|"\(.id)"'
echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Starting delete hook process one by one, press enter to continue"
fi
 for row in $(echo "$GET_RESULT" | jq -r '.response[] | @base64'); do
    _jq() {
     echo ${row} | base64 --decode | jq -r ${1}
    }
echo ${row} | base64 --decode | jq -r ${1}

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Would you like to delete $(_jq '.id') yes or no:" COMP
fi
if [[ $COMP == yes ]]; then
	DELETE_RESULT=`curl -k -verbose -X DELETE -k "$HOST_URL/api/services/v1/hooks/delete/$(_jq '.id')"`
	jq . <<< $DELETE_RESULT
	if [[ -z "$deletedHooks" ]]; then
		deletedHooks="${0##*/}: $(_jq '.id')"
	else
		deletedHooks="$deletedHooks, $(_jq '.id')"
	fi
fi
done

if [[ $ACKNOWLEDGE_PROMPTS == false && ! -z "$deletedHooks" ]]; then
	echo $deletedHooks >> $FILE_NAME
fi

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Create PrePost Hook in $inpClientName SpaceId $inpSpaceId(continue): continue"
fi

POSTPAYLOAD='{
    "hook" : {
        "name" : "prepostrealtimehook",
        "action" : {
            "type" : "workflow",
            "config" : {
                "search_window" : '${searchWindow}',
                "search_criteria" : '${searchCriteria}',
                "providerEmailAddress" : {
                    "process_key" : "retrieveProviderEmailAddressProcess",
                    "providerSpaceIdV2" : "'"${providerSpaceId}"'",
                    "skipEFTIndFlag" : "'"${skipEFTIND}"'",
                    "useFDSCloud" : true,
                    "fdsCloudAuthUrl" : "'"${fdsCloud_AuthUrl}"'",
                    "cloud_client_id" : "'"${PesClientAppId}"'",
                    "cloud_client_secret" : "'"${PesClientSecret}"'",
                    "cloud_grant_type" : "'"${grant_type}"'",
                    "fdsCloudGetDocumentUrl" : "'"${fdsCloudGetDocumentUrl}"'"
                },
                "requiredFieldRule" : {
                    "process_key" : "requiredFieldRuleProcess",
                    "rules" : '${rules}'
                }
            }
        }
    },
    "hookRecordType" : "hook",
    "spaceId" : '${inpSpaceId}',
    "target" : "documents",
    "locked" : false,
    "name" : "prepostrealtimehook",
    "status" : "AVAILABLE"
}'

POST_RESULT=`curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD}"`
echo
jq . <<< $POST_RESULT
echo "POST Result: " $POST_RESULT

exit 0
