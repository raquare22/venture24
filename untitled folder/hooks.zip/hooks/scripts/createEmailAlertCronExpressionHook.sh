#!/bin/bash

function prop {
    grep "^\\s*${1}=" elgsHook.properties|cut -d'=' -f2-
}

proccessName=EmailAlertCronExpressionHook
inpClientName=CheckWritePRA

if [[ -z "$*" ]]; then
	echo
  read -p "Enter environment (local or dev or qa or stage or prod:) " inpEnvironment
	inResponseTemplateName="checkWritePRAEmailAlert"
	ACKNOWLEDGE_PROMPTS=true
else
	ACKNOWLEDGE_PROMPTS=$1
	inpEnvironment=$2
	inResponseTemplateName=$3
	shift "$#"
fi

if [[ ( $inpEnvironment == local || $inpEnvironment == dev || $inpEnvironment == qa || $inpEnvironment == stage || $inpEnvironment == prod ) && ( -n "$inResponseTemplateName" ) ]]; then
	searchCriteria=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.searchCriteria)
	searchWindow=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.searchWindow)
	cronExpression=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.cronExpression)
	emailSender=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.emailSender)
	emailReceiver=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.emailReceiver)
	emailSubject=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.emailSubject)
	processorTransactionMetadataFlagPath=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.processor_transaction_metadata_flag_path)
	processorTransactionMetadataFlagValue=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.processor_transaction_metadata_flag_value)
	HOST_URL=$(prop ${inpEnvironment}.HOST_URL)
	spaceId=$(prop ${inpEnvironment}.${inpClientName}.spaceId)
else
	echo
	echo "Try again"
	exit 0
fi

echo
echo "inpEnvironment: $inpEnvironment"
echo "inpResponseTemplateName: $inResponseTemplateName"
echo "searchCriteria: $searchCriteria"
echo "searchWindow: $searchWindow"
echo "cronExpression: $cronExpression"
echo "emailSender: $emailSender"
echo "emailReceiver: $emailReceiver"
echo "emailSubject: $emailSubject"
echo "Host URL: $HOST_URL"

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Create Email Alert CronExpression Hook (continue): continue"
fi

echo
echo "Creating Hook in spaceId: " $spaceId

hookName='EmailAlertCronExpressionHook'

POSTPAYLOAD='{
        "hook" : {
            "name" : "'"${hookName}"'",
            "hook_type" : "cron",
            "hook_object" : "cronObject",
            "action" : {
              "type" : "workflow",
              "config" : {
                "process_key" : "emailProcessorTransactionMetadataProcess",
                "search_criteria" : '${searchCriteria}',
                "search_window" : '${searchWindow}',
                "template_name" : "'"${inResponseTemplateName}"'",
                "emailSender" : "'"${emailSender}"'",
                "emailReceiver" : "'"${emailReceiver}"'",
                "emailSubject" : "'"${emailSubject}"'",
                "grant_type" : "authorization_code",
                "fdsAuthUrl" : "'"${HOST_URL/v2/oauth2/token.json}"'",
                "environment" : "'"${inpEnvironment}"'",
                "processor_transaction_metadata_flag_path" : "'"${processorTransactionMetadataFlagPath}"'",
                "processor_transaction_metadata_flag_value" : "'"${processorTransactionMetadataFlagValue}"'"
              }
            }
        },
    "hookRecordType" : "hook",
    "method" : "cron",
    "spaceId" : '${spaceId}',
    "target" : "hooks",
    "executionOrder" : 0,
    "locked" : false,
    "name" : "EmailAlertCronExpressionHook",
    "status" : "AVAILABLE"
}'

POST_RESULT=`curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD}"`
echo
echo $POST_RESULT

echo
jq . <<< $POST_RESULT

