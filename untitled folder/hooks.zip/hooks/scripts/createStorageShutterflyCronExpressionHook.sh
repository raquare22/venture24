#!/bin/bash

function prop {
    grep "^\\s*${1}=" elgsHook.Properties|cut -d'=' -f2
}

linkPreferences=LinkPreferencesV2

if [[ -z "$*" ]]; then
	echo
  read -p "Enter environment (local or dev or qa or stage or prod): " inpEnvironment
	echo
	read -p "Enter client (CheckWritePRA or PaymentEngPRA or COSMOSDoc1 or CSP-PRA or UHCWest or 1Click or CCSManual or NextGen or UNET or ODAR or COSMOS or MR_Appeals or ETS_Appeals or USP-PRA or USP-claims or CSP-Claims or OCM or CAP or TXGC or HouseCalls or NGS-Claims or PECOSMOSPRA or MCRLetters): " inpClientName
	echo
	read -p "Enter  Shutterfly /Storage Shutterfly Hook (SFLY/StorageSFLY): " hookNameType
	ACKNOWLEDGE_PROMPTS=true
else
	ACKNOWLEDGE_PROMPTS=$1
	if [[ $ACKNOWLEDGE_PROMPTS == false ]]; then
		COMP="yes"
	fi
	FILE_NAME=$2
	inpEnvironment=$3
	inpClientName=$4
	shift "$#"
fi

if [[ ($hookNameType == SFLY) && ( $inpEnvironment == local || $inpEnvironment == dev || $inpEnvironment == qa || $inpEnvironment == stage || $inpEnvironment == prod ) && ( $inpClientName == NextGen || $inpClientName == 1Click || $inpClientName == CCSManual || $inpClientName == CheckWritePRA || $inpClientName == UNET || $inpClientName == ODAR || $inpClientName == PaymentEngPRA || $inpClientName == COSMOSDoc1 || $inpClientName == CSP-PRA || $inpClientName == UHCWest || $inpClientName == COSMOS || $inpClientName == MR_Appeals || $inpClientName == ETS_Appeals || $inpClientName == USP-PRA || $inpClientName == USP-Claims || $inpClientName == CSP-Claims || $inpClientName == OCM || $inpClientName == CAP || $inpClientName == TXGC || $inpClientName == HouseCalls || $inpClientName = NGS_Claims || $inpClientName == PECOSMOSPRA || $inpClientName == MCRLetters)]]; then
	spaceId=$(prop ${inpEnvironment}.${inpClientName}.spaceId)
	HOST_URL=$(prop ${inpEnvironment}.HOST_URL)
	SFTP_HOST=$(prop ${inpEnvironment}.SFTP_HOST)
	SFTP_USER=$(prop ${inpEnvironment}.SFTP_USER)
	SFTP_PASSWORD=$(prop ${inpEnvironment}.SFTP_PASSWORD)
	searchCriteria=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.searchCriteria)
	searchWindow=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.searchWindow)
	cronExpression=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.cronExpression)
	emailReceiver=$(prop ${inpEnvironment}.emailReceiver)
	providerSpaceIdV2=$(prop ${inpEnvironment}.${linkPreferences}.spaceId)
	sftp_hostname=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_url)
	sftp_username=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_username)
	sftp_pw=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_password)
	sftp_username_arc=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_username_arc)
	sftp_pw_arc=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_password_arc)
	sftp_dir=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_path)
	sftp_archive_dir=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_archive_path)
	bounceEmailCheckEFTIND=$(prop ${inpEnvironment}.${inpClientName}.bounceEmailCheckEFTIND)
	fdsCloudAuthUrl=$(prop ${inpEnvironment}.fdsCloudAuthUrl)
	cloud_client_id=$(prop ${inpEnvironment}.cloud_client_id)
	cloud_client_secret=$(prop ${inpEnvironment}.cloud_client_secret)
	fdsCloudGetAttachmentUrl=$(prop ${inpEnvironment}.fdsCloudGetAttachmentUrl)
	maxDocumentsOccurs=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.maxDocumentsOccurs)
	skipManipulatePdfFile=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.skipManipulatePdfFile)
	originalPrintTrail=$(prop ${inpEnvironment}.${inpClientName}.originalPrintTrail)
	createOriginalCompanionFile=$(prop ${inpClientName}.createOriginalCompanionFile)
	writeEncryptedPDF=$([[ ( -z "$(prop ${inpEnvironment}.${inpClientName}.writeEncryptedPDF)" ) && ($(prop ${ENVIRO}.${inpClientName}.writeEncryptedPDF) == true) ]] && echo "true" || echo "false")

elif [[ ($hookNameType == StorageSFLY) && ( $inpEnvironment == local || $inpEnvironment == dev || $inpEnvironment == qa || $inpEnvironment == stage || $inpEnvironment == prod ) && ( $inpClientName == NextGen || $inpClientName == 1Click || $inpClientName == CCSManual || $inpClientName == CheckWritePRA || $inpClientName == UNET || $inpClientName == ODAR || $inpClientName == PaymentEngPRA || $inpClientName == COSMOSDoc1 || $inpClientName == CSP-PRA || $inpClientName == UHCWest || $inpClientName == COSMOS || $inpClientName == MR_Appeals || $inpClientName == ETS_Appeals || $inpClientName == USP-PRA || $inpClientName == USP-claims || $inpClientName == CSP-Claims || $inpClientName == OCM || $inpClientName == CAP || $inpClientName == HouseCalls || $inpClientName = NGS_Claims || $inpClientName == PECOSMOSPRA)]]; then

	spaceId=$(prop ${inpEnvironment}.${inpClientName}.spaceId)
	HOST_URL=$(prop ${inpEnvironment}.HOST_URL)
	SFTP_HOST=$(prop ${inpEnvironment}.SFTP_HOST)
	SFTP_USER=$(prop ${inpEnvironment}.SFTP_USER)
	SFTP_PASSWORD=$(prop ${inpEnvironment}.SFTP_PASSWORD)
	searchCriteria=$(prop ${inpEnvironment}.${inpClientName}.StorageShutterfly.searchCriteria)
	searchWindow=$(prop ${inpEnvironment}.${inpClientName}.StorageShutterfly.searchWindow)
	cronExpression=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.cronExpression)
	emailReceiver=$(prop ${inpEnvironment}.emailReceiver)
	providerSpaceIdV2=$(prop ${inpEnvironment}.${linkPreferences}.spaceId)
	sftp_hostname=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_url)
	sftp_username=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_username)
	sftp_pw=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_password)
	sftp_username_arc=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_username_arc)
	sftp_pw_arc=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_password_arc)
	sftp_dir=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_path)
	sftp_archive_dir=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.ftp_archive_path)
	bounceEmailCheckEFTIND=$(prop ${inpEnvironment}.${inpClientName}.bounceEmailCheckEFTIND)
	maxDocumentsOccurs=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.maxDocumentsOccurs)
	skipManipulatePdfFile=$(prop ${inpEnvironment}.${inpClientName}.Shutterfly.skipManipulatePdfFile)
	originalPrintTrail=$(prop ${inpEnvironment}.${inpClientName}.originalPrintTrail)
	createOriginalCompanionFile=$(prop ${inpClientName}.createOriginalCompanionFile)
	writeEncryptedPDF=$([[ ( -z "$(prop ${inpEnvironment}.${inpClientName}.writeEncryptedPDF)" ) && ($(prop ${ENVIRO}.${inpClientName}.writeEncryptedPDF) == true) ]] && echo "true" || echo "false")
	
else
	echo
	echo "Try again"
	exit 0
fi

document_update_flag_path=rprntSentToSF

if [[ ($inpClientName == CheckWritePRA) ]]; then
	if [[ -z "$TEMPLATENAME" ]]; then
		TEMPLATENAME="checkWritePRACompanion"
	fi
    if [[ -z "$TEMPLATENAME" ]]; then
	 echo "Try again"
	 exit 0
    fi
fi

if [[ ( $inpClientName == UNET ) && ( $hookNameType == SFLY )]]; then
    IFS=';' read -r -a arr_searchCriteria <<< "$searchCriteria"
    echo
    if [[ $inpEnvironment == qa ]]; then
		read -p "Enter Original Print Trail (3591 or 3599): " originalPrintTrail
		if [[ $originalPrintTrail -eq 3591 ]]; then
       		searchCriteria="${arr_searchCriteria[0]}"
       		originalPrintTrail=$originalPrintTrail
    	elif [[ $originalPrintTrail -eq 3599 ]]; then
       		searchCriteria="${arr_searchCriteria[1]}"
       		originalPrintTrail=$originalPrintTrail
    	else
       		echo
	   		echo "Try again"
	   		exit 0
    	fi
    elif [[ $inpEnvironment == prod ]]; then
    	read -p "Enter Original Print Trail (3610 or 3618): " originalPrintTrail
		if [[ $originalPrintTrail -eq 3610 ]]; then
       		searchCriteria="${arr_searchCriteria[0]}"
       		originalPrintTrail=$originalPrintTrail
    	elif [[ $originalPrintTrail -eq 3618 ]]; then
       		searchCriteria="${arr_searchCriteria[1]}"
       		originalPrintTrail=$originalPrintTrail
    	else
       		echo
	   		echo "Try again"
	   		exit 0
    	fi
    else
    	read -p "Enter Original Print Trail (3730 or 3738): " originalPrintTrail
		if [[ $originalPrintTrail -eq 3730 ]]; then
       		searchCriteria="${arr_searchCriteria[0]}"
       		originalPrintTrail=$originalPrintTrail
    	elif [[ $originalPrintTrail -eq 3738 ]]; then
       		searchCriteria="${arr_searchCriteria[1]}"
       		originalPrintTrail=$originalPrintTrail
    	else
       		echo
	   		echo "Try again"
	   		exit 0
    	fi
    fi
fi

echo
echo "inpEnvironment: $inpEnvironment"
echo "spaceId: $spaceId"
echo "ftpArchivedir: $sftp_archive_dir"
echo "Host URL: $HOST_URL"
echo "SFTP Host: $SFTP_HOST"
echo "SFTP User: $SFTP_USER"
echo "SFTP Password: $SFTP_PASSWORD"
echo "searchCriteria: $searchCriteria"
echo "searchWindow: $searchWindow"
echo "cronExpression: $cronExpression"
echo "originalPrintTrail: $originalPrintTrail"
echo "fdsCloudAuthUrl: $fdsCloudAuthUrl"
echo "cloud_client_id: $cloud_client_id"
echo "cloud_client_secret: $cloud_client_secret"
echo "fdsCloudGetAttachmentUrl: $fdsCloudGetAttachmentUrl"


echo
if [[ ( $ACKNOWLEDGE_PROMPTS == true ) && ( $hookNameType == SFLY )]]; then
read -p "Create Shutterfly CronExpression Hook (continue): continue"
else 
read -p "Create Storage Shutterfly CronExpression Hook (continue): continue"
fi

echo
echo "Creating Hook in spaceId: " $spaceId
echo "hookNameType : $hookNameType"
if [[ $hookNameType == SFLY ]]; then
hookName='sendDocumentsToShutterflyProcess'$inpClientName'CronExpressionHook'
else 
hookName='sendStorageErrorToShutterflyProcess'$inpClientName'CronExpressionHook'
fi


if [[ ( $inpClientName == CheckWritePRA ) && ($hookNameType == SFLY )]]; then
	POSTPAYLOAD='{
        "hook" : {
          "name" : "'"${hookName}"'",
          "hook_type" : "cron",
          "hook_object" : "cronObject",
          "action" : {
            "type" : "workflow",
            "config" : {
              "process_key" : "sendDocumentsToShutterflyProcess",
 "search_criteria" : "'"${searchCriteria}"'",
               "search_window" : "'"${searchWindow}"'",
              "sftp_hostname" : "'"${sftp_hostname}"'",
              "sftp_username" : "'"${sftp_username}"'",
              "sftp_pw" : "'"${sftp_pw}"'",
              "sftp_archive_dir" : "'"${ftpArchivedir}"'",
              "grant_type" : "authorization_code",
              "fdsAuthUrl" : "'"${HOST_URL/v2/oauth2/token.json}"'",
              "fdsDocumentUrl" : "'"${HOST_URL/v2/documents}"'",
              "document_update_flag_path" : "'"${document_update_flag_path}"'",
              "document_update_flag_value": true,
              "document_format_field" : "dateEmailSent",
              "environment" : "'"${inpEnvironment}"'",
              "spaceId" : "'"${spaceId}"'",
              "providerSpaceIdV2" : "'"${providerSpaceIdV2}"'",
              "maxDocumentsOccurs" : '${maxDocumentsOccurs}',
              "fdsCloudAuthUrl" : "'"${fdsCloudAuthUrl}"'",
              "cloud_client_id" : "'"${cloud_client_id}"'",
              "cloud_client_secret" : "'"${cloud_client_secret}"'",
              "cloud_grant_type" : "client_credentials",
              "fdsCloudGetAttachmentUrl" : "'"${fdsCloudGetAttachmentUrl}"'",
              "sftp_username_arc" : "'"${sftp_username_arc}"'",
              "sftp_pw_arc" : "'"${sftp_pw_arc}"'",
              "sftp_dir" : "'"${sftp_dir}"'",
              "sftp_archive_dir" : "'"${sftp_archive_dir}"'",
              "addressBlockX" : 1.0,
              "addressBlockY" : 1.84,
              "identifierFontSize" : 8.0,
              "originalPrintTrail" : "'"${originalPrintTrail}"'",
              "receiverIdentifier" : "'"DPS\$\$\$PKG"'",
              "template_name" : "'"${TEMPLATENAME}"'",
              "skipManipulatePdfFile" : '${skipManipulatePdfFile}',
              "createOriginalCompanionFile" : '${createOriginalCompanionFile}',
              "writeEncryptedPDF" : "'"${writeEncryptedPDF}"'"
            }
          }
        },
    "hookRecordType" : "hook",
    "method" : "cron",
    "spaceId" : '${spaceId}',
    "target" : "hooks",
    "executionOrder" : 0,
    "locked" : false,
    "name" : "'"${hookName}"'",
    "status" : "AVAILABLE"
}'
elif [[ ($inpClientName != CheckWritePRA) && ($hookNameType == SFLY)]]; then
	POSTPAYLOAD='{
        "hook" : {
          "name" : "'"${hookName}"'",
          "hook_type" : "cron",
          "hook_object" : "cronObject",
          "action" : {
            "type" : "workflow",
            "config" : {
              "process_key" : "sendDocumentsToShutterflyProcess",
 "search_criteria" : "'"${searchCriteria}"'",
               "search_window" : "'"${searchWindow}"'",
              "sftp_hostname" : "'"${sftp_hostname}"'",
              "sftp_username" : "'"${sftp_username}"'",
              "sftp_pw" : "'"${sftp_pw}"'",
              "sftp_archive_dir" : "'"${ftpArchivedir}"'",
              "grant_type" : "authorization_code",
              "fdsAuthUrl" : "'"${HOST_URL/v2/oauth2/token.json}"'",
              "fdsDocumentUrl" : "'"${HOST_URL/v2/documents}"'",
              "document_update_flag_path" : "'"${document_update_flag_path}"'",
              "document_update_flag_value": true,
              "document_format_field" : "dateEmailSent",
              "environment" : "'"${inpEnvironment}"'",
              "spaceId": "'"${spaceId}"'",
              "providerSpaceIdV2": "'"${providerSpaceIdV2}"'",
              "maxDocumentsOccurs": '${maxDocumentsOccurs}',
              "bounceEmailCheckEFTIND": '${bounceEmailCheckEFTIND}',
              "startDateInDays" : -8,
              "fdsCloudAuthUrl" : "'"${fdsCloudAuthUrl}"'",
              "cloud_client_id" : "'"${cloud_client_id}"'",
              "cloud_client_secret" : "'"${cloud_client_secret}"'",
              "cloud_grant_type" : "client_credentials",
              "fdsCloudGetAttachmentUrl" : "'"${fdsCloudGetAttachmentUrl}"'",
              "sftp_username_arc": "'"${sftp_username_arc}"'",
              "sftp_pw_arc": "'"${sftp_pw_arc}"'",
              "sftp_dir": "'"${sftp_dir}"'",
              "sftp_archive_dir": "'"${sftp_archive_dir}"'",
              "addressBlockX": 1.0,
              "addressBlockY": 1.84,
              "identifierFontSize": 8.0,
              "originalPrintTrail": "'"${originalPrintTrail}"'",
              "receiverIdentifier": "'"DPS\$\$\$PKG"'",
              "skipManipulatePdfFile": '${skipManipulatePdfFile}',
              "createOriginalCompanionFile": '${createOriginalCompanionFile}',
              "writeEncryptedPDF": "'"${writeEncryptedPDF}"'"
            }
          }
        },
    "hookRecordType" : "hook",
    "method" : "cron",
    "spaceId" : '${spaceId}',
    "target" : "hooks",
    "executionOrder" : 0,
    "locked" : false,
    "name" : "'"${hookName}"'",
    "status" : "AVAILABLE"
}'
fi


if [[ ( $inpClientName == CheckWritePRA ) && ( $hookNameType == StorageSFLY )]]; then
	POSTPAYLOAD='{
        "hook" : {
          "name" : "'"${hookName}"'",
          "hook_type" : "cron",
          "hook_object" : "cronObject",
          "action" : {
            "type" : "workflow",
            "config" : {
              "process_key" : "sendStorageErrorToShutterfly",
 "search_criteria" : "'"${searchCriteria}"'",
               "search_window" : "'"${searchWindow}"'",
              "sftp_hostname" : "'"${sftp_hostname}"'",
              "sftp_username" : "'"${sftp_username}"'",
              "sftp_pw" : "'"${sftp_pw}"'",
              "sftp_archive_dir" : "'"${ftpArchivedir}"'",
              "grant_type" : "authorization_code",
              "fdsAuthUrl" : "'"${HOST_URL/v2/oauth2/token.json}"'",
              "fdsDocumentUrl" : "'"${HOST_URL/v2/documents}"'",
              "document_update_flag_path" : "'"${document_update_flag_path}"'",
              "document_update_flag_value": true,
              "document_format_field" : "dateEmailSent",
              "environment" : "'"${inpEnvironment}"'",
              "spaceId" : "'"${spaceId}"'",
              "providerSpaceIdV2" : "'"${providerSpaceIdV2}"'",
              "maxDocumentsOccurs" : '${maxDocumentsOccurs}',
              "sftp_username_arc" : "'"${sftp_username_arc}"'",
              "sftp_pw_arc" : "'"${sftp_pw_arc}"'",
              "sftp_dir" : "'"${sftp_dir}"'",
              "sftp_archive_dir" : "'"${sftp_archive_dir}"'",
              "addressBlockX" : 1.0,
              "addressBlockY" : 1.84,
              "identifierFontSize" : 8.0,
              "originalPrintTrail" : "'"${originalPrintTrail}"'",
              "receiverIdentifier" : "'"DPS\$\$\$PKG"'",
              "template_name" : "'"${TEMPLATENAME}"'",
              "skipManipulatePdfFile" : '${skipManipulatePdfFile}',
              "createOriginalCompanionFile" : '${createOriginalCompanionFile}',
              "writeEncryptedPDF" : "'"${writeEncryptedPDF}"'"
            }
          }
        },
    "hookRecordType" : "hook",
    "method" : "cron",
    "spaceId" : '${spaceId}',
    "target" : "hooks",
    "executionOrder" : 0,
    "locked" : false,
    "name" : "'"${hookName}"'",
    "status" : "AVAILABLE"
}'
elif [[ ($inpClientName != CheckWritePRA) && ( $hookNameType == StorageSFLY )]]; then

	POSTPAYLOAD='{
        "hook" : {
          "name" : "'"${hookName}"'",
          "hook_type" : "cron",
          "hook_object" : "cronObject",
          "action" : {
            "type" : "workflow",
            "config" : {
              "process_key" : "sendStorageErrorToShutterfly",
              "search_criteria" : "'"${searchCriteria}"'",
               "search_window" : "'"${searchWindow}"'",
              "sftp_hostname" : "'"${sftp_hostname}"'",
              "sftp_username" : "'"${sftp_username}"'",
              "sftp_pw" : "'"${sftp_pw}"'",
              "sftp_archive_dir" : "'"${ftpArchivedir}"'",
              "grant_type" : "authorization_code",
              "fdsAuthUrl" : "'"${HOST_URL/v2/oauth2/token.json}"'",
              "fdsDocumentUrl" : "'"${HOST_URL/v2/documents}"'",
              "document_update_flag_path" : "'"${document_update_flag_path}"'",
              "document_update_flag_value": true,
              "document_format_field" : "dateEmailSent",
              "environment" : "'"${inpEnvironment}"'",
              "spaceId": "'"${spaceId}"'",
              "providerSpaceIdV2": "'"${providerSpaceIdV2}"'",
              "maxDocumentsOccurs": '${maxDocumentsOccurs}',
              "bounceEmailCheckEFTIND": '${bounceEmailCheckEFTIND}',
              "startDateInDays" : -8,
              "sftp_username_arc": "'"${sftp_username_arc}"'",
              "sftp_pw_arc": "'"${sftp_pw_arc}"'",
              "sftp_dir": "'"${sftp_dir}"'",
              "sftp_archive_dir": "'"${sftp_archive_dir}"'",
              "addressBlockX": 1.0,
              "addressBlockY": 1.84,
              "identifierFontSize": 8.0,
              "originalPrintTrail": "'"${originalPrintTrail}"'",
              "receiverIdentifier": "'"DPS\$\$\$PKG"'",
              "skipManipulatePdfFile": '${skipManipulatePdfFile}',
              "createOriginalCompanionFile": '${createOriginalCompanionFile}',
              "writeEncryptedPDF": "'"${writeEncryptedPDF}"'"
            }
          }
        },
    "hookRecordType" : "hook",
    "method" : "cron",
    "spaceId" : '${spaceId}',
    "target" : "hooks",
    "executionOrder" : 0,
    "locked" : false,
    "name" : "'"${hookName}"'",
    "status" : "AVAILABLE"
}'
fi


GET_RESULT=`curl -verbose -X GET -k "$HOST_URL/api/services/v1/hooks?name=$hookName&spaceId=$spaceId"`
echo "GET_RESULT:  " $GET_RESULT
jq . <<< $GET_RESULT
 echo 'List of available hook IDs'
echo "$GET_RESULT" | jq -r '.response[]|"\(.id)"'
echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Starting delete hook process one by one, press enter to continue : "
fi
 for row in $(echo "$GET_RESULT" | jq -r '.response[] | @base64'); do
    _jq() {
     echo ${row} | base64 --decode | jq -r ${1}
    }
echo ${row} | base64 --decode | jq -r ${1}

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Would you like to delete $(_jq '.id') yes or no:" COMP
fi
if [[ $COMP == yes ]]; then
  DELETE_RESULT=`curl -k -verbose -X DELETE -k "$HOST_URL/api/services/v1/hooks/delete/$(_jq '.id')"`
	jq . <<< $DELETE_RESULT
	if [[ -z "$deletedHooks" ]]; then
		deletedHooks="${0##*/}: $(_jq '.id')"
	else
		deletedHooks="$deletedHooks, $(_jq '.id')"
	fi
fi
done

if [[ $ACKNOWLEDGE_PROMPTS == false && ! -z "$deletedHooks" ]]; then
	echo $deletedHooks >> $FILE_NAME
fi

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Post Shutterfly Cron Expression Hook, press enter to continue"
fi

POST_RESULT=`curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD}"`
echo
echo $POST_RESULT

echo
jq . <<< $POST_RESULT
