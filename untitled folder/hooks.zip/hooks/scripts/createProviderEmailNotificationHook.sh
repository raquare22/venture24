#!/bin/bash

function prop {
    grep "^\\s*${1}=" elgsHook.Properties|cut -d'=' -f2-
}

hookName=ProviderEmailNotificationHook
processName=providerEmailNotificationProcess

if [[ -z "$*" ]]; then
	echo
  read -p "Enter environment (local, dev, qa, stage, prod): " ENVIRO
	echo
	read -p "Enter client (UNET, COSMOS, COSMOSDoc1, NextGen, 1Click, CCSManual, PaymentEngPRA, CheckWritePRA, CSP-PRA, UHCWest, ODAR, MR_Appeals, ETS_Appeals or USP-PRA or USP-claims or CSP-Claims or OCM or CAP or TXGC or HouseCalls or NGS-Claims or PECOSMOSPRA): " inpClientName
  penRequestTemplateName="emailRequestToPEN"
	ACKNOWLEDGE_PROMPTS=true
else
	ACKNOWLEDGE_PROMPTS=$1
	if [[ $ACKNOWLEDGE_PROMPTS == false ]]; then
		COMP="yes"
		CHOICE="no"
	fi
	FILE_NAME=$2
	ENVIRO=$3
	inpClientName=$4
  penRequestTemplateName=$5
	shift "$#"
fi

echo ENVIRO=$ENVIRO
echo inpClientName=$inpClientName

if [[ ( $ENVIRO == local || $ENVIRO == dev || $ENVIRO == qa || $ENVIRO == stage || $ENVIRO == prod ) &&
 ( $inpClientName == UNET || $inpClientName == COSMOS || $inpClientName == COSMOSDoc1 || $inpClientName == NextGen || $inpClientName == 1Click || $inpClientName == CCSManual || $inpClientName == PaymentEngPRA || $inpClientName == CheckWritePRA || $inpClientName == CSP-PRA || $inpClientName == UHCWest || $inpClientName == ODAR || $inpClientName == MR_Appeals || $inpClientName == ETS_Appeals || $inpClientName == USP-PRA || $inpClientName == USP-claims || $inpClientName == CSP-Claims || $inpClientName == OCM || $inpClientName == CAP || $inpClientName == TXGC || $inpClientName == HouseCalls || $inpClientName = NGS_Claims || $inpClientName == PECOSMOSPRA) ]]; then
	HOST_URL=$(prop ${ENVIRO}.HOST_URL)
	inpConfigSpaceId=$(prop ${ENVIRO}.${inpClientName}.spaceId)
	PENAPIUrl=$(prop ${ENVIRO}.${hookName}.PENAPIUrl)
	cronExpression=$(prop ${ENVIRO}.${inpClientName}.${hookName}.cronExpression)
	searchCriteria=$(prop ${ENVIRO}.${inpClientName}.${hookName}.searchCriteria)
	searchWindow=$(prop ${hookName}.searchWindow)
	flagPath=$(prop ${hookName}.processor_transaction_metadata_flag_path)
	flagValue=$(prop ${ENVIRO}.${inpClientName}.${hookName}.processor_transaction_metadata_flag_value)

else
	echo "Try again"
	exit 0
fi

echo
echo "HOST_URL=$HOST_URL"
echo "inpConfigSpaceId=$inpConfigSpaceId"
echo "PENAPIUrl:$PENAPIUrl"
echo "cronExpression:$cronExpression"
echo "search_criteria:$searchCriteria"
echo "search_window:$searchWindow"
echo "template_name:$penRequestTemplateName"
echo "processor_transaction_metadata_flag_path:$flagPath"
echo "processor_transaction_metadata_flag_value:$flagValue"

GET_RESULT=`curl -verbose -X GET -k "$HOST_URL/api/services/v1/hooks?name=$hookName&spaceId=$inpConfigSpaceId"`
echo "GET_RESULT:  " $GET_RESULT
jq . <<< $GET_RESULT
echo 'List of available hook IDs'
currentHooks=`echo "$GET_RESULT" | jq -r '.response[]|"\(.id)"'`
if [[ -z "$currentHooks" ]]; then
echo "No hook(s) currently exist"
else
echo "$currentHooks"
echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Starting delete hook process one by one, press enter to continue"
fi
 for row in $(echo "$GET_RESULT" | jq -r '.response[] | @base64'); do
    _jq() {
     echo ${row} | base64 --decode | jq -r ${1}
    }
echo ${row} | base64 --decode | jq -r ${1}

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Would you like to delete $(_jq '.id') yes or no:" COMP
fi
if [[ $COMP == yes ]]; then
  DELETE_RESULT=`curl -k -verbose -X DELETE -k "$HOST_URL/api/services/v1/hooks/delete/$(_jq '.id')"`
	jq . <<< $DELETE_RESULT
	if [[ -z "$deletedHooks" ]]; then
		deletedHooks="${0##*/}: $(_jq '.id')"
	else
		deletedHooks="$deletedHooks, $(_jq '.id')"
	fi
fi
done

if [[ $ACKNOWLEDGE_PROMPTS == false && ! -z "$deletedHooks" ]]; then
	echo $deletedHooks >> $FILE_NAME
fi
fi

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Create Provider Email Notification Hook in $inpClientName SpaceId $inpConfigSpaceId(continue): continue"
fi

POSTPAYLOAD='{
        "hook" : {
            "name" : "'"${hookName}"'",
				    "hook_type" : "cron",
				    "hook_object" : "cronObject",
				    "action" : {
					    "type" : "workflow",
					    "config" : {
						    "process_key" : "'"${processName}"'",
                "PENAPIUrl" : "'"${PENAPIUrl}"'",
                "search_criteria" : "'"${searchCriteria}"'",
                "search_window" : "'"${searchWindow}"'",
                "document_update_flag_path" : "'"${flagPath}"'",
                "document_update_flag_value" : '${flagValue}',
                "template_name" : "'"${penRequestTemplateName}"'",
                "maxRetries": 2,
                "retrySleepTime": 500,
					    }
				    }
        },
    "hookRecordType" : "hook",
    "method" : "cron",
    "spaceId" : '${inpConfigSpaceId}',
    "target" : "hooks",
    "executionOrder" : 0,
    "locked" : false,
    "name" : "ProviderEmailNotificationHook",
    "status" : "AVAILABLE"
}'

POST_RESULT=`curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD}"`
echo
echo $POST_RESULT

echo
jq . <<< $POST_RESULT

exit 0
