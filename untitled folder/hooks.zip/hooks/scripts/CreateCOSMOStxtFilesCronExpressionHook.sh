#!/bin/bash

function prop {
    grep "^\\s*${1}=" elgsHook.Properties|cut -d'=' -f2
}

proccessName=CreateAckProccess

if [[ -z "$*" ]]; then
       echo
       read -p "Enter environment (local or dev or qa or stage or prod): " inpEnvironment
       echo
       read -p "Enter client (COSMOS or COSMOSDoc1): " inpClientName
       echo
       read -p "Enter MongoDB ack/stat Template Name (cosmosAckTemplate or cosmosDoc1StatusTemplate): " inpTemplateName
       ACKNOWLEDGE_PROMPTS=true
else
       ACKNOWLEDGE_PROMPTS=$1
       if [[ $ACKNOWLEDGE_PROMPTS == false ]]; then
              COMP="yes"
       fi
       FILE_NAME=$2
       inpEnvironment=$3
       inpClientName=$4
       inpTemplateName=$5
       shift "$#"
fi

if [[ ( $inpEnvironment == local || $inpEnvironment == dev || $inpEnvironment == qa || $inpEnvironment == stage || $inpEnvironment == prod ) && ( $inpClientName == COSMOS || $inpClientName == COSMOSDoc1 ) && ( -n "$inpTemplateName" ) ]]; then
       spaceId=$(prop ${inpEnvironment}.${inpClientName}.spaceId)
       ftpArchivedir=$(prop ${inpEnvironment}.${inpClientName}.ftpArchivedir)
       HOST_URL=$(prop ${inpEnvironment}.HOST_URL)
       SFTP_HOST=$(prop ${inpEnvironment}.SFTP_HOST)
       SFTP_USER=$(prop ${inpEnvironment}.SFTP_USER)
       SFTP_PASSWORD=$(prop ${inpEnvironment}.SFTP_PASSWORD)
       sftpDir=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.sftpDir)
       searchCriteria=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.searchCriteria)
       searchWindow=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.searchWindow)
       cronExpression=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.cronExpression)
       outputFileExtension=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.outputFileExtension)
       zipOutputFile=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.zipOutputFile)
else
       echo
       echo "Try again"
       exit 0
fi

echo
echo "inpEnvironment: $inpEnvironment"
echo "spaceId: $spaceId"
echo "inpTemplateName: $inpTemplateName"
echo "sftpDir: $sftpDir"
echo "ftpArchivedir: $ftpArchivedir"
echo "Host URL: $HOST_URL"
echo "SFTP Host: $SFTP_HOST"
echo "SFTP User: $SFTP_USER"
echo "SFTP Password: $SFTP_PASSWORD"
echo "searchCriteria: $searchCriteria"
echo "searchWindow: $searchWindow"
echo "cronExpression: $cronExpression"
echo "outputFileExtension: $outputFileExtension"
echo "zipOutputFile: $zipOutputFile"

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Create Ack Files CronExpression Hook (continue): continue"
fi

hookName='Create'$inpClientName$outputFileExtension'FilesCronExpressionHook'

GET_RESULT=`curl -verbose -X GET -k "$HOST_URL/api/services/v1/hooks?name=$hookName&spaceId=$spaceId"`
echo "GET_RESULT:  " $GET_RESULT
jq . <<< $GET_RESULT
 echo 'List of available hook IDs'
echo "$GET_RESULT" | jq -r '.response[]|"\(.id)"'
echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Starting delete hook process one by one, press enter to continue"
fi
 for row in $(echo "$GET_RESULT" | jq -r '.response[] | @base64'); do
    _jq() {
     echo ${row} | base64 --decode | jq -r ${1}
    }
echo ${row} | base64 --decode | jq -r ${1}

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Would you like to delete $(_jq '.id') yes or no:" COMP
fi
if [[ $COMP == yes ]]; then
       DELETE_RESULT=`curl -k -verbose -X DELETE -k "$HOST_URL/api/services/v1/hooks/delete/$(_jq '.id')"`
       jq . <<< $DELETE_RESULT
       if [[ -z "$deletedHooks" ]]; then
              deletedHooks="${0##*/}: $(_jq '.id')"
       else
              deletedHooks="$deletedHooks, $(_jq '.id')"
       fi
fi
done

if [[ $ACKNOWLEDGE_PROMPTS == false && ! -z "$deletedHooks" ]]; then
       echo $deletedHooks >> $FILE_NAME
fi

echo
echo "Creating Hook in spaceId: " $spaceId

POSTPAYLOAD='{
        "hook" : {
            "name" : "'"${hookName}"'",
            "hook_type" : "cron",
            "hook_object" : "cronObject",
            "action" : {
              "type" : "workflow",
              "config" : {
                "process_key" : "createStatusFileAndAckProcess",
                "search_criteria" : "'"${searchCriteria}"'",
                "search_window" : '${searchWindow}',
                "template_name" : "'"${inpTemplateName}"'",
                "output_file_extension" : "'"${outputFileExtension}"'",
                "zip_output_file" : '${zipOutputFile}',
                "sftp_hostname" : "'"${SFTP_HOST}"'",
                "sftp_username" : "'"${SFTP_USER}"'",
                "sftp_pw" : "'"${SFTP_PASSWORD}"'",
                "sftp_dir" : "'"${sftpDir}"'",
                "sftp_archive_dir" : "'"${ftpArchivedir}"'",
                "grant_type" : "authorization_code",
                "fdsAuthUrl" : "'"${HOST_URL/v2/oauth2/token.json}"'",
                "document_update_flag_path" : "addedToStatusFile",
                "document_update_flag_value" : true,
                "multi_put_request_size" : 300
                }
            }
        },
    "hookRecordType" : "hook",
    "method" : "cron",
    "spaceId" : "'"${spaceId}"'",
    "target" : "hooks",
    "executionOrder" : 0,
    "locked" : false,
    "name" : "'"${hookName}"'",
    "status" : "AVAILABLE"
}'

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Create Ack Files CronExpression Hook (continue): continue"
fi

POST_RESULT=`curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD}"`
echo
echo $POST_RESULT

echo
jq . <<< $POST_RESULT