#!/bin/bash

function prop {
    grep "^\\s*${1}=" elgsHook.properties|cut -d'=' -f2-
}

if [[ -z "$*" ]]; then
       echo
       read -p "Enter environment (local or dev or qa or stage or prod): " ENVIRO
       echo
       read -p "Enter client (CheckWritePRA or PaymentEngPRA or COSMOSDoc1 or CSP-PRA or UHCWest or 1Click or CCSManual or NextGen or UNET or ODAR or COSMOS or MR_Appeals or ETS_Appeals or USP-PRA or USP-claims or CSP-Claims or CAP or TXGC or HouseCalls or NGS-Claims or PECOSMOSPRA or MCRLetters or PaySummaryDocs or TennCareReports or LeifProviderReports or NYPCMHReports): " inpClientName


       trigger_method="post"
       doc_lib_template_name="filterReqFieldForDocvault"
       ACKNOWLEDGE_PROMPTS=true
else
       ACKNOWLEDGE_PROMPTS=$1
       if [[ $ACKNOWLEDGE_PROMPTS == false ]]; then
              COMP="yes"
       fi
       FILE_NAME=$2
       ENVIRO=$3
       inpClientName=$4
       if [[ "$#" -ge 7 ]]; then
              doc_lib_template_name=$5
              trigger_method=$6
       else
         echo "Required greater than equal to 6 parameters found $#"
         exit 0
       fi
       shift "$#"
fi


if [[ ( $ENVIRO == local || $ENVIRO == dev || $ENVIRO == qa || $ENVIRO == stage || $ENVIRO == prod) &&
  ($inpClientName == PaymentEngPRA || $inpClientName == COSMOSDoc1  || $inpClientName == CheckWritePRA || $inpClientName == CSP-PRA || $inpClientName == UHCWest || $inpClientName == CCSManual || $inpClientName == NextGen || $inpClientName == 1Click || $inpClientName == UNET || $inpClientName == ODAR || $inpClientName == COSMOS || $inpClientName == MR_Appeals || $inpClientName == ETS_Appeals || $inpClientName == USP-PRA || $inpClientName == USP-claims || $inpClientName == CSP-Claims || $inpClientName == CAP || $inpClientName == TXGC || $inpClientName == HouseCalls || $inpClientName = NGS_Claims || $inpClientName == PECOSMOSPRA || $inpClientName == MCRLetters || $inpClientName == PaySummaryDocs || $inpClientName == TennCareReports || $inpClientName == LeifProviderReports || $inpClientName == NYPCMHReports) &&
  ($trigger_method == post)
  ]]; then

       HOST_URL=$(prop "${ENVIRO}.HOST_URL")
       inpSpaceId=$(prop "${ENVIRO}.${inpClientName}.spaceId")
       searchCriteria=$(prop ${ENVIRO}.${inpClientName}.DocLib.searchCriteria)
       searchWindow=$(prop ${ENVIRO}.${inpClientName}.DocLib.searchWindow)
       maxDocumentsOccurs=$(prop ${ENVIRO}.${inpClientName}.DocLib.maxDocumentsOccurs)
       slaTime=$(prop ${ENVIRO}.${inpClientName}.DocLib.slaTime)
       criteria=$(prop "${inpClientName}.${trigger_method}.docVault.criteria")
       doc_vault_oauth_url=$(prop docVaultOauthUrl)
       doc_vault_rest_url=$(prop "${ENVIRO}.docVaultRestUrl")
       doc_lib_oauth_url=$(prop "${ENVIRO}.docLibOauthUrl")
       doc_lib_rest_url=$(prop "${ENVIRO}.docLibRestUrl")
       doc_lib_client_id=$(prop "${ENVIRO}.docLibClientId")
       doc_lib_client_secret=$(prop "${ENVIRO}.docLibClientSecret")
       hook_name=hookDocLibRestApi_${trigger_method}_${inpSpaceId}
else
       echo "Try again"
       exit 0
fi


echo
echo "hookName: $hook_name"
echo "search_criteria: $searchCriteria"
echo "search_window: $searchWindow"
echo "docVault rest url: $doc_vault_rest_url"
echo "docVault oauth url: $doc_vault_oauth_url"
echo "docLib rest url: $doc_lib_rest_url"
echo "docLib oauth url: $doc_lib_oauth_url"
echo "docLib client id: $doc_lib_client_id"
echo "docLib client secret: $doc_lib_client_secret"
echo "inpSpaceId: $inpSpaceId"
echo "criteria: $criteria"
echo "trigger_method: $trigger_method"
echo "maxDocumentsOccurs: $maxDocumentsOccurs"
echo "docLib template name: $doc_lib_template_name"


if [[ ($inpClientName == CheckWritePRA) ]]; then
  hook_name1=hookDocLibRestApi_post_${inpSpaceId}
  hook_name2=hookDocLibRestApi_put_${inpSpaceId}
  hook_name3=hookDocLibRestApi_put_${inpSpaceId}
  searchCriteria_put1=$(prop ${ENVIRO}.${inpClientName}.DocLib.searchCriteria_put1)
  searchWindow_put1=$(prop ${ENVIRO}.${inpClientName}.DocLib.searchWindow_put1)
  searchCriteria_put2=$(prop ${ENVIRO}.${inpClientName}.DocLib.searchCriteria_put2)
  searchWindow_put2=$(prop ${ENVIRO}.${inpClientName}.DocLib.searchWindow_put2)

  POSTPAYLOAD1='{
        "hook" : {
          "name": "'"${hook_name1}"'",
          "executionOrder" : "0",
          "eval_time": "POST_PROCESS",
          "hook_type": "standard",
          "hook_object": "objectOne",
          "action": {
            "type": "workflow",
            "config": {
              "search_criteria" : '${searchCriteria}',
              "search_window" : "'"${searchWindow}"'",
              "process_key" : "postDocumentDocvaultForElgsProcess",
              "docLibOauthUrl" : "'"${doc_lib_oauth_url}"'",
              "docLibClientId" : "'"${doc_lib_client_id}"'",
              "docLibClientSecret" : "'"${doc_lib_client_secret}"'",
              "docLibRestUrl" : "'"${doc_lib_rest_url}"'",
              "template_name" : "'"${doc_lib_template_name}"'",
              "maxRetries" : 2,
              "retrySleepTime" : 500,
              "slaTime" : '${slaTime}',
              "maxDocumentsOccurs" : '${maxDocumentsOccurs}'
            }
          }
        },
    "hookRecordType" : "hook",
    "method" : "post",
    "spaceId" : "'"${inpSpaceId}"'",
    "target" : "documents",
    "executionOrder" : 0,
    "locked" : false,
    "name" : "'"${hook_name1}"'",
    "status" : "AVAILABLE"
}'

POSTPAYLOAD2='{
        "hook" : {
          "name": "'"${hook_name2}"'",
          "executionOrder" : "0",
          "eval_time": "POST_PROCESS",
          "hook_type": "standard",
          "hook_object": "objectOne",
          "action": {
            "type": "workflow",
            "config": {
              "search_criteria" : '${searchCriteria_put1}',
              "search_window" : "'"${searchWindow_put1}"'",
              "process_key" : "postDocumentDocvaultForElgsProcess",
              "docLibOauthUrl" : "'"${doc_lib_oauth_url}"'",
              "docLibClientId" : "'"${doc_lib_client_id}"'",
              "docLibClientSecret" : "'"${doc_lib_client_secret}"'",
              "docLibRestUrl" : "'"${doc_lib_rest_url}"'",
              "template_name" : "'"${doc_lib_template_name}"'",
              "maxRetries" : 2,
              "retrySleepTime" : 500,
              "slaTime" : '${slaTime}',
              "maxDocumentsOccurs" : '${maxDocumentsOccurs}'
            }
          }
        },
    "hookRecordType" : "hook",
    "method" : "put",
    "spaceId" : "'"${inpSpaceId}"'",
    "target" : "documents",
    "executionOrder" : 0,
    "locked" : false,
    "name" : "'"${hook_name2}"'",
    "status" : "AVAILABLE"
}'

POSTPAYLOAD3='{
        "hook" : {
          "name": "'"${hook_name3}"'",
          "executionOrder" : "0",
          "eval_time": "POST_PROCESS",
          "hook_type": "standard",
          "hook_object": "objectOne",
          "action": {
            "type": "workflow",
            "config": {
              "search_criteria" : '${searchCriteria_put2}',
              "search_window" : "'"${searchWindow_put2}"'",
              "process_key" : "postDocumentDocvaultForElgsProcess",
              "docLibOauthUrl" : "'"${doc_lib_oauth_url}"'",
              "docLibClientId" : "'"${doc_lib_client_id}"'",
              "docLibClientSecret" : "'"${doc_lib_client_secret}"'",
              "docLibRestUrl" : "'"${doc_lib_rest_url}"'",
              "template_name" : "'"${doc_lib_template_name}"'",
              "maxRetries" : 2,
              "retrySleepTime" : 500,
              "slaTime" : '${slaTime}',
              "maxDocumentsOccurs" : '${maxDocumentsOccurs}'
            }
          }
        },
    "hookRecordType" : "hook",
    "method" : "put",
    "spaceId" : "'"${inpSpaceId}"'",
    "target" : "documents",
    "executionOrder" : 0,
    "locked" : false,
    "name" : "'"${hook_name3}"'",
    "status" : "AVAILABLE"
}'

else
  POSTPAYLOAD='{
        "hook" : {
          "name": "'"${hook_name}"'",
          "executionOrder" : "0",
          "eval_time": "POST_PROCESS",
          "hook_type": "standard",
          "hook_object": "objectOne",
          "action": {
            "type": "workflow",
            "config": {
              "search_criteria" : '${searchCriteria}',
              "search_window" : "'"${searchWindow}"'",
              "process_key" : "postDocumentDocvaultForElgsProcess",
              "docLibOauthUrl" : "'"${doc_lib_oauth_url}"'",
              "docLibClientId" : "'"${doc_lib_client_id}"'",
              "docLibClientSecret" : "'"${doc_lib_client_secret}"'",
              "docLibRestUrl" : "'"${doc_lib_rest_url}"'",
              "template_name" : "'"${doc_lib_template_name}"'",
              "maxRetries" : 2,
              "retrySleepTime" : 500,
              "slaTime" : '${slaTime}',
              "maxDocumentsOccurs" : '${maxDocumentsOccurs}'
            }
          }
        },
    "hookRecordType" : "hook",
    "method" : "'"${trigger_method}"'",
    "spaceId" : "'"${inpSpaceId}"'",
    "target" : "documents",
    "executionOrder" : 0,
    "locked" : false,
    "name" : "'"${hook_name}"'",
    "status" : "AVAILABLE"
}'
fi

GET_RESULT=`curl -verbose -X GET -k "$HOST_URL/api/services/v1/hooks?name=$hook_name&spaceId=$inpSpaceId"`

echo "GET_RESULT:  " "$GET_RESULT"
jq . <<< $GET_RESULT
 echo 'List of available hook IDs'
echo "$GET_RESULT" | jq -r '.response[]|"\(.id)"'
echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Starting delete hook process one by one, press enter to continue"
fi
 for row in $(echo "$GET_RESULT" | jq -r '.response[] | @base64'); do
    _jq() {
     echo ${row} | base64 --decode | jq -r ${1}
    }
echo ${row} | base64 --decode | jq -r ${1}

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Would you like to delete $(_jq '.id') yes or no:" COMP
fi
if [[ $COMP == yes ]]; then
       DELETE_RESULT=`curl -k -verbose -X DELETE -k "$HOST_URL/api/services/v1/hooks/delete/$(_jq '.id')"`
       jq . <<< $DELETE_RESULT
       if [[ -z "$deletedHooks" ]]; then
              deletedHooks="${0##*/}: $(_jq '.id')"
       else
              deletedHooks="$deletedHooks, $(_jq '.id')"
       fi
fi
done

if [[ $ACKNOWLEDGE_PROMPTS == false && ! -z "$deletedHooks" ]]; then
       echo $deletedHooks >> $FILE_NAME
fi

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
  read -p "Post Process for DocLib Hook, press enter to continue"
fi

if [[ ($inpClientName == CheckWritePRA) ]]; then
  POST_RESULT=$(curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD1}")
  POST_RESULT1=$(curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD2}")
  POST_RESULT2=$(curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD3}")
  echo
  echo $POST_RESULT
  echo
  echo $POST_RESULT1
  echo
  echo $POST_RESULT2
else
  POST_RESULT=$(curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD}")
  echo
  echo $POST_RESULT
fi
#POST_RESULT=$(curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD}")

#echo
#echo $POST_RESULT

echo
jq . <<< "$POST_RESULT"