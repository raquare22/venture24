#!/bin/bash

function prop {
	grep "^\\s*${1}=" elgsHook.properties | cut -d'=' -f2-
}

hookName=processConvertMetadataHook

if [[ -z "$*" ]]; then
	echo
	read -p "Enter environment (local or dev or qa or stage or prod): " ENVIRO
	echo
	read -p "Enter client (PaySummaryDocs or TennCareReports or LeifProviderReports or NYPCMHReports): " inpClientName
	ACKNOWLEDGE_PROMPTS=true
else
	ACKNOWLEDGE_PROMPTS=$1
	if [[ $ACKNOWLEDGE_PROMPTS == false ]]; then
		COMP="yes"
	fi
	FILE_NAME=$2
	ENVIRO=$3
	inpClientName=$4
	shift "$#"
fi

if [[ ( $ENVIRO == local || $ENVIRO == dev || $ENVIRO == qa || $ENVIRO == stage || $ENVIRO == prod ) && ( $inpClientName == PaySummaryDocs || $inpClientName == TennCareReports || $inpClientName == LeifProviderReports || $inpClientName == NYPCMHReports ) ]]; then
	HOST_URL=$(prop ${ENVIRO}.HOST_URL)
	inpConfigSpaceId=$(prop ${ENVIRO}.${inpClientName}.spaceId)
	searchCriteria=$(prop ${ENVIRO}.${inpClientName}.${hookName}.searchCriteria)
	searchWindow=$(prop ${ENVIRO}.${inpClientName}.${hookName}.searchWindow)
	maxDocumentsOccurs=$(prop ${ENVIRO}.${inpClientName}.${hookName}.maxDocumentsOccurs)
else
	echo "Try again"
	exit 0
fi

if [[ -z "$HOST_URL" || -z "$inpConfigSpaceId" || -z "$searchCriteria" || -z "$searchWindow" || -z "$maxDocumentsOccurs" ]]; then
	echo "Missing required property value(s). Please verify ${ENVIRO}.${inpClientName}.${hookName}.* entries in elgsHook.properties"
	exit 0
fi

echo
echo "HOST_URL=$HOST_URL"
echo "hookName=$hookName"
echo "inpConfigSpaceId=$inpConfigSpaceId"
echo "search_criteria=$searchCriteria"
echo "search_window=$searchWindow"
echo "maxDocumentsOccurs=$maxDocumentsOccurs"

GET_RESULT=`curl -verbose -X GET -k "$HOST_URL/api/services/v1/hooks?name=$hookName&spaceId=$inpConfigSpaceId"`
echo "GET_RESULT:  " $GET_RESULT
jq . <<< $GET_RESULT
echo 'List of available hook IDs'
currentHooks=`echo "$GET_RESULT" | jq -r '.response[]|"\(.id)"'`
if [[ -z "$currentHooks" ]]; then
	echo "No hook(s) currently exist"
else
	echo "$currentHooks"
	echo
	if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
		read -p "Starting delete hook process one by one, press enter to continue"
	fi
	for row in $(echo "$GET_RESULT" | jq -r '.response[] | @base64'); do
		_jq() {
			echo ${row} | base64 --decode | jq -r ${1}
		}
		echo ${row} | base64 --decode | jq -r ${1}

		echo
		if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
			read -p "Would you like to delete $(_jq '.id') yes or no:" COMP
		fi
		if [[ $COMP == yes ]]; then
			DELETE_RESULT=`curl -k -verbose -X DELETE -k "$HOST_URL/api/services/v1/hooks/delete/$(_jq '.id')"`
			jq . <<< $DELETE_RESULT
			if [[ -z "$deletedHooks" ]]; then
				deletedHooks="${0##*/}: $(_jq '.id')"
			else
				deletedHooks="$deletedHooks, $(_jq '.id')"
			fi
		fi
	done

	if [[ $ACKNOWLEDGE_PROMPTS == false && ! -z "$deletedHooks" ]]; then
		echo $deletedHooks >> $FILE_NAME
	fi
fi

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
	read -p "Create processConvertMetadataHook in $inpClientName SpaceId $inpConfigSpaceId (continue): continue"
fi

POSTPAYLOAD='{
	"hook" : {
		"name" : "'"${hookName}"'",
		"hook_type" : "cron",
		"hook_object" : "cronObject",
		"action" : {
			"type" : "workflow",
			"config" : {
				"process_key" : "processConvertMetadata",
				"search_criteria" : "'"${searchCriteria}"'",
				"search_window" : "'"${searchWindow}"'",
				"spaceId" : "'"${inpConfigSpaceId}"'",
				"maxDocumentsOccurs" : '"${maxDocumentsOccurs}"',
				"clientName" : "'"${inpClientName}"'"
			}
		}
	},
	"hookRecordType" : "hook",
	"method" : "cron",
	"spaceId" : '"${inpConfigSpaceId}"',
	"target" : "hooks",
	"executionOrder" : 0,
	"locked" : false,
	"name" : "'"${hookName}"'",
	"status" : "AVAILABLE"
}'

POST_RESULT=`curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD}"`
echo
echo $POST_RESULT

echo
jq . <<< $POST_RESULT

exit 0

