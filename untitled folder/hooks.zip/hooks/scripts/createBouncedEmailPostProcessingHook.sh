#!/bin/bash

function prop {
    grep "^\\s*${1}=" elgsHook.properties|cut -d'=' -f2-
}

hookName=BouncedEmails

if [[ -z "$*" ]]; then
	echo
  read -p "Enter environment (local or dev or qa or stage or prod): " ENVIRO
	echo
	read -p "Enter client (CheckWritePRA or PaymentEngPRA or COSMOSDoc1 or CSP-PRA or UHCWest or 1Click or CCSManual or NextGen or UNET or ODAR or COSMOS or MR_Appeals or ETS_Appeals or USP-PRA or USP-claims or CSP-Claims or OCM or CAP or TXGC or HouseCalls or NGS-Claims or PECOSMOSPRA or MCRLetters): " inpClientName
	ACKNOWLEDGE_PROMPTS=true
else
	ACKNOWLEDGE_PROMPTS=$1
	if [[ $ACKNOWLEDGE_PROMPTS == false ]]; then
		COMP="yes"
		CHOICE="no"
	fi
	FILE_NAME=$2
	ENVIRO=$3
	inpClientName=$4
	if [[ "$#" -eq 5 ]]; then
		TEMPLATENAME=$5
	fi
	shift "$#"
fi

if [[ ( $ENVIRO == local || $ENVIRO == dev || $ENVIRO == qa || $ENVIRO == stage || $ENVIRO == prod) && ( $inpClientName == UNET || $inpClientName == COSMOS || $inpClientName == NextGen || $inpClientName == 1Click || $inpClientName == CCSManual || $inpClientName == PaymentEngPRA || $inpClientName == COSMOSDoc1 || $inpClientName == CheckWritePRA || $inpClientName == CSP-PRA || $inpClientName == UHCWest|| $inpClientName == ODAR || $inpClientName == MR_Appeals  || $inpClientName == ETS_Appeals || $inpClientName == USP-PRA || $inpClientName == USP-claims || $inpClientName == CSP-Claims || $inpClientName == OCM || $inpClientName == CAP || $inpClientName == TXGC || $inpClientName == HouseCalls || $inpClientName = NGS_Claims || $inpClientName == PECOSMOSPRA || $inpClientName == MCRLetters) ]]; then
	HOST_URL=$(prop ${ENVIRO}.HOST_URL)
	inpSpaceId=$(prop ${ENVIRO}.${hookName}.spaceId)
	inpConfigSpaceId=$(prop ${ENVIRO}.${inpClientName}.spaceId)
	originalPrintTrail=$(prop ${ENVIRO}.${inpClientName}.originalPrintTrail)
	sftp_hostname=$(prop ${ENVIRO}.${inpClientName}.Shutterfly.ftp_url)
	sftp_username=$(prop ${ENVIRO}.${inpClientName}.Shutterfly.ftp_username)
	sftp_pw=$(prop ${ENVIRO}.${inpClientName}.Shutterfly.ftp_password)
	sftp_username_arc=$(prop ${ENVIRO}.${inpClientName}.Shutterfly.ftp_username_arc)
	sftp_pw_arc=$(prop ${ENVIRO}.${inpClientName}.Shutterfly.ftp_password_arc)
	sftp_dir=$(prop ${ENVIRO}.${inpClientName}.Shutterfly.ftp_path)
	sftp_archive_dir=$(prop ${ENVIRO}.${inpClientName}.Shutterfly.ftp_archive_path)
	fdsCloudAuthUrl=$(prop ${ENVIRO}.fdsCloudAuthUrl)
	cloud_client_id=$(prop ${ENVIRO}.cloud_client_id)
	cloud_client_secret=$(prop ${ENVIRO}.cloud_client_secret)
	fdsCloudGetAttachmentUrl=$(prop ${ENVIRO}.fdsCloudGetAttachmentUrl)
	skipManipulatePdfFile=$(prop ${ENVIRO}.${inpClientName}.Shutterfly.skipManipulatePdfFile)
	criteria=$(prop ${inpClientName}.bouncedProviderEmailAddressProcess.criteria)
	createOriginalCompanionFile=$(prop ${inpClientName}.createOriginalCompanionFile)
	bounceEmailCheckEFTIND=$([[ ( -z "$(prop ${ENVIRO}.${inpClientName}.bounceEmailCheckEFTIND)" ) && ( $(prop ${ENVIRO}.${inpClientName}.bounceEmailCheckEFTIND) == true) ]] && echo "true" || echo "false")
	writeEncryptedPDF=$([[ ( -z "$(prop ${ENVIRO}.${inpClientName}.writeEncryptedPDF)" ) && ( $(prop ${ENVIRO}.${inpClientName}.writeEncryptedPDF) == true) ]] && echo "true" || echo "false")
    bounceEmailAppIdentifer=$(prop ${ENVIRO}.BouncedEmails.appIdentifier)



else
	echo "Try again"
	exit 0
fi

if [[ ($inpClientName == CheckWritePRA) ]]; then
	if [[ -z "$TEMPLATENAME" ]]; then
		TEMPLATENAME="checkWritePRACompanion"
	fi
    if [[ -z "$TEMPLATENAME" ]]; then
	 echo "Try again"
	 exit 0
    fi
fi


GET_RESULT=`curl -verbose -X GET -k "$HOST_URL/api/services/v1/hooks?name=BouncedEmailPostProcessingHook&spaceId=$inpSpaceId"`
echo "GET_RESULT:  " $GET_RESULT
jq . <<< $GET_RESULT


echo; echo; echo; echo;
echo "RESULT_BY_SPACEID: "
RESULT_BY_SPACEID=$( jq -r --arg inpConfigSpaceId "$inpConfigSpaceId" '.response[]| select(.hook.action.config.spaceId==$inpConfigSpaceId)' <<< "$GET_RESULT" )
jq . <<< $RESULT_BY_SPACEID

echo 'List of available hook IDs that match ' $inpConfigSpaceId
jq -r '.id' <<< "$RESULT_BY_SPACEID"

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Starting delete hook process one by one, press enter to continue"
fi
for row in $( jq -r @base64 <<<  $RESULT_BY_SPACEID ); do

    _jq() {
     echo ${row} | base64 --decode | jq -r ${1}
    }

	echo
	if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
		read -p "Would you like to delete $(_jq '.id') yes or no:" COMP
	fi
	if [[ $COMP == yes ]]; then
    DELETE_RESULT=`curl -k -verbose -X DELETE -k "$HOST_URL/api/services/v1/hooks/delete/$(_jq '.id')"`
		jq . <<< $DELETE_RESULT
		if [[ -z "$deletedHooks" ]]; then
			deletedHooks="${0##*/}: $(_jq '.id')"
		else
			deletedHooks="$deletedHooks, $(_jq '.id')"
		fi
	fi

done

if [[ $ACKNOWLEDGE_PROMPTS == false && ! -z "$deletedHooks" ]]; then
	echo $deletedHooks >> $FILE_NAME
fi

echo
echo "Host URL: $HOST_URL"
echo "inpSpaceId: $inpSpaceId"
echo "inpConfigSpaceId: $inpConfigSpaceId"
echo "inpConfigClientSecred: $inpConfigClientSecret"
echo "sftp_hostname: $sftp_hostname"
echo "sftp_username: $sftp_username"
echo "sftp_pw: $sftp_pw"
echo "sftp_username_arc: $sftp_username_arc"
echo "sftp_pw_arc: $sftp_pw_arc"
echo "sftp_dir: $sftp_dir"
echo "sftp_archive_dir: $sftp_archive_dir"
echo "fdsCloudAuthUrl: $fdsCloudAuthUrl"
echo "cloud_client_id: $cloud_client_id"
echo "cloud_client_secret: $cloud_client_secret"
echo "fdsCloudGetAttachmentUrl: $fdsCloudGetAttachmentUrl"
echo "skipManipulatePdfFile: $skipManipulatePdfFile"
echo "criteria:$criteria"
echo "createOriginalCompanionFile: $createOriginalCompanionFile"
echo "bounceEmailCheckEFTIND: $bounceEmailCheckEFTIND"
echo "writeEncryptedPDF: $writeEncryptedPDF"
echo "template_name: $TEMPLATENAME"

if [[ ($inpClientName == CheckWritePRA) ]]; then
       POSTPAYLOAD='{
          "hook" : {
            "executionOrder": "100",
            "name": "BouncedEmailPostProcessingHook",
            "eval_time": "POST_PROCESS",
            "hook_type": "now",
            "hook_object": "objectOne",
            "action": {
              "type": "workflow",
              "config": {
                "process_key": "bouncedProviderEmailAddressProcess",
                "sftp_username" : "'"${sftp_username}"'",
                "sftp_pw" : "'"${sftp_pw}"'",
                "sftp_username_arc" : "'"${sftp_username_arc}"'",
                "sftp_pw_arc" : "'"${sftp_pw_arc}"'",
                "sftp_dir" : "'"${sftp_dir}"'",
                "sftp_hostname" : "'"${sftp_hostname}"'",
                "sftp_archive_dir" : "'"${sftp_archive_dir}"'",
                "startDateInDays" : -8,
                "maxDocumentsOccurs" : 500,
                "spaceId" : "'"${inpConfigSpaceId}"'",
                "grant_type" : "authorization_code",
                "fdsCloudAuthUrl" : "'"${fdsCloudAuthUrl}"'",
                "cloud_client_id" : "'"${cloud_client_id}"'",
                "cloud_client_secret" : "'"${cloud_client_secret}"'",
                "cloud_grant_type" : "client_credentials",
                "fdsCloudGetAttachmentUrl" : "'"${fdsCloudGetAttachmentUrl}"'",
                "addressBlockX" : 1.0,
                "addressBlockY" : 1.84,
                "identifierFontSize" : 8.0,
                "originalPrintTrail" : "'"${originalPrintTrail}"'",
                "receiverIdentifier" : "'"DPS\$\$\$PKG"'",
                "skipManipulatePdfFile" : "'"${skipManipulatePdfFile}"'",
                "createOriginalCompanionFile" : '${createOriginalCompanionFile}',
                "bounceEmailCheckEFTIND" : "'"${bounceEmailCheckEFTIND}"'",
                "document_format_field" : "dateEmailSent",
                "template_name" : "'"${TEMPLATENAME}"'",
                "writeEncryptedPDF" : "'"${writeEncryptedPDF}"'"
            }
          }
        },
    "hookRecordType" : "hook",
    "method" : "post",
    "spaceId" : '${inpSpaceId}',
    "target" : "documents",
    "executionOrder" : 100,
    "locked" : false,
    "appIdentifier" : "'"${bounceEmailAppIdentifer}"'",
    "name" : "BouncedEmailPostProcessingHook",
    "status" : "AVAILABLE"
}'
else
       POSTPAYLOAD='{
        "hook" : {
          "executionOrder": "100",
          "name": "BouncedEmailPostProcessingHook",
          "eval_time": "POST_PROCESS",
          "hook_type": "now",
          "hook_object": "objectOne",
          "action": {
            "type": "workflow",
            "config": {
              "process_key" : "bouncedProviderEmailAddressProcess",
              "sftp_username" : "'"${sftp_username}"'",
              "sftp_pw" : "'"${sftp_pw}"'",
              "sftp_username_arc" : "'"${sftp_username_arc}"'",
              "sftp_pw_arc" : "'"${sftp_pw_arc}"'",
              "sftp_dir" : "'"${sftp_dir}"'",
              "sftp_hostname" : "'"${sftp_hostname}"'",
              "sftp_archive_dir" : "'"${sftp_archive_dir}"'",
              "startDateInDays" : -8,
              "maxDocumentsOccurs" : 500,
              "spaceId" : "'"${inpConfigSpaceId}"'",
              "grant_type" : "authorization_code",
              "fdsCloudAuthUrl" : "'"${fdsCloudAuthUrl}"'",
              "cloud_client_id" : "'"${cloud_client_id}"'",
              "cloud_client_secret" : "'"${cloud_client_secret}"'",
              "cloud_grant_type" : "client_credentials",
              "fdsCloudGetAttachmentUrl" : "'"${fdsCloudGetAttachmentUrl}"'",
              "addressBlockX" : 1.0,
              "addressBlockY" : 1.84,
              "identifierFontSize" : 8.0,
              "originalPrintTrail" : "'"${originalPrintTrail}"'",
              "receiverIdentifier" : "'"DPS\$\$\$PKG"'",
              "skipManipulatePdfFile" : "'"${skipManipulatePdfFile}"'",
              "createOriginalCompanionFile" : '${createOriginalCompanionFile}',
              "bounceEmailCheckEFTIND" : "'"${bounceEmailCheckEFTIND}"'",
              "document_format_field" : "dateEmailSent",
              "writeEncryptedPDF" : "'"${writeEncryptedPDF}"'"
            }
          }
        },
    "hookRecordType" : "hook",
    "method" : "post",
    "spaceId" : '${inpSpaceId}',
    "target" : "documents",
    "executionOrder" : 100,
    "locked" : false,
    "appIdentifier" : "'"${bounceEmailAppIdentifer}"'",
    "name" : "BouncedEmailPostProcessingHook",
    "status" : "AVAILABLE"
}'
fi


echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Create Bounced Email Post Processing Hook (continue): continue"
fi


POST_RESULT=`curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD}"`
echo
jq . <<< $POST_RESULT
echo "POST Result: " $POST_RESULT


echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Do you want to test print services workflow (yes or no): " CHOICE
fi

if [[ $CHOICE == yes ]]; then

POST_RESULT=`curl -k -verbose -F "documents={'space_id':$inpSpaceId,  'metadata' : { 'providerEmailId': 'test@bouncedemailtest.com', 'original_email_from': 'none@none.com', 'original_email_datetime': '2018-04-17T12:42:36.247+05:30'}}" "$HOST_URL/api/services/v1/hooks" --header "Content-Type:multipart/form-data"`
echo
jq . <<< $POST_RESULT
echo "POST Result: " $POST_RESULT
inpdocId=`echo $POST_RESULT |  getDocId`
echo "Document Id: " $inpdocId

else

exit 0

fi