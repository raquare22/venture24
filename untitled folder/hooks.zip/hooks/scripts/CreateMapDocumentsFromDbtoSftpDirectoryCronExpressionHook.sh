#!/bin/bash

function prop {
    grep "^\\s*${1}=" elgsHook.Properties|cut -d'=' -f2
}

proccessName=CreateResponseFileProccess

if [[ -z "$*" ]]; then
	echo
	read -p "Enter environment (local or dev or qa or stage or prod): " inpEnvironment
	echo
	read -p "Enter client (NextGen or 1Click or CCSManual or CheckWritePRA or UNET or ODAR): " inpClientName
	echo
	read -p "Enter MongoDB Response Template Name (PriorAuthResponse or checkWritePRAResponse or ODARResponse):" inpResponseTemplateName
	ACKNOWLEDGE_PROMPTS=true
else
	ACKNOWLEDGE_PROMPTS=$1
	if [[ $ACKNOWLEDGE_PROMPTS == false ]]; then
		COMP="yes"
	fi
	FILE_NAME=$2
	inpEnvironment=$3
	inpClientName=$4
	inpResponseTemplateName=$5
	shift "$#"
fi

if [[ ( $inpEnvironment == local || $inpEnvironment == dev || $inpEnvironment == qa || $inpEnvironment == stage  || $inpEnvironment == prod ) && ( $inpClientName == NextGen || $inpClientName == 1Click || $inpClientName == CCSManual || $inpClientName == CheckWritePRA || $inpClientName == UNET || $inpClientName == ODAR ) && ( -n "$inpResponseTemplateName" ) ]]; then
	spaceId=$(prop ${inpEnvironment}.${inpClientName}.spaceId)
	ftpRespdir=$(prop ${inpEnvironment}.${inpClientName}.ftpRespdir)
	ftpArchivedir=$(prop ${inpEnvironment}.${inpClientName}.ftpArchivedir)
	HOST_URL=$(prop ${inpEnvironment}.HOST_URL)
	SFTP_HOST=$(prop ${inpEnvironment}.SFTP_HOST)
	SFTP_USER=$(prop ${inpEnvironment}.SFTP_USER)
	SFTP_PASSWORD=$(prop ${inpEnvironment}.SFTP_PASSWORD)
	searchCriteria=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.searchCriteria)
	searchWindow=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.searchWindow)
	cronExpression=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.cronExpression)
	sftpFilename=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.sftpFilename)
	fileFormat=$(prop ${inpEnvironment}.${inpClientName}.${proccessName}.fileFormat)
	emailReceiver=$(prop ${inpEnvironment}.emailReceiver)
else
	echo
	echo "Try again"
	exit 0
fi


if [[ $inpClientName == CheckWritePRA ]]; then
	document_update_flag_path=addedToCosmosPraResponseFile
else
	 document_update_flag_path=addedToResponseFile
fi

if [[ $inpClientName == UNET ]]; then
    IFS=';' read -r -a arr_searchCriteria <<< "$searchCriteria"
    IFS=';' read -r -a arr_sftpFilename <<< "$sftpFilename"
    echo
    if [[ $inpEnvironment == qa ]]; then
		read -p "Enter Original Print Trail (3591 or 3599): " originalPrintTrail
		if [[ $originalPrintTrail -eq 3591 ]]; then
       		searchCriteria="${arr_searchCriteria[0]}"
       		sftpFilename="${arr_sftpFilename[0]}"
    	elif [[ $originalPrintTrail -eq 3599 ]]; then
       		searchCriteria="${arr_searchCriteria[1]}"
       		sftpFilename="${arr_sftpFilename[1]}"
    	else
       		echo
	   		echo "Try again"
	   		exit 0
    	fi
    elif [[ $inpEnvironment == prod ]]; then
    	read -p "Enter Original Print Trail (3610 or 3618): " originalPrintTrail
		if [[ $originalPrintTrail -eq 3610 ]]; then
       		searchCriteria="${arr_searchCriteria[0]}"
       		sftpFilename="${arr_sftpFilename[0]}"
    	elif [[ $originalPrintTrail -eq 3618 ]]; then
       		searchCriteria="${arr_searchCriteria[1]}"
       		sftpFilename="${arr_sftpFilename[1]}"
    	else
       		echo
	   		echo "Try again"
	   		exit 0
    	fi
    else
    	read -p "Enter Original Print Trail (3730 or 3738): " originalPrintTrail
		if [[ $originalPrintTrail -eq 3730 ]]; then
       		searchCriteria="${arr_searchCriteria[0]}"
       		sftpFilename="${arr_sftpFilename[0]}"
    	elif [[ $originalPrintTrail -eq 3738 ]]; then
       		searchCriteria="${arr_searchCriteria[1]}"
       		sftpFilename="${arr_sftpFilename[1]}"
    	else
       		echo
	   		echo "Try again"
	   		exit 0
    	fi
    fi
fi


echo
echo "inpEnvironment: $inpEnvironment"
echo "spaceId: $spaceId"
echo "inpResponseTemplateName: $inpResponseTemplateName"
echo "ftpRespdir: $ftpRespdir"
echo "ftpArchivedir: $ftpArchivedir"
echo "Host URL: $HOST_URL"
echo "SFTP Host: $SFTP_HOST"
echo "SFTP User: $SFTP_USER"
echo "SFTP Password: $SFTP_PASSWORD"
echo "searchCriteria: $searchCriteria"
echo "searchWindow: $searchWindow"
echo "cronExpression: $cronExpression"
echo "sftpFilename: $sftpFilename"
echo "file_format: $fileFormat"
echo "emailReceiver: $emailReceiver"

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Create PriorAuth Response File CronExpression Hook (continue): continue"
fi

echo
echo "Creating Hook in spaceId: " $spaceId

hookName='CreateMapDocumentsFromDbtoSftpDirectory'$inpClientName'CronExpressionHook'

POSTPAYLOAD='{
        "hook" : {
          "name" : "'"${hookName}"'",
          "hook_type" : "cron",
          "hook_object" : "cronObject",
          "action" : {
            "type" : "workflow",
            "config" : {
              "process_key" : "mapDocumentsFromDbToSftpDirectoryProcess",
              "search_criteria" : "'"${searchCriteria}"'",
              "search_window" : '${searchWindow}',
              "template_name" : "'"${inpResponseTemplateName}"'",
              "sftp_hostname" : "'"${SFTP_HOST}"'",
              "sftp_username" : "'"${SFTP_USER}"'",
              "sftp_pw" : "'"${SFTP_PASSWORD}"'",
              "sftp_dir" : "'"${ftpRespdir}"'",
              "sftp_archive_dir" : "'"${ftpArchivedir}"'",
              "grant_type" : "authorization_code",
              "fdsAuthUrl" : "'"${HOST_URL/v2/oauth2/token.json}"'",
              "document_update_flag_path" : "'"${document_update_flag_path}"'",
              "document_update_flag_value": true,
              "document_format_field" : "dateEmailSent",
              "fdsDocumentsUrl" : "'"${HOST_URL/v2/documents}"'",
              "emailReceiver" : "'"${emailReceiver}"'",
              "environment" : "'"${inpEnvironment}"'",
              "sftp_Filename" : "'"${sftpFilename}"'",
              "file_format" : "'"${fileFormat}"'"
            }
          }
        },
    "hookRecordType" : "hook",
    "method" : "cron",
    "spaceId" : '${spaceId}',
    "target" : "hooks",
    "executionOrder" : 0,
    "locked" : false,
    "clientId" : 685,
    "name" : "'"${hookName}"'",
    "status" : "AVAILABLE"
}'


GET_RESULT=`curl -verbose -X GET -k "$HOST_URL/api/services/v1/hooks?name=$hookName&spaceId=$spaceId"`
echo "GET_RESULT:  " $GET_RESULT
jq . <<< $GET_RESULT
 echo 'List of available hook IDs'
echo "$GET_RESULT" | jq -r '.response[]|"\(.id)"'
echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Starting delete hook process one by one, press enter to continue"
fi
 for row in $(echo "$GET_RESULT" | jq -r '.response[] | @base64'); do
    _jq() {
     echo ${row} | base64 --decode | jq -r ${1}
    }
echo ${row} | base64 --decode | jq -r ${1}

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Would you like to delete $(_jq '.id') yes or no:" COMP
fi
if [[ $COMP == yes ]]; then
	DELETE_RESULT=`curl -k -verbose -X DELETE -k "$HOST_URL/api/services/v1/hooks/delete/$(_jq '.id')"`
	jq . <<< $DELETE_RESULT
	if [[ -z "$deletedHooks" ]]; then
		deletedHooks="${0##*/}: $(_jq '.id')"
	else
		deletedHooks="$deletedHooks, $(_jq '.id')"
	fi
fi
done

if [[ $ACKNOWLEDGE_PROMPTS == false && ! -z "$deletedHooks" ]]; then
	echo $deletedHooks >> $FILE_NAME
fi

echo
if [[ $ACKNOWLEDGE_PROMPTS == true ]]; then
read -p "Post PriorAuth Response File Cron Expression Hook, press enter to continue"
fi

POST_RESULT=`curl -v -k -X POST "$HOST_URL/api/services/v1/hooks" -H "Content-Type: application/json" -d "${POSTPAYLOAD}"`
echo
echo $POST_RESULT

echo
jq . <<< $POST_RESULT