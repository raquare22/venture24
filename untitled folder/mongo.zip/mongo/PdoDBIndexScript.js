db.paymentPreference.createIndex( { "id": 1} )
db.paymentPreference.createIndex( { "metadata.tin": 1} )
db.paymentPreference.createIndex( { "metadata.mpin": 1} )
db.paymentPreference.createIndex( { "metadata.paymentPref": 1} )
db.paymentPreference.createIndex( { "metadata.accountNumber": 1} )
db.paymentPreference.createIndex( { "metadata.updatedBy": 1} )

db.deliveryPreference.createIndex( { "id": 1} )
db.deliveryPreference.createIndex( { "metadata.tin": 1} )
db.deliveryPreference.createIndex( { "metadata.mpin": 1} )
db.deliveryPreference.createIndex( { "metadata.deliveryPref": 1} )
db.deliveryPreference.createIndex( { "metadata.providerEmailId": 1} )

db.deliveryPreference.createIndex({
  "metadata.tin": 1,
  "metadata.mpin": 1,
  "metadata.classifier": 1,
  "metadata.deliveryPreference": 1
});