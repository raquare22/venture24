db.getCollection('processorTransaction').getIndexes();


db.getCollection('document').createIndex(
{dateCreated:1 },
{name: "ttl_expireAfter_6mo",
  expireAfterSeconds: 15552000,
  partialFilterExpression:  {"spaceId": {"$in":[11703, 11903, 20303] } }
  }
);



db.getCollection('document').createIndex(
{dateModified:1 },
{name: "ttl_expireAfter_2yr",
  expireAfterSeconds: 63072000,
  partialFilterExpression:  {"spaceId": {"$in":[8936, 8937, 8938, 8889, 8935, 10074,10075, 10103, 10303,10403, 10503, 10603, 10803, 11103, 11203, 11503, 11803, 20103, 20803, 7003, 7103, 7403] } }
  }
);



db.getCollection('appError').createIndex(
{dateCreated:1 },
{name: "ttl_expireAfter_1mo",
  expireAfterSeconds: 2592000
  }
);



db.getCollection('hookTransaction').createIndex(
{dateCreated:1 },
{name: "ttl_expireAfter_1mo",
  expireAfterSeconds: 2592000
  }
);



db.getCollection('csvProcessorRowTask').createIndex(
{dateCreated:1 },
{name: "ttl_expireAfter_2yr",
  expireAfterSeconds: 63072000
  }
);



db.getCollection('transaction').createIndex(
{dateCreated:1 },
{name: "ttl_expireAfter_1mo",
  expireAfterSeconds: 2592000
  }
);



db.getCollection('csvProcessorTransaction').createIndex(
{dateCreated:1 },
{name: "ttl_expireAfter_2yr",
  expireAfterSeconds: 63072000
  }
);



db.getCollection('processorTransaction').createIndex(
{dateModified:1 },
{name: "ttl_expireAfter_2yr",
  expireAfterSeconds: 63072000
  }
);



db.getCollection('processorFileTask').createIndex(
{dateModified:1 },
{name: "ttl_expireAfter_2yr",
  expireAfterSeconds: 63072000
  }
);