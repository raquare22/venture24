var db = connect('127.0.0.1:27017/paperlessDeliveryOptionsStore'),
    vr = null;

print('* Database created');

db.createCollection("paymentPreference", function(err, res) {
  if (err) throw err;
  print('* paymentPreference Collection created!');
});

db.createCollection("deliveryPreference", function(err, res) {
  if (err) throw err;
  print('* deliveryPreference Collection created!');
});

//create user
db.createUser(
    {
      user: "admin02",
      pwd: "admin02",
      roles: [
         { role: "readWrite", db: "paperlessDeliveryOptionsStore" }
      ]
    }
  )


db.document.createIndex( { "id": 1} )
