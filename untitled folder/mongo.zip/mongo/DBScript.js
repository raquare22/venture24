//create the PaperLess Rules Engine database and connect to it
var db = connect('127.0.0.1:27017/rulesEngineStore'),
    vr = null;

print('* Database created');

//create the all collection
db.createCollection("document", function(err, res) {
  if (err) throw err;
  print('* Document Collection created!');
});

db.createCollection("CSVdocument", function(err, res) {
    if (err) throw err;
    print('* CSVdocument Collection created!');
  });

db.createCollection("PDOdocument", function(err, res) {
    if (err) throw err;
    print('* PDOdocument Collection created!');
  });

db.createCollection("processor", function(err, res) {
    if (err) throw err;
    print('* processor Collection created!');
  }); 
  
db.createCollection("processorFileTask", function(err, res) {
    if (err) throw err;
    print('* processorFileTask Collection created!');
  });
  
db.createCollection("processorTransaction", function(err, res) {
    if (err) throw err;
    print('* processorTransaction Collection created!');
  });

db.createCollection("csvProcessor", function(err, res) {
    if (err) throw err;
    print('* csvProcessor Collection created!');
  });

db.createCollection("csvProcessorRowTask", function(err, res) {
    if (err) throw err;
    print('* csvProcessorRowTask Collection created!');
  });

db.createCollection("csvProcessorTransaction", function(err, res) {
    if (err) throw err;
    print('* csvProcessorTransaction Collection created!');
  });

db.createCollection("hook", function(err, res) {
    if (err) throw err;
    print('* hook Collection created!');
  }); 

db.createCollection("hookTransaction", function(err, res) {
    if (err) throw err;
    print('* hookTransaction Collection created!');
  }); 
  
db.createCollection("attachment", function(err, res) {
    if (err) throw err;
    print('* attachment Collection created!');
  });

db.createCollection("appError", function(err, res) {
  if (err) throw err;
  print('* appError Collection created!');
});

//create user
db.createUser(
    {
      user: "admin01",
      pwd: "admin01",
      roles: [
         { role: "readWrite", db: "rulesEngineStore" }
      ]
    }
  ) 
 
//create Index  
db.document.createIndex( { "spaceId": 1} ) 

db.CSVdocument.createIndex( { "spaceId": 1} )

db.PDOdocument.createIndex( { "spaceId": 1} )

db.processor.createIndex( { "configSpaceId": 1} )

db.processorFileTask.createIndex( { "configSpaceId": 1} )

db.processorTransaction.createIndex( { "configSpaceId": 1} )

db.csvProcessor.createIndex( { "configSpaceId": 1} )

db.csvProcessorRowTask.createIndex( { "configSpaceId": 1} )

db.csvProcessorTransaction.createIndex( { "configSpaceId": 1} )

db.hook.createIndex( { "spaceId": 1} )

db.hookTransaction.createIndex( { "spaceId": 1} )

db.attachment.createIndex( { "spaceId": 1} )
