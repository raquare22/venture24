db.getCollection('processorTransaction').getIndexes();


db.getCollection('document').createIndex(
{dateCreated:1 },
{name: "ttl_expireAfter_6mo",
  expireAfterSeconds: 15552000,
  partialFilterExpression:  {"spaceId": {"$in":[11702, 11902, 20302] } }
  }
);



db.getCollection('document').createIndex(
{dateModified:1 },
{name: "ttl_expireAfter_2yr",
  expireAfterSeconds: 63072000,
  partialFilterExpression:  {"spaceId": {"$in":[3006, 8888, 8896, 8897, 8928, 8934, 10053, 10056, 10057, 10059, 10067, 10070, 10102, 10207, 10302, 10402, 10502, 10602, 10702, 10802, 10902, 11102, 11202, 11302, 11303, 11400, 11401, 11402, 11404, 11405, 11502, 11602, 11800, 11802, 20102, 20802, 7002, 7102, 7402] } }
  }
);



db.getCollection('appError').createIndex(
{dateCreated:1 },
{name: "ttl_expireAfter_1mo",
  expireAfterSeconds: 2592000
  }
);



db.getCollection('hookTransaction').createIndex(
{dateCreated:1 },
{name: "ttl_expireAfter_1mo",
  expireAfterSeconds: 2592000
  }
);



db.getCollection('csvProcessorRowTask').createIndex(
{dateCreated:1 },
{name: "ttl_expireAfter_2yr",
  expireAfterSeconds: 63072000
  }
);



db.getCollection('transaction').createIndex(
{dateCreated:1 },
{name: "ttl_expireAfter_1mo",
  expireAfterSeconds: 2592000
  }
);



db.getCollection('csvProcessorTransaction').createIndex(
{dateCreated:1 },
{name: "ttl_expireAfter_2yr",
  expireAfterSeconds: 63072000
  }
);



db.getCollection('processorTransaction').createIndex(
{dateModified:1 },
{name: "ttl_expireAfter_2yr",
  expireAfterSeconds: 63072000
  }
);



db.getCollection('processorFileTask').createIndex(
{dateModified:1 },
{name: "ttl_expireAfter_2yr",
  expireAfterSeconds: 63072000
  }
);