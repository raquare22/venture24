db.csvProcessor.createIndex( {"processorId":1} )
db.csvProcessor.createIndex( {"configSpaceId":1} )
db.csvProcessor.createIndex( {"appIdentifier":1} )
db.csvProcessor.createIndex( {"dateCreated":1} )
db.csvProcessor.createIndex( {"dateModified":1} )
db.csvProcessor.createIndex( {"status":1} )
db.csvProcessor.createIndex( {"fileName":1} )
db.csvProcessor.createIndex( {"_id":1} )

db.hookTransaction.createIndex( {"hookRecordType":1} )
db.hookTransaction.createIndex( {"targetId":1} )
db.hookTransaction.createIndex( {"hookExecutionList.hookId":1} )
db.hookTransaction.createIndex( {"spaceId":1} )
db.hookTransaction.createIndex( {"hook.hookExecutionList.status":1} )
db.hookTransaction.createIndex( {"hook.hookExecutionList.spaceId":1} )
db.hookTransaction.createIndex( {"hook.hookExecutionList.hookId":1} )
db.hookTransaction.createIndex( {"hook.hookExecutionList.dateCreated":1} )
db.hookTransaction.createIndex( {"hook.hookExecutionList.activitiProcessKey":1} )
db.hookTransaction.createIndex( {"_id":1} )

db.document.createIndex( {"dateCreated":1} )
db.document.createIndex( {"dateModified":1} )
db.document.createIndex( {"appIdentifier":1} )
db.document.createIndex( {"metadata.corporateMpin":1} )
db.document.createIndex( {"metadata.tin":1} )
db.document.createIndex( {"metadata.fileName":1} )
db.document.createIndex( {"metadata.createdDate":1} )
db.document.createIndex( {"documentAttachments.fileName":1} )
db.document.createIndex( {"metadata.providerEmailId":1} )
db.document.createIndex( {"appIdentifier":1,"status":1} )
db.document.createIndex( {"metadata.subCategory":1} )
db.document.createIndex( {"documentAttachments.attachmentId":1} )
db.document.createIndex( {"spaceId":1,"status":1} )
db.document.createIndex( { "metadata.BARCODE_FIFTEEN" : 1, "spaceId" : 1, "status" : 1 } )
db.document.createIndex( { "metadata.emailAlertReq":1} )
db.document.createIndex( {"_id":1} )

db.hook.createIndex( {"appIdentifier":1} )
db.hook.createIndex( {"status":1} )
db.hook.createIndex( {"spaceId":1} )
db.hook.createIndex( {"dateCreated":1} )
db.hook.createIndex( {"hook.name":1} )
db.hook.createIndex( {"hook.action.config.process_key":1} )
db.hook.createIndex( {"hook.action.type":1} )
db.hook.createIndex( {"_id":1} )

db.processor.createIndex( {"lastRun":1} )
db.processor.createIndex( {"transactionId":1} )
db.processor.createIndex( {"appIdentifier":1,"status":1} )
db.processor.createIndex( {"appIdentifier":1,"locked":1} )
db.processor.createIndex( {"configSpaceId":1} )
db.processor.createIndex( {"dateCreated":1} )
db.processor.createIndex( {"dateModified":1} )
db.processor.createIndex( {"_id":1} )

db.processorTransaction.createIndex( {"dateCreated":1} )
db.processorTransaction.createIndex( {"fileName":1} )
db.processorTransaction.createIndex( {"configSpaceId":1} )
db.processorTransaction.createIndex( {"processorId":1} )
db.processorTransaction.createIndex( {"clientId":1} )
db.processorTransaction.createIndex( {"appIdentifier":1} )
db.processorTransaction.createIndex( {"transactionId":1} )
db.processorTransaction.createIndex( {"appIdentifier":1,"status":1} )
db.processorTransaction.createIndex( {"_id":1} )

db.processorFileTask.createIndex( {"appIdentifier":1,"status":1} )
db.processorFileTask.createIndex( {"appIdentifier":1,"targetId":1, "targetType":1} )
db.processorFileTask.createIndex( {"configSpaceId":1} )
db.processorFileTask.createIndex( {"dateCreated":1} )
db.processorFileTask.createIndex( {"fileName":1} )
db.processorFileTask.createIndex( {"processorId":1} )
db.processorFileTask.createIndex( {"processorTransactionId":1} )
db.processorFileTask.createIndex( {"targetId":1} )
db.processorFileTask.createIndex( {"_id":1} )

db.PDOdocument.createIndex( {"_id":1} )
db.PDOdocument.createIndex( {"spaceId":1,"metadata.fileName":1,"metadata.mpin":1,"metadata.tin":1,"status":1,"dateModified":-1} )

db.CSVdocument.createIndex( {"_id":1} )

db.appError.createIndex( {"_id":1} )

db.csvProcessorRowTask.createIndex( {"_id":1} )

db.csvProcessorTransaction.createIndex( {"_id":1} )
db.csvProcessorTransaction.createIndex( {"fileName": 1} )
db.csvProcessorTransaction.createIndex( {"appIdentifier": 1} )
db.csvProcessorTransaction.createIndex( {"status": 1} )

// Added index based on mongoDB performance advisor May 24, 2022

db.document.createIndex({
    "spaceId": 1,
"metadata.EFT_Ind": 1,
"metadata.emailAlertReq": 1,
"status": 1,
"metadata.sendEmailNotifications": 1,
"metadata.sendPENAPIRequest": 1,
"metadata.sendToDocVault": 1,
"dateCreated": 1,
"metadata.docLibAPIResponse": 1,
"metadata.prepostEnded": 1
    });

db.document.createIndex({    
"spaceId": 1,
"metadata.docLibAPIResponse": 1,
"metadata.sendEmailNotifications": 1,
"metadata.sendPENAPIRequest": 1,
"dateCreated": 1
        });
        
db.document.createIndex({        
"spaceId": 1,
"status": 1,
"metadata.postCardInd": 1,
"metadata.sendToShutterfly": 1,
"dateCreated": 1,
"metadata.rprntSentToSF": 1
       });

db.document.createIndex({       
"spaceId": 1,
"status": 1,
"metadata.sendToDocVault": 1,
"dateCreated": 1,
"metadata.docLibAPIResponse": 1,
"metadata.prepostEnded": 1
    });
    
 db.document.createIndex({      
"spaceId": 1,
"status": 1,
"metadata.sendToShutterfly": 1,
"dateCreated": 1,
"metadata.rprntSentToSF": 1
       });
  
db.document.createIndex({       
"spaceId": 1,
"metadata.emailAlertReq": 1,
"metadata.originalPrintTrail": 1,
"status": 1,
"metadata.docLibAPIResponse": 1,
"metadata.sendEmailNotifications": 1,
"dateCreated": 1,
"metadata.addedToResponseFile": 1,
"metadata.prepostEnded": 1
    });
    
 db.document.createIndex({     
    "spaceId": 1,
"metadata.emailAlertReq": 1,
"metadata.originalPrintTrail": 1,
"status": 1,
"dateCreated": 1,
"metadata.addedToResponseFile": 1,
"metadata.corporateMpin": 1,
"metadata.prepostEnded": 1
      });
      
     db.document.createIndex({     
"spaceId": 1,
"metadata.emailAlertReq": 1,
"metadata.originalPrintTrail": 1,
"metadata.providerEmailId": 1,
"status": 1,
"metadata.docLibAPIResponse": 1,
"dateCreated": 1,
"metadata.addedToResponseFile": 1,
"metadata.prepostEnded": 1
         });

db.document.createIndex({
 "spaceId": 1,
 "status": 1,
"metadata.messageId": 1
})