# fds_paperless
This repository is used to store resource files, properties and images for all applications involved in fds paperless

#Run the command to create mongoDB database:
$ mongo DBScript.js
