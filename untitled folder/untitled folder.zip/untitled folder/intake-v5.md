## Section 1: Product Summary

| Product Name                 | Ask ID          | Technical Lead            | PMO Lead       |Cloud Platform  | Business Unit    |
| -----------------------------| --------------- | --------------------------| -------------- | -------------- | ---------------- |
| Paperless Letters Project    | UHGWM110-023810 | Saravanan Nedunchezhiyan  | Sinha, Rashmi  |    GCP       |     44770        |



## New to Markdown??- here are some guides:  
  * https://guides.github.com/pdfs/markdown-cheatsheet-online.pdf
  * https://www.markdowntutorial.com/

#

| Table of Contents |
| ----------------- |
| [Section 1: General](#section-1-general) |
| [Section 2: Data Governance](#section-2-data-governance) |
| [Section 3: Code Delivery and Management](#section-3-code-delivery-and-management) |
| [Section 4: Architecture Summary](#section-4-architecture-summary) |
| [Section 5: Network Summary](#section-5-network-summary) |
| [Section 6: Security Criteria](#section-6-security-criteria) |

## Section 1: General

### General Intake Requirements
#### When submitting a request for a Public Cloud account:

- [ ] the completed copy of this document **must** be placed in a github project repo, not a personal repo  
- [ ] the document content **must** be submitted in Markdown (.md) format for easy consumption and updates  
- [ ] Use the latest version of this document even if your prior requests used an older version  
  -  The latest version can be found here: https://github.optum.com/healthcarecloud/intake/
- [ ] Read and complete ALL sections  
  - Do not remove any sections of the document
- [ ] Obtain prior approval from your business segment chief architect for the effort  
- [ ] Consider leveraging these Microsoft assessments to help you on your cloud journey  
  -  Microsoft Assessments - https://docs.microsoft.com/en-us/assessments/    


> **Guidance**:  Use this section to describe your application, its use case(s), and why you want to house it in the public cloud as opposed to any other platform.  

## Description:
FDS (Federated Data Storage) Provider Paperless Letters helps facilitating electronic delivery of provider letters. 
Benefits of this project involves:

* Reduce delivery of paper correspondence to providers by making letters and documents available electronically.
* Reduce delivery time for documents
* Make documents available to providers in a central location
* Save United up to $24.5M annually


## Use cases:
* Store received metadata and electronic letters
* Validate metadata and send to Document Vault
* Send acknowledgement file back to client (and other files if required)
* Send e-delivery letters to Shutterfly for printing if we are not able to successfully post them to Document Vault or DocuLibrary

## GCP Public Cloud:
As we are planning to enhance our projects getting public cloud would help us following ways:

* Flexibility, Reliability and Competitive cost.
* Hybrid Capability and Scalability on demand 
* Automation, API Management, run VMs, Simple and Reliable Data Storage. 


##
Business Segment Chief Architect Awareness

> **Guidance**: Use this section to provide the name of the Chief Architect (or listed delegate), and statement that they are aware and support this public cloud effort.  
> * List of business segment architects: https://architecture.uhg.com/docs/architecture-leader-community.html
--------------------

[Share the Chief Architect awareness information here]  

Singh, Lalitha <lalitha_singh@optum.com>
--------------------
Kakula, Venkateswara <venkat_kakula@optum.com>
--------------------

![arch_apprv_letter](https://github.optum.com/FDSPaperless/fds_paperless/blob/master/images/arch_approval.png)

## Ticket approval: RITM1358934


## User Details

> **Guidance**: Use this section to describe your application's users. Some things to think about (non-exhaustive):  

- **Who are your users?** 
- **Are they internal Health Care Provider (UHG Employees), external, or a mix of both?**
- **What is the expected activity (total population, Daily active Users, new users per month)?**

_**There are no application users for this application. The application has no user interfaces to expose the data. The data from the application will be posted to DocVault and FDS**_

There are no providers accessing this application directly. The providers will be accessing the electronic documents through DocVault or DocuLibrary. 

--------------------

### Workload Placement use case

> **Guidance**: Please describe how your use case meets one (or more) of the below criteria.  Addressing more than one use case is advantageous.   Additional placement guidance can be found [HERE](https://cloud.optum.com/docs/getting-started/workload-placement)
> - **Commercial Initiative:** This solution exclusively supports an external commercial customer.
> - **Volatile or Elastic Capacity:** This solution leverages a 10x or great elastic demand, capacity is increased and decreased by 10x within a 24 hour period.
> - **Data\User Gravity:** This solution does not have heavy data transfer or internal user demands between it UHG's systems.
> - **Critical Emerging Technology:** This solution requires an emerging public cloud technology (Azure IOT, AWS SageMaker, GCP, etc)
> - **Isolated Workload:** A solution that does not integrate with other UHG applications or systems.

--------------------

_**Use Case**_

--------------------
> - Our current application setup can handle normal loads but when we receive extremely large files our current system resource gets drained and result in high memory usage. Hence we need on demand elasticity to scale up the capacity to handle such high loads and scale down once process is completed.

> - DocuLibrary(DocVault), our primary consumer is already in azure, Hence migrating our app will benefits us in cost and ease of operation to call azure functions directly. 


--------------------

### Existing workload displacement & cost recovery
> **Guidance**: Please provide any additional details here about how this Cloud effort will realize a net cost savings  
>  
>Describe in the space below:
>* Are you decommissioning on-prem systems/services
>* Any transition of resource consumption
>* Perceived amount of cost savings over time  
>* Provide a list of services and the supporting math that can demonstrate the cost savings
>* Useful Links:  
>   * https://azure.microsoft.com/en-us/pricing/calculator/
>   * https://calculator.aws/
>   * https://cloud.google.com/products/calculator  
>   * https://cloud.optum.com/docs/operational-guides/chargeback/

--------------------

[Use this space to describe the cost benefit that will be realized by moving to public cloud]

_**DocuLibrary, our primary consumer is already in azure, Hence migrating our app will benefits us in cost and ease of operation to call azure functions directly.**_

--------------------

### External API documentation
> **Guidance**: Provide external API documentation links to your Open API Spec documentation.  
> **Reference**: https://api-docs.optum.com/
--------------------

[Place API document links here, as applicable]

_**Not Applicable for FDS Provider Paperless Project**_


--------------------

### Product Summary Circumstances and Exceptions

> **Guidance**: Special circumstances or exceptions to the criteria
> 1. *example* The initial design for this solution does not integrate with other UHG teams but we are exploring the possibility of using OptumID
> 2. *example* Our intention is to capture at least a 10x elastic advantage, but our current tool selection needs to be re-factored to better leverage elasticity
--------------------

[If Applicable, enter your Circumstances and exceptions here] 

_**Not Applicable for FDS Provider Paperless Project**_




--------------------  

## Section 2: Data Governance
> **PLEASE NOTE:** 
> * The application specific Data Governance details requested below are for documentation purposes. 
> * An approval of this public cloud account request is NOT an approval for use and movement of the data.
> * For specific questions regarding data usage and governance, the Data Governance team may be contacted at: data-governance@optum.com

### Data Details

> **Guidance**: Use this section to describe details about the data you will be hosting/collecting.  Remember to include details about the classification of the data.
> * Until Policy 15a Data Governance is complete, refer to Policy 13a
> * [13A.2.01.03 Securing Protected and Confidential Information](https://egrc.uhg.com/default.aspx?requestUrl=..%2fGenericContent%2fRecord.aspx%3fid%3d16037416%26moduleId%3d66)
>    

_**Not Applicable for FDS Provider Paperless Project, since we don't store any PHI data**_

#### Intended Data Use
> **Guidance**:  is this an existing or new Use case for the data?  
>  * **Note:** there may be follow-up with additional questions by the Platform Data Governance team.
--------------------

 - [x] This is a new application
 - [ ] This is a replacement for an existing system

Intended Data Use 
*	Data Use Cases:  
    - [x] Data use cases remain as-is and unchanged
    - [ ] New and/or modified use cases for the data
   
*	Does data need to return to targets outside of your cloud account?  
    - [ ] Yes
    - [x] No
 
*	How will the data get back to those targets?
     _**N/A**_

--------------------

[Describe the data return methods here]

 _**N/A**_
--------------------


#### Upstream Data Interfaces and Sources

> **Guidance**: Describe your upstream data interfaces and sources.  Where does the data come from?
> 
> What systems are they? _**ELGS**_
> - ASKID, ASK Short Name  
>   Leverage the ASK Portal to research information about your data sources
>   * https://ask-portal.optum.com/
> - If the downstream target is an external vendor or entity, please indicate that as well  
>  
> Other data notes to add (non-exhaustive):    
> - In what domain does it reside (internal/external/other)? internal
> - How will you be accessing data from these systems from the cloud? ECG
> - What size/quantity of data is ingested (GB/Day, GB in total)

--------------------

| ASK ID           | ASK ID Short Name  | Other Data Notes                   | 
|------------------|:------------------:|:-----------------------------------| 
| UHGWM110-002668  |  ELGS              | Enterprise Letter Generation System| 


--------------------

#### Source Data Sets
> **Guidance**: Please supply details of the various data sets from the above sources that you are consuming, and provide a description of the information in those data sets
>   * Data Set Name (Examples: Member, Claim)  _**Provider letters, which include Claims, Appeals, priorAuth and PRA.**_
>   * Data Set Short description (Examples: standardized Member data, standardized Claim data)
>  
> Example: dNHI contains User Views for consumption. 
>  
> Those include (but are not limited to):
> *	STATEVIEW: State level geographic view, for which use is permitted for the purposes of public health, healthcare operations, research, and product development.
> *	CCISTATEVIEW: A view combining clinical and administrative claimsdata. This view is a state level geographic view. CCISTATEVIEW is a copy of STATEVIEW plus clinical data.

--------------------

[List source data sets you will be consuming] 


| Data Set Name            | Data Set Description     |
|:------------------------:|:------------------------:|
|Letter category Claims    | Provider Claims letter   |
|Letter category Appeals   | Provider Appeals letter  |
|Letter category priorAuth | provider PriorAuth letter|
|Letter category PRA       | provider PRA letter      |  
  

--------------------


#### Downstream Targets

> **Guidance**: Describe where your data will end up.  
> - ASKID & Short name for the destination where the data is going
> - If the downstream target is an external vendor or entity, please indicate that as well
>  _**DocVault, ECG and FDS.**_ 

> **Other data notes to add (non-exhaustive)**: 
> - How will you be providing data to these systems from your cloud application?
>  _**Stargate API.**_ 
> - What size/quantity of data is egressed/consumed (GB/Day, GB in total)
>  _**We are processing 90 million records per year with average file size of 100KB.**_ 
#
--------------------


| ASK ID           | ASK ID Short Name          | Other Data Notes                 | 
|------------------|:--------------------------:|:---------------------------------| 
| UHGWM110-015085  |Federated Services FS2      | FDS(Federated data Services)     | 
| UHGWM110-027163  |New Document Vault (DV)     | DocVault/DocuLibrary             | 
| UHGWM110-014470  |Provider Elastic Search     | Provider Elastic Search          |
| UHGWM110-026131  |Provider Email Notifications| Provider Email Notifications     |
| UHGWM110-018344  | Doc360 					| Doc360			               |
 
 
 
--------------------

# 

## Section 3: Code Delivery and Management

> #### Samples to work from
> * Here is a link to our Azure Starter repo that may help get you going with Terraform builds into Public Cloud:  https://github.optum.com/CommercialCloud-EAC/azure_starter
> * For Jenkins pipelines, here is the related sample Jenkinsfile that may help with the CI/CD requirement:  https://github.optum.com/CommercialCloud-EAC/azure_starter/blob/master/Jenkinsfile


### Infrastructure as Code

> **Guidance**: Describe how you will be using Infrastructure as Code (IaC) patterns within your solution.  
> Some things to think about (non-exhaustive):  
> - What tool(s) do you plan to use? 
>   - The most common tool for IaC is Terraform
> - IaC is required to be established in nonProd for all components
> - The HCC Intake team will be reviewing your IaC code
> - Are there any IaC limitations that you are aware of within your proposed solution?
>  
> **NonProd requests:** identify the IaC method (most often Terraform) that will be leveraged  
>   
> **Prod requests:** provide the actual links to the IaC/Terraform code that builds the cloud components
> * this will be a link or links into the repos that contain your Terraform build files
> * **NOTE:** verify that the members of the MS/hcc_intake SECURE group have access to these repos
--------------------

[Use this space to provide the direct links to your IaC github repos]

_**We have existing applications that uses Jenkins, but we are also open to explore Terraform.**_

--------------------

### CI/CD

> **Guidance**: Describe how you plan to use CI/CD processes & which tools to support your environment.  Use diagrams as you see fit.  
> _**Jenkins/Azure Pipelines, GIT and docker.**_

> **NonProd requests:** identify the CI/CD service you are planning to use  
>  
> **Prod requests:** provide the actual links to successfull fully automated builds of your IaC in a CI/CD pipeline  
> * this is often a link or links into your Jenkins instance(s)  
> * **NOTE:** verify that the members of the MS/hcc_intake SECURE group have access to see the results  
--------------------

[Use this space to provide direct links to describe your CI/CD build pipelines.]

![Prun_arch_dia](https://github.optum.com/FDSPaperless/fds_paperless/blob/master/images/CI_CD.png)

--------------------

[link](https://github.optum.com/FDSPaperless/fds_paperless/blob/master/images/CI_CD.png)



--------------------
### Code Delivery and Management Circumstances and Exceptions

> **Guidance**: Special circumstances or exceptions to the criteria
> 1. *example* Azure SQL scaling can only be executed from the portal, we are unable to automate this step at this time.
> 2. *example* We are integrating with a 3rd party that does not support our automation and we will need to manually rotate and exchange API keys
--------------------

[If Applicable, enter your Code Delivery and Management Circumstances and exceptions here]

_**N/A**_


--------------------
#
## Section 4: Architecture Summary

### Architecture Overview

--------------------

> **Guidance**: This section must contain logical architecture diagram(s) of your solution that can be reviewed by others. Provide the actual diagrams, not links to remote diagrams, nor documentation with embedded diagrams.
> * Also, populate the table below (add rows as needed) to identify the cloud components and their purpose/usage.

The existing applications FDS Core and FDS Batch are tightly coupled, that’s makes development, refactor, deployments and maintenance harder and cumbersome. We need to decouple FDS core and do batch processing separately to make the project life cycle more efficient. Hence, we are proposing new architecture to address our challenges on tight coupled along with other enhancement by using Spring Cloud framework using Spring Boot, Config-server/client, Service discovery and API gateway.  Below is the high-level architecture diagram to illustrate the basic functionality of the proposed platform

_**High level illustration of proposed architecture**_ 

 ![Prun_arch_dia](https://github.com/uhc-tech-provider/ppl_paperless/blob/main/images/prun_design_v4.png)  



--------------------

[link](https://github.com/uhc-tech-provider/ppl_paperless/blob/main/images/prun_design_v4.png)

_**Overview of System Design**_ 

 ![Prun_arch_dia](https://github.optum.com/FDSPaperless/fds_paperless/blob/master/images/MicrosoftTeams-image.png)  



--------------------

[link](https://github.optum.com/FDSPaperless/fds_paperless/blob/master/images/MicrosoftTeams-image.png)

| Cloud Component | Usage           | 
|-----------------| --------------- |
| Config server   | centralized repo| 
| Spring Admin    | admin fds apps  |
| Spring boot     | Orchestration   |
| Spring boot	  | services apps   |
| Spring Cloud	  | Security Gateway|
| Spring Activiti | Workflow engine |
| MYSQL and Cosmos| Databases       |

--------------------

### Architecture Circumstances and Exceptions

> **Guidance**: Special circumstances or exceptions to the criteria
> 1. *example:* We have not yet decided/identified a replacement for F5 as our web application firewall and are exploring additional options.
> 2. *example:* We are required to use Oracle because of contractual commitments to our customer
--------------------

[If Applicable, enter your Architectural Circumstances and exceptions here]




--------------------
#
## Section 5: Network Summary

### Network Summary Diagram

--------------------

> **Guidance**: This section should contain logical network diagram(s) of your solution that can be reviewed by others. Provide the actual diagrams, not links to remote diagrams, nor documentation with embedded diagrams
> * Review the Network Architecture diagram requirements and examples at this link: https://vanguard.optum.com/docs/ArchitectureModels/network_template/  
>  
>	For your new cloud subscription/account/project:  
>	* Represent all components that are being built and consumed  
>	* **Clearly differentiate** what you are building from other cloud or on-prem components with which you are connecting, but are not building  
>  * Populate the table below (add rows as needed) to identify network communication into and out of the the cloud subscription/account

--------------------

![Prun_arch_dia](https://github.optum.com/FDSPaperless/fds_paperless/blob/master/images/azure_module_arch.png)

--------------------

[link](https://github.optum.com/FDSPaperless/fds_paperless/blob/master/images/azure_module_arch.png)

| Connection Info/Direction      | Network Ports              | Purpose          | 
|--------------------------------|:--------------------------:|:-----------------| 
| API Gateway: TCP/IP            |    8080(HTTP),8443(HTTPS)  | web applications | 
| Micro Services: TCP/IP         |    8080(HTTP),8443(HTTPS)  | web applications |
| Mysql(spring activiti): TCP/IP |    8080(HTTP),8443(HTTPS)  | Data storage     | 
| CosmosDB: TCP/IP               |    8080(HTTP),8443(HTTPS)  | Data storage     | 
| Azure Service Bus: TCP/IP      |    8080(HTTP),8443(HTTPS)  | Message queues   | 

--------------------

### Network Circumstances and Exceptions

> **Guidance**: Special circumstances or exceptions to the criteria
> 1. *example* We are required to allow UDP egress on ports 8000-8100 due allow for blockchain synchronization.  All resources with this egress are isolated with a dedicated security group and cannot connect to other internet resources.
--------------------

[If Applicable, enter your Network Circumstances and exceptions here]



--------------------
#
## Section 6: Security Criteria

### Security Considerations

> **Guidance**: Describe any exceptions you may be seeking and why you need them.  

Some things to think about (non-exhaustive):  
- Are there any resources that can't be created with automation?
- Are you needing to make use of non-standard ports (anything other than TCP 443)?
- Do you have extremely high volumes of data to move (over 10TB at a time)?

### EIS Security Intent Review

Be sure to review the **55 Technical Controls and 14 Principles** as you will need to meet these controls within your solution.
* https://new-wiki.optum.com/display/seccldgov/SCG+55+Technical+Controls+in+14+Principles
* https://vanguard.optum.com/docs/patterns/security/55-security-questions
* https://github.optum.com/pages/SPACE/SPACE_documentation/docs/controls/controls/

### Security Circumstances and Exceptions

> **Guidance**: Please make note of any Special circumstances or exceptions to the criteria
> 1. *Example* PEX0000001 - Exception for network access, last reviewed and approved on 11/15/2019, expires on 2/15/2020
--------------------

[List your special circumstances or security exceptions here]



--------------------
#
**Internal Use Only:**  v5.0.0
<!-- ps52101 -->
