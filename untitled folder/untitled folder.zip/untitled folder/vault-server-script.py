import json

path = '/usr/local/src/fds_config_store/ppl-prun-processor-listener/ppl-prun-processor-listener-prod-hcc.properties'
# change pending- loop to iterate in directory insted of changing path for every file 1 by 1

f = open(path)
save = path.split(".properties")[0]
lines = f.read().splitlines()

# print(lines)
data = {}

for i, line in enumerate(lines):

    arr = line.split("=", 1)
    key = arr[0].strip()
    val = arr[1].strip()
    data[key] = val

json_data = json.dumps(data, sort_keys=True, indent=4, separators=(',', ': '))
print(json_data)

text_file = open((save + ".json"), "w")
text_file.write(json_data)
text_file.close()
