package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.unetpra", havingValue = "true")
public class UNETPRAConsumerService extends AbstractDocumentConsumer {

    @Value("${UNETPRA_SPACEID}")
    private int unetpra_spaceId;


    @KafkaListener(
            topics = "${spring.kafka.topic.unetpra}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, unetpra_spaceId);
    }
}