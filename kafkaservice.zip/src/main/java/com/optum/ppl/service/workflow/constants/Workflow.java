package com.optum.ppl.service.workflow.constants;

/**
 * Fields in interface are public static final by default.
 */
public final class Workflow {

    public static final String POD_NAME = "podName";
    public static final String NUM_RETRIES = "numRetries";
    public static final String TIME_TO_WAIT = "timeToWaitMS";
    public static final String CASE_ID = "caseId";
    public static final String NSG_ID = "ngsId";
    public static final String ORIGINAL_ZIP_FILE_NAME = "originalZipFileName";
    public static final String DATE_MODIFIED = "dateModified";
    public static final String CREATED_DATE = "createdDate";
    public static final String LETTER_GROUP_ID = "letterGroupId";
    public static final String LETTER_TYPE = "letterType";
    public static final String HISTORYID = "historyId";
    public static final String NOTIFICATION_LETTER_ID = "NotificationLetterID";
    public static final String UNIQUEFIELDTOGROUPDOCS = "UniqueFieldToGroupDocs";

    /* Bounced provider email address workflow */
    public static final String METADATA_PROVIDER_EMAIL_ID = "metadata.providerEmailId";
    public static final String METADATA_MESSAGE_ID = "metadata.messageId";
    public static final String METADATA_RESPONSE_FILE_NAME = "metadata.responseFileName";
    public static final String METADATA_SHUTTERFLY_FILE_NAME = "metadata.shutterflyFileName";
    public static final String METADATA_BOUNCED_EMAIL_FILE_NAME = "metadata.bouncedEmailFileName";
    public static final String MESSAGE_ID = "message_id";
    public static final String SPACE_ID = "spaceId";
    public static final String SPACE__ID = "space_id";
    public static final String APP_ID_V1 = "appIdentifier";
    public static final String APP_ID = "appId";
    public static final String APP_IDENTIFIER = "appIdentifier";
    public static final String APP_SECRET = "appSecret";
    public static final String CLIENT_IDENTIFIER = "clientIdentifier";
    public static final String CLIENT_PASS = "clientSecret";
    public static final String START_DATE_IN_DAYS = "startDateInDays";
    public static final String MAX_DOCUMENTS_OCCURS = "maxDocumentsOccurs";
    public static final String BATCH_SIZE = "batchSize";
    public static final String DOCUMENT_STATUS_AVAILABLE = "AVAILABLE";
    public static final String NO_OF_BUSINESS_DAYS = "noOfBusinessDays";
    public static final String NO_OF_DAYS = "noOfDays";
    public static final String EMAIL_TERMINATION_WINDOW = "emailTerminationWindow";
    public static final String ATTESTATION_COMPLETED = "attestationCompleted";
    public static final String MANUAL_OUTREACH = "MANUAL_OUTREACH";
    public static final String ELECTRONIC_OUTREACH = "ELECTRONIC_OUTREACH";
    public static final String INITIATE_OUTREACH = "INITIATE_OUTREACH";
    public static final String VERIFIED = "VERIFIED";
    public static final String TERMED = "TERMED";
    public static final String STOP_SENDING_EMAIL = "stopSendingEmail";
    public static final String DOCUMENTS_COLLECTION = "documents";
    public static final String HOOK = "hook";
    public static final String DEFAULT_FILE_SEPARATOR = "/";
    public static final String ACTIVITI_PROCESS_DELEGATE = "CreateOneZipfilePrintServices";
    public static final String PRINT_SERVICES_MANIFEST = "printServicesManifest";
    public static final String COMPANION_ZIP_FILE_NAME_MESSAGE = "companion_zip_file_name_message";
    public static final String METADATA_DOCSENTTO_FIELD = "docSentTo";
    public static final String METADATA_DOCSENTTO_VALUE = "PrintServices";
    public static final String METADATA_DOCSENTTO_DOCVAULT = "DocVault";
    public static final String METADATA_DOCVAULT_API_RESPONSE = "docVaultAPIResponse";
    public static final String METADATA_DOCVAULT_UPLOAD_DATE = "docVaultUploadDate";
    public static final String METADATA_UPDATE_DOCLIB_API_RESPONSE = "updateDocLibAPIResponse";
    public static final String METADATA_UPDATE_DOCLIB_UPLOAD_DATE = "updateDocLibUploadDate";
    public static final String METADATA_SEND_PEN_API_REQUEST = "sendPENAPIRequest";
    public static final String METADATA_SEND_PENAPI_REQUEST = "metadata.sendPENAPIRequest";

    public static final String DOCVAULT_API_RESPONSE_SUCCESS_MESSAGE = "docvault_api_response_success_message";
    public static final String DOCVAULT_API_RESPONSE_ERROR_MESSAGE = "docvault_api_response_error_message";
    public static final String REPRNT_SENT_TO_SHUTTERFLY = "rprntSentToSF";
    public static final String SKIP_SEND_TO_SHUTTERFLY = "skipSendToShutterfly";
    
    /* Manipulate PDF */
    public static final String ERROR_MAP = "errorMap";
    public static final String NEW_ERRORS = "newErrors";
    public static final String DOCUMENT = "Document";
    public static final String ATTACHMENT = "Attachment";
    public static final String ATTACHMENTS = "Attachments";
    public static final String LIST_DOCUMENT_METADATA = "listDocumentMetaData";
    public static final String ZIP_FILE_PATH = "zipfile_path";
    public static final String EXECUTION_ERROR_CODE = "executionErrorCode";
    public static final String EXECUTION_ERROR_SOURCE_MODULE = "executionErrorSourceModule";
    public static final String EXECUTION_ERROR_MSG = "executionErrorMsg";
    public static final String DOCUMENT_ABSOLUTE_PATH = "absolutePath";
    public static final String PROCESSOR_FILE_TASK_ID = "processorFileTaskId";
    public static final String PROCESSOR_METADATA = "processorMetaData";
    public static final String PROCESSOR = "processor";
    public static final String ADDRESS_BLOCK_X = "addressBlockX";
    public static final String ADDRESS_BLOCK_Y = "addressBlockY";
    public static final String IDENTIFIER_FONT_SIZE = "identifierFontSize";
    public static final String RECEIVER_IDENTIFIER = "receiverIdentifier";
    public static final String SKIP_MANIPULATE_PDF_FILE = "skipManipulatePdfFile";
    public static final String TURN_PEN = "turnPEN";
    public static final String WRITE_ENCRYPTED_PDF = "writeEncryptedPDF";
    public static final String MANIPULATE_PDF_FILE_MESSAGE = "manipulate_pdf_file_message";
    public static final String VALIDATE_CORPORATE_MPIN = "validateCorprateMPIN";

    /* Oauth vars. */
    public static final String CLIENT_ID = "client_id";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String CLOUD_CLIENT_ID = "cloud_client_id";
    public static final String CLOUD_CLIENT_SECRET = "cloud_client_secret";
    public static final String FDS_CLOUD_AUTH_URL = "fdsCloudAuthUrl";
    public static final String GRANT_TYPE = "grant_type";
    public static final String CLOUD_GRANT_TYPE = "cloud_grant_type";
    public static final String SMAPI_CLIENT_ID = "smapi_client_id";
    public static final String SMAPI_CLIENT_SECRET = "smapi_client_secret";
    public static final String SMAPI_GRANT_TYPE = "smapi_grant_type";
    public static final String SMAPI_OAUTH_URL = "sm_oauth_url";
    public static final String SMAPI_OATH_ERROR_MESSAGE = "smapi_oauth_error_message";
    public static final String FDS_CLOUD_GET_DOCUMENT_URL = "fdsCloudGetDocumentUrl";
    public static final String FDS_CLOUD_GET_ATTACHMENT_URL = "fdsCloudGetAttachmentUrl";

    /* SecureMessaging vars. */
    public static final String SM_API_URL = "sm_api_url";
    public static final String SUBJECT = "subject";
    public static final String BODY = "body";
    public static final String SENDER_MAILBOX_ID = "sender_mailbox_id";
    public static final String RECIPIENT_EMAIL = "recipient_email";
    public static final String RECIPIENT_SPACE_ID = "recipient_space_id";
    public static final String SMAPI_OAUTH_TOKEN = "smapi_oauth_token";
    public static final String TEMPLATE_ID = "template_id";
    public static final String TEMPLATE_NAME = "template_name";
    public static final String FILE_PATH = "filePath";
    public static final String LOCATION =  "location";
    public static final String PEN_TEMPLATE_ID = "pen_template_id";
    public static final String SM_TEMPLATE_ID = "sm_template_id";
    public static final String SM_TEMPLATE_CONTEXT = "sm_template_context";
    public static final String DOCUMENT_RECIPIENT_EMAIL_PATH = "document_recipient_email_path";
    public static final String RECIPIENT_MAILBOX_ID_PATH = "recipient_mailbox_id_path";
    public static final String DOCUMENT_METADATA = "metadata";
    public static final String SMAPI_EXCEPTION = "smapi_exception";

    /* UpdateDocumentListWithApi vars. */
    public static final String DOCUMENT_UPDATE_FLAG_PATH = "document_update_flag_path";
    public static final String DOCUMENT_FORMAT_FIELD = "document_format_field";
    public static final String UPDATE_DOCUMENT_WITH_API_SUCCESS_MESSAGE = "update_document_with_api_success_message";
    public static final String IDENTIFY_DOCUMENTS_SUCCESS_MESSAGE = "identify_documents_success_message";
    public static final String UPDATE_DOCUMENT_WITH_API_FAILURE_MESSAGE = "FDS PUT Document failed.";
    public static final String PREPOSTENDED = "metadata.prepostEnded";
    

    /* TranformMerge vars. */
    public static final String TRANSFORM_MERGE_SUCCESS_MESSAGE = "transform_merge_success_message";
    public static final String TRANSFORM_MERGE_FAILURE_MESSAGE = "transform_merge_failure_message";
    public static final String TRANSFORM_MERGE_FILES_NOT_FOUND_TO_MERGE = "Files not found to merge";
    public static final String TRANSFORM_MERGE_INVALID_SPACE_ID = "Not a valid space Id";
    public static final String TRANSFORM_MERGE_NO_MERGED_PDF_FOUND = "Merge PDF not found";
    public static final String TRANSACTION_ID_IS_EMPTY = "transactionID can't be Empty!";
    public static final String TRANSACTION_ID_IS_NULL = "transactionID can't be Null";
    public static final String METADATA_TRANSACTION_ID = "transactionID";
    public static final String REQUIRED_SECTIONS = "Required sections Document metadata OR FormData OR confirmation OR transactionID field missing";

    /* CallRestApi vars */
    public static final String CALL_REST_API_SUCCESS_MESSAGE = "call_rest_api_success_message";
    public static final String UNSUPPORTED_METHOD = "UNSUPPORTED_METHOD";
    public static final String INVALID_JOB_TYPE = "REST_API_JOB_REQUIRED";
    public static final String REST_URI = "uri";
    public static final String REST_METHOD = "method";
    public static final String REST_REQUEST = "request";
    public static final String REST_SOURCE_TYPE = "sourceType";
    public static final String REST_SOURCE_ID = "sourceId";
    public static final String REST_SERVER_TYPE = "serverType";
    public static final String REST_SERVER_NAME = "serverName";
    public static final String REST_JOB_TYPE = "jobType";
    public static final String REST_JOB_ID = "jobId";
    public static final String REST_CLIENT_ID = "clientId";
    public static final String REST_CLIENT_SECRET = "clientSecret";
    public static final String REST_APP_IDENTIFIER = "appIdentifier";
    public static final String REST_CONFIG_SPACE_ID = "configSpaceId";
    public static final String REST_RESPONSE = "response";
    public static final String REST_TRX_ID = "transactionId";
    public static final String REST_VERSION = "version";
    public static final String REST_CSV_FILE_NAME = "csvFileName";
    public static final String REST_JSON_FILE_NAME = "jsonFileName";
    public static final String REST_TARGET_TYPE = "targetType";
    public static final String REST_TARGET_ID = "targetId";
    public static final String REST_STATUS = "status";
    public static final String REST_API_JOB_ATTRS = "restApiJobAttrs";
    public static final String REST_COMPLETE = "COMPLETE";
    public static final String REST_COMPLETE_WITH_ERRORS = "COMPLETE_WITH_ERRORS";
    public static final String REST_DB_STATUS_OBJ_ID = "dbStatusObjId";
    public static final String REST_OAUTH_TOKEN = "oauthToken";
    public static final String REST_ACCESS_TOKEN = "accessToken";
    public static final String REST_CSV_PROCESSOR_ROW_TASK_RECORD_NOT_LOCATED = "CsvProcessorRowTask record could not be located";
    public static final String REST_CSV_PROCESSOR_ROW_TASK_RECORD_NOT_UPDATED = "CsvProcessorRowTask record could not be updated";
    public static final String REST_ERROR_MSG = "Error Executing CallRestApi";
    public static final String REST_X_TRX_HEADER = "X-Transaction-Id";
    public static final String REST_HTTP_REQUEST_EXECUTION_ERROR = "Error Executing Http Request";

    public static final String REST_LAST_RECORD = "lastRecord";
    public static final String REST_RECORD_NUMBER = "recordNumber";
    public static final String REST_CSV_PROCESSOR_ROW_TASK = "csvProcessorRowTask";
    /* PreprocessValidation vars. */
    public static final String PREPROCESS_VALIDATION_SUCCESS_MESSAGE = "preprocess_validation_success_message";
    public static final String PREPROCESS_VALIDATION_ERROR_MESSAGE = "preprocess_validation_error_message";
    /* OptumPreprocessValidation vars. */
    public static final String SOURCE = "source";
    
    public static final String USE_FDS_CLOUD = "useFDSCloud";

    /* RabbitMq vars. */
    public static final String NAME = "name";
    public static final String HOST = "host";
    public static final String VHOST = "vhost";
    public static final String PORT = "port";
    public static final String USER = "user";
    public static final String PASS = "pass";
    public static final String EXCHANGE = "exchange";
    public static final String KEY = "key";
    public static final String MAX_RETRIES = "maxRetries";
    public static final String MAX_RETRIES_VALUE = "3";
    public static final String RETRY_SLEEP_TIME = "retrySleepTime";
    public static final String RETRY_SLEEP_TIME_VALUE = "2000";

    public static final String RABBITMQ_SUCCESS_MESSAGE = "rabbitmq_success_message";
    public static final String RABBITMQ_ERROR_MESSAGE = "rabbitmq_error_message";
    public static final String RABBITMQ_POST_FAILED = "rabbitmq_post_failed";
    public static final String RABBITMQ_READER_SUCCESS_MESSAGE = "rabbitmq_reader_success_message";
    public static final String RABBITMQ_READER_ERROR_MESSAGE = "rabbitmq_reader_error_message";
    public static final String SMAPI_SUCCESS_MESSAGE = "smapi_success_message";
    public static final String SMAPI_ERROR_MESSAGE = "smapi_error_message";
    public static final String MPIN_SUCCESS_MESSAGE = "mpin_success_message";
    public static final String MPIN_ERROR_MESSAGE = "mpin_error_message";
    public static final String RABBITMQ_READER_INGEST_FOLDER = "ingestFolder";
    public static final String RABBITMQ_RECORD_INGEST_FOLDER = "recordingestfolder";
    public static final String PROCESSOR_TRANSACTION_INGEST_FOLDER = "processorTransactionIngestFolder";
    
    public static final String ERROR_MESSAGE = "error_message";

    /* Processor vars */
    public static final String PROCESS_KEY = "process_key";
    public static final String JOB = "job";
    /* file unzip vars. */
    public static final String UNZIP_ERROR_MESSAGE = "unzip_error_message";
    public static final String UNZIP_SUCCESS_MESSAGE = "unzip_success_message";
    /* Metadata file. */
    public static final String METADATAFILE_ERROR_MESSAGE = "metadata_error_message";
    public static final String METADATAFILE_SUCCESS_MESSAGE = "metadata_success_message";

    /* Generic OATH vars */
    public static final String OAUTH_ERROR_MESSAGE = "oauth_error_message";
    public static final String OAUTH_URL = "fdsAuthUrl";
    public static final String OAUTH_TOKEN = "oauth_token";
    public static final String CORRELATION_IDS = "CorrelationID";
    public static final String OAUTH_TOKEN_V1 = "oauthToken";
    public static final String PES_OAUTH_URL = "pesAuthUrl";
    public static final String PES_APP_ID = "pesAppId";
    public static final String PES_APP_SECRET = "pesAppSecret";
    public static final String PES_GRANT_TYPE = "pesGrantType";

    /* PDO fields  */
    public static final String TIN = "tin";
    public static final String MPIN = "mpin";
    public static final String FILE_NAME = "fileName";

    public static final String FILE_TYPE = "fileType";
    public static final String PROVIDER_EMAIL_ID = "providerEmailId";
    public static final String PROVIDER_EMAIL_ID_LIST = "providerEmailIdList";
    public static final String SUBSCRIBE_TO_EMAIL = "subscribeToEmail";
    public static final String FREQUENCY = "frequency";
    public static final String DELIVERY_METHOD = "deliveryMethod";
    public static final String OK_TO_CHANGE_PDO_IND = "okToChangePDOInd";
    public static final String AUTO_EDEL_UPDATE_IND = "autoEdelUpdateInd";

    public static final String FDS_DOCUMENT_URL = "fdsDocumentUrl";
    public static final String FDS_AUTH_URL = "fdsAuthUrl";
    public static final String PROVIDER_EMAIL = "providerEmailId";
    public static final String WEEK_DAY = "weekDay";
    public static final String SUBCATEGORY = "subCategory";

    /* Retrieve Corporate MPIN Provider Search */
    public static final String ERROR_RETRIEVE_MPIN_V2 = "RetrieveCorporateMPIN_V2 error";
    public static final String ERROR_SAVE_MPIN = "SaveCorporateMPIN error";
    public static final String ERROR_NO_MPIN_EMAIL = "No MPIN Send Email error";

    public static final String PROV_MPIN = "mpin";
    public static final String PROV_CORP_MPIN = "corporateMpin";
    public static final String PROV_APP_NAME = "appName";
    public static final String PROV_PROCESS_KEY = "process_key";
    public static final String PROV_AUTH_URL = "provAuthUrl";
    public static final String PROV_SEARCH_URL = "provSearchUrl";
    public static final String PROV_GRANT_TYPE = "grantType";
    public static final String PROV_THROTTLE_COUNT_PER_TIME_PERIOD = "throttleCountPerTimePeriod";
    public static final String PROV_THROTTLE_PERIOD_MILLISECONDS = "throttlePeriodMilliSeconds";

    public static final String PROV_CLIENT_ID = "inpClientId";
    public static final String PROV_CLIENT_SECRET = "inpClientSecret";
    public static final String PROV_ACTOR = "actor";
    public static final String PROV_SCOPE = "scope";
    public static final String PROV_CORRELATION_ID = "correlationId";
    public static final String PROV_ATTRIBUTE_SET = "attributeSet";
    public static final String PROV_COUNT = "count";

    /* Retrieve Corporate MPIN V2 Provider Timeout configurations */
    public static final String RETRIEVE_CORPMPIN_RETRIES = "retrieveCorpMpinRetries";
    public static final String RETRIEVE_CORPMPIN_RETRY_DEFAULT_CALL_INTERVAL = "retrieveCorpMpinRetryDefaultCallInterval";
    public static final String CORPMPIN_RETRY_SLEEP_PERIOD_INTERVAL = "retrieveCorpMpinRetrySleepPeriodInterval";

    /* Retrieve Corporate MPIN Send Email */
    public static final String SMTP_HOST_NAME = "smtpHostName";
    public static final String SMTP_PORT_NUMBER = "smtpPortNumber";
    public static final String EMAIL_SENDER = "emailSender";
    public static final String EMAIL_RECEIVER = "emailReceiver";
    public static final String EMAIL_SUBJECT = "emailSubject";
    public static final String EMAIL_SUBJECT_TIN_NUMBER = " - Tin Number: ";
    public static final String EMAIL_MESSAGE = "emailMessage";
    public static final String EMAIL_ALERT_REQUEST = "emailAlertReq";

    /* Retrieve provider data V4 Provider  */
    public static final String ST_CD = "st-cd";
    public static final String ADR_TYPE_CD = "adr-typ-cd";

    /* Bounced Provider Email */
    public static final String BOUNCED_ZIP_FILE_NAME = "bouncedZipFileName";
    public static final String HOOK_STATUS_ACTIVE = "ACTIVE";
    public static final String HOOK_RECORD_TYPE_TRANSACTION = "hookTransaction";

    /* Build OR Send Email */
    public static final String ERROR_BUILD_EMAIL = "BuildEmail error";
    public static final String ERROR_SEND_EMAIL = "SendEmail error";
    public static final String DOCUMENTS_DIRECTORY = "documentsDirectory";
    public static final String OUTPUT_FILE_DIR = "outputFileDir";
    public static final String OUTPUT_FILE_DIR_SHUTTERFLY = "outputFileDirShutterfly";
    public static final String OUTPUT_FILE_DIR_BOUNCE = "outputFileDirBounce";

    /* noCorporateMPIN Or NoEmailAddress */
    public static final String FDS_DOCUMENTS_URL = "fdsDocumentsUrl";
    public static final String PROVIDER_PREFERENCE_SPACE_ID = "providerSpaceId";
    public static final String PROVIDER_PREFERENCE_SPACE_ID_V2 = "providerSpaceIdV2";
    public static final String TARGET_MANIFEST_DIR = "targetManifestDir";
    public static final String ORIGINAL_PRINT_TRAIL = "originalPrintTrail";

    /* CleverSafe Retry */
    public static final String CLEVER_SAFE_RETRIES = "CLEVER_SAFE_RETRIES";
    public static final String CLEVER_SAFE_RETRIES_VALUE = "3";
    public static final String CLEVER_SAFE_RETRIES_SLEEP_TIME = "CLEVER_SAFE_RETRIES_SLEEP_TIME";
    public static final String CLEVER_SAFE_RETRIES_SLEEP_TIME_VALUE = "2000";

    public static final String ORS_REQUEST = "ORSRequest";
    public static final String ORS_RESPONSE = "ORSResponse";
    public static final String EXTERNAL_ID = "externalId";
    public static final String EXTERNAL__ID = "external_id";

    // Health Monitor
    public static final String UNPLANNED_PROCESSOR_SHUTDOWN_PENDING_TIME = "UNPLANNED_PROCESSOR_SHUTDOWN_PENDING_TIME";
    public static final String UNPLANNED_PROCESSOR_SHUTDOWN_PENDING_TIME_VALUE = "7200";
    public static final String UNPLANNED_PROCESSOR_PENDING_TIME = "UNPLANNED_PROCESSOR_PENDING_TIME";
    public static final String UNPLANNED_PROCESSOR_PENDING_TIME_VALUE = "7200";

    public static final String RUN_HOOK_HEALTH_MONITOR = "RUN_HOOK_HEALTH_MONITOR";
    public static final String HOOK_PENDING_JOB_TIME = "HOOK_PENDING_JOB_TIME";
    public static final String HOOK_PENDING_JOB_TIME_VALUE = "7200";
    // CleanUp
    public static final String POLL_PROCESSOR_TRANSACTIONS_START_TIME_OFFSET_FOR_CLEANUP = "POLL_PROCESSOR_TRANSACTIONS_START_TIME_OFFSET_FOR_CLEANUP";
    public static final String POLL_PROCESSOR_TRANSACTIONS_START_TIME_OFFSET_FOR_CLEANUP_VALUE = "7"; // 7 days
    public static final String POLL_CSV_PROCESSOR_TRANSACTIONS_START_TIME_OFFSET_FOR_CLEANUP = "POLL_CSV_PROCESSOR_TRANSACTIONS_START_TIME_OFFSET_FOR_CLEANUP";
    public static final String POLL_CSV_PROCESSOR_TRANSACTIONS_START_TIME_OFFSET_FOR_CLEANUP_VALUE = "7"; // 7 days

    // Vars required for converting CSV to Json File
    public static final String JSON_TEMPLATE = "template_definition";
    public static final String CSVTOJSON_SUCCESS_MESSAGE = "csvToJson_success_message";
    public static final String CSVTOJSON_ERROR_MESSAGE = "csvToJson_error_message";
    public static final String JSONTOREST_SUCCESS_MESSAGE = "jsonToRest_success_message";
    public static final String JSONTOREST_ERROR_MESSAGE = "jsonToRest_error_message";

    // REST Common Vars
    public static final String COMMON_BASE_URL = "baseUrl";
    public static final String COMMON_PATH = "path";
    public static final String COMMON_BODY = "body";
    public static final String COMMON_MESSAGE_MAP = "message";

    public static final String COMMON_CONNECT_TIMEOUT = "connectTimeout";
    public static final String COMMON_ERRORS = "errors";
    public static final String COMMON_ERROR_CODE = "code";
    public static final String COMMON_ERROR_DESCRIPTION = "description";
    public static final String COMMON_FORM_POST_CONFIG = "HttpUrlEncodedFormPostConfig";
    public static final String COMMON_FORM_POST_RESULT = "HttpUrlEncodedFormPostResult";
    public static final String COMMON_HEADERS = "requestHeaders";
    public static final String COMMON_HTTP_POST_CONFIG = "HttpPostConfig";
    public static final String COMMON_HTTP_POST_RESULT = "HttpPostResult";
    public static final String COMMON_HTTP_GET_CONFIG = "HttpGetConfig";
    public static final String COMMON_HTTP_GET_RESULT = "HttpGetResult";
    public static final String COMMON_HTTP_GET_TASK_CONFIG = "HttpGetConfig";
    public static final String COMMON_HTTP_GET_TASK_RESULT = "HttpGetResult";
    public static final String COMMON_JSON_STRING = "jsonString";
    public static final String COMMON_JSON_PARSER_CONFIG = "JsonParserConfig";
    public static final String COMMON_JSON_PARSER_RESULT = "JsonParserResult";
    public static final String COMMON_PARSED_TYPE = "parsedType";
    public static final String COMMON_PARSED_LIST = "parsedList";
    public static final String COMMON_PARSED_MAP = "parsedMap";
    public static final String COMMON_QUERY_PARAM = "queryParams";

    public static final String COMMON_RESULT_HEADERS = "headers";
    public static final String COMMON_REQ_TYPE = "request_type";
    public static final String COMMON_SOCKET_TIMEOUT = "socketTimeout";
    public static final String COMMON_STATUS = "status";
    public static final String COMMON_SUCCESS = "success";

    // IRIS Wrapper constants in addition to the SMAPI constants defined above
    public static final String SMAPI_MESSAGE_URL = "smapi_message_url";
    public static final String SMAPI_MAILBOX_URL = "smapi_mailbox_url";

    public static final String SMAPI_MESSAGE_TEMPLATE_ID = "smapi_message_template_id";
    public static final String SMAPI_SPACE_ID = "smapi_space_id";
    public static final String DOC_META_EXTERNAL_ID = "doc_meta_external_id";
    public static final String DOC_META_EMAIL = "doc_meta_email";
    public static final String IRIS_COPAY_HOLD_WRAPPER_RESULT = "IrisCopayHoldWrapperResult";

    // Transform Process Constants
    public static final String FDS_PROVISIONING_SPACE_URL = "fdsProvisioningSpaceUrl";
    public static final String EXECUTE_TRANSFORM_MERGE_ATTACHMENTS_UPDATE_DOCUMENT_PPROCESS = "executeTransformMergeAttachmentsUpdateDocumentProcess";
    public static final String GET_SPACE_PROPERTIES_TASK_ERROR_MESSAGE = "getSpacePropertiesTask_error_message";

    public static final String FDS_ATTACHMENT_URL = "fdsAttachmentUrl";
    public static final String FDS_TRANSFORM_URL = "fdsTransformUrl";
    public static final String SFTP_OUTBOUND_SEND_EMAIL_NOTIFICATION_ERROR = "SFTP Outbound Send Email error";

    // RetrieveProcessorTransaction
    public static final String SEARCH_CRITERIA = "search_criteria";
    public static final String SEARCH_WINDOW = "search_window";
    public static final String SEARCH_WINDOW_TIMEWINDOW = "time_window";
    public static final String SEARCH_WINDOW_FORMAT = "format";
    public static final String SEARCH_WINDOW_START_DATE = "start_date";
    public static final String SEARCH_WINDOW_START_DATE_OFFSET = "start_date_offset";
    public static final String SEARCH_WINDOW_END_DATE = "end_date";
    public static final String SEARCH_WINDOW_END_DATE_OFFSET = "end_date_offset";
    public static final String PROCESSOR_DATE_CREATED = "dateCreated";
    public static final String PROCESSOR_RECORD_TYPE = "processorRecordType";
    public static final String PROCESSOR_COLLECTION_NAME = "processor";
    public static final String INGEST_ROOT = "INGEST_ROOT";
    public static final String ACK_STATUS_IN_PROCESS = "IN_PROCESS";
    public static final String PROCESSOR_TRANSACTION_UPDATE = "PROCESSOR_TRANSACTION_UPDATE";
    public static final String MONGO_ID = "_id";
    public static final String ACK_STATUS = "ackStatus";
    public static final String GMT_06_00 = "GMT-06:00";
    public static final String PROCCESSOR_TRANSACTION = "processorTransaction";
    public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
    public static final String HOOK_EXECUTION_ID = "hookExecutionId";
    public static final String HOOK_TRANSACTION_METADATA = "hookTransactionMetaData";
    public static final String HOOK_TRANSACTION_METADATA_ID = "hookTransactionId";
    public static final String HOOK_ID = "hookId";
    public static final String CLIENTID = "clientId";
    public static final String PROCESSOR_TRANSACTION_IDS_MESSAGE = "processor_transaction_ids_message";
    public static final String OUTPUT_FILE_EXTENSION = "output_file_extension";
    public static final String ZIP_OUTPUT_FILE = "zip_output_file";
    public static final String DOC_UPDATE_FLAG_PATH = "document_update_flag_path";

    public static final String DOC_UPDATE_FLAG_VALUE = "document_update_flag_value";

    public static final String DOCUMENT_MISSING_FORMPDF = "Invalid document.metadata.formData.files.formPdf-  null or does not exist";
    public static final String DOCUMENT_MISSING_ATTACHMENTIDS = "Invalid metadata.formData.files.attachments-  null or does not exist";
    public static final String DOCUMENT_MISSING_FDS_ATTACHMENT_URL = "Invalid fdsAttachmentUrl null or does not exist";
    public static final String INVALID_FORMPDF_ERROR = "Invalid formPdf Error";
    public static final String INVALID_ATTACHMENTIDS_ERROR = "Invalid attachments Errror";
    public static final String INVALID_FDS_ATTACHMENT_URL = "Invalid fdsAttachmentUrl Errror";
    public static final String INVALID_OAUTH_TOKEN = "invalidOauth_token";
    public static final String INVALID_OAUTH_TOKEN_ERROR = "Invalid oauth Token";
    public static final String ATTACHMENT_RETRIEVAL_ERROR = "Error Retrieving FDS Attachment";
    public static final String RETRIEVED_ATTACHMENTS = "retrievedAttachments";
    public static final String MERGED_PDF_ATTACHMENT = "mergedPdfAttachment";
    public static final String RETRIEVE_ATTACHMENTS_ERROR_MESSAGE = "retrieveAttachments_error_message";
    public static final String MERGED_PDF_ATTACHMENTS_ERROR_MESSAGE = "mergedPdfAttachment_error_message";

    public static final String SFTP_URL = "sftpUrl";
    public static final String SFTP_USER = "sftpUser";
    public static final String SFTP_PASS = "sftpPassword";
    public static final String SFTP_ROOT = "sftpRoot";
    public static final String INVALID_DATA_ERROR = "Error occurred while validating data {}";
    public static final String INVALID_DATA_MSG = "Invalid data provided in the excecution bus";
    public static final String RMO_STATUS = "rmoStatus";
    public static final String SFTP_FAILED = "sftp_failed";
    public static final String SFTP_SUCCESS = "sftp_success";
    public static final String SENT = "sent";
    public static final String Y = "Y";
    public static final String N = "N";

    public static final String ERROR_SFTP_TEMP_FOLDER = "Error occured while creating a temp folder";
    public static final String ERROR_CREATING_FILE = "Error occured while creating file from byte array";
    public static final String ERROR_SFTP_TRANSFER = "Error occured while transferring file to sftp";

    public static final String INVALID_SFTP_ERROR = "Invalid Sftp error";
    public static final String INVALID_SFTP_MSG = "Invalid or Missing Sftp details";
    public static final String INVALID_FILE_NAME_ERROR = "Invalid file name error";
    public static final String INVALID_FILE_NAME_MSG = "Invalid file name for merged pdf";
    public static final String INVALID_FILE_ERROR = "Invalid file error";
    public static final String INVALID_FILE_MSG = "Invalid data for merged pdf";
    public static final String MERGED_PDF = "mergedPdf";

    public static final String FILE_FORMAT = "file_format";
    public static final String SFTP_DIRECTORY = "sftp_dir";
    public static final String SFTP_FILENAME = "sftp_Filename";
    public static final String SFTP_USERNAME = "sftp_username";
    public static final String SFTP_USERNAME_ARC = "sftp_username_arc";
    public static final String SFTP_PW_ARC = "sftp_pw_arc";
    public static final String SFTP_PW = "sftp_pw";
    public static final String SFTP_HOSTNAME = "sftp_hostname";
    public static final String SFTP_FILE_LIST = "sftp_filelist";
    public static final String SFTP_ARCHIVE_DIRECTORY = "sftp_archive_dir";
    public static final String MAX_SFTP_TRIES = "maxSftpTries";
    public static final String RETRY_TIME_SECS = "retryTimeSecs";

    public static final String MERGED_FILE_NAME = "mergedFileName";
    public static final String FSID = "fsId";

    // TransformJsonFileWithTemplate
    public static final String JSON_FILE = "jsonFile";
    public static final String DOCUMENTS = "Documents";
    public static final String DOCUMENT_IDS_MESSAGE = "document_ids_message";
    public static final String RESPONSE_FILE_NAME_MESSAGE = "response_file_name_message";
    public static final String ADD_ORIGINAL_ZIP_FILENAME = "addOriginalZipFileName";
    public static final String METADATA_ADDED_TO_RESPONSE_FILE = "addedToResponseFile";

    public static final String EXECUTE_NEXT_PROCESS = "executeNextProcess";
    public static final String PROCESS_NAME = "processName";
    public static final String ENVIRONMENT = "environment";
    public static final String MISSING_FORMPDF_ATTACHMENTIDS_ERROR = "Missing formPdf and attachments Errror";
    public static final String MISSING_FORMPDF_ATTACHMENTIDS_MSG = "Invalid metadata.formData.files -  Missing files.formPdf And files.attachments ";
    public static final String ERROR_MSG_FOR_EMPTY_FORM_PDF = "There is No form pdf found ";
    public static final String ERROR_MSG_FOR_EMPTY_ATTACHMENT_LIST = "No Attachment or Empty Attachment List";
    public static final String ERROR_MSG_FOR_EMPTY_ZERO_BYTE_ARRAY_FILE = "There is zero byte or empty file uploaded";
    public static final String KEY_FORM_PDF = "formPdf";
    public static final String KEY_ATTACHMENT = "attachment";
    public static final String KEY_ZERO_BYTE = "zeroByte";
    public static final String EMPTY_ATTACHMENT_FILE_NAME = "emptyAttachment.txt";
    public static final String CREDENTIAL_LIST = "credentialList";
    public static final String TOKEN_LIST = "tokenList";
    public static final String EMAIL_FROM = "emailFrom";
    public static final String EMAIL_RECIPIENT = "emailRecipient";
    public static final String EMAIL_DETAILS = "emailDetails";
    public static final String EMAIL_BODY = "emailBody";
    public static final String DOCUMENT_ATTACHMENTS = "documentAttachments";
    public static final String TOKEN_LIST_MESSAGE = "token_list_message";
    public static final String OUTPUT_FILE_DIR_MESSAGE = "output_file_directory_message";
    // cleanupFilesCreateACKProcess
    public static final String CLEANUP_PROCESS_KEY = "processCleanupFilesCreateACK";
    public static final String PROCESSOR_TRANSACTION_ID = "processorTransactionId";
    public static final String PROCESSOR_TRANSACTION = "processorTransaction";
    public static final String CSV_PROCESSOR_TRANSACTION = "csvProcessorTransaction";
    public static final String HOST_NAME_DESTINATION = "host_name_destination";
    public static final String USER_NAME_DESTINATION = "username_destination";
    public static final String USER_CREDENTIALS_DESTINATION = "pw_destination";
    public static final String FTP_ROOT_DIR = "ftp_rootdir";
    public static final String FTP_ACK_DIR = "ftp_ackdir";
    public static final String FTP_ARCHIVE_DIR = "ftp_archivedir";
    public static final String SFTP_ROOT_DIRECTORY = "sftp_root_dir";
    public static final String SFTP_ACK_DIRECTORY = "sftp_ack_dir";
    public static final String ACK_FLAG = "ack_flag";
    public static final String ACK_ZIP_FILE_EXTENSION = "_ack.zip";
    public static final String ACK_SUMMARY_FILE_EXTENSION = "_ack.summary";
    public static final String ACK_FILE = "ack_file";
    public static final String OUTCOME_KEY = "outcome";
    public static final String ERROR_KEY = "error";
    public static final String CLEANUP_FLAG = "cleanup_flag";
    public static final String E_DELIVERY_ERROR = "eDeliveryError";
    public static final String EFT_IND = "EFT_Ind";
    public static final String IND_835 = "Ind_835";
    public static final String SKIP_EFT_IND = "skipEFTIndFlag";
    public static final String BOUNCE_EMAIL_CHECK_EFT_IND = "bounceEmailCheckEFTIND";
    public static final String GENERATE_SINGLE_ACK_SUMMARY_FILE_FLAG = "generateSingleAckSummaryFile";
    public static final String ACK_WITH_ERRORS_ONLY = "ackWithErrorsOnlyFile";
    // Required Field Process
    public static final String RULES = "rules";
    public static final String SEND_TO_DOCVAULT = "sendToDocVault";
    public static final String SEND_TO_SHUTTERFLY = "sendToShutterfly";
    public static final String SEND_TO_DOCVAULT_MESSAGE = "send_to_docvault_message";
    public static final String SEND_TO_SHUTTERFLY_MESSAGE = "send_to_shutterfly_message";
    public static final String CRITERIA = "criteria";
    public static final String REQUIRED_FIELDS = "requiredFields";
    public static final String TRUE = "true";
    public static final String FALSE = "false";
    public static final String DOCVAULT_OAUTH_URL = "docvaultOauthUrl";

    //PostDocument to DocLib
    public static final String DOCLIB_OAUTH_URL = "docLibOauthUrl";
    public static final String DOCLIB_TEMPLATE_NAME = "docLibTemplateName";
    public static final String DOCLIB_CLIENT_ID = "docLibClientId";
    public static final String DOCLIB_CLIENT_SECRET = "docLibClientSecret";
    public static final String DOCLIB_REST_URL = "docLibRestUrl";
    public static final String DOCLIB_PUT_URL = "docLibPutUrl";
    public static final String METADATA_DOCLIB_API_RESPONSE = "docLibAPIResponse";
    public static final String METADATA_DOCLIB_UPLOAD_DATE = "docLibUploadDate";
    public static final String METADATA_DOCSENTTO_DOCLIB = "DocLib";
    public static final String DOCLIB_API_RESPONSE_SUCCESS_MESSAGE = "doclib_api_response_success_message";
    public static final String DOCLIB_API_RESPONSE_ERROR_MESSAGE = "doclib_api_response_error_message";
    public static final String SLA_TIME = "slaTime";

    public static final String PROCESSOR_TRANSACTION_LIST_ID = "processorTransactionListId";
    //Sftp process
    public static final String SFTP_PROCESS_KEY = "sftpProcess";
    
    public static final String SFTP_ZIP_FILE_PROCESS_KEY = "sftpUnzipProcess";
    //Unzip file process
    public static final String UNZIP_FILE_PROCESS_KEY = "processFileUnzip";
    
    public static final String DOCID = "docId";
    public static final String DOCUMENT_ID = "documentId";
    public static final String DOCUMENT_IDS = "documentIds";
    public static final String DOCLIB_PUT_DOCUMENT_IDS = "docLibPutDocumentIds";

    // SendDocumentTransactionEmail
    public static final String EMAIL_METADATA_FORM_NAME = "name";
    public static final String EMAIL_METADATA_TRANSACTION_ID = "transactionID";
    public static final String EMAIL_BODY_CONTENT = "Hello, \n\n We have received below transaction in the FDS/form center-";
    public static final String EMAIL_BODY_CONTENT_TRANSACTION_ID = "Transaction ID";
    public static final String SEND_DOCUMENT_TRANSACTION_EMAIL_MESSAGE = "send_document_transaction_email_message";
    public static final String SEND_DOCUMENT_TRANSACTION_EMAIL_FAILURE_MESSAGE = "Required Fields Transaction ID OR form name missing for document ID: ";

    public static final String MATCH_CRITERIA = "match_criteria";
    public static final String COMPANION_TEMPLATE_ID = "companion_template_id";
    public static final String DOCUMENT_UPDATE_FLAG_VALUE = "document_update_flag_value";
    public static final String RESOLVE_IN_COMPLETION_PROCESSOR_TRANSACTION_INTERVAL = "resolveIncompleteProcessorTransactionInterval";
    public static final String TOTAL_RECORDS_TO_FETCH = "totalRecords";
    // Companion file updates
    public static final String CREATE_ORIGINAL_COMPANION_FILE = "createOriginalCompanionFile";
    public static final String ORIGINAL_COMPANION_FILENAME = "originalCompanionFileName";
    public static final String DOCUMENT_UPDATE_ELEMENT_PATH = "document_update_element_path";
    // Email Alert Workflow
    public static final String PROCESSOR_TRANSACTION_METADATA_FLAG_PATH = "processor_transaction_metadata_flag_path";
    public static final String PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE = "processor_transaction_metadata_flag_value";
    public static final String PROCESSOR_TRANSACTIONS = "ProcessorTransactions";
    // Attachment retry
    public static final String ATTACHMENT_RETRIES = "3";
    public static final String ATTACHMENT_RETRIES_SLEEP_TIME = "ATTACHMENT_RETRIES_SLEEP_TIME";
    public static final String ATTACHMENT_RETRIES_SLEEP_TIME_VALUE = "1000";
    public static final String ATTACHMENT_EXECUTED_SUCCESSFULLY = "Attachment retrieved successfully after retrying";
    public static final String ATTACHMENT_FAILED = "Attachment retrieval failed after: %s retry/retries ";
    public static final String ATTACHMENT_RETRYING = "Attachment retrival retrying: %s";
    // Post Card Indicator
    public static final String POST_CARD_IND = "postCardInd";
    // Post Card Indicator
    public static final String IS_POST_CARD = "isPostCard";
    // Shutterfly Documents fileName
    public static final String FDS_NO_RPRNT_APPLICATION_NAME = "FDS_NO_RPRNT";
    public static final String FDS_RPRNT_APPLICATION_NAME = "FDS_RPRNT";
    // PEN
    public static final String PEN_API_URL = "PENAPIUrl";
    public static final String CATEGORY = "category";
    public static final String PEN_API_MULTI_CLOUD_URL = "PENAPIMultiCloudUrl";
    public static final String PEN_OAUTH_URL = "PENOauthUrl";
    public static final String PEN_APP_ID = "PENAppId";
    public static final String PEN_APP_SECRET= "PENAppSecret";
    public static final String PEN_GRANT_TYPE = "PENGrantType";
    
    //Appeal
    public static final String NGSID = "ngsId";
    public static final String CHECK_DOCUMENT_CRITERIA = "search_criteria_flag";
    public static final String PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP = "printServicesManifestGroupedList";
    /* Bounced provider email address workflow */
    public static final String DATE_EMAIL_SENT = "dateEmailSent";
    public static final String METADATA_DATE_EMAIL_SENT = "metadata.dateEmailSent";
    public static final String LAST_DATE_EMAIL_SENT_LIST = "lastDateEmailSentList";

    public static final String SEND_EMAIL_NOTIFICATIONS = "sendEmailNotifications";
    public static final String METADATA_SEND_EMAIL_NOTIFICATIONS = "metadata.sendEmailNotifications";

    public static final String STOP_PROCESSING_KEY = "stop";
    public static final String TAG_LINE = "tagLine";
    public static final String TXT_FINAL_EXTENSION = ".txt";
    public static final String CMP_FINAL_EXTENSION = ".cmp";
    public static final String ZIP_FINAL_EXTENSION = ".zip";
    public static final String XML_FINAL_EXTENSION = ".xml";

    public static final String PATIENT_FIRST_NAME = "patientFirstName";
    public static final String PATIENT_LAST_NAME = "patientLastName";
    public static final String PATIENT_DATE_OF_BIRTH = "patientDateOfBirth";
    public static final String PROVIDER_NAME = "providerName";
    public static final String PHYSICIAN_NAME = "physicianName";
    public static final String PROVIDER_FULL_NAME = "ProviderFullName";
    public static final String PROVIDER_FIRST_NAME = "ProviderFirstName";
    public static final String PROVIDER_LAST_NAME = "ProviderLastName";
    public static final String PROVIDER_CITY = "ProviderCity";
    public static final String PROVIDER_STATE = "ProviderState";
    public static final String PROVIDER_ZIP = "ProviderZip";
    public static final String PROVIDER_ZIP4 = "ProviderZip4";
    public static final String PROVIDER_COUNTY = "ProviderCounty";
    public static final String PROVIDER_ADDRESS_LINE_1 = "ProviderAddressLine1";
    public static final String PROVIDER_ADDRESS_LINE_2 = "ProviderAddressLine2";
    public static final String GROUP_NAME = "GroupName";
    public static final String PROVIDER_DATA = "ProviderData";
    public static final String UNIQUE_ID = "UniqueID";
    public static final String PROVIDER_TYPE = "providerType";


    public static final String PASS_THRU_DATA = "PassThruData";
    public static final String LETTER_HISTORY_ID = "LetterHistoryID";
    public static final String HISTORY_ID = "HISTORYID";
    public static final String CHECK_AMT = "CheckAmt";
    public static final String CHECK_TRACE_NUMBER = "CheckTraceNumber";
    public static final String MAIL_TO_ADDRESSONE = "MailToAddress1";
    public static final String MAIL_TO_ADDRESSTWO = "MailToAddress2";
    public static final String MAIL_TO_ADDRESSTHREE = "MailToAddress3";
    public static final String MAIL_TO_ADDRESSFOUR = "MailToAddress4";
    public static final String MAIL_TO_ADDRESSFIVE = "MailToAddress5";
    public static final String MAIL_TO_ADDRESSSIX = "MailToAddress6";
    public static final String CONFIGKEY = "CONFIGKEY";
    public static final String CREATE_APPLICATION = "createApplication";
    public static final String EDELIVERY_ERROR = "eDeliveryError";
    public static final String EMAIL_ADDRESS = "EmailAddress";
    public static final String RECORD_TERMINATOR_CHAR = "\r\n";
    public static final String INGEST_PATH_PROPERTY_NAME = "INGEST_ROOT";
    public static final String DELIVERY_METHOD_EMAIL = "E";
    public static final String ORIGNIAL_COMPANION_FILE_RECORDS = "originalCompanionFileRecords";
	public static final Object BARCODE = "BARCODE";
	public static final Object DIV = "DIV";
	public static final Object MEMBER_NUMBER = "MEMBER NUMBER";
	public static final Object MEMBER_NAME = "MEMBER NAME";
	public static final Object CLAIM_NUMBER = "CLAIM NUMBER";
	public static final Object MEDIA_TYPE = "MEDIA TYPE";
	public static final Object CLAIM_SYSTEM = "CLAIM SYSTEM";
	public static final Object MEMBER_NUMBER_CAMEL = "memberNumber";
	public static final Object MEMBER_NAME_CAMEL = "memberName";
	public static final Object CLAIM_NUMBER_CAMEL = "claimNumber";
	public static final Object MEDIA_TYPE_CAMEL = "mediaType";
	public static final Object CLAIM_SYSTEM_CAMEL = "claimSystem";
	public static final Object SEND_COMPANION_FILE_UNREADABLE_EMAIL="sendCompanionFileUnreadableEmail";
	public static final Object SEND_COMPANION_FILE_MISSING_EMAIL="sendCompanionFileMissingEmail";
	public static final Object COMPANION_FILE_DATE_RECEIVED="companionFileDateReceived";
	public static final String PROCESSOR_TRANSACTIONS_METADATA = "processorTransactionMetadata";
	public static final String RETRIEVE_CORPORATE_MPIN = "retrieveCorporateMPINv2Process";
	
	//USP Claims Response File Api Notify 
	
	public static final String USPCLAIMS_REST_URL="USPClaimsRestUrl";
	public static final String NOTIFY_API_OAUTH_URL="notifyApiOauthUrl";
	public static final String NOTIFY_API_CLIENT_ID="notifyApiClientId";
	public static final String NOTIFY_API_CLIENT_SECRET="notifyApiClientSecret";
	
	
	public static final String CLIENT_NAME="clientName";
	
	
	//CreateMetadataFiles
	
	public static final String PROVIDERCOUNTRY = "ProviderCountry";
	public static final String PROVIDERPROVINCE = "ProviderProvince";
	public static final String HOST_NAME_SOURCE = "host_name_source";
	public static final String USERNAME_SOURCE = "username_source";
	public static final String PW_SOURCE = "pw_source";
	public static final String PW_DESTINATION = "pw_destination";

    //Kafka constants
    public static final String CONFIG_SECURITY_PROTOCOL     		    = "security.protocol";
    public static final String CONFIG_SSL_TRUSTSTORE_LOCATION     		= "ssl.truststore.location";
    public static final String CONFIG_SSL_KEYSTORE_LOCATION     		= "ssl.keystore.location";
    public static final String CONFIG_SSL_TRUSTSTORE_PASSWORD     		= "ssl.truststore.password";
    public static final String CONFIG_SSL_KEYSTORE_PASSWORD     		= "ssl.keystore.password";
    public static final String SSL                                      = "SSL";
	public static final String PROCCESSOR_TRANSACTIONS = "ProcessorTransactions";
    public static final String SKIP_DOCUMENT_GROUPING = "skipDocumentGrouping";


    private Workflow() {
        throw new AssertionError("cannot instantiate");
    }
}