package com.optum.ppl.kafka.service.template;

public enum Templates {
	/**
	 * template method name should be same. For eg: checkWritePRAResponse,
	 * mergedMetaDataTemplate are present as method in allTemplates.stg
	 */
	
	
	KAFKA_RESPONSE_DOCUMENT("KafkaResponseDocument"),
	KAFKA_MNR_DOCUMENT("KafkaMnRDocument"),
	ALINK_KAFKA_TEMPLATE("AlinkKafkaTemplate"),
	CNS_KAFKA_MESSAGE("CNSKafkaMessage"),
	ATS_KAFKA_DOCUMENT("ATSKafkaDocument"),
	GPS_KAFKA_DOCUMENT("KafkaGPSDocument"),
	KAFKA_CONSUMER_ENGINEERING_DOCUMENT("KafkaConsumerEngineering"),
	TRACKIT_KAFKA_TEMPLATE("TrackItConsumer");
	


	private final String template;

	Templates(String template) {
		this.template = template;
	}

	public String getTemplate() {
		return this.template;
	}
}
