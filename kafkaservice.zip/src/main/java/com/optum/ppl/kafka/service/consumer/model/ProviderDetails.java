package com.optum.ppl.kafka.service.consumer.model;

public class ProviderDetails {
	
    private String primaryCareProviderFirstName;
    private String primaryCareProviderLastName;
    private String primaryCareProviderCorpMpin;
    private String primaryCareProviderTin;
    private String referredToProviderFirstName;
    private String referredToProviderLastName;
    private String referredToProviderTin;
    private String referredToProviderCorpMpin;
    private String referredToProviderId;
    
	public String getPrimaryCareProviderFirstName() {
		return primaryCareProviderFirstName;
	}
	public void setPrimaryCareProviderFirstName(String primaryCareProviderFirstName) {
		this.primaryCareProviderFirstName = primaryCareProviderFirstName;
	}
	public String getPrimaryCareProviderLastName() {
		return primaryCareProviderLastName;
	}
	public void setPrimaryCareProviderLastName(String primaryCareProviderLastName) {
		this.primaryCareProviderLastName = primaryCareProviderLastName;
	}
	public String getPrimaryCareProviderCorpMpin() {
		return primaryCareProviderCorpMpin;
	}
	public void setPrimaryCareProviderCorpMpin(String primaryCareProviderCorpMpin) {
		this.primaryCareProviderCorpMpin = primaryCareProviderCorpMpin;
	}
	public String getPrimaryCareProviderTin() {
		return primaryCareProviderTin;
	}
	public void setPrimaryCareProviderTin(String primaryCareProviderTin) {
		this.primaryCareProviderTin = primaryCareProviderTin;
	}
	public String getReferredToProviderFirstName() {
		return referredToProviderFirstName;
	}
	public void setReferredToProviderFirstName(String referredToProviderFirstName) {
		this.referredToProviderFirstName = referredToProviderFirstName;
	}
	public String getReferredToProviderLastName() {
		return referredToProviderLastName;
	}
	public void setReferredToProviderLastName(String referredToProviderLastName) {
		this.referredToProviderLastName = referredToProviderLastName;
	}
	public String getReferredToProviderTin() {
		return referredToProviderTin;
	}
	public void setReferredToProviderTin(String referredToProviderTin) {
		this.referredToProviderTin = referredToProviderTin;
	}
	public String getReferredToProviderCorpMpin() {
		return referredToProviderCorpMpin;
	}
	public void setReferredToProviderCorpMpin(String referredToProviderCorpMpin) {
		this.referredToProviderCorpMpin = referredToProviderCorpMpin;
	}
	public String getReferredToProviderId() {
		return referredToProviderId;
	}
	public void setReferredToProviderId(String referredToProviderId) {
		this.referredToProviderId = referredToProviderId;
	}

    
}
