package com.optum.ppl.kafka.service;

import java.util.HashMap;
import java.util.Map;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

@Configuration
public class CustomKafkaConsumerConfig {

    @Value("${kafkaGroupIdDoc360}")
    private String defaultGroupId;

    @Value("${Doc360KafkaConsumerBootstrapServers}")
    private String bootstrapServers;

    @Value("${Doc360.security.protocol}")
    private String securityProtocol;

    @Value("${Doc360ConsumerKeystorePath}")
    private String keystoreLocation;

    @Value("${Doc360ConsumerKeystorePassword}")
    private String keystorePassword;

    @Value("${Doc360ConsumerTruststoreLocation}")
    private String truststoreLocation;

    @Value("${Doc360ConsumerTruststorePassword}")
    private String truststorePassword;

    @Bean
    public ConsumerFactory<String, String> documentConsumerFactory() {
        Map<String, Object> props = new HashMap<>();
        
        // Infrastructure and Connection
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, defaultGroupId); 
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.StringDeserializer.class);
       
        // SSL Configurations
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, securityProtocol);
        props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, keystoreLocation);
        props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keystorePassword);
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, truststoreLocation);
        props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, truststorePassword);
        
        return new DefaultKafkaConsumerFactory<>(props);
    }

    @Bean("secureKafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> secureKafkaListenerContainerFactory(
            ConsumerFactory<String, String> documentConsumerFactory) { 
        
        ConcurrentKafkaListenerContainerFactory<String, String> factory = 
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(documentConsumerFactory);
        return factory;
    }
}
