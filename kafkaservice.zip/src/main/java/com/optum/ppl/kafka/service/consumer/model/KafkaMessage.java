package com.optum.ppl.kafka.service.consumer.model;

public class KafkaMessage {
	
    private MemberInfo memberInfo;
    private PlanDetails planDetails;
    private ProviderDetails providerDetails;
    private ReferralDetails referralDetails;
    
    public KafkaMessage() {}
    
	public MemberInfo getMemberInfo() {
		return memberInfo;
	}
	public void setMemberInfo(MemberInfo memberInfo) {
		this.memberInfo = memberInfo;
	}
	public PlanDetails getPlanDetails() {
		return planDetails;
	}
	public void setPlanDetails(PlanDetails planDetails) {
		this.planDetails = planDetails;
	}
	public ProviderDetails getProviderDetails() {
		return providerDetails;
	}
	public void setProviderDetails(ProviderDetails providerDetails) {
		this.providerDetails = providerDetails;
	}
	public ReferralDetails getReferralDetails() {
		return referralDetails;
	}
	public void setReferralDetails(ReferralDetails referralDetails) {
		this.referralDetails = referralDetails;
	}

    @Override
    public String toString() {
        return "KafkaMessage{" +
                "memberInfo=" + memberInfo +
                ", planDetails=" + planDetails +
                ", providerDetails=" + providerDetails +
                ", referralDetails=" + referralDetails +
                '}';
    }
}
