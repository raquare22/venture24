package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class AbstractDocumentConsumer {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractDocumentConsumer.class);

    @Autowired
    protected DocumentMetaDataService documentMetaDataService;

    
    protected abstract int getSpaceId();

    protected void processMessage(ConsumerRecord<String, String> message) {
       
        DocumentMetaData document = null;
        int spaceId = getSpaceId();

        try {
            if (message.value() == null || message.value().isEmpty()) {
                LOGGER.warn("Kafka Consumer --> received null or empty message, kafkaKey={}", Encode.forJava(message.key()));
                return;
            }

            org.bson.Document metadata = org.bson.Document.parse(message.value());
            document = new DocumentMetaData();
            document.setMetadata(metadata);
            document.setStatus(MetaDataStatus.NEW);
                

            if (metadata.containsKey("globalDocumentId")) {
                document.setDoc360DocumentId(metadata.getString("globalDocumentId"));
            }
            if (metadata.containsKey("documentClass")) {
                document.setDoc360DocClass(metadata.getString("documentClass"));
            }

            
           String documentId = documentMetaDataService.insertDocumentWithSpaceId(document, spaceId);
            LOGGER.info("Successfully processed message for key={} in spaceId={} with documentId={}", Encode.forJava(message.key()), spaceId, documentId);

        } catch (Exception e) {
            LOGGER.error("Error processing Kafka message, Key={} in spaceId={} : {}", Encode.forJava(message.value()),spaceId, e.getMessage());
        }
    }
}

