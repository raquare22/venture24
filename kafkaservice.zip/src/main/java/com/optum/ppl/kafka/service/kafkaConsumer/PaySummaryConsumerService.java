package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.paysummary", havingValue = "true")
public class PaySummaryConsumerService extends AbstractDocumentConsumer {

    @Value("${PaymentSummary_SPACEID}")
    private int paySummary_spaceId;

    @Override
    protected int getSpaceId() {
        return this.paySummary_spaceId;
    }

    @KafkaListener(
            topics = "${spring.kafka.topic.paySummary}",
            containerFactory = "secureKafkaListenerContainerFactory" 
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message);
    }
}
