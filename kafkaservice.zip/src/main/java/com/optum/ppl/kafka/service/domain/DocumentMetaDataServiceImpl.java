package com.optum.ppl.kafka.service.domain;

import com.fasterxml.jackson.core.JsonProcessingException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.result.UpdateResult;
import com.optum.ppl.kafka.service.beans.ProviderDocument;
import com.optum.ppl.kafka.service.exception.InvalidExpressionException;
import com.optum.ppl.kafka.service.model.MultiPutResponse;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import com.optum.ppl.kafka.service.util.DocumentUtil;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

@Service
public class DocumentMetaDataServiceImpl implements DocumentMetaDataService {
	
	@Autowired 
	private DocumentUtil documentUtil;
	
	static final Logger logger = LoggerFactory.getLogger(DocumentMetaDataServiceImpl.class);

	private static final String DATE_MODIFIED = "dateModified";
	private static final String DATE_CREATED = "dateCreated";
	private static final String APP_IDENTIFIER = "appIdentifier";
	private static final String EXTERNAL_ID = "externalId";
	private static final String SPACE_ID = "spaceId";
	private static final String METADATA = "metadata";
	private static final String STATUS = "status";
	private static final String CASE_NUMBER = "caseNumber";
	private static final String ID = "id";
	private static final String ERROR_MESSEGAE = "errorMessage";
	private static final String TRANSACTION_ID = "transactionId";
	private static final String REVISIONS = "revisions";
	private static final String DOCUEMNT_ATTACHMENTS = "documentAttachments";
	private static final String QUERY_STRING = "{} query={}";
	private static final String QUERY_EXCEPTION_STRING = "{} query={} {}";
	private static final String DOCUMENT_COLLECTION = "document";
	private static final String PDO_DOCUMENT_COLLECTION = "PDOdocument";
	private static final String CSV_DOCUMENT_COLLECTION = "CSVdocument";
	private static final String GET_DOCUMENT = "getDocumentMetaData";
	private static final String DOCUMENT = "document";
	private static final String GET_DOCUMENT_META_DATA = "getDocumentMetaData";
	
	private ObjectMapper mapper = new ObjectMapper();

	@Autowired
	MongoTemplate mongoTemplate;
	
	 @Value("${MONGO_QUERY_MAX_MILLIS:90000}")
	 String mongoQueryMaxMillis;

	public void setMongoQueryMaxMillis(String mongoQueryMaxMillis) {
        this.mongoQueryMaxMillis = mongoQueryMaxMillis;
    }

    @Override
	public DocumentMetaData saveDocumentMetaData(DocumentMetaData doc) {
		logger.debug("Entering saveDocumentMetaData");
		MongoOperations op = mongoTemplate;
		
		DocumentMetaData updatedDoc = null;
		
		String id = doc.getId();
		if (id == null || id.isEmpty()) {
			// document doesn't exist, insert
			updatedDoc = op.insert(doc, DOCUMENT_COLLECTION);
			return updatedDoc;
		} else {
			// check document already exists in collection
			DocumentMetaData document = mongoTemplate.findOne(query(where(ID).is(id)), DocumentMetaData.class, DOCUMENT_COLLECTION);
			if (document != null) {
				mongoTemplate.save(doc, DOCUMENT_COLLECTION);
				return doc;
			} else {
				updatedDoc = op.insert(doc, DOCUMENT_COLLECTION);
				return updatedDoc;
			}
		}
	}
    
	@Override
	public long saveDocumentMetaDataMulti(List<String> docIdList, Map<String, Object> updateMap) {

		long result = 0L;

		try {
			Query query = Query.query(Criteria.where("id").in(docIdList));
			Update update = new Update();
			for (var entry : updateMap.entrySet()) {
				update.set(entry.getKey(), entry.getValue());
			}
			UpdateResult updateResult = mongoTemplate.updateMulti(query, update, DocumentMetaData.class,
					DOCUMENT_COLLECTION);
			result = updateResult.getModifiedCount();
		} catch (Exception ex) {
			logger.error("exception to update doclist {} {}", StringUtils.join(docIdList, ","), ExceptionUtils.getStackTrace(ex));

		}
		return result;
	}

	@Override
	public DocumentMetaData savePDODocumentMetaData(DocumentMetaData doc) {
		logger.debug("Entering savePDODocumentMetaData");
		MongoOperations op = mongoTemplate;

		DocumentMetaData updatedDoc = null;

		String id = doc.getId();
		if (id == null || id.isEmpty()) {
			// document doesn't exist, insert
			updatedDoc = op.insert(doc, PDO_DOCUMENT_COLLECTION);
			return updatedDoc;
		} else {
			// check document already exists in collection
			DocumentMetaData document = mongoTemplate.findOne(query(where(ID).is(id)), DocumentMetaData.class, PDO_DOCUMENT_COLLECTION);
			if (document != null) {
				mongoTemplate.save(doc, PDO_DOCUMENT_COLLECTION);
				return doc;
			} else {
				updatedDoc = op.insert(doc, PDO_DOCUMENT_COLLECTION);
				return updatedDoc;
			}
		}
	}

	@Override
	public DocumentMetaData updatePDODocumentMetaData(DocumentMetaData doc, String id) {
		logger.debug("Entering updatePDODocumentMetaData");
		DocumentMetaData document = mongoTemplate.findOne(query(where(ID).is(id)), DocumentMetaData.class, PDO_DOCUMENT_COLLECTION);
		if (document != null) {
			DocumentUtil.updateDocumentMetaDataRevisions(document);
			DocumentUtil.updateDateModified(document);
			Document md = document.getMetadata();
			if (md == null) {
				Document metadata = new Document();
				doc.getMetadata().forEach((key, value) -> {
					metadata.append(key, value);
				});
				document.setMetadata(metadata);
			} else {
				doc.getMetadata().forEach((key, value) -> {
					md.append(key, value);
				});
			}
			mongoTemplate.save(document, PDO_DOCUMENT_COLLECTION);
		}
		return document;
	}
	
	@Override
	public DocumentMetaData updateDocMetaData(DocumentMetaData doc, String id) {
		logger.debug("Entering updatePDODocumentMetaData");
		DocumentMetaData document = mongoTemplate.findOne(query(where(ID).is(id)), DocumentMetaData.class, DOCUMENT_COLLECTION);
		if (document != null) {
			DocumentUtil.updateDocumentMetaDataRevisions(document);
			DocumentUtil.updateDateModified(document);
			Document md = document.getMetadata();
			if (md == null) {
				Document metadata = new Document();
				doc.getMetadata().forEach((key, value) -> {
					metadata.append(key, value);
				});
				document.setMetadata(metadata);
			} else {
				doc.getMetadata().forEach((key, value) -> {
					md.append(key, value);
				});
			}
			mongoTemplate.save(document, DOCUMENT_COLLECTION);
		}
		return document;
	}
	
	@Override
    public List<DocumentMetaData> insertMultiPDODocuments(List<DocumentMetaData> documentMetaDataList) {
		documentMetaDataList.forEach(doc -> documentUtil.appendDefaultValues(doc));
		return (List<DocumentMetaData>) mongoTemplate.insert(documentMetaDataList, PDO_DOCUMENT_COLLECTION);
	}
    
	
	@Override
    public MultiPutResponse updateMultiPDODocuments(List<String> docIds, DocumentMetaData document) {
		List<String> updated = new ArrayList<>();
		List<String> notUpdated = new ArrayList<>();
		for (String id : docIds) {
			var updatedDoc = updatePDODocumentMetaData(document, id);
			if (updatedDoc != null) {
				updated.add(updatedDoc.getId());
			} else {
				notUpdated.add(id);
			}
		}
		return new MultiPutResponse(updated, notUpdated);
	}
	
	@Override
	public DocumentMetaData getPDODocumentById(String id) {
		logger.debug("Entering getPDODocumentById");
		return mongoTemplate.findOne(query(where(ID).is(id)), DocumentMetaData.class, PDO_DOCUMENT_COLLECTION);
	}
	
	@Override
	public List<DocumentMetaData> getPDODocuments(Map<String, String> queryParams) throws JsonProcessingException {
		logger.debug("getPDODocuments --> ENTER");
		String searchCriteriaJson = mapper.writeValueAsString(queryParams);
		var query = new BasicQuery(searchCriteriaJson);		
		String spaceId = queryParams.get(SPACE_ID);
		if (StringUtils.isNotEmpty(spaceId) && StringUtils.isNumeric(spaceId)) {
			query.addCriteria(Criteria.where(SPACE_ID).is(Integer.parseInt(spaceId)));
		}
		logger.debug("getPDODocuments query={}", query);
		return mongoTemplate.find(query, DocumentMetaData.class, PDO_DOCUMENT_COLLECTION);
	}


	public DocumentMetaData getDocumentMetaData(String id) {
		logger.debug("Entering getDocumentMetaData");
		DocumentMetaData retVal = mongoTemplate.find(query(where(ID).is(id)), DocumentMetaData.class)
				.stream()
				.findFirst()
				.orElse(null);
		logger.debug("Leaving getDocumentMetaData");
		return retVal;
	}

	public DocumentMetaData getATSDocumentMetaData(String caseNum, int spaceId, int queryTimeWindow) {
		logger.debug("Entering getATSDocumentMetaData");
		Query query = query(where(SPACE_ID).is(spaceId).and(METADATA+"."+CASE_NUMBER).is(caseNum));
		String daysCreated7 = getPastDateString(queryTimeWindow);
		String daysCreatedNow = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS'Z'").format(new Date());
		addDateCreatedConstraintsToQuery(query, daysCreated7, daysCreatedNow);
		DocumentMetaData retVal = mongoTemplate.find(query, DocumentMetaData.class)
				.stream()
				.findFirst()
				.orElse(null);
		logger.debug("Leaving getATSDocumentMetaData");
		return retVal;
	}
	
	public DocumentMetaData getReferralDocumentMetaData(String requestId, int spaceId, String referralStatus, int queryTimeWindow) {
		logger.debug("Entering getATSDocumentMetaData");
		Query query = query(where(SPACE_ID).is(spaceId).and(METADATA+"."+"requestId").is(requestId).and(METADATA+"."+"referralStatus").is(referralStatus));
		String daysCreated7 = getPastDateString(queryTimeWindow);
		String daysCreatedNow = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS'Z'").format(new Date());
		addDateCreatedConstraintsToQuery(query, daysCreated7, daysCreatedNow);
		DocumentMetaData retVal = mongoTemplate.find(query, DocumentMetaData.class)
				.stream()
				.findFirst()
				.orElse(null);
		logger.debug("Leaving getATSDocumentMetaData");
		return retVal;
	}

	public List<DocumentMetaData> getGPSDocumentMetaData(String key, int spaceId, int queryTimeWindow) {
		logger.debug("Entering getGPSDocumentMetaData");
		Query query = query(where(SPACE_ID).is(spaceId).and(METADATA+"."+TRANSACTION_ID).is(key));
		String daysCreatedPast = getPastDateString(queryTimeWindow);
		String daysCreatedNow = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS'Z'").format(new Date());
		addDateCreatedConstraintsToQuery(query, daysCreatedPast, daysCreatedNow);
		List<DocumentMetaData> retVal = mongoTemplate.find(query, DocumentMetaData.class, DOCUMENT_COLLECTION);
		logger.debug("Leaving getGPSDocumentMetaData");
		return retVal;
	}
	
	public List<DocumentMetaData> getDocumentMetaDataList(List<String> ids) {
		logger.debug("Entering getDocumentMetaDataList");
		List<DocumentMetaData> retVal = mongoTemplate.find(query(where(ID).in(ids)), DocumentMetaData.class, DOCUMENT_COLLECTION);
		logger.debug("Leaving getDocumentMetaDataList");
		return retVal;
	}

	public DocumentMetaData getCsvDocumentMetaData(String id) {
		logger.debug("Entering getCsvDocumentMetaData");
		DocumentMetaData retVal = mongoTemplate.find(query(where(ID).is(id)), DocumentMetaData.class, CSV_DOCUMENT_COLLECTION)
				.stream()
				.findFirst()
				.orElse(null);
		logger.debug("Leaving getCsvDocumentMetaData");
		return retVal;
	}

	/**
	 * Used to set mongoTemplate in JUnit test
	 * 
	 * @param mongoTemplate
	 */
	public void setMongoTemplate(MongoTemplate mongoTemplate) {
		this.mongoTemplate = mongoTemplate;
	}

	public DocumentMetaData updateDocumentMetaDataStatus(String docId, String status) {
		var query = new Query();
		query.addCriteria(Criteria.where(ID).is(docId));
		MongoOperations op = mongoTemplate;
		DocumentMetaData docMetaData = op.findOne(query, DocumentMetaData.class);
		if (docMetaData == null) {
			return docMetaData;
		}
		docMetaData.setStatus(status);
		docMetaData.setDateModified(new java.util.Date());
		op.save(docMetaData);
		return docMetaData;
	}

	public DocumentMetaData updateDocumentMetaDataStatus(String docId, String status, String trxId) {

		return updateDocumentMetaDataStatus(docId, status, trxId, null); // call
																			// version
																			// that
																			// writes
																			// error
																			// message

	}

	public DocumentMetaData updateDocumentMetaDataStatus(String docId, String status, String trxId,
			String errorMessage) {
		logger.debug("Entering updateDocumentMetaDataStatus");
		if (StringUtils.isEmpty(status) || StringUtils.isEmpty(docId) || StringUtils.isEmpty(trxId)) {
			return null;
		}
		var query = new Query();
		query.addCriteria(Criteria.where(ID).is(docId));
		MongoOperations op = mongoTemplate;
		DocumentMetaData docMetaData = op.findOne(query, DocumentMetaData.class);
		if (docMetaData == null) {
			return docMetaData;
		}
		docMetaData.setStatus(status);
		docMetaData.setErrorMessage(errorMessage);
		docMetaData.setTransactionId(trxId);
		docMetaData.setDateModified(new java.util.Date());
		op.save(docMetaData);
		logger.debug("Leaving updateDocumentMetaDataStatus");
		return docMetaData;
	}
	
	public DocumentMetaData updateReferralDocumentStatus(String docId, Document metadata) {
		logger.debug("Entering updateDocumentMetaDataStatus");
		if (metadata.isEmpty() || StringUtils.isEmpty(docId)) {
			return null;
		}
		var query = new Query();
		query.addCriteria(Criteria.where(ID).is(docId));
		MongoOperations op = mongoTemplate;
		DocumentMetaData docMetaData = op.findOne(query, DocumentMetaData.class);
		if (docMetaData == null) {
			return docMetaData;
		}
		docMetaData.setMetadata(metadata);
		docMetaData.setDateModified(new java.util.Date());
		op.save(docMetaData);
		logger.debug("Leaving updateDocumentMetaDataStatus");
		return docMetaData;
	}

	@Override
	public List<DocumentMetaData> getDocumentListById(String id) {
		return mongoTemplate.find(query(where(ID).is(id)), DocumentMetaData.class);
	}

	@Override
	public List<DocumentMetaData> getDocumentListByExternalId(String appId, String externalId) {
		return mongoTemplate.find(query(where(APP_IDENTIFIER).is(appId).and(EXTERNAL_ID).is(externalId)),
				DocumentMetaData.class);
	}

	@Override
	public List<DocumentMetaData> getDocumentListByExternalIdAndSpaceId(String externalId, int spaceId) {
		return mongoTemplate.find(query(where(EXTERNAL_ID).is(externalId).and(SPACE_ID).is(spaceId)),
				DocumentMetaData.class);

	}

	@Override
	public List<DocumentMetaData> getDocumentListMetadata(String appId, Map<String, String> metadataMap) {
		// Could check if size = 1 otherwise have to do more complex and
		// conditions
		String metaPath = null;
		String metaValue = null;

		if (MapUtils.isNotEmpty(metadataMap)) {
			var entry = metadataMap.entrySet().iterator().next();
			metaPath = entry.getKey();
			metaValue = entry.getValue();
			return mongoTemplate.find(query(where(APP_IDENTIFIER).is(appId).and(metaPath).is(metaValue)),
					DocumentMetaData.class);
		}
		/// Need to refactor for multiple queries with different Params
        return List.of();
	}

	@Override
	public List<DocumentMetaData> getDocumentListAppId(String appIdentifier) {
		return mongoTemplate.find(query(where(APP_IDENTIFIER).is(appIdentifier)), DocumentMetaData.class);

	}

	/**
	 * Method to Generate a Query to Get a List of Documents based on the list
	 * of criteria provided in the user request. A Query to list Documents by
	 * the appIdentifier and the Status is returned if there are no criteria.
	 * 
	 * @param appIdentifier
	 * @param status
	 * @return
	 */
	private Query generateListFilterQuery(List<Integer> spaceIdList, String status, Query query) {
		logger.debug("Entering generateListFilterQuery");
		var spaceIdCriteria = Criteria.where(SPACE_ID).in(spaceIdList);

		if (query == null) {
			query = new Query();
		}

		if (!"ALL".equals(status)) {
			spaceIdCriteria.and(STATUS).is(status);
		} else {
			String pattern = "/|" + 123 + "|/";
			spaceIdCriteria.and("CLAIMNUMBER").regex(pattern);
		}

		logger.debug("Leaving generateListFilterQuery");
		return query.addCriteria(spaceIdCriteria);
	}

	private static final List<SimpleDateFormat> dateFormatList = List.of(
	        new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
			new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS'Z'"),
			new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS"),
			new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
	);

	public Date convertISOStringToDate(String isoDate) {
		if (StringUtils.isNotEmpty(isoDate)) {
		    var itr = dateFormatList.iterator();
		    while (itr.hasNext()) {
		    	var format = itr.next();
		    	try {
		    		return format.parse(isoDate);
				} catch (ParseException e) {

				}
			}
		}
		return null;
	}


	public static String getPastDateString(Integer numberDaysPrevious) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS'Z'");
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, numberDaysPrevious);
		Date pastDate = calendar.getTime();
		return dateFormat.format(pastDate);
	}

	private void addDateCreatedConstraintsToQuery(Query query, String startCreationDate, String endCreationDate) {
		BiConsumer<String, Consumer<Date>> consume = (x, z) -> Stream.of(x)
				.filter(StringUtils::isNotEmpty)
				.map(this::convertISOStringToDate)
				.forEach(z);

		var dateCreatedCriteria = Criteria.where(DATE_CREATED);
		consume.accept(startCreationDate, dateCreatedCriteria::gte);
		consume.accept(endCreationDate, dateCreatedCriteria::lt);
		query.addCriteria(dateCreatedCriteria);
	}

	private void addDateConstraintsToQuery(Query query, String startCreationDate, String endCreationDate,
			String startModifiedDate, String endModifiedDate) {
		BiConsumer<String, Consumer<Date>> consume = (x, z) -> Stream.of(x)
				.filter(StringUtils::isNotEmpty)
				.map(this::convertISOStringToDate)
				.forEach(z);

		var dateCreatedCriteria = Criteria.where(DATE_CREATED);
		consume.accept(startCreationDate, dateCreatedCriteria::gte);
		consume.accept(endCreationDate, dateCreatedCriteria::lt);
		query.addCriteria(dateCreatedCriteria);

		var dateModifiedCriteria = Criteria.where(DATE_MODIFIED);
		consume.accept(startModifiedDate, dateModifiedCriteria::gte);
		consume.accept(endModifiedDate, dateModifiedCriteria::lt);
		query.addCriteria(dateModifiedCriteria);
	}

	private Query addMetaDataConstarintsToQuery(Map<String, String> metaDataMap, Query query) {
		String metaPath = null;
		String metaValue = null;
		if (metaDataMap != null && !metaDataMap.isEmpty()) {
			Iterator<Entry<String, String>> metaDataMapIterator = metaDataMap.entrySet().iterator();
			while (metaDataMapIterator.hasNext()) {
				Entry<String, String> entry = metaDataMapIterator.next();
				metaPath = entry.getKey();
				metaValue = entry.getValue();
				query.addCriteria(Criteria.where(metaPath).is(metaValue));
			}
		}

		return query;
	}

	@Override
	public List<DocumentMetaData> getDocumentMetaDataListWithPagingNew(String status, List<Integer> spaceIdList, Criteria documentsQry,
																	   int startPosition, int countToReturn) {
		logger.debug("Entering getDocumentMetaDataListWithPagingNew");
		MongoOperations op = mongoTemplate;
		List<DocumentMetaData> amds;
		Query query = null;
		logger.debug("Space Id list: {}, Status: {}", spaceIdList, status);

		try {
			query = generateListFilterQuery(spaceIdList, status, query);

			query.addCriteria(documentsQry);

			query.with(Sort.by(Sort.Direction.ASC, DATE_CREATED)).skip(startPosition).limit(countToReturn);
			logger.debug(QUERY_STRING, "getDocumentMetaDataListWithPagingNew", query);

			// execute Query
			amds = op.find(query, DocumentMetaData.class);

			logger.debug("Record found: {}", amds.size());
			logger.debug("spaceIdList={}, ResultSet Size is {}", spaceIdList, amds.size());
			logger.debug("Leaving getDocumentMetaDataListWithPagingNew");
			return amds;
		} catch (Exception e) {
			logger.error(QUERY_EXCEPTION_STRING, "getDocumentMetaDataListWithPagingNew", query, ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}

	public List<ProviderDocument> getPDODocuments(Document criteriaDocument) {
		MongoOperations op = mongoTemplate;
		Query query = null;
		try {
			query = new BasicQuery(criteriaDocument).with(Sort.by(Sort.Direction.DESC, DATE_MODIFIED));
			return op.find(query, ProviderDocument.class, PDO_DOCUMENT_COLLECTION);
		} catch (Exception e) {
			logger.error(QUERY_EXCEPTION_STRING, "getPDODocuments", query, ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}

	@Override
	public List<DocumentMetaData> insertMultiDocuments(List<DocumentMetaData> documentMetaDataList) {
		documentMetaDataList.forEach(doc -> documentUtil.appendDefaultValues(doc));
		return (List<DocumentMetaData>) mongoTemplate.insert(documentMetaDataList, DOCUMENT_COLLECTION);
	}
	
	@Override
	public List<DocumentMetaData> insertMultiDocumentsWithSpaceId(List<DocumentMetaData> documentMetaDataList, int spaceId) {
		documentMetaDataList.forEach(doc -> documentUtil.appendDefaultValuesWithSpaceId(doc, spaceId));
		return (List<DocumentMetaData>) mongoTemplate.insert(documentMetaDataList, DOCUMENT_COLLECTION);
	}

	@Override
	public MultiPutResponse updateMultiDocuments(List<String> docIds, DocumentMetaData document) {
		List<String> updated = new ArrayList<>();
		List<String> notUpdated = new ArrayList<>();
		for (String id : docIds) {
			var updatedDoc = updateDocMetaData(document, id);
			if (updatedDoc != null) {
				updated.add(updatedDoc.getId());
			} else {
				notUpdated.add(id);
			}
		}
		return new MultiPutResponse(updated, notUpdated);
	}
	
	
	@Override
	public MultiPutResponse updateMultiDocument(List<String> docIds, DocumentMetaData document) {
		List<String> updated = new ArrayList<>();
		List<String> notUpdated = new ArrayList<>();
		for (String id : docIds) {
			var updatedDoc = putDocumentMetadata(document, id);
			if (updatedDoc != null) {
				updated.add(updatedDoc.getId());
			} else {
				notUpdated.add(id);
			}
		}
		return new MultiPutResponse(updated, notUpdated);
	}

	@Override
	public List<DocumentMetaData> getDocuments(Map<String, String> queryParams) throws JsonProcessingException {
		logger.debug("getDocuments --> ENTER");
		String searchCriteriaJson = mapper.writeValueAsString(queryParams);
		var query = new BasicQuery(searchCriteriaJson);
		String spaceId = queryParams.get(SPACE_ID);
		if (StringUtils.isNotEmpty(spaceId) && StringUtils.isNumeric(spaceId)) {
			query.addCriteria(Criteria.where(SPACE_ID).is(Integer.parseInt(spaceId)));
		}
		logger.debug("getDocuments query={}", query);
		return mongoTemplate.find(query, DocumentMetaData.class, DOCUMENT_COLLECTION);
	}


	@Override
	public DocumentMetaData updateDocumentMetaData(DocumentMetaData documentMetaData, String trxId) {
		
		logger.debug("Entering updateDocumentMetaData");
		DocumentMetaData savedDocumentMetaData = null;
		var status = documentMetaData.getStatus().toString();
		String docId = documentMetaData.getId();
		String errorMessage = documentMetaData.getErrorMessage();
		var documentAttachments = documentMetaData.getDocumentAttachments();
		if (StringUtils.isNotEmpty(status) && StringUtils.isNotEmpty(docId)
				&& StringUtils.isNotEmpty(trxId)) {
			var query = new Query();
			query.addCriteria(Criteria.where(ID).is(docId));
			MongoOperations op = mongoTemplate;
			savedDocumentMetaData = op.findOne(query, DocumentMetaData.class);
			if (savedDocumentMetaData != null) {
				savedDocumentMetaData.setStatus(status);
				savedDocumentMetaData.setTransactionId(trxId);
				savedDocumentMetaData.setDateModified(new java.util.Date());
				savedDocumentMetaData.setDocumentAttachments(documentAttachments);
				savedDocumentMetaData.setErrorMessage(errorMessage);
				op.save(savedDocumentMetaData);
			}
		}
		logger.debug("Leaving updateDocumentMetaData");
		return savedDocumentMetaData;
	}

	@Override
	public DocumentMetaData putDocumentMetadata(DocumentMetaData documentMetaData) {
		logger.debug("Entering putDocumentMetaData");
		MongoOperations op = mongoTemplate;
		String docId = documentMetaData.getId();

		var update = new Update();
		update.set(STATUS, documentMetaData.getStatus());
		update.set(DATE_MODIFIED, new java.util.Date());
		update.set(TRANSACTION_ID, documentMetaData.getTransactionId());
		update.set(REVISIONS, documentMetaData.getRevisions());

		if (MapUtils.isNotEmpty(documentMetaData.getMetadata())) {
			update.set(METADATA, documentMetaData.getMetadata());
		} else if (documentMetaData.getMetadata() != null && documentMetaData.getMetadata().isEmpty()) {
			update.unset(METADATA);
		}

		if (StringUtils.isNotEmpty(documentMetaData.getExternalId())) {
			update.set(EXTERNAL_ID, documentMetaData.getExternalId());
		} else {
			update.unset(EXTERNAL_ID);
		}

		if (StringUtils.isNotEmpty(documentMetaData.getErrorMessage())) {
			update.set(ERROR_MESSEGAE, documentMetaData.getErrorMessage());
		} else {
			update.unset(ERROR_MESSEGAE);
		}

		if (CollectionUtils.isNotEmpty(documentMetaData.getDocumentAttachments())) {
			update.set(DOCUEMNT_ATTACHMENTS, documentMetaData.getDocumentAttachments());
		}

		var retVal = Optional.ofNullable(op.findAndModify(query(where(ID).is(docId)), update,
				new FindAndModifyOptions().returnNew(true), DocumentMetaData.class)); // (query(where("id").is(docId)),
																						// DocumentMetaData.class);//
																						// (query(where("id").is(docId)),
																						// DocumentMetaData.class);

		if (logger.isDebugEnabled()) {
			logger.debug("Updated docId: {} New Status: {}", retVal.map(DocumentMetaData::getId).orElse("no id"), retVal.map(DocumentMetaData::getStatus)
					.map(String::valueOf).orElse("no status"));
		}
		logger.debug("Leaving putDocumentMetaData");

		return retVal.orElse(null);
	}
	
	
	@Override
	public DocumentMetaData putDocumentMetadata(DocumentMetaData documentMetaData,String docId) {
		logger.debug("Entering putDocumentMetaData");
		MongoOperations op = mongoTemplate;
		//String docId = docId;

		var update = new Update();
		update.set(STATUS, documentMetaData.getStatus());
		update.set(DATE_MODIFIED, new java.util.Date());
		update.set(TRANSACTION_ID, documentMetaData.getTransactionId());
		update.set(REVISIONS, documentMetaData.getRevisions());

		if (MapUtils.isNotEmpty(documentMetaData.getMetadata())) {
			update.set(METADATA, documentMetaData.getMetadata());
		} else if (documentMetaData.getMetadata() != null && documentMetaData.getMetadata().isEmpty()) {
			update.unset(METADATA);
		}

		if (StringUtils.isNotEmpty(documentMetaData.getExternalId())) {
			update.set(EXTERNAL_ID, documentMetaData.getExternalId());
		} else {
			update.unset(EXTERNAL_ID);
		}

		if (StringUtils.isNotEmpty(documentMetaData.getErrorMessage())) {
			update.set(ERROR_MESSEGAE, documentMetaData.getErrorMessage());
		} else {
			update.unset(ERROR_MESSEGAE);
		}

		if (CollectionUtils.isNotEmpty(documentMetaData.getDocumentAttachments())) {
			update.set(DOCUEMNT_ATTACHMENTS, documentMetaData.getDocumentAttachments());
		}

		var retVal = Optional.ofNullable(op.findAndModify(query(where(ID).is(docId)), update,
				new FindAndModifyOptions().returnNew(true), DocumentMetaData.class)); // (query(where("id").is(docId)),
																						// DocumentMetaData.class);//
																						// (query(where("id").is(docId)),
																						// DocumentMetaData.class);

		if (logger.isDebugEnabled()) {
			logger.debug("Updated docId: {} New Status: {}", retVal.map(DocumentMetaData::getId).orElse("no id"), retVal.map(DocumentMetaData::getStatus)
					.map(String::valueOf).orElse("no status"));
		}
		logger.debug("Leaving putDocumentMetaData");

		return retVal.orElse(null);
	}

	/**
	 * Input : searchCriteria can be NULL but not empty
	 * additionalFilters can be added as criteria, should be not NULL,
	 * Return List of documentMetaData
	 * throws InvalidExpressionException if documentFilter is null
	 */
	@Override
	public List<DocumentMetaData> getDocumentMetaData(String documentSearchCriteriaJson, Criteria documentFilter) throws InvalidExpressionException{
		logger.debug("DocumentMetaDataServiceImpl-->getDocumentMetaData-->ENTER");

		if(Objects.isNull(documentFilter))
			throw new InvalidExpressionException("filter should be logical query expression");
    	var query = new BasicQuery(documentSearchCriteriaJson).addCriteria(documentFilter);
		logger.debug(QUERY_STRING, GET_DOCUMENT, query);
		logger.debug("DocumentMetaDataServiceImpl-->getDocumentMetaData-->EXIT");

		try {
			return mongoTemplate.find(query, DocumentMetaData.class,DOCUMENT_COLLECTION);
		} catch (Exception e) {
			logger.error(QUERY_EXCEPTION_STRING, GET_DOCUMENT, query, ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}
	
	
	@Override
	public List<String> getDocumentMetaDataIds(String documentSearchCriteriaJson, Criteria documentFilter, Criteria uniqueMetadataQuery) 
			throws InvalidExpressionException {
		logger.debug("DocumentMetaDataServiceImpl-->getDocumentMetaData-->ENTER");

		if(Objects.isNull(documentFilter))
			throw new InvalidExpressionException("filter should be logical query expression");
    	var query = new BasicQuery(documentSearchCriteriaJson).addCriteria(documentFilter).addCriteria(uniqueMetadataQuery);
    	logger.debug(QUERY_STRING, GET_DOCUMENT, query);
		logger.debug("DocumentMetaDataServiceImpl-->getDocumentMetaData-->EXIT");
		List<String> idList = new ArrayList<>();
		try {
			List<DocumentMetaData> list = mongoTemplate.find(query, DocumentMetaData.class,DOCUMENT_COLLECTION);
			
			for (var doc : list) {
				idList.add(doc.getId());
			}
			
			return idList;
			
		} catch (Exception e) {
			logger.error(QUERY_EXCEPTION_STRING, GET_DOCUMENT, query, ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}

	@Override
	public List<DocumentMetaData> getCsvDocumentMetaData(String documentSearchCriteriaJson, Criteria documentFilter) throws InvalidExpressionException{
		logger.debug("DocumentMetaDataServiceImpl-->getDocumentMetaData-->ENTER");

		if(Objects.isNull(documentFilter))
			throw new InvalidExpressionException("filter should be logical query expression");
		var query = new BasicQuery(documentSearchCriteriaJson).addCriteria(documentFilter);
		logger.debug(QUERY_STRING, GET_DOCUMENT, query);
		logger.debug("DocumentMetaDataServiceImpl-->getDocumentMetaData-->EXIT");

		try {
			return mongoTemplate.find(query, DocumentMetaData.class, DOCUMENT_COLLECTION);
		} catch (Exception e) {
			logger.error(QUERY_EXCEPTION_STRING, GET_DOCUMENT, query, ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}


    @Override
    public DocumentMetaData updateDocumentMetadataFields(Map<String, Object> fieldsToUpdate, String documentId, String trxId) {
        MongoOperations op = mongoTemplate;
        var query = new Query(Criteria.where("id").is(documentId));
        var update = new Update();
        update.set(TRANSACTION_ID, trxId);
        update.set(DATE_MODIFIED, new Date());
        for (Entry<String, Object> entry : fieldsToUpdate.entrySet()) {
            update.set(entry.getKey(), entry.getValue());
        }
        return op.findAndModify(query, update, new FindAndModifyOptions().returnNew(true), DocumentMetaData.class);
    }
    
    @Override
	public List<DocumentMetaData> getDocumentMetaData(String documentSearchCriteriaJson, Criteria documentFilter, Integer countToReturn) throws InvalidExpressionException {
		logger.debug("DocumentMetaDataServiceImpl-->getDocumentMetaDataWithMaxDocuments-->ENTER");

		if(Objects.isNull(documentFilter))
			throw new InvalidExpressionException("filter should be logical query expresssion");
    	Query query = new BasicQuery(documentSearchCriteriaJson);
		query.addCriteria(documentFilter);
		query.limit(countToReturn);
		logger.debug(QUERY_STRING, "getDocumentMetaDataWithMaxDocuments", query);
		logger.debug("DocumentMetaDataServiceImpl-->getDocumentMetaDataWithMaxDocuments-->EXIT");
		
		try {
			return mongoTemplate.find(query, DocumentMetaData.class, DOCUMENT);
		} catch (Exception e) {
			logger.error(QUERY_EXCEPTION_STRING, GET_DOCUMENT_META_DATA, query, ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}

    @Override
    public DocumentMetaData deleteDocument(String id) {
    	 MongoOperations op = mongoTemplate;
         var update = new Update();
         update.set(STATUS, MetaDataStatus.DELETED);
        
         return op.findAndModify(query(where(ID).is(id)), update,
 				new FindAndModifyOptions().returnNew(true), DocumentMetaData.class);
    }

	@Override
	public List<DocumentMetaData> getDocumentMetaDataByZipFileName(String documentSearchCriteriaJson,
			Criteria documentsFilter, String zipFileName, int spaceId) throws InvalidExpressionException {
		
		logger.debug("DocumentMetaDataServiceImpl-->getDocumentMetaData-->ENTER");

		if(Objects.isNull(documentsFilter))
			throw new InvalidExpressionException("filter should be logical query expression");
		var query = new BasicQuery(documentSearchCriteriaJson).addCriteria(documentsFilter)
				.addCriteria(Criteria.where("metadata.zipFileName").is(zipFileName))
				.addCriteria(Criteria.where(SPACE_ID).is(spaceId));
		
		logger.debug(QUERY_STRING, GET_DOCUMENT, query);
		logger.debug("DocumentMetaDataServiceImpl-->getDocumentMetaData-->EXIT");

		try {
			return mongoTemplate.find(query, DocumentMetaData.class, DOCUMENT_COLLECTION);
		} catch (Exception e) {
			logger.error(QUERY_EXCEPTION_STRING, GET_DOCUMENT, query, ExceptionUtils.getStackTrace(e));
			throw e;
		}

	}
	
	@Override
    public String insertDocumentWithSpaceId(DocumentMetaData documentMetaData, int spaceId) {
        documentMetaData.setSpaceId(spaceId);
        mongoTemplate.insert(documentMetaData, DOCUMENT_COLLECTION);
        return documentMetaData.getId();
    }
}