package com.optum.ppl.kafka.service.consumer.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ReferralDetails {
	
	   
	    private String requestId;
	    private String specialty;
	    private String comments;
	    private List<String> diagnosisCodes;
	    
		public String getRequestId() {
			return requestId;
		}
		public void setRequestId(String requestId) {
			this.requestId = requestId;
		}
		public String getSpecialty() {
			return specialty;
		}
		public void setSpecialty(String specialty) {
			this.specialty = specialty;
		}
		public String getComments() {
			return comments;
		}
		public void setComments(String comments) {
			this.comments = comments;
		}
		public List<String> getDiagnosisCodes() {
			return diagnosisCodes;
		}
		public void setDiagnosisCodes(List<String> diagnosisCodes) {
			this.diagnosisCodes = diagnosisCodes;
		}
	    
	    

}
