package com.optum.ppl.kafka.service.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProviderGPS {

    private String providerId;
    private String npi;
    private String pcpName;
    private String taxId;
    private List<String> emailAddress;

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public String getNpi() {
        return npi;
    }

    public void setNpi(String npi) {
        this.npi = npi;
    }

    public String getPcpName() {
        return pcpName;
    }

    public void setPcpName(String pcpName) {
        this.pcpName = pcpName;
    }

    public String getTaxId() {
        return taxId;
    }

    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }

    public List<String> getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(List<String> emailAddress) {
        this.emailAddress = emailAddress;
    }

    @Override
    public String toString() {
        return "ProviderGPS{" +
                "providerId='" + providerId + '\'' +
                ", npi='" + npi + '\'' +
                ", pcpName='" + pcpName + '\'' +
                ", taxId='" + taxId + '\'' +
                ", emailAddress=" + emailAddress +
                '}';
    }
}
