package com.optum.ppl.kafka.service.template.java.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.kafka.model.*;
import com.optum.ppl.kafka.service.template.Templates;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class ATSKafkaDocumentTemplate extends TemplateHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ATSKafkaDocumentTemplate.class);

    @Override
    public String convertWithTemplate(String jsonString) {
        return "";
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return "";
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        var st = this.templateLoader.getTemplate(Templates.ATS_KAFKA_DOCUMENT);

        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> kafkaMessage = (Map<String, Object>) pojo;
        String key = (String) kafkaMessage.get("key");

        ATSKafka atsMsg = (ATSKafka) kafkaMessage.get("kafkaMessage");

        CaseInfo caseInfo = atsMsg.getCaseInfo();
        List<ClaimInfo> claimInfoList = caseInfo.getLstClaimInfo();
        MemberInfo memberInfo = caseInfo.getMemberInfo();

        if (claimInfoList != null && !claimInfoList.isEmpty()) {
            ClaimInfo claimInfoObj = claimInfoList.get(0);
            caseInfo.setMpin(claimInfoObj.getMpin());
            caseInfo.setTin(claimInfoObj.getBillingTaxID());
        } else {
            caseInfo.setMpin("");
            caseInfo.setTin("");
        }


        return st.add("caseInfo", caseInfo)
                .add("claimInfo", claimInfoList)
                .add("memberInfo", memberInfo)
                .add("transactionId", key)
                .render();
    }
}
