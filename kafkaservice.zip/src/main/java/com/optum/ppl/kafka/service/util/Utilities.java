package com.optum.ppl.kafka.service.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utilities {

    private static final Logger LOGGER = LoggerFactory.getLogger(Utilities.class);

    public static boolean validateProviderEmail(String providerEmail) {
        if (providerEmail == null || providerEmail.isEmpty()) {
            LOGGER.warn("Provider email is null or empty.");
            return false;
        }
        String regexPattern = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@" + "[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9]+)*$";
        final Pattern VALID_EMAIL_ADDRESS_REGEX=Pattern.compile(regexPattern,Pattern.CASE_INSENSITIVE);
        Matcher matcher =VALID_EMAIL_ADDRESS_REGEX.matcher(providerEmail);
        return matcher.find();
    }
}
