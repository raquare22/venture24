package com.optum.ppl.kafka.service.kafkaConsumer;


import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bson.Document;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import com.optum.ppl.kafka.service.template.Templates;
import com.optum.ppl.kafka.service.template.java.TemplateFactory;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.alink", havingValue = "true")
public final class AlinkConsumerService {

    private static final Logger LOGGER = LogManager.getLogger(AlinkConsumerService.class);


    @Autowired
    DocumentMetaDataService documentMetaDataService;

    @Value("${PRUN.alink_SPACEID}") 
    private int alinkSpaceId;

    @KafkaListener(
    		
    		topics = "${spring.kafka.topic.alink}", 
    		groupId = "${kafkaGroupIdalink}", 
            properties= {
               "bootstrap.servers=${alinkKafkaConsumerBootstrapServers}",
    		   "ssl.keystore.location=${alinkconsumerKeystorePath}", 
    		   "ssl.keystore.password=${alinkconsumerkeystorePassword}", 
    		   "ssl.truststore.location=${alinkconsumertruststorelocation}", 
    		   "ssl.truststore.password=${alinkconsumertruststorePassword}"
			}
    )
    public void consume(ConsumerRecord<String, String> message) {
        LOGGER.info("KafkaConsumerService --> Kafka Alink Consumer -->message received: key={}, value={}",
                message.key(), Encode.forJava(message.value()));

        List<DocumentMetaData> insertedDocList = new ArrayList<>();
        String metadataStr = null;
        
        DocumentMetaData document = null;
        try {
        	
            Map<String, Object> kafkaResponseMap = new HashMap<>();
            kafkaResponseMap.put("message", message.value());
            kafkaResponseMap.put("key", message.key());
            
           
            
        	TemplateHandler templateHandler = TemplateFactory.getInstance(Templates.ALINK_KAFKA_TEMPLATE.getTemplate());
        	metadataStr = templateHandler.convertWithTemplate(kafkaResponseMap);
        	
        	
        	org.bson.Document metadata = Document.parse(metadataStr);
        	document = new DocumentMetaData();
             
            document.setMetadata(metadata);
            document.setStatus(MetaDataStatus.AVAILABLE);   
            

            insertedDocList.add(document);
             
        } catch (Exception e) {
            LOGGER.error("KafkaConsumerService --> Kafka Alink Consumer --> unable to convert json string to documentMetaData, kafkaKey={}, e={}", 
            		Encode.forJava(message.key()), ExceptionUtils.getStackTrace(e));
        }
        if (CollectionUtils.isEmpty(insertedDocList)) {
            LOGGER.warn("KafkaConsumerService --> Kafka Alink Consumer-->documentMetaDataList is null or empty");
            return;
        }
        documentMetaDataService.insertMultiDocumentsWithSpaceId(insertedDocList, alinkSpaceId);
        LOGGER.info("Kafka Alink Consumer --> document inserted to mongodb: transactionId={}", message.key());
        
    }
}
