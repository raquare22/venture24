package com.optum.ppl.kafka.service.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProviderDocument implements Serializable {

	private ObjectMapper mapper = new ObjectMapper();
	
    private String id;
    
    private String documentId;

	private String spaceId;

    private String status;

    private String dateCreated;

    private ProviderDocumentMetaData metadata;

    public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

    public String getId() {
        return id;
    }

    public ProviderDocument setId(String id) {
        this.id = id;
        return this;
    }

    public String getSpaceId() {
        return spaceId;
    }

    public ProviderDocument setSpaceId(String spaceId) {
        this.spaceId = spaceId;
        return this;
    }

    public String getStatus() {
        return status;
    }

    public ProviderDocument setStatus(String status) {
        this.status = status;
        return this;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public ProviderDocument setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
        return this;
    }

    public ProviderDocumentMetaData getMetadata() {
        return metadata;
    }

    public ProviderDocument setMetadata(ProviderDocumentMetaData metadata) {
        this.metadata = metadata;
        return this;
    }
    
    public void setMetadata(String metadataJsonStr) throws JsonMappingException, JsonProcessingException {
    	ProviderDocumentMetaData convertedMetadata = mapper.readValue(metadataJsonStr, ProviderDocumentMetaData.class);
        this.metadata = convertedMetadata;
    }
    
    @Override
    public String toString() {
    	return "ProviderDocument [ documentId: " + documentId + ", metadata: " + metadata + " ] "; 
    }
}
