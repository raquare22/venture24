package com.optum.ppl.kafka.service.kafkaConsumer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.kafka.model.TrackItKafka;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import com.optum.ppl.kafka.service.template.Templates;
import com.optum.ppl.kafka.service.template.java.TemplateFactory;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.TrackIt", havingValue = "true")
public final class TrackItConsumerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TrackItConsumerService.class);

    @Autowired
    DocumentMetaDataService documentMetaDataService;

    @Value("${PRUN.TRACKIT_SPACEID}")
    private int TrackIt_SPACEID;

    @KafkaListener(
            topics = "${spring.kafka.topic.trackit}",
            groupId = "${kafkaGroupIdTrackIt}",
            properties = {
                    "bootstrap.servers=${TrackItBootstrapServers}",
                    "ssl.keystore.location=${TrackItconsumerKeystorePath}",
                    "ssl.keystore.password=${TrackItconsumerkeystorePassword}",
                    "ssl.truststore.location=${TrackItconsumertruststorelocation}",
                    "ssl.truststore.password=${TrackItconsumertruststorePassword}"
            }
    )
    public void consume(ConsumerRecord<String, String> message) {
        List<DocumentMetaData> insertedDocList = new ArrayList<>();
        String metadataStr = null;

        DocumentMetaData document = null;
        try {
            ObjectMapper mapper = new ObjectMapper();
            TrackItKafka trackitKafka = mapper.readValue(message.value(), TrackItKafka.class);

            validateTrackItMessage(trackitKafka);

            Map<String, Object> kafkaResponseMap = new HashMap<>();
            kafkaResponseMap.put("kafkaResponse", message.value());

            TemplateHandler templateHandler = TemplateFactory.getInstance(Templates.TRACKIT_KAFKA_TEMPLATE.getTemplate());
            metadataStr = templateHandler.convertWithTemplate(kafkaResponseMap);

            Document metadata = mapper.readValue(metadataStr, Document.class);
            document = new DocumentMetaData();
            document.setMetadata(metadata);
            document.setStatus(MetaDataStatus.AVAILABLE);

            insertedDocList.add(document);

            LOGGER.info("TrackItConsumerService --> Successfully processed message for email: {}", trackitKafka.getProviderEmailId());

        } catch (JsonParseException e) {
            LOGGER.error("TrackItConsumerService --> Invalid JSON format in Kafka message: key={}, value={}, error={}",
                    Encode.forJava(message.key()), message.value(), ExceptionUtils.getStackTrace(e));
            return;
        } catch (IllegalArgumentException e) {
            LOGGER.error("TrackItConsumerService --> Validation failed for Kafka message: key={}, error={}, message={}",
                    Encode.forJava(message.key()), ExceptionUtils.getStackTrace(e), e.getMessage());
            return;
        } catch (JsonProcessingException e) {
            LOGGER.error("TrackItConsumerService --> Parsing/conversion failure for Kafka message: key={}, error={}, message={}",
                    Encode.forJava(message.key()), ExceptionUtils.getStackTrace(e), e.getMessage());
        }

        if (CollectionUtils.isEmpty(insertedDocList)) {
            LOGGER.warn("TrackItConsumerService --> documentMetaDataList is null or empty");
            return;
        }

        try {
            documentMetaDataService.insertMultiDocumentsWithSpaceId(insertedDocList, TrackIt_SPACEID);
            LOGGER.info("TrackItConsumerService --> Document inserted to MongoDB: transactionId={}", message.key());
        } catch (Exception e) {
            LOGGER.error("TrackItConsumerService --> Failed to insert documents to MongoDB: transactionId={}, error={}",
                    message.key(), ExceptionUtils.getStackTrace(e));
        }
    }

    private void validateTrackItMessage(TrackItKafka trackitKafka) {
        if (trackitKafka == null) {
            LOGGER.error("TrackItConsumerService --> Received TrackItKafka message cannot be null");
            throw new IllegalArgumentException("TrackItKafka message cannot be null");
        }

        if (trackitKafka.getRecordID() == null || trackitKafka.getRecordID().isEmpty()) {
            LOGGER.error("TrackItConsumerService --> Record ID is required in the message");
            throw new IllegalArgumentException("Record ID is required");
        }

        if (trackitKafka.getProviderEmailId() == null || trackitKafka.getProviderEmailId().isEmpty()) {
            LOGGER.error("TrackItConsumerService --> Email address is required in the message");
            throw new IllegalArgumentException("Email address is required");
        }

        if (trackitKafka.getRecordsCountList() == null || trackitKafka.getRecordsCountList().isEmpty()) {
            LOGGER.error("TrackItConsumerService --> At least one RecordCount is required in the message");
            throw new IllegalArgumentException("At least one RecordCount is required");
        }
    }

}