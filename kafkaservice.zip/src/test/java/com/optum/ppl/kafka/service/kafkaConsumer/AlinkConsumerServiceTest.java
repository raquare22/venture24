package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import com.optum.ppl.kafka.service.template.Templates;
import com.optum.ppl.kafka.service.template.java.TemplateFactory;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
public class AlinkConsumerServiceTest {

    @InjectMocks
    AlinkConsumerService alinkConsumerService;

    @Mock
    DocumentMetaDataService documentMetaDataService;

    @Mock
    TemplateHandler templateHandler;

    @Mock
    ConsumerRecord<String, String> consumerRecord;

    private AutoCloseable mockedStatic;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(alinkConsumerService, "alinkSpaceId", 42);
        mockedStatic = mockStatic(TemplateFactory.class);
        when(TemplateFactory.getInstance(Templates.ALINK_KAFKA_TEMPLATE.getTemplate())).thenReturn(templateHandler);
    }

    @After
    public void tearDown() throws Exception {
        mockedStatic.close();
    }

    @Test
    public void testConsume_HappyPath() {
        String key = "alinkKey";
        String value = "{\"someField\":\"someValue\"}";
        String metadataStr = "{\"meta\":\"data\"}";

        when(consumerRecord.key()).thenReturn(key);
        when(consumerRecord.value()).thenReturn(value);
        when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataStr);

        alinkConsumerService.consume(consumerRecord);

        ArgumentCaptor<List<DocumentMetaData>> captor = ArgumentCaptor.forClass(List.class);
        verify(documentMetaDataService).insertMultiDocumentsWithSpaceId(captor.capture(), eq(42));
        List<DocumentMetaData> docs = captor.getValue();
        Assert.assertEquals(1, docs.size());
        Assert.assertEquals(MetaDataStatus.AVAILABLE, docs.get(0).getStatus());
        Assert.assertEquals(new Document("meta", "data"), docs.get(0).getMetadata());
    }

    @Test
    public void testConsume_EmptyMetadata() throws Exception {
        String key = "alinkKey";
        String value = "{\"someField\":\"someValue\"}";
        // Simulate template returns empty JSON
        String metadataStr = "{}";

        when(consumerRecord.key()).thenReturn(key);
        when(consumerRecord.value()).thenReturn(value);
        when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataStr);

        alinkConsumerService.consume(consumerRecord);

        // Should still insert, as document is created even for empty metadata
        verify(documentMetaDataService).insertMultiDocumentsWithSpaceId(anyList(), eq(42));
    }

    @Test
    public void testConsume_TemplateHandlerThrowsException() throws Exception {
        String key = "alinkKey";
        String value = "{\"someField\":\"someValue\"}";

        when(consumerRecord.key()).thenReturn(key);
        when(consumerRecord.value()).thenReturn(value);
        when(templateHandler.convertWithTemplate(anyMap())).thenThrow(new RuntimeException("Template error"));

        alinkConsumerService.consume(consumerRecord);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }
}