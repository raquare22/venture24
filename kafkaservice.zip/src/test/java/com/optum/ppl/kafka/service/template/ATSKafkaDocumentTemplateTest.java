package com.optum.ppl.kafka.service.template;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.kafka.model.ATSKafka;
import com.optum.ppl.kafka.service.template.java.TemplateFactory;

import junit.framework.Assert;
import org.json.JSONException;
import org.junit.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ATSKafkaDocumentTemplateTest {
    Map<String, Object> map = new HashMap<>();

    @Test
    public void testATSKafkaDocumentTemplate() throws IOException, JSONException {

        String jsonString = "{\n" +
                "    \"CaseInfo\": {\n" +
                "        \"CaseNumber\": \"AT-1111-W\",\n" +
                "        \"OrgReceivedDateTimeInUTC\": \"2024-07-12T21:57:21\",\n" +
                "        \"PlanReviewDueDateTimeInUTC\": \"2024-09-10T21:57:21\",\n" +
                "        \"InitialClaimDenailDate\": \"2024-07-03T00:00:00\",\n" +
                "        \"CaseStatus\": \"Closed\",\n" +
                "        \"CaseStatusLkup\": 1490,\n" +
                "        \"CaseDecision\": \"Closed – Redirect\",\n" +
                "        \"CaseDecisionLkup\": 1862770,\n" +
                "        \"DepartmentReceivedTimeInUTC\": \"2024-07-12T21:57:21\",\n" +
                "        \"Appellant\": \"Par Provider\",\n" +
                "        \"OnBehalfOf\": \"Provider\",\n" +
                "        \"Intakechannel\": \"Integration (provider portal)\",\n" +
                "        \"IntakechannelLkup\": 2039,\n" +
                "        \"IntakechannelQue\": \"Provider Portal (non API)\",\n" +
                "        \"IntakechannelQueLkup\": 1862254,\n" +
                "        \"UniqueImageID\": \"PTPAP-20240712165714518\",\n" +
                "        \"StateBusinessDueDateInUTC\": \"2024-09-10T21:57:21\",\n" +
                "        \"Urgency\": \"Standard\",\n" +
                "        \"Team\": \"C&S PAD\",\n" +
                "        \"CreatedOn\": \"2024-07-12T21:58:06.853\",\n" +
                "        \"LastUpdatedOn\": \"2024-07-15T20:31:35.39\",\n" +
                "        \"LstClaimInfo\": [\n" +
                "            {\n" +
                "                \"TRN_ClaimInfoID\": 3878682,\n" +
                "                \"ProviderStatus\": \"Par\",\n" +
                "                \"ClaimNumber\": \"24K252508300\",\n" +
                "                \"TotalBilled\": 200.00,\n" +
                "                \"TotalPaid\": 0.00,\n" +
                "                \"DrugName\": \"\",\n" +
                "                \"BillingTaxID\": \"860695862\",\n" +
                "                \"MPIN\": \"007039670\",\n" +
                "                \"StartDate\": \"2024-06-10T00:00:00\",\n" +
                "                \"EndDate\": \"2024-06-10T00:00:00\",\n" +
                "                \"LastUpdatedOn\": \"2024-07-12T22:06:13.29\",\n" +
                "                \"LstClaimLine\": [\n" +
                "                    {\n" +
                "                        \"TRN_ClaimLineId\": 180326077,\n" +
                "                        \"TRN_ClaimInfoRef\": 3878682,\n" +
                "                        \"ClaimLineNum\": \"1\",\n" +
                "                        \"LastUpdatedOn\": \"2024-07-12T22:06:13.29\",\n" +
                "                        \"IsSelectedForCurrentAppeal\": \"YES\",\n" +
                "                        \"Deductible\": 0.00,\n" +
                "                        \"CoPay\": 0.00,\n" +
                "                        \"LstClaimLineAdjustment\": []\n" +
                "                    }\n" +
                "                ],\n" +
                "                \"ClaimSystem\": \"CSP FACETS\",\n" +
                "                \"CreatedOn\": \"2024-07-12T21:59:18.87\",\n" +
                "                \"PatientID\": \"xxxx\"\n" +
                "            }\n" +
                "        ],\n" +
                "        \"LstDocuments\": [],\n" +
                "        \"LstComments\": [],\n" +
                "        \"MemberInfo\": {\n" +
                "            \"MemberId\": \"xxxxxxxxxx\",\n" +
                "            \"MemberFirstName\": \"xxxxxx\",\n" +
                "            \"MemberLastName\": \"xxxxx\",\n" +
                "            \"EmployerGroupNumber\": \"xxxxxxx\",\n" +
                "            \"MemberDOB\": \"1966-03-06T00:00:00\",\n" +
                "            \"MemberLastUpdatedOn\": \"2024-07-15T20:27:45.64\"\n" +
                "        },\n" +
                "        \"PatientInfo\": {},\n" +
                "        \"LstRelatedCases\": [],\n" +
                "        \"ProviderInfo\": {},\n" +
                "        \"LstTaskFlow\": [],\n" +
                "        \"PerformGrievanceReviewTask\": {},\n" +
                "        \"PerformPreServiceAppealReviewTask\": {},\n" +
                "        \"PerformExtensionTask\": {},\n" +
                "        \"PerformExternalReviewTask\": {},\n" +
                "        \"BenefitType\": \"C&S Part C PAD\",\n" +
                "        \"BenefitTypeLkup\": 1862664\n" +
                "    }\n" +
                "}";

        ObjectMapper objectMapper = new ObjectMapper();
        ATSKafka atsMsg = objectMapper.readValue(jsonString, ATSKafka.class);

        map.put("key", "cd566a5f-1b62-4b63-bb7e-09369349ef69");
        map.put("kafkaMessage", atsMsg);

        String output = TemplateFactory.getInstance(Templates.ATS_KAFKA_DOCUMENT.getTemplate())
                .convertWithTemplate(map);

        System.out.println(output);
        Assert.assertTrue(output.contains("AT-1111-W"));

    }

    @Test
    public void testATSKafkaTemplate() throws Exception {
        String jsonString = "{\"CaseInfo\":{\"CaseNumber\":\"AT-1470213-A\",\"OrgReceivedDateTimeInUTC\":\"2025-03-25T05:00:00\",\"CaseStatus\":\"Draft\",\"CaseStatusLkup\":1493,\"DepartmentReceivedTimeInUTC\":\"2025-03-25T05:00:00\",\"Intakechannel\":\"ORS\",\"IntakechannelLkup\":20000006,\"IntakechannelQue\":\"113 TRI PAO\",\"IntakechannelQueLkup\":18683571,\"UniqueImageID\":\"9102500817914\",\"Urgency\":\"Standard\",\"Team\":\"E&I\",\"LastUpdatedOn\":\"2025-03-25T16:50:38.743\",\"CreatedOn\":\"2025-03-25T16:50:38.743\",\"LstClaimInfo\":[],\"LstDocuments\":[],\"LstComments\":[],\"MemberInfo\":{},\"PatientInfo\":{\"TRN_PatientInfoId\":0},\"LstRelatedCases\":[],\"ProviderInfo\":{},\"LstTaskFlow\":[{\"TaskFlowId\":5272276,\"TaskName\":\"Create Case Triage Task\",\"TaskStatusStage\":\"Open\"}],\"PerformGrievanceReviewTask\":{},\"PerformPreServiceAppealReviewTask\":{},\"PerformExtensionTask\":{},\"PerformExternalReviewTask\":{}}}";
        ObjectMapper objectMapper = new ObjectMapper();
        ATSKafka atsMsg = objectMapper.readValue(jsonString, ATSKafka.class);

        map.put("key", "cd566a5f-1b62-4b63-bb7e-09369349ef69");
        map.put("kafkaMessage", atsMsg);

        String output = TemplateFactory.getInstance(Templates.ATS_KAFKA_DOCUMENT.getTemplate())
                .convertWithTemplate(map);

        System.out.println(output);
        Assert.assertTrue(output.contains("AT-1470213-A"));
        Assert.assertFalse(output.contains("lstClaimInfo"));
    }


    @Test
    public void testATSKafkaDocumentTemplateMissingLstClaimInfo() throws IOException, JSONException {

        String jsonString = "{\n" +
                "    \"CaseInfo\": {\n" +
                "        \"CaseNumber\": \"AT-1111-W\",\n" +
                "        \"OrgReceivedDateTimeInUTC\": \"2024-07-12T21:57:21\",\n" +
                "        \"PlanReviewDueDateTimeInUTC\": \"2024-09-10T21:57:21\",\n" +
                "        \"InitialClaimDenailDate\": \"2024-07-03T00:00:00\",\n" +
                "        \"CaseStatus\": \"Closed\",\n" +
                "        \"CaseStatusLkup\": 1490,\n" +
                "        \"CaseDecision\": \"Closed – Redirect\",\n" +
                "        \"CaseDecisionLkup\": 1862770,\n" +
                "        \"DepartmentReceivedTimeInUTC\": \"2024-07-12T21:57:21\",\n" +
                "        \"Appellant\": \"Par Provider\",\n" +
                "        \"OnBehalfOf\": \"Provider\",\n" +
                "        \"Intakechannel\": \"Integration (provider portal)\",\n" +
                "        \"IntakechannelLkup\": 2039,\n" +
                "        \"IntakechannelQue\": \"Provider Portal (non API)\",\n" +
                "        \"IntakechannelQueLkup\": 1862254,\n" +
                "        \"UniqueImageID\": \"PTPAP-20240712165714518\",\n" +
                "        \"StateBusinessDueDateInUTC\": \"2024-09-10T21:57:21\",\n" +
                "        \"Urgency\": \"Standard\",\n" +
                "        \"Team\": \"C&S PAD\",\n" +
                "        \"CreatedOn\": \"2024-07-12T21:58:06.853\",\n" +
                "        \"LastUpdatedOn\": \"2024-07-15T20:31:35.39\",\n" +
                "        \"LstDocuments\": [],\n" +
                "        \"LstComments\": [],\n" +
                "        \"MemberInfo\": {\n" +
                "            \"MemberId\": \"xxxxxxxxxx\",\n" +
                "            \"MemberFirstName\": \"xxxxxx\",\n" +
                "            \"MemberLastName\": \"xxxxx\",\n" +
                "            \"EmployerGroupNumber\": \"xxxxxxx\",\n" +
                "            \"MemberDOB\": \"1966-03-06T00:00:00\",\n" +
                "            \"MemberLastUpdatedOn\": \"2024-07-15T20:27:45.64\"\n" +
                "        },\n" +
                "        \"PatientInfo\": {},\n" +
                "        \"LstRelatedCases\": [],\n" +
                "        \"ProviderInfo\": {},\n" +
                "        \"LstTaskFlow\": [],\n" +
                "        \"PerformGrievanceReviewTask\": {},\n" +
                "        \"PerformPreServiceAppealReviewTask\": {},\n" +
                "        \"PerformExtensionTask\": {},\n" +
                "        \"PerformExternalReviewTask\": {},\n" +
                "        \"BenefitType\": \"C&S Part C PAD\",\n" +
                "        \"BenefitTypeLkup\": 1862664\n" +
                "    }\n" +
                "}";

        ObjectMapper objectMapper = new ObjectMapper();
        ATSKafka atsMsg = objectMapper.readValue(jsonString, ATSKafka.class);

        map.put("key", "cd566a5f-1b62-4b63-bb7e-09369349ef69");
        map.put("kafkaMessage", atsMsg);

        String output = TemplateFactory.getInstance(Templates.ATS_KAFKA_DOCUMENT.getTemplate())
                .convertWithTemplate(map);

        System.out.println(output);
        Assert.assertTrue(output.contains("AT-1111-W"));
        Assert.assertFalse(output.contains("lstClaimInfo"));

    }
}
