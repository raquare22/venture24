package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.Mockito.*;

@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
public class MnRConsumerServiceTest {

    @InjectMocks
    private MnRConsumerService mnRConsumerService;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private TemplateHandler templateHandler;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(mnRConsumerService, "MnR_SPACEID", 123);
    }

    @Test
    public void testConsume_ValidMessage_InsertsDocument() throws Exception {
        String key = "txn1";
        String value = """
        {
          "recordInfo": {
            "recordID": "540620889-825626883-1722095580000",
            "recordType": "EMERGENCY",
            "encounterID": "86af17358dbe9778f9830c39b6bdfe2f"
          },
          "providerDetails": {
            "admittingProviderName": "BEBARTA VIKHYAT",
            "providerTin": "540620889",
            "providerName": "LOFTON, SHERI A.",
            "facilityProvider": "INOVA - FAIRFAX HOSPITAL",
            "providerNpi": "1114988730"
          },
          "memberDetails": {
            "patientFirstName": "test",
            "patientLastName": "test",
            "lob": "test",
            "state": "test",
            "patientDateOfBirth": "03/20/2020"
          },
          "encounterDetails": {
            "admitDate": "2024-05-22 12:46:00",
            "dischargeDisposition": [
              "Atherosclerotic heart disease of native coronary artery without angina pectoris",
              "Ischemic cardiomyopathy",
              "Chronic kidney disease, stage 3 (moderate)",
              "Essential (primary) hypertension"
            ],
            "chiefComplaintList": [
              "Stenosis of other vascular prosthetic devices, implants and grafts, initial encounter",
              "Unspecified fall, initial encounter",
              "Fracture of unspecified carpal bone, right wrist, initial encounter for closed fracture"
            ]
          }
        }
        """;
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // Mock templateHandler and ObjectMapper

        // No exception expected, so documentMetaDataService.insertMultiDocumentsWithSpaceId should be called
        mnRConsumerService.consume(record);

        verify(documentMetaDataService, times(1))
                .insertMultiDocumentsWithSpaceId(anyList(), eq(123));
    }

    @Test
    public void testConsume_InvalidJson_LogsErrorAndReturns() throws Exception {
        String key = "txn2";
        String value = "{invalid_json}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        mnRConsumerService.consume(record);

        // Should not call insertMultiDocumentsWithSpaceId due to parse error
        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsume_TemplateHandlerThrowsException_LogsErrorAndReturns() throws Exception {
        String key = "txn3";
        String value = "{\"field\":\"val\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);


        mnRConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }
}