package com.optum.ppl.kafka.service.template;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.template.java.impl.ConsumerEngineeringKafkaDocumentTemplate;
import org.mockito.ArgumentMatchers;
import tools.jackson.core.type.TypeReference;

import static com.mongodb.client.model.Filters.eq;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class ConsumerEngineeringKafkaDocumentTemplateTest {
	
	private ConsumerEngineeringKafkaDocumentTemplate consumerEngineeringKafkaDocumentTemplate;
	
	 @Before
	 public void setUp() {		 
		 consumerEngineeringKafkaDocumentTemplate = new ConsumerEngineeringKafkaDocumentTemplate();	 
	 }
	 
	 
	 @Test
	 public void testFormatTinWithValidTin() throws Exception {
		 Method formatTinMethod = ConsumerEngineeringKafkaDocumentTemplate.class.getDeclaredMethod("formatTin", String.class);
		 formatTinMethod.setAccessible(true);

	     String tin = "68542";
	     String formattedTin = (String) formatTinMethod.invoke(consumerEngineeringKafkaDocumentTemplate, tin);
	     assertEquals("000068542", formattedTin); 
	 }
	 
	@Test
    public void testFormatTinWithEmptyTin() throws Exception {
	     Method formatTinMethod = ConsumerEngineeringKafkaDocumentTemplate.class.getDeclaredMethod("formatTin", String.class);
	     formatTinMethod.setAccessible(true);

	     String tin = "";
	     String formattedTin = (String) formatTinMethod.invoke(consumerEngineeringKafkaDocumentTemplate, tin);
	     assertEquals("", formattedTin);
	 }
	
	@Test
	public void testFormatTinWithNullTin() throws Exception {
	     Method formatTinMethod = ConsumerEngineeringKafkaDocumentTemplate.class.getDeclaredMethod("formatTin", String.class);
	     formatTinMethod.setAccessible(true);

	     String formattedTin = (String) formatTinMethod.invoke(consumerEngineeringKafkaDocumentTemplate, (String) null);
	     assertEquals(null, formattedTin);
	 }

	@Test
	public void testFormatTinWithNineCharacterTin() throws Exception {
	     Method formatTinMethod = ConsumerEngineeringKafkaDocumentTemplate.class.getDeclaredMethod("formatTin", String.class);
	     formatTinMethod.setAccessible(true);

	     String tin = "123456789";
	     String formattedTin = (String) formatTinMethod.invoke(consumerEngineeringKafkaDocumentTemplate, tin);
	     assertEquals("123456789", formattedTin);
	}
	
   
    
    String kafkaJsonMessage() {
    	return """
   {
    "memberInfo": {
        "requestingMember": {
            "memberIdCardNbr": "162080645",
            "firstName": "FNGVSLMDSRJM",
            "lastName": "LNTWOEADGL",
            "dob": "2000-05-19",
            "groupNumber": "0021311",
            "dependentSeqNbr": "01"
        },
        "requestedMember": {
            "memberIdCardNbr": "162080645",
            "firstName": "FNGVSLMDSRJM",
            "lastName": "LNTWOEADGL",
            "groupNumber": "0021311",
            "dob": "2000-05-19"
        }
    },
    "planDetails": {
        "insuranceType": "M",
        "planEndDate": "2025-12-31",
        "planStartDate": "2025-01-01",
        "policyId": "092019",
        "policyType": "Medical"
    },
    "providerDetails": {
        "primaryCareProviderFirstName": "FNGALILEO ",
        "primaryCareProviderLastName": "LNHEALTH ",
        "primaryCareProviderCorpMpin": "1831",
        "primaryCareProviderTin": "9812391",
        "referredToProviderFirstName": "FNKENDRA ",
        "referredToProviderLastName": "LNMULHOLAND ",
        "referredToProviderTin": "76231",
        "referredToProviderCorpMpin": "981923",
        "referredToProviderId": "005222521014"
    },
    "referralDetails": {
        "requestId": "RF_64c11a80-0d9d-48a3-a100-bd80004dc7e7",
        "specialty": "Dermatologist ",
        "comments": "Hello, Dr Paterakos has recommended that I get a colonoscopy.  Dr Stevoff is among the doctors he recommended, and I would like to select him.  Can you please put in a referral with my insurance using the UHC portal, thank you.\\n",
        "diagnosisCodes": [
            "A0100",
            "A0101"
        ]
    }
}

    			""";
    }
    
    String expectedString() {
    	
    	return """
    			
  {
   "memberInfo":{
      "requestingMember":{
         "memberIdCardNbr":"162080645",
         "firstName":"FNGVSLMDSRJM",
         "lastName":"LNTWOEADGL",
         "dob":"2000-05-19",
         "groupNumber":"0021311",
         "dependentSeqNbr":"01"
      },
      "requestedMember":{
         "memberIdCardNbr":"162080645",
         "firstName":"FNGVSLMDSRJM",
         "lastName":"LNTWOEADGL",
         "groupNumber":"0021311",
         "dob":"2000-05-19"
      }
   },
   "planDetails":{
      "insuranceType":"M",
      "planEndDate":"2025-12-31",
      "planStartDate":"2025-01-01",
      "policyId":"092019",
      "policyType":"Medical"
   },
   "providerDetails":{
      "primaryCareProviderFirstName":"FNGALILEO  ",
      "primaryCareProviderLastName":"LNHEALTH ",
      "primaryCareProviderCorpMpin":"1831",
      "primaryCareProviderTin":"009812391",
      "referredToProviderFirstName":"FNKENDRA ",
      "referredToProviderLastName":"LNMULHOLAND ",
      "referredToProviderTin":"000076231",
      "referredToProviderCorpMpin":"981923",
      "referredToProviderId":"005222521014"
   },
   "referralDetails":{
      "requestId":"RF_64c11a80-0d9d-48a3-a100-bd80004dc7e7",
      "specialty":"Dermatologist  ",
      "comments":"Requesting referrals for dermatologist",
      "diagnosisCodes":[
         "A0100",
         "A0101"
      ]
   },
   "tin": "009812391",
   "corporateMpin":"1831",
   "providerEmailId" : "",
   "createApplication" : "Consumer Engineering",
   "requestId" : "RF_64c11a80-0d9d-48a3-a100-bd80004dc7e7",
   "referralStatus" : "IN_PROCESS"
}

    			
    			""";
    }

    @Test
    public void testConvertWithTemplate_String_ValidJson() {
        String json = kafkaJsonMessage();
        String doubleEncoded = null;
        try {
            // Simulate the double-encoded JSON as expected by the method
            doubleEncoded = new ObjectMapper().writeValueAsString(json);
        } catch (JsonProcessingException e) {
            fail("Failed to encode JSON for test");
        }
        String result = consumerEngineeringKafkaDocumentTemplate.convertWithTemplate(doubleEncoded);
        System.out.println(result);
        assertNotNull(result);
    }

    @Test
    public void testConvertWithTemplateFromFilePath_ReturnsNull() {
        String result = consumerEngineeringKafkaDocumentTemplate.convertWithTemplateFromFilePath("any/path");
        assertNull(result);
    }

}
