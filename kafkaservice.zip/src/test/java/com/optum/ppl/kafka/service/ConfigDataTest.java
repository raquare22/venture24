package com.optum.ppl.kafka.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.MapType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
public class ConfigDataTest {

    @InjectMocks
    private ConfigData configData;

    @Mock
    private ObjectMapper objectMapper;

    @Before
    public void setUp() {
        // Set property values
        ReflectionTestUtils.setField(configData, "TRACKIT_configcredentials", "{\"1\":{\"user\":\"a\"}}");
        ReflectionTestUtils.setField(configData, "ADT_CNS_configcredentials", "{}");
        ReflectionTestUtils.setField(configData, "ATSAPPEALS_configcredentials", "{}");
        ReflectionTestUtils.setField(configData, "mnrConfigcredentials", "{}");
        ReflectionTestUtils.setField(configData, "consumerEngineeringConfigcredentials", "{}");
        ReflectionTestUtils.setField(configData, "ssbciConfigcredentials", "{}");
        ReflectionTestUtils.setField(configData, "mapper", objectMapper);

        // Fix: stub getTypeFactory to return a mock
        TypeFactory typeFactory = mock(TypeFactory.class);
        when(objectMapper.getTypeFactory()).thenReturn(typeFactory);
        MapType mapType = mock(MapType.class);
        when(typeFactory.constructMapType(Map.class, String.class, Object.class)).thenReturn(mapType);
    }

    @Test
    public void testGetCredentials_FoundFirstTry() throws Exception {
        MapType type = objectMapper.getTypeFactory().constructMapType(Map.class, String.class, Object.class);
        Map<String, Object> userMap = Map.of("user", "a");

        Map<String, Object> result = configData.getCredentials(1);
        assertFalse(result.isEmpty());
        assertEquals("a", result.get("user"));
    }

    @Test
    public void testGetCredentials_NotFoundAfterRetries() throws Exception {
        MapType type = objectMapper.getTypeFactory().constructMapType(Map.class, String.class, Object.class);

        Map<String, Object> result = configData.getCredentials(99);
        assertTrue(result.isEmpty());
    }
}