package com.optum.ppl.kafka.service.domain;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mongodb.client.result.UpdateResult;
import com.optum.ppl.kafka.service.beans.ProviderDocument;
import com.optum.ppl.kafka.service.exception.InvalidExpressionException;
import com.optum.ppl.kafka.service.model.MultiPutResponse;
import com.optum.ppl.kafka.service.mongo.DocumentAttachmentMetaData;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import com.optum.ppl.kafka.service.util.DocumentUtil;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

@RunWith(MockitoJUnitRunner.class)
public class DocumentMetaDataServiceImplTest {

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private DocumentUtil documentUtil;

    @InjectMocks
    private DocumentMetaDataServiceImpl documentMetaDataService;

    private DocumentMetaData doc;

    private final DocumentMetaDataServiceImpl service = new DocumentMetaDataServiceImpl();

    private static final String DOCUMENT_COLLECTION = "document";

    @Before
    public void setUp() {
        doc = new DocumentMetaData();
        doc.setId("testId");
        doc.setName("testName");
        doc.setAppIdentifier("app");
        doc.setClientId(0);
    }

    @Test
    public void testSaveDocumentMetaData() {
        when(mongoTemplate.insert(any(DocumentMetaData.class), anyString())).thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.saveDocumentMetaData(doc);
        assertNotNull(result);
        assertEquals("testId", result.getId());
    }

    @Test
    public void testSavePDODocumentMetaData() {
        when(mongoTemplate.insert(any(DocumentMetaData.class), anyString())).thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.savePDODocumentMetaData(doc);
        assertNotNull(result);
        assertEquals("testId", result.getId());
    }

//    @Tests
    public void testUpdatePDODocumentMetaData() {
        when(mongoTemplate.findOne(any(Query.class), any(), anyString())).thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.updatePDODocumentMetaData(doc, "testId");
        assertNotNull(result);
        assertEquals("testId", result.getId());
    }

    @Test
    public void testGetPDODocumentById() {
        when(mongoTemplate.findOne(any(Query.class), any(), anyString())).thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.getPDODocumentById("testId");
        assertNotNull(result);
        assertEquals("testId", result.getId());
    }

    @Test
    public void testGetPDODocuments() throws JsonProcessingException {
        List<DocumentMetaData> docList = new ArrayList<>();
        docList.add(doc);
        when(mongoTemplate.find(any(Query.class), any(), anyString())).thenReturn(Collections.singletonList(docList));
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("appIdentifier", "app");
        List<DocumentMetaData> result = documentMetaDataService.getPDODocuments(queryParams);
        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    public void testUpdateDocumentMetaDataStatus() {
        when(mongoTemplate.findOne(any(Query.class), any())).thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.updateDocumentMetaDataStatus("testId", MetaDataStatus.ACTIVE.toString());
        assertNotNull(result);
        assertEquals(MetaDataStatus.ACTIVE.toString(), result.getStatus().toString());
    }

    @Test
    public void testGetDocumentMetaDataByZipFileName_Success() throws Exception {
        String documentSearchCriteriaJson = "{\"key\":\"value\"}";
        Criteria documentsFilter = Criteria.where("someField").is("someValue");
        String zipFileName = "test.zip";
        int spaceId = 8896;

        List<DocumentMetaData> expectedDocs = new ArrayList<>();
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("testId123");
        doc.setSpaceId(spaceId);
        Document metadata = new Document();
        metadata.append("zipFileName", zipFileName);
        doc.setMetadata(metadata);
        expectedDocs.add(doc);

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(expectedDocs);

        List<DocumentMetaData> result = documentMetaDataService.getDocumentMetaDataByZipFileName(
                documentSearchCriteriaJson, documentsFilter, zipFileName, spaceId);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("testId123", result.get(0).getId());
        assertEquals(spaceId, result.get(0).getSpaceId());
        assertEquals(zipFileName, result.get(0).getMetadata().get("zipFileName"));

        ArgumentCaptor<Query> queryCaptor = ArgumentCaptor.forClass(Query.class);
        verify(mongoTemplate).find(queryCaptor.capture(), eq(DocumentMetaData.class), eq("document"));
        String query = queryCaptor.getValue().toString();
        assertTrue(query.contains("metadata.zipFileName"));
        assertTrue(query.contains("spaceId"));
    }

    @Test(expected = InvalidExpressionException.class)
    public void testGetDocumentMetaDataByZipFileName_NullFilter() throws Exception {
        String documentSearchCriteriaJson = "{\"key\":\"value\"}";
        String zipFileName = "test.zip";
        int spaceId = 8896;

        documentMetaDataService.getDocumentMetaDataByZipFileName(
                documentSearchCriteriaJson, null, zipFileName, spaceId);
    }

    @Test
    public void testGetDocumentMetaDataByZipFileName_ExceptionHandling() throws Exception {
        String documentSearchCriteriaJson = "{\"key\":\"value\"}";
        Criteria documentsFilter = Criteria.where("someField").is("someValue");
        String zipFileName = "test.zip";
        int spaceId = 8896;

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenThrow(new RuntimeException("Simulated database error"));

        try {
            documentMetaDataService.getDocumentMetaDataByZipFileName(
                    documentSearchCriteriaJson, documentsFilter, zipFileName, spaceId);
            fail("Expected exception was not thrown");
        } catch (Exception e) {
            assertEquals("Simulated database error", e.getMessage());
        }
    }

    @Test
    public void testGetDocumentMetaDataByZipFileName_EmptyResults() throws Exception {
        String documentSearchCriteriaJson = "{\"key\":\"value\"}";
        Criteria documentsFilter = Criteria.where("someField").is("someValue");
        String zipFileName = "nonexistent.zip";
        int spaceId = 8896;

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(Collections.emptyList());

        List<DocumentMetaData> result = documentMetaDataService.getDocumentMetaDataByZipFileName(
                documentSearchCriteriaJson, documentsFilter, zipFileName, spaceId);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testGetDocumentMetaData_ExceptionHandling() throws Exception {
        String documentSearchCriteriaJson = "{\"key\":\"value\"}";
        Criteria documentFilter = Criteria.where("someField").is("someValue");
        Integer countToReturn = 100;

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenThrow(new RuntimeException("Simulated database error"));

        try {
            documentMetaDataService.getDocumentMetaData(documentSearchCriteriaJson, documentFilter, countToReturn);
            fail("Expected exception was not thrown");
        } catch (Exception e) {
            assertEquals("Simulated database error", e.getMessage());
            assertTrue(e instanceof RuntimeException);
        }
    }

    @Test
    public void testGetDocumentMetaDataIds_ExceptionHandling() throws Exception {
        String documentSearchCriteriaJson = "{\"key\":\"value\"}";
        Criteria documentFilter = Criteria.where("someField").is("someValue");
        Criteria uniqueMetadataQuery = Criteria.where("metadataField").is("metadataValue");

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenThrow(new RuntimeException("Simulated database error"));

        try {
            documentMetaDataService.getDocumentMetaDataIds(documentSearchCriteriaJson, documentFilter, uniqueMetadataQuery);
            fail("Expected exception was not thrown");
        } catch (Exception e) {
            assertEquals("Simulated database error", e.getMessage());
            assertTrue(e instanceof RuntimeException);
        }
    }

    @Test
    public void testSaveDocumentMetaDataMulti_Success() {
        List<String> docIdList = Arrays.asList("id1", "id2", "id3");
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("status", MetaDataStatus.ACTIVE);
        updateMap.put("dateModified", new Date());

        UpdateResult mockResult = mock(UpdateResult.class);
        when(mockResult.getModifiedCount()).thenReturn(3L);

        when(mongoTemplate.updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document")))
                .thenReturn(mockResult);

        long result = documentMetaDataService.saveDocumentMetaDataMulti(docIdList, updateMap);

        assertEquals(3L, result);
        verify(mongoTemplate).updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testSaveDocumentMetaDataMulti_Exception() {
        List<String> docIdList = Arrays.asList("id1", "id2", "id3");
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("status", MetaDataStatus.ACTIVE);

        when(mongoTemplate.updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document")))
                .thenThrow(new RuntimeException("Simulated database error"));

        long result = documentMetaDataService.saveDocumentMetaDataMulti(docIdList, updateMap);

        assertEquals(0L, result); // Should return 0 on exception
        verify(mongoTemplate).updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testSaveDocumentMetaDataMulti_EmptyIdList() {
        List<String> docIdList = Collections.emptyList();
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("status", MetaDataStatus.ACTIVE);

        UpdateResult mockResult = mock(UpdateResult.class);
        when(mockResult.getModifiedCount()).thenReturn(0L);

        when(mongoTemplate.updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document")))
                .thenReturn(mockResult);

        long result = documentMetaDataService.saveDocumentMetaDataMulti(docIdList, updateMap);

        assertEquals(0L, result);
        verify(mongoTemplate).updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testSaveDocumentMetaDataMulti_EmptyUpdateMap() {
        List<String> docIdList = Arrays.asList("id1", "id2", "id3");
        Map<String, Object> updateMap = Collections.emptyMap();

        UpdateResult mockResult = mock(UpdateResult.class);
        when(mockResult.getModifiedCount()).thenReturn(0L);

        when(mongoTemplate.updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document")))
                .thenReturn(mockResult);

        long result = documentMetaDataService.saveDocumentMetaDataMulti(docIdList, updateMap);

        assertEquals(0L, result);
        verify(mongoTemplate).updateMulti(any(Query.class), any(Update.class),
                eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testSaveDocumentMetaDataMulti_ComplexUpdateMap() {
        List<String> docIdList = Arrays.asList("id1", "id2");
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("status", MetaDataStatus.ACTIVE);
        updateMap.put("dateModified", new Date());
        updateMap.put("metadata.field1", "value1");
        updateMap.put("metadata.nested.field2", 123);

        UpdateResult mockResult = mock(UpdateResult.class);
        when(mockResult.getModifiedCount()).thenReturn(2L);

        ArgumentCaptor<Update> updateCaptor = ArgumentCaptor.forClass(Update.class);
        when(mongoTemplate.updateMulti(any(Query.class), updateCaptor.capture(),
                eq(DocumentMetaData.class), eq("document")))
                .thenReturn(mockResult);

        long result = documentMetaDataService.saveDocumentMetaDataMulti(docIdList, updateMap);

        assertEquals(2L, result);
        Update capturedUpdate = updateCaptor.getValue();
        Document updateObject = capturedUpdate.getUpdateObject();
        assertEquals(4, updateMap.size());
    }

    @Test
    public void testGetDocumentMetaDataList() {
        List<String> ids = Arrays.asList("id1", "id2", "id3");
        List<DocumentMetaData> expectedDocs = new ArrayList<>();
        DocumentMetaData doc1 = new DocumentMetaData();
        doc1.setId("id1");
        DocumentMetaData doc2 = new DocumentMetaData();
        doc2.setId("id2");
        expectedDocs.add(doc1);
        expectedDocs.add(doc2);

        when(mongoTemplate.find(query(where("id").in(ids)), DocumentMetaData.class, "document"))
                .thenReturn(expectedDocs);

        List<DocumentMetaData> result = documentMetaDataService.getDocumentMetaDataList(ids);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("id1", result.get(0).getId());
        assertEquals("id2", result.get(1).getId());
        verify(mongoTemplate, times(1)).find(query(where("id").in(ids)), DocumentMetaData.class, "document");
    }

    @Test
    public void testConvertISOStringToDate_ValidDate() {
        String isoDate = "2023-10-01T12:30:45.123Z";
        Date result = service.convertISOStringToDate(isoDate);
        assertNotNull(result);
    }

    @Test
    public void testConvertISOStringToDate_InvalidDate() {
        String invalidDate = "invalid-date";
        Date result = service.convertISOStringToDate(invalidDate);
        assertNull(result);
    }

    @Test
    public void testConvertISOStringToDate_EmptyString() {
        String emptyDate = "";
        Date result = service.convertISOStringToDate(emptyDate);
        assertNull(result);
    }

    @Test
    public void testConvertISOStringToDate_NullInput() {
        String nullDate = null;
        Date result = service.convertISOStringToDate(nullDate);
        assertNull(result);
    }

    @Test
    public void testConvertISOStringToDate_AnotherValidFormat() {
        String isoDate = "2023-10-01 12:30:45.123Z";
        Date result = service.convertISOStringToDate(isoDate);
        assertNotNull(result);
    }

    @Test
    public void testAddDateConstraintsToQuery_ValidDates() {
        Query query = new Query();
        String startCreationDate = "2023-10-01T00:00:00.000Z";
        String endCreationDate = "2023-10-10T00:00:00.000Z";
        String startModifiedDate = "2023-10-05T00:00:00.000Z";
        String endModifiedDate = "2023-10-15T00:00:00.000Z";

        ReflectionTestUtils.invokeMethod(service, "addDateConstraintsToQuery",query,startCreationDate,endCreationDate,startModifiedDate,endModifiedDate);

        Object criteria = ReflectionTestUtils.invokeMethod(query, "getCriteria");

        System.out.println("Criteria: " + criteria);

        assertNotNull(criteria);
        assertTrue(criteria instanceof List);
        List<?> criteriaList = (List<?>) criteria;
        assertEquals(2, criteriaList.size());
//        assertTrue(criteriaList.get(0).toString().contains("dateCreated"));
//        assertTrue(criteriaList.get(1).toString().contains("dateModified"));
    }

    @Test
    public void testAddDateConstraintsToQuery_EmptyDates() {
        Query query = new Query();
        String startCreationDate = "";
        String endCreationDate = "";
        String startModifiedDate = "";
        String endModifiedDate = "";

        ReflectionTestUtils.invokeMethod(service, "addDateConstraintsToQuery", query, startCreationDate, endCreationDate, startModifiedDate,endModifiedDate);

        Object criteria = ReflectionTestUtils.invokeMethod(query, "getCriteria");

        assertNotNull(criteria);
        assertFalse(criteria.toString().contains("dateCreated"));
        assertFalse(criteria.toString().contains("dateModified"));
    }

    @Test
    public void testAddDateConstraintsToQuery_PartialDates() {
        Query query = new Query();
        String startCreationDate = "2023-10-01T00:00:00.000Z";
        String endCreationDate = null;
        String startModifiedDate = null;
        String endModifiedDate = "2023-10-15T00:00:00.000Z";

        ReflectionTestUtils.invokeMethod(
                service,
                "addDateConstraintsToQuery",
                query,
                startCreationDate,
                endCreationDate,
                startModifiedDate,
                endModifiedDate
        );


        Object criteria = ReflectionTestUtils.invokeMethod(query, "getCriteria");

        System.out.println("Criteria: " + criteria);

        assertNotNull(criteria);
        assertTrue(criteria instanceof List);
        List<?> criteriaList = (List<?>) criteria;
        assertEquals(2, criteriaList.size());
//        assertTrue(criteriaList.get(0).toString().contains("dateCreated"));
//        assertTrue(criteriaList.get(1).toString().contains("dateModified"));
    }

    @Test
    public void testGetGPSDocumentMetaData_Found() {
        DocumentMetaData expected = new DocumentMetaData();
        expected.setId("doc123");
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq(DOCUMENT_COLLECTION)))
                .thenReturn(Collections.singletonList(expected));

        List<DocumentMetaData> result = documentMetaDataService.getGPSDocumentMetaData("key123", 42, 2);

        assertNotNull(result);
    }

    @Test
    public void testGetGPSDocumentMetaData_NotFound() {
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq(DOCUMENT_COLLECTION)))
                .thenReturn(Collections.emptyList());

        List<DocumentMetaData> result = documentMetaDataService.getGPSDocumentMetaData("key123", 42, 2);

        assertEquals(0,result.size());
    }

    @Test
    public void testGetReferralDocumentMetaData_Found() {
        DocumentMetaData expected = new DocumentMetaData();
        expected.setId("doc456");
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class)))
                .thenReturn(Collections.singletonList(expected));

        DocumentMetaData result = documentMetaDataService.getReferralDocumentMetaData("req123", 99, "APPROVED", 7);

        assertNotNull(result);
        assertEquals("doc456", result.getId());
    }

    @Test
    public void testGetReferralDocumentMetaData_NotFound() {
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class)))
                .thenReturn(Collections.emptyList());

        DocumentMetaData result = documentMetaDataService.getReferralDocumentMetaData("req123", 99, "APPROVED", 7);

        assertNull(result);
    }

    @Test
    public void testUpdateDocMetaData_HappyFlow() {
        DocumentMetaData existingDoc = new DocumentMetaData();
        existingDoc.setId("doc1");
        existingDoc.setMetadata(new Document());
        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(existingDoc);
        DocumentMetaData updateDoc = new DocumentMetaData();
        updateDoc.setId("doc1");
        Document meta = new Document();
        meta.put("key", "value");
        updateDoc.setMetadata(meta);

        DocumentMetaData result = documentMetaDataService.updateDocMetaData(updateDoc, "doc1");
        assertNotNull(result);
        verify(mongoTemplate).save(any(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testInsertMultiPDODocuments_HappyFlow() {
        List<DocumentMetaData> docs = Arrays.asList(new DocumentMetaData(), new DocumentMetaData());
        doNothing().when(documentUtil).appendDefaultValues(any(DocumentMetaData.class));
        when(mongoTemplate.insert(any(Collection.class), eq("PDOdocument"))).thenReturn(docs);
        List<DocumentMetaData> result = documentMetaDataService.insertMultiPDODocuments(docs);
        assertEquals(2, result.size());
    }

    @Test
    public void testUpdateMultiPDODocuments_HappyFlow() {
        DocumentMetaData updateDoc = new DocumentMetaData();
        updateDoc.setId("id");
        List<String> ids = Arrays.asList("id1", "id2");
        DocumentMetaDataServiceImpl spyService = spy(documentMetaDataService);
        doReturn(updateDoc).when(spyService).updatePDODocumentMetaData(any(), anyString());
        MultiPutResponse response = spyService.updateMultiPDODocuments(ids, updateDoc);
        assertEquals(2, response.getUpdated().size());
        assertTrue(response.getNotUpdated().isEmpty());
    }

    @Test
    public void testInsertMultiDocuments_HappyFlow() {
        List<DocumentMetaData> docs = Arrays.asList(new DocumentMetaData(), new DocumentMetaData());
        doNothing().when(documentUtil).appendDefaultValues(any(DocumentMetaData.class));
        when(mongoTemplate.insert(any(Collection.class), eq("document"))).thenReturn(docs);
        List<DocumentMetaData> result = documentMetaDataService.insertMultiDocuments(docs);
        assertEquals(2, result.size());
    }

    @Test
    public void testInsertMultiDocumentsWithSpaceId_HappyFlow() {
        List<DocumentMetaData> docs = Arrays.asList(new DocumentMetaData(), new DocumentMetaData());
        doNothing().when(documentUtil).appendDefaultValuesWithSpaceId(any(DocumentMetaData.class), anyInt());
        when(mongoTemplate.insert(any(Collection.class), eq("document"))).thenReturn(docs);
        List<DocumentMetaData> result = documentMetaDataService.insertMultiDocumentsWithSpaceId(docs, 123);
        assertEquals(2, result.size());
    }

    @Test
    public void testUpdateMultiDocuments_HappyFlow() {
        DocumentMetaData updateDoc = new DocumentMetaData();
        updateDoc.setId("id");
        List<String> ids = Arrays.asList("id1", "id2");
        DocumentMetaDataServiceImpl spyService = spy(documentMetaDataService);
        doReturn(updateDoc).when(spyService).updateDocMetaData(any(), anyString());
        MultiPutResponse response = spyService.updateMultiDocuments(ids, updateDoc);
        assertEquals(2, response.getUpdated().size());
        assertTrue(response.getNotUpdated().isEmpty());
    }

    @Test
    public void testUpdateMultiDocument_HappyFlow() {
        DocumentMetaData updateDoc = new DocumentMetaData();
        updateDoc.setId("id");
        List<String> ids = Arrays.asList("id1", "id2");
        DocumentMetaDataServiceImpl spyService = spy(documentMetaDataService);
        doReturn(updateDoc).when(spyService).putDocumentMetadata(any(), anyString());
        MultiPutResponse response = spyService.updateMultiDocument(ids, updateDoc);
        assertEquals(2, response.getUpdated().size());
        assertTrue(response.getNotUpdated().isEmpty());
    }

    @Test
    public void testPutDocumentMetadata_HappyFlow() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc1");
        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class), any(), eq(DocumentMetaData.class)))
                .thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.putDocumentMetadata(doc);
        assertNotNull(result);
    }

    @Test
    public void testPutDocumentMetadataWithId_HappyFlow() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc1");
        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class), any(), eq(DocumentMetaData.class)))
                .thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.putDocumentMetadata(doc, "doc1");
        assertNotNull(result);
    }

    @Test
    public void testUpdateDocumentMetadataFields_HappyFlow() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc1");
        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class), any(), eq(DocumentMetaData.class)))
                .thenReturn(doc);
        Map<String, Object> fields = new HashMap<>();
        fields.put("status", "ACTIVE");
        DocumentMetaData result = documentMetaDataService.updateDocumentMetadataFields(fields, "doc1", "trx1");
        assertNotNull(result);
    }

    @Test
    public void testDeleteDocument_HappyFlow() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc1");
        when(mongoTemplate.findAndModify(any(Query.class), any(Update.class), any(), eq(DocumentMetaData.class)))
                .thenReturn(doc);
        DocumentMetaData result = documentMetaDataService.deleteDocument("doc1");
        assertNotNull(result);
    }


    @Test
    public void testUpdatePDODocumentMetaData_MetadataNull() {
        DocumentMetaData existingDoc = new DocumentMetaData();
        existingDoc.setId("doc1");
        existingDoc.setMetadata(null);

        DocumentMetaData updateDoc = new DocumentMetaData();
        updateDoc.setId("doc1");
        Document updateMetadata = new Document();
        updateMetadata.put("key", "value");
        updateDoc.setMetadata(updateMetadata);

        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("PDOdocument")))
                .thenReturn(existingDoc);

        DocumentMetaData result = documentMetaDataService.updatePDODocumentMetaData(updateDoc, "doc1");

        assertNotNull(result);
        assertEquals("value", result.getMetadata().get("key"));
        verify(mongoTemplate).save(any(DocumentMetaData.class), eq("PDOdocument"));
    }

    @Test
    public void testUpdatePDODocumentMetaData_MetadataNotNull() {
        DocumentMetaData existingDoc = new DocumentMetaData();
        existingDoc.setId("doc1");
        Document existingMetadata = new Document();
        existingMetadata.put("oldKey", "oldValue");
        existingDoc.setMetadata(existingMetadata);

        DocumentMetaData updateDoc = new DocumentMetaData();
        updateDoc.setId("doc1");
        Document updateMetadata = new Document();
        updateMetadata.put("newKey", "newValue");
        updateDoc.setMetadata(updateMetadata);

        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("PDOdocument")))
                .thenReturn(existingDoc);

        DocumentMetaData result = documentMetaDataService.updatePDODocumentMetaData(updateDoc, "doc1");

        assertNotNull(result);
        assertEquals("oldValue", result.getMetadata().get("oldKey"));
        assertEquals("newValue", result.getMetadata().get("newKey"));
        verify(mongoTemplate).save(any(DocumentMetaData.class), eq("PDOdocument"));
    }

    @Test
    public void testUpdatePDODocumentMetaData_DocumentNotFound() {
        DocumentMetaData updateDoc = new DocumentMetaData();
        updateDoc.setId("doc1");
        Document updateMetadata = new Document();
        updateMetadata.put("key", "value");
        updateDoc.setMetadata(updateMetadata);

        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("PDOdocument")))
                .thenReturn(null);

        DocumentMetaData result = documentMetaDataService.updatePDODocumentMetaData(updateDoc, "doc1");

        assertNull(result);
        verify(mongoTemplate, never()).save(any(DocumentMetaData.class), anyString());
    }

    @Test
    public void testGetDocumentMetaData_Found() {
        DocumentMetaData expected = new DocumentMetaData();
        expected.setId("doc123");
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class)))
                .thenReturn(Collections.singletonList(expected));

        DocumentMetaData result = documentMetaDataService.getDocumentMetaData("doc123");

        assertNotNull(result);
        assertEquals("doc123", result.getId());
    }

    @Test
    public void testGetDocumentMetaData_NotFound() {
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class)))
                .thenReturn(Collections.emptyList());

        DocumentMetaData result = documentMetaDataService.getDocumentMetaData("doc123");

        assertNull(result);
    }

    @Test
    public void testGetATSDocumentMetaData_Found() {
        DocumentMetaData expected = new DocumentMetaData();
        expected.setId("ats123");
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class)))
                .thenReturn(Collections.singletonList(expected));

        DocumentMetaData result = documentMetaDataService.getATSDocumentMetaData("caseNum", 42, 7);

        assertNotNull(result);
        assertEquals("ats123", result.getId());
    }

    @Test
    public void testGetATSDocumentMetaData_NotFound() {
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class)))
                .thenReturn(Collections.emptyList());

        DocumentMetaData result = documentMetaDataService.getATSDocumentMetaData("caseNum", 42, 7);

        assertNull(result);
    }

    @Test
    public void testGetCsvDocumentMetaData_Found() {
        DocumentMetaData expected = new DocumentMetaData();
        expected.setId("csv123");
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("CSVdocument")))
                .thenReturn(Collections.singletonList(expected));

        DocumentMetaData result = documentMetaDataService.getCsvDocumentMetaData("csv123");

        assertNotNull(result);
        assertEquals("csv123", result.getId());
    }

    @Test
    public void testGetCsvDocumentMetaData_NotFound() {
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class), eq("CSVdocument")))
                .thenReturn(Collections.emptyList());

        DocumentMetaData result = documentMetaDataService.getCsvDocumentMetaData("csv123");

        assertNull(result);
    }

    @Test
    public void testUpdateDocumentMetaDataStatus_HappyFlow() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc1");
        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class))).thenReturn(doc);

        DocumentMetaData result = documentMetaDataService.updateDocumentMetaDataStatus("doc1", "ACTIVE", "trx1", "errMsg");

        assertNotNull(result);
        assertEquals(MetaDataStatus.ACTIVE, result.getStatus());
        assertEquals("trx1", result.getTransactionId());
        assertEquals("errMsg", result.getErrorMessage());
        verify(mongoTemplate).save(doc);
    }

    @Test
    public void testUpdateDocumentMetaDataStatus_NullOrEmptyArgs() {
        DocumentMetaData result1 = documentMetaDataService.updateDocumentMetaDataStatus("", "ACTIVE", "trx1", "errMsg");
        DocumentMetaData result2 = documentMetaDataService.updateDocumentMetaDataStatus("doc1", "", "trx1", "errMsg");
        DocumentMetaData result3 = documentMetaDataService.updateDocumentMetaDataStatus("doc1", "ACTIVE", "", "errMsg");
        assertNull(result1);
        assertNull(result2);
        assertNull(result3);
    }

    @Test
    public void testUpdateDocumentMetaDataStatus_DocNotFound() {
        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class))).thenReturn(null);
        DocumentMetaData result = documentMetaDataService.updateDocumentMetaDataStatus("doc1", "ACTIVE", "trx1", "errMsg");
        assertNull(result);
    }

    @Test
    public void testUpdateReferralDocumentStatus_HappyFlow() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("doc1");
        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class))).thenReturn(doc);

        Document metadata = new Document();
        metadata.put("key", "value");

        DocumentMetaData result = documentMetaDataService.updateReferralDocumentStatus("doc1", metadata);

        assertNotNull(result);
        assertEquals(metadata, result.getMetadata());
        verify(mongoTemplate).save(doc);
    }

    @Test
    public void testUpdateReferralDocumentStatus_EmptyMetadata() {
        Document metadata = new Document();
        DocumentMetaData result = documentMetaDataService.updateReferralDocumentStatus("doc1", metadata);
        assertNull(result);
    }

    @Test
    public void testUpdateReferralDocumentStatus_EmptyDocId() {
        Document metadata = new Document();
        metadata.put("key", "value");
        DocumentMetaData result = documentMetaDataService.updateReferralDocumentStatus("", metadata);
        assertNull(result);
    }

    @Test
    public void testUpdateReferralDocumentStatus_DocNotFound() {
        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class))).thenReturn(null);
        Document metadata = new Document();
        metadata.put("key", "value");
        DocumentMetaData result = documentMetaDataService.updateReferralDocumentStatus("doc1", metadata);
        assertNull(result);
    }

    @Test
    public void testGetDocumentListMetadata_WithMetadata() {
        Map<String, String> metadataMap = new HashMap<>();
        metadataMap.put("metadata.someField", "someValue");
        List<DocumentMetaData> expected = Arrays.asList(new DocumentMetaData());
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(expected);

        List<DocumentMetaData> result = documentMetaDataService.getDocumentListMetadata("appId", metadataMap);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(mongoTemplate).find(any(Query.class), eq(DocumentMetaData.class));
    }

    @Test
    public void testGetDocumentListMetadata_EmptyMetadata() {
        Map<String, String> metadataMap = new HashMap<>();
        List<DocumentMetaData> result = documentMetaDataService.getDocumentListMetadata("appId", metadataMap);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(mongoTemplate, never()).find(any(Query.class), any(), anyString());
    }

    @Test
    public void testGetDocumentListMetadata_NullMetadata() {
        List<DocumentMetaData> result = documentMetaDataService.getDocumentListMetadata("appId", null);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(mongoTemplate, never()).find(any(Query.class), any(), anyString());
    }

    @Test
    public void testGetDocumentMetaDataListWithPagingNew_HappyFlow() {
        List<Integer> spaceIdList = Arrays.asList(1, 2);
        String status = "ACTIVE";
        Criteria documentsQry = Criteria.where("someField").is("someValue");
        int startPosition = 0;
        int countToReturn = 10;

        List<DocumentMetaData> expected = Arrays.asList(new DocumentMetaData(), new DocumentMetaData());
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(expected);

        List<DocumentMetaData> result = documentMetaDataService.getDocumentMetaDataListWithPagingNew(
                status, spaceIdList, documentsQry, startPosition, countToReturn);

        assertNotNull(result);
        assertEquals(2, result.size());
        verify(mongoTemplate).find(any(Query.class), eq(DocumentMetaData.class));
    }

    @Test
    public void testGetDocumentMetaDataListWithPagingNew_EmptyResult() {
        List<Integer> spaceIdList = Arrays.asList(1, 2);
        String status = "ACTIVE";
        Criteria documentsQry = Criteria.where("someField").is("someValue");

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(Collections.emptyList());

        List<DocumentMetaData> result = documentMetaDataService.getDocumentMetaDataListWithPagingNew(
                status, spaceIdList, documentsQry, 0, 10);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test(expected = RuntimeException.class)
    public void testGetDocumentMetaDataListWithPagingNew_Exception() {
        List<Integer> spaceIdList = Arrays.asList(1, 2);
        String status = "ACTIVE";
        Criteria documentsQry = Criteria.where("someField").is("someValue");

        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class)))
                .thenThrow(new RuntimeException("Simulated DB error"));

        documentMetaDataService.getDocumentMetaDataListWithPagingNew(
                status, spaceIdList, documentsQry, 0, 10);
    }

    @Test
    public void testGetPDODocuments_HappyFlow() {
        Document criteriaDocument = new Document("field", "value");
        List<ProviderDocument> expected = Arrays.asList(new ProviderDocument(), new ProviderDocument());
        when(mongoTemplate.find(any(Query.class), eq(ProviderDocument.class), eq("PDOdocument"))).thenReturn(expected);

        List<ProviderDocument> result = documentMetaDataService.getPDODocuments(criteriaDocument);

        assertNotNull(result);
        assertEquals(2, result.size());
        verify(mongoTemplate).find(any(Query.class), eq(ProviderDocument.class), eq("PDOdocument"));
    }

    @Test(expected = RuntimeException.class)
    public void testGetPDODocuments_Exception() {
        Document criteriaDocument = new Document("field", "value");
        when(mongoTemplate.find(any(Query.class), eq(ProviderDocument.class), eq("PDOdocument")))
                .thenThrow(new RuntimeException("Simulated DB error"));

        documentMetaDataService.getPDODocuments(criteriaDocument);
    }


    @Test
    public void testGetDocuments_HappyFlow() throws Exception {
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("appIdentifier", "app");
        List<DocumentMetaData> expected = Arrays.asList(new DocumentMetaData());
        when(mongoTemplate.find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document"))).thenReturn(expected);

        List<DocumentMetaData> result = documentMetaDataService.getDocuments(queryParams);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(mongoTemplate).find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testGetDocuments_WithSpaceId() throws Exception {
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("spaceId", "123");
        List<DocumentMetaData> expected = Arrays.asList(new DocumentMetaData());
        when(mongoTemplate.find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document"))).thenReturn(expected);

        List<DocumentMetaData> result = documentMetaDataService.getDocuments(queryParams);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(mongoTemplate).find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testGetDocuments_EmptyResult() throws Exception {
        Map<String, String> queryParams = new HashMap<>();
        when(mongoTemplate.find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document"))).thenReturn(Collections.emptyList());

        List<DocumentMetaData> result = documentMetaDataService.getDocuments(queryParams);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test(expected = JsonProcessingException.class)
    public void testGetDocuments_JsonProcessingException() throws Exception {
        Map<String, String> queryParams = new HashMap<>();
        DocumentMetaDataServiceImpl spyService = spy(documentMetaDataService);
        doThrow(JsonProcessingException.class).when(spyService).getDocuments(anyMap());
        spyService.getDocuments(queryParams);
    }

    @Test
    public void testUpdateDocumentMetaData_HappyFlow() {
        DocumentMetaData input = new DocumentMetaData();
        input.setId("doc1");
        input.setStatus(MetaDataStatus.ACTIVE);
        input.setErrorMessage("err");
        DocumentAttachmentMetaData documentMetaData = new DocumentAttachmentMetaData();
        input.setDocumentAttachments(Collections.singletonList(documentMetaData));

        DocumentMetaData existing = new DocumentMetaData();
        existing.setId("doc1");

        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class))).thenReturn(existing);

        DocumentMetaData result = documentMetaDataService.updateDocumentMetaData(input, "trx1");

        assertNotNull(result);
        assertEquals("ACTIVE", result.getStatus().toString());
        assertEquals("trx1", result.getTransactionId());
        assertEquals("err", result.getErrorMessage());
        assertEquals(Collections.singletonList(documentMetaData), result.getDocumentAttachments());
        verify(mongoTemplate).save(existing);
    }

    @Test
    public void testUpdateDocumentMetaData_NullOrEmptyArgs() {
        DocumentMetaData input = new DocumentMetaData();
        input.setId("");
        input.setStatus(MetaDataStatus.ACTIVE);

        DocumentMetaData result = documentMetaDataService.updateDocumentMetaData(input, "trx1");
        assertNull(result);

        input.setId("doc1");
        input.setStatus(MetaDataStatus.ACTIVE);
        result = documentMetaDataService.updateDocumentMetaData(input, "trx1");
        assertNull(result);

        input.setStatus(MetaDataStatus.ACTIVE);
        result = documentMetaDataService.updateDocumentMetaData(input, "");
        assertNull(result);
    }

    @Test
    public void testUpdateDocumentMetaData_DocNotFound() {
        DocumentMetaData input = new DocumentMetaData();
        input.setId("doc1");
        input.setStatus(MetaDataStatus.ACTIVE);

        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class))).thenReturn(null);

        DocumentMetaData result = documentMetaDataService.updateDocumentMetaData(input, "trx1");
        assertNull(result);
    }

    @Test
    public void testGetDocumentMetaData_Success() throws Exception {
        String searchCriteriaJson = "{\"key\":\"value\"}";
        Criteria filter = Criteria.where("someField").is("someValue");
        List<DocumentMetaData> expected = Arrays.asList(new DocumentMetaData());

        when(mongoTemplate.find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(expected);

        List<DocumentMetaData> result = documentMetaDataService.getDocumentMetaData(searchCriteriaJson, filter);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(mongoTemplate).find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document"));
    }

    @Test(expected = InvalidExpressionException.class)
    public void testGetDocumentMetaData_NullFilter() throws Exception {
        String searchCriteriaJson = "{\"key\":\"value\"}";
        documentMetaDataService.getDocumentMetaData(searchCriteriaJson, null);
    }

    @Test
    public void testGetDocumentMetaData_EmptyResult() throws Exception {
        String searchCriteriaJson = "{\"key\":\"value\"}";
        Criteria filter = Criteria.where("someField").is("someValue");

        when(mongoTemplate.find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(Collections.emptyList());

        List<DocumentMetaData> result = documentMetaDataService.getDocumentMetaData(searchCriteriaJson, filter);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test(expected = RuntimeException.class)
    public void testGetDocumentMetaData_Exception() throws Exception {
        String searchCriteriaJson = "{\"key\":\"value\"}";
        Criteria filter = Criteria.where("someField").is("someValue");

        when(mongoTemplate.find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document")))
                .thenThrow(new RuntimeException("Simulated DB error"));

        documentMetaDataService.getDocumentMetaData(searchCriteriaJson, filter);
    }

    @Test
    public void testGetCsvDocumentMetaData_Success() throws Exception {
        String searchCriteriaJson = "{\"key\":\"value\"}";
        Criteria filter = Criteria.where("someField").is("someValue");
        List<DocumentMetaData> expected = Arrays.asList(new DocumentMetaData());

        when(mongoTemplate.find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(expected);

        List<DocumentMetaData> result = documentMetaDataService.getCsvDocumentMetaData(searchCriteriaJson, filter);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(mongoTemplate).find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document"));
    }

    @Test(expected = InvalidExpressionException.class)
    public void testGetCsvDocumentMetaData_NullFilter() throws Exception {
        String searchCriteriaJson = "{\"key\":\"value\"}";
        documentMetaDataService.getCsvDocumentMetaData(searchCriteriaJson, null);
    }

    @Test
    public void testGetCsvDocumentMetaData_EmptyResult() throws Exception {
        String searchCriteriaJson = "{\"key\":\"value\"}";
        Criteria filter = Criteria.where("someField").is("someValue");

        when(mongoTemplate.find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(Collections.emptyList());

        List<DocumentMetaData> result = documentMetaDataService.getCsvDocumentMetaData(searchCriteriaJson, filter);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test(expected = RuntimeException.class)
    public void testGetCsvDocumentMetaData_Exception() throws Exception {
        String searchCriteriaJson = "{\"key\":\"value\"}";
        Criteria filter = Criteria.where("someField").is("someValue");

        when(mongoTemplate.find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document")))
                .thenThrow(new RuntimeException("Simulated DB error"));

        documentMetaDataService.getCsvDocumentMetaData(searchCriteriaJson, filter);
    }

    @Test
    public void testSaveDocumentMetaData_IdNullOrEmpty_InsertsDocument() {
        DocumentMetaData docNullId = new DocumentMetaData();
        docNullId.setId(null);
        DocumentMetaData docEmptyId = new DocumentMetaData();
        docEmptyId.setId("");
        when(mongoTemplate.insert(any(DocumentMetaData.class), anyString()))
            .thenReturn(docNullId)
            .thenReturn(docEmptyId);

        DocumentMetaData resultNull = documentMetaDataService.saveDocumentMetaData(docNullId);
        DocumentMetaData resultEmpty = documentMetaDataService.saveDocumentMetaData(docEmptyId);

        assertNotNull(resultNull);
        assertNotNull(resultEmpty);
        verify(mongoTemplate, times(2)).insert(any(DocumentMetaData.class), eq("document"));
    }

    @Test
    public void testSaveDocumentMetaData_IdExists_SavesDocument() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("existingId");
        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("document"))).thenReturn(doc);
        when(mongoTemplate.save(any(DocumentMetaData.class), eq("document"))).thenReturn(doc);

        DocumentMetaData result = documentMetaDataService.saveDocumentMetaData(doc);

        assertNotNull(result);
        assertEquals("existingId", result.getId());
        verify(mongoTemplate).findOne(any(Query.class), eq(DocumentMetaData.class), eq("document"));
        verify(mongoTemplate).save(doc, "document");
    }

    @Test
    public void testSavePDODocumentMetaData_IdNullOrEmpty_InsertsDocument() {
        DocumentMetaData docNullId = new DocumentMetaData();
        docNullId.setId(null);
        DocumentMetaData docEmptyId = new DocumentMetaData();
        docEmptyId.setId("");
        when(mongoTemplate.insert(any(DocumentMetaData.class), eq("PDOdocument")))
            .thenReturn(docNullId)
            .thenReturn(docEmptyId);

        DocumentMetaData resultNull = documentMetaDataService.savePDODocumentMetaData(docNullId);
        DocumentMetaData resultEmpty = documentMetaDataService.savePDODocumentMetaData(docEmptyId);

        assertNotNull(resultNull);
        assertNotNull(resultEmpty);
        verify(mongoTemplate, times(2)).insert(any(DocumentMetaData.class), eq("PDOdocument"));
    }

    @Test
    public void testSavePDODocumentMetaData_IdExists_SavesDocument() {
        DocumentMetaData doc = new DocumentMetaData();
        doc.setId("existingId");
        when(mongoTemplate.findOne(any(Query.class), eq(DocumentMetaData.class), eq("PDOdocument"))).thenReturn(doc);
        when(mongoTemplate.save(any(DocumentMetaData.class), eq("PDOdocument"))).thenReturn(doc);

        DocumentMetaData result = documentMetaDataService.savePDODocumentMetaData(doc);

        assertNotNull(result);
        assertEquals("existingId", result.getId());
        verify(mongoTemplate).findOne(any(Query.class), eq(DocumentMetaData.class), eq("PDOdocument"));
        verify(mongoTemplate).save(doc, "PDOdocument");
    }

    // For: getDocumentListAppId(String appIdentifier)
    @Test
    public void testGetDocumentListAppId_HappyFlow() {
        List<DocumentMetaData> expected = Arrays.asList(new DocumentMetaData());
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(expected);

        List<DocumentMetaData> result = documentMetaDataService.getDocumentListAppId("appId");

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(mongoTemplate).find(any(Query.class), eq(DocumentMetaData.class));
    }

    @Test
    public void testGetDocumentListAppId_EmptyResult() {
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(Collections.emptyList());

        List<DocumentMetaData> result = documentMetaDataService.getDocumentListAppId("appId");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // For: getDocumentListById(String id)
    @Test
    public void testGetDocumentListById_HappyFlow() {
        List<DocumentMetaData> expected = Arrays.asList(new DocumentMetaData());
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(expected);

        List<DocumentMetaData> result = documentMetaDataService.getDocumentListById("docId");

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(mongoTemplate).find(any(Query.class), eq(DocumentMetaData.class));
    }

    @Test
    public void testGetDocumentListById_EmptyResult() {
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(Collections.emptyList());

        List<DocumentMetaData> result = documentMetaDataService.getDocumentListById("docId");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // For: getDocumentListByExternalId(String appId, String externalId)
    @Test
    public void testGetDocumentListByExternalId_HappyFlow() {
        List<DocumentMetaData> expected = Arrays.asList(new DocumentMetaData());
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(expected);

        List<DocumentMetaData> result = documentMetaDataService.getDocumentListByExternalId("appId", "externalId");

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(mongoTemplate).find(any(Query.class), eq(DocumentMetaData.class));
    }

    @Test
    public void testGetDocumentListByExternalId_EmptyResult() {
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(Collections.emptyList());

        List<DocumentMetaData> result = documentMetaDataService.getDocumentListByExternalId("appId", "externalId");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // For: getDocumentListByExternalIdAndSpaceId(String externalId, int spaceId)
    @Test
    public void testGetDocumentListByExternalIdAndSpaceId_HappyFlow() {
        List<DocumentMetaData> expected = Arrays.asList(new DocumentMetaData());
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(expected);

        List<DocumentMetaData> result = documentMetaDataService.getDocumentListByExternalIdAndSpaceId("externalId", 123);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(mongoTemplate).find(any(Query.class), eq(DocumentMetaData.class));
    }

    @Test
    public void testGetDocumentListByExternalIdAndSpaceId_EmptyResult() {
        when(mongoTemplate.find(any(Query.class), eq(DocumentMetaData.class))).thenReturn(Collections.emptyList());

        List<DocumentMetaData> result = documentMetaDataService.getDocumentListByExternalIdAndSpaceId("externalId", 123);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test(expected = InvalidExpressionException.class)
    public void testGetDocumentMetaDataIds_NullFilter_throwsException() throws Exception {
        DocumentMetaDataServiceImpl service = new DocumentMetaDataServiceImpl();
        service.getDocumentMetaDataIds("{\"key\":\"value\"}", null, null);
    }

    @Test
    public void testGetDocumentMetaDataIds_ReturnsIds() throws Exception {
        String searchCriteriaJson = "{}";
        Criteria filter = Criteria.where("field").is("value");
        Criteria uniqueMetadataQuery = Criteria.where("meta").is("metaValue");

        DocumentMetaData doc1 = new DocumentMetaData();
        doc1.setId("id1");
        DocumentMetaData doc2 = new DocumentMetaData();
        doc2.setId("id2");
        List<DocumentMetaData> docs = Arrays.asList(doc1, doc2);

        when(mongoTemplate.find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document")))
                .thenReturn(docs);

        List<String> ids = documentMetaDataService.getDocumentMetaDataIds(searchCriteriaJson, filter, uniqueMetadataQuery);

        assertEquals(Arrays.asList("id1", "id2"), ids);
        verify(mongoTemplate).find(any(BasicQuery.class), eq(DocumentMetaData.class), eq("document"));
    }


}