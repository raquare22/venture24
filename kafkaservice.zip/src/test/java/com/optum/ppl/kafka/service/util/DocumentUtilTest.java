package com.optum.ppl.kafka.service.util;

import com.optum.ppl.kafka.service.ConfigData;
import com.optum.ppl.kafka.service.mongo.DocumentAttachmentMetaData;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.DocumentRevision;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;

import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
public class DocumentUtilTest {

    @Mock
    private ConfigData config;

    @InjectMocks
    private DocumentUtil documentUtil;

    private DocumentMetaData doc;

    @Before
    public void setUp() {
        doc = new DocumentMetaData();
    }

    @Test
    public void testUpdateDateModified() {
        Date before = doc.getDateModified();
        DocumentUtil.updateDateModified(doc);
        assertNotNull(doc.getDateModified());
        assertTrue(doc.getDateModified().getTime() >= System.currentTimeMillis() - 1000);
    }

    @Test
    public void testUpdateDocumentMetaDataRevisions_NewList() {
        doc.setRevisions(null);
        doc.setSpaceId(1);
        DocumentUtil.updateDocumentMetaDataRevisions(doc);
        assertNotNull(doc.getRevisions());
        assertEquals(1, doc.getRevisions().size());
    }

    @Test
    public void testUpdateDocumentMetaDataRevisions_ExistingList() {
        List<DocumentRevision> list = new ArrayList<>();
        doc.setRevisions(list);
        doc.setSpaceId(1);
        DocumentUtil.updateDocumentMetaDataRevisions(doc);
        assertEquals(1, doc.getRevisions().size());
    }

    @Test
    public void testCreateRevision_AllFields() {
        doc.setExternalId("ext");
        doc.setAppIdentifier("app");
        doc.setClientId(123);
        doc.setDateCreated(new Date());
        doc.setDateModified(new Date());
        doc.setStatus(MetaDataStatus.AVAILABLE);
        doc.setSpaceId(1);
        doc.setTransactionId("txn");
        doc.setMetadata(new Document(Map.of("k", "v")));
        DocumentAttachmentMetaData documentAttachmentMetaData = new DocumentAttachmentMetaData();
        doc.setDocumentAttachments(List.of(documentAttachmentMetaData));
        doc.setErrorMessage("err");

        DocumentRevision rev = DocumentUtil.createRevision(doc, "1");
        assertEquals("ext", rev.getExternalId());
        assertEquals("app", rev.getAppIdentifier());
        assertEquals(123, rev.getClientId());
        assertEquals(MetaDataStatus.AVAILABLE, rev.getStatus());
        assertEquals(1, rev.getSpaceId());
        assertEquals("txn", rev.getTransactionId());
        assertEquals("v", rev.getMetadata().get("k"));
        assertEquals(List.of(documentAttachmentMetaData), rev.getDocumentAttachments());
        assertEquals("err", rev.getErrorMessage());
    }

    @Test
    public void testCreateRevision_NullFields() {
        DocumentRevision rev = DocumentUtil.createRevision(doc, "2");
        assertNull(rev.getExternalId());
        assertEquals(2, rev.getSpaceId());
        assertNull(rev.getMetadata());
        assertNull(rev.getDocumentAttachments());
        assertNull(rev.getErrorMessage());
    }

    @Test
    public void testAppendDefaultValuesWithSpaceId() {
        int spaceId = 42;
        Map<String, Object> creds = new HashMap<>();
        creds.put("clientId", "123");
        creds.put("appIdentifier", "appId");
        when(config.getCredentials(spaceId)).thenReturn(creds);

        documentUtil.appendDefaultValuesWithSpaceId(doc, spaceId);

        assertEquals(spaceId, doc.getSpaceId());
        assertEquals(123, doc.getClientId());
        assertEquals("appId", doc.getAppIdentifier());
        assertEquals(MetaDataStatus.AVAILABLE, doc.getStatus());
        assertNotNull(doc.getTransactionId());
    }

    @Test
    public void testAppendDefaultValues_Success() {
        int spaceId = 99;
        doc.setSpaceId(spaceId);
        Map<String, Object> creds = new HashMap<>();
        creds.put("clientId", "456");
        creds.put("appIdentifier", "appX");
        when(config.getCredentials(spaceId)).thenReturn(creds);

        documentUtil.appendDefaultValues(doc);

        assertEquals(456, doc.getClientId());
        assertEquals("appX", doc.getAppIdentifier());
        assertEquals(MetaDataStatus.AVAILABLE, doc.getStatus());
        assertNotNull(doc.getTransactionId());
    }

    @Test(expected = NullPointerException.class)
    public void testAppendDefaultValues_SpaceIdZero() {
        doc.setSpaceId(0);
        documentUtil.appendDefaultValues(doc);
    }
}