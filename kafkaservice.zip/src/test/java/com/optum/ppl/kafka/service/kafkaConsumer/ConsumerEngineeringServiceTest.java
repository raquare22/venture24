package com.optum.ppl.kafka.service.kafkaConsumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.optum.ce.referrals.avro.ReferralEvent;
import com.optum.ppl.kafka.service.consumer.model.*;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.template.java.TemplateFactory;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.checkerframework.checker.units.qual.K;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.sql.Ref;
import java.util.*;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class ConsumerEngineeringServiceTest {

    @InjectMocks
    private ConsumerEngineeringService consumerEngineeringService;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private ObjectMapper objectMapper;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(consumerEngineeringService, "CONSUMER_ENGINEERING_SPACEID", 42);
        ReflectionTestUtils.setField(consumerEngineeringService, "queryTimeWindow", 15);
    }

    @Test
    public void testConsume_SuccessfulInsert() throws Exception {
        ConsumerRecord<String, ReferralEvent> record = new ConsumerRecord<>("topic", 0, 0L, "key",getKafkaMessage());

        consumerEngineeringService.consume(record);

    }

    @Test
    public void testConsume_EmptyMetadataList() throws Exception {
        ConsumerRecord<String, ReferralEvent> record = new ConsumerRecord<>("topic", 0, 0L, "key", new ReferralEvent());
        String metadataListStr = "[]";

        consumerEngineeringService.consume(record);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }


    @Test
    public void testProcessTopic_Exception() throws Exception {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", "bad_json");
        when(objectMapper.readValue(anyString(), ArgumentMatchers.<TypeReference<Map<String, Object>>>any()))
                .thenThrow(new RuntimeException("parse error"));

        java.lang.reflect.Method m = ConsumerEngineeringService.class.getDeclaredMethod("consumeTrackItPCPReferral", ConsumerRecord.class);
        m.setAccessible(true);
        m.invoke(consumerEngineeringService, record);

        verify(documentMetaDataService, never()).updateReferralDocumentStatus(anyString(), any());
    }

    private ReferralEvent getKafkaMessage1() throws Exception {
        String message = "{\"memberInfo\": {\"requestingMember\": {\"memberIdCardNbr\": \"00990917634\", \"firstName\": \"Fniodislrucw\", \"lastName\": \"Lnzyjvwwfl\", \"dob\": \"1981-01-31\", \"groupNumber\": \"0705077\", \"dependentSeqNbr\": \"00\"}, \"requestedMember\": {\"memberIdCardNbr\": \"00990917634\", \"firstName\": \"FNIODISLRUCW\", \"lastName\": \"LNZYJVWWFL\", \"groupNumber\": \"0705077\", \"dob\": \"1981-01-31\"}}, \"planDetails\": {\"insuranceType\": \"MEDICAL\", \"planEndDate\": \"2026-12-31\", \"planStartDate\": \"2026-01-01\", \"policyId\": \"705077\", \"policyType\": null}, \"providerDetails\": {\"primaryCareProviderFirstName\": \"Jeffrey\", \"primaryCareProviderLastName\": \"Moore\", \"primaryCareProviderCorpMpin\": \"002260423\", \"primaryCareProviderTin\": \"710892430\", \"referredToProviderFirstName\": \"Texas\", \"referredToProviderLastName\": \"Harris Methodist Hosp Steph\", \"referredToProviderTin\": \"751752253\", \"referredToProviderCorpMpin\": null, \"referredToProviderId\": \"724532\"}, \"referralDetails\": {\"requestId\": \"RF_eedb14be-7fa4-4673-98a8-9ee24efe5d59\", \"specialty\": null, \"comments\": \"test referral\", \"diagnosisCodes\": [\"\"]}}";
        ObjectMapper object = new ObjectMapper();
        ReferralEvent event = new ReferralEvent();

        event = object.readValue( message, new TypeReference<ReferralEvent>(){});


        System.out.println(event);
        return event;
    }


    private ReferralEvent getKafkaMessage() throws JsonMappingException, JsonProcessingException {

        ObjectMapper object = new ObjectMapper();

        String message =   """ 
                {
                "memberInfo": {
            "requestingMember": {
                "memberIdCardNbr": "162080645",
                        "firstName": "FNGVSLMDSRJM",
                        "lastName": "LNTWOEADGL",
                        "dob": "2000-05-19",
                        "groupNumber": "0021311",
                        "dependentSeqNbr": "01"
            },
            "requestedMember": {
                "memberIdCardNbr": "162080645",
                        "firstName": "FNGVSLMDSRJM",
                        "lastName": "LNTWOEADGL",
                        "groupNumber": "0021311",
                        "dob": "2000-05-19"
            }
        },
        "planDetails": {
            "insuranceType": "M",
                    "planEndDate": "2025-12-31",
                    "planStartDate": "2025-01-01",
                    "policyId": "092019",
                    "policyType": "Medical"
        },
        "providerDetails": {
            "primaryCareProviderFirstName": "FNGALILEO ",
                    "primaryCareProviderLastName": "LNHEALTH ",
                    "primaryCareProviderCorpMpin": "1831",
                    "primaryCareProviderTin": "9812391",
                    "referredToProviderFirstName": "FNKENDRA ",
                    "referredToProviderLastName": "LNMULHOLAND ",
                    "referredToProviderTin": "76231",
                    "referredToProviderCorpMpin": "981923",
                    "referredToProviderId": "005222521014"
        },
        "referralDetails": {
                   "requestId": "RF_64c11a80-0d9d-48a3-a100-bd80004dc7e7",
                    "specialty": "Dermatologist ",
                    "comments": "Requesting referrals for dermatologist",
                    "diagnosisCodes": [
            "A0100",
                    "A0101"
        ]
        }
  }

        """;

        ReferralEvent event = new ReferralEvent();

        event = object.readValue( message, new TypeReference<ReferralEvent>(){});


        System.out.println(event);
        return event;
    }


    @Test
    public void testConsume_SuccessfulInsertion() throws Exception {

        ReferralEvent event = getKafkaMessage1();
        ConsumerRecord<String, ReferralEvent> record = new ConsumerRecord<>("topic", 0, 0L, "key", event);
        String message = "{\"memberInfo\": {\"requestingMember\": {\"memberIdCardNbr\": \"00990917634\", \"firstName\": \"Fniodislrucw\", \"lastName\": \"Lnzyjvwwfl\", \"dob\": \"1981-01-31\", \"groupNumber\": \"0705077\", \"dependentSeqNbr\": \"00\"}, \"requestedMember\": {\"memberIdCardNbr\": \"00990917634\", \"firstName\": \"FNIODISLRUCW\", \"lastName\": \"LNZYJVWWFL\", \"groupNumber\": \"0705077\", \"dob\": \"1981-01-31\"}}, \"planDetails\": {\"insuranceType\": \"MEDICAL\", \"planEndDate\": \"2026-12-31\", \"planStartDate\": \"2026-01-01\", \"policyId\": \"705077\", \"policyType\": null}, \"providerDetails\": {\"primaryCareProviderFirstName\": \"Jeffrey\", \"primaryCareProviderLastName\": \"Moore\", \"primaryCareProviderCorpMpin\": \"002260423\", \"primaryCareProviderTin\": \"710892430\", \"referredToProviderFirstName\": \"Texas\", \"referredToProviderLastName\": \"Harris Methodist Hosp Steph\", \"referredToProviderTin\": \"751752253\", \"referredToProviderCorpMpin\": null, \"referredToProviderId\": \"724532\"}, \"referralDetails\": {\"requestId\": \"RF_eedb14be-7fa4-4673-98a8-9ee24efe5d59\", \"specialty\": null, \"comments\": \"test referral\", \"diagnosisCodes\": [\"\"]}}";

//        when(objectMapper.readValue(anyString(), eq(KafkaMessage.class))).thenReturn(getKafkaMessageObj());
//
//        when(objectMapper.writeValueAsString(any())).thenReturn(message);

        consumerEngineeringService.consume(record);

        verify(documentMetaDataService).insertMultiDocumentsWithSpaceId(anyList(), anyInt());

    }



    @Test
    public void testConsumeTrackItPCPReferral_DocumentFound_StatusNotReceived() throws Exception {
        // Arrange
        Map<String, Object> recordInfo = new HashMap<>();
        recordInfo.put("recordID", "req1");
        recordInfo.put("recordStatus", "APPROVED");
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("recordInfo", recordInfo);

        String msgStr = new ObjectMapper().writeValueAsString(jsonMap);
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "req1", msgStr);

        DocumentMetaData docMeta = new DocumentMetaData();
        org.bson.Document metadata = new org.bson.Document();
        docMeta.setId("docId");
        docMeta.setMetadata(metadata);

        when(objectMapper.readValue(anyString(), ArgumentMatchers.<TypeReference<Map<String, Object>>>any()))
                .thenReturn(jsonMap);
        when(documentMetaDataService.getReferralDocumentMetaData(eq("req1"), eq(42), eq("IN_PROCESS"), eq(15)))
                .thenReturn(docMeta);

        // Act
        consumerEngineeringService.consumeTrackItPCPReferral(record);

        // Assert
        assertEquals("APPROVED", metadata.get("referralStatus"));
        verify(documentMetaDataService).updateReferralDocumentStatus(eq("docId"), eq(metadata));
    }

    @Test
    public void testConsumeTrackItPCPReferral_DocumentFound_StatusReceived() throws Exception {
        // Arrange
        Map<String, Object> recordInfo = new HashMap<>();
        recordInfo.put("recordID", "req2");
        recordInfo.put("recordStatus", "Received");
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("recordInfo", recordInfo);

        String msgStr = new ObjectMapper().writeValueAsString(jsonMap);
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "req2", msgStr);

        DocumentMetaData docMeta = new DocumentMetaData();
        org.bson.Document metadata = new org.bson.Document();
        docMeta.setId("docId2");
        docMeta.setMetadata(metadata);

        when(objectMapper.readValue(anyString(), ArgumentMatchers.<TypeReference<Map<String, Object>>>any()))
                .thenReturn(jsonMap);
        when(documentMetaDataService.getReferralDocumentMetaData(eq("req2"), eq(42), eq("IN_PROCESS"), eq(15)))
                .thenReturn(docMeta);

        // Act
        consumerEngineeringService.consumeTrackItPCPReferral(record);

        // Assert
        assertNull(metadata.get("referralStatus"));
        verify(documentMetaDataService, never()).updateReferralDocumentStatus(anyString(), any());
    }

    @Test
    public void testConsumeTrackItPCPReferral_DocumentNotFound() throws Exception {
        // Arrange
        Map<String, Object> recordInfo = new HashMap<>();
        recordInfo.put("recordID", "req3");
        recordInfo.put("recordStatus", "DENIED");
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("recordInfo", recordInfo);

        String msgStr = new ObjectMapper().writeValueAsString(jsonMap);
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "req3", msgStr);

        when(objectMapper.readValue(anyString(), ArgumentMatchers.<TypeReference<Map<String, Object>>>any()))
                .thenReturn(jsonMap);
        when(documentMetaDataService.getReferralDocumentMetaData(eq("req3"), eq(42), eq("IN_PROCESS"), eq(15)))
                .thenReturn(null);

        // Act
        consumerEngineeringService.consumeTrackItPCPReferral(record);

        // Assert
        verify(documentMetaDataService, never()).updateReferralDocumentStatus(anyString(), any());
    }

    @Test
    public void testConsume_InvalidMetadata_NullTopLevelField_DoesNotInsert() throws Exception {
        // Arrange

        ReferralEvent event = new ReferralEvent();
        ConsumerRecord<String, ReferralEvent> record = new ConsumerRecord<>("topic", 0, 0L, "key", event);
        TemplateHandler templateHandler = mock(TemplateHandler.class);

        try (MockedStatic<TemplateFactory> factoryMock = mockStatic(TemplateFactory.class)) {
            factoryMock.when(() -> TemplateFactory.getInstance(anyString())).thenReturn(templateHandler);

            // Act
            consumerEngineeringService.consume(record);

            // Assert: early-return, no insert, and template conversion not attempted
            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
            verify(templateHandler, never()).convertWithTemplate(any());
        }
    }

    @Test
    public void testConsume_InvalidMetadata_NullRequestedMember_DoesNotInsert() throws Exception {
        // Arrange

        ReferralEvent event = new ReferralEvent();
        ConsumerRecord<String, ReferralEvent> record = new ConsumerRecord<>("topic", 0, 0L, "key", event);


        TemplateHandler templateHandler = mock(TemplateHandler.class);

        try (MockedStatic<TemplateFactory> factoryMock = mockStatic(TemplateFactory.class)) {
            factoryMock.when(() -> TemplateFactory.getInstance(anyString())).thenReturn(templateHandler);
            // Act
            consumerEngineeringService.consume(record);

            // Assert: early-return, no insert, and template conversion not attempted
            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
            verify(templateHandler, never()).convertWithTemplate(any());
        }
    }

    @Test
    public void testConsume_ValidateMetadataFieldsThrows_ExceptionCaught_NoInsert() throws Exception {
        // Arrange
        ReferralEvent event = new ReferralEvent();
        ConsumerRecord<String, ReferralEvent> record = new ConsumerRecord<>("topic", 0, 0L, "key", event);
        String message = "{\"memberInfo\": {\"requestingMember\": {\"memberIdCardNbr\": \"00990917634\", \"firstName\": \"Fniodislrucw\", \"lastName\": \"Lnzyjvwwfl\", \"dob\": \"1981-01-31\", \"groupNumber\": \"0705077\", \"dependentSeqNbr\": \"00\"}, \"requestedMember\": {\"memberIdCardNbr\": \"00990917634\", \"firstName\": \"FNIODISLRUCW\", \"lastName\": \"LNZYJVWWFL\", \"groupNumber\": \"0705077\", \"dob\": \"1981-01-31\"}}, \"planDetails\": {\"insuranceType\": \"MEDICAL\", \"planEndDate\": \"2026-12-31\", \"planStartDate\": \"2026-01-01\", \"policyId\": \"705077\", \"policyType\": null}, \"providerDetails\": {\"primaryCareProviderFirstName\": \"Jeffrey\", \"primaryCareProviderLastName\": \"Moore\", \"primaryCareProviderCorpMpin\": \"002260423\", \"primaryCareProviderTin\": \"710892430\", \"referredToProviderFirstName\": \"Texas\", \"referredToProviderLastName\": \"Harris Methodist Hosp Steph\", \"referredToProviderTin\": \"751752253\", \"referredToProviderCorpMpin\": null, \"referredToProviderId\": \"724532\"}, \"referralDetails\": {\"requestId\": \"RF_eedb14be-7fa4-4673-98a8-9ee24efe5d59\", \"specialty\": null, \"comments\": \"test referral\", \"diagnosisCodes\": [\"\"]}}";

        KafkaMessage msg = new KafkaMessage();
        msg.setMemberInfo(new MemberInfo());
        msg.setPlanDetails(new PlanDetails());
        msg.setProviderDetails(new ProviderDetails());
        msg.setReferralDetails(new ReferralDetails());

        TemplateHandler templateHandler = mock(TemplateHandler.class);

        try (MockedStatic<TemplateFactory> factoryMock = mockStatic(TemplateFactory.class)) {
            factoryMock.when(() -> TemplateFactory.getInstance(anyString())).thenReturn(templateHandler);

            // Act
            consumerEngineeringService.consume(record);

            // Assert: exception in validateMetadataFields => returns false => early return from consume()
            verify(templateHandler, never()).convertWithTemplate(any());
            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

}