package com.optum.ppl.kafka.service.template;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.bson.Document;
import org.json.JSONException;
import org.junit.Test;

import com.optum.ppl.kafka.service.template.java.TemplateFactory;



public class MnRKafkaDocumentTemplateTest {
	
	Map<String, String> map = new HashMap<>();

	@Test
	public void testKafkaDocumentTemplate() throws IOException, JSONException {
		
		
        String jsonString= inputJson();

		map.put("key", "cd566a5f-1b62-4b63-bb7e-09369349ef69");
		map.put("kafkaResponse", jsonString);

		String output = TemplateFactory.getInstance(Templates.KAFKA_MNR_DOCUMENT.getTemplate())
				.convertWithTemplate(map);
		System.out.println(output);

		org.bson.Document metadata = Document.parse(output);

		System.out.println(metadata);
	}
	
	
	
	String inputJson()
	{
		
		return """
				
				{
    "recordInfo": {
        "recordID": "540620889-825626883-1722095580000",
        "recordType": "EMERGENCY",
        "encounterID": "86af17358dbe9778f9830c39b6bdfe2f"
    },
    "providerDetails": {
        "admittingProviderName": "BEBARTA VIKHYAT",
        "providerTin": "540620889",
        "providerName": "LOFTON, SHERI A.",
        "facilityProvider": "INOVA - FAIRFAX HOSPITAL",
        "providerNpi": "1114988730"
    },
    "memberDetails": {
        "patientFirstName": "test",
        "patientLastName": "test",
        "lob": "test",
        "state": "test",
        "patientDateOfBirth": "03/20/2020"
    },
    "encounterDetails": {
        "admitDate": "2024-05-22 12:46:00",
        "dischargeDisposition": [
           "Atherosclerotic heart disease of native coronary artery without angina pectoris",
           "Ischemic cardiomyopathy",
           "Chronic kidney disease, stage 3 (moderate)",
           "Essential (primary) hypertension"
        ],
        "chiefComplaintList": [
          "Stenosis of other vascular prosthetic devices, implants and grafts, initial encounter",
          "Unspecified fall, initial encounter",
          "Fracture of unspecified carpal bone, right wrist, initial encounter for closed fracture"
        ]
    }
}
				
				""";
	}
}