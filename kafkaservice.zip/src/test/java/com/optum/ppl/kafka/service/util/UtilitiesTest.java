package com.optum.ppl.kafka.service.util;

import org.junit.Test;

import static org.junit.Assert.*;

public class UtilitiesTest {

    @Test
    public void testValidateProviderEmail_ValidEmails() {
        assertTrue(Utilities.validateProviderEmail("test@example.com"));
        assertTrue(Utilities.validateProviderEmail("user.name+tag@sub.domain.com"));
        assertTrue(Utilities.validateProviderEmail("user_name@domain.co"));
        assertTrue(Utilities.validateProviderEmail("user-name@domain.org"));
        assertTrue(Utilities.validateProviderEmail("user123@domain123.com"));
    }

    @Test
    public void testValidateProviderEmail_InvalidEmails() {
        assertFalse(Utilities.validateProviderEmail("plainaddress"));
        assertFalse(Utilities.validateProviderEmail("@missingusername.com"));
        assertFalse(Utilities.validateProviderEmail("username@.com"));
        assertFalse(Utilities.validateProviderEmail("username@domain..com"));
        assertFalse(Utilities.validateProviderEmail("username@domain,com"));
        assertFalse(Utilities.validateProviderEmail("username@domain@domain.com"));
    }

    @Test
    public void testValidateProviderEmail_EmptyOrNull() {
        assertFalse(Utilities.validateProviderEmail(""));
        assertFalse(Utilities.validateProviderEmail(null));
    }
}