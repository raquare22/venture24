package com.optum.ppl.kafka.service.template;


import org.junit.Before;
import org.junit.Test;
import org.stringtemplate.v4.ST;

import com.optum.ppl.kafka.service.template.java.impl.KafkaDocumentTemplate;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.mockito.ArgumentMatchers.argThat;

public class KafkaDocumentTemplateTest {

    private KafkaDocumentTemplate kafkaDocumentTemplate;

    @Before
    public void setUp() {
        kafkaDocumentTemplate = new KafkaDocumentTemplate();
    }

    @Test
    public void testFormatTinWithValidTin() throws Exception {
        Method formatTinMethod = KafkaDocumentTemplate.class.getDeclaredMethod("formatTin", String.class);
        formatTinMethod.setAccessible(true);

        String tin = "12345";
        String formattedTin = (String) formatTinMethod.invoke(kafkaDocumentTemplate, tin);
        assertEquals("000012345", formattedTin);
    }

    @Test
    public void testFormatTinWithEmptyTin() throws Exception {
        Method formatTinMethod = KafkaDocumentTemplate.class.getDeclaredMethod("formatTin", String.class);
        formatTinMethod.setAccessible(true);

        String tin = "";
        String formattedTin = (String) formatTinMethod.invoke(kafkaDocumentTemplate, tin);
        assertEquals("", formattedTin);
    }

    @Test
    public void testFormatTinWithNullTin() throws Exception {
        Method formatTinMethod = KafkaDocumentTemplate.class.getDeclaredMethod("formatTin", String.class);
        formatTinMethod.setAccessible(true);

        String formattedTin = (String) formatTinMethod.invoke(kafkaDocumentTemplate, (String) null);
        assertEquals(null, formattedTin);
    }

    @Test
    public void testFormatTinWithNineCharacterTin() throws Exception {
        Method formatTinMethod = KafkaDocumentTemplate.class.getDeclaredMethod("formatTin", String.class);
        formatTinMethod.setAccessible(true);

        String tin = "123456789";
        String formattedTin = (String) formatTinMethod.invoke(kafkaDocumentTemplate, tin);
        assertEquals("123456789", formattedTin);
    }

    @Test
    public void testConvertWithTemplate() throws Exception {
        // Mock the template
        ST mockTemplate = mock(ST.class);
        TemplateLoader mockTemplateLoader = mock(TemplateLoader.class);
        when(mockTemplateLoader.getTemplate(Templates.CNS_KAFKA_MESSAGE)).thenReturn(mockTemplate);
        when(mockTemplate.add(anyString(), any())).thenReturn(mockTemplate);
        when(mockTemplate.render()).thenReturn("Rendered Template");

        // Use reflection to set the protected 'templateLoader' field
        Field templateLoaderField = KafkaDocumentTemplate.class.getSuperclass().getDeclaredField("templateLoader");
        templateLoaderField.setAccessible(true);
        templateLoaderField.set(kafkaDocumentTemplate, mockTemplateLoader);

        // Create a sample input
        Map<String, Object> pojo = new HashMap<>();
        pojo.put("key", "transaction123");
        pojo.put("kafkaResponse", "{\"recordInfo\":{},\"memberDetails\":{},\"providerDetails\":{\"providerTin\":\"12345\"}}");

        // Call the method
        String result = kafkaDocumentTemplate.convertWithTemplate(pojo);

        // Verify the behavior
        assertNotNull(result);
        verify(mockTemplate, times(1)).render();
    }

    @Test
    public void testConvertWithTemplate_WithBhProviderList() throws Exception {
        // Mock the template and loader
        ST mockTemplate = mock(ST.class);
        TemplateLoader mockTemplateLoader = mock(TemplateLoader.class);
        when(mockTemplateLoader.getTemplate(Templates.CNS_KAFKA_MESSAGE)).thenReturn(mockTemplate);
        when(mockTemplate.add(anyString(), any())).thenReturn(mockTemplate);
        when(mockTemplate.render()).thenReturn("Rendered Template");

        // Inject the mock template loader
        Field templateLoaderField = KafkaDocumentTemplate.class.getSuperclass().getDeclaredField("templateLoader");
        templateLoaderField.setAccessible(true);
        templateLoaderField.set(kafkaDocumentTemplate, mockTemplateLoader);

        // Build a kafkaResponse with providerDetails containing bhProviderList
        String kafkaResponseJson = "{"
            + "\"recordInfo\":{},"
            + "\"memberDetails\":{},"
            + "\"providerDetails\":{"
            + "  \"providerTin\":\"11111\","
            + "  \"providerNpi\":\"npi1\","
            + "  \"admittingProviderName\":\"adm1\","
            + "  \"facilityProvider\":\"fac1\","
            + "  \"providerName\":\"prov1\","
            + "  \"bhProviderList\":["
            + "    {\"providerTin\":\"22222\",\"providerNpi\":\"npi2\",\"providerName\":\"bhProv1\"},"
            + "    {\"providerTin\":\"33333\",\"providerNpi\":\"npi3\",\"providerName\":\"bhProv2\"}"
            + "  ]"
            + "}"
            + "}";

        Map<String, Object> pojo = new HashMap<>();
        pojo.put("key", "txn456");
        pojo.put("kafkaResponse", kafkaResponseJson);

        // Call the method
        String result = kafkaDocumentTemplate.convertWithTemplate(pojo);

        // Verify the template was rendered
        assertNotNull(result);
        verify(mockTemplate, times(1)).render();

        // Verify providerInfoList contains main and BH providers with correct fields
        verify(mockTemplate).add(anyString(), argThat(list -> {
            if (!(list instanceof java.util.List)) return false;
            java.util.List<?> providerList = (java.util.List<?>) list;
            if (providerList.size() != 3) return false;
            Map<?,?> main = (Map<?,?>) providerList.get(0);
            Map<?,?> bh1 = (Map<?,?>) providerList.get(1);
            Map<?,?> bh2 = (Map<?,?>) providerList.get(2);
            return Boolean.FALSE.equals(main.get("isBHProvider"))
                && Boolean.TRUE.equals(bh1.get("isBHProvider"))
                && Boolean.TRUE.equals(bh2.get("isBHProvider"))
                && "000022222".equals(bh1.get("providerTin"))
                && "bhProv1".equals(bh1.get("providerName"))
                && "000033333".equals(bh2.get("providerTin"))
                && "bhProv2".equals(bh2.get("providerName"));
        }));
    }
}