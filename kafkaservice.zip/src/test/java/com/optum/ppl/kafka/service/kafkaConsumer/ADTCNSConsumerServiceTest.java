package com.optum.ppl.kafka.service.kafkaConsumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
public class ADTCNSConsumerServiceTest {

    @InjectMocks
    ADTCNSConsumerService adtcnsConsumerService;

    @Mock
    DocumentMetaDataService documentMetaDataService;

    @Mock
    TemplateHandler templateHandler;

    @Mock
    ConsumerRecord<String, String> consumerRecord;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(adtcnsConsumerService, "ADT_CNS_SPACEID", 123);
    }

    @Test
    public void testConsume_HappyPath() throws Exception {
        String key = "testKey";
        String value = """
        {
          "recordInfo": {},
          "memberDetails": {},
          "providerDetails": {
            "providerTin": "12345",
            "providerNpi": "9876543210",
            "admittingProviderName": "Dr. Smith",
            "facilityProvider": "Facility A",
            "providerName": "Provider X",
            "bhProviderList": []
          }
        }
        """;
        List<Document> docList = Collections.singletonList(new Document("field", "value"));
        ObjectMapper mapper = new ObjectMapper();
        String metadataListStr = mapper.writeValueAsString(docList);

        when(consumerRecord.key()).thenReturn(key);
        when(consumerRecord.value()).thenReturn(value);

        adtcnsConsumerService.consume(consumerRecord);

        ArgumentCaptor<List<DocumentMetaData>> captor = ArgumentCaptor.forClass(List.class);
        verify(documentMetaDataService).insertMultiDocumentsWithSpaceId(captor.capture(), eq(123));
        List<DocumentMetaData> inserted = captor.getValue();
        assert inserted.size() == 1;
        assert inserted.get(0).getStatus() == MetaDataStatus.AVAILABLE;
    }

    @Test
    public void testConsume_EmptyMetadataList() throws Exception {
        String key = "testKey";
        String value = "testValue";
        ObjectMapper mapper = new ObjectMapper();
        String metadataListStr = mapper.writeValueAsString(Collections.emptyList());

        when(consumerRecord.key()).thenReturn(key);
        when(consumerRecord.value()).thenReturn(value);

        adtcnsConsumerService.consume(consumerRecord);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsume_ExceptionDuringProcessing() throws Exception {
        String key = "testKey";
        String value = "testValue";

        when(consumerRecord.key()).thenReturn(key);
        when(consumerRecord.value()).thenReturn(value);

        adtcnsConsumerService.consume(consumerRecord);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }
}