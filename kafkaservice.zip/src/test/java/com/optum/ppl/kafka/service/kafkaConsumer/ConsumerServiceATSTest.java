package com.optum.ppl.kafka.service.kafkaConsumer;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.kafka.model.ATSKafka;
import com.optum.ppl.kafka.service.kafka.model.CaseInfo;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.template.java.TemplateFactory;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ConsumerServiceATSTest {

    @InjectMocks
    private ConsumerServiceATS consumerServiceATS;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private TemplateHandler templateHandler;

    private AutoCloseable templateFactoryMockedStatic;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(consumerServiceATS, "ATS_SPACEID", 123);
        ReflectionTestUtils.setField(consumerServiceATS, "queryTimeWindow", 15);

        templateFactoryMockedStatic = mockStatic(TemplateFactory.class);
        when(TemplateFactory.getInstance(anyString())).thenReturn(templateHandler);
    }

    @After
    public void tearDown() throws Exception {
        if (templateFactoryMockedStatic != null) {
            templateFactoryMockedStatic.close();
        }
    }

    @Test
    public void testConsumePrimary_InsertsNewDocument() {
        String key = "txn1";
        String value = """
        {
          "CaseInfo": { "CaseNumber": "CASE123" }
        }
        """;
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        when(documentMetaDataService.getATSDocumentMetaData(anyString(), anyInt(), anyInt())).thenReturn(null);
        when(templateHandler.convertWithTemplate(anyMap())).thenReturn("{\"meta\":1}");

        consumerServiceATS.consumePrimary(record);

        verify(documentMetaDataService).insertMultiDocumentsWithSpaceId(anyList(), eq(123));
    }

    @Test
    public void testConsumePrimary_UpdatesExistingDocument() {
        String key = "txn2";
        String value = " {\"CaseInfo\": { \"CaseNumber\": \"CASE456\" }}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);


        DocumentMetaData docMeta = new DocumentMetaData();
        docMeta.setId("docId");

        when(documentMetaDataService.getATSDocumentMetaData(eq("CASE456"), anyInt(), anyInt())).thenReturn(docMeta);
        when(templateHandler.convertWithTemplate(anyMap())).thenReturn("{\"meta\":2}");

        consumerServiceATS.consumePrimary(record);

        verify(documentMetaDataService).updateDocMetaData(eq(docMeta), eq("docId"));
    }

    @Test
    public void testConsumeSecondary_InsertsNewDocument() throws Exception {
        String key = "txn4";
        String value = """
        {
          "CaseNumber": "CASE789",
          "AttemptNumber": 1,
          "TRN_TaskFlowId": 100,
          "TwoWayStatus": { "Value": "APPROVED" }
        }
        """;
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        Map<String, Object> kafkaResponseMap = new HashMap<>();
        kafkaResponseMap.put("CaseNumber", "CASE789");
        kafkaResponseMap.put("AttemptNumber", 1);
        kafkaResponseMap.put("TRN_TaskFlowId", 100);
        kafkaResponseMap.put("TwoWayStatus", Map.of("Value", "APPROVED"));

        DocumentMetaData docMeta = new DocumentMetaData();
        docMeta.setMetadata(new Document());

        // Use thenAnswer to return the correct map for each call
        Mockito.when(objectMapper.writeValueAsString(any())).thenReturn("{ \"Value\": \"APPROVED\" }");
        Mockito.when(objectMapper.readValue(anyString(), any(TypeReference.class)))
            .thenAnswer(invocation -> {
                String arg = invocation.getArgument(0);
                if (arg.contains("CaseNumber")) {
                    return kafkaResponseMap;
                }
                if (arg.contains("APPROVED")) {
                    return Map.of("Value", "APPROVED");
                }
                return null;
            });

        Mockito.when(documentMetaDataService.getATSDocumentMetaData(anyString(), anyInt(), anyInt())).thenReturn(docMeta);

        consumerServiceATS.consumeSecondary(record);

        Mockito.verify(documentMetaDataService).insertMultiDocumentsWithSpaceId(anyList(), eq(123));
    }

    @Test
    public void testConsumeSecondary_DocumentNotFound() throws Exception {
        String key = "txn5";
        String value = """
        {
          "CaseNumber": "CASE000",
          "AttemptNumber": 1,
          "TRN_TaskFlowId": 100,
          "TwoWayStatus": { "Value": "DENIED" }
        }
        """;
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        Map<String, Object> kafkaResponseMap = new HashMap<>();
        kafkaResponseMap.put("CaseNumber", "CASE000");
        kafkaResponseMap.put("AttemptNumber", 1);
        kafkaResponseMap.put("TRN_TaskFlowId", 100);
        kafkaResponseMap.put("TwoWayStatus", Map.of("Value", "DENIED"));

        when(objectMapper.readValue(anyString(), any(TypeReference.class))).thenReturn(kafkaResponseMap).thenReturn(Map.of("Value", "DENIED"));

        consumerServiceATS.consumeSecondary(record);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsumeSecondary_WithSubmitterEmailAddress_SetsProviderEmailId() throws Exception {
        String key = "txn-email";
        String value = """
        {
          "CaseNumber": "CASE111",
          "AttemptNumber": 1,
          "TRN_TaskFlowId": 200,
          "TwoWayStatus": { "Value": "APPROVED" },
          "SubmitterEmailAddress": "provider@example.com"
        }
        """;
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        Map<String, Object> kafkaResponseMap = new HashMap<>();
        kafkaResponseMap.put("CaseNumber", "CASE111");
        kafkaResponseMap.put("AttemptNumber", 1);
        kafkaResponseMap.put("TRN_TaskFlowId", 200);
        kafkaResponseMap.put("TwoWayStatus", Map.of("Value", "APPROVED"));
        kafkaResponseMap.put("SubmitterEmailAddress", "provider@example.com");

        Map<String, Object> twoWayStatus = new HashMap<>();
        twoWayStatus.put("Value", "APPROVED");

        DocumentMetaData docMeta = new DocumentMetaData();
        Document metadata = new Document();
        docMeta.setMetadata(metadata);

        when(objectMapper.writeValueAsString(any())).thenReturn("");
        when(objectMapper.readValue(anyString(), any(TypeReference.class)))
            .thenReturn(kafkaResponseMap)
            .thenReturn(twoWayStatus);
        when(documentMetaDataService.getATSDocumentMetaData(anyString(), anyInt(), anyInt())).thenReturn(docMeta);

        consumerServiceATS.consumeSecondary(record);

        verify(documentMetaDataService).insertMultiDocumentsWithSpaceId(argThat(list -> {
            DocumentMetaData inserted = list.get(0);
            return "provider@example.com".equals(inserted.getMetadata().get("providerEmailId"));
        }), eq(123));
    }

    @Test
    public void testConsumeSecondary_DocMetaDataNull_LogsAndReturns() throws Exception {
        String key = "txn-missing-doc";
        String value = """
        {
          "CaseNumber": "CASE404",
          "AttemptNumber": 1,
          "TRN_TaskFlowId": 101,
          "TwoWayStatus": { "Value": "PENDING" }
        }
        """;
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        Map<String, Object> kafkaResponseMap = new HashMap<>();
        kafkaResponseMap.put("CaseNumber", "CASE404");
        kafkaResponseMap.put("AttemptNumber", 1);
        kafkaResponseMap.put("TRN_TaskFlowId", 101);
        kafkaResponseMap.put("TwoWayStatus", Map.of("Value", "PENDING"));

        when(objectMapper.writeValueAsString(any())).thenReturn("");
        when(objectMapper.readValue(anyString(), any(TypeReference.class)))
            .thenReturn(kafkaResponseMap)
            .thenReturn(Map.of("Value", "PENDING"));
        when(documentMetaDataService.getATSDocumentMetaData(anyString(), anyInt(), anyInt())).thenReturn(null);

        consumerServiceATS.consumeSecondary(record);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }
}