package com.optum.ppl.kafka.service.kafkaConsumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.kafka.model.RecordCount;
import com.optum.ppl.kafka.service.kafka.model.TrackItKafka;
import com.optum.ppl.kafka.service.template.java.TemplateFactory;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class TrackItConsumerServiceTest {

    @InjectMocks
    private TrackItConsumerService service;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private TemplateHandler templateHandler;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(service, "TrackIt_SPACEID", 123);
    }

    @Test
    public void testConsume_HappyPath() throws Exception {
        // Arrange
        TrackItKafka kafka = new TrackItKafka();
        kafka.setRecordID("rec-1");
        kafka.setProviderEmailId("test@example.com");
        List<RecordCount> counts = new ArrayList<>();
        RecordCount rc = new RecordCount();
        rc.setDailyReconCount(1);
        counts.add(rc);
        kafka.setRecordsCountList(counts);

        ObjectMapper mapper = spy(new ObjectMapper());
        String json = mapper.writeValueAsString(kafka);

        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", json);

        try (MockedStatic<TemplateFactory> mockedStatic = mockStatic(TemplateFactory.class)) {
            mockedStatic.when(() -> TemplateFactory.getInstance(anyString())).thenReturn(templateHandler);
            when(templateHandler.convertWithTemplate(anyMap())).thenReturn("{\"foo\":\"bar\"}");

            // Act
            service.consume(record);

            // Assert
            verify(documentMetaDataService, times(1)).insertMultiDocumentsWithSpaceId(anyList(), eq(123));
        }
    }

    @Test
    public void testConsume_InvalidJson() throws Exception {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", "invalid json");
        // No exception should be thrown, just error log and return
        service.consume(record);
        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsume_ValidationFails() throws Exception {
        TrackItKafka kafka = new TrackItKafka(); // missing required fields
        ObjectMapper mapper = spy(new ObjectMapper());
        String json = mapper.writeValueAsString(kafka);
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", json);

        service.consume(record);
        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsume_TemplateHandlerThrows() throws Exception {
        TrackItKafka kafka = new TrackItKafka();
        kafka.setRecordID("rec-1");
        kafka.setProviderEmailId("test@example.com");
        List<RecordCount> counts = new ArrayList<>();
        RecordCount rc = new RecordCount();
        rc.setDailyReconCount(1);
        counts.add(rc);
        kafka.setRecordsCountList(counts);

        ObjectMapper mapper = spy(new ObjectMapper());
        String json = mapper.writeValueAsString(kafka);
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", json);

        try (MockedStatic<TemplateFactory> mockedStatic = mockStatic(TemplateFactory.class)) {
            mockedStatic.when(() -> TemplateFactory.getInstance(anyString())).thenReturn(templateHandler);
            when(templateHandler.convertWithTemplate(anyMap())).thenThrow(new IllegalArgumentException("fail"));

            service.consume(record);
            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_EmptyInsertedDocList() throws Exception {
        // Simulate templateHandler returning invalid JSON so Document can't be parsed
        TrackItKafka kafka = new TrackItKafka();
        kafka.setRecordID("rec-1");
        kafka.setProviderEmailId("test@example.com");
        List<RecordCount> counts = new ArrayList<>();
        RecordCount rc = new RecordCount();
        rc.setDailyReconCount(1);
        counts.add(rc);
        kafka.setRecordsCountList(counts);

        ObjectMapper mapper = spy(new ObjectMapper());
        String json = mapper.writeValueAsString(kafka);
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", json);

        try (MockedStatic<TemplateFactory> mockedStatic = mockStatic(TemplateFactory.class)) {
            mockedStatic.when(() -> TemplateFactory.getInstance(anyString())).thenReturn(templateHandler);
            when(templateHandler.convertWithTemplate(anyMap())).thenReturn("invalid json");

            service.consume(record);
            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_InsertThrows() throws Exception {
        // Happy path up to insert, but insert throws
        TrackItKafka kafka = new TrackItKafka();
        kafka.setRecordID("rec-1");
        kafka.setProviderEmailId("test@example.com");
        List<RecordCount> counts = new ArrayList<>();
        RecordCount rc = new RecordCount();
        rc.setDailyReconCount(1);
        counts.add(rc);
        kafka.setRecordsCountList(counts);

        ObjectMapper mapper = spy(new ObjectMapper());
        String json = mapper.writeValueAsString(kafka);
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", json);

        try (MockedStatic<TemplateFactory> mockedStatic = mockStatic(TemplateFactory.class)) {
            mockedStatic.when(() -> TemplateFactory.getInstance(anyString())).thenReturn(templateHandler);
            when(templateHandler.convertWithTemplate(anyMap())).thenReturn("{\"foo\":\"bar\"}");
            doThrow(new RuntimeException("mongo fail")).when(documentMetaDataService).insertMultiDocumentsWithSpaceId(anyList(), anyInt());

            service.consume(record);
            verify(documentMetaDataService, times(1)).insertMultiDocumentsWithSpaceId(anyList(), eq(123));
        }
    }

    @Test
    public void testConsume_ValidJsonButMappingFails_JsonProcessingException() throws Exception {
        // Arrange
        TrackItKafka kafka = new TrackItKafka();
        kafka.setRecordID("rec-1");
        kafka.setProviderEmailId("test@example.com");
        List<RecordCount> counts = new ArrayList<>();
        RecordCount rc = new RecordCount();
        rc.setDailyReconCount(1);
        counts.add(rc);
        kafka.setRecordsCountList(counts);

        ObjectMapper mapper = spy(new ObjectMapper());
        String json = mapper.writeValueAsString(kafka);
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", json);

        try (MockedStatic<TemplateFactory> mockedStatic = mockStatic(TemplateFactory.class)) {
            mockedStatic.when(() -> TemplateFactory.getInstance(anyString())).thenReturn(templateHandler);
            // Return a valid JSON array, which cannot be mapped to Document (expect JsonProcessingException)
            when(templateHandler.convertWithTemplate(anyMap())).thenReturn("[1,2,3]");

            // Act
            service.consume(record);

            // Assert: No document should be inserted
            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_InsertedDocListEmpty_WarnsAndReturns() throws Exception {
        // Arrange
        TrackItKafka kafka = new TrackItKafka();
        kafka.setRecordID("rec-1");
        kafka.setProviderEmailId("test@example.com");
        List<RecordCount> counts = new ArrayList<>();
        RecordCount rc = new RecordCount();
        rc.setDailyReconCount(1);
        counts.add(rc);
        kafka.setRecordsCountList(counts);

        ObjectMapper mapper = spy(new ObjectMapper());
        String json = mapper.writeValueAsString(kafka);
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", json);

        try (MockedStatic<TemplateFactory> mockedStatic = mockStatic(TemplateFactory.class)) {
            mockedStatic.when(() -> TemplateFactory.getInstance(anyString())).thenReturn(templateHandler);
            // Return a valid JSON array, which cannot be mapped to Document (causes JsonProcessingException)
            when(templateHandler.convertWithTemplate(anyMap())).thenReturn("[1,2,3]");

            // Act
            service.consume(record);

            // Assert: No document should be inserted
            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_MissingProviderEmailId_ThrowsIllegalArgumentException() throws Exception {
        // Arrange: providerEmailId is null
        TrackItKafka kafka = new TrackItKafka();
        kafka.setRecordID("rec-1");
        kafka.setProviderEmailId(null); // missing email
        List<RecordCount> counts = new ArrayList<>();
        RecordCount rc = new RecordCount();
        rc.setDailyReconCount(1);
        counts.add(rc);
        kafka.setRecordsCountList(counts);

        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(kafka);
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", json);

        try {
            service.consume(record);
        } catch (IllegalArgumentException e) {
            assertEquals("Email address is required", e.getMessage());
        }
        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsume_EmptyRecordsCountList_ThrowsIllegalArgumentException() throws Exception {
        // Arrange: recordsCountList is empty
        TrackItKafka kafka = new TrackItKafka();
        kafka.setRecordID("rec-1");
        kafka.setProviderEmailId("test@example.com");
        kafka.setRecordsCountList(new ArrayList<>()); // empty list

        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(kafka);
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", json);

        try {
            service.consume(record);
        } catch (IllegalArgumentException e) {
            assertEquals("At least one RecordCount is required", e.getMessage());
        }
        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

}