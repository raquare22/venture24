package com.optum.ppl.kafka.service.template.java.render;

import org.junit.Before;
import org.junit.Test;

import java.util.Locale;

import static org.junit.Assert.*;

public class CustomStringRendererTest {

    private CustomStringRenderer renderer;

    @Before
    public void setUp() {
        renderer = new CustomStringRenderer();
    }

    @Test
    public void testToString_NullFormatString_ReturnsOriginal() {
        String result = renderer.toString("abc", null, Locale.US);
        assertEquals("abc", result);
    }

    @Test
    public void testToString_BlankFormatString_ReturnsOriginal() {
        String result = renderer.toString("abc", "   ", Locale.US);
        assertEquals("abc", result);
    }

    @Test
    public void testToString_SubStringHandler() {
        String result = renderer.toString("HelloWorld", "substring-2-7", Locale.US);
        assertEquals("lloWo", result);
    }

    @Test
    public void testToString_SubStringHandler_OutOfBounds() {
        String result = renderer.toString("abc", "substring-2-10", Locale.US);
        assertEquals("", result);
    }

    @Test
    public void testToString_MyStringHandler_LeftAlign() {
        String result = renderer.toString("abc", "5-*-L", Locale.US);
        assertEquals("**abc", result);
    }

    @Test
    public void testToString_MyStringHandler_RightAlign() {
        String result = renderer.toString("abc", "5-*-R", Locale.US);
        assertEquals("abc**", result);
    }

    @Test
    public void testToString_MyStringHandler_LengthLessThanValue() {
        String result = renderer.toString("abcdef", "3-*-L", Locale.US);
        assertEquals("abc", result); // "abc" padded to length 3 with '*', but already 3 chars
    }

    @Test
    public void testToString_MyStringHandler_EmptyPaddingString() {
        String result = renderer.toString("abc", "5--L", Locale.US);
        assertNull(result);
    }

    @Test
    public void testToString_DefaultSuper() {
        // Format string not starting with 's' or digit, should call super
        String result = renderer.toString("abc", "z-format", Locale.US);
        assertEquals("z-format", result); // StringRenderer just returns the string
    }

    @Test
    public void testSubStringHandler_Valid() {
        String result = renderer.toString("HelloWorld", "substring-0-5", Locale.US);
        assertEquals("Hello", result);
    }

    @Test
    public void testMyStringHandler_LeftAlign() {
        String result = renderer.toString("abc", "6-0-L", Locale.US);
        assertEquals("000abc", result);
    }

    @Test
    public void testMyStringHandler_RightAlign() {
        String result = renderer.toString("abc", "6-0-R", Locale.US);
        assertEquals("abc000", result);
    }

    @Test
    public void testToString_MyStringHandler_NumberFormatException() {
        // The first part ("abc") is not a number, so NumberFormatException is thrown and null is returned
        String result = renderer.toString("abc", "0bc-*-L", Locale.US);
        assertNull(result);
    }
}