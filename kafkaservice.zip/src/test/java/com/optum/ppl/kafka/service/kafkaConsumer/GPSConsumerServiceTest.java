package com.optum.ppl.kafka.service.kafkaConsumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.kafka.model.KafkaMessageGPS;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
public class GPSConsumerServiceTest {

    @InjectMocks
    private GPSConsumerService gpsConsumerService;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private ObjectMapper objectMapper;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(gpsConsumerService, "ssbci_spaceId", "123");
        ReflectionTestUtils.setField(gpsConsumerService, "queryTimeWindow", 10);
    }

    @Test
    public void testConsume_NewDocument_HappyPath()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        KafkaMessageGPS kafkaMessageGPS = new KafkaMessageGPS();
        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";
        List<Document> metadataList = Arrays.asList(Document.parse("{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}"));

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);

        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);


            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt())).thenReturn(Collections.emptyList());

            gpsConsumerService.consume(record);

            verify(documentMetaDataService).insertMultiDocumentsWithSpaceId(anyList(), eq(123));
        }
    }


    @Test
    public void testConsume_ExistingDocument_TriggersUpdate()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        KafkaMessageGPS kafkaMessageGPS = new KafkaMessageGPS();
        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";
        List<Document> metadataList = Arrays.asList(Document.parse("{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}"));

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

                when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);


                DocumentMetaData existingDoc = new DocumentMetaData();
                existingDoc.setId("1");
                // Make the existing metadata different from the new one
                Document existingMetadata = Document.parse("{\"id\":\"1\",\"effectiveDate\":\"2024-01-01\"}");
                existingDoc.setMetadata(existingMetadata);

                when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                        .thenReturn(Collections.singletonList(existingDoc));

                // Act
                gpsConsumerService.consume(record);

                // Assert
                verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
                verify(documentMetaDataService, atLeastOnce()).saveDocumentMetaData(any(DocumentMetaData.class));
        }
    }

    @Test
    public void testConsume_InvalidMetadata_NotInserted()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        KafkaMessageGPS kafkaMessageGPS = new KafkaMessageGPS();
        String metadataListStr = "[{\"id\":\"1\"}]"; // missing required fields
        List<Document> metadataList = Arrays.asList(Document.parse("{\"id\":\"1\"}"));

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

                when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);


                when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt())).thenReturn(Collections.emptyList());

                // Act
                gpsConsumerService.consume(record);

                // Assert
                verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_ExceptionDuringProcessing()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);


        gpsConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsume_WhenJsonParsingThrowsException_LogsError()  {
        String key = "trxKey";
        String value = "{\"invalid\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // Mock ObjectMapper to throw exception
        GPSConsumerService spyService = spy(gpsConsumerService);
        doThrow(new RuntimeException("JSON parse error"))
                .when(spyService)
                .consume(any(ConsumerRecord.class));

        // Optionally, you can use a logger appender to verify logging if needed

        try {
            spyService.consume(record);
        } catch (Exception ignored) {
            // Exception is expected, but should be caught in the method
        }

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        // Optionally, verify logger.error was called (requires logger mocking or appender)
    }

    @Test
    public void testConsume_ExistingDocument_CallsUpdateGPSMetadataStatus()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // Prepare the metadata list string and Document
        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";
        Document metadataDoc = Document.parse("{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}");

        // Mock TemplateHandler and TemplateFactory
        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            // Mock existing document in DB
            DocumentMetaData existingDoc = new DocumentMetaData();
            existingDoc.setId("1");
            existingDoc.setMetadata(Document.parse("{\"id\":\"1\",\"effectiveDate\":\"2024-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"MANUAL_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}"));

            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.singletonList(existingDoc));

            // Act
            gpsConsumerService.consume(record);

            // Assert: updateGPSMetadataStatus should be called, so saveDocumentMetaData should be called
            verify(documentMetaDataService, atLeastOnce()).saveDocumentMetaData(any(DocumentMetaData.class));
            // insertMultiDocumentsWithSpaceId should NOT be called
            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_ExceptionInSaveDocumentMetaData_DoesNotPropagate()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            DocumentMetaData existingDoc = new DocumentMetaData();
            existingDoc.setId("1");
            existingDoc.setMetadata(Document.parse("{\"id\":\"1\",\"effectiveDate\":\"2024-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"MANUAL_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}"));

            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.singletonList(existingDoc));

            // Simulate exception during save
            doThrow(new RuntimeException("DB error")).when(documentMetaDataService).saveDocumentMetaData(any(DocumentMetaData.class));

            // Should not throw
            gpsConsumerService.consume(record);

            verify(documentMetaDataService, atLeastOnce()).saveDocumentMetaData(any(DocumentMetaData.class));
            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_ExceptionInExistingMetadata_DoesNotPropagate()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            // Mock DocumentMetaData to throw on getMetadata
            DocumentMetaData existingDoc = mock(DocumentMetaData.class);
            when(existingDoc.getId()).thenReturn("1");
            when(existingDoc.getMetadata()).thenThrow(new RuntimeException("Corrupt metadata"));

            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.singletonList(existingDoc));

            // Should not throw
            gpsConsumerService.consume(record);

            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_MetadataNullOrEmpty_NotInserted()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // Simulate both null and empty metadata in the list
        String metadataListStr = "[null, {}]";

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.emptyList());

            gpsConsumerService.consume(record);

            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_MetadataMissingRequiredField_NotInserted()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // Metadata missing "id" field
        String metadataListStr = "[{\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.emptyList());

            gpsConsumerService.consume(record);

            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_MetadataEmptyRequiredField_NotInserted()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // Metadata with empty "id" field
        String metadataListStr = "[{\"id\":\"\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.emptyList());

            gpsConsumerService.consume(record);

            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_MetadataMissingProviders_NotInserted()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // Metadata missing "providers" field
        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\",\"providers\":null}]";

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.emptyList());

            gpsConsumerService.consume(record);

            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_InvalidProvidersType_NotInserted()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // providers is a string instead of an object, will cause ClassCastException
        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":\"notAProviderObject\",\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.emptyList());

            gpsConsumerService.consume(record);

            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_MissingOrEmptyProviderField_NotInserted()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // providers missing "taxId"
        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.emptyList());

            gpsConsumerService.consume(record);

            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_EndDateInPast_NotInserted()  {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // endDate is today (should fail validation)
        String today = java.time.LocalDate.now().toString();
        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2020-01-01\",\"endDate\":\"" + today + "\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.emptyList());

            gpsConsumerService.consume(record);

            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_EndDateInvalidFormat_NotInserted() {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // endDate is invalid
        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2020-01-01\",\"endDate\":\"not-a-date\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.emptyList());

            gpsConsumerService.consume(record);

            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }
    
    @Test
    public void testConsume_MetadataWithNullProviders_NotInserted(){
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);
    
        // Metadata with "providers": null
        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":null,\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";
    
        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);
    
            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);
    
            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.emptyList());
    
            gpsConsumerService.consume(record);
    
            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_WhenExceptionThrown_LogsErrorAndDoesNotInsert() {
        String key = "trxKey";
        String value = "{\"invalid\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // Mock TemplateHandler to throw an exception
        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenThrow(new RuntimeException("Template error"));

            gpsConsumerService.consume(record);

            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_AddsAttestationCompleted_WhenMissingInExisting() {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        // New metadata includes ATTESTATION_COMPLETED
        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\",\"attestationCompleted\":true}]";

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            // Existing document does NOT have ATTESTATION_COMPLETED
            DocumentMetaData existingDoc = new DocumentMetaData();
            existingDoc.setId("1");
            existingDoc.setMetadata(Document.parse("{\"id\":\"1\",\"effectiveDate\":\"2024-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}"));

            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.singletonList(existingDoc));

            gpsConsumerService.consume(record);

            // Should update the document (add ATTESTATION_COMPLETED)
            verify(documentMetaDataService, atLeastOnce()).saveDocumentMetaData(argThat(doc ->
                doc.getMetadata().get("attestationCompleted") != null
            ));
            verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
        }
    }

    @Test
    public void testConsume_ExistingDocMetadataListNullOrEmptyOrNullMetadata_NoUpdate() {
        String key = "trxKey";
        String value = "{\"some\":\"json\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        String metadataListStr = "[{\"id\":\"1\",\"effectiveDate\":\"2025-01-01\",\"endDate\":\"2099-12-31\",\"mbi\":\"mbi\",\"firstName\":\"fn\",\"lastName\":\"ln\",\"dateOfBirth\":\"2000-01-01\",\"providers\":{\"taxId\":\"t\",\"providerId\":\"p\",\"pcpName\":\"n\"},\"status\":\"ELECTRONIC_OUTREACH\",\"eventType\":\"INITIATE_OUTREACH\"}]";

        com.optum.ppl.kafka.service.template.java.TemplateHandler templateHandler = mock(com.optum.ppl.kafka.service.template.java.TemplateHandler.class);
        try (MockedStatic<com.optum.ppl.kafka.service.template.java.TemplateFactory> mockedStatic = mockStatic(com.optum.ppl.kafka.service.template.java.TemplateFactory.class)) {
            mockedStatic.when(() -> com.optum.ppl.kafka.service.template.java.TemplateFactory.getInstance(anyString()))
                    .thenReturn(templateHandler);

            when(templateHandler.convertWithTemplate(anyMap())).thenReturn(metadataListStr);

            // Case 1: getGPSDocumentMetaData returns null
            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(null);

            gpsConsumerService.consume(record);
            verify(documentMetaDataService, never()).saveDocumentMetaData(any());

            // Case 2: getGPSDocumentMetaData returns empty list
            reset(documentMetaDataService);
            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.emptyList());

            gpsConsumerService.consume(record);
            verify(documentMetaDataService, never()).saveDocumentMetaData(any());

            // Case 3: metadata is null (simulate by making metadataListStr = "[null]")
            reset(documentMetaDataService);
            when(templateHandler.convertWithTemplate(anyMap())).thenReturn("[null]");
            when(documentMetaDataService.getGPSDocumentMetaData(anyString(), anyInt(), anyInt()))
                    .thenReturn(Collections.singletonList(new DocumentMetaData()));

            gpsConsumerService.consume(record);
            verify(documentMetaDataService, never()).saveDocumentMetaData(any());
        }
    }

}