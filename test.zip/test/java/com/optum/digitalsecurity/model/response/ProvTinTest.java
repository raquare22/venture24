package com.optum.digitalsecurity.model.response;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class ProvTinTest {

    @Test
    public void testParameterizedConstructor() {
        List<Provider> providers = new ArrayList<>();
        ProvTin provTin = new ProvTin("uuid-001", "corp-123", "tin-999", providers);

        assertEquals("uuid-001", provTin.getUuid());
        assertEquals("corp-123", provTin.getCorpMpin());
        assertEquals("tin-999", provTin.getTin());
        assertSame(providers, provTin.getProvider());
    }

    @Test
    public void testParameterizedConstructorWithNullValues() {
        ProvTin provTin = new ProvTin(null, null, null, null);

        assertNull(provTin.getUuid());
        assertNull(provTin.getCorpMpin());
        assertNull(provTin.getTin());
        assertNull(provTin.getProvider());
    }

    @Test
    public void testGettersAndSetters() {
        ProvTin provTin = new ProvTin("init-uuid", "init-corp", "init-tin", new ArrayList<Provider>());
        List<Provider> providers = new ArrayList<>();

        provTin.setUuid("uuid-002");
        provTin.setCorpMpin("corp-456");
        provTin.setTin("tin-888");
        provTin.setProvider(providers);

        assertEquals("uuid-002", provTin.getUuid());
        assertEquals("corp-456", provTin.getCorpMpin());
        assertEquals("tin-888", provTin.getTin());
        assertSame(providers, provTin.getProvider());
    }

    @Test
    public void testSetterOverwritesValue() {
        ProvTin provTin = new ProvTin("uuid-old", "corp-old", "tin-old", null);

        provTin.setTin("tin-new");

        assertEquals("tin-new", provTin.getTin());
    }
}

