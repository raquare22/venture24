package com.optum.digitalsecurity.model.response;

import org.junit.Test;
import static org.junit.Assert.*;

public class JobFunctionTest {

    @Test
    public void testNoArgConstructorDefaultsToNull() {
        JobFunction jobFunction = new JobFunction();

        assertNull(jobFunction.getCode());
        assertNull(jobFunction.getDesc());
        assertNull(jobFunction.getNpi());
    }

    @Test
    public void testParameterizedConstructor() {
        JobFunction jobFunction = new JobFunction("JF001", "Primary Care", "NPI123456");

        assertEquals("JF001", jobFunction.getCode());
        assertEquals("Primary Care", jobFunction.getDesc());
        assertEquals("NPI123456", jobFunction.getNpi());
    }

    @Test
    public void testParameterizedConstructorWithNullValues() {
        JobFunction jobFunction = new JobFunction(null, null, null);

        assertNull(jobFunction.getCode());
        assertNull(jobFunction.getDesc());
        assertNull(jobFunction.getNpi());
    }

    @Test
    public void testGettersAndSetters() {
        JobFunction jobFunction = new JobFunction();

        jobFunction.setCode("JF002");
        jobFunction.setDesc("Specialist");
        jobFunction.setNpi("NPI654321");

        assertEquals("JF002", jobFunction.getCode());
        assertEquals("Specialist", jobFunction.getDesc());
        assertEquals("NPI654321", jobFunction.getNpi());
    }

    @Test
    public void testSetterOverwritesValue() {
        JobFunction jobFunction = new JobFunction("JF001", "Primary Care", "NPI123456");

        jobFunction.setDesc("Surgeon");

        assertEquals("Surgeon", jobFunction.getDesc());
    }
}

