package com.optum.digitalsecurity.model.response;

import org.junit.Test;
import static org.junit.Assert.*;

public class NonProviderOrgTest {

    @Test
    public void testNoArgConstructorDefaultsToNull() {
        NonProviderOrg org = new NonProviderOrg();

        assertNull(org.getIrsOrgId());
        assertNull(org.getCorpName());
        assertFalse(org.isPaa());
    }

    @Test
    public void testParameterizedConstructor() {
        NonProviderOrg org = new NonProviderOrg("IRS001", "Optum Corp", true);

        assertEquals("IRS001", org.getIrsOrgId());
        assertEquals("Optum Corp", org.getCorpName());
        assertTrue(org.isPaa());
    }

    @Test
    public void testParameterizedConstructorWithNullStringsAndFalsePaa() {
        NonProviderOrg org = new NonProviderOrg(null, null, false);

        assertNull(org.getIrsOrgId());
        assertNull(org.getCorpName());
        assertFalse(org.isPaa());
    }

    @Test
    public void testGettersAndSetters() {
        NonProviderOrg org = new NonProviderOrg();

        org.setIrsOrgId("IRS002");
        org.setCorpName("United Health");
        org.setPaa(true);

        assertEquals("IRS002", org.getIrsOrgId());
        assertEquals("United Health", org.getCorpName());
        assertTrue(org.isPaa());
    }

    @Test
    public void testSetterOverwritesValue() {
        NonProviderOrg org = new NonProviderOrg("IRS001", "Optum Corp", true);

        org.setPaa(false);

        assertFalse(org.isPaa());
    }
}

