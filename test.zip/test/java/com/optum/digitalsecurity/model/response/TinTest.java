package com.optum.digitalsecurity.model.response;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class TinTest {

    @Test
    public void testNoArgConstructorDefaults() {
        Tin tin = new Tin();

        assertNull(tin.getTin());
        assertFalse(tin.isAllPermission());
        assertNull(tin.getPermission());
    }

    @Test
    public void testParameterizedConstructor() {
        List<Permission> permissions = new ArrayList<>();
        Tin tin = new Tin("123456789", true, permissions);

        assertEquals("123456789", tin.getTin());
        assertTrue(tin.isAllPermission());
        assertSame(permissions, tin.getPermission());
    }

    @Test
    public void testGettersAndSetters() {
        Tin tin = new Tin();
        List<Permission> permissions = new ArrayList<>();

        tin.setTin("987654321");
        tin.setAllPermission(true);
        tin.setPermission(permissions);

        assertEquals("987654321", tin.getTin());
        assertTrue(tin.isAllPermission());
        assertSame(permissions, tin.getPermission());
    }

    @Test
    public void testSetterOverwritesValue() {
        Tin tin = new Tin();

        tin.setTin("111111111");
        tin.setTin("222222222");
        tin.setAllPermission(true);
        tin.setAllPermission(false);

        assertEquals("222222222", tin.getTin());
        assertFalse(tin.isAllPermission());
    }
}

