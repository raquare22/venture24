package com.optum.digitalsecurity.model.response;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class PDOProvTinTest {

    @Test
    public void testDefaultValueIsNull() {
        PDOProvTin pdoProvTin = new PDOProvTin();

        assertNull(pdoProvTin.getTin());
    }

    @Test
    public void testGetterAndSetter() {
        PDOProvTin pdoProvTin = new PDOProvTin();

        pdoProvTin.setTin("123456789");

        assertEquals("123456789", pdoProvTin.getTin());
    }

    @Test
    public void testSetterOverwritesValue() {
        PDOProvTin pdoProvTin = new PDOProvTin();

        pdoProvTin.setTin("111111111");
        pdoProvTin.setTin("222222222");

        assertEquals("222222222", pdoProvTin.getTin());
    }
}

