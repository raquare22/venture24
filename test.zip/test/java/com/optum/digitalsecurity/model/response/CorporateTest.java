package com.optum.digitalsecurity.model.response;

import org.junit.Test;
import static org.junit.Assert.*;

public class CorporateTest {

    @Test
    public void testGettersAndSetters() {
        Corporate corporate = new Corporate();

        corporate.setUhcID("UHC123");
        corporate.setMpin("MPIN001");
        corporate.setCorporateName("Optum Health");
        corporate.setProvId("PROV456");

        assertEquals("UHC123", corporate.getUhcID());
        assertEquals("MPIN001", corporate.getMpin());
        assertEquals("Optum Health", corporate.getCorporateName());
        assertEquals("PROV456", corporate.getProvId());
    }

    @Test
    public void testDefaultValuesAreNull() {
        Corporate corporate = new Corporate();

        assertNull(corporate.getUhcID());
        assertNull(corporate.getMpin());
        assertNull(corporate.getCorporateName());
        assertNull(corporate.getProvId());
    }

    @Test
    public void testPublicFieldDirectAccess() {
        Corporate corporate = new Corporate();

        corporate.uhcID = "UHC789";
        corporate.mpin = "MPIN002";
        corporate.corporateName = "United Health";
        corporate.provId = "PROV999";

        assertEquals("UHC789", corporate.uhcID);
        assertEquals("MPIN002", corporate.mpin);
        assertEquals("United Health", corporate.corporateName);
        assertEquals("PROV999", corporate.provId);
    }

    @Test
    public void testSetterOverwritesValue() {
        Corporate corporate = new Corporate();

        corporate.setUhcID("UHC001");
        corporate.setUhcID("UHC002");

        assertEquals("UHC002", corporate.getUhcID());
    }
}

