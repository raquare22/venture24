package com.optum.digitalsecurity.model.response;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class OrgDataTest {

    @Test
    public void testNoArgConstructorDefaultsToNull() {
        OrgData orgData = new OrgData();

        assertNull(orgData.getId());
        assertNull(orgData.getCorpMpin());
        assertNull(orgData.getTins());
    }

    @Test
    public void testParameterizedConstructor() {
        List<Tin> tins = new ArrayList<>();
        OrgData orgData = new OrgData("ORG001", "MPIN001", tins);

        assertEquals("ORG001", orgData.getId());
        assertEquals("MPIN001", orgData.getCorpMpin());
        assertSame(tins, orgData.getTins());
    }

    @Test
    public void testGettersAndSetters() {
        OrgData orgData = new OrgData();
        List<Tin> tins = new ArrayList<>();

        orgData.setId("ORG002");
        orgData.setCorpMpin("MPIN002");
        orgData.setTins(tins);

        assertEquals("ORG002", orgData.getId());
        assertEquals("MPIN002", orgData.getCorpMpin());
        assertSame(tins, orgData.getTins());
    }

    @Test
    public void testSetterOverwritesValue() {
        OrgData orgData = new OrgData();
        List<Tin> first = new ArrayList<>();
        List<Tin> second = new ArrayList<>();

        orgData.setTins(first);
        orgData.setTins(second);

        assertSame(second, orgData.getTins());
    }
}

