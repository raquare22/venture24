package com.optum.digitalsecurity.model.response;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class PDOCorporatesTest {

    @Test
    public void testDefaultValuesAreNull() {
        PDOCorporates pdoCorporates = new PDOCorporates();

        assertNull(pdoCorporates.getOptumUUID());
        assertNull(pdoCorporates.getCorporates());
    }

    @Test
    public void testGettersAndSetters() {
        PDOCorporates pdoCorporates = new PDOCorporates();
        List<Corporate> corporates = new ArrayList<>();

        pdoCorporates.setOptumUUID("optum-uuid-001");
        pdoCorporates.setCorporates(corporates);

        assertEquals("optum-uuid-001", pdoCorporates.getOptumUUID());
        assertSame(corporates, pdoCorporates.getCorporates());
    }

    @Test
    public void testSetterOverwritesValue() {
        PDOCorporates pdoCorporates = new PDOCorporates();

        pdoCorporates.setOptumUUID("optum-uuid-old");
        pdoCorporates.setOptumUUID("optum-uuid-new");

        assertEquals("optum-uuid-new", pdoCorporates.getOptumUUID());
    }
}

