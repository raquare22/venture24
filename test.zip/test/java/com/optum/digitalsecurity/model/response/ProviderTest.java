package com.optum.digitalsecurity.model.response;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class ProviderTest {

    @Test
    public void testNoArgConstructorDefaultsToNull() {
        Provider provider = new Provider();

        assertNull(provider.getFirstName());
        assertNull(provider.getLastName());
        assertNull(provider.getProviderMpin());
    }

    @Test
    public void testParameterizedConstructor() {
        Provider provider = new Provider("John", "Doe", "MPIN123");

        assertEquals("John", provider.getFirstName());
        assertEquals("Doe", provider.getLastName());
        assertEquals("MPIN123", provider.getProviderMpin());
    }

    @Test
    public void testGettersAndSetters() {
        Provider provider = new Provider();

        provider.setFirstName("Jane");
        provider.setLastName("Smith");
        provider.setProviderMpin("MPIN456");

        assertEquals("Jane", provider.getFirstName());
        assertEquals("Smith", provider.getLastName());
        assertEquals("MPIN456", provider.getProviderMpin());
    }

    @Test
    public void testSetterOverwritesValue() {
        Provider provider = new Provider();

        provider.setProviderMpin("OLD-MPIN");
        provider.setProviderMpin("NEW-MPIN");

        assertEquals("NEW-MPIN", provider.getProviderMpin());
    }
}

