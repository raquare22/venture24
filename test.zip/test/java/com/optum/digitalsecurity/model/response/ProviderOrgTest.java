package com.optum.digitalsecurity.model.response;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ProviderOrgTest {

    @Test
    public void testNoArgConstructorDefaults() {
        ProviderOrg providerOrg = new ProviderOrg();

        assertEquals(null, providerOrg.getId());
        assertEquals(null, providerOrg.getCorpMpin());
        assertEquals(null, providerOrg.getUhcProviderId());
        assertEquals(null, providerOrg.getFirstName());
        assertEquals(null, providerOrg.getLastName());
        assertFalse(providerOrg.isPaa());
        assertFalse(providerOrg.isIa());
    }

    @Test
    public void testParameterizedConstructor() {
        ProviderOrg providerOrg = new ProviderOrg(
                "PROV001",
                "CORP123",
                "UHC987",
                "Jane",
                "Doe",
                true,
                false
        );

        assertEquals("PROV001", providerOrg.getId());
        assertEquals("CORP123", providerOrg.getCorpMpin());
        assertEquals("UHC987", providerOrg.getUhcProviderId());
        assertEquals("Jane", providerOrg.getFirstName());
        assertEquals("Doe", providerOrg.getLastName());
        assertTrue(providerOrg.isPaa());
        assertFalse(providerOrg.isIa());
    }

    @Test
    public void testGettersAndSetters() {
        ProviderOrg providerOrg = new ProviderOrg();

        providerOrg.setId("PROV002");
        providerOrg.setCorpMpin("CORP456");
        providerOrg.setUhcProviderId("UHC654");
        providerOrg.setFirstName("John");
        providerOrg.setLastName("Smith");
        providerOrg.setPaa(false);
        providerOrg.setIa(true);

        assertEquals("PROV002", providerOrg.getId());
        assertEquals("CORP456", providerOrg.getCorpMpin());
        assertEquals("UHC654", providerOrg.getUhcProviderId());
        assertEquals("John", providerOrg.getFirstName());
        assertEquals("Smith", providerOrg.getLastName());
        assertFalse(providerOrg.isPaa());
        assertTrue(providerOrg.isIa());
    }

    @Test
    public void testSetterOverwritesValues() {
        ProviderOrg providerOrg = new ProviderOrg();

        providerOrg.setFirstName("Initial");
        providerOrg.setFirstName("Updated");
        providerOrg.setPaa(true);
        providerOrg.setPaa(false);

        assertEquals("Updated", providerOrg.getFirstName());
        assertFalse(providerOrg.isPaa());
    }
}

