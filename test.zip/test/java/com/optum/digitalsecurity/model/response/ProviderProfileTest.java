package com.optum.digitalsecurity.model.response;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class ProviderProfileTest {

    @Test
    public void testNoArgConstructorDefaultsToNull() {
        ProviderProfile profile = new ProviderProfile();

        assertNull(profile.getUuid());
        assertNull(profile.getDemographics());
        assertNull(profile.getJobFunction());
        assertNull(profile.getProviderOrg());
        assertNull(profile.getNonProviderOrg());
    }

    @Test
    public void testParameterizedConstructor() {
        Demographics demographics = new Demographics("John", "Doe", "john.doe@example.com", "5551234567", "101");
        List<JobFunction> jobFunctions = new ArrayList<>();
        List<ProviderOrg> providerOrgs = new ArrayList<>();
        List<NonProviderOrg> nonProviderOrgs = new ArrayList<>();

        ProviderProfile profile = new ProviderProfile("uuid-001", demographics, jobFunctions, providerOrgs, nonProviderOrgs);

        assertEquals("uuid-001", profile.getUuid());
        assertSame(demographics, profile.getDemographics());
        assertSame(jobFunctions, profile.getJobFunction());
        assertSame(providerOrgs, profile.getProviderOrg());
        assertSame(nonProviderOrgs, profile.getNonProviderOrg());
    }

    @Test
    public void testGettersAndSetters() {
        ProviderProfile profile = new ProviderProfile();
        Demographics demographics = new Demographics();
        List<JobFunction> jobFunctions = new ArrayList<>();
        List<ProviderOrg> providerOrgs = new ArrayList<>();
        List<NonProviderOrg> nonProviderOrgs = new ArrayList<>();

        profile.setUuid("uuid-002");
        profile.setDemographics(demographics);
        profile.setJobFunction(jobFunctions);
        profile.setProviderOrg(providerOrgs);
        profile.setNonProviderOrg(nonProviderOrgs);

        assertEquals("uuid-002", profile.getUuid());
        assertSame(demographics, profile.getDemographics());
        assertSame(jobFunctions, profile.getJobFunction());
        assertSame(providerOrgs, profile.getProviderOrg());
        assertSame(nonProviderOrgs, profile.getNonProviderOrg());
    }

    @Test
    public void testSetterOverwritesValue() {
        ProviderProfile profile = new ProviderProfile();

        profile.setUuid("uuid-old");
        profile.setUuid("uuid-new");

        assertEquals("uuid-new", profile.getUuid());
    }
}

