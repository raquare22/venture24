package com.optum.digitalsecurity.model.response;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class PDOTinsTest {

    @Test
    public void testDefaultValuesAreNull() {
        PDOTins pdoTins = new PDOTins();

        assertNull(pdoTins.getOptumUUID());
        assertNull(pdoTins.getUhcID());
        assertNull(pdoTins.getMpin());
        assertNull(pdoTins.getProviders());
    }

    @Test
    public void testGettersAndSetters() {
        PDOTins pdoTins = new PDOTins();
        List<PDOProvTin> providers = new ArrayList<>();

        pdoTins.setOptumUUID("optum-uuid-001");
        pdoTins.setUhcID("uhc-123");
        pdoTins.setMpin("mpin-456");
        pdoTins.setProviders(providers);

        assertEquals("optum-uuid-001", pdoTins.getOptumUUID());
        assertEquals("uhc-123", pdoTins.getUhcID());
        assertEquals("mpin-456", pdoTins.getMpin());
        assertSame(providers, pdoTins.getProviders());
    }

    @Test
    public void testSetterOverwritesValue() {
        PDOTins pdoTins = new PDOTins();

        pdoTins.setMpin("mpin-old");
        pdoTins.setMpin("mpin-new");

        assertEquals("mpin-new", pdoTins.getMpin());
    }
}

