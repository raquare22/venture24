package com.optum.digitalsecurity.model.response;

import org.junit.Test;
import static org.junit.Assert.*;

public class DemographicsTest {

    @Test
    public void testNoArgConstructorDefaultsToNull() {
        Demographics demographics = new Demographics();

        assertNull(demographics.getFirstName());
        assertNull(demographics.getLastName());
        assertNull(demographics.getEmail());
        assertNull(demographics.getPhone());
        assertNull(demographics.getPhoneExt());
    }

    @Test
    public void testParameterizedConstructor() {
        Demographics demographics = new Demographics("John", "Doe", "john.doe@example.com", "5551234567", "101");

        assertEquals("John", demographics.getFirstName());
        assertEquals("Doe", demographics.getLastName());
        assertEquals("john.doe@example.com", demographics.getEmail());
        assertEquals("5551234567", demographics.getPhone());
        assertEquals("101", demographics.getPhoneExt());
    }

    @Test
    public void testParameterizedConstructorWithNullValues() {
        Demographics demographics = new Demographics(null, null, null, null, null);

        assertNull(demographics.getFirstName());
        assertNull(demographics.getLastName());
        assertNull(demographics.getEmail());
        assertNull(demographics.getPhone());
        assertNull(demographics.getPhoneExt());
    }

    @Test
    public void testGettersAndSetters() {
        Demographics demographics = new Demographics();

        demographics.setFirstName("Jane");
        demographics.setLastName("Smith");
        demographics.setEmail("jane.smith@example.com");
        demographics.setPhone("5559876543");
        demographics.setPhoneExt("202");

        assertEquals("Jane", demographics.getFirstName());
        assertEquals("Smith", demographics.getLastName());
        assertEquals("jane.smith@example.com", demographics.getEmail());
        assertEquals("5559876543", demographics.getPhone());
        assertEquals("202", demographics.getPhoneExt());
    }

    @Test
    public void testSetterOverwritesValue() {
        Demographics demographics = new Demographics("John", "Doe", "old@example.com", "5551234567", "101");

        demographics.setEmail("new@example.com");

        assertEquals("new@example.com", demographics.getEmail());
    }
}

