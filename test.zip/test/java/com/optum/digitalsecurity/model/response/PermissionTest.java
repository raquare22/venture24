package com.optum.digitalsecurity.model.response;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class PermissionTest {

    @Test
    public void testNoArgConstructorDefaultsToNull() {
        Permission permission = new Permission();

        assertNull(permission.getCode());
        assertNull(permission.getSubCode());
        assertNull(permission.getCodeDesc());
        assertNull(permission.getSubCodeDesc());
    }

    @Test
    public void testParameterizedConstructor() {
        Permission permission = new Permission("CODE1", "SUB1", "Code Desc", "Subcode Desc");

        assertEquals("CODE1", permission.getCode());
        assertEquals("SUB1", permission.getSubCode());
        assertEquals("Code Desc", permission.getCodeDesc());
        assertEquals("Subcode Desc", permission.getSubCodeDesc());
    }

    @Test
    public void testGettersAndSetters() {
        Permission permission = new Permission();

        permission.setCode("CODE2");
        permission.setSubCode("SUB2");
        permission.setCodeDesc("Updated Code Desc");
        permission.setSubCodeDesc("Updated Subcode Desc");

        assertEquals("CODE2", permission.getCode());
        assertEquals("SUB2", permission.getSubCode());
        assertEquals("Updated Code Desc", permission.getCodeDesc());
        assertEquals("Updated Subcode Desc", permission.getSubCodeDesc());
    }

    @Test
    public void testSetterOverwritesValue() {
        Permission permission = new Permission();

        permission.setCode("OLD");
        permission.setCode("NEW");

        assertEquals("NEW", permission.getCode());
    }
}

