package com.optum.digitalsecurity.model.request;

import org.junit.Test;
import static org.junit.Assert.*;

public class UserTest {

    @Test
    public void testGettersAndSetters() {
        User user = new User();

        user.setUuid("uuid-001");
        user.setOneHealthId("OHI123");
        user.setFirstName("John");
        user.setLastName("Doe");
        user.setEmail("john.doe@example.com");

        assertEquals("uuid-001", user.getUuid());
        assertEquals("OHI123", user.getOneHealthId());
        assertEquals("John", user.getFirstName());
        assertEquals("Doe", user.getLastName());
        assertEquals("john.doe@example.com", user.getEmail());
    }

    @Test
    public void testDefaultValuesAreNull() {
        User user = new User();

        assertNull(user.getUuid());
        assertNull(user.getOneHealthId());
        assertNull(user.getFirstName());
        assertNull(user.getLastName());
        assertNull(user.getEmail());
    }

    @Test
    public void testToString() {
        User user = new User();
        user.setUuid("uuid-001");
        user.setOneHealthId("OHI123");
        user.setFirstName("John");
        user.setLastName("Doe");
        user.setEmail("john.doe@example.com");

        String expected = "User [uuid=uuid-001, oneHealthId=OHI123, firstName=John, lastName=Doe, email=john.doe@example.com]";
        assertEquals(expected, user.toString());
    }

    @Test
    public void testToStringWithNullValues() {
        User user = new User();

        String expected = "User [uuid=null, oneHealthId=null, firstName=null, lastName=null, email=null]";
        assertEquals(expected, user.toString());
    }

    @Test
    public void testSetterOverwritesValue() {
        User user = new User();

        user.setEmail("old@example.com");
        user.setEmail("new@example.com");

        assertEquals("new@example.com", user.getEmail());
    }
}

