package com.optum.digitalsecurity.model.request;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TinTest {

    @Test
    public void shouldCreateTinInstance() {
        Tin tin = new Tin();

        assertNotNull(tin);
        assertEquals(Tin.class, tin.getClass());
    }
}

