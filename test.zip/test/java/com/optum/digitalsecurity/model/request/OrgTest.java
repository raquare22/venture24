package com.optum.digitalsecurity.model.request;

import org.junit.Test;
import static org.junit.Assert.*;

public class OrgTest {

    @Test
    public void testGettersAndSetters() {
        Org org = new Org();

        org.setId("123");
        org.setCorpMpin("MPIN001");
        org.setUhcProviderId("UHC999");

        assertEquals("123", org.getId());
        assertEquals("MPIN001", org.getCorpMpin());
        assertEquals("UHC999", org.getUhcProviderId());
    }

    @Test
    public void testDefaultValuesAreNull() {
        Org org = new Org();

        assertNull(org.getId());
        assertNull(org.getCorpMpin());
        assertNull(org.getUhcProviderId());
    }

    @Test
    public void testToString() {
        Org org = new Org();
        org.setId("123");
        org.setCorpMpin("MPIN001");
        org.setUhcProviderId("UHC999");

        String expected = "Org [id=123, corpMpin=MPIN001, uhcProviderId=UHC999]";
        assertEquals(expected, org.toString());
    }

    @Test
    public void testToStringWithNullValues() {
        Org org = new Org();

        String expected = "Org [id=null, corpMpin=null, uhcProviderId=null]";
        assertEquals(expected, org.toString());
    }

    @Test
    public void testPublicFieldDirectAccess() {
        Org org = new Org();
        org.id = "456";
        org.corpMpin = "MPIN002";
        org.uhcProviderId = "UHC888";

        assertEquals("456", org.id);
        assertEquals("MPIN002", org.corpMpin);
        assertEquals("UHC888", org.uhcProviderId);
    }
}

