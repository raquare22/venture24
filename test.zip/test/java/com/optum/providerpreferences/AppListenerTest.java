package com.optum.providerpreferences;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.event.ContextClosedEvent;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

public class AppListenerTest {

    private AppListener listener;

    @Before
    public void setUp() {
        listener = new AppListener();
        AppListener.shutdown = false;
    }

    @After
    public void tearDown() {
        AppListener.shutdown = false;
    }

    @Test
    public void shutdownShouldBeFalseByDefault() {
        assertFalse(AppListener.shutdown);
    }

    @Test
    public void onApplicationEventShouldSetShutdownToTrue() {
        ContextClosedEvent event = mock(ContextClosedEvent.class);

        listener.onApplicationEvent(event);

        assertTrue(AppListener.shutdown);
    }

    @Test
    public void onApplicationEventShouldBeIdempotentWhenCalledMultipleTimes() {
        ContextClosedEvent event = mock(ContextClosedEvent.class);

        listener.onApplicationEvent(event);
        listener.onApplicationEvent(event);

        assertTrue(AppListener.shutdown);
    }

    @Test
    public void onApplicationEventShouldNotResetShutdownWhenAlreadyTrue() {
        AppListener.shutdown = true;
        ContextClosedEvent event = mock(ContextClosedEvent.class);

        listener.onApplicationEvent(event);

        assertTrue(AppListener.shutdown);
    }
}

