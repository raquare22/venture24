package com.optum.providerpreferences.autoenrollment.config;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class SchedulerConfigTest {

    @Before
    public void resetStaticFields() {
        SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE = null;
        SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN = null;
        SchedulerConfig.prunHost = null;
        SchedulerConfig.prunUserName = null;
        SchedulerConfig.prunKey = null;
        SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY = null;
        SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY = null;
        SchedulerConfig.PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY = null;
        SchedulerConfig.PRUN_ONESHOT_NDB_WORKING_DIRECTORY = null;
        SchedulerConfig.PRUN_ONESHOT_NDB_DESTINATION_DIRECTORY = null;
        SchedulerConfig.PRUN_ONESHOT_NDB_ARCHIVE_DIRECTORY = null;
        SchedulerConfig.retryWorkingDirec = null;
        SchedulerConfig.retryProcessedDirec = null;
        SchedulerConfig.PRUN_DESTINATION_PROCESSED_DIRECTORY = null;
        SchedulerConfig.PRUN_EMAIL_HOST = null;
        SchedulerConfig.prunEmailFrom = null;
        SchedulerConfig.prunEmailMessage = null;
        SchedulerConfig.prunEmailTo = null;
        SchedulerConfig.prunEmailSubject = null;
        SchedulerConfig.prunEmailToPODM = null;
        SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_WORKING_DIRECTORY = null;
        SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_DESTINATION_DIRECTORY = null;
        SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_ARCHIVE_DIRECTORY = null;
        SchedulerConfig.PRUN_WORKINGDIR_LOADTEST = null;
        SchedulerConfig.prunPort = null;
        SchedulerConfig.THREADS_DIGISEC_GET = null;
        SchedulerConfig.THREADS_FDSCLOUD_GET = null;
        SchedulerConfig.THREADS_PES_GET = null;
        SchedulerConfig.THREAD_COUNT_HEALTHCHECK = null;
        SchedulerConfig.PRUN_EMAIL_CHECK_WORKING_DIRECTORY = null;
        SchedulerConfig.PRUN_EMAIL_CHECK_DESTINATION_DIRECTORY = null;
        SchedulerConfig.PRUN_EMAIL_CHECK_ARCHIVE_DIRECTORY = null;
    }

    @Test
    public void testFieldsStartAsNullAfterReset() {
        assertNull(SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE);
        assertNull(SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN);
        assertNull(SchedulerConfig.prunHost);
        assertNull(SchedulerConfig.prunUserName);
        assertNull(SchedulerConfig.prunKey);
        assertNull(SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY);
        assertNull(SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY);
        assertNull(SchedulerConfig.PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY);
        assertNull(SchedulerConfig.PRUN_ONESHOT_NDB_WORKING_DIRECTORY);
        assertNull(SchedulerConfig.PRUN_ONESHOT_NDB_DESTINATION_DIRECTORY);
        assertNull(SchedulerConfig.PRUN_ONESHOT_NDB_ARCHIVE_DIRECTORY);
        assertNull(SchedulerConfig.retryWorkingDirec);
        assertNull(SchedulerConfig.retryProcessedDirec);
        assertNull(SchedulerConfig.PRUN_DESTINATION_PROCESSED_DIRECTORY);
        assertNull(SchedulerConfig.PRUN_EMAIL_HOST);
        assertNull(SchedulerConfig.prunEmailFrom);
        assertNull(SchedulerConfig.prunEmailMessage);
        assertNull(SchedulerConfig.prunEmailTo);
        assertNull(SchedulerConfig.prunEmailSubject);
        assertNull(SchedulerConfig.prunEmailToPODM);
        assertNull(SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_WORKING_DIRECTORY);
        assertNull(SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_DESTINATION_DIRECTORY);
        assertNull(SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_ARCHIVE_DIRECTORY);
        assertNull(SchedulerConfig.PRUN_WORKINGDIR_LOADTEST);
        assertNull(SchedulerConfig.prunPort);
        assertNull(SchedulerConfig.THREADS_DIGISEC_GET);
        assertNull(SchedulerConfig.THREADS_FDSCLOUD_GET);
        assertNull(SchedulerConfig.THREADS_PES_GET);
        assertNull(SchedulerConfig.THREAD_COUNT_HEALTHCHECK);
        assertNull(SchedulerConfig.PRUN_EMAIL_CHECK_WORKING_DIRECTORY);
        assertNull(SchedulerConfig.PRUN_EMAIL_CHECK_DESTINATION_DIRECTORY);
        assertNull(SchedulerConfig.PRUN_EMAIL_CHECK_ARCHIVE_DIRECTORY);
    }

    @Test
    public void testAllSettersPopulateMappedStaticFields() {
        SchedulerConfig config = new SchedulerConfig();

        config.setSplitCsvPerMaxMbSize("10");
        config.setSplitMaxBytesNewLineWithin("1024");
        config.setPrunHost("host");
        config.setPrunUserName("user");
        config.setPrunKey("key");
        config.setPrunAutoEnrollmentWorkingDirectory("/auto/work");
        config.setPrunAutoEnrollmentDestinationDirectory("/auto/dest");
        config.setPrunAutoEnrollmentArchiveDirectory("/auto/archive");
        config.setPrunOneshotNdbWorkingDirectory("/ndb/work");
        config.setPrunOneshotNdbDestinationDirectory("/ndb/dest");
        config.setPrunOneshotNdbArchiveDirectory("/ndb/archive");
        config.setRetryWorkingDirec("/retry/work");
        config.setRetryProcessedDirec("/retry/processed");
        config.setPrunDestinationProcessedDirectory("/prun/processed");
        config.setPrunEmailHost("smtp.example.com");
        config.setPrunEmailFrom("from@example.com");
        config.setPrunEmailMessage("message");
        config.setPrunEmailTo("to@example.com");
        config.setPrunEmailSubject("subject");
        config.setPrunEmailToPODM("podm@example.com");
        config.setMemberPaymentPreferenceWorkingDirectory("/mpp/work");
        config.setMemberPaymentPreferenceDestinationDirectory("/mpp/dest");
        config.setMemberPaymentPreferenceArchiveDirectory("/mpp/archive");
        config.setWorkingDirecLoadTest("/loadtest/work");
        config.setPrunPort("22");
        config.setThreadsDigiSecGet("5");
        config.setThreadsFdsCloudGet("6");
        config.setThreadsPesGet("7");
        config.setThreadCountHealthCheck("3");
        config.setPrunEmailCheckWorkingDirectory("/emailcheck/work");
        config.setPrunEmailCheckDestinationDirectory("/emailcheck/dest");
        config.setPrunEmailCheckArchiveDirectory("/emailcheck/archive");

        assertEquals("10", SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE);
        assertEquals("1024", SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN);
        assertEquals("host", SchedulerConfig.prunHost);
        assertEquals("user", SchedulerConfig.prunUserName);
        assertEquals("key", SchedulerConfig.prunKey);
        assertEquals("/auto/work", SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY);
        assertEquals("/auto/dest", SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY);
        assertEquals("/auto/archive", SchedulerConfig.PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY);
        assertEquals("/ndb/work", SchedulerConfig.PRUN_ONESHOT_NDB_WORKING_DIRECTORY);
        assertEquals("/ndb/dest", SchedulerConfig.PRUN_ONESHOT_NDB_DESTINATION_DIRECTORY);
        assertEquals("/ndb/archive", SchedulerConfig.PRUN_ONESHOT_NDB_ARCHIVE_DIRECTORY);
        assertEquals("/retry/work", SchedulerConfig.retryWorkingDirec);
        assertEquals("/retry/processed", SchedulerConfig.retryProcessedDirec);
        assertEquals("/prun/processed", SchedulerConfig.PRUN_DESTINATION_PROCESSED_DIRECTORY);
        assertEquals("smtp.example.com", SchedulerConfig.PRUN_EMAIL_HOST);
        assertEquals("from@example.com", SchedulerConfig.prunEmailFrom);
        assertEquals("message", SchedulerConfig.prunEmailMessage);
        assertEquals("to@example.com", SchedulerConfig.prunEmailTo);
        assertEquals("subject", SchedulerConfig.prunEmailSubject);
        assertEquals("podm@example.com", SchedulerConfig.prunEmailToPODM);
        assertEquals("/mpp/work", SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_WORKING_DIRECTORY);
        assertEquals("/mpp/dest", SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_DESTINATION_DIRECTORY);
        assertEquals("/mpp/archive", SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_ARCHIVE_DIRECTORY);
        assertEquals("/loadtest/work", SchedulerConfig.PRUN_WORKINGDIR_LOADTEST);
        assertEquals("22", SchedulerConfig.prunPort);
        assertEquals("5", SchedulerConfig.THREADS_DIGISEC_GET);
        assertEquals("6", SchedulerConfig.THREADS_FDSCLOUD_GET);
        assertEquals("7", SchedulerConfig.THREADS_PES_GET);
        assertEquals("3", SchedulerConfig.THREAD_COUNT_HEALTHCHECK);
        assertEquals("/emailcheck/work", SchedulerConfig.PRUN_EMAIL_CHECK_WORKING_DIRECTORY);
        assertEquals("/emailcheck/dest", SchedulerConfig.PRUN_EMAIL_CHECK_DESTINATION_DIRECTORY);
        assertEquals("/emailcheck/archive", SchedulerConfig.PRUN_EMAIL_CHECK_ARCHIVE_DIRECTORY);
    }

    @Test
    public void testSetterOverwritesPreviousValue() {
        SchedulerConfig config = new SchedulerConfig();

        config.setPrunHost("old-host");
        config.setPrunHost("new-host");

        assertEquals("new-host", SchedulerConfig.prunHost);
    }
}

