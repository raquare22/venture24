package com.optum.providerpreferences.autoenrollment;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.Session;
import com.optum.providerpreferences.autoenrollment.config.SchedulerConfig;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.mockStatic;

@RunWith(MockitoJUnitRunner.class)
public class SchedulerAutoEnrollmentTest {

    @Before
    public void setUp() throws Exception {
        setStaticField("getCount", new AtomicInteger(0));
        setStaticField("postCount", new AtomicInteger(0));
        setStaticField("emailCount", new AtomicInteger(0));
        setStaticField("emailNotFound", new AtomicInteger(0));
        setStaticField("lastSchedulerCount", new AtomicInteger(0));
        setStaticField("lock", new AtomicBoolean(false));

        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";
        SchedulerConfig.prunPort = "22";
        SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY = "/working";
        SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY = "/dest";
        SchedulerConfig.PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY = "/archive";
        SchedulerConfig.PRUN_ONESHOT_NDB_WORKING_DIRECTORY = "/oneshot/working";
        SchedulerConfig.PRUN_ONESHOT_NDB_DESTINATION_DIRECTORY = "/oneshot/dest";
        SchedulerConfig.PRUN_ONESHOT_NDB_ARCHIVE_DIRECTORY = "/oneshot/archive";
        SchedulerConfig.retryWorkingDirec = "/retry/work";
        SchedulerConfig.retryProcessedDirec = "/retry/processed";
        SchedulerConfig.PRUN_DESTINATION_PROCESSED_DIRECTORY = "/processed";
        SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE = "20";
        SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN = "256";
    }

    @Test
    public void testPollCSVFilesWeekdaysSkipsDuringBusinessHours() {
        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            SchedulerAutoEnrollment.pollCSVFilesWeekdays();

            timeUtils.verify(TimeUtils::isWithinBusinessHours, times(1));
        }
    }

    @Test
    public void testPollCSVFilesOneshotNDBSkipsDuringBusinessHours() {
        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            SchedulerAutoEnrollment.pollCSVFilesOneshotNDB();

            timeUtils.verify(TimeUtils::isWithinBusinessHours, times(1));
        }
    }

    @Test
    public void testPollCSVFilesManualSkipsDuringBusinessHours() {
        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            SchedulerAutoEnrollment.pollCSVFilesManual();

            timeUtils.verify(TimeUtils::isWithinBusinessHours, times(1));
        }
    }

    @Test
    public void testPollCSVFilesWeekendsReturnsWhenLocked() throws Exception {
        AtomicBoolean lock = (AtomicBoolean) getStaticField("lock");
        lock.set(true);

        SchedulerAutoEnrollment.pollCSVFilesWeekends();

        assertTrue(lock.get());
    }

    @Test
    public void testPollCSVFilesWeekdaysReturnsWhenLocked() throws Exception {
        AtomicBoolean lock = (AtomicBoolean) getStaticField("lock");
        AtomicInteger getCount = (AtomicInteger) getStaticField("getCount");
        AtomicInteger postCount = (AtomicInteger) getStaticField("postCount");
        AtomicInteger lastSchedulerCount = (AtomicInteger) getStaticField("lastSchedulerCount");

        lock.set(true);
        getCount.set(0);
        postCount.set(5);
        lastSchedulerCount.set(0);

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);

            SchedulerAutoEnrollment.pollCSVFilesWeekdays();

            sftp.verifyNoInteractions();
        }

        assertTrue(lock.get());
    }

    @Test
    public void testPollDailyProcessDoesNotThrow() {
        try (MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential(
                    SchedulerConfig.prunHost,
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY)).thenReturn(true);

            SchedulerAutoEnrollment.pollDailyProcess();
        }
    }

    @Test
    public void testSplitFilesReturnsDuringBusinessHours() {
        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            SchedulerAutoEnrollment.splitFiles("/tmp", 20, 256, new HashMap<>());

            timeUtils.verify(TimeUtils::isWithinBusinessHours, times(1));
        }
    }

    @Test
    public void testExtractCSVReturnsNullDuringBusinessHours() throws Exception {
        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            Method extractCSV = SchedulerAutoEnrollment.class.getDeclaredMethod("extractCSV", String.class, String.class);
            extractCSV.setAccessible(true);
            Object result = extractCSV.invoke(null, "file.csv", "/tmp");

            assertNull(result);
        }
    }

    @Test
    public void testPollRetrySkipsDuringBusinessHours() {
        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            SchedulerAutoEnrollment.pollRetry();

            timeUtils.verify(TimeUtils::isWithinBusinessHours, times(1));
        }
    }

    @Test
    public void testPollRetryReturnsImmediatelyWhenLocked() throws Exception {
        AtomicBoolean lock = (AtomicBoolean) getStaticField("lock");
        lock.set(true);

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);

            SchedulerAutoEnrollment.pollRetry();

            sftp.verifyNoInteractions();
            assertTrue(lock.get());
        }
    }

    @Test
    public void testPollRetryProcessesWhenCredentialsPresent() throws Exception {
        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        Mockito.when(entry.getFilename()).thenReturn("retry.csv");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<>(List.of(entry)));
        sftpMap.put("channelSftp", Mockito.mock(ChannelSftp.class));
        sftpMap.put("sftpSession", Mockito.mock(Session.class));
        sftpMap.put("channel", Mockito.mock(Channel.class));

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/retry/work"))
                    .thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/retry/work")).thenReturn(sftpMap);
            sftp.when(() -> SftpUtil.readRetryData("/retry/work", getLocalDirectory(), "retry.csv", sftpMap, true))
                    .thenReturn(List.of("retry-row"));

            SchedulerAutoEnrollment.pollRetry();

            sftp.verify(() -> SftpUtil.readRetryData("/retry/work", getLocalDirectory(), "retry.csv", sftpMap, true), times(1));
        }

        AtomicBoolean lock = (AtomicBoolean) getStaticField("lock");
        assertFalse(lock.get());
    }

    @Test
    public void testPollRetryHandlesReadRetryDataException() throws Exception {
        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        Mockito.when(entry.getFilename()).thenReturn("retry.csv");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<>(List.of(entry)));
        sftpMap.put("channelSftp", Mockito.mock(ChannelSftp.class));
        sftpMap.put("sftpSession", Mockito.mock(Session.class));
        sftpMap.put("channel", Mockito.mock(Channel.class));

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/retry/work"))
                    .thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/retry/work")).thenReturn(sftpMap);
            sftp.when(() -> SftpUtil.readRetryData("/retry/work", getLocalDirectory(), "retry.csv", sftpMap, true))
                    .thenThrow(new ApplicationException("a"));

            SchedulerAutoEnrollment.pollRetry();
        }

        AtomicBoolean lock = (AtomicBoolean) getStaticField("lock");
        assertFalse(lock.get());
    }

    @Test
    public void testExecuteScheduledJobUnlocksWhenMissingCredentials() throws Exception {
        Method method = SchedulerAutoEnrollment.class.getDeclaredMethod(
                "executeScheduledJob", String.class, String.class, String.class, String.class);
        method.setAccessible(true);

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/working")).thenReturn(true);

            method.invoke(null, "Manual", "/working", "/dest", "/archive");
        }

        AtomicBoolean lock = (AtomicBoolean) getStaticField("lock");
        assertFalse(lock.get());
    }

    @Test
    public void testExecuteScheduledJobUnlocksWhenNoWork() throws Exception {
        Method method = SchedulerAutoEnrollment.class.getDeclaredMethod(
                "executeScheduledJob", String.class, String.class, String.class, String.class);
        method.setAccessible(true);

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/working")).thenReturn(false);
            sftp.when(() -> SftpUtil.createNewDirectoryAndMoveFiles(
                    Mockito.any(), Mockito.eq("/working"), Mockito.eq("/dest"), Mockito.eq("/working"), Mockito.eq("/dest"),
                    Mockito.eq("user"), Mockito.eq("pass"), Mockito.eq("host"), Mockito.eq(".csv"), Mockito.eq("20"), Mockito.eq("256"),
                    Mockito.eq(20), Mockito.eq(256), Mockito.eq(""), Mockito.any()))
                    .thenReturn(false);

            method.invoke(null, "Manual", "/working", "/dest", "/archive");
        }

        AtomicBoolean lock = (AtomicBoolean) getStaticField("lock");
        assertFalse(lock.get());
    }

    @Test
    public void testExecuteScheduledJobReturnsWhenBusinessHoursAfterLockSet() throws Exception {
        Method method = SchedulerAutoEnrollment.class.getDeclaredMethod(
                "executeScheduledJob", String.class, String.class, String.class, String.class);
        method.setAccessible(true);

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            method.invoke(null, "Manual", "/working", "/dest", "/archive");

            sftp.verifyNoInteractions();
        }

        AtomicBoolean lock = (AtomicBoolean) getStaticField("lock");
        assertTrue(lock.get());
    }

    @Test
    public void testExecuteScheduledJobResetsCountsThenContinues() throws Exception {
        Method method = SchedulerAutoEnrollment.class.getDeclaredMethod(
                "executeScheduledJob", String.class, String.class, String.class, String.class);
        method.setAccessible(true);

        AtomicBoolean lock = (AtomicBoolean) getStaticField("lock");
        AtomicInteger getCount = (AtomicInteger) getStaticField("getCount");
        AtomicInteger postCount = (AtomicInteger) getStaticField("postCount");
        AtomicInteger lastSchedulerCount = (AtomicInteger) getStaticField("lastSchedulerCount");

        lock.set(true);
        getCount.set(4);
        postCount.set(4);
        lastSchedulerCount.set(4);

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/working"))
                    .thenReturn(true);

            method.invoke(null, "Manual", "/working", "/dest", "/archive");
        }

        assertFalse(lock.get());
        assertEquals(0, getCount.get());
        assertEquals(0, postCount.get());
    }

    @Test
    public void testCheckAndSplitProcessesSplitFiles() {
        ChannelSftp channelSftp = Mockito.mock(ChannelSftp.class);
        Session session = Mockito.mock(Session.class);
        Channel channel = Mockito.mock(Channel.class);
        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        Mockito.when(entry.getFilename()).thenReturn("file.csv");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<>(List.of(entry)));
        sftpMap.put("channelSftp", channelSftp);
        sftpMap.put("sftpSession", session);
        sftpMap.put("channel", channel);

        Map<String, Long> fileSizeMap = new HashMap<>();
        fileSizeMap.put("file.csv", 1024L * 1024L * 30L);

        Path split = Paths.get("/tmp/file.csv.1.csv");

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest")).thenReturn(sftpMap);
            sftp.when(() -> SftpUtil.splitFilePerMbPerNewLine(Mockito.anyString(), Mockito.eq(20), Mockito.eq(256), Mockito.anyString(), Mockito.eq(false), Mockito.eq(".csv")))
                    .thenReturn(List.of(split));

            SchedulerAutoEnrollment.checkAndSplit("/dest", 20, 256, fileSizeMap);

            sftp.verify(() -> SftpUtil.movefileFromlocalToServer(split.toFile().getPath(), sftpMap, "/dest"));
            sftp.verify(() -> SftpUtil.removeFileFromServer(sftpMap, "/dest", "file.csv"));
        }
    }

    @Test
    public void testCheckAndSplitSkipsWhenFileSizeIsMissing() {
        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        Mockito.when(entry.getFilename()).thenReturn("missing.csv");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<>(List.of(entry)));

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest")).thenReturn(sftpMap);

            SchedulerAutoEnrollment.checkAndSplit("/dest", 20, 256, new HashMap<>());

            sftp.verify(() -> SftpUtil.copyFileToLocal(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyMap()), Mockito.never());
        }
    }

    @Test
    public void testCheckAndSplitHandlesSftpException() {
        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"))
                    .thenThrow(new SftpException(1, "SFTP Error"));

            SchedulerAutoEnrollment.checkAndSplit("/dest", 20, 256, new HashMap<>());

            sftp.verify(() -> SftpUtil.copyFileToLocal(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyMap()), Mockito.never());
        }
    }

    @Test
    public void testCheckAndSplitReturnsDuringBusinessHours() {
        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            SchedulerAutoEnrollment.checkAndSplit("/dest", 20, 256, new HashMap<>());

            sftp.verifyNoInteractions();
        }
    }

    @Test
    public void testExtractCsvRetriesThenSucceeds() throws Exception {
        Method extractCSV = SchedulerAutoEnrollment.class.getDeclaredMethod("extractCSV", String.class, String.class);
        extractCSV.setAccessible(true);

        Map<String, Object> sftpMap = new HashMap<>();

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest")).thenReturn(sftpMap);
            sftp.when(() -> SftpUtil.readFileStoreData("/dest", getLocalDirectory(), "file.csv", sftpMap, false))
                    .thenThrow(new SftpException(4, "first fail"))
                    .thenReturn(List.of("row1"));

            Object result = extractCSV.invoke(null, "file.csv", "/dest");

            assertNotNull(result);
            assertTrue(((List<?>) result).contains("row1"));
        }
    }

    @Test
    public void testExtractCsvThrowsAfterFiveFailures() throws Exception {
        Method extractCSV = SchedulerAutoEnrollment.class.getDeclaredMethod("extractCSV", String.class, String.class);
        extractCSV.setAccessible(true);

        Map<String, Object> sftpMap = new HashMap<>();

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest")).thenReturn(sftpMap);
            sftp.when(() -> SftpUtil.readFileStoreData("/dest", getLocalDirectory(), "file.csv", sftpMap, false))
                    .thenThrow(new SftpException(4, "fail"));

            try {
                extractCSV.invoke(null, "file.csv", "/dest");
                fail("Expected SftpException wrapped in InvocationTargetException");
            } catch (InvocationTargetException e) {
                assertTrue(e.getCause() instanceof SftpException);
            }
        }
    }

    @Test
    public void testProcessFilesHandlesValidCsvFile() throws Exception {
        Method processFiles = SchedulerAutoEnrollment.class.getDeclaredMethod(
                "processFiles", String.class, String.class, String.class, String.class, String.class);
        processFiles.setAccessible(true);

        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        Mockito.when(entry.getFilename()).thenReturn("test.csv");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<>(List.of(entry)));

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/dest"))
                    .thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest")).thenReturn(sftpMap);
            sftp.when(() -> SftpUtil.readFileStoreData("/dest", getLocalDirectory(), "test.csv", sftpMap, false))
                    .thenReturn(List.of("data1", "data2"));
            sftp.when(() -> SftpUtil.createNewDirectoryAndMoveFiles(
                    Mockito.any(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
                    Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyString(), Mockito.any()))
                    .thenReturn(true);

            processFiles.invoke(null, "/dest", "/working", "/dest", "/dest", "/archive");

            sftp.verify(() -> SftpUtil.readFileSendAutoEnroCloud(Mockito.anyList()), times(1));
        }
    }

    @Test
    public void testProcessFilesSkipsNonCsvFiles() throws Exception {
        Method processFiles = SchedulerAutoEnrollment.class.getDeclaredMethod(
                "processFiles", String.class, String.class, String.class, String.class, String.class);
        processFiles.setAccessible(true);

        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        Mockito.when(entry.getFilename()).thenReturn("test.txt");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<>(List.of(entry)));

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/dest"))
                    .thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest")).thenReturn(sftpMap);

            processFiles.invoke(null, "/dest", "/working", "/dest", "/dest", "/archive");

            sftp.verify(() -> SftpUtil.readFileStoreData(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(), Mockito.anyBoolean()), Mockito.never());
        }
    }

    @Test
    public void testProcessFilesHandlesMissingCredentials() throws Exception {
        Method processFiles = SchedulerAutoEnrollment.class.getDeclaredMethod(
                "processFiles", String.class, String.class, String.class, String.class, String.class);
        processFiles.setAccessible(true);

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/dest"))
                    .thenReturn(true);

            processFiles.invoke(null, "/dest", "/working", "/dest", "/dest", "/archive");

            sftp.verify(() -> SftpUtil.sftpDirectory(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString()), Mockito.never());
        }
    }

    @Test
    public void testProcessFilesHandlesSftpException() throws Exception {
        Method processFiles = SchedulerAutoEnrollment.class.getDeclaredMethod(
                "processFiles", String.class, String.class, String.class, String.class, String.class);
        processFiles.setAccessible(true);

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/dest"))
                    .thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"))
                    .thenThrow(new SftpException(1, "SFTP Error"));

            processFiles.invoke(null, "/dest", "/working", "/dest", "/dest", "/archive");

            sftp.verify(() -> SftpUtil.readFileStoreData(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(), Mockito.anyBoolean()), Mockito.never());
        }
    }

    @Test
    public void testProcessFilesReturnsImmediatelyDuringBusinessHours() throws Exception {
        Method processFiles = SchedulerAutoEnrollment.class.getDeclaredMethod(
                "processFiles", String.class, String.class, String.class, String.class, String.class);
        processFiles.setAccessible(true);

        setStaticField("stoppedFileName", "already-stopped.csv");

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            processFiles.invoke(null, "/dest", "/working", "/dest", "/dest", "/archive");

            sftp.verifyNoInteractions();
        }
    }

    @Test
    public void testProcessFilesStopsMidLoopWhenBusinessHoursBegins() throws Exception {
        Method processFiles = SchedulerAutoEnrollment.class.getDeclaredMethod(
                "processFiles", String.class, String.class, String.class, String.class, String.class);
        processFiles.setAccessible(true);

        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        Mockito.when(entry.getFilename()).thenReturn("midstop.csv");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<>(List.of(entry)));

        setStaticField("stoppedFileName", null);

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            // 1) processFiles start, 2) extractCSV start, 3) after extractCSV before processing post
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false, false, true);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/dest"))
                    .thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"))
                    .thenReturn(sftpMap)
                    .thenReturn(sftpMap);
            sftp.when(() -> SftpUtil.readFileStoreData("/dest", getLocalDirectory(), "midstop.csv", sftpMap, false))
                    .thenReturn(List.of("row"));

            processFiles.invoke(null, "/dest", "/working", "/dest", "/dest", "/archive");

            sftp.verify(() -> SftpUtil.readFileSendAutoEnroCloud(Mockito.anyList()), Mockito.never());
            assertEquals("midstop.csv", getStaticField("stoppedFileName"));
        }
    }

    @Test
    public void testProcessRetryReturnsDuringBusinessHours() throws Exception {
        Method processRetry = SchedulerAutoEnrollment.class.getDeclaredMethod("processRetry");
        processRetry.setAccessible(true);

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            processRetry.invoke(null);

            sftp.verifyNoInteractions();
        }

        AtomicBoolean lock = (AtomicBoolean) getStaticField("lock");
        assertFalse(lock.get());
    }

    @Test
    public void testProcessRetryHandlesMissingCredentialsAndUnlocks() throws Exception {
        Method processRetry = SchedulerAutoEnrollment.class.getDeclaredMethod("processRetry");
        processRetry.setAccessible(true);

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/retry/work"))
                    .thenReturn(true);

            processRetry.invoke(null);

            sftp.verify(() -> SftpUtil.sftpDirectory(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString()), Mockito.never());
        }

        AtomicBoolean lock = (AtomicBoolean) getStaticField("lock");
        assertFalse(lock.get());
    }

    @Test
    public void testStaticCountersAreInitialized() throws Exception {
        AtomicInteger getCount = (AtomicInteger) getStaticField("getCount");
        AtomicInteger postCount = (AtomicInteger) getStaticField("postCount");
        AtomicInteger emailCount = (AtomicInteger) getStaticField("emailCount");
        AtomicInteger emailNotFound = (AtomicInteger) getStaticField("emailNotFound");
        AtomicBoolean lock = (AtomicBoolean) getStaticField("lock");

        assertNotNull(getCount);
        assertNotNull(postCount);
        assertNotNull(emailCount);
        assertNotNull(emailNotFound);
        assertNotNull(lock);
        assertFalse(lock.get());
    }

    private void setStaticField(String fieldName, Object value) throws Exception {
        Field field = SchedulerAutoEnrollment.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(null, value);
    }

    private Object getStaticField(String fieldName) throws Exception {
        Field field = SchedulerAutoEnrollment.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(null);
    }

    private String getLocalDirectory() {
        try {
            Field field = SchedulerAutoEnrollment.class.getDeclaredField("LOCAL_DIRECTORY");
            field.setAccessible(true);
            return (String) field.get(null);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }
}
