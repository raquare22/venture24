package com.optum.providerpreferences.autoenrollment;

import com.optum.providerpreferences.autoenrollment.config.SchedulerConfig;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.optum.providerpreferences.rs.model.PaymentPreference;
import com.optum.providerpreferences.rs.service.PaymentPreferenceServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.MockitoJUnitRunner;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class SchedulerMemberPaymentPreferenceTest {

    @Mock
    private PaymentPreferenceServiceImpl paymentPreferenceService;

    @Before
    public void setUp() throws Exception {
        // Reset static fields
        setStaticField(SchedulerMemberPaymentPreference.class, "getCount", new java.util.concurrent.atomic.AtomicInteger(0));
        setStaticField(SchedulerMemberPaymentPreference.class, "postCount", new java.util.concurrent.atomic.AtomicInteger(0));
        setStaticField(SchedulerMemberPaymentPreference.class, "emailCount", new java.util.concurrent.atomic.AtomicInteger(0));
        setStaticField(SchedulerMemberPaymentPreference.class, "lastSchedulerCount", new java.util.concurrent.atomic.AtomicInteger(0));
        setStaticField(SchedulerMemberPaymentPreference.class, "lock", new java.util.concurrent.atomic.AtomicBoolean(false));
    }

    private void setStaticField(Class<?> clazz, String fieldName, Object value) throws Exception {
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(null, value);
    }

    @Test
    public void testProcessMemberPaymentPreferenceDataWithNullData() throws Exception {
        // Arrange - null data
        List<String> data = null;
        setPaymentPreferenceServiceField(paymentPreferenceService);

        // Act & Assert - should not throw exception
        java.lang.reflect.Method method = SchedulerMemberPaymentPreference.class.getDeclaredMethod("processMemberPaymentPreferenceData", List.class);
        method.setAccessible(true);
        method.invoke(null, data);
    }

    @Test
    public void testProcessMemberPaymentPreferenceDataWithEmptyData() throws Exception {
        // Arrange - empty list
        List<String> data = new ArrayList<>();
        setPaymentPreferenceServiceField(paymentPreferenceService);

        // Act & Assert - should not throw exception
        java.lang.reflect.Method method = SchedulerMemberPaymentPreference.class.getDeclaredMethod("processMemberPaymentPreferenceData", List.class);
        method.setAccessible(true);
        method.invoke(null, data);
    }

    @Test
    public void testProcessMemberPaymentPreferenceDataWithValidTokens() throws Exception {
        // Arrange
        PaymentPreference existingPref = new PaymentPreference();
        existingPref.setTin("123456789");
        existingPref.setMpin("9876543");
        existingPref.setUpdatedBy("");

        setPaymentPreferenceServiceField(paymentPreferenceService);
        when(paymentPreferenceService.getPaymentPreferenceByTinAndMpin("123456789", "9876543"))
                .thenReturn(existingPref);

        List<String> data = new ArrayList<>();
        data.add("123456789,9876543,111111,ACH,123456789,");

        // Act
        java.lang.reflect.Method method = SchedulerMemberPaymentPreference.class.getDeclaredMethod("processMemberPaymentPreferenceData", List.class);
        method.setAccessible(true);
        method.invoke(null, data);

        // Assert - verify update was called
        verify(paymentPreferenceService, times(1)).updatePaymentPreference("123456789", "9876543", "ACH", "");
    }

    @Test
    public void testProcessMemberPaymentPreferenceDataWithInvalidLineTokens() throws Exception {
        // Arrange - line with less than 6 tokens
        List<String> data = new ArrayList<>();
        data.add("123456789,9876543"); // Only 2 tokens, needs 6

        setPaymentPreferenceServiceField(paymentPreferenceService);

        // Act & Assert - should skip invalid line
        java.lang.reflect.Method method = SchedulerMemberPaymentPreference.class.getDeclaredMethod("processMemberPaymentPreferenceData", List.class);
        method.setAccessible(true);
        method.invoke(null, data);

        // Verify service was not called
        verify(paymentPreferenceService, never()).getPaymentPreferenceByTinAndMpin(anyString(), anyString());
    }

    @Test
    public void testProcessMemberPaymentPreferenceDataInsertNewRecord() throws Exception {
        // Arrange
        setPaymentPreferenceServiceField(paymentPreferenceService);
        when(paymentPreferenceService.getPaymentPreferenceByTinAndMpin("999999999", "1111111"))
                .thenReturn(null); // Record doesn't exist

        List<String> data = new ArrayList<>();
        data.add("999999999,1111111,222222,WIRE,987654321,");

        // Act
        java.lang.reflect.Method method = SchedulerMemberPaymentPreference.class.getDeclaredMethod("processMemberPaymentPreferenceData", List.class);
        method.setAccessible(true);
        method.invoke(null, data);

        // Assert - verify insert was called
        verify(paymentPreferenceService, times(1)).insertPaymentPreference(any(PaymentPreference.class));
    }

    @Test
    public void testProcessMemberPaymentPreferenceDataSkipUpdateWhenUpdatedByNotEmpty() throws Exception {
        // Arrange
        PaymentPreference existingPref = new PaymentPreference();
        existingPref.setTin("555555555");
        existingPref.setMpin("5555555");
        existingPref.setUpdatedBy("ADMIN"); // Not empty

        setPaymentPreferenceServiceField(paymentPreferenceService);
        when(paymentPreferenceService.getPaymentPreferenceByTinAndMpin("555555555", "5555555"))
                .thenReturn(existingPref);

        List<String> data = new ArrayList<>();
        data.add("555555555,5555555,333333,CHECK,111111111,");

        // Act
        java.lang.reflect.Method method = SchedulerMemberPaymentPreference.class.getDeclaredMethod("processMemberPaymentPreferenceData", List.class);
        method.setAccessible(true);
        method.invoke(null, data);

        // Assert - verify update was NOT called
        verify(paymentPreferenceService, never()).updatePaymentPreference(anyString(), anyString(), anyString(), anyString());
    }

    @Test
    public void testProcessMemberPaymentPreferenceDataUpdatesWhenUpdatedByNull() throws Exception {
        PaymentPreference existingPref = new PaymentPreference();
        existingPref.setTin("101010101");
        existingPref.setMpin("2020202");
        existingPref.setUpdatedBy(null);

        setPaymentPreferenceServiceField(paymentPreferenceService);
        when(paymentPreferenceService.getPaymentPreferenceByTinAndMpin("101010101", "2020202"))
                .thenReturn(existingPref);

        List<String> data = new ArrayList<>();
        data.add("101010101,2020202,303030,ACH,444444444,");

        java.lang.reflect.Method method = SchedulerMemberPaymentPreference.class.getDeclaredMethod("processMemberPaymentPreferenceData", List.class);
        method.setAccessible(true);
        method.invoke(null, data);

        verify(paymentPreferenceService, times(1)).updatePaymentPreference("101010101", "2020202", "ACH", "");
    }

    @Test
    public void testSchedulerMemberPaymentSkipsWhenWithinBusinessHours() {
        try (MockedStatic<TimeUtils> mockedTimeUtils = mockStatic(TimeUtils.class)) {
            // Arrange
            mockedTimeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            // Act
            SchedulerMemberPaymentPreference.class.getDeclaredMethod("SchedulerMemberPayment").invoke(null);

            // Assert - no exception thrown, method returns early
            mockedTimeUtils.verify(TimeUtils::isWithinBusinessHours, times(1));
        } catch (Exception e) {
            fail("Should not throw exception: " + e.getMessage());
        }
    }

    @Test
    public void testSchedulerMemberPaymentInvokesJobWhenOffBusinessHours() throws Exception {
        SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_WORKING_DIRECTORY = "/work";
        SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_DESTINATION_DIRECTORY = "/dest";
        SchedulerConfig.MEMBER_PAYMENT_PREFERENCE_ARCHIVE_DIRECTORY = "/archive";
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "key";

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false, false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "key", "/work"))
                    .thenReturn(true);

            SchedulerMemberPaymentPreference.SchedulerMemberPayment();

            sftp.verify(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "key", "/work"), times(1));
        }
    }

    @Test
    public void testExecuteScheduledJobReturnsWhenAlreadyLocked() throws Exception {
        setStaticField(SchedulerMemberPaymentPreference.class, "lock", new java.util.concurrent.atomic.AtomicBoolean(true));

        invokePrivateStatic("executeScheduledJob",
                new Class<?>[]{String.class, String.class, String.class, String.class},
                "id", "/work", "/dest", "/archive");

        java.util.concurrent.atomic.AtomicBoolean lock =
                (java.util.concurrent.atomic.AtomicBoolean) getStaticField(SchedulerMemberPaymentPreference.class, "lock");
        assertTrue(lock.get());
    }

    @Test
    public void testExecuteScheduledJobReturnsDuringBusinessHours() throws Exception {
        setStaticField(SchedulerMemberPaymentPreference.class, "lock", new java.util.concurrent.atomic.AtomicBoolean(false));
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            invokePrivateStatic("executeScheduledJob",
                    new Class<?>[]{String.class, String.class, String.class, String.class},
                    "id", "/work", "/dest", "/archive");
        }

        java.util.concurrent.atomic.AtomicBoolean lock =
                (java.util.concurrent.atomic.AtomicBoolean) getStaticField(SchedulerMemberPaymentPreference.class, "lock");
        assertTrue(lock.get());
    }

    @Test
    public void testExecuteScheduledJobReturnsWhenMissingCredentials() throws Exception {
        setStaticField(SchedulerMemberPaymentPreference.class, "lock", new java.util.concurrent.atomic.AtomicBoolean(false));
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "key";

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "key", "/work"))
                    .thenReturn(true);

            invokePrivateStatic("executeScheduledJob",
                    new Class<?>[]{String.class, String.class, String.class, String.class},
                    "id", "/work", "/dest", "/archive");
        }

        java.util.concurrent.atomic.AtomicBoolean lock =
                (java.util.concurrent.atomic.AtomicBoolean) getStaticField(SchedulerMemberPaymentPreference.class, "lock");
        assertFalse(lock.get());
    }

    @Test
    public void testExecuteScheduledJobReturnsWhenNoWorkFound() throws Exception {
        setStaticField(SchedulerMemberPaymentPreference.class, "lock", new java.util.concurrent.atomic.AtomicBoolean(false));
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "key";
        SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE = "20";
        SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN = "256";

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "key", "/work"))
                    .thenReturn(false);

            invokePrivateStatic("executeScheduledJob",
                    new Class<?>[]{String.class, String.class, String.class, String.class},
                    "id", "/work", "/dest", "/archive");
        }

        java.util.concurrent.atomic.AtomicBoolean lock =
                (java.util.concurrent.atomic.AtomicBoolean) getStaticField(SchedulerMemberPaymentPreference.class, "lock");
        assertFalse(lock.get());
    }

    @Test
    public void testProcessFilesHandlesPerFileSftpException() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "key";

        ChannelSftp channelSftp = mock(ChannelSftp.class);
        Session session = mock(Session.class);
        Channel channel = mock(Channel.class);
        ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
        when(entry.getFilename()).thenReturn("a.csv");
        ArrayList<ChannelSftp.LsEntry> listing = new ArrayList<>();
        listing.add(entry);

        Map<String, Object> map = new HashMap<>();
        map.put("directoryListing", listing);
        map.put("channelSftp", channelSftp);
        map.put("sftpSession", session);
        map.put("channel", channel);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "key", "/dest")).thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "key", "host", "/dest")).thenReturn(map).thenThrow(new SftpException(4, "boom"));
            sftp.when(() -> SftpUtil.closeSFTPChannel(channelSftp, session, channel)).thenAnswer(invocation -> null);

            invokePrivateStatic("processFiles",
                    new Class<?>[]{String.class, String.class, String.class, String.class, String.class},
                    "/dest", "/fixedWork", "/fixedDest", "/dirFrom", "/dirTo");

            sftp.verify(() -> SftpUtil.closeSFTPChannel(channelSftp, session, channel), times(1));
        }
    }

    @Test
    public void testProcessFilesReturnsDuringBusinessHours() throws Exception {
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            invokePrivateStatic("processFiles",
                    new Class<?>[]{String.class, String.class, String.class, String.class, String.class},
                    "/dest", "/fixedWork", "/fixedDest", "/dirFrom", "/dirTo");

            sftp.verifyNoInteractions();
        }
    }

    @Test
    public void testProcessFilesReturnsWhenMissingCredentials() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "key";

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "key", "/dest"))
                    .thenReturn(true);

            invokePrivateStatic("processFiles",
                    new Class<?>[]{String.class, String.class, String.class, String.class, String.class},
                    "/dest", "/fixedWork", "/fixedDest", "/dirFrom", "/dirTo");

            sftp.verify(() -> SftpUtil.sftpDirectory(anyString(), anyString(), anyString(), anyString()), never());
        }
    }

    @Test
    public void testProcessFilesSkipsNonCsvEntry() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "key";

        ChannelSftp channelSftp = mock(ChannelSftp.class);
        Session session = mock(Session.class);
        Channel channel = mock(Channel.class);
        ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
        when(entry.getFilename()).thenReturn("not-csv.txt");

        ArrayList<ChannelSftp.LsEntry> listing = new ArrayList<>();
        listing.add(entry);
        Map<String, Object> map = new HashMap<>();
        map.put("directoryListing", listing);
        map.put("channelSftp", channelSftp);
        map.put("sftpSession", session);
        map.put("channel", channel);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "key", "/dest")).thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "key", "host", "/dest")).thenReturn(map);

            invokePrivateStatic("processFiles",
                    new Class<?>[]{String.class, String.class, String.class, String.class, String.class},
                    "/dest", "/fixedWork", "/fixedDest", "/dirFrom", "/dirTo");

            sftp.verify(() -> SftpUtil.readFileStoreMemberPaymentData(anyString(), anyString(), anyString(), anyMap(), anyBoolean()), never());
            sftp.verify(() -> SftpUtil.closeSFTPChannel(channelSftp, session, channel), times(1));
        }
    }

    @Test
    public void testProcessFilesStopsWhenBusinessHoursBeginsMidLoop() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "key";
        setStaticField(SchedulerMemberPaymentPreference.class, "stoppedFileName", null);

        ChannelSftp channelSftp = mock(ChannelSftp.class);
        Session session = mock(Session.class);
        Channel channel = mock(Channel.class);
        ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
        when(entry.getFilename()).thenReturn("stop.csv");

        ArrayList<ChannelSftp.LsEntry> listing = new ArrayList<>();
        listing.add(entry);
        Map<String, Object> map = new HashMap<>();
        map.put("directoryListing", listing);
        map.put("channelSftp", channelSftp);
        map.put("sftpSession", session);
        map.put("channel", channel);
        String localDirectory = getPrivateStaticString(SchedulerMemberPaymentPreference.class, "LOCAL_DIRECTORY");

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            // 1) processFiles entry 2) extractCSV entry 3) post-extract check
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false, false, true);
            sftp.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "key", "/dest")).thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "key", "host", "/dest")).thenReturn(map).thenReturn(map);
            sftp.when(() -> SftpUtil.readFileStoreMemberPaymentData("/dest", localDirectory, "stop.csv", map, false))
                    .thenReturn(List.of("line"));

            invokePrivateStatic("processFiles",
                    new Class<?>[]{String.class, String.class, String.class, String.class, String.class},
                    "/dest", "/fixedWork", "/fixedDest", "/dirFrom", "/dirTo");

            sftp.verify(() -> SftpUtil.createNewDirectoryAndMoveFiles(
                    any(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyInt(), anyInt(), anyString(), any()), never());
            assertEquals("stop.csv", getStaticField(SchedulerMemberPaymentPreference.class, "stoppedFileName"));
            sftp.verify(() -> SftpUtil.closeSFTPChannel(channelSftp, session, channel), times(1));
        }
    }

    @Test
    public void testExtractCsvReturnsDataOnSuccessfulRead() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "key";
        String localDirectory = getPrivateStaticString(SchedulerMemberPaymentPreference.class, "LOCAL_DIRECTORY");

        Map<String, Object> map = new HashMap<>();
        List<String> expected = new ArrayList<>();
        expected.add("line1");

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "key", "host", "/dest")).thenReturn(map);
            sftp.when(() -> SftpUtil.readFileStoreMemberPaymentData("/dest", localDirectory, "a.csv", map, false)).thenReturn(expected);

            Object result = invokePrivateStatic("extractCSV",
                    new Class<?>[]{String.class, String.class}, "a.csv", "/dest");

            assertEquals(expected, result);
        }
    }

    @Test
    public void testExtractCsvReturnsNullDuringBusinessHours() throws Exception {
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);

            Object result = invokePrivateStatic("extractCSV", new Class<?>[]{String.class, String.class}, "a.csv", "/dest");

            assertNull(result);
        }
    }

    @Test
    public void testExtractCsvRetriesThenSucceeds() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "key";
        String localDirectory = getPrivateStaticString(SchedulerMemberPaymentPreference.class, "LOCAL_DIRECTORY");

        Map<String, Object> map = new HashMap<>();
        List<String> expected = List.of("line1", "line2");
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "key", "host", "/dest"))
                    .thenReturn(map)
                    .thenReturn(map);
            sftp.when(() -> SftpUtil.readFileStoreMemberPaymentData("/dest", localDirectory, "a.csv", map, false))
                    .thenThrow(new SftpException(4, "retry"))
                    .thenReturn(expected);

            Object result = invokePrivateStatic("extractCSV", new Class<?>[]{String.class, String.class}, "a.csv", "/dest");

            assertEquals(expected, result);
        }
    }

    @Test
    public void testExtractCsvThrowsAfterRetries() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "key";
        String localDirectory = getPrivateStaticString(SchedulerMemberPaymentPreference.class, "LOCAL_DIRECTORY");

        Map<String, Object> map = new HashMap<>();
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> sftp = mockStatic(SftpUtil.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            sftp.when(() -> SftpUtil.sftpDirectory("user", "key", "host", "/dest")).thenReturn(map);
            sftp.when(() -> SftpUtil.readFileStoreMemberPaymentData("/dest", localDirectory, "a.csv", map, false))
                    .thenThrow(new SftpException(4, "sftp down"));

            try {
                invokePrivateStatic("extractCSV", new Class<?>[]{String.class, String.class}, "a.csv", "/dest");
                fail("Expected SftpException");
            } catch (InvocationTargetException e) {
                assertTrue(e.getCause() instanceof SftpException);
                assertEquals(4, ((SftpException) e.getCause()).id);
            }
        }
    }

    @Test
    public void testProcessMemberPaymentPreferenceDataHandlesPerLineException() throws Exception {
        setPaymentPreferenceServiceField(paymentPreferenceService);
        when(paymentPreferenceService.getPaymentPreferenceByTinAndMpin("123456789", "9876543"))
                .thenThrow(new RuntimeException("db fail"));

        List<String> data = new ArrayList<>();
        data.add("123456789,9876543,111111,ACH,123456789,");

        java.lang.reflect.Method method = SchedulerMemberPaymentPreference.class.getDeclaredMethod("processMemberPaymentPreferenceData", List.class);
        method.setAccessible(true);
        method.invoke(null, data);

        verify(paymentPreferenceService, times(1)).getPaymentPreferenceByTinAndMpin("123456789", "9876543");
    }

    @Test
    public void testAtomicCountersAreInitialized() throws Exception {
        // Assert
        java.util.concurrent.atomic.AtomicInteger getCount = 
            (java.util.concurrent.atomic.AtomicInteger) getStaticField(SchedulerMemberPaymentPreference.class, "getCount");
        java.util.concurrent.atomic.AtomicInteger postCount = 
            (java.util.concurrent.atomic.AtomicInteger) getStaticField(SchedulerMemberPaymentPreference.class, "postCount");
        java.util.concurrent.atomic.AtomicInteger emailCount = 
            (java.util.concurrent.atomic.AtomicInteger) getStaticField(SchedulerMemberPaymentPreference.class, "emailCount");

        assertNotNull(getCount);
        assertNotNull(postCount);
        assertNotNull(emailCount);
        assertEquals(0, getCount.get());
        assertEquals(0, postCount.get());
        assertEquals(0, emailCount.get());
    }

    @Test
    public void testLockIsInitiallyFalse() throws Exception {
        // Assert
        java.util.concurrent.atomic.AtomicBoolean lock = 
            (java.util.concurrent.atomic.AtomicBoolean) getStaticField(SchedulerMemberPaymentPreference.class, "lock");

        assertNotNull(lock);
        assertFalse(lock.get());
    }

    private Object getStaticField(Class<?> clazz, String fieldName) throws Exception {
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(null);
    }

    private void setPaymentPreferenceServiceField(PaymentPreferenceServiceImpl service) throws Exception {
        Field field = SchedulerMemberPaymentPreference.class.getDeclaredField("paymentPreferenceService");
        field.setAccessible(true);
        field.set(null, service);
    }

    private Object invokePrivateStatic(String methodName, Class<?>[] types, Object... args) throws Exception {
        java.lang.reflect.Method method = SchedulerMemberPaymentPreference.class.getDeclaredMethod(methodName, types);
        method.setAccessible(true);
        return method.invoke(null, args);
    }

    private String getPrivateStaticString(Class<?> clazz, String fieldName) throws Exception {
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        return (String) field.get(null);
    }
}

