package com.optum.providerpreferences.autoenrollment;

import com.optum.providerpreferences.autoenrollment.config.SchedulerConfig;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockedStatic;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.BufferedWriter;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class SchedulerMonthlyTest {

    @Before
    public void setUp() throws Exception {
        // Reset static fields to clean state
        setStaticField(SchedulerMonthly.class, "getCount", new AtomicInteger(0));
        setStaticField(SchedulerMonthly.class, "postCount", new AtomicInteger(0));
        setStaticField(SchedulerMonthly.class, "emailCount", new AtomicInteger(0));
        setStaticField(SchedulerMonthly.class, "emailNotFound", new AtomicInteger(0));
        setStaticField(SchedulerMonthly.class, "lastSchedulerCount", new AtomicInteger(0));
        setStaticField(SchedulerMonthly.class, "lock", new AtomicBoolean(false));
        setStaticField(SchedulerMonthly.class, "tinsUpdatedEmail", new HashSet<>());
        setStaticField(SchedulerMonthly.class, "tinsWithoutEmail", new HashSet<>());
    }

    private void setStaticField(Class<?> clazz, String fieldName, Object value) throws Exception {
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(null, value);
    }

    private Object getStaticField(Class<?> clazz, String fieldName) throws Exception {
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(null);
    }

    @Test
    public void testAtomicCountersInitialized() throws Exception {
        // Assert
        AtomicInteger getCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "getCount");
        AtomicInteger postCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "postCount");
        AtomicInteger emailCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "emailCount");
        AtomicInteger emailNotFound = (AtomicInteger) getStaticField(SchedulerMonthly.class, "emailNotFound");
        AtomicInteger lastSchedulerCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "lastSchedulerCount");

        assertNotNull(getCount);
        assertNotNull(postCount);
        assertNotNull(emailCount);
        assertNotNull(emailNotFound);
        assertNotNull(lastSchedulerCount);
        assertEquals(0, getCount.get());
        assertEquals(0, postCount.get());
        assertEquals(0, emailCount.get());
        assertEquals(0, emailNotFound.get());
        assertEquals(0, lastSchedulerCount.get());
    }

    @Test
    public void testTinsSetInitialized() throws Exception {
        // Assert
        @SuppressWarnings("unchecked")
        HashSet<String> tinsUpdatedEmail = (HashSet<String>) getStaticField(SchedulerMonthly.class, "tinsUpdatedEmail");
        @SuppressWarnings("unchecked")
        HashSet<String> tinsWithoutEmail = (HashSet<String>) getStaticField(SchedulerMonthly.class, "tinsWithoutEmail");

        assertNotNull(tinsUpdatedEmail);
        assertNotNull(tinsWithoutEmail);
        assertTrue(tinsUpdatedEmail.isEmpty());
        assertTrue(tinsWithoutEmail.isEmpty());
    }

    @Test
    public void testLockIsInitiallyFalse() throws Exception {
        // Assert
        AtomicBoolean lock = (AtomicBoolean) getStaticField(SchedulerMonthly.class, "lock");

        assertNotNull(lock);
        assertFalse(lock.get());
    }

    @Test
    public void testSchedulerEmailCheckSkipsWhenLocked() throws Exception {
        // Arrange - set lock to true
        AtomicBoolean lock = (AtomicBoolean) getStaticField(SchedulerMonthly.class, "lock");
        lock.set(true);

        // Act - should return early without error
        java.lang.reflect.Method method = SchedulerMonthly.class.getDeclaredMethod("SchedulerEmailCheck");
        method.setAccessible(true);
        method.invoke(null);

        // Assert - lock should still be true (early return)
        assertTrue(lock.get());
    }

    @Test
    public void testEmailCheckManualSkipsWhenLocked() throws Exception {
        // Arrange - set lock to true
        AtomicBoolean lock = (AtomicBoolean) getStaticField(SchedulerMonthly.class, "lock");
        lock.set(true);

        // Act - should return early without error
        java.lang.reflect.Method method = SchedulerMonthly.class.getDeclaredMethod("EmailCheckManual");
        method.setAccessible(true);
        method.invoke(null);

        // Assert - lock should still be true (early return)
        assertTrue(lock.get());
    }

    @Test
    public void testCountsMatchLogic() throws Exception {
        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            SchedulerConfig.PRUN_EMAIL_CHECK_WORKING_DIRECTORY = "/work";
            SchedulerConfig.PRUN_EMAIL_CHECK_DESTINATION_DIRECTORY = "/dest";
            SchedulerConfig.PRUN_EMAIL_CHECK_ARCHIVE_DIRECTORY = "/archive";
            SchedulerConfig.prunHost = "host";
            SchedulerConfig.prunUserName = "user";
            SchedulerConfig.prunKey = "pass";
            // Arrange - mock SftpUtil to prevent IOException
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential(
                    "host", "user", "pass", "/work"))
                    .thenReturn(false);
            
            AtomicBoolean lock = (AtomicBoolean) getStaticField(SchedulerMonthly.class, "lock");
            AtomicInteger lastSchedulerCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "lastSchedulerCount");
            AtomicInteger postCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "postCount");
            AtomicInteger getCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "getCount");

            lock.set(true);
            lastSchedulerCount.set(5);
            postCount.set(5);
            getCount.set(5);

            // Act
            java.lang.reflect.Method method = SchedulerMonthly.class.getDeclaredMethod("SchedulerEmailCheck");
            method.setAccessible(true);
            method.invoke(null);

            // Assert - lock should be reset to false when counts match
            assertFalse(lock.get());
            assertEquals(0, getCount.get());
            assertEquals(0, postCount.get());
        }
    }

    @Test
    public void testCountsDoNotMatchKeepsLockTrue() throws Exception {
        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            SchedulerConfig.PRUN_EMAIL_CHECK_WORKING_DIRECTORY = "/work";
            SchedulerConfig.PRUN_EMAIL_CHECK_DESTINATION_DIRECTORY = "/dest";
            SchedulerConfig.PRUN_EMAIL_CHECK_ARCHIVE_DIRECTORY = "/archive";
            SchedulerConfig.prunHost = "host";
            SchedulerConfig.prunUserName = "user";
            SchedulerConfig.prunKey = "pass";
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/work"))
                    .thenReturn(false);

            AtomicBoolean lock = (AtomicBoolean) getStaticField(SchedulerMonthly.class, "lock");
            AtomicInteger lastSchedulerCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "lastSchedulerCount");
            AtomicInteger postCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "postCount");
            AtomicInteger getCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "getCount");

            lock.set(true);
            lastSchedulerCount.set(5);
            postCount.set(4); // mismatch path
            getCount.set(3);

            Method method = SchedulerMonthly.class.getDeclaredMethod("SchedulerEmailCheck");
            method.setAccessible(true);
            method.invoke(null);

            assertTrue(lock.get());
        }
    }

    @Test
    public void testCountsStuckResetsWhenLastMatchesPostButNotGet() throws Exception {
        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            SchedulerConfig.PRUN_EMAIL_CHECK_WORKING_DIRECTORY = "/work";
            SchedulerConfig.PRUN_EMAIL_CHECK_DESTINATION_DIRECTORY = "/dest";
            SchedulerConfig.PRUN_EMAIL_CHECK_ARCHIVE_DIRECTORY = "/archive";
            SchedulerConfig.prunHost = "host";
            SchedulerConfig.prunUserName = "user";
            SchedulerConfig.prunKey = "pass";

            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/work"))
                    .thenReturn(false);

            AtomicBoolean lock = (AtomicBoolean) getStaticField(SchedulerMonthly.class, "lock");
            AtomicInteger lastSchedulerCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "lastSchedulerCount");
            AtomicInteger postCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "postCount");
            AtomicInteger getCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "getCount");

            lock.set(true);
            lastSchedulerCount.set(5);
            postCount.set(5);
            getCount.set(3);

            Method method = SchedulerMonthly.class.getDeclaredMethod("SchedulerEmailCheck");
            method.setAccessible(true);
            method.invoke(null);

            assertFalse(lock.get());
            assertEquals(0, getCount.get());
            assertEquals(0, postCount.get());
            assertEquals(0, lastSchedulerCount.get());
        }
    }

    @Test
    public void testExecuteScheduledJobReturnsWhenCredentialsMissing() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        AtomicBoolean lock = (AtomicBoolean) getStaticField(SchedulerMonthly.class, "lock");
        lock.set(false);

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/work"))
                    .thenReturn(true);

            invokePrivateStatic("executeScheduledJob",
                    new Class<?>[]{String.class, String.class, String.class, String.class},
                    "id", "/work", "/dest", "/archive");

            assertFalse(lock.get());
        }
    }

    @Test
    public void testExecuteScheduledJobReturnsWhenNoWork() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";
        SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE = "20";
        SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN = "256";

        AtomicBoolean lock = (AtomicBoolean) getStaticField(SchedulerMonthly.class, "lock");
        lock.set(false);

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/work"))
                    .thenReturn(false);

            invokePrivateStatic("executeScheduledJob",
                    new Class<?>[]{String.class, String.class, String.class, String.class},
                    "id", "/work", "/dest", "/archive");

            assertFalse(lock.get());
        }
    }

    @Test
    public void testProcessFilesMissingCredentialPath() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/dest"))
                    .thenReturn(true);

            invokePrivateStatic("processFiles",
                    new Class<?>[]{String.class, String.class, String.class, String.class, String.class},
                    "/dest", "/fixedWork", "/fixedDest", "/from", "/to");

            mockedSftpUtil.verify(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"), never());
        }
    }

    @Test
    public void testProcessFilesOuterCatchOnSftpDirectoryFailure() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/dest"))
                    .thenReturn(false);
            mockedSftpUtil.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"))
                    .thenThrow(new SftpException(4, "sftp down"));

            invokePrivateStatic("processFiles",
                    new Class<?>[]{String.class, String.class, String.class, String.class, String.class},
                    "/dest", "/fixedWork", "/fixedDest", "/from", "/to");
        }
    }

    @Test
    public void testExtractCsvRetriesThenSucceeds() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        Map<String, Object> sftpMap = new HashMap<>();
        List<String> expected = new ArrayList<>();
        expected.add("line");

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"))
                    .thenReturn(sftpMap)
                    .thenReturn(sftpMap);
            mockedSftpUtil.when(() -> SftpUtil.readFileStoreDataEmailCheck("/dest", SchedulerMonthly.LOCAL_DIRECTORY, "f.json", sftpMap, false,
                    "/fixedWork", "/fixedDest", "/from", "/to", "f.json"))
                    .thenThrow(new SftpException(4, "retry"))
                    .thenReturn(expected);

            Object result = invokePrivateStatic("extractCSV",
                    new Class<?>[]{String.class, String.class, String.class, String.class, String.class, String.class, String.class},
                    "f.json", "/dest", "/fixedWork", "/fixedDest", "/from", "/to", "f.json");

            assertEquals(expected, result);
        }
    }

    @Test
    public void testSplitFilesSkipsWhenCredentialsMissing() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/dest"))
                    .thenReturn(true);

            invokePrivateStatic("splitFiles",
                    new Class<?>[]{String.class, int.class, int.class, Map.class},
                    "/dest", 20, 256, new HashMap<String, Long>());

            mockedSftpUtil.verify(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"), never());
        }
    }

    @Test
    public void testSaveChunkToFileCreatesFile() throws Exception {
        // Arrange
        String chunk = "[{\"id\":1},{\"id\":2}]";
        int fileCounter = 1;
        String fileName = "test_file";

        // Act
        java.lang.reflect.Method method = SchedulerMonthly.class.getDeclaredMethod("saveChunkToFile", 
            String.class, int.class, String.class);
        method.setAccessible(true);
        Object result = method.invoke(null, chunk, fileCounter, fileName);

        // Assert - result should be a Path
        assertNotNull(result);
        assertTrue(result instanceof java.nio.file.Path);
    }

    @Test
    public void testSplitJsonFileWithSmallFile() throws Exception {
        // Arrange
        java.nio.file.Path tempFile = java.nio.file.Files.createTempFile("test_", ".json");
        java.nio.file.Files.write(tempFile, "[{\"id\":1}]".getBytes());

        // Act
        java.lang.reflect.Method method = SchedulerMonthly.class.getDeclaredMethod("splitJsonFile", 
            String.class, int.class, int.class, String.class);
        method.setAccessible(true);
        Object result = method.invoke(null, tempFile.toString(), 20, 256, tempFile.getParent().toString());

        // Assert - should return empty list for small file
        assertNotNull(result);
        assertTrue(result instanceof java.util.List);
        
        // Cleanup
        java.nio.file.Files.deleteIfExists(tempFile);
    }

    @Test
    public void testAtomicCountersCanBeIncremented() throws Exception {
        // Arrange
        AtomicInteger getCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "getCount");
        AtomicInteger postCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "postCount");

        // Act
        getCount.incrementAndGet();
        postCount.addAndGet(5);

        // Assert
        assertEquals(1, getCount.get());
        assertEquals(5, postCount.get());
    }

    @Test
    public void testTinsSetCanAddAndClear() throws Exception {
        // Arrange
        @SuppressWarnings("unchecked")
        HashSet<String> tinsUpdatedEmail = (HashSet<String>) getStaticField(SchedulerMonthly.class, "tinsUpdatedEmail");

        // Act
        tinsUpdatedEmail.add("123456789");
        tinsUpdatedEmail.add("987654321");
        assertEquals(2, tinsUpdatedEmail.size());

        tinsUpdatedEmail.clear();

        // Assert
        assertTrue(tinsUpdatedEmail.isEmpty());
    }

    @Test
    public void testLocalDirectoryConstantNotNull() {
        // Assert
        assertNotNull(SchedulerMonthly.LOCAL_DIRECTORY);
        assertFalse(SchedulerMonthly.LOCAL_DIRECTORY.isEmpty());
    }

    @Test
    public void testExecuteScheduledJobHandlesIOExceptionFromCredentialCheck() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        AtomicInteger postCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "postCount");
        AtomicInteger lastSchedulerCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "lastSchedulerCount");
        postCount.set(7);

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/work"))
                    .thenThrow(new java.io.IOException("credential read failure"));

            invokePrivateStatic("executeScheduledJob",
                    new Class<?>[]{String.class, String.class, String.class, String.class},
                    "id", "/work", "/dest", "/archive");
        }

        // finally block should copy postCount to lastSchedulerCount
        assertEquals(7, lastSchedulerCount.get());
    }

    @Test
    public void testExecuteScheduledJobHandlesIOExceptionFromCreateAndMove() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";
        SchedulerConfig.SPLIT_CSV_PER_MAX_MB_SIZE = "20";
        SchedulerConfig.SPLIT_MAX_BYTES_NEW_LINE_WITHIN = "256";

        AtomicInteger postCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "postCount");
        AtomicInteger lastSchedulerCount = (AtomicInteger) getStaticField(SchedulerMonthly.class, "lastSchedulerCount");
        postCount.set(9);

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/work"))
                    .thenReturn(false);
            mockedSftpUtil.when(() -> SftpUtil.createNewDirectoryAndMoveFiles(
                            any(),
                            eq("/work"),
                            eq("/dest"),
                            eq("/work"),
                            eq("/dest"),
                            eq("user"),
                            eq("pass"),
                            eq("host"),
                            eq(".json"),
                            eq("20"),
                            eq("256"),
                            eq(20),
                            eq(256),
                            eq(""),
                            any()))
                    .thenThrow(new java.io.UncheckedIOException(new java.io.IOException("io-failure")));

            try {
                invokePrivateStatic("executeScheduledJob",
                        new Class<?>[]{String.class, String.class, String.class, String.class},
                        "id", "/work", "/dest", "/archive");
                fail("Expected InvocationTargetException with UncheckedIOException cause");
            } catch (InvocationTargetException ex) {
                assertTrue(ex.getCause() instanceof java.io.UncheckedIOException);
                assertEquals("io-failure", ((java.io.UncheckedIOException) ex.getCause()).getCause().getMessage());
            }
        }

        assertEquals(9, lastSchedulerCount.get());
    }

    @Test
    public void testCheckAndSplitSkipsCopyWhenJsonFileMissingFromSizeMap() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        ChannelSftp.LsEntry jsonEntry = mock(ChannelSftp.LsEntry.class);
        when(jsonEntry.getFilename()).thenReturn("missingSize.json");

        ArrayList<ChannelSftp.LsEntry> listing = new ArrayList<>();
        listing.add(jsonEntry);

        ChannelSftp channelSftp = mock(ChannelSftp.class);
        Session session = mock(Session.class);
        Channel channel = mock(Channel.class);

        Map<String, Object> sftpResult = new HashMap<>();
        sftpResult.put("directoryListing", listing);
        sftpResult.put("channelSftp", channelSftp);
        sftpResult.put("sftpSession", session);
        sftpResult.put("channel", channel);

        Map<String, Long> fileSizeMap = new HashMap<>(); // intentionally empty

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"))
                    .thenReturn(sftpResult);

            SchedulerMonthly.checkAndSplit("/dest", 20, 256, fileSizeMap);

            mockedSftpUtil.verify(() -> SftpUtil.copyFileToLocal(anyString(), anyString(), anyString(), anyMap()), never());
            mockedSftpUtil.verify(() -> SftpUtil.closeSFTPChannel(channelSftp, session, channel), times(1));
        }
    }

    @Test
    public void testCheckAndSplitProcessesOnlyJsonFiles() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        ChannelSftp.LsEntry txtEntry = mock(ChannelSftp.LsEntry.class);
        when(txtEntry.getFilename()).thenReturn("ignore.txt");

        ArrayList<ChannelSftp.LsEntry> listing = new ArrayList<>();
        listing.add(txtEntry);

        ChannelSftp channelSftp = mock(ChannelSftp.class);
        Session session = mock(Session.class);
        Channel channel = mock(Channel.class);

        Map<String, Object> sftpResult = new HashMap<>();
        sftpResult.put("directoryListing", listing);
        sftpResult.put("channelSftp", channelSftp);
        sftpResult.put("sftpSession", session);
        sftpResult.put("channel", channel);

        Map<String, Long> fileSizeMap = new HashMap<>();
        fileSizeMap.put("ignore.txt", 1024L);

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"))
                    .thenReturn(sftpResult);

            SchedulerMonthly.checkAndSplit("/dest", 20, 256, fileSizeMap);

            mockedSftpUtil.verify(() -> SftpUtil.copyFileToLocal(anyString(), anyString(), anyString(), anyMap()), never());
            mockedSftpUtil.verify(() -> SftpUtil.closeSFTPChannel(channelSftp, session, channel), times(1));
        }
    }

    @Test
    public void testCheckAndSplitJsonWithSmallSourceSkipsSplitUploadAndCleanup() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        String fileName = "small_source_" + System.nanoTime() + ".json";

        ChannelSftp.LsEntry jsonEntry = mock(ChannelSftp.LsEntry.class);
        when(jsonEntry.getFilename()).thenReturn(fileName);

        ArrayList<ChannelSftp.LsEntry> listing = new ArrayList<>();
        listing.add(jsonEntry);

        ChannelSftp channelSftp = mock(ChannelSftp.class);
        Session session = mock(Session.class);
        Channel channel = mock(Channel.class);

        Map<String, Object> sftpResult = new HashMap<>();
        sftpResult.put("directoryListing", listing);
        sftpResult.put("channelSftp", channelSftp);
        sftpResult.put("sftpSession", session);
        sftpResult.put("channel", channel);

        Map<String, Long> fileSizeMap = new HashMap<>();
        fileSizeMap.put(fileName, 1024L);

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"))
                    .thenReturn(sftpResult);

            SchedulerMonthly.checkAndSplit("/dest", 20, 256, fileSizeMap);

            mockedSftpUtil.verify(() -> SftpUtil.copyFileToLocal("/dest", SchedulerMonthly.LOCAL_DIRECTORY, fileName, sftpResult), times(1));
            mockedSftpUtil.verify(() -> SftpUtil.movefileFromlocalToServer(anyString(), anyMap(), anyString()), never());
            mockedSftpUtil.verify(() -> SftpUtil.removeFileFromServer(anyMap(), anyString(), anyString()), never());
            mockedSftpUtil.verify(() -> SftpUtil.closeSFTPChannel(channelSftp, session, channel), times(1));
        }
    }

    @Test
    public void testSplitJsonFileReturnsEmptyWhenSplitSizeNonPositive() throws Exception {
        Method method = SchedulerMonthly.class.getDeclaredMethod("splitJsonFile", String.class, int.class, int.class, String.class);
        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<java.nio.file.Path> result = (List<java.nio.file.Path>) method.invoke(null, "/tmp/does-not-matter.json", 0, 256, "/tmp");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testSplitJsonFileReturnsEmptyWhenFileMissing() throws Exception {
        Method method = SchedulerMonthly.class.getDeclaredMethod("splitJsonFile", String.class, int.class, int.class, String.class);
        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<java.nio.file.Path> result = (List<java.nio.file.Path>) method.invoke(null, "/tmp/not-found-" + System.nanoTime() + ".json", 1, 256, "/tmp");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testExtractCsvThrowsWhenAllRetriesFail() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        Map<String, Object> sftpMap = new HashMap<>();

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest")).thenReturn(sftpMap);
            mockedSftpUtil.when(() -> SftpUtil.readFileStoreDataEmailCheck("/dest", SchedulerMonthly.LOCAL_DIRECTORY, "f.json", sftpMap, false,
                    "/fixedWork", "/fixedDest", "/from", "/to", "f.json"))
                    .thenThrow(new SftpException(4, "retry"));

            try {
                invokePrivateStatic("extractCSV",
                        new Class<?>[]{String.class, String.class, String.class, String.class, String.class, String.class, String.class},
                        "f.json", "/dest", "/fixedWork", "/fixedDest", "/from", "/to", "f.json");
                fail("Expected InvocationTargetException with SftpException cause");
            } catch (InvocationTargetException ex) {
                assertTrue(ex.getCause() instanceof SftpException);
                assertEquals(4, ((SftpException) ex.getCause()).id);
            }
        }
    }

    @Test
    public void testExtractCsvReturnsOnFirstTryWithoutRetry() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        Map<String, Object> sftpMap = new HashMap<>();
        List<String> expected = new ArrayList<>();
        expected.add("line-1");
        expected.add("line-2");

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"))
                    .thenReturn(sftpMap);
            mockedSftpUtil.when(() -> SftpUtil.readFileStoreDataEmailCheck(
                            "/dest", SchedulerMonthly.LOCAL_DIRECTORY, "f.json", sftpMap, false,
                            "/fixedWork", "/fixedDest", "/from", "/to", "f.json"))
                    .thenReturn(expected);

            Object result = invokePrivateStatic("extractCSV",
                    new Class<?>[]{String.class, String.class, String.class, String.class, String.class, String.class, String.class},
                    "f.json", "/dest", "/fixedWork", "/fixedDest", "/from", "/to", "f.json");

            assertEquals(expected, result);
            mockedSftpUtil.verify(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"), times(1));
            mockedSftpUtil.verify(() -> SftpUtil.readFileStoreDataEmailCheck(
                    "/dest", SchedulerMonthly.LOCAL_DIRECTORY, "f.json", sftpMap, false,
                    "/fixedWork", "/fixedDest", "/from", "/to", "f.json"), times(1));
        }
    }

    @Test
    public void testSplitFilesInvokesCheckAndSplitPathWhenCredentialsPresent() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        ChannelSftp channelSftp = mock(ChannelSftp.class);
        Session session = mock(Session.class);
        Channel channel = mock(Channel.class);

        Map<String, Object> sftpResult = new HashMap<>();
        sftpResult.put("directoryListing", new ArrayList<ChannelSftp.LsEntry>());
        sftpResult.put("channelSftp", channelSftp);
        sftpResult.put("sftpSession", session);
        sftpResult.put("channel", channel);

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/dest"))
                    .thenReturn(false);
            mockedSftpUtil.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"))
                    .thenReturn(sftpResult);

            invokePrivateStatic("splitFiles",
                    new Class<?>[]{String.class, int.class, int.class, Map.class},
                    "/dest", 20, 256, new HashMap<String, Long>());

            mockedSftpUtil.verify(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"), times(1));
            mockedSftpUtil.verify(() -> SftpUtil.closeSFTPChannel(channelSftp, session, channel), times(1));
        }
    }

    @Test
    public void testSplitJsonFileLargeInputCreatesChunkFiles() throws Exception {
        Path tempFile = Files.createTempFile("monthly-large-", ".json");
        String baseName = tempFile.getFileName().toString().replace(".json", "");
        List<Path> createdChunks = new ArrayList<>();

        // Build a large JSON-like payload (>10,000,000 chars) to trigger chunking branch.
        try (BufferedWriter writer = Files.newBufferedWriter(tempFile, StandardCharsets.UTF_8)) {
            writer.write("[");
            int charCount = 1;
            int i = 0;
            while (charCount < 10_100_000) {
                String obj = (i == 0 ? "{\"a\":1}" : ",{\"a\":1}");
                writer.write(obj);
                charCount += obj.length();
                i++;
            }
            writer.write("]");
        }

        Method method = SchedulerMonthly.class.getDeclaredMethod("splitJsonFile", String.class, int.class, int.class, String.class);
        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        List<Path> result = (List<Path>) method.invoke(null, tempFile.toString(), 1, 256, tempFile.getParent().toString());

        assertNotNull(result);
        assertFalse(result.isEmpty());
        createdChunks.addAll(result);
        for (Path chunk : createdChunks) {
            assertTrue(chunk.getFileName().toString().startsWith(baseName + "_chunk"));
            assertTrue(chunk.getFileName().toString().endsWith(".json"));
        }

        Files.deleteIfExists(tempFile);
        for (Path chunk : createdChunks) {
            Files.deleteIfExists(chunk);
        }
    }

    @Test
    public void testSplitFilesHandlesIOExceptionFromCredentialLookup() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/dest"))
                    .thenThrow(new java.io.IOException("credential-failure"));

            invokePrivateStatic("splitFiles",
                    new Class<?>[]{String.class, int.class, int.class, Map.class},
                    "/dest", 20, 256, new HashMap<String, Long>());

            mockedSftpUtil.verify(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/dest"), times(1));
            mockedSftpUtil.verify(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"), never());
        }
    }

    @Test
    public void testProcessFilesInnerCatchHandlesExtractCsvSftpFailure() throws Exception {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";

        ChannelSftp.LsEntry jsonEntry = mock(ChannelSftp.LsEntry.class);
        when(jsonEntry.getFilename()).thenReturn("f.json");
        ArrayList<ChannelSftp.LsEntry> listing = new ArrayList<>();
        listing.add(jsonEntry);

        ChannelSftp channelSftp = mock(ChannelSftp.class);
        Session session = mock(Session.class);
        Channel channel = mock(Channel.class);

        Map<String, Object> outerSftpResult = new HashMap<>();
        outerSftpResult.put("directoryListing", listing);
        outerSftpResult.put("channelSftp", channelSftp);
        outerSftpResult.put("sftpSession", session);
        outerSftpResult.put("channel", channel);

        try (MockedStatic<SftpUtil> mockedSftpUtil = mockStatic(SftpUtil.class)) {
            mockedSftpUtil.when(() -> SftpUtil.exceptionForMissingLoginCredential("host", "user", "pass", "/dest"))
                    .thenReturn(false);
            mockedSftpUtil.when(() -> SftpUtil.sftpDirectory("user", "pass", "host", "/dest"))
                    .thenReturn(outerSftpResult)
                    .thenThrow(new SftpException(4, "extract-failure"));

            invokePrivateStatic("processFiles",
                    new Class<?>[]{String.class, String.class, String.class, String.class, String.class},
                    "/dest", "/fixedWork", "/fixedDest", "/from", "/to");

            mockedSftpUtil.verify(() -> SftpUtil.closeSFTPChannel(channelSftp, session, channel), times(1));
        }
    }

    private Object invokePrivateStatic(String methodName, Class<?>[] types, Object... args) throws Exception {
        Method method = SchedulerMonthly.class.getDeclaredMethod(methodName, types);
        method.setAccessible(true);
        try {
            return method.invoke(null, args);
        } catch (InvocationTargetException e) {
            throw e;
        }
    }
}

