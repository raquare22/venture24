package com.optum.providerpreferences.autoenrollment;

import com.optum.providerpreferences.autoenrollment.config.SchedulerConfig;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockedStatic;

import java.lang.reflect.Constructor;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicReference;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;

public class EmailUtilsTest {

    @Before
    public void setUpSchedulerConfig() {
        SchedulerConfig.PRUN_EMAIL_HOST = "localhost";
        SchedulerConfig.prunEmailFrom = "from@example.com";
        SchedulerConfig.prunEmailTo = "to@example.com";
        SchedulerConfig.prunEmailSubject = "Subject [dateTime]";
        SchedulerConfig.prunEmailMessage = "Body [dateTime] [Tin]";
        SchedulerConfig.prunEmailToPODM = "podm@example.com";
    }

    @Test
    public void testPrivateConstructorIsAccessibleViaReflection() throws Exception {
        Constructor<EmailUtils> constructor = EmailUtils.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        constructor.newInstance();
    }

    @Test
    public void testSendEmailMultiAttachmentsThrowsOnInvalidSender() {
        try {
            EmailUtils.sendEmailMultiAttachments(null, "to@example.com", "subject", "body", null);
            fail("Expected an exception to be thrown");
        } catch (Exception expected) {
            // expected path
        }
    }

    @Test
    public void testSendEmailSingleAttachmentDoesNotPropagateErrors() {
        try {
            EmailUtils.sendEmailSingleAttachment(null, "to@example.com", "subject", "body", "non-existent-file.txt");
        } catch (Exception ex) {
            fail("sendEmailSingleAttachment should swallow exceptions, but threw: " + ex.getClass().getName());
        }
    }

    @Test
    public void testSendEmailMultipleFilesDoesNotPropagateErrors() {
        try {
            EmailUtils.sendEmail(new String[] {"missing-a.txt", "missing-b.txt"});
        } catch (Exception ex) {
            fail("sendEmail(String[]) should swallow exceptions, but threw: " + ex.getClass().getName());
        }
    }

    @Test
    public void testSendEmailSingleFileWithDateTimeDoesNotPropagateErrors() {
        try {
            EmailUtils.sendEmail("missing.txt", "2026-05-19T10:30:00");
        } catch (Exception ex) {
            fail("sendEmail(String, String) should swallow exceptions, but threw: " + ex.getClass().getName());
        }
    }

    @Test
    public void testSendEmailWithoutAttachmentDoesNotPropagateErrors() {
        try {
            EmailUtils.sendEmailWithoutAttachment(
                    "123456789",
                    "2026-05-19T10:30:00",
                    "Subject [dateTime] [Tin]",
                    "Body [dateTime] [Tin]"
            );
        } catch (Exception ex) {
            fail("sendEmailWithoutAttachment should swallow exceptions, but threw: " + ex.getClass().getName());
        }
    }

    @Test
    public void testSendEmailMultiAttachmentsSendsMessageWhenInputsAreValid() throws Exception {
        AtomicReference<Message> sentMessage = new AtomicReference<>();

        try (MockedStatic<Transport> transportMock = mockStatic(Transport.class)) {
            transportMock.when(() -> Transport.send(any(Message.class))).thenAnswer(invocation -> {
                sentMessage.set(invocation.getArgument(0));
                return null;
            });

            EmailUtils.sendEmailMultiAttachments("from@example.com", "to@example.com", "subject", "body", null);

            transportMock.verify(() -> Transport.send(any(Message.class)), times(1));
            assertNotNull(sentMessage.get());
            MimeMessage mimeMessage = (MimeMessage) sentMessage.get();
            assertEquals("subject", mimeMessage.getSubject());
            assertEquals("from@example.com", mimeMessage.getFrom()[0].toString());
            assertEquals("to@example.com", mimeMessage.getRecipients(Message.RecipientType.TO)[0].toString());
            assertTrue(mimeMessage.getContent() instanceof Multipart);
            Multipart multipart = (Multipart) mimeMessage.getContent();
            assertEquals(1, multipart.getCount());
        }
    }

    @Test
    public void testSendEmailMultiAttachmentsAddsMultipleAttachments() throws Exception {
        Path fileOne = Files.createTempFile("email-utils-one", ".txt");
        Path fileTwo = Files.createTempFile("email-utils-two", ".txt");
        Files.write(fileOne, "one".getBytes(StandardCharsets.UTF_8));
        Files.write(fileTwo, "two".getBytes(StandardCharsets.UTF_8));
        AtomicReference<Message> sentMessage = new AtomicReference<>();

        try (MockedStatic<Transport> transportMock = mockStatic(Transport.class)) {
            transportMock.when(() -> Transport.send(any(Message.class))).thenAnswer(invocation -> {
                sentMessage.set(invocation.getArgument(0));
                return null;
            });

            EmailUtils.sendEmailMultiAttachments(
                    "from@example.com",
                    "to@example.com",
                    "subject",
                    "body",
                    new String[] {fileOne.toString(), fileTwo.toString()}
            );

            Multipart multipart = (Multipart) ((MimeMessage) sentMessage.get()).getContent();
            assertEquals(3, multipart.getCount());
        } finally {
            Files.deleteIfExists(fileOne);
            Files.deleteIfExists(fileTwo);
        }
    }

    @Test
    public void testSendEmailSingleAttachmentSendsMessageWithAttachment() throws Exception {
        Path file = Files.createTempFile("email-utils-single", ".txt");
        Files.write(file, "single".getBytes(StandardCharsets.UTF_8));
        AtomicReference<Message> sentMessage = new AtomicReference<>();

        try (MockedStatic<Transport> transportMock = mockStatic(Transport.class)) {
            transportMock.when(() -> Transport.send(any(Message.class))).thenAnswer(invocation -> {
                sentMessage.set(invocation.getArgument(0));
                return null;
            });

            EmailUtils.sendEmailSingleAttachment("from@example.com", "to@example.com", "subject", "body", file.toString());

            transportMock.verify(() -> Transport.send(any(Message.class)), times(1));
            Multipart multipart = (Multipart) ((MimeMessage) sentMessage.get()).getContent();
            assertEquals(2, multipart.getCount());
        } finally {
            Files.deleteIfExists(file);
        }
    }

    @Test
    public void testSendEmailMultipleFilesSendsConfiguredMessage() throws Exception {
        AtomicReference<Message> sentMessage = new AtomicReference<>();

        try (MockedStatic<Transport> transportMock = mockStatic(Transport.class)) {
            transportMock.when(() -> Transport.send(any(Message.class))).thenAnswer(invocation -> {
                sentMessage.set(invocation.getArgument(0));
                return null;
            });

            EmailUtils.sendEmail((String[]) null);

            transportMock.verify(() -> Transport.send(any(Message.class)), times(1));
            MimeMessage mimeMessage = (MimeMessage) sentMessage.get();
            assertEquals(SchedulerConfig.prunEmailSubject, mimeMessage.getSubject());
            assertEquals(SchedulerConfig.prunEmailTo, mimeMessage.getRecipients(Message.RecipientType.TO)[0].toString());
            Multipart multipart = (Multipart) mimeMessage.getContent();
            assertEquals(1, multipart.getCount());
        }
    }

    @Test
    public void testSendEmailSingleFileReplacesDateTimeInSubjectAndBody() throws Exception {
        AtomicReference<Message> sentMessage = new AtomicReference<>();

        try (MockedStatic<Transport> transportMock = mockStatic(Transport.class)) {
            transportMock.when(() -> Transport.send(any(Message.class))).thenAnswer(invocation -> {
                sentMessage.set(invocation.getArgument(0));
                return null;
            });

            EmailUtils.sendEmail(null, "2026-05-27T10:15:00");

            transportMock.verify(() -> Transport.send(any(Message.class)), times(1));
            MimeMessage mimeMessage = (MimeMessage) sentMessage.get();
            assertEquals("Subject 2026-05-27T10:15:00", mimeMessage.getSubject());
            Multipart multipart = (Multipart) mimeMessage.getContent();
            assertEquals(1, multipart.getCount());
            String body = (String) multipart.getBodyPart(0).getContent();
            assertTrue(body.contains("2026-05-27T10:15:00"));
        }
    }

    @Test
    public void testSendEmailWithoutAttachmentReplacesDateTimeAndTin() throws Exception {
        AtomicReference<Message> sentMessage = new AtomicReference<>();

        try (MockedStatic<Transport> transportMock = mockStatic(Transport.class)) {
            transportMock.when(() -> Transport.send(any(Message.class))).thenAnswer(invocation -> {
                sentMessage.set(invocation.getArgument(0));
                return null;
            });

            EmailUtils.sendEmailWithoutAttachment(
                    "123456789",
                    "2026-05-27T10:30:00",
                    "Subject [dateTime] [Tin]",
                    "Body [dateTime] [Tin]"
            );

            transportMock.verify(() -> Transport.send(any(Message.class)), times(1));
            MimeMessage mimeMessage = (MimeMessage) sentMessage.get();
            assertEquals("Subject 2026-05-27T10:30:00 123456789", mimeMessage.getSubject());
            assertEquals(SchedulerConfig.prunEmailToPODM, mimeMessage.getRecipients(Message.RecipientType.TO)[0].toString());
            Multipart multipart = (Multipart) mimeMessage.getContent();
            String body = (String) multipart.getBodyPart(0).getContent();
            assertTrue(body.contains("2026-05-27T10:30:00"));
            assertTrue(body.contains("123456789"));
        }
    }
}

