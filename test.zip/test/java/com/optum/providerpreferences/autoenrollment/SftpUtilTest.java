package com.optum.providerpreferences.autoenrollment;

import com.optum.digitalsecurity.model.request.User;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.PESCorpMpinHandler;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObj;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.service.AutoenrollmentServiceImpl;
import com.optum.providerpreferences.rs.service.DigitalSecurityServiceImpl;
import com.optum.providerpreferences.rs.service.ProviderPreferenceServiceImpl;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.MockedStatic;
import org.mockito.ArgumentCaptor;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class SftpUtilTest {

    private static final String TEST_TEMP_DIR = System.getProperty("java.io.tmpdir") + "/sftputil_test";

    @Before
    public void setUp() throws Exception {
        Files.createDirectories(Paths.get(TEST_TEMP_DIR));
        com.optum.providerpreferences.autoenrollment.config.SchedulerConfig.prunPort = "22";
        com.optum.providerpreferences.autoenrollment.config.SchedulerConfig.THREAD_COUNT_HEALTHCHECK = "100";
        com.optum.providerpreferences.autoenrollment.config.SchedulerConfig.THREADS_DIGISEC_GET = "2";
        com.optum.providerpreferences.autoenrollment.config.SchedulerConfig.THREADS_FDSCLOUD_GET = "2";
        com.optum.providerpreferences.autoenrollment.config.SchedulerConfig.THREADS_PES_GET = "2";
    }

    // ========== exceptionForMissingLoginCredential ==========

    @Test
    public void testExceptionForMissingLoginCredential_MissingCombinations() {
        String[][] missing = {
            {null, "user", "pass", "/dir"},
            {"host", null, "pass", "/dir"},
            {"host", "user", null, "/dir"},
            {"host", "user", "pass", null},
            {null, null, null, null},
            {"", "user", "pass", "/dir"},
            {"host", "", "pass", "/dir"},
        };
        for (String[] c : missing) {
            try {
                SftpUtil.exceptionForMissingLoginCredential(c[0], c[1], c[2], c[3]);
                fail("Expected IOException for: " + Arrays.toString(c));
            } catch (IOException e) {
                assertTrue(e.getMessage().contains("Missing"));
            }
        }
    }

    @Test
    public void testExceptionForMissingLoginCredential_ValidCredentials() throws IOException {
        assertFalse(SftpUtil.exceptionForMissingLoginCredential("host.com", "user", "pass", "/dir"));
    }

    // ========== isMissingLoginCredential ==========

    @Test
    public void testIsMissingLoginCredential_AllCases() {
        assertFalse(SftpUtil.isMissingLoginCredential("host", "user", "pass", "/dir"));
        assertTrue(SftpUtil.isMissingLoginCredential(null, "user", "pass", "/dir"));
        assertTrue(SftpUtil.isMissingLoginCredential("host", null, "pass", "/dir"));
        assertTrue(SftpUtil.isMissingLoginCredential("host", "user", null, "/dir"));
        assertTrue(SftpUtil.isMissingLoginCredential("host", "user", "pass", null));
        assertTrue(SftpUtil.isMissingLoginCredential("", "user", "pass", "/dir"));
        assertTrue(SftpUtil.isMissingLoginCredential("host", "", "pass", "/dir"));
        assertTrue(SftpUtil.isMissingLoginCredential("host", "user", "", "/dir"));
        assertTrue(SftpUtil.isMissingLoginCredential("host", "user", "pass", ""));
    }

    // ========== createDateintoString ==========

    @Test
    public void testCreateDateintoString_ValidFormat() {
        String result = SftpUtil.createDateintoString();
        assertNotNull(result);
        assertTrue("Should be 8-digit yyyyMMdd format", result.matches("\\d{8}"));
        assertEquals(new SimpleDateFormat("yyyyMMdd").format(new Date()), result);
    }

    // ========== checkFileExistsOrNot ==========

    @Test
    public void testCheckFileExistsOrNot_DeletesExistingAndIgnoresNonExistent() throws Exception {
        Path testFile = Paths.get(TEST_TEMP_DIR, "cfe_" + System.currentTimeMillis() + ".txt");
        Files.write(testFile, "data".getBytes());

        Method method = SftpUtil.class.getDeclaredMethod("checkFileExistsOrNot", String.class, String.class);
        method.setAccessible(true);

        // Deletes existing file
        method.invoke(null, testFile.getFileName().toString(), TEST_TEMP_DIR);
        assertFalse("File should have been deleted", Files.exists(testFile));

        // Non-existent file — should not throw
        method.invoke(null, "nonexistent_" + System.currentTimeMillis() + ".txt", TEST_TEMP_DIR);
    }

    // ========== deleteFile ==========

    @Test
    public void testDeleteFile_ExistingAndNonExisting() throws IOException {
        Path file = Paths.get(TEST_TEMP_DIR, "del_" + System.currentTimeMillis() + ".txt");
        Files.write(file, "x".getBytes());
        assertTrue(SftpUtil.deleteFile(file));
        assertFalse(Files.exists(file));

        assertFalse(SftpUtil.deleteFile(Paths.get(TEST_TEMP_DIR, "ghost_" + System.currentTimeMillis() + ".txt")));
    }

    // ========== backoutSplit ==========

    @Test
    public void testBackoutSplit_DuringBusinessHoursReturnsEmpty() {
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertTrue(SftpUtil.backoutSplit(new ArrayList<>()).isEmpty());
        }
    }

    @Test
    public void testBackoutSplit_DeletesSplitFilesAndReturnsEmpty() throws IOException {
        List<Path> splitFiles = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            Path p = Paths.get(TEST_TEMP_DIR, "split_" + i + "_" + System.currentTimeMillis() + ".csv");
            Files.write(p, ("d" + i).getBytes());
            splitFiles.add(p);
        }
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            assertTrue(SftpUtil.backoutSplit(splitFiles).isEmpty());
        }
        for (Path p : splitFiles) assertFalse(Files.exists(p));
    }

    // ========== getFilesToSplit ==========

    @Test
    public void testGetFilesToSplit_BusinessHoursReturnsEmpty() {
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertTrue(SftpUtil.getFilesToSplit(5, Collections.singletonMap("big.csv", 20L * 1024 * 1024)).isEmpty());
        }
    }

    @Test
    public void testGetFilesToSplit_FiltersAndIgnoresNull() {
        Map<String, Long> input = new HashMap<>();
        input.put("big.csv", 10L * 1024 * 1024);
        input.put("small.csv", 100L);
        input.put("null.csv", null);
        input.put("exact.csv", 5L * 1024 * 1024);
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            Map<String, Long> result = SftpUtil.getFilesToSplit(5, input);
            assertTrue(result.containsKey("big.csv"));
            assertTrue(result.containsKey("exact.csv"));
            assertFalse(result.containsKey("small.csv"));
            assertFalse(result.containsKey("null.csv"));
        }
    }

    @Test
    public void testGetFilesToSplit_EmptyMap() {
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            assertTrue(SftpUtil.getFilesToSplit(5, new HashMap<>()).isEmpty());
        }
    }

    // ========== retryWaitHelper ==========

    @Test
    public void testRetryWaitHelper_ZeroSecondsAndInterrupted() throws Exception {
        SftpUtil.retryWaitHelper("/archive", "file.csv", 0);

        final boolean[] flag = {false};
        Thread t = new Thread(() -> {
            Thread.currentThread().interrupt();
            SftpUtil.retryWaitHelper("dir", "f.csv", 1);
            flag[0] = Thread.currentThread().isInterrupted();
        });
        t.start();
        t.join();
        assertTrue("Thread should remain interrupted", flag[0]);
    }

    // ========== validateEmail ==========

    @Test
    public void testValidateEmail_AllBranches() {
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            assertTrue(SftpUtil.validateEmail("valid@example.com"));
            assertFalse(SftpUtil.validateEmail("not-an-email"));

            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertFalse(SftpUtil.validateEmail("valid@example.com"));
        }
    }

    // ========== headerValidation ==========

    @Test
    public void testHeaderValidation_BusinessHoursSkips_NonBusinessAdds() {
        clearHeaders();
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            SftpUtil.headerValidation();
            assertTrue(getHeaders().isEmpty());

            clearHeaders();
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            SftpUtil.headerValidation();
            List<String> h = getHeaders();
            assertTrue(h.contains("MPIN") && h.contains("TAX ID") && h.contains("LETTER TYPE") && h.contains("CORP MPIN"));
        }
    }

    @Test
    public void testHeaderValidationEmailCheck_AddsCorrectHeaders() {
        clearHeaders();
        SftpUtil.headerValidationEmailCheck();
        List<String> h = getHeaders();
        assertTrue(h.contains("MPIN") && h.contains("TAX ID") && h.contains("DOC ID"));
    }

    @Test
    public void testHeaderValidationMemberPaymentPreference_AddsCorrectHeaders() {
        clearHeaders();
        SftpUtil.headerValidationMemberPaymentPreference();
        List<String> h = getHeaders();
        assertTrue(h.contains("TAX ID") && h.contains("MPIN") && h.contains("ENROLLMENT")
            && h.contains("ACTIVE") && h.contains("ACCOUNT NUMBER"));
    }

    // ========== writeInCSVFile ==========

    @Test
    public void testWriteInCSVFile_CreatesFileAndHandlesEmpty() throws IOException {
        SftpUtil.writeInCSVFile(Arrays.asList("a,b", "c,d"), TEST_TEMP_DIR);
        File[] files = new File(TEST_TEMP_DIR).listFiles((d, n) -> n.endsWith("_PAAEmails.csv"));
        assertNotNull(files);
        assertTrue(files.length > 0);

        // Empty data should not throw
        SftpUtil.writeInCSVFile(new ArrayList<>(), TEST_TEMP_DIR);
    }

    // ========== splitFilePerMbPerNewLine ==========

    @Test
    public void testSplitFilePerMbPerNewLine_EarlyExitCases() throws IOException {
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertTrue(SftpUtil.splitFilePerMbPerNewLine("/f.csv", 5, 256, TEST_TEMP_DIR, false, ".csv").isEmpty());

            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            assertTrue(SftpUtil.splitFilePerMbPerNewLine("/f.csv", 0, 256, TEST_TEMP_DIR, false, ".csv").isEmpty());
            assertTrue(SftpUtil.splitFilePerMbPerNewLine("/nonexistent/f.csv", 5, 256, TEST_TEMP_DIR, false, ".csv").isEmpty());

            Path small = Paths.get(TEST_TEMP_DIR, "sm_" + System.currentTimeMillis() + ".csv");
            Files.write(small, "tiny\n".getBytes());
            assertTrue(SftpUtil.splitFilePerMbPerNewLine(small.toString(), 5, 256, TEST_TEMP_DIR, false, ".csv").isEmpty());
            Files.deleteIfExists(small);
        }
    }

    // ========== writePartToSplitFile ==========

    @Test
    public void testWritePartToSplitFile_BusinessHoursReturnsZero() throws Exception {
        Path src = Paths.get(TEST_TEMP_DIR, "ws_" + System.currentTimeMillis() + ".csv");
        Files.write(src, "abcdefg".getBytes(StandardCharsets.UTF_8));
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             RandomAccessFile raf = new RandomAccessFile(src.toFile(), "r")) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertEquals(0L, SftpUtil.writePartToSplitFile(src.toString(), 1, 0, 4, 256, raf.getChannel(), new ArrayList<>(), TEST_TEMP_DIR, false, ".part"));
        }
        Files.deleteIfExists(src);
    }

    @Test
    public void testWritePartToSplitFile_WritesBytes() throws Exception {
        Path src = Paths.get(TEST_TEMP_DIR, "wr_" + System.currentTimeMillis() + ".csv");
        Files.write(src, "abcdefg".getBytes(StandardCharsets.UTF_8));
        List<Path> splitFiles = new ArrayList<>();
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             RandomAccessFile raf = new RandomAccessFile(src.toFile(), "r")) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            long written = SftpUtil.writePartToSplitFile(src.toString(), 1, 0, 4, 256, raf.getChannel(), splitFiles, TEST_TEMP_DIR, true, ".part");
            assertEquals(4L, written);
            assertEquals(1, splitFiles.size());
            assertTrue(Files.exists(splitFiles.get(0)));
        }
        for (Path p : splitFiles) Files.deleteIfExists(p);
        Files.deleteIfExists(src);
    }

    // ========== rename / retryRename / retryRemove ==========

    @Test
    public void testRename_NormalSuccess() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        when(ch.stat("/t/f.csv")).thenReturn(mock(SftpATTRS.class));
        assertTrue(SftpUtil.rename(ch, "/w/f.csv", "/t/f.csv", false));
        verify(ch).rename("/w/f.csv", "/t/f.csv");
        verify(ch, never()).rm(anyString());
    }

    @Test
    public void testRename_NoSuchFileTriggersRetryRename() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        doThrow(new SftpException(ChannelSftp.SSH_FX_NO_SUCH_FILE, "missing"))
            .doNothing().when(ch).rename("/w/f.csv", "/t/f.csv");
        when(ch.stat("/t/f.csv")).thenReturn(mock(SftpATTRS.class));
        assertTrue(SftpUtil.rename(ch, "/w/f.csv", "/t/f.csv", false));
        verify(ch, atLeast(2)).rename("/w/f.csv", "/t/f.csv");
    }

    @Test
    public void testRename_ForceDeleteSuccess() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        when(ch.stat("/t/f.csv")).thenReturn(mock(SftpATTRS.class));
        assertTrue(SftpUtil.rename(ch, "/w/f.csv", "/t/f.csv", true));
        verify(ch).rm("/w/f.csv");
    }

    @Test
    public void testRename_ForceDeleteFallsBackToRetryRemove_NotFound() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        when(ch.stat("/t/f.csv")).thenReturn(mock(SftpATTRS.class));
        doThrow(new SftpException(ChannelSftp.SSH_FX_NO_SUCH_FILE, "gone")).when(ch).stat("/w/f.csv");
        doThrow(new SftpException(4, "rm fail")).when(ch).rm("/w/f.csv");
        assertTrue(SftpUtil.rename(ch, "/w/f.csv", "/t/f.csv", true));
    }

    @Test
    public void testRetryRename_ReturnsFalseAfterMax() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        doThrow(new SftpException(4, "fail")).when(ch).rename(anyString(), anyString());
        assertFalse(SftpUtil.retryRename(ch, "/w.csv", "/t.csv"));
        verify(ch, times(5)).rename("/w.csv", "/t.csv");
    }

    @Test
    public void testRetryRemove_TrueWhenGone_FalseAfterMax() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        doThrow(new SftpException(ChannelSftp.SSH_FX_NO_SUCH_FILE, "gone")).when(ch).stat("/gone.csv");
        assertTrue(SftpUtil.retryRemove(ch, "/gone.csv"));

        ChannelSftp ch2 = mock(ChannelSftp.class);
        when(ch2.stat("/stuck.csv")).thenReturn(mock(SftpATTRS.class));
        doThrow(new SftpException(4, "fail")).when(ch2).rm("/stuck.csv");
        assertFalse(SftpUtil.retryRemove(ch2, "/stuck.csv"));
        verify(ch2, times(5)).rm("/stuck.csv");
    }

    // ========== removeFileFromServer / removeFileInSFTPLocation ==========

    @Test
    public void testRemoveFileFromServer() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        SftpUtil.removeFileFromServer(Collections.singletonMap("channelSftp", ch), "/dest", "x.csv");
        verify(ch).rm("/dest" + File.separator + "x.csv");
    }

    @Test
    public void testRemoveFileInSFTPLocation_WithSeparateArgs() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        ReflectionTestUtils.invokeMethod(SftpUtil.class, "removeFileInSFTPLocation", ch, "/root", "a.csv");
        verify(ch).rm("/root" + File.separator + "a.csv");
    }

    // ========== movefileFromlocalToServer ==========

    @Test
    public void testMovefileFromlocalToServer() throws Exception {
        Path local = Paths.get(TEST_TEMP_DIR, "up_" + System.currentTimeMillis() + ".csv");
        Files.write(local, "a,b".getBytes(StandardCharsets.UTF_8));
        ChannelSftp ch = mock(ChannelSftp.class);
        SftpUtil.movefileFromlocalToServer(local.toString(), Collections.singletonMap("channelSftp", ch), "/dest");
        verify(ch).cd("/dest" + File.separator);
        verify(ch).put(any(FileInputStream.class), eq(local.getFileName().toString()));
        Files.deleteIfExists(local);
    }

    // ========== readFileFromServer ==========

    @Test
    public void testReadFileFromServer_VoidDelegatesToStringOverload() throws Exception {
        Map<String, Object> sftpResult = new HashMap<>();
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.readFileFromServer("/dest", sftpResult, "/work", false, "")).thenReturn("");
            SftpUtil.readFileFromServer("/dest", sftpResult, "/work");
            util.verify(() -> SftpUtil.readFileFromServer("/dest", sftpResult, "/work", false, ""));
        }
    }

    @Test
    public void testReadFileFromServer_NoMatch_ReturnsEmpty() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
        when(entry.getFilename()).thenReturn("other.csv");
        Map<String, Object> sftpResult = new HashMap<>();
        sftpResult.put("channelSftp", ch);
        sftpResult.put("directoryListing", new ArrayList<>(Collections.singletonList(entry)));
        assertEquals("", SftpUtil.readFileFromServer("/to", sftpResult, "/from", false, "target.csv"));
    }

    @Test
    public void testReadFileFromServer_RenameSucceeds_ReturnsEmpty() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
        when(entry.getFilename()).thenReturn("x.csv");
        Map<String, Object> sftpResult = new HashMap<>();
        sftpResult.put("channelSftp", ch);
        sftpResult.put("directoryListing", new ArrayList<>(Collections.singletonList(entry)));
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.rename(ch, "/from" + File.separator + "x.csv", "/to" + File.separator + "x.csv", false)).thenReturn(true);
            assertEquals("", SftpUtil.readFileFromServer("/to", sftpResult, "/from", false, "x.csv"));
        }
    }

    @Test
    public void testReadFileFromServer_RenameFails_ReturnsOriginalPath() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
        when(entry.getFilename()).thenReturn("x.csv");
        Map<String, Object> sftpResult = new HashMap<>();
        sftpResult.put("channelSftp", ch);
        sftpResult.put("directoryListing", new ArrayList<>(Collections.singletonList(entry)));
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.rename(ch, "/from" + File.separator + "x.csv", "/to" + File.separator + "x.csv", true)).thenReturn(false);
            assertEquals("/from" + File.separator + "x.csv", SftpUtil.readFileFromServer("/to", sftpResult, "/from", true, "x.csv"));
        }
    }

    // ========== readFileFromServerCheckSize ==========

    @Test
    public void testReadFileFromServerCheckSize_CsvOnly() throws Exception {
        ChannelSftp sftp = mock(ChannelSftp.class);
        ChannelSftp.LsEntry csv = mock(ChannelSftp.LsEntry.class);
        ChannelSftp.LsEntry txt = mock(ChannelSftp.LsEntry.class);
        SftpATTRS attrs = mock(SftpATTRS.class);
        when(csv.getFilename()).thenReturn("a.csv");
        when(csv.getAttrs()).thenReturn(attrs);
        when(attrs.getSize()).thenReturn(1024L);
        when(txt.getFilename()).thenReturn("b.txt");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("channelSftp", sftp);
        sftpMap.put("directoryListing", new ArrayList<>(Arrays.asList(csv, txt)));

        Map<String, Long> result = SftpUtil.readFileFromServerCheckSize("/dest", sftpMap, "/work", ".csv", "");

        assertEquals(1, result.size());
        assertEquals(Long.valueOf(1024L), result.get("a.csv"));
        verify(sftp).rename(eq("/work" + File.separator + "a.csv"), eq("/dest" + File.separator + "a.csv"));
        verify(sftp, never()).rename(eq("/work" + File.separator + "b.txt"), anyString());
    }

    // ========== sftpDirectory ==========

    @Test
    public void testSftpDirectory_BusinessHoursReturnsEmpty() throws Exception {
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertTrue(SftpUtil.sftpDirectory("u", "p", "h", "/d").isEmpty());
        }
    }

    @Test
    public void testSftpDirectory_PopulatesResultMap() throws Exception {
        Session session = mock(Session.class);
        ChannelSftp sftp = mock(ChannelSftp.class);
        Vector<ChannelSftp.LsEntry> vec = new Vector<>(Collections.singletonList(mock(ChannelSftp.LsEntry.class)));

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            util.when(() -> SftpUtil.createSession("u", "p", "h", 22)).thenReturn(session);
            util.when(() -> SftpUtil.createSFTPChannel(session)).thenReturn(sftp);
            when(sftp.pwd()).thenReturn("/work");
            when(sftp.ls("/work")).thenReturn(vec);

            Map<String, Object> result = SftpUtil.sftpDirectory("u", "p", "h", "/work");
            assertEquals(sftp, result.get("channelSftp"));
            assertEquals(session, result.get("sftpSession"));
            assertEquals(1, ((List<?>) result.get("directoryListing")).size());
            verify(sftp).cd("/work");
        }
    }

    // ========== createSFTPChannel / closeSFTPChannel ==========

    @Test
    public void testCreateSFTPChannel_ConnectFailure_StillReturnsChannel() throws Exception {
        Session session = mock(Session.class);
        Channel ch = mock(Channel.class);
        when(session.openChannel("sftp")).thenReturn(ch);
        doThrow(new JSchException("fail")).when(ch).connect();
        assertSame(ch, SftpUtil.createSFTPChannel(session));
    }

    @Test
    public void testCloseSFTPChannel_Connected_DisconnectsAll() throws Exception {
        ChannelSftp chSftp = mock(ChannelSftp.class);
        Session session = mock(Session.class);
        Channel ch = mock(Channel.class);
        when(chSftp.isConnected()).thenReturn(true);
        when(chSftp.getSession()).thenReturn(session);
        SftpUtil.closeSFTPChannel(chSftp, null, ch);
        verify(ch).disconnect();
        verify(chSftp).disconnect();
        verify(chSftp).quit();
        verify(session).disconnect();
    }

    @Test
    public void testCloseSFTPChannel_NotConnected_DoesNothing() {
        ChannelSftp chSftp = mock(ChannelSftp.class);
        when(chSftp.isConnected()).thenReturn(false);
        SftpUtil.closeSFTPChannel(chSftp, null, mock(Channel.class));
        verify(chSftp, never()).disconnect();
    }

    // ========== sftpFileHelper ==========

    @Test
    public void testSftpFileHelper_ReturnsChannel() throws Exception {
        Session session = mock(Session.class);
        ChannelSftp ch = mock(ChannelSftp.class);
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.createSession("u", "p", "h", 22)).thenReturn(session);
            util.when(() -> SftpUtil.createSFTPChannel(session)).thenReturn(ch);
            assertSame(ch, SftpUtil.sftpFileHelper("u", "p", "h"));
        }
    }

    // ========== removeFileFromSFTPLocation ==========

    @Test
    public void testRemoveFileFromSFTPLocation_Success() throws Exception {
        Session session = mock(Session.class);
        ChannelSftp ch = mock(ChannelSftp.class);
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.createSession("u", "p", "h", 22)).thenReturn(session);
            util.when(() -> SftpUtil.createSFTPChannel(session)).thenReturn(ch);
            SftpUtil.removeFileFromSFTPLocation("u", "p", "h", 22, "/target", "f.csv");
            verify(ch).cd("/target");
            verify(ch).rm("/target" + File.separator + "f.csv");
            verify(session).disconnect();
        }
    }

    // ========== moveFileToLocation ==========

    @Test
    public void testMoveFileToLocation_FileExistsAndNotExists() throws Exception {
        Method m = SftpUtil.class.getDeclaredMethod("moveFileToLocation", ChannelSftp.class, String.class, String.class, String.class);
        m.setAccessible(true);

        // File exists → rename + chmod
        ChannelSftp ch = mock(ChannelSftp.class);
        when(ch.get("f.csv")).thenReturn(mock(InputStream.class));
        m.invoke(null, ch, "/from", "/to", "f.csv");
        verify(ch).rename("/from" + File.pathSeparator + "f.csv", "/to" + File.pathSeparator + "f.csv");

        // File does not exist → no rename
        ChannelSftp ch2 = mock(ChannelSftp.class);
        when(ch2.get("f.csv")).thenReturn(null);
        m.invoke(null, ch2, "/from", "/to", "f.csv");
        verify(ch2, never()).rename(anyString(), anyString());
    }

    // ========== parseBufferReader ==========

    @Test
    public void testParseBufferReader_AllBranches() throws Exception {
        Method m = SftpUtil.class.getDeclaredMethod("parseBufferReader", BufferedReader.class);
        m.setAccessible(true);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            // Business hours → empty
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertTrue(((List<?>) m.invoke(null, new BufferedReader(new StringReader("data")))).isEmpty());

            // Valid row with corp MPIN
            clearHeaders();
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            List<List<String>> r1 = (List<List<String>>) m.invoke(null,
                new BufferedReader(new StringReader("MPIN,TIN,LETTER\n123456789,987654321,E2,111111111\n")));
            assertEquals(1, r1.size());
            assertEquals("111111111", r1.get(0).get(3));

            // Missing corp MPIN falls back to provider MPIN
            clearHeaders();
            List<List<String>> r2 = (List<List<String>>) m.invoke(null,
                new BufferedReader(new StringReader("MPIN,TIN,LETTER\n123456789,987654321,E2\n")));
            assertEquals(1, r2.size());
            assertEquals("123456789", r2.get(0).get(3));
        }
    }

    // ========== parseBufferReaderEmailCheck ==========

    @Test
    public void testParseBufferReaderEmailCheck_AllBranches() throws Exception {
        Method m = SftpUtil.class.getDeclaredMethod("parseBufferReaderEmailCheck", BufferedReader.class);
        m.setAccessible(true);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertTrue(((List<?>) m.invoke(null, new BufferedReader(new StringReader("data")))).isEmpty());

            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            String content = "MPIN,TAX ID,LETTER TYPE,DOC ID\n123456789,987654321,E2,123e4567-e89b-12d3-a456-426614174000\n";
            List<List<String>> result = (List<List<String>>) m.invoke(null, new BufferedReader(new StringReader(content)));
            assertEquals(1, result.size());
            assertEquals(4, result.get(0).size());
        }
    }

    // ========== parseBufferReaderPaymentPreference ==========

    @Test
    public void testParseBufferReaderPaymentPreference_AllBranches() throws Exception {
        Method m = SftpUtil.class.getDeclaredMethod("parseBufferReaderPaymentPreference", BufferedReader.class);
        m.setAccessible(true);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertTrue(((List<?>) m.invoke(null, new BufferedReader(new StringReader("data")))).isEmpty());

            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            String content = "TAX ID,MPIN,ENROLLMENT,ACTIVE,ACCOUNT NUMBER\n123456789,987654321,YES,NO,1234\n";
            List<List<String>> result = (List<List<String>>) m.invoke(null, new BufferedReader(new StringReader(content)));
            assertEquals(1, result.size());
            assertEquals(Arrays.asList("123456789", "987654321", "YES", "NO", "1234"), result.get(0));
        }
    }

    // ========== validateBuffer variants ==========

    @Test
    public void testValidateBuffer_ValidAndInvalid() throws Exception {
        clearHeaders();
        Method m = SftpUtil.class.getDeclaredMethod("validateBuffer", String[].class, String.class);
        m.setAccessible(true);
        assertTrue((Boolean) m.invoke(null, new Object[]{new String[]{"123456789", "987654321", "E2", "111111111"}, ""}));
        assertFalse((Boolean) m.invoke(null, new Object[]{new String[]{"1", "2", "E", "3"}, ""}));
    }

    @Test
    public void testValidateBufferEmailCheck_ValidAndInvalid() throws Exception {
        clearHeaders();
        Method m = SftpUtil.class.getDeclaredMethod("validateBufferEmailCheck", String[].class, String.class);
        m.setAccessible(true);
        assertTrue((Boolean) m.invoke(null, new Object[]{new String[]{"123456789", "987654321", "E2", "123e4567-e89b-12d3-a456-426614174000"}, ""}));
        assertFalse((Boolean) m.invoke(null, new Object[]{new String[]{"123456789", "987654321", "E2", "short"}, ""}));
    }

    @Test
    public void testValidateBufferMemberPaymentPreference_ValidAndInvalid() throws Exception {
        clearHeaders();
        Method m = SftpUtil.class.getDeclaredMethod("validateBufferMemberPaymentPreference", String[].class, String.class);
        m.setAccessible(true);
        assertTrue((Boolean) m.invoke(null, new Object[]{new String[]{"123456789", "987654321", "ENROLL", "ACTIVE", "1234"}, ""}));
        assertFalse((Boolean) m.invoke(null, new Object[]{new String[]{"123456789", "987654321", "ENROLL", "ACTIVE", "12345"}, ""}));
    }

    // ========== retryLineFormat / parseRetryReader ==========

    @Test
    public void testRetryLineFormat_ParsesMapAndBusinessHours() throws Exception {
        Method m = SftpUtil.class.getDeclaredMethod("retryLineFormat", String.class);
        m.setAccessible(true);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertTrue(((Map<?, ?>) m.invoke(null, "x")).isEmpty());

            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            Map<String, Object> result = (Map<String, Object>) m.invoke(null, "ignored -> {mpin:123,tin:456,fileName:E2}}");
            assertEquals("123", result.get("mpin"));
            assertEquals("456", result.get("tin"));
            assertEquals("E2", result.get("fileName"));
        }
    }

    @Test
    public void testParseRetryReader_EmptyInputAndBusinessHours() throws Exception {
        Method m = SftpUtil.class.getDeclaredMethod("parseRetryReader", BufferedReader.class);
        m.setAccessible(true);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertTrue(((List<?>) m.invoke(null, new BufferedReader(new StringReader("data")))).isEmpty());

            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            List<List<String>> result = (List<List<String>>) ReflectionTestUtils.invokeMethod(
                SftpUtil.class, "parseRetryReader", new BufferedReader(new StringReader("")));
            assertNotNull(result);
        }
    }

    // ========== Executor shutdowns ==========

    @Test
    public void testServiceSendGetShutdown_AwaitsTermination() throws Exception {
        ExecutorService exec = mock(ExecutorService.class);
        when(exec.awaitTermination(anyLong(), eq(TimeUnit.MILLISECONDS))).thenReturn(true);
        ReflectionTestUtils.setField(SftpUtil.class, "sendGetExecutorService", exec);
        ReflectionTestUtils.invokeMethod(SftpUtil.class, "serviceSendGetShutdown");
        verify(exec).shutdown();
        verify(exec).awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
    }

    @Test
    public void testServicePESGetShutdown_AwaitsTermination() throws Exception {
        ExecutorService exec = mock(ExecutorService.class);
        when(exec.awaitTermination(anyLong(), eq(TimeUnit.MILLISECONDS))).thenReturn(true);
        ReflectionTestUtils.setField(SftpUtil.class, "EmailCheckExecutorService", exec);
        ReflectionTestUtils.invokeMethod(SftpUtil.class, "servicePESGetShutdown");
        verify(exec).shutdown();
        verify(exec).awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
    }

    @Test
    public void testServiceDigiSecGetShutdown_BusinessHoursSkipsAwait_NonBusinessAwaits() throws Exception {
        ExecutorService exec = mock(ExecutorService.class);
        when(exec.awaitTermination(anyLong(), eq(TimeUnit.MILLISECONDS))).thenReturn(true);
        ReflectionTestUtils.setField(SftpUtil.class, "digiSecGetExecutorService", exec);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            ReflectionTestUtils.invokeMethod(SftpUtil.class, "serviceDigiSecGetShutdown");
            verify(exec).shutdown();
            verify(exec, never()).awaitTermination(anyLong(), any(TimeUnit.class));

            reset(exec);
            when(exec.awaitTermination(anyLong(), eq(TimeUnit.MILLISECONDS))).thenReturn(true);
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            ReflectionTestUtils.invokeMethod(SftpUtil.class, "serviceDigiSecGetShutdown");
            verify(exec).shutdown();
            verify(exec).awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
        }
    }

    // ========== getEmailFromFdsCloudForCategory ==========

    @Test
    public void testGetEmailFromFdsCloud_AllBranches() throws Exception {
        FDSCloudHandler handler = mock(FDSCloudHandler.class);
        ReflectionTestUtils.setField(SftpUtil.class, "fdsCloudHandler", handler);

        FDSCloudRequest req = new FDSCloudRequest();
        when(handler.createSearchTermsRequestFromMap(anyMap())).thenReturn(req);

        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        FDSCloudGETResponse resp = new FDSCloudGETResponse();
        resp.setDocuments(Collections.singletonList(doc));
        when(handler.FDSCloudGetRequest("getLoadTestCloud", req)).thenReturn(resp);

        // Email delivery → returns email
        Map<String, Object> emailMap = new HashMap<>();
        emailMap.put("providerEmailId", "u@t.com");
        emailMap.put("deliveryMethod", "E");
        when(handler.getSearchTermsFromDocument(doc)).thenReturn(emailMap);
        assertEquals("u@t.com", SftpUtil.getEmailFromFdsCloudForCategory("123456789", "987654321", "P1"));

        // Non-email delivery → null
        emailMap.put("deliveryMethod", "P");
        when(handler.getSearchTermsFromDocument(doc)).thenReturn(emailMap);
        assertNull(SftpUtil.getEmailFromFdsCloudForCategory("123456789", "987654321", "P1"));

        // Exception → null
        when(handler.createSearchTermsRequestFromMap(anyMap())).thenThrow(new RuntimeException("fail"));
        assertNull(SftpUtil.getEmailFromFdsCloudForCategory("123456789", "987654321", "P1"));
    }

    // ========== Business-hours guard on read methods ==========

    @Test
    public void testReadMethods_BusinessHoursReturnEmpty() throws Exception {
        Map<String, Object> sftpResult = new HashMap<>();
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertTrue(SftpUtil.readFile("/d", TEST_TEMP_DIR, "f.csv", sftpResult).isEmpty());
            assertTrue(SftpUtil.readRetryData("/d", TEST_TEMP_DIR, "f.csv", sftpResult, false).isEmpty());
            assertTrue(SftpUtil.readFileStoreMemberPaymentData("/d", TEST_TEMP_DIR, "f.csv", sftpResult, false).isEmpty());
            assertTrue(SftpUtil.readFileSendAutoEnroCloud(Collections.singletonList("1,2,E2,3,e@t.com")).isEmpty());
            assertTrue(SftpUtil.checkAutoenrollmentSetup("u", "p", "h", "/d", "f.csv").isEmpty());
            assertTrue(SftpUtil.checkAutoenrollmentGET(new BufferedReader(new StringReader("")), mock(InputStream.class), 0).isEmpty());
        }
    }

    @Test
    public void testReadFileSendAutoEnroCloud_MissingEmailFieldUsesBlank() {
        AutoenrollmentServiceImpl service = mock(AutoenrollmentServiceImpl.class);
        ReflectionTestUtils.setField(SftpUtil.class, "autoenrollmentServiceImpl", service);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            List<String> expected = Collections.singletonList("ok");
            try {
                when(service.createAutoenrollmentDocumentsFDSCloud(any(AutoenrollmentRequest.class), any(HttpHeaders.class)))
                    .thenReturn(expected);
            } catch (ApplicationException e) {
                fail("Mock setup should not throw");
            }

            List<String> result = SftpUtil.readFileSendAutoEnroCloud(
                Collections.singletonList("123456789,987654321,E2,111111111"));

            assertEquals(expected, result);

            ArgumentCaptor<AutoenrollmentRequest> reqCaptor = ArgumentCaptor.forClass(AutoenrollmentRequest.class);
            try {
                verify(service).createAutoenrollmentDocumentsFDSCloud(reqCaptor.capture(), any(HttpHeaders.class));
            } catch (ApplicationException e) {
                fail("verify should not throw");
            }

            List<AutoenrollmentObj> docs = reqCaptor.getValue().getAutoenrollDocuments();
            assertEquals(1, docs.size());
            assertEquals("", docs.get(0).getProviderEmailId());
        }
    }

    // ========== createNewDirectoryAndMoveFiles ==========

    @Test
    public void testCreateNewDirectoryAndMoveFiles_SftpThrows_ReturnsFalse() {
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.sftpDirectory("u", "p", "h", "/fixed"))
                .thenThrow(new SftpException(4, "boom"));
            assertFalse(SftpUtil.createNewDirectoryAndMoveFiles(
                mock(org.apache.logging.log4j.Logger.class), "/fixed", "/fixedDest", "/fixed", "/to",
                "u", "p", "h", ".csv", "20", "256", 20, 256, "", null));
        }
    }

    @Test
    public void testCreateNewDirectoryAndMoveFiles_NonFixed_RenameSuccess_ReturnsTrue() throws Exception {
        Map<String, Object> sftpMap = buildSftpMap();
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.sftpDirectory("u", "p", "h", "/from")).thenReturn(sftpMap);
            util.when(() -> SftpUtil.readFileFromServer("/to", sftpMap, "/from", true, "a.csv")).thenReturn("");
            util.when(() -> SftpUtil.closeSFTPChannel(any(), any(), any())).thenAnswer(i -> null);
            assertTrue(SftpUtil.createNewDirectoryAndMoveFiles(
                mock(org.apache.logging.log4j.Logger.class), "/fixed", "/fixedDest", "/from", "/to",
                "u", "p", "h", ".csv", "20", "256", 20, 256, "a.csv", null));
        }
    }

    @Test
    public void testCreateNewDirectoryAndMoveFiles_NonFixed_RenameFailsTriggesRemove() throws Exception {
        Map<String, Object> sftpMap = buildSftpMap();
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.sftpDirectory("u", "p", "h", "/from")).thenReturn(sftpMap);
            util.when(() -> SftpUtil.readFileFromServer("/to", sftpMap, "/from", true, "a.csv")).thenReturn("dir/file.csv");
            util.when(() -> SftpUtil.removeFileFromSFTPLocation("u", "p", "h", 22, "dir", "file.csv")).thenAnswer(i -> null);
            util.when(() -> SftpUtil.closeSFTPChannel(any(), any(), any())).thenAnswer(i -> null);
            assertTrue(SftpUtil.createNewDirectoryAndMoveFiles(
                mock(org.apache.logging.log4j.Logger.class), "/fixed", "/fixedDest", "/from", "/to",
                "u", "p", "h", ".csv", "20", "256", 20, 256, "a.csv", null));
            util.verify(() -> SftpUtil.removeFileFromSFTPLocation("u", "p", "h", 22, "dir", "file.csv"), atLeastOnce());
        }
    }

    @Test
    public void testCreateNewDirectoryAndMoveFiles_Fixed_EmptyFiles_ReturnsFalse() throws Exception {
        Map<String, Object> sftpMap = buildSftpMap();
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.sftpDirectory("u", "p", "h", "/fixed")).thenReturn(sftpMap);
            util.when(() -> SftpUtil.readFileFromServerCheckSize("/to", sftpMap, "/fixed", ".csv", "")).thenReturn(Collections.emptyMap());
            util.when(() -> SftpUtil.closeSFTPChannel(any(), any(), any())).thenAnswer(i -> null);
            assertFalse(SftpUtil.createNewDirectoryAndMoveFiles(
                mock(org.apache.logging.log4j.Logger.class), "/fixed", "/fixedDest", "/fixed", "/to",
                "u", "p", "h", ".csv", "20", "256", 20, 256, "", null));
        }
    }

    @Test
    public void testCreateNewDirectoryAndMoveFiles_Fixed_WithSplitHandler() throws Exception {
        Map<String, Object> sftpMap = buildSftpMap();
        Map<String, Long> sizeMap = Collections.singletonMap("a.csv", 10L * 1024L * 1024L);
        AtomicBoolean splitCalled = new AtomicBoolean(false);

        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.sftpDirectory("u", "p", "h", "/fixed")).thenReturn(sftpMap);
            util.when(() -> SftpUtil.readFileFromServerCheckSize("/to", sftpMap, "/fixed", ".csv", "")).thenReturn(sizeMap);
            util.when(() -> SftpUtil.getFilesToSplit(20, sizeMap)).thenReturn(sizeMap);
            util.when(() -> SftpUtil.closeSFTPChannel(any(), any(), any())).thenAnswer(i -> null);

            assertTrue(SftpUtil.createNewDirectoryAndMoveFiles(
                mock(org.apache.logging.log4j.Logger.class), "/fixed", "/fixedDest", "/fixed", "/to",
                "u", "p", "h", ".csv", "20", "256", 20, 256, "",
                (dest, mb, max, map) -> splitCalled.set(true)));
            assertTrue(splitCalled.get());
        }
    }

    @Test
    public void testCreateNewDirectoryAndMoveFiles_NumberFormatException_UsesDefaults() throws Exception {
        Map<String, Object> sftpMap = buildSftpMap();
        Map<String, Long> sizeMap = Collections.singletonMap("a.csv", 6L * 1024L * 1024L);

        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.sftpDirectory("u", "p", "h", "/fixed")).thenReturn(sftpMap);
            util.when(() -> SftpUtil.readFileFromServerCheckSize("/to", sftpMap, "/fixed", ".csv", "")).thenReturn(sizeMap);
            util.when(() -> SftpUtil.getFilesToSplit(20, sizeMap)).thenReturn(Collections.emptyMap());
            util.when(() -> SftpUtil.closeSFTPChannel(any(), any(), any())).thenAnswer(i -> null);

            assertTrue(SftpUtil.createNewDirectoryAndMoveFiles(
                mock(org.apache.logging.log4j.Logger.class), "/fixed", "/fixedDest", "/fixed", "/to",
                "u", "p", "h", ".csv", "bad", "bad", 20, 256, "", null));
            util.verify(() -> SftpUtil.getFilesToSplit(20, sizeMap));
        }
    }

    // ========== jsonFileToCsv ==========

    @Test
    public void testJsonFileToCsv_CreatesCsvFile() throws Exception {
        String jsonName = "test_" + System.currentTimeMillis() + ".json";
        Path jsonPath = Paths.get(TEST_TEMP_DIR, jsonName);
        Files.write(jsonPath, "[{\"ST\":{\"tin\":\"123456789\",\"mpin\":\"987654321\",\"fileName\":\"E2\"},\"docId\":\"abc-123\"}]".getBytes(StandardCharsets.UTF_8));
        Map<String, Object> sftpResult = Collections.singletonMap("channelSftp", mock(ChannelSftp.class));

        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.sftpDirectory(anyString(), anyString(), anyString(), anyString())).thenReturn(sftpResult);
            util.when(() -> SftpUtil.movefileFromlocalToServer(anyString(), eq(sftpResult), anyString())).thenAnswer(i -> null);
            util.when(() -> SftpUtil.createNewDirectoryAndMoveFiles(any(), anyString(), anyString(), anyString(), anyString(),
                anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyInt(), anyInt(), anyString(), any()))
                .thenReturn(true);

            String csvPath = SftpUtil.jsonFileToCsv(TEST_TEMP_DIR, jsonName, "/fixed", "/fixedDest", "/from", "/to", jsonName);
            assertNotNull(csvPath);
            assertTrue(Files.exists(Paths.get(csvPath)));
        }
        Files.deleteIfExists(jsonPath);
    }

    // ========== Inner class Runnable tests ==========

    @Test
    public void testGetDigiSecEmailRequest_RunDuringBusinessHours() {
        SftpUtil.getDigiSecEmailRequest req = new SftpUtil.getDigiSecEmailRequest(
            Arrays.asList("123456789", "987654321", "E2", "111111111"));
        assertNotNull(req);
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            req.run(); // should return immediately without NPE
        }
    }

    @Test
    public void testSendFDSCloudGetRequest_RunDuringBusinessHours() {
        AutoenrollmentObj obj = new AutoenrollmentObj();
        SftpUtil.sendFDSCloudGetRequest req = new SftpUtil.sendFDSCloudGetRequest(obj);
        assertNotNull(req);
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            req.run();
        }
    }

    @Test
    public void testGetPESCorpMpinRequest_RunDuringBusinessHours() {
        SftpUtil.getPESCorpMpinRequest req = new SftpUtil.getPESCorpMpinRequest(
            Arrays.asList("123456789", "987654321", "E2", "111111111"));
        assertNotNull(req);
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            req.run();
        }
    }

    // ========== moveFileFromSFTPDirToArchive ==========

    @Test
    public void testMoveFileFromSFTPDirToArchive_SucceedsOnFirstTry() throws Exception {
        Session session = mock(Session.class);
        ChannelSftp ch = mock(ChannelSftp.class);
        when(ch.get("f.csv")).thenReturn(mock(InputStream.class));
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.createSession("u", "p", "h", 22)).thenReturn(session);
            util.when(() -> SftpUtil.createSFTPChannel(session)).thenReturn(ch);
            SftpUtil.moveFileFromSFTPDirToArchive("u", "p", "h", 22, "/from", "/archive", "f.csv", 1, 0);
            verify(ch).quit();
            verify(session).disconnect();
        }
    }

    @Test(expected = JSchException.class)
    public void testMoveFileFromSFTPDirToArchive_ThrowsAfterMaxTries_JSchException() throws Exception {
        Session session = mock(Session.class);
        ChannelSftp ch = mock(ChannelSftp.class);
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.createSession("u", "p", "h", 22)).thenThrow(new JSchException("fail"));
            SftpUtil.moveFileFromSFTPDirToArchive("u", "p", "h", 22, "/from", "/archive", "f.csv", 1, 0);
        }
    }

    @Test(expected = SftpException.class)
    public void testMoveFileFromSFTPDirToArchive_ThrowsAfterMaxTries_SftpException() throws Exception {
        Session session = mock(Session.class);
        ChannelSftp ch = mock(ChannelSftp.class);
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.createSession("u", "p", "h", 22)).thenReturn(session);
            util.when(() -> SftpUtil.createSFTPChannel(session)).thenReturn(ch);
            doThrow(new SftpException(4, "sftp fail")).when(ch).cd("/from");
            SftpUtil.moveFileFromSFTPDirToArchive("u", "p", "h", 22, "/from", "/archive", "f.csv", 1, 0);
        }
    }

    // ========== copyFileToArchive / validateDirectory ==========

    @Test
    public void testCopyFileToArchive_DirectoryExists() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        SftpATTRS attrs = mock(SftpATTRS.class);
        when(attrs.isDir()).thenReturn(true);
        when(ch.stat(anyString())).thenReturn(attrs);
        Map<String, Object> sftpResult = Collections.singletonMap("channelSftp", (Object) ch);
        Path localFile = Paths.get(TEST_TEMP_DIR, "arch_" + System.currentTimeMillis() + ".csv");
        Files.write(localFile, "data".getBytes());
        // Should not throw
        SftpUtil.copyFileToArchive("/work", "/dest", TEST_TEMP_DIR, localFile.getFileName().toString(), sftpResult);
        verify(ch, never()).mkdir(anyString());
        Files.deleteIfExists(localFile);
    }

    @Test
    public void testCopyFileToArchive_DirectoryDoesNotExist_CreatesMkdir() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        doThrow(new SftpException(ChannelSftp.SSH_FX_NO_SUCH_FILE, "not found")).when(ch).stat(anyString());
        Map<String, Object> sftpResult = Collections.singletonMap("channelSftp", (Object) ch);
        Path localFile = Paths.get(TEST_TEMP_DIR, "mkdir_" + System.currentTimeMillis() + ".csv");
        Files.write(localFile, "data".getBytes());
        SftpUtil.copyFileToArchive("/work", "/dest", TEST_TEMP_DIR, localFile.getFileName().toString(), sftpResult);
        verify(ch).mkdir(anyString());
        Files.deleteIfExists(localFile);
    }

    // ========== copyFileToLocal / copyFileToLocalNoDate ==========

    @Test
    public void testCopyFileToLocal_InvokesSftpGet() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        Map<String, Object> sftpResult = Collections.singletonMap("channelSftp", (Object) ch);
        SftpUtil.copyFileToLocal("/dest", TEST_TEMP_DIR, "f.csv", sftpResult);
        verify(ch).get("/dest" + File.separator + "f.csv", TEST_TEMP_DIR);
    }

    @Test
    public void testCopyFileToLocalNoDate_InvokesSftpGet() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        Map<String, Object> sftpResult = Collections.singletonMap("channelSftp", (Object) ch);
        SftpUtil.copyFileToLocalNoDate("/dest", TEST_TEMP_DIR, "f.csv", sftpResult);
        verify(ch).get("/dest" + File.separator + "f.csv", TEST_TEMP_DIR);
    }

    // ========== closeSFTPChannel – session already connected branch ==========

    @Test
    public void testCloseSFTPChannel_SessionNotNullAndConnected_UsesProvidedSession() throws Exception {
        ChannelSftp chSftp = mock(ChannelSftp.class);
        Session session = mock(Session.class);
        Channel ch = mock(Channel.class);
        when(chSftp.isConnected()).thenReturn(true);
        when(session.isConnected()).thenReturn(true);
        SftpUtil.closeSFTPChannel(chSftp, session, ch);
        verify(session).disconnect();
        verify(chSftp, never()).getSession();
    }

    // ========== removeFileFromSFTPLocation – exception branch ==========

    @Test
    public void testRemoveFileFromSFTPLocation_ExceptionLogged() throws Exception {
        try (MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            util.when(() -> SftpUtil.createSession(anyString(), anyString(), anyString(), anyInt()))
                .thenThrow(new JSchException("cannot connect"));
            // Should not throw – exception is caught and logged
            SftpUtil.removeFileFromSFTPLocation("u", "p", "h", 22, "/target", "f.csv");
        }
    }

    // ========== readFileFromServerCheckSize — empty listing ==========

    @Test
    public void testReadFileFromServerCheckSize_EmptyListing() throws Exception {
        ChannelSftp sftp = mock(ChannelSftp.class);
        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("channelSftp", sftp);
        sftpMap.put("directoryListing", new ArrayList<>());
        Map<String, Long> result = SftpUtil.readFileFromServerCheckSize("/dest", sftpMap, "/work", ".csv", "");
        assertTrue(result.isEmpty());
    }

    // ========== splitFilePerMbPerNewLine — happy path (actually splits) ==========

    @Test
    public void testSplitFilePerMbPerNewLine_ActuallySplits() throws Exception {
        // Create a file > 1 MB
        Path bigFile = Paths.get(TEST_TEMP_DIR, "big_" + System.currentTimeMillis() + ".csv");
        int oneMb = 1024 * 1024;
        byte[] row = "123456789,987654321,E2\n".getBytes(StandardCharsets.UTF_8);
        try (java.io.OutputStream os = Files.newOutputStream(bigFile)) {
            int written = 0;
            while (written < oneMb * 2 + 100) {
                os.write(row);
                written += row.length;
            }
        }
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            List<Path> splitFiles = SftpUtil.splitFilePerMbPerNewLine(bigFile.toString(), 1, 256, TEST_TEMP_DIR, false, ".part");
            assertFalse("Should have produced split files", splitFiles.isEmpty());
            for (Path p : splitFiles) Files.deleteIfExists(p);
        }
        Files.deleteIfExists(bigFile);
    }

    @Test
    public void testSplitFilePerMbPerNewLine_DeleteOriginalWhenDeleteTrue() throws Exception {
        Path bigFile = Paths.get(TEST_TEMP_DIR, "bigdel_" + System.currentTimeMillis() + ".csv");
        int oneMb = 1024 * 1024;
        byte[] row = "123456789,987654321,E2\n".getBytes(StandardCharsets.UTF_8);
        try (java.io.OutputStream os = Files.newOutputStream(bigFile)) {
            int written = 0;
            while (written < oneMb * 2 + 100) {
                os.write(row);
                written += row.length;
            }
        }
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            List<Path> splitFiles = SftpUtil.splitFilePerMbPerNewLine(bigFile.toString(), 1, 256, TEST_TEMP_DIR, true, ".part");
            assertFalse(Files.exists(bigFile));
            for (Path p : splitFiles) Files.deleteIfExists(p);
        }
    }

    // ========== processResendAEList (via reflection) ==========

    @Test
    public void testProcessResendAEList_BusinessHoursSkips() throws Exception {
        Method m = SftpUtil.class.getDeclaredMethod("processResendAEList");
        m.setAccessible(true);

        AutoenrollmentObj obj = new AutoenrollmentObj();
        obj.setMpin("123456789");
        obj.setTin("987654321");
        obj.setFileName("E2");
        obj.setCorpMpin("111111111");
        Field resendField = SftpUtil.class.getDeclaredField("resendAEList");
        resendField.setAccessible(true);
        resendField.set(null, new ArrayList<>(Collections.singletonList(obj)));

        ExecutorService exec = mock(ExecutorService.class);
        ReflectionTestUtils.setField(SftpUtil.class, "digiSecGetExecutorService", exec);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            m.invoke(null);
        }
        verify(exec, never()).execute(any(Runnable.class));
    }

    @Test
    public void testProcessResendAEList_NonBusinessHours_SubmitsTasksForEachRecord() throws Exception {
        Method m = SftpUtil.class.getDeclaredMethod("processResendAEList");
        m.setAccessible(true);

        AutoenrollmentObj obj = new AutoenrollmentObj();
        obj.setMpin("123456789");
        obj.setTin("987654321");
        obj.setFileName("E2");
        obj.setCorpMpin("111111111");

        Field resendField = SftpUtil.class.getDeclaredField("resendAEList");
        resendField.setAccessible(true);
        resendField.set(null, new ArrayList<>(Collections.singletonList(obj)));

        ExecutorService exec = mock(ExecutorService.class);
        ReflectionTestUtils.setField(SftpUtil.class, "digiSecGetExecutorService", exec);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            m.invoke(null);
            verify(exec, atLeastOnce()).execute(any(Runnable.class));
        }
    }

    // ========== serviceSendGetShutdown interrupted ==========

    @Test
    public void testServiceSendGetShutdown_InterruptedExceptionHandled() throws Exception {
        ExecutorService exec = mock(ExecutorService.class);
        doThrow(new InterruptedException("interrupted")).when(exec).awaitTermination(anyLong(), any(TimeUnit.class));
        ReflectionTestUtils.setField(SftpUtil.class, "sendGetExecutorService", exec);
        ReflectionTestUtils.invokeMethod(SftpUtil.class, "serviceSendGetShutdown");
        verify(exec).shutdown();
    }

    @Test
    public void testServicePESGetShutdown_InterruptedExceptionHandled() throws Exception {
        ExecutorService exec = mock(ExecutorService.class);
        doThrow(new InterruptedException("interrupted")).when(exec).awaitTermination(anyLong(), any(TimeUnit.class));
        ReflectionTestUtils.setField(SftpUtil.class, "EmailCheckExecutorService", exec);
        ReflectionTestUtils.invokeMethod(SftpUtil.class, "servicePESGetShutdown");
        verify(exec).shutdown();
    }

    // ========== deleteFile — IOException branch ==========

    @Test
    public void testDeleteFile_NonDeletable_ReturnsFalse() throws Exception {
        // Pass a path that doesn't exist — IOException (NoSuchFileException) → returns false
        assertFalse(SftpUtil.deleteFile(Paths.get("/nonexistent_dir_xyz/nofile.csv")));
    }

    // ========== retryLineFormat edge ==========

    @Test
    public void testRetryLineFormat_MalformedLine_ThrowsOrEmpty() throws Exception {
        Method m = SftpUtil.class.getDeclaredMethod("retryLineFormat", String.class);
        m.setAccessible(true);
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            // valid formatted line with multiple fields
            Map<String, Object> result = (Map<String, Object>) m.invoke(null, "prefix -> {mpin:111222333,tin:987654321,fileName:E2,extra:value}}");
            assertNotNull(result);
            assertEquals("111222333", result.get("mpin"));
        }
    }

    // ========== readFileFromServer overload (void) cd throws SftpException ==========

    @Test
    public void testReadFileFromServer_VoidOverload_CdThrows() throws Exception {
        ChannelSftp ch = mock(ChannelSftp.class);
        doThrow(new SftpException(ChannelSftp.SSH_FX_NO_SUCH_FILE, "no dir")).when(ch).cd("/dest");
        Map<String, Object> sftpResult = new HashMap<>();
        sftpResult.put("channelSftp", ch);
        sftpResult.put("directoryListing", new ArrayList<>());
        try {
            SftpUtil.readFileFromServer("/dest", sftpResult, "/work");
            fail("Expected SftpException");
        } catch (SftpException e) {
            assertEquals(ChannelSftp.SSH_FX_NO_SUCH_FILE, e.id);
        }
    }

    // ========== Autowired setter coverage ==========

    @Test
    public void testSetters_WireStaticFields() {
        DigitalSecurityServiceImpl dss = mock(DigitalSecurityServiceImpl.class);
        AutoenrollmentServiceImpl aes = mock(AutoenrollmentServiceImpl.class);
        PESCorpMpinHandler pes = mock(PESCorpMpinHandler.class);
        FDSCloudHandler fds = mock(FDSCloudHandler.class);
        ProviderPreferenceServiceImpl pps = mock(ProviderPreferenceServiceImpl.class);

        ReflectionTestUtils.setField(SftpUtil.class, "digitalSecurityServiceImpl", dss);
        ReflectionTestUtils.setField(SftpUtil.class, "autoenrollmentServiceImpl", aes);
        ReflectionTestUtils.setField(SftpUtil.class, "PESCorpMpinHandler", pes);
        ReflectionTestUtils.setField(SftpUtil.class, "fdsCloudHandler", fds);
        ReflectionTestUtils.setField(SftpUtil.class, "providerPreferenceServiceImpl", pps);

        assertEquals(dss, ReflectionTestUtils.getField(SftpUtil.class, "digitalSecurityServiceImpl"));
        assertEquals(aes, ReflectionTestUtils.getField(SftpUtil.class, "autoenrollmentServiceImpl"));
        assertEquals(pes, ReflectionTestUtils.getField(SftpUtil.class, "PESCorpMpinHandler"));
        assertEquals(fds, ReflectionTestUtils.getField(SftpUtil.class, "fdsCloudHandler"));
        assertEquals(pps, ReflectionTestUtils.getField(SftpUtil.class, "providerPreferenceServiceImpl"));
    }

    // ========== sftpDirectory – cd throws SftpException (swallowed) ==========

    @Test
    public void testSftpDirectory_CdThrows_StillReturnsResult() throws Exception {
        Session session = mock(Session.class);
        ChannelSftp sftp = mock(ChannelSftp.class);
        Vector<ChannelSftp.LsEntry> vec = new Vector<>(Collections.singletonList(mock(ChannelSftp.LsEntry.class)));
        doThrow(new SftpException(ChannelSftp.SSH_FX_NO_SUCH_FILE, "no dir")).when(sftp).cd("/work");
        when(sftp.pwd()).thenReturn("/work");
        when(sftp.ls("/work")).thenReturn(vec);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            util.when(() -> SftpUtil.createSession("u", "p", "h", 22)).thenReturn(session);
            util.when(() -> SftpUtil.createSFTPChannel(session)).thenReturn(sftp);

            Map<String, Object> result = SftpUtil.sftpDirectory("u", "p", "h", "/work");
            assertNotNull(result.get("channelSftp"));
            assertNotNull(result.get("sftpSession"));
        }
    }

    // ========== readFile – non-business-hours path (file on disk) ==========

    @Test
    public void testReadFile_NonBusinessHours_ValidRecords() throws Exception {
        Path file = Paths.get(TEST_TEMP_DIR, "rf_" + System.currentTimeMillis() + ".csv");
        Files.write(file, "123456789,987654321,E2\n".getBytes(StandardCharsets.UTF_8));

        Map<String, Object> sftpResult = new HashMap<>();
        sftpResult.put("channelSftp", mock(ChannelSftp.class));

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            // doNothing-equivalent for void static: stub to return null via doAnswer
            util.when(() -> SftpUtil.copyFileToLocal(anyString(), anyString(), anyString(), anyMap()))
                .thenThrow(new AssertionError("should not reach real copyFileToLocal"));
            // Override with a no-op using doAnswer on the specific call
            util.when(() -> SftpUtil.copyFileToLocal(eq("/dest"), eq(TEST_TEMP_DIR), anyString(), anyMap()))
                .then(i -> null);

            clearHeaders();
            List<String> result = SftpUtil.readFile("/dest", TEST_TEMP_DIR, file.getFileName().toString(), sftpResult);
            assertNotNull(result);
            assertFalse(result.isEmpty());
            assertEquals("987654321", result.get(0));
        }
        Files.deleteIfExists(file);
    }

    @Test
    public void testReadFile_NonBusinessHours_InvalidFieldsSkipped() throws Exception {
        Path file = Paths.get(TEST_TEMP_DIR, "rf_bad_" + System.currentTimeMillis() + ".csv");
        // first field length != 9 — should fail predicate
        Files.write(file, "BAD,987654321,E2\n".getBytes(StandardCharsets.UTF_8));

        Map<String, Object> sftpResult = Collections.singletonMap("channelSftp", mock(ChannelSftp.class));

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            util.when(() -> SftpUtil.copyFileToLocal(anyString(), anyString(), anyString(), anyMap()))
                .then(i -> null);

            clearHeaders();
            List<String> result = SftpUtil.readFile("/dest", TEST_TEMP_DIR, file.getFileName().toString(), sftpResult);
            assertTrue(result.isEmpty());
        }
        Files.deleteIfExists(file);
    }

    // ========== readFileStoreData – non-business-hours, daily + non-daily ==========

    @Test
    public void testReadFileStoreData_BusinessHoursReturnsEmpty() throws Exception {
        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(true);
            assertTrue(SftpUtil.readFileStoreData("/d", TEST_TEMP_DIR, "f.csv",
                Collections.emptyMap(), false).isEmpty());
        }
    }

    @Test
    public void testReadFileStoreData_NonDaily_E2E3E4Branches() throws Exception {
        Path file = Paths.get(TEST_TEMP_DIR, "rsd_" + System.currentTimeMillis() + ".csv");
        Files.write(file, (
            "123456789,987654321,E2,111111111\n" +
            "111111111,222222222,E3,333333333\n" +
            "444444444,555555555,E4,666666666\n"
        ).getBytes(StandardCharsets.UTF_8));

        DigitalSecurityServiceImpl dss = mock(DigitalSecurityServiceImpl.class);
        when(dss.getDigiSecToken(anyString())).thenReturn(new Token());
        ReflectionTestUtils.setField(SftpUtil.class, "digitalSecurityServiceImpl", dss);

        ExecutorService exec = mock(ExecutorService.class);
        when(exec.isShutdown()).thenReturn(false);
        when(exec.awaitTermination(anyLong(), any(TimeUnit.class))).thenReturn(true);
        ReflectionTestUtils.setField(SftpUtil.class, "digiSecGetExecutorService", exec);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            util.when(() -> SftpUtil.copyFileToLocal(anyString(), anyString(), anyString(), anyMap()))
                .then(i -> null);
            // stub getEmailFromFdsCloudForCategory to return null → forces executor path
            util.when(() -> SftpUtil.getEmailFromFdsCloudForCategory(anyString(), anyString(), anyString()))
                .thenReturn(null);

            clearHeaders();
            List<String> result = SftpUtil.readFileStoreData("/dest", TEST_TEMP_DIR,
                file.getFileName().toString(), Collections.singletonMap("channelSftp", mock(ChannelSftp.class)), false);
            assertNotNull(result);
            verify(exec, times(3)).execute(any(Runnable.class));
        }
        Files.deleteIfExists(file);
    }

    @Test
    public void testReadFileStoreData_EmailFoundDirectly_AddsToRecords() throws Exception {
        Path file = Paths.get(TEST_TEMP_DIR, "rsd_email_" + System.currentTimeMillis() + ".csv");
        Files.write(file, "123456789,987654321,E2,111111111\n".getBytes(StandardCharsets.UTF_8));

        DigitalSecurityServiceImpl dss = mock(DigitalSecurityServiceImpl.class);
        when(dss.getDigiSecToken(anyString())).thenReturn(new Token());
        ReflectionTestUtils.setField(SftpUtil.class, "digitalSecurityServiceImpl", dss);

        ExecutorService exec = mock(ExecutorService.class);
        when(exec.isShutdown()).thenReturn(false);
        when(exec.awaitTermination(anyLong(), any(TimeUnit.class))).thenReturn(true);
        ReflectionTestUtils.setField(SftpUtil.class, "digiSecGetExecutorService", exec);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            util.when(() -> SftpUtil.copyFileToLocal(anyString(), anyString(), anyString(), anyMap()))
                .then(i -> null);
            util.when(() -> SftpUtil.getEmailFromFdsCloudForCategory("123456789", "987654321", "P1"))
                .thenReturn("provider@test.com");

            clearHeaders();
            List<String> result = SftpUtil.readFileStoreData("/dest", TEST_TEMP_DIR,
                file.getFileName().toString(), Collections.singletonMap("channelSftp", mock(ChannelSftp.class)), false);
            assertEquals(1, result.size());
            assertTrue(result.get(0).contains("provider@test.com"));
            verify(exec, never()).execute(any(Runnable.class));
        }
        Files.deleteIfExists(file);
    }

    @Test
    public void testReadFileStoreData_IsDailyTrue_CallsCopyNoDate() throws Exception {
        Path file = Paths.get(TEST_TEMP_DIR, "rsd_daily_" + System.currentTimeMillis() + ".csv");
        Files.write(file, "".getBytes());

        DigitalSecurityServiceImpl dss = mock(DigitalSecurityServiceImpl.class);
        when(dss.getDigiSecToken(anyString())).thenReturn(new Token());
        ReflectionTestUtils.setField(SftpUtil.class, "digitalSecurityServiceImpl", dss);

        ExecutorService exec = mock(ExecutorService.class);
        when(exec.isShutdown()).thenReturn(false);
        when(exec.awaitTermination(anyLong(), any(TimeUnit.class))).thenReturn(true);
        ReflectionTestUtils.setField(SftpUtil.class, "digiSecGetExecutorService", exec);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            util.when(() -> SftpUtil.copyFileToLocalNoDate(anyString(), anyString(), anyString(), anyMap()))
                .then(i -> null);

            clearHeaders();
            SftpUtil.readFileStoreData("/dest", TEST_TEMP_DIR, file.getFileName().toString(),
                Collections.singletonMap("channelSftp", mock(ChannelSftp.class)), true);
            // verify copyFileToLocalNoDate was called: once during mockStatic stubbing setup + once by readFileStoreData
            util.verify(() -> SftpUtil.copyFileToLocalNoDate(anyString(), anyString(), anyString(), anyMap()),
                times(2));
        }
        Files.deleteIfExists(file);
    }

    // ========== readFileStoreMemberPaymentData – non-business-hours ==========

    @Test
    public void testReadFileStoreMemberPaymentData_NonBusinessHours_BuildsRecords() throws Exception {
        Path file = Paths.get(TEST_TEMP_DIR, "rmem_" + System.currentTimeMillis() + ".csv");
        // Avoid keywords that cause the parser to skip the line (ACTIVE, ENROLLMENT, MPIN, TIN, ACCOUNT)
        Files.write(file, "123456789,987654321,ENRL,ACT,1234\n".getBytes(StandardCharsets.UTF_8));

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class);
             MockedStatic<SftpUtil> util = mockStatic(SftpUtil.class, CALLS_REAL_METHODS)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            util.when(() -> SftpUtil.copyFileToLocal(anyString(), anyString(), anyString(), anyMap()))
                .then(i -> null);

            clearHeaders();
            List<String> result = SftpUtil.readFileStoreMemberPaymentData("/dest", TEST_TEMP_DIR,
                file.getFileName().toString(), Collections.singletonMap("channelSftp", mock(ChannelSftp.class)), false);
            assertNotNull(result);
            assertEquals(1, result.size());
            assertTrue(result.get(0).contains("123456789"));
        }
        Files.deleteIfExists(file);
    }

    // ========== getDigiSecEmailRequest.run() – non-business-hours branches ==========

    @Test
    public void testGetDigiSecEmailRequest_Run_EmailFound() throws Exception {
        DigitalSecurityServiceImpl dss = mock(DigitalSecurityServiceImpl.class);
        ReflectionTestUtils.setField(SftpUtil.class, "digitalSecurityServiceImpl", dss);

        User user = mock(User.class);
        when(user.getEmail()).thenReturn("good@example.com");
        // toString() must contain "email" to pass the production code's .toString().contains("email") check
        when(user.toString()).thenReturn("User{email=good@example.com}");
        ResponseEntity<User> response = ResponseEntity.ok(user);
        when(dss.getEmailsByCorporate(eq("111111111"), any(HttpHeaders.class))).thenReturn(response);

        Field recordsField = SftpUtil.class.getDeclaredField("records");
        recordsField.setAccessible(true);
        recordsField.set(null, Collections.synchronizedList(new ArrayList<String>()));

        SftpUtil.getDigiSecEmailRequest req = new SftpUtil.getDigiSecEmailRequest(
            Arrays.asList("123456789", "987654321", "E2", "111111111"));

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            req.run();
        }

        @SuppressWarnings("unchecked")
        List<String> records = (List<String>) recordsField.get(null);
        assertFalse(records.isEmpty());
        assertTrue(records.get(0).contains("good@example.com"));
    }

    @Test
    public void testGetDigiSecEmailRequest_Run_EmailResponseNull() throws Exception {
        DigitalSecurityServiceImpl dss = mock(DigitalSecurityServiceImpl.class);
        ReflectionTestUtils.setField(SftpUtil.class, "digitalSecurityServiceImpl", dss);
        when(dss.getEmailsByCorporate(anyString(), any(HttpHeaders.class))).thenReturn(null);

        Field recordsField = SftpUtil.class.getDeclaredField("records");
        recordsField.setAccessible(true);
        recordsField.set(null, Collections.synchronizedList(new ArrayList<String>()));

        SftpUtil.getDigiSecEmailRequest req = new SftpUtil.getDigiSecEmailRequest(
            Arrays.asList("123456789", "987654321", "E2", "111111111"));

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            req.run();
        }

        @SuppressWarnings("unchecked")
        List<String> records = (List<String>) recordsField.get(null);
        assertFalse(records.isEmpty());  // record still appended with empty email
        assertTrue(records.get(0).endsWith(","));  // last token is blank email
    }

    @Test
    public void testGetDigiSecEmailRequest_Run_EmptyCorpMpin_SkipsCall() throws Exception {
        DigitalSecurityServiceImpl dss = mock(DigitalSecurityServiceImpl.class);
        ReflectionTestUtils.setField(SftpUtil.class, "digitalSecurityServiceImpl", dss);

        Field recordsField = SftpUtil.class.getDeclaredField("records");
        recordsField.setAccessible(true);
        recordsField.set(null, Collections.synchronizedList(new ArrayList<String>()));

        SftpUtil.getDigiSecEmailRequest req = new SftpUtil.getDigiSecEmailRequest(
            Arrays.asList("123456789", "987654321", "E2", ""));  // empty corp mpin

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            req.run();
        }

        verify(dss, never()).getEmailsByCorporate(anyString(), any(HttpHeaders.class));
    }

    // ========== sendFDSCloudGetRequest.run() – non-business-hours branches ==========

    @Test
    public void testSendFDSCloudGetRequest_Run_DocumentFound_EmailNotEmpty() throws Exception {
        FDSCloudHandler fds = mock(FDSCloudHandler.class);
        ReflectionTestUtils.setField(SftpUtil.class, "fdsCloudHandler", fds);

        FDSCloudRequest req = new FDSCloudRequest();
        when(fds.createSearchTermsRequestFromMap(anyMap())).thenReturn(req);

        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        FDSCloudGETResponse resp = new FDSCloudGETResponse();
        resp.setDocuments(Collections.singletonList(doc));
        when(fds.FDSCloudGetRequest(anyString(), any())).thenReturn(resp);

        Map<String, Object> docMap = new HashMap<>();
        docMap.put("providerEmailId", "found@test.com");
        when(fds.getSearchTermsFromDocument(doc)).thenReturn(docMap);

        // pre-initialize static lists
        Field missingField = SftpUtil.class.getDeclaredField("missingDocList");
        missingField.setAccessible(true);
        missingField.set(null, Collections.synchronizedList(new ArrayList<>()));

        Field resendField = SftpUtil.class.getDeclaredField("resendAEList");
        resendField.setAccessible(true);
        resendField.set(null, Collections.synchronizedList(new ArrayList<>()));

        AutoenrollmentObj obj = new AutoenrollmentObj();
        obj.setMpin("123456789");
        obj.setTin("987654321");
        obj.setFileName("E2");

        SftpUtil.sendFDSCloudGetRequest runnable = new SftpUtil.sendFDSCloudGetRequest(obj);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            runnable.run();
        }

        @SuppressWarnings("unchecked")
        List<?> missing = (List<?>) missingField.get(null);
        assertTrue(missing.isEmpty()); // document found, no missing
    }

    @Test
    public void testSendFDSCloudGetRequest_Run_DocumentNotFound_AddsToMissing() throws Exception {
        FDSCloudHandler fds = mock(FDSCloudHandler.class);
        ReflectionTestUtils.setField(SftpUtil.class, "fdsCloudHandler", fds);

        FDSCloudRequest fdsReq = new FDSCloudRequest();
        when(fds.createSearchTermsRequestFromMap(anyMap())).thenReturn(fdsReq);

        FDSCloudGETResponse resp = new FDSCloudGETResponse();
        resp.setDocuments(Collections.emptyList());
        when(fds.FDSCloudGetRequest(anyString(), any())).thenReturn(resp);

        Field missingField = SftpUtil.class.getDeclaredField("missingDocList");
        missingField.setAccessible(true);
        missingField.set(null, Collections.synchronizedList(new ArrayList<>()));

        Field resendField = SftpUtil.class.getDeclaredField("resendAEList");
        resendField.setAccessible(true);
        resendField.set(null, Collections.synchronizedList(new ArrayList<>()));

        AutoenrollmentObj obj = new AutoenrollmentObj();
        obj.setMpin("123456789");
        obj.setTin("987654321");
        obj.setFileName("E2");

        SftpUtil.sendFDSCloudGetRequest runnable = new SftpUtil.sendFDSCloudGetRequest(obj);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            runnable.run();
        }

        @SuppressWarnings("unchecked")
        List<?> missing = (List<?>) missingField.get(null);
        assertEquals(1, missing.size());

        @SuppressWarnings("unchecked")
        List<?> resend = (List<?>) resendField.get(null);
        assertEquals(1, resend.size());
    }

    @Test
    public void testSendFDSCloudGetRequest_Run_ExceptionCaught() throws Exception {
        FDSCloudHandler fds = mock(FDSCloudHandler.class);
        ReflectionTestUtils.setField(SftpUtil.class, "fdsCloudHandler", fds);
        when(fds.createSearchTermsRequestFromMap(anyMap())).thenThrow(new RuntimeException("boom"));

        Field missingField = SftpUtil.class.getDeclaredField("missingDocList");
        missingField.setAccessible(true);
        missingField.set(null, Collections.synchronizedList(new ArrayList<>()));

        AutoenrollmentObj obj = new AutoenrollmentObj();
        obj.setMpin("123456789"); obj.setTin("987654321"); obj.setFileName("E2");

        SftpUtil.sendFDSCloudGetRequest runnable = new SftpUtil.sendFDSCloudGetRequest(obj);

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            runnable.run(); // must not propagate
        }

        verify(fds, times(1)).createSearchTermsRequestFromMap(anyMap());
        @SuppressWarnings("unchecked")
        List<?> missing = (List<?>) missingField.get(null);
        assertTrue(missing.isEmpty());
    }

    // ========== getPESCorpMpinRequest.run() – non-business-hours branches ==========

    @Test
    public void testGetPESCorpMpinRequest_Run_CorpMpinFoundEmailFound() throws Exception {
        PESCorpMpinHandler pes = mock(PESCorpMpinHandler.class);
        when(pes.getCorpMpin("987654321")).thenReturn("111111111");
        ReflectionTestUtils.setField(SftpUtil.class, "PESCorpMpinHandler", pes);

        DigitalSecurityServiceImpl dss = mock(DigitalSecurityServiceImpl.class);
        // Build a User whose toString() contains "email" so the production code's
        // emailResponse.toString().contains("email") check passes
        User user = mock(User.class);
        when(user.getEmail()).thenReturn("valid@example.com");
        when(user.toString()).thenReturn("User{email=valid@example.com}");
        // Wrap in a real ResponseEntity so .getBody() and .toString() work correctly
        ResponseEntity<User> emailResp = ResponseEntity.ok(user);
        when(dss.getEmailsByCorporate(eq("111111111"), any(HttpHeaders.class))).thenReturn(emailResp);
        ReflectionTestUtils.setField(SftpUtil.class, "digitalSecurityServiceImpl", dss);

        ProviderPreferenceServiceImpl pps = mock(ProviderPreferenceServiceImpl.class);
        ReflectionTestUtils.setField(SftpUtil.class, "providerPreferenceServiceImpl", pps);

        Field recordsField = SftpUtil.class.getDeclaredField("records");
        recordsField.setAccessible(true);
        recordsField.set(null, Collections.synchronizedList(new ArrayList<String>()));

        SftpUtil.getPESCorpMpinRequest req = new SftpUtil.getPESCorpMpinRequest(
            Arrays.asList("123456789", "987654321", "E2", "111111111"));

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            req.run();
        }

        verify(pps).updateProviderPreferencesFDSCloud(any(), any(HttpHeaders.class));

        @SuppressWarnings("unchecked")
        List<String> records = (List<String>) recordsField.get(null);
        assertFalse(records.isEmpty());
        assertTrue(records.get(0).contains("valid@example.com"));
    }

    @Test
    public void testGetPESCorpMpinRequest_Run_CorpMpinEmpty_SkipsEmailCall() throws Exception {
        PESCorpMpinHandler pes = mock(PESCorpMpinHandler.class);
        when(pes.getCorpMpin(anyString())).thenReturn("");
        ReflectionTestUtils.setField(SftpUtil.class, "PESCorpMpinHandler", pes);

        DigitalSecurityServiceImpl dss = mock(DigitalSecurityServiceImpl.class);
        ReflectionTestUtils.setField(SftpUtil.class, "digitalSecurityServiceImpl", dss);

        ProviderPreferenceServiceImpl pps = mock(ProviderPreferenceServiceImpl.class);
        ReflectionTestUtils.setField(SftpUtil.class, "providerPreferenceServiceImpl", pps);

        Field recordsField = SftpUtil.class.getDeclaredField("records");
        recordsField.setAccessible(true);
        recordsField.set(null, Collections.synchronizedList(new ArrayList<String>()));

        SftpUtil.getPESCorpMpinRequest req = new SftpUtil.getPESCorpMpinRequest(
            Arrays.asList("123456789", "987654321", "E2", ""));

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            req.run();
        }

        verify(dss, never()).getEmailsByCorporate(anyString(), any(HttpHeaders.class));
        verify(pps, never()).updateProviderPreferencesFDSCloud(any(), any(HttpHeaders.class));
    }

    @Test
    public void testGetPESCorpMpinRequest_Run_EmailResponseNull_NoUpdate() throws Exception {
        PESCorpMpinHandler pes = mock(PESCorpMpinHandler.class);
        when(pes.getCorpMpin("987654321")).thenReturn("111111111");
        ReflectionTestUtils.setField(SftpUtil.class, "PESCorpMpinHandler", pes);

        DigitalSecurityServiceImpl dss = mock(DigitalSecurityServiceImpl.class);
        when(dss.getEmailsByCorporate(anyString(), any(HttpHeaders.class))).thenReturn(null);
        ReflectionTestUtils.setField(SftpUtil.class, "digitalSecurityServiceImpl", dss);

        ProviderPreferenceServiceImpl pps = mock(ProviderPreferenceServiceImpl.class);
        ReflectionTestUtils.setField(SftpUtil.class, "providerPreferenceServiceImpl", pps);

        Field recordsField = SftpUtil.class.getDeclaredField("records");
        recordsField.setAccessible(true);
        recordsField.set(null, Collections.synchronizedList(new ArrayList<String>()));

        SftpUtil.getPESCorpMpinRequest req = new SftpUtil.getPESCorpMpinRequest(
            Arrays.asList("123456789", "987654321", "E2", "111111111"));

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            req.run();
        }

        verify(pps, never()).updateProviderPreferencesFDSCloud(any(), any(HttpHeaders.class));
    }

    // ========== readFileSendAutoEnroCloud – null record skipped ==========

    @Test
    public void testReadFileSendAutoEnroCloud_NullRecordSkipped() throws Exception {
        AutoenrollmentServiceImpl aes = mock(AutoenrollmentServiceImpl.class);
        when(aes.createAutoenrollmentDocumentsFDSCloud(any(), any())).thenReturn(Collections.emptyList());
        ReflectionTestUtils.setField(SftpUtil.class, "autoenrollmentServiceImpl", aes);

        List<String> records = new ArrayList<>();
        records.add(null);
        records.add("123456789,987654321,E2,111111111,user@test.com");

        try (MockedStatic<TimeUtils> time = mockStatic(TimeUtils.class)) {
            time.when(TimeUtils::isWithinBusinessHours).thenReturn(false);
            List<String> result = SftpUtil.readFileSendAutoEnroCloud(records);
            assertNotNull(result);
        }

        ArgumentCaptor<AutoenrollmentRequest> captor = ArgumentCaptor.forClass(AutoenrollmentRequest.class);
        verify(aes).createAutoenrollmentDocumentsFDSCloud(captor.capture(), any(HttpHeaders.class));
        // null was skipped — only 1 doc
        assertEquals(1, captor.getValue().getAutoenrollDocuments().size());
        assertEquals("user@test.com", captor.getValue().getAutoenrollDocuments().get(0).getProviderEmailId());
    }

    // ========== closeSFTPChannel – connected but getSession throws ==========

    @Test
    public void testCloseSFTPChannel_Connected_GetSessionThrows_StillCompletes() throws Exception {
        ChannelSftp chSftp = mock(ChannelSftp.class);
        Channel ch = mock(Channel.class);
        when(chSftp.isConnected()).thenReturn(true);
        when(chSftp.getSession()).thenThrow(new JSchException("session gone"));
        // Pass null session so code falls into getSession() branch
        SftpUtil.closeSFTPChannel(chSftp, null, ch);
        verify(ch).disconnect();
        verify(chSftp).disconnect();
        verify(chSftp).quit();
    }

    // ========== readFileFromServerCheckSize – non-csv entry ignored ==========

    @Test
    public void testReadFileFromServerCheckSize_NonMatchingExtensionIgnored() throws Exception {
        ChannelSftp sftp = mock(ChannelSftp.class);
        ChannelSftp.LsEntry ignoredEntry = mock(ChannelSftp.LsEntry.class);
        when(ignoredEntry.getFilename()).thenReturn("report.txt");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("channelSftp", sftp);
        sftpMap.put("directoryListing", new ArrayList<>(Collections.singletonList(ignoredEntry)));

        Map<String, Long> result = SftpUtil.readFileFromServerCheckSize("/dest", sftpMap, "/work", ".csv", "");
        assertTrue(result.isEmpty());
        verify(sftp, never()).rename(anyString(), anyString());
    }

    // ========== Helpers ==========

    private Map<String, Object> buildSftpMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("channelSftp", mock(ChannelSftp.class));
        map.put("sftpSession", mock(Session.class));
        map.put("channel", mock(Channel.class));
        return map;
    }

    private void clearHeaders() {
        try {
            Field f = SftpUtil.class.getDeclaredField("headers");
            f.setAccessible(true);
            ((List<String>) f.get(null)).clear();
        } catch (Exception ignored) {}
    }

    private List<String> getHeaders() {
        try {
            Field f = SftpUtil.class.getDeclaredField("headers");
            f.setAccessible(true);
            return (List<String>) f.get(null);
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }
}
