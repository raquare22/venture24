package com.optum.providerpreferences.autoenrollment;

import com.optum.providerpreferences.autoenrollment.config.SchedulerConfig;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class SchedulerTest {

    @Before
    public void setUpMissingCredentials() {
        SchedulerConfig.prunHost = null;
        SchedulerConfig.prunUserName = null;
        SchedulerConfig.prunKey = null;
        SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY = null;
        SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY = null;
        SchedulerConfig.PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY = null;
        SchedulerConfig.PRUN_DESTINATION_PROCESSED_DIRECTORY = null;
    }

    @Test
    public void testConstructor() {
        Scheduler scheduler = new Scheduler();
        assertNotNull(scheduler);
    }

    @Test
    public void testCheckAutoenrollmentReturnsEmptyWhenCredentialsMissing() {
        Set<String> result = Scheduler.checkAutoenrollment();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testScheduledCheckAutoenrollmentReturnsEmptyWhenCredentialsMissing() {
        Set<String> result = Scheduler.scheduledCheckAutoenrollment("/some/dir");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testProcessFilesDoesNotThrowWhenCredentialsMissing() {
        Scheduler.processFiles();
    }

    @Test
    public void testPollCsvFilesLeavesLockFalseOnFailurePath() throws Exception {
        Scheduler.pollCSVFiles();

        Field lockField = Scheduler.class.getDeclaredField("lock");
        lockField.setAccessible(true);
        AtomicBoolean lock = (AtomicBoolean) lockField.get(null);

        assertFalse(lock.get());
    }

    @Test
    public void testPollCsvFilesReturnsWhenAlreadyLocked() throws Exception {
        setLock(true);
        try (MockedStatic<SftpUtil> mocked = Mockito.mockStatic(SftpUtil.class)) {
            Scheduler.pollCSVFiles();
            mocked.verifyNoInteractions();
        } finally {
            setLock(false);
        }
    }

    @Test
    public void testProcessFilesHappyPathWithCsvEntry() {
        setValidSchedulerConfig();
        ChannelSftp channelSftp = Mockito.mock(ChannelSftp.class);
        Session session = Mockito.mock(Session.class);
        Channel channel = Mockito.mock(Channel.class);
        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        Mockito.when(entry.getFilename()).thenReturn("sample.csv");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<>(List.of(entry)));
        sftpMap.put("channelSftp", channelSftp);
        sftpMap.put("sftpSession", session);
        sftpMap.put("channel", channel);

        try (MockedStatic<SftpUtil> mocked = Mockito.mockStatic(SftpUtil.class)) {
            mocked.when(() -> SftpUtil.exceptionForMissingLoginCredential(
                    SchedulerConfig.prunHost,
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY)).thenReturn(false);
            mocked.when(() -> SftpUtil.sftpDirectory(
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.prunHost,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY)).thenReturn(sftpMap);
            mocked.when(() -> SftpUtil.readFileStoreData(
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY,
                    getLocalDirectory(),
                    "sample.csv",
                    sftpMap,
                    true)).thenReturn(List.of("111111111,222222222,E2,corp,email@test.com"));
            mocked.when(() -> SftpUtil.readFileSendAutoEnroCloud(Mockito.anyList())).thenReturn(List.of("doc1"));
            mocked.when(() -> SftpUtil.rename(Mockito.eq(channelSftp), Mockito.anyString(), Mockito.anyString(), Mockito.eq(true))).thenReturn(true);

            Scheduler.processFiles();

            mocked.verify(() -> SftpUtil.readFileStoreData(
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY,
                    getLocalDirectory(),
                    "sample.csv",
                    sftpMap,
                    true));
            mocked.verify(() -> SftpUtil.rename(Mockito.eq(channelSftp), Mockito.anyString(), Mockito.anyString(), Mockito.eq(true)));
        }
    }

    @Test
    public void testCheckAutoenrollmentHappyPathWithCsvEntry() {
        setValidSchedulerConfig();
        SchedulerConfig.prunPort = "22";
        ChannelSftp channelSftp = Mockito.mock(ChannelSftp.class);
        Session session = Mockito.mock(Session.class);
        Channel channel = Mockito.mock(Channel.class);
        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        Mockito.when(entry.getFilename()).thenReturn("check.csv");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<>(List.of(entry)));
        sftpMap.put("channelSftp", channelSftp);
        sftpMap.put("sftpSession", session);
        sftpMap.put("channel", channel);

        try (MockedStatic<SftpUtil> mocked = Mockito.mockStatic(SftpUtil.class)) {
            mocked.when(() -> SftpUtil.exceptionForMissingLoginCredential(
                    SchedulerConfig.prunHost,
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY)).thenReturn(false);
            mocked.when(() -> SftpUtil.sftpDirectory(
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.prunHost,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY)).thenReturn(sftpMap);
            mocked.when(() -> SftpUtil.checkAutoenrollmentSetup(
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.prunHost,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY,
                    "check.csv")).thenReturn(List.of("encoded-search"));

            Set<String> result = Scheduler.checkAutoenrollment();

            assertNotNull(result);
            assertTrue(result.contains("encoded-search"));
        }
    }

    @Test
    public void testScheduledCheckAutoenrollmentHappyPathRenamesFile() {
        setValidSchedulerConfig();
        ChannelSftp channelSftp = Mockito.mock(ChannelSftp.class);
        Session session = Mockito.mock(Session.class);
        Channel channel = Mockito.mock(Channel.class);
        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        Mockito.when(entry.getFilename()).thenReturn("batch.csv");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<>(List.of(entry)));
        sftpMap.put("channelSftp", channelSftp);
        sftpMap.put("sftpSession", session);
        sftpMap.put("channel", channel);

        try (MockedStatic<SftpUtil> mocked = Mockito.mockStatic(SftpUtil.class)) {
            mocked.when(() -> SftpUtil.exceptionForMissingLoginCredential(
                    SchedulerConfig.prunHost,
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    "/from")).thenReturn(true);
            mocked.when(() -> SftpUtil.sftpDirectory(
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.prunHost,
                    "/from")).thenReturn(sftpMap);
            mocked.when(() -> SftpUtil.checkAutoenrollmentSetup(
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.prunHost,
                    "/from",
                    "batch.csv")).thenReturn(List.of("missing1"));
            mocked.when(() -> SftpUtil.rename(Mockito.eq(channelSftp), Mockito.anyString(), Mockito.anyString(), Mockito.eq(true))).thenReturn(true);

            Set<String> result = Scheduler.scheduledCheckAutoenrollment("/from");

            assertNotNull(result);
            assertTrue(result.contains("missing1"));
            mocked.verify(() -> SftpUtil.rename(Mockito.eq(channelSftp), Mockito.anyString(), Mockito.anyString(), Mockito.eq(true)));
        }
    }

    @Test
    public void testPollCsvFilesCallsCreateDirectoryPath() {
        setValidSchedulerConfig();

        ChannelSftp channelSftp = Mockito.mock(ChannelSftp.class);
        Session session = Mockito.mock(Session.class);
        Channel channel = Mockito.mock(Channel.class);
        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<ChannelSftp.LsEntry>());
        sftpMap.put("channelSftp", channelSftp);
        sftpMap.put("sftpSession", session);
        sftpMap.put("channel", channel);

        try (MockedStatic<SftpUtil> mocked = Mockito.mockStatic(SftpUtil.class)) {
            mocked.when(() -> SftpUtil.exceptionForMissingLoginCredential(
                    SchedulerConfig.prunHost,
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY)).thenReturn(false);
            mocked.when(() -> SftpUtil.exceptionForMissingLoginCredential(
                    SchedulerConfig.prunHost,
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY)).thenReturn(true);
            mocked.when(() -> SftpUtil.sftpDirectory(
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.prunHost,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY)).thenReturn(sftpMap);

            Scheduler.pollCSVFiles();

            mocked.verify(() -> SftpUtil.readFileFromServer(
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY,
                    sftpMap,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY));
            mocked.verify(() -> SftpUtil.closeSFTPChannel(channelSftp, session, channel));
        }
    }

    @Test
    public void testProcessFilesSkipsPaaFile() {
        setValidSchedulerConfig();
        ChannelSftp channelSftp = Mockito.mock(ChannelSftp.class);
        Session session = Mockito.mock(Session.class);
        Channel channel = Mockito.mock(Channel.class);
        ChannelSftp.LsEntry entry = Mockito.mock(ChannelSftp.LsEntry.class);
        Mockito.when(entry.getFilename()).thenReturn("inbound_PAA.csv");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<>(List.of(entry)));
        sftpMap.put("channelSftp", channelSftp);
        sftpMap.put("sftpSession", session);
        sftpMap.put("channel", channel);

        try (MockedStatic<SftpUtil> mocked = Mockito.mockStatic(SftpUtil.class)) {
            mocked.when(() -> SftpUtil.exceptionForMissingLoginCredential(
                    SchedulerConfig.prunHost,
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY)).thenReturn(false);
            mocked.when(() -> SftpUtil.sftpDirectory(
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.prunHost,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY)).thenReturn(sftpMap);

            Scheduler.processFiles();

            mocked.verify(() -> SftpUtil.readFileStoreData(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyMap(), Mockito.anyBoolean()), Mockito.never());
            mocked.verify(() -> SftpUtil.closeSFTPChannel(channelSftp, session, channel));
        }
    }

    @Test
    public void testProcessFilesHandlesOuterSftpExceptionAndUnlocks() throws Exception {
        setValidSchedulerConfig();

        try (MockedStatic<SftpUtil> mocked = Mockito.mockStatic(SftpUtil.class)) {
            mocked.when(() -> SftpUtil.exceptionForMissingLoginCredential(
                    SchedulerConfig.prunHost,
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY)).thenReturn(false);
            mocked.when(() -> SftpUtil.sftpDirectory(
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.prunHost,
                    SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY))
                    .thenThrow(new com.jcraft.jsch.SftpException(4, "down"));

            Scheduler.processFiles();
        }

        Field lockField = Scheduler.class.getDeclaredField("lock");
        lockField.setAccessible(true);
        AtomicBoolean lock = (AtomicBoolean) lockField.get(null);
        assertFalse(lock.get());
    }

    @Test
    public void testScheduledCheckAutoenrollmentEarlyReturnWhenCredentialCheckFalse() {
        setValidSchedulerConfig();
        try (MockedStatic<SftpUtil> mocked = Mockito.mockStatic(SftpUtil.class)) {
            mocked.when(() -> SftpUtil.exceptionForMissingLoginCredential(
                    SchedulerConfig.prunHost,
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    "/from")).thenReturn(false);

            Set<String> result = Scheduler.scheduledCheckAutoenrollment("/from");

            assertTrue(result.isEmpty());
            mocked.verify(() -> SftpUtil.sftpDirectory(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString()), Mockito.never());
        }
    }

    @Test
    public void testScheduledCheckAutoenrollmentSkipsCheckedAndDotEntries() {
        setValidSchedulerConfig();
        ChannelSftp channelSftp = Mockito.mock(ChannelSftp.class);
        Session session = Mockito.mock(Session.class);
        Channel channel = Mockito.mock(Channel.class);
        ChannelSftp.LsEntry entryChecked = Mockito.mock(ChannelSftp.LsEntry.class);
        ChannelSftp.LsEntry entryDot = Mockito.mock(ChannelSftp.LsEntry.class);
        ChannelSftp.LsEntry entryDotDot = Mockito.mock(ChannelSftp.LsEntry.class);
        Mockito.when(entryChecked.getFilename()).thenReturn("batch_checked.csv");
        Mockito.when(entryDot.getFilename()).thenReturn(".");
        Mockito.when(entryDotDot.getFilename()).thenReturn("..");

        Map<String, Object> sftpMap = new HashMap<>();
        sftpMap.put("directoryListing", new ArrayList<>(List.of(entryChecked, entryDot, entryDotDot)));
        sftpMap.put("channelSftp", channelSftp);
        sftpMap.put("sftpSession", session);
        sftpMap.put("channel", channel);

        try (MockedStatic<SftpUtil> mocked = Mockito.mockStatic(SftpUtil.class)) {
            mocked.when(() -> SftpUtil.exceptionForMissingLoginCredential(
                    SchedulerConfig.prunHost,
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    "/from")).thenReturn(true);
            mocked.when(() -> SftpUtil.sftpDirectory(
                    SchedulerConfig.prunUserName,
                    SchedulerConfig.prunKey,
                    SchedulerConfig.prunHost,
                    "/from")).thenReturn(sftpMap);

            Set<String> result = Scheduler.scheduledCheckAutoenrollment("/from");

            assertTrue(result.isEmpty());
            mocked.verify(() -> SftpUtil.checkAutoenrollmentSetup(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString()), Mockito.never());
            mocked.verify(() -> SftpUtil.rename(Mockito.eq(channelSftp), Mockito.anyString(), Mockito.anyString(), Mockito.eq(true)), Mockito.never());
            mocked.verify(() -> SftpUtil.closeSFTPChannel(channelSftp, session, channel));
        }
    }

    @Test
    public void testPrivateWriteCsvMovesGeneratedFile() throws Exception {
        Method writeCsv = Scheduler.class.getDeclaredMethod("writeCSV", String.class, Set.class, Map.class, String.class);
        writeCsv.setAccessible(true);

        Map<String, Object> sftpMap = new HashMap<>();
        Set<String> rows = Set.of("a,b,c");

        try (MockedStatic<SftpUtil> mocked = Mockito.mockStatic(SftpUtil.class)) {
            mocked.when(SftpUtil::createDateintoString).thenReturn("20260527_");

            writeCsv.invoke(null, "missing", rows, sftpMap, "/dest");

            String expected = getLocalDirectory() + java.io.File.separator + "20260527_missing.csv";
            mocked.verify(() -> SftpUtil.writeInCSVFile(rows, getLocalDirectory()));
            mocked.verify(() -> SftpUtil.movefileFromlocalToServer(expected, sftpMap, "/dest"));
        }
    }

    private void setValidSchedulerConfig() {
        SchedulerConfig.prunHost = "host";
        SchedulerConfig.prunUserName = "user";
        SchedulerConfig.prunKey = "pass";
        SchedulerConfig.PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY = "/working";
        SchedulerConfig.PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY = "/dest";
        SchedulerConfig.PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY = "/archive";
        SchedulerConfig.PRUN_DESTINATION_PROCESSED_DIRECTORY = "/processed";
        SchedulerConfig.THREAD_COUNT_HEALTHCHECK = "1000";
        SchedulerConfig.prunPort = "22";
    }

    private String getLocalDirectory() {
        try {
            Field field = Scheduler.class.getDeclaredField("LOCAL_DIRECTORY");
            field.setAccessible(true);
            return (String) field.get(null);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
    }

    private void setLock(boolean value) throws Exception {
        Field lockField = Scheduler.class.getDeclaredField("lock");
        lockField.setAccessible(true);
        AtomicBoolean lock = (AtomicBoolean) lockField.get(null);
        lock.set(value);
    }
}

