package com.optum.providerpreferences.suite;

import com.optum.digitalsecurity.model.request.OrgTest;
import com.optum.digitalsecurity.model.request.UserTest;
import com.optum.digitalsecurity.model.response.*;
import com.optum.providerpreferences.AppListenerTest;
import com.optum.providerpreferences.ApplicationTest;
import com.optum.providerpreferences.autoenrollment.EmailUtilsTest;
import com.optum.providerpreferences.autoenrollment.SchedulerAutoEnrollmentTest;
import com.optum.providerpreferences.autoenrollment.SchedulerMemberPaymentPreferenceTest;
import com.optum.providerpreferences.autoenrollment.SchedulerMonthlyTest;
import com.optum.providerpreferences.autoenrollment.SchedulerTest;
import com.optum.providerpreferences.autoenrollment.SftpUtilTest;
import com.optum.providerpreferences.autoenrollment.TimeUtilsTest;
import com.optum.providerpreferences.autoenrollment.config.SchedulerConfigTest;
import com.optum.providerpreferences.kafka.ConfigDataTest;
import com.optum.providerpreferences.kafka.EnvironmentsTest;
import com.optum.providerpreferences.kafka.KafkaProducerTest;
import com.optum.providerpreferences.kafka.KafkaPublisherTest;
import com.optum.providerpreferences.kafka.NessAppLogTest;
import com.optum.providerpreferences.kafka.UtilityTest;
import com.optum.providerpreferences.rs.controller.AutoenrollmentControllerTest;
import com.optum.providerpreferences.rs.controller.DigitalSecurityControllerTest;
import com.optum.providerpreferences.rs.controller.LoggersControllerTest;
import com.optum.providerpreferences.rs.controller.OptOutControllerTest;
import com.optum.providerpreferences.rs.controller.ProvPrefDigiSecControllerTest;
import com.optum.providerpreferences.rs.controller.ProvPrefFDSCloudControllerTest;
import com.optum.providerpreferences.rs.controller.RootControllerTest;
import com.optum.providerpreferences.rs.exception.ErrorResponseTest;
import com.optum.providerpreferences.rs.exception.GeneralExceptionMapperTest;
import com.optum.providerpreferences.rs.handler.CACFHandlerTest;
import com.optum.providerpreferences.rs.handler.FDSCloudHandlerTest;
import com.optum.providerpreferences.rs.handler.FDSHandlerTest;
import com.optum.providerpreferences.rs.handler.LinkSecurityHandlerTest;
import com.optum.providerpreferences.rs.handler.NDBHandlerTest;
import com.optum.providerpreferences.rs.handler.Oauth2HandlerTest;
import com.optum.providerpreferences.rs.handler.PESCorpMpinHandlerTest;
import com.optum.providerpreferences.rs.handler.PESHandlerTest;
import com.optum.providerpreferences.rs.handler.RequestFactoryTest;
import com.optum.providerpreferences.rs.handler.ServiceBaseTest;
import com.optum.providerpreferences.rs.model.LogLevelObjTest;
import com.optum.providerpreferences.rs.model.NDBTokenTest;
import com.optum.providerpreferences.rs.model.ProviderPreferenceUpdateResponseTest;
import com.optum.providerpreferences.rs.model.TokenAbstTest;
import com.optum.providerpreferences.rs.model.TokenTest;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentAuditLogTest;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObjTest;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequestTest;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPostResponseTest;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPutResponseTest;
import com.optum.providerpreferences.rs.model.fds.DocumentTest;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponseTest;
import com.optum.providerpreferences.rs.model.fds.FDSResponseTest;
import com.optum.providerpreferences.rs.model.fds.MetadataTest;
import com.optum.providerpreferences.rs.model.linksecurity.PSMRequestTest;
import com.optum.providerpreferences.rs.model.linksecurity.PSMResponseTest;
import com.optum.providerpreferences.rs.model.logging.LogMessageTest;
import com.optum.providerpreferences.rs.model.ndb.CorporateEntitiesTest;
import com.optum.providerpreferences.rs.model.ndb.IndividualMPINRequestTest;
import com.optum.providerpreferences.rs.model.ndb.IndividualMPINResponseTest;
import com.optum.providerpreferences.rs.model.ndb.NDBProviderTest;
import com.optum.providerpreferences.rs.model.ndb.NDBProvidersTest;
import com.optum.providerpreferences.rs.model.ndb.ProviderOrganizationTest;
import com.optum.providerpreferences.rs.model.ndb.ProviderOrganizationsTest;
import com.optum.providerpreferences.rs.model.ndb.TinsTest;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesRequestTest;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponseTest;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterTypeTest;
import com.optum.providerpreferences.rs.model.ndb.preferences.MailPrefTest;
import com.optum.providerpreferences.rs.model.ndb.preferences.ResponseDataTest;
import com.optum.providerpreferences.rs.model.ndb.preferences.ResponseHeaderTest;
import com.optum.providerpreferences.rs.model.ndb.preferences.UILetterPreferencesRequestTest;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinRequestTest;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponseTest;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinDataTest;
import com.optum.providerpreferences.rs.model.optout.OptOutAuditMetadataTest;
import com.optum.providerpreferences.rs.model.optout.OptOutAuditUpdateTest;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocumentTest;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTRequestTest;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponseTest;
import com.optum.providerpreferences.rs.model.optout.OptOutRequestTest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinRequestTest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinResponseTest;
import com.optum.providerpreferences.rs.model.pes.KeyTest;
import com.optum.providerpreferences.rs.model.pes.MetaTest;
import com.optum.providerpreferences.rs.model.pes.PESCorpmpinRequestTest;
import com.optum.providerpreferences.rs.model.pes.PESResponseTest;
import com.optum.providerpreferences.rs.model.pes.PESTinRequestTest;
import com.optum.providerpreferences.rs.model.pes.TinObjectTest;
import com.optum.providerpreferences.rs.service.AutoenrollmentServiceImplTest;
import com.optum.providerpreferences.rs.service.DigitalSecurityServiceImplTest;
import com.optum.providerpreferences.rs.service.OptOutServiceImplTest;
import com.optum.providerpreferences.rs.service.PaymentPreferenceServiceImplTest;
import com.optum.providerpreferences.rs.service.PaymentPreferenceServiceTest;
import com.optum.providerpreferences.rs.service.ProviderPreferenceServiceImplTest;
import com.optum.providerpreferences.rs.utility.ApplicationUtilTest;
import com.optum.providerpreferences.rs.utility.ClassifierDescriptionTest;
import com.optum.providerpreferences.rs.utility.ConstantsTest;
import com.optum.providerpreferences.rs.utility.ConverterTest;
import com.optum.providerpreferences.rs.utility.MessageBuilderTest;
import com.optum.providerpreferences.rs.utility.PasswordOwnerUtilTest;
import junit.framework.TestCase;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        // digitalsecurity model
        OrgTest.class,
        UserTest.class,
        com.optum.digitalsecurity.model.request.TinTest.class,
        CorporateTest.class,
        DemographicsTest.class,
        JobFunctionTest.class,
        NonProviderOrgTest.class,
        OrgDataTest.class,
        PDOCorporatesTest.class,
        PDOProvTinTest.class,
        PDOTinsTest.class,
        PermissionTest.class,
        ProviderOrgTest.class,
        ProviderProfileTest.class,
        ProviderTest.class,
        ProvTinTest.class,
        TinTest.class,

        // application bootstrap
        AppListenerTest.class,
        ApplicationTest.class,

        // autoenrollment scheduler / utils
        SchedulerAutoEnrollmentTest.class,
        SchedulerMonthlyTest.class,
        SchedulerMemberPaymentPreferenceTest.class,
        SchedulerTest.class,
        EmailUtilsTest.class,
        TimeUtilsTest.class,
        SftpUtilTest.class,
        SchedulerConfigTest.class,

        // kafka
        ConfigDataTest.class,
        EnvironmentsTest.class,
        KafkaProducerTest.class,
        KafkaPublisherTest.class,
        NessAppLogTest.class,
        UtilityTest.class,

        // controllers
        AutoenrollmentControllerTest.class,
        DigitalSecurityControllerTest.class,
        LoggersControllerTest.class,
        OptOutControllerTest.class,
        ProvPrefDigiSecControllerTest.class,
        ProvPrefFDSCloudControllerTest.class,
        RootControllerTest.class,

        // exception
        ErrorResponseTest.class,
        GeneralExceptionMapperTest.class,

        // handlers
        CACFHandlerTest.class,
        FDSCloudHandlerTest.class,
        FDSHandlerTest.class,
        LinkSecurityHandlerTest.class,
        NDBHandlerTest.class,
        Oauth2HandlerTest.class,
        PESCorpMpinHandlerTest.class,
        PESHandlerTest.class,
        RequestFactoryTest.class,
        ServiceBaseTest.class,

        // models – root
        LogLevelObjTest.class,
        NDBTokenTest.class,
        ProviderPreferenceUpdateResponseTest.class,
        TokenAbstTest.class,
        TokenTest.class,

        // models – autoenroll
        AutoenrollmentAuditLogTest.class,
        AutoenrollmentObjTest.class,
        AutoenrollmentRequestTest.class,
        FDSMultiPostResponseTest.class,
        FDSMultiPutResponseTest.class,

        // models – fds
        DocumentTest.class,
        FDSCloudGETResponseTest.class,
        FDSResponseTest.class,
        MetadataTest.class,

        // models – linksecurity
        PSMRequestTest.class,
        PSMResponseTest.class,
        com.optum.providerpreferences.rs.model.linksecurity.UserTest.class,

        // models – logging
        LogMessageTest.class,

        // models – ndb base
        CorporateEntitiesTest.class,
        IndividualMPINRequestTest.class,
        IndividualMPINResponseTest.class,
        com.optum.providerpreferences.rs.model.ndb.CorporateTest.class,
        NDBProviderTest.class,
        NDBProvidersTest.class,
        ProviderOrganizationTest.class,
        ProviderOrganizationsTest.class,
        com.optum.providerpreferences.rs.model.ndb.TinTest.class,
        TinsTest.class,

        // models – ndb preferences
        LetterPreferencesRequestTest.class,
        LetterPreferencesResponseTest.class,
        LetterTypeTest.class,
        MailPrefTest.class,
        com.optum.providerpreferences.rs.model.ndb.preferences.RequestDataTest.class,
        com.optum.providerpreferences.rs.model.ndb.preferences.RequestHeaderTest.class,
        ResponseDataTest.class,
        ResponseHeaderTest.class,
        UILetterPreferencesRequestTest.class,

        // models – ndb provider
        CorpMpinRequestTest.class,
        CorpMpinResponseTest.class,
        MpinDataTest.class,
        com.optum.providerpreferences.rs.model.ndb.provider.RequestDataTest.class,
        com.optum.providerpreferences.rs.model.ndb.provider.RequestHeaderTest.class,

        // models – optout
        OptOutAuditMetadataTest.class,
        OptOutAuditUpdateTest.class,
        OptOutFDSCloudDocumentTest.class,
        OptOutFDSCloudPOSTRequestTest.class,
        OptOutFDSCloudPOSTResponseTest.class,
        OptOutRequestTest.class,
        OptOutTinRequestTest.class,
        OptOutTinResponseTest.class,

        // models – pes
        KeyTest.class,
        MetaTest.class,
        PESCorpmpinRequestTest.class,
        PESResponseTest.class,
        PESTinRequestTest.class,
        TinObjectTest.class,

        // services
        PaymentPreferenceServiceTest.class,
        PaymentPreferenceServiceImplTest.class,
        AutoenrollmentServiceImplTest.class,
        OptOutServiceImplTest.class,
        ProviderPreferenceServiceImplTest.class,
        DigitalSecurityServiceImplTest.class,

        // utilities
        ApplicationUtilTest.class,
        ClassifierDescriptionTest.class,
        ConstantsTest.class,
        ConverterTest.class,
        MessageBuilderTest.class,
        PasswordOwnerUtilTest.class,
})
public class AutoenrollmentTestSuite extends TestCase {
}
