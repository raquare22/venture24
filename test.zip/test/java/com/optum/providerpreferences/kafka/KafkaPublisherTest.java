package com.optum.providerpreferences.kafka;

import com.optum.eis.kraken.core.NessLog;
import com.optum.eis.kraken.core.exceptions.NessLoggerValidationException;
import com.optum.eis.kraken.kafka.producers.NessKafkaProducer;
import org.junit.After;
import org.junit.Test;
import sun.misc.Unsafe;

import java.lang.reflect.Field;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class KafkaPublisherTest {

    private NessKafkaProducer originalProducer;

    @After
    public void tearDown() throws Exception {
        // Restore original producer after each test that overrides it
        if (originalProducer != null) {
            setStaticFieldUnsafe(KafkaPublisher.class, "nessKafkaProducer", originalProducer);
            originalProducer = null;
        }
    }

    @Test
    public void testGetKafkaProducerReturnsInitializedInstance() {
        KafkaPublisher publisher = new KafkaPublisher();

        KafkaProducer producer = publisher.getKafkaProducer();

        assertNotNull(producer);
    }

    @Test
    public void testGetKafkaProducerSharedAcrossInstances() {
        KafkaPublisher publisher1 = new KafkaPublisher();
        KafkaPublisher publisher2 = new KafkaPublisher();

        KafkaProducer producer1 = publisher1.getKafkaProducer();
        KafkaProducer producer2 = publisher2.getKafkaProducer();

        assertSame(producer1, producer2);
    }

    @Test
    public void testPublishToKafkaDoesNotThrow() {
        KafkaPublisher publisher = new KafkaPublisher();
        NessLog log = mock(NessLog.class);

        publisher.publishToKafka(log);
    }

    @Test
    public void testCloseNessProducerDoesNotThrow() {
        KafkaPublisher publisher = new KafkaPublisher();

        publisher.closeNessProducer();
    }

    @Test
    public void testPublishToKafkaCallsPublishNessLogsWhenProducerNotNull() throws Exception {
        NessKafkaProducer mockProducer = mock(NessKafkaProducer.class);
        originalProducer = injectMockProducer(mockProducer);

        NessLog log = mock(NessLog.class);

        new KafkaPublisher().publishToKafka(log);

        verify(mockProducer).publishNessLogs(log);
    }

    @Test
    public void testPublishToKafkaLogsErrorOnNessLoggerValidationException() throws Exception {
        NessKafkaProducer mockProducer = mock(NessKafkaProducer.class);
        originalProducer = injectMockProducer(mockProducer);

        NessLog log = mock(NessLog.class);
        doThrow(new NessLoggerValidationException("validation error")).when(mockProducer).publishNessLogs(any(NessLog.class));

        // Should not throw - exception is caught and logged
        new KafkaPublisher().publishToKafka(log);

        verify(mockProducer).publishNessLogs(log);
    }

    @Test
    public void testCloseNessProducerCallsCloseWhenProducerNotNull() throws Exception {
        NessKafkaProducer mockProducer = mock(NessKafkaProducer.class);
        originalProducer = injectMockProducer(mockProducer);

        new KafkaPublisher().closeNessProducer();

        verify(mockProducer).closeNessProducer();
    }

    /**
     * Injects a mock NessKafkaProducer into KafkaPublisher's static final field using Unsafe,
     * which works on Java 17 without needing --add-opens flags.
     * Returns the original value so it can be restored afterwards.
     */
    private static NessKafkaProducer injectMockProducer(NessKafkaProducer mock) throws Exception {
        Field field = KafkaPublisher.class.getDeclaredField("nessKafkaProducer");
        field.setAccessible(true);
        NessKafkaProducer original = (NessKafkaProducer) field.get(null);
        setStaticFieldUnsafe(KafkaPublisher.class, "nessKafkaProducer", mock);
        return original;
    }

    private static void setStaticFieldUnsafe(Class<?> clazz, String fieldName, Object value) throws Exception {
        Field unsafeField = Unsafe.class.getDeclaredField("theUnsafe");
        unsafeField.setAccessible(true);
        Unsafe unsafe = (Unsafe) unsafeField.get(null);

        Field field = clazz.getDeclaredField(fieldName);
        Object staticFieldBase = unsafe.staticFieldBase(field);
        long staticFieldOffset = unsafe.staticFieldOffset(field);
        unsafe.putObject(staticFieldBase, staticFieldOffset, value);
    }
}

