package com.optum.providerpreferences.kafka;

import org.junit.Test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

public class EnvironmentsTest {

    @Test
    public void testEnumOrderAndValues() {
        Environments[] expected = {
            Environments.LOCAL,
            Environments.DEV,
            Environments.STAGE,
            Environments.PROD
        };

        assertArrayEquals(expected, Environments.values());
    }

    @Test
    public void testGetEnvMappings() {
        assertEquals("local", Environments.LOCAL.getEnv());
        assertEquals("dev", Environments.DEV.getEnv());
        assertEquals("stage", Environments.STAGE.getEnv());
        assertEquals("prod", Environments.PROD.getEnv());
    }

    @Test
    public void testValueOfConstants() {
        assertEquals(Environments.LOCAL, Environments.valueOf("LOCAL"));
        assertEquals(Environments.DEV, Environments.valueOf("DEV"));
        assertEquals(Environments.STAGE, Environments.valueOf("STAGE"));
        assertEquals(Environments.PROD, Environments.valueOf("PROD"));
    }
}

