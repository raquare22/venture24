package com.optum.providerpreferences.kafka;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class ConfigDataTest {

    private ConfigData configData;

    @Before
    public void setUp() {
        configData = new ConfigData();

        // Reset static fields for test isolation.
        ConfigData.brokers = null;
        ConfigData.topic = null;
        ConfigData.location = null;
        ConfigData.pvFileLoc = null;
        ConfigData.pw = null;
        ConfigData.askId = null;
        ConfigData.appName = null;
        ConfigData.vendor = null;
        ConfigData.product = null;
        ConfigData.producerType = null;
    }

    @Test
    public void testDefaultsAreNull() {
        assertNull(configData.getBrokers());
        assertNull(configData.getTopic());
        assertNull(configData.getLocation());
        assertNull(configData.getPvFileLoc());
        assertNull(configData.getPw());
        assertNull(configData.getAskId());
        assertNull(configData.getAppName());
        assertNull(configData.getVendor());
        assertNull(configData.getProduct());
        assertNull(configData.getProducerType());
    }

    @Test
    public void testSettersAndGetters() {
        configData.setBrokers("broker1:9092");
        configData.setTopic("topic-a");
        configData.setLocation("/tmp/location");
        configData.setPvFileLoc("/tmp/pv.file");
        configData.setPw("secret");
        configData.setAskId("ask-id");
        configData.setAppName("pdo-app");
        configData.setVendor("optum");
        configData.setProduct("provider-preferences");
        configData.setProducerType("kafka");

        assertEquals("broker1:9092", configData.getBrokers());
        assertEquals("topic-a", configData.getTopic());
        assertEquals("/tmp/location", configData.getLocation());
        assertEquals("/tmp/pv.file", configData.getPvFileLoc());
        assertEquals("secret", configData.getPw());
        assertEquals("ask-id", configData.getAskId());
        assertEquals("pdo-app", configData.getAppName());
        assertEquals("optum", configData.getVendor());
        assertEquals("provider-preferences", configData.getProduct());
        assertEquals("kafka", configData.getProducerType());
    }

    @Test
    public void testSettersOverwriteValues() {
        configData.setTopic("old-topic");
        assertEquals("old-topic", configData.getTopic());

        configData.setTopic("new-topic");
        assertEquals("new-topic", configData.getTopic());
    }

    @Test
    public void testStaticBackingFieldsSharedAcrossInstances() {
        ConfigData another = new ConfigData();

        configData.setBrokers("shared-broker");
        another.setTopic("shared-topic");

        assertEquals("shared-broker", another.getBrokers());
        assertEquals("shared-topic", configData.getTopic());
    }
}

