package com.optum.providerpreferences.kafka;

import com.optum.eis.kraken.core.NessLog;
import com.optum.eis.kraken.kafka.producers.NessKafkaAsyncProducer;
import com.optum.eis.event.model.outcome;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.net.InetSocketAddress;
import java.lang.reflect.Field;
import java.util.Properties;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class NessAppLogTest {

    @Before
    public void setUp() throws Exception {
        // NessAppLog static init writes these into Properties; null values throw NPE.
        ConfigData.askId = "123456";
        ConfigData.appName = "app-name";
        ConfigData.vendor = "vendor";
        ConfigData.product = "product";

        // Keep tests isolated from real Kafka setup during class initialization.
        KafkaProducer.setUpOff();

        // Refresh the static requiredFields with the corrected ConfigData values so
        // that NessLog.buildLog() receives a valid ASK ID on every test run.
        NessAppLog.requiredFields.clear();
        NessAppLog.requiredFields.putAll(NessAppLog.getNewRequiredFields());

        setStaticField("shutdown", false);
        setStaticField("kafkaPublisher", null);
        setStaticField("kafkaProducer", null);
        setStaticField("kafkaAsyncProducer", null);
        setStaticField("applicationEnvironment", null);
    }

    @After
    public void tearDown() throws Exception {
        // Restore default setup state for any other tests.
        setKafkaSetupFlag(true);
    }

    @Test
    public void testPublishLogReturnsWhenShutdownTrue() throws Exception {
        KafkaPublisher publisher = mock(KafkaPublisher.class);
        NessKafkaAsyncProducer asyncProducer = mock(NessKafkaAsyncProducer.class);
        NessLog nessLog = mock(NessLog.class);

        setStaticField("shutdown", true);
        setStaticField("kafkaPublisher", publisher);
        setStaticField("kafkaAsyncProducer", asyncProducer);

        NessAppLog.publishLog(nessLog);

        verify(publisher, never()).publishToKafka(nessLog);
        verify(asyncProducer, never()).publishNessLogsAsync(nessLog);
    }

    @Test
    public void testPublishLogUsesKafkaPublisherWhenAvailable() throws Exception {
        KafkaPublisher publisher = mock(KafkaPublisher.class);
        NessLog nessLog = mock(NessLog.class);

        setStaticField("shutdown", false);
        setStaticField("kafkaPublisher", publisher);
        setStaticField("kafkaAsyncProducer", null);

        NessAppLog.publishLog(nessLog);

        verify(publisher, times(1)).publishToKafka(nessLog);
    }

    @Test
    public void testPublishLogUsesKafkaAsyncProducerWhenPublisherAbsent() throws Exception {
        NessKafkaAsyncProducer asyncProducer = mock(NessKafkaAsyncProducer.class);
        NessLog nessLog = mock(NessLog.class);

        setStaticField("shutdown", false);
        setStaticField("kafkaPublisher", null);
        setStaticField("kafkaAsyncProducer", asyncProducer);

        NessAppLog.publishLog(nessLog);

        verify(asyncProducer, times(1)).publishNessLogsAsync(nessLog);
    }

    @Test
    public void testPublishLogNoopWhenNoPublishersConfigured() throws Exception {
        NessLog nessLog = mock(NessLog.class);
        setStaticField("shutdown", false);
        setStaticField("kafkaPublisher", null);
        setStaticField("kafkaAsyncProducer", null);

        NessAppLog.publishLog(nessLog);
        // No exception and no verification target means branch executed safely.
    }

    @Test
    public void testStartupPublishesViaKafkaPublisher() throws Exception {
        KafkaPublisher publisher = mock(KafkaPublisher.class);

        setStaticField("shutdown", false);
        setStaticField("kafkaPublisher", publisher);
        setStaticField("kafkaAsyncProducer", null);

        NessAppLog.startup();

        verify(publisher, times(1)).publishToKafka(org.mockito.ArgumentMatchers.any(NessLog.class));
    }

    @Test
    public void testShutdownClosesKafkaPublisherAndMarksShutdown() throws Exception {
        KafkaPublisher publisher = mock(KafkaPublisher.class);
        KafkaProducer producer = mock(KafkaProducer.class);
        when(publisher.getKafkaProducer()).thenReturn(producer);

        setStaticField("shutdown", false);
        setStaticField("kafkaPublisher", publisher);
        setStaticField("kafkaAsyncProducer", null);

        NessAppLog.shutdown();

        verify(publisher, times(1)).publishToKafka(org.mockito.ArgumentMatchers.any(NessLog.class));
        verify(publisher, times(1)).closeNessProducer();
        verify(producer, times(1)).deleteStreamFile();
        assertEquals(true, getStaticField("shutdown"));
    }

    @Test
    public void testShutdownClosesKafkaAsyncProducerAndDeletesStream() throws Exception {
        NessKafkaAsyncProducer asyncProducer = mock(NessKafkaAsyncProducer.class);
        KafkaProducer producer = mock(KafkaProducer.class);

        setStaticField("shutdown", false);
        setStaticField("kafkaPublisher", null);
        setStaticField("kafkaAsyncProducer", asyncProducer);
        setStaticField("kafkaProducer", producer);

        NessAppLog.shutdown();

        verify(asyncProducer, times(1)).publishNessLogsAsync(org.mockito.ArgumentMatchers.any(NessLog.class));
        verify(asyncProducer, times(1)).closeNessAsyncProducer();
        verify(producer, times(1)).deleteStreamFile();
        assertEquals(true, getStaticField("shutdown"));
    }

    @Test
    public void testCreateHttpLogEventStringSuccessAndFailure() throws Exception {
        KafkaPublisher publisher = mock(KafkaPublisher.class);
        setStaticField("shutdown", false);
        setStaticField("kafkaPublisher", publisher);
        setStaticField("kafkaAsyncProducer", null);

        HttpHeaders headers = new HttpHeaders();
        headers.setHost(new InetSocketAddress("localhost", 8080));

        NessAppLog.createHttpLogEvent(headers, "m1", "response-body", true);
        NessAppLog.createHttpLogEvent(headers, "m2", "error-body", false);

        verify(publisher, times(2)).publishToKafka(org.mockito.ArgumentMatchers.any(NessLog.class));
    }

    @Test
    public void testCreateHttpLogEventResponseEntitySuccessAndFailure() throws Exception {
        KafkaPublisher publisher = mock(KafkaPublisher.class);
        setStaticField("shutdown", false);
        setStaticField("kafkaPublisher", publisher);
        setStaticField("kafkaAsyncProducer", null);

        HttpHeaders headers = new HttpHeaders();
        headers.setHost(new InetSocketAddress("localhost", 9090));

        NessAppLog.createHttpLogEvent(headers, "ok", new ResponseEntity<>("ok", HttpStatus.OK));
        NessAppLog.createHttpLogEvent(headers, "fail", new ResponseEntity<>("bad", HttpStatus.BAD_REQUEST));
        NessAppLog.createHttpLogEvent(headers, "null", (ResponseEntity<?>) null);

        verify(publisher, times(3)).publishToKafka(org.mockito.ArgumentMatchers.any(NessLog.class));
    }

    @Test
    public void testGetNessLogBuilderProducesLogWithConfiguredOutcome() {
        NessLog log = NessAppLog.getNessLogBuilder().setOutcome(outcome.SUCCESS).setMsg("test").buildLog();
        assertNotNull(log);
        assertNotNull(log.getLog());
    }

    @Test
    public void testGetNewRequiredFieldsWhenSetupOff() throws Exception {
        setKafkaSetupFlag(false);
        ConfigData.producerType = "sync";

        Properties properties = NessAppLog.getNewRequiredFields();

        assertNotNull(properties);
        assertTrue(properties.size() >= 4);
    }

    @Test
    public void testGetNewRequiredFieldsSetupOnSyncAndAsyncBranches() throws Exception {
        setKafkaSetupFlag(true);

        ConfigData.producerType = null;
        Properties syncProps = NessAppLog.getNewRequiredFields();
        assertNotNull(syncProps);
        assertNotNull(getStaticField("kafkaPublisher"));

        ConfigData.producerType = "async";
        Properties asyncProps = NessAppLog.getNewRequiredFields();
        assertNotNull(asyncProps);
        assertNotNull(getStaticField("kafkaProducer"));
    }

    private void setStaticField(String fieldName, Object value) throws Exception {
        Field field = NessAppLog.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(null, value);
    }

    private Object getStaticField(String fieldName) throws Exception {
        Field field = NessAppLog.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(null);
    }

    private void setKafkaSetupFlag(boolean value) throws Exception {
        Field field = KafkaProducer.class.getDeclaredField("setUp");
        field.setAccessible(true);
        field.set(null, value);
    }
}
