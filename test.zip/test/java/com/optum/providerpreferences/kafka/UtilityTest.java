package com.optum.providerpreferences.kafka;

import org.junit.After;
import org.junit.Test;

import java.lang.reflect.Field;

import static org.junit.Assert.assertEquals;

public class UtilityTest {

    @After
    public void tearDown() throws Exception {
        setActiveProfile(null);
    }

    @Test
    public void testGetEnvironmentReturnsLocalWhenProfileIsNull() throws Exception {
        setActiveProfile(null);

        assertEquals("local", Utility.getEnvironment());
    }

    @Test
    public void testGetEnvironmentReturnsDevWhenProfileIsDev() throws Exception {
        setActiveProfile("dev");

        assertEquals("dev", Utility.getEnvironment());
    }

    @Test
    public void testGetEnvironmentReturnsStageWhenProfileIsStage() throws Exception {
        setActiveProfile("stage");

        assertEquals("stage", Utility.getEnvironment());
    }

    @Test
    public void testGetEnvironmentReturnsProdWhenProfileIsProd() throws Exception {
        setActiveProfile("prod");

        assertEquals("prod", Utility.getEnvironment());
    }

    @Test
    public void testGetEnvironmentReturnsLocalWhenProfileIsInvalid() throws Exception {
        setActiveProfile("qa");

        assertEquals("local", Utility.getEnvironment());
    }

    @Test
    public void testGetEnvironmentReturnsLocalWhenProfileHasDifferentCase() throws Exception {
        setActiveProfile("DEV");

        assertEquals("local", Utility.getEnvironment());
    }

    private void setActiveProfile(String value) throws Exception {
        Field field = Utility.class.getDeclaredField("activeProfile");
        field.setAccessible(true);
        field.set(null, value);
    }
}

