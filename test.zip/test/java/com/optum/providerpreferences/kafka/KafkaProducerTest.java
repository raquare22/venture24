package com.optum.providerpreferences.kafka;

import com.optum.eis.kraken.kafka.producers.NessKafkaAsyncProducer;
import com.optum.eis.kraken.kafka.producers.NessKafkaProducer;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

public class KafkaProducerTest {

    @Before
    public void setUp() throws Exception {
        // Reset static config state for deterministic tests.
        ConfigData.brokers = null;
        ConfigData.topic = null;
        ConfigData.location = null;
        ConfigData.pvFileLoc = null;
        ConfigData.pw = null;
        ConfigData.askId = null;
        ConfigData.appName = null;
        ConfigData.vendor = null;
        ConfigData.product = null;
        ConfigData.producerType = null;

        Field setupField = KafkaProducer.class.getDeclaredField("setUp");
        setupField.setAccessible(true);
        setupField.set(null, true);
    }

    @Test
    public void testSetUpOffAndGetSetUp() {
        assertTrue(KafkaProducer.getSetUp());
        KafkaProducer.setUpOff();
        assertFalse(KafkaProducer.getSetUp());
    }

    @Test
    public void testGetNessKafkaProducerReturnsNullWhenConfigMissing() {
        KafkaProducer producer = new KafkaProducer();
        assertNull(producer.getNessKafkaProducer());
    }

    @Test
    public void testGetNewNessKafkaAsyncProducerReturnsNullWhenConfigMissing() {
        KafkaProducer producer = new KafkaProducer();
        assertNull(producer.getNewNessKafkaAsyncProducer());
    }

    @Test
    public void testCreateFileFromStreamWritesBytes() throws Exception {
        Path tempDir = Files.createTempDirectory("kafka-producer-test");
        byte[] payload = "keystore-bytes".getBytes();

        File output = KafkaProducer.createFileFromStream(new ByteArrayInputStream(payload), tempDir.toString());

        assertNotNull(output);
        assertTrue(output.exists());
        assertArrayEquals(payload, Files.readAllBytes(output.toPath()));
    }

    @Test
    public void testGetNessKafkaKeystoreFileReturnsNullForMissingResource() throws Exception {
        KafkaProducer producer = new KafkaProducer();
        Path tempDir = Files.createTempDirectory("kafka-producer-missing-resource");

        File result = producer.getNessKafkaKeystoreFile("missing/resource/cert.jks", tempDir.toString());

        assertNull(result);
    }

    @Test
    public void testDeleteStreamFileDeletesFile() throws Exception {
        KafkaProducer producer = new KafkaProducer();
        Path file = Files.createTempFile("stream-file", ".jks");

        Field streamField = KafkaProducer.class.getDeclaredField("streamFile");
        streamField.setAccessible(true);
        streamField.set(producer, file.toFile());

        producer.deleteStreamFile();

        assertFalse(Files.exists(file));
    }

    @Test
    public void testGetNewNessKafkaProducerUsesResolvedConfig() {
        ConfigData.brokers = "broker:9092";
        ConfigData.topic = "topic-a";
        ConfigData.location = "any-resource";
        ConfigData.pvFileLoc = "/tmp";
        ConfigData.pw = "secret";
        ConfigData.askId = "ask-id";

        TestKafkaProducer producer = new TestKafkaProducer();
        NessKafkaProducer mockSync = mock(NessKafkaProducer.class);
        producer.syncToReturn = mockSync;

        NessKafkaProducer result = producer.getNewNessKafkaProducer();

        assertEquals(mockSync, result);
        assertEquals("broker:9092", producer.capturedBrokers);
        assertEquals("topic-a", producer.capturedTopic);
        assertEquals("secret", producer.capturedPw);
        assertEquals("ask-id", producer.capturedAskId);
        assertTrue(producer.capturedLoc.endsWith("cert.jks"));
    }

    @Test
    public void testGetNewNessKafkaAsyncProducerUsesResolvedConfig() {
        ConfigData.brokers = "broker:9092";
        ConfigData.topic = "topic-a";
        ConfigData.location = "any-resource";
        ConfigData.pvFileLoc = "/tmp";
        ConfigData.pw = "secret";
        ConfigData.askId = "ask-id";

        TestKafkaProducer producer = new TestKafkaProducer();
        NessKafkaAsyncProducer mockAsync = mock(NessKafkaAsyncProducer.class);
        producer.asyncToReturn = mockAsync;

        NessKafkaAsyncProducer result = producer.getNewNessKafkaAsyncProducer();

        assertEquals(mockAsync, result);
        assertEquals("broker:9092", producer.capturedBrokers);
        assertEquals("topic-a", producer.capturedTopic);
        assertEquals("secret", producer.capturedPw);
        assertEquals("ask-id", producer.capturedAskId);
        assertTrue(producer.capturedLoc.endsWith("cert.jks"));
    }

    private static class TestKafkaProducer extends KafkaProducer {
        NessKafkaProducer syncToReturn;
        NessKafkaAsyncProducer asyncToReturn;

        String capturedBrokers;
        String capturedTopic;
        String capturedLoc;
        String capturedPw;
        String capturedAskId;

        @Override
        protected File getNessKafkaKeystoreFile(String nkLoc, String nkPvFileLoc) {
            return new File(nkPvFileLoc + File.separator + "cert.jks");
        }

        @Override
        protected NessKafkaProducer getNewNessKafkaSyncProducer(String nkBrokers, String nkTopic, String nkLoc, String nkPw, String askId) {
            this.capturedBrokers = nkBrokers;
            this.capturedTopic = nkTopic;
            this.capturedLoc = nkLoc;
            this.capturedPw = nkPw;
            this.capturedAskId = askId;
            return syncToReturn;
        }

        @Override
        protected NessKafkaAsyncProducer getNewNessKafkaAsyncProducer(String nkBrokers, String nkTopic, String nkLoc, String nkPw, String askId) {
            this.capturedBrokers = nkBrokers;
            this.capturedTopic = nkTopic;
            this.capturedLoc = nkLoc;
            this.capturedPw = nkPw;
            this.capturedAskId = askId;
            return asyncToReturn;
        }
    }

    @Test
    public void testGetNessKafkaProducerReturnsCachedInstanceWhenNotNull() {
        KafkaProducer producer = new KafkaProducer();
        NessKafkaProducer mockProducer = mock(NessKafkaProducer.class);
        
        // Set the cached producer
        try {
            Field field = KafkaProducer.class.getDeclaredField("nessKafkaProducer");
            field.setAccessible(true);
            field.set(producer, mockProducer);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }

        NessKafkaProducer result = producer.getNessKafkaProducer();

        assertEquals(mockProducer, result);
    }

    @Test
    public void testDeleteStreamFileLogsWhenFileDeletionFails() throws Exception {
        KafkaProducer producer = new KafkaProducer();
        // Create a mock file that won't delete
        File mockFile = new File("/nonexistent/path/that/cannot/be/deleted");

        Field streamField = KafkaProducer.class.getDeclaredField("streamFile");
        streamField.setAccessible(true);
        streamField.set(producer, mockFile);

        // This should not throw - deleteStreamFile logs the failure
        producer.deleteStreamFile();
    }

    @Test
    public void testGetNessKafkaKeystoreFileHandlesIOExceptionDuringStreamOpen() throws Exception {
        KafkaProducer producer = new KafkaProducer();
        Path tempDir = Files.createTempDirectory("kafka-producer-ioex");

        // Pass a resource that doesn't exist - will throw NullPointerException in openStream
        File result = producer.getNessKafkaKeystoreFile("nonexistent/path/to/cert.jks", tempDir.toString());

        assertNull(result);
    }

//    @Test
//    public void testGetNewNessKafkaSyncProducerReturnsNullOnNessLoggerValidationException() {
//        TestKafkaProducerThrowingSync producer = new TestKafkaProducerThrowingSync();
//        ConfigData.brokers = "broker:9092";
//        ConfigData.topic = "topic-a";
//        ConfigData.location = "kafka/cert.jks";
//        ConfigData.pvFileLoc = "/tmp";
//        ConfigData.pw = "secret";
//        ConfigData.askId = "ask-id";
//
//        NessKafkaProducer result = producer.getNewNessKafkaProducer();
//
//        assertNull(result);
//    }

//    @Test
//    public void testGetNewNessKafkaAsyncProducerReturnsNullOnNessLoggerValidationException() {
//        TestKafkaProducerThrowingAsync producer = new TestKafkaProducerThrowingAsync();
//        ConfigData.brokers = "broker:9092";
//        ConfigData.topic = "topic-a";
//        ConfigData.location = "kafka/cert.jks";
//        ConfigData.pvFileLoc = "/tmp";
//        ConfigData.pw = "secret";
//        ConfigData.askId = "ask-id";
//
//        NessKafkaAsyncProducer result = producer.getNewNessKafkaAsyncProducer();
//
//        assertNull(result);
//    }

    private static class TestKafkaProducerThrowingSync extends KafkaProducer {
        @Override
        protected File getNessKafkaKeystoreFile(String nkLoc, String nkPvFileLoc) {
            return new File(nkPvFileLoc + File.separator + "cert.jks");
        }

        @Override
        protected NessKafkaProducer getNewNessKafkaSyncProducer(String nkBrokers, String nkTopic, String nkLoc, String nkPw, String askId) {
            throw new com.optum.eis.kraken.core.exceptions.NessLoggerValidationException("Test exception");
        }
    }

    private static class TestKafkaProducerThrowingAsync extends KafkaProducer {
        @Override
        protected File getNessKafkaKeystoreFile(String nkLoc, String nkPvFileLoc) {
            return new File(nkPvFileLoc + File.separator + "cert.jks");
        }

        @Override
        protected NessKafkaAsyncProducer getNewNessKafkaAsyncProducer(String nkBrokers, String nkTopic, String nkLoc, String nkPw, String askId) {
            throw new com.optum.eis.kraken.core.exceptions.NessLoggerValidationException("Test exception");
        }
    }
}
