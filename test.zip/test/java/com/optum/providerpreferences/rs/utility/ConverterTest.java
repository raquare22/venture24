package com.optum.providerpreferences.rs.utility;

import org.junit.Test;

import java.text.ParseException;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ConverterTest {

    @Test
    public void convertNullToStringShouldHandleNullAndTrim() {
        assertEquals("", Converter.convertNullToString(null));
        assertEquals("abc", Converter.convertNullToString("  abc  "));
    }

    @Test
    public void convertStringToDateShouldParseExpectedFormat() throws ParseException {
        Date date = Converter.convertStringToDate("Tue May 21 12:34:56 UTC 2024");
        assertNotNull(date);
    }

    @Test(expected = ParseException.class)
    public void convertStringToDateShouldThrowOnInvalidInput() throws ParseException {
        Converter.convertStringToDate("not-a-date");
    }
}

