package com.optum.providerpreferences.rs.utility;

import com.optum.providerpreferences.rs.model.logging.LogMessage;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class MessageBuilderTest {

    @Test
    public void buildShouldPopulateActorFields() {
        MessageBuilder builder = new MessageBuilder();

        LogMessage message = builder.build("10.0.0.1", "actor", "user1");

        assertNotNull(message);
        assertEquals("10.0.0.1", message.getActorIp());
        assertEquals("actor", message.getActor());
        assertEquals("user1", message.getUsername());
    }
}

