package com.optum.providerpreferences.rs.utility;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class ApplicationUtilTest {

    @Test
    public void isNotNullShouldReturnExpectedValues() {
        assertTrue(ApplicationUtil.isNotNull("x"));
        assertFalse(ApplicationUtil.isNotNull(null));
    }

    @Test
    public void getServerDateShouldReturnUtcIsoLikeValue() {
        String value = ApplicationUtil.getServerDate();

        assertNotNull(value);
        assertTrue(value.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z"));
    }

    @Test
    public void rerStatusHelpersShouldAppendExpectedSuffix() {
        ApplicationUtil util = new ApplicationUtil();

        assertEquals("msg, RERstatus=SUCCESS", util.rerSuccess("msg"));
        assertEquals("msg, RERstatus=FAILURE", util.rerFailure("msg"));
    }

    @Test
    public void parseWithDefaultShouldUseParsedOrFallback() {
        assertEquals(42, ApplicationUtil.parseWithDefault("42", 7));
        assertEquals(7, ApplicationUtil.parseWithDefault("abc", 7));
    }
}

