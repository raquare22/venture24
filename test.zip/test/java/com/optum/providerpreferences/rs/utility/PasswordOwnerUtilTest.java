package com.optum.providerpreferences.rs.utility;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.PasswordOwnerInfo;
import com.optum.providerpreferences.rs.model.linksecurity.User;
import org.junit.Test;

import java.util.Collections;

import static org.junit.Assert.assertEquals;

public class PasswordOwnerUtilTest {

    @Test
    public void compilePasswordOwnerInfoShouldReturnMatchedCorporate() throws Exception {
        PasswordOwnerUtil util = new PasswordOwnerUtil();

        PasswordOwnerInfo ownerInfo = new PasswordOwnerInfo();
        ownerInfo.setUhcID("UHC1");
        ownerInfo.setMpin("123456789");

        User profile = new User();
        profile.setUserAcctSeqNbr("UHC1");
        profile.setRespOrgMpin("123456789");

        PasswordOwner result = util.compilePasswordOwnerInfo(
                "uuid-1",
                Collections.singletonList(ownerInfo),
                Collections.singletonList(profile),
                "session-1");

        assertEquals("uuid-1", result.getOptumUUID());
        assertEquals(1, result.getCorporates().size());
        assertEquals("UHC1", result.getCorporates().get(0).getUhcID());
    }

    @Test(expected = ApplicationException.class)
    public void compilePasswordOwnerInfoShouldThrowWhenNoMatches() throws Exception {
        PasswordOwnerUtil util = new PasswordOwnerUtil();

        PasswordOwnerInfo ownerInfo = new PasswordOwnerInfo();
        ownerInfo.setUhcID("UHC1");
        ownerInfo.setMpin("123456789");

        User profile = new User();
        profile.setUserAcctSeqNbr("DIFFERENT");
        profile.setRespOrgMpin("000000000");

        util.compilePasswordOwnerInfo(
                "uuid-1",
                Collections.singletonList(ownerInfo),
                Collections.singletonList(profile),
                "session-1");
    }
}

