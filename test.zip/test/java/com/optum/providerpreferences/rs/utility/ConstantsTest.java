package com.optum.providerpreferences.rs.utility;

import org.junit.Test;

import java.lang.reflect.Constructor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ConstantsTest {

    @Test
    public void constantsShouldMatchExpectedValues() {
        assertEquals("update-prefs-amq", Constants.UPDATE_PREFS_QUEUE);
        assertEquals("admin", Constants.USERNAME);
    }

    @Test
    public void privateConstructorShouldBeAccessibleViaReflectionForCoverage() throws Exception {
        Constructor<Constants> ctor = Constants.class.getDeclaredConstructor();
        assertTrue((ctor.getModifiers() & java.lang.reflect.Modifier.PRIVATE) != 0);
        ctor.setAccessible(true);
        ctor.newInstance();
    }
}

