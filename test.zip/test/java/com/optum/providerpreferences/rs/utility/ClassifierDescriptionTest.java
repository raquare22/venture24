package com.optum.providerpreferences.rs.utility;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class ClassifierDescriptionTest {

    @Test
    public void classifierDescriptionShouldReturnKnownValue() {
        assertEquals("Detailed PRAs", ClassifierDescription.getClassifierDescription("P1"));
        assertEquals("House Calls - Post Assessment Letters", ClassifierDescription.getClassifierDescription("H1"));
    }

    @Test
    public void lobShouldReturnKnownValue() {
        assertEquals("Commercial", ClassifierDescription.getLob("P1"));
        assertEquals("House Calls", ClassifierDescription.getLob("H1"));
    }

    @Test
    public void unknownClassifierShouldReturnNull() {
        assertNull(ClassifierDescription.getClassifierDescription("ZZ"));
        assertNull(ClassifierDescription.getLob("ZZ"));
    }

    @Test
    public void classifierMapShouldContainExpectedEntries() {
        assertTrue(ClassifierDescription.classifierDescriptionHash.containsKey("E2"));
        assertTrue(ClassifierDescription.classifierDescriptionHash.containsKey("M7"));
    }
}

