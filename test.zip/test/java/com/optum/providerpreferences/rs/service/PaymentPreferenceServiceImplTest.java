package com.optum.providerpreferences.rs.service;

import com.optum.providerpreferences.rs.model.PaymentPreference;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.*;
import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

@RunWith(MockitoJUnitRunner.class)
public class PaymentPreferenceServiceImplTest {


    @Mock
    private MongoTemplate mongoTemplate;

    @InjectMocks
    PaymentPreferenceServiceImpl paymentPreferenceService;

    private PaymentPreference doc;

    @Before
    public void setUp() {
        doc = new PaymentPreference();
        doc.setId("testId");
        doc.setTin("451230492");
        doc.setPaymentpref("ACH");
        doc.setMpin("9358938");
        doc.setUpdatedBy("abc");
    }

    @Test
    public void testInsertPaymentPreference() {
        when(mongoTemplate.insert(any(PaymentPreference.class), anyString())).thenReturn(doc);
        PaymentPreference result = paymentPreferenceService.insertPaymentPreference(doc);
        assertNotNull(result);
        assertEquals("testId", result.getId());
    }

    @Test
    public void testInsertPaymentPreferenceInsertsWhenIdNull() {
        PaymentPreference newDoc = new PaymentPreference();
        newDoc.setId(null);
        newDoc.setTin("123456789");

        when(mongoTemplate.insert(newDoc, "paymentPreference")).thenReturn(newDoc);

        PaymentPreference result = paymentPreferenceService.insertPaymentPreference(newDoc);

        assertSame(newDoc, result);
        verify(mongoTemplate, times(1)).insert(newDoc, "paymentPreference");
        verify(mongoTemplate, never()).findOne(any(), eq(PaymentPreference.class), anyString());
        verify(mongoTemplate, never()).save(any(PaymentPreference.class), anyString());
    }

    @Test
    public void testInsertPaymentPreferenceInsertsWhenIdEmpty() {
        PaymentPreference newDoc = new PaymentPreference();
        newDoc.setId("");

        when(mongoTemplate.insert(newDoc, "paymentPreference")).thenReturn(newDoc);

        PaymentPreference result = paymentPreferenceService.insertPaymentPreference(newDoc);

        assertSame(newDoc, result);
        verify(mongoTemplate, times(1)).insert(newDoc, "paymentPreference");
    }

    @Test
    public void testInsertPaymentPreferenceSavesWhenExistingDocumentFound() {
        when(mongoTemplate.findOne(query(where("id").is(doc.getId())), PaymentPreference.class, "paymentPreference"))
                .thenReturn(doc);

        PaymentPreference result = paymentPreferenceService.insertPaymentPreference(doc);

        assertSame(doc, result);
        verify(mongoTemplate, times(1)).findOne(query(where("id").is(doc.getId())), PaymentPreference.class, "paymentPreference");
        verify(mongoTemplate, times(1)).save(doc, "paymentPreference");
        verify(mongoTemplate, never()).insert(doc, "paymentPreference");
    }

    @Test
    public void testInsertPaymentPreferenceInsertsWhenExistingDocumentNotFound() {
        when(mongoTemplate.findOne(query(where("id").is(doc.getId())), PaymentPreference.class, "paymentPreference"))
                .thenReturn(null);
        when(mongoTemplate.insert(doc, "paymentPreference")).thenReturn(doc);

        PaymentPreference result = paymentPreferenceService.insertPaymentPreference(doc);

        assertSame(doc, result);
        verify(mongoTemplate, times(1)).findOne(query(where("id").is(doc.getId())), PaymentPreference.class, "paymentPreference");
        verify(mongoTemplate, times(1)).insert(doc, "paymentPreference");
        verify(mongoTemplate, never()).save(doc, "paymentPreference");
    }

    @Test
    public void testGetPaymentPreferenceById() {
        when(mongoTemplate.findOne(query(where("id").is("testId")), PaymentPreference.class, "paymentPreference"))
                .thenReturn(doc);

        PaymentPreference result = paymentPreferenceService.getPaymentPreference("testId");

        assertNotNull(result);
        assertEquals("testId", result.getId());
        verify(mongoTemplate, times(1)).findOne(query(where("id").is("testId")), PaymentPreference.class, "paymentPreference");
    }

    @Test
    public void testDeletePaymentPreference() {
        paymentPreferenceService.deletePaymentPreference("toDelete");

        verify(mongoTemplate, times(1)).remove(query(where("id").is("toDelete")), PaymentPreference.class, "paymentPreference");
    }

    @Test
    public void testGetPaymentPreferenceList() {
        List<String> ids = Arrays.asList("id1", "id2");
        List<PaymentPreference> docs = Collections.singletonList(doc);
        when(mongoTemplate.find(query(where("id").in(ids)), PaymentPreference.class, "paymentPreference"))
                .thenReturn(docs);

        List<PaymentPreference> result = paymentPreferenceService.getPaymentPreferenceList(ids);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(mongoTemplate, times(1)).find(query(where("id").in(ids)), PaymentPreference.class, "paymentPreference");
    }

    @Test
    public void testInsertMultiPaymentPreferences() {
        List<PaymentPreference> list = Collections.singletonList(doc);
        when(mongoTemplate.insert(list, "paymentPreference")).thenReturn(list);

        List<PaymentPreference> result = paymentPreferenceService.insertMultiPaymentPreferences(list);

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(mongoTemplate, times(1)).insert(list, "paymentPreference");
    }

    @Test

    public void testGetPaymentPreferenceByTinAndMpin() {

        when(mongoTemplate.findOne(query(where("tin").is(doc.getTin()).and("mpin").is(doc.getMpin())), PaymentPreference.class, "paymentPreference"))
                .thenReturn(doc);

        PaymentPreference result = paymentPreferenceService.getPaymentPreferenceByTinAndMpin(doc.getTin(), doc.getMpin());
        assertNotNull(result);

        assertEquals("9358938", result.getMpin());
        assertEquals("451230492", result.getTin());
        verify(mongoTemplate, times(1)).findOne(query(where("tin").is(doc.getTin()).and("mpin").is(doc.getMpin())), PaymentPreference.class, "paymentPreference");
    }

    @Test
    public void testUpdatePaymentPreferenceWhenDocumentExists() {
        when(mongoTemplate.findOne(query(where("tin").is("451230492").and("mpin").is("9358938")), PaymentPreference.class, "paymentPreference"))
                .thenReturn(doc);

        PaymentPreference result = paymentPreferenceService.updatePaymentPreference("451230492", "9358938", "CHECK", "updatedUser");

        assertNotNull(result);
        assertEquals("CHECK", result.getPaymentPref());
        assertEquals("updatedUser", result.getUpdatedBy());
        assertNotNull(result.getDateModified());
        verify(mongoTemplate, times(1)).save(doc, "paymentPreference");
    }

    @Test
    public void testUpdatePaymentPreferenceWhenDocumentMissing() {
        when(mongoTemplate.findOne(query(where("tin").is("451230492").and("mpin").is("9358938")), PaymentPreference.class, "paymentPreference"))
                .thenReturn(null);

        PaymentPreference result = paymentPreferenceService.updatePaymentPreference("451230492", "9358938", "CHECK", "updatedUser");

        assertNull(result);
        verify(mongoTemplate, never()).save(any(PaymentPreference.class), anyString());
    }

    @Test
    public void testSetMongoQueryMaxMillis() {
        paymentPreferenceService.setMongoQueryMaxMillis("12345");
        assertEquals("12345", paymentPreferenceService.mongoQueryMaxMillis);
    }

}