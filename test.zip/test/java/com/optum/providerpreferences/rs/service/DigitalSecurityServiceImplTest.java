package com.optum.providerpreferences.rs.service;

import com.optum.digitalsecurity.model.request.User;
import com.optum.digitalsecurity.model.response.OrgData;
import com.optum.digitalsecurity.model.response.PDOCorporates;
import com.optum.digitalsecurity.model.response.PDOTins;
import com.optum.digitalsecurity.model.response.ProviderOrg;
import com.optum.digitalsecurity.model.response.ProviderProfile;
import com.optum.digitalsecurity.model.response.Tin;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.Oauth2Handler;
import com.optum.providerpreferences.rs.handler.ServiceBase;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

public class DigitalSecurityServiceImplTest {

    private DigitalSecurityServiceImpl service;

    @Before
    public void setUp() {
        service = new DigitalSecurityServiceImpl();
        service.DigiSec_User_URL = "http://mock-user-url";
        service.DigiSec_UserOrg_URL = "http://mock-org-url";
        service.DigiSec_PAA_URL = "http://mock-paa-url";
    }

    @Test
    public void getDigiSecTokenShouldReturnTokenOnSuccess() throws Exception {
        Oauth2Handler oauth2Handler = mock(Oauth2Handler.class);
        Token token = new Token();
        token.setAccessToken("abc123");

        setOauth2Handler(service, oauth2Handler);
        when(oauth2Handler.getOauthToken("session1", "DS")).thenReturn(token);

        Token result = service.getDigiSecToken("session1");

        assertEquals("abc123", result.getAccessToken());
    }

    @Test
    public void getDigiSecTokenShouldWrapOauthFailure() throws Exception {
        Oauth2Handler oauth2Handler = mock(Oauth2Handler.class);
        setOauth2Handler(service, oauth2Handler);

        when(oauth2Handler.getOauthToken("session2", "DS")).thenThrow(new IOException("oauth down"));

        try {
            service.getDigiSecToken("session2");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to retrieve OAuth Token for Digital security API"));
        }
    }

    @Test
    public void getCorporatesByPasswordOwnerShouldReturnFilteredCorporates() throws Exception {
        DigitalSecurityServiceImpl spyService = spy(service);
        Oauth2Handler oauth2Handler = mock(Oauth2Handler.class);
        setOauth2Handler(spyService, oauth2Handler);

        Token token = new Token();
        token.setAccessToken("token");
        when(oauth2Handler.getOauthToken(null, "DS")).thenReturn(token);

        ProviderOrg paaOrg = new ProviderOrg();
        paaOrg.setPaa(true);
        paaOrg.setFirstName("John");
        paaOrg.setLastName("Doe");
        paaOrg.setUhcProviderId("uhc-1");
        paaOrg.setCorpMpin("123456789");
        paaOrg.setId("prov-1");

        ProviderOrg nonPaaOrg = new ProviderOrg();
        nonPaaOrg.setPaa(false);
        nonPaaOrg.setFirstName("Ignore");

        ProviderProfile profile = new ProviderProfile();
        profile.setProviderOrg(java.util.Arrays.asList(paaOrg, nonPaaOrg));
        ResponseEntity<?> response = new ResponseEntity<>(profile, HttpStatus.OK);

        doReturn(response).when(spyService).sendRequest(anyString(), any(HttpEntity.class), eq(ProviderProfile.class), eq(HttpMethod.POST));

        PDOCorporates result = spyService.getCorporatesByPasswordOwner("uuid-1", new HttpHeaders(), new LogMessage());

        assertNotNull(result);
        assertEquals("uuid-1", result.getOptumUUID());
        assertEquals(1, result.getCorporates().size());
        assertEquals("John Doe", result.getCorporates().get(0).getCorporateName());
    }

    @Test
    public void getCorporatesByPasswordOwnerShouldWrapGeneralFailure() throws Exception {
        DigitalSecurityServiceImpl spyService = spy(service);
        Oauth2Handler oauth2Handler = mock(Oauth2Handler.class);
        setOauth2Handler(spyService, oauth2Handler);

        Token token = new Token();
        token.setAccessToken("token");
        when(oauth2Handler.getOauthToken(null, "DS")).thenReturn(token);
        doThrow(new RuntimeException("boom")).when(spyService).sendRequest(anyString(), any(HttpEntity.class), eq(ProviderProfile.class), eq(HttpMethod.POST));

        try {
            spyService.getCorporatesByPasswordOwner("uuid-1", new HttpHeaders(), new LogMessage());
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertEquals("WEB SERVICE CALL FAILURE - DIGITAL SECURITY CORPORATE CALL", e.getMessage());
        }
    }

    @Test
    public void getProvidersByCorporateShouldReturnProviderTins() throws Exception {
        DigitalSecurityServiceImpl spyService = spy(service);
        Oauth2Handler oauth2Handler = mock(Oauth2Handler.class);
        setOauth2Handler(spyService, oauth2Handler);

        Token token = new Token();
        token.setAccessToken("token");
        when(oauth2Handler.getOauthToken(null, "DS")).thenReturn(token);

        Tin tin = new Tin();
        tin.setTin("111111111");
        OrgData orgData = new OrgData();
        orgData.setTins(Collections.singletonList(tin));
        ResponseEntity<?> response = new ResponseEntity<>(orgData, HttpStatus.OK);

        doReturn(response).when(spyService).sendRequest(anyString(), any(HttpEntity.class), eq(OrgData.class), eq(HttpMethod.POST));

        PDOTins result = spyService.getProvidersByCorporate("uuid-1", "uhc-1", "123456789", new HttpHeaders(), new LogMessage());

        assertNotNull(result);
        assertEquals("uuid-1", result.getOptumUUID());
        assertEquals("uhc-1", result.getUhcID());
        assertEquals("123456789", result.getMpin());
        assertNotNull(result.getProviders());
    }

    @Test
    public void getProvidersByCorporateShouldWrapOauthFailure() throws Exception {
        Oauth2Handler oauth2Handler = mock(Oauth2Handler.class);
        setOauth2Handler(service, oauth2Handler);

        when(oauth2Handler.getOauthToken(null, "DS")).thenThrow(new IOException("oauth fail"));

        try {
            service.getProvidersByCorporate("uuid-1", "uhc-1", "123456789", new HttpHeaders(), new LogMessage());
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to retrieve OAuth Token for Digital security API"));
        }
    }

    @Test
    public void getEmailsByCorporateShouldReturnResponseFromDigiSec() throws Exception {
        DigitalSecurityServiceImpl spyService = spy(service);

        Token token = new Token();
        token.setAccessToken("token");
        doReturn(token).when(spyService).getDigiSecToken("DS_PAA");

        User user = new User();
        user.setEmail("test@example.com");
        ResponseEntity<?> response = new ResponseEntity<>(user, HttpStatus.OK);
        doReturn(response).when(spyService).sendDigiSecRequest(anyString(), any(HttpEntity.class), eq(User.class), eq(HttpMethod.POST));

        ResponseEntity<?> result = spyService.getEmailsByCorporate("123456789", new HttpHeaders());

        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        assertEquals("test@example.com", ((User) result.getBody()).getEmail());
    }

    @Test
    public void getEmailsByCorporateShouldReturnNotFoundWhenExceptionOccurs() throws Exception {
        DigitalSecurityServiceImpl spyService = spy(service);
        doThrow(new ApplicationException("token fail")).when(spyService).getDigiSecToken("DS_PAA");

        ResponseEntity<?> result = spyService.getEmailsByCorporate("123456789", new HttpHeaders());

        assertNotNull(result);
        assertEquals(HttpStatus.NOT_FOUND, result.getStatusCode());
    }

    private static void setOauth2Handler(DigitalSecurityServiceImpl service, Oauth2Handler oauth2Handler) throws Exception {
        Field field = ServiceBase.class.getDeclaredField("oauth2handler");
        field.setAccessible(true);
        field.set(service, oauth2Handler);
    }
}

