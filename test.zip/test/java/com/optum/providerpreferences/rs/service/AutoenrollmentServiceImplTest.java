package com.optum.providerpreferences.rs.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.autoenrollment.SchedulerAutoEnrollment;
import com.optum.providerpreferences.autoenrollment.TimeUtils;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObj;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AutoenrollmentServiceImplTest {

    @InjectMocks
    private AutoenrollmentServiceImpl service;

    @Mock
    private FDSCloudHandler fdsCloudHandler;

    @Mock
    private ObjectMapper mapper;

    @Mock
    private ExecutorService mockExecutorService;

    @Before
    public void setUp() {
        SchedulerAutoEnrollment.getCount = new AtomicInteger(0);
        SchedulerAutoEnrollment.postCount = new AtomicInteger(0);
    }

    @After
    public void tearDown() {
        shutdownExecutorField("emailRequestExecutorService");
        shutdownExecutorField("autoenrollmentPostExecutorService");
        shutdownExecutorField("autoenrollmentGetExecutorService");
    }

    @Test
    public void checkIfExistShouldReturnTrueWhenFieldHasValue() {
        Map<String, Object> map = new HashMap<>();
        map.put("providerEmailId", "test@example.com");

        boolean result = service.checkIfExist(map, "providerEmailId");

        assertTrue(result);
    }

    @Test
    public void testCreateAutoenrollmentDocumentsFDSCloud_Success() throws Exception {
        AutoenrollmentRequest autoenrollRequest = new AutoenrollmentRequest();
        AutoenrollmentObj autoenrollObj = new AutoenrollmentObj();
        autoenrollObj.setTin("123456");
        autoenrollObj.setMpin("111111");
        autoenrollObj.setProviderEmailId("test@example.com");
        autoenrollObj.setFileName("TestFile");
        autoenrollRequest.setAutoenrollDocuments(Collections.singletonList(autoenrollObj));

        HttpHeaders headers = new HttpHeaders();
        headers.add("optum-cid-ext", "test-cid");

        setPrivateField("emailRequestExecutorService", mockExecutorService);
        setPrivateField("autoenrollmentPostExecutorService", mockExecutorService);
        setPrivateField("autoenrollmentGetExecutorService", mockExecutorService);

        when(mockExecutorService.isShutdown()).thenReturn(false);
        doNothing().when(mockExecutorService).execute(any(Runnable.class));
        doNothing().when(mockExecutorService).shutdown();
        when(mockExecutorService.awaitTermination(anyLong(), eq(TimeUnit.MILLISECONDS))).thenReturn(true);

        Token token = new Token();
        token.setAccessToken("token");
        when(fdsCloudHandler.getFDSCloudToken(anyString())).thenReturn(token);
        when(mapper.convertValue(any(), any(TypeReference.class))).thenReturn(new HashMap<String, Object>());

        OptOutFDSCloudPOSTResponse responseBody = new OptOutFDSCloudPOSTResponse();
        responseBody.setDocumentId("mockDocId");
        responseBody.setSearchTerms(new ArrayList<>());
        responseBody.setAttachments(new ArrayList<>());
        ResponseEntity<OptOutFDSCloudPOSTResponse> response = new ResponseEntity<>(responseBody, HttpStatus.CREATED);
        when(fdsCloudHandler.FDSCloudPostRequest(anyString(), any(FDSCloudRequest.class))).thenReturn(response);
        when(fdsCloudHandler.FDSCloudPutRequest(anyString(), any(FDSCloudRequest.class))).thenReturn(response);

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);

            List<String> result = service.createAutoenrollmentDocumentsFDSCloud(autoenrollRequest, headers);

            assertNotNull(result);
            assertEquals(0, result.size());
            verify(mockExecutorService, times(1)).execute(any(Runnable.class));
        }
    }

    @Test
    public void testFormatDate_ValidDate() throws Exception {
        TimeZone original = TimeZone.getDefault();
        try {
            TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
            Method method = AutoenrollmentServiceImpl.class.getDeclaredMethod("formatDate", java.util.Date.class);
            method.setAccessible(true);

            String formattedDate = (String) method.invoke(service, new java.util.Date(1672531200000L));
            assertEquals("2023-01-01T00:00:00.000Z", formattedDate);
        } finally {
            TimeZone.setDefault(original);
        }
    }

    @Test
    public void testExistingEmailRequest_Run() throws Exception {
        AutoenrollmentObj autoenrollRequest = new AutoenrollmentObj();
        autoenrollRequest.setTin("123456");
        autoenrollRequest.setMpin("111111");
        autoenrollRequest.setProviderEmailId("old@example.com");
        autoenrollRequest.setFileName("TestFile");

        FDSCloudRequest mockRequest = new FDSCloudRequest();
        FDSCloudGETResponse mockResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument document = new OptOutFDSCloudDocument();
        mockResponse.setDocuments(Collections.singletonList(document));

        Map<String, Object> mockMetadata = new HashMap<>();
        mockMetadata.put("providerEmailId", "test@test.com");

        when(fdsCloudHandler.createSearchTermsRequestFromMap(anyMap())).thenReturn(mockRequest);
        when(fdsCloudHandler.FDSCloudGetRequest(anyString(), eq(mockRequest))).thenReturn(mockResponse);
        when(fdsCloudHandler.getSearchTermsFromDocument(document)).thenReturn(mockMetadata);

        setPrivateField("autoenrollObjects", Collections.synchronizedList(new ArrayList<AutoenrollmentObj>()));

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);

            AutoenrollmentServiceImpl.existingEmailRequest existingEmailRequest =
                    service.new existingEmailRequest(autoenrollRequest);
            existingEmailRequest.run();
        }

        List<AutoenrollmentObj> autoenrollObjects = getPrivateAutoenrollObjects();
        assertEquals("test@test.com", autoenrollRequest.getProviderEmailId());
        assertEquals(1, autoenrollObjects.size());
        assertTrue(autoenrollObjects.contains(autoenrollRequest));
    }

    @Test
    public void testAutoenrollmentFDSCloudPostRequest_Run() throws Exception {
        FDSCloudRequest mockRequest = new FDSCloudRequest();
        OptOutFDSCloudPOSTResponse responseBody = new OptOutFDSCloudPOSTResponse();
        responseBody.setDocumentId("mockDocId");
        responseBody.setSearchTerms(new ArrayList<>());
        responseBody.setAttachments(new ArrayList<>());

        ResponseEntity<OptOutFDSCloudPOSTResponse> response =
                new ResponseEntity<>(responseBody, HttpStatus.CREATED);
        when(fdsCloudHandler.FDSCloudPostRequest(eq("autoenrollmentPOST"), eq(mockRequest)))
                .thenReturn(response);

        setPrivateField("docIdList", Collections.synchronizedList(new ArrayList<String>()));

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);

            AutoenrollmentServiceImpl.autoenrollmentFDSCloudPostRequest postRequest =
                    service.new autoenrollmentFDSCloudPostRequest(mockRequest);
            postRequest.run();
        }

        List<String> docIdList = getPrivateDocIdList();
        assertEquals(1, docIdList.size());
        assertTrue(docIdList.contains("mockDocId"));
    }

    @Test
    public void testAutoenrollmentFDSCloudPostRequest_Run_Failure() throws Exception {
        FDSCloudRequest mockRequest = new FDSCloudRequest();

        OptOutFDSCloudPOSTResponse failureBody = new OptOutFDSCloudPOSTResponse();
        failureBody.setDocumentId("failureDocId");
        failureBody.setSearchTerms(new ArrayList<>());
        failureBody.setAttachments(new ArrayList<>());
        ResponseEntity<OptOutFDSCloudPOSTResponse> failureResponse =
                new ResponseEntity<>(failureBody, HttpStatus.BAD_REQUEST);

        OptOutFDSCloudPOSTResponse retryBody = new OptOutFDSCloudPOSTResponse();
        retryBody.setDocumentId("retryDocId");
        retryBody.setSearchTerms(new ArrayList<>());
        retryBody.setAttachments(new ArrayList<>());
        ResponseEntity<OptOutFDSCloudPOSTResponse> retryResponse =
                new ResponseEntity<>(retryBody, HttpStatus.CREATED);

        when(fdsCloudHandler.FDSCloudPostRequest(eq("autoenrollmentPOST"), eq(mockRequest)))
                .thenReturn(failureResponse);
        when(fdsCloudHandler.FDSCloudPostRequest(eq("autoenrollmentPOSTretry"), eq(mockRequest)))
                .thenReturn(retryResponse);

        setPrivateField("docIdList", Collections.synchronizedList(new ArrayList<String>()));

        try (MockedStatic<TimeUtils> timeUtils = mockStatic(TimeUtils.class)) {
            timeUtils.when(TimeUtils::isWithinBusinessHours).thenReturn(false);

            AutoenrollmentServiceImpl.autoenrollmentFDSCloudPostRequest postRequest =
                    service.new autoenrollmentFDSCloudPostRequest(mockRequest);
            postRequest.run();
        }

        List<String> docIdList = getPrivateDocIdList();
        assertEquals(1, docIdList.size());
        assertTrue(docIdList.contains("retryDocId"));
        verify(fdsCloudHandler, times(1)).FDSCloudPostRequest("autoenrollmentPOST", mockRequest);
        verify(fdsCloudHandler, times(1)).FDSCloudPostRequest("autoenrollmentPOSTretry", mockRequest);
    }

    @SuppressWarnings("unchecked")
    private List<AutoenrollmentObj> getPrivateAutoenrollObjects() throws Exception {
        Field field = AutoenrollmentServiceImpl.class.getDeclaredField("autoenrollObjects");
        field.setAccessible(true);
        return (List<AutoenrollmentObj>) field.get(service);
    }

    @SuppressWarnings("unchecked")
    private List<String> getPrivateDocIdList() throws Exception {
        Field field = AutoenrollmentServiceImpl.class.getDeclaredField("docIdList");
        field.setAccessible(true);
        return (List<String>) field.get(service);
    }

    private void setPrivateField(String fieldName, Object value) throws Exception {
        Field field = AutoenrollmentServiceImpl.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        Object existing = field.get(service);
        if (existing instanceof ExecutorService) {
            ((ExecutorService) existing).shutdownNow();
        }
        field.set(service, value);
    }

    private void shutdownExecutorField(String fieldName) {
        try {
            Field field = AutoenrollmentServiceImpl.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            Object value = field.get(service);
            if (value instanceof ExecutorService) {
                ((ExecutorService) value).shutdownNow();
            }
        } catch (Exception ignored) {
            // Best effort cleanup for thread pools created by the service.
        }
    }
}
