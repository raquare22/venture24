package com.optum.providerpreferences.rs.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.handler.PESHandler;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.FDSResponse;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinData;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.ndb.provider.ResponseData;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPutResponse;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinResponse;
import com.optum.providerpreferences.rs.model.pes.Key;
import com.optum.providerpreferences.rs.model.pes.PESResponse;
import com.optum.providerpreferences.rs.model.pes.TinObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.lang.reflect.Method;
import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OptOutServiceImplTest {

    @InjectMocks
    private OptOutServiceImpl service;

    @Mock
    private ObjectMapper mapper;

    @Mock
    private FDSCloudHandler fdsCloudHandler;

    @Mock
    private PESHandler pesHandler;

    @Mock
    private FDSHandler fdsHandler;

    @Mock
    private NDBHandler ndbHandler;

    @Before
    public void setUp() {
        service.SPACE_ID = "space-id";
    }

    @Test
    public void getTinsShouldReturnOnlyNonBlankTinValues() throws Exception {
        Key validKey = new Key();
        validKey.setTaxIdNumber("123456789");
        TinObject validTin = new TinObject();
        validTin.setKey(validKey);

        Key blankKey = new Key();
        blankKey.setTaxIdNumber("");
        TinObject blankTin = new TinObject();
        blankTin.setKey(blankKey);

        TinObject nullKeyTin = new TinObject();

        PESResponse response = new PESResponse();
        response.setData(Arrays.asList(validTin, blankTin, nullKeyTin, null));

        when(pesHandler.getTins(org.mockito.ArgumentMatchers.any())).thenReturn(response);

        OptOutTinRequest request = new OptOutTinRequest();
        request.setCorporateMpin("987654321");

        OptOutTinResponse result = service.getTins(request);

        assertEquals(1, result.getTins().size());
        assertEquals("123456789", result.getTins().get(0));
    }

    @Test
    public void fdsCloudDeleteShouldDelegateToHandler() throws Exception {
        FDSCloudRequest request = new FDSCloudRequest();
        Map<String, Object> body = new HashMap<>();
        body.put("documentId", "doc-1");
        request.setRequest(body);

        Map<String, Boolean> expected = new HashMap<>();
        expected.put("doc-1", true);

        when(fdsCloudHandler.FDSCloudDelete("DELETE", "doc-1")).thenReturn(expected);

        Map<String, Boolean> result = service.FDSCloudDelete("DELETE", request);

        assertTrue(result.get("doc-1"));
    }

    @Test
    public void getOptOutAuditLogShouldDelegateToFdsCloudHandler() throws Exception {
        FDSCloudRequest request = new FDSCloudRequest();
        FDSCloudGETResponse expected = new FDSCloudGETResponse();

        when(fdsCloudHandler.FDSCloudGetRequest("audit", request)).thenReturn(expected);

        FDSCloudGETResponse result = service.getOptOutAuditLog("audit", request);

        assertNotNull(result);
        verify(fdsCloudHandler, times(1)).FDSCloudGetRequest("audit", request);
    }

    @Test
    public void addOptOutAuditLogShouldDelegateToFdsCloudHandler() throws Exception {
        FDSCloudRequest request = new FDSCloudRequest();
        OptOutFDSCloudPOSTResponse body = new OptOutFDSCloudPOSTResponse();
        body.setDocumentId("audit-id");
        ResponseEntity<OptOutFDSCloudPOSTResponse> expected = new ResponseEntity<>(body, HttpStatus.CREATED);

        when(fdsCloudHandler.FDSCloudPostRequest("audit", request)).thenReturn(expected);

        ResponseEntity<OptOutFDSCloudPOSTResponse> result = service.addOptOutAuditLog("audit", request);

        assertNotNull(result);
        assertNotNull(result.getBody());
        assertEquals("audit-id", result.getBody().getDocumentId());
        verify(fdsCloudHandler, times(1)).FDSCloudPostRequest("audit", request);
    }

    @Test
    public void fdsCloudPutShouldDelegateToFdsCloudHandler() throws Exception {
        FDSCloudRequest request = new FDSCloudRequest();
        OptOutFDSCloudPOSTResponse body = new OptOutFDSCloudPOSTResponse();
        body.setDocumentId("put-id");
        ResponseEntity<OptOutFDSCloudPOSTResponse> expected = new ResponseEntity<>(body, HttpStatus.OK);

        when(fdsCloudHandler.FDSCloudPutRequest("put", request)).thenReturn(expected);

        ResponseEntity<OptOutFDSCloudPOSTResponse> result = service.FDSCloudPut("put", request);

        assertNotNull(result);
        assertNotNull(result.getBody());
        assertEquals("put-id", result.getBody().getDocumentId());
        verify(fdsCloudHandler, times(1)).FDSCloudPutRequest("put", request);
    }

    @Test
    public void getFdsCloudDocumentShouldDelegateToFdsCloudHandler() throws Exception {
        FDSCloudRequest request = new FDSCloudRequest();
        request.setDocumentId("doc-123");
        OptOutFDSCloudDocument expected = new OptOutFDSCloudDocument();
        expected.setDocumentId("doc-123");

        when(fdsCloudHandler.FDSCloudGetDocument("document", "doc-123")).thenReturn(expected);

        OptOutFDSCloudDocument result = service.getFDSCloudDocument("document", request);

        assertNotNull(result);
        assertEquals("doc-123", result.getDocumentId());
        verify(fdsCloudHandler, times(1)).FDSCloudGetDocument("document", "doc-123");
    }

    @Test
    public void getDocumentsFromFdsShouldCollectIdsWhenDocumentsExist() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");

        FDSResponse sortedDocs = new FDSResponse();
        Document document = new Document();
        document.setId("doc-id");
        sortedDocs.setDocuments(Collections.singletonList(document));

        when(ndbHandler.updateProviderLetterPreferences(any(), anyString(), anyString())).thenReturn(true);
        when(fdsHandler.getAutoEnrollDocumentListSortCreated(anyString(), eq("123456789"), anyString(), eq("session")))
                .thenReturn(sortedDocs);

        List<String> result = service.getDocumentsFromFDS(Collections.singletonList("123456789"), "123456789", headers);

        assertNotNull(result);
        assertTrue(result.contains("doc-id"));
        verify(ndbHandler, atLeast(1)).updateProviderLetterPreferences(any(), anyString(), anyString());
    }

    @Test
    public void updateOptOutDocumentsShouldThrowWhenProviderLookupFails() throws Exception {
        OptOutRequest optOutRequest = new OptOutRequest();
        optOutRequest.setTin("123456789");
        optOutRequest.setCorpMpin("123456789");
        optOutRequest.setProviderMpins(Collections.emptyList());
        optOutRequest.setLastUpdatedBy("user");
        optOutRequest.setLastUpdatedById("user-id");
        optOutRequest.setOptedOutDuration(30);

        when(ndbHandler.getProviderData(any(RequestData.class)))
                .thenThrow(new ApplicationException("mock ndb failure"));

        try {
            service.updateOptOutDocuments(optOutRequest, new HttpHeaders());
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("Error making service call to NDB", ex.getMessage());
        }

        verify(ndbHandler, times(1)).ndbWebServicePrep();
        verify(ndbHandler, times(1)).getProviderData(any(RequestData.class));
    }

    @Test
    public void getTinsShouldPropagateHandlerException() throws Exception {
        OptOutTinRequest request = new OptOutTinRequest();
        request.setCorporateMpin("987654321");

        when(pesHandler.getTins(any())).thenThrow(new ApplicationException("Error retrieving TINs"));

        try {
            service.getTins(request);
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("Error retrieving TINs", ex.getMessage());
        }
    }

    @Test
    public void getDocumentsFromFdsShouldReturnEmptyWhenNoDocuments() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");

        when(ndbHandler.updateProviderLetterPreferences(any(), anyString(), anyString())).thenReturn(true);
        when(fdsHandler.getAutoEnrollDocumentListSortCreated(anyString(), eq("123456789"), anyString(), eq("session")))
                .thenReturn(new FDSResponse());

        List<String> result = service.getDocumentsFromFDS(Collections.singletonList("123456789"), "123456789", headers);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void getDocumentsFromFdsShouldThrowWhenNdbUpdateFails() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");

        when(ndbHandler.updateProviderLetterPreferences(any(), anyString(), anyString()))
                .thenThrow(new com.fasterxml.jackson.core.JsonProcessingException("ndb fail") {});

        try {
            service.getDocumentsFromFDS(Collections.singletonList("123456789"), "123456789", headers);
            fail("Expected JsonProcessingException");
        } catch (com.fasterxml.jackson.core.JsonProcessingException expected) {
            assertNotNull(expected);
        }
    }

    @Test
    public void updateOptOutDocumentsShouldSucceedWithProvidedMpins() throws Exception {
        OptOutRequest request = new OptOutRequest();
        request.setTin("123456789");
        request.setCorpMpin("123456789");
        request.setProviderMpins(Collections.singletonList("123456789"));
        request.setLastUpdatedBy("tester");
        request.setLastUpdatedById("tester-id");
        request.setOptedOutDuration(30);

        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");

        Document doc = new Document();
        doc.setId("doc-id");
        FDSResponse fdsResponse = new FDSResponse();
        fdsResponse.setDocuments(Collections.singletonList(doc));

        when(ndbHandler.updateProviderLetterPreferences(any(), anyString(), anyString())).thenReturn(true);
        when(fdsHandler.getAutoEnrollDocumentListSortCreated(anyString(), eq("123456789"), anyString(), eq("session")))
                .thenReturn(fdsResponse);

        FDSMultiPutResponse putResponse = new FDSMultiPutResponse();
        putResponse.setUpdated(Collections.singletonList("doc-id"));
        putResponse.setNotfound(Collections.emptyList());
        when(fdsHandler.updateMultiDocuments(any(), eq(headers), eq("OPTOUT"))).thenReturn(putResponse);

        when(mapper.convertValue(any(), any(TypeReference.class))).thenReturn(new HashMap<>());

        OptOutFDSCloudPOSTResponse auditBody = new OptOutFDSCloudPOSTResponse();
        auditBody.setDocumentId("audit");
        when(fdsCloudHandler.FDSCloudPostRequest(eq("OptOutAuditLog"), any(FDSCloudRequest.class)))
                .thenReturn(new ResponseEntity<>(auditBody, HttpStatus.CREATED));

        FDSMultiPutResponse result = service.updateOptOutDocuments(request, headers);

        assertNotNull(result);
        assertEquals(1, result.getUpdated().size());
        verify(fdsHandler, times(1)).updateMultiDocuments(any(), eq(headers), eq("OPTOUT"));
        verify(fdsCloudHandler, times(1)).FDSCloudPostRequest(eq("OptOutAuditLog"), any(FDSCloudRequest.class));
    }

    @Test
    public void updateOptOutDocumentsShouldBuildMpinsFromCorpResponse() throws Exception {        OptOutRequest request = new OptOutRequest();
        request.setTin("123456789");
        request.setCorpMpin("999999999");
        request.setProviderMpins(Collections.emptyList());
        request.setLastUpdatedBy("tester");
        request.setLastUpdatedById("tester-id");
        request.setOptedOutDuration(9999);

        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");

        CorpMpinResponse corpMpinResponse = new CorpMpinResponse();
        ResponseData responseData = new ResponseData();
        MpinData mpinData = new MpinData();
        mpinData.setProviderId("1234");
        responseData.setMpinList(Collections.singletonList(mpinData));
        corpMpinResponse.setResponse(responseData);
        when(ndbHandler.getProviderData(any(RequestData.class))).thenReturn(corpMpinResponse);

        Document doc = new Document();
        doc.setId("doc-id");
        FDSResponse fdsResponse = new FDSResponse();
        fdsResponse.setDocuments(Collections.singletonList(doc));

        when(ndbHandler.updateProviderLetterPreferences(any(), anyString(), anyString())).thenReturn(true);
        when(fdsHandler.getAutoEnrollDocumentListSortCreated(anyString(), eq("000001234"), anyString(), eq("session")))
                .thenReturn(fdsResponse);

        FDSMultiPutResponse putResponse = new FDSMultiPutResponse();
        putResponse.setUpdated(Collections.singletonList("doc-id"));
        when(fdsHandler.updateMultiDocuments(any(), eq(headers), eq("OPTOUT"))).thenReturn(putResponse);

        when(mapper.convertValue(any(), any(TypeReference.class))).thenReturn(new HashMap<>());

        OptOutFDSCloudPOSTResponse auditBody = new OptOutFDSCloudPOSTResponse();
        auditBody.setDocumentId("audit");
        when(fdsCloudHandler.FDSCloudPostRequest(eq("OptOutAuditLog"), any(FDSCloudRequest.class)))
                .thenReturn(new ResponseEntity<>(auditBody, HttpStatus.CREATED));

        FDSMultiPutResponse result = service.updateOptOutDocuments(request, headers);

        assertNotNull(result);
        verify(ndbHandler, times(1)).getProviderData(any(RequestData.class));
        verify(fdsHandler, atLeast(1)).getAutoEnrollDocumentListSortCreated(anyString(), eq("000001234"), anyString(), eq("session"));
    }

    @Test
    public void privatePadWithLeadingZerosShouldHandleAllBranches() throws Exception {
        Method method = OptOutServiceImpl.class.getDeclaredMethod("padWithLeadingZeros", String.class);
        method.setAccessible(true);

        assertEquals("000000123", method.invoke(service, "123"));
        assertEquals("123456789", method.invoke(service, "123456789"));

        try {
            method.invoke(service, "1234567890");
            fail("Expected ApplicationException");
        } catch (Exception ex) {
            assertTrue(ex.getCause() instanceof ApplicationException);
        }
    }

    @Test
    public void privateCreateOptOutDocumentShouldSetExpectedMetadata() throws Exception {
        Method method = OptOutServiceImpl.class.getDeclaredMethod("createOptOutDocument", String.class, String.class, int.class);
        method.setAccessible(true);

        Document normal = (Document) method.invoke(service, "u1", "id1", 30);
        assertNotNull(normal);
        assertEquals("space-id", normal.getSpaceId());
        Metadata normalMeta = normal.getMetadata();
        assertEquals("u1", normalMeta.getLastUpdatedBy());
        assertEquals("id1", normalMeta.getLastUpdatedById());
        assertEquals("P", normalMeta.getDeliveryMethod());
        assertEquals("Y", normalMeta.getAutoOptOutInd());

        Document perpetual = (Document) method.invoke(service, "u2", "id2", 9999);
        assertEquals("9999-12-31T23:59:59.000Z", perpetual.getMetadata().getExpiryDate());
        assertEquals(Long.valueOf("253402300799000"), perpetual.getMetadata().getExpiryDateEpoch());
    }

    @Test
    public void privateParseExpiryDateShouldParseKnownFormat() throws Exception {
        Method method = OptOutServiceImpl.class.getDeclaredMethod("parseExpiryDate", String.class);
        method.setAccessible(true);

        Instant parsed = (Instant) method.invoke(service, "2024-01-01T00:00:00.000Z");
        assertEquals(1704067200L, parsed.getEpochSecond());
    }
}

