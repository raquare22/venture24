package com.optum.providerpreferences.rs.service;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.CACFHandler;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.FDSResponse;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponse;
import com.optum.providerpreferences.rs.model.ndb.preferences.MailPref;
import com.optum.providerpreferences.rs.model.ndb.preferences.ResponseData;
import com.optum.providerpreferences.rs.model.ndb.preferences.ResponseHeader;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;

import java.lang.reflect.Method;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.mockConstruction;

@RunWith(MockitoJUnitRunner.class)
public class ProviderPreferenceServiceImplTest {

    @InjectMocks
    private ProviderPreferenceServiceImpl service;

    @Mock
    private NDBHandler ndbHandler;

    @Mock
    private FDSHandler fdsHandler;

    @Before
    public void setUp() {
        service.SPACE_ID = "space-id";
    }

    @Test
    public void determineMultiShouldPickFirstValidAutoEnrollment() {
        ProviderPreferenceServiceImpl.AutoEnrollment first = service.new AutoEnrollment(true, 0);
        ProviderPreferenceServiceImpl.AutoEnrollment second = service.new AutoEnrollment(true, -1);

        int result = service.determineMulti(first, second);

        assertEquals(0, result);
    }

    @Test
    public void determineMultiShouldPickSecondNonAutoEnrollmentWhenNeeded() {
        ProviderPreferenceServiceImpl.AutoEnrollment first = service.new AutoEnrollment(true, -1);
        ProviderPreferenceServiceImpl.AutoEnrollment second = service.new AutoEnrollment(false, 1);

        int result = service.determineMulti(first, second);

        assertEquals(1, result);
    }

    @Test
    public void determineMultiShouldReturnMinusOneWhenNoCandidateIsValid() {
        ProviderPreferenceServiceImpl.AutoEnrollment first = service.new AutoEnrollment(true, -1);
        ProviderPreferenceServiceImpl.AutoEnrollment second = service.new AutoEnrollment(true, -1);

        int result = service.determineMulti(first, second);

        assertEquals(-1, result);
    }

    @Test
    public void determineDocumentIndexShouldTreatMissingActiveDateAsNonAuto() {
        Metadata metadata = new Metadata();
        Document doc = new Document();
        doc.setMetadata(metadata);

        ProviderPreferenceServiceImpl.AutoEnrollment result = service.determineDocumentIndex(
                Collections.singletonList(doc),
                1,
                0,
                OffsetDateTime.now(ZoneOffset.UTC)
        );

        assertFalse(result.isAutoEnrollment());
        assertFalse(result.isValidAutoEnrollment());
    }

    @Test
    public void determineDocumentIndexShouldMarkPastActiveDateAsValidAuto() {
        Metadata metadata = new Metadata();
        String past = OffsetDateTime.now(ZoneOffset.UTC).minusDays(1)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
        metadata.setActiveDate(past);
        Document doc = new Document();
        doc.setMetadata(metadata);

        ProviderPreferenceServiceImpl.AutoEnrollment result = service.determineDocumentIndex(
                Collections.singletonList(doc),
                1,
                0,
                OffsetDateTime.now(ZoneOffset.UTC)
        );

        assertTrue(result.isAutoEnrollment());
        assertTrue(result.isValidAutoEnrollment());
    }

    @Test
    public void determineDocumentIndexShouldMarkFutureActiveDateAsInvalidAuto() {
        Metadata metadata = new Metadata();
        String future = OffsetDateTime.now(ZoneOffset.UTC).plusDays(1)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
        metadata.setActiveDate(future);
        Document doc = new Document();
        doc.setMetadata(metadata);

        ProviderPreferenceServiceImpl.AutoEnrollment result = service.determineDocumentIndex(
                Collections.singletonList(doc),
                1,
                0,
                OffsetDateTime.now(ZoneOffset.UTC)
        );

        assertTrue(result.isAutoEnrollment());
        assertFalse(result.isValidAutoEnrollment());
    }

    @Test
    public void determineDocumentIndexCloudShouldHandleMissingActiveDateAsNonAuto() throws Exception {
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        doc.setMetadata("{}");

        ProviderPreferenceServiceImpl.AutoEnrollment result = service.determineDocumentIndexCloud(
                Collections.singletonList(doc),
                1,
                0,
                OffsetDateTime.now(ZoneOffset.UTC)
        );

        assertFalse(result.isAutoEnrollment());
        assertFalse(result.isValidAutoEnrollment());
    }

    @Test
    public void determineDocumentIndexCloudShouldMarkPastActiveDateAsValidAuto() throws Exception {
        String past = OffsetDateTime.now(ZoneOffset.UTC).minusDays(1)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        doc.setMetadata("{\"activeDate\":\"" + past + "\"}");

        ProviderPreferenceServiceImpl.AutoEnrollment result = service.determineDocumentIndexCloud(
                Collections.singletonList(doc),
                1,
                0,
                OffsetDateTime.now(ZoneOffset.UTC)
        );

        assertTrue(result.isAutoEnrollment());
        assertTrue(result.isValidAutoEnrollment());
    }

    @Test
    public void determineDocumentIndexCloudShouldThrowIOExceptionForInvalidMetadataJson() {
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        doc.setMetadata("not-json");

        try {
            service.determineDocumentIndexCloud(Collections.singletonList(doc), 1, 0, OffsetDateTime.now(ZoneOffset.UTC));
            fail("Expected IOException");
        } catch (java.io.IOException expected) {
            assertNotNull(expected);
        }
    }

    @Test
    public void getProviderDataShouldReturnResponseFromHandler() throws Exception {
        CorpMpinResponse expected = new CorpMpinResponse();
        when(ndbHandler.getProviderData(any(RequestData.class))).thenReturn(expected);

        CorpMpinResponse result = service.getProviderData(new RequestData(), new HttpHeaders(), new LogMessage());

        assertNotNull(result);
        verify(ndbHandler, times(1)).getProviderData(any(RequestData.class));
    }

    @Test
    public void getProviderDataShouldWrapHandlerException() throws Exception {
        when(ndbHandler.getProviderData(any(RequestData.class)))
                .thenThrow(new ApplicationException("ndb down"));

        try {
            service.getProviderData(new RequestData(), new HttpHeaders(), new LogMessage());
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("Error making service call to NDB", ex.getMessage());
        }
    }

    @Test
    public void getProviderPreferencesShouldWorkForCucumberFlow() throws Exception {
        String tin = "123456789";
        String mpin = "123456789";
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");

        LogMessage logMessage = new LogMessage();
        logMessage.setUsername("CUCUMBERTEST");
        logMessage.setActor("C1");

        FDSResponse listResponse = new FDSResponse();
        Document providerDoc = new Document();
        Metadata providerMeta = new Metadata();
        providerMeta.setProviderName("Provider One");
        providerDoc.setMetadata(providerMeta);
        listResponse.setDocuments(Collections.singletonList(providerDoc));
        when(fdsHandler.getDocumentList(eq(tin), eq(mpin), eq(null), eq("session"))).thenReturn(listResponse);

        FDSResponse sortedDocs = new FDSResponse();
        Document prefDoc = new Document();
        prefDoc.setId("doc-1");
        Metadata prefMeta = new Metadata();
        prefMeta.setProviderEmailId("a@b.com");
        prefMeta.setFrequency("D");
        prefMeta.setOkToChangePDOInd("N");
        prefMeta.setAutoEdelUpdateInd("Y");
        prefMeta.setActiveDate(OffsetDateTime.now(ZoneOffset.UTC).minusDays(1)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")));
        prefDoc.setMetadata(prefMeta);
        sortedDocs.setDocuments(Collections.singletonList(prefDoc));
        when(fdsHandler.getDocumentListSortCreated(eq(tin), eq(mpin), eq("C1"), eq("session"))).thenReturn(sortedDocs);

        ProviderPreferencesObj result = service.getProviderPreferences(tin, mpin, headers, logMessage);

        assertNotNull(result);
        assertEquals(tin, result.getCorporateTin());
        assertEquals(1, result.getPreferenceTypes().size());
        PreferenceType pref = result.getPreferenceTypes().get(0);
        assertEquals("C1", pref.getClassifier());
        assertEquals("E", pref.getDeliveryMethod());
        assertEquals("doc-1", pref.getDocumentId());
    }

    @Test
    public void getProviderPreferencesShouldFailWhenNdbResponseHeaderMessageIsNull() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");

        LogMessage logMessage = new LogMessage();

        LetterPreferencesResponse ndbResponse = new LetterPreferencesResponse();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setMessage(null);
        ndbResponse.setResponseHeader(responseHeader);

        when(ndbHandler.getProviderLetterPreferences(any())).thenReturn(ndbResponse);

        try {
            service.getProviderPreferences("123456789", "123456789", headers, logMessage);
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("ERROR RETRIEVING PREFERENCES FOR MPIN", ex.getMessage());
        }
    }

    @Test
    public void getProviderPreferencesShouldFailFastForMpinLongerThanNine() {
        try {
            service.getProviderPreferences("123456789", "1234567890", new HttpHeaders(), new LogMessage());
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("MPIN longer than 9 digits", ex.getMessage());
        }
    }

    @Test
    public void getProviderPreferencesFdsCloudShouldFailFastForMpinLongerThanNine() throws Exception {
        try {
            service.getProviderPreferencesFDSCloud("123456789", "1234567890", new HttpHeaders(), new LogMessage());
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("MPIN longer than 9 digits", ex.getMessage());
        }
    }

    @Test
    public void printDocumentShouldContainEmailMpinAndFileName() {
        Metadata metadata = new Metadata();
        metadata.setProviderEmailId("test@example.com");
        metadata.setMpin("123456789");
        metadata.setFileName("E2");

        String result = service.printDocument(metadata);

        assertEquals("providerEmailId = test@example.com, mpin = 123456789, fileName= E2", result);
    }

    @Test
    public void privatePadWithLeadingZerosShouldHandleAllBranches() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod("padWithLeadingZeros", String.class);
        method.setAccessible(true);

        assertEquals("000000123", method.invoke(service, "123"));
        assertEquals("123456789", method.invoke(service, "123456789"));

        try {
            method.invoke(service, "1234567890");
            fail("Expected ApplicationException");
        } catch (Exception ex) {
            assertTrue(ex.getCause() instanceof ApplicationException);
        }
    }

    @Test
    public void privateCreateDocToSendCloudShouldDefaultSubscribeAndUseClassifier() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setFrequency("D");
        pref.setProviderEmailId("a@b.com");
        pref.setProviderName("Provider");
        pref.setAutoEdelUpdateInd("Y");
        pref.setOkToChangePDOInd("N");

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", null, null, null);

        assertEquals("Y", result.get("subscribeToEmail"));
        assertEquals("C1", result.get("fileName"));
        assertEquals("123456789", result.get("mpin"));
        assertEquals("987654321", result.get("tin"));
    }

    @Test
    public void privateCreateDocToSendWithClassifierCloudShouldSetInfiniteExpiryFor9999() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendWithClassifierCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setDeliveryMethod("E");
        pref.setFrequency("D");
        pref.setProviderEmailId("a@b.com");
        pref.setProviderName("Provider");
        pref.setAutoEdelUpdateInd("Y");
        pref.setOkToChangePDOInd("N");
        pref.setOptedOutDuration(9999);
        pref.setOptedOutDateTime("2024-01-01T00:00:00.000Z");

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", null, null, "C5");

        assertEquals("9999-12-31T23:59:59.000Z", result.get("expiryDate"));
        assertEquals("C5", result.get("fileName"));
    }

    @Test
    public void updateProviderPreferencesShouldHandleAllBranchWithNoSelectedProviders() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.emptyList());

        PreferenceType all = new PreferenceType();
        all.setClassifier("ALL");
        all.setDeliveryMethod("E");
        all.setFrequency("D");
        request.setPreferenceTypes(Collections.singletonList(all));

        service.updateProviderPreferences(request, new HttpHeaders());

        verify(ndbHandler, times(1)).ndbWebServicePrep();
    }

    @Test
    public void updateProviderPreferencesShouldHandleSpecificBranchWithNoSelectedProviders() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.emptyList());

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setFrequency("D");
        request.setPreferenceTypes(Collections.singletonList(pref));

        service.updateProviderPreferences(request, new HttpHeaders());

        verify(ndbHandler, times(1)).ndbWebServicePrep();
    }

    @Test
    public void updateProviderPreferencesFdsCloudShouldHandleAllBranchWithNoSelectedProviders() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.emptyList());

        PreferenceType all = new PreferenceType();
        all.setClassifier("ALL");
        all.setDeliveryMethod("E");
        all.setFrequency("D");
        request.setPreferenceTypes(Collections.singletonList(all));

        service.updateProviderPreferencesFDSCloud(request, new HttpHeaders());

        verify(ndbHandler, times(1)).ndbWebServicePrep();
    }

    @Test
    public void privateCreateDocToSendShouldHonorProvidedExpiryDate() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSend",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setFrequency("D");
        pref.setProviderEmailId("a@b.com");
        pref.setProviderName("Provider");
        pref.setAutoEdelUpdateInd("Y");
        pref.setOkToChangePDOInd("N");
        pref.setExpiryDate("2030-01-01T00:00:00.000Z");

        Document result = (Document) method.invoke(service, pref, "123456789", "987654321", "doc-1", null);

        assertNotNull(result);
        assertEquals("doc-1", result.getId());
        assertEquals("2030-01-01T00:00:00.000Z", result.getMetadata().getExpiryDate());
    }

    @Test
    public void privateCreateDocToSendShouldComputeExpiryWhenMissingAndDurationProvided() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSend",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setFrequency("D");
        pref.setProviderEmailId("a@b.com");
        pref.setProviderName("Provider");
        pref.setAutoEdelUpdateInd("Y");
        pref.setOkToChangePDOInd("N");
        pref.setOptedOutDuration(30);
        pref.setOptedOutDateTime("2024-01-01T00:00:00.000Z");

        Document result = (Document) method.invoke(service, pref, "123456789", "987654321", null, null);

        assertNotNull(result);
        assertNotNull(result.getMetadata().getExpiryDate());
    }

    @Test
    public void privateParseDateStringShouldParseIsoDate() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod("parseDateString", String.class);
        method.setAccessible(true);

        Date parsed = (Date) method.invoke(service, "2024-01-01T00:00:00.000Z");

        assertNotNull(parsed);
    }

    // ---- additional coverage tests ----

    private LetterPreferencesResponse buildSuccessfulNdbResponse(String classifier, String mailingPref) {
        LetterPreferencesResponse response = new LetterPreferencesResponse();
        ResponseHeader header = new ResponseHeader();
        header.setMessage("SUCCESSFUL");
        response.setResponseHeader(header);
        ResponseData data = new ResponseData();
        MailPref mp = new MailPref(classifier, mailingPref);
        data.setLtrTypMailPrfList(Collections.singletonList(mp));
        response.setRequestResponse(data);
        return response;
    }

    @Test
    public void getProviderPreferencesShouldThrowWhenNdbCallThrowsApplicationException() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenThrow(new ApplicationException("ndb timeout"));

        try {
            service.getProviderPreferences("123456789", "123456789", headers, logMessage);
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("ERROR RETRIEVING PREFERENCES FOR MPIN", ex.getMessage());
        }
    }

    @Test
    public void getProviderPreferencesShouldThrowWhenNdbMessageNotSuccessful() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        LetterPreferencesResponse ndbResponse = new LetterPreferencesResponse();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setMessage("FAILURE");
        ndbResponse.setResponseHeader(responseHeader);

        when(ndbHandler.getProviderLetterPreferences(any())).thenReturn(ndbResponse);

        try {
            service.getProviderPreferences("123456789", "123456789", headers, logMessage);
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("ERROR RETRIEVING PREFERENCES FOR MPIN", ex.getMessage());
        }
    }

    @Test
    public void getProviderPreferencesShouldReturnPrefsWhenNdbSuccessfulAndFdsHasNoDocs() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenReturn(buildSuccessfulNdbResponse("C1", "E"));

        FDSResponse emptyListResponse = new FDSResponse();
        emptyListResponse.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(emptyListResponse);

        FDSResponse emptySortedDocs = new FDSResponse();
        emptySortedDocs.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(emptySortedDocs);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        assertEquals("123456789", result.getCorporateTin());
        assertEquals(1, result.getPreferenceTypes().size());
        // docId should be null since no FDS docs
        assertNull(result.getPreferenceTypes().get(0).getDocumentId());
    }

    @Test
    public void getProviderPreferencesShouldComputeExpiryFor9999Duration() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenReturn(buildSuccessfulNdbResponse("C1", "E"));

        FDSResponse listResponse = new FDSResponse();
        Document providerDoc = new Document();
        Metadata providerMeta = new Metadata();
        providerMeta.setProviderName("Acme");
        providerDoc.setMetadata(providerMeta);
        listResponse.setDocuments(Collections.singletonList(providerDoc));
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(listResponse);

        FDSResponse sortedDocs = new FDSResponse();
        Document prefDoc = new Document();
        prefDoc.setId("doc-9999");
        Metadata prefMeta = new Metadata();
        prefMeta.setProviderEmailId("a@b.com");
        prefMeta.setFrequency("D");
        prefMeta.setOkToChangePDOInd("N");
        prefMeta.setAutoEdelUpdateInd("Y");
        prefMeta.setOptedOutDuration(9999);
        prefMeta.setOptedOutDateTime("2024-01-01T00:00:00.000Z");
        // expiryDate is null so computation branch triggered
        prefDoc.setMetadata(prefMeta);
        sortedDocs.setDocuments(Collections.singletonList(prefDoc));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(sortedDocs);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        assertEquals("9999-12-31T23:59:59.000Z", result.getPreferenceTypes().get(0).getExpiryDate());
    }

    @Test
    public void getProviderPreferencesShouldComputeExpiryForFiniteDuration() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenReturn(buildSuccessfulNdbResponse("C1", "E"));

        FDSResponse listResponse = new FDSResponse();
        Document providerDoc = new Document();
        Metadata providerMeta = new Metadata();
        providerMeta.setProviderName("Acme");
        providerDoc.setMetadata(providerMeta);
        listResponse.setDocuments(Collections.singletonList(providerDoc));
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(listResponse);

        FDSResponse sortedDocs = new FDSResponse();
        Document prefDoc = new Document();
        prefDoc.setId("doc-30");
        Metadata prefMeta = new Metadata();
        prefMeta.setOptedOutDuration(30);
        prefMeta.setOptedOutDateTime("2024-01-01T00:00:00.000Z");
        prefDoc.setMetadata(prefMeta);
        sortedDocs.setDocuments(Collections.singletonList(prefDoc));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(sortedDocs);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        // should be computed from optedOutDateTime + 30 days
        assertNotNull(result.getPreferenceTypes().get(0).getExpiryDate());
    }

    @Test
    public void getProviderPreferencesShouldUseTwoDocScenario() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenReturn(buildSuccessfulNdbResponse("C1", "E"));

        FDSResponse listResponse = new FDSResponse();
        Document providerDoc = new Document();
        Metadata providerMeta = new Metadata();
        providerMeta.setProviderName("Acme");
        providerDoc.setMetadata(providerMeta);
        listResponse.setDocuments(Collections.singletonList(providerDoc));
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(listResponse);

        // two documents: first has past active date (autoEnrollment, valid), second has no active date
        FDSResponse sortedDocs = new FDSResponse();
        Document doc0 = new Document();
        doc0.setId("auto-doc");
        Metadata meta0 = new Metadata();
        String pastDate = OffsetDateTime.now(ZoneOffset.UTC).minusDays(1)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
        meta0.setActiveDate(pastDate);
        meta0.setProviderEmailId("auto@test.com");
        doc0.setMetadata(meta0);

        Document doc1 = new Document();
        doc1.setId("pre-auto-doc");
        Metadata meta1 = new Metadata();
        meta1.setProviderEmailId("pre@test.com");
        doc1.setMetadata(meta1);

        sortedDocs.setDocuments(Arrays.asList(doc0, doc1));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(sortedDocs);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        assertEquals("auto-doc", result.getPreferenceTypes().get(0).getDocumentId());
        assertEquals("auto@test.com", result.getPreferenceTypes().get(0).getProviderEmailId());
    }

    @Test
    public void getProviderPreferencesShouldPickPreAutoDocWhenAutoEnrollmentFutureInTwoDocScenario() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenReturn(buildSuccessfulNdbResponse("C1", "E"));

        FDSResponse listResponse = new FDSResponse();
        Document providerDoc = new Document();
        Metadata providerMeta = new Metadata();
        providerDoc.setMetadata(providerMeta);
        listResponse.setDocuments(Collections.singletonList(providerDoc));
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(listResponse);

        // two documents: first has future active date (autoEnrollment, NOT valid), second has no active date (pre-auto)
        FDSResponse sortedDocs = new FDSResponse();
        Document doc0 = new Document();
        doc0.setId("auto-doc");
        Metadata meta0 = new Metadata();
        String futureDate = OffsetDateTime.now(ZoneOffset.UTC).plusDays(5)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
        meta0.setActiveDate(futureDate);
        meta0.setProviderEmailId("auto@test.com");
        doc0.setMetadata(meta0);

        Document doc1 = new Document();
        doc1.setId("pre-auto-doc");
        Metadata meta1 = new Metadata();
        meta1.setProviderEmailId("pre@test.com");
        doc1.setMetadata(meta1);

        sortedDocs.setDocuments(Arrays.asList(doc0, doc1));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(sortedDocs);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        assertEquals("pre-auto-doc", result.getPreferenceTypes().get(0).getDocumentId());
    }

    @Test
    public void getProviderPreferencesShouldReturnNoDocIdWhenBothDocsHaveFutureActiveDates() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenReturn(buildSuccessfulNdbResponse("C1", "E"));

        FDSResponse listResponse = new FDSResponse();
        Document providerDoc = new Document();
        providerDoc.setMetadata(new Metadata());
        listResponse.setDocuments(Collections.singletonList(providerDoc));
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(listResponse);

        // both docs have future active date -> determineMulti returns -1 -> docIndex = -1 -> no doc set
        FDSResponse sortedDocs = new FDSResponse();
        String futureDate = OffsetDateTime.now(ZoneOffset.UTC).plusDays(5)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));

        Document doc0 = new Document();
        doc0.setId("auto-doc-0");
        Metadata meta0 = new Metadata();
        meta0.setActiveDate(futureDate);
        doc0.setMetadata(meta0);

        Document doc1 = new Document();
        doc1.setId("auto-doc-1");
        Metadata meta1 = new Metadata();
        meta1.setActiveDate(futureDate);
        doc1.setMetadata(meta1);

        sortedDocs.setDocuments(Arrays.asList(doc0, doc1));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(sortedDocs);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        assertNull(result.getPreferenceTypes().get(0).getDocumentId());
    }

    @Test
    public void privateCreateDocToSendCloudShouldUseSubscribeToEmailFromExistingDoc() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setFrequency("D");
        pref.setProviderEmailId("a@b.com");
        pref.setProviderName("Provider");
        pref.setAutoEdelUpdateInd("Y");
        pref.setOkToChangePDOInd("N");
        // subscribeToEmail NOT set on pref, but provided as existing doc value

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", null, null, "N");

        assertEquals("N", result.get("subscribeToEmail"));
    }

    @Test
    public void privateCreateDocToSendCloudShouldUseSubscribeToEmailFromPref() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setFrequency("D");
        pref.setProviderEmailId("a@b.com");
        pref.setProviderName("Provider");
        pref.setSubscribeToEmail("N");

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", null, null, null);

        assertEquals("N", result.get("subscribeToEmail"));
    }

    @Test
    public void determineDocumentIndexCloudShouldMarkFutureActiveDateAsInvalidAuto() throws Exception {
        String future = OffsetDateTime.now(ZoneOffset.UTC).plusDays(1)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        doc.setMetadata("{\"activeDate\":\"" + future + "\"}");

        ProviderPreferenceServiceImpl.AutoEnrollment result = service.determineDocumentIndexCloud(
                Collections.singletonList(doc),
                1,
                0,
                OffsetDateTime.now(ZoneOffset.UTC)
        );

        assertTrue(result.isAutoEnrollment());
        assertFalse(result.isValidAutoEnrollment());
    }

    @Test
    public void determineMultiShouldPickFirstNonAutoEnrollmentWhenSecondIsAuto() {
        ProviderPreferenceServiceImpl.AutoEnrollment first = service.new AutoEnrollment(false, 0);
        ProviderPreferenceServiceImpl.AutoEnrollment second = service.new AutoEnrollment(true, -1);

        int result = service.determineMulti(first, second);

        assertEquals(0, result);
    }

    @Test
    public void getProviderPreferencesShouldSetExpiryDateDirectlyWhenPresent() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenReturn(buildSuccessfulNdbResponse("C1", "E"));

        FDSResponse listResponse = new FDSResponse();
        Document providerDoc = new Document();
        providerDoc.setMetadata(new Metadata());
        listResponse.setDocuments(Collections.singletonList(providerDoc));
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(listResponse);

        FDSResponse sortedDocs = new FDSResponse();
        Document prefDoc = new Document();
        prefDoc.setId("doc-with-expiry");
        Metadata prefMeta = new Metadata();
        prefMeta.setExpiryDate("2030-01-01T00:00:00.000Z");
        prefDoc.setMetadata(prefMeta);
        sortedDocs.setDocuments(Collections.singletonList(prefDoc));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(sortedDocs);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        assertEquals("2030-01-01T00:00:00.000Z", result.getPreferenceTypes().get(0).getExpiryDate());
    }

    @Test
    public void getProviderPreferencesShouldHandleDocWithFutureActiveDateInSingleDocScenario() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenReturn(buildSuccessfulNdbResponse("C1", "E"));

        FDSResponse listResponse = new FDSResponse();
        Document providerDoc = new Document();
        providerDoc.setMetadata(new Metadata());
        listResponse.setDocuments(Collections.singletonList(providerDoc));
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(listResponse);

        // single doc with future active date -> isAutoEnrollment=true, isValidAutoEnrollment=false -> docIndex stays -1
        FDSResponse sortedDocs = new FDSResponse();
        Document prefDoc = new Document();
        prefDoc.setId("future-doc");
        Metadata prefMeta = new Metadata();
        String futureDate = OffsetDateTime.now(ZoneOffset.UTC).plusDays(5)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
        prefMeta.setActiveDate(futureDate);
        prefDoc.setMetadata(prefMeta);
        sortedDocs.setDocuments(Collections.singletonList(prefDoc));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(sortedDocs);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        assertNull(result.getPreferenceTypes().get(0).getDocumentId());
    }

    @Test
    public void privateCreateDocToSendWithClassifierCloudShouldComputeExpiryForFiniteDuration() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendWithClassifierCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setDeliveryMethod("E");
        pref.setFrequency("D");
        pref.setProviderEmailId("a@b.com");
        pref.setProviderName("Provider");
        pref.setAutoEdelUpdateInd("Y");
        pref.setOkToChangePDOInd("N");
        pref.setOptedOutDuration(30);
        pref.setOptedOutDateTime("2024-01-01T00:00:00.000Z");

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", null, null, "C1");

        assertNotNull(result.get("expiryDate"));
    }

    @Test
    public void privateCreateDocToSendShouldSet9999ExpiryWhenDurationIs9999() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSend",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setFrequency("D");
        pref.setProviderEmailId("a@b.com");
        pref.setProviderName("Provider");
        pref.setAutoEdelUpdateInd("Y");
        pref.setOkToChangePDOInd("N");
        pref.setOptedOutDuration(9999);
        pref.setOptedOutDateTime("2024-01-01T00:00:00.000Z");

        Document result = (Document) method.invoke(service, pref, "123456789", "987654321", null, null);

        assertNotNull(result);
        assertEquals("9999-12-31T23:59:59.000Z", result.getMetadata().getExpiryDate());
    }

    @Test
    public void privateCreateDocToSendShouldSetActiveDateFromPrefWhenPresent() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSend",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setActiveDate("2025-01-01T00:00:00.000+00:00");

        Document result = (Document) method.invoke(service, pref, "123456789", "987654321", null, null);

        assertEquals("2025-01-01T00:00:00.000+00:00", result.getMetadata().getActiveDate());
    }

    @Test
    public void privateCreateDocToSendShouldSetActiveDateFromExistingDocWhenPrefActiveDateNull() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSend",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");

        Document result = (Document) method.invoke(service, pref, "123456789", "987654321", "doc-123", "2025-06-01T00:00:00.000+00:00");

        assertEquals("2025-06-01T00:00:00.000+00:00", result.getMetadata().getActiveDate());
    }

    // ---- createDocToSendWithClassifier (private, non-cloud) coverage ----

    @Test
    public void privateCreateDocToSendWithClassifierShouldSetActiveDateFromPref() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendWithClassifier",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setDeliveryMethod("E");
        pref.setActiveDate("2025-03-01T00:00:00.000+00:00");

        Document result = (Document) method.invoke(service, pref, "123456789", "987654321", "doc-1", null, "C1");

        assertNotNull(result);
        assertEquals("2025-03-01T00:00:00.000+00:00", result.getMetadata().getActiveDate());
        assertEquals("C1", result.getMetadata().getFileName());
    }

    @Test
    public void privateCreateDocToSendWithClassifierShouldUseActiveDateFromExistingDoc() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendWithClassifier",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setDeliveryMethod("E");
        // activeDate is null on pref — should pick up from activeDateStr

        Document result = (Document) method.invoke(service, pref, "123456789", "987654321", null, "2025-07-01T00:00:00.000+00:00", "C2");

        assertNotNull(result);
        assertEquals("2025-07-01T00:00:00.000+00:00", result.getMetadata().getActiveDate());
        assertEquals("C2", result.getMetadata().getFileName());
    }

    @Test
    public void privateCreateDocToSendWithClassifierShouldSet9999Expiry() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendWithClassifier",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setDeliveryMethod("E");
        pref.setOptedOutDuration(9999);
        pref.setOptedOutDateTime("2024-01-01T00:00:00.000Z");

        Document result = (Document) method.invoke(service, pref, "123456789", "987654321", null, null, "C3");

        assertEquals("9999-12-31T23:59:59.000Z", result.getMetadata().getExpiryDate());
    }

    @Test
    public void privateCreateDocToSendWithClassifierShouldComputeExpiryForFiniteDuration() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendWithClassifier",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setDeliveryMethod("E");
        pref.setOptedOutDuration(60);
        pref.setOptedOutDateTime("2024-01-01T00:00:00.000Z");

        Document result = (Document) method.invoke(service, pref, "123456789", "987654321", null, null, "C4");

        assertNotNull(result.getMetadata().getExpiryDate());
    }

    @Test
    public void privateCreateDocToSendWithClassifierShouldHonorExistingExpiryDate() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendWithClassifier",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setDeliveryMethod("E");
        pref.setExpiryDate("2031-06-01T00:00:00.000Z");

        Document result = (Document) method.invoke(service, pref, "123456789", "987654321", "doc-99", null, "C5");

        assertEquals("2031-06-01T00:00:00.000Z", result.getMetadata().getExpiryDate());
    }

    // ---- createDocToSendWithClassifierCloud active-date branches ----

    @Test
    public void privateCreateDocToSendWithClassifierCloudShouldSetActiveDateFromPref() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendWithClassifierCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setDeliveryMethod("E");
        pref.setActiveDate("2025-05-01T00:00:00.000+00:00");

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", "doc-1", null, "C1");

        assertEquals("2025-05-01T00:00:00.000+00:00", result.get("activeDate"));
    }

    @Test
    public void privateCreateDocToSendWithClassifierCloudShouldUseActiveDateFromExistingDoc() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendWithClassifierCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setDeliveryMethod("E");

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", null, "2025-08-01T00:00:00.000+00:00", "C2");

        assertEquals("2025-08-01T00:00:00.000+00:00", result.get("activeDate"));
    }

    @Test
    public void privateCreateDocToSendWithClassifierCloudShouldHonorExistingExpiryDate() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendWithClassifierCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setDeliveryMethod("E");
        pref.setExpiryDate("2033-01-01T00:00:00.000Z");

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", null, null, "C3");

        assertEquals("2033-01-01T00:00:00.000Z", result.get("expiryDate"));
    }

    // ---- createDocToSendCloud active-date branches ----

    @Test
    public void privateCreateDocToSendCloudShouldSetActiveDateFromPref() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setActiveDate("2026-01-01T00:00:00.000+00:00");

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", null, null, null);

        assertEquals("2026-01-01T00:00:00.000+00:00", result.get("activeDate"));
    }

    @Test
    public void privateCreateDocToSendCloudShouldSetActiveDateFromExistingDoc() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", "doc-id-1", "2025-09-01T00:00:00.000+00:00", null);

        assertEquals("2025-09-01T00:00:00.000+00:00", result.get("activeDate"));
    }

    @Test
    public void privateCreateDocToSendCloudShouldCompute9999Expiry() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setOptedOutDuration(9999);
        pref.setOptedOutDateTime("2024-01-01T00:00:00.000Z");

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", null, null, null);

        assertEquals("9999-12-31T23:59:59.000Z", result.get("expiryDate"));
    }

    @Test
    public void privateCreateDocToSendCloudShouldComputeExpiryForFiniteDuration() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setOptedOutDuration(45);
        pref.setOptedOutDateTime("2024-01-01T00:00:00.000Z");

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", null, null, null);

        assertNotNull(result.get("expiryDate"));
    }

    @Test
    public void privateCreateDocToSendCloudShouldHonorDirectExpiryDate() throws Exception {
        Method method = ProviderPreferenceServiceImpl.class.getDeclaredMethod(
                "createDocToSendCloud",
                PreferenceType.class,
                String.class,
                String.class,
                String.class,
                String.class,
                String.class
        );
        method.setAccessible(true);

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setExpiryDate("2035-06-01T00:00:00.000Z");

        @SuppressWarnings("unchecked")
        Map<String, Object> result = (Map<String, Object>) method.invoke(service, pref, "123456789", "987654321", null, null, null);

        assertEquals("2035-06-01T00:00:00.000Z", result.get("expiryDate"));
    }

    // ---- determineMulti additional branch ----

    @Test
    public void determineMultiShouldPickSecondNonAutoEnrollmentWhenFirstIsInvalidAuto() {
        // both are "auto" (isAutoEnrollment=true) but first has index -1 (not valid)
        // and second is NOT auto (isAutoEnrollment=false), index 1 → should return 1
        ProviderPreferenceServiceImpl.AutoEnrollment first = service.new AutoEnrollment(true, -1);
        ProviderPreferenceServiceImpl.AutoEnrollment second = service.new AutoEnrollment(false, 1);

        int result = service.determineMulti(first, second);

        assertEquals(1, result);
    }

    // ---- updateProviderPreferencesFDSCloud specific branch with empty selected providers ----

    @Test
    public void updateProviderPreferencesFdsCloudShouldHandleSpecificBranchWithNoSelectedProviders() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.emptyList());

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setFrequency("D");
        request.setPreferenceTypes(Collections.singletonList(pref));

        service.updateProviderPreferencesFDSCloud(request, new HttpHeaders());

        verify(ndbHandler, times(1)).ndbWebServicePrep();
    }

    // ---- AutoEnrollment inner class index accessor ----

    @Test
    public void autoEnrollmentShouldExposeIndexViaIsValidAutoEnrollment() {
        ProviderPreferenceServiceImpl.AutoEnrollment ae = service.new AutoEnrollment(true, 2);
        assertTrue(ae.isAutoEnrollment());
        assertTrue(ae.isValidAutoEnrollment());

        ProviderPreferenceServiceImpl.AutoEnrollment ae2 = service.new AutoEnrollment(false, 0);
        assertFalse(ae2.isAutoEnrollment());
        assertFalse(ae2.isValidAutoEnrollment()); // not auto, so isAutoEnrollment && index != -1 → false
    }

    // ---- getProviderPreferences with NDB CUCUMBERTEST + multiple classifiers ----

    @Test
    public void getProviderPreferencesCucumberFlowShouldHandleMultipleClassifiers() throws Exception {
        String tin = "123456789";
        String mpin = "123456789";
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");

        LogMessage logMessage = new LogMessage();
        logMessage.setUsername("CUCUMBERTEST");
        logMessage.setActor("C2");

        FDSResponse listResponse = new FDSResponse();
        listResponse.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(listResponse);

        FDSResponse emptySortedDocs = new FDSResponse();
        emptySortedDocs.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(emptySortedDocs);

        ProviderPreferencesObj result = service.getProviderPreferences(tin, mpin, headers, logMessage);

        assertNotNull(result);
        assertEquals(tin, result.getCorporateTin());
        assertEquals(1, result.getPreferenceTypes().size());
        assertEquals("C2", result.getPreferenceTypes().get(0).getClassifier());
    }

    // ---- getProviderPreferences: NDB successful, FDS list has no provider name ----

    @Test
    public void getProviderPreferencesShouldHandleEmptyFDSListDocuments() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenReturn(buildSuccessfulNdbResponse("C1", "E"));

        FDSResponse emptyListResponse = new FDSResponse();
        emptyListResponse.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(emptyListResponse);

        FDSResponse sortedDocsWithDoc = new FDSResponse();
        Document d = new Document();
        d.setId("doc-xyz");
        Metadata m = new Metadata();
        m.setProviderEmailId("e@mail.com");
        d.setMetadata(m);
        sortedDocsWithDoc.setDocuments(Collections.singletonList(d));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(sortedDocsWithDoc);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        assertNull(result.getCorporateName()); // no provider name set since list was empty
        assertEquals("doc-xyz", result.getPreferenceTypes().get(0).getDocumentId());
    }

    // ---- getProviderPreferences: mpin shorter than 9 gets padded ----

    @Test
    public void getProviderPreferencesShouldPadShortMpin() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();
        logMessage.setUsername("CUCUMBERTEST");
        logMessage.setActor("C1");

        FDSResponse emptyList = new FDSResponse();
        emptyList.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(emptyList);

        FDSResponse emptyDocs = new FDSResponse();
        emptyDocs.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(emptyDocs);

        // mpin = "123" (shorter than 9) should get padded to "000000123"
        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123", headers, logMessage);

        assertNotNull(result);
    }

    // ---- getProviderPreferencesFDSCloud: mpin > 9 digits ----

    @Test
    public void getProviderPreferencesFDSCloudShouldThrowForLongMpin() {
        try {
            service.getProviderPreferencesFDSCloud("123456789", "1234567890", new HttpHeaders(), new LogMessage());
            fail("Expected ApplicationException");
        } catch (Exception ex) {
            assertTrue(ex instanceof ApplicationException);
            assertEquals("MPIN longer than 9 digits", ex.getMessage());
        }
    }

    // ---- getProviderPreferencesFDSCloud: NDB returns null message ----

    @Test
    public void getProviderPreferencesFDSCloudShouldThrowWhenNdbMessageNull() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        LetterPreferencesResponse ndbResponse = new LetterPreferencesResponse();
        ResponseHeader rh = new ResponseHeader();
        rh.setMessage(null);
        ndbResponse.setResponseHeader(rh);
        when(ndbHandler.getProviderLetterPreferences(any())).thenReturn(ndbResponse);

        try {
            service.getProviderPreferencesFDSCloud("123456789", "123456789", headers, logMessage);
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("ERROR RETRIEVING PREFERENCES FOR MPIN", ex.getMessage());
        }
    }

    // ---- getProviderPreferencesFDSCloud: NDB non-SUCCESSFUL message ----

    @Test
    public void getProviderPreferencesFDSCloudShouldThrowWhenNdbMessageNotSuccessful() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        LetterPreferencesResponse ndbResponse = new LetterPreferencesResponse();
        ResponseHeader rh = new ResponseHeader();
        rh.setMessage("ERROR");
        ndbResponse.setResponseHeader(rh);
        when(ndbHandler.getProviderLetterPreferences(any())).thenReturn(ndbResponse);

        try {
            service.getProviderPreferencesFDSCloud("123456789", "123456789", headers, logMessage);
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("ERROR RETRIEVING PREFERENCES FOR MPIN", ex.getMessage());
        }
    }

    // ---- getProviderPreferencesFDSCloud: NDB throws ApplicationException ----

    @Test
    public void getProviderPreferencesFDSCloudShouldThrowWhenNdbCallFails() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenThrow(new ApplicationException("ndb down"));

        try {
            service.getProviderPreferencesFDSCloud("123456789", "123456789", headers, logMessage);
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("ERROR RETRIEVING PREFERENCES FOR MPIN", ex.getMessage());
        }
    }

    // ---- printDocument edge cases ----

    @Test
    public void printDocumentShouldHandleNullFields() {
        Metadata metadata = new Metadata();
        // all fields null
        String result = service.printDocument(metadata);
        assertNotNull(result);
        assertTrue(result.contains("providerEmailId = null"));
        assertTrue(result.contains("mpin = null"));
        assertTrue(result.contains("fileName= null"));
    }

    // ---- determineDocumentIndex with empty activeDate string ----

    @Test
    public void determineDocumentIndexShouldTreatEmptyActiveDateAsNonAuto() {
        Metadata metadata = new Metadata();
        metadata.setActiveDate("");
        Document doc = new Document();
        doc.setMetadata(metadata);

        ProviderPreferenceServiceImpl.AutoEnrollment result = service.determineDocumentIndex(
                Collections.singletonList(doc),
                1,
                0,
                OffsetDateTime.now(ZoneOffset.UTC)
        );

        assertFalse(result.isAutoEnrollment());
        assertFalse(result.isValidAutoEnrollment());
    }

    // ---- determineDocumentIndexCloud with empty activeDate string ----

    @Test
    public void determineDocumentIndexCloudShouldTreatEmptyActiveDateAsNonAuto() throws Exception {
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        doc.setMetadata("{\"activeDate\":\"\"}");

        ProviderPreferenceServiceImpl.AutoEnrollment result = service.determineDocumentIndexCloud(
                Collections.singletonList(doc),
                1,
                0,
                OffsetDateTime.now(ZoneOffset.UTC)
        );

        assertFalse(result.isAutoEnrollment());
        assertFalse(result.isValidAutoEnrollment());
    }

    // ---- getProviderPreferences with NDB response returning multiple MailPrefs ----

    // ---- updateProviderPreferences with actual providers (ALL branch) ----

    @Test
    public void updateProviderPreferencesShouldCallFdsForEachClassifierWhenAllBranchWithOneProvider() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType all = new PreferenceType();
        all.setClassifier("ALL");
        all.setDeliveryMethod("E");
        all.setFrequency("D");
        request.setPreferenceTypes(Collections.singletonList(all));

        FDSResponse emptyResp = new FDSResponse();
        emptyResp.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(emptyResp);

        service.updateProviderPreferences(request, new HttpHeaders());

        verify(ndbHandler, times(1)).ndbWebServicePrep();
        // callFDSPostDocument should be called once per classifier
        verify(fdsHandler, org.mockito.Mockito.atLeastOnce())
                .callFDSPostDocument(any(), any(), any());
    }

    @Test
    public void updateProviderPreferencesShouldPutDocumentWhenFdsHasExistingDocAllBranch() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType all = new PreferenceType();
        all.setClassifier("ALL");
        all.setDeliveryMethod("E");
        all.setFrequency("D");
        request.setPreferenceTypes(Collections.singletonList(all));

        // Return a doc with no active date (non-auto) so docIndex = 0 → PUT path
        FDSResponse resp = new FDSResponse();
        Document d = new Document();
        d.setId("existing-doc");
        Metadata m = new Metadata();
        d.setMetadata(m);
        resp.setDocuments(Collections.singletonList(d));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(resp);

        service.updateProviderPreferences(request, new HttpHeaders());

        verify(fdsHandler, org.mockito.Mockito.atLeastOnce())
                .callFDSPutDocument(any(), any(), any(), any());
    }

    @Test
    public void updateProviderPreferencesShouldHandleFutureActiveDateDocAllBranch() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType all = new PreferenceType();
        all.setClassifier("ALL");
        all.setDeliveryMethod("E");
        request.setPreferenceTypes(Collections.singletonList(all));

        // Single doc with future active date → docIndex = -2 → POST (create pre-auto)
        FDSResponse resp = new FDSResponse();
        Document d = new Document();
        d.setId("auto-doc");
        Metadata m = new Metadata();
        String future = OffsetDateTime.now(ZoneOffset.UTC).plusDays(10)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
        m.setActiveDate(future);
        d.setMetadata(m);
        resp.setDocuments(Collections.singletonList(d));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(resp);

        service.updateProviderPreferences(request, new HttpHeaders());

        verify(fdsHandler, org.mockito.Mockito.atLeastOnce())
                .callFDSPostDocument(any(), any(), any());
    }

    // ---- updateProviderPreferences specific branch with actual providers ----

    @Test
    public void updateProviderPreferencesShouldCallFdsForSpecificPrefWithOneProvider() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        pref.setFrequency("D");
        request.setPreferenceTypes(Collections.singletonList(pref));

        FDSResponse emptyResp = new FDSResponse();
        emptyResp.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(emptyResp);

        service.updateProviderPreferences(request, new HttpHeaders());

        verify(fdsHandler, times(1)).callFDSPostDocument(any(), any(), any());
    }

    @Test
    public void updateProviderPreferencesShouldPutDocumentWhenFdsHasExistingDocSpecificBranch() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        request.setPreferenceTypes(Collections.singletonList(pref));

        FDSResponse resp = new FDSResponse();
        Document d = new Document();
        d.setId("doc-c1");
        Metadata m = new Metadata();
        d.setMetadata(m);
        resp.setDocuments(Collections.singletonList(d));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(resp);

        service.updateProviderPreferences(request, new HttpHeaders());

        verify(fdsHandler, times(1)).callFDSPutDocument(any(), any(), any(), any());
    }

    @Test
    public void updateProviderPreferencesShouldHandleFutureActiveDateDocSpecificBranch() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        request.setPreferenceTypes(Collections.singletonList(pref));

        FDSResponse resp = new FDSResponse();
        Document d = new Document();
        d.setId("future-auto");
        Metadata m = new Metadata();
        String future = OffsetDateTime.now(ZoneOffset.UTC).plusDays(5)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
        m.setActiveDate(future);
        d.setMetadata(m);
        resp.setDocuments(Collections.singletonList(d));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(resp);

        service.updateProviderPreferences(request, new HttpHeaders());

        verify(fdsHandler, times(1)).callFDSPostDocument(any(), any(), any());
    }

    @Test
    public void updateProviderPreferencesShouldHandleTwoDocsSpecificBranch() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        request.setPreferenceTypes(Collections.singletonList(pref));

        // Two docs: first has past active date → docIndex = 0 → PUT
        String past = OffsetDateTime.now(ZoneOffset.UTC).minusDays(1)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
        FDSResponse resp = new FDSResponse();
        Document d0 = new Document();
        d0.setId("auto-past");
        Metadata m0 = new Metadata();
        m0.setActiveDate(past);
        d0.setMetadata(m0);
        Document d1 = new Document();
        d1.setId("pre-auto");
        Metadata m1 = new Metadata();
        d1.setMetadata(m1);
        resp.setDocuments(Arrays.asList(d0, d1));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(resp);

        service.updateProviderPreferences(request, new HttpHeaders());

        verify(fdsHandler, times(1)).callFDSPutDocument(any(), any(), any(), any());
    }

    @Test
    public void updateProviderPreferencesShouldSwallowNdbUpdateException() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        request.setPreferenceTypes(Collections.singletonList(pref));

        when(ndbHandler.updateProviderLetterPreferences(any(), any(), any()))
                .thenThrow(new com.fasterxml.jackson.core.JsonProcessingException("json error") {});

        FDSResponse emptyResp = new FDSResponse();
        emptyResp.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(emptyResp);

        // Should not throw — exception is swallowed with logger.warn
        service.updateProviderPreferences(request, new HttpHeaders());

        verify(ndbHandler, times(1)).ndbWebServicePrep();
    }

    @Test
    public void updateProviderPreferencesShouldSwallowFdsPutException() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        request.setPreferenceTypes(Collections.singletonList(pref));

        FDSResponse resp = new FDSResponse();
        Document d = new Document();
        d.setId("doc-c1");
        Metadata m = new Metadata();
        d.setMetadata(m);
        resp.setDocuments(Collections.singletonList(d));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(resp);
        when(fdsHandler.callFDSPutDocument(any(), any(), any(), any()))
                .thenThrow(new org.springframework.web.client.RestClientException("put failed"));

        // Should not throw — exception is caught with logger.warn and continue
        service.updateProviderPreferences(request, new HttpHeaders());

        verify(fdsHandler, times(1)).callFDSPutDocument(any(), any(), any(), any());
    }

    @Test
    public void updateProviderPreferencesShouldSwallowFdsPostException() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        request.setPreferenceTypes(Collections.singletonList(pref));

        FDSResponse emptyResp = new FDSResponse();
        emptyResp.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(emptyResp);
        when(fdsHandler.callFDSPostDocument(any(), any(), any()))
                .thenThrow(new java.io.IOException("post failed"));

        // Should not throw — exception caught with logger.warn and continue
        service.updateProviderPreferences(request, new HttpHeaders());

        verify(fdsHandler, times(1)).callFDSPostDocument(any(), any(), any());
    }

    // ---- updateProviderPreferences ALL branch with provider, FDS PUT exception swallowed ----

    @Test
    public void updateProviderPreferencesAllBranchShouldSwallowFdsPutException() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType all = new PreferenceType();
        all.setClassifier("ALL");
        all.setDeliveryMethod("E");
        request.setPreferenceTypes(Collections.singletonList(all));

        FDSResponse resp = new FDSResponse();
        Document d = new Document();
        d.setId("doc-id");
        Metadata m = new Metadata();
        d.setMetadata(m);
        resp.setDocuments(Collections.singletonList(d));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(resp);
        when(fdsHandler.callFDSPutDocument(any(), any(), any(), any()))
                .thenThrow(new org.springframework.web.client.RestClientException("put error"));

        service.updateProviderPreferences(request, new HttpHeaders());

        verify(fdsHandler, org.mockito.Mockito.atLeastOnce()).callFDSPutDocument(any(), any(), any(), any());
    }

    // ---- getProviderPreferences with expiryDate set to short string (triggers compute) ----

    @Test
    public void getProviderPreferencesShouldComputeExpiryWhenExpiryDateTooShort() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenReturn(buildSuccessfulNdbResponse("C1", "E"));

        FDSResponse listResp = new FDSResponse();
        Document pd = new Document();
        pd.setMetadata(new Metadata());
        listResp.setDocuments(Collections.singletonList(pd));
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(listResp);

        FDSResponse sorted = new FDSResponse();
        Document d = new Document();
        d.setId("short-expiry-doc");
        Metadata m = new Metadata();
        m.setOptedOutDuration(30);
        m.setOptedOutDateTime("2024-01-01T00:00:00.000Z");
        m.setExpiryDate("short"); // length < reference length triggers compute
        d.setMetadata(m);
        sorted.setDocuments(Collections.singletonList(d));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(sorted);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        assertNotNull(result.getPreferenceTypes().get(0).getExpiryDate());
    }

    // ---- getProviderPreferences with expiryDate set to empty string (triggers compute) ----

    @Test
    public void getProviderPreferencesShouldComputeExpiryWhenExpiryDateEmpty() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenReturn(buildSuccessfulNdbResponse("C1", "E"));

        FDSResponse listResp = new FDSResponse();
        Document pd = new Document();
        pd.setMetadata(new Metadata());
        listResp.setDocuments(Collections.singletonList(pd));
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(listResp);

        FDSResponse sorted = new FDSResponse();
        Document d = new Document();
        d.setId("empty-expiry");
        Metadata m = new Metadata();
        m.setOptedOutDuration(9999);
        m.setOptedOutDateTime("2024-01-01T00:00:00.000Z");
        m.setExpiryDate(""); // empty triggers compute → 9999
        d.setMetadata(m);
        sorted.setDocuments(Collections.singletonList(d));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(sorted);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        assertEquals("9999-12-31T23:59:59.000Z", result.getPreferenceTypes().get(0).getExpiryDate());
    }

    // ---- getProviderPreferences NDB message null → already tested but confirming ERROR CALLING NDB path ----

    @Test
    public void getProviderPreferencesShouldThrowErrorCallingNdbWhenNdbMessageNull() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        LetterPreferencesResponse resp = new LetterPreferencesResponse();
        ResponseHeader rh = new ResponseHeader();
        rh.setMessage(null);
        resp.setResponseHeader(rh);
        when(ndbHandler.getProviderLetterPreferences(any())).thenReturn(resp);

        try {
            service.getProviderPreferences("123456789", "123456789", headers, logMessage);
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("ERROR RETRIEVING PREFERENCES FOR MPIN", ex.getMessage());
        }
    }

    // ---- getProviderData wraps RestClientException ----

    @Test
    public void getProviderDataShouldWrapRestClientException() throws Exception {
        when(ndbHandler.getProviderData(any(RequestData.class)))
                .thenThrow(new org.springframework.web.client.RestClientException("network"));

        try {
            service.getProviderData(new RequestData(), new HttpHeaders(), new LogMessage());
            fail("Expected ApplicationException");
        } catch (ApplicationException ex) {
            assertEquals("Error making service call to NDB", ex.getMessage());
        }
    }

    // ---- updateProviderPreferences with multiple preference types (non-ALL, multiple prefs) ----

    @Test
    public void updateProviderPreferencesShouldProcessMultipleSpecificPrefsForOneProvider() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType pref1 = new PreferenceType();
        pref1.setClassifier("C1");
        pref1.setDeliveryMethod("E");

        PreferenceType pref2 = new PreferenceType();
        pref2.setClassifier("C2");
        pref2.setDeliveryMethod("M");

        request.setPreferenceTypes(Arrays.asList(pref1, pref2));

        FDSResponse empty = new FDSResponse();
        empty.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(empty);

        service.updateProviderPreferences(request, new HttpHeaders());

        verify(fdsHandler, times(2)).callFDSPostDocument(any(), any(), any());
    }

    // ---- updateProviderPreferences two-doc case in specific branch ----

    @Test
    public void updateProviderPreferencesShouldHandleTwoDocsWithBothFutureActiveDatesSpecificBranch() throws Exception {
        ProviderPreferencesObj request = new ProviderPreferencesObj();
        request.setCorporateTin("123456789");
        request.setSelectedProviders(Collections.singletonList("123456789"));

        PreferenceType pref = new PreferenceType();
        pref.setClassifier("C1");
        pref.setDeliveryMethod("E");
        request.setPreferenceTypes(Collections.singletonList(pref));

        // Both docs future → determineMulti returns -1 → no PUT or POST
        String future = OffsetDateTime.now(ZoneOffset.UTC).plusDays(5)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
        FDSResponse resp = new FDSResponse();
        Document d0 = new Document();
        d0.setId("d0");
        Metadata m0 = new Metadata();
        m0.setActiveDate(future);
        d0.setMetadata(m0);
        Document d1 = new Document();
        d1.setId("d1");
        Metadata m1 = new Metadata();
        m1.setActiveDate(future);
        d1.setMetadata(m1);
        resp.setDocuments(Arrays.asList(d0, d1));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(resp);

        service.updateProviderPreferences(request, new HttpHeaders());

        verify(fdsHandler, times(0)).callFDSPutDocument(any(), any(), any(), any());
        verify(fdsHandler, times(0)).callFDSPostDocument(any(), any(), any());
    }

    // ---- getProviderPreferences two-doc case where second doc is also auto but past (edge case) ----

    @Test
    public void getProviderPreferencesShouldPickFirstDocWhenBothAutoAndFirstIsPast() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        when(ndbHandler.getProviderLetterPreferences(any()))
                .thenReturn(buildSuccessfulNdbResponse("C1", "E"));

        FDSResponse listResp = new FDSResponse();
        Document pd = new Document();
        pd.setMetadata(new Metadata());
        listResp.setDocuments(Collections.singletonList(pd));
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(listResp);

        String past = OffsetDateTime.now(ZoneOffset.UTC).minusDays(1)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));

        FDSResponse twoDocResp = new FDSResponse();
        Document d0 = new Document();
        d0.setId("past-auto-0");
        Metadata m0 = new Metadata();
        m0.setActiveDate(past);
        m0.setProviderEmailId("first@test.com");
        d0.setMetadata(m0);

        Document d1 = new Document();
        d1.setId("past-auto-1");
        Metadata m1 = new Metadata();
        m1.setActiveDate(past);
        m1.setProviderEmailId("second@test.com");
        d1.setMetadata(m1);

        twoDocResp.setDocuments(Arrays.asList(d0, d1));
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(twoDocResp);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        // determineMulti: first is valid auto → returns 0
        assertEquals("past-auto-0", result.getPreferenceTypes().get(0).getDocumentId());
    }

    @Test
    public void getProviderPreferencesShouldHandleMultipleNdbMailPrefs() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();

        LetterPreferencesResponse ndbResp = new LetterPreferencesResponse();
        ResponseHeader rh = new ResponseHeader();
        rh.setMessage("SUCCESSFUL");
        ndbResp.setResponseHeader(rh);
        ResponseData rd = new ResponseData();
        rd.setLtrTypMailPrfList(Arrays.asList(
                new MailPref("C1", "E"),
                new MailPref("C2", "M")
        ));
        ndbResp.setRequestResponse(rd);
        when(ndbHandler.getProviderLetterPreferences(any())).thenReturn(ndbResp);

        FDSResponse listResp = new FDSResponse();
        Document pd = new Document();
        Metadata pm = new Metadata();
        pm.setProviderName("Multi Corp");
        pd.setMetadata(pm);
        listResp.setDocuments(Collections.singletonList(pd));
        when(fdsHandler.getDocumentList(any(), any(), any(), any())).thenReturn(listResp);

        FDSResponse sorted = new FDSResponse();
        sorted.setDocuments(Collections.emptyList());
        when(fdsHandler.getDocumentListSortCreated(any(), any(), any(), any())).thenReturn(sorted);

        ProviderPreferencesObj result = service.getProviderPreferences("123456789", "123456789", headers, logMessage);

        assertNotNull(result);
        assertEquals(2, result.getPreferenceTypes().size());
        assertEquals("C1", result.getPreferenceTypes().get(0).getClassifier());
        assertEquals("C2", result.getPreferenceTypes().get(1).getClassifier());
    }

    @Test
    public void getProvidersByCorporateShouldUseCacfHandlerConstructionAndReturnResult() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session-id");
        LogMessage logMessage = new LogMessage();

        PasswordOwner expected = new PasswordOwner();
        expected.setMpin("123456789");

        try (MockedConstruction<CACFHandler> cacfConstruction = mockConstruction(CACFHandler.class,
                (mock, context) -> when(mock.getTaxIDNumbers("uuid", "uhc", "123456789", "session-id")).thenReturn(expected))) {

            PasswordOwner result = service.getProvidersByCorporate("uuid", "uhc", "123456789", headers, logMessage);

            assertNotNull(result);
            assertEquals("123456789", result.getMpin());
            assertEquals(1, cacfConstruction.constructed().size());
            verify(cacfConstruction.constructed().get(0), times(1))
                    .getTaxIDNumbers("uuid", "uhc", "123456789", "session-id");
            assertTrue(logMessage.getDetail().contains("Session-session-id"));
        }
    }

    @Test
    public void getProviderPreferencesFDSCloudShouldReturnPreferenceForCucumberPath() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();
        logMessage.setUsername("CUCUMBERTEST");
        logMessage.setActor("C1");

        FDSCloudRequest searchRequest = new FDSCloudRequest();
        FDSCloudGETResponse cloudResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument cloudDoc = new OptOutFDSCloudDocument();
        cloudDoc.setDocumentId("cloud-doc-1");
        String pastDate = OffsetDateTime.now(ZoneOffset.UTC).minusDays(1)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
        cloudDoc.setMetadata("{\"providerEmailId\":\"a@b.com\",\"frequency\":\"D\",\"okToChangePDOInd\":\"N\",\"autoEdelUpdateInd\":\"Y\",\"activeDate\":\"" + pastDate + "\",\"expiryDate\":\"2030-01-01T00:00:00.000Z\"}");
        cloudResponse.setDocuments(Collections.singletonList(cloudDoc));

        try (MockedConstruction<FDSCloudHandler> fdsCloudConstruction = mockConstruction(FDSCloudHandler.class,
                (mock, context) -> {
                    when(mock.createSearchTermsRequestFromMap(any())).thenReturn(searchRequest);
                    when(mock.FDSCloudGetRequest(eq("testId"), eq(searchRequest))).thenReturn(cloudResponse);
                })) {

            ProviderPreferencesObj result = service.getProviderPreferencesFDSCloud("123456789", "123456789", headers, logMessage);

            assertNotNull(result);
            assertEquals("123456789", result.getCorporateTin());
            assertEquals(1, result.getPreferenceTypes().size());
            assertEquals("cloud-doc-1", result.getPreferenceTypes().get(0).getDocumentId());
            assertEquals("a@b.com", result.getPreferenceTypes().get(0).getProviderEmailId());
            assertEquals("2030-01-01T00:00:00.000Z", result.getPreferenceTypes().get(0).getExpiryDate());
            assertEquals(1, fdsCloudConstruction.constructed().size());
        }
    }

    @Test(expected = java.io.IOException.class)
    public void getProviderPreferencesFDSCloudShouldThrowIOExceptionForInvalidCloudMetadata() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "session");
        LogMessage logMessage = new LogMessage();
        logMessage.setUsername("CUCUMBERTEST");
        logMessage.setActor("C1");

        FDSCloudRequest searchRequest = new FDSCloudRequest();
        FDSCloudGETResponse cloudResponse = new FDSCloudGETResponse();
        OptOutFDSCloudDocument cloudDoc = new OptOutFDSCloudDocument();
        cloudDoc.setDocumentId("cloud-doc-1");
        cloudDoc.setMetadata("not-json");
        cloudResponse.setDocuments(Collections.singletonList(cloudDoc));

        try (MockedConstruction<FDSCloudHandler> ignored = mockConstruction(FDSCloudHandler.class,
                (mock, context) -> {
                    when(mock.createSearchTermsRequestFromMap(any())).thenReturn(searchRequest);
                    when(mock.FDSCloudGetRequest(eq("testId"), eq(searchRequest))).thenReturn(cloudResponse);
                })) {

            service.getProviderPreferencesFDSCloud("123456789", "123456789", headers, logMessage);
        }
    }

}
