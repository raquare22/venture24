package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.linksecurity.PSMResponse;
import com.optum.providerpreferences.rs.model.linksecurity.User;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class LinkSecurityHandlerTest {

    private LinkSecurityHandler handlerSpy;
    private Oauth2Handler oauth2Handler;

    @Before
    public void setUp() throws Exception {
        LinkSecurityHandler realHandler = new LinkSecurityHandler();
        handlerSpy = Mockito.spy(realHandler);

        oauth2Handler = Mockito.mock(Oauth2Handler.class);
        setOauth2Handler(handlerSpy, oauth2Handler);
        setPsmUrl(handlerSpy);
    }

    @Test
    public void testGetUserProfilesSuccessFiltersUsers() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("session-1", "PSM")).thenReturn(token);

        User keep = new User();
        keep.setAccountType("PO");
        keep.setStatusCode("A");
        keep.setRespOrgMpin("123456789");

        User rejectStatus = new User();
        rejectStatus.setAccountType("PO");
        rejectStatus.setStatusCode("I");
        rejectStatus.setRespOrgMpin("123456789");

        User rejectType = new User();
        rejectType.setAccountType("XX");
        rejectType.setStatusCode("A");
        rejectType.setRespOrgMpin("123456789");

        User rejectMpin = new User();
        rejectMpin.setAccountType("PO");
        rejectMpin.setStatusCode("A");
        rejectMpin.setRespOrgMpin(null);

        PSMResponse psmResponse = new PSMResponse();
        psmResponse.setUsers(Arrays.asList(keep, rejectStatus, rejectType, rejectMpin));

        ResponseEntity<?> response = new ResponseEntity<>(psmResponse, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(PSMResponse.class), eq(HttpMethod.POST));

        List<User> result = handlerSpy.getUserProfiles("uuid-1", "session-1");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("PO", result.get(0).getAccountType());
        assertEquals("A", result.get(0).getStatusCode());
        assertEquals("123456789", result.get(0).getRespOrgMpin());

        verify(oauth2Handler, times(1)).getOauthToken("session-1", "PSM");
    }

    @Test
    public void testGetUserProfilesThrowsWhenOauthFails() throws Exception {
        when(oauth2Handler.getOauthToken("session-1", "PSM"))
                .thenThrow(new RuntimeException("oauth-fail"));

        try {
            handlerSpy.getUserProfiles("uuid-1", "session-1");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to retrieve OAuth Token for LINK/PSM"));
        }
    }

    @Test
    public void testGetUserProfilesThrowsWhenNoFilteredUsersFound() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("session-1", "PSM")).thenReturn(token);

        User reject = new User();
        reject.setAccountType("PO");
        reject.setStatusCode("I");
        reject.setRespOrgMpin("123456789");

        PSMResponse psmResponse = new PSMResponse();
        psmResponse.setUsers(Collections.singletonList(reject));

        ResponseEntity<?> response = new ResponseEntity<>(psmResponse, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(PSMResponse.class), eq(HttpMethod.POST));

        try {
            handlerSpy.getUserProfiles("uuid-1", "session-1");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("No users found for given UUID"));
        }
    }

    @Test
    public void testGetUserProfilesThrowsWhenSendRequestFails() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("session-1", "PSM")).thenReturn(token);

        doThrow(new RuntimeException("service unavailable")).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(PSMResponse.class), eq(HttpMethod.POST));

        try {
            handlerSpy.getUserProfiles("uuid-1", "session-1");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("WEB SERVICE CALL FAILURE - PSM USER PROFILES"));
        }
    }

    private void setOauth2Handler(LinkSecurityHandler target, Oauth2Handler oauth2) throws Exception {
        Field field = ServiceBase.class.getDeclaredField("oauth2handler");
        field.setAccessible(true);
        field.set(target, oauth2);
    }

    private void setPsmUrl(LinkSecurityHandler target) throws Exception {
        Field field = LinkSecurityHandler.class.getDeclaredField("PSM_URL");
        field.setAccessible(true);
        field.set(target, "https://example.test/psm");
    }
}
