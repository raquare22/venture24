package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPostResponse;
import kong.unirest.HttpRequestWithBody;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ServiceBaseTest {

    private ServiceBase serviceBase;
    private RestTemplate restTemplate;
    private RestTemplate restTemplateAutoEnroll;
    private Oauth2Handler oauth2Handler;

    @Before
    public void setUp() throws Exception {
        serviceBase = new ServiceBase();
        restTemplate = mock(RestTemplate.class);
        restTemplateAutoEnroll = mock(RestTemplate.class);
        oauth2Handler = mock(Oauth2Handler.class);

        setPrivateField(serviceBase, "restTemplate", restTemplate);
        setPrivateField(serviceBase, "oauth2handler", oauth2Handler);
        serviceBase.restTemplateAutoEnroll = restTemplateAutoEnroll;
        serviceBase.numRetries = 0;
        serviceBase.numRetriesAutoEnroll = 0;
    }

    @Test
    public void retryRequestReturnsResponseWhenExchangeSucceeds() {
        ResponseEntity<String> expected = ResponseEntity.ok("ok");
        when(restTemplate.exchange(eq("http://8.8.8.8/test"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(expected);

        ResponseEntity<?> actual = serviceBase.retryRequest("http://8.8.8.8/test", new HttpEntity<>("body"), String.class, HttpMethod.POST);

        assertNotNull(actual);
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals("ok", actual.getBody());
    }

    @Test(expected = IllegalArgumentException.class)
    public void retryRequestThrowsIllegalArgumentExceptionForInvalidScheme() {
        serviceBase.retryRequest("ftp://8.8.8.8/test", new HttpEntity<>("body"), String.class, HttpMethod.GET);
    }

    @Test
    public void retryRequestReturnsNullOnHttpClientErrorException() {
        when(restTemplate.exchange(eq("http://8.8.8.8/test"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad request", HttpHeaders.EMPTY, null, null));

        ResponseEntity<?> response = serviceBase.retryRequest("http://8.8.8.8/test", new HttpEntity<>("body"), String.class, HttpMethod.GET);

        assertNull(response);
    }

    @Test
    public void retryRequestAutoEnrollReturnsOkForGatewayTimeout() {
        when(restTemplateAutoEnroll.exchange(eq("https://api.example.com/auto"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpServerErrorException.create(HttpStatus.GATEWAY_TIMEOUT, "timeout", HttpHeaders.EMPTY, null, null));

        ResponseEntity<?> response = serviceBase.retryRequestAutoEnroll("https://api.example.com/auto", new HttpEntity<>("body"), String.class, HttpMethod.POST);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody() instanceof FDSMultiPostResponse);
        FDSMultiPostResponse body = (FDSMultiPostResponse) response.getBody();
        assertEquals(1, body.getInserted().size());
        assertEquals("Documents sent to FDS to be processed", body.getInserted().get(0));
    }

    @Test(expected = HttpServerErrorException.class)
    public void retryRequestAutoEnrollRethrowsNonGatewayServerError() {
        when(restTemplateAutoEnroll.exchange(eq("https://api.example.com/auto"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpServerErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, "boom", HttpHeaders.EMPTY, null, null));

        serviceBase.retryRequestAutoEnroll("https://api.example.com/auto", new HttpEntity<>("body"), String.class, HttpMethod.POST);
    }

    @Test(expected = HttpClientErrorException.class)
    public void retryRequestFDSRethrowsInvalidGrantBadRequest() {
        byte[] body = "invalid_grant".getBytes(StandardCharsets.UTF_8);
        when(restTemplate.exchange(any(String.class), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad request", HttpHeaders.EMPTY, body, StandardCharsets.UTF_8));

        serviceBase.retryRequestFDS("https://api.example.com/fds", new HttpEntity<>("body"), String.class, HttpMethod.POST);
    }

    @Test
    public void retryRequestReturnsNullOnRestClientException() {
        when(restTemplate.exchange(eq("http://8.8.8.8/test"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RestClientException("rest failure"));

        ResponseEntity<?> response = serviceBase.retryRequest("http://8.8.8.8/test", new HttpEntity<>("body"), String.class, HttpMethod.GET);

        assertNull(response);
    }

    @Test
    public void retryRequestFDSReturnsNullOnResourceAccessException() {
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new ResourceAccessException("unavailable"));

        ResponseEntity<?> response = serviceBase.retryRequestFDS("https://api.example.com/fds", new HttpEntity<>("body"), String.class, HttpMethod.GET);

        assertNull(response);
    }

    @Test
    public void retryRequestFDSReturnsNullOnNonInvalidGrantBadRequest() {
        byte[] body = "different error".getBytes(StandardCharsets.UTF_8);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad request", HttpHeaders.EMPTY, body, StandardCharsets.UTF_8));

        ResponseEntity<?> response = serviceBase.retryRequestFDS("https://api.example.com/fds", new HttpEntity<>("body"), String.class, HttpMethod.POST);

        assertNull(response);
    }

    @Test(expected = RestClientException.class)
    public void retryRequestAutoEnrollRethrowsRestClientException() {
        when(restTemplateAutoEnroll.exchange(eq("https://api.example.com/auto"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RestClientException("rest fail"));

        serviceBase.retryRequestAutoEnroll("https://api.example.com/auto", new HttpEntity<>("body"), String.class, HttpMethod.POST);
    }

    @Test
    public void retryDigiSecRequestReturnsNullForBadRequest() {
        when(restTemplate.exchange(eq("https://api.example.com/digisec"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad request", HttpHeaders.EMPTY, null, null));

        ResponseEntity<?> response = serviceBase.retryDigiSecRequest("https://api.example.com/digisec", new HttpEntity<>("body"), String.class, HttpMethod.POST);

        assertNull(response);
    }

    @Test
    public void retryDigiSecRequestReturnsNullForPaaResourceAccessException() {
        when(restTemplate.exchange(eq("https://api.example.com/paa/test"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new ResourceAccessException("timeout"));

        ResponseEntity<?> response = serviceBase.retryDigiSecRequest("https://api.example.com/paa/test", new HttpEntity<>("body"), String.class, HttpMethod.GET);

        assertNull(response);
    }

    @Test
    public void sendDigiSecRequestReturnsNullForPaaWhenInitialCallReturnsNull() {
        when(restTemplate.exchange(eq("https://api.example.com/paa/test"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new ResourceAccessException("timeout"));

        serviceBase.timeToWaitMsArr = new long[]{0, 0, 0, 0, 0, 0, 0};
        ResponseEntity<?> response = serviceBase.sendDigiSecRequest("https://api.example.com/paa/test", new HttpEntity<>("body"), String.class, HttpMethod.GET);

        assertNull(response);
    }

    @Test
    public void sendDigiSecRequestReturnsBadRequestWithoutRetry() {
        ResponseEntity<String> badRequest = new ResponseEntity<>("bad", HttpStatus.BAD_REQUEST);
        when(restTemplate.exchange(eq("https://api.example.com/digisec"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(badRequest);

        ResponseEntity<?> response = serviceBase.sendDigiSecRequest("https://api.example.com/digisec", new HttpEntity<>("body"), String.class, HttpMethod.POST);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void sendRequestFDSRefreshesTokenOnInvalidGrantAndRetriesSuccessfully() throws Exception {
        byte[] body = "invalid_grant".getBytes(StandardCharsets.UTF_8);
        ResponseEntity<String> okResponse = ResponseEntity.ok("ok");
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad request", HttpHeaders.EMPTY, body, StandardCharsets.UTF_8))
                .thenReturn(okResponse);

        Token token = new Token();
        token.setAccessToken("fresh-token");
        when(oauth2Handler.getOauthToken(eq("FDS_OAUTH_RETRY"), eq("FDSCLOUD"))).thenReturn(token);

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer expired");
        ResponseEntity<?> response = serviceBase.sendRequestFDS("https://api.example.com/fds", new HttpEntity<>("body", headers), String.class, HttpMethod.POST);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("ok", response.getBody());
        verify(oauth2Handler, times(1)).getOauthToken("FDS_OAUTH_RETRY", "FDSCLOUD");
    }

    @Test(expected = HttpClientErrorException.class)
    public void sendRequestFDSRethrowsInvalidGrantWhenTokenRefreshFails() throws Exception {
        byte[] body = "invalid_grant".getBytes(StandardCharsets.UTF_8);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad request", HttpHeaders.EMPTY, body, StandardCharsets.UTF_8));
        when(oauth2Handler.getOauthToken(eq("FDS_OAUTH_RETRY"), eq("FDSCLOUD")))
                .thenThrow(new com.optum.providerpreferences.rs.exception.ApplicationException("oauth failed"));

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer expired");
        serviceBase.sendRequestFDS("https://api.example.com/fds", new HttpEntity<>("body", headers), String.class, HttpMethod.POST);
    }

    @Test
    public void sendRequestAutoEnrollmentRefreshesTokenAndDelegatesToFdsRequest() throws Exception {
        byte[] body = "invalid_grant".getBytes(StandardCharsets.UTF_8);
        when(restTemplateAutoEnroll.exchange(eq("https://api.example.com/auto"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad request", HttpHeaders.EMPTY, body, StandardCharsets.UTF_8));

        ResponseEntity<String> okResponse = ResponseEntity.ok("ok");
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(okResponse);

        Token token = new Token();
        token.setAccessToken("fresh-fds-token");
        when(oauth2Handler.getOauthToken(eq("FDS_OAUTH_RETRY"), eq("FDS"))).thenReturn(token);

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer expired");
        ResponseEntity<?> response = serviceBase.sendRequestAutoEnrollment("https://api.example.com/auto", new HttpEntity<>("body", headers), String.class, HttpMethod.POST);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("ok", response.getBody());
        verify(oauth2Handler, times(1)).getOauthToken("FDS_OAUTH_RETRY", "FDS");
    }

    @Test(expected = HttpClientErrorException.class)
    public void sendRequestAutoEnrollmentRethrowsWhenRefreshFails() throws Exception {
        byte[] body = "invalid_grant".getBytes(StandardCharsets.UTF_8);
        when(restTemplateAutoEnroll.exchange(eq("https://api.example.com/auto"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad request", HttpHeaders.EMPTY, body, StandardCharsets.UTF_8));
        when(oauth2Handler.getOauthToken(eq("FDS_OAUTH_RETRY"), eq("FDS")))
                .thenThrow(new com.optum.providerpreferences.rs.exception.ApplicationException("oauth failed"));

        serviceBase.sendRequestAutoEnrollment("https://api.example.com/auto", new HttpEntity<>("body"), String.class, HttpMethod.POST);
    }

    @Test(expected = NullPointerException.class)
    public void sendRequestAutoEnrollmentThrowsNullPointerWhenNonBadRequestIsSwallowedByRetry() throws Exception {
        when(restTemplateAutoEnroll.exchange(eq("https://api.example.com/auto"), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.UNAUTHORIZED, "unauthorized", HttpHeaders.EMPTY, "expired".getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));

        serviceBase.sendRequestAutoEnrollment("https://api.example.com/auto", new HttpEntity<>("body"), String.class, HttpMethod.POST);
    }

    @Test
    public void retryUnirestRequestReturnsNullOnRestClientException() {
        HttpRequestWithBody request = mock(HttpRequestWithBody.class);
        when(request.getUrl()).thenReturn("https://api.example.com/unirest");
        when(request.asJson()).thenThrow(new RestClientException("unirest fail"));

        HttpResponse<JsonNode> response = serviceBase.retryUnirestRequest(request);

        assertNull(response);
    }

    @Test
    public void retryUnirestRequestReturnsResponseWhenSuccessful() {
        HttpRequestWithBody request = mock(HttpRequestWithBody.class);
        @SuppressWarnings("unchecked")
        HttpResponse<JsonNode> httpResponse = mock(HttpResponse.class);
        when(request.asJson()).thenReturn(httpResponse);

        HttpResponse<JsonNode> response = serviceBase.retryUnirestRequest(request);

        assertNotNull(response);
        assertEquals(httpResponse, response);
    }

    @Test
    public void privateCheckFdsResponseEntityShouldHandleStatuses() throws Exception {
        Method method = ServiceBase.class.getDeclaredMethod("checkFDSResponseEntity", ResponseEntity.class);
        method.setAccessible(true);

        assertEquals(true, method.invoke(null, ResponseEntity.ok("ok")));
        assertEquals(true, method.invoke(null, new ResponseEntity<>("created", HttpStatus.CREATED)));
        assertEquals(false, method.invoke(null, new ResponseEntity<>("bad", HttpStatus.BAD_REQUEST)));
        assertEquals(false, method.invoke(null, new Object[]{null}));
    }

    @Test
    public void privateCheckDigiSecResponseEntityShouldHandleNullAndFailingStatuses() throws Exception {
        Method method = ServiceBase.class.getDeclaredMethod("checkDigiSecResponseEntity", ResponseEntity.class, java.util.List.class, String.class);
        method.setAccessible(true);

        assertEquals(true, method.invoke(null, null, Arrays.asList(HttpStatus.OK, HttpStatus.CREATED), "https://api.example.com/test"));
        assertEquals(false, method.invoke(null, null, Arrays.asList(HttpStatus.OK, HttpStatus.CREATED), "https://api.example.com/paa/test"));
        assertEquals(false, method.invoke(null, ResponseEntity.ok("ok"), Arrays.asList(HttpStatus.OK, HttpStatus.CREATED), "https://api.example.com/test"));
        assertEquals(true, method.invoke(null, new ResponseEntity<>("bad", HttpStatus.BAD_REQUEST), Arrays.asList(HttpStatus.OK, HttpStatus.CREATED), "https://api.example.com/test"));
    }

    @Test
    public void privateCheckUnirestResponseEntityShouldHandleDocumentNotFoundAndOk() throws Exception {
        Method method = ServiceBase.class.getDeclaredMethod("checkUnirestResponseEntity", HttpResponse.class);
        method.setAccessible(true);

        @SuppressWarnings("unchecked")
        HttpResponse<JsonNode> okResponse = mock(HttpResponse.class);
        when(okResponse.getStatus()).thenReturn(HttpStatus.OK.value());
        assertEquals(true, method.invoke(null, okResponse));

        @SuppressWarnings("unchecked")
        HttpResponse<JsonNode> notFoundDocResponse = mock(HttpResponse.class);
        JsonNode body = new JsonNode("{\"details\":\"document not found in store\"}");
        when(notFoundDocResponse.getStatus()).thenReturn(HttpStatus.BAD_REQUEST.value());
        when(notFoundDocResponse.getBody()).thenReturn(body);
        assertEquals(true, method.invoke(null, notFoundDocResponse));

        @SuppressWarnings("unchecked")
        HttpResponse<JsonNode> badResponse = mock(HttpResponse.class);
        JsonNode badBody = new JsonNode("{\"details\":\"different error\"}");
        when(badResponse.getStatus()).thenReturn(HttpStatus.BAD_REQUEST.value());
        when(badResponse.getBody()).thenReturn(badBody);
        assertEquals(false, method.invoke(null, badResponse));
    }

    @Test
    public void privateValidateUriShouldRejectLocalAndAcceptExternal() throws Exception {
        Method method = ServiceBase.class.getDeclaredMethod("validateUri", String.class);
        method.setAccessible(true);

        method.invoke(serviceBase, "http://8.8.8.8/test");

        try {
            method.invoke(serviceBase, "http://127.0.0.1/test");
        } catch (Exception ex) {
            assertTrue(ex.getCause() instanceof IllegalArgumentException);
            assertTrue(ex.getCause().getMessage().contains("Invalid URL"));
        }
    }

    @Test
    public void privateIsPrivateIpv6ShouldIdentifyPrivatePrefixes() throws Exception {
        Method method = ServiceBase.class.getDeclaredMethod("isPrivateIPv6", InetAddress.class);
        method.setAccessible(true);

        assertEquals(true, method.invoke(serviceBase, InetAddress.getByName("fd00::1")));
        assertEquals(true, method.invoke(serviceBase, InetAddress.getByName("fe80::1")));
        assertEquals(false, method.invoke(serviceBase, InetAddress.getByName("2001:4860:4860::8888")));
    }

    // ---- sendRequest tests ----

    @Test
    public void sendRequestReturnsOkResponseOnFirstTry() throws Exception {
        ResponseEntity<String> ok = ResponseEntity.ok("ok");
        when(restTemplate.exchange(eq("http://8.8.8.8/path"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ok);
        ResponseEntity<?> response = serviceBase.sendRequest("http://8.8.8.8/path", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void sendRequestReturnsCreatedResponseOnFirstTry() throws Exception {
        ResponseEntity<String> created = new ResponseEntity<>("created", HttpStatus.CREATED);
        when(restTemplate.exchange(eq("http://8.8.8.8/path"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(created);
        ResponseEntity<?> response = serviceBase.sendRequest("http://8.8.8.8/path", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNotNull(response);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    public void sendRequestReturnsNonOkAfterRetries() throws Exception {
        ResponseEntity<String> badResp = new ResponseEntity<>("bad", HttpStatus.BAD_REQUEST);
        when(restTemplate.exchange(eq("http://8.8.8.8/path"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(badResp);
        ResponseEntity<?> response = serviceBase.sendRequest("http://8.8.8.8/path", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    public void sendRequestReturnsNullOnExceptionDuringRetry() throws Exception {
        when(restTemplate.exchange(eq("http://8.8.8.8/path"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new IllegalArgumentException("Invalid URL: bad"));
        ResponseEntity<?> response = serviceBase.sendRequest("http://8.8.8.8/path", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNull(response);
    }

    // ---- sendRequestFDS tests ----

    @Test
    public void sendRequestFDSReturnsOkOnFirstTry() throws Exception {
        ResponseEntity<String> ok = ResponseEntity.ok("success");
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ok);
        ResponseEntity<?> response = serviceBase.sendRequestFDS("https://api.example.com/fds", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test(expected = NullPointerException.class)
    public void sendRequestFDSRethrowsNonBadRequestClientError() throws Exception {
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.UNAUTHORIZED, "unauth", HttpHeaders.EMPTY, null, null));
        serviceBase.sendRequestFDS("https://api.example.com/fds", new HttpEntity<>("body"), String.class, HttpMethod.GET);
    }

    @Test(expected = RuntimeException.class)
    public void sendRequestFDSRethrowsGenericException() throws Exception {
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException("unexpected"));
        serviceBase.sendRequestFDS("https://api.example.com/fds", new HttpEntity<>("body"), String.class, HttpMethod.GET);
    }

    @Test
    public void sendRequestFDSReturnsNonOkAfterRetries() throws Exception {
        ResponseEntity<String> notFoundResp = new ResponseEntity<>("nf", HttpStatus.NOT_FOUND);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(notFoundResp);
        ResponseEntity<?> response = serviceBase.sendRequestFDS("https://api.example.com/fds", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    // ---- sendRequestAutoEnrollment tests ----

    @Test
    public void sendRequestAutoEnrollmentReturnsOkOnFirstTry() throws Exception {
        ResponseEntity<String> ok = ResponseEntity.ok("ok");
        when(restTemplateAutoEnroll.exchange(eq("https://api.example.com/auto"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(ok);
        ResponseEntity<?> response = serviceBase.sendRequestAutoEnrollment("https://api.example.com/auto", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void sendRequestAutoEnrollmentReturnsNonOkAfterRetries() throws Exception {
        ResponseEntity<String> badResp = new ResponseEntity<>("bad", HttpStatus.BAD_REQUEST);
        when(restTemplateAutoEnroll.exchange(eq("https://api.example.com/auto"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(badResp);
        ResponseEntity<?> response = serviceBase.sendRequestAutoEnrollment("https://api.example.com/auto", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test(expected = RuntimeException.class)
    public void sendRequestAutoEnrollmentRethrowsGenericException() throws Exception {
        when(restTemplateAutoEnroll.exchange(eq("https://api.example.com/auto"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException("unexpected"));
        serviceBase.sendRequestAutoEnrollment("https://api.example.com/auto", new HttpEntity<>("body"), String.class, HttpMethod.GET);
    }

    // ---- sendUnirestRequest tests ----

    @Test
    public void sendUnirestRequestReturnsOkResponseOnFirstTry() throws Exception {
        HttpRequestWithBody request = mock(HttpRequestWithBody.class);
        @SuppressWarnings("unchecked")
        HttpResponse<JsonNode> httpResponse = mock(HttpResponse.class);
        when(httpResponse.getStatus()).thenReturn(HttpStatus.OK.value());
        when(request.asJson()).thenReturn(httpResponse);
        when(request.getUrl()).thenReturn("https://api.example.com/unirest");

        HttpResponse<JsonNode> response = serviceBase.sendUnirestRequest(request);

        assertNotNull(response);
        assertEquals(httpResponse, response);
    }

    @Test
    public void sendUnirestRequestReturnsNullOnException() throws Exception {
        HttpRequestWithBody request = mock(HttpRequestWithBody.class);
        when(request.asJson()).thenThrow(new RuntimeException("fail"));
        when(request.getUrl()).thenReturn("https://api.example.com/unirest");

        HttpResponse<JsonNode> response = serviceBase.sendUnirestRequest(request);

        assertNull(response);
    }

    @Test
    public void sendUnirestRequestHandlesNonOkNotDocNotFound() throws Exception {
        HttpRequestWithBody request = mock(HttpRequestWithBody.class);
        when(request.getUrl()).thenReturn("https://api.example.com/unirest");

        @SuppressWarnings("unchecked")
        HttpResponse<JsonNode> badResponse = mock(HttpResponse.class);
        JsonNode badBody = new JsonNode("{\"details\":\"other error\"}");
        when(badResponse.getStatus()).thenReturn(HttpStatus.BAD_REQUEST.value());
        when(badResponse.getBody()).thenReturn(badBody);
        when(request.asJson()).thenReturn(badResponse);

        // numRetries=0 means it exits loop after first attempt
        HttpResponse<JsonNode> response = serviceBase.sendUnirestRequest(request);
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());
    }

    @Test
    public void sendUnirestRequestRefreshesTokenOnExpiredJwt() throws Exception {
        HttpRequestWithBody request = mock(HttpRequestWithBody.class);
        when(request.getUrl()).thenReturn("https://api.example.com/unirest");

        @SuppressWarnings("unchecked")
        HttpResponse<JsonNode> expiredResponse = mock(HttpResponse.class);
        JsonNode expiredBody = new JsonNode("{\"details\":\"Expired JWT token\"}");
        when(expiredResponse.getStatus()).thenReturn(HttpStatus.UNAUTHORIZED.value());
        when(expiredResponse.getBody()).thenReturn(expiredBody);

        @SuppressWarnings("unchecked")
        HttpResponse<JsonNode> okResponse = mock(HttpResponse.class);
        when(okResponse.getStatus()).thenReturn(HttpStatus.OK.value());

        when(request.asJson())
                .thenReturn(expiredResponse)
                .thenReturn(okResponse);

        Token token = new Token();
        token.setAccessToken("new-token");
        when(oauth2Handler.getOauthTokenRefresh(anyString(), anyString())).thenReturn(token);

        serviceBase.numRetries = 1;
        serviceBase.timeToWaitMsArr = new long[]{0, 0, 0, 0, 0, 0, 0};
        HttpResponse<JsonNode> response = serviceBase.sendUnirestRequest(request);
        assertNotNull(response);
    }

    // ---- retryRequest additional tests ----

    @Test(expected = HttpServerErrorException.class)
    public void retryRequestRethrows500WithNullStatusText() {
        HttpServerErrorException ex = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR) {
            @Override public String getStatusText() { return null; }
        };
        when(restTemplate.exchange(eq("http://8.8.8.8/test"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(ex);
        serviceBase.retryRequest("http://8.8.8.8/test", new HttpEntity<>("body"), String.class, HttpMethod.GET);
    }

    @Test
    public void retryRequestReturnsNullOnNon500ServerError() {
        when(restTemplate.exchange(eq("http://8.8.8.8/test"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpServerErrorException.create(HttpStatus.BAD_GATEWAY, "gateway", HttpHeaders.EMPTY, null, null));
        ResponseEntity<?> response = serviceBase.retryRequest("http://8.8.8.8/test", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNull(response);
    }

    @Test(expected = RuntimeException.class)
    public void retryRequestRethrowsGenericException() {
        when(restTemplate.exchange(eq("http://8.8.8.8/test"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException("unexpected"));
        serviceBase.retryRequest("http://8.8.8.8/test", new HttpEntity<>("body"), String.class, HttpMethod.GET);
    }

    // ---- retryRequestFDS additional tests ----

    @Test(expected = HttpServerErrorException.class)
    public void retryRequestFDSRethrows500WithNullStatusText() {
        HttpServerErrorException ex = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR) {
            @Override public String getStatusText() { return null; }
        };
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(ex);
        serviceBase.retryRequestFDS("https://api.example.com/fds", new HttpEntity<>("body"), String.class, HttpMethod.GET);
    }

    @Test
    public void retryRequestFDSReturnsNullOnNon500ServerError() {
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpServerErrorException.create(HttpStatus.BAD_GATEWAY, "gateway", HttpHeaders.EMPTY, null, null));
        ResponseEntity<?> response = serviceBase.retryRequestFDS("https://api.example.com/fds", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNull(response);
    }

    @Test
    public void retryRequestFDSReturnsNullOnRestClientException() {
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RestClientException("rest fail"));
        ResponseEntity<?> response = serviceBase.retryRequestFDS("https://api.example.com/fds", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNull(response);
    }

    @Test(expected = RuntimeException.class)
    public void retryRequestFDSRethrowsGenericException() {
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException("unexpected"));
        serviceBase.retryRequestFDS("https://api.example.com/fds", new HttpEntity<>("body"), String.class, HttpMethod.GET);
    }

    // ---- retryRequestAutoEnroll additional tests ----

    @Test
    public void retryRequestAutoEnrollReturnsNullOnNonInvalidGrantClientError() {
        when(restTemplateAutoEnroll.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.UNAUTHORIZED, "unauth", HttpHeaders.EMPTY, "other".getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));
        ResponseEntity<?> response = serviceBase.retryRequestAutoEnroll("https://api.example.com/auto", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNull(response);
    }

    @Test
    public void retryRequestAutoEnrollReturnsNullOnResourceAccessException() {
        when(restTemplateAutoEnroll.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new ResourceAccessException("unavailable"));
        ResponseEntity<?> response = serviceBase.retryRequestAutoEnroll("https://api.example.com/auto", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNull(response);
    }

    @Test(expected = RuntimeException.class)
    public void retryRequestAutoEnrollRethrowsGenericException() {
        when(restTemplateAutoEnroll.exchange(anyString(), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException("unexpected"));
        serviceBase.retryRequestAutoEnroll("https://api.example.com/auto", new HttpEntity<>("body"), String.class, HttpMethod.GET);
    }

    // ---- retryDigiSecRequest additional tests ----

    @Test
    public void retryDigiSecRequestReturnsNullOnNonPaaResourceAccessException() {
        when(restTemplate.exchange(eq("https://api.example.com/digisec"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new ResourceAccessException("fail"));
        ResponseEntity<?> response = serviceBase.retryDigiSecRequest("https://api.example.com/digisec", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNull(response);
    }

    @Test
    public void retryDigiSecRequestReturnsNullOnNonPaaRestClientException() {
        when(restTemplate.exchange(eq("https://api.example.com/digisec"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RestClientException("fail"));
        ResponseEntity<?> response = serviceBase.retryDigiSecRequest("https://api.example.com/digisec", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNull(response);
    }

    @Test
    public void retryDigiSecRequestReturnsNullForPaaRestClientException() {
        when(restTemplate.exchange(eq("https://api.example.com/paa/test"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RestClientException("fail"));
        ResponseEntity<?> response = serviceBase.retryDigiSecRequest("https://api.example.com/paa/test", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNull(response);
    }

    @Test(expected = RuntimeException.class)
    public void retryDigiSecRequestRethrowsNonPaaGenericException() {
        when(restTemplate.exchange(eq("https://api.example.com/digisec"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException("unexpected"));
        serviceBase.retryDigiSecRequest("https://api.example.com/digisec", new HttpEntity<>("body"), String.class, HttpMethod.GET);
    }

    @Test
    public void retryDigiSecRequestReturnsNullForPaaGenericException() {
        when(restTemplate.exchange(eq("https://api.example.com/paa/test"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException("unexpected"));
        ResponseEntity<?> response = serviceBase.retryDigiSecRequest("https://api.example.com/paa/test", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNull(response);
    }

    @Test
    public void retryDigiSecRequestReturnsNullOnClientErrorWithPaaUri() {
        when(restTemplate.exchange(eq("https://api.example.com/paa/test"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.NOT_FOUND, "not found", HttpHeaders.EMPTY, null, null));
        ResponseEntity<?> response = serviceBase.retryDigiSecRequest("https://api.example.com/paa/test", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNull(response);
    }

    @Test
    public void retryDigiSecRequestLogsAndReturnsNullOnNonPaaClientError() {
        when(restTemplate.exchange(eq("https://api.example.com/digisec"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenThrow(HttpClientErrorException.create(HttpStatus.UNAUTHORIZED, "unauth", HttpHeaders.EMPTY, null, null));
        ResponseEntity<?> response = serviceBase.retryDigiSecRequest("https://api.example.com/digisec", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNull(response);
    }

    // ---- retryUnirestRequest additional tests ----

    @Test
    public void retryUnirestRequestReturnsNullOnHttpClientErrorException() {
        HttpRequestWithBody request = mock(HttpRequestWithBody.class);
        when(request.getUrl()).thenReturn("https://api.example.com/unirest");
        when(request.asJson()).thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "bad", HttpHeaders.EMPTY, null, null));
        HttpResponse<JsonNode> response = serviceBase.retryUnirestRequest(request);
        assertNull(response);
    }

    @Test
    public void retryUnirestRequestReturnsNullOnHttpServerErrorException() {
        HttpRequestWithBody request = mock(HttpRequestWithBody.class);
        when(request.getUrl()).thenReturn("https://api.example.com/unirest");
        when(request.asJson()).thenThrow(HttpServerErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, "err", HttpHeaders.EMPTY, null, null));
        HttpResponse<JsonNode> response = serviceBase.retryUnirestRequest(request);
        assertNull(response);
    }

    // ---- checkUnirestResponseEntity null test ----

    @Test
    public void privateCheckUnirestResponseEntityReturnsFalseForNull() throws Exception {
        java.lang.reflect.Method method = ServiceBase.class.getDeclaredMethod("checkUnirestResponseEntity", HttpResponse.class);
        method.setAccessible(true);
        assertEquals(false, method.invoke(null, new Object[]{null}));
    }

    // ---- sendDigiSecRequest additional tests ----

//    @Test(expected = ResourceAccessException.class)
//    public void sendDigiSecRequestRethrowsResourceAccessExceptionForNonPaa() {
//        when(restTemplate.exchange(eq("https://api.example.com/digisec"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
//                .thenThrow(new ResourceAccessException("fail"));
//        serviceBase.numRetries = 0;
//        serviceBase.timeToWaitMsArr = new long[]{0, 0, 0, 0, 0, 0, 0};
//        serviceBase.sendDigiSecRequest("https://api.example.com/digisec", new HttpEntity<>("body"), String.class, HttpMethod.GET);
//    }

//    @Test(expected = HttpServerErrorException.class)
//    public void sendDigiSecRequestRethrowsHttpServerErrorException() {
//        when(restTemplate.exchange(eq("https://api.example.com/digisec"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
//                .thenThrow(HttpServerErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, "err", HttpHeaders.EMPTY, null, null));
//        serviceBase.numRetries = 0;
//        serviceBase.timeToWaitMsArr = new long[]{0, 0, 0, 0, 0, 0, 0};
//        serviceBase.sendDigiSecRequest("https://api.example.com/digisec", new HttpEntity<>("body"), String.class, HttpMethod.GET);
//    }

    @Test
    public void sendDigiSecRequestReturnOkResponse() {
        ResponseEntity<String> okResp = ResponseEntity.ok("ok");
        when(restTemplate.exchange(eq("https://api.example.com/digisec"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
                .thenReturn(okResp);
        ResponseEntity<?> response = serviceBase.sendDigiSecRequest("https://api.example.com/digisec", new HttpEntity<>("body"), String.class, HttpMethod.GET);
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

//    @Test
//    public void sendDigiSecRequestRetriesWhenInitialFails() {
//        ResponseEntity<String> badResp = new ResponseEntity<>("bad", HttpStatus.NOT_FOUND);
//        ResponseEntity<String> okResp = ResponseEntity.ok("ok");
//        when(restTemplate.exchange(eq("https://api.example.com/digisec"), eq(HttpMethod.GET), any(HttpEntity.class), eq(String.class)))
//                .thenReturn(badResp)
//                .thenReturn(okResp);
//        serviceBase.numRetries = 1;
//        serviceBase.timeToWaitMsArr = new long[]{0, 0, 0, 0, 0, 0, 0};
//        ResponseEntity<?> response = serviceBase.sendDigiSecRequest("https://api.example.com/digisec", new HttpEntity<>("body"), String.class, HttpMethod.GET);
//        assertNotNull(response);
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//    }

    private static void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}

