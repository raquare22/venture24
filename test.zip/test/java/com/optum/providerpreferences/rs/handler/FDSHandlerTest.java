package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObj;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSResponse;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class FDSHandlerTest {

    private FDSHandler handlerSpy;
    private Oauth2Handler oauth2Handler;

    @Before
    public void setUp() throws Exception {
        FDSHandler realHandler = new FDSHandler();
        handlerSpy = Mockito.spy(realHandler);

        oauth2Handler = Mockito.mock(Oauth2Handler.class);
        setOauth2Handler(handlerSpy, oauth2Handler);

        setField(handlerSpy, "fdsCloudURL", "https://example.test/fds");
        setField(handlerSpy, "fdsCloudSpaceId", "space-1");
    }

    @Test
    public void testGetDocumentListSuccess() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("session-1", "FDS")).thenReturn(token);

        FDSResponse body = new FDSResponse();
        Document doc = new Document();
        Metadata md = new Metadata();
        md.setTin("111223333");
        doc.setMetadata(md);
        body.setDocuments(Collections.singletonList(doc));

        ResponseEntity<?> response = new ResponseEntity<>(body, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(FDSResponse.class), eq(HttpMethod.GET));

        FDSResponse result = handlerSpy.getDocumentList("111223333", "123456789", "x", "session-1");

        assertNotNull(result);
        assertEquals(1, result.getDocuments().size());
        assertEquals("111223333", result.getDocuments().get(0).getMetadata().getTin());
    }

    @Test
    public void testGetDocumentListThrowsWhenOauthFails() throws Exception {
        when(oauth2Handler.getOauthToken("session-1", "FDS")).thenThrow(new IOException("oauth-fail"));

        try {
            handlerSpy.getDocumentList("111223333", "123456789", "x", "session-1");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to make FDS OAUTH service call"));
        }
    }

    @Test
    public void testGetDocumentListReturnsEmptyWhenResponseIsNull() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("session-1", "FDS")).thenReturn(token);

        doReturn(null).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(FDSResponse.class), eq(HttpMethod.GET));

        FDSResponse result = handlerSpy.getDocumentList("111223333", "123456789", "x", "session-1");

        assertNotNull(result);
        assertTrue(result.getDocuments().isEmpty());
    }

    @Test
    public void testGetAutoEnrollDocumentListSortCreatedInvalidTin() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("session-1", "FDS")).thenReturn(token);

        try {
            handlerSpy.getAutoEnrollDocumentListSortCreated("bad-tin", "123456789", "fn", "session-1");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Invalid tin value"));
        }
    }

    @Test
    public void testGetAutoEnrollDocumentListSortCreatedInvalidMpin() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("session-1", "FDS")).thenReturn(token);

        try {
            handlerSpy.getAutoEnrollDocumentListSortCreated("111223333", "bad-mpin", "fn", "session-1");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Invalid mpin value"));
        }
    }

    @Test
    public void testGetAutoEnrollDocumentListSortCreatedReturnsEmptyWhenResponseIsNull() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("session-1", "FDS")).thenReturn(token);

        doReturn(null).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(FDSResponse.class), eq(HttpMethod.GET));

        FDSResponse result = handlerSpy.getAutoEnrollDocumentListSortCreated("111223333", "123456789", "fn", "session-1");

        assertNotNull(result);
        assertTrue(result.getDocuments().isEmpty());
    }

    @Test
    public void testGetExistingFDSEmailsReplacesEmail() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken(anyString(), eq("FDS"))).thenReturn(token);

        Metadata md = new Metadata();
        md.setProviderEmailId("existing@email.com");
        Document doc = new Document();
        doc.setMetadata(md);
        FDSResponse fdsResponse = new FDSResponse();
        fdsResponse.setDocuments(Collections.singletonList(doc));

        ResponseEntity<?> response = new ResponseEntity<>(fdsResponse, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(FDSResponse.class), eq(HttpMethod.GET));

        AutoenrollmentObj obj = new AutoenrollmentObj();
        obj.setTin("111223333");
        obj.setMpin("123456789");
        obj.setFileName("fileA");
        obj.setProviderEmailId("new@email.com");
        AutoenrollmentRequest req = new AutoenrollmentRequest();
        req.setAutoenrollDocuments(Collections.singletonList(obj));

        AutoenrollmentRequest result = handlerSpy.getExistingFDSEmails(req);

        assertNotNull(result);
        assertEquals(1, result.getAutoenrollDocuments().size());
        assertEquals("existing@email.com", result.getAutoenrollDocuments().get(0).getProviderEmailId());
        verify(oauth2Handler, times(1)).getOauthToken("AutoEnrollment_existingEmail", "FDS");
    }

    @Test
    public void testGetFDSCloudTokenViaGetDocByIdOauthFailureWrapped() throws Exception {
        when(oauth2Handler.getOauthToken("AutoEnrollment_Id", "FDS"))
                .thenThrow(new OAuthSystemException("oauth-system-fail"));

        try {
            handlerSpy.getDocById(Collections.singletonList("doc-1"));
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to make FDS OAUTH service call"));
        }
    }

    @Test
    public void testGetOptOutDocumentsReturnsEmptyWhenResponseIsNull() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("session-2", "FDS")).thenReturn(token);

        doReturn(null).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(FDSResponse.class), eq(HttpMethod.GET));

        FDSResponse result = handlerSpy.getOptOutDocuments("session-2", null);

        assertNotNull(result);
        assertTrue(result.getDocuments().isEmpty());
    }

    @Test
    public void testCallFDSPostDocumentWrapsOauthFailure() throws Exception {
        when(oauth2Handler.getOauthToken("session-post", "FDS")).thenThrow(new IOException("oauth down"));

        MultiValueMap<String, Document> parts = new LinkedMultiValueMap<>();
        parts.add("documents", new Document());

        try {
            handlerSpy.callFDSPostDocument(parts, new HttpHeaders(), "session-post");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to make FDS OAUTH service call"));
        }
    }

    @Test
    public void testCallFDSPutDocumentWrapsOauthFailure() throws Exception {
        when(oauth2Handler.getOauthToken("session-put", "FDS")).thenThrow(new IOException("oauth down"));

        MultiValueMap<String, Document> parts = new LinkedMultiValueMap<>();
        parts.add("documents", new Document());

        try {
            handlerSpy.callFDSPutDocument(parts, new HttpHeaders(), "doc-1", "session-put");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to make FDS OAUTH service call"));
        }
    }

    @Test
    public void testUpdateMultiDocumentsWrapsOauthFailure() throws Exception {
        when(oauth2Handler.getOauthToken("session-multi-put", "FDS")).thenThrow(new IOException("oauth down"));

        MultiValueMap<String, Object> parts = new LinkedMultiValueMap<>();
        parts.add("documentIdList", "doc1,doc2");

        try {
            handlerSpy.updateMultiDocuments(parts, new HttpHeaders(), "session-multi-put");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to make FDS OAUTH service call"));
        }
    }

    @Test
    public void testCreateMultiDocumentsWrapsOauthFailure() throws Exception {
        when(oauth2Handler.getOauthToken("session-multi-post", "FDS")).thenThrow(new IOException("oauth down"));

        MultiValueMap<String, Object> parts = new LinkedMultiValueMap<>();
        parts.add("documents", "doc");

        try {
            handlerSpy.createMultiDocuments(parts, new HttpHeaders(), "session-multi-post");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to make FDS OAUTH service call"));
        }
    }

    @Test
    public void testGetDocumentListSortCreatedWithTokenOverloadReturnsBody() {
        Token token = new Token();
        token.setAccessToken("token-1");

        FDSResponse body = new FDSResponse();
        Document doc = new Document();
        Metadata md = new Metadata();
        md.setFileName("E2");
        doc.setMetadata(md);
        body.setDocuments(Collections.singletonList(doc));

        ResponseEntity<?> response = new ResponseEntity<>(body, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(FDSResponse.class), eq(HttpMethod.GET));

        FDSResponse result = handlerSpy.getDocumentListSortCreated("111223333", "123456789", "E2", "session", token);

        assertNotNull(result);
        assertEquals(1, result.getDocuments().size());
        assertEquals("E2", result.getDocuments().get(0).getMetadata().getFileName());
    }

    @Test
    public void testGetDocumentListWithTokenOverloadReturnsEmptyWhenNullResponse() {
        Token token = new Token();
        token.setAccessToken("token-1");

        doReturn(null).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(FDSResponse.class), eq(HttpMethod.GET));

        FDSResponse result = handlerSpy.getDocumentList("111223333", "123456789", null, "session", token);

        assertNotNull(result);
        assertTrue(result.getDocuments().isEmpty());
    }

    @Test
    public void testGetDocumentListSortCreatedPrimaryReturnsEmptyWhenNullResponse() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("sort-session", "FDS")).thenReturn(token);

        doReturn(null).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(FDSResponse.class), eq(HttpMethod.GET));

        FDSResponse result = handlerSpy.getDocumentListSortCreated("111223333", "123456789", null, "sort-session");

        assertNotNull(result);
        assertTrue(result.getDocuments().isEmpty());
    }

    @Test
    public void testGetDocumentListSortCreatedPrimaryWrapsOauthFailure() throws Exception {
        when(oauth2Handler.getOauthToken("sort-fail", "FDS")).thenThrow(new IOException("oauth down"));

        try {
            handlerSpy.getDocumentListSortCreated("111223333", "123456789", "E2", "sort-fail");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to make FDS OAUTH service call"));
        }
    }

    @Test
    public void testCallFDSPostDocumentSuccess() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("post-success", "FDS")).thenReturn(token);

        ResponseEntity<?> sendResponse = new ResponseEntity<>(new Document(), HttpStatus.OK);
        doReturn(sendResponse).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(Document.class), eq(HttpMethod.POST));

        MultiValueMap<String, Document> parts = new LinkedMultiValueMap<>();
        Document postDoc = new Document();
        postDoc.setMetadata(new Metadata());
        parts.add("documents", postDoc);

        ResponseEntity<Document> result = handlerSpy.callFDSPostDocument(parts, new HttpHeaders(), "post-success");

        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testCallFDSPutDocumentSuccess() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("put-success", "FDS")).thenReturn(token);

        ResponseEntity<?> sendResponse = new ResponseEntity<>(new Document(), HttpStatus.OK);
        doReturn(sendResponse).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(Document.class), eq(HttpMethod.PUT));

        MultiValueMap<String, Document> parts = new LinkedMultiValueMap<>();
        Document putDoc = new Document();
        putDoc.setMetadata(new Metadata());
        parts.add("documents", putDoc);

        ResponseEntity<Document> result = handlerSpy.callFDSPutDocument(parts, new HttpHeaders(), "doc-1", "put-success");

        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testUpdateDocumentsCoversPostAndPutBranches() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("update-session", "FDS")).thenReturn(token);

        ResponseEntity<Document> okResponse = new ResponseEntity<>(new Document(), HttpStatus.OK);
        doReturn(okResponse).when(handlerSpy)
                .callFDSPostDocument(any(MultiValueMap.class), any(HttpHeaders.class), eq("update-session"), eq(token));
        doReturn(okResponse).when(handlerSpy)
                .callFDSPutDocument(any(MultiValueMap.class), any(HttpHeaders.class), eq("doc-1"), eq(""), eq(token));

        Document noId = new Document();
        noId.setId(null);
        noId.setMetadata(new Metadata());

        Document withId = new Document();
        withId.setId("doc-1");
        withId.setMetadata(new Metadata());

        handlerSpy.updateDocuments(new ArrayList<>(java.util.Arrays.asList(noId, withId)), "update-session");

        verify(handlerSpy, times(1)).callFDSPostDocument(any(MultiValueMap.class), any(HttpHeaders.class), eq("update-session"), eq(token));
        verify(handlerSpy, times(1)).callFDSPutDocument(any(MultiValueMap.class), any(HttpHeaders.class), eq("doc-1"), eq(""), eq(token));
    }

    @Test
    public void testGetDocByIdSuccess() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("AutoEnrollment_Id", "FDS")).thenReturn(token);

        Document body = new Document();
        body.setId("doc-1");
        ResponseEntity<?> response = new ResponseEntity<>(body, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(Document.class), eq(HttpMethod.GET));

        java.util.List<Document> result = handlerSpy.getDocById(Collections.singletonList("doc-1"));

        assertEquals(1, result.size());
        assertEquals("doc-1", result.get(0).getId());
    }

    @Test
    public void testGetExistingFDSEmailsKeepsOriginalWhenNoDocuments() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken(anyString(), eq("FDS"))).thenReturn(token);

        FDSResponse fdsResponse = new FDSResponse();
        fdsResponse.setDocuments(Collections.emptyList());
        ResponseEntity<?> response = new ResponseEntity<>(fdsResponse, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(FDSResponse.class), eq(HttpMethod.GET));

        AutoenrollmentObj obj = new AutoenrollmentObj();
        obj.setTin("111223333");
        obj.setMpin("123456789");
        obj.setFileName("fileA");
        obj.setProviderEmailId("original@email.com");
        AutoenrollmentRequest req = new AutoenrollmentRequest();
        req.setAutoenrollDocuments(Collections.singletonList(obj));

        AutoenrollmentRequest result = handlerSpy.getExistingFDSEmails(req);

        assertEquals("original@email.com", result.getAutoenrollDocuments().get(0).getProviderEmailId());
    }

    @Test
    public void testGetDocumentListWithTokenIncludesFileNameAndReturnsBody() {
        Token token = new Token();
        token.setAccessToken("token-1");

        FDSResponse body = new FDSResponse();
        body.setDocuments(Collections.singletonList(new Document()));
        ResponseEntity<?> response = new ResponseEntity<>(body, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(FDSResponse.class), eq(HttpMethod.GET));

        FDSResponse result = handlerSpy.getDocumentList("111223333", "123456789", "E3", "session", token);

        assertNotNull(result);
        assertEquals(1, result.getDocuments().size());
    }

    @Test
    public void testGetOptOutDocumentsWithMpinReturnsBody() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-2");
        when(oauth2Handler.getOauthToken("opt-session", "FDS")).thenReturn(token);

        FDSResponse body = new FDSResponse();
        Document doc = new Document();
        Metadata md = new Metadata();
        md.setMpin("123456789");
        doc.setMetadata(md);
        body.setDocuments(Collections.singletonList(doc));

        ResponseEntity<?> response = new ResponseEntity<>(body, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(FDSResponse.class), eq(HttpMethod.GET));

        FDSResponse result = handlerSpy.getOptOutDocuments("opt-session", "123456789");

        assertEquals(1, result.getDocuments().size());
        assertEquals("123456789", result.getDocuments().get(0).getMetadata().getMpin());
    }

    @Test
    public void testCallFDSPostDocumentOverloadRetriesOnResourceAccessException() {
        Token token = new Token();
        token.setAccessToken("token-1");

        MultiValueMap<String, Document> parts = new LinkedMultiValueMap<>();
        Document doc = new Document();
        doc.setMetadata(new Metadata());
        parts.add("documents", doc);

        ResponseEntity<?> okResponse = new ResponseEntity<>(new Document(), HttpStatus.OK);
        doThrow(new ResourceAccessException("socket"))
                .doReturn(okResponse)
                .when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(Document.class), eq(HttpMethod.POST));

        ResponseEntity<Document> result = handlerSpy.callFDSPostDocument(parts, new HttpHeaders(), "session", token);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        verify(handlerSpy, times(2)).sendRequestFDS(anyString(), any(HttpEntity.class), eq(Document.class), eq(HttpMethod.POST));
    }

    @Test
    public void testCallFDSPutDocumentOverloadRetriesOnHttpServerErrorException() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");

        MultiValueMap<String, Document> parts = new LinkedMultiValueMap<>();
        Document doc = new Document();
        doc.setMetadata(new Metadata());
        parts.add("documents", doc);

        ResponseEntity<?> okResponse = new ResponseEntity<>(new Document(), HttpStatus.OK);
        doThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR))
                .doReturn(okResponse)
                .when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(Document.class), eq(HttpMethod.PUT));

        ResponseEntity<Document> result = handlerSpy.callFDSPutDocument(parts, new HttpHeaders(), "doc-1", "", token);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        verify(handlerSpy, times(2)).sendRequestFDS(anyString(), any(HttpEntity.class), eq(Document.class), eq(HttpMethod.PUT));
    }

    @Test
    public void testUpdateDocumentsRetriesWhenPostAndPutReturnNonOk() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("retry-session", "FDS")).thenReturn(token);

        ResponseEntity<Document> badResponse = new ResponseEntity<>(new Document(), HttpStatus.INTERNAL_SERVER_ERROR);
        doReturn(badResponse).when(handlerSpy)
                .callFDSPostDocument(any(MultiValueMap.class), any(HttpHeaders.class), eq("retry-session"), eq(token));
        doReturn(badResponse).when(handlerSpy)
                .callFDSPutDocument(any(MultiValueMap.class), any(HttpHeaders.class), eq("doc-1"), eq(""), eq(token));

        Document noId = new Document();
        noId.setMetadata(new Metadata());

        Document withId = new Document();
        withId.setId("doc-1");
        withId.setMetadata(new Metadata());

        handlerSpy.updateDocuments(new ArrayList<>(java.util.Arrays.asList(noId, withId)), "retry-session");

        verify(handlerSpy, times(2)).callFDSPostDocument(any(MultiValueMap.class), any(HttpHeaders.class), eq("retry-session"), eq(token));
        verify(handlerSpy, times(2)).callFDSPutDocument(any(MultiValueMap.class), any(HttpHeaders.class), eq("doc-1"), eq(""), eq(token));
    }

    @Test
    public void testGetDocByIdWrapsSendFailureAsApplicationException() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken("AutoEnrollment_Id", "FDS")).thenReturn(token);

        doThrow(new RuntimeException("fds-down")).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(Document.class), eq(HttpMethod.GET));

        try {
            handlerSpy.getDocById(Collections.singletonList("doc-1"));
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to make FDS web service call"));
        }
    }

    @Test
    public void testGetExistingFDSEmailsWrapsRequestFailure() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken(anyString(), eq("FDS"))).thenReturn(token);

        doThrow(new RuntimeException("fds-down")).when(handlerSpy)
                .sendRequestFDS(anyString(), any(HttpEntity.class), eq(FDSResponse.class), eq(HttpMethod.GET));

        AutoenrollmentObj obj = new AutoenrollmentObj();
        obj.setTin("111223333");
        obj.setMpin("123456789");
        obj.setFileName("fileA");
        obj.setProviderEmailId("orig@email.com");
        AutoenrollmentRequest req = new AutoenrollmentRequest();
        req.setAutoenrollDocuments(Collections.singletonList(obj));

        try {
            handlerSpy.getExistingFDSEmails(req);
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to make FDS web service call"));
        }
    }

    private void setOauth2Handler(FDSHandler target, Oauth2Handler oauth2) throws Exception {
        Field field = FDSHandler.class.getDeclaredField("oauth2handler");
        field.setAccessible(true);
        field.set(target, oauth2);
    }

    private void setField(FDSHandler target, String fieldName, String value) throws Exception {
        Field field = FDSHandler.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}
