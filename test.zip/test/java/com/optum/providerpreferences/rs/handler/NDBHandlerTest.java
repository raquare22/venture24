package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.NDBToken;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesRequest;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponse;
import com.optum.providerpreferences.rs.model.ndb.preferences.ResponseHeader;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

public class NDBHandlerTest {

    private NDBHandler handlerSpy;
    private Oauth2Handler oauth2Handler;
    private RestTemplate client;

    @Before
    public void setUp() throws Exception {
        NDBHandler realHandler = new NDBHandler();
        handlerSpy = Mockito.spy(realHandler);

        oauth2Handler = Mockito.mock(Oauth2Handler.class);
        setOauth2Handler(handlerSpy, oauth2Handler);

        client = Mockito.mock(RestTemplate.class);
        setClient(handlerSpy, client);

        handlerSpy.ndbLetterPrefsURL = "https://example.test/ndb/letter";
        handlerSpy.ndbCorpMpinURL = "https://example.test/ndb/corp";

        handlerSpy.numRetries = 1;
        handlerSpy.timeToWaitMsArr = new long[]{0L};
    }

    @Test
    public void testGetProviderDataSuccess() throws Exception {
        doNothing().when(handlerSpy).ndbWebServicePrep();

        com.optum.providerpreferences.rs.model.ndb.provider.RequestData requestData =
                new com.optum.providerpreferences.rs.model.ndb.provider.RequestData("111223333", "corp-1");

        CorpMpinResponse expectedBody = new CorpMpinResponse();
        ResponseEntity<?> response = new ResponseEntity<>(expectedBody, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(CorpMpinResponse.class), eq(HttpMethod.POST));

        CorpMpinResponse result = handlerSpy.getProviderData(requestData);

        assertNotNull(result);
        assertEquals(expectedBody, result);
    }

    @Test(expected = RestClientException.class)
    public void testGetProviderDataRethrowsRestClientException() throws Exception {
        doNothing().when(handlerSpy).ndbWebServicePrep();

        com.optum.providerpreferences.rs.model.ndb.provider.RequestData requestData =
                new com.optum.providerpreferences.rs.model.ndb.provider.RequestData("111223333", "corp-1");

        doThrow(new RestClientException("downstream-fail")).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(CorpMpinResponse.class), eq(HttpMethod.POST));

        handlerSpy.getProviderData(requestData);
    }

    @Test
    public void testGetProviderLetterPreferencesSuccess() throws Exception {
        doNothing().when(handlerSpy).ndbWebServicePrep();

        com.optum.providerpreferences.rs.model.ndb.preferences.RequestData req =
                new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData();

        LetterPreferencesResponse expectedBody = new LetterPreferencesResponse();
        ResponseEntity<?> response = new ResponseEntity<>(expectedBody, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(LetterPreferencesResponse.class), eq(HttpMethod.POST));

        LetterPreferencesResponse result = handlerSpy.getProviderLetterPreferences(req);

        assertNotNull(result);
        assertEquals(expectedBody, result);
    }

    @Test
    public void testGetProviderLetterPreferencesWrapsException() throws Exception {
        doNothing().when(handlerSpy).ndbWebServicePrep();

        com.optum.providerpreferences.rs.model.ndb.preferences.RequestData req =
                new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData();

        doThrow(new RuntimeException("ndb-fail")).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(LetterPreferencesResponse.class), eq(HttpMethod.POST));

        try {
            handlerSpy.getProviderLetterPreferences(req);
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("ndb-fail"));
        }
    }

    @Test
    public void testNdbWebServicePrepSetsTokenAndHeaders() throws Exception {
        NDBToken token = new NDBToken();
        token.setAccessToken("access-123");
        when(oauth2Handler.getOauthToken("PDO", "NDB")).thenReturn(token);

        handlerSpy.ndbWebServicePrep();

        assertNotNull(handlerSpy.getToken());
        assertEquals("access-123", handlerSpy.getToken().getAccessToken());

        HttpHeaders headers = getHeaders(handlerSpy);
        assertEquals("Bearer access-123", headers.getFirst("Authorization"));
        assertEquals("test", headers.getFirst("actor"));
        assertEquals("read", headers.getFirst("scope"));
        assertNotNull(headers.getFirst("timestamp"));
    }

    @Test
    public void testNdbWebServicePrepRethrowsOauthException() throws Exception {
        when(oauth2Handler.getOauthToken("PDO", "NDB")).thenThrow(new IOException("oauth-io-fail"));

        try {
            handlerSpy.ndbWebServicePrep();
            fail("Expected IOException");
        } catch (IOException e) {
            assertTrue(e.getMessage().contains("oauth-io-fail"));
        }
    }


    @Test
    public void testUpdateProviderLetterPreferencesReturnsTrueOnOk() throws Exception {
        LetterPreferencesRequest request = createLetterPreferenceRequest();

        LetterPreferencesResponse body = new LetterPreferencesResponse();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setReturncode("00");
        responseHeader.setMessage("SUCCESSFUL");
        body.setResponseHeader(responseHeader);

        ResponseEntity<LetterPreferencesResponse> response = new ResponseEntity<>(body, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(LetterPreferencesResponse.class), eq(HttpMethod.POST), eq(request));

        boolean result = handlerSpy.updateProviderLetterPreferences(request, "123456789", "111223333");

        assertTrue(result);
    }

    @Test
    public void testUpdateProviderLetterPreferencesReturnsFalseOnReturnCode99() throws Exception {
        LetterPreferencesRequest request = createLetterPreferenceRequest();

        LetterPreferencesResponse body = new LetterPreferencesResponse();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setReturncode("99");
        responseHeader.setMessage("FAIL");
        body.setResponseHeader(responseHeader);

        ResponseEntity<LetterPreferencesResponse> response = new ResponseEntity<>(body, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(LetterPreferencesResponse.class), eq(HttpMethod.POST), eq(request));

        boolean result = handlerSpy.updateProviderLetterPreferences(request, "123456789", "111223333");

        assertFalse(result);
    }

    @Test
    public void testUpdateProviderLetterPreferencesReturnsTrueOnAlreadyExistsWithNonOkStatus() throws Exception {
        LetterPreferencesRequest request = createLetterPreferenceRequest();

        LetterPreferencesResponse body = new LetterPreferencesResponse();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setReturncode("00");
        responseHeader.setMessage("ALREADY EXIST IN DB");
        body.setResponseHeader(responseHeader);

        ResponseEntity<LetterPreferencesResponse> response = new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(LetterPreferencesResponse.class), eq(HttpMethod.POST), eq(request));

        boolean result = handlerSpy.updateProviderLetterPreferences(request, "123456789", "111223333");

        assertTrue(result);
    }

    @Test
    public void testUpdateProviderLetterPreferencesListSuccess() throws Exception {
        NDBToken token = new NDBToken();
        token.setAccessToken("access-123");
        when(oauth2Handler.getOauthToken("PDO", "NDB")).thenReturn(token);

        LetterPreferencesResponse body = new LetterPreferencesResponse();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setMessage("SUCCESSFUL");
        body.setResponseHeader(responseHeader);

        ResponseEntity<?> response = new ResponseEntity<>(body, HttpStatus.OK);
        doReturn(response).when(client)
                .exchange(anyString(), eq(HttpMethod.POST), Mockito.<HttpEntity<String>>any(), eq(LetterPreferencesResponse.class));

        boolean result = handlerSpy.updateProviderLetterPreferences(Collections.singletonList(createLetterPreferenceRequest()));

        assertTrue(result);
    }

    @Test
    public void testUpdateProviderLetterPreferencesListReturnsFalseOnNonOkAndNonAlreadyExists() throws Exception {
        NDBToken token = new NDBToken();
        token.setAccessToken("access-123");
        when(oauth2Handler.getOauthToken("PDO", "NDB")).thenReturn(token);

        LetterPreferencesResponse body = new LetterPreferencesResponse();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setMessage("OTHER");
        body.setResponseHeader(responseHeader);

        ResponseEntity<LetterPreferencesResponse> response = new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
        doReturn(response).when(client)
                .exchange(anyString(), eq(HttpMethod.POST), Mockito.<HttpEntity<String>>any(), eq(LetterPreferencesResponse.class));

        boolean result = handlerSpy.updateProviderLetterPreferences(Collections.singletonList(createLetterPreferenceRequest()));

        assertFalse(result);
    }

    @Test
    public void testSendRequestReturnsImmediateOkResponse() throws Exception {
        LetterPreferencesRequest request = createLetterPreferenceRequest();
        ResponseEntity<?> okResponse = new ResponseEntity<>(new LetterPreferencesResponse(), HttpStatus.OK);

        doReturn(okResponse).when(handlerSpy)
                .retryRequest(anyString(), any(HttpEntity.class), eq(LetterPreferencesResponse.class), eq(HttpMethod.POST));

        ResponseEntity<?> result = handlerSpy.sendRequest("https://example.test", new HttpEntity<>("{}"), LetterPreferencesResponse.class, HttpMethod.POST, request);

        assertEquals(HttpStatus.OK, result.getStatusCode());
    }

//    @Test
//    public void testSendRequestRetriesAndUsesRefreshToken() throws Exception {
//        handlerSpy.numRetries = 1;
//        handlerSpy.timeToWaitMsArr = new long[]{0L};
//
//        LetterPreferencesRequest request = createLetterPreferenceRequest();
//        ResponseEntity<?> okResponse = new ResponseEntity<>(new LetterPreferencesResponse(), HttpStatus.OK);
//
//        doReturn(null)
//                .doReturn(okResponse)
//                .when(handlerSpy)
//                .retryRequest(anyString(), any(HttpEntity.class), eq(LetterPreferencesResponse.class), eq(HttpMethod.POST));
//
//        NDBToken refresh = new NDBToken();
//        refresh.setAccessToken("refresh-token");
//        when(oauth2Handler.getOauthTokenRefresh("PDO", "NDB")).thenReturn(refresh);
//
//        ResponseEntity<?> result = handlerSpy.sendRequest("https://example.test", new HttpEntity<>("{}"), LetterPreferencesResponse.class, HttpMethod.POST, request);
//
//        assertEquals(HttpStatus.OK, result.getStatusCode());
//    }

//    @Test(expected = OAuthSystemException.class)
//    public void testSendRequestThrowsWhenRefreshTokenCallFails() throws Exception {
//        handlerSpy.numRetries = 1;
//        handlerSpy.timeToWaitMsArr = new long[]{0L};
//
//        LetterPreferencesRequest request = createLetterPreferenceRequest();
//        doReturn(null).when(handlerSpy)
//                .retryRequest(anyString(), any(HttpEntity.class), eq(LetterPreferencesResponse.class), eq(HttpMethod.POST));
//
//        when(oauth2Handler.getOauthTokenRefresh("PDO", "NDB")).thenThrow(new OAuthSystemException("refresh-fail"));
//
//        handlerSpy.sendRequest("https://example.test", new HttpEntity<>("{}"), LetterPreferencesResponse.class, HttpMethod.POST, request);
//    }

//    @Test
//    public void testSendRequestReturnsNonOkAfterRetries() throws Exception {
//        handlerSpy.numRetries = 1;
//        handlerSpy.timeToWaitMsArr = new long[]{0L};
//
//        LetterPreferencesRequest request = createLetterPreferenceRequest();
//        ResponseEntity<?> badResponse = new ResponseEntity<>(new LetterPreferencesResponse(), HttpStatus.BAD_REQUEST);
//
//        doReturn(badResponse).when(handlerSpy)
//                .retryRequest(anyString(), any(HttpEntity.class), eq(LetterPreferencesResponse.class), eq(HttpMethod.POST));
//
//        NDBToken refresh = new NDBToken();
//        refresh.setAccessToken("refresh-token");
//        when(oauth2Handler.getOauthTokenRefresh("PDO", "NDB")).thenReturn(refresh);
//
//        ResponseEntity<?> result = handlerSpy.sendRequest("https://example.test", new HttpEntity<>("{}"), LetterPreferencesResponse.class, HttpMethod.POST, request);
//
//        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
//    }

    @Test(expected = NullPointerException.class)
    public void testUpdateProviderLetterPreferencesThrowsOnNullResponseEntity() throws Exception {
        LetterPreferencesRequest request = createLetterPreferenceRequest();

        doReturn(null).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(LetterPreferencesResponse.class), eq(HttpMethod.POST), eq(request));

        handlerSpy.updateProviderLetterPreferences(request, "123456789", "111223333");
    }

    @Test
    public void testUpdateProviderLetterPreferencesListReturnsTrueWhenPrepFails() throws Exception {
        when(oauth2Handler.getOauthToken("PDO", "NDB")).thenThrow(new IOException("oauth down"));

        boolean result = handlerSpy.updateProviderLetterPreferences(Collections.singletonList(createLetterPreferenceRequest()));

        assertTrue(result);
    }

    @Test
    public void testNdbWebServicePrepSetsTokenWhenNotNull() throws Exception {
        NDBToken token = new NDBToken();
        token.setAccessToken("set-token");
        when(oauth2Handler.getOauthToken("PDO", "NDB")).thenReturn(token);

        handlerSpy.ndbWebServicePrep();

        assertNotNull(handlerSpy.getToken());
        assertEquals("set-token", handlerSpy.getToken().getAccessToken());
    }

    @Test
    public void testGetProviderDataBuildsRequest() throws Exception {
        doNothing().when(handlerSpy).ndbWebServicePrep();

        com.optum.providerpreferences.rs.model.ndb.provider.RequestData requestData =
                new com.optum.providerpreferences.rs.model.ndb.provider.RequestData("111223333", "corp-1");

        CorpMpinResponse expectedBody = new CorpMpinResponse();
        ResponseEntity<?> response = new ResponseEntity<>(expectedBody, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(CorpMpinResponse.class), eq(HttpMethod.POST));

        CorpMpinResponse result = handlerSpy.getProviderData(requestData);

        assertNotNull(result);
    }

    @Test
    public void testUpdateProviderLetterPreferencesReturnsFalseOnNonOkNonAlreadyExists() throws Exception {
        LetterPreferencesRequest request = createLetterPreferenceRequest();

        LetterPreferencesResponse body = new LetterPreferencesResponse();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setReturncode("00");
        responseHeader.setMessage("OTHER_ERROR");
        body.setResponseHeader(responseHeader);

        ResponseEntity<LetterPreferencesResponse> response = new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(LetterPreferencesResponse.class), eq(HttpMethod.POST), eq(request));

        boolean result = handlerSpy.updateProviderLetterPreferences(request, "123456789", "111223333");

        assertFalse(result);
    }

    @Test
    public void testUpdateProviderLetterPreferencesAlreadyExistMessage() throws Exception {
        LetterPreferencesRequest request = createLetterPreferenceRequest();

        LetterPreferencesResponse body = new LetterPreferencesResponse();
        ResponseHeader responseHeader = new ResponseHeader();
        responseHeader.setReturncode("00");
        responseHeader.setMessage("already exist in db");
        body.setResponseHeader(responseHeader);

        ResponseEntity<LetterPreferencesResponse> response = new ResponseEntity<>(body, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(LetterPreferencesResponse.class), eq(HttpMethod.POST), eq(request));

        boolean result = handlerSpy.updateProviderLetterPreferences(request, "123456789", "111223333");

        assertTrue(result);
    }

    private void setOauth2Handler(NDBHandler target, Oauth2Handler oauth2) throws Exception {
        Field field = ServiceBase.class.getDeclaredField("oauth2handler");
        field.setAccessible(true);
        field.set(target, oauth2);
    }

    private HttpHeaders getHeaders(NDBHandler target) throws Exception {
        Field field = NDBHandler.class.getDeclaredField("headers");
        field.setAccessible(true);
        return (HttpHeaders) field.get(target);
    }

    private void setClient(NDBHandler target, RestTemplate restTemplate) throws Exception {
        Field field = NDBHandler.class.getDeclaredField("client");
        field.setAccessible(true);
        field.set(target, restTemplate);
    }

    private LetterPreferencesRequest createLetterPreferenceRequest() {
        com.optum.providerpreferences.rs.model.ndb.preferences.RequestData requestData =
                new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData("123456789", "111223333", "U", "E", "E2");
        return new LetterPreferencesRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestHeader("PDO", "PDO", "938", "0"), requestData);
    }
}

