package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import kong.unirest.HttpRequestWithBody;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.json.JSONArray;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class FDSCloudHandlerTest {

    private FDSCloudHandler handler;
    private Oauth2Handler oauth2Handler;

    @Before
    public void setUp() throws Exception {
        handler = new FDSCloudHandler();
        oauth2Handler = Mockito.mock(Oauth2Handler.class);
        setOauth2Handler(handler, oauth2Handler);
        setField(handler, "fdsCloudURL", "https://example.test/fds/{spaceId}");
        setField(handler, "fdsCloudSpaceId", "space-1");
    }

    @Test
    public void testCreateSearchTermsFromMap() {
        Map<String, Object> metadata = new LinkedHashMap<>();
        metadata.put("tin", "111223333");
        metadata.put("corpMpin", "ABC123");

        String result = handler.createSearchTermsFromMap(metadata);

        assertEquals("(tin=111223333)+(corpMpin=ABC123)", result);
    }

    @Test
    public void testCreateSearchTermsFromMapWithEmptyInput() {
        String result = handler.createSearchTermsFromMap(Collections.emptyMap());

        assertEquals("", result);
    }

    @Test
    public void testCreateSearchTermsRequestFromMap() {
        Map<String, Object> metadata = new LinkedHashMap<>();
        metadata.put("tin", "111223333");
        metadata.put("corpMpin", "ABC123");

        FDSCloudRequest request = handler.createSearchTermsRequestFromMap(metadata);

        assertNotNull(request);
        assertNotNull(request.getRequest());
        assertEquals("(tin=111223333)+(corpMpin=ABC123)", request.getRequest().get("searchTerms"));
    }

    @Test
    public void testGetSearchTermsFromString() {
        String metadata = "{\"tin\":\"111223333\",\"corpMpin\":\"ABC123\"}";

        Map<String, Object> result = handler.getSearchTermsFromString(metadata);

        assertNotNull(result);
        assertEquals("111223333", result.get("tin"));
        assertEquals("ABC123", result.get("corpMpin"));
    }

    @Test
    public void testGetSearchTermsFromStringInvalidJsonReturnsNull() {
        Map<String, Object> result = handler.getSearchTermsFromString("not-json");

        assertNull(result);
    }

    @Test(expected = NullPointerException.class)
    public void testGetSearchTermsFromStringNullThrows() {
        handler.getSearchTermsFromString(null);
    }

    @Test
    public void testGetSearchTermsFromDocument() {
        OptOutFDSCloudDocument document = new OptOutFDSCloudDocument();
        document.setMetadata("{\"tin\":\"111223333\",\"corpMpin\":\"ABC123\"}");

        Map<String, Object> result = handler.getSearchTermsFromDocument(document);

        assertNotNull(result);
        assertEquals("111223333", result.get("tin"));
        assertEquals("ABC123", result.get("corpMpin"));
    }

    @Test(expected = NullPointerException.class)
    public void testGetSearchTermsFromDocumentWithNullMetadataThrows() {
        OptOutFDSCloudDocument document = new OptOutFDSCloudDocument();
        handler.getSearchTermsFromDocument(document);
    }

    @Test
    public void testFDSCloudGetRequestMapsBody() throws Exception {
        FDSCloudHandler spyHandler = Mockito.spy(handler);
        mockToken("session-get");

        HttpResponse<JsonNode> uniResponse = mockUnirestResponse("{}", 0);
        doReturn(uniResponse).when(spyHandler).sendUnirestRequest(any(HttpRequestWithBody.class));

        Map<String, Object> req = new HashMap<>();
        req.put("searchTerms", "(tin=111223333)");
        FDSCloudRequest fdsRequest = new FDSCloudRequest();
        fdsRequest.setRequest(req);

        FDSCloudGETResponse result = spyHandler.FDSCloudGetRequest("session-get", fdsRequest);

        assertNotNull(result);
    }

    @Test
    public void testFDSCloudGetDocumentMapsBody() throws Exception {
        FDSCloudHandler spyHandler = Mockito.spy(handler);
        mockToken("session-doc");

        HttpResponse<JsonNode> uniResponse = mockUnirestResponse("{\"documentId\":\"doc-1\"}", 1);
        doReturn(uniResponse).when(spyHandler).sendUnirestRequest(any(HttpRequestWithBody.class));

        OptOutFDSCloudDocument result = spyHandler.FDSCloudGetDocument("session-doc", "doc-1");

        assertNotNull(result);
        assertEquals("doc-1", result.getDocumentId());
    }

    @Test
    public void testFDSCloudPostRequestSuccess() throws Exception {
        FDSCloudHandler spyHandler = Mockito.spy(handler);
        mockToken("session-post");

        ResponseEntity<?> postResponse = new ResponseEntity<>(new OptOutFDSCloudPOSTResponse(), HttpStatus.CREATED);
        doReturn(postResponse).when(spyHandler)
                .sendRequest(anyString(), any(HttpEntity.class), eq(OptOutFDSCloudPOSTResponse.class), eq(HttpMethod.POST));

        FDSCloudRequest request = new FDSCloudRequest();
        request.setRequest(new HashMap<>());

        ResponseEntity<?> result = spyHandler.FDSCloudPostRequest("session-post", request);

        assertNotNull(result);
        assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testFDSCloudPutRequestSuccess() throws Exception {
        FDSCloudHandler spyHandler = Mockito.spy(handler);
        mockToken("session-put");

        ResponseEntity<?> putResponse = new ResponseEntity<>(new OptOutFDSCloudPOSTResponse(), HttpStatus.OK);
        doReturn(putResponse).when(spyHandler)
                .sendRequest(anyString(), any(HttpEntity.class), eq(OptOutFDSCloudPOSTResponse.class), eq(HttpMethod.PUT));

        FDSCloudRequest request = new FDSCloudRequest();
        request.setDocumentId("doc-1");
        request.setRequest(new HashMap<>());

        ResponseEntity<?> result = spyHandler.FDSCloudPutRequest("session-put", request);

        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testFDSCloudResendPutSuccess() throws Exception {
        FDSCloudHandler spyHandler = Mockito.spy(handler);
        mockToken("resend");

        ResponseEntity<?> putResponse = new ResponseEntity<>(new OptOutFDSCloudPOSTResponse(), HttpStatus.OK);
        doReturn(putResponse).when(spyHandler)
                .sendRequest(anyString(), any(HttpEntity.class), eq(OptOutFDSCloudPOSTResponse.class), eq(HttpMethod.PUT));

        FDSCloudRequest request = new FDSCloudRequest();
        request.setDocumentId("doc-2");
        request.setRequest(new HashMap<>());

        ResponseEntity<?> result = spyHandler.FDSCloudResendPUT(request);

        assertNotNull(result);
        assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testCreateMapFromPojo() {
        Map<String, Object> source = new LinkedHashMap<>();
        source.put("k1", "v1");

        Map<String, Object> result = handler.createMapFromPOJO(source);

        assertNotNull(result);
        assertEquals("v1", result.get("k1"));
    }

    @Test
    public void testEncodeToUTF() {
        String result = handler.encodeToUTF("hello world+test");

        assertEquals("hello+world%2Btest", result);
    }

    @Test
    public void testGetFDSCloudTokenSuccess() throws Exception {
        Token token = new Token();
        token.setAccessToken("token-123");
        when(oauth2Handler.getOauthToken("session-1", "FDSCLOUD")).thenReturn(token);

        Token result = handler.getFDSCloudToken("session-1");

        assertNotNull(result);
        assertEquals("token-123", result.getAccessToken());
        verify(oauth2Handler, times(1)).getOauthToken("session-1", "FDSCLOUD");
    }

    @Test
    public void testGetFDSCloudTokenWrapsOauthException() throws Exception {
        when(oauth2Handler.getOauthToken("session-1", "FDSCLOUD"))
                .thenThrow(new OAuthSystemException("oauth-failed"));

        try {
            handler.getFDSCloudToken("session-1");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to make FDS OAUTH service call"));
        }
    }

    @Test
    public void testGetFDSCloudTokenWrapsIOException() throws Exception {
        when(oauth2Handler.getOauthToken("session-1", "FDSCLOUD"))
                .thenThrow(new IOException("io-failed"));

        try {
            handler.getFDSCloudToken("session-1");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to make FDS OAUTH service call"));
        }
    }

    @Test(expected = NullPointerException.class)
    public void testGetFDSCloudTokenThrowsWhenAccessTokenMissing() throws Exception {
        Token token = new Token();
        when(oauth2Handler.getOauthToken("session-2", "FDSCLOUD")).thenReturn(token);

        handler.getFDSCloudToken("session-2");
    }

    @Test(expected = NullPointerException.class)
    public void testFDSCloudPutRequestNullDocumentIdValidation() throws Exception {
        invokeValidateDocumentId(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFDSCloudPutRequestEmptyDocumentIdValidation() throws Exception {
        invokeValidateDocumentId("   ");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFDSCloudPutRequestDocumentIdWithSpacesValidation() throws Exception {
        invokeValidateDocumentId("abc 123");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFDSCloudPutRequestTooLongDocumentIdValidation() throws Exception {
        String tooLongId = "a".repeat(256);
        invokeValidateDocumentId(tooLongId);
    }

    private void setOauth2Handler(FDSCloudHandler target, Oauth2Handler oauth2) throws Exception {
        Field field = ServiceBase.class.getDeclaredField("oauth2handler");
        field.setAccessible(true);
        field.set(target, oauth2);
    }

    private void setField(FDSCloudHandler target, String fieldName, String value) throws Exception {
        Field field = FDSCloudHandler.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private void mockToken(String sessionId) throws Exception {
        Token token = new Token();
        token.setAccessToken("token-1");
        when(oauth2Handler.getOauthToken(sessionId, "FDSCLOUD")).thenReturn(token);
    }

    @SuppressWarnings("unchecked")
    private HttpResponse<JsonNode> mockUnirestResponse(String bodyAsString, int arrayLength) {
        HttpResponse<JsonNode> response = Mockito.mock(HttpResponse.class);
        JsonNode body = Mockito.mock(JsonNode.class);
        JSONArray array = new JSONArray();
        for (int i = 0; i < arrayLength; i++) {
            array.put(new Object());
        }
        when(response.getBody()).thenReturn(body);
        when(body.getArray()).thenReturn(array);
        when(body.toString()).thenReturn(bodyAsString);
        return response;
    }

    private void invokeValidateDocumentId(String documentId) throws Exception {
        Method method = FDSCloudHandler.class.getDeclaredMethod("validateDocumentId", String.class);
        method.setAccessible(true);
        try {
            method.invoke(handler, documentId);
        } catch (java.lang.reflect.InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof RuntimeException) {
                throw (RuntimeException) cause;
            }
            throw e;
        }
    }
}

