package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PESCorpMpinHandlerTest {

    private PESCorpMpinHandler handler;

    @Before
    public void setUp() {
        handler = new PESCorpMpinHandler();
        handler.headers = new HttpHeaders();
        handler.pesCorpMpinUrl = "https://example.org/pes";
    }

    @Test
    public void xmlResponseParserReturnsCorpMpinWhenTagExists() {
        String response = "<response><corpMPIN>123456789</corpMPIN></response>";

        String result = handler.xmlResponseParser(response);

        assertEquals("123456789", result);
    }

    @Test
    public void xmlResponseParserReturnsNullWhenTagMissing() {
        String response = "<response><other>value</other></response>";

        String result = handler.xmlResponseParser(response);

        assertNull(result);
    }

    @Test
    public void getCorpMpinReturnsParsedValue() throws Exception {
        PESCorpMpinHandler spyHandler = spy(handler);
        ResponseEntity<String> mockResponse = ResponseEntity.ok("<corpMPIN>998877665</corpMPIN>");

        doReturn(mockResponse).when(spyHandler)
                .sendRequest(eq("https://example.org/pes"), any(HttpEntity.class), eq(String.class), eq(HttpMethod.POST));

        String result = spyHandler.getCorpMpin("123456789");

        assertEquals("998877665", result);
        verify(spyHandler, times(1))
                .sendRequest(eq("https://example.org/pes"), any(HttpEntity.class), eq(String.class), eq(HttpMethod.POST));
    }

    @Test
    public void getCorpMpinWrapsUnexpectedExceptionAsApplicationException() throws Exception {
        PESCorpMpinHandler spyHandler = spy(handler);
        doThrow(new RuntimeException("boom")).when(spyHandler)
                .sendRequest(eq("https://example.org/pes"), any(HttpEntity.class), eq(String.class), eq(HttpMethod.POST));

        try {
            spyHandler.getCorpMpin("123456789");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("boom"));
        }
    }

    @Test
    public void getPESTokenSetsBearerHeaderAndFormContentType() throws Exception {
        Oauth2Handler oauth2Handler = mock(Oauth2Handler.class);
        Token token = new Token();
        token.setAccessToken("access-token-123");

        when(oauth2Handler.getOauthToken("PDO", "PES_CORPMPIN")).thenReturn(token);

        handler.oauth2handler = oauth2Handler;
        handler.headers = new HttpHeaders();

        handler.getPESToken();

        assertNotNull(handler.getToken());
        assertEquals("access-token-123", handler.getToken().getAccessToken());
        assertEquals("bearer access-token-123", handler.headers.getFirst("Authorization"));
        assertEquals(MediaType.APPLICATION_FORM_URLENCODED, handler.headers.getContentType());
    }

    @Test
    public void getPESTokenRetriesWhenFirstTokenIsNull() throws Exception {
        Oauth2Handler oauth2Handler = mock(Oauth2Handler.class);
        Token token = new Token();
        token.setAccessToken("retry-token");

        when(oauth2Handler.getOauthToken("PDO", "PES_CORPMPIN"))
                .thenReturn(null)
                .thenReturn(token);

        handler.oauth2handler = oauth2Handler;
        handler.headers = new HttpHeaders();
        handler.numRetries = 1;
        handler.timeToWaitMsArr = new long[]{1};

        handler.getPESToken();

        verify(oauth2Handler, times(2)).getOauthToken("PDO", "PES_CORPMPIN");
        assertEquals("bearer retry-token", handler.headers.getFirst("Authorization"));
    }
}

