package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.PasswordOwnerInfo;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.ndb.NDBProvider;
import com.optum.providerpreferences.rs.model.ndb.NDBProviders;
import com.optum.providerpreferences.rs.model.ndb.Tin;
import com.optum.providerpreferences.rs.model.ndb.Tins;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class CACFHandlerTest {

    private CACFHandler handlerSpy;
    private Oauth2Handler oauth2Handler;

    @Before
    public void setUp() throws Exception {
        CACFHandler realHandler = new CACFHandler();
        handlerSpy = Mockito.spy(realHandler);

        oauth2Handler = Mockito.mock(Oauth2Handler.class);
        setOauth2Handler(handlerSpy, oauth2Handler);

        setLinkField(handlerSpy, "linkTinsURL", "https://example.test/tins");
        setLinkField(handlerSpy, "linkProvidersURL", "https://example.test/providers");
    }

    @Test
    public void testGetTaxIDNumbersSuccess() throws Exception {
        Token token = new Token();
        token.setAccessToken("access-token");
        when(oauth2Handler.getOauthToken("session-1", "LINK")).thenReturn(token);

        Tin tin1 = new Tin();
        tin1.setTin("111223333");
        Tin tin2 = new Tin();
        tin2.setTin("222334444");

        Tins tins = new Tins();
        tins.setTinList(Arrays.asList(tin1, tin2));

        ResponseEntity<?> response = new ResponseEntity<>(tins, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(Tins.class), eq(HttpMethod.GET));

        PasswordOwner result = handlerSpy.getTaxIDNumbers("uuid-1", "uhc-1", "mpin-1", "session-1");

        assertNotNull(result);
        assertEquals("uuid-1", result.getOptumUUID());
        assertEquals("uhc-1", result.getUhcID());
        assertEquals("mpin-1", result.getMpin());
        assertEquals(2, result.getProviders().size());
        assertEquals("111223333", result.getProviders().get(0).getTin());
        assertEquals("222334444", result.getProviders().get(1).getTin());

        verify(oauth2Handler, times(1)).getOauthToken("session-1", "LINK");
    }

    @Test
    public void testGetTaxIDNumbersThrowsWhenNoTins() throws Exception {
        Token token = new Token();
        token.setAccessToken("access-token");
        when(oauth2Handler.getOauthToken("session-1", "LINK")).thenReturn(token);

        Tins tins = new Tins();
        tins.setTinList(Collections.emptyList());

        ResponseEntity<?> response = new ResponseEntity<>(tins, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(Tins.class), eq(HttpMethod.GET));

        try {
            handlerSpy.getTaxIDNumbers("uuid-1", "uhc-1", "mpin-1", "session-1");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Error: LINK Tax ID Numbers"));
        }
    }

    @Test
    public void testGetTaxIDNumbersThrowsWhenOauthFails() throws Exception {
        when(oauth2Handler.getOauthToken("session-1", "LINK")).thenThrow(new IOException("oauth-fail"));

        try {
            handlerSpy.getTaxIDNumbers("uuid-1", "uhc-1", "mpin-1", "session-1");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to make CACF web service call"));
        }
    }

    @Test
    public void testGetProvidersSuccess() throws Exception {
        Token token = new Token();
        token.setAccessToken("access-token");
        when(oauth2Handler.getOauthToken("session-2", "LINK")).thenReturn(token);

        NDBProvider p1 = new NDBProvider();
        p1.setName("Provider A");
        NDBProvider p2 = new NDBProvider();
        p2.setName("Provider B");

        NDBProviders providers = new NDBProviders();
        providers.setProviderList(Arrays.asList(p1, p2));

        ResponseEntity<?> response = new ResponseEntity<>(providers, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(NDBProviders.class), eq(HttpMethod.GET));

        List<PasswordOwnerInfo> result = handlerSpy.getProviders("uuid-2", "uhc-2", "mpin-2", "tin-2", "session-2");

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Provider A", result.get(0).getProviderName());
        assertEquals("Provider B", result.get(1).getProviderName());
        assertEquals("tin-2", result.get(0).getTin());
        assertEquals("tin-2", result.get(1).getTin());
    }

    @Test
    public void testGetProvidersThrowsWhenNoProviders() throws Exception {
        Token token = new Token();
        token.setAccessToken("access-token");
        when(oauth2Handler.getOauthToken("session-2", "LINK")).thenReturn(token);

        NDBProviders providers = new NDBProviders();
        providers.setProviderList(Collections.emptyList());

        ResponseEntity<?> response = new ResponseEntity<>(providers, HttpStatus.OK);
        doReturn(response).when(handlerSpy)
                .sendRequest(anyString(), any(HttpEntity.class), eq(NDBProviders.class), eq(HttpMethod.GET));

        try {
            handlerSpy.getProviders("uuid-2", "uhc-2", "mpin-2", "tin-2", "session-2");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("NDB PROVIDERS WAS EMPTY"));
        }
    }

    @Test
    public void testGetProvidersThrowsWhenOauthFails() throws Exception {
        when(oauth2Handler.getOauthToken("session-2", "LINK"))
                .thenThrow(new OAuthSystemException("oauth-system-fail"));

        try {
            handlerSpy.getProviders("uuid-2", "uhc-2", "mpin-2", "tin-2", "session-2");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Failed to get OAuth Token for LINK - getProviders"));
        }
    }

    private void setOauth2Handler(Object target, Object value) throws Exception {
        Field field = CACFHandler.class.getDeclaredField("oauth2handler");
        field.setAccessible(true);
        field.set(target, value);
    }

    private void setLinkField(Object target, String fieldName, Object value) throws Exception {
        Field field = CACFHandler.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}

