package com.optum.providerpreferences.rs.handler;

import org.junit.Test;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class RequestFactoryTest {

    @Test
    public void restTemplateShouldReturnConfiguredBean() {
        RequestFactory requestFactoryConfig = new RequestFactory();

        RestTemplate restTemplate = requestFactoryConfig.restTemplate();

        assertNotNull(restTemplate);
        assertNotNull(restTemplate.getRequestFactory());
        assertTrue(restTemplate.getRequestFactory() instanceof HttpComponentsClientHttpRequestFactory);
    }
}

