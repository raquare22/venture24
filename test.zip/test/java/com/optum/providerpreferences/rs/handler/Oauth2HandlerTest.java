package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class Oauth2HandlerTest {

    private Oauth2Handler handler;
    private RestTemplate restTemplate;

    @Before
    public void setUp() {
        handler = Mockito.spy(new Oauth2Handler());
        restTemplate = Mockito.mock(RestTemplate.class);
        handler.restTemplate = restTemplate;

        // Reset static shared state between tests.
        Oauth2Handler.tokenMap.clear();

        handler.stargateTokenUrl = "https://stargate.test/oauth";
        handler.stargateClientId = "sg-client";
        handler.stargateClientSecret = "sg-secret";
        handler.fdsTokenUrl = "https://fds.test/oauth";
        handler.fdsClientId = "fds-client";
        handler.fdsClientSecret = "fds-secret";
        handler.pesCorpMpinClientId = "pes-client";
        handler.pesCorpMpinClientSecret = "pes-secret";
    }

    @Test
    public void testGetTokenFromMapCreatesAndCachesTokenStore() throws Exception {
        Oauth2Handler.TokenStore tokenStore = handler.getTokenFromMap("s1", "FDSCLOUD");

        assertNotNull(tokenStore);
        assertEquals("https://fds.test/oauth", tokenStore.tokenURL);
        assertEquals("fds-client", tokenStore.clientId);
        assertEquals("fds-secret", tokenStore.clientSecret);
        assertTrue(Oauth2Handler.tokenMap.containsKey("FDSCLOUD"));
    }

    @Test
    public void testGetTokenFromMapThrowsWhenEnvMissing() {
        handler.stargateTokenUrl = null;
        handler.stargateClientId = null;
        handler.stargateClientSecret = null;

        try {
            handler.getTokenFromMap("s1", "DS");
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("System environment variable"));
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    public void testGetNewTokenPopulatesAccessTokenAndExpiry() throws Exception {
        Oauth2Handler.TokenStore tokenStore = handler.new TokenStore("https://fds.test/oauth", "id", "secret");

        HashMap<String, Object> body = new HashMap<>();
        body.put("access_token", "abc123");
        body.put("expires_in", 3600);

        ResponseEntity<HashMap<String, Object>> responseEntity = Mockito.mock(ResponseEntity.class);
        when(responseEntity.getBody()).thenReturn(body);
        when(restTemplate.exchange(eq("https://fds.test/oauth"), eq(HttpMethod.POST), any(HttpEntity.class), eq(HashMap.class)))
                .thenReturn((ResponseEntity) responseEntity);

        Oauth2Handler.TokenStore updated = handler.getNewToken("s1", "FDSCLOUD", tokenStore);

        assertNotNull(updated.token);
        assertEquals("abc123", updated.token.getAccessToken());
        assertEquals(3600L, updated.expiresIn);
    }

    @Test
    public void testGetOauthTokenCallsGetSyncTokenWhenExpiring() throws Exception {
        Oauth2Handler.TokenStore tokenStore = handler.new TokenStore("u", "i", "s");
        tokenStore.lastTokenExpireTime = 0L;
        tokenStore.token = new Token();
        tokenStore.token.setAccessToken("old");
        Oauth2Handler.tokenMap.put("FDSCLOUD", tokenStore);

        doNothing().when(handler).getSyncToken("sess", "FDSCLOUD");

        handler.getOauthToken("sess", "FDSCLOUD");

        verify(handler).getSyncToken("sess", "FDSCLOUD");
    }

    @Test
    public void testGetOauthTokenDoesNotCallGetSyncTokenWhenValid() throws Exception {
        Oauth2Handler.TokenStore tokenStore = handler.new TokenStore("u", "i", "s");
        tokenStore.lastTokenExpireTime = System.currentTimeMillis() + 3_600_000L;
        tokenStore.token = new Token();
        tokenStore.token.setAccessToken("valid");
        Oauth2Handler.tokenMap.put("FDSCLOUD", tokenStore);

        Token result = (Token) handler.getOauthToken("sess", "FDSCLOUD");

        assertEquals("valid", result.getAccessToken());
        verify(handler, never()).getSyncToken("sess", "FDSCLOUD");
    }

    @Test
    public void testTokenAboutToExpireThreshold() {
        boolean expiring = handler.tokenAboutToExpire("s1", System.currentTimeMillis() + 1000L);
        boolean notExpiring = handler.tokenAboutToExpire("s1", System.currentTimeMillis() + 600_000L);

        assertTrue(expiring);
        assertFalse(notExpiring);
    }

    @Test
    public void testGetInstanceReturnsSingleton() {
        Oauth2Handler h1 = Oauth2Handler.getInstance();
        Oauth2Handler h2 = Oauth2Handler.getInstance();
        assertSame(h1, h2);
    }

    @Test
    public void testGetOauthTokenRefreshClearsAndRefreshesToken() throws Exception {
        // Verify that refresh method clears the token by checking that getSyncToken is called
        Oauth2Handler.TokenStore tokenStore = handler.new TokenStore("https://stargate.test/oauth", "sg-client", "sg-secret");
        tokenStore.lastTokenExpireTime = System.currentTimeMillis() + 3_600_000L;
        tokenStore.expiresIn = 3600L;
        Token oldToken = new Token();
        oldToken.setAccessToken("old");
        tokenStore.token = oldToken;
        Oauth2Handler.tokenMap.put("DS", tokenStore);

        // Mock getSyncToken to avoid actual HTTP call
        doNothing().when(handler).getSyncToken("sess", "DS");

        // Call refresh which should clear expiry and call getSyncToken
        handler.getOauthTokenRefresh("sess", "DS");

        // Verify that getSyncToken was called (which handles actual token fetch)
        verify(handler, times(1)).getSyncToken("sess", "DS");
    }

    @Test
    public void testGetTokenFromMapNDBServiceIndicator() throws Exception {
        Oauth2Handler.TokenStore ts = handler.getTokenFromMap("s1", "NDB");
        assertEquals("https://stargate.test/oauth", ts.tokenURL);
        assertEquals("pes-client", ts.clientId);
    }

    @Test
    public void testGetTokenFromMapPESServiceIndicator() throws Exception {
        Oauth2Handler.TokenStore ts = handler.getTokenFromMap("s1", "PES");
        assertEquals("https://stargate.test/oauth", ts.tokenURL);
        assertEquals("pes-client", ts.clientId);
    }

    @Test
    public void testGetTokenFromMapLINKServiceIndicator() throws Exception {
        Oauth2Handler.TokenStore ts = handler.getTokenFromMap("s1", "LINK");
        assertEquals("https://stargate.test/oauth", ts.tokenURL);
        assertEquals("pes-client", ts.clientId);
    }

    @Test
    public void testGetTokenFromMapPES_CORPMPINServiceIndicator() throws Exception {
        Oauth2Handler.TokenStore ts = handler.getTokenFromMap("s1", "PES_CORPMPIN");
        assertEquals("https://stargate.test/oauth", ts.tokenURL);
        assertEquals("pes-client", ts.clientId);
    }

    @Test
    public void testGetTokenFromMapDSServiceIndicator() throws Exception {
        Oauth2Handler.TokenStore ts = handler.getTokenFromMap("s1", "DS");
        assertEquals("https://stargate.test/oauth", ts.tokenURL);
        assertEquals("sg-client", ts.clientId);
    }

    @Test
    public void testGetTokenFromMapDefaultServiceIndicator() throws Exception {
        Oauth2Handler.TokenStore ts = handler.getTokenFromMap("s1", "UNKNOWN");
        assertEquals("https://stargate.test/oauth", ts.tokenURL);
        assertEquals("sg-client", ts.clientId);
    }

    @Test
    public void testGetTokenFromMapReturnsCachedWhenExists() throws Exception {
        Oauth2Handler.TokenStore ts1 = handler.getTokenFromMap("s1", "DS");
        Oauth2Handler.TokenStore ts2 = handler.getTokenFromMap("s2", "DS");
        assertSame(ts1, ts2);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    public void testSetExpireTimeOfTokenUpdatesLastTokenExpireTime() {
        Oauth2Handler.TokenStore ts = handler.new TokenStore("u", "i", "s", 0L);
        ts.expiresIn = 3600L;
        long before = System.currentTimeMillis();
        handler.setExpireTimeOfToken("s1", "DS", ts);
        long after = System.currentTimeMillis();

        assertTrue(ts.lastTokenExpireTime >= before + 3_600_000L);
        assertTrue(ts.lastTokenExpireTime <= after + 3_600_000L);
    }

    @Test
    public void testTokenStoreConstructorWithExpireTime() {
        Oauth2Handler.TokenStore ts = handler.new TokenStore("url", "id", "secret", 12345L);
        assertEquals("url", ts.tokenURL);
        assertEquals("id", ts.clientId);
        assertEquals("secret", ts.clientSecret);
        assertEquals(12345L, ts.lastTokenExpireTime);
        assertNotNull(ts.toString());
    }

    @Test
    public void testSanitizeTimeLeftBeforeTokenExpires() {
        Long result = Oauth2Handler.sanitizetimeLeftBeforeTokenExpires(500L);
        assertEquals(500L, (long) result);
    }
}



