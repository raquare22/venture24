package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.NDBToken;
import com.optum.providerpreferences.rs.model.pes.Meta;
import com.optum.providerpreferences.rs.model.pes.PESResponse;
import com.optum.providerpreferences.rs.model.pes.PESTinRequest;import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.lang.reflect.Field;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PESHandlerTest {

    private PESHandler handler;

    @Before
    public void setUp() throws Exception {
        handler = new PESHandler();
        handler.pesTinUrl = "https://example.org/pes/tins";
        setPrivateField(handler, "headers", new HttpHeaders());
    }

    @Test
    public void testGetTinsReturnsBodyFromServiceResponse() throws Exception {
        PESHandler spyHandler = spy(handler);
        doNothing().when(spyHandler).pesWebServicePrep();

        PESResponse expectedBody = new PESResponse();
        expectedBody.setMeta(new Meta());
        expectedBody.setData(new java.util.ArrayList<>());
        ResponseEntity<PESResponse> responseEntity = ResponseEntity.ok(expectedBody);
        doReturn(responseEntity).when(spyHandler)
                .sendRequest(eq("https://example.org/pes/tins"), any(HttpEntity.class), eq(PESResponse.class), eq(HttpMethod.POST));

        PESResponse actual = spyHandler.getTins(new PESTinRequest("123456789"));

        assertSame(expectedBody, actual);
        verify(spyHandler, times(1)).pesWebServicePrep();
        verify(spyHandler, times(1))
                .sendRequest(eq("https://example.org/pes/tins"), any(HttpEntity.class), eq(PESResponse.class), eq(HttpMethod.POST));
    }

    @Test
    public void testGetTinsWrapsExceptionInApplicationException() throws Exception {
        PESHandler spyHandler = spy(handler);
        doNothing().when(spyHandler).pesWebServicePrep();
        doThrow(new RuntimeException("boom")).when(spyHandler)
                .sendRequest(eq("https://example.org/pes/tins"), any(HttpEntity.class), eq(PESResponse.class), eq(HttpMethod.POST));

        try {
            spyHandler.getTins(new PESTinRequest("123456789"));
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("boom"));
        }
    }

    @Test
    public void testPesWebServicePrepSetsAuthorizationAndJsonContentType() throws Exception {
        Oauth2Handler oauth2Handler = mock(Oauth2Handler.class);
        NDBToken token = new NDBToken();
        token.setAccessToken("ndb-token");
        when(oauth2Handler.getOauthToken("PDO", "PES")).thenReturn(token);

        handler.oauth2handler = oauth2Handler;
        HttpHeaders headers = new HttpHeaders();
        setPrivateField(handler, "headers", headers);

        handler.pesWebServicePrep();

        assertNotNull(handler.getToken());
        assertEquals("ndb-token", handler.getToken().getAccessToken());
        assertEquals("bearer ndb-token", headers.getFirst("Authorization"));
        assertEquals(MediaType.APPLICATION_JSON, headers.getContentType());
    }

    @Test
    public void testPesWebServicePrepRetriesWhenTokenInitiallyNull() throws Exception {
        Oauth2Handler oauth2Handler = mock(Oauth2Handler.class);
        NDBToken token = new NDBToken();
        token.setAccessToken("retry-token");

        when(oauth2Handler.getOauthToken("PDO", "PES"))
                .thenReturn(null)
                .thenReturn(token);

        handler.oauth2handler = oauth2Handler;
        handler.numRetries = 1;
        handler.timeToWaitMsArr = new long[]{1};
        HttpHeaders headers = new HttpHeaders();
        setPrivateField(handler, "headers", headers);

        handler.pesWebServicePrep();

        verify(oauth2Handler, times(2)).getOauthToken("PDO", "PES");
        assertEquals("bearer retry-token", headers.getFirst("Authorization"));
    }

    private static void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
}

