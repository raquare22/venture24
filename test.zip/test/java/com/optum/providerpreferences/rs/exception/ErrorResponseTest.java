package com.optum.providerpreferences.rs.exception;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ErrorResponseTest {

    @Test
    public void testConstructorInitializesFields() {
        ErrorResponse response = new ErrorResponse("E001", "Invalid request");

        assertEquals("E001", response.getErrorCode());
        assertEquals("Invalid request", response.getErrorMessage());
    }

    @Test
    public void testSettersUpdateFields() {
        ErrorResponse response = new ErrorResponse("E001", "Invalid request");

        response.setErrorCode("E002");
        response.setErrorMessage("Internal server error");

        assertEquals("E002", response.getErrorCode());
        assertEquals("Internal server error", response.getErrorMessage());
    }
}

