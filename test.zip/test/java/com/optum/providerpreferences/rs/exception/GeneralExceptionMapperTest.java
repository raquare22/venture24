package com.optum.providerpreferences.rs.exception;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.junit.Test;
import org.mockito.MockedStatic;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

public class GeneralExceptionMapperTest {

    @Test
    public void testToResponseForApplicationException() {
        GeneralExceptionMapper mapper = new GeneralExceptionMapper();
        ApplicationException exception = new ApplicationException("bad request payload");

        Response.ResponseBuilder builder = mock(Response.ResponseBuilder.class);
        Response mockedResponse = mock(Response.class);

        when(builder.type(MediaType.APPLICATION_JSON)).thenReturn(builder);
        when(builder.entity(any())).thenReturn(builder);
        when(builder.build()).thenReturn(mockedResponse);

        try (MockedStatic<Response> responseStatic = mockStatic(Response.class)) {
            responseStatic.when(() -> Response.status(Response.Status.BAD_REQUEST)).thenReturn(builder);

            Response result = mapper.toResponse(exception);

            assertNotNull(result);
            responseStatic.verify(() -> Response.status(Response.Status.BAD_REQUEST));
        }
    }

    @Test
    public void testToResponseForGenericException() {
        GeneralExceptionMapper mapper = new GeneralExceptionMapper();
        RuntimeException exception = new RuntimeException("unexpected error");

        Response.ResponseBuilder builder = mock(Response.ResponseBuilder.class);
        Response mockedResponse = mock(Response.class);

        when(builder.type(MediaType.APPLICATION_JSON)).thenReturn(builder);
        when(builder.entity(any())).thenReturn(builder);
        when(builder.build()).thenReturn(mockedResponse);

        try (MockedStatic<Response> responseStatic = mockStatic(Response.class)) {
            responseStatic.when(() -> Response.status(Response.Status.INTERNAL_SERVER_ERROR)).thenReturn(builder);

            Response result = mapper.toResponse(exception);

            assertNotNull(result);
            responseStatic.verify(() -> Response.status(Response.Status.INTERNAL_SERVER_ERROR));
        }
    }

    @Test
    public void testErrorResponsePojoFields() {
        ErrorResponse badRequest = new ErrorResponse("400", "bad request payload");
        ErrorResponse internal = new ErrorResponse("500", "Provider Preferences Internal Process Issue");

        assertEquals("400", badRequest.getErrorCode());
        assertEquals("bad request payload", badRequest.getErrorMessage());
        assertEquals("500", internal.getErrorCode());
        assertEquals("Provider Preferences Internal Process Issue", internal.getErrorMessage());
    }
}
