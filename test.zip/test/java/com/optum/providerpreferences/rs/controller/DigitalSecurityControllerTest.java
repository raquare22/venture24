package com.optum.providerpreferences.rs.controller;

import com.optum.digitalsecurity.model.response.OrgData;
import com.optum.digitalsecurity.model.response.ProvTin;
import com.optum.digitalsecurity.model.response.ProviderProfile;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class DigitalSecurityControllerTest {

    @Test
    public void testGetProviderReturnsExpectedProfile() {
        DigitalSecurityController controller = new DigitalSecurityController();
        Map<String, String> req = new HashMap<>();
        req.put("uuid", "uuid-123");

        ProviderProfile profile = controller.getProvider(req);

        assertNotNull(profile);
        assertEquals("uuid-123", profile.getUuid());
        assertNotNull(profile.getDemographics());
        assertEquals("Tim", profile.getDemographics().getFirstName());
        assertEquals("Cook", profile.getDemographics().getLastName());

        assertNotNull(profile.getJobFunction());
        assertEquals(1, profile.getJobFunction().size());
        assertEquals("sampleCode", profile.getJobFunction().get(0).getCode());

        assertNotNull(profile.getProviderOrg());
        assertEquals(4, profile.getProviderOrg().size());
        assertEquals("1234", profile.getProviderOrg().get(0).getId());
        assertTrue(profile.getProviderOrg().get(0).isPaa());

        assertNotNull(profile.getNonProviderOrg());
        assertEquals(1, profile.getNonProviderOrg().size());
        assertEquals("sampleIrsOrgId", profile.getNonProviderOrg().get(0).getIrsOrgId());
    }

    @Test
    public void testGetOrgDataReturnsExpectedOrgData() {
        DigitalSecurityController controller = new DigitalSecurityController();
        Map<String, String> req = new HashMap<>();
        req.put("uuid", "uuid-456");
        req.put("corpMpin", "corp-111");

        OrgData orgData = controller.getOrgData(req);

        assertNotNull(orgData);
        assertEquals("uuid-456", orgData.getId());
        assertEquals("corp-111", orgData.getCorpMpin());

        assertNotNull(orgData.getTins());
        assertEquals(2, orgData.getTins().size());
        assertEquals("261531455", orgData.getTins().get(0).getTin());
        assertEquals("261531454", orgData.getTins().get(1).getTin());

        assertNotNull(orgData.getTins().get(0).getPermission());
        assertEquals(1, orgData.getTins().get(0).getPermission().size());
        assertEquals("sampleCode", orgData.getTins().get(0).getPermission().get(0).getCode());
    }

    @Test
    public void testGetTinDataReturnsExpectedProvTin() {
        DigitalSecurityController controller = new DigitalSecurityController();
        Map<String, String> req = new HashMap<>();
        req.put("uuid", "uuid-789");
        req.put("corpMpin", "corp-222");
        req.put("tin", "111223333");

        ProvTin provTin = controller.getTinData(req);

        assertNotNull(provTin);
        assertEquals("uuid-789", provTin.getUuid());
        assertEquals("corp-222", provTin.getCorpMpin());
        assertEquals("111223333", provTin.getTin());

        assertNotNull(provTin.getProvider());
        assertEquals(1, provTin.getProvider().size());
        assertEquals("Tim", provTin.getProvider().get(0).getFirstName());
        assertEquals("Cook", provTin.getProvider().get(0).getLastName());
        assertEquals("002056499", provTin.getProvider().get(0).getProviderMpin());
    }

    @Test
    public void testGetProviderHandlesMissingUuid() {
        DigitalSecurityController controller = new DigitalSecurityController();
        Map<String, String> req = new HashMap<>();

        ProviderProfile profile = controller.getProvider(req);

        assertNotNull(profile);
        assertEquals(null, profile.getUuid());
        assertFalse(profile.getProviderOrg().isEmpty());
    }
}

