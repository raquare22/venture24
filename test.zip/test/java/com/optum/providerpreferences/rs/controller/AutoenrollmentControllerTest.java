package com.optum.providerpreferences.rs.controller;

import com.optum.providerpreferences.autoenrollment.Scheduler;
import com.optum.providerpreferences.autoenrollment.SchedulerAutoEnrollment;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import org.junit.Test;
import org.mockito.MockedStatic;

import java.util.LinkedHashSet;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;

public class AutoenrollmentControllerTest {

    @Test
    public void testCheckAutoenrollmentReturnsSchedulerResult() throws Exception {
        Set<String> expected = new LinkedHashSet<>();
        expected.add("doc-1");
        expected.add("doc-2");

        try (MockedStatic<Scheduler> schedulerMock = mockStatic(Scheduler.class)) {
            schedulerMock.when(Scheduler::checkAutoenrollment).thenReturn(expected);

            Set<String> result = AutoenrollmentController.checkAutoenrollment();

            assertEquals(expected, result);
            schedulerMock.verify(Scheduler::checkAutoenrollment, times(1));
        }
    }

    @Test
    public void testCheckAutoenrollmentWrapsExceptionInApplicationException() {
        try (MockedStatic<Scheduler> schedulerMock = mockStatic(Scheduler.class)) {
            schedulerMock.when(Scheduler::checkAutoenrollment)
                    .thenThrow(new RuntimeException("boom"));

            try {
                AutoenrollmentController.checkAutoenrollment();
                fail("Expected ApplicationException");
            } catch (ApplicationException e) {
                assertTrue(e.getMessage().contains("Error at checkAutoenrollment"));
                assertTrue(e.getMessage().contains("boom"));
            }
        }
    }

    @Test
    public void testStartAutoenrollmentInvokesSchedulerManualPoll() throws Exception {
        try (MockedStatic<SchedulerAutoEnrollment> schedulerAutoMock = mockStatic(SchedulerAutoEnrollment.class)) {
            AutoenrollmentController.startAutoenrollment();

            schedulerAutoMock.verify(SchedulerAutoEnrollment::pollCSVFilesManual, times(1));
        }
    }

    @Test
    public void testStartAutoenrollmentWrapsExceptionInApplicationException() {
        try (MockedStatic<SchedulerAutoEnrollment> schedulerAutoMock = mockStatic(SchedulerAutoEnrollment.class)) {
            schedulerAutoMock.when(SchedulerAutoEnrollment::pollCSVFilesManual)
                    .thenThrow(new RuntimeException("manual-fail"));

            try {
                AutoenrollmentController.startAutoenrollment();
                fail("Expected ApplicationException");
            } catch (ApplicationException e) {
                assertTrue(e.getMessage().contains("Error at checkAutoenrollment"));
                assertTrue(e.getMessage().contains("manual-fail"));
            }
        }
    }
}

