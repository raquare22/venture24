package com.optum.providerpreferences.rs.controller;

import com.optum.digitalsecurity.model.request.User;
import com.optum.digitalsecurity.model.response.Corporate;
import com.optum.digitalsecurity.model.response.PDOCorporates;
import com.optum.digitalsecurity.model.response.PDOProvTin;
import com.optum.digitalsecurity.model.response.PDOTins;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.GenericResponse;
import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinData;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.ndb.provider.ResponseData;
import com.optum.providerpreferences.rs.service.DigitalSecurityService;
import com.optum.providerpreferences.rs.service.ProviderPreferencesService;
import com.optum.providerpreferences.rs.utility.MessageBuilder;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ProvPrefFDSCloudControllerTest {

    @InjectMocks
    private ProvPrefFDSCloudController controller;

    @Mock
    private DigitalSecurityService digitalSecService;

    @Mock
    private ProviderPreferencesService providerPreferencesService;

    @Mock
    private MessageBuilder messageBuilder;

    @Mock
    private HttpServletRequest requestContext;

    @Test
    public void testLogReturns400ForNullMessage() {
        Map<String, String> payload = new HashMap<>();
        payload.put("timestamp", "t1");

        GenericResponse response = controller.log(payload);

        assertEquals("400", response.getStatusCode());
        assertEquals("Null or empty log message", response.getStatusMessage());
    }

    @Test
    public void testLogReturns200ForValidMessage() {
        Map<String, String> payload = new HashMap<>();
        payload.put("log", "hello");
        payload.put("timestamp", "t1");

        GenericResponse response = controller.log(payload);

        assertEquals("200", response.getStatusCode());
        assertTrue(response.getStatusMessage().contains("Log message received: hello"));
    }

    @Test
    public void testGetEmailsSuccess() throws Exception {
        Map<String, String> req = new HashMap<>();
        req.put("corpMpin", "123");
        HttpHeaders headers = new HttpHeaders();
        ResponseEntity<User> expected = new ResponseEntity<>(new User(), HttpStatus.OK);

        when(digitalSecService.getEmailsByCorporate("123", headers)).thenReturn(expected);

        ResponseEntity<?> result = controller.getEmails(req, headers, requestContext);

        assertEquals(expected, result);
        verify(digitalSecService, times(1)).getEmailsByCorporate("123", headers);
    }

    @Test
    public void testGetEmailsReturnsNullOnHandledApplicationException() throws Exception {
        Map<String, String> req = new HashMap<>();
        req.put("corpMpin", "123");
        HttpHeaders headers = new HttpHeaders();

        when(digitalSecService.getEmailsByCorporate("123", headers)).thenThrow(new ApplicationException("not found"));

        ResponseEntity<?> result = controller.getEmails(req, headers, requestContext);

        assertNull(result);
    }

    @Test
    public void testGetCorporatesByPasswordOwnerSuccess() throws Exception {
        PasswordOwner providers = new PasswordOwner();
        providers.setOptumUUID("uuid-1");
        HttpHeaders headers = new HttpHeaders();
        headers.add("uuid", "actor-uuid");
        headers.add("username", "optum-user");

        when(requestContext.getRemoteAddr()).thenReturn("127.0.0.1");
        when(messageBuilder.build(eq("127.0.0.1"), eq("actor-uuid"), eq("optum-user"))).thenReturn(new LogMessage());

        Corporate corporate = new Corporate();
        corporate.setProvId("prov-1");
        corporate.setUhcID("uhc-1");
        corporate.setMpin("mpin-1");
        corporate.setCorporateName("corp-name");

        PDOCorporates expected = new PDOCorporates();
        expected.setCorporates(Collections.singletonList(corporate));

        when(digitalSecService.getCorporatesByPasswordOwner(eq("uuid-1"), eq(headers), any(LogMessage.class)))
                .thenReturn(expected);

        PDOCorporates result = controller.getCorporatesByPasswordOwner(providers, headers, requestContext);

        assertEquals(expected, result);
    }

    @Test
    public void testGetProvidersByCorporateSuccess() throws Exception {
        PasswordOwner providers = new PasswordOwner();
        providers.setOptumUUID("uuid-1");
        providers.setUhcID("uhc-1");
        providers.setMpin("mpin-1");
        HttpHeaders headers = new HttpHeaders();
        headers.add("uuid", "actor-uuid");
        headers.add("username", "optum-user");

        when(requestContext.getRemoteAddr()).thenReturn("127.0.0.1");
        when(messageBuilder.build(eq("127.0.0.1"), eq("actor-uuid"), eq("optum-user"))).thenReturn(new LogMessage());

        PDOProvTin prov = new PDOProvTin();
        prov.setTin("111223333");
        PDOTins expected = new PDOTins();
        expected.setProviders(Collections.singletonList(prov));

        when(digitalSecService.getProvidersByCorporate(eq("uuid-1"), eq("uhc-1"), eq("mpin-1"), eq(headers), any(LogMessage.class)))
                .thenReturn(expected);

        PDOTins result = controller.getProvidersByCorporate(providers, headers, requestContext);

        assertEquals(expected, result);
    }

    @Test
    public void testGetFileTypesByProviderMpinSuccess() throws Exception {
        PasswordOwner providers = new PasswordOwner();
        providers.setTin("111223333");
        providers.setMpin("mpin-1");
        HttpHeaders headers = new HttpHeaders();
        headers.add("uuid", "actor-uuid");
        headers.add("username", "optum-user");

        when(requestContext.getRemoteAddr()).thenReturn("127.0.0.1");
        when(messageBuilder.build(eq("127.0.0.1"), eq("actor-uuid"), eq("optum-user"))).thenReturn(new LogMessage());

        ProviderPreferencesObj expected = new ProviderPreferencesObj();
        expected.setCorporateTin("111223333");
        PreferenceType type = new PreferenceType();
        type.setClassifier("C1");
        expected.setPreferenceTypes(Collections.singletonList(type));

        when(providerPreferencesService.getProviderPreferencesFDSCloud(eq("111223333"), eq("mpin-1"), eq(headers), any(LogMessage.class)))
                .thenReturn(expected);

        ProviderPreferencesObj result = controller.getFileTypesByProviderMpin(providers, headers, requestContext);

        assertEquals(expected, result);
    }

    @Test
    public void testGetFileTypesByProviderMpinWrapsException() throws Exception {
        PasswordOwner providers = new PasswordOwner();
        providers.setTin("111223333");
        providers.setMpin("mpin-1");
        HttpHeaders headers = new HttpHeaders();
        headers.add("uuid", "actor-uuid");
        headers.add("username", "optum-user");

        when(requestContext.getRemoteAddr()).thenReturn("127.0.0.1");
        when(messageBuilder.build(eq("127.0.0.1"), eq("actor-uuid"), eq("optum-user"))).thenReturn(new LogMessage());

        when(providerPreferencesService.getProviderPreferencesFDSCloud(eq("111223333"), eq("mpin-1"), eq(headers), any(LogMessage.class)))
                .thenThrow(new RuntimeException("pref-fail"));

        try {
            controller.getFileTypesByProviderMpin(providers, headers, requestContext);
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Error at getFileTypesByProviderMpin"));
        }
    }

    @Test
    public void testUpdateFileTypesByProviderTinSuccess() throws Exception {
        ProviderPreferencesObj req = new ProviderPreferencesObj();
        req.setCorporateTin("111223333");
        req.setSelectedProviders(Collections.singletonList("mpin-1"));
        req.setPreferenceTypes(new ArrayList<>());
        HttpHeaders headers = new HttpHeaders();
        headers.add("uuid", "actor-uuid");
        headers.add("username", "optum-user");

        ResponseEntity<?> result = controller.updateFileTypesByProviderTin(req, headers, requestContext);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertNotNull(result.getBody());
        GenericResponse body = (GenericResponse) result.getBody();
        assertEquals("200", body.getStatusCode());
        assertEquals("Preferences updated", body.getStatusMessage());
        verify(providerPreferencesService, times(1)).updateProviderPreferencesFDSCloud(req, headers);
    }

    @Test
    public void testUpdateFileTypesByProviderTinHandlesException() throws Exception {
        ProviderPreferencesObj req = new ProviderPreferencesObj();
        req.setCorporateTin("111223333");
        req.setSelectedProviders(Collections.singletonList("mpin-1"));
        req.setPreferenceTypes(new ArrayList<>());
        HttpHeaders headers = new HttpHeaders();
        headers.add("uuid", "actor-uuid");
        headers.add("username", "optum-user");

        doThrow(new RuntimeException("update-fail")).when(providerPreferencesService).updateProviderPreferencesFDSCloud(req, headers);

        ResponseEntity<?> result = controller.updateFileTypesByProviderTin(req, headers, requestContext);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
        assertNotNull(result.getBody());
        GenericResponse body = (GenericResponse) result.getBody();
        assertEquals("500", body.getStatusCode());
    }

    @Test
    public void testGetProviderDataSuccess() throws Exception {
        RequestData request = new RequestData("111223333", "corp-1");
        HttpHeaders headers = new HttpHeaders();
        headers.add("uuid", "actor-uuid");
        headers.add("username", "optum-user");

        when(requestContext.getRemoteAddr()).thenReturn("127.0.0.1");
        when(messageBuilder.build(eq("127.0.0.1"), eq("actor-uuid"), eq("optum-user"))).thenReturn(new LogMessage());

        MpinData mpin = new MpinData();
        mpin.setProviderId("mpin-1");
        ResponseData responseData = new ResponseData();
        responseData.setMpinList(Collections.singletonList(mpin));
        CorpMpinResponse expected = new CorpMpinResponse();
        expected.setResponse(responseData);

        when(providerPreferencesService.getProviderData(eq(request), eq(headers), any(LogMessage.class))).thenReturn(expected);

        CorpMpinResponse result = controller.getProviderData(request, headers, requestContext);

        assertEquals(expected, result);
    }
}

