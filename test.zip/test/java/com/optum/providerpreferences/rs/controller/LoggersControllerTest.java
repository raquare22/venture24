package com.optum.providerpreferences.rs.controller;

import com.optum.providerpreferences.rs.model.GenericResponse;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class LoggersControllerTest {

    @Test
    public void testHealthCheckReturnsOkResponse() {
        LoggersController controller = new LoggersController();

        GenericResponse response = controller.healthCheck();

        assertNotNull(response);
        assertEquals("200", response.getStatusCode());
        assertEquals("OK", response.getStatusMessage());
    }
}
