package com.optum.providerpreferences.rs.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPutResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinResponse;
import com.optum.providerpreferences.rs.service.OptOutService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OptOutControllerTest {

    @InjectMocks
    private OptOutController controller;

    @Mock
    private OptOutService optOutService;

    @Mock
    private ObjectMapper mapper;

    @Test
    public void testGetTinsByCorpMpinSuccess() throws Exception {
        OptOutTinRequest req = new OptOutTinRequest();
        req.setCorporateMpin("123");
        OptOutTinResponse expected = new OptOutTinResponse(Arrays.asList("111", "222"));

        when(optOutService.getTins(req)).thenReturn(expected);

        OptOutTinResponse result = controller.getTinsByCorpMpin(req);

        assertEquals(expected, result);
        verify(optOutService, times(1)).getTins(req);
    }

    @Test
    public void testGetTinsByCorpMpinWrapsException() throws Exception {
        OptOutTinRequest req = new OptOutTinRequest();
        req.setCorporateMpin("123");

        when(optOutService.getTins(req)).thenThrow(new RuntimeException("boom"));

        try {
            controller.getTinsByCorpMpin(req);
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Error at getTinsByCorpMpin"));
        }
    }

    @Test
    public void testUpdateMultiDocumentsSuccess() throws Exception {
        OptOutRequest req = new OptOutRequest();
        req.setTin("123456789");
        HttpHeaders headers = new HttpHeaders();
        FDSMultiPutResponse expected = new FDSMultiPutResponse();

        when(optOutService.updateOptOutDocuments(req, headers)).thenReturn(expected);

        FDSMultiPutResponse result = controller.updateMultiDocuments(req, headers, null);

        assertEquals(expected, result);
        verify(optOutService, times(1)).updateOptOutDocuments(req, headers);
    }

    @Test
    public void testUpdateMultiDocumentsWrapsException() throws Exception {
        OptOutRequest req = new OptOutRequest();
        req.setTin("123456789");
        HttpHeaders headers = new HttpHeaders();

        when(optOutService.updateOptOutDocuments(req, headers)).thenThrow(new RuntimeException("update-fail"));

        try {
            controller.updateMultiDocuments(req, headers, null);
            fail("Expected ApplicationException");
        } catch (ApplicationException e) {
            assertTrue(e.getMessage().contains("Error at updateMultiDocuments"));
        }
    }

    @Test
    public void testGetFDSCloudDocumentReturnsServiceResult() throws Exception {
        FDSCloudRequest req = new FDSCloudRequest();
        req.getRequest().put("searchTerms", "abc");
        HttpHeaders headers = new HttpHeaders();

        FDSCloudGETResponse expected = new FDSCloudGETResponse();
        expected.setCount("1");
        when(optOutService.getOptOutAuditLog("FDSCloudGET", req)).thenReturn(expected);

        FDSCloudGETResponse result = controller.getFDSCloudDocument(req, headers, null);

        assertEquals("1", result.getCount());
        verify(optOutService, times(1)).getOptOutAuditLog("FDSCloudGET", req);
    }

    @Test
    public void testGetFDSCloudDocumentIdReturnsServiceResult() throws Exception {
        FDSCloudRequest req = new FDSCloudRequest();
        req.setDocumentId("doc-1");
        req.getRequest().put("k", "v");
        HttpHeaders headers = new HttpHeaders();

        OptOutFDSCloudDocument expected = new OptOutFDSCloudDocument();
        expected.setDocumentId("doc-1");

        when(optOutService.getFDSCloudDocument("FDSCloudGETDocumentId", req)).thenReturn(expected);

        OptOutFDSCloudDocument result = controller.getFDSCloudDocumentId(req, headers, null);

        assertEquals("doc-1", result.getDocumentId());
        verify(optOutService, times(1)).getFDSCloudDocument("FDSCloudGETDocumentId", req);
    }

    @Test
    public void testAddFDSCloudDocumentReturnsParsedMap() throws Exception {
        FDSCloudRequest req = new FDSCloudRequest();
        req.getRequest().put("tin", "123");
        HttpHeaders headers = new HttpHeaders();

        OptOutFDSCloudPOSTResponse body = new OptOutFDSCloudPOSTResponse();
        body.setSearchTerms(new ArrayList<>());
        body.setAttachments(new ArrayList<>());
        body.setDocumentId("doc-1");
        ResponseEntity<OptOutFDSCloudPOSTResponse> responseEntity = new ResponseEntity<>(body, HttpStatus.OK);
        when(optOutService.addOptOutAuditLog("FDSCloudPOST", req)).thenReturn(responseEntity);

        Map<String, Object> parsed = new LinkedHashMap<>();
        parsed.put("status", "ok");
        when(mapper.readValue(anyString(), eq(Map.class))).thenReturn(parsed);

        Map<String, Object> result = controller.addFDSCloudDocument(req, headers, null);

        assertEquals("ok", result.get("status"));
        verify(optOutService, times(1)).addOptOutAuditLog("FDSCloudPOST", req);
    }

    @Test
    public void testAddFDSCloudDocumentHandlesMapperIOException() throws Exception {
        FDSCloudRequest req = new FDSCloudRequest();
        req.setDocumentId("doc-x");
        req.getRequest().put("tin", "123");
        HttpHeaders headers = new HttpHeaders();

        // Use real mapper so invalid JSON naturally throws IOException from readValue.
        controller.mapper = new ObjectMapper();

        OptOutFDSCloudPOSTResponse body = new OptOutFDSCloudPOSTResponse() {
            @Override
            public String toString() {
                return "invalid-json";
            }
        };
        ResponseEntity<OptOutFDSCloudPOSTResponse> responseEntity = new ResponseEntity<>(body, HttpStatus.OK);
        when(optOutService.addOptOutAuditLog("FDSCloudPOST", req)).thenReturn(responseEntity);

        Map<String, Object> result = controller.addFDSCloudDocument(req, headers, null);

        assertTrue(result.containsKey("error"));
    }

    @Test
    public void testDeleteFDSCloudDocumentReturnsServiceResponseString() throws Exception {
        FDSCloudRequest req = new FDSCloudRequest();
        req.getRequest().put("tin", "123");
        HttpHeaders headers = new HttpHeaders();

        Map<String, Boolean> deleted = new HashMap<>();
        deleted.put("deleted", true);
        when(optOutService.FDSCloudDelete("testFDSCloudDELETE", req)).thenReturn(deleted);

        String result = controller.deleteFDSCloudDocument(req, headers, null);

        assertEquals(deleted.toString(), result);
        verify(optOutService, times(1)).FDSCloudDelete("testFDSCloudDELETE", req);
    }
}
