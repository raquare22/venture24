package com.optum.providerpreferences.rs.controller;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class RootControllerTest {

    @Test
    public void testHealthCheckReturnsExpectedMessage() {
        RootController controller = new RootController();

        String result = controller.healthCheck();

        assertNotNull(result);
        assertEquals("paperless-letters-connector-autoenrollment is up and running", result);
    }
}

