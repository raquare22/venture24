package com.optum.providerpreferences.rs.model.ndb.preferences;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class RequestDataTest {

    @Test
    public void shouldBuildWithDefaultConstructor() {
        RequestData data = new RequestData();

        assertEquals("", data.getSubmitterIdNumber());
        assertEquals("", data.getFunctionCode());
        assertEquals("", data.getProviderId());
        assertEquals("", data.getProviderTIN());
        assertEquals("", data.getProviderTINType());
        assertEquals("", data.getTinPrefix());
        assertEquals("0", data.getTinSuffix());
        assertEquals("", data.getUhcid());
        assertEquals("", data.getDiv());
    }

    @Test
    public void shouldBuildWithFiveArgConstructor() {
        RequestData data = new RequestData("provider1", "123456789", "FUNC1", "ELEC", "E2");

        assertEquals("PDO", data.getSubmitterIdNumber());
        assertEquals("provider1", data.getProviderId());
        assertEquals("123456789", data.getProviderTIN());
        assertEquals("FUNC1", data.getFunctionCode());
        assertEquals("ELEC", data.getMailPref());
        assertEquals("T", data.getProviderTINType());
        assertEquals("0", data.getUhcid());
        assertEquals(1, data.getLetterTypeList().size());
        assertEquals("E2", data.getLetterTypeList().get(0).getLetterType());
    }

    @Test
    public void shouldBuildWithThreeArgConstructor() {
        RequestData data = new RequestData("provider2", "987654321", "FUNC2");

        assertEquals("PDO", data.getSubmitterIdNumber());
        assertEquals("provider2", data.getProviderId());
        assertEquals("987654321", data.getProviderTIN());
        assertEquals("FUNC2", data.getFunctionCode());
    }

    @Test
    public void shouldBuildWithTenArgConstructor() {
        List<LetterType> letterTypes = new ArrayList<>();
        letterTypes.add(new LetterType("E3"));

        RequestData data = new RequestData("FUNC3", "provider3", "111222333", "T", "PRE", "SUF", "uhc1", "div1", letterTypes, "MAIL");

        assertEquals("PDO", data.getSubmitterIdNumber());
        assertEquals("FUNC3", data.getFunctionCode());
        assertEquals("provider3", data.getProviderId());
        assertEquals("111222333", data.getProviderTIN());
        assertEquals("T", data.getProviderTINType());
        assertEquals("PRE", data.getTinPrefix());
        assertEquals("SUF", data.getTinSuffix());
        assertEquals("uhc1", data.getUhcid());
        assertEquals("div1", data.getDiv());
        assertSame(letterTypes, data.getLetterTypeList());
        assertEquals("MAIL", data.getMailPref());
    }

    @Test
    public void shouldLazilyInitializeLetterTypeListWhenNull() {
        RequestData data = new RequestData();

        List<LetterType> result = data.getLetterTypeList();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        RequestData data = new RequestData();

        data.setSubmitterIdNumber("SUBMIT1");
        data.setFunctionCode("FUNC");
        data.setProviderId("prov");
        data.setProviderTIN("tin");
        data.setProviderTINType("tintype");
        data.setTinPrefix("prefix");
        data.setTinSuffix("suffix");
        data.setUhcid("uhcid");
        data.setDiv("div");
        data.setMailPref("pref");

        List<LetterType> letterTypes = new ArrayList<>();
        letterTypes.add(new LetterType("E4"));
        data.setLetterTypeList(letterTypes);

        assertEquals("SUBMIT1", data.getSubmitterIdNumber());
        assertEquals("FUNC", data.getFunctionCode());
        assertEquals("prov", data.getProviderId());
        assertEquals("tin", data.getProviderTIN());
        assertEquals("tintype", data.getProviderTINType());
        assertEquals("prefix", data.getTinPrefix());
        assertEquals("suffix", data.getTinSuffix());
        assertEquals("uhcid", data.getUhcid());
        assertEquals("div", data.getDiv());
        assertEquals("pref", data.getMailPref());
        assertSame(letterTypes, data.getLetterTypeList());
    }
}

