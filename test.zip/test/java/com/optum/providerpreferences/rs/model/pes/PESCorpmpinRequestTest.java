package com.optum.providerpreferences.rs.model.pes;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class PESCorpmpinRequestTest {

    @Test
    public void constructorShouldPopulateDefaults() {
        PESCorpmpinRequest request = new PESCorpmpinRequest("123456789");

        assertEquals("123456789", request.getTaxIdNumber());
        assertEquals("PDO", request.getAppName());
        assertEquals("summary_0002", request.getAttributeSet());
        assertEquals("1", request.getCount());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        PESCorpmpinRequest request = new PESCorpmpinRequest("123456789");

        request.setTaxIdNumber("987654321");
        request.setAppName("APP");
        request.setAttributeSet("set");
        request.setCount("5");

        assertEquals("987654321", request.getTaxIdNumber());
        assertEquals("APP", request.getAppName());
        assertEquals("set", request.getAttributeSet());
        assertEquals("5", request.getCount());
    }

    @Test
    public void toStringShouldContainKeyValues() {
        PESCorpmpinRequest request = new PESCorpmpinRequest("123456789");

        String value = request.toString();

        assertTrue(value.contains("taxIdNumber: 123456789"));
        assertTrue(value.contains("appName: PDO"));
    }
}

