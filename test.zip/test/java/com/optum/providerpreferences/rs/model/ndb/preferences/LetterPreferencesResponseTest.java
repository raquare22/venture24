package com.optum.providerpreferences.rs.model.ndb.preferences;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class LetterPreferencesResponseTest {

    @Test
    public void shouldBuildWithDefaultConstructor() {
        LetterPreferencesResponse response = new LetterPreferencesResponse();

        assertNull(response.getResponseHeader());
        assertNull(response.getRequestHeader());
        assertNull(response.getRequest());
        assertNull(response.getRequestResponse());
    }

    @Test
    public void shouldBuildWithFullConstructor() {
        ResponseHeader resHeader = new ResponseHeader("200", "ok");
        RequestHeader reqHeader = new RequestHeader("prog1", "user1", "ccc1", "000");
        RequestData reqData = new RequestData();
        reqData.setProviderId("provider1");
        ResponseData resData = new ResponseData("provider1", "123456789", "T", null);

        LetterPreferencesResponse response = new LetterPreferencesResponse(resHeader, reqHeader, reqData, resData);

        assertSame(resHeader, response.getResponseHeader());
        assertSame(reqHeader, response.getRequestHeader());
        assertSame(reqData, response.getRequest());
        assertSame(resData, response.getRequestResponse());
    }

    @Test
    public void shouldSetAndGetResponseHeader() {
        LetterPreferencesResponse response = new LetterPreferencesResponse();
        ResponseHeader header = new ResponseHeader("201", "created");

        response.setResponseHeader(header);

        assertSame(header, response.getResponseHeader());
        assertEquals("201", response.getResponseHeader().getReturncode());
    }

    @Test
    public void shouldSetAndGetRequestHeader() {
        LetterPreferencesResponse response = new LetterPreferencesResponse();
        RequestHeader header = new RequestHeader("prog2", "user2", "ccc2", "001");

        response.setRequestHeader(header);

        assertSame(header, response.getRequestHeader());
        assertEquals("prog2", response.getRequestHeader().getcallingprogram());
    }

    @Test
    public void shouldSetAndGetRequest() {
        LetterPreferencesResponse response = new LetterPreferencesResponse();
        RequestData data = new RequestData();
        data.setProviderId("provider2");

        response.setRequest(data);

        assertSame(data, response.getRequest());
        assertEquals("provider2", response.getRequest().getProviderId());
    }

    @Test
    public void shouldSetAndGetRequestResponse() {
        LetterPreferencesResponse response = new LetterPreferencesResponse();
        ResponseData data = new ResponseData("provider3", "987654321", "T", null);

        response.setRequestResponse(data);

        assertSame(data, response.getRequestResponse());
        assertEquals("provider3", response.getRequestResponse().getProviderId());
    }

    @Test
    public void toStringShouldReturnJsonFormat() {
        ResponseHeader resHeader = new ResponseHeader("200", "ok");
        RequestHeader reqHeader = new RequestHeader("prog", "user", "ccc", "000");
        RequestData reqData = new RequestData();
        ResponseData resData = new ResponseData();

        LetterPreferencesResponse response = new LetterPreferencesResponse(resHeader, reqHeader, reqData, resData);

        String value = response.toString();

        assertNotNull(value);
        // Should contain JSON format (curly braces)
        assertTrue(value.contains("{") || value.contains("responseHeader"));
    }
}

