package com.optum.providerpreferences.rs.model.ndb.preferences;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class RequestHeaderTest {

    @Test
    public void shouldBuildWithDefaultConstructor() {
        RequestHeader header = new RequestHeader();

        assertNull(header.getcallingprogram());
        assertNull(header.getUserid());
        assertNull(header.getUserofccd());
        assertNull(header.getSqlCode());
    }

    @Test
    public void shouldBuildWithFourArgConstructor() {
        RequestHeader header = new RequestHeader("prog1", "user1", "ccc1", "000");

        assertEquals("prog1", header.getcallingprogram());
        assertEquals("user1", header.getUserid());
        assertEquals("ccc1", header.getUserofccd());
        assertEquals("000", header.getSqlCode());
    }

    @Test
    public void shouldSetAndGetCallingprogram() {
        RequestHeader header = new RequestHeader();

        header.setcallingprogram("prog2");

        assertEquals("prog2", header.getcallingprogram());
    }

    @Test
    public void shouldSetAndGetUserid() {
        RequestHeader header = new RequestHeader();

        header.setUserid("user2");

        assertEquals("user2", header.getUserid());
    }

    @Test
    public void shouldSetAndGetUserofccd() {
        RequestHeader header = new RequestHeader();

        header.setUserofccd("ccc2");

        assertEquals("ccc2", header.getUserofccd());
    }

    @Test
    public void shouldSetAndGetSqlCode() {
        RequestHeader header = new RequestHeader();

        header.setSqlCode("001");

        assertEquals("001", header.getSqlCode());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        RequestHeader header = new RequestHeader();

        header.setcallingprogram("prog3");
        header.setUserid("user3");
        header.setUserofccd("ccc3");
        header.setSqlCode("002");

        assertEquals("prog3", header.getcallingprogram());
        assertEquals("user3", header.getUserid());
        assertEquals("ccc3", header.getUserofccd());
        assertEquals("002", header.getSqlCode());
    }
}

