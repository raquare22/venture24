package com.optum.providerpreferences.rs.model.ndb.provider;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class CorpMpinRequestTest {

    @Test
    public void shouldSetAndGetRequestHeader() {
        CorpMpinRequest request = new CorpMpinRequest();
        RequestHeader header = new RequestHeader();
        header.setApplicationId("app1");
        header.setUserId("user1");

        request.setRequestHeader(header);

        assertSame(header, request.getRequestHeader());
        assertNotNull(request.getRequestHeader());
    }

    @Test
    public void shouldSetAndGetRequestData() {
        CorpMpinRequest request = new CorpMpinRequest();
        RequestData data = new RequestData();
        data.setTaxIdNumber("123456789");

        request.setRequestData(data);

        assertSame(data, request.getRequestData());
        assertNotNull(request.getRequestData());
    }

    @Test
    public void shouldHaveNullHeaderAndDataByDefault() {
        CorpMpinRequest request = new CorpMpinRequest();

        assertNull(request.getRequestHeader());
        assertNull(request.getRequestData());
    }

    @Test
    public void shouldSetAndGetBothHeaderAndData() {
        CorpMpinRequest request = new CorpMpinRequest();
        RequestHeader header = new RequestHeader();
        header.setApplicationId("app2");
        RequestData data = new RequestData();
        data.setTaxIdNumber("987654321");

        request.setRequestHeader(header);
        request.setRequestData(data);

        assertSame(header, request.getRequestHeader());
        assertSame(data, request.getRequestData());
    }
}

