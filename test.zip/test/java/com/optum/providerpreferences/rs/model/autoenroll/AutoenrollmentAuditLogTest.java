package com.optum.providerpreferences.rs.model.autoenroll;

import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class AutoenrollmentAuditLogTest {

    @Test
    public void shouldLazilyInitializeListsWhenNull() {
        AutoenrollmentAuditLog auditLog = new AutoenrollmentAuditLog();

        List<Document> autoenrollDocuments = auditLog.getAutoenrollDocuments();
        List<String> inserted = auditLog.getInserted();
        List<FDSCloudRequest> errors = auditLog.getErrors();

        assertNotNull(autoenrollDocuments);
        assertNotNull(inserted);
        assertNotNull(errors);
        assertTrue(autoenrollDocuments.isEmpty());
        assertTrue(inserted.isEmpty());
        assertTrue(errors.isEmpty());

        // Verify lazy-init collections are retained between repeated getter calls.
        assertSame(autoenrollDocuments, auditLog.getAutoenrollDocuments());
        assertSame(inserted, auditLog.getInserted());
        assertSame(errors, auditLog.getErrors());
    }

    @Test
    public void shouldReturnValuesSetBySetters() {
        AutoenrollmentAuditLog auditLog = new AutoenrollmentAuditLog();

        List<Document> autoenrollDocuments = new ArrayList<>();
        Document document = new Document();
        document.setId("doc-1");
        autoenrollDocuments.add(document);

        List<String> inserted = new ArrayList<>();
        inserted.add("doc-1");

        List<FDSCloudRequest> errors = new ArrayList<>();
        FDSCloudRequest errorRequest = new FDSCloudRequest();
        errorRequest.setDocumentId("error-doc");
        errors.add(errorRequest);

        auditLog.setRecordType("AUTOENROLL");
        auditLog.setAutoenrollDocuments(autoenrollDocuments);
        auditLog.setCountToInsert(1L);
        auditLog.setInserted(inserted);
        auditLog.setErrors(errors);
        auditLog.setStatus("COMPLETE");

        assertEquals("AUTOENROLL", auditLog.getRecordType());
        assertSame(autoenrollDocuments, auditLog.getAutoenrollDocuments());
        assertEquals(1L, auditLog.getCountToInsert());
        assertSame(inserted, auditLog.getInserted());
        assertSame(errors, auditLog.getErrors());
        assertEquals("COMPLETE", auditLog.getStatus());
    }

    @Test
    public void toStringShouldContainKeyFields() {
        AutoenrollmentAuditLog auditLog = new AutoenrollmentAuditLog();
        auditLog.setRecordType("AE");
        auditLog.setCountToInsert(3L);
        auditLog.setStatus("SUCCESS");

        String result = auditLog.toString();

        assertTrue(result.contains("recordType=AE"));
        assertTrue(result.contains("countToInsert=3"));
        assertTrue(result.contains("status=SUCCESS"));
    }
}

