package com.optum.providerpreferences.rs.model.optout;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class OptOutFDSCloudPOSTRequestTest {

    @Test
    public void shouldSetAndGetSpaceId() {
        OptOutFDSCloudPOSTRequest request = new OptOutFDSCloudPOSTRequest();

        request.setSpace_id("space-123");

        assertEquals("space-123", request.getSpace_id());
    }

    @Test
    public void shouldSetAndGetMetadata() {
        OptOutFDSCloudPOSTRequest request = new OptOutFDSCloudPOSTRequest();
        OptOutAuditMetadata metadata = new OptOutAuditMetadata();
        metadata.setRecordType("OPTOUT");

        request.setMetadata(metadata);

        assertSame(metadata, request.getMetadata());
        assertEquals("OPTOUT", request.getMetadata().getRecordType());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        OptOutFDSCloudPOSTRequest request = new OptOutFDSCloudPOSTRequest();
        OptOutAuditMetadata metadata = new OptOutAuditMetadata();
        metadata.setRecordType("POST");

        request.setSpace_id("space-999");
        request.setMetadata(metadata);

        assertEquals("space-999", request.getSpace_id());
        assertSame(metadata, request.getMetadata());
    }

    @Test
    public void fieldsShouldDefaultToNull() {
        OptOutFDSCloudPOSTRequest request = new OptOutFDSCloudPOSTRequest();

        assertNull(request.getSpace_id());
        assertNull(request.getMetadata());
    }

    @Test
    public void shouldHandleNullValues() {
        OptOutFDSCloudPOSTRequest request = new OptOutFDSCloudPOSTRequest();
        request.setSpace_id("space-temp");
        request.setMetadata(new OptOutAuditMetadata());

        request.setSpace_id(null);
        request.setMetadata(null);

        assertNull(request.getSpace_id());
        assertNull(request.getMetadata());
    }
}

