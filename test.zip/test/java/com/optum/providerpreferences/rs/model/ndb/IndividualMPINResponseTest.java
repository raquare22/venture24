package com.optum.providerpreferences.rs.model.ndb;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class IndividualMPINResponseTest {

    @Test
    public void constructorShouldSetStatusCodeAndStatusMessage() {
        IndividualMPINResponse response = new IndividualMPINResponse("200", "Success");

        assertEquals("200", response.getStatusCode());
        assertEquals("Success", response.getStatusMessage());
    }

    @Test
    public void shouldAllowUpdatingInheritedFields() {
        IndividualMPINResponse response = new IndividualMPINResponse("200", "Success");

        response.setStatusCode("500");
        response.setStatusMessage("Failure");

        assertEquals("500", response.getStatusCode());
        assertEquals("Failure", response.getStatusMessage());
    }

    @Test
    public void shouldAllowNullValuesViaConstructor() {
        IndividualMPINResponse response = new IndividualMPINResponse(null, null);

        assertNull(response.getStatusCode());
        assertNull(response.getStatusMessage());
    }
}

