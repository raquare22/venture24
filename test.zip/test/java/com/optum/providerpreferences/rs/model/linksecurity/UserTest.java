package com.optum.providerpreferences.rs.model.linksecurity;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class UserTest {

    @Test
    public void shouldSetAndGetAllFieldsUsingDefaultConstructor() {
        User user = new User();

        user.setUserAcctSeqNbr("acct-1");
        user.setB2cUserId("b2c-1");
        user.setAccessProfile("ADMIN");
        user.setStatusCode("A");
        user.setStatusDesc("Active");
        user.setAccountType("IND");
        user.setAccountDesc("Individual");
        user.setDept("IT");
        user.setOrgType("ORG");
        user.setTitle("Manager");
        user.setState("MN");
        user.setZipCode("55344");
        user.setRoleId("ROLE1");
        user.setRoleDesc("Role Desc");
        user.setRespOrgMpin("123456789");
        user.setHasAccessProfiles(true);

        assertEquals("acct-1", user.getUserAcctSeqNbr());
        assertEquals("b2c-1", user.getB2cUserId());
        assertEquals("ADMIN", user.getAccessProfile());
        assertEquals("A", user.getStatusCode());
        assertEquals("Active", user.getStatusDesc());
        assertEquals("IND", user.getAccountType());
        assertEquals("Individual", user.getAccountDesc());
        assertEquals("IT", user.getDept());
        assertEquals("ORG", user.getOrgType());
        assertEquals("Manager", user.getTitle());
        assertEquals("MN", user.getState());
        assertEquals("55344", user.getZipCode());
        assertEquals("ROLE1", user.getRoleId());
        assertEquals("Role Desc", user.getRoleDesc());
        assertEquals("123456789", user.getRespOrgMpin());
        assertTrue(user.isHasAccessProfiles());
    }

    @Test
    public void shouldBuildFromFullConstructorWhenHasAccessProfilesTrue() {
        User user = new User(
                "acct-2", "b2c-2", "STANDARD", "A", "Active", "CORP", "Corporate",
                "Ops", "ORG", "Director", "CA", "90210", "ROLE2", "Role Two", "987654321", "true");

        assertEquals("acct-2", user.getUserAcctSeqNbr());
        assertEquals("b2c-2", user.getB2cUserId());
        assertEquals("STANDARD", user.getAccessProfile());
        assertEquals("A", user.getStatusCode());
        assertEquals("Active", user.getStatusDesc());
        assertEquals("CORP", user.getAccountType());
        assertEquals("Corporate", user.getAccountDesc());
        assertEquals("Ops", user.getDept());
        assertEquals("ORG", user.getOrgType());
        assertEquals("Director", user.getTitle());
        assertEquals("CA", user.getState());
        assertEquals("90210", user.getZipCode());
        assertEquals("ROLE2", user.getRoleId());
        assertEquals("Role Two", user.getRoleDesc());
        assertEquals("987654321", user.getRespOrgMpin());
        assertTrue(user.isHasAccessProfiles());
    }

    @Test
    public void setHasAccessProfilesStringShouldHandleFalseAndNull() {
        User user = new User();

        user.setHasAccessProfiles("false");
        assertFalse(user.isHasAccessProfiles());

        user.setHasAccessProfiles(null);
        assertFalse(user.isHasAccessProfiles());
    }

    @Test
    public void setHasAccessProfilesStringShouldBeCaseInsensitive() {
        User user = new User();

        user.setHasAccessProfiles("TrUe");

        assertTrue(user.isHasAccessProfiles());
    }
}

