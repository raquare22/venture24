package com.optum.providerpreferences.rs.model.fds;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class MetadataTest {

    @Test
    public void shouldSetAndGetAllFields() {
        Metadata metadata = new Metadata();

        metadata.setTin("123456789");
        metadata.setMpin("987654321");
        metadata.setProviderName("Provider Name");
        metadata.setFileName("E2");
        metadata.setFileType("LETTER");
        metadata.setProviderEmailId("provider@example.com");
        metadata.setFrequency("MONTHLY");
        metadata.setDeliveryMethod("E");
        metadata.setOkToChangePDOInd("Y");
        metadata.setAutoEdelUpdateInd("N");
        metadata.setActiveDate("2026-05-22");
        metadata.setLastUpdatedBy("SYSTEM");
        metadata.setLastUpdatedById("user-123");
        metadata.setAutoOptOutInd("N");
        metadata.setOptedOutDuration(30);
        metadata.setOptedOutDateTime("2026-05-22T12:00:00Z");
        metadata.setExpiryDate("2026-12-31");
        metadata.setExpiryDateEpoch(1798675200L);
        metadata.setSubscribeToEmail("Y");

        assertEquals("123456789", metadata.getTin());
        assertEquals("987654321", metadata.getMpin());
        assertEquals("Provider Name", metadata.getProviderName());
        assertEquals("E2", metadata.getFileName());
        assertEquals("LETTER", metadata.getFileType());
        assertEquals("provider@example.com", metadata.getProviderEmailId());
        assertEquals("MONTHLY", metadata.getFrequency());
        assertEquals("E", metadata.getDeliveryMethod());
        assertEquals("Y", metadata.getOkToChangePDOInd());
        assertEquals("N", metadata.getAutoEdelUpdateInd());
        assertEquals("2026-05-22", metadata.getActiveDate());
        assertEquals("SYSTEM", metadata.getLastUpdatedBy());
        assertEquals("user-123", metadata.getLastUpdatedById());
        assertEquals("N", metadata.getAutoOptOutInd());
        assertEquals(Integer.valueOf(30), metadata.getOptedOutDuration());
        assertEquals("2026-05-22T12:00:00Z", metadata.getOptedOutDateTime());
        assertEquals("2026-12-31", metadata.getExpiryDate());
        assertEquals(Long.valueOf(1798675200L), metadata.getExpiryDateEpoch());
        assertEquals("Y", metadata.getSubscribeToEmail());
    }

    @Test
    public void toStringShouldContainKeyValues() {
        Metadata metadata = new Metadata();
        metadata.setTin("123456789");
        metadata.setMpin("987654321");
        metadata.setProviderName("Provider Name");
        metadata.setFileName("E2");
        metadata.setDeliveryMethod("E");
        metadata.setExpiryDate("2026-12-31");

        String value = metadata.toString();

        assertTrue(value.contains("tin=123456789"));
        assertTrue(value.contains("mpin=987654321"));
        assertTrue(value.contains("providerName=Provider Name"));
        assertTrue(value.contains("fileName=E2"));
        assertTrue(value.contains("deliveryMethod=E"));
        assertTrue(value.contains("expiryDate=2026-12-31"));
    }
}

