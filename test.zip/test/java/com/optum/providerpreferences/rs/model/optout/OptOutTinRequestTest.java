package com.optum.providerpreferences.rs.model.optout;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class OptOutTinRequestTest {

    @Test
    public void corporateMpinShouldDefaultToNull() {
        OptOutTinRequest request = new OptOutTinRequest();

        assertNull(request.getCorporateMpin());
    }

    @Test
    public void shouldSetAndGetCorporateMpin() {
        OptOutTinRequest request = new OptOutTinRequest();

        request.setCorporateMpin("123456789");

        assertEquals("123456789", request.getCorporateMpin());
    }

    @Test
    public void shouldHandleNullCorporateMpin() {
        OptOutTinRequest request = new OptOutTinRequest();
        request.setCorporateMpin("999999999");

        request.setCorporateMpin(null);

        assertNull(request.getCorporateMpin());
    }
}

