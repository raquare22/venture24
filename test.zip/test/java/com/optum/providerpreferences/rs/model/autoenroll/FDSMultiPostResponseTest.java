package com.optum.providerpreferences.rs.model.autoenroll;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

public class FDSMultiPostResponseTest {

    @Test
    public void shouldSetAndGetInsertedList() {
        FDSMultiPostResponse response = new FDSMultiPostResponse();
        List<String> inserted = Arrays.asList("doc-1", "doc-2");

        response.setInserted(inserted);

        assertSame(inserted, response.getInserted());
        assertEquals(2, response.getInserted().size());
        assertEquals("doc-1", response.getInserted().get(0));
        assertEquals("doc-2", response.getInserted().get(1));
    }

    @Test
    public void toStringShouldContainInsertedValues() {
        FDSMultiPostResponse response = new FDSMultiPostResponse();
        response.setInserted(Arrays.asList("doc-1", "doc-2"));

        String value = response.toString();

        assertEquals("inserted: [doc-1, doc-2]", value);
    }
}

