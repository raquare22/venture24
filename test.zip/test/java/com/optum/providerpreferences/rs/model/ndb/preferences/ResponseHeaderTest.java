package com.optum.providerpreferences.rs.model.ndb.preferences;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class ResponseHeaderTest {

    @Test
    public void shouldBuildWithDefaultConstructor() {
        ResponseHeader header = new ResponseHeader();

        assertNull(header.getReturncode());
        assertNull(header.getMessage());
    }

    @Test
    public void shouldBuildWithTwoArgConstructor() {
        ResponseHeader header = new ResponseHeader("200", "Success");

        assertEquals("200", header.getReturncode());
        assertEquals("Success", header.getMessage());
    }

    @Test
    public void shouldSetAndGetReturncode() {
        ResponseHeader header = new ResponseHeader();

        header.setReturncode("201");

        assertEquals("201", header.getReturncode());
    }

    @Test
    public void shouldSetAndGetMessage() {
        ResponseHeader header = new ResponseHeader();

        header.setMessage("Created");

        assertEquals("Created", header.getMessage());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        ResponseHeader header = new ResponseHeader();

        header.setReturncode("400");
        header.setMessage("Bad Request");

        assertEquals("400", header.getReturncode());
        assertEquals("Bad Request", header.getMessage());
    }

    @Test
    public void shouldHandleNullValues() {
        ResponseHeader header = new ResponseHeader("500", "Server Error");

        header.setReturncode(null);
        header.setMessage(null);

        assertNull(header.getReturncode());
        assertNull(header.getMessage());
    }
}

