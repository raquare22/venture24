package com.optum.providerpreferences.rs.model.optout;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class OptOutAuditUpdateTest {

    @Test
    public void shouldSetAndGetAllFields() {
        OptOutAuditUpdate update = new OptOutAuditUpdate();

        update.setDeliveryMethod("E");
        update.setOkToChangePDOInd("Y");
        update.setAutoEdelUpdateInd("N");
        update.setLastUpdatedBy("SYSTEM");
        update.setLastUpdatedById("user-123");
        update.setAutoOptOutInd("Y");
        update.setOptedOutDuration(30);
        update.setOptedOutDateTime("2026-05-22T12:00:00Z");
        update.setExpiryDate("2026-12-31");
        update.setExpiryDateEpoch(1798675200L);

        assertEquals("E", update.getDeliveryMethod());
        assertEquals("Y", update.getOkToChangePDOInd());
        assertEquals("N", update.getAutoEdelUpdateInd());
        assertEquals("SYSTEM", update.getLastUpdatedBy());
        assertEquals("user-123", update.getLastUpdatedById());
        assertEquals("Y", update.getAutoOptOutInd());
        assertEquals(Integer.valueOf(30), update.getOptedOutDuration());
        assertEquals("2026-05-22T12:00:00Z", update.getOptedOutDateTime());
        assertEquals("2026-12-31", update.getExpiryDate());
        assertEquals(Long.valueOf(1798675200L), update.getExpiryDateEpoch());
    }

    @Test
    public void fieldsShouldDefaultToNull() {
        OptOutAuditUpdate update = new OptOutAuditUpdate();

        assertNull(update.getDeliveryMethod());
        assertNull(update.getOkToChangePDOInd());
        assertNull(update.getAutoEdelUpdateInd());
        assertNull(update.getLastUpdatedBy());
        assertNull(update.getLastUpdatedById());
        assertNull(update.getAutoOptOutInd());
        assertNull(update.getOptedOutDuration());
        assertNull(update.getOptedOutDateTime());
        assertNull(update.getExpiryDate());
        assertNull(update.getExpiryDateEpoch());
    }

    @Test
    public void shouldHandleNullValues() {
        OptOutAuditUpdate update = new OptOutAuditUpdate();
        update.setDeliveryMethod("E");
        update.setOkToChangePDOInd("Y");
        update.setAutoEdelUpdateInd("N");
        update.setLastUpdatedBy("SYSTEM");
        update.setLastUpdatedById("id");
        update.setAutoOptOutInd("Y");
        update.setOptedOutDuration(1);
        update.setOptedOutDateTime("time");
        update.setExpiryDate("date");
        update.setExpiryDateEpoch(1L);

        update.setDeliveryMethod(null);
        update.setOkToChangePDOInd(null);
        update.setAutoEdelUpdateInd(null);
        update.setLastUpdatedBy(null);
        update.setLastUpdatedById(null);
        update.setAutoOptOutInd(null);
        update.setOptedOutDuration(null);
        update.setOptedOutDateTime(null);
        update.setExpiryDate(null);
        update.setExpiryDateEpoch(null);

        assertNull(update.getDeliveryMethod());
        assertNull(update.getOkToChangePDOInd());
        assertNull(update.getAutoEdelUpdateInd());
        assertNull(update.getLastUpdatedBy());
        assertNull(update.getLastUpdatedById());
        assertNull(update.getAutoOptOutInd());
        assertNull(update.getOptedOutDuration());
        assertNull(update.getOptedOutDateTime());
        assertNull(update.getExpiryDate());
        assertNull(update.getExpiryDateEpoch());
    }

    @Test
    public void toStringShouldContainKeyValues() {
        OptOutAuditUpdate update = new OptOutAuditUpdate();
        update.setDeliveryMethod("E");
        update.setOkToChangePDOInd("Y");
        update.setAutoEdelUpdateInd("N");
        update.setLastUpdatedBy("SYSTEM");
        update.setOptedOutDuration(15);
        update.setExpiryDate("2026-12-31");

        String value = update.toString();

        assertTrue(value.contains("deliveryMethod=E"));
        assertTrue(value.contains("okToChangePDOInd=Y"));
        assertTrue(value.contains("autoEdelUpdateInd=N"));
        assertTrue(value.contains("lastUpdatedBy=SYSTEM"));
        assertTrue(value.contains("optedOutDuration=15"));
        assertTrue(value.contains("expiryDate=2026-12-31"));
    }
}

