package com.optum.providerpreferences.rs.model;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class NDBTokenTest {

    @Test
    public void shouldSetAndGetAllFields() {
        NDBToken token = new NDBToken();

        token.setAccessToken("access-123");
        token.setTokenType("Bearer");
        token.setExpiresIn("3600");
        token.setScope("read write");

        assertEquals("access-123", token.getAccessToken());
        assertEquals("Bearer", token.getTokenType());
        assertEquals("3600", token.getExpiresIn());
        assertEquals("read write", token.getScope());
    }

    @Test
    public void shouldSupportAccessTokenThroughAbstractType() {
        TokenAbst token = new NDBToken();

        token.setAccessToken("abstract-access");

        assertEquals("abstract-access", token.getAccessToken());
    }

    @Test
    public void fieldsShouldDefaultToNull() {
        NDBToken token = new NDBToken();

        assertNull(token.getAccessToken());
        assertNull(token.getTokenType());
        assertNull(token.getExpiresIn());
        assertNull(token.getScope());
    }

    @Test
    public void toStringShouldContainAllFieldValues() {
        NDBToken token = new NDBToken();
        token.setAccessToken("a1");
        token.setTokenType("Bearer");
        token.setExpiresIn("1800");
        token.setScope("scope-a");

        String value = token.toString();

        assertTrue(value.contains("access_token=a1"));
        assertTrue(value.contains("token_type=Bearer"));
        assertTrue(value.contains("expires_in=1800"));
        assertTrue(value.contains("scope=scope-a"));
    }

    @Test
    public void shouldDeserializeJsonProperties() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        String json = "{" +
                "\"access_token\":\"access-json\"," +
                "\"token_type\":\"Bearer\"," +
                "\"expires_in\":\"7200\"," +
                "\"scope\":\"scope-json\"" +
                "}";

        NDBToken token = mapper.readValue(json, NDBToken.class);

        assertNotNull(token);
        assertEquals("access-json", token.getAccessToken());
        assertEquals("Bearer", token.getTokenType());
        assertEquals("7200", token.getExpiresIn());
        assertEquals("scope-json", token.getScope());
    }

    @Test
    public void shouldSerializeUsingAnnotatedJsonPropertyNames() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        NDBToken token = new NDBToken();
        token.setAccessToken("serialized-access");
        token.setTokenType("Bearer");
        token.setExpiresIn("900");
        token.setScope("serialized-scope");

        String json = mapper.writeValueAsString(token);

        assertTrue(json.contains("\"access_token\":\"serialized-access\""));
        assertTrue(json.contains("\"token_type\":\"Bearer\""));
        assertTrue(json.contains("\"expires_in\":\"900\""));
        assertTrue(json.contains("\"scope\":\"serialized-scope\""));
    }
}

