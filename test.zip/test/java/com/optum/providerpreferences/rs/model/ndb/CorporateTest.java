package com.optum.providerpreferences.rs.model.ndb;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class CorporateTest {

    @Test
    public void shouldSetAndGetName() {
        Corporate corporate = new Corporate();

        corporate.setName("Acme Corp");

        assertEquals("Acme Corp", corporate.getName());
    }

    @Test
    public void shouldSetAndGetAllTins() {
        Corporate corporate = new Corporate();

        corporate.setAllTins("123456789,987654321");

        assertEquals("123456789,987654321", corporate.getAllTins());
    }

    @Test
    public void shouldSetAndGetMpin() {
        Corporate corporate = new Corporate();

        corporate.setMpin("MPIN123");

        assertEquals("MPIN123", corporate.getMpin());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        Corporate corporate = new Corporate();

        corporate.setName("Test Corp");
        corporate.setAllTins("111222333,444555666");
        corporate.setMpin("MPIN456");

        assertEquals("Test Corp", corporate.getName());
        assertEquals("111222333,444555666", corporate.getAllTins());
        assertEquals("MPIN456", corporate.getMpin());
    }

    @Test
    public void fieldsDefaultToNull() {
        Corporate corporate = new Corporate();

        assertNull(corporate.getName());
        assertNull(corporate.getAllTins());
        assertNull(corporate.getMpin());
    }

    @Test
    public void toStringShouldContainNameAndMpin() {
        Corporate corporate = new Corporate();
        corporate.setName("Another Corp");
        corporate.setAllTins("999888777");
        corporate.setMpin("MPIN789");

        String value = corporate.toString();

        assertTrue(value.contains("name=Another Corp"));
        assertTrue(value.contains("mpin=MPIN789"));
        assertTrue(value.contains("Corporate"));
    }

    @Test
    public void toStringShouldHandleNullValues() {
        Corporate corporate = new Corporate();

        String value = corporate.toString();

        assertNull(corporate.getName());
        assertTrue(value.contains("Corporate"));
    }

    @Test
    public void shouldHandleNullValues() {
        Corporate corporate = new Corporate();
        corporate.setName("Corp");
        corporate.setAllTins("123");
        corporate.setMpin("MPIN");

        corporate.setName(null);
        corporate.setAllTins(null);
        corporate.setMpin(null);

        assertNull(corporate.getName());
        assertNull(corporate.getAllTins());
        assertNull(corporate.getMpin());
    }
}

