package com.optum.providerpreferences.rs.model.fds;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class FDSResponseTest {

    @Test
    public void shouldLazilyInitializeDocumentsList() {
        FDSResponse response = new FDSResponse();

        List<Document> documents = response.getDocuments();

        assertNotNull(documents);
        assertTrue(documents.isEmpty());
        assertSame(documents, response.getDocuments());
    }

    @Test
    public void shouldSetAndGetDocuments() {
        FDSResponse response = new FDSResponse();
        List<Document> documents = new ArrayList<>();

        Document document = new Document();
        document.setId("doc-1");
        document.setMetadata(new Metadata());
        documents.add(document);

        response.setDocuments(documents);

        assertSame(documents, response.getDocuments());
        assertEquals(1, response.getDocuments().size());
        assertEquals("doc-1", response.getDocuments().get(0).getId());
    }

    @Test
    public void toStringShouldContainDocuments() {
        FDSResponse response = new FDSResponse();
        List<Document> documents = new ArrayList<>();

        Document document = new Document();
        document.setId("doc-1");
        document.setMetadata(new Metadata());
        documents.add(document);

        response.setDocuments(documents);

        String value = response.toString();

        assertTrue(value.startsWith("documents: [Document"));
        assertTrue(value.contains("id=doc-1"));
    }
}

