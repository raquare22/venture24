package com.optum.providerpreferences.rs.model.fds;

import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class FDSCloudGETResponseTest {

    @Test
    public void shouldLazilyInitializeDocumentsList() {
        FDSCloudGETResponse response = new FDSCloudGETResponse();

        List<OptOutFDSCloudDocument> docs = response.getDocuments();

        assertNotNull(docs);
        assertTrue(docs.isEmpty());
        assertSame(docs, response.getDocuments());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        FDSCloudGETResponse response = new FDSCloudGETResponse();
        List<OptOutFDSCloudDocument> docs = new ArrayList<>();
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        doc.setDocumentId("doc-1");
        docs.add(doc);

        response.setTotal_records("10");
        response.setCount("1");
        response.setStart("0");
        response.setDocuments(docs);
        response.setZonedDateTime("2026-05-22T10:00:00Z");
        response.setMessage("ok");
        response.setDetails("done");

        assertEquals("10", response.getTotal_records());
        assertEquals("1", response.getCount());
        assertEquals("0", response.getStart());
        assertSame(docs, response.getDocuments());
        assertEquals("2026-05-22T10:00:00Z", response.getZonedDateTime());
        assertEquals("ok", response.getMessage());
        assertEquals("done", response.getDetails());
    }

    @Test
    public void toStringShouldContainKeyValues() {
        FDSCloudGETResponse response = new FDSCloudGETResponse();
        List<OptOutFDSCloudDocument> docs = new ArrayList<>();
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        doc.setDocumentId("doc-1");
        docs.add(doc);

        response.setTotal_records("10");
        response.setCount("1");
        response.setStart("0");
        response.setDocuments(docs);
        response.setZonedDateTime("2026-05-22T10:00:00Z");
        response.setMessage("ok");
        response.setDetails("done");

        String value = response.toString();

        assertTrue(value.contains("total_records=10"));
        assertTrue(value.contains("count=1"));
        assertTrue(value.contains("start=0"));
        assertTrue(value.contains("documents=[OptOutFDSCloudDocument [documentId=doc-1"));
        assertTrue(value.contains("zonedDateTime=2026-05-22T10:00:00Z"));
        assertTrue(value.contains("message=ok"));
        assertTrue(value.contains("details=done"));
    }
}

