package com.optum.providerpreferences.rs.model.ndb;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class NDBProviderTest {

    @Test
    public void shouldSetAndGetName() {
        NDBProvider provider = new NDBProvider();

        provider.setName("Provider Name");

        assertEquals("Provider Name", provider.getName());
    }

    @Test
    public void shouldSetAndGetMpin() {
        NDBProvider provider = new NDBProvider();

        provider.setMpin("MPIN123");

        assertEquals("MPIN123", provider.getMpin());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        NDBProvider provider = new NDBProvider();

        provider.setName("Test Provider");
        provider.setMpin("MPIN456");

        assertEquals("Test Provider", provider.getName());
        assertEquals("MPIN456", provider.getMpin());
    }

    @Test
    public void fieldsDefaultToNull() {
        NDBProvider provider = new NDBProvider();

        assertNull(provider.getName());
        assertNull(provider.getMpin());
    }

    @Test
    public void shouldHandleNullValues() {
        NDBProvider provider = new NDBProvider();
        provider.setName("Provider");
        provider.setMpin("MPIN");

        provider.setName(null);
        provider.setMpin(null);

        assertNull(provider.getName());
        assertNull(provider.getMpin());
    }

    @Test
    public void shouldUpdateValues() {
        NDBProvider provider = new NDBProvider();

        provider.setName("First Name");
        provider.setMpin("FIRST");

        assertEquals("First Name", provider.getName());
        assertEquals("FIRST", provider.getMpin());

        provider.setName("Updated Name");
        provider.setMpin("UPDATED");

        assertEquals("Updated Name", provider.getName());
        assertEquals("UPDATED", provider.getMpin());
    }
}

