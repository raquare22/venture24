package com.optum.providerpreferences.rs.model.ndb.preferences;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class LetterTypeTest {

    @Test
    public void shouldBuildWithDefaultConstructor() {
        LetterType letterType = new LetterType();

        assertNull(letterType.getLetterType());
    }

    @Test
    public void shouldBuildWithSingleArgConstructor() {
        LetterType letterType = new LetterType("E2");

        assertEquals("E2", letterType.getLetterType());
    }

    @Test
    public void shouldSetAndGetLetterType() {
        LetterType letterType = new LetterType();

        letterType.setLetterType("E3");

        assertEquals("E3", letterType.getLetterType());
    }

    @Test
    public void shouldHandleNullLetterType() {
        LetterType letterType = new LetterType("E4");

        letterType.setLetterType(null);

        assertNull(letterType.getLetterType());
    }
}

