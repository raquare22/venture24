package com.optum.providerpreferences.rs.model.ndb.preferences;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class LetterPreferencesRequestTest {

    @Test
    public void shouldBuildWithDefaultConstructor() {
        LetterPreferencesRequest request = new LetterPreferencesRequest();

        assertNull(request.getRequestHeader());
        assertNull(request.getRequest());
    }

    @Test
    public void shouldBuildWithFullConstructor() {
        RequestHeader header = new RequestHeader("prog1", "user1", "ccc1", "000");
        RequestData data = new RequestData();
        data.setProviderId("provider1");

        LetterPreferencesRequest request = new LetterPreferencesRequest(header, data);

        assertSame(header, request.getRequestHeader());
        assertSame(data, request.getRequest());
        assertEquals("prog1", request.getRequestHeader().getcallingprogram());
        assertEquals("provider1", request.getRequest().getProviderId());
    }

    @Test
    public void shouldSetAndGetRequestHeader() {
        LetterPreferencesRequest request = new LetterPreferencesRequest();
        RequestHeader header = new RequestHeader("prog2", "user2", "ccc2", "001");

        request.setRequestHeader(header);

        assertSame(header, request.getRequestHeader());
    }

    @Test
    public void shouldSetAndGetRequest() {
        LetterPreferencesRequest request = new LetterPreferencesRequest();
        RequestData data = new RequestData();
        data.setProviderId("provider2");

        request.setRequest(data);

        assertSame(data, request.getRequest());
        assertEquals("provider2", request.getRequest().getProviderId());
    }

    @Test
    public void toStringShouldContainBothComponents() {
        RequestHeader header = new RequestHeader("prog3", "user3", "ccc3", "002");
        RequestData data = new RequestData();
        data.setProviderId("provider3");

        LetterPreferencesRequest request = new LetterPreferencesRequest(header, data);

        String value = request.toString();

        assertNotNull(value);
        assertTrue(value.contains("LetterPreferencesRequest"));
        assertTrue(value.contains("requestHeader="));
        assertTrue(value.contains("request="));
    }
}

