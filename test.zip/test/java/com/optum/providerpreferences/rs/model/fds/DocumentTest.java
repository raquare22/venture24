package com.optum.providerpreferences.rs.model.fds;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class DocumentTest {

    @Test
    public void shouldSetAndGetAllFields() {
        Document document = new Document();
        Metadata metadata = new Metadata();

        document.setDateCreated("2026-05-22T10:00:00Z");
        document.setDateModified("2026-05-22T12:00:00Z");
        document.setId("doc-123");
        document.setSpaceId("space-456");
        document.setMetadata(metadata);

        assertEquals("2026-05-22T10:00:00Z", document.getDateCreated());
        assertEquals("2026-05-22T12:00:00Z", document.getDateModified());
        assertEquals("doc-123", document.getId());
        assertEquals("space-456", document.getSpaceId());
        assertEquals(metadata, document.getMetadata());
    }

    @Test
    public void toStringShouldContainKeyValues() {
        Document document = new Document();
        Metadata metadata = new Metadata();
        metadata.setTin("123456789");

        document.setDateCreated("2026-05-22T10:00:00Z");
        document.setId("doc-123");
        document.setSpaceId("space-456");
        document.setMetadata(metadata);

        String value = document.toString();

        assertTrue(value.contains("dateCreated=2026-05-22T10:00:00Z"));
        assertTrue(value.contains("id=doc-123"));
        assertTrue(value.contains("space_id=space-456"));
        assertTrue(value.contains("metadata=Metadata [tin=123456789"));
    }
}

