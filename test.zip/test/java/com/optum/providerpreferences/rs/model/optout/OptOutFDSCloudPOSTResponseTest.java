package com.optum.providerpreferences.rs.model.optout;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class OptOutFDSCloudPOSTResponseTest {

    @Test
    public void getDocumentIdShouldDefaultToEmptyStringWhenNull() {
        OptOutFDSCloudPOSTResponse response = new OptOutFDSCloudPOSTResponse();

        String documentId = response.getDocumentId();

        assertEquals("", documentId);
    }

    @Test
    public void shouldLazilyInitializeSearchTermsAndAttachments() {
        OptOutFDSCloudPOSTResponse response = new OptOutFDSCloudPOSTResponse();

        List<String> searchTerms = response.getSearchTerms();
        List<Object> attachments = response.getAttachments();

        assertNotNull(searchTerms);
        assertNotNull(attachments);
        assertTrue(searchTerms.isEmpty());
        assertTrue(attachments.isEmpty());
        assertSame(searchTerms, response.getSearchTerms());
        assertSame(attachments, response.getAttachments());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        OptOutFDSCloudPOSTResponse response = new OptOutFDSCloudPOSTResponse();
        List<String> searchTerms = new ArrayList<>(Arrays.asList("tin:123456789", "mpin:987654321"));
        List<Object> attachments = new ArrayList<>(Arrays.asList("a.pdf", "b.pdf"));

        response.setDocumentId("doc-1");
        response.setSpaceId("space-1");
        response.setMetadata("{\"recordType\":\"OPTOUT\"}");
        response.setSearchTerms(searchTerms);
        response.setCreatedOn(100L);
        response.setModifiedOn(200L);
        response.setCreatedBy("creator");
        response.setModifiedBy("modifier");
        response.setAttachments(attachments);

        assertEquals("doc-1", response.getDocumentId());
        assertEquals("space-1", response.getSpaceId());
        assertEquals("{\"recordType\":\"OPTOUT\"}", response.getMetadata());
        assertSame(searchTerms, response.getSearchTerms());
        assertEquals(Long.valueOf(100L), response.getCreatedOn());
        assertEquals(Long.valueOf(200L), response.getModifiedOn());
        assertEquals("creator", response.getCreatedBy());
        assertEquals("modifier", response.getModifiedBy());
        assertSame(attachments, response.getAttachments());
    }

    @Test
    public void fieldsShouldDefaultToNullExceptDocumentIdGetter() {
        OptOutFDSCloudPOSTResponse response = new OptOutFDSCloudPOSTResponse();

        assertNull(response.getSpaceId());
        assertNull(response.getMetadata());
        assertNull(response.getCreatedOn());
        assertNull(response.getModifiedOn());
        assertNull(response.getCreatedBy());
        assertNull(response.getModifiedBy());
    }

    @Test
    public void toStringShouldContainExpectedJsonFieldsWhenListsInitialized() {
        OptOutFDSCloudPOSTResponse response = new OptOutFDSCloudPOSTResponse();
        response.setDocumentId("doc-42");
        response.setSpaceId("space-42");
        response.setMetadata("meta-42");
        response.setSearchTerms(Arrays.asList("term1", "term2"));
        response.setCreatedOn(1L);
        response.setModifiedOn(2L);
        response.setCreatedBy("creator-42");
        response.setModifiedBy("modifier-42");
        response.setAttachments(Arrays.asList("file-1"));

        String value = response.toString();

        assertTrue(value.contains("\"documentId\":\"doc-42\""));
        assertTrue(value.contains("\"spaceId\":\"space-42\""));
        assertTrue(value.contains("\"metadata\":\"meta-42\""));
        assertTrue(value.contains("\"searchTerms\":\"[term1, term2]\""));
        assertTrue(value.contains("\"attachments\":\"[file-1]\""));
    }

    @Test
    public void toStringShouldThrowWhenListsAreNotInitialized() {
        OptOutFDSCloudPOSTResponse response = new OptOutFDSCloudPOSTResponse();
        response.setDocumentId("doc-99");

        try {
            response.toString();
            fail("Expected NullPointerException when searchTerms/attachments are null");
        } catch (NullPointerException expected) {
            assertTrue(true);
        }
    }
}

