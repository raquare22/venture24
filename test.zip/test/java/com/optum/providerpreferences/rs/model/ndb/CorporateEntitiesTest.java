package com.optum.providerpreferences.rs.model.ndb;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class CorporateEntitiesTest {

    @Test
    public void shouldLazilyInitializePrivilegesList() {
        CorporateEntities entities = new CorporateEntities();

        List<String> privileges = entities.getPrivileges();

        assertNotNull(privileges);
        assertTrue(privileges.isEmpty());
        assertSame(privileges, entities.getPrivileges());
    }

    @Test
    public void shouldLazilyInitializeCorporatesList() {
        CorporateEntities entities = new CorporateEntities();

        List<Corporate> corporates = entities.getCorporates();

        assertNotNull(corporates);
        assertTrue(corporates.isEmpty());
        assertSame(corporates, entities.getCorporates());
    }

    @Test
    public void shouldSetAndGetPrivileges() {
        CorporateEntities entities = new CorporateEntities();
        List<String> privileges = new ArrayList<>();
        privileges.add("PRIV1");
        privileges.add("PRIV2");

        entities.setPrivileges(privileges);

        assertSame(privileges, entities.getPrivileges());
        assertEquals(2, entities.getPrivileges().size());
        assertEquals("PRIV1", entities.getPrivileges().get(0));
        assertEquals("PRIV2", entities.getPrivileges().get(1));
    }

    @Test
    public void shouldSetAndGetCorporates() {
        CorporateEntities entities = new CorporateEntities();
        List<Corporate> corporates = new ArrayList<>();
        Corporate corp = new Corporate();
        corp.setName("Corp1");
        corporates.add(corp);

        entities.setCorporates(corporates);

        assertSame(corporates, entities.getCorporates());
        assertEquals(1, entities.getCorporates().size());
        assertEquals("Corp1", entities.getCorporates().get(0).getName());
    }

    @Test
    public void shouldSetAndGetStatusCode() {
        CorporateEntities entities = new CorporateEntities();

        entities.setStatusCode("200");

        assertEquals("200", entities.getStatusCode());
    }

    @Test
    public void shouldSetAndGetStatusMessage() {
        CorporateEntities entities = new CorporateEntities();

        entities.setStatusMessage("Success");

        assertEquals("Success", entities.getStatusMessage());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        CorporateEntities entities = new CorporateEntities();
        List<String> privileges = new ArrayList<>();
        privileges.add("ADMIN");
        List<Corporate> corporates = new ArrayList<>();
        Corporate corp = new Corporate();
        corp.setName("TestCorp");
        corporates.add(corp);

        entities.setPrivileges(privileges);
        entities.setCorporates(corporates);
        entities.setStatusCode("201");
        entities.setStatusMessage("Created");

        assertSame(privileges, entities.getPrivileges());
        assertSame(corporates, entities.getCorporates());
        assertEquals("201", entities.getStatusCode());
        assertEquals("Created", entities.getStatusMessage());
    }

    @Test
    public void statusFieldsDefaultToNull() {
        CorporateEntities entities = new CorporateEntities();

        assertNull(entities.getStatusCode());
        assertNull(entities.getStatusMessage());
    }

    @Test
    public void shouldHandleNullValues() {
        CorporateEntities entities = new CorporateEntities();
        List<String> privileges = new ArrayList<>();
        privileges.add("PRIV");
        List<Corporate> corporates = new ArrayList<>();
        Corporate corp = new Corporate();
        corporates.add(corp);

        entities.setPrivileges(privileges);
        entities.setCorporates(corporates);
        entities.setStatusCode("OK");
        entities.setStatusMessage("Msg");

        entities.setPrivileges(null);
        entities.setCorporates(null);
        entities.setStatusCode(null);
        entities.setStatusMessage(null);

        assertNotNull(entities.getPrivileges());
        assertTrue(entities.getPrivileges().isEmpty());
        assertNotNull(entities.getCorporates());
        assertTrue(entities.getCorporates().isEmpty());
        assertNull(entities.getStatusCode());
        assertNull(entities.getStatusMessage());
    }
}

