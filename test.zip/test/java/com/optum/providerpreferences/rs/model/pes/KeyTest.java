package com.optum.providerpreferences.rs.model.pes;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class KeyTest {

    @Test
    public void shouldSetAndGetFields() {
        Key key = new Key();

        key.setTaxIdNumber("123456789");
        key.setTaxIdTypeCode("EIN");

        assertEquals("123456789", key.getTaxIdNumber());
        assertEquals("EIN", key.getTaxIdTypeCode());
    }

    @Test
    public void fieldsDefaultToNull() {
        Key key = new Key();

        assertNull(key.getTaxIdNumber());
        assertNull(key.getTaxIdTypeCode());
    }

    @Test
    public void toStringShouldContainFieldValues() {
        Key key = new Key();
        key.setTaxIdNumber("123456789");
        key.setTaxIdTypeCode("EIN");

        String value = key.toString();

        assertTrue(value.contains("taxIdNumber: 123456789"));
        assertTrue(value.contains("taxIdTypeCode: EIN"));
    }
}

