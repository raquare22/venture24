package com.optum.providerpreferences.rs.model.optout;

import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class OptOutFDSCloudDocumentTest {

    @Test
    public void shouldSetAndGetAllFields() {
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();

        Map<String, Object> searchTerms = new HashMap<>();
        searchTerms.put("tin", "123456789");
        List<Object> attachments = new ArrayList<>();
        attachments.add("file1.pdf");

        doc.setDocumentId("doc-1");
        doc.setSearchTerms(searchTerms);
        doc.setSpaceId("space-1");
        doc.setModifiedOn(111L);
        doc.setModifiedBy("modifier");
        doc.setCreatedBy("creator");
        doc.setCreatedOn(222L);
        doc.setMetadata("{\"key\":\"value\"}");
        doc.setExpiryDate(333L);
        doc.setExternalId("ext-1");
        doc.setAttachments(attachments);
        doc.setWorkflow("wf-1");
        doc.setAccessToken("token-1");
        doc.setStatus("SUCCESS");
        doc.setTransactionId("txn-1");
        doc.setOnPremSpaceId("onprem-space-1");
        doc.setOnPremRecordType("REC_TYPE");

        assertEquals("doc-1", doc.getDocumentId());
        assertSame(searchTerms, doc.getSearchTerms());
        assertEquals("space-1", doc.getSpaceId());
        assertEquals(Long.valueOf(111L), doc.getModifiedOn());
        assertEquals("modifier", doc.getModifiedBy());
        assertEquals("creator", doc.getCreatedBy());
        assertEquals(Long.valueOf(222L), doc.getCreatedOn());
        assertEquals("{\"key\":\"value\"}", doc.getMetadata());
        assertEquals(Long.valueOf(333L), doc.getExpiryDate());
        assertEquals("ext-1", doc.getExternalId());
        assertSame(attachments, doc.getAttachments());
        assertEquals("wf-1", doc.getWorkflow());
        assertEquals("token-1", doc.getAccessToken());
        assertEquals("SUCCESS", doc.getStatus());
        assertEquals("txn-1", doc.getTransactionId());
        assertEquals("onprem-space-1", doc.getOnPremSpaceId());
        assertEquals("REC_TYPE", doc.getOnPremRecordType());
    }

    @Test
    public void fieldsShouldDefaultToNull() {
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();

        assertNull(doc.getDocumentId());
        assertNull(doc.getSearchTerms());
        assertNull(doc.getSpaceId());
        assertNull(doc.getModifiedOn());
        assertNull(doc.getModifiedBy());
        assertNull(doc.getCreatedBy());
        assertNull(doc.getCreatedOn());
        assertNull(doc.getMetadata());
        assertNull(doc.getExpiryDate());
        assertNull(doc.getExternalId());
        assertNull(doc.getAttachments());
        assertNull(doc.getWorkflow());
        assertNull(doc.getAccessToken());
        assertNull(doc.getStatus());
        assertNull(doc.getTransactionId());
        assertNull(doc.getOnPremSpaceId());
        assertNull(doc.getOnPremRecordType());
    }

    @Test
    public void shouldHandleNullAssignments() {
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();

        doc.setDocumentId("doc");
        doc.setSearchTerms("x");
        doc.setSpaceId("space");
        doc.setModifiedOn(1L);
        doc.setModifiedBy("m");
        doc.setCreatedBy("c");
        doc.setCreatedOn(2L);
        doc.setMetadata("meta");
        doc.setExpiryDate(3L);
        doc.setExternalId("ext");
        doc.setAttachments(new ArrayList<>());
        doc.setWorkflow("wf");
        doc.setAccessToken("token");
        doc.setStatus("status");
        doc.setTransactionId("txn");
        doc.setOnPremSpaceId("ops");
        doc.setOnPremRecordType("type");

        doc.setDocumentId(null);
        doc.setSearchTerms(null);
        doc.setSpaceId(null);
        doc.setModifiedOn(null);
        doc.setModifiedBy(null);
        doc.setCreatedBy(null);
        doc.setCreatedOn(null);
        doc.setMetadata(null);
        doc.setExpiryDate(null);
        doc.setExternalId(null);
        doc.setAttachments(null);
        doc.setWorkflow(null);
        doc.setAccessToken(null);
        doc.setStatus(null);
        doc.setTransactionId(null);
        doc.setOnPremSpaceId(null);
        doc.setOnPremRecordType(null);

        assertNull(doc.getDocumentId());
        assertNull(doc.getSearchTerms());
        assertNull(doc.getSpaceId());
        assertNull(doc.getModifiedOn());
        assertNull(doc.getModifiedBy());
        assertNull(doc.getCreatedBy());
        assertNull(doc.getCreatedOn());
        assertNull(doc.getMetadata());
        assertNull(doc.getExpiryDate());
        assertNull(doc.getExternalId());
        assertNull(doc.getAttachments());
        assertNull(doc.getWorkflow());
        assertNull(doc.getAccessToken());
        assertNull(doc.getStatus());
        assertNull(doc.getTransactionId());
        assertNull(doc.getOnPremSpaceId());
        assertNull(doc.getOnPremRecordType());
    }

    @Test
    public void toStringShouldContainKeyValues() {
        OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();
        doc.setDocumentId("doc-42");
        doc.setSpaceId("space-42");
        doc.setModifiedBy("user-42");
        doc.setMetadata("meta-42");
        doc.setExternalId("ext-42");
        doc.setWorkflow("wf-42");

        String value = doc.toString();

        assertTrue(value.contains("documentId=doc-42"));
        assertTrue(value.contains("spaceId=space-42"));
        assertTrue(value.contains("modifiedBy=user-42"));
        assertTrue(value.contains("metadata=meta-42"));
        assertTrue(value.contains("externalId=ext-42"));
        assertTrue(value.contains("workflow=wf-42"));
    }
}

