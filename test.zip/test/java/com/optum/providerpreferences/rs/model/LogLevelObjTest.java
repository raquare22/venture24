package com.optum.providerpreferences.rs.model;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class LogLevelObjTest {

    @Test
    public void shouldDefaultFieldsToNull() {
        LogLevelObj obj = new LogLevelObj();

        assertNull(obj.getLogLevel());
        assertNull(obj.getPackageName());
    }

    @Test
    public void shouldSetAndGetFields() {
        LogLevelObj obj = new LogLevelObj();

        obj.setLogLevel("INFO");
        obj.setPackageName("com.optum.providerpreferences");

        assertEquals("INFO", obj.getLogLevel());
        assertEquals("com.optum.providerpreferences", obj.getPackageName());
    }

    @Test
    public void toStringShouldIncludeFieldValues() {
        LogLevelObj obj = new LogLevelObj();
        obj.setLogLevel("DEBUG");
        obj.setPackageName("com.optum.providerpreferences.rs");

        String text = obj.toString();

        assertTrue(text.contains("logLevel: DEBUG"));
        assertTrue(text.contains("packageName: com.optum.providerpreferences.rs"));
    }

    @Test
    public void toStringShouldHandleNullValues() {
        LogLevelObj obj = new LogLevelObj();

        String text = obj.toString();

        assertEquals("logLevel: null, packageName: null", text);
    }
}

