package com.optum.providerpreferences.rs.model.optout;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class OptOutTinResponseTest {

    @Test
    public void constructorShouldInitializeTins() {
        List<String> tins = Arrays.asList("123456789", "987654321");

        OptOutTinResponse response = new OptOutTinResponse(tins);

        assertSame(tins, response.getTins());
        assertEquals(2, response.getTins().size());
        assertEquals("123456789", response.getTins().get(0));
        assertEquals("987654321", response.getTins().get(1));
    }

    @Test
    public void shouldSetAndGetTins() {
        List<String> initialTins = Collections.singletonList("111111111");
        OptOutTinResponse response = new OptOutTinResponse(initialTins);
        List<String> updatedTins = Arrays.asList("222222222", "333333333");

        response.setTins(updatedTins);

        assertSame(updatedTins, response.getTins());
        assertEquals(2, response.getTins().size());
    }

    @Test
    public void shouldHandleNullTins() {
        OptOutTinResponse response = new OptOutTinResponse(null);

        assertNull(response.getTins());

        response.setTins(null);
        assertNull(response.getTins());
    }
}

