package com.optum.providerpreferences.rs.model.ndb;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class IndividualMPINRequestTest {

    @Test
    public void shouldCreateInstance() {
        IndividualMPINRequest request = new IndividualMPINRequest();

        assertNotNull(request);
        assertEquals(IndividualMPINRequest.class, request.getClass());
    }
}

