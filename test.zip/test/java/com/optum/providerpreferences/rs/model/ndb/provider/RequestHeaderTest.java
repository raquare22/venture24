package com.optum.providerpreferences.rs.model.ndb.provider;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class RequestHeaderTest {

    @Test
    public void shouldSetAndGetApplicationId() {
        RequestHeader header = new RequestHeader();

        header.setApplicationId("app1");

        assertEquals("app1", header.getApplicationId());
    }

    @Test
    public void shouldSetAndGetClientId() {
        RequestHeader header = new RequestHeader();

        header.setClientId("client1");

        assertEquals("client1", header.getClientId());
    }

    @Test
    public void shouldSetAndGetSubscriber() {
        RequestHeader header = new RequestHeader();

        header.setSubscriber("subscriber1");

        assertEquals("subscriber1", header.getSubscriber());
    }

    @Test
    public void shouldSetAndGetCallingEntity() {
        RequestHeader header = new RequestHeader();

        header.setCallingEntity("entity1");

        assertEquals("entity1", header.getCallingEntity());
    }

    @Test
    public void shouldSetAndGetUserId() {
        RequestHeader header = new RequestHeader();

        header.setUserId("user1");

        assertEquals("user1", header.getUserId());
    }

    @Test
    public void shouldSetAndGetUserOfficeCode() {
        RequestHeader header = new RequestHeader();

        header.setUserOfficeCode("office1");

        assertEquals("office1", header.getUserOfficeCode());
    }

    @Test
    public void shouldSetAndGetLastUpdateTypeCode() {
        RequestHeader header = new RequestHeader();

        header.setLastUpdateTypeCode("UPDATE1");

        assertEquals("UPDATE1", header.getLastUpdateTypeCode());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        RequestHeader header = new RequestHeader();

        header.setApplicationId("app2");
        header.setClientId("client2");
        header.setSubscriber("subscriber2");
        header.setCallingEntity("entity2");
        header.setUserId("user2");
        header.setUserOfficeCode("office2");
        header.setLastUpdateTypeCode("UPDATE2");

        assertEquals("app2", header.getApplicationId());
        assertEquals("client2", header.getClientId());
        assertEquals("subscriber2", header.getSubscriber());
        assertEquals("entity2", header.getCallingEntity());
        assertEquals("user2", header.getUserId());
        assertEquals("office2", header.getUserOfficeCode());
        assertEquals("UPDATE2", header.getLastUpdateTypeCode());
    }

    @Test
    public void fieldsDefaultToNull() {
        RequestHeader header = new RequestHeader();

        assertNull(header.getApplicationId());
        assertNull(header.getClientId());
        assertNull(header.getSubscriber());
        assertNull(header.getCallingEntity());
        assertNull(header.getUserId());
        assertNull(header.getUserOfficeCode());
        assertNull(header.getLastUpdateTypeCode());
    }

    @Test
    public void shouldHandleNullValues() {
        RequestHeader header = new RequestHeader();
        header.setApplicationId("app3");
        header.setClientId("client3");
        header.setSubscriber("subscriber3");
        header.setCallingEntity("entity3");
        header.setUserId("user3");
        header.setUserOfficeCode("office3");
        header.setLastUpdateTypeCode("UPDATE3");

        header.setApplicationId(null);
        header.setClientId(null);
        header.setSubscriber(null);
        header.setCallingEntity(null);
        header.setUserId(null);
        header.setUserOfficeCode(null);
        header.setLastUpdateTypeCode(null);

        assertNull(header.getApplicationId());
        assertNull(header.getClientId());
        assertNull(header.getSubscriber());
        assertNull(header.getCallingEntity());
        assertNull(header.getUserId());
        assertNull(header.getUserOfficeCode());
        assertNull(header.getLastUpdateTypeCode());
    }
}

