package com.optum.providerpreferences.rs.model.autoenroll;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

public class FDSMultiPutResponseTest {

    @Test
    public void shouldSetAndGetUpdatedAndNotfoundLists() {
        FDSMultiPutResponse response = new FDSMultiPutResponse();
        List<String> updated = Arrays.asList("doc-1", "doc-2");
        List<String> notfound = Arrays.asList("doc-3");

        response.setUpdated(updated);
        response.setNotfound(notfound);

        assertSame(updated, response.getUpdated());
        assertSame(notfound, response.getNotfound());
        assertEquals(2, response.getUpdated().size());
        assertEquals(1, response.getNotfound().size());
        assertEquals("doc-1", response.getUpdated().get(0));
        assertEquals("doc-3", response.getNotfound().get(0));
    }

    @Test
    public void toStringShouldContainUpdatedAndNotfoundValues() {
        FDSMultiPutResponse response = new FDSMultiPutResponse();
        response.setUpdated(Arrays.asList("doc-1", "doc-2"));
        response.setNotfound(Arrays.asList("doc-3"));

        String value = response.toString();

        assertEquals("updated: [doc-1, doc-2] ; notfound: [doc-3]", value);
    }
}

