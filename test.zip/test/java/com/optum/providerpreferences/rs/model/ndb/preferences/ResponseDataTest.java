package com.optum.providerpreferences.rs.model.ndb.preferences;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class ResponseDataTest {

    @Test
    public void shouldBuildWithDefaultConstructor() {
        ResponseData data = new ResponseData();

        assertNull(data.getProviderId());
        assertNull(data.getProviderTIN());
        assertNull(data.getProviderTINType());
        assertNull(data.getLtrTypMailPrfList());
    }

    @Test
    public void shouldBuildWithFourArgConstructor() {
        List<MailPref> mailPrefs = new ArrayList<>();
        mailPrefs.add(new MailPref("E2", "ELECTRONIC"));

        ResponseData data = new ResponseData("provider1", "123456789", "T", mailPrefs);

        assertEquals("provider1", data.getProviderId());
        assertEquals("123456789", data.getProviderTIN());
        assertEquals("T", data.getProviderTINType());
        assertSame(mailPrefs, data.getLtrTypMailPrfList());
    }

    @Test
    public void shouldSetAndGetProviderId() {
        ResponseData data = new ResponseData();

        data.setProviderId("provider2");

        assertEquals("provider2", data.getProviderId());
    }

    @Test
    public void shouldSetAndGetProviderTIN() {
        ResponseData data = new ResponseData();

        data.setProviderTIN("987654321");

        assertEquals("987654321", data.getProviderTIN());
    }

    @Test
    public void shouldSetAndGetProviderTINType() {
        ResponseData data = new ResponseData();

        data.setProviderTINType("T");

        assertEquals("T", data.getProviderTINType());
    }

    @Test
    public void shouldSetAndGetLtrTypMailPrfList() {
        ResponseData data = new ResponseData();
        List<MailPref> mailPrefs = new ArrayList<>();
        mailPrefs.add(new MailPref("E3", "PAPER"));

        data.setLtrTypMailPrfList(mailPrefs);

        assertSame(mailPrefs, data.getLtrTypMailPrfList());
        assertEquals(1, data.getLtrTypMailPrfList().size());
        assertEquals("E3", data.getLtrTypMailPrfList().get(0).getLetterType());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        ResponseData data = new ResponseData();
        List<MailPref> mailPrefs = new ArrayList<>();
        mailPrefs.add(new MailPref("E4", "BOTH"));

        data.setProviderId("provider3");
        data.setProviderTIN("111222333");
        data.setProviderTINType("T");
        data.setLtrTypMailPrfList(mailPrefs);

        assertEquals("provider3", data.getProviderId());
        assertEquals("111222333", data.getProviderTIN());
        assertEquals("T", data.getProviderTINType());
        assertSame(mailPrefs, data.getLtrTypMailPrfList());
    }
}

