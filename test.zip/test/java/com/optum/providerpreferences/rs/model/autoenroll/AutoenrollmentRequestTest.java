package com.optum.providerpreferences.rs.model.autoenroll;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;

public class AutoenrollmentRequestTest {

    @Test
    public void shouldSetAndGetAutoenrollDocuments() {
        AutoenrollmentRequest request = new AutoenrollmentRequest();
        List<AutoenrollmentObj> docs = new ArrayList<>();

        AutoenrollmentObj doc = new AutoenrollmentObj();
        doc.setTin("123456789");
        doc.setMpin("987654321");
        docs.add(doc);

        request.setAutoenrollDocuments(docs);

        List<AutoenrollmentObj> result = request.getAutoenrollDocuments();
        assertNotNull(result);
        assertSame(docs, result);
        assertEquals(1, result.size());
        assertEquals("123456789", result.get(0).getTin());
        assertEquals("987654321", result.get(0).getMpin());
    }
}

