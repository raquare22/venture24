package com.optum.providerpreferences.rs.model.ndb.preferences;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class UILetterPreferencesRequestTest {

    @Test
    public void shouldBuildWithDefaultConstructor() {
        UILetterPreferencesRequest request = new UILetterPreferencesRequest();

        assertNull(request.getProviderId());
        assertNull(request.getProviderTIN());
    }

    @Test
    public void shouldBuildWithTwoArgConstructor() {
        UILetterPreferencesRequest request = new UILetterPreferencesRequest("provider1", "123456789");

        assertEquals("provider1", request.getProviderId());
        assertEquals("123456789", request.getProviderTIN());
    }

    @Test
    public void shouldSetAndGetProviderId() {
        UILetterPreferencesRequest request = new UILetterPreferencesRequest();

        request.setProviderId("provider2");

        assertEquals("provider2", request.getProviderId());
    }

    @Test
    public void shouldSetAndGetProviderTIN() {
        UILetterPreferencesRequest request = new UILetterPreferencesRequest();

        request.setProviderTIN("987654321");

        assertEquals("987654321", request.getProviderTIN());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        UILetterPreferencesRequest request = new UILetterPreferencesRequest();

        request.setProviderId("provider3");
        request.setProviderTIN("111222333");

        assertEquals("provider3", request.getProviderId());
        assertEquals("111222333", request.getProviderTIN());
    }

    @Test
    public void shouldHandleNullValues() {
        UILetterPreferencesRequest request = new UILetterPreferencesRequest("provider4", "444555666");

        request.setProviderId(null);
        request.setProviderTIN(null);

        assertNull(request.getProviderId());
        assertNull(request.getProviderTIN());
    }
}

