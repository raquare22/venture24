package com.optum.providerpreferences.rs.model.logging;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class LogMessageTest {

    @Test
    public void shouldReturnConstantLogType() {
        LogMessage logMessage = new LogMessage();

        String logType = logMessage.getLogtype();

        assertEquals("SECURITY_AUDIT", logType);
    }

    @Test
    public void shouldSetAndGetActor() {
        LogMessage logMessage = new LogMessage();

        logMessage.setActor("USER1");

        assertEquals("USER1", logMessage.getActor());
    }

    @Test
    public void shouldSetAndGetActorIp() {
        LogMessage logMessage = new LogMessage();

        logMessage.setActorIp("192.168.1.1");

        assertEquals("192.168.1.1", logMessage.getActorIp());
    }

    @Test
    public void shouldSetAndGetDetail() {
        LogMessage logMessage = new LogMessage();

        logMessage.setDetail("User login successful");

        assertEquals("User login successful", logMessage.getDetail());
    }

    @Test
    public void shouldSetAndGetUsername() {
        LogMessage logMessage = new LogMessage();

        logMessage.setUsername("testuser");

        assertEquals("testuser", logMessage.getUsername());
    }

    @Test
    public void getSrcIpShouldReturnValidIpAddress() {
        LogMessage logMessage = new LogMessage();

        String srcIp = logMessage.getSrcIp();

        assertNotNull(srcIp);
        // Valid IP or hostname pattern (should not be null and should contain at least one dot or be a valid hostname)
        assertTrue(srcIp.length() > 0);
    }

    @Test
    public void getSrcIpShouldReturnFallbackWhenLocalHostNotAvailable() {
        LogMessage logMessage = new LogMessage();
        logMessage.setActorIp("fallback-ip");

        // Even if InetAddress.getLocalHost() fails, getSrcIp should handle it gracefully
        String srcIp = logMessage.getSrcIp();
        assertNotNull(srcIp);
    }

    @Test
    public void shouldSetAndGetAllFieldsTogether() {
        LogMessage logMessage = new LogMessage();

        logMessage.setActor("ADMIN");
        logMessage.setActorIp("10.0.0.1");
        logMessage.setDetail("Sensitive operation performed");
        logMessage.setUsername("admin1");

        assertEquals("SECURITY_AUDIT", logMessage.getLogtype());
        assertEquals("ADMIN", logMessage.getActor());
        assertEquals("10.0.0.1", logMessage.getActorIp());
        assertEquals("Sensitive operation performed", logMessage.getDetail());
        assertEquals("admin1", logMessage.getUsername());
        assertNotNull(logMessage.getSrcIp());
    }
}

