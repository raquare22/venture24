package com.optum.providerpreferences.rs.model.optout;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class OptOutRequestTest {

    @Test
    public void shouldSetAndGetAllFields() {
        OptOutRequest request = new OptOutRequest();
        List<String> providerMpins = Arrays.asList("111111111", "222222222");

        request.setTin("123456789");
        request.setCorpMpin("999999999");
        request.setProviderMpins(providerMpins);
        request.setLastUpdatedBy("SYSTEM");
        request.setLastUpdatedById("user-123");
        request.setOptedOutDuration(45);

        assertEquals("123456789", request.getTin());
        assertEquals("999999999", request.getCorpMpin());
        assertSame(providerMpins, request.getProviderMpins());
        assertEquals("SYSTEM", request.getLastUpdatedBy());
        assertEquals("user-123", request.getLastUpdatedById());
        assertEquals(45, request.getOptedOutDuration());
    }

    @Test
    public void shouldHaveExpectedDefaults() {
        OptOutRequest request = new OptOutRequest();

        assertNull(request.getTin());
        assertNull(request.getCorpMpin());
        assertNull(request.getProviderMpins());
        assertNull(request.getLastUpdatedBy());
        assertNull(request.getLastUpdatedById());
        assertEquals(0, request.getOptedOutDuration());
    }

    @Test
    public void shouldHandleNullValues() {
        OptOutRequest request = new OptOutRequest();
        request.setTin("123");
        request.setCorpMpin("999");
        request.setProviderMpins(Collections.singletonList("1"));
        request.setLastUpdatedBy("A");
        request.setLastUpdatedById("B");
        request.setOptedOutDuration(1);

        request.setTin(null);
        request.setCorpMpin(null);
        request.setProviderMpins(null);
        request.setLastUpdatedBy(null);
        request.setLastUpdatedById(null);
        request.setOptedOutDuration(0);

        assertNull(request.getTin());
        assertNull(request.getCorpMpin());
        assertNull(request.getProviderMpins());
        assertNull(request.getLastUpdatedBy());
        assertNull(request.getLastUpdatedById());
        assertEquals(0, request.getOptedOutDuration());
    }

    @Test
    public void toStringShouldContainKeyValues() {
        OptOutRequest request = new OptOutRequest();
        request.setTin("123456789");
        request.setCorpMpin("999999999");
        request.setProviderMpins(Collections.singletonList("111111111"));
        request.setLastUpdatedBy("SYSTEM");
        request.setLastUpdatedById("user-123");
        request.setOptedOutDuration(30);

        String value = request.toString();

        assertTrue(value.contains("tin: 123456789"));
        assertTrue(value.contains("corpMpin: 999999999"));
        assertTrue(value.contains("providerMpins: [111111111]"));
        assertTrue(value.contains("lastUpdatedBy: SYSTEM"));
        assertTrue(value.contains("lastUpdatedByIduser-123"));
        assertTrue(value.contains("optedOutDuration: 30"));
    }
}

