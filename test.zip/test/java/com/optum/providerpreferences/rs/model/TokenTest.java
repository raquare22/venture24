package com.optum.providerpreferences.rs.model;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNull;

public class TokenTest {

    @Test
    public void shouldSetAndGetAllFields() {
        Token token = new Token();

        token.setAccessToken("access-123");
        token.setRefreshToken("refresh-123");
        token.setTokenType("Bearer");
        token.setExpiresIn("3600");
        token.setCreatedAt("1716681600");

        assertEquals("access-123", token.getAccessToken());
        assertEquals("refresh-123", token.getRefreshToken());
        assertEquals("Bearer", token.getTokenType());
        assertEquals("3600", token.getExpiresIn());
        assertEquals("1716681600", token.getCreatedAt());
    }

    @Test
    public void shouldSupportAccessTokenThroughAbstractType() {
        TokenAbst token = new Token();

        token.setAccessToken("abstract-access");

        assertEquals("abstract-access", token.getAccessToken());
    }

    @Test
    public void fieldsShouldDefaultToNull() {
        Token token = new Token();

        assertNull(token.getAccessToken());
        assertNull(token.getRefreshToken());
        assertNull(token.getTokenType());
        assertNull(token.getExpiresIn());
        assertNull(token.getCreatedAt());
    }

    @Test
    public void toStringShouldContainAllFieldValues() {
        Token token = new Token();
        token.setAccessToken("a1");
        token.setRefreshToken("r1");
        token.setTokenType("Bearer");
        token.setExpiresIn("1800");
        token.setCreatedAt("12345");

        String value = token.toString();

        assertTrue(value.contains("access_token=a1"));
        assertTrue(value.contains("refresh_token=r1"));
        assertTrue(value.contains("token_type=Bearer"));
        assertTrue(value.contains("expires_in=1800"));
        assertTrue(value.contains("created_at=12345"));
    }

    @Test
    public void shouldDeserializeJsonPropertiesAndIgnoreUnknownFields() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        String json = "{" +
                "\"access_token\":\"access-json\"," +
                "\"refresh_token\":\"refresh-json\"," +
                "\"token_type\":\"Bearer\"," +
                "\"expires_in\":\"7200\"," +
                "\"created_at\":\"99999\"," +
                "\"ignored_field\":\"ignored\"" +
                "}";

        Token token = mapper.readValue(json, Token.class);

        assertNotNull(token);
        assertEquals("access-json", token.getAccessToken());
        assertEquals("refresh-json", token.getRefreshToken());
        assertEquals("Bearer", token.getTokenType());
        assertEquals("7200", token.getExpiresIn());
        assertEquals("99999", token.getCreatedAt());
    }

    @Test
    public void shouldSerializeUsingAnnotatedJsonPropertyNames() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        Token token = new Token();
        token.setAccessToken("serialized-access");
        token.setRefreshToken("serialized-refresh");
        token.setTokenType("Bearer");
        token.setExpiresIn("900");
        token.setCreatedAt("55555");

        String json = mapper.writeValueAsString(token);

        assertTrue(json.contains("\"access_token\":\"serialized-access\""));
        assertTrue(json.contains("\"refresh_token\":\"serialized-refresh\""));
        assertTrue(json.contains("\"token_type\":\"Bearer\""));
        assertTrue(json.contains("\"expires_in\":\"900\""));
        assertTrue(json.contains("\"created_at\":\"55555\""));
    }
}

