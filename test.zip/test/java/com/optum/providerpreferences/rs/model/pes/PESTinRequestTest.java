package com.optum.providerpreferences.rs.model.pes;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class PESTinRequestTest {

    @Test
    public void constructorShouldPopulateDefaults() {
        PESTinRequest request = new PESTinRequest("corp123");

        assertEquals("fds.paperless.pdo", request.getApplicationName());
        assertEquals("0", request.getPageOffset());
        assertEquals("Active", request.getStatusCode());
        assertEquals("corp123", request.getCorporateOwnerProviderId());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        PESTinRequest request = new PESTinRequest("corp123");

        request.setApplicationName("app");
        request.setPageOffset("10");
        request.setStatusCode("Inactive");
        request.setCorporateOwnerProviderId("corp999");

        assertEquals("app", request.getApplicationName());
        assertEquals("10", request.getPageOffset());
        assertEquals("Inactive", request.getStatusCode());
        assertEquals("corp999", request.getCorporateOwnerProviderId());
    }

    @Test
    public void toStringShouldContainKeyValues() {
        PESTinRequest request = new PESTinRequest("corp123");

        String value = request.toString();

        assertTrue(value.contains("applicationName: fds.paperless.pdo"));
        assertTrue(value.contains("corporateOwnerProviderId: corp123"));
    }
}

