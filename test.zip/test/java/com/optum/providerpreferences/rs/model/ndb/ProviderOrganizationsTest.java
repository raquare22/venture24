package com.optum.providerpreferences.rs.model.ndb;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class ProviderOrganizationsTest {

    @Test
    public void shouldLazilyInitializeRespOrgs() {
        ProviderOrganizations organizations = new ProviderOrganizations();

        List<ProviderOrganization> result = organizations.getRespOrgs();

        assertNotNull(result);
        assertTrue(result.isEmpty());
        assertSame(result, organizations.getRespOrgs());
    }

    @Test
    public void shouldSetAndGetRespOrgs() {
        ProviderOrganizations organizations = new ProviderOrganizations();
        List<ProviderOrganization> respOrgs = new ArrayList<>();
        ProviderOrganization org = new ProviderOrganization();
        org.setUhcId("UHC1");
        org.setRespOrgName("Org One");
        respOrgs.add(org);

        organizations.setRespOrgs(respOrgs);

        assertSame(respOrgs, organizations.getRespOrgs());
        assertEquals(1, organizations.getRespOrgs().size());
        assertEquals("UHC1", organizations.getRespOrgs().get(0).getUhcId());
    }

    @Test
    public void shouldSetAndGetOptumUUId() {
        ProviderOrganizations organizations = new ProviderOrganizations();

        organizations.setOptumUUId("uuid-123");

        assertEquals("uuid-123", organizations.getOptumUUId());
    }

    @Test
    public void shouldSetAndGetStatusCodeAndStatusMessage() {
        ProviderOrganizations organizations = new ProviderOrganizations();

        organizations.setStatusCode("200");
        organizations.setStatusMessage("Success");

        assertEquals("200", organizations.getStatusCode());
        assertEquals("Success", organizations.getStatusMessage());
    }

    @Test
    public void shouldHandleNullRespOrgsByReturningEmptyList() {
        ProviderOrganizations organizations = new ProviderOrganizations();
        organizations.setRespOrgs(null);

        List<ProviderOrganization> result = organizations.getRespOrgs();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void statusFieldsShouldDefaultToNull() {
        ProviderOrganizations organizations = new ProviderOrganizations();

        assertNull(organizations.getOptumUUId());
        assertNull(organizations.getStatusCode());
        assertNull(organizations.getStatusMessage());
    }

    @Test
    public void toStringShouldContainKeyFields() {
        ProviderOrganizations organizations = new ProviderOrganizations();
        organizations.setOptumUUId("uuid-456");
        organizations.setStatusCode("201");
        organizations.setStatusMessage("Created");
        organizations.getRespOrgs().add(new ProviderOrganization());

        String value = organizations.toString();

        assertTrue(value.contains("optumUUId=uuid-456"));
        assertTrue(value.contains("statusCode=201"));
        assertTrue(value.contains("statusMessage=Created"));
        assertTrue(value.contains("respOrgs="));
    }
}

