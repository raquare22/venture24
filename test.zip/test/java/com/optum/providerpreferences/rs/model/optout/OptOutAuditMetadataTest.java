package com.optum.providerpreferences.rs.model.optout;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class OptOutAuditMetadataTest {

    @Test
    public void shouldLazilyInitializeNestedObjects() {
        OptOutAuditMetadata metadata = new OptOutAuditMetadata();

        OptOutRequest optOutRequest = metadata.getOptOutRequest();
        OptOutAuditUpdate optOutUpdate = metadata.getOptOutUpdate();

        assertNotNull(optOutRequest);
        assertNotNull(optOutUpdate);
        assertSame(optOutRequest, metadata.getOptOutRequest());
        assertSame(optOutUpdate, metadata.getOptOutUpdate());
    }

    @Test
    public void shouldLazilyInitializeLists() {
        OptOutAuditMetadata metadata = new OptOutAuditMetadata();

        List<String> documentIds = metadata.getDocumentIds();
        List<String> updated = metadata.getUpdated();
        List<String> failedDocumentIds = metadata.getFailedDocumentIds();

        assertNotNull(documentIds);
        assertNotNull(updated);
        assertNotNull(failedDocumentIds);
        assertTrue(documentIds.isEmpty());
        assertTrue(updated.isEmpty());
        assertTrue(failedDocumentIds.isEmpty());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        OptOutAuditMetadata metadata = new OptOutAuditMetadata();

        OptOutRequest request = new OptOutRequest();
        request.setTin("123456789");
        OptOutAuditUpdate update = new OptOutAuditUpdate();
        update.setDeliveryMethod("E");

        List<String> documentIds = new ArrayList<>();
        documentIds.add("doc-1");
        List<String> updated = new ArrayList<>();
        updated.add("doc-1");
        List<String> failedDocumentIds = new ArrayList<>();
        failedDocumentIds.add("doc-2");

        metadata.setRecordType("OPTOUT");
        metadata.setOptOutRequest(request);
        metadata.setOptOutUpdate(update);
        metadata.setDocumentIds(documentIds);
        metadata.setUpdated(updated);
        metadata.setFailedDocumentIds(failedDocumentIds);

        assertEquals("OPTOUT", metadata.getRecordType());
        assertSame(request, metadata.getOptOutRequest());
        assertSame(update, metadata.getOptOutUpdate());
        assertSame(documentIds, metadata.getDocumentIds());
        assertSame(updated, metadata.getUpdated());
        assertSame(failedDocumentIds, metadata.getFailedDocumentIds());
    }

    @Test
    public void toStringShouldContainKeyFields() {
        OptOutAuditMetadata metadata = new OptOutAuditMetadata();
        metadata.setRecordType("OPTOUT");
        metadata.getDocumentIds().add("doc-1");
        metadata.getUpdated().add("doc-1");
        metadata.getFailedDocumentIds().add("doc-2");

        String value = metadata.toString();

        assertTrue(value.contains("recordType=OPTOUT"));
        assertTrue(value.contains("documentIds=[doc-1]"));
        assertTrue(value.contains("updated=[doc-1]"));
        assertTrue(value.contains("failedDocumentIds=[doc-2]"));
    }
}

