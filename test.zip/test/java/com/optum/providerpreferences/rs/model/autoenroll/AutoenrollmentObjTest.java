package com.optum.providerpreferences.rs.model.autoenroll;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class AutoenrollmentObjTest {

    @Test
    public void shouldSetAndGetAllFields() {
        AutoenrollmentObj obj = new AutoenrollmentObj();

        obj.setTin("123456789");
        obj.setMpin("987654321");
        obj.setFileName("E2");
        obj.setProviderEmailId("test@example.com");
        obj.setActiveDate("2026-05-22");
        obj.setCorpMpin("111222333");
        obj.setOkTochangePDOInd("Y");
        obj.setAutoEdelUpdateInd("N");

        assertEquals("123456789", obj.getTin());
        assertEquals("987654321", obj.getMpin());
        assertEquals("E2", obj.getFileName());
        assertEquals("test@example.com", obj.getProviderEmailId());
        assertEquals("2026-05-22", obj.getActiveDate());
        assertEquals("111222333", obj.getCorpMpin());
        assertEquals("Y", obj.getOkTochangePDOInd());
        assertEquals("N", obj.getAutoEdelUpdateInd());
    }

    @Test
    public void toStringShouldContainImportantFields() {
        AutoenrollmentObj obj = new AutoenrollmentObj();
        obj.setTin("123456789");
        obj.setMpin("987654321");
        obj.setFileName("E2");
        obj.setProviderEmailId("test@example.com");
        obj.setActiveDate("2026-05-22");
        obj.setCorpMpin("111222333");
        obj.setOkTochangePDOInd("Y");
        obj.setAutoEdelUpdateInd("N");

        String value = obj.toString();

        assertTrue(value.contains("tin=123456789"));
        assertTrue(value.contains("mpin=987654321"));
        assertTrue(value.contains("fileName=E2"));
        assertTrue(value.contains("providerEmailId=test@example.com"));
        assertTrue(value.contains("okTochangePDOInd=Y"));
        assertTrue(value.contains("autoEdelUpdateInd=N"));
    }
}

