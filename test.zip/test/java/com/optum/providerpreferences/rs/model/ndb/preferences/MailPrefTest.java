package com.optum.providerpreferences.rs.model.ndb.preferences;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class MailPrefTest {

    @Test
    public void shouldBuildWithDefaultConstructor() {
        MailPref mailPref = new MailPref();

        assertNull(mailPref.getLetterType());
        assertNull(mailPref.getMailingPref());
    }

    @Test
    public void shouldBuildWithTwoArgConstructor() {
        MailPref mailPref = new MailPref("E2", "ELECTRONIC");

        assertEquals("E2", mailPref.getLetterType());
        assertEquals("ELECTRONIC", mailPref.getMailingPref());
    }

    @Test
    public void shouldSetAndGetLetterType() {
        MailPref mailPref = new MailPref();

        mailPref.setLetterType("E3");

        assertEquals("E3", mailPref.getLetterType());
    }

    @Test
    public void shouldSetAndGetMailingPref() {
        MailPref mailPref = new MailPref();

        mailPref.setMailingPref("PAPER");

        assertEquals("PAPER", mailPref.getMailingPref());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        MailPref mailPref = new MailPref();

        mailPref.setLetterType("E4");
        mailPref.setMailingPref("BOTH");

        assertEquals("E4", mailPref.getLetterType());
        assertEquals("BOTH", mailPref.getMailingPref());
    }

    @Test
    public void shouldHandleNullValues() {
        MailPref mailPref = new MailPref("E2", "ELECTRONIC");

        mailPref.setLetterType(null);
        mailPref.setMailingPref(null);

        assertNull(mailPref.getLetterType());
        assertNull(mailPref.getMailingPref());
    }
}

