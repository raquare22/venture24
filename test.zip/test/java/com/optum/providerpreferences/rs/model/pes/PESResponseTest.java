package com.optum.providerpreferences.rs.model.pes;

import org.junit.Test;

import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class PESResponseTest {

    @Test
    public void shouldSetAndGetMetaAndData() {
        PESResponse response = new PESResponse();
        Meta meta = new Meta();
        TinObject tinObject = new TinObject();

        response.setMeta(meta);
        response.setData(Collections.singletonList(tinObject));

        assertSame(meta, response.getMeta());
        assertEquals(1, response.getData().size());
        assertSame(tinObject, response.getData().get(0));
    }

    @Test
    public void fieldsDefaultToNull() {
        PESResponse response = new PESResponse();

        assertNull(response.getMeta());
        assertNull(response.getData());
    }

    @Test
    public void toStringShouldContainKeyValues() {
        PESResponse response = new PESResponse();
        Meta meta = new Meta();
        meta.setTransactionId("txn");

        Key key = new Key();
        key.setTaxIdNumber("123456789");
        TinObject tinObject = new TinObject();
        tinObject.setKey(key);

        response.setMeta(meta);
        response.setData(Collections.singletonList(tinObject));

        String value = response.toString();

        assertTrue(value.contains("PESResponse"));
        assertTrue(value.contains("transactionId: txn"));
        assertTrue(value.contains("taxIdNumber: 123456789"));
    }
}

