package com.optum.providerpreferences.rs.model.ndb.provider;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class CorpMpinResponseTest {

    @Test
    public void shouldSetAndGetRequestHeader() {
        CorpMpinResponse response = new CorpMpinResponse();
        RequestHeader header = new RequestHeader();
        header.setApplicationId("app1");

        response.setRequestHeader(header);

        assertSame(header, response.getRequestHeader());
        assertNotNull(response.getRequestHeader());
    }

    @Test
    public void shouldSetAndGetResponseHeader() {
        CorpMpinResponse response = new CorpMpinResponse();
        ResponseHeader resHeader = new ResponseHeader();

        response.setResponseHeader(resHeader);

        assertSame(resHeader, response.getResponseHeader());
        assertNotNull(response.getResponseHeader());
    }

    @Test
    public void shouldSetAndGetRequestData() {
        CorpMpinResponse response = new CorpMpinResponse();
        RequestData data = new RequestData();
        data.setTaxIdNumber("123456789");

        response.setRequestData(data);

        assertSame(data, response.getRequestData());
        assertNotNull(response.getRequestData());
    }

    @Test
    public void shouldSetAndGetResponse() {
        CorpMpinResponse response = new CorpMpinResponse();
        ResponseData resData = new ResponseData();

        response.setResponse(resData);

        assertSame(resData, response.getResponse());
        assertNotNull(response.getResponse());
    }

    @Test
    public void shouldHaveAllFieldsNullByDefault() {
        CorpMpinResponse response = new CorpMpinResponse();

        assertNull(response.getRequestHeader());
        assertNull(response.getResponseHeader());
        assertNull(response.getRequestData());
        assertNull(response.getResponse());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        CorpMpinResponse response = new CorpMpinResponse();
        RequestHeader reqHeader = new RequestHeader();
        reqHeader.setApplicationId("app2");
        ResponseHeader resHeader = new ResponseHeader();
        RequestData reqData = new RequestData();
        reqData.setTaxIdNumber("987654321");
        ResponseData resData = new ResponseData();

        response.setRequestHeader(reqHeader);
        response.setResponseHeader(resHeader);
        response.setRequestData(reqData);
        response.setResponse(resData);

        assertSame(reqHeader, response.getRequestHeader());
        assertSame(resHeader, response.getResponseHeader());
        assertSame(reqData, response.getRequestData());
        assertSame(resData, response.getResponse());
    }
}

