package com.optum.providerpreferences.rs.model.linksecurity;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class PSMResponseTest {

    @Test
    public void shouldLazilyInitializeUsersList() {
        PSMResponse response = new PSMResponse();

        List<User> users = response.getUsers();

        assertNotNull(users);
        assertTrue(users.isEmpty());
        assertSame(users, response.getUsers());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        PSMResponse response = new PSMResponse();
        List<User> users = new ArrayList<>();
        User user = new User();
        user.setUserAcctSeqNbr("acct-123");
        users.add(user);

        response.setResult("SUCCESS");
        response.setMessage("ok");
        response.setOptumUuid("uuid-123");
        response.setUsers(users);

        assertEquals("SUCCESS", response.getResult());
        assertEquals("ok", response.getMessage());
        assertEquals("uuid-123", response.getOptumUuid());
        assertSame(users, response.getUsers());
        assertEquals(1, response.getUsers().size());
        assertEquals("acct-123", response.getUsers().get(0).getUserAcctSeqNbr());
    }
}

