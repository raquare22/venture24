package com.optum.providerpreferences.rs.model.pes;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class MetaTest {

    @Test
    public void shouldSetAndGetAllFields() {
        Meta meta = new Meta();

        meta.setTransactionId("txn-1");
        meta.setPageOffset("0");
        meta.setPageLimit("25");
        meta.setTotalRecordCount("100");
        meta.setElapsedTimeMilliseconds("10");
        meta.setSupportContact("support@test.com");

        assertEquals("txn-1", meta.getTransactionId());
        assertEquals("0", meta.getPageOffset());
        assertEquals("25", meta.getPageLimit());
        assertEquals("100", meta.getTotalRecordCount());
        assertEquals("10", meta.getElapsedTimeMilliseconds());
        assertEquals("support@test.com", meta.getSupportContact());
    }

    @Test
    public void fieldsDefaultToNull() {
        Meta meta = new Meta();

        assertNull(meta.getTransactionId());
        assertNull(meta.getPageOffset());
        assertNull(meta.getPageLimit());
        assertNull(meta.getTotalRecordCount());
        assertNull(meta.getElapsedTimeMilliseconds());
        assertNull(meta.getSupportContact());
    }

    @Test
    public void toStringShouldContainFieldValues() {
        Meta meta = new Meta();
        meta.setTransactionId("txn-1");
        meta.setPageOffset("0");

        String value = meta.toString();

        assertTrue(value.contains("transactionId: txn-1"));
        assertTrue(value.contains("pageOffset: 0"));
    }
}

