package com.optum.providerpreferences.rs.model.ndb;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class ProviderOrganizationTest {

    @Test
    public void shouldSetAndGetUhcId() {
        ProviderOrganization org = new ProviderOrganization();

        org.setUhcId("UHC123");

        assertEquals("UHC123", org.getUhcId());
    }

    @Test
    public void shouldSetAndGetRespOrgName() {
        ProviderOrganization org = new ProviderOrganization();

        org.setRespOrgName("Responsible Organization");

        assertEquals("Responsible Organization", org.getRespOrgName());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        ProviderOrganization org = new ProviderOrganization();

        org.setUhcId("UHC456");
        org.setRespOrgName("Test Organization");

        assertEquals("UHC456", org.getUhcId());
        assertEquals("Test Organization", org.getRespOrgName());
    }

    @Test
    public void fieldsDefaultToNull() {
        ProviderOrganization org = new ProviderOrganization();

        assertNull(org.getUhcId());
        assertNull(org.getRespOrgName());
    }

    @Test
    public void shouldHandleNullValues() {
        ProviderOrganization org = new ProviderOrganization();
        org.setUhcId("UHC789");
        org.setRespOrgName("Organization");

        org.setUhcId(null);
        org.setRespOrgName(null);

        assertNull(org.getUhcId());
        assertNull(org.getRespOrgName());
    }

    @Test
    public void toStringShouldContainUhcIdAndRespOrgName() {
        ProviderOrganization org = new ProviderOrganization();
        org.setUhcId("UHC999");
        org.setRespOrgName("MyOrganization");

        String value = org.toString();

        assertTrue(value.contains("uhcId=UHC999"));
        assertTrue(value.contains("respOrgName=MyOrganization"));
        assertTrue(value.contains("ProviderOrganization"));
    }

    @Test
    public void toStringShouldHandleNullValues() {
        ProviderOrganization org = new ProviderOrganization();

        String value = org.toString();

        assertTrue(value.contains("ProviderOrganization"));
        assertTrue(value.contains("null"));
    }

    @Test
    public void shouldUpdateValues() {
        ProviderOrganization org = new ProviderOrganization();

        org.setUhcId("FIRST");
        org.setRespOrgName("First Org");

        assertEquals("FIRST", org.getUhcId());
        assertEquals("First Org", org.getRespOrgName());

        org.setUhcId("SECOND");
        org.setRespOrgName("Second Org");

        assertEquals("SECOND", org.getUhcId());
        assertEquals("Second Org", org.getRespOrgName());
    }
}

