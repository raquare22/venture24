package com.optum.providerpreferences.rs.model.ndb;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class TinsTest {

    @Test
    public void shouldLazilyInitializeTinList() {
        Tins tins = new Tins();

        List<Tin> result = tins.getTinList();

        assertNotNull(result);
        assertTrue(result.isEmpty());
        assertSame(result, tins.getTinList());
    }

    @Test
    public void shouldSetAndGetTinList() {
        Tins tins = new Tins();
        List<Tin> tinList = new ArrayList<>();
        Tin tin = new Tin();
        tin.setTin("123456789");
        tin.setTinType("EIN");
        tinList.add(tin);

        tins.setTinList(tinList);

        assertSame(tinList, tins.getTinList());
        assertEquals(1, tins.getTinList().size());
        assertEquals("123456789", tins.getTinList().get(0).getTin());
        assertEquals("EIN", tins.getTinList().get(0).getTinType());
    }

    @Test
    public void shouldSetAndGetStatusFields() {
        Tins tins = new Tins();

        tins.setStatusCode("200");
        tins.setStatusMessage("Success");

        assertEquals("200", tins.getStatusCode());
        assertEquals("Success", tins.getStatusMessage());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        Tins tins = new Tins();
        List<Tin> tinList = new ArrayList<>();
        Tin tinA = new Tin();
        tinA.setTin("111222333");
        Tin tinB = new Tin();
        tinB.setTin("444555666");
        tinList.add(tinA);
        tinList.add(tinB);

        tins.setTinList(tinList);
        tins.setStatusCode("201");
        tins.setStatusMessage("Created");

        assertSame(tinList, tins.getTinList());
        assertEquals(2, tins.getTinList().size());
        assertEquals("201", tins.getStatusCode());
        assertEquals("Created", tins.getStatusMessage());
    }

    @Test
    public void statusFieldsShouldDefaultToNull() {
        Tins tins = new Tins();

        assertNull(tins.getStatusCode());
        assertNull(tins.getStatusMessage());
    }

    @Test
    public void shouldHandleNullTinListByReturningEmptyList() {
        Tins tins = new Tins();
        tins.setTinList(null);

        List<Tin> result = tins.getTinList();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    public void shouldHandleNullStatusValues() {
        Tins tins = new Tins();
        tins.setStatusCode("OK");
        tins.setStatusMessage("Message");

        tins.setStatusCode(null);
        tins.setStatusMessage(null);

        assertNull(tins.getStatusCode());
        assertNull(tins.getStatusMessage());
    }
}

