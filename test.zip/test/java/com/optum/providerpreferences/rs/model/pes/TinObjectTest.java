package com.optum.providerpreferences.rs.model.pes;

import org.junit.Test;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class TinObjectTest {

    @Test
    public void shouldSetAndGetKey() {
        TinObject tinObject = new TinObject();
        Key key = new Key();
        key.setTaxIdNumber("123456789");

        tinObject.setKey(key);

        assertSame(key, tinObject.getKey());
    }

    @Test
    public void keyShouldDefaultToNull() {
        TinObject tinObject = new TinObject();

        assertNull(tinObject.getKey());
    }

    @Test
    public void toStringShouldContainKeyValues() {
        TinObject tinObject = new TinObject();
        Key key = new Key();
        key.setTaxIdNumber("123456789");
        key.setTaxIdTypeCode("EIN");
        tinObject.setKey(key);

        String value = tinObject.toString();

        assertTrue(value.contains("key"));
        assertTrue(value.contains("taxIdNumber: 123456789"));
        assertTrue(value.contains("taxIdTypeCode: EIN"));
    }
}

