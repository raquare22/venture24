package com.optum.providerpreferences.rs.model.ndb.provider;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class RequestDataTest {

    @Test
    public void shouldBuildWithDefaultConstructor() {
        RequestData data = new RequestData();

        assertNull(data.getTaxIdNumber());
        assertNull(data.getCorpOwnerId());
    }

    @Test
    public void shouldBuildWithTwoArgConstructor() {
        RequestData data = new RequestData("123456789", "corp123");

        assertEquals("123456789", data.getTaxIdNumber());
        assertEquals("corp123", data.getCorpOwnerId());
    }

    @Test
    public void shouldSetAndGetTaxIdNumber() {
        RequestData data = new RequestData();

        data.setTaxIdNumber("987654321");

        assertEquals("987654321", data.getTaxIdNumber());
    }

    @Test
    public void shouldSetAndGetCorpOwnerId() {
        RequestData data = new RequestData();

        data.setCorpOwnerId("corp456");

        assertEquals("corp456", data.getCorpOwnerId());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        RequestData data = new RequestData();

        data.setTaxIdNumber("111222333");
        data.setCorpOwnerId("corp789");

        assertEquals("111222333", data.getTaxIdNumber());
        assertEquals("corp789", data.getCorpOwnerId());
    }

    @Test
    public void shouldHandleNullValues() {
        RequestData data = new RequestData("555666777", "corpABC");

        data.setTaxIdNumber(null);
        data.setCorpOwnerId(null);

        assertNull(data.getTaxIdNumber());
        assertNull(data.getCorpOwnerId());
    }
}

