package com.optum.providerpreferences.rs.model.ndb;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class TinTest {

    @Test
    public void shouldSetAndGetTin() {
        Tin tin = new Tin();

        tin.setTin("123456789");

        assertEquals("123456789", tin.getTin());
    }

    @Test
    public void shouldSetAndGetTinType() {
        Tin tin = new Tin();

        tin.setTinType("EIN");

        assertEquals("EIN", tin.getTinType());
    }

    @Test
    public void shouldSetAndGetProviderType() {
        Tin tin = new Tin();

        tin.setProviderType("INDIVIDUAL");

        assertEquals("INDIVIDUAL", tin.getProviderType());
    }

    @Test
    public void shouldSetAndGetCorpTINFlag() {
        Tin tin = new Tin();

        tin.setCorpTINFlag("Y");

        assertEquals("Y", tin.getCorpTINFlag());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        Tin tin = new Tin();

        tin.setTin("987654321");
        tin.setTinType("SSN");
        tin.setProviderType("GROUP");
        tin.setCorpTINFlag("N");

        assertEquals("987654321", tin.getTin());
        assertEquals("SSN", tin.getTinType());
        assertEquals("GROUP", tin.getProviderType());
        assertEquals("N", tin.getCorpTINFlag());
    }

    @Test
    public void fieldsDefaultToNull() {
        Tin tin = new Tin();

        assertNull(tin.getTin());
        assertNull(tin.getTinType());
        assertNull(tin.getProviderType());
        assertNull(tin.getCorpTINFlag());
    }

    @Test
    public void shouldHandleNullValues() {
        Tin tin = new Tin();
        tin.setTin("1");
        tin.setTinType("2");
        tin.setProviderType("3");
        tin.setCorpTINFlag("4");

        tin.setTin(null);
        tin.setTinType(null);
        tin.setProviderType(null);
        tin.setCorpTINFlag(null);

        assertNull(tin.getTin());
        assertNull(tin.getTinType());
        assertNull(tin.getProviderType());
        assertNull(tin.getCorpTINFlag());
    }
}

