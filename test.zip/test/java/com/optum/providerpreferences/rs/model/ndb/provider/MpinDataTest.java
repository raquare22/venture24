package com.optum.providerpreferences.rs.model.ndb.provider;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class MpinDataTest {

    @Test
    public void shouldSetAndGetTaxIdTypeCode() {
        MpinData data = new MpinData();

        data.setTaxIdTypeCode("T");

        assertEquals("T", data.getTaxIdTypeCode());
    }

    @Test
    public void shouldSetAndGetProviderId() {
        MpinData data = new MpinData();

        data.setProviderId("provider1");

        assertEquals("provider1", data.getProviderId());
    }

    @Test
    public void shouldSetAndGetProvFstNm() {
        MpinData data = new MpinData();

        data.setProvFstNm("John");

        assertEquals("John", data.getProvFstNm());
    }

    @Test
    public void shouldSetAndGetProvLstNm() {
        MpinData data = new MpinData();

        data.setProvLstNm("Doe");

        assertEquals("Doe", data.getProvLstNm());
    }

    @Test
    public void shouldSetAndGetEpsCd() {
        MpinData data = new MpinData();

        data.setEpsCd("EPS123");

        assertEquals("EPS123", data.getEpsCd());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        MpinData data = new MpinData();

        data.setTaxIdTypeCode("T");
        data.setProviderId("provider2");
        data.setProvFstNm("Jane");
        data.setProvLstNm("Smith");
        data.setEpsCd("EPS456");

        assertEquals("T", data.getTaxIdTypeCode());
        assertEquals("provider2", data.getProviderId());
        assertEquals("Jane", data.getProvFstNm());
        assertEquals("Smith", data.getProvLstNm());
        assertEquals("EPS456", data.getEpsCd());
    }

    @Test
    public void shouldHandleNullValues() {
        MpinData data = new MpinData();

        data.setTaxIdTypeCode(null);
        data.setProviderId(null);
        data.setProvFstNm(null);
        data.setProvLstNm(null);
        data.setEpsCd(null);

        assertNull(data.getTaxIdTypeCode());
        assertNull(data.getProviderId());
        assertNull(data.getProvFstNm());
        assertNull(data.getProvLstNm());
        assertNull(data.getEpsCd());
    }

    @Test
    public void fieldsDefaultToNull() {
        MpinData data = new MpinData();

        assertNull(data.getTaxIdTypeCode());
        assertNull(data.getProviderId());
        assertNull(data.getProvFstNm());
        assertNull(data.getProvLstNm());
        assertNull(data.getEpsCd());
    }
}

