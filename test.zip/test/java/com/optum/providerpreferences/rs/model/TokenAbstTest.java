package com.optum.providerpreferences.rs.model;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class TokenAbstTest {

    private static class TestTokenAbst extends TokenAbst {
    }

    @Test
    public void shouldCreateConcreteSubclassInstance() {
        TokenAbst token = new TestTokenAbst();

        assertNotNull(token);
        assertSame(TestTokenAbst.class, token.getClass());
    }

    @Test
    public void accessTokenShouldDefaultToNull() {
        TokenAbst token = new TestTokenAbst();

        assertNull(token.getAccessToken());
    }

    @Test
    public void shouldSetAndGetAccessToken() {
        TokenAbst token = new TestTokenAbst();

        token.setAccessToken("token-123");

        assertEquals("token-123", token.getAccessToken());
    }

    @Test
    public void shouldAllowSettingAccessTokenToNull() {
        TokenAbst token = new TestTokenAbst();
        token.setAccessToken("token-123");

        token.setAccessToken(null);

        assertNull(token.getAccessToken());
    }

    @Test
    public void shouldDeserializeUsingAnnotatedAccessTokenProperty() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        String json = "{\"access_token\":\"json-access\"}";

        TestTokenAbst token = mapper.readValue(json, TestTokenAbst.class);

        assertNotNull(token);
        assertEquals("json-access", token.getAccessToken());
    }

    @Test
    public void shouldSerializeUsingAnnotatedAccessTokenProperty() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        TestTokenAbst token = new TestTokenAbst();
        token.setAccessToken("serialized-access");

        String json = mapper.writeValueAsString(token);

        org.junit.Assert.assertTrue(json.contains("\"access_token\":\"serialized-access\""));
    }
}


