package com.optum.providerpreferences.rs.model;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class ProviderPreferenceUpdateResponseTest {

    @Test
    public void shouldCreateInstance() {
        ProviderPreferenceUpdateResponse response = new ProviderPreferenceUpdateResponse();

        assertNotNull(response);
        assertEquals(ProviderPreferenceUpdateResponse.class, response.getClass());
    }

    @Test
    public void shouldSetAndGetInheritedStatusFields() {
        ProviderPreferenceUpdateResponse response = new ProviderPreferenceUpdateResponse();

        response.setStatusCode("200");
        response.setStatusMessage("Updated successfully");

        assertEquals("200", response.getStatusCode());
        assertEquals("Updated successfully", response.getStatusMessage());
    }

    @Test
    public void inheritedFieldsShouldDefaultToNull() {
        ProviderPreferenceUpdateResponse response = new ProviderPreferenceUpdateResponse();

        assertNull(response.getStatusCode());
        assertNull(response.getStatusMessage());
    }
}


