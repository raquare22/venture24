package com.optum.providerpreferences.rs.model.ndb;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class NDBProvidersTest {

    @Test
    public void shouldLazilyInitializeProviderList() {
        NDBProviders providers = new NDBProviders();

        List<NDBProvider> providerList = providers.getProviderList();

        assertNotNull(providerList);
        assertTrue(providerList.isEmpty());
        assertSame(providerList, providers.getProviderList());
    }

    @Test
    public void shouldSetAndGetProviderList() {
        NDBProviders providers = new NDBProviders();
        List<NDBProvider> providerList = new ArrayList<>();
        NDBProvider provider = new NDBProvider();
        provider.setName("Provider1");
        provider.setMpin("MPIN1");
        providerList.add(provider);

        providers.setProviderList(providerList);

        assertSame(providerList, providers.getProviderList());
        assertEquals(1, providers.getProviderList().size());
        assertEquals("Provider1", providers.getProviderList().get(0).getName());
        assertEquals("MPIN1", providers.getProviderList().get(0).getMpin());
    }

    @Test
    public void shouldSetAndGetStatusCode() {
        NDBProviders providers = new NDBProviders();

        providers.setStatusCode("200");

        assertEquals("200", providers.getStatusCode());
    }

    @Test
    public void shouldSetAndGetStatusMessage() {
        NDBProviders providers = new NDBProviders();

        providers.setStatusMessage("Success");

        assertEquals("Success", providers.getStatusMessage());
    }

    @Test
    public void shouldSetAndGetAllFields() {
        NDBProviders providers = new NDBProviders();
        List<NDBProvider> providerList = new ArrayList<>();
        NDBProvider provider1 = new NDBProvider();
        provider1.setName("Provider1");
        NDBProvider provider2 = new NDBProvider();
        provider2.setName("Provider2");
        providerList.add(provider1);
        providerList.add(provider2);

        providers.setProviderList(providerList);
        providers.setStatusCode("201");
        providers.setStatusMessage("Created");

        assertSame(providerList, providers.getProviderList());
        assertEquals(2, providers.getProviderList().size());
        assertEquals("201", providers.getStatusCode());
        assertEquals("Created", providers.getStatusMessage());
    }

    @Test
    public void statusFieldsDefaultToNull() {
        NDBProviders providers = new NDBProviders();

        assertNull(providers.getStatusCode());
        assertNull(providers.getStatusMessage());
    }

    @Test
    public void shouldHandleNullValues() {
        NDBProviders providers = new NDBProviders();
        List<NDBProvider> providerList = new ArrayList<>();
        NDBProvider provider = new NDBProvider();
        providerList.add(provider);

        providers.setProviderList(providerList);
        providers.setStatusCode("OK");
        providers.setStatusMessage("Msg");

        providers.setProviderList(null);
        providers.setStatusCode(null);
        providers.setStatusMessage(null);

        assertNotNull(providers.getProviderList());
        assertTrue(providers.getProviderList().isEmpty());
        assertNull(providers.getStatusCode());
        assertNull(providers.getStatusMessage());
    }

    @Test
    public void shouldAddMultipleProviders() {
        NDBProviders providers = new NDBProviders();

        providers.getProviderList().add(createProvider("ProvA", "MPINA"));
        providers.getProviderList().add(createProvider("ProvB", "MPINB"));
        providers.getProviderList().add(createProvider("ProvC", "MPINC"));

        assertEquals(3, providers.getProviderList().size());
        assertEquals("ProvA", providers.getProviderList().get(0).getName());
        assertEquals("ProvC", providers.getProviderList().get(2).getName());
    }

    private NDBProvider createProvider(String name, String mpin) {
        NDBProvider provider = new NDBProvider();
        provider.setName(name);
        provider.setMpin(mpin);
        return provider;
    }
}

