package com.optum.providerpreferences.rs.model.linksecurity;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class PSMRequestTest {

    @Test
    public void shouldSetAndGetAllFields() {
        PSMRequest request = new PSMRequest();

        request.setOptumUuid("uuid-123");
        request.setSource("PORTAL");
        request.setVerifySource(true);

        assertEquals("uuid-123", request.getOptumUuid());
        assertEquals("PORTAL", request.getSource());
        assertTrue(request.isVerifySource());
    }

    @Test
    public void verifySourceShouldDefaultToFalse() {
        PSMRequest request = new PSMRequest();

        assertFalse(request.isVerifySource());
    }
}

