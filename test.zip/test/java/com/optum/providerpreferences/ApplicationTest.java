package com.optum.providerpreferences;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.mockito.MockedConstruction;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.http.HttpHeaders;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockConstruction;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class ApplicationTest {

    private final Application application = new Application();

    @Test
    public void getMapperShouldReturnNonNullObjectMapper() {
        ObjectMapper mapper = application.getMapper();

        assertNotNull(mapper);
    }

    @Test
    public void getHttpHeadersShouldReturnNonNullHttpHeaders() {
        HttpHeaders headers = application.getHttpHeaders();

        assertNotNull(headers);
    }

    @Test
    public void getMapperShouldReturnNewInstanceEachTime() {
        ObjectMapper first = application.getMapper();
        ObjectMapper second = application.getMapper();

        assertNotNull(first);
        assertNotNull(second);
        assertNotSame(first, second);
    }

    @Test
    public void getHttpHeadersShouldReturnEmptyHeadersByDefault() {
        HttpHeaders headers = application.getHttpHeaders();

        assertNotNull(headers);
        assertTrue(headers.isEmpty());
    }

    @Test
    public void getHttpHeadersShouldReturnNewInstanceEachTime() {
        HttpHeaders first = application.getHttpHeaders();
        HttpHeaders second = application.getHttpHeaders();

        assertNotNull(first);
        assertNotNull(second);
        assertNotSame(first, second);
    }

    @Test
    public void mainShouldCreateSpringApplicationAddListenerAndRun() {
        String[] args = new String[] {"--spring.main.web-application-type=none"};
        List<Object> constructorArgs = new ArrayList<>();

        try (MockedConstruction<SpringApplication> mocked = mockConstruction(SpringApplication.class,
                (mock, context) -> {
                    constructorArgs.addAll(context.arguments());
                    when(mock.run(any(String[].class))).thenReturn(mock(ConfigurableApplicationContext.class));
                })) {

            Application.main(args);

            org.junit.Assert.assertEquals(1, mocked.constructed().size());
            SpringApplication springApplication = mocked.constructed().get(0);
            assertNotNull(constructorArgs.get(0));
            Class<?>[] primarySources = (Class<?>[]) constructorArgs.get(0);
            org.junit.Assert.assertEquals(1, primarySources.length);
            assertSame(Application.class, primarySources[0]);
            verify(springApplication).addListeners(any(AppListener.class));
            verify(springApplication).run(eq(args));
        }
    }
}

