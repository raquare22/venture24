package com.optum.data;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;

public class Converter
{

    public static ProviderPreferencesObj ConvertToJsonObject(String fileName)
    {
        ObjectMapper mapper = new ObjectMapper();
        fileName = "src/test/resources/com/optum/data/" + fileName;

        try
        {
            return mapper.readValue(new File(fileName), ProviderPreferencesObj.class);

        }
        catch (JsonGenerationException e)
        {
            e.printStackTrace();
        }
        catch (JsonMappingException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return null;
    }
}
