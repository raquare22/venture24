
package com.cucumber.runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;

//@RunWith(Cucumber.class)

@CucumberOptions(features = "src/test/resources/com/optum/cucumber", tags = "@cacf,@oauth,@passwordOwnerInfo,@provPrefs,@utility,@FDS,@NDB,@updateletterPrefsNDB,@updateLetterPrefsFDS,@getLetterPrefsFDS,@reqTimeout,@autoEnroll,@SFTP,@optOut,@FDSCloud,@oauthRefreshFDS,@emailListDrop",
        glue = { "com/cucumber/steps" }, plugin = { "pretty", "json:target/surefire-reports/CucumberReport.json",
        "junit:target/surefire-reports/CucumberReport.xml" })
public class CucumberRunnerTest
{

}