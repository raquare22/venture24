package com.cucumber.steps.oauth2;

import org.junit.Assert;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.providerpreferences.rs.handler.Oauth2Handler;
import com.optum.providerpreferences.rs.model.Token;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OauthTokenTest
{
    private static final Logger LOGGER = LoggerFactory.getLogger(OauthTokenTest.class);

    String sessionId;
    Oauth2Handler oauthHandler = Oauth2Handler.getInstance();
    Oauth2Handler oauthHandler2 = Oauth2Handler.getInstance();
    
    Token responseToken;
    Token responseToken2;
    Token responseTokenAfter1Sec;
    Token responseTokenAfter6Sec;
    Token responseToken2Plus;
    
    @Given("^a \"(.*?)\"$")
    public void a(String sessionId) throws Throwable
    {
        this.sessionId = sessionId;
    }

    @When("^I attempt to get a token for \"(.*?)\"$")
    public void i_attempt_to_get_a_token_for(String serviceIndicator) throws Throwable
    {
        //FDS=1800
        long setTimeLeftBeforeTokenExpires = 1795L;
        if (serviceIndicator.equals("LINK") || serviceIndicator.equals("PSM")) {
            setTimeLeftBeforeTokenExpires = 7195L;
        }
//        oauthHandler.setTimeLeftBeforeTokenExpires(setTimeLeftBeforeTokenExpires);
        responseToken = (Token) oauthHandler.getOauthToken(sessionId, serviceIndicator);

        LOGGER.info("{}: responseToken.getAccess_token={}, responseToken={}", Encode.forJava(serviceIndicator), Encode.forJava(responseToken.getAccessToken()), Encode.forJava(responseToken.toString()));
        responseToken2 = (Token) oauthHandler2.getOauthToken(sessionId, serviceIndicator);
        LOGGER.info("{}: responseToken2={}", serviceIndicator, Encode.forJava(responseToken2.getAccessToken()));
        LOGGER.info("{}: Sleeping 1 second", serviceIndicator);
        Thread.sleep(1000);
        responseTokenAfter1Sec = (Token) oauthHandler.getOauthToken(sessionId, serviceIndicator);
        LOGGER.info("{}: responseTokenAfter1Sec={}", serviceIndicator, Encode.forJava(responseTokenAfter1Sec.getAccessToken()));
        LOGGER.info("{}: Sleeping 5 seconds", serviceIndicator);
        Thread.sleep(5000);
        responseTokenAfter6Sec = (Token) oauthHandler.getOauthToken(sessionId, serviceIndicator);
        LOGGER.info("{}: responseTokenAfter6Sec={}", serviceIndicator, Encode.forJava(responseTokenAfter6Sec.getAccessToken()));
        responseToken2Plus = (Token) oauthHandler2.getOauthToken(sessionId, serviceIndicator);
        LOGGER.info("{}: responseToken2Plus={}", serviceIndicator, Encode.forJava(responseToken2Plus.getAccessToken()));
    }

    @Then("^I should be successful retrieving a token$")
    public void i_should_be_successful_retrieving_a_token() throws Throwable
    {
        LOGGER.info("token={}, token2={}, responseTokenAfter1Sec={}, responseTokenAfter6Sec={}, token={}",
                Encode.forJava(responseToken.getAccessToken()), Encode.forJava(responseToken2.getAccessToken()), Encode.forJava(responseTokenAfter1Sec.getAccessToken()),
            Encode.forJava(responseTokenAfter6Sec.getAccessToken()), Encode.forJava(responseToken.toString()));
        Assert.assertEquals(oauthHandler,oauthHandler2);
        Assert.assertNotNull(responseToken);
        Assert.assertNotNull(responseToken.getAccessToken());
        Assert.assertNotNull(responseToken2);
        Assert.assertNotNull(responseToken2.getAccessToken());
        Assert.assertEquals(responseToken.getAccessToken(), responseToken2.getAccessToken());
        Assert.assertEquals(responseToken.getAccessToken(), responseTokenAfter1Sec.getAccessToken());
        Assert.assertNotEquals(responseToken.getAccessToken(), responseTokenAfter6Sec.getAccessToken());
        Assert.assertEquals(responseTokenAfter6Sec.getAccessToken(), responseToken2Plus.getAccessToken());

    }
}
