package com.cucumber.steps.utilities;

import java.util.Date;

import com.optum.providerpreferences.rs.utility.Converter;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ConvertDateToStringTest
{

    String dateString;

    Date date;

    @Given("^a date in string format$")
    public void a_date_in_string_format() throws Throwable
    {
        dateString = "Mon May 22 21:24:52 UTC 2017";
    }

    @When("^I attempt to convert from string to date$")
    public void i_attempt_to_convert_from_string_to_date() throws Throwable
    {
        date = Converter.convertStringToDate(dateString);
    }

    @Then("^I should be successful;$")
    public void i_should_be_successful() throws Throwable
    {
        System.out.println(date);
    }
}
