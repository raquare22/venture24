package com.cucumber.steps.utilities;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.PasswordOwnerInfo;
import com.optum.providerpreferences.rs.model.linksecurity.User;
import com.optum.providerpreferences.rs.utility.PasswordOwnerUtil;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CompilePasswordOwnerInfoTest
{
    ObjectMapper tempMapper = new ObjectMapper();

    PasswordOwnerUtil util = new PasswordOwnerUtil();

    String givenOptumUUID;

    List<PasswordOwnerInfo> givenUsersPasswordOwnerInfoList;

    List<User> givenProfiles;

    String givenSessionId;

    User givenUser;

    PasswordOwner actualResult;

    List<PasswordOwnerInfo> expectedProviders = null;

    List<PasswordOwnerInfo> expectedCorporates = null;
    
    @Given("^a table of gathered User/Password Owner Info$")
    public void a_table_of_gathered_User_Password_Owner_Info(List<String> givenParams) throws Throwable
    {
        givenUsersPasswordOwnerInfoList = new ArrayList<PasswordOwnerInfo>();
        givenProfiles = new ArrayList<User>();
        this.givenOptumUUID = givenParams.get(0);
        for (int i = 0; i < givenParams.get(2).split(",").length; i++)
        {
            PasswordOwnerInfo tempInfoHolder = new PasswordOwnerInfo();
            tempInfoHolder.setTin(givenParams.get(1));
            tempInfoHolder.setUhcID(givenParams.get(2).split(",")[i]);
            tempInfoHolder.setMpin(givenParams.get(3).split(",")[i]);
            tempInfoHolder.setProviderName(givenParams.get(4));
            tempInfoHolder.setCorporateName(givenParams.get(5).split(",")[i]);
            tempInfoHolder.setOrganizationName(givenParams.get(6));

            givenUsersPasswordOwnerInfoList.add(tempInfoHolder);
        }

        givenUser = new User();
        givenUser.setUserAcctSeqNbr(givenParams.get(7));
        givenUser.setB2cUserId(givenParams.get(8));
        givenUser.setAccessProfile(givenParams.get(9));
        givenUser.setStatusCode(givenParams.get(10));
        givenUser.setStatusDesc(givenParams.get(11));
        givenUser.setAccountType(givenParams.get(12));
        givenUser.setAccountDesc(givenParams.get(13));
        givenUser.setDept(givenParams.get(14));
        givenUser.setOrgType(givenParams.get(15));
        givenUser.setTitle(givenParams.get(16));
        givenUser.setState(givenParams.get(17));
        givenUser.setZipCode(givenParams.get(18));
        givenUser.setRoleId(givenParams.get(19));
        givenUser.setRoleDesc(givenParams.get(20));
        givenUser.setRespOrgMpin(givenParams.get(21));
        if (givenParams.get(22).equalsIgnoreCase("true"))
        {
            givenUser.setHasAccessProfiles(true);
        }
        else
            givenUser.setHasAccessProfiles(false);

        givenProfiles.add(givenUser);

        this.givenSessionId = givenParams.get(23);

    }
    
    @When("^I compile the password owner info$")
    public void i_compile_the_password_owner_info() throws Throwable
    {
        actualResult = util.compilePasswordOwnerInfo(givenOptumUUID, givenUsersPasswordOwnerInfoList, givenProfiles, givenSessionId);

    }
    
    @Then("^I should get should match the response table$")
    public void i_should_get_should_match_the_response_table(List<String> expectedResults) throws Throwable
    {
        PasswordOwner expectedPasswordOwner = new PasswordOwner();
        expectedPasswordOwner.setOptumUUID(expectedResults.get(0));
        expectedPasswordOwner.setTin(expectedResults.get(1));
        expectedPasswordOwner.setUhcID(expectedResults.get(2));
        expectedPasswordOwner.setMpin(expectedResults.get(3));

        // Providers is empty in the current example in the feature file
        // expectedProviders = new ArrayList<PasswordOwnerInfo>();
        expectedPasswordOwner.setProviders(expectedProviders);

        expectedCorporates = new ArrayList<PasswordOwnerInfo>();
        PasswordOwnerInfo tempExpectedCorporatePasswordOwnerInfo = new PasswordOwnerInfo();
        tempExpectedCorporatePasswordOwnerInfo.setCorporateName(expectedResults.get(5).split(",")[0]);
        tempExpectedCorporatePasswordOwnerInfo.setMpin(expectedResults.get(5).split(",")[1]);
        tempExpectedCorporatePasswordOwnerInfo.setOrganizationName(expectedResults.get(5).split(",")[2]);
        tempExpectedCorporatePasswordOwnerInfo.setProviderName(expectedResults.get(5).split(",")[3]);
        tempExpectedCorporatePasswordOwnerInfo.setTin(expectedResults.get(5).split(",")[4]);
        tempExpectedCorporatePasswordOwnerInfo.setUhcID(expectedResults.get(5).split(",")[5]);
        expectedCorporates.add(tempExpectedCorporatePasswordOwnerInfo);

        expectedPasswordOwner.setCorporates(expectedCorporates);

        Assert.assertEquals(expectedPasswordOwner.getOptumUUID(), actualResult.getOptumUUID());
        for (int i = 0; i < expectedPasswordOwner.getCorporates().size(); i++)
        {
            Assert.assertEquals(expectedPasswordOwner.getCorporates().get(i).getCorporateName(), actualResult.getCorporates().get(i).getCorporateName());
            Assert.assertEquals(expectedPasswordOwner.getCorporates().get(i).getUhcID(), actualResult.getCorporates().get(i).getUhcID());
            Assert.assertEquals(expectedPasswordOwner.getCorporates().get(i).getMpin(), actualResult.getCorporates().get(i).getMpin());
        }

        System.out.println("temp pause");
    }
}
