package com.cucumber.steps.utilities;

import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.handler.RequestFactory;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.fds.FDSResponse;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import com.optum.providerpreferences.rs.service.ProviderPreferenceServiceImpl;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RequestTimeoutTest {
	
	ObjectMapper tempMapper = new ObjectMapper();
	
    String tin;

    String mpin;
    
    String classifier;
    
    String timeout;
    
    String timeoutType;
    
    ProviderPreferencesObj providerPreferences;

    ProviderPreferenceServiceImpl serviceProvider = new ProviderPreferenceServiceImpl();

    List<String> expectedDocIds;

    List<String> expectedErrors;
    
    Exception receivedError;
    
    private RequestFactory requestFactory = new RequestFactory();
    private RestTemplate restTemplate = requestFactory.restTemplate();
    private HttpHeaders headers = new HttpHeaders();
	
	private static final Logger logger = LoggerFactory.getLogger(RequestTimeoutTest.class);

	@Given("^the following information \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", and \"(.*?)\"$")
	public void the_following_information_and(
		String mpin, String tin, String classifier, String timeout, String timeoutType) throws Throwable {
      this.tin = tin;
      this.mpin = mpin;
      this.classifier = classifier;
      this.timeout = timeout;
      this.timeoutType = timeoutType;
	}

	@When("^I call the preference service and aggregate the data$")
	public void i_call_the_preference_service_and_aggregate_the_data() throws Throwable {
		
		    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		    HttpEntity<String> entity = new HttpEntity<String>(headers);
			if (timeoutType.equalsIgnoreCase("connect") && Integer.valueOf(timeout) < 5000) {
				String url = "http://localhost:8000";
				HttpURLConnection.setFollowRedirects(false);
				HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
				try {
			        con.setRequestMethod("HEAD");
			        con.setConnectTimeout(Integer.valueOf(timeout)); //set timeout to 5 seconds
			        
			        restTemplate.exchange(url, HttpMethod.GET, entity, FDSResponse.class);
			        
			        
//			        System.out.println(con.getResponseCode());
				}
				catch (Exception e) {
					receivedError = e; 
					e.printStackTrace();
				}
//				catch (ConnectException e) {
//					receivedError = e; 
//					e.printStackTrace();
//				}
			}
			else if (timeoutType.equalsIgnoreCase("read")) {
				logger.info("Overwriting Read timeout={}", timeout);
				updateEnv("PDO_READ_TIMEOUT", timeout);
				try {
			        HttpHeaders headers = new HttpHeaders();
			        headers.add("sm_serversessionid", "1234");
			        LogMessage logMessage = new LogMessage();
			        logMessage.setUsername("CUCUMBERTEST");
			        logMessage.setActor(classifier);
			        providerPreferences = serviceProvider.getProviderPreferences(tin, mpin, headers, logMessage);
			        System.out.println("Provider Preferences returned: "+providerPreferences.toString());
				}
					
				catch (Exception e) {
					receivedError = e; 
					e.printStackTrace();
				}
			}
			// 5000 connect
			else {
				logger.info("Overwriting Connect timeout={}", timeout);
				updateEnv("PDO_CONNECT_TIMEOUT", timeout);
				logger.info(System.getenv("PDO_CONNECT_TIMEOUT"));
				try {
			        HttpHeaders headers = new HttpHeaders();
			        headers.add("sm_serversessionid", "1234");
			        LogMessage logMessage = new LogMessage();
			        logMessage.setUsername("CUCUMBERTEST");
			        logMessage.setActor(classifier);
			        providerPreferences = serviceProvider.getProviderPreferences(tin, mpin, headers, logMessage);
			        System.out.println("Provider Preferences returned: "+providerPreferences.toString());
				}
					
				catch (Exception e) {
					receivedError = e; 
					e.printStackTrace();
				}
			}
			
        
        

        
	}

	@Then("^I should get back the corresponding message with the following response: \"(.*?)\", and \"(.*?)\"$")
	public void i_should_get_back_the_corresponding_message_with_the_following_response_and(String expectedDocIds, String expectedErrors) throws Throwable {
		
        this.expectedDocIds = buildArrayOfExpectedValues(expectedDocIds);
        this.expectedErrors = buildArrayOfExpectedValues(expectedErrors);
        
        if (receivedError != null) {
        	if (receivedError.getCause() != null) {
        		Assert.assertEquals(expectedErrors, receivedError.getCause().getClass().getName());
        	}
        	else {
        		Assert.assertEquals(expectedErrors, receivedError.getClass().getName());
        	}
        }
        else {
            
          List<PreferenceType> preferences = providerPreferences.getPreferenceTypes();
  
          for (PreferenceType currentPref : preferences)
          {
              Assert.assertEquals(expectedDocIds, currentPref.getDocumentId());
          }
        }
        
	}
	
    private List<String> buildArrayOfExpectedValues(String expectedValue)
    {
        String resultArray[] = expectedValue.split(",");
        if (resultArray.length == 0)
        {
            return new ArrayList<String>();
        }
        else
        {
            return Arrays.asList(resultArray);
        }

    }
	
    @SuppressWarnings({ "unchecked" })
    public static void updateEnv(String name, String val) throws ReflectiveOperationException {
      Map<String, String> env = System.getenv();
      Field field = env.getClass().getDeclaredField("m");
      field.setAccessible(true);
      ((Map<String, String>) field.get(env)).put(name, val);
    }

	
}