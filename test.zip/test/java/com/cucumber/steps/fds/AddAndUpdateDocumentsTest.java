package com.cucumber.steps.fds;

import java.util.List;
import java.io.IOException;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.handler.Oauth2Handler;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSResponse;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.utility.ClassifierDescription;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddAndUpdateDocumentsTest {
	
    private final static String SESSION_ID_ALL = "allUpdate";

    private final static String SESSION_ID_SPECIFIC = "specificUpdate";
    
    private static Logger LOGGER = LoggerFactory.getLogger(AddAndUpdateDocumentsTest.class);
    
    private HttpHeaders headers = new HttpHeaders();
    
    ObjectMapper mapper = new ObjectMapper();
    
    Oauth2Handler oauth2handler = Oauth2Handler.getInstance();
    
    String messageString;
    
    ProviderPreferencesObj obj;
    PreferenceType pref;
    

    List<String> givenMpins;
    String givenMpin;
    String givenTin;

    FDSResponse actualFDSResponse;
    
    ResponseEntity<Document> response;

    FDSHandler fdsHandler = new FDSHandler();

    @Given("^a queue message \"(.*?)\"$")
    public void a_queue_message(String msg) throws Throwable {
    	
        this.messageString = msg;
        
        this.obj = mapper.readValue(messageString, ProviderPreferencesObj.class);
        this.pref = obj.getPreferenceTypes().get(0);
        
        this.givenMpins = obj.getSelectedProviders();
        this.givenMpin = givenMpins.get(0);
        System.out.println("hello: " + this.givenMpin);
        this.givenTin = obj.getCorporateTin();

    }
    
    
    @When("^I call the documents service$")
    public void i_call_the_documents_service() throws Throwable {
    	
    	
    	Token fdsToken = (Token) oauth2handler.getOauthToken(SESSION_ID_SPECIFIC, "FDS");
    	headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        
        actualFDSResponse = fdsHandler.getDocumentListSortCreated(givenTin, givenMpin, pref.getClassifier(), "1234", fdsToken);

        
        Assert.assertNotNull(actualFDSResponse);
        System.out.println(mapper.writeValueAsString(actualFDSResponse));
        List<Document> actualDocList = actualFDSResponse.getDocuments();
        System.out.println(mapper.writeValueAsString("Number of Documents found: " + actualDocList.size()));       
        
        int lenDocs = actualDocList.size();
        
        Assert.assertTrue(lenDocs >= 0);
        
        MultiValueMap<String, Document> docsMapToSend = new LinkedMultiValueMap<>();
        Document docToSend;
        String docId;
        
        if (lenDocs > 0) {
        	int docIndex = -1;
        	OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);
        	
        	AutoEnrollment doc0 = determineDocumentIndex(actualDocList, lenDocs, 0, currentDate);
        	AutoEnrollment doc1;
        	
        	if (lenDocs == 1) {
        		// only 1 document
        		if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {  // document is pre-autoenrollment doc or autoenrollment doc and its past active date
        			docIndex = 0;
        		} else if (doc0.isAutoEnrollment && !doc0.isValidAutoEnrollment()) {
        			docIndex = -2;
        		}
        		
        	} else {
        		// 2 documents, pick the autoenrollment one if after active date, pick pre-autoenrollment one if before active date
        		doc1 = determineDocumentIndex(actualDocList, lenDocs, 1, currentDate);
				docIndex = determineMulti(doc0, doc1);
        	}

        	System.out.println("docIndex: " + docIndex);
        	
        	if (docIndex >= 0) {
        		// creating docToSend
        		docId = actualDocList.get(docIndex).getId();
        		String activeDate = actualDocList.get(docIndex).getMetadata().getActiveDate();
        		docToSend = createDocToSend(pref, padWithLeadingZeros(givenMpin), givenTin, docId, activeDate);
        		docToSend.setSpaceId(System.getenv("SPACE_ID"));
        		docsMapToSend.add("documents", docToSend);
        		
        		try {
                	System.out.println("Trying to update document");
                	response = fdsHandler.callFDSPutDocument(docsMapToSend, headers, docId, SESSION_ID_ALL, fdsToken);
                } catch (Exception e) {
                    LOGGER.error("ERROR UPDATING DOCUMENT ID, documentID={}", docToSend.getId());
                }
        	}
        	
        	if (docIndex == -2) {
        		// no pre-autoenrollment document in FDS, must create with null docId and null activeDate
        		docToSend = createDocToSend(pref, padWithLeadingZeros(givenMpin), givenTin, null, null);
            	docToSend.setSpaceId(System.getenv("SPACE_ID"));
            	docsMapToSend.add("documents", docToSend);

            	try {
                	System.out.println("Trying to post pre-autoenroll document");
                    response = fdsHandler.callFDSPostDocument(docsMapToSend, headers, SESSION_ID_ALL, fdsToken);
                } catch (Exception e) {
                    LOGGER.error("ERROR ADDING TEST DOCUMENT FOR MPIN: " + docToSend.getMetadata().getMpin());
                }
        		
        	}
        	
        } else {
        	// no document in FDS, must create with null docId and activeDate
        	docToSend = createDocToSend(pref, padWithLeadingZeros(givenMpin), givenTin, null, null);
        	docToSend.setSpaceId(System.getenv("SPACE_ID"));
        	docsMapToSend.add("documents", docToSend);

        	try {
            	System.out.println("Trying to post document");
                response = fdsHandler.callFDSPostDocument(docsMapToSend, headers, SESSION_ID_ALL, fdsToken);
            } catch (Exception e) {
                LOGGER.error("ERROR ADDING TEST DOCUMENT FOR MPIN: " + docToSend.getMetadata().getMpin());
            }
        }
        
        Assert.assertNotNull(response);
        System.out.println("response: " + response.toString());
        Assert.assertEquals(200, response.getStatusCode().value());
        
              
    }
    
    @Then("^I call the getDocumentList service$")
    public void i_call_the_getDocumentList_service() throws Throwable {
    	Token fdsToken = (Token) oauth2handler.getOauthToken(SESSION_ID_ALL, "FDS");
    	
        actualFDSResponse = fdsHandler.getDocumentList(givenTin, givenMpin, pref.getClassifier(), "1234", fdsToken);
    }

    @Then("^I receive an FDSResponse with the correct list of documents: \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\"$")
    public void i_receive_an_FDSResponse_with_the_correct_list_of_documents(String expectedFileName, String expectedFileType, String expectedProvEmail, String expectedFrequency,
            String expectedDeliveryMethod) throws Throwable
    {
        Assert.assertNotNull(actualFDSResponse);
        System.out.println(mapper.writeValueAsString(actualFDSResponse));
        List<Document> actualDocList = actualFDSResponse.getDocuments();
        System.out.println(mapper.writeValueAsString("Number of Documents returned: " + actualDocList.size()));
                
        int lenDocs = actualDocList.size();
        Assert.assertTrue(lenDocs > 0);

        
        int docIndex = -1;
    	OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);
    	
    	AutoEnrollment doc0 = determineDocumentIndex(actualDocList, lenDocs, 0, currentDate);
    	AutoEnrollment doc1;
    	
    	if (lenDocs == 1) {
    		// only 1 document
    		if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {  // document is pre-autoenrollment doc or autoenrollment doc and its past active date
    			docIndex = 0;
    		}
    		
    	} else {
    		// 2 documents, pick the autoenrollment one if after active date, pick pre-autoenrollment one if before active date
    		doc1 = determineDocumentIndex(actualDocList, lenDocs, 1, currentDate);
			docIndex = determineMulti(doc0, doc1);
    	}

    	if (docIndex >= 0) {
    		// creating docToSend
    		Document doc = actualDocList.get(docIndex);
        	Metadata meta = doc.getMetadata();
        	
        	Assert.assertEquals(expectedFileName, meta.getFileName());
        	Assert.assertEquals(expectedFileType, meta.getFileType());
            Assert.assertEquals(expectedFrequency, meta.getFrequency());
            Assert.assertEquals(expectedProvEmail, meta.getProviderEmailId());
            Assert.assertEquals(expectedDeliveryMethod, meta.getDeliveryMethod());
    	}
    }
    
    
    private Document createDocToSend(PreferenceType masterPref, String mpin, String tin, String docId, String activeDate) {
    	
    	Document docToSend = new Document();
    	Metadata metadata = new Metadata();
    	
    	if (docId != null) {
    		docToSend.setId(docId);
    	}
    	if (masterPref.getActiveDate() != null) {
    		metadata.setActiveDate(masterPref.getActiveDate());
    	} else {
    		if (activeDate != null) {
    			metadata.setActiveDate(activeDate);
    		}
    	}
        metadata.setDeliveryMethod(masterPref.getDeliveryMethod());
        metadata.setFileName(masterPref.getClassifier());
        metadata.setFileType(ClassifierDescription.getClassifierDescription(masterPref.getClassifier()));
        metadata.setFrequency(masterPref.getFrequency());
        metadata.setMpin(mpin);
        metadata.setProviderEmailId(masterPref.getProviderEmailId());
        metadata.setProviderName(masterPref.getProviderName());
        metadata.setTin(tin);
        metadata.setAutoEdelUpdateInd(masterPref.getAutoEdelUpdateInd());
        metadata.setOkToChangePDOInd(masterPref.getOkToChangePDOInd());
        docToSend.setMetadata(metadata);

        return docToSend;
    	
    }
    
    private String padWithLeadingZeros(String currentMpin) throws Exception {
        int currentMpinLength = currentMpin.length();
        String stringOfZeros = "";
        if (currentMpinLength == 9) {
            return currentMpin;
        } else if (currentMpinLength < 9) {
            int numberOfZerosNeeded = 9 - currentMpinLength;
            for (int i = 0; i < numberOfZerosNeeded; i++) {
                stringOfZeros += "0";
            }
            currentMpin = stringOfZeros + currentMpin;
            return currentMpin;
        } else {
            LOGGER.error("MPIN longer than 9 digits, mpin={}", currentMpin);
            throw new Exception("MPIN longer than 9 digits");
        }

    }
    
    
    
	protected AutoEnrollment determineDocumentIndex(List<Document> documentList, int documentCount, int index, OffsetDateTime currentDate) {
 		LOGGER.info("Entering determineDocumentIndex: documentCount={}, index={}", documentCount, index);

 		// PDO have the assumption that a maximum of 2 documents will exist for a given MPIN/TIN/LetterType combination
 		// them being the AutoEnrollment and the pre-AutoEnrollment records.
 		// The niche scenario occurs where a preference only has an AutoEnrollment record with no pre-AutoEnrollment record for
 		// it will create a new pre-AutoEnrollment record to store client changes between now and AutoEnrollment date.
 		// Thus if we have > 2 records they will be ignore.
 		
 		String activeDateStr = documentList.get(index).getMetadata().getActiveDate();
 		if (activeDateStr == null || activeDateStr.isEmpty()) {
 			LOGGER.info("AutoEnrollment not found: documentCount={}, index={}, {}",
 					documentCount, index, printDocument(documentList.get(index).getMetadata()));
 			return this.new AutoEnrollment(false, index);
 		}

 		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"); 		
 		OffsetDateTime activeDate = null;
 		try {
 			activeDate = OffsetDateTime.parse(activeDateStr, df);
 		} catch(Exception e) {
 			LOGGER.error("checkDocumentIndex: ZonedDateTime; {}: {}", printDocument(documentList.get(index).getMetadata()), e);
 			return this.new AutoEnrollment(true, -1);
 		}
 		if (currentDate.isAfter(activeDate)) {
 			LOGGER.info("AutoEnrollment active: documentCount={}, index={}, {}",
 					documentCount, index, printDocument(documentList.get(index).getMetadata()));
 			return this.new AutoEnrollment(true, index);
 		}
 		LOGGER.info("AutoEnrollment not active: documentCount={}, index={}, {}",
 				documentCount, index, printDocument(documentList.get(index).getMetadata()));
 		return this.new AutoEnrollment(true, -1);
 	}
    
	
    
	protected int determineMulti(AutoEnrollment autoEnrollment0, AutoEnrollment autoEnrollment1) {
 		if (autoEnrollment0.isValidAutoEnrollment()) {
 			return 0;
 		}
 		if (autoEnrollment1.isValidAutoEnrollment()) {
 			return 1;
 		}
 		if (! autoEnrollment0.isAutoEnrollment()) {
 			return 0;
 		}
 		if (! autoEnrollment1.isAutoEnrollment()) {
 			return 1;
 		}
 		return -1;
 	}
    
	protected String printDocument(Metadata metadata) {
		return "providerEmailId = " + metadata.getProviderEmailId() + ", mpin = " + metadata.getMpin() + ", fileName= " + metadata.getFileName();
	}
    
    public class AutoEnrollment {
    	
    	private boolean isAutoEnrollment;
    	private int index;
    	
    	public AutoEnrollment(Boolean isAutoEnrollment, int index) {
    		this.isAutoEnrollment = isAutoEnrollment;
    		this.index = index;
		}
    	
    	boolean isAutoEnrollment() { return isAutoEnrollment; }

 		public boolean isValidAutoEnrollment() {
 			return isAutoEnrollment && index != -1;
 		}

    }
    
    
}
