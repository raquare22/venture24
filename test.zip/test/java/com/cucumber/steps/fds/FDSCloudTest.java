package com.cucumber.steps.fds;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class FDSCloudTest {

	private final static Logger logger = LoggerFactory.getLogger(FDSCloudTest.class);

	@Autowired
	FDSCloudHandler fdsCloudHandler;

	FDSCloudRequest fdsCloudRequest;

	ObjectMapper mapper = new ObjectMapper();

	String searchTerms = "";

	String documentId = "";
	ResponseEntity<OptOutFDSCloudPOSTResponse> response;


	@Given("a request to FDSCloud")
	public void a_request_to_FDSCloud() throws ApplicationException{
		fdsCloudRequest = new FDSCloudRequest();
	}

	@When("I query on <searchTerms>")
	public void i_query_on_searchTerms(io.cucumber.datatable.DataTable dataTable) {
		List<String> searchCriteria =  dataTable.transpose().asList(String.class);
		searchTerms = "(" + String.join("+", searchCriteria) + ")";
		Map<String, Object> requestMap = new HashMap<String, Object>();
		requestMap.put("searchTerms", searchTerms);
		fdsCloudRequest.setRequest(requestMap);
	}

	@Then("I should get <expectedCount> in return")
	public void i_should_get_expectedCount_in_return(io.cucumber.datatable.DataTable dataTable) throws ApplicationException{
		Map<String, Integer> expectedCount = dataTable.asMap(String.class, Integer.class);



		FDSCloudGETResponse response = fdsCloudHandler.FDSCloudGetRequest("cucumberTest", fdsCloudRequest);

		logger.info("Received response from FDSCloud, response={}", response.toString());

		Assert.assertEquals(expectedCount.get("expectedCount").toString(), response.getTotal_records());
	}

	@When("I send the <metadata>")
	public void i_send_the_metadata(io.cucumber.datatable.DataTable dataTable) throws ApplicationException{
		Map<String, Object> metadata = dataTable.asMap(String.class, Object.class);
		fdsCloudRequest.setRequest(metadata);


		response = fdsCloudHandler.FDSCloudPostRequest("cucumberTest", fdsCloudRequest);

	}

	@When("I get <expectedresult>")
	public void i_get_expectedresult() {
		Assert.assertEquals(response.getStatusCode(), HttpStatus.CREATED);
		Assert.assertTrue(!response.getBody().equals(null));
		logger.info("{} Response received from FDSCloud, documentId={}, response={}", response.getStatusCode(), response.getBody().getDocumentId(), response.getBody().toString());
		documentId = response.getBody().getDocumentId();

	}
	@Then("I should update the new document with")
	public void i_should_update_the_new_document_with(io.cucumber.datatable.DataTable dataTable) throws ApplicationException {
		Map<String, Object> metadata = dataTable.asMap(String.class, Object.class);

		fdsCloudRequest.setDocumentId(documentId);
		fdsCloudRequest.setRequest(metadata);

		ResponseEntity<OptOutFDSCloudPOSTResponse> putResponse = fdsCloudHandler.FDSCloudPutRequest("cucumberTest", fdsCloudRequest);

		Assert.assertEquals(HttpStatus.OK, putResponse.getStatusCode());
	}

	@Then("when I GET said document again, I should get <expectedTin>")
	public void when_I_GET_said_document_again_I_should_get_expectedTin(io.cucumber.datatable.DataTable dataTable) throws ApplicationException, IOException {
		Map<String, Object> tinCheck = dataTable.asMap(String.class, Object.class);

		OptOutFDSCloudDocument putCheck = fdsCloudHandler.FDSCloudGetDocument("cucumberTest", documentId);
		String searchTermsJson = putCheck.getMetadata().toString().replaceAll("\\\\", "");
		try {
			Map<String, Object> searchTerms = mapper.readValue(searchTermsJson, Map.class);
			Assert.assertEquals(tinCheck.get("expectedTin"), searchTerms.get("tin"));
		}
		catch (Exception e) {
			logger.error("Error mapping searchTerms");
		}

	}

	@Then("cleanup the posted document")
	public void cleanup_the_posted_document() throws ApplicationException{

		Map<String, Boolean> response = fdsCloudHandler.FDSCloudDelete("cucumberTest", documentId);
		Assert.assertEquals(response.get("deleted"), true);

	}

}
