package com.cucumber.steps.fds;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.handler.Oauth2Handler;
import com.optum.providerpreferences.rs.handler.ServiceBase;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.TokenAbst;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObj;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSResponse;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class FDSOauthRefreshTest {
	
	ObjectMapper tempMapper = new ObjectMapper();

    String givenTin;

    String givenMpin;
    
    String expiredToken;

    ResponseEntity<FDSResponse> actualFDSResponse;
    
    FDSResponse actualFDSResponse2;
    
    AutoenrollmentRequest request;

    FDSHandler fdsHandler = new FDSHandler();
    
    ServiceBase serviceBase = new ServiceBase();

    @Given("^an expired token \"(.*?)\"$")
    public void an_expired_token(String expiredToken) throws Throwable {
        this.givenTin = "911853574";
        this.givenMpin = "000097819";
        this.expiredToken = expiredToken;
    }

    @When("^I call the sendRequestFDS$")
    public void i_call_the_sendRequestFDS() throws Throwable {
    	String spaceId = "8928";
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(System.getenv("FDS_GET_URL")).queryParam("metadata.tin", givenTin)
                .queryParam("metadata.mpin", givenMpin).queryParam("space_id", spaceId);
        
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("Authorization", "Bearer " + expiredToken);
        
        HttpEntity<String> entity = new HttpEntity<>(headers);
    	
        // This request will fail because of expired token
        actualFDSResponse = (ResponseEntity<FDSResponse>) serviceBase.sendRequestFDS(builder.toUriString(), entity, FDSResponse.class, HttpMethod.GET);
        
        // These requests will succeed after new token is fetched
        actualFDSResponse2 = fdsHandler.getDocumentList(givenTin, givenMpin, "A1", "TEST");
        request = fdsHandler.getExistingFDSEmails(createAutoEnrollRequest());
        
    }

    @Then("^I receive an FDSResponse with the correct documents: \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\"$")
    public void i_receive_an_FDSResponse_with_the_correct_documents(String expectedDateCreated, String expectedIds, String expectedSpaceIds,
            String expectedProviderNames, String expectedFileNames, String expectedFileTypes, String expectedProvEmails, String expectedFrequencies,
            String expectedDeliveryMethods) throws Throwable
    {
        Assert.assertNotNull(actualFDSResponse);
        Assert.assertNotNull(actualFDSResponse.getBody());
        System.out.println(tempMapper.writeValueAsString(actualFDSResponse));
        List<Document> actualDocList = actualFDSResponse.getBody().getDocuments();
        System.out.println(tempMapper.writeValueAsString("Number of Documents returned: " + actualDocList.size()));
        
        Assert.assertNotNull(actualFDSResponse2);
        Assert.assertNotNull(request);
    }
    
    
    public AutoenrollmentRequest createAutoEnrollRequest() {
    	AutoenrollmentRequest req = new AutoenrollmentRequest();
    	
    	List<AutoenrollmentObj> list = new ArrayList<>();
    	
    	AutoenrollmentObj doc1 = new AutoenrollmentObj();
    	doc1.setTin("testtin");
    	doc1.setMpin("testmpin");
    	doc1.setProviderEmailId("testEmailToBeReplaced@optum.com");
    	doc1.setFileName("C1");
    	list.add(doc1);
    	
    	AutoenrollmentObj doc2 = new AutoenrollmentObj();
    	doc2.setTin("testtin2");
    	doc2.setMpin("testmpin");
    	doc2.setProviderEmailId("testEmailToBeReplaced@optum.com");
    	doc2.setFileName("C2");
    	list.add(doc2);
    	
    	AutoenrollmentObj doc3 = new AutoenrollmentObj();
    	doc3.setTin("testtin3");
    	doc3.setMpin("testmpin");
    	doc3.setProviderEmailId("testEmailToBeKept@optum.com");
    	doc3.setFileName("C3");
    	list.add(doc3);
    	
    	
    	
    	req.setAutoenrollDocuments(list);
    	
    	return req;
    }
    

}
