package com.cucumber.steps.fds;

import java.util.List;

import org.junit.Assert;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSResponse;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GetDocumentsTest
{
    ObjectMapper tempMapper = new ObjectMapper();

    String givenTin;

    String givenMpin;

    FDSResponse actualFDSResponse;

    FDSHandler fdsHandler = new FDSHandler();

    @Given("^a provider tax id \"(.*?)\"$")
    public void a_provider_tax_id(String givenTin) throws Throwable
    {
        this.givenTin = givenTin;
        this.givenMpin = "000097819";
    }

    @When("^I call the getDocuments service$")
    public void i_call_the_getDocuments_service() throws Throwable
    {
        actualFDSResponse = fdsHandler.getDocumentList(givenTin, givenMpin, "", "1234");
    }

    @Then("^I recieve an FDSResponse with the correct list of documents: \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\"$")
    public void i_recieve_an_FDSResponse_with_the_correct_list_of_documents(String expectedDateCreated, String expectedIds, String expectedSpaceIds,
            String expectedProviderNames, String expectedFileNames, String expectedFileTypes, String expectedProvEmails, String expectedFrequencies,
            String expectedDeliveryMethods) throws Throwable
    {
        Assert.assertNotNull(actualFDSResponse);
        System.out.println(tempMapper.writeValueAsString(actualFDSResponse));
        List<Document> actualDocList = actualFDSResponse.getDocuments();
        System.out.println(tempMapper.writeValueAsString("Number of Documents returned: " + actualDocList.size()));
    }
}
