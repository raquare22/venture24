package com.cucumber.steps.optout;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPutResponse;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.service.OptOutServiceImpl;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class OptOutUpdateTest {
	
	private final static Logger logger = LoggerFactory.getLogger(OptOutUpdateTest.class);
	
	@Autowired
	OptOutServiceImpl optOutService;
	
	@Autowired
	FDSCloudHandler fdsCloudHandler; 
	
	OptOutRequest optOutRequestObj;
	FDSMultiPutResponse response;
	
	@Autowired
	FDSHandler fds;
	
	@Given("^an optOutRequest object \"(.*?)\"$")
	public void an_optOutRequest_object(String optOutRequest) throws Throwable {
		ObjectMapper mapper = new ObjectMapper();
		
		optOutRequestObj = mapper.readValue(optOutRequest, OptOutRequest.class);
		logger.info("OptOutRequestObject created {}", optOutRequestObj);
	}

	@When("^I send this request for opt out$")
	public void i_send_this_request_for_opt_out() throws Throwable {
		HttpHeaders headers = new HttpHeaders();
		
		response = optOutService.updateOptOutDocuments(optOutRequestObj, headers);
		
        logger.info("Updated docs={}", response.getUpdated());
		
	}
	
	@Then("^I will verify that the correct number of (\\d+) is returned$")
	public void i_will_verify_that_the_correct_number_of_recordsUpdated_is_returned(int recordsUpdated) throws Throwable {
		Assert.assertEquals(recordsUpdated, response.getUpdated().size());
	}

	@Then("^I will verify that the documents have been updated with the correct data$")
	public void i_will_verify_that_the_documents_have_been_updated_with_the_correct_data() throws Throwable {
		
		String expiryDateEpoch = "";
		List<Document> fdsResponses = fds.getDocById(response.getUpdated());
		for (Document resp : fdsResponses) {
			Metadata respMetadata = resp.getMetadata();
			Assert.assertEquals("Y", respMetadata.getAutoEdelUpdateInd());
			Assert.assertEquals("Y", respMetadata.getOkToChangePDOInd());
			Assert.assertEquals("P", respMetadata.getDeliveryMethod());

			Assert.assertEquals(Integer.valueOf(60), respMetadata.getOptedOutDuration());
			Assert.assertEquals(optOutRequestObj.getLastUpdatedBy(), respMetadata.getLastUpdatedBy());
			Assert.assertEquals(optOutRequestObj.getLastUpdatedById(), respMetadata.getLastUpdatedById());
			expiryDateEpoch = respMetadata.getExpiryDateEpoch().toString();
			
		}
		
		// check for docId in FDS Cloud + remove if found
		
		String searchTerm = "(optOutUpdate.expiryDateEpoch="+ expiryDateEpoch +")";
		Map<String, Object> requestMap = new HashMap<String, Object>();
		requestMap.put("searchTerms", searchTerm);
		
		FDSCloudRequest fdsCloudRequest = new FDSCloudRequest();
		fdsCloudRequest.setRequest(requestMap);
		
		FDSCloudGETResponse fdsCloudResponse = fdsCloudHandler.FDSCloudGetRequest("cucumberTest", fdsCloudRequest);
		Assert.assertTrue(fdsCloudResponse.getCount().equals("1"));
		String documentId = fdsCloudResponse.getDocuments().get(0).getDocumentId();
		logger.info("Audit log created, documentId={}, response={}", documentId, fdsCloudResponse.toString());
		
		Map<String, Boolean> response = fdsCloudHandler.FDSCloudDelete("cucumberTest", documentId);
		Assert.assertEquals(response.get("deleted"), true);
		
		System.out.println("Query to reset documents, be sure to clean up: \n");
		System.out.println("db.document.update( {"
				+ "spaceId: 8928, \"metadata.tin\": \"020695721\", "
				+ "\"metadata.mpin\": {$in: [\"test50921\", \"test50927\"]}}, "
				+ "{     $set: {\"metadata.deliveryMethod\": \"E\", \"metadata.okToChangePDOInd\": \"N\"},      "
				+ "$unset: {\"metadata.expiryDate\": \"\", \"metadata.lastUpdatedBy\": \"\", \"metadata.lastUpdatedById\": \"\", \"metadata.optedOutDateTime\": \"\", \"metadata.optedOutDuration\": \"\", 'metadata.expiryDateEpoch': \"\", \"space_id\": \"\"} }, "
				+ "{multi: true} )");
				
	}

}
