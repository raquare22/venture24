package com.cucumber.steps.optout;

import java.util.ArrayList;

import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.handler.PESHandler;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPutResponse;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinResponse;
import com.optum.providerpreferences.rs.service.OptOutServiceImpl;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class OptOutTinsTest {
	
	private final static Logger logger = LoggerFactory.getLogger(OptOutTinsTest.class);
	
	@Autowired
	OptOutServiceImpl optOutService;
	
	OptOutTinRequest optOutTinRequest;
	
	OptOutTinResponse response;
	
	@Given("^an optOutTinRequest object \"(.*?)\"$")
	public void an_optOutTinRequest_object(String optOutRequest) throws Throwable {
		ObjectMapper mapper = new ObjectMapper();
		
		optOutTinRequest = mapper.readValue(optOutRequest, OptOutTinRequest.class);
		logger.info("OptOutTinRequest object created {}", optOutTinRequest);
	}

	@When("^I send this request to get tins$")
	public void i_send_this_request_for_opt_out() throws Throwable {
		
		response = optOutService.getTins(optOutTinRequest);
		
        logger.info("Tins={}", response.getTins());
		
	}
	
	@Then("^I will confirm that the correct number of (\\d+) is returned$")
	public void i_will_verify_that_the_correct_number_of_tins_is_returned(int tins) throws Throwable {
		Assert.assertEquals(tins, response.getTins().size());
	}

}
