package com.cucumber.steps.optout;

import java.util.List;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.autoenrollment.Scheduler;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPutResponse;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.service.OptOutServiceImpl;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RevertOptOutTest {
	
	private final static Logger logger = LoggerFactory.getLogger(RevertOptOutTest.class);
	
	@Autowired
	OptOutServiceImpl optOutService;
	
	OptOutRequest optOutRequestObj;
	FDSMultiPutResponse response;
	
	@Autowired
	FDSHandler fds;
	
	@Given("^an opt out request object \"(.*?)\"$")
	public void an_opt_out_request_object(String optOutRequest) throws Throwable {
		ObjectMapper mapper = new ObjectMapper();
		
		optOutRequestObj = mapper.readValue(optOutRequest, OptOutRequest.class);
		logger.info("OptOutRequestObject created {}", optOutRequestObj);
	}

	@When("^I send this opt out request$")
	public void i_send_this_opt_out_request() throws Throwable {
		HttpHeaders headers = new HttpHeaders();
		
		response = optOutService.updateOptOutDocuments(optOutRequestObj, headers);
		
        logger.info("Updated docs={}", response.getUpdated());
		
	}
	
	@Then("^I run the scheduler$")
	public void i_run_the_scheduler() throws Throwable {
		optOutService.revertExpiredOptOutDocuments("test50921");
	}

	@Then("^I will verify that the opt out documents have been reverted$")
	public void i_will_verify_that_the_opt_out_documents_have_been_reverted() throws Throwable {
		
		
		List<Document> fdsResponses = fds.getDocById(response.getUpdated());
		for (Document resp : fdsResponses) {
			Metadata respMetadata = resp.getMetadata();
			Assert.assertEquals("Y", respMetadata.getAutoEdelUpdateInd());
			Assert.assertEquals("N", respMetadata.getOkToChangePDOInd());
			Assert.assertEquals("E", respMetadata.getDeliveryMethod());
			Assert.assertEquals("N", respMetadata.getAutoOptOutInd());
			Assert.assertEquals("", respMetadata.getProviderEmailId());
		}
		
		System.out.println("Query to reset documents, be sure to clean up: \n");
		System.out.println("db.document.update(\n" + 
				"    {spaceId: 8928, \"metadata.tin\": \"test95721\", \"metadata.mpin\": {$in: [\"test50921\", \"test50927\"]}},\n" + 
				"    {\n" + 
				"        $set: {\"metadata.deliveryMethod\": \"E\", \"metadata.okToChangePDOInd\": \"N\"}, \n" + 
				"        $unset: {\"metadata.expiryDate\": \"\", \"metadata.lastUpdatedBy\": \"\", \"metadata.lastUpdatedById\": \"\", \"metadata.optedOutDateTime\": \"\", \"metadata.optedOutDuration\": \"\"}\n" + 
				"    },\n" + 
				"    {multi: true}\n" + 
				")\n" + 
				"");
				
	}

}
