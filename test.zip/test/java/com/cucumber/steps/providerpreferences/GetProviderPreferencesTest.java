package com.cucumber.steps.providerpreferences;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpHeaders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import com.optum.providerpreferences.rs.service.ProviderPreferenceServiceImpl;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GetProviderPreferencesTest
{
    ObjectMapper tempMapper = new ObjectMapper();

    String tin;

    String mpin;
    
    String classifier;

    ProviderPreferencesObj providerPreferences;

    ProviderPreferenceServiceImpl serviceProvider = new ProviderPreferenceServiceImpl();

    List<String> expectedClassifiers;

    List<String> expectedDescriptions;

    List<String> expectedDeliveryMethods;

    String expectedProviderName;

    @Given("^an \"(.*?)\" and a \"(.*?)\" and a \"(.*?)\"$")
    public void an_and_a(String mpin, String tin, String classifier) throws Throwable
    {
        this.tin = tin;
        this.mpin = mpin;
        this.classifier = classifier;
    }

    @When("^I call the services and aggregate the data$")
    public void i_call_the_services_and_aggregate_the_data() throws Throwable
    {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "1234");
        LogMessage logMessage = new LogMessage();
        logMessage.setUsername("CUCUMBERTEST");
        logMessage.setActor(classifier);
        providerPreferences = serviceProvider.getProviderPreferences(tin, mpin, headers, logMessage);
        System.out.println("Provider Preferences returned: "+providerPreferences.toString());
        
    }

//    @Then("^I should get back preferences with: \"(.*?)\", \"(.*?)\", \"(.*?)\", and \"(.*?)\"$")
//    public void i_should_get_back_preferences_with_and(String expectedProviderName, String expectedClassifers, String expectedDescriptions,
//            String expectedDeliveryMethods) throws Throwable
//    {
    @Then("^I should get back preferences with: \"(.*?)\", \"(.*?)\" \"(.*?)\", \"(.*?)\", and \"(.*?)\"$")
    public void i_should_get_back_preferences_with_and(String expectedProviderName, String expectedClassifers, String expectedDescriptions, String expectedDeliveryMethods, String expectedDocumentId) throws Throwable 
    {
        System.out.println("Provider Preferences: " + tempMapper.writeValueAsString(providerPreferences));
        if (providerPreferences.getPreferenceTypes().get(0).getExpiryDate() != null) {
        	System.out.println(">>>>>> Opt-out Duration (Days/Evergreen): " + providerPreferences.getPreferenceTypes().get(0).getOptedOutDuration());
        	System.out.println(">>>>>> Opted-out Date: " + providerPreferences.getPreferenceTypes().get(0).getOptedOutDateTime());
        	System.out.println(">>>>>> Expiry Date: " + providerPreferences.getPreferenceTypes().get(0).getExpiryDate());
        }

        this.expectedClassifiers = buildArrayOfExpectedValues(expectedClassifers);
        this.expectedDescriptions = buildArrayOfExpectedValues(expectedDescriptions);
        this.expectedDeliveryMethods = buildArrayOfExpectedValues(expectedDeliveryMethods);

        Assert.assertEquals(expectedProviderName, (providerPreferences.getCorporateName() == null ? "" : providerPreferences.getCorporateName()));
        List<PreferenceType> preferences = providerPreferences.getPreferenceTypes();

        for (PreferenceType currentPref : preferences)
        {
            // just checking for one preference
            if (expectedClassifiers.get(0) == currentPref.getClassifier())
            {
                Assert.assertEquals(expectedClassifers, currentPref.getClassifier());
                Assert.assertEquals(expectedDescriptions, currentPref.getDescription());
                Assert.assertEquals(expectedDeliveryMethods, currentPref.getDeliveryMethod());
                Assert.assertEquals(expectedDocumentId, currentPref.getDocumentId());
            }
        }

    }

    // TODO: This method appears in at least 3 test/step classes, condense to a testing utility class
    private List<String> buildArrayOfExpectedValues(String expectedValue)
    {
        String resultArray[] = expectedValue.split(",");
        if (resultArray.length == 0)
        {
            return new ArrayList<String>();
        }
        else
        {
            return Arrays.asList(resultArray);
        }

    }
}
