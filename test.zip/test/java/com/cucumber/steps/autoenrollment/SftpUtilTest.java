package com.cucumber.steps.autoenrollment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.optum.providerpreferences.autoenrollment.SftpUtil;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObj;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPostResponse;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.datatable.DataTable;

public class SftpUtilTest {
	private final static Logger logger = LoggerFactory.getLogger(SftpUtilTest.class);
	
	private Session utilSession;
	private Channel utilChannel;
	private ChannelSftp utilChannelSftp;
	
	private static int port = 22;	
	private static String host = System.getenv("PRUN_HOST");
	private static String userName = System.getenv("PRUN_USERNAME");
	private static String userKey = System.getenv("PRUN_PASSWORD");
	private static String workingDir = System.getenv("PRUN_WORKING_DIRECTORY");
	// test folder dropzone for cleanup 
	private static String destination = System.getenv("PRUN_DESTINATION_DIRECTORY") + "/test";
	private static String localDirectory = System.getenv("PRUN_SFTP_LOCALDIR");
	
	private static String laneWorkingDir = System.getenv("PRUN_WORKINGDIR_LANE")+ "/test";
	

	private static final String DIRECTORY_LISTING = "directoryListing";
	private static final String CHANNEL_SFTP = "channelSftp";
	private static final String SFTP_SESSION = "sftpSession";
	private static final String CHANNEL = "channel";
	private static final String FILE_EXTENSION = ".csv";
	
	
	List<List<String>> csvFile = new ArrayList<List<String>>();
	Map<Integer, List<List<String>>> csvMap = new HashMap<Integer, List<List<String>>>();
	String testFileName = "";
	Calendar cal = Calendar.getInstance();
	String fileDate = formatDate(cal.getTime());
	FDSMultiPostResponse response = new FDSMultiPostResponse();

	@Given("^an SFTP connection setup$")
	public void an_SFTP_connection_setup() throws Throwable {
		logger.info("Creating SFTP session: userName={}, userKey={}, host={}, port={}", userName, userKey, host, port);
		this.utilSession =  SftpUtil.createSession(userName, userKey, host, port);
		this.utilChannel = SftpUtil.createSFTPChannel(utilSession);
	}
	
	@When("^I connect to the server for \"(.*?)\"$")
	public void i_connect_to_the_server_for(String connectType) throws Throwable {
		this.utilChannelSftp = (ChannelSftp) utilChannel;
		SftpUtilTest.validateDirectory(utilChannelSftp, destination);
		if (connectType.toLowerCase().equals("emaillist")) {
			SftpUtilTest.validateDirectory(utilChannelSftp, laneWorkingDir);
		}
	}

	@Then("^I should be able to access the \"(.*?)\"$")
	public void i_should_be_able_to_access_the(String dropzone) throws Throwable {
		logger.info("testConnection -> SFTPing to directory, dropzone={}", dropzone);
		try {
			dropzone = dropzone.replace("_", "/");
			utilChannelSftp.cd(dropzone);
			logger.info("In directory={}, contents={}", utilChannelSftp.pwd(), utilChannelSftp.ls(dropzone));
			Assert.assertEquals(dropzone, utilChannelSftp.pwd());
		}
		catch (Exception e) {
			logger.error("Directories missing: error={}", e.getMessage());
		}
	}

	@Then("^create <testcsv> file$")
	public void create_testcsv_file(DataTable metadata) throws Throwable {
		this.csvFile = createCSV(metadata);
		logger.info("Create testcsv file, preppedCSV={}", csvFile.toString());
	}
	
	@When("^I drop the files into the <dropzone>$")
	public void i_drop_the_files_into_the_dropzone(DataTable dropzone) throws Throwable {
		Map<String, String> dropzoneMap = dropzone.asMap(String.class, String.class);
		String dropDir = dropzoneMap.get("dropzone").replace("_", "/");
		String dropType = dropDir.split("/")[2];
		logger.info("Checking for dropzone={}, dropType={}", dropDir, dropType);
		createTestCSVs(csvFile, dropDir, utilChannelSftp, dropType);
		
	}
	
	@When("^run the scheduler$")
	public void run_the_scheduler() throws Throwable {
		logger.info("Running scheduler process -> pollCSVFiles");
		String fileName = "";
		Map<String, Object> sftpResult = null;
		try {	
			sftpResult = SftpUtil.sftpDirectory(userName, userKey, host, workingDir);

			for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult
					.get(DIRECTORY_LISTING)) {

				fileName = entry.getFilename();

				if (entry.getFilename().endsWith(FILE_EXTENSION)) {
					
					SftpUtil.copyFileToArchive(workingDir, destination, localDirectory, entry.getFilename(),
							sftpResult);
					SftpUtil.removeFileFromSFTPLocation(userName, userKey, host, port, workingDir, fileName);
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();

		} finally {
			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
						(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
				logger.info("pollCSVFiles -> sftp connection closed");

			}
		}
	}
	

	@Then("^the file should transfer to <expectedDir>$")
	public void the_file_should_transfer_to_expectedDir(DataTable expectedDir) throws Throwable {
		Map<String, String> expectedMap = expectedDir.asMap(String.class, String.class);
		String expected = expectedMap.get("expectedDir").replace("_", "/");
		utilChannelSftp.cd(expected + "/" + fileDate);
		ArrayList<ChannelSftp.LsEntry> fileList = new ArrayList<>(utilChannelSftp.ls(utilChannelSftp.pwd()));
		for (ChannelSftp.LsEntry file : fileList) {
			if (!file.getFilename().equals(".") && !file.getFilename().equals("..")) {
				String[] csvTestFileName = testFileName.split("/");
				logger.info("Assert these, expected={}, actual={}", csvTestFileName[csvTestFileName.length-1], file.getFilename());
				Assert.assertEquals(csvTestFileName[csvTestFileName.length-1], file.getFilename());
			}
		}
	}
	
	@Then("^I will initiate file cleanup$")
	public void i_will_initiate_file_cleanup() throws Throwable {
		logger.info("Cleaning up test directory/files, destination={}", destination);
		
		validateDirectoryToDelete(utilChannelSftp, destination, "");
		
		FileUtils.cleanDirectory(new File(localDirectory));
	}

	@Then("^create <testcsv(\\d+)> file$")
	public void create_testcsv_file(int testIndex, DataTable metadata) throws Throwable {
		List<List<String>> testFile = createCSV(metadata);
		csvMap.put(testIndex, testFile);
		logger.info("Mapped created testcsv file, testIndex={}, preppedCSV={}", testIndex, testFile.toString());
	}

	@When("^I mass drop the files into the <dropzone>$")
	public void i_mass_drop_the_files_into_the_dropzone(DataTable dropzone) throws Throwable {
		Map<String, String> dropzoneMap = dropzone.asMap(String.class, String.class);
		String dropDir = dropzoneMap.get("dropzone").replace("_", "/");
		String dropType = dropDir.split("/")[2];
		logger.info("Checking for dropzone={}", dropDir);
		for(Map.Entry<Integer, List<List<String>>> entry : csvMap.entrySet()) {
			logger.info("Entry in csvMap, key={}. value={}", entry.getKey(), entry.getValue());
			createTestCSVs(entry.getValue(), dropDir, utilChannelSftp, dropType);
		}
	}
	
	@When("^run the process scheduler$")
	public void run_the_process_scheduler() throws Throwable {
		logger.info("Running scheduler process -> processFiles");
		List<String> completeData = new ArrayList<String>();
		String fileName = "";

		try {
			if (!SftpUtil.exceptionForMissingLoginCredential(host, userName, userKey,
					destination + "/" + SftpUtil.createDateintoString())) {
				Map<String, Object> sftpResult = null;

				try {
					sftpResult = SftpUtil.sftpDirectory(userName, userKey, host,
							destination + "/" + SftpUtil.createDateintoString());
					for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult
							.get(DIRECTORY_LISTING)) {

						fileName = entry.getFilename();

						if (entry.getFilename().endsWith(FILE_EXTENSION)) {
							logger.info("processFiles -> Processing files, fileName={}", entry.getFilename());
							
							// TODO: readFile extracts the TIN in [1] of corpMpin, tin, providerMpin, fileName csv.
							// reuse logic to create AutoEnrollObj for processing
							List<String> data = SftpUtil.readFile(destination, localDirectory, entry.getFilename(),
									sftpResult);
							completeData.addAll(data);

						}
					}
					completeData = new ArrayList<>(new LinkedHashSet<>(completeData));
					SftpUtil.writeInCSVFile(completeData, localDirectory);
					
					// TODO: if switched to local folder on OSE, ensure this works. 
					// have to change destination variable
					SftpUtil.movefileFromlocalToServer(
							localDirectory + "/" + SftpUtil.createDateintoString() + "_emailList" + FILE_EXTENSION, sftpResult,
							destination);
					logger.info("processFiles -> Created TIN list, destination={}, absolutePath={}", destination, localDirectory + "/" + SftpUtil.createDateintoString() + FILE_EXTENSION);
				} catch (Exception ex) {
					ex.printStackTrace();

				} finally {
					if (sftpResult != null) {
						SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
								(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
						logger.info("processFiles -> sftp connection closed");

					}
				}

			} else {
				logger.warn("processFiles -> Missing some of the sftp credentials");
			}

		} catch (IOException e) {

		}
	}

	@When("^the files should transfer to <expectedDir>$")
	public void the_files_should_transfer_to_expectedDir(DataTable expectedDir) throws Throwable {
		Map<String, String> expectedMap = expectedDir.asMap(String.class, String.class);
		String expected = expectedMap.get("expectedDir").replace("_", "/");
		utilChannelSftp.cd(expected + "/" + fileDate);
		ArrayList<ChannelSftp.LsEntry> fileList = new ArrayList<>(utilChannelSftp.ls(utilChannelSftp.pwd()));
		Integer fileCount = 0; 
		for (ChannelSftp.LsEntry file : fileList) {
			if (!file.getFilename().equals(".") && !file.getFilename().equals("..")) {
				fileCount++;
				}
		}
		logger.info("Checking transferred file counts, expected={}, actual={}", 3, fileCount);
		Assert.assertTrue(3 == fileCount);
	}

	@Then("^the resulting CSV should have the <expectedUniqueTins>$")
	public void the_resulting_CSV_should_have_the_expectedUniqueTins(DataTable expectedUniqueTins) throws Throwable {
		List<String> csvTins = new ArrayList<String>(); 
		
		List<String> expectedCSVTins = expectedUniqueTins.transpose().asList(String.class);
		
		try {
			utilChannelSftp.cd(destination + "/" + fileDate);
			ArrayList<ChannelSftp.LsEntry> fileList = new ArrayList<>(utilChannelSftp.ls(utilChannelSftp.pwd()));
			for (ChannelSftp.LsEntry file : fileList) {
				if (!file.getFilename().equals(".") && !file.getFilename().equals("..") && file.getFilename().contains(fileDate)) {
					logger.info("Reading tinlist, fileName={}", file.getFilename());
					InputStream csvStream = utilChannelSftp.get(destination + "/" + fileDate + "/" + file.getFilename());
					
					BufferedReader br = new BufferedReader(new InputStreamReader(csvStream));
					String line;
	                while ((line = br.readLine()) != null) {
	                	csvTins.add(line);
	                }
	                break;
				}
			}
			
		}
		catch (Exception e) {
			logger.error("Error in checking expectedUniqueTins, error={}", e.getMessage());
		}
		
		logger.info("Assert TINs, expectedCSVTins={}, csvTins={}", expectedCSVTins, csvTins);
		for (String tin: expectedCSVTins) {
			Assert.assertTrue(csvTins.contains(tin));
		}
	}
	
	// ----------------------- email List --------------------------
	
	@Then("^create <testEmailList> emailList$")
	public void create_testEmailList_emailList(DataTable testEmailList) throws Throwable {
		csvFile = testEmailList.asLists();
		logger.info("Created testEmailList CSV, csvFile={}", csvFile);
	}

	@When("^run the email list scheduler$")
	public void run_the_email_list_scheduler() throws Throwable {
		String fileName = "";
		try {
			if (!SftpUtil.exceptionForMissingLoginCredential(host, userName, userKey, laneWorkingDir)) {
				Map<String, Object> laneResult = null;

				try {	
					laneResult = SftpUtil.sftpDirectory(userName, userKey, host, laneWorkingDir);

					for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) laneResult
							.get(DIRECTORY_LISTING)) {

						fileName = entry.getFilename();
						
						// if email list exists, find corresponding directory of files
						// delete after each time because we have hard copy to drop file in 
						if (entry.getFilename().endsWith(FILE_EXTENSION) && fileName.toLowerCase().contains("email")) {
							String matchedDate = fileName.split("_")[0];
							String matchedDateDestDir = destination + "/" + matchedDate;
							
							logger.info("found file, fileName={}, matchedDate={}, matchedDateDestDir={}", fileName, matchedDate, matchedDateDestDir);

//							response = SftpUtil.sftpFileStream(userName, userKey, host, laneWorkingDir, matchedDateDestDir, matchedDate);
							SftpUtil.removeFileFromSFTPLocation(userName, userKey, host, port, laneWorkingDir, fileName);
							
							
						}

						}

				} catch (Exception ex) {
					ex.printStackTrace();

				} finally {
					if (laneResult != null) {
						SftpUtil.closeSFTPChannel((ChannelSftp) laneResult.get(CHANNEL_SFTP),
								(Session) laneResult.get(SFTP_SESSION), (Channel) laneResult.get(CHANNEL));
						logger.info("pollCSVFiles -> sftp connection closed");

					}
				}

			} else {
				logger.warn("pollCSVFiles -> Missing some of the sftp credentials");
			}

		} catch (IOException e) {

		}

	}

	@Then("^I validate the number of records created$")
	public void i_validate_the_number_of_records_created() throws Throwable {
		
		logger.info("Asserting added autoenrollment records, expected={}, actual={}", 21, response.getInserted().size());;
		Assert.assertTrue(response.getInserted().size() == 21);
	}

	@When("^I will initiate email list cleanup$")
	public void i_will_initiate_email_list_cleanup() throws Throwable {
		logger.info("Cleaning up test directory/files, laneWorkingDir={}", laneWorkingDir);
		logger.info("SFTP connection status, isConnected={}", utilChannelSftp.isConnected());
		validateDirectoryToDelete(utilChannelSftp, laneWorkingDir, "email");
		
	}
	
	
	
	// ----------------------- cleanup --------------------------	
	
	
	
	// cleanup in case of any errors in NDB folder
// 	@After
	public void teardown() throws Throwable {
		logger.info("Executing teardown...");
		validateDirectoryToDelete(utilChannelSftp, destination, "");
		validateDirectoryToDelete(utilChannelSftp, laneWorkingDir, "email");
		FileUtils.cleanDirectory(new File(localDirectory));
	}
	

	// ----------------------- test utils --------------------------
	
	public synchronized String formatDate(Date date) {
		SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyyMMdd");
		return isoDateFormat.format(date);
	}

	public AutoenrollmentObj createMetadata(DataTable data) {
		AutoenrollmentObj autoEnrollDoc = new AutoenrollmentObj();
		
		Map<String, String> metadata = data.asMap(String.class, String.class);
		
		autoEnrollDoc.setTin(metadata.get("tin"));
		autoEnrollDoc.setMpin(metadata.get("mpin"));
		autoEnrollDoc.setProviderEmailId(metadata.get("providerEmailId"));
		autoEnrollDoc.setFileName(metadata.get("fileName"));
		autoEnrollDoc.setActiveDate(metadata.get("activeDate"));
		
		return autoEnrollDoc;
	}
	
	public List<List<String>> createCSV(DataTable data) {
		csvFile = data.asLists();		
//		csvFile.remove(0);
		// remove function won't work 
		List<List<String>> csvNoFirstRow = new ArrayList<List<String>>();
		for (List<String> csvLine : csvFile) {
			if (!csvLine.contains("provMpin") && 
					!csvLine.contains("tin") &&
					!csvLine.contains("letterCategory") &&
					!csvLine.contains("corpMpin")) {
				csvNoFirstRow.add(csvLine);
			}
		}
		
		return csvNoFirstRow;

	}
	
	public void writeTestEmailList(List<List<String>> emailList, String dir, ChannelSftp channelSftp) {
		try {
			
			this.testFileName = dir + "/" + fileDate + "_" + RandomStringUtils.randomAlphanumeric(8) + "_emailList" + FILE_EXTENSION;
			File tempFile = File.createTempFile(dir + "/" + fileDate + "_" + RandomStringUtils.randomAlphanumeric(8) + "_emailList", FILE_EXTENSION);
			logger.info("Created email list, createdList={}", testFileName);
			FileWriter writer = new FileWriter(tempFile);
			for(List<String> data : emailList) {
				writer.write(String.join(",", data)+ "\n");
				System.out.println(String.join(",", data));
			}
			writer.close();
			channelSftp.put(tempFile.getAbsolutePath(), testFileName);
		}
		catch (IOException | SftpException e) {
			logger.error("Sftp Error, error={}", e.getMessage());
		}
	}
	
	public void writeTestCSVFile(List<List<String>> csvData, String dir, ChannelSftp channelSftp) {
		
		try {
			
			this.testFileName = dir + "/" + RandomStringUtils.randomAlphanumeric(8) + FILE_EXTENSION;
			File tempFile = File.createTempFile(dir + "/" + RandomStringUtils.randomAlphanumeric(8), FILE_EXTENSION);
			logger.info("Created test CSV, createdCsv={}", testFileName);
			FileWriter writer = new FileWriter(tempFile);
			for(List<String> data : csvData) {
				writer.write(String.join(",", data)+ "\n");
				System.out.println(String.join(",", data));
			}
			writer.close();
			channelSftp.put(tempFile.getAbsolutePath(), testFileName);
		}
		catch (IOException | SftpException e) {
			logger.error("Sftp Error, error={}", e.getMessage());
		}
	}
	
	private static void validateDirectory(ChannelSftp sftpChannel, String dest) throws SftpException {

		SftpATTRS attrs = null;
		try {
			sftpChannel.cd(dest);
			attrs = sftpChannel.stat(dest);
		} catch (Exception e) {
			logger.error("validateDirectory ->" + dest + " not found");
		}

		if (attrs != null) {
			logger.info("validateDirectory -> Directory exists IsDir=" + attrs.isDir());
		} else {
			logger.info("validateDirectory -> Creating dir " + dest);
			sftpChannel.mkdir(dest);
		}

	}
	
	private void createTestCSVs(List<List<String>> file, String dir, ChannelSftp utilChanSFTP, String dirType) {
		
		try {
			utilChanSFTP.cd(dir);
			if (dirType.toLowerCase().equals("ndb")) {
				writeTestCSVFile(file, dir, utilChannelSftp);
			}
			else if (dirType.toLowerCase().equals("lane")) {
				writeTestEmailList(file, dir, utilChannelSftp);
			}
			
		} catch (Exception e) {
			logger.error("sftpDirectory Failure: cd to sftpWorkingDir: {}, errMsg={}", dir,
					e.getMessage());
			if (e.getMessage().contains("No such file")) {
				logger.warn("No directory found, creating directory, sftpWorkingDir={}", dir);
				try {
					utilChanSFTP.mkdir(dir);
				}
				catch (SftpException f) {
					logger.error("createTestCSVs error, error={}", f.getMessage());
				}
			}
			else {
				logger.error("createTestCSVs error, error={}", e.getMessage());
			}
		}
	}
	
	private void validateDirectoryToDelete(ChannelSftp sftpChannel, String dest, String cleanType) throws SftpException {

		SftpATTRS attrs = null;
		try {
			sftpChannel.cd(dest);
			attrs = sftpChannel.stat(dest);
		} catch (Exception e) {
			logger.error("validateDirectory ->" + dest + " not found, error={}", e.getMessage());
		}

		if (attrs != null) {
			logger.info("validateDirectory -> Directory exists, removing IsDir=" + attrs.isDir());
			cleanDirectory(sftpChannel, dest, cleanType);
		}
		else {
			logger.info("No test directories found, teardown complete");
		}

	}
	
	private void cleanDirectory(ChannelSftp channel, String dir, String cleanType) {
		try {
			String cleanDir = dir;
			if (!cleanType.toLowerCase().equals("email")) {
				cleanDir = dir + "/" + fileDate;
			}
			channel.cd(cleanDir);
			ArrayList<ChannelSftp.LsEntry> fileList = new ArrayList<>(channel.ls(channel.pwd()));
			for (ChannelSftp.LsEntry file : fileList) {
				if (!file.getFilename().equals(".") && !file.getFilename().equals("..")) {
					logger.info("Removing file={}", file.getFilename());
					channel.rm(file.getFilename());
				}
			}
			if (!cleanType.toLowerCase().equals("email")) {
				channel.rmdir(cleanDir);
			}
			channel.rmdir(dir); 
			
		}
		catch (Exception e) {
			logger.error("Error found in cleanDirectory. error={}", e.getMessage());
		}
	}
	
}