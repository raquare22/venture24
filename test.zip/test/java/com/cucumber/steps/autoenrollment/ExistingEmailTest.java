package com.cucumber.steps.autoenrollment;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObj;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class ExistingEmailTest {

	//TODO: UPDATE WITH FDS CLOUD CALLS

	private final static Logger logger = LoggerFactory.getLogger(ExistingEmailTest.class);
	AutoenrollmentRequest autoEnrollReq = new AutoenrollmentRequest();

	private String originalEmail;

	@Given("^an AutoEnrollment object with \"(.*?)\", \"(.*?)\", \"(.*?)\", and \"(.*?)\"$")
//    Given an AutoEnrollment object with "<tin>", "<mpin>", "<fileName>", and "<providerEmailId>"
	public void an_AutoEnrollment_object_with_and(String tin, String mpin, String fileName, String providerEmailId) throws Throwable {

		this.originalEmail = providerEmailId;

		List<AutoenrollmentObj> autoEnrollDocList = new ArrayList<AutoenrollmentObj>();

		AutoenrollmentObj autoEnrollDoc = new AutoenrollmentObj();
		autoEnrollDoc.setTin(tin);
		autoEnrollDoc.setMpin(mpin);
		autoEnrollDoc.setFileName(fileName);
		autoEnrollDoc.setProviderEmailId(providerEmailId);

		autoEnrollDocList.add(autoEnrollDoc);

		autoEnrollReq.setAutoenrollDocuments(autoEnrollDocList);
	}

	@When("^I check FDS for the existing emails for the given records$")
	public void i_check_FDS_for_the_existing_emails_for_the_given_records() throws Throwable {
//		autoEnrollReq = fds.getExistingFDSEmails(autoEnrollReq);
		logger.info("Existing FDS Email check - Complete");
	}

	@Then("^I will verify that the \"(.*?)\" are in the AutoEnrollment object\\.$")
//    Then I will verify that the "<expectedEmails>" are in the AutoEnrollment object.
	public void i_will_verify_that_the_are_in_the_AutoEnrollment_object(String expectedEmails) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		String requestEmail = autoEnrollReq.getAutoenrollDocuments().get(0).getProviderEmailId();
		logger.info("originalEmail={}, expectedResult={}, actualResult={}", originalEmail, expectedEmails, requestEmail);
		Assert.assertEquals(expectedEmails, requestEmail);
	}


}
