package com.cucumber.steps.autoenrollment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootContextLoader;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.ContextConfiguration;

import com.optum.providerpreferences.Application;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.FDSHandler;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObj;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPostResponse;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.service.AutoenrollmentServiceImpl;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

@SpringBootTest
@ContextConfiguration(
        classes = Application.class,
        loader = SpringBootContextLoader.class)
public class AutoEnrollmentPostTest {
	
	private final static Logger logger = LoggerFactory.getLogger(AutoEnrollmentPostTest.class);
	AutoenrollmentRequest autoEnrollReq = new AutoenrollmentRequest();
	
	@Autowired
	AutoenrollmentServiceImpl autoenrollService;
	
	FDSMultiPostResponse response;
	
	List<String> fdsCloudDocIds;
	
	FDSCloudHandler fdsCloudHandler = new FDSCloudHandler();
	
	@Autowired
	FDSHandler fds;
	
	List<AutoenrollmentObj> autoEnrollDocList = new ArrayList<AutoenrollmentObj>();
	
	@Given("^I add the first <metadata(\\d+)> set to an Autoenrollment request$")
	public void i_add_the_first_metadata_set_to_an_Autoenrollment_request(int index, DataTable testData) throws Throwable {		
		autoEnrollDocList.add(createMetadata(testData));
	}

	@Then("^I add the second <metadata(\\d+)> set$")
	public void i_add_the_second_metadata_set(int index, DataTable testData) throws Throwable {
		autoEnrollDocList.add(createMetadata(testData));
	}
	
	@Then("^I add the third <metadata(\\d+)> set$")
	public void i_add_the_third_metadata_set(int index, DataTable testData) throws Throwable {
		autoEnrollDocList.add(createMetadata(testData));
	}

	@Then("^I add the last <metadata(\\d+)> set$")
	public void i_add_the_last_metadata_set(int index, DataTable testData) throws Throwable {
		autoEnrollDocList.add(createMetadata(testData));
	}

	@When("^I send this request for AutoEnrollment$")
	public void i_send_this_request_for_AutoEnrollment() throws Throwable {
		
		autoEnrollReq.setAutoenrollDocuments(autoEnrollDocList);
        HttpHeaders headers = new HttpHeaders();
        headers.add("sessionId", "1234");
//        response = autoenrollService.createAutoenrollmentDocuments(autoEnrollReq, headers); 
//        logger.info("Added docs={}", response.getInserted());
        fdsCloudDocIds = autoenrollService.createAutoenrollmentDocumentsFDSCloud(autoEnrollReq, headers);

	}

	@Then("^I will verify that new documents have been added with <expectedData>$")
	public void i_will_verify_that_new_documents_have_been_added_with_expectedData(DataTable data) throws Throwable {

		Map<String, String> expectedData = data.asMap(String.class, String.class);
		
		List<Document> fdsResponses = fds.getDocById(response.getInserted());
		Integer testIndex = 1;
		for (Document resp : fdsResponses) {
			Metadata respMetadata = resp.getMetadata();
			Assert.assertEquals("Y", respMetadata.getAutoEdelUpdateInd());
			Assert.assertEquals("N", respMetadata.getOkToChangePDOInd());
			Assert.assertEquals("E", respMetadata.getDeliveryMethod());
			Assert.assertEquals("D", respMetadata.getFrequency());
			Assert.assertEquals(respMetadata.getFileType(), expectedData.get("fileType" + Integer.toString(testIndex)));
			Assert.assertEquals(respMetadata.getProviderEmailId(), expectedData.get("emailId" + Integer.toString(testIndex)));
			// unless activeDate passed, should be server date. 
			logger.info("activeDate assigned: activeDate={}", Encode.forJava(respMetadata.getActiveDate()));
			if (testIndex ==4) {
				Assert.assertEquals("9999-12-31T00:00:00.000Z", respMetadata.getActiveDate());
			}
			
			testIndex++;
		}
		
		
		// can't remove test docs, scuffed cleanup
		System.out.println("Removal query, be sure to clean up: \n");
		System.out.println("db.document.deleteMany({spaceId: 8928, 'metadata.mpin': 'testmpin', _id: {$nin: [\nObjectId(\"60b7e32b7b54890051c76ead\"),  \nObjectId(\"60b7e32b7b54890051c76eac\"), \nObjectId(\"60b7e32b7b54890051c76eab\")]}})");
	}
	
	@Then("I will verify that new documents have been added to FDSCloud with <expectedData>")
	public void i_will_verify_that_new_documents_have_been_added_to_FDSCloud_with_expectedData(DataTable data) throws ApplicationException, IOException{
//        logger.info("Added docs={}", fdsCloudDocIds);
//        Assert.assertEquals(fdsCloudDocIds.size(), 4);
        
		Map<String, String> expectedData = data.asMap(String.class, String.class);
		
		List<String> expectedFileType = new ArrayList<String>();
		List<String> expectedEmail = new ArrayList<String>();
		
		for (String key : expectedData.keySet()) {
			if (key.contains("email")) {
				expectedEmail.add(expectedData.get(key));
			}
			else { 
				expectedFileType.add(expectedData.get(key));
			}
		}
		Integer retryCount = 1;
		while (retryCount < 5) {
			try {
				for (String docId : fdsCloudDocIds) {
					OptOutFDSCloudDocument response = fdsCloudHandler.FDSCloudGetDocument("cucumberTest", docId);
					
					Map<String, Object> responseMap = fdsCloudHandler.getSearchTermsFromDocument(response);
					Assert.assertEquals("Y", responseMap.get("autoEdelUpdateInd").toString());
					Assert.assertEquals("N", responseMap.get("okToChangePDOInd").toString());
					Assert.assertEquals("E", responseMap.get("deliveryMethod").toString());
					Assert.assertEquals("D", responseMap.get("frequency").toString());
					
					Assert.assertTrue(expectedFileType.contains(responseMap.get("fileType")));
					Assert.assertTrue(expectedEmail.contains(responseMap.get("providerEmailId")));
					
				}
				break;
			}
			catch(Exception e) {
				
				retryCount ++; 
			}
		}

	}
	
	public AutoenrollmentObj createMetadata(DataTable data) {
		AutoenrollmentObj autoEnrollDoc = new AutoenrollmentObj();
		
		Map<String, String> metadata = data.asMap(String.class, String.class);
		
		autoEnrollDoc.setTin(metadata.get("tin"));
		autoEnrollDoc.setMpin(metadata.get("mpin"));
		autoEnrollDoc.setProviderEmailId(metadata.get("providerEmailId"));
		autoEnrollDoc.setFileName(metadata.get("fileName"));
		autoEnrollDoc.setActiveDate(metadata.get("activeDate"));
		
		return autoEnrollDoc;
	}

}