package com.cucumber.steps.linksecurity;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;

import com.optum.providerpreferences.rs.handler.LinkSecurityHandler;
import com.optum.providerpreferences.rs.model.linksecurity.User;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GetUserProfilesTest
{
    String[] userAttributesArray;

    String uuid;

    String sessionId;

    List<User> actualUserList;

    List<User> expectedUserList;

    User expectedUser;

    LinkSecurityHandler linkSecurityHandler = new LinkSecurityHandler();

    @Given("^a unique \"(.*?)\" and \"(.*?)\"$")
    public void a_unique_and(String uuid, String sessionId) throws Throwable
    {
        this.uuid = uuid;
        this.sessionId = sessionId;
    }

    @When("^I call the link service$")
    public void i_call_the_link_service() throws Throwable
    {
        actualUserList = linkSecurityHandler.getUserProfiles(uuid, sessionId);
    }

    @Then("^I recieve a list of users with correct \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\",\"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\"$")
    public void i_recieve_a_list_of_users_with_correct(String userAcctSeqNbr, String b2cUserId, String accessProfile, String statusCode, String statusDesc,
            String accountType, String accountDesc, String dept, String orgType, String title, String state, String zipCode, String roleId, String roleDesc,
            String respOrgMpin, String hasAccessProfiles) throws Throwable
    {
        buildExpectedUserList(userAcctSeqNbr, b2cUserId, accessProfile, statusCode, statusDesc, accountType, accountDesc, dept, orgType, title, state, zipCode,
                roleId, roleDesc, respOrgMpin, hasAccessProfiles);

        for (int i = 0; i < actualUserList.size(); i++)
        {
            Assert.assertEquals(expectedUserList.get(i).getAccessProfile(), actualUserList.get(i).getAccessProfile());
            Assert.assertEquals(expectedUserList.get(i).getAccountDesc(), actualUserList.get(i).getAccountDesc());
            Assert.assertEquals(expectedUserList.get(i).getAccountType(), actualUserList.get(i).getAccountType());
            Assert.assertEquals(expectedUserList.get(i).getB2cUserId(), actualUserList.get(i).getB2cUserId());
            Assert.assertEquals(expectedUserList.get(i).getDept(), actualUserList.get(i).getDept());
            Assert.assertEquals(expectedUserList.get(i).getOrgType(), actualUserList.get(i).getOrgType());
            Assert.assertEquals(expectedUserList.get(i).getRespOrgMpin(), actualUserList.get(i).getRespOrgMpin());
            Assert.assertEquals(expectedUserList.get(i).getRoleDesc(), actualUserList.get(i).getRoleDesc());
            Assert.assertEquals(expectedUserList.get(i).getRoleId(), actualUserList.get(i).getRoleId());
            Assert.assertEquals(expectedUserList.get(i).getState(), actualUserList.get(i).getState());
            Assert.assertEquals(expectedUserList.get(i).getStatusCode(), actualUserList.get(i).getStatusCode());
            Assert.assertEquals(expectedUserList.get(i).getStatusDesc(), actualUserList.get(i).getStatusDesc());
            Assert.assertEquals(expectedUserList.get(i).getTitle(), actualUserList.get(i).getTitle());
            Assert.assertEquals(expectedUserList.get(i).getUserAcctSeqNbr(), actualUserList.get(i).getUserAcctSeqNbr());
            Assert.assertEquals(expectedUserList.get(i).getZipCode(), actualUserList.get(i).getZipCode());
            Assert.assertEquals(expectedUserList.get(i).isHasAccessProfiles(), actualUserList.get(i).isHasAccessProfiles());

        }
    }

    private void buildExpectedUserList(String userAcctSeqNbrValues, String b2cUserIdValues, String accessProfileValues, String statusCodeValues,
            String statusDescValues, String accountTypeValues, String accountDescValues, String deptValues, String orgTypeValues, String titleValues,
            String stateValues, String zipCodeValues, String roleIdValues, String roleDescValues, String respOrgMpinValues, String hasAccessProfilesValues)
            throws Exception
    {
        String regex = ",";
        expectedUserList = new ArrayList<User>();
        
        String[] userAcctSeqNbrValuesArray = userAcctSeqNbrValues.split(regex);
        String[] b2cUserIdValuesArray = b2cUserIdValues.split(regex);
        String[] accessProfileValuesArray = accessProfileValues.split(regex);
        String[] statusCodeValuesArray = statusCodeValues.split(regex);
        String[] statusDescValuesArray = statusDescValues.split(regex);
        String[] accountTypeValuesArray = accountTypeValues.split(regex);
        String[] accountDescValuesArray = accountDescValues.split(regex);
        String[] deptValuesArray = deptValues.split(regex);
        String[] orgTypeValuesArray = orgTypeValues.split(regex);
        String[] titleValuesArray = titleValues.split(regex);
        String[] stateValuesArray = stateValues.split(regex);
        String[] zipCodeValuesArray = zipCodeValues.split(regex);
        String[] roleIdValuesArray = roleIdValues.split(regex);
        String[] roleDescValuesArray = roleDescValues.split(regex);
        String[] respOrgMpinValuesArray = respOrgMpinValues.split(regex);
        String[] hasAccessProfilesValuesArray = hasAccessProfilesValues.split(regex);

        for (int i = 0; i < hasAccessProfilesValuesArray.length; i++)
        {
            expectedUser = new User();

            expectedUser.setAccessProfile(accessProfileValuesArray[i]);
            expectedUser.setAccountDesc(accountDescValuesArray[i]);
            expectedUser.setAccountType(accountTypeValuesArray[i]);
            expectedUser.setB2cUserId(b2cUserIdValuesArray[i]);
            expectedUser.setDept(deptValuesArray[i]);
            expectedUser.setHasAccessProfiles(hasAccessProfilesValuesArray[i]);
            expectedUser.setOrgType(orgTypeValuesArray[i]);
            expectedUser.setRespOrgMpin(respOrgMpinValuesArray[i]);
            expectedUser.setRoleDesc(roleDescValuesArray[i]);
            expectedUser.setRoleId(roleIdValuesArray[i]);
            expectedUser.setState(stateValuesArray[i]);
            expectedUser.setStatusCode(statusCodeValuesArray[i]);
            expectedUser.setStatusDesc(statusDescValuesArray[i]);
            expectedUser.setTitle(titleValuesArray[i]);
            expectedUser.setUserAcctSeqNbr(userAcctSeqNbrValuesArray[i]);
            expectedUser.setZipCode(zipCodeValuesArray[i]);

            expectedUserList.add(expectedUser);

        }
    }

}
