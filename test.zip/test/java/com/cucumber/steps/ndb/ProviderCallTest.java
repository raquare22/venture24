package com.cucumber.steps.ndb;

import org.junit.Assert;

import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinData;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ProviderCallTest
{
    NDBHandler ndb = new NDBHandler();

    com.optum.providerpreferences.rs.model.ndb.provider.RequestData request;

    CorpMpinResponse response;

    @Given("^\"(.*?)\" and \"(.*?)\"$")
    public void and(String taxIdNumber, String corpOwnerId) throws Throwable
    {
        request = new RequestData(taxIdNumber, corpOwnerId);
    }

    @When("^I call the service$")
    public void i_call_the_service() throws Throwable
    {
        response = ndb.getProviderData(request);
    }

    @Then("^I get \"(.*?)\", \"(.*?)\", and \"(.*?)\"$")
    public void i_get_and(String taxIdTypeCode, String provFstNm, String provLstNm) throws Throwable
    {
        MpinData data = response.getResponse().getMpinList().get(1);
        Assert.assertEquals(taxIdTypeCode, data.getTaxIdTypeCode());
        Assert.assertEquals(provFstNm, data.getProvFstNm());
        Assert.assertEquals(provLstNm, data.getProvLstNm());
    }
}
