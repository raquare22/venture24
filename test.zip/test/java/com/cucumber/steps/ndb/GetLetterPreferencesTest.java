package com.cucumber.steps.ndb;

import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponse;
import com.optum.providerpreferences.rs.model.ndb.preferences.MailPref;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class GetLetterPreferencesTest
{
    NDBHandler ndb = new NDBHandler();

    com.optum.providerpreferences.rs.model.ndb.preferences.RequestData requestData;

    LetterPreferencesResponse response;

    @Given("^\"(.*?)\", \"(.*?)\", \"(.*?)\"and \"(.*?)\"$")
    public void and(String providerId, String providerTIN, String letterType, String functionCode) throws Throwable
    {
        requestData = new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(providerId, providerTIN, functionCode);
    }

    @When("^I call the letterPref service$")
    public void i_call_the_letterPref_service() throws Throwable
    {
        response = ndb.getProviderLetterPreferences(requestData);
    }

    @Then("^I recieve a response$")
    public void i_recieve_a_response() throws Throwable
    {
        for (MailPref pref : response.getRequestResponse().getLtrTypMailPrfList())
        {
            String letterType = pref.getLetterType();

            switch (letterType)
            {
            case "C6":
                Assert.assertEquals("E",pref.getMailingPref());
                break;
            case "C7":
                Assert.assertEquals("E",pref.getMailingPref());
                break;
            case "C8":
                Assert.assertEquals("E",pref.getMailingPref());
                break;
            case "C1":
                Assert.assertEquals("E",pref.getMailingPref());
                break;
            case "C2":
                Assert.assertEquals("E",pref.getMailingPref());
                break;
            default:
                Assert.assertEquals("E",pref.getMailingPref());
                break;
            }

        }

    }
}
