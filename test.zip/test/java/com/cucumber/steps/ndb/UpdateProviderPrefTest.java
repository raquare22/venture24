package com.cucumber.steps.ndb;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesRequest;
import com.optum.providerpreferences.rs.model.ndb.preferences.RequestData;
import com.optum.providerpreferences.rs.model.ndb.preferences.RequestHeader;
import com.optum.providerpreferences.rs.model.ndb.preferences.ResponseData;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponse;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterType;
import com.optum.providerpreferences.rs.model.ndb.preferences.MailPref;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class UpdateProviderPrefTest {
	
	private static Logger LOGGER = LoggerFactory.getLogger(UpdateProviderPrefTest.class);
	private ObjectMapper mapper = new ObjectMapper();
	
	NDBHandler ndb = new NDBHandler();
	
	LetterPreferencesRequest webRequest;
	
    RequestData reqData;
    
    Boolean ndbUpdateResponse;

    LetterPreferencesResponse prefResponse;
    
    @Given("^the request string: \"(.*?)\" and \"(.*?)\"$")
    public void the_request_string(String request, String classifier) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	
    	ndb.ndbWebServicePrep();
    	
    	System.out.println("request string: " + request);
    	
    	reqData = mapper.readValue(request, RequestData.class);    
    	reqData.setLetterTypeList(Arrays.asList(new LetterType(classifier)));
    	
        webRequest = new LetterPreferencesRequest();
        webRequest.setRequest(reqData);
        webRequest.setRequestHeader(new RequestHeader("sys", " ", "938", "0"));
    }


    @When("^I call the update provider preferences service$")
    public void i_call_the_update_provider_preferences_service() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	
        try {
            ndbUpdateResponse = ndb.updateProviderLetterPreferences(webRequest, reqData.getProviderId(), reqData.getProviderTIN());
        } catch (Exception e) {
            LOGGER.error("ERROR UPDATING TO NDB IN TEST, mpin={}, tin={}, error={}", reqData.getProviderId(), reqData.getProviderTIN(),
                    e);
            throw e;
        }
        
        Assert.assertNotNull(ndbUpdateResponse);
        Assert.assertTrue(ndbUpdateResponse);
        
    }

    @Then("^I call the get provider preferences service$")
    public void i_call_the_get_provider_preferences_service() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	
        try {            
            prefResponse = ndb.getProviderLetterPreferences(new RequestData(reqData.getProviderId(), reqData.getProviderTIN(), "I"));
            
        } catch (Exception e) {
            LOGGER.error("ERROR UPDATING TO NDB IN TEST, mpin={}, tin={}, error={}", reqData.getProviderId(), reqData.getProviderTIN(),
                    e);
            throw e;
        }
        
        Assert.assertNotNull(prefResponse);
        
    }

    @Then("^I receive a LetterPreferencesResponse with the correct list of documents: \"(.*?)\", \"(.*?)\"$")
    public void i_receive_a_LetterPreferencesResponse_with_the_correct_list_of_documents(String fileName, String deliveryMethod) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    	ResponseData response = prefResponse.getRequestResponse();
    	List<MailPref> responseList = response.getLtrTypMailPrfList();
    	
    	MailPref expectedMailPref = new MailPref(fileName, deliveryMethod);
    	Assert.assertTrue(responseList.contains(expectedMailPref));
    	
    }

	
	
}

