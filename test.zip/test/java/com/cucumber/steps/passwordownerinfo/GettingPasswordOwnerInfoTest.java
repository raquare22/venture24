package com.cucumber.steps.passwordownerinfo;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpHeaders;

import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.PasswordOwnerInfo;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import com.optum.providerpreferences.rs.service.ProviderPreferenceServiceImpl;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GettingPasswordOwnerInfoTest
{

    String optumUUID;

    PasswordOwner providers;

    ProviderPreferenceServiceImpl serviceProvider = new ProviderPreferenceServiceImpl();
    
    @Given("^an unique user id \"(.*?)\"$")
    public void an_unique_user_id(String optumUUID) throws Throwable
    {
        this.optumUUID = optumUUID;
    }

//    @When("^I attempt to retrieving all provider tins for a password owner$")
//    public void i_attempt_to_retrieving_all_provider_tins_for_a_password_owner() throws Throwable
//    {
//        HttpHeaders headers = new HttpHeaders();
//        headers.add("sm_serversessionid", "1234");
//        providers = serviceProvider.getCorporatesByPasswordOwner(optumUUID, headers, new LogMessage());
//    }

    @Then("^I expect to get back the correct \"(.*?)\" , \"(.*?)\" , and \"(.*?)\"$")
    public void i_expect_to_get_back_the_correct(String corpName, String uhcId, String corpMpin) throws Throwable
    {
        PasswordOwner expectedOwner = new PasswordOwner();
        expectedOwner.setOptumUUID(optumUUID);

        List<PasswordOwnerInfo> expectedCorporatesList = new ArrayList<PasswordOwnerInfo>();

        PasswordOwnerInfo expectedInfo = new PasswordOwnerInfo();
        expectedInfo.setUhcID(uhcId);
        expectedInfo.setMpin(corpMpin);
        expectedInfo.setCorporateName(corpName);

        expectedCorporatesList.add(expectedInfo);

        Assert.assertEquals(expectedOwner.getOptumUUID(), optumUUID);
        for (PasswordOwnerInfo actualInfo : providers.getCorporates())
        {
            Assert.assertEquals(expectedInfo.getCorporateName(), actualInfo.getCorporateName());
            Assert.assertEquals(expectedInfo.getUhcID(), actualInfo.getUhcID());
            Assert.assertEquals(expectedInfo.getMpin(), actualInfo.getMpin());
        }
    }
}
