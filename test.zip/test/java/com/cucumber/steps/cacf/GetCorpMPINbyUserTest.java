package com.cucumber.steps.cacf;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;

import com.optum.providerpreferences.rs.handler.CACFHandler;
import com.optum.providerpreferences.rs.model.PasswordOwnerInfo;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GetCorpMPINbyUserTest
{
    
    ///v1/corporates/search{?optumUuid,uhcId,appCode}
    
    String uuid;

    String uhcId;

    CACFHandler cacf = new CACFHandler();

    List<PasswordOwnerInfo> results;
    
    List<String> expectedCorpNames;
    
    List<String> expectedCorpMPins;

    @Given("^a collection of \"(.*?)\" and \"(.*?)\"$")
    public void a_collection_of_and(String givenUUID, String givenUhcId) throws Throwable
    {
        this.uuid = givenUUID;
        this.uhcId = givenUhcId;
    }

//    @When("^I call the cacf service GetCorporates$")
//    public void i_call_the_cacf_service_GetCorporates() throws Throwable
//    {
//        results = cacf.getCorporatesForUser(uuid, uhcId, "1234");
//    }

    @Then("^I get back a list of Corporates: \"(.*?)\" and \"(.*?)\"$")
    public void i_get_back_a_list_of_Corporates_and(String expectedCorpName, String expectedCorpMPin) throws Throwable
    {
        expectedCorpNames = buildArrayOfExpectedValues(expectedCorpName);
        expectedCorpMPins = buildArrayOfExpectedValues(expectedCorpMPin);
        
        for(int i = 0; i < results.size(); i ++)
        {
            PasswordOwnerInfo currentResult = results.get(i);
            Assert.assertEquals(expectedCorpNames.get(i), currentResult.getCorporateName());
            Assert.assertEquals(expectedCorpMPins.get(i), currentResult.getMpin());
        }
    }
    
    private List<String> buildArrayOfExpectedValues(String expectedValue)
    {
        String resultArray[] = expectedValue.split(",");
        return Arrays.asList(resultArray);
    }
}
