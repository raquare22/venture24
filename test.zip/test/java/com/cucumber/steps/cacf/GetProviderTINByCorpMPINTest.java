package com.cucumber.steps.cacf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.springframework.http.HttpHeaders;

import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.PasswordOwnerInfo;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import com.optum.providerpreferences.rs.service.ProviderPreferenceServiceImpl;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GetProviderTINByCorpMPINTest
{
    ///v1/provider_tax_ids/search{?optumUuid,uhcId,mpin,appCode}
    
    String corpMpin;

    String uhcId;

    String uuid;

    PasswordOwner passwordOwnerInfoWithTins;

    List<PasswordOwnerInfo> expectedPasswordOwnerInfoList;

    PasswordOwnerInfo expectedPasswordOwnerInfo;

    ProviderPreferenceServiceImpl serviceProvider = new ProviderPreferenceServiceImpl();

    @Given("^a set of \"(.*?)\", \"(.*?)\", \"(.*?)\"$")
    public void a_set_of(String corpMpin, String uuid, String uhcId) throws Throwable
    {
        this.corpMpin = corpMpin;
        this.uuid = uuid;
        this.uhcId = uhcId;
    }

    @When("^I call the cacf service$")
    public void i_call_the_cacf_service() throws Throwable
    {
        HttpHeaders headers = new HttpHeaders();
        headers.add("sm_serversessionid", "1234");
        passwordOwnerInfoWithTins = serviceProvider.getProvidersByCorporate(uuid, uhcId, corpMpin, headers, new LogMessage());
    }

    @Then("^I get back a list of \"(.*?)\"$")
    public void i_get_back_a_list_of(String tins) throws Throwable
    {
        PasswordOwner expectedPasswordOwnerInfoWithTins = new PasswordOwner();

        expectedPasswordOwnerInfoList = new ArrayList<PasswordOwnerInfo>();

        List<String> expectedTinList = buildArrayOfTins(tins);

        for (int i = 0; i < expectedTinList.size(); i++)
        {
            expectedPasswordOwnerInfo = new PasswordOwnerInfo();
            expectedPasswordOwnerInfo.setTin(expectedTinList.get(i));

            expectedPasswordOwnerInfoList.add(expectedPasswordOwnerInfo);
        }

        expectedPasswordOwnerInfoWithTins.setProviders(expectedPasswordOwnerInfoList);

        try
        {
            for (int i = 0; i < expectedPasswordOwnerInfoWithTins.getProviders().size(); i++)
            {
                Assert.assertEquals(expectedPasswordOwnerInfoWithTins.getProviders().get(i).getTin(), passwordOwnerInfoWithTins.getProviders().get(i).getTin());
            }
        }
        catch (IndexOutOfBoundsException e)
        {
            throw new Exception("Caught an exception cause theres too many expected Tins");
        }

    }

    private List<String> buildArrayOfTins(String tins)
    {
        String tinArray[] = tins.split(",");
        return Arrays.asList(tinArray);
    }

}
