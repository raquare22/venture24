@reqTimeout
Feature: Test out request timeouts for API calls

  Scenario Outline: Test that the timeout is throwing the proper exception
    Given the following information "<mpin>", "<tin>", "<classifier>", "<timeout>", and "<timeoutType>"
    When I call the preference service and aggregate the data
    Then I should get back the corresponding message with the following response: "<documentId>", and "<errorMessage>"

    Examples: 
      | timeout | timeoutType | mpin      | tin           | classifier | documentId               | errorMessage                                                    |
      |     100 | read        | 002056499 | 020695721temp | C1         |                          | com.optum.providerpreferences.rs.exception.ApplicationException |
      |    5000 | read        | 002056499 | 020695721temp | C1         | 5f2dc11ba70b910050c40a80 |                                                                 |
      |    5000 | connect     | 002056499 | 020695721temp | C1         | 5f2dc11ba70b910050c40a80 |                                                                 |
      |     100 | connect     | 002056499 | 020695721temp | C1         | 5f2dc11ba70b910050c40a80 | java.net.ConnectException                                       |
