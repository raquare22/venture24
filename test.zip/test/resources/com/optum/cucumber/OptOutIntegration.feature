@optOut
Feature: Opt out endpoint testing

	@updateOptOutDocuments
	Scenario Outline: Send Opt Out Update Request
		Given an optOutRequest object "<optOutRequest>"
		When I send this request for opt out
		Then I will verify that the correct number of <recordsUpdated> is returned
		Then I will verify that the documents have been updated with the correct data
		
		#circumvent FDS slowness, 1 mpin
	Examples: 
      | optOutRequest                                                                                                                                                               | recordsUpdated |
      #| {"tin": "020695721", "corpMpin": "002056499",  "providerMpins": ["test50921", "test50927"], "optedOutDuration": 60, "lastUpdatedBy": "jwang39", "lastUpdatedById": "1234"}  | 10             |
      | {"tin": "020695721", "corpMpin": "002056499",  "providerMpins": ["test50921"], "optedOutDuration": 60, "lastUpdatedBy": "jwang39", "lastUpdatedById": "1234"} |              5 |
	
#	
#	@getTinsForOptOut
#	Scenario Outline: Send Opt Out Tins Request
#		Given an optOutTinRequest object "<optOutTinRequest>"
#		When I send this request to get tins
#		Then I will confirm that the correct number of <tins> is returned
#	
#	Examples:
#		| optOutTinRequest                  | tins  |
#		| { "corporateMpin" : "002056499" } | 1     |
#		| { "corporateMpin" : "0" }         | 10    |
#		
#		
#	@revertExpiredOptOut
#	Scenario Outline: Revert expired opt out documents
#		Given an opt out request object "<optOutRequest>"
#		When I send this opt out request
#		Then I run the scheduler
#		Then I will verify that the opt out documents have been reverted
#	
#	Examples:
#		| optOutRequest                                                                                                                                                |
#		| {"tin": "test95721", "corpMpin": "002056499",  "providerMpins": ["test50921"], "optedOutDuration": 0, "lastUpdatedBy": "jwang39", "lastUpdatedById": "1234"} |
#
#	