@cacf
Feature: Calling CACF Services

  Scenario Outline: Get Corporate MPINs for a User  #/v1/corporates/search{?optumUuid,uhcId,appCode}  USED IN RETRIEVEPASSWORDOWNERINFO.FEATURE
    Given a collection of "<uuid>" and "<uhcId>"
    When I call the cacf service GetCorporates
    Then I get back a list of Corporates: "<name>" and "<mpin>"

    Examples: 
      | uuid                                 | uhcId | name        | mpin      |
      | a3696819-d660-4969-a7aa-9ec646a75c3c | 46141 | DIANE MOORE | 003138643 |

  Scenario Outline: Get Providers By Corporate MPIN #/v1/provider_tax_ids/search{?optumUuid,uhcId,mpin,appCode}
    Given a set of "<mpin>", "<uuid>", "<uhcId>"
    When I call the cacf service
    Then I get back a list of "<tins>"

    #Can add multiple tins for the last column using a comma (,) as delimiter -- i.e. (1234, 5678)
    Examples: 
      | mpin      | uuid                                 | uhcId | tins      |
      | 003138643 | a3696819-d660-4969-a7aa-9ec646a75c3c | 46141 | 000675607 |
