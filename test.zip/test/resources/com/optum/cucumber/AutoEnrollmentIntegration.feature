@autoEnroll
Feature: AutoEnrollment Integration testing
  Testing various flows for autoenrollment

  @existingEmails
  Scenario Outline: Checking existing emails in FDS
    Given an AutoEnrollment object with "<tin>", "<mpin>", "<fileName>", and "<providerEmailId>"
    When I check FDS for the existing emails for the given records
    Then I will verify that the "<expectedEmails>" are in the AutoEnrollment object.

    Examples: 
      | tin      | mpin     | fileName | providerEmailId                | expectedEmails                 |
      | testtin  | testmpin | C1       | sameEmailRecordWithE@optum.com | sameEmailRecordWithE@optum.com |
      | testtin2 | testmpin | C2       | replacingThisEmail@optum.com   | differentTestEmail@optum.com   |
      | testtin3 | testmpin | C3       | brandNewEmailforP@optum.com    | brandNewEmailforP@optum.com    |

  @autoEnrollmentPOST
  Scenario: Checking existing emails in FDS
    Given I add the first <metadata1> set to an Autoenrollment request
      | tin             | testtin                         |
      | mpin            | testmpin                        |
      | fileName        | C1                              |
      | providerEmailId | testEmailToBeReplaced@optum.com |
    Then I add the second <metadata2> set
      | tin             | testtin2                        |
      | mpin            | testmpin                        |
      | fileName        | C2                              |
      | providerEmailId | testEmailToBeReplaced@optum.com |
    Then I add the third <metadata3> set
      | tin             | testtin3                    |
      | mpin            | testmpin                    |
      | fileName        | C3                          |
      | providerEmailId | testEmailToBeKept@optum.com |
    Then I add the last <metadata4> set
      | tin             | testtin4                    |
      | mpin            | testmpin                    |
      | fileName        | C3                          |
      | providerEmailId | testEmailToBeKept@optum.com |
      | activeDate      | 9999-12-31T00:00:00.000Z    |
    When I send this request for AutoEnrollment
    # TODO: when activeDate is complete and sorted out, check for the correct activeDate
    #Then I will verify that new documents have been added with <expectedData>
    Then I will verify that new documents have been added to FDSCloud with <expectedData>
      | emailId1  | sameEmailRecordWithE@optum.com            |
      | fileType1 | Commercial Claim - Additional Info Needed |
      | emailId2  | differentTestEmail@optum.com              |
      | fileType2 | Commercial Claim - Acknowledgements       |
      | emailId3  | testEmailToBeKept@optum.com               |
      | fileType3 | Commercial Claim Medicaid - Non covered   |
      | emailId4  | testEmailToBeKept@optum.com               |
      | fileType4 | Commercial Claim Medicaid - Non covered   |
  #@tag2
  #Scenario Outline: Title of your scenario outline
    #Given I want to write a step with <name>
    #When I check for the <value> in step
    #Then I verify the <status> in step
#
    #Examples: 
      #| name  | value | status  |
      #| name1 |     5 | success |
      #| name2 |     7 | Fail    |
