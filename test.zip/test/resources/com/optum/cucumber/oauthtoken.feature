@oauth
Feature: Calling Oauth Token Generation Service for All Services

  Scenario Outline: Get Oauth Token for a Service
    Given a "<sessionID>"
    When I attempt to get a token for "<serviceIndicator>"
    Then I should be successful retrieving a token

    Examples: 
      | sessionID | serviceIndicator |
      |         1 | FDS              |
      #|      1234 | PSM              |
      #|        12 | LINK             |
