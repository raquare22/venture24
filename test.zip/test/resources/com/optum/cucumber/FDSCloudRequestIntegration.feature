
@FDSCloud
Feature: Title of your feature
  I want to use this template for my feature file

  @FDSCloudGet
  Scenario: Test GET request in non-prod
    Given a request to FDSCloud
    When I query on <searchTerms>
     #((name = test | name = test1) +(age >=25))
      | (recordType=UnitTestGet) |
    Then I should get <expectedCount> in return
      | expectedCount | 1 |

  @FDSCloudPostandPut
  Scenario: Test POST request in non-prod
    Given a request to FDSCloud
    When I send the <metadata>
      | tin               |                        133757370 |
      | mpin              |                        001146342 |
      | fileName          | A1                               |
      | fileType          | Commercial Prior Auth - Approved |
      | providerEmailId   | john_l_mooney@uhc.com            |
      | frequency         | D                                |
      | deliveryMethod    | E                                |
      | okToChangePDOInd  | Y                                |
      | autoEdelUpdateInd | Y                                |
    And I get <expectedresult>
    Then I should update the new document with
    | tin               |                        123456789 |
    And when I GET said document again, I should get <expectedTin>
    | expectedTin               |                        123456789 |
    And cleanup the posted document
		