@link
Feature: Link Security - Get User Profiles from UUID  

  Scenario Outline: Get User Profile by UUID #https://api-test.linkhealth.com/psm-api/v1/profile
    Given a unique "<uuid>" and "<sessionId>"
    When I call the link service
    Then I recieve a list of users with correct "<userAcctSeqNbr>", "<b2cUserId>", "<accessProfile>", "<statusCode>", "<statusDesc>", "<accountType>", "<accountDesc>", "<dept>", "<orgType>", "<title>", "<state>","<zipCode>", "<roleId>", "<roleDesc>", "<respOrgMpin>", "<hasAccessProfiles>"

    #separate the expected values by a comma and DO NOT use spaces between comma and next value -- i.e (test,test1)
    Examples: 
      | uuid                                 | sessionId | userAcctSeqNbr | b2cUserId    | accessProfile | statusCode | statusDesc | accountType | accountDesc    | dept           | orgType                               | title     | state | zipCode | roleId | roleDesc                       | respOrgMpin | hasAccessProfiles |
      | 19a0e8df-da2d-4182-9be8-a1299b415c16 |      1234 |          42936 | 83622288522A |         24041 | A          | Active     | PO          | Password Owner | Administration | Physician/Health Care Provider Office | Physician | NJ    |   07920 |     10 | Administration  -  Pre-defined |   002056499 | true              |
