@NDB
Feature: NDB Service Integration

  @provider
  Scenario Outline: call the provider service
    Given "<taxIdnumber>" and "<corpOwnerId>"
    When I call the service
    Then I get "<taxIdTypeCode>", "<provFstNm>", and "<provLstNm>"

    Examples: 
      | taxIdnumber | corpOwnerId | taxIdTypeCode | provFstNm | provLstNm |
      |   020695721 |     002056499 | T             | DIANE     | MOORE     |

  @letterPrefs
  Scenario Outline: call the get letter preferences service
    Given "<providerId>", "<providerTIN>", "<letterType>"and "<functionCode>"
    When I call the letterPref service
    Then I recieve a response

    Examples: 
      | providerId | providerTIN | letterType | functionCode |
      |    2056499 |   020695721 |            | I            |

  
  @updateletterPrefsNDB    
  Scenario Outline: 
    Given the request string: "<request>" and "<letterType>"
    When I call the update provider preferences service
    Then I call the get provider preferences service
    Then I receive a LetterPreferencesResponse with the correct list of documents: "<fileName>", "<deliveryMethod>"

    Examples: 
      | request                                                                                         | letterType |  fileName |   deliveryMethod |           
      | {"providerId": "002056499", "providerTIN": "020695721", "functionCode": "U", "mailPref": "E"}   | X1         | X1        |   P              |
      | {"providerId": "002056499", "providerTIN": "020695721", "functionCode": "U", "mailPref": "E"}   | X2         | X2        |   P              |
      