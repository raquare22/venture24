@FDS
Feature: Calling FDS Services

  @getLetterPrefsFDS
  Scenario Outline: 
    Given a provider tax id "<tin>"
    When I call the getDocuments service
    Then I recieve an FDSResponse with the correct list of documents: "<dateCreated>", "<id>", "<space_id>", "<providerName>", "<fileName>", "<fileType>", "<providerEmailId>", "<frequency>", "<deliveryMethod>"

    Examples: 
      | tin       | dateCreated                  | id                       | space_id | providerName | fileName | fileType               | providerEmailId | frequency | deliveryMethod |
      | 911853574 | Fri Mar 23 19:34:41 UTC 2018 | 5ab556d1e4b04b61f7da1cc7 |     8928 | DR.ONESHOT   | C1       | Additional Info Needed | test1@optum.com | D         | E              |

  @updateLetterPrefsFDS
  Scenario Outline: 
    Given a queue message "<msg>"
    When I call the documents service
    Then I call the getDocumentList service
    Then I receive an FDS response with the correct list of documents: "<fileName>", "<fileType>", "<providerEmailId>", "<frequency>", "<deliveryMethod>"

    Examples: 
      | msg                                                                                                                                                                                                                         |  fileName | fileType                                                                         | providerEmailId    | frequency |  deliveryMethod |
      |{"corporateTin":"020695721","corporateName":"","selectedProviders":["007169054"],"preferenceTypes":[{"classifier":"A2","deliveryMethod":"E","frequency":"D","okToChangePDOInd":"Y","providerEmailId": "newEmail2@gmail.com"}]}|  A2       | Commercial Prior Auth - Denied     | newEmail2@gmail.com | D         |  E              |
      |{"corporateTin":"020695721","corporateName":"","selectedProviders":["002056499"],"preferenceTypes":[{"classifier":"X1","deliveryMethod":"E","frequency":"D","okToChangePDOInd":"Y","providerEmailId": "newEmail@gmail.com"}]}|  X1       | Commercial Appeals and Dispute - Acknowledgement, Notification, and Response     | newEmail@gmail.com | D         |  E              |
      |{"corporateTin":"020695721","corporateName":"","selectedProviders":["002056499"],"preferenceTypes":[{"classifier":"X2","deliveryMethod":"E","frequency":"D","okToChangePDOInd":"Y","providerEmailId": "newEmail@gmail.com"}]}|  X2       | Community Plan Appeals and Disputes - Acknowledgement, Notification, and Response| newEmail@gmail.com | D         |  E              |
      
      
  @oauthRefreshFDS
  Scenario Outline: Oauth Refresh
  	Given an expired token "<expiredToken>"
  	When I call the sendRequestFDS
  	Then I receive an FDSResponse with the correct documents: "<dateCreated>", "<id>", "<space_id>", "<providerName>", "<fileName>", "<fileType>", "<providerEmailId>", "<frequency>", "<deliveryMethod>"
  	
  	
  	Examples: 
      | expiredToken                         | dateCreated                  | id                       | space_id | providerName | fileName | fileType               | providerEmailId | frequency | deliveryMethod |
      | de3fed17-70d7-4518-a27f-95f5d0d00654 | Fri Mar 23 19:34:41 UTC 2018 | 5ab556d1e4b04b61f7da1cc7 |     8928 | DR.ONESHOT   | C1       | Additional Info Needed | test1@optum.com | D         | E              |
  	