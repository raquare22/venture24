@provPrefs
Feature: Calling both NDB and FDS services for Provider Preference retrieval and update

  Scenario Outline: Retrieve Prov Prefs
    Given an "<mpin>" and a "<tin>" and a "<classifier>"
    When I call the services and aggregate the data
    Then I should get back preferences with: "<providerName>", "<classifier>" "<description>", "<deliveryMethod>", and "<documentId>"

    Examples: 
      | mpin      | tin           | providerName | classifier | description                               | deliveryMethod | documentId               |
      | 002056499 | 020695721temp |              | C1         | Commercial Claim - Additional Info Needed | E              | 5f2dc11ba70b910050c40a80 |
      | 002056499 | 020695721temp |              | C3         | Commercial Claim Medicaid - Non covered   | E              | 5f2db9f7810c24005030bd3e |
      | 002056499 |     020695721 |              | C4         | Commercial Claim - Resubmit               | E              | 5d1d1dbac9b5f0004d80827b |
      | 002056499 |     020695721 |              | C5         | Commercial Overpayment Identified         | E              | 609598a50990410050cdd232 |
      | 000014121 |     222394898 |              | C2         | Commercial Claim - Acknowledgements       | E              | 5e8e31ef23bd5d00504d6526 |
      | 000014783 |     431873267 |              | C2         | Commercial Claim - Acknowledgements       | E              | 5e8e31ef2fc67e004f64c680 |
      | 000014784 |     431873267 |              | C2         | Commercial Claim - Acknowledgements       | E              | 5e8e31ef81f4200050e73102 |
      | 000823945 |     431873267 |              | C2         | Commercial Claim - Acknowledgements       | E              | 5e8e31ef8a899c004f17db79 |
      | 000014781 |     431873267 |              | C2         | Commercial Claim - Acknowledgements       | E              | 5e8e31efed63b3004ff2cac3 |
      #Notes
      #| 000014121 |     222394898 | 90 days duration
      #| 000014783 |     431873267 | 120 days duration
      #| 000014784 |     431873267 | 180 days duration
      #| 000823945 |     431873267 | evergreen
      #| 000014781 |     431873267 | has autoenrollment date
