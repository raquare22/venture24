@passwordOwnerInfo
Feature: Retrive password owner info based on UUID

  Scenario Outline: Get Corporates by Password Owner
    Given an unique user id "<optum_uuid>"
    When I attempt to retrieving all provider tins for a password owner
    Then I expect to get back the correct "<corpName>" , "<uhcId>" , and "<corpMpin>"

    Examples: 
      | optum_uuid                           | corpName      | uhcId | corpMpin  |
      | 19a0e8df-da2d-4182-9be8-a1299b415c16 | CAILLET FRANK | 42936 | 002056499 |

