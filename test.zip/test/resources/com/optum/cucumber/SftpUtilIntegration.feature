@SFTP
Feature: Title of your feature
  I want to use this template for my feature file

  @testConnection
  Scenario Outline: SFTP to server
  Given an SFTP connection setup
  When I connect to the server for "SFTP"
  Then I should be able to access the "<dropzone>"
  
  Examples:
  | dropzone                    |
  | _dropzone_ndb_stage_archive |
  | _dropzone_ndb_prod_archive  |
  | _dropzone_lane_stage        |
  | _dropzone_lane_prod         |
  
  #can't use forward slash
  @testFileTransfer
  Scenario: SFTP to server
  Given an SFTP connection setup
  Then create <testcsv> file
  | provMpin  | tin       | letterCategory | corpMpin  |
  | 001174028 | 480559088 | A2             | 000981822 |
  | 003194384 | 581992673 | A2             | 000981954 |
  | 002849871 | 943355315 | A2             | 000982093 |
  When I connect to the server for "SFTP"
  And I drop the files into the <dropzone>
  | dropzone | _dropzone_ndb_stage |
  And run the scheduler
  Then the file should transfer to <expectedDir>
  | expectedDir | _dropzone_ndb_stage_archive_test |
  And I will initiate file cleanup
  
  @testCreateTinList
  Scenario: Create unique TIN CSV
  Given an SFTP connection setup
  Then create <testcsv1> file
  | provMpin  | tin       | letterCategory | corpMpin  |
  | 001444524 | 416006852 | A5             | 000694533 |
  | 002228008 | 416006852 | A5             | 000694533 |
  | 002332918 | 416006852 | A5             | 000694533 |
  | 002444679 | 416006852 | A5             | 000694533 |
  | 003585646 | 416006852 | A5             | 000694533 |
  | 006279534 | 416006852 | A5             | 000694533 |
  | 003214010 | 710436342 | A5             | 000695385 |
  | 003456924 | 710436342 | A5             | 000695385 |
  | 002112858 | 204474637 | A5             | 000695922 |
  | 002570297 | 204474637 | A5             | 000695922 |
  | 000768433 | 430687077 | A5             | 000696580 |
  | 001302388 | 430687077 | A5             | 000696580 |
  | 001404237 | 430687077 | A5             | 000696580 |
  | 002100506 | 430687077 | A5             | 000696580 |
  | 003094779 | 430687077 | A5             | 000696580 |
  | 004391674 | 430687077 | A5             | 000696580 |
  | 005125881 | 430687077 | A5             | 000696580 |
  | 001661314 | 631185612 | A5             | 000697045 |
  | 002263977 | 800639088 | A5             | 000697807 |
  | 003301403 | 800639088 | A5             | 000697807 |
  | 005618349 | 800639088 | A5             | 000697807 |
  | 005712538 | 800639088 | A5             | 000697807 |
  | 007169743 | 800639088 | A5             | 000697807 |
  Then create <testcsv2> file
  | provMpin  | tin       | letterCategory | corpMpin  |
  | 005703246 | 460224743 | N2             | 000899396 |
  | 006881082 | 460224743 | N2             | 000899396 |
  | 005953910 | 956152773 | N2             | 000902004 |
  | 000902030 | 870455303 | N2             | 000902030 |
  | 001397296 | 630837257 | N2             | 000902317 |
  | 001397386 | 630837257 | N2             | 000902317 |
  | 001397525 | 630837257 | N2             | 000902317 |
  | 002506714 | 630837257 | N2             | 000902317 |
  | 003606374 | 630837257 | N2             | 000902317 |
  | 004473433 | 630837257 | N2             | 000902317 |
  | 001952062 | 161395906 | N2             | 000902428 |
  | 002513143 | 161395906 | N2             | 000902428 |
  | 002519949 | 161395906 | N2             | 000902428 |
  | 002918548 | 161395906 | N2             | 000902428 |
  | 003564307 | 161395906 | N2             | 000902428 |
  | 003770635 | 161395906 | N2             | 000902428 |
  | 002409819 | 636001138 | N2             | 000902720 |
  | 003381295 | 636001138 | N2             | 000902720 |
  | 001332982 | 251651582 | N2             | 000903045 |
  | 001811759 | 251651582 | N2             | 000903045 |
  | 005378494 | 251651582 | N2             | 000903045 |
  | 000009184 | 870474317 | N2             | 000903128 |
  | 002215945 | 911780074 | N2             | 000903436 |
  | 001844374 | 591237521 | N2             | 000904264 |
  Then create <testcsv3> file
  | provMpin  | tin       | letterCategory | corpMpin  |
  | 001174028 | 480559088 | A2             | 000981822 |
  | 003194384 | 581992673 | A2             | 000981954 |
  | 002849871 | 943355315 | A2             | 000982093 |
  | 001438112 | 223316007 | A2             | 000982359 |
  | 003097252 | 223316007 | A2             | 000982359 |
  | 003272683 | 223316007 | A2             | 000982359 |
  | 005979946 | 223316007 | A2             | 000982359 |
  | 002840556 | 223172481 | A2             | 000982744 |
  | 005534873 | 223178133 | A2             | 000983171 |
  | 001297583 | 411772562 | A2             | 000983383 |
  | 001971930 | 411772562 | A2             | 000983383 |
  | 002097359 | 363807853 | A2             | 000984441 |
  | 003497792 | 363807853 | A2             | 000984441 |
  | 001905584 | 931176109 | A2             | 000985285 |
  | 002805991 | 931176109 | A2             | 000985285 |
  | 003211023 | 931176109 | A2             | 000985285 |
  | 006298649 | 931176109 | A2             | 000985285 |
  | 000986709 | 431625293 | A2             | 000986709 |
  | 006344942 | 751285603 | A2             | 000986822 |
  | 002123525 | 916064184 | A2             | 000987850 |
  | 002888812 | 421283849 | A2             | 000987922 |
  | 000987950 | 556333654 | A2             | 000987950 |
  When I connect to the server for "SFTP"
  And I mass drop the files into the <dropzone>
  | dropzone | _dropzone_ndb_stage |
  And run the scheduler
  And the files should transfer to <expectedDir>
  | expectedDir | _dropzone_ndb_stage_archive_test |
  And run the process scheduler
  Then the resulting CSV should have the <expectedUniqueTins>
  | 416006852, |
  | 710436342, |
  | 204474637, |
  | 430687077, |
  | 631185612, |
  | 800639088, |
  | 460224743, |
  | 956152773, |
  | 870455303, |
  | 630837257, |
  | 161395906, |
  | 636001138, |
  | 251651582, |
  | 870474317, |
  | 911780074, |
  | 591237521, |
  | 480559088, |
  | 581992673, |
  | 943355315, |
  | 223316007, |
  | 223172481, |
  | 223178133, |
  | 411772562, |
  | 363807853, |
  | 931176109, |
  | 431625293, |
  | 751285603, |
  | 916064184, |
  | 421283849, |
  | 556333654 |
  And I will initiate file cleanup
  
  @emailListDrop
  Scenario: SFTP to server
    Given an SFTP connection setup
    Then create <testcsv2> file
      | provMpin  | tin           | letterCategory | corpMpin  |
      | 005703246 | 46022test | N2             | 000899396 |
      | 006881082 | 46022test | N2             | 000899396 |
      | 005953910 | 95615test | N2             | 000902004 |
      | 000902030 | 87045test | N2             | 000902030 |
      | 001397296 | 63083test | N2             | 000902317 |
      | 001397386 | 63083test | N2             | 000902317 |
      | 001397525 | 63083test | N2             | 000902317 |
      | 002506714 | 63083test | N2             | 000902317 |
      | 003606374 | 63083test | N2             | 000902317 |
      | 004473433 | 63083test | N2             | 000902317 |
      | 001952062 | 16139test | N2             | 000902428 |
      | 002513143 | 16139test | N2             | 000902428 |
      | 002519949 | 16139test | N2             | 000902428 |
      | 002918548 | 16139test | N2             | 000902428 |
      | 003564307 | 16139test | N2             | 000902428 |
      | 003770635 | 16139test | N2             | 000902428 |
      | 000986709 | 43162test | A2             | 000986709 |
      | 006344942 | 75128test | A2             | 000986822 |
      | 002123525 | 91606test | A2             | 000987850 |
      | 002888812 | 42128test | A2             | 000987922 |
      | 000987950 | 55633test | A2             | 000987950 |
    When I connect to the server for "EmailList"
    And I mass drop the files into the <dropzone>
      | dropzone | _dropzone_ndb_stage |
    And run the scheduler
    Then create <testEmailList> emailList
      #| tin       | providerEmailId       |
      | 46022test | testEmail1@optum.com  |
      | 95615test | testEmail2@optum.com  |
      | 87045test | testEmail3@optum.com  |
      | 63083test | testEmail4@optum.com  |
      | 16139test | testEmail5@optum.com  |
      #below will replace with testEmail
      | 43162test | testEmail6@optum.com  |
      | 75128test | testEmail7@optum.com  |
      | 91606test | testEmail8@optum.com  |
      | 42128test | testEmail9@optum.com  |
      | 55633test | testEmail10@optum.com |
    And I drop the files into the <dropzone>
      | dropzone | _dropzone_lane_stage_test |
    And run the email list scheduler
    And I validate the number of records created
    And I will initiate email list cleanup
    And I will initiate file cleanup
