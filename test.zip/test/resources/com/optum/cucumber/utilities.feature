@utility
Feature: Testing utility methods

  Scenario: Compile/Validate Password Owner Info
    Given a table of gathered User/Password Owner Info
      #| optumUUID   (0)                      |tin(1)| uhcId (2)   | mpin       (3)      |providerName(4)| corporateName (5)                          |organizationName(6)|userAcctSeqNbr(7)| b2cUserId(8) |accessProfile(9)|statusCode(10)|statusDesc(11)|accountType(12)| accountDesc(13)| dept(14)       | orgType  (15)                         | title(16) |state(17)|zipCode(18)|roleId(19) | roleDesc(20)                   |respOrgMpin(21)|hasAccessProfiles(22)|sessionId(23)|
      | 19a0e8df-da2d-4182-9be8-a1299b415c16 | null | 42936,42936 | 002056499,002460004 | null | CAILLET FRANK,CEREBRAL PALSY CN/GRTR N BED | null | 42936 | 83622288522A | 24041 | A | Active | PO | Password Owner | Administration | Physician/Health Care Provider Office | Physician | NJ | 07920 | 10 | Administration  -  Pre-defined | 002056499 | true | 1234 |
    When I compile the password owner info
    Then I should get should match the response table
      #| uuid(0)                             | tin(1) | uhcId (2) | mpin(3) | providers(4) --> corporateName(0), mpin(1), orgName(2), provName(3), tin(4), uhcId(5)  | coporates (5) --> corporateName(0), mpin(1), orgName(2), provName(3), tin(4), uhcId(5) |
      | 19a0e8df-da2d-4182-9be8-a1299b415c16 | null | null | null | null | CAILLET FRANK,002056499,null,null,null,42936 |
