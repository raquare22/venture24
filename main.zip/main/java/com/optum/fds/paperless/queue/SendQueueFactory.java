package com.optum.fds.paperless.queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.File;
import java.io.IOException;

@Configuration
public class SendQueueFactory {
	private static final Logger LOGGER = LoggerFactory.getLogger(SendQueueFactory.class);
	private static final String PRUN_PV = "prun-pv";
	private static final String CONFIG = "config";
	private static final String PRUN_QUEUE = "prunQueue";

	@Bean
	public CsvSendQueue createCsvSendQueue() throws IOException {
		String path = getQueuePath();
		LOGGER.debug("CsvSendQueue instantiated: Using path={}{}{}", path, File.separator, "csvSendQueue");
		return new CsvSendQueue(path, "csvSendQueue");
	}

	@Bean
	public CsvSendErrorQueue createCsvSendErrorQueue() throws IOException {
		String path = getQueuePath();
		LOGGER.debug("CsvSendErrorQueue instantiated: Using path={}{}{}", path, File.separator, "csvSendErrorQueue");
		return new CsvSendErrorQueue(path, "csvSendErrorQueue");
	}

	@Bean
	public HookSendQueue createHookSendQueue() throws IOException {
		String path = getQueuePath();
		LOGGER.debug("HookSendQueue instantiated: Using path={}{}{}", path, File.separator, "hook");
		return new HookSendQueue(path, "hookSendQueue");
	}

	@Bean
	public HookSendErrorQueue createHookSendErrorQueue() throws IOException {
		String path = getQueuePath();
		LOGGER.debug("HookSendErrorQueue instantiated: Using path={}{}{}", path, File.separator, "hook");
		return new HookSendErrorQueue(path, "hookSendErrorQueue");
	}

	@Bean
	public MetadataSendQueue createMetadataSendQueue() throws IOException {
		String path = getQueuePath();
		LOGGER.debug("MetadataSendQueue instantiated: Using path={}{}{}", path, File.separator, "metadataSendQueue");
		return new MetadataSendQueue(path, "metadataSendQueue");
	}
	
	@Bean
	public MetadataSendErrorQueue createMetadataSendErrorQueue() throws IOException {
		String path = getQueuePath();
		LOGGER.debug("MetadataSendErrorQueue instantiated: Using path={}{}{}", path, File.separator, "metadataSendErrorQueue");
		return new MetadataSendErrorQueue(path, "metadataSendErrorQueue");
	}

	protected String getQueuePath() {
		String path = String.join(File.separator, "", PRUN_PV, CONFIG, PRUN_QUEUE);
		File directory = new File(path);
		if (! directory.exists()) {
			LOGGER.error("Queue directory doesn't exist creating directory={}", directory);
			if (directory.mkdirs()) {
				LOGGER.warn("Queue directory created successfully; directory={}", directory);
			} else {
				LOGGER.error("Queue directory mkdir failed; directory={}", directory);
				path = System.getProperty("user.home");
				LOGGER.warn("Using user.home={}", path);
			}
		}
		return path;
	}
}