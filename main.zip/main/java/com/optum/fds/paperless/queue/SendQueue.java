package com.optum.fds.paperless.queue;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.util.RawValue;
import com.leansoft.bigqueue.BigQueueImpl;
import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.FDSHelper;
import com.optum.fds.paperless.FDSPaperlessMain;
//import com.optum.fds.paperless.constants.CommonConstants;
import com.optum.fds.paperless.controller.FDSServicesController;
import com.optum.fds.paperless.domain.service.ServiceBase;
import com.optum.fds.paperless.exception.ValidationException;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.util.Parser;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public abstract class SendQueue extends BigQueueImpl { ////implements NotifyOnConfigEvent{
	
	@Value("${SendQueueRetryCountMax}")
	private Integer sendQueueRetryCountMax;
	
	@Value("${QUEUED_ID}")
	private String queuedId;
	
	@Value("${QUEUED_PATH_VARIABLE}")
	private String queuedpathVariable;
	
	@Value("${QUEUED_API_URL}")
	private String queuedApiUrl;
	
	@Value("${QUEUED_DELEGATE}")
	private String queuedDelegate;

	@Value("${QUEUED_DELEGATE_PARMS}")
	private String queuedDelegateParams;
	
	@Value("${QUEUED_RETRY_CNT}")
	private String queuedRetryCnt;
	
	@Value("${QUEUED_REQUEST}")
	private String queuedRequest;
	
	@Value("${QUEUED_HTTP_METHOD}")
	private String queuedHttpMethod;
	
	public static final String SOMETHING_WENT_WRONG = "SOMETHING WENT WRONG ERROR={}";
	
	@Autowired
	ServiceBase serviceBase;
	
	@Autowired
	ObjectMapper mapper;

	private static final Logger LOGGER = LogManager.getLogger(SendQueue.class);

	protected int maxRetries;

	private static final ObjectMapper objectMapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);

	protected SendQueue(String path, String name) throws IOException {
		super(path, name);
		initMethod();
	}

	public void addSendDocumentRequestToFds(String delegate, Map<String, Object> delegateParams, String apiUrl, Object request, Integer retryCnt, boolean enqueue, boolean loadTest) throws ValidationException, JsonProcessingException {
		addSendDocumentRequestToFds(delegate, delegateParams, apiUrl, request, retryCnt, enqueue, loadTest, null);
	}

	public void addSendDocumentRequestToFds(String delegate, Map<String, Object> delegateParams, String apiUrl, Object request, Integer retryCnt, boolean enqueue, boolean loadTest, String pathVariable) throws ValidationException, JsonProcessingException {
		mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
		LOGGER.debug("QUEUE addDocument: pathVariable={}, apiUrl={}, request={}, retryCnt={}, enqueue={}, loadTest={}", pathVariable, apiUrl, request, retryCnt, enqueue, loadTest);
		if (loadTest) {
			LOGGER.warn("Skipping postDocument: loadTest={}, apiUrl={}, request={}", loadTest, apiUrl, request);
			return;
		}

		maxRetries = sendQueueRetryCountMax;

		if (delegate == null) {
			delegate = "NULL";
		}

		if (pathVariable == null) {
			pathVariable = "NULL";
		}

		String url = apiUrl;
		if (url == null) {
			// TODO: Post it to the error queue. Leave it as apiUrl in the queue
			throw new ValidationException("No corresponding apiUrl to URL: apiUrl=" + apiUrl);
		}

		if (! enqueue) {
			boolean success = sendRequestToSvc(pathVariable, delegate, delegateParams, apiUrl, retryCnt, request);
			if (success) {
				return;
			} else {
				LOGGER.debug("sendRequestToSvc unsuccessful");
			}
		}

		LOGGER.debug("Queueing apiUrl={}, url={}, request={}", apiUrl, url, request);
		ObjectNode fdsParametersNode  = null;
		
		if (request instanceof MultiValueMap<?,?>) {
			String strRequest = mapper.writeValueAsString(request);
			fdsParametersNode = getSendingParameters(pathVariable, delegate, mapper.writeValueAsString(delegateParams), apiUrl, strRequest, retryCnt);
		} else {
			fdsParametersNode = getSendingParameters(pathVariable, delegate, mapper.writeValueAsString(delegateParams), apiUrl, (String) request, retryCnt);
		}
		addToQueue(fdsParametersNode);
	}

	public void sendToSvc() {
		LOGGER.debug("##### DEQUEUE #####: bigQueue.size={}", size());

		maxRetries = sendQueueRetryCountMax;
		while(! isEmpty()) {
			byte[] input;
			try {
				input = dequeue();
				if (! convertAndProcess(input)) {
					LOGGER.warn("RETRY: Failed sending request");
				}
			}
			catch (IOException e) {
				LOGGER.warn(SOMETHING_WENT_WRONG, e.getLocalizedMessage());
				cleanup();
			}
		}
		try {
			if (isEmpty()) {
				LOGGER.debug("bigQueue is empty calling gc");
				gc();
			}
		}
		catch(IOException e) {
			// TODO: This should be handled better if possible instead of killing the queue
			LOGGER.error(SOMETHING_WENT_WRONG, e.getLocalizedMessage());
			cleanup();
			return;
		}
		requeue();
		LOGGER.debug("Exiting: bigQueue.size={}", size());
	}

	//TODO: Use a retryQueue not a List
		protected abstract List<ObjectNode> getRetryList();

		protected boolean addToErrorQueue(String request) { return false; }

	protected ObjectNode getSendingParameters(String pathVariable, String delegate, String delegateParms, String apiUrl, String request, Integer retryCnt) {
		UUID uuid = UUID.randomUUID();
		return objectMapper.createObjectNode()
				.put(queuedId, uuid.toString())
				.put(queuedpathVariable, pathVariable)
				.put(queuedDelegate, delegate)
				.put(queuedDelegateParams, delegateParms)
				.put(queuedApiUrl, apiUrl)
				.put(queuedRetryCnt, retryCnt)
				.put(queuedRequest, request);
	}

	protected boolean addToQueue(ObjectNode request) {
		boolean addedToQueue = false;
		try {
			String stringForQueue = objectMapper.writeValueAsString(request);
			LOGGER.debug("string to be added in queue {}", stringForQueue);
			enqueue(stringForQueue.getBytes(StandardCharsets.UTF_8));
			addedToQueue = true;
		}
		catch(IOException e) {
			LOGGER.warn(SOMETHING_WENT_WRONG, e.getLocalizedMessage());
			cleanup();
		}
		return addedToQueue;
	}

	protected boolean convertAndProcess(byte[] input) {
		if(input == null) {
			LOGGER.debug("byte[] array is null");
			return true;
		}
		ObjectNode readNode;
		try {
			readNode = objectMapper.readValue(input, ObjectNode.class);
			String id = readNode.get(queuedId).asText();
			String pathVariable = readNode.get(queuedpathVariable).asText();
			String delegate = readNode.get(queuedDelegate).asText();
			String delegateParms = readNode.get(queuedDelegateParams).asText();
			String apiUrl = readNode.get(queuedApiUrl).asText();
			Integer retryCnt = readNode.get(queuedRetryCnt).asInt();
			String request = readNode.get(queuedRequest).toString();

			try {
				@SuppressWarnings("unchecked")
				Map<String, Object> delegateParamsMap = null;
				try {
					delegateParamsMap = Parser.readValue(delegateParms, new TypeReference<HashMap<String, Object>>(){});
				} catch (JsonProcessingException e) {
					LOGGER.error("responseDetailMap error: {}", e.getMessage());
				}
				boolean isSendToSvc = sendRequestToSvc(pathVariable, delegate, delegateParamsMap, apiUrl, retryCnt, request);
				LOGGER.debug("id={}, request={} is {}send to svc", id, request, (isSendToSvc)? "" : "not ");
				if (! isSendToSvc) {
					if (retryCnt >= maxRetries) {
						LOGGER.warn("RETRY: Count exceeded; retryCnt={}, maxRetries={}, request={}", retryCnt, maxRetries, request);
						//If autoErrorQueue put to the errorQueue
						if (! addToErrorQueue(request)) {
							//TODO: This must get back to the callback delegate
						}
						return isSendToSvc;
					}
					LOGGER.warn("RETRY: Put on retryList.size={}", getRetryList().size());
					ObjectNode retryRequest = convertAndRetry(id, pathVariable, delegate, delegateParms, apiUrl, retryCnt, request);
					if (retryRequest != null) {
						getRetryList().add(retryRequest);
						LOGGER.warn("RETRY: Added to retryList.size={}, retryList.size(), retryCnt={}, id={}, request={}", getRetryList().size(), retryCnt, id, request);
					}
				}
				return isSendToSvc;
			} catch (Exception e) {
				LOGGER.error("sendToSvc failure: retryCnt={}, request={}; {}", retryCnt, request, ExceptionUtils.getStackTrace(e));
				if (retryCnt >= maxRetries) {
					LOGGER.error("RETRY: Count exceeded; retryCnt={}, maxRetries={}, request={}", retryCnt, maxRetries, request);
					if (! addToErrorQueue(request)) {
						//TODO: This must get back to the callback delegate
						if (delegate != null && ! delegate.isEmpty() && ! delegate.equals("NULL")) {
							//LOGGER.info("QUEUE: Invoking delegate={}, delegateParms={}, apiUrl={}, request={}", delegate, delegateParms, apiUrl, request);
							//FDSPaperlessMain.runProcess(delegate, delegateParms, responseEntity.getBody());
						} else {
							LOGGER.debug("Not invoking delegate={}, delegateParms={}, apiUrl={}, request={}", delegate, delegateParms, apiUrl, request);
						}
					}
				} else {
					LOGGER.warn("RETRY: Put on retryList.size={}", getRetryList().size());
					ObjectNode retryRequest = convertAndRetry(id, pathVariable, delegate, delegateParms, apiUrl, retryCnt, request);
					if (retryRequest != null) {
						getRetryList().add(retryRequest);
						LOGGER.warn("RETRY: Added to retryList.size={}, retryList.size(), retryCnt={}, id={}, request={}", getRetryList().size(), retryCnt, id, request);
					}
				}
			}
		} catch (IOException e) {
			LOGGER.warn("Error while Converting byte[] to ObjectNode, inputString={} errorMessage={}", new String(input, StandardCharsets.UTF_8), e.getLocalizedMessage());
			//TODO: This must get back to the callback delegate
		}
		return false;
	}

	protected ObjectNode convertAndRetry(String id, String pathVariable, String delegate, String delegateParms, String apiUrl, int retryCnt, String request) {
		if (++retryCnt >= maxRetries) {
			LOGGER.warn("RETRY: count exceeded; id={}, request={}", id, request);
			return null;
		}

		LOGGER.warn("RETRY: retryCnt={}, id={}, request={}", retryCnt, id, request);
		return objectMapper.createObjectNode()
			.put(queuedId, id)
			.put(queuedpathVariable, pathVariable)
			.put(queuedDelegate, delegate)
			.put(delegateParms, delegateParms)
			.put(queuedApiUrl, apiUrl)
			.put(queuedRetryCnt, retryCnt)
			.putRawValue(queuedRequest, new RawValue(request));
	}

	protected boolean sendRequestToSvc(String pathVariable, String callbackDelegate, Map<String, Object> delegateParams, String apiUrl, Integer retryCount, Object request) {
		String url = apiUrl;
		if (url == null) {
			// This should never happen
			return false;
		}

		if (pathVariable.equals("NULL")) {
			pathVariable = null;
		}
		
		ResponseEntity<GenericResponse> responseEntity = null;
		
		if (request instanceof MultiValueMap<?,?>) {
			responseEntity = postRequestMultipart(url, (MultiValueMap<String, Object>) request, pathVariable);
		} else {
			responseEntity = postRequestGenericResponse(url, (String) request, pathVariable);
		}


		LOGGER.info("SERVICE: sendToSvc response; statusCode={}, body={}, headers={}",
				responseEntity.getStatusCode(), Encode.forJava(String.valueOf(responseEntity.getBody())), Encode.forJava(String.valueOf(responseEntity.getHeaders())));
		boolean success = responseEntity.getStatusCode() == HttpStatus.OK || responseEntity.getStatusCode() == HttpStatus.CREATED;
		if (success) {
			if (callbackDelegate != null && ! callbackDelegate.isEmpty() && ! callbackDelegate.equals("NULL")) {
				LOGGER.info("QUEUE: Invoking delegate={}, delegateParms={}, apiUrl={}, url={}, request={}", callbackDelegate, delegateParams, apiUrl, url, request);
				FDSHelper.runProcess(callbackDelegate, delegateParams, responseEntity.getBody());
			} else {
				LOGGER.info("Not invoking callbackDelegate={}, delegateParams={}, apiUrl={}, url={}, request={}", callbackDelegate, delegateParams, apiUrl, url, request);
			}
		}
		return success;
	}

	protected ResponseEntity<GenericResponse> postRequestGenericResponse(String apiUrl, String request, String pathVariable) {
		LOGGER.info("apiUrl={}, request={}, pathVariable={}", apiUrl, request, pathVariable);
		return serviceBase.postRequestToSvc(apiUrl, request, pathVariable);
	}
	
	
	protected ResponseEntity<GenericResponse> postRequestMultipart(String apiUrl, MultiValueMap<String, Object> requestMap, String pathVariable) {
		LOGGER.info("apiUrl={}, request={}, pathVariable={}", apiUrl, requestMap, pathVariable);
		return serviceBase.postRequestToSvcMultipartForm(apiUrl, requestMap, pathVariable);
	}

	protected void requeue() {
		List<ObjectNode> retryList = getRetryList();
		if (! retryList.isEmpty()) {
			LOGGER.warn("REQUEUE: retryList.size={}", retryList.size());
			for (ObjectNode objectNode : retryList) {
				addToQueue(objectNode);
			}
			retryList.clear();
			LOGGER.debug("REQUEUE: bigQueue.size={}", size());
		}
	}

	private void cleanup() {
		LOGGER.warn("Cleanup BigQueue");
		try {
			close();
			gc();
		}
		catch (IOException e) {
			LOGGER.debug("{}", e.getLocalizedMessage());
		}
	}

	private void initMethod() {
		////configData.registerForConfigChange(this);
	}
}
