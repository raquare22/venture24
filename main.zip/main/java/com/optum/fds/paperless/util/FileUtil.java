/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2014.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who                     	Revision
 * Feb 10 2015  Chidambaram Jeyabalan 		Initial version
 ****************************************************************/


////package com.optum.fs.util;
package com.optum.fds.paperless.util;


import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileUtil {
	private static final String VK_PERIOD = ".";
	private static FileUtil instance = null;
	private static InetAddress localhost = null;
	private static final Logger log = LoggerFactory.getLogger(FileUtil.class);

	private FileUtil(){}

	public synchronized static FileUtil getInstance(){
		if(instance == null){
			instance = new FileUtil();
		}

		if(localhost == null){
			try {
				localhost = InetAddress.getLocalHost();
			} catch (UnknownHostException e) {
				log.error("getInstance Could not get localhost. {}", ExceptionUtils.getStackTrace(e));
			}
		}

		return instance;
	}

	/**
	 * Use this if you are passing filenames that have spaces to unix command line programs
	 * if input is null,  null is returned
	 * @param input
	 * @return
	 */
	public static final String addQuotesAroundName(String input) {
		String retVal = input;
		if(input != null) {
			StringBuilder sb = new StringBuilder();
			sb.append("\"").append(input).append("\"");
			retVal =  sb.toString();
		}
		return retVal;
	}

	public static final List<File> getFilesByExtension(String extension, File directory) throws IOException{
		return getFilesByExtension(extension, directory.toPath());
	}

    public static final List<File> getFilesByExtension(String extension, Path directory) throws IOException{
		List<File> files = new ArrayList<>();
		try(final DirectoryStream<Path> stream = Files.newDirectoryStream(directory, "*." + extension)){
			stream.forEach(file -> files.add(file.toFile()));
		} catch (IOException e) {
			log.warn("getFilesByExtension {}={}, {}={} {}",
					"extension", extension,
					"directory", directory != null ? directory.toString() : "NULL",
                    ExceptionUtils.getStackTrace(e));
			throw e;
		}

		return files;
	}


	/**
	 * Use this if you are passing filenames that have spaces to unix command line programs
	 * if input is null,  null is returned
	 * @param name
	 * @return
	 */
	public static final String replaceSpaceToUnderScoreInFilename(String name) {
		String retVal = name;
		if(name != null && name.contains(" ")) {
			retVal = name.replace(" ", "_");
		}
		return retVal;
	}

	public static final Long totalBytesAtLocation(Path location){
		return totalBytesAtLocation(location, new ArrayList<String>());
	}
	public static final Long totalBytesAtLocation(Path location, List<String> extensionsToExclude){
		final Long[] totalBytes = {0L};

		try(final Stream<Path> stream = Files.list(location)){
			stream.filter(Files::isRegularFile).forEach(file -> {
				final Boolean[] exclude = {false};
				extensionsToExclude.forEach(extensionToExclude ->{
					if(file.getFileName().toString().endsWith(extensionToExclude)){
						exclude[0] = true;
					}
				});
				if(!exclude[0]){
					totalBytes[0] += file.toFile().length();
				}
			});
		}
		catch (IOException e) {
			log.error("totalBytesAtLocation {}={}, {}={} {}",
					"location", location != null ? location.toString() : "NULL",
					"extensionsToExclude", extensionsToExclude != null ? extensionsToExclude.toString() : "NULL",
                    ExceptionUtils.getStackTrace(e));
		}

		return totalBytes[0];
	}


	/**
	 * Returns the local host IP
	 * @return
	 */
	public String getLocalHostIP(){
		return localhost.getHostAddress();
	}

	/**
	 * Returns the Local Hostname
	 * @return
	 */
	public String getLocalHostName(){
		return localhost.getHostName();
	}

	public String removeFileExtesion(String fileName){
		String tmpFileName = fileName;
		
		if(fileName!=null &&
				!StringUtils.isEmpty(fileName) &&
				fileName.length() > 2 &&
				fileName.contains(VK_PERIOD) ){
			int index = fileName.lastIndexOf(VK_PERIOD);
			tmpFileName = fileName.substring(0,index);
		}
		return tmpFileName;
	}

}
