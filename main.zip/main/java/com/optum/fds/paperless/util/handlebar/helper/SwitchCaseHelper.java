////package com.optum.fs.handlebar.helper;
package com.optum.fds.paperless.util.handlebar.helper;

import java.io.IOException;
import java.util.Optional;

import com.github.jknack.handlebars.Helper;
import com.github.jknack.handlebars.Options;
import com.optum.fds.paperless.util.handlebar.helper.pojo.SwitchCase;
////import com.optum.fs.handlebar.helper.pojo.SwitchCase;

public class SwitchCaseHelper implements Helper<Object> {
	SwitchCase switchCase;

	public SwitchCaseHelper(SwitchCase switchCase){
		this.switchCase = switchCase;
	}

	@Override
	public CharSequence apply(Object value, Options options) throws IOException {
		this.switchCase.setValue(value);
		this.switchCase.setSwitchBreak(false);
		return options.fn();
	}

	public static class Case implements Helper<Object> {
		private static final String BREAK = "break";
		SwitchCase switchCase;

		public Case(SwitchCase switchCase){
			this.switchCase = switchCase;
		}

		@Override
		public CharSequence apply(Object value, Options options) throws IOException {
			if(switchCase.isSwitchBreak()){
				return options.inverse();
			}

			boolean breaks = Optional.ofNullable(options.hash(BREAK))
					.filter(context -> context instanceof Boolean)
					.map(context -> ((Boolean) context).booleanValue())
					.orElse(true);

			if (switchCase.getValue().equals(value)) {
				switchCase.setSwitchBreak(breaks);
				return options.fn(this);
			}else{
				return options.inverse();
			}
		}
	}

	public static class Default implements Helper<Object> {
		SwitchCase switchCase;

		public Default(SwitchCase switchCase){
			this.switchCase = switchCase;
		}

		@Override
		public CharSequence apply(Object value, Options options) throws IOException {
			return (switchCase.isSwitchBreak())?  options.inverse() : options.fn();
		}
	}
}