////package com.optum.fds.paperless.processorlistener.util;
package com.optum.fds.paperless.util;

import org.bouncycastle.crypto.DataLengthException;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.authentication.UserCredentials;


public class FsCredentials extends UserCredentials {

	private static final Logger logger = LoggerFactory
			.getLogger(FsCredentials.class);

	public FsCredentials(String username, String password) {
		super(username, password);
	}

	private String decrypt(String encryptedStr) {
		String retVal = null;
		try {
			retVal =  EncryptionUtil.decrypt(encryptedStr);
		} catch (DataLengthException | IllegalStateException
				| InvalidCipherTextException e) {
			logger.error("error decrypting password", e);
		}
		return retVal;
	}
	
	@Override
	public String getPassword() {
	  return decrypt(super.getPassword());
	}
}