////package com.optum.fs.handlebar.helper.pojo;
package com.optum.fds.paperless.util.handlebar.helper.pojo;

public class SwitchCase {
	Object value;
	boolean switchBreak;
	
	public Object getValue() {
		return value;
	}
	public boolean isSwitchBreak() {
		return switchBreak;
	}
	public void setValue(Object value) {
		this.value = value;
	}
	public void setSwitchBreak(boolean switchBreak) {
		this.switchBreak = switchBreak;
	}

}
