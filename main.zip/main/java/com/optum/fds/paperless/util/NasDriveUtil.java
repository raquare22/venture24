package com.optum.fds.paperless.util;


import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.FileAttributes;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.SmbConfig;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import com.hierynomus.protocol.commons.socket.ProxySocketFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.EnumSet;
import java.util.UUID;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class NasDriveUtil {

	@Value("${SMB_USERNAME}")
    private String smbUser;

	@Value("${SMB_PASSWORD}")
    private String smbPass;

	@Value("${NAS_SERVER}")
    private String nasServer;

	@Value("${NAS_SHARE}")
    private String nasShare;

	@Value("${SMB_CONNECT_TIMEOUT_MILLIS:10000}")
	private int smbConnectTimeoutMillis;

	@Value("${SMB_READ_TIMEOUT_MILLIS:60000}")
	private long smbReadTimeoutMillis;

	@Value("${SMB_WRITE_TIMEOUT_MILLIS:120000}")
	private long smbWriteTimeoutMillis;

	@Value("${SMB_TRANSACT_TIMEOUT_MILLIS:60000}")
	private long smbTransactTimeoutMillis;

	@Value("${SMB_SOCKET_TIMEOUT_MILLIS:150000}")
	private long smbSocketTimeoutMillis;

	private static final Logger LOGGER = LoggerFactory.getLogger(NasDriveUtil.class);

	private volatile Semaphore nasTransferSemaphore = new Semaphore(1, true);

	@Value("${NAS_TRANSFER_MAX_CONCURRENT_SESSIONS:1}")
	void configureNasTransferSemaphore(int maxConcurrentSessions) {
		if (maxConcurrentSessions < 1) {
			throw new IllegalArgumentException("NAS transfer maximum concurrent sessions must be at least 1");
		}
		nasTransferSemaphore = new Semaphore(maxConcurrentSessions, true);
	}


    /**
     * Connect to NAS via SMB
     */
    public void moveFileFromLocalToNAS(String targetDir, String localFileName, int maxTries, long retryTimeSecs) throws Exception {

		if (maxTries < 1) {
			// set maxTries to minimum 1 if it is 0 or negative to force at least 1 attempt
			maxTries = 1;
		}

    	boolean success = false;

	  for (int tries = 0; tries < maxTries; tries++) {
		long sourceBytes = -1;
		boolean sessionAcquired = false;

	try {
		nasTransferSemaphore.acquire();
		sessionAcquired = true;

		SmbConfig smbConfig = SmbConfig.builder()
				.withSocketFactory(new ProxySocketFactory(smbConnectTimeoutMillis))
				.withReadTimeout(smbReadTimeoutMillis, TimeUnit.MILLISECONDS)
				.withWriteTimeout(smbWriteTimeoutMillis, TimeUnit.MILLISECONDS)
				.withTransactTimeout(smbTransactTimeoutMillis, TimeUnit.MILLISECONDS)
				.withSoTimeout(smbSocketTimeoutMillis, TimeUnit.MILLISECONDS)
				.build();

		try (SMBClient smbClient = new SMBClient(smbConfig); Connection connection = smbClient.connect(nasServer)) {

    		AuthenticationContext auth = new AuthenticationContext(smbUser,smbPass.toCharArray(), "");


    		try (Session session = connection.authenticate(auth); DiskShare share = (DiskShare) session.connectShare(nasShare)) {

    			Path localPath = Path.of(localFileName);

    			String fileName = localPath.getFileName().toString();


    			String remoteDir = targetDir;

    			remoteDir = "/out" + remoteDir;

    			remoteDir = remoteDir.replace("/", "\\");


    			if (remoteDir.startsWith("\\")) {
    				remoteDir = remoteDir.substring(1);
    				}

			String remoteFile = remoteDir + "\\" + fileName;
			String temporaryRemoteFile = remoteFile + "." + UUID.randomUUID() + ".part";
			long expectedSourceBytes = Files.size(localPath);
			boolean temporaryFilePromoted = false;

			try {
				try (File smbFile = share.openFile(
						temporaryRemoteFile,
    					EnumSet.of(AccessMask.GENERIC_WRITE),
    					EnumSet.of(FileAttributes.FILE_ATTRIBUTE_NORMAL),
    					EnumSet.of(
    							SMB2ShareAccess.FILE_SHARE_READ,
    							SMB2ShareAccess.FILE_SHARE_WRITE),
    					SMB2CreateDisposition.FILE_OVERWRITE_IF,
    					null);
						FileInputStream fis = new FileInputStream(localFileName)) {
					byte[] buffer = new byte[1024 * 1024];
					long fileOffset = 0;
					int bytesRead;

					while ((bytesRead = fis.read(buffer)) != -1) {
						long bytesWritten = smbFile.write(buffer, fileOffset, 0, bytesRead);
						if (bytesWritten != bytesRead) {
							throw new IOException("Incomplete NAS file write");
						}
						fileOffset += bytesWritten;
					}

					sourceBytes = fileOffset;

				}

				if (sourceBytes != expectedSourceBytes || Files.size(localPath) != expectedSourceBytes) {
					throw new IOException("Source file changed during NAS transfer");
				}

				long remoteBytes = share.getFileInformation(temporaryRemoteFile).getStandardInformation().getEndOfFile();
				if (remoteBytes != expectedSourceBytes) {
					throw new IOException("NAS file size does not match source file size");
				}

				if (share.fileExists(remoteFile)) {
					LOGGER.warn("NAS archive target already exists; retaining the existing archive");
				} else {
					try (File temporarySmbFile = share.openFile(
							temporaryRemoteFile,
							EnumSet.of(AccessMask.DELETE),
							EnumSet.of(FileAttributes.FILE_ATTRIBUTE_NORMAL),
							EnumSet.of(
									SMB2ShareAccess.FILE_SHARE_READ,
									SMB2ShareAccess.FILE_SHARE_WRITE),
							SMB2CreateDisposition.FILE_OPEN,
							null)) {
						temporarySmbFile.rename(remoteFile, false);
						temporaryFilePromoted = true;
					} catch (Exception renameException) {
						if (!share.fileExists(remoteFile)) {
							throw renameException;
						}
						LOGGER.warn("NAS archive target was created during promotion; retaining the existing archive");
					}
				}
			} finally {
				if (!temporaryFilePromoted) {
					try {
						share.rm(temporaryRemoteFile);
					} catch (Exception cleanupException) {
						LOGGER.warn("NAS incomplete transfer cleanup failed: exceptionType={}", cleanupException.getClass().getSimpleName());
					}
				}
			}

    			success=true;
				LOGGER.info("NAS transfer completed: attempt={}, maxAttempts={}, sourceBytes={}",
						tries + 1, maxTries, sourceBytes);
                break;
	    		}
	    	}
	    	} catch(Exception e) {
	    		if(tries >= maxTries - 1) {
                LOGGER.error("NAS transfer failed: attempt={}, maxAttempts={}, sourceBytes={}, exceptionType={}, retrying=false",
                		tries + 1, maxTries, sourceBytes >= 0 ? sourceBytes : null, e.getClass().getSimpleName());
                throw e;
            } else {
				LOGGER.warn("NAS transfer failed: attempt={}, maxAttempts={}, sourceBytes={}, exceptionType={}, retrying=true",
						tries + 1, maxTries, sourceBytes >= 0 ? sourceBytes : null, e.getClass().getSimpleName());
	    		}
	    	} finally {
	    		if (sessionAcquired) {
	    			nasTransferSemaphore.release();
	    		}
	    	}



    	if (!success) {
            long waitSecs = computeBackoffSecs(tries);
            sleepSecondsQuietly(waitSecs);
        }
      }
    }


    private static long addJitter(long baseSeconds) {
        // Add ±20% jitter
        double jitter = 0.2 * baseSeconds;
        long min = (long) (baseSeconds - jitter);
        long max = (long) (baseSeconds + jitter);
        return ThreadLocalRandom.current().nextLong(min, max + 1);
    }

    private static long computeBackoffSecs(int attemptIndex /* 0-based */) {
		final long[] BACKOFF = new long[] { 10, 30, 60, 90 };
        long base = (attemptIndex < BACKOFF.length) ? BACKOFF[attemptIndex] : BACKOFF[BACKOFF.length - 1];
        return addJitter(base);
	}

    private static void sleepSecondsQuietly(long secs) {
		try {
			TimeUnit.SECONDS.sleep(secs);
		} catch (InterruptedException ie) {
			Thread.currentThread().interrupt();
			LOGGER.warn("SFTP retry sleep interrupted");
		}
	}

}
