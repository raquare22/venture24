package com.optum.fds.paperless.util;


import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.FileAttributes;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;

import java.io.FileInputStream;
import java.nio.file.Path;
import java.util.EnumSet;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class NasDriveUtil {

	@Value("${SMB_USERNAME}")
    private String smbUser;

	@Value("${SMB_PASSWORD}")
    private String smbPass;

	@Value("${NAS_SERVER}")
    private String nasServer;

	@Value("${NAS_SHARE}")
    private String nasShare;

	private static final Logger LOGGER = LoggerFactory.getLogger(NasDriveUtil.class);


    /**
     * Connect to NAS via SMB
     */
    public void moveFileFromLocalToNAS(String targetDir, String localFileName, int maxTries, long retryTimeSecs) throws Exception {




    	boolean success = false;

      for (int tries = 0; tries < maxTries; tries++) {

    	try (SMBClient smbClient = new SMBClient(); Connection connection = smbClient.connect(nasServer)) {

    		AuthenticationContext auth = new AuthenticationContext(smbUser,smbPass.toCharArray(), "");


    		try (Session session = connection.authenticate(auth); DiskShare share = (DiskShare) session.connectShare(nasShare)) {

    			Path localPath = Path.of(localFileName);

    			String fileName = localPath.getFileName().toString();


    			String remoteDir = targetDir;

    			remoteDir = "/out" + remoteDir;

    			remoteDir = remoteDir.replace("/", "\\");


    			if (remoteDir.startsWith("\\")) {
    				remoteDir = remoteDir.substring(1);
    				}

    			String remoteFile = remoteDir + "\\" + fileName;

    			try (File smbFile = share.openFile(
    					remoteFile,
    					EnumSet.of(AccessMask.GENERIC_WRITE),
    					EnumSet.of(FileAttributes.FILE_ATTRIBUTE_NORMAL),
    					EnumSet.of(
    							SMB2ShareAccess.FILE_SHARE_READ,
    							SMB2ShareAccess.FILE_SHARE_WRITE),
    					SMB2CreateDisposition.FILE_OVERWRITE_IF,
    					null);
    					FileInputStream fis = new FileInputStream(localFileName)) {
    				    byte[] buffer = fis.readAllBytes();
    				    smbFile.write(buffer, 0);

    			}

    			success=true;
                break;
    		}
    	}catch(Exception e) {
    		if(tries >= maxTries - 1) {
                LOGGER.error("moveFileFromLocalToNAS {}, {}, {}, {}={}, {}={}, {}={}, {}={} {}",
                		smbUser, nasServer, nasShare,  "fromDir", localFileName, "targetDir", targetDir,
					 "MAX_TRIES", maxTries, "RETRY_TIME_SECS", retryTimeSecs, ExceptionUtils.getStackTrace(e));
                throw e;
            } else {
				LOGGER.warn("NAS MOVE attempt {} failed for file  ({} -> {}). Retrying, e={}", tries + 1, localFileName, targetDir, e.getMessage());
			}
    	}



    	if (!success) {
            long waitSecs = computeBackoffSecs(tries);
            sleepSecondsQuietly(waitSecs);
        }
      }
    }


    private static long addJitter(long baseSeconds) {
        // Add ±20% jitter
        double jitter = 0.2 * baseSeconds;
        long min = (long) (baseSeconds - jitter);
        long max = (long) (baseSeconds + jitter);
        return ThreadLocalRandom.current().nextLong(min, max + 1);
    }

    private static long computeBackoffSecs(int attemptIndex /* 0-based */) {
		final long[] BACKOFF = new long[] { 10, 30, 60, 300 };
        long base = (attemptIndex < BACKOFF.length) ? BACKOFF[attemptIndex] : BACKOFF[BACKOFF.length - 1];
        return addJitter(base);
	}

    private static void sleepSecondsQuietly(long secs) {
		try {
			TimeUnit.SECONDS.sleep(secs);
		} catch (InterruptedException ie) {
			Thread.currentThread().interrupt();
			LOGGER.warn("SFTP retry sleep interrupted");
		}
	}

}