package com.optum.fds.paperless.util.handlebar.helper.pojo;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;
import java.util.stream.Collectors;

public final class NormalizeUtil {
    private NormalizeUtil() {
        // private constructor to prevent instantiation
    }

    private static final ObjectMapper LOCAL_MAPPER = new ObjectMapper();


    public static String normalizePipeDelimitedValue(Object raw) {
        if (raw == null) {
            return null;
        }

        if (raw instanceof Collection<?> col) {
            return col.stream()
                    .filter(Objects::nonNull)
                    .map(String::valueOf)
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.joining("|"));
        }

        if (raw instanceof String s && !s.isBlank()) {
            String trimmed = s.trim();

            if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
                String inner = trimmed.substring(1, trimmed.length() - 1).trim();
                try {
                    Collection<String> parsed = LOCAL_MAPPER.readValue(
                            trimmed, new TypeReference<Collection<String>>() {});
                    return parsed.stream()
                            .filter(Objects::nonNull)
                            .map(String::trim)
                            .filter(v -> !v.isEmpty())
                            .collect(Collectors.joining("|"));
                } catch (Exception ignored) {
                    return Arrays.stream(inner.split("\\s*,\\s*"))
                            .map(part -> part.replaceAll("^\"|\"$", "").trim())
                            .filter(part -> !part.isEmpty())
                            .collect(Collectors.joining("|"));
                }
            }

            return trimmed;
        }

        return String.valueOf(raw);
    }
}
