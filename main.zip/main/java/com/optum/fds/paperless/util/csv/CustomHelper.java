////package com.optum.fs.csv.util;
package com.optum.fds.paperless.util.csv;

import java.io.IOException;

import com.github.jknack.handlebars.Handlebars;
import com.github.jknack.handlebars.Helper;
import com.github.jknack.handlebars.Options;

public class CustomHelper implements Helper<Object>{

	@Override
	public CharSequence apply(Object value, Options options) throws IOException {
		return (Handlebars.Utils.isEmpty(value)) ? options.param(0, "") : String.valueOf(value);
	}

}
