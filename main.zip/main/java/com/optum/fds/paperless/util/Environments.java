package com.optum.fds.paperless.util;

public enum Environments {
    LOCAL("local"),
    TEST("test"),
    DEV("dev"),
    STAGE("stage"),
    PROD("prod");

    private final String env;

    Environments(String env) {
        this.env = env;
    }
    
    public String getEnv() {
        return env;
    }
}
