package com.optum.fds.paperless.util;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.springframework.http.*;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import jakarta.ws.rs.core.UriBuilderException;
import java.net.URI;
import java.net.URISyntaxException;

public class HttpUtils {
    public static <T> ResponseEntity<T> postExchange( HttpHeaders headers,
                                                      MultiValueMap<?, ?> reqPayload,
                                                      String url,
                                                      Class<T> responseType,
                                                      RestTemplate restTemplate) throws RestClientException {

        HttpEntity<?> requestEntity = new HttpEntity<>(reqPayload, headers);
        String verifiedURL=null;
        if(restTemplate == null){
            restTemplate = new RestTemplate();
        }
        try{
            verifiedURL = Encode.forJava(url);
        }catch (UriBuilderException e){
            throw new RestClientException("Error building URI", e);
        }
        return restTemplate.exchange(verifiedURL, HttpMethod.POST, requestEntity, responseType);
    }
    
	public static boolean validateStatusCode(HttpStatusCode statusCodeToSearch) {

		return HttpStatus.INTERNAL_SERVER_ERROR.equals(statusCodeToSearch)
				|| HttpStatus.BAD_GATEWAY.equals(statusCodeToSearch)
				|| HttpStatus.SERVICE_UNAVAILABLE.equals(statusCodeToSearch)
				|| HttpStatus.GATEWAY_TIMEOUT.equals(statusCodeToSearch);
	}
}
