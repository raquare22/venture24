package com.optum.fds.paperless.util;

import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.stream.Collectors;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;

@Component
public class SftpMonitorUtil {

	@Value("${INGEST_ROOT}")
	private String ingestRoot;
	
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SftpMonitorUtil.class);
	
	private static final int SFTP_PORT = 22;
	//private static final String INGEST_ROOT = ingestRoot;

	private static final String DIRECTORY_LISTING = "directoryListing";
    private static final String CHANNEL_SFTP = "channelSftp";
    private static final String SFTP_SESSION = "sftpSession";
    private static final String CHANNEL = "channel";

	@SuppressWarnings("unchecked")
    public Map<String, Object> proccessSFTPDirectory(String sftpUSER, String sftpPASS, String sftpHost, String sftpWorkingDir ) throws JSchException, SftpException {
	    Map<String, Object> result = new HashMap<>();
        Session sftpSession;
        Channel channel;
        ChannelSftp channelSftp;
        sftpSession = SftpUtil.createSesssion(sftpUSER, sftpPASS, sftpHost, SFTP_PORT);
        channel = SftpUtil.createSFTPChannel(sftpSession);
        channelSftp = (ChannelSftp) channel;

        LOGGER.debug("proccessSFTPDirectory cd to sftpWorkingDir: {}", sftpWorkingDir );
        try {
            channelSftp.cd(sftpWorkingDir);
        } catch (Exception e) {
            LOGGER.error("proccessSFTPDirectory Failure: cd to sftpWorkingDir: {}, errMsg={}", sftpWorkingDir, e.getMessage());
            throw e;
        }
        
        var directoryListing = ((Vector<ChannelSftp.LsEntry>)channelSftp.ls(channelSftp.pwd()))
                .stream()
                .sorted(Comparator.comparingInt(o -> o.getAttrs().getMTime()))
                .collect(Collectors.toList());
        result.put(DIRECTORY_LISTING, directoryListing);
        result.put(CHANNEL_SFTP, channelSftp);
        result.put(SFTP_SESSION, sftpSession);
        result.put(CHANNEL, channel);
        return result;
    }

	public String createFileOutputDirectoryPath(Map processConfig, ProcessorMetaData processor, String dirFromFileName) {
	    return ingestRoot
	        + "/" + processor.getAppIdentifier() 
	        + "/" + processor.getConfigSpaceId().toString()
	        + "/" + dirFromFileName.replaceAll("\\.\\w{0,4}", "");
    }

    public boolean exceptionForMissingLoginCredential(String sftpHost, String sftpUSER, String sftpPASS, String sftpWorkingDir ) throws IOException {
        if( isMissingLoginCredential(sftpHost, sftpUSER, sftpPASS, sftpWorkingDir )) {
            LOGGER.debug("runCsvSFTPMonitor Login credentials must be supplied ; not able to login to SFTP host={}", sftpHost);
            throw new IOException("Missing login credentials host=" + sftpHost);
        }
        return false;

    }

	public boolean isMissingLoginCredential(String sftpHost, String sftpUSER, String sftpPASS, String sftpWorkingDir ) {
        return StringUtils.isEmpty(sftpHost)
                || StringUtils.isEmpty(sftpUSER)
                || StringUtils.isEmpty(sftpPASS)
                || StringUtils.isEmpty(sftpWorkingDir);
    }

	public boolean hasValidStatus(ProcessorMetaData processor) {
        return processor != null &&
                (MetaDataStatus.IN_PROCESS.equals(processor.getStatus()) ||
                        MetaDataStatus.ACTIVE.equals(processor.getStatus()) ||
                        MetaDataStatus.NEW.equals(processor.getStatus()));
    }

	public void closeSFTPChannel(ChannelSftp channelSftp, Session sftpSession, Channel channel){
        if (channelSftp != null && channelSftp.isConnected()) {
        	try {
                channel.disconnect();
                channelSftp.disconnect();
                channelSftp.quit();
                if(sftpSession == null || !sftpSession.isConnected()) {
                    sftpSession = channelSftp.getSession();
                }
                sftpSession.disconnect();
            } catch (Exception e) {
                LOGGER.error("closeSFTPChannel IOException Error Message {}", ExceptionUtils.getStackTrace(e));
}
        }
    }
}
