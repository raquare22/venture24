//package com.optum.fs.fs_batch_processing.sftp;
package com.optum.fds.paperless.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import java.util.concurrent.Semaphore;

@Component
public class SftpUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(SftpUtil.class);
	private static final String FILE_NAME = "fileName";
	private static final String MAX_TRIES = "maxTries";
	private static final String RETRY_TIME_SECS = "retryTimeSecs";
	private static final String SFTP_HOST = "sftpHost";
	private static final String SFTP_PORT = "sftpPort";
	private static final String SFTP_USER = "sftpUSER";
	private static final String TARGET_DIR = "targetDir";
	private static final String ARCHIVE_DIR = "archiveDir";
	private volatile Semaphore sftpPermits;
	
	@Value("${MinFreeSpacePercentage}")
    protected Integer minFreeSpacePercentage;
	
	// SFTP concurrency limit (from Vault)
	@Value("${SFTP.MAX.CONCURRENT:0}")
	private int maxConcurrentSftp;
	
	 public boolean isEnoughFreeSpace(Path filePath, boolean log) {
			File file = filePath.toFile();
			var freeSpacePercentage = getFreeSpacePercentage(file, log);
			if (LOGGER.isWarnEnabled() && freeSpacePercentage < minFreeSpacePercentage) {
				LOGGER.warn("FREESPACE INSUFFICIENT: freeSpacePercentage={}, minFreeSpacePercentage={}, freeSpacePercentage > minFreeSpacePercentage={}, file={}",
					freeSpacePercentage, minFreeSpacePercentage, freeSpacePercentage > minFreeSpacePercentage, file);
			}
			else
			if (log) {
				LOGGER.warn("FREESPACE OK: freeSpacePercentage={}, minFreeSpacePercentage={}, freeSpacePercentage > minFreeSpacePercentage={}, file={}",
					freeSpacePercentage, minFreeSpacePercentage, freeSpacePercentage > minFreeSpacePercentage, file);
			}
			else
			{
				LOGGER.debug("FREESPACE OK: freeSpacePercentage={}, minFreeSpacePercentage={}, freeSpacePercentage > minFreeSpacePercentage={}, file={}",
					freeSpacePercentage, minFreeSpacePercentage, freeSpacePercentage > minFreeSpacePercentage, file);
			}
			return freeSpacePercentage > minFreeSpacePercentage;
		}

	    public int getFreeSpacePercentage(File file, boolean log) {
			var rootFreeBytes = file.getFreeSpace();
			var rootTotalBytes = file.getTotalSpace();
			var freeSpacePercentage = (int) (0.5d + ((double) rootFreeBytes / (double) rootTotalBytes) * 100);
			if (log) {
				LOGGER.warn("FREESPACE: freeSpacePercentage={}: rootFreeBytes={}, rootTotalBytes={}, file={}",
					freeSpacePercentage, rootFreeBytes, rootTotalBytes, file);
			}
			return freeSpacePercentage;
		}

	public void moveFileFromLocalToSFTPLocation(String sftpUSER, String sftpPASS, String sftpHost,
			int sftpPort, String targetDir, String fileName, int maxTries, long retryTimeSecs)
			throws JSchException, SftpException, IOException, IllegalArgumentException {
		LOGGER.debug("targetDir={}, fileName={}, maxTries={}, retryTimeSecs={} (ignored; using increasing backoff)", targetDir, fileName, maxTries, retryTimeSecs);

        if (fileName != null && (fileName.contains("..") || fileName.contains("/../") || fileName.contains("\\..\\"))) {
            throw new IllegalArgumentException("Invalid file name, potential path traversal detected");
        }

		Session sftpSession = null;
		ChannelSftp channel = null;
		int sftpExceptionId = 0;
		for (int tries = 0; tries < maxTries; tries++) {
			Semaphore semaphore = null;
			boolean acquired = false;
            boolean success = false;
    		try {
				semaphore = getSftpSemaphore();
				if (semaphore != null) {
					try {
						acquired = semaphore.tryAcquire(30, TimeUnit.SECONDS); // waits up to 30 seconds
                        if (!acquired) {
                            LOGGER.warn("SFTP concurrency limit reached. Could not acquire permit within timeout");
                            throw new JSchException("SFTP concurrency limit reached. Could not acquire permit within timeout. Try again later.");
                        }
					} catch (InterruptedException e) {
						Thread.currentThread().interrupt();
						throw new JSchException("Interrupted while acquiring SFTP concurrency permit", e);
					}
				}
    		  LOGGER.debug("sftp tries {} on sftpHost {} targetDir {} file {} sftpExceptionId {}", tries + 1, sftpHost, targetDir, fileName, sftpExceptionId);
    			sftpSession = createSesssion(sftpUSER, sftpPASS, sftpHost, sftpPort);
    			channel = (ChannelSftp) createSFTPChannel(sftpSession);
    			if (LOGGER.isInfoEnabled()) {
    				LOGGER.debug("channel pwd {} - channel.lpwd {}", channel.pwd(), channel.lpwd());
    			}
    			channel.cd(targetDir);
    			if (LOGGER.isInfoEnabled()) {
    				LOGGER.debug("after cd channel pwd {} - channel.lpwd {}", channel.pwd(), channel.lpwd());
    			}
    			createFileInSFTPLocation(channel, fileName);
                success = true;
    			break;
    		} catch (Exception e) {
    		    if(tries >= maxTries - 1) {
    		        LOGGER.error("moveFileFromLocalToSFTPLocation {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={} {}",
    					SFTP_USER, sftpUSER, SFTP_HOST, sftpHost, SFTP_PORT, sftpPort, TARGET_DIR, targetDir,
    					FILE_NAME, fileName, MAX_TRIES, maxTries, RETRY_TIME_SECS, retryTimeSecs, ExceptionUtils.getStackTrace(e));
    		        throw e;
    		    }
				else {
					LOGGER.warn("SFTP PUT attempt {} failed for file {} on host {}. Retrying, e={}", tries + 1, fileName, sftpHost, e.getMessage());
				}
    		} finally {
    			if (channel != null) {
    	            channel.disconnect();
    	            channel.quit();			
    			}
    			if (sftpSession != null) {
    				sftpSession.disconnect();
    			}
				if (semaphore != null && acquired) {
					semaphore.release();
				}
    		}
            // Sleep for backoff outside the try/catch/finally
            if (!success) {
                long waitSecs = computeBackoffSecs(tries);
                sleepSecondsQuietly(waitSecs);
            }

	      }
	}

	/**
	 * Retry every 6 minutes. maxTries default is 10 times
	 */
	public void moveFileFromSFTPDirToArchive(String sftpUSER, String sftpPASS, String sftpHost,
			int sftpPort, String fromDir, String archiveDir, String fileName, int maxTries, long retryTimeSecs)
			throws JSchException, SftpException {

		Session sftpSession = null;
		ChannelSftp channel = null;
	      for (int tries = 0; tries < maxTries; tries++) {
	    	  Semaphore semaphore = null;
			  boolean acquired = false;
              boolean success = false;
        		try {
					semaphore = getSftpSemaphore();
					if (semaphore != null) {
						try {
                            acquired = semaphore.tryAcquire(30, TimeUnit.SECONDS); // waits up to 30 seconds
                            if (!acquired) {
                                LOGGER.warn("SFTP concurrency limit reached. Could not acquire permit within timeout");
                                throw new JSchException("SFTP concurrency limit reached. Could not acquire permit within timeout. Try again later.");
                            }
						} catch (InterruptedException e) {
							Thread.currentThread().interrupt();
							throw new JSchException("Interrupted while acquiring SFTP concurrency permit", e);
						}
					}
        		    LOGGER.debug("sftp tries {}, fromDir {}, archiveDir {}, fileName {}", tries + 1, fromDir, archiveDir, fileName);
        			sftpSession = createSesssion(sftpUSER, sftpPASS, sftpHost, sftpPort);
        			channel = (ChannelSftp) createSFTPChannel(sftpSession);
        			moveFileToLocation(channel, fromDir, archiveDir, fileName);
                    success=true;
                    break;
                } catch (Exception e) {
                    if(tries >= maxTries - 1) {
                        LOGGER.error("moveFileFromSFTPDirToArchive {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={} {}",
        					SFTP_USER, sftpUSER, SFTP_HOST, sftpHost, SFTP_PORT, sftpPort, "fromDir", fromDir, ARCHIVE_DIR, archiveDir, FILE_NAME,
        					fileName, MAX_TRIES, maxTries, RETRY_TIME_SECS, retryTimeSecs, ExceptionUtils.getStackTrace(e));
                        throw e;
                    } else {
						LOGGER.warn("SFTP MOVE attempt {} failed for file {} ({} -> {}). Retrying, e={}", tries + 1, fileName, fromDir, archiveDir, e.getMessage());
					}
        		} finally {
        			if (channel != null) {
        	            channel.disconnect();
        	            channel.quit();			
        			}
        			if (sftpSession != null) {
        				sftpSession.disconnect();
        			}
					if (semaphore != null && acquired) {
						semaphore.release();
					}
        		}
                // Sleep for backoff outside the try/catch/finally
              if (!success) {
                  long waitSecs = computeBackoffSecs(tries);
                  sleepSecondsQuietly(waitSecs);
              }

	      }

	}

	private static final void createFileInSFTPLocation(ChannelSftp channel, String fileName) throws SftpException, IOException {
	    File f = new File(fileName);
	    try (InputStream localFile = new BufferedInputStream(Files.newInputStream(f.toPath()))) {
			channel.put(localFile, f.getName());
        } 
	}

	private static final void moveFileToLocation(ChannelSftp channel, String fromDir, String targetDir, String fileName) throws SftpException {
		channel.cd(fromDir);
		if (channel.get(fileName) != null) {
			channel.rename(fromDir + "/" + fileName, targetDir + "/" + fileName);
			channel.cd(fromDir);
		}

	}

	public static final Channel createSFTPChannel(Session sftpSession) throws JSchException {
		Channel channel = sftpSession.openChannel("sftp");
		channel.connect();
		return channel;
	}

	public static final Session createSesssion(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort)
			throws JSchException {
		Session sftpSession;
		JSch jsch = new JSch();
		sftpSession = jsch.getSession(sftpUSER, sftpHost, sftpPort);
		sftpSession.setPassword(sftpPASS);
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		sftpSession.setConfig(config);
		sftpSession.connect(20000);
		return sftpSession;
	}

    private static long addJitter(long baseSeconds) {
        // Add ±20% jitter
        double jitter = 0.2 * baseSeconds;
        long min = (long) (baseSeconds - jitter);
        long max = (long) (baseSeconds + jitter);
        return ThreadLocalRandom.current().nextLong(min, max + 1);
    }

	public static final void removeFileFromSFTPLocation(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort, String targetDir, String fileName) throws JSchException, SftpException {
		Session sftpSession = null;
		ChannelSftp channel = null;
		try {
			sftpSession = createSesssion(sftpUSER, sftpPASS, sftpHost, sftpPort);
			channel = (ChannelSftp)createSFTPChannel(sftpSession);
			removeFileInSFTPLocation(channel, targetDir, fileName);
		} catch (JSchException | SftpException e) {
		    LOGGER.error("removeFileFromSFTPLocation {}={}, {}={}, {}={}, {}={}, {}={} {}",
				SFTP_USER, sftpUSER, SFTP_HOST, sftpHost, SFTP_PORT, sftpPort,
				TARGET_DIR, targetDir, FILE_NAME, fileName, ExceptionUtils.getStackTrace(e));
		} finally {

			if (channel != null) {
	            channel.disconnect();
	            channel.quit();			
			}
			if (sftpSession != null) {
				sftpSession.disconnect();
			}
		}
	}

	private static final void removeFileInSFTPLocation(ChannelSftp channel, String location, String fileName) throws SftpException {
		removeFileInSFTPLocation(channel, location + File.separator + fileName);
	}
	
	private static final void removeFileInSFTPLocation(ChannelSftp channel, String fileNameWithPath) throws SftpException {
		channel.rm(fileNameWithPath);
	}
	
	// Increasing backoff: 10s, 30s, 60s, 300s (then stay at 300s)
	private static long computeBackoffSecs(int attemptIndex /* 0-based */) {
		final long[] BACKOFF = new long[] { 10, 30, 60, 300 };
        long base = (attemptIndex < BACKOFF.length) ? BACKOFF[attemptIndex] : BACKOFF[BACKOFF.length - 1];
        return addJitter(base);
	}

	private static void sleepSecondsQuietly(long secs) {
		try {
			TimeUnit.SECONDS.sleep(secs);
		} catch (InterruptedException ie) {
			Thread.currentThread().interrupt();
			LOGGER.warn("SFTP retry sleep interrupted");
		}
	}

	Semaphore getSftpSemaphore() {
		if (sftpPermits == null && maxConcurrentSftp > 0) {
			synchronized (this) {
				if (sftpPermits == null) {
					LOGGER.info("SFTP concurrency limiter ENABLED with {} permits", maxConcurrentSftp);
					sftpPermits = new Semaphore(maxConcurrentSftp);
				}
			}
		}
		return sftpPermits;
	}
	
	void setMaxConcurrentSftp(int maxConcurrentSftp) {
		this.maxConcurrentSftp = maxConcurrentSftp;
	}

}