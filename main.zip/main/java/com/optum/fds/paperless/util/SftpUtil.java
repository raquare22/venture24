package com.optum.fds.paperless.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import java.util.concurrent.Semaphore;


@Component
public class SftpUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(SftpUtil.class);
	private static final String FILE_NAME = "fileName";
	private static final String MAX_TRIES = "maxTries";
	private static final String RETRY_TIME_SECS = "retryTimeSecs";
	private static final String SFTP_HOST = "sftpHost";
	private static final String SFTP_PORT = "sftpPort";
	private static final String SFTP_USER = "sftpUSER";
	private static final String TARGET_DIR = "targetDir";
	private static final String ARCHIVE_DIR = "archiveDir";
	private volatile Semaphore sftpPermits;
	
	@Value("${MinFreeSpacePercentage}")
    protected Integer minFreeSpacePercentage;
	
	// SFTP concurrency limit (from Vault)
	@Value("${SFTP.MAX.CONCURRENT:0}")
	private int maxConcurrentSftp;

	@Value("${SFTP.LEGACY.HOSTS:}")
	private String legacySftpHosts;

	@Value("${SFTP.LEGACY.KEX:}")
	private String legacyKexAlgorithms;

	@Value("${SFTP.LEGACY.SERVER_HOST_KEY:}")
	private String legacyServerHostKeyAlgorithms;

	@Value("${SFTP.LEGACY.PUBKEY_ACCEPTED_ALGORITHMS:}")
	private String legacyPubkeyAcceptedAlgorithms;
	
	 public boolean isEnoughFreeSpace(Path filePath, boolean log) {
			File file = filePath.toFile();
			var freeSpacePercentage = getFreeSpacePercentage(file, log);
			if (LOGGER.isWarnEnabled() && freeSpacePercentage < minFreeSpacePercentage) {
				LOGGER.warn("FREESPACE INSUFFICIENT: freeSpacePercentage={}, minFreeSpacePercentage={}, freeSpacePercentage > minFreeSpacePercentage={}, file={}",
					freeSpacePercentage, minFreeSpacePercentage, freeSpacePercentage > minFreeSpacePercentage, file);
			}
			else
			if (log) {
				LOGGER.warn("FREESPACE OK: freeSpacePercentage={}, minFreeSpacePercentage={}, freeSpacePercentage > minFreeSpacePercentage={}, file={}",
					freeSpacePercentage, minFreeSpacePercentage, freeSpacePercentage > minFreeSpacePercentage, file);
			}
			else
			{
				LOGGER.debug("FREESPACE OK: freeSpacePercentage={}, minFreeSpacePercentage={}, freeSpacePercentage > minFreeSpacePercentage={}, file={}",
					freeSpacePercentage, minFreeSpacePercentage, freeSpacePercentage > minFreeSpacePercentage, file);
			}
			return freeSpacePercentage > minFreeSpacePercentage;
		}

	    public int getFreeSpacePercentage(File file, boolean log) {
			var rootFreeBytes = file.getFreeSpace();
			var rootTotalBytes = file.getTotalSpace();
			var freeSpacePercentage = (int) (0.5d + ((double) rootFreeBytes / (double) rootTotalBytes) * 100);
			if (log) {
				LOGGER.warn("FREESPACE: freeSpacePercentage={}: rootFreeBytes={}, rootTotalBytes={}, file={}",
					freeSpacePercentage, rootFreeBytes, rootTotalBytes, file);
			}
			return freeSpacePercentage;
		}

	public void moveFileFromLocalToSFTPLocation(String sftpUSER, String sftpPASS, String sftpHost,
			int sftpPort, String targetDir, String fileName, int maxTries, long retryTimeSecs)
			throws JSchException, SftpException, IOException, IllegalArgumentException {
		LOGGER.debug("SFTP transfer started: maxAttempts={}, retryBackoffConfigured={}", maxTries, retryTimeSecs);

        if (fileName != null && (fileName.contains("..") || fileName.contains("/../") || fileName.contains("\\..\\"))) {
            throw new IllegalArgumentException("Invalid file name, potential path traversal detected");
        }

		Session sftpSession = null;
		ChannelSftp channel = null;
		int sftpExceptionId = 0;
		for (int tries = 0; tries < maxTries; tries++) {
			Semaphore semaphore = null;
			boolean acquired = false;
            boolean success = false;
			Long sourceBytes = null;
    		try {
				semaphore = getSftpSemaphore();
				if (semaphore != null) {
					try {
						acquired = semaphore.tryAcquire(30, TimeUnit.SECONDS); // waits up to 30 seconds
                        if (!acquired) {
                            LOGGER.warn("SFTP concurrency limit reached. Could not acquire permit within timeout");
                            throw new JSchException("SFTP concurrency limit reached. Could not acquire permit within timeout. Try again later.");
                        }
					} catch (InterruptedException e) {
						Thread.currentThread().interrupt();
						throw new JSchException("Interrupted while acquiring SFTP concurrency permit", e);
					}
				}
			  LOGGER.debug("SFTP transfer attempt started: attempt={}, maxAttempts={}", tries + 1, maxTries);
    			sftpSession = createSession(sftpUSER, sftpPASS, sftpHost, sftpPort);
    			channel = (ChannelSftp) createSFTPChannel(sftpSession);
    			if (LOGGER.isInfoEnabled()) {
    				LOGGER.debug("channel pwd {} - channel.lpwd {}", channel.pwd(), channel.lpwd());
    			}
    			channel.cd(targetDir);
    			if (LOGGER.isInfoEnabled()) {
    				LOGGER.debug("after cd channel pwd {} - channel.lpwd {}", channel.pwd(), channel.lpwd());
    			}
				sourceBytes = Files.size(Path.of(fileName));
    			createFileInSFTPLocation(channel, fileName);
                success = true;
				LOGGER.info("SFTP transfer completed: attempt={}, maxAttempts={}, sourceBytes={}",
						tries + 1, maxTries, sourceBytes);
    			break;
    		} catch (Exception e) {
    		    if(tries >= maxTries - 1) {
		        LOGGER.error("SFTP transfer failed: attempt={}, maxAttempts={}, sourceBytes={}, exceptionType={}, retrying=false",
		        		tries + 1, maxTries, sourceBytes, e.getClass().getSimpleName());
    		        throw e;
    		    }
				else {
					LOGGER.warn("SFTP transfer failed: attempt={}, maxAttempts={}, sourceBytes={}, exceptionType={}, retrying=true",
							tries + 1, maxTries, sourceBytes, e.getClass().getSimpleName());
				}
    		} finally {
    			if (channel != null) {
    	            channel.disconnect();
    	            channel.quit();			
    			}
    			if (sftpSession != null) {
    				sftpSession.disconnect();
    			}
				if (semaphore != null && acquired) {
					semaphore.release();
				}
    		}
            // Sleep for backoff outside the try/catch/finally
            if (!success) {
                long waitSecs = computeBackoffSecs(tries);
                sleepSecondsQuietly(waitSecs);
            }

	      }
	}


	private static final void createFileInSFTPLocation(ChannelSftp channel, String fileName) throws SftpException, IOException {
	    File f = new File(fileName);
	    try (InputStream localFile = new BufferedInputStream(Files.newInputStream(f.toPath()))) {
			channel.put(localFile, f.getName());
        } 
	}

	private static final void moveFileToLocation(ChannelSftp channel, String fromDir, String targetDir, String fileName) throws SftpException {
		channel.cd(fromDir);
		if (channel.get(fileName) != null) {
			channel.rename(fromDir + "/" + fileName, targetDir + "/" + fileName);
			channel.cd(fromDir);
		}

	}

	public static final Channel createSFTPChannel(Session sftpSession) throws JSchException {
		Channel channel = sftpSession.openChannel("sftp");
		channel.connect();
		return channel;
	}

	public Session createSession(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort)
			throws JSchException {
		return createSession(sftpUSER, sftpPASS, sftpHost, sftpPort, buildSessionConfig(sftpHost));
	}


	private static Session createSession(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort,
			Properties config) throws JSchException {
        if (config == null) {
            config = defaultSessionConfig();
            LOGGER.warn("SFTP session config is null for host={}, using default config", sftpHost);
        }
		JSch jsch = new JSch();
		Session sftpSession = jsch.getSession(sftpUSER, sftpHost, sftpPort);
		sftpSession.setPassword(sftpPASS);
		sftpSession.setConfig(config);
		sftpSession.connect(20000);
		return sftpSession;
	}

	Properties buildSessionConfig(String sftpHost) {
		Properties config = defaultSessionConfig();
		if (!isLegacySftpHost(sftpHost)) {
			return config;
		}

		appendConfig(config, "kex", legacyKexAlgorithms);
		appendConfig(config, "server_host_key", legacyServerHostKeyAlgorithms);
		appendConfig(config, "PubkeyAcceptedAlgorithms", legacyPubkeyAcceptedAlgorithms);
		LOGGER.info("Applying legacy SFTP algorithm profile for host={}", sftpHost);
		return config;
	}

	private static Properties defaultSessionConfig() {
		Properties config = new Properties();
		config.put("StrictHostKeyChecking", "no");
		return config;
	}

	private boolean isLegacySftpHost(String sftpHost) {
		if (isBlank(sftpHost) || isBlank(legacySftpHosts)) {
			return false;
		}
		return Arrays.stream(legacySftpHosts.split(","))
				.map(String::trim)
				.anyMatch(configuredHost -> configuredHost.equalsIgnoreCase(sftpHost.trim()));
	}

	private static void appendConfig(Properties config, String key, String configuredAlgorithms) {
		if (isBlank(configuredAlgorithms)) {
			return;
		}
        try {
            Set<String> algorithms = new LinkedHashSet<>();
            addAlgorithms(algorithms, JSch.getConfig(key));
            addAlgorithms(algorithms, configuredAlgorithms);
            config.put(key, String.join(",", algorithms));
        } catch (Exception e) {
            LOGGER.warn("Failed to append SFTP config for key={}, configuredAlgorithms={}. Using default algorithms. e={}", key, configuredAlgorithms, e.getMessage());
        }
	}

	private static void addAlgorithms(Set<String> algorithms, String configuredAlgorithms) {
		if (isBlank(configuredAlgorithms)) {
			return;
		}
		Arrays.stream(configuredAlgorithms.split(","))
				.map(String::trim)
				.filter(algorithm -> !algorithm.isEmpty())
				.forEach(algorithms::add);
	}

	private static boolean isBlank(String value) {
		return value == null || value.trim().isEmpty();
	}

    private static long addJitter(long baseSeconds) {
        // Add ±20% jitter
        double jitter = 0.2 * baseSeconds;
        long min = (long) (baseSeconds - jitter);
        long max = (long) (baseSeconds + jitter);
        return ThreadLocalRandom.current().nextLong(min, max + 1);
    }

	public void removeFileFromSFTPLocation(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort, String targetDir, String fileName) throws JSchException, SftpException {
		Session sftpSession = null;
		ChannelSftp channel = null;
		try {
			sftpSession = createSession(sftpUSER, sftpPASS, sftpHost, sftpPort);
			channel = (ChannelSftp)createSFTPChannel(sftpSession);
			removeFileInSFTPLocation(channel, targetDir, fileName);
		} catch (JSchException | SftpException e) {
		    LOGGER.error("removeFileFromSFTPLocation {}={}, {}={}, {}={}, {}={}, {}={} {}",
				SFTP_USER, sftpUSER, SFTP_HOST, sftpHost, SFTP_PORT, sftpPort,
				TARGET_DIR, targetDir, FILE_NAME, fileName, ExceptionUtils.getStackTrace(e));
		} finally {

			if (channel != null) {
	            channel.disconnect();
	            channel.quit();			
			}
			if (sftpSession != null) {
				sftpSession.disconnect();
			}
		}
	}

	private static final void removeFileInSFTPLocation(ChannelSftp channel, String location, String fileName) throws SftpException {
		removeFileInSFTPLocation(channel, location + File.separator + fileName);
	}
	
	private static final void removeFileInSFTPLocation(ChannelSftp channel, String fileNameWithPath) throws SftpException {
		channel.rm(fileNameWithPath);
	}
	
	// Increasing backoff: 10s, 30s, 60s, 300s (then stay at 300s)
	private static long computeBackoffSecs(int attemptIndex /* 0-based */) {
		final long[] BACKOFF = new long[] { 10, 30, 60, 300 };
        long base = (attemptIndex < BACKOFF.length) ? BACKOFF[attemptIndex] : BACKOFF[BACKOFF.length - 1];
        return addJitter(base);
	}

	private static void sleepSecondsQuietly(long secs) {
		try {
			TimeUnit.SECONDS.sleep(secs);
		} catch (InterruptedException ie) {
			Thread.currentThread().interrupt();
			LOGGER.warn("SFTP retry sleep interrupted");
		}
	}

	Semaphore getSftpSemaphore() {
		if (sftpPermits == null && maxConcurrentSftp > 0) {
			synchronized (this) {
				if (sftpPermits == null) {
					LOGGER.info("SFTP concurrency limiter ENABLED with {} permits", maxConcurrentSftp);
					sftpPermits = new Semaphore(maxConcurrentSftp);
				}
			}
		}
		return sftpPermits;
	}
	
	void setMaxConcurrentSftp(int maxConcurrentSftp) {
		this.maxConcurrentSftp = maxConcurrentSftp;
	}

	void setLegacySftpHosts(String legacySftpHosts) {
		this.legacySftpHosts = legacySftpHosts;
	}

	void setLegacyKexAlgorithms(String legacyKexAlgorithms) {
		this.legacyKexAlgorithms = legacyKexAlgorithms;
	}

	void setLegacyServerHostKeyAlgorithms(String legacyServerHostKeyAlgorithms) {
		this.legacyServerHostKeyAlgorithms = legacyServerHostKeyAlgorithms;
	}

	void setLegacyPubkeyAcceptedAlgorithms(String legacyPubkeyAcceptedAlgorithms) {
		this.legacyPubkeyAcceptedAlgorithms = legacyPubkeyAcceptedAlgorithms;
	}

}
