package com.optum.fds.paperless.workflow.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.JsonPath;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.document.util.DocumentResponse;
import com.optum.fds.paperless.exception.FSDataException;
import com.optum.fds.paperless.mongo.AckFileBean;
import com.optum.fds.paperless.mongo.Batch;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import com.optum.fds.paperless.util.HttpUtils;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.SftpUtil;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Rule;
import org.junit.rules.TemporaryFolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.*;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class WorkFlowUtil {
	
	@Value("${INGEST_ROOT}")
	private static String ingestRoot;
	
    private static final Logger LOGGER = LoggerFactory.getLogger(WorkFlowUtil.class);

    private static final String MISSING_OR_INVALID_DATA = "Missing or invalid data: ";
    private static final String DEFAULT_OFFSET = "0";
    private static final String DEFAULT_FORMAT_HOURS = "Hours";
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final Pattern pattern = Pattern.compile("\\$\\{([^}]+)}");
    
    @Autowired
    private SftpUtil sftpUtil;

    private WorkFlowUtil() {
    }

    @SuppressWarnings("unchecked")
    public static Criteria getSearchWindowCriteria(String searchWindow) throws IOException, ParseException {
        Criteria searchWindowCriteria = null;
        if (searchWindow != null) {
            Date startDate = null;
            Date endDate = null;
            Instant instant = Instant.now();

            Document windowMap = Parser.parseJson(searchWindow, Document.class);
            String startDateString = windowMap.get(Workflow.SEARCH_WINDOW_START_DATE, String.class);
            String endDateString = windowMap.get(Workflow.SEARCH_WINDOW_END_DATE, String.class);
            Map<String, String> startDateOffset = windowMap.get(Workflow.SEARCH_WINDOW_START_DATE_OFFSET, HashMap.class);
            Map<String, String> endDateOffset = windowMap.get(Workflow.SEARCH_WINDOW_END_DATE_OFFSET, HashMap.class);

            if (StringUtils.isNoneEmpty(startDateString, endDateString)) {
                SimpleDateFormat formatter = new SimpleDateFormat(Workflow.DATE_FORMAT);
                startDate = formatter.parse(startDateString);
                endDate = formatter.parse(endDateString);
            } else if (startDateOffset != null) {
                String startTimeWindow = Optional.of(startDateOffset)
                        .map(mapper -> mapper.get(Workflow.SEARCH_WINDOW_TIMEWINDOW))
                        .orElse(null);
                String startFormat = Optional.of(startDateOffset)
                        .map(mapper -> mapper.get(Workflow.SEARCH_WINDOW_FORMAT))
                        .orElse(DEFAULT_FORMAT_HOURS);

                String endTimeWindow = Optional.ofNullable(endDateOffset)
                        .map(mapper -> mapper.get(Workflow.SEARCH_WINDOW_TIMEWINDOW))
                        .orElse(DEFAULT_OFFSET);
                String endFormat = Optional.ofNullable(endDateOffset)
                        .map(mapper -> mapper.get(Workflow.SEARCH_WINDOW_FORMAT))
                        .orElse(DEFAULT_FORMAT_HOURS);

                if (StringUtils.isNoneEmpty(startTimeWindow, startFormat, endTimeWindow, endFormat)) {
                    ZonedDateTime time = null;

                    time = getLocalDateTimeByTimeWindow(instant, startTimeWindow, startFormat);
                    startDate = Date.from(time.toInstant());

                    time = getLocalDateTimeByTimeWindow(instant, endTimeWindow, endFormat);
                    endDate = Date.from(time.toInstant());
                }

            }

            if (startDate != null && endDate != null) {
                searchWindowCriteria = Criteria.where(Workflow.PROCESSOR_DATE_CREATED).gte(startDate).lt(endDate);
            }
        }
        return searchWindowCriteria;
    }

    public static String getTemporaryWorkingPath(Integer spaceId) throws FSDataException, IOException {
//    	TODO find why ingest value is not set here from config store.
    	if(ObjectUtils.isEmpty(ingestRoot)) {
    		ingestRoot = "/ingest";
    	}
        String ingestWorkingDir=ingestRoot;
    	Path tempWorkingPath = Utilities.createWorkingDirectory(ingestWorkingDir + File.separator + spaceId + File.separator + UUID.randomUUID());
        return tempWorkingPath.toString();
    }

    public static ZonedDateTime getLocalDateTimeByTimeWindow(Instant instant, String timeWindow, String timeUnit) {
        int timeTosubtract = Integer.parseInt(timeWindow);
        ZonedDateTime now = ZonedDateTime.ofInstant(instant, ZoneOffset.UTC);
        return now.minus(timeTosubtract, ChronoUnit.valueOf(timeUnit.toUpperCase()));
    }

    public static File generateFileFromString(String data, String filePath) throws IOException {
        File file = new File(filePath);
        try (OutputStream fos = new BufferedOutputStream(Files.newOutputStream(file.toPath()));
             BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos))) {
            bw.write(data);
        }
        return file;
    }

    public static void updateEDeliveryError(Document metaData, String field) {
        String eDeliveryError = metaData.getString(Workflow.E_DELIVERY_ERROR);
        String errorMessage = MISSING_OR_INVALID_DATA + field;
        if (StringUtils.isBlank(eDeliveryError)) {
            metaData.put(Workflow.E_DELIVERY_ERROR, errorMessage);
        } else {
            if (!eDeliveryError.contains(errorMessage)) {
                metaData.put(Workflow.E_DELIVERY_ERROR, eDeliveryError + "|" + errorMessage);
            }
        }
    }

    public static String getStackTrace(final Throwable throwable) {
        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw, true);
        throwable.printStackTrace(pw);
        return sw.getBuffer().toString();
    }

    public static List<DocumentMetaData> readDocumentsFromJsonFile(String fileName) throws IOException, JSONException {
        List<DocumentMetaData> documentMetaDataList = new ArrayList<>();
        try (InputStream is = new BufferedInputStream(Files.newInputStream(Paths.get(fileName)))) {
            String documentsAsJsonString = Parser.inputStreamToStringNoBomExclusion(is);
            JSONObject documentsAsJson = new JSONObject(documentsAsJsonString);
            JSONArray documentsArray = documentsAsJson.getJSONArray(Workflow.DOCUMENTS);
            SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
            for (int i = 0; i < documentsArray.length(); i++) {
                DocumentMetaData metaData = Parser.parseJsonWithDateFormat(documentsArray.getJSONObject(i).toString(),
                        DocumentMetaData.class, sdf);
                documentMetaDataList.add(metaData);
            }
        }
        return documentMetaDataList;
    }
    
    public static Map<String, List<DocumentMetaData>> readDocumentsFromJsonFileMap(String fileName, Set<String> zipFileName) throws IOException, JSONException {
    	 HashMap<String, List<DocumentMetaData>> documentMapList=new HashMap<>();
    	
        try (InputStream is = new BufferedInputStream(Files.newInputStream(Paths.get(fileName)))) {
            String documentsAsJsonString = Parser.inputStreamToStringNoBomExclusion(is);
            JSONObject documentsAsJson = new JSONObject(documentsAsJsonString);
            for(String zipfile : zipFileName)
            {
              List<DocumentMetaData> documentMetaDataList = new ArrayList<>();
              JSONArray documentsListAsJson=(JSONArray) documentsAsJson.get(zipfile);
              
            
              SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
              for (int i = 0; i < documentsListAsJson.length(); i++) {
                  DocumentMetaData metaData = Parser.parseJsonWithDateFormat(documentsListAsJson.getJSONObject(i).toString(),
                          DocumentMetaData.class, sdf);
                  documentMetaDataList.add(metaData);
              }
              documentMapList.put(zipfile, documentMetaDataList);
             }
           
        }
        return documentMapList;
    }
    
    public static String readDocumentsFromJsonFileToString(String fileName) throws IOException, JSONException {
    	String txtFileString = null;
        try (InputStream is = new BufferedInputStream(Files.newInputStream(Paths.get(fileName)))) {
            txtFileString = Parser.inputStreamToStringNoBomExclusion(is);
        }
        return txtFileString;
    }

    
    public static List<DocumentMetaData> readDocumentsFromJsonFile(String fileName, String dateFormat) throws IOException, JSONException {
        List<DocumentMetaData> documentMetaDataList = new ArrayList<>();
        try (InputStream is = new BufferedInputStream(Files.newInputStream(Paths.get(fileName)))) {
            String documentsAsJsonString = Parser.inputStreamToStringNoBomExclusion(is);
            JSONObject documentsAsJson = new JSONObject(documentsAsJsonString);
            JSONArray documentsArray = documentsAsJson.getJSONArray(Workflow.DOCUMENTS);
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
            for (int i = 0; i < documentsArray.length(); i++) {
                DocumentMetaData metaData = Parser.parseJsonWithDateFormat(documentsArray.getJSONObject(i).toString(),
                        DocumentMetaData.class, sdf);
                documentMetaDataList.add(metaData);
            }
        }
        return documentMetaDataList;
    }
    
    public static List<DocumentMetaData> readDocumentsFromJsonString(String jsonString) throws IOException, JSONException {
        List<DocumentMetaData> documentMetaDataList = new ArrayList<>();
        JSONObject documentsAsJson = new JSONObject(jsonString);
        JSONArray documentsArray = documentsAsJson.getJSONArray(Workflow.DOCUMENTS);
        SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
        for (int i = 0; i < documentsArray.length(); i++) {
            DocumentMetaData metaData = Parser.parseJsonWithDateFormat(documentsArray.getJSONObject(i).toString(),
                    DocumentMetaData.class, sdf);
            documentMetaDataList.add(metaData);
        }
        return documentMetaDataList;
    }

    public static DocumentMetaData readDocumentFromJsonFile(String fileName) throws IOException, JSONException {
        try (InputStream is = new BufferedInputStream(Files.newInputStream(Paths.get(fileName)))) {
            String documentAsJsonString = Parser.inputStreamToStringNoBomExclusion(is);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

            return Parser.parseJsonWithDateFormat(documentAsJsonString,
                    DocumentMetaData.class, sdf);
        }
    }

    public static AckFileBean readAckFileBeanFromJsonFile(String fileName) throws IOException, JSONException {
        try (InputStream is = new ByteArrayInputStream(fileName.getBytes())) {
            String batchAsJsonString = Parser.inputStreamToStringNoBomExclusion(is);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

            return Parser.parseJsonWithDateFormat(batchAsJsonString,
                    AckFileBean.class, sdf);
        }
    }

    public static Batch readBatchFromJsonFile(String fileName) throws IOException, JSONException {
        try (InputStream is = new ByteArrayInputStream(fileName.getBytes())) {
            String batchAsJsonString = Parser.inputStreamToString(is);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

            return Parser.parseJsonWithDateFormat(batchAsJsonString,
                    Batch.class, sdf);
        }
    }

    public static DocumentMetaData readDocumentFromJsonFilePath(String fileName) throws IOException, JSONException{
        InputStream is = new BufferedInputStream(Files.newInputStream(Paths.get(fileName)));
        String documentAsJsonString = Parser.inputStreamToStringNoBomExclusion(is);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        JSONObject processorTransactionAsJson = new JSONObject(documentAsJsonString);
        DocumentMetaData docmetadata = new DocumentMetaData();
        org.bson.Document metaData = Parser.parseJsonWithDateFormat(processorTransactionAsJson.getString(Workflow.DOCUMENT_METADATA), org.bson.Document.class, sdf);
        docmetadata.setMetadata(metaData);
        return docmetadata;
    }
    
    public static DocumentMetaData readDocumentMetadataFromJsonString(String jsonString) throws IOException, JSONException{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        DocumentMetaData docmetadata = new DocumentMetaData();
        org.bson.Document metaData = Parser.parseJsonWithDateFormat(jsonString, org.bson.Document.class, sdf);
        docmetadata.setMetadata(metaData);
        return docmetadata;
    }
    
    public static DocumentMetaData readDocumentFromJsonString(String jsonString) throws IOException, JSONException {
    
    	 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
         DocumentMetaData documentMetadata;
         JSONObject document=new JSONObject(jsonString);
         documentMetadata = Parser.parseJsonWithDateFormat(document.toString(),
                 DocumentMetaData.class, sdf);
    	return documentMetadata;
    }
    
    public static org.bson.Document readMetadataFromJsonString(String jsonString) throws IOException, JSONException{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        org.bson.Document metaData = Parser.parseJsonWithDateFormat(jsonString, org.bson.Document.class, sdf);
        return metaData;
    }

    public static File convertDocumentToFile(String metadata , String tempWorkingPath, String fileName) throws IOException {
        Map<String, Object> documentJson = new HashMap<>();
        documentJson.put(Workflow.DOCUMENT_METADATA, metadata);
        String documentListJsonString = Parser.toJson(documentJson);
        String filePath = tempWorkingPath + File.separator + fileName;
        return generateFileFromString(documentListJsonString, filePath);
    }

    public static DocumentResponse readDocumentResponseFromJsonFile(String fileName) throws IOException, JSONException {
        try (InputStream is = new BufferedInputStream(Files.newInputStream(Paths.get(fileName)))) {
            String documentAsJsonString = Parser.inputStreamToStringNoBomExclusion(is);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

            return Parser.parseJsonWithDateFormat(documentAsJsonString,
                    DocumentResponse.class, sdf);
        }
    }
    
    public static DocumentResponse readDocumentResponseFromJsonString(String jsonString) throws IOException, JSONException {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        return Parser.parseJsonWithDateFormat(jsonString,
                DocumentResponse.class, sdf);
    }


    public static List<ProcessorTransactionMetadata> readProcessorTransactionMetadataFromJsonFile(String fileName) throws IOException, JSONException {
        List<ProcessorTransactionMetadata> processorTransactionMetadataList = new ArrayList<>();
        try (InputStream is = new BufferedInputStream(Files.newInputStream(Paths.get(fileName)))) {
            String processorTransactionAsJsonString = Parser.inputStreamToStringNoBomExclusion(is);
            JSONObject processorTransactionAsJson = new JSONObject(processorTransactionAsJsonString);
            JSONArray processorTransactionArray = processorTransactionAsJson.getJSONArray(Workflow.PROCESSOR_TRANSACTIONS);
            SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
            for (int i = 0; i < processorTransactionArray.length(); i++) {
                ProcessorTransactionMetadata metaData = Parser.parseJsonWithDateFormat(processorTransactionArray.getJSONObject(i).toString(),
                        ProcessorTransactionMetadata.class, sdf);
                processorTransactionMetadataList.add(metaData);
            }
        }
        return processorTransactionMetadataList;
    }

    public static File processorTransactionMetadataListToFile(List<ProcessorTransactionMetadata> processorTransactionList, String tempWorkingPath, String fileName) throws IOException {
        Map<String,Object> processorTransactionListJson = new HashMap<>();
        processorTransactionListJson.put(Workflow.PROCESSOR_TRANSACTIONS, processorTransactionList);
        String processorTransactionJsonString = Parser.toJson(processorTransactionListJson);
        String filePath = tempWorkingPath + File.separator + fileName;
        return generateFileFromString(processorTransactionJsonString, filePath);
    }

    public static String replacePlaceHolders(String target, String sourceAsJsonString) throws IOException {
        StringBuilder builder = new StringBuilder();
        Matcher matcher = pattern.matcher(target);
        int start = 0;
        while (matcher.find(start)) {
            builder.append(target, start, matcher.start());
            String property = matcher.group(1);
            Object value = JsonPath.read(sourceAsJsonString, property);
            String valueAsJsonString = Parser.toJson(value);
            builder.append(valueAsJsonString);
            start = matcher.end();
        }
        builder.append(target.substring(start));
        return builder.toString();
    }

    public static File documentListToFile(List<DocumentMetaData> documentList, String tempWorkingPath, String fileName) throws IOException {
        Map<String, Object> documentListJson = new HashMap<>();
        documentListJson.put(Workflow.DOCUMENTS, documentList);
        String documentListJsonString = Parser.toJson(documentListJson);
        String filePath = tempWorkingPath + File.separator + fileName;
        return generateFileFromString(documentListJsonString, filePath);
    }
    
    public static File documentMapToFile(Map<String, List<DocumentMetaData>> documentMapList, String tempWorkingPath, String fileName) throws IOException {
       
        String documentMapListJsonString = Parser.toJson(documentMapList);
        String filePath = tempWorkingPath + File.separator + fileName;
        return generateFileFromString(documentMapListJsonString, filePath);
    }

//    public static String convertJsonWithTemplate(String jsonString, String templateDefinition) throws IOException {
//        JsonNode jsonNode = objectMapper.readValue(jsonString, JsonNode.class);
//        ObjectNode objectNode = (ObjectNode) jsonNode;
//        HandlebarTemplateUtil templateUtil = new HandlebarTemplateUtil();
//        com.github.jknack.handlebars.Template template = templateUtil.getTemplateInLine(templateDefinition);
//        return template.apply(templateUtil.getContext(objectNode));
//    }

    public void moveFileFromSFTPDirToArchive(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort, String ftpWorkingDir, String archiveWorkingDir,
                                                    String fileName, int maxSftpTries, long retryTimeSecs) throws JSchException, SftpException, FileNotFoundException {
    	sftpUtil.moveFileFromSFTPDirToArchive(sftpUSER, sftpPASS, sftpHost, sftpPort, ftpWorkingDir, archiveWorkingDir, fileName, maxSftpTries, retryTimeSecs);
    }

    public void moveFileFromLocalToSFTPLocation(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort, String archiveWorkingDir,
                                                       String fileName, int maxSftpTries, long retryTimeSecs) throws JSchException, SftpException, IOException {
    	sftpUtil.moveFileFromLocalToSFTPLocation(sftpUSER, sftpPASS, sftpHost, sftpPort, archiveWorkingDir, fileName, maxSftpTries, retryTimeSecs);
    }


    public static String convertToCompanionFileName(String fileName, String fileExtension, int startIndex, int endIndex) {
        String companionFileName = "";
        if (!StringUtils.isEmpty(fileName)) {
            if (fileName.length() > endIndex) {
                companionFileName = fileName.substring(startIndex, endIndex) + fileExtension;
            } else {
                companionFileName = companionFileName + fileExtension;
            }
        }
        return companionFileName;
    }

	public static String getSearchWindowCriteriaString(String SEARCH_WINDOW_OFFSET_WITH_DATES) {
		// TODO Auto-generated method stub
		return null;
	}

	public static List<ProcessorTransactionMetadata> readOneProcessorTransactionMetadataFromJsonFile(String fileName)
			throws IOException, JSONException {
		List<ProcessorTransactionMetadata> processorTransactionMetadataList = new ArrayList<>();
		try (InputStream is = new BufferedInputStream(Files.newInputStream(Paths.get(fileName)))) {
			String processorTransactionAsJsonString = Parser.inputStreamToStringNoBomExclusion(is);
			JSONObject processorTransactionAsJson = new JSONObject(processorTransactionAsJsonString);
			SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");

			ProcessorTransactionMetadata metaData = Parser.parseJsonWithDateFormat(
					processorTransactionAsJson.getString(Workflow.PROCESSOR_TRANSACTIONS_METADATA),
					ProcessorTransactionMetadata.class, sdf);
			processorTransactionMetadataList.add(metaData);

		}
		return processorTransactionMetadataList;
	}
	
	
	public static List<ProcessorTransactionMetadata> readOneProcessorTransactionMetadataFromJsonString(String jsonString)
			throws IOException, JSONException {
		List<ProcessorTransactionMetadata> processorTransactionMetadataList = new ArrayList<>();
		JSONObject processorTransactionAsJson = new JSONObject(jsonString);		
//		SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.'000Z'");
		ProcessorTransactionMetadata metaData = Parser.parseJsonWithDateFormat(
				processorTransactionAsJson.getJSONObject(Workflow.PROCESSOR_TRANSACTIONS_METADATA).toString(),
				ProcessorTransactionMetadata.class, sdf);
		processorTransactionMetadataList.add(metaData);
		return processorTransactionMetadataList;
	}
	

}