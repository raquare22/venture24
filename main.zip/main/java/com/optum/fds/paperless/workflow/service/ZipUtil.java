package com.optum.fds.paperless.workflow.service;

import com.optum.fds.paperless.workflow.beans.ZipUtilBean;

import java.io.IOException;
import java.util.List;

@FunctionalInterface
public interface ZipUtil {

	boolean zipFiles(List<ZipUtilBean> listFilesToZip, String outputPath, String zipFile) throws IOException;

}