package com.optum.fds.paperless.workflow.service;

import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;

public interface EmailService {
	
	boolean sendEmail(DelegateExecution execution, Map<String, Object> errorMap, String message);
    boolean sendEmail(DelegateExecution execution, String message);

}
