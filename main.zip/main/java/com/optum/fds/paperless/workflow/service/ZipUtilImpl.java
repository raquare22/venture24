package com.optum.fds.paperless.workflow.service;


import com.optum.fds.paperless.workflow.beans.ZipUtilBean;
import org.springframework.stereotype.Component;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Component
public class ZipUtilImpl implements ZipUtil {

    private static final int BUFFER_SIZE = 8192;

    @Override
    public boolean zipFiles(List<ZipUtilBean> listFilesToZip, String outputPath, String zipFile) throws IOException {

        String pathOP = outputPath + zipFile;
        try (var fos = new BufferedOutputStream(Files.newOutputStream(Paths.get(pathOP)));
             var zos = new ZipOutputStream(fos)) {

            for (var zipUtilBean : listFilesToZip) {
                var zipEntry = new ZipEntry(zipUtilBean.getZipEntryFileName());
                var pathIP = zipUtilBean.getPathOrigin() + zipUtilBean.getFileName();
                try (var fis = new BufferedInputStream(Files.newInputStream(Paths.get(pathIP)))) {
                    zos.putNextEntry(zipEntry);
                    var bytes = new byte[BUFFER_SIZE];
                    int length;
                    while ((length = fis.read(bytes)) >= 0) {
                        zos.write(bytes, 0, length);
                    }
                    zos.closeEntry();
                }
            }
        }
        return true;
    }
}