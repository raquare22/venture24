package com.optum.fds.paperless.workflow.beans;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FDSCloudGetDocumentsResponse {
	
	private String count;
	
	private String start;
	
	private List<ProviderDocument> documents;
	
	@JsonProperty("total_records")
	private String totalRecords;

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public List<ProviderDocument> getDocuments() {
		if (documents == null) {
			documents = new ArrayList<>();
		}
		return documents;
	}

	public void setDocuments(List<ProviderDocument> documents) {
		this.documents = documents;
	}

	public String getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(String totalRecords) {
		this.totalRecords = totalRecords;
	}
	
	@Override
	public String toString() {
		return "FDSCloudGetDocumentResponse [ " + "totalRecords: " + totalRecords + ", documents: " + documents + " ]";
	}

}
