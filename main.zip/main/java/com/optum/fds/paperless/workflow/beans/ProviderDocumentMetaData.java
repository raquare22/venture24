package com.optum.fds.paperless.workflow.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProviderDocumentMetaData implements Serializable {

    private String providerEmailId;

    private String weekday;

    private String frequency;

    private String deliveryMethod;

    private String mpin;
    
    private String tin;

    private String activeDate;

    private String subscribeToEmail;

    public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getProviderEmailId() {
        return providerEmailId;
    }

    public ProviderDocumentMetaData setProviderEmailId(String providerEmailId) {
        this.providerEmailId = providerEmailId;
        return this;
    }

    public String getWeekday() {
        return weekday;
    }

    public ProviderDocumentMetaData setWeekday(String weekday) {
        this.weekday = weekday;
        return this;
    }

    public String getFrequency() {
        return frequency;
    }

    public ProviderDocumentMetaData setFrequency(String frequency) {
        this.frequency = frequency;
        return this;
    }

    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    public ProviderDocumentMetaData setDeliveryMethod(String deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
        return this;
    }

    public String getMpin() {
        return mpin;
    }

    public ProviderDocumentMetaData setMpin(String mpin) {
        this.mpin = mpin;
        return this;
    }

    public String getActiveDate() {
        return activeDate;
    }

    public ProviderDocumentMetaData setActiveDate(String activeDate) {
        this.activeDate = activeDate;
        return this;
    }
    public String getSubscribeToEmail() {
        return subscribeToEmail;
    }

    public ProviderDocumentMetaData setSubsribeToEmail(String subscribeToEmail) {
        this.subscribeToEmail = subscribeToEmail;
        return this;
    }
    
    @Override
    public String toString() {
    	return "[ mpin : " + mpin + ", tin : " + tin + ", providerEmailId: " + providerEmailId +
                ", subscribeToEmail: " + subscribeToEmail + " ]";
    }
}
