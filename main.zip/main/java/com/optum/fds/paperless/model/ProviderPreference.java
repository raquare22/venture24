package com.optum.fds.paperless.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProviderPreference {

        private String corporateTin;

        private String corporateName;

        private List<String> selectedProviders;

        private List<PreferenceType> preferenceTypes;

        public List<PreferenceType> getPreferenceTypes()
        {
            return preferenceTypes;
        }

        public void setPreferenceTypes(List<PreferenceType> preferenceTypes)
        {
            this.preferenceTypes = preferenceTypes;
        }

        public List<String> getSelectedProviders()
        {
            return selectedProviders;
        }

        public void setSelectedProviders(List<String> selectedProviders)
        {
            this.selectedProviders = selectedProviders;
        }

        public String getCorporateTin()
        {
            return corporateTin;
        }

        public void setCorporateTin(String corporateTin)
        {
            this.corporateTin = corporateTin;
        }

        public String getCorporateName()
        {
            return corporateName;
        }

        public void setCorporateName(String corporateName)
        {
            this.corporateName = corporateName;
        }

        @Override
        public String toString()
        {
            return "ProviderPreferencesObj [corporateTin=" + corporateTin + ", corporateName=" + corporateName + ", selectedProviders=" + selectedProviders
                    + ", preferenceTypes=" + preferenceTypes + "]";
        }

        public String toStringMpins()
        {
            StringBuilder sb = new StringBuilder();
            for (String mpin : this.selectedProviders)
            {
                sb.append(mpin + ",");
            }

            // remove last comma
            sb.deleteCharAt(sb.length() - 1);

            return sb.toString();
        }

    }
