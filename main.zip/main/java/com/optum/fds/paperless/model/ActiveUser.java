package com.optum.fds.paperless.model;

import java.util.List;

public class ActiveUser {
    private String corpMpin;
    private String tin;
    private List<User> users;

    public String getCorpMpin() {
        return corpMpin;
    }

    public void setCorpMpin(String corpMpin) {
        this.corpMpin = corpMpin;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public List<User> getUsers() {
        return users;
    }
    public void setUsers(List<User> users) {
        this.users = users;
    }


}
