package com.optum.fds.paperless.model;

import org.beanio.annotation.Field;
import org.beanio.annotation.Record;


@Record
public class FixedLengthMetadata {

    @Field(at = 0, length = 23)
    String tagLine;
    @Field(at = 23, length = 15)
    String providerId;
    @Field(at = 38, length = 15)
    String mpin;
    @Field(at = 53, length = 70)
    String patientName;
    @Field(at = 123, length = 15)
    String patientDateOfBirth;
    @Field(at = 138, length = 70)
    String recipientName;
    @Field(at = 208, length = 100)
    String applicationPassThru;
    @Field(at = 308, length = 20)
    String checkAmount;
    @Field(at = 328, length = 20)
    String checkNumber;
    @Field(at = 348, length = 2)
    String subCategory;
    @Field(at = 350, length = 23)
    String category;
    @Field(at = 373, length = 70)
    String recipientAddressLine1;
    @Field(at = 443, length = 70)
    String recipientAddressLine2;
    @Field(at = 513, length = 70)
    String recipientAddressLine3;
    @Field(at = 583, length = 70)
    String recipientAddressLine4;
    @Field(at = 653, length = 70)
    String recipientAddressLine5;
    @Field(at = 723, length = 21)
    String configKey;
    @Field(at = 744, length = 10)
    String originalPrintTrail;
    @Field(at = 754, length = 200)
    String edeliveryError;
    @Field(at = 954, length = 100)
    String emailAddress;
    @Field(at = 1054, length = 100)
    String fileName;
    @Field(at = 1154, length = 2)
    String nextLine;

    public String getTagLine() {
        return tagLine;
    }

    public FixedLengthMetadata setTagLine(String tagLine) {
        this.tagLine = tagLine;
        return this;
    }

    public String getProviderId() {
        return providerId;
    }

    public FixedLengthMetadata setProviderId(String providerId) {
        this.providerId = providerId;
        return this;
    }

    public String getMpin() {
        return mpin;
    }

    public FixedLengthMetadata setMpin(String mpin) {
        this.mpin = mpin;
        return this;
    }

    public String getPatientName() {
        return patientName;
    }

    public FixedLengthMetadata setPatientName(String patientName) {
        this.patientName = patientName;
        return this;
    }

    public FixedLengthMetadata setPatientName(String patientFirstName, String patientLastName) {
        this.patientName = patientFirstName != null ? (patientFirstName + " " + patientLastName) : patientLastName;
        return this;
    }

    public String getPatientDateOfBirth() {
        return patientDateOfBirth;
    }

    public FixedLengthMetadata setPatientDateOfBirth(String patientDateOfBirth) {
        this.patientDateOfBirth = patientDateOfBirth;
        return this;
    }

    public String getRecipientName() {
        return recipientName;
    }

    public FixedLengthMetadata setRecipientName(String recipientName) {
        this.recipientName = recipientName;
        return this;
    }

    public FixedLengthMetadata setRecipientName(String recipientFirstName, String recepientLastName) {
        this.recipientName = recipientFirstName != null ? (recipientFirstName + " " + recepientLastName) : recepientLastName;
        return this;
    }

    public String getApplicationPassThru() {
        return applicationPassThru;
    }

    public FixedLengthMetadata setApplicationPassThru(String passThruData) {
        this.applicationPassThru = passThruData;
        return this;
    }

    public FixedLengthMetadata setApplicationPassThru(String passThruData, String historyID) {
        this.applicationPassThru = passThruData + "_" + historyID;
        return this;
    }

    public String getCheckAmount() {
        return checkAmount;
    }

    public FixedLengthMetadata setCheckAmount(String checkAmount) {
        this.checkAmount = checkAmount;
        return this;
    }

    public String getCheckNumber() {
        return checkNumber;
    }

    public FixedLengthMetadata setCheckNumber(String checkNumber) {
        this.checkNumber = checkNumber;
        return this;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public FixedLengthMetadata setSubCategory(String subCategory) {
        this.subCategory = subCategory;
        return this;
    }

    public String getCategory() {
        return category;
    }

    public FixedLengthMetadata setCategory(String category) {
        this.category = category;
        return this;
    }

    public String getFileName() {
        return fileName;
    }

    public FixedLengthMetadata setFileName(String fileName) {
        this.fileName = fileName;
        return this;
    }

    public String getRecipientAddressLine1() {
        return recipientAddressLine1;
    }

    public FixedLengthMetadata setRecipientAddressLine1(String recipientAddressLine1) {
        this.recipientAddressLine1 = recipientAddressLine1;
        return this;
    }

    public String getRecipientAddressLine2() {
        return recipientAddressLine2;
    }

    public FixedLengthMetadata setRecipientAddressLine2(String recipientAddressLine2) {
        this.recipientAddressLine2 = recipientAddressLine2;
        return this;
    }

    public String getRecipientAddressLine3() {
        return recipientAddressLine3;
    }

    public FixedLengthMetadata setRecipientAddressLine3(String recipientAddressLine3) {
        this.recipientAddressLine3 = recipientAddressLine3;
        return this;
    }

    public String getRecipientAddressLine4() {
        return recipientAddressLine4;
    }

    public FixedLengthMetadata setRecipientAddressLine4(String recipientAddressLine4) {
        this.recipientAddressLine4 = recipientAddressLine4;
        return this;
    }

    public String getRecipientAddressLine5() {
        return recipientAddressLine5;
    }

    public FixedLengthMetadata setRecipientAddressLine5(String recipientAddressLine5) {
        this.recipientAddressLine5 = recipientAddressLine5;
        return this;
    }

    public String getConfigKey() {
        return configKey;
    }

    public FixedLengthMetadata setConfigKey(String configKey) {
        this.configKey = configKey;
        return this;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public FixedLengthMetadata setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
        return this;
    }

    public String getEdeliveryError() {
        return edeliveryError;
    }

    public FixedLengthMetadata setEdeliveryError(String edeliveryError) {
        this.edeliveryError = edeliveryError;
        return this;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public FixedLengthMetadata setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
        return this;
    }

    public String getNextLine() {
        return nextLine;
    }

    public FixedLengthMetadata setNextLine(String nextLine) {
        this.nextLine = nextLine;
        return this;
    }

}