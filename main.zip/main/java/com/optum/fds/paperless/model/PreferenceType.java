package com.optum.fds.paperless.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PreferenceType {

        private String classifier; // C1-C8, A1-A9, N1-N3, R1-R3, etc

        private String lob;

        private String providerName;

        private String description;

        private String documentId;

        private String deliveryMethod;

        private String providerEmailId;

        private String frequency;

        private String okToChangePDOInd = "Y";

        private String autoEdelUpdateInd;

        private String activeDate;
        private String lastOONPopUpDate;

        private String lastUpdatedBy;

        private String lastUpdatedById;

        private String autoOptOutInd;

        private Integer optedOutDuration;

        private String optedOutDateTime;

        private String expiryDate;

        private String subscribeToEmail;

        private String dateModified;

        private List<String> secondaryEmails;

        public PreferenceType()
        {}

        public PreferenceType(String classifier, String providerName, String description, String documentId, String deliveryMethod,
                              String providerEmailId, String frequency, String okToChangePDOInd, String autoEdelUpdateInd, String activeDate, String lastOONPopUpDate, String lastUpdatedBy, String lastUpdatedById,
                              String autoOptOutInd, Integer optedOutDuration, String optedOutDateTime, String expiryDate, String subscribeToEmail, String dateModified, List<String> secondaryEmails)
        {
            super();
            this.classifier = classifier;
            this.providerName = providerName;
            this.description = description;
            this.documentId = documentId;
            this.deliveryMethod = deliveryMethod;
            this.providerEmailId = providerEmailId;
            this.frequency = frequency;
            this.okToChangePDOInd = okToChangePDOInd;
            this.autoEdelUpdateInd = autoEdelUpdateInd;
            this.activeDate = activeDate;
            this.lastOONPopUpDate = lastOONPopUpDate;
            this.lastUpdatedById=lastUpdatedById;
            this.lastUpdatedBy =lastUpdatedBy;
            this.autoOptOutInd = autoOptOutInd;
            this.optedOutDuration = optedOutDuration;
            this.optedOutDateTime = optedOutDateTime;
            this.expiryDate = expiryDate;
            this.subscribeToEmail = subscribeToEmail;
            this.dateModified = dateModified;
            this.secondaryEmails = secondaryEmails;
        }

    public List<String> getSecondaryEmails() {
        return secondaryEmails;
    }

    public void setSecondaryEmails(List<String> secondaryEmails) {
        this.secondaryEmails = secondaryEmails;
    }

    public String getLastUpdatedById() {
            return lastUpdatedById;
        }

        public void setLastUpdatedById(String lastUpdatedById) {
            this.lastUpdatedById = lastUpdatedById;
        }

        public String getClassifier()
        {
            return classifier;
        }

        public void setClassifier(String classifier)
        {
            this.classifier = classifier;
        }

        public String getDocumentId()
        {
            return documentId;
        }

        public void setDocumentId(String documentId)
        {
            this.documentId = documentId;
        }

        public String getDescription()
        {
            return description;
        }

        public void setDescription(String description)
        {
            this.description = description;
        }

        public String getDeliveryMethod()
        {
            return deliveryMethod;
        }

        public void setDeliveryMethod(String deliveryMethod)
        {
            this.deliveryMethod = deliveryMethod;
        }


        public String getProviderEmailId()
        {
            return providerEmailId;
        }

        public void setProviderEmailId(String providerEmailId)
        {
            this.providerEmailId = providerEmailId;
        }

        public String getFrequency()
        {
            return frequency;
        }

        public void setFrequency(String frequency)
        {
            this.frequency = frequency;
        }

        public String getProviderName()
        {
            return providerName;
        }

        public void setProviderName(String providerName)
        {
            this.providerName = providerName;
        }

        public String getLob()
        {
            return lob;
        }

        public void setLob(String lob)
        {
            this.lob = lob;
        }

        public String getOkToChangePDOInd()
        {
            return okToChangePDOInd;
        }

        public void setOkToChangePDOInd(String okToChangePDOInd)
        {
            this.okToChangePDOInd = okToChangePDOInd;
        }

        public String getAutoEdelUpdateInd()
        {
            return autoEdelUpdateInd;
        }

        public void setAutoEdelUpdateInd(String autoEdelUpdateInd)
        {
            this.autoEdelUpdateInd = autoEdelUpdateInd;
        }



        public String getActiveDate() {
            return activeDate;
        }

        public void setActiveDate(String activeDate) {
            this.activeDate = activeDate;
        }
        public String getLastOONPopUpDate() {
            return lastOONPopUpDate;
        }

        public void setLastOONPopUpDate(String lastOONPopUpDate) {
            this.lastOONPopUpDate = lastOONPopUpDate;
        }


        public String getLastUpdatedBy() {
            return lastUpdatedBy;
        }

        public void setLastUpdatedBy(String lastUpdatedBy) {
            this.lastUpdatedBy = lastUpdatedBy;
        }

        public String getAutoOptOutInd() {
            return autoOptOutInd;
        }

        public void setAutoOptOutInd(String autoOptOutInd) {
            this.autoOptOutInd = autoOptOutInd;
        }

        public Integer getOptedOutDuration() {
            return optedOutDuration;
        }

        public void setOptedOutDuration(Integer optedOutDuration) {
            this.optedOutDuration = optedOutDuration;
        }

        public String getOptedOutDateTime() {
            return optedOutDateTime;
        }

        public void setOptedOutDateTime(String optedOutDateTime) {
            this.optedOutDateTime = optedOutDateTime;
        }

        public String getExpiryDate() {
            return expiryDate;
        }

        public void setExpiryDate(String expiryDate) {
            this.expiryDate = expiryDate;
        }

        public String getSubscribeToEmail() {
            return subscribeToEmail;
        }

        public void setSubscribeToEmail(String subscribeToEmail) {
            this.subscribeToEmail = subscribeToEmail;
        }

        public String getDateModified() { return dateModified; }

        public void setDateModified(String dateModified) { this.dateModified = dateModified; }
        @Override
        public String toString() {
            return "PreferenceType [classifier=" + classifier + ", lob=" + lob + ", providerName=" + providerName
                    + ", description=" + description + ", documentId=" + documentId + ", deliveryMethod=" + deliveryMethod
                    + ", providerEmailId=" + providerEmailId + ", frequency=" + frequency + ", okToChangePDOInd="
                    + okToChangePDOInd + ", autoEdelUpdateInd=" + autoEdelUpdateInd + ", activeDate=" + activeDate
                    + ", lastOONPopUpDate=" + lastOONPopUpDate + ", lastUpdatedBy=" + lastUpdatedBy + ", autoOptOutInd=" + autoOptOutInd + ", optedOutDuration="
                    + optedOutDuration + ", optedOutDateTime=" + optedOutDateTime + ", expiryDate=" + expiryDate
                    + ", subscribeToEmail=" + subscribeToEmail +", dateModified=" + dateModified +"]";
        }

}
