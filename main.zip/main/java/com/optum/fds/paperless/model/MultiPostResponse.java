package com.optum.fds.paperless.model;

import java.util.List;

public class MultiPostResponse {
	
	private List<String> insertedDocIds;
	
	public MultiPostResponse(List<String> insertedDocIds) {
		this.insertedDocIds = insertedDocIds;
	}

	public List<String> getInsertedDocIds() {
		return insertedDocIds;
	}

	public void setInsertedDocIds(List<String> insertedDocIds) {
		this.insertedDocIds = insertedDocIds;
	}

}
