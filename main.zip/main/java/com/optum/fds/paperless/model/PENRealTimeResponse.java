package com.optum.fds.paperless.model;

import java.util.List;
import java.util.Map;

public class PENRealTimeResponse {
    private String statusCode;
    
    private String statusMessage;
    
    private PENRealTimeResponseMessage responseMessage;

	@Override
	public String toString() {
		return "PENRealTimeResponse [statusCode=" + statusCode + ", statusMessage=" + statusMessage
				+ ", responseMessage=" + responseMessage + "]";
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public PENRealTimeResponseMessage getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(PENRealTimeResponseMessage responseMessage) {
		this.responseMessage = responseMessage;
	}
	
	

}
