package com.optum.fds.paperless.provider.pojo;

import java.util.Date;

public class RequestHeader {
    private final String scope;
    private final String actor;
    private final String correlationId;
    private final String token;
    private final Date timeStamp;

    private RequestHeader(RequestHeaderBuilder builder) {
        scope = builder.scope;
        actor = builder.actor;
        correlationId = builder.correlationId;
        token = builder.token;
        timeStamp = (builder.timeStamp == null)? new Date() : builder.timeStamp;
    }

    public static class RequestHeaderBuilder {
        private String scope;
        private String actor;
        private String correlationId;
        private String token;
        private Date timeStamp;

        public RequestHeaderBuilder setScope(String scope) {
            this.scope = scope;
            return this;
        }

        public RequestHeaderBuilder setActor(String actor) {
            this.actor = actor;
            return this;
        }

        public RequestHeaderBuilder setCorrelationId(String correlationId) {
            this.correlationId = correlationId;
            return this;
        }

        public RequestHeaderBuilder setToken(String token) {
            this.token = token;
            return this;
        }

        public RequestHeaderBuilder setTimeStamp(Date timeStamp) {
            this.timeStamp = timeStamp;
            return this;
        }

        public RequestHeader build() {
            return new RequestHeader(this);
        }
    }

    public String getScope() {
        return scope;
    }

    public String getActor() {
        return actor;
    }

    public String getToken() {
        return token;
    }

    public String getTimeStamp() {
        return timeStamp.toString();
    }

    public String getCorrelationId() {
        return correlationId;
    }
}
