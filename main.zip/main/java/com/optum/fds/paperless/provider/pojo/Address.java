package com.optum.fds.paperless.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class Address {

    @JsonProperty("adr_pri_cd")
    private String adrPriCd;
    @JsonProperty("mdcd_loc_cd")
    private String mdcdLocCd;
    @JsonProperty("mdcd_id")
    private String mdcdId;
    @JsonProperty("addr_seq")
    private int addrSeq;
    @JsonProperty("adr_eff_dt")
    private Date adrEffDt;
    @JsonProperty("adr_canc_dt")
    private Date adrCancDt;
    @JsonProperty("adr_id")
    private String adrId;
    @JsonProperty("adr_ln_1_txt")
    private String adrLn1Txt;
    @JsonProperty("cty_nm")
    private String ctyNm;
    @JsonProperty("st_cd")
    private String stCd;
    @JsonProperty("zip_cd")
    private String zipCd;
    @JsonProperty("zip_pls_4_cd")
    private String zipPls4Cd;
    @JsonProperty("cnty_nm")
    private String cntyNm;
    @JsonProperty("hncp_acsbl_ind")
    private String hncpAcsblInd;
    @JsonProperty("adr_typ_cd")
    private String adrTypCd;
    @JsonProperty("adr_typ_desc")
    private String adrTypDesc;
    @JsonProperty("bill_adr_id")
    private String billAdrId;
    @JsonProperty("bill_adr_typ")
    private String billAdrTyp;
    @JsonProperty("bill_adr_typ_desc")
    private String billAdrTypDesc;
    @JsonProperty("bill_adr_seq")
    private int billAdrSeq;
    public void setAdrPriCd(String adrPriCd) {
        this.adrPriCd = adrPriCd;
    }
    public String getAdrPriCd() {
        return adrPriCd;
    }

    public void setMdcdLocCd(String mdcdLocCd) {
        this.mdcdLocCd = mdcdLocCd;
    }
    public String getMdcdLocCd() {
        return mdcdLocCd;
    }

    public void setMdcdId(String mdcdId) {
        this.mdcdId = mdcdId;
    }
    public String getMdcdId() {
        return mdcdId;
    }

    public void setAddrSeq(int addrSeq) {
        this.addrSeq = addrSeq;
    }
    public int getAddrSeq() {
        return addrSeq;
    }

    public void setAdrEffDt(Date adrEffDt) {
        this.adrEffDt = adrEffDt==null?null:(Date)adrEffDt.clone();
    }
    public Date getAdrEffDt() {
        return adrEffDt==null?null:(Date)adrEffDt.clone();
    }

    public void setAdrCancDt(Date adrCancDt) {
        this.adrCancDt = adrCancDt==null?null:(Date)adrCancDt.clone();
    }
    public Date getAdrCancDt() {
        return adrCancDt==null?null:(Date)adrCancDt.clone();
    }

    public void setAdrId(String adrId) {
        this.adrId = adrId;
    }
    public String getAdrId() {
        return adrId;
    }

    public void setAdrLn1Txt(String adrLn1Txt) {
        this.adrLn1Txt = adrLn1Txt;
    }
    public String getAdrLn1Txt() {
        return adrLn1Txt;
    }

    public void setCtyNm(String ctyNm) {
        this.ctyNm = ctyNm;
    }
    public String getCtyNm() {
        return ctyNm;
    }

    public void setStCd(String stCd) {
        this.stCd = stCd;
    }
    public String getStCd() {
        return stCd;
    }

    public void setZipCd(String zipCd) {
        this.zipCd = zipCd;
    }
    public String getZipCd() {
        return zipCd;
    }

    public void setZipPls4Cd(String zipPls4Cd) {
        this.zipPls4Cd = zipPls4Cd;
    }
    public String getZipPls4Cd() {
        return zipPls4Cd;
    }

    public void setCntyNm(String cntyNm) {
        this.cntyNm = cntyNm;
    }
    public String getCntyNm() {
        return cntyNm;
    }

    public void setHncpAcsblInd(String hncpAcsblInd) {
        this.hncpAcsblInd = hncpAcsblInd;
    }
    public String getHncpAcsblInd() {
        return hncpAcsblInd;
    }

    public void setAdrTypCd(String adrTypCd) {
        this.adrTypCd = adrTypCd;
    }
    public String getAdrTypCd() {
        return adrTypCd;
    }

    public void setAdrTypDesc(String adrTypDesc) {
        this.adrTypDesc = adrTypDesc;
    }
    public String getAdrTypDesc() {
        return adrTypDesc;
    }

    public void setBillAdrId(String billAdrId) {
        this.billAdrId = billAdrId;
    }
    public String getBillAdrId() {
        return billAdrId;
    }

    public void setBillAdrTyp(String billAdrTyp) {
        this.billAdrTyp = billAdrTyp;
    }
    public String getBillAdrTyp() {
        return billAdrTyp;
    }

    public void setBillAdrTypDesc(String billAdrTypDesc) {
        this.billAdrTypDesc = billAdrTypDesc;
    }
    public String getBillAdrTypDesc() {
        return billAdrTypDesc;
    }

    public void setBillAdrSeq(int billAdrSeq) {
        this.billAdrSeq = billAdrSeq;
    }
    public int getBillAdrSeq() {
        return billAdrSeq;
    }


}
