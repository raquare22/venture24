package com.optum.fds.paperless.provider.pojo;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>Java class for specialtyType complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="specialtyType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="primarySpecialtyIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="specialtyTypeCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="specialtyFullDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "specialtyType", propOrder = {
        "primarySpecialtyIndicator",
        "specialtyTypeCode",
        "specialtyFullDescription"
})

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class SpecialtyType implements Serializable {

    protected String primarySpecialtyIndicator;
    protected String specialtyTypeCode;
    protected String specialtyFullDescription;

    /**
     * Gets the value of the primarySpecialtyIndicator property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getPrimarySpecialtyIndicator() {
        return primarySpecialtyIndicator;
    }

    /**
     * Sets the value of the primarySpecialtyIndicator property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setPrimarySpecialtyIndicator(String value) {
        this.primarySpecialtyIndicator = value;
    }

    /**
     * Gets the value of the specialtyTypeCode property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getSpecialtyTypeCode() {
        return specialtyTypeCode;
    }

    /**
     * Sets the value of the specialtyTypeCode property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setSpecialtyTypeCode(String value) {
        this.specialtyTypeCode = value;
    }

    /**
     * Gets the value of the specialtyFullDescription property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getSpecialtyFullDescription() {
        return specialtyFullDescription;
    }

    /**
     * Sets the value of the specialtyFullDescription property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setSpecialtyFullDescription(String value) {
        this.specialtyFullDescription = value;
    }

}
