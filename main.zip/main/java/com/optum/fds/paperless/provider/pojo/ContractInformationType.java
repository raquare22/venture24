package com.optum.fds.paperless.provider.pojo;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;

/**
 * <p>Java class for contractInformationType complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="contractInformationType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="contractId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="incentiveDisincentiveId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="preferredNetworkIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tierIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="contractRoleCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="demoteIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="acoId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="acoName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "contractInformationType", propOrder = {
        "contractId",
        "incentiveDisincentiveId",
        "preferredNetworkIndicator",
        "tierIndicator",
        "contractRoleCode",
        "demoteIndicator",
        "acoId",
        "acoName"
})

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class ContractInformationType implements Serializable {

    protected String contractId;
    protected String incentiveDisincentiveId;
    protected String preferredNetworkIndicator;
    protected String tierIndicator;
    protected String contractRoleCode;
    protected String demoteIndicator;
    protected String acoId;
    protected String acoName;

    /**
     * Gets the value of the contractId property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getContractId() {
        return contractId;
    }

    /**
     * Sets the value of the contractId property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setContractId(String value) {
        this.contractId = value;
    }

    /**
     * Gets the value of the incentiveDisincentiveId property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getIncentiveDisincentiveId() {
        return incentiveDisincentiveId;
    }

    /**
     * Sets the value of the incentiveDisincentiveId property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setIncentiveDisincentiveId(String value) {
        this.incentiveDisincentiveId = value;
    }

    /**
     * Gets the value of the preferredNetworkIndicator property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getPreferredNetworkIndicator() {
        return preferredNetworkIndicator;
    }

    /**
     * Sets the value of the preferredNetworkIndicator property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setPreferredNetworkIndicator(String value) {
        this.preferredNetworkIndicator = value;
    }

    /**
     * Gets the value of the tierIndicator property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTierIndicator() {
        return tierIndicator;
    }

    /**
     * Sets the value of the tierIndicator property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTierIndicator(String value) {
        this.tierIndicator = value;
    }

    /**
     * Gets the value of the contractRoleCode property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getContractRoleCode() {
        return contractRoleCode;
    }

    /**
     * Sets the value of the contractRoleCode property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setContractRoleCode(String value) {
        this.contractRoleCode = value;
    }

    /**
     * Gets the value of the demoteIndicator property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDemoteIndicator() {
        return demoteIndicator;
    }

    /**
     * Sets the value of the demoteIndicator property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDemoteIndicator(String value) {
        this.demoteIndicator = value;
    }

    /**
     * Gets the value of the acoId property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getAcoId() {
        return acoId;
    }

    /**
     * Sets the value of the acoId property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setAcoId(String value) {
        this.acoId = value;
    }

    /**
     * Gets the value of the acoName property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getAcoName() {
        return acoName;
    }

    /**
     * Sets the value of the acoName property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setAcoName(String value) {
        this.acoName = value;
    }

}
