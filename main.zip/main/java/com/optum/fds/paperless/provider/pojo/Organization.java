package com.optum.fds.paperless.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class Organization {

    @JsonProperty("org_org_typ_cd")
    private String orgOrgTypCd;
    @JsonProperty("org_typ_desc")
    private String orgTypDesc;
    public void setOrgOrgTypCd(String orgOrgTypCd) {
        this.orgOrgTypCd = orgOrgTypCd;
    }
    public String getOrgOrgTypCd() {
        return orgOrgTypCd;
    }

    public void setOrgTypDesc(String orgTypDesc) {
        this.orgTypDesc = orgTypDesc;
    }
    public String getOrgTypDesc() {
        return orgTypDesc;
    }

}