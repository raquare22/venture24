package com.optum.fds.paperless.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class Provider {

    @JsonProperty("prov_eff_dt")
    private Date provEffDt;
    @JsonProperty("prov_canc_dt")
    private Date provCancDt;
    @JsonProperty("lst_nm")
    private String lstNm;
    @JsonProperty("fst_nm")
    private String fstNm;
    @JsonProperty("mdl_nm")
    private String mdlNm;
    @JsonProperty("nm_sufx_cd")
    private String nmSufxCd;
    @JsonProperty("prov_bth_dt")
    private Date provBthDt;
    @JsonProperty("prov_gdr_cd")
    private String provGdrCd;
    @JsonProperty("prov_typ_cd")
    private String provTypCd;
    @JsonProperty("org_typ_cd")
    private String orgTypCd;

    public void setProvEffDt(Date provEffDt) {
        this.provEffDt = provEffDt==null?null:(Date) provEffDt.clone();
    }
    public Date getProvEffDt() {
        return provEffDt==null?null:(Date) provEffDt.clone();
    }

    public void setProvCancDt(Date provCancDt) {
        this.provCancDt = provCancDt==null?null:(Date) provCancDt.clone();
    }
    public Date getProvCancDt() {
        return provCancDt==null?null:(Date) provCancDt.clone();
    }

    public void setLstNm(String lstNm) {
        this.lstNm = lstNm;
    }
    public String getLstNm() {
        return lstNm;
    }

    public void setFstNm(String fstNm) {
        this.fstNm = fstNm;
    }
    public String getFstNm() {
        return fstNm;
    }

    public void setMdlNm(String mdlNm) {
        this.mdlNm = mdlNm;
    }
    public String getMdlNm() {
        return mdlNm;
    }

    public void setNmSufxCd(String nmSufxCd) {
        this.nmSufxCd = nmSufxCd;
    }
    public String getNmSufxCd() {
        return nmSufxCd;
    }

    public void setProvBthDt(Date provBthDt) {
        this.provBthDt = provBthDt==null?null:(Date) provBthDt.clone();
    }
    public Date getProvBthDt() {
        return provBthDt==null?null:(Date) provBthDt.clone();
    }

    public void setProvGdrCd(String provGdrCd) {
        this.provGdrCd = provGdrCd;
    }
    public String getProvGdrCd() {
        return provGdrCd;
    }

    public void setProvTypCd(String provTypCd) {
        this.provTypCd = provTypCd;
    }
    public String getProvTypCd() {
        return provTypCd;
    }

    public void setOrgTypCd(String orgTypCd) {
        this.orgTypCd = orgTypCd;
    }
    public String getOrgTypCd() {
        return orgTypCd;
    }

}