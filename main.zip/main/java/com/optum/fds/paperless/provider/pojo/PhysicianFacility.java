package com.optum.fds.paperless.provider.pojo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class PhysicianFacility implements Serializable {
    private SvcResponse svcResponse;

    public SvcResponse getSvcResponse() {
        return svcResponse;
    }

    public void setSvcResponse(SvcResponse svcResponse) {
        this.svcResponse = svcResponse;
    }

}
