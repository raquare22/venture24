package com.optum.fds.paperless.provider.pojo;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>Java class for physicianFacilityInformationType complex type.
 *
 * <p>The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="physicianFacilityInformationType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="firstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gender" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="middleName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="facilityName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nhpInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nhpFlexInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="unetTciParStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="divPanelParStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lobParStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="providerId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="suffix" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="taxId" type="{}taxIdType" minOccurs="0"/>
 *         &lt;element name="npi" type="{}npiType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="organizationalType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="organizationalTypeDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="specialty" type="{}specialtyType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="corpOwnerInformation" type="{}corpOwnerInformationType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="contractInformation" type="{}contractInformationType" minOccurs="0"/>
 *         &lt;element name="entityInformation" type="{}entityInformationType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="uhpd" type="{}uhpdType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "physicianFacilityInformationType", propOrder = {
        "firstName",
        "gender",
        "lastName",
        "middleName",
        "facilityName",
        "nhpInd",
        "nhpFlexInd",
        "unetTciParStatus",
        "divPanelParStatus",
        "lobParStatus",
        "providerId",
        "suffix",
        "taxId",
        "address",
        "npi",
        "organizationalType",
        "organizationalTypeDescription",
        "specialty",
        "corpOwnerInformation",
        "contractInformation",
        "entityInformation",
        "uhpd"
})

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class PhysicianFacilityInformation implements Serializable {

    protected String firstName;
    protected String gender;
    protected String lastName;
    protected String middleName;
    protected String facilityName;
	protected String nhpInd;
    protected String nhpFlexInd;
    protected String unetTciParStatus;
    protected String divPanelParStatus;
    protected String lobParStatus;
    protected String providerId;
    protected String suffix;
    protected List<TaxIdType> taxId;
    protected AddressType address;
    protected List<NpiType> npi;
    protected String organizationalType;
    protected String organizationalTypeDescription;
    protected List<SpecialtyType> specialty;
    protected List<CorpOwnerInformationType> corpOwnerInformation;
    protected ContractInformationType contractInformation;
    protected List<EntityInformationType> entityInformation;
    protected List<UhpdType> uhpd;
   

    /**
     * Gets the value of the firstName property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Gets the value of the gender property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getGender() {
        return gender;
    }

    /**
     * Sets the value of the gender property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setGender(String value) {
        this.gender = value;
    }

    /**
     * Gets the value of the lastName property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Gets the value of the middleName property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Sets the value of the middleName property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setMiddleName(String value) {
        this.middleName = value;
    }

    /**
     * Gets the value of the nhpInd property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNhpInd() {
        return nhpInd;
    }

    /**
     * Sets the value of the nhpInd property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNhpInd(String value) {
        this.nhpInd = value;
    }

    /**
     * Gets the value of the nhpFlexInd property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getNhpFlexInd() {
        return nhpFlexInd;
    }

    /**
     * Sets the value of the nhpFlexInd property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setNhpFlexInd(String value) {
        this.nhpFlexInd = value;
    }

    /**
     * Gets the value of the unetTciParStatus property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getUnetTciParStatus() {
        return unetTciParStatus;
    }

    /**
     * Sets the value of the unetTciParStatus property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setUnetTciParStatus(String value) {
        this.unetTciParStatus = value;
    }

    /**
     * Gets the value of the divPanelParStatus property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDivPanelParStatus() {
        return divPanelParStatus;
    }

    /**
     * Sets the value of the divPanelParStatus property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDivPanelParStatus(String value) {
        this.divPanelParStatus = value;
    }

    /**
     * Gets the value of the lobParStatus property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLobParStatus() {
        return lobParStatus;
    }

    /**
     * Sets the value of the lobParStatus property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLobParStatus(String value) {
        this.lobParStatus = value;
    }

    /**
     * Gets the value of the providerId property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getProviderId() {
        return providerId;
    }

    /**
     * Sets the value of the providerId property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setProviderId(String value) {
        this.providerId = value;
    }

    /**
     * Gets the value of the suffix property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getSuffix() {
        return suffix;
    }

    /**
     * Sets the value of the suffix property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setSuffix(String value) {
        this.suffix = value;
    }

    /**
     * Gets the value of the taxId property.
     *
     * @return
     *     possible object is
     *     {@link TaxIdType }
     *
     */
    public List<TaxIdType> getTaxId() {
        if (taxId == null) {
            taxId = new ArrayList<TaxIdType> ();
        }
        return taxId;
    }

    public AddressType getAddress() {
        return address;
    }

    public void setAddress(AddressType address) {
        this.address = address;
    }

    /**
     * Gets the value of the npi property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the npi property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNpi().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NpiType }
     *
     *
     */
    public List<NpiType> getNpi() {
        if (npi == null) {
            npi = new ArrayList<NpiType> ();
        }
        return this.npi;
    }

    /**
     * Gets the value of the organizationalType property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getOrganizationalType() {
        return organizationalType;
    }

    /**
     * Sets the value of the organizationalType property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setOrganizationalType(String value) {
        this.organizationalType = value;
    }

    /**
     * Gets the value of the organizationalTypeDescription property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getOrganizationalTypeDescription() {
        return organizationalTypeDescription;
    }

    /**
     * Sets the value of the organizationalTypeDescription property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setOrganizationalTypeDescription(String value) {
        this.organizationalTypeDescription = value;
    }

    /**
     * Gets the value of the specialty property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the specialty property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSpecialty().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SpecialtyType }
     *
     *
     */
    public List<SpecialtyType> getSpecialty() {
        if (specialty == null) {
            specialty = new ArrayList<SpecialtyType>();
        }
        return this.specialty;
    }

    /**
     * Gets the value of the corpOwnerInformation property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the corpOwnerInformation property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCorpOwnerInformation().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CorpOwnerInformationType }
     *
     *
     */
    public List<CorpOwnerInformationType> getCorpOwnerInformation() {
        if (corpOwnerInformation == null) {
            corpOwnerInformation = new ArrayList<CorpOwnerInformationType>();
        }
        return this.corpOwnerInformation;
    }

    public void setCorpOwnerInformation(List<CorpOwnerInformationType> corpOwnerInformation) {
        this.corpOwnerInformation = corpOwnerInformation;
    }

    /**
     * Gets the value of the contractInformation property.
     *
     * @return
     *     possible object is
     *     {@link ContractInformationType }
     *
     */
    public ContractInformationType getContractInformation() {
        return contractInformation;
    }

    public void setTaxId(List<TaxIdType> taxId) {
		this.taxId = taxId;
	}

	/**
     * Sets the value of the contractInformation property.
     *
     * @param value
     *     allowed object is
     *     {@link ContractInformationType }
     *
     */
    public void setContractInformation(ContractInformationType value) {
        this.contractInformation = value;
    }

    /**
     * Gets the value of the entityInformation property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the entityInformation property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEntityInformation().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EntityInformationType }
     *
     *
     */
    public List<EntityInformationType> getEntityInformation() {
        if (entityInformation == null) {
            entityInformation = new ArrayList<EntityInformationType>();
        }
        return this.entityInformation;
    }

    /**
     * Gets the value of the uhpd property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the uhpd property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUhpd().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link UhpdType }
     *
     *
     */
    public List<UhpdType> getUhpd() {
        if (uhpd == null) {
            uhpd = new ArrayList<UhpdType>();
        }
        return this.uhpd;
    }
    
    public String getFacilityName() {
  		return facilityName;
  	}

  	public void setFacilityName(String facilityName) {
  		this.facilityName = facilityName;
  	}

}