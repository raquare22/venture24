package com.optum.fds.paperless.provider.pojo;

public class RequestNPI {
    private final RequestBodyNPI requestBodyNPI;
    private final RequestHeader requestHeader;

    private RequestNPI(RequestNPI.RequestBuilder builder) {
        requestBodyNPI = builder.requestBodyNPI;
        requestHeader = builder.requestHeader;
    }

    public static class RequestBuilder {
        private RequestBodyNPI requestBodyNPI;
        private RequestHeader requestHeader;

        public RequestNPI.RequestBuilder setRequestBodyNPI(RequestBodyNPI RequestBodyNPI) {
            this.requestBodyNPI = RequestBodyNPI;
            return this;
        }

        public RequestNPI.RequestBuilder setRequestHeader(RequestHeader requestHeader) {
            this.requestHeader = requestHeader;
            return this;
        }

        public RequestNPI build() {
            return new RequestNPI(this);
        }
    }
    public RequestBodyNPI getRequestBodyNPI() {
        return requestBodyNPI;
    }
    public RequestHeader getRequestHeader() {
        return requestHeader;
    }

    @Override
    public String toString() {
        return String.format("Request [RequestBodyNPI=%s, requestHeader=%s]", requestBodyNPI, requestHeader);
    }
}
