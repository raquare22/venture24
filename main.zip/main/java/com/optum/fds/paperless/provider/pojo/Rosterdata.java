package com.optum.fds.paperless.provider.pojo;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class Rosterdata {

    @JsonProperty("prov_key")
    private String provKey;
    @JsonProperty("prov_id")
    private String provId;
    @JsonProperty("tax_id_nbr")
    private String taxIdNbr;
    @JsonProperty("tax_id_typ_cd")
    private String taxIdTypCd;
    private List<List<Provider>> provider;
    @JsonProperty("tax_id")
    private List<List<TaxId>> taxId;
    private List<List<Specialty>> specialty;
    private List<List<Organization>> organization;
    private List<List<Npi>> npi;
    @JsonProperty("unet_contract")
    private List<List<UnetContract>> unetContract;
    private List<List<Degree>> degree;
    @JsonProperty("address_data")
    private List<List<AddressData>> addressData;
    public void setProvKey(String provKey) {
        this.provKey = provKey;
    }
    public String getProvKey() {
        return provKey;
    }

    public void setProvId(String provId) {
        this.provId = provId;
    }
    public String getProvId() {
        return provId;
    }

    public void setTaxIdNbr(String taxIdNbr) {
        this.taxIdNbr = taxIdNbr;
    }
    public String getTaxIdNbr() {
        return taxIdNbr;
    }

    public void setTaxIdTypCd(String taxIdTypCd) {
        this.taxIdTypCd = taxIdTypCd;
    }
    public String getTaxIdTypCd() {
        return taxIdTypCd;
    }

    public void setProvider(List<List<Provider>> provider) {
        this.provider = new ArrayList<>(provider);
    }
    public List<List<Provider>> getProvider() {
        return new ArrayList<>(provider);
    }

    public void setTaxId(List<List<TaxId>> taxId) {
        this.taxId = new ArrayList<>(taxId);
    }
    public List<List<TaxId>> getTaxId() {
        return new ArrayList<>(taxId);
    }

    public void setSpecialty(List<List<Specialty>> specialty) {
        this.specialty = new ArrayList<>(specialty);
    }
    public List<List<Specialty>> getSpecialty() {
        return new ArrayList<>(specialty);
    }

    public void setOrganization(List<List<Organization>> organization) {
        this.organization = new ArrayList<>(organization);
    }
    public List<List<Organization>> getOrganization() {
        return new ArrayList<>(organization);
    }

    public void setNpi(List<List<Npi>> npi) {
        this.npi = new ArrayList<>(npi);
    }
    public List<List<Npi>> getNpi() {
        return new ArrayList<>(npi);
    }

    public void setUnetContract(List<List<UnetContract>> unetContract) {
        this.unetContract = new ArrayList<>(unetContract);
    }
    public List<List<UnetContract>> getUnetContract() {
        return new ArrayList<>(unetContract);
    }

    public void setDegree(List<List<Degree>> degree) {
        this.degree = new ArrayList<>(degree);
    }
    public List<List<Degree>> getDegree() {
        return new ArrayList<> (degree);
    }

    public void setAddressData(List<List<AddressData>> addressData) {
        this.addressData = new ArrayList<>(addressData);
    }
    public List<List<AddressData>> getAddressData() {
        return new ArrayList<>(addressData);
    }

}