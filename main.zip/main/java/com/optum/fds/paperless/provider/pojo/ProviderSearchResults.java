package com.optum.fds.paperless.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class ProviderSearchResults {
    private List<Records> records;
    private Metadata metadata;

    public void setRecords(List<Records> records) {
        this.records = records==null?null:new ArrayList<>(records);
    }
    public List<Records> getRecords() {
        return records==null?null:new ArrayList<> (records);
    }

    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }
    public Metadata getMetadata() {
        return metadata;
    }
}
