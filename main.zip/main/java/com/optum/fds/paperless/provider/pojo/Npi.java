package com.optum.fds.paperless.provider.pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class Npi {

    @JsonProperty("npi_id")
    private String npiId;
    @JsonProperty("npi_lvl_cd")
    private String npiLvlCd;
    @JsonProperty("npi_eff_dt")
    private Date npiEffDt;
    @JsonProperty("npi_canc_dt")
    private Date npiCancDt;
    public void setNpiId(String npiId) {
        this.npiId = npiId;
    }
    public String getNpiId() {
        return npiId;
    }

    public void setNpiLvlCd(String npiLvlCd) {
        this.npiLvlCd = npiLvlCd;
    }
    public String getNpiLvlCd() {
        return npiLvlCd;
    }

    public void setNpiEffDt( Date npiEffDt) {
        this.npiEffDt = npiEffDt==null?null:(Date) npiEffDt.clone();
    }
    public Date getNpiEffDt() {
        return npiEffDt==null?null:(Date) npiEffDt.clone();
    }

    public void setNpiCancDt(Date npiCancDt) {
        this.npiCancDt = npiCancDt==null?null:(Date) npiCancDt.clone();
    }
    public Date getNpiCancDt() {
        return npiCancDt==null?null:(Date) npiCancDt.clone();
    }

}