package com.optum.fds.paperless.document.util;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.domain.revision.AttachmentRevision;
import com.optum.fds.paperless.mongo.AttachmentMetaData;
import org.springframework.beans.factory.annotation.Value;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Attachment implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty(value = "id")
    private String id;

    @JsonProperty(value = "index")
    private Integer index;

    @JsonProperty(value = "status")
    private String status;

    @JsonProperty(value = "external_id")
    private String externalId;

    @JsonProperty(value = "space_id")
    private Integer spaceIdUnder;

    @JsonProperty(value = "expires")
    private Date expires;

    @JsonProperty(value = "file_name")
    private String fileNameUnder;

    @JsonProperty(value = "file_size")
    private Long fileSizeUnder;

    @JsonProperty(value = "content_type")
    private String contentTypeUnder;

    @JsonProperty(value = "date_created")
    private Date dateCreated;

    @JsonProperty(value = "source_system_name")
    private String sourceSystemName;

    @JsonProperty(value = "source_system_date_created")
    private Date sourceSystemDateCreated;

    @JsonProperty(value = "revisions")
    private List<AttachmentRevision> revisions;

    // DocLibrary fields
    @JsonProperty(value = "fileId")
    private String fileId;

    @JsonProperty(value = "fileDescription")
    private String fileDescription;

    @JsonProperty(value = "fileCreatedDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date fileCreatedDate;

    @JsonProperty(value = "spaceId")
    private String spaceId;

    @JsonProperty(value = "fileName")
    private String fileName;

    @JsonProperty(value = "fileSize")
    private String fileSize;

    @JsonProperty(value = "contentType")
    private String contentType;

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public static Attachment createDocLibAttachment(AttachmentMetaData amd) {
		Attachment atmt = new Attachment();
        if (amd.getAttachmentId() != null && !amd.getAttachmentId().isEmpty()) {
            atmt.setFileId(amd.getAttachmentId());
        } else {
            if(amd.getDoc360DocumentId() != null && !amd.getDoc360DocumentId().isEmpty()) {
                atmt.setFileId(amd.getDoc360DocumentId());
            }
        }
		atmt.setFileCreatedDate(amd.getDateCreated());
		atmt.setSpaceId(amd.getSpaceId());
		atmt.setFileName(amd.getFileName());
		atmt.setFileSize(amd.getFileSize());
//		atmt.setContentType(amd.getContentType());
		return atmt;
	}
	

	public void setIndex(Integer index) {
		this.index = index;
	}

	public void setSpaceIdUnder(Integer spaceIdUnder) {
		this.spaceIdUnder = spaceIdUnder;
	}

	public void setFileSizeUnder(Long fileSizeUnder) {
		this.fileSizeUnder = fileSizeUnder;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getFileDescription() {
		return fileDescription;
	}

	public void setFileDescription(String fileDescription) {
		this.fileDescription = fileDescription;
	}

	public Date getFileCreatedDate() {
		return fileCreatedDate;
	}

	public void setFileCreatedDate(Date fileCreatedDate) {
		this.fileCreatedDate = fileCreatedDate;
	}

	public String getSpaceId() {
		return spaceId;
	}

	public void setSpaceId(String spaceId) {
		this.spaceId = spaceId;
	}

	public void setSpaceId(int spaceId) {
		this.setSpaceId(String.valueOf(spaceId));
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getSpaceIdUnder() {
        return spaceIdUnder;
    }

    public void setSpaceIdUnder(int spaceIdUnder) {
        this.spaceIdUnder = spaceIdUnder;
    }

    public Date getExpires() {
        return expires == null ? null : (Date) expires.clone();
    }

    public void setExpires(Date expires) {
        this.expires = expires == null ? null : (Date) expires.clone();
    }

    public String getFileNameUnder() {
        return fileNameUnder;
    }

    public void setFileNameUnder(String fileNameUnder) {
        this.fileNameUnder = fileNameUnder;
    }

    public Long getFileSizeUnder() {
        return fileSizeUnder;
    }

    public void setFileSizeUnder(long fileSizeUnder) {
        this.fileSizeUnder = fileSizeUnder;
    }

    public String getContentTypeUnder() {
        return contentTypeUnder;
    }

    public void setContentTypeUnder(String contentTypeUnder) {
        this.contentTypeUnder = contentTypeUnder;
    }

    public Date getDateCreated() {
        return dateCreated == null ? null : (Date) dateCreated.clone();
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated == null ? null : (Date) dateCreated.clone();
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getSourceSystemName() {
        return sourceSystemName;
    }

    public void setSourceSystemName(String sourceSystemName) {
        this.sourceSystemName = sourceSystemName;
    }

    public Date getSourceSystemDateCreated() {
        return sourceSystemDateCreated == null ? null : (Date) sourceSystemDateCreated.clone();
    }

    public void setSourceSystemDateCreated(Date sourceSystemDateCreated) {
        this.sourceSystemDateCreated = sourceSystemDateCreated == null ? null : (Date) sourceSystemDateCreated.clone();
    }

    public List<AttachmentRevision> getRevisions() {
        return revisions == null ? null : new ArrayList<>(revisions);
    }

    public void setRevisions(List<AttachmentRevision> revisions) {
        this.revisions = revisions == null ? null : new ArrayList<>(revisions);
    }

	public void setFileSize(long fileSize) {
		this.fileSize = String.valueOf(fileSize);
	}
}
