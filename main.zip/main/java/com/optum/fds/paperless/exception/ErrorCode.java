package com.optum.fds.paperless.exception;

public enum ErrorCode {
	PROCESS(0, "A process error has occurred."),
	VALIDATION(1, "A validation error has occurred."),
	PROCESS_SEND(2, "A process send error has occurred."),
	OUT_OF_RETRIES(3, "An out of retries error has occurred."),
	AUTHORIZATION_INITIALIZE(4, "An authorization initialization error has occurred."),
	
	RESPONSE_FILE_ERROR(25, "Error to process response file"),
	STATUS_FILE_ERROR(26, "Error to process status file"),
	DOCLIB_ERROR(27, "Error to process docLib"),
	PREPOST_ERROR(28, "Error to process prepost hook"),
	BOUNCE_EMAIL_ERROR(29, "Error to process bounce email"),
	MATCH_AND_MERGE_ERROR(30, "Error to process match and merge"),
	SHUTTERFLY_ERROR(31, "Error to process shutterfly"),
	REQUIRE_FIELD_ERROR(32, "Error to process required fields rules"),
	COMPANION_FILE_EMAIL_ALERT_ERROR(33, "Error to failed companion file email alert"),
	PEN_ERROR(34, "Error to process provider email notifications"),
	CLEANUP_ERROR(35, "Error to process cleanup"),
	CSV_CLEANUP_ERROR(36, "Error to process csv cleanup"),
	FILE_UNZIP_ERROR(37, "Error to process file unzip"),
	PROCESS_METADATA_ERROR(38, "Error to process metadata"),
	SFTP_ERROR(39, "Error to process sftp"),
	WORKFLOW_ERROR(40, "Error to process workflow"),
	REST_API_ERROR(41, "Message Service Rest Api Error"),
	STORAGE_ERROR_SHUTTERFLY_ERROR(42, "Error to process storage error shutterfly"),
	PROCESS_TEXT_FILE_ERROR(43, "Error to process text file"),
	PROCESS_USPCLAIMS_RESPONSE_FILE(44, "Error to process USP Claims respose xml file"),
	PROCESS_SFTP_SEND_EMAIL(45, "Error to process sftp send email"),
	PROCESS_CREATE_METADATA_FILES(46, "Error to retrieve and Send Metadata Files");

	private final int code;
	private final String description;

	private ErrorCode(int code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public int getCode() {
		return code;
	}

	@Override
	public String toString() {
		return code + ": " + description;
	}
}
