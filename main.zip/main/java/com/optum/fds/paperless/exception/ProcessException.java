package com.optum.fds.paperless.exception;

public class ProcessException extends PrunException {

	private static final long serialVersionUID = -3130853967314096765L;

	public ProcessException() {
		super(ErrorCode.PROCESS);
	}

	public ProcessException(String message, Throwable cause) {
		super(message, cause, ErrorCode.PROCESS);
	}

	public ProcessException(String message) {
		super(message, ErrorCode.PROCESS);
	}

	public ProcessException(Throwable cause) {
		super(cause, ErrorCode.PROCESS);
	}
}
