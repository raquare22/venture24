package com.optum.fds.paperless.exception;

public class OutOfRetriesException extends PrunException {

	private static final long serialVersionUID = 8432958972269652692L;

	public OutOfRetriesException() {
		super(ErrorCode.OUT_OF_RETRIES);
	}

	public OutOfRetriesException(String message, Throwable cause) {
		super(message, cause, ErrorCode.OUT_OF_RETRIES);
	}

	public OutOfRetriesException(String message) {
		super(message, ErrorCode.OUT_OF_RETRIES);
	}

	public OutOfRetriesException(Throwable cause) {
		super(cause, ErrorCode.OUT_OF_RETRIES);
	}
}
