package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service("RequiredVarsForProviderEmailNotification")
public class RequiredVarsForProviderEmailNotification extends OptumJavaDelegateBase{

    private static final Logger LOGGER = LoggerFactory.getLogger(RequiredVarsForProviderEmailNotification.class);

    private static final List<String> REQ_VARS = Arrays.asList(
            Workflow.PEN_API_URL,
            Workflow.APP_ID,
            Workflow.APP_SECRET,
            Workflow.TEMPLATE_NAME,
            Workflow.DOCUMENT_UPDATE_FLAG_VALUE,
            Workflow.DOCUMENT_UPDATE_FLAG_PATH,
            Workflow.MAX_RETRIES,
            Workflow.RETRY_SLEEP_TIME
    );

    public RequiredVarsForProviderEmailNotification() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("RequiredVarsForProviderEmailNotification-->doExecute-->Required variables are present in execution bus {}={}",
                "delegateExecutionId", getExecutionId(execution));
    }

    protected String getExecutionId(DelegateExecution execution) {
        return execution != null ? execution.getId() : "NULL";
    }
}
