package com.optum.fds.paperless.java.delegate;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import jakarta.annotation.PostConstruct;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.json.JSONObject;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.util.concurrent.RateLimiter;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.java.delegate.docvault.OutOfRetriesException;
import com.optum.fds.paperless.java.delegate.docvault.RetryOnExceptionHandler;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.model.ActiveUser;
import com.optum.fds.paperless.model.Org;
import com.optum.fds.paperless.model.User;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;


@Service("RetrieveEmailFromDigiSec")

public class RetrieveEmailFromDigiSec extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(RetrieveEmailFromDigiSec.class);
    private static final String JWT_HEADER = "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
    private static final String METADATA_PREFIX = "metadata.";
	
    String oauthFailure = "Failed to retrieve OAuth Token for Digital security API";

    private static String AUTHORIZATION_STRING = "Authorization";
    private static final String MISSING_OR_INVALID_DATA = "Missing or invalid data: ";
    private static final String PADDING_0 = "0";

    private RateLimiter rateLimiter;

    @Autowired
    private RestTemplate restTemplate;
    
    @Autowired
    private DocumentMetaDataService documentMetaDataService;
    
    @Autowired
    private OauthManagerUtil oauthManagerUtil;

    @Value("${useDigiSecPAA:true}")
    private boolean useDigiSecPAA;

	@Value("${DigiSec_PAA_URL}")
	private String DigiSecPAAURL;

    @Value("${DigiSec_USER_URL}")
    private String DigiSecUserURL;
    
    @Value("${DIGISEC_JWT_TOKEN_SECRET_KEY}")
    private String DIGISEC_JWT_TOKEN_SECRET_KEY;
    
    @Value("${DIGISEC_JWT_TOKEN_ISS}")
    private String DIGISEC_JWT_TOKEN_ISS;
    
    @Value("${DIGISEC_JWT_TOKEN_SUB}")
    private String DIGISEC_JWT_TOKEN_SUB;
    
    @Value("${DIGISEC_TPS:5}")
    private int DIGISEC_TPS;
    
    @Value("${DIGISEC_MULTIPLE_EMAILS_CLIENT_LIST}")
    public String digisecMultipleEmailsClientList;
    
    @Value("${DIGISEC_PAA_EMAIL_CLIENT_LIST}")
    public String digisecPAAEmailClientList;

	@Value("${PRUN.EMAIL_WORKFLOW_SPACEID}")
	private List<String> emailWorkflowSpaceIds;


    @PostConstruct
    private void initRateLimiter() {
        this.rateLimiter = RateLimiter.create(DIGISEC_TPS);
    }

	@Override
    public void doExecute(DelegateExecution execution) {
        LOGGER.info("RetrieveEmailFromDigiSec-->doExecute-->ENTER");
        
        String clientName = execution.getVariable(Workflow.CLIENT_NAME).toString();
        String spaceId = execution.getVariable(Workflow.SPACE_ID).toString();
		boolean skipDocumentGrouping = Boolean
				.parseBoolean(String.valueOf(execution.getVariable(Workflow.SKIP_DOCUMENT_GROUPING, String.class)));
        
        List<DocumentMetaData> documentMetaDataList = (List<DocumentMetaData>) execution.getVariable("documentMetaDataList");
        List<DocumentMetaData> updatedDocumentMetadataList = new ArrayList<>();
        
        Map<String, List<String>> groupedByMetadataMap = null;
        
        // if trackit spaceId, then get other documentMetaDataList
        if (emailWorkflowSpaceIds.contains(spaceId)){
        	documentMetaDataList = (List<DocumentMetaData>) execution.getVariable("uniqueFieldDocumentList");
        	groupedByMetadataMap = (Map<String, List<String>>) execution.getVariable("uniqueFieldMap");
        }
        
        else if (documentMetaDataList == null || documentMetaDataList.isEmpty() ) {
        	// if documentMetaDataList isn't on execution bus, check the documentIds variable to get list of documentIds 
    		List<String> docList = execution.getVariable("documentIds", List.class);
    		if (docList != null && !docList.isEmpty()) {
    		   documentMetaDataList = documentMetaDataService.getDocumentMetaDataList(docList);
    		}
        }
        
        
        
        for (var document : documentMetaDataList) {
			LOGGER.info("RetrieveEmailFromDigiSec process started for docId={}", document.getId());

			document = documentMetaDataService.getDocumentMetaData(document.getId());
            Document metadata = document.getMetadata();
            String id = document.getId();
            String corpMpin = metadata.getString("corporateMpin");
            String tin = metadata.getString("tin");
            String providerEmailId = metadata.getString(Workflow.PROVIDER_EMAIL_ID);
            List<String> providerEmailList = new ArrayList<>();
            try {

            	if(providerEmailId ==null || providerEmailId.isEmpty()) {
            	
                if (StringUtils.isEmpty(corpMpin) || StringUtils.isEmpty(tin)) {
                	// if missing tin or corpMpin, we can't fetch email, so no need to send to PEN
                	updateDocWithEDeliveryError(spaceId, tin, corpMpin, groupedByMetadataMap, id, document, skipDocumentGrouping);
                } else {
                	providerEmailList = getEmailsByCorporate(execution, document.getId(), corpMpin, tin, rateLimiter, clientName);
                }
                // trackit workflow
            	if (emailWorkflowSpaceIds.contains(spaceId)) {
            		List<String> documentIdsToUpdate = null;
					documentIdsToUpdate = (skipDocumentGrouping)?Collections.singletonList(id):groupedByMetadataMap.get(tin);
            		updateDocumentListWithEmail(providerEmailList, documentIdsToUpdate, id);
            	} else {
            		updatedDocumentMetadataList.add(updateDocumentWithEmail(providerEmailList, id));
            	}
             }
            } catch (Exception e) {
            	LOGGER.error("Error fetching email from DigiSec API for docId={}, e={}", document.getId(), ExceptionUtils.getStackTrace(e));
            	updateDocumentWithEmail(providerEmailList, document.getId());
            }
			LOGGER.info("RetrieveEmailFromDigiSec process complete for docId={}", document.getId());
		}
        
        execution.setTransientVariable("updatedDocumentMetadataList", updatedDocumentMetadataList);
        
        LOGGER.info("RetrieveEmailFromDigiSec-->doExecute-->EXIT");
    }

    public List<String> getEmailsByCorporate(DelegateExecution execution, String docId, String corporateMpin, String tin, RateLimiter rateLimiter, String clientName) {
    	rateLimiter.acquire();
    	
    	String formattedTin = StringUtils.leftPad(tin, 9, PADDING_0);
    	
    	try {
			if(digisecMultipleEmailsClientList.contains(clientName)){
				//get multiple Emails
    			ResponseEntity<String> response = postRequestToDigiSecWithRetry(execution, docId, corporateMpin, formattedTin, false);
				if (response != null && response.getBody() != null && response.getStatusCode().value() == 200) {
					ObjectMapper mapper = new ObjectMapper();
					ActiveUser activeUser;
					activeUser = mapper.readValue(response.getBody(), ActiveUser.class);
					if(activeUser != null && !activeUser.getUsers().isEmpty()){
						return getEmailList(activeUser.getUsers());}
				}
    		}

			else if(digisecPAAEmailClientList.contains(clientName))
			{
				//get PAA Email
				ResponseEntity<String> response = postRequestToDigiSecWithRetry(execution, docId, corporateMpin, formattedTin, true);
				if (response != null && response.getBody() != null && response.getStatusCode().value() == 200) {
                    return getPAAEmail(response.getBody());
				}

			}
    		return null;
		} catch (Exception e) {
			LOGGER.error("Error getting email from DigiSec API for docId={}, e={}", docId, ExceptionUtils.getStackTrace(e));
			return null;
		}
    }
    
    private List<String> getEmailList(List<User> users) {
    	List<String> emailList = new ArrayList<>();
    	for (User user : users) {
    		if ( user.getEmail() != null && !user.getEmail().isEmpty()) {
        		emailList.add(user.getEmail());
    		}
    	}
    	return emailList;
    }

    private List<String> getPAAEmail(String responseBody) {
        List<String> emailList = new ArrayList<>();
        try {
            ObjectMapper mapper = new ObjectMapper();
            if (useDigiSecPAA) {
                HashMap<String, String> responseMap = mapper.readValue(responseBody, HashMap.class);
                String email = responseMap.get("email");
                if (email != null && !email.isEmpty()){
                    emailList.add(email);
                }
            } else {
                ActiveUser activeUser = mapper.readValue(responseBody, ActiveUser.class);
                if (activeUser != null && !activeUser.getUsers().isEmpty()) {
                    for (User user : activeUser.getUsers()) {
                        if ("PA".equals(user.getUserType()) && user.getEmail() != null && !user.getEmail().isEmpty()) {
                            emailList.add(user.getEmail());
                        }
                    }
                }
            }

        } catch (Exception e) {
            LOGGER.error("Error parsing PAA email from DigiSec response, err={}", ExceptionUtils.getStackTrace(e));
        }
        return emailList;
    }

    
	ResponseEntity<String> postRequestToDigiSec(String corporateMpin, String tin, String token, String docId, Boolean isPaa)
			throws RestClientException {
		String url = (isPaa && useDigiSecPAA)?DigiSecPAAURL:DigiSecUserURL;
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);
		
		var headers = new HttpHeaders();
        headers.set(AUTHORIZATION_STRING, token);
		headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("x-identity", getHeaderJwtToken());
        headers.setConnection("keep-alive");
        Org provRequest = new Org();
        provRequest.setCorpMpin(corporateMpin);
		if (!isPaa) {
			provRequest.setTin(tin);
		}        HttpEntity<Org> requestEntity = new HttpEntity<Org>(provRequest, headers);
        LOGGER.info("postRequestToDigiSec for docId={}", Encode.forJava(docId));
        return restTemplate.exchange(builder.toUriString(), HttpMethod.POST, requestEntity, String.class);
	}
    
    ResponseEntity<String> postRequestToDigiSecWithRetry(DelegateExecution execution, String docId, String corporateMpin, String tin, boolean isPaa) throws OutOfRetriesException {
		ResponseEntity<String> response = null;
		
		var pesAppId = execution.getVariable(Workflow.PES_APP_ID, String.class);
        var pesAppSecret = execution.getVariable(Workflow.PES_APP_SECRET, String.class);
        var pesUrl = execution.getVariable(Workflow.PES_OAUTH_URL, String.class);
        var pesGrantType = execution.getVariable(Workflow.PES_GRANT_TYPE, String.class);


		var numRetries = 3;
		var timeToWaitMS = 500L;
		var retryHandler = new RetryOnExceptionHandler(numRetries, timeToWaitMS);

		String msg;
		while (retryHandler.shouldRetry()) {
			try {
				try {
					if (retryHandler.isRetry()) {
						String newToken = oauthManagerUtil.getOauthToken("tokenStargate", pesAppId, pesAppSecret, pesGrantType, pesUrl, true, null);
						String newAccessToken = "Bearer " + newToken;
						LOGGER.info("postRequestToDigiSecWithRetry retrying DigiSec call with new token");

						response = (isPaa)?postRequestToDigiSec(corporateMpin, tin, newAccessToken, docId, true): postRequestToDigiSec(corporateMpin, tin, newAccessToken, docId, false);
					} else {
						String token = oauthManagerUtil.getOauthToken("tokenStargate", pesAppId, pesAppSecret, pesGrantType, pesUrl, false, null);
						var accessToken = "Bearer " + token;
						response = (isPaa)?postRequestToDigiSec(corporateMpin, tin, accessToken, docId, true): postRequestToDigiSec(corporateMpin, tin, accessToken, docId, false);
					}
					break;
				} catch (HttpClientErrorException.Unauthorized e) {
					LOGGER.error("HttpClientErrorException Unauthorized for documentId={}, responseBody={}, statusCode={}", docId, e.getResponseBodyAsString(), e.getStatusCode());
					retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
					retryHandler.exceptionOccurred();
				} catch (HttpClientErrorException e) {
					if (e instanceof HttpClientErrorException.BadRequest) {
						LOGGER.warn("HttpClientErrorException for documentId={}, responseBody={}, statusCode={}", docId, e.getResponseBodyAsString(), e.getStatusCode());
					} else {
						LOGGER.error("HttpClientErrorException for documentId={}, responseBody={}, statusCode={}", docId, e.getResponseBodyAsString(), e.getStatusCode());
					}
					return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());					
				} catch (HttpServerErrorException e) {
					if (e instanceof HttpServerErrorException.GatewayTimeout || e instanceof HttpServerErrorException.BadGateway) {
						LOGGER.error("HttpClientErrorException for documentId={}, responseBody={}, statusCode={}", docId, e.getResponseBodyAsString(), e.getStatusCode());
						retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
						retryHandler.exceptionOccurred();
					}
					else {
						LOGGER.error("{} exception for documentId={}, responseBody={}, statusCode={}", e.getClass().getSimpleName(), docId, e.getResponseBodyAsString(), e.getStatusCode());
						return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
					}
				} catch (RestClientException e) {
					LOGGER.error("RestClientException for document {} and exception {} ", docId,
							ExceptionUtils.getStackTrace(e));

					retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
					retryHandler.exceptionOccurred();
				} catch(RuntimeException  e) {
					LOGGER.error("{} for document {} and exception {} ", e.getClass().getSimpleName(), docId,
							ExceptionUtils.getStackTrace(e));
					retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
					retryHandler.exceptionOccurred();
				}
				
			} catch (OutOfRetriesException e) {
				msg = String.format(
						"RestClientException to digisec exhausted %s retries with retry time %s millis",
						retryHandler.getNumRetries(), retryHandler.getTimeToWaitMS());
				LOGGER.error(msg);
				addErrorMsg("RestClientException", msg);
				throw new OutOfRetriesException(msg);
			}
		}
		return response;
	}

	private static String encode(byte[] bytes) {
	        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
	}
	
	private static String encode(JSONObject obj) {
        return encode(obj.toString().getBytes(StandardCharsets.UTF_8));
    }
	
	private String hmacSha256(String data, String secret) {
	    try {

	        byte[] hash = secret.getBytes(StandardCharsets.UTF_8);
	        Mac sha256Hmac = Mac.getInstance("HmacSHA256");
	        SecretKeySpec secretKey = new SecretKeySpec(hash, "HmacSHA256");
	        sha256Hmac.init(secretKey);

	        byte[] signedBytes = sha256Hmac.doFinal(data.getBytes(StandardCharsets.UTF_8));

	        return encode(signedBytes);
	    } catch (Exception ex) {
	        LOGGER.error("Error signing data with HMAC SHA256, err={}", ExceptionUtils.getStackTrace(ex));
	        return null;
	    }
	}
	
	
    private String getHeaderJwtToken() {
    	try {
    		JSONObject payload = new JSONObject();
        	
        	payload.put("iss", DIGISEC_JWT_TOKEN_ISS);
        	payload.put("sub", DIGISEC_JWT_TOKEN_SUB);
        	payload.put("exp", (System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(10)) / 1000L);
        	payload.put("iat", System.currentTimeMillis() / 1000L);
        	payload.put("preferred_username", "optumid");
        	payload.put("given_name", "fname");
        	payload.put("family_name", "lastname");
        	payload.put("email", "test@optum.com");
        	
        	String encodedHeader = encode(new JSONObject(JWT_HEADER));
        	String signature = hmacSha256(encodedHeader + "." + encode(payload), DIGISEC_JWT_TOKEN_SECRET_KEY);
        	String jwtToken = encodedHeader + "." + encode(payload) + "." + signature;
        	
        	return jwtToken;
    	} catch (Exception ex) {
    		LOGGER.error("Error creating JWT token, err={}", ExceptionUtils.getStackTrace(ex));
    		return null;
    	}
    }

    
    private void addEDeliverErrorToUpdateMap(Map<String, Object> updateMap, String field, org.bson.Document metadata) {
    	String eDeliveryError = metadata.getString(Workflow.E_DELIVERY_ERROR);
        String errorMessage = MISSING_OR_INVALID_DATA + field;
        if (StringUtils.isBlank(eDeliveryError)) {
        	updateMap.put(METADATA_PREFIX + Workflow.E_DELIVERY_ERROR, errorMessage);
        } else {
            if (!eDeliveryError.contains(errorMessage)) {
            	updateMap.put(METADATA_PREFIX + Workflow.E_DELIVERY_ERROR, eDeliveryError + "|" + errorMessage);
            }
        }
    }
    
    private void updateDocWithEDeliveryError(String spaceId, String tin, String corpMpin,
											 Map<String, List<String>> groupedByMetadataMap, String documentId, DocumentMetaData document, boolean skipDocumentGrouping) {
    	
    	// trackit workflow
    	if (emailWorkflowSpaceIds.contains(spaceId)) {
			List<String> documentIdsUpdateList = null;
			documentIdsUpdateList = (skipDocumentGrouping)?Collections.singletonList(documentId):groupedByMetadataMap.get(tin);
    		Map<String, Object> updateMap = new HashMap<>();
    		
    		org.bson.Document metadata = document.getMetadata();
    		
    		if (StringUtils.isEmpty(corpMpin)) {
    			LOGGER.info("adding corpMpin eDeliveryError, corpMpin={}", corpMpin);
    			addEDeliverErrorToUpdateMap(updateMap, Workflow.PROV_CORP_MPIN, metadata);
    		}
    		
    		if (StringUtils.isEmpty(tin)) {
    			LOGGER.info("adding tin eDeliveryError, tin={}", tin);
    			addEDeliverErrorToUpdateMap(updateMap, Workflow.TIN, metadata);
    		}
            
    		LOGGER.debug("updateDocWithEDeliveryError documentId={}, metadata={}, updateMap={}, docIdsUpdateList={}",
    				documentId, metadata, updateMap, documentIdsUpdateList);  		
    		if (!updateMap.isEmpty()) {
    			documentMetaDataService.saveDocumentMetaDataMulti(documentIdsUpdateList, updateMap);
    		}
    		
            
    		
    	} else {
    		
    		org.bson.Document metadata = document.getMetadata();
    		if (StringUtils.isEmpty(corpMpin)) {
        		WorkFlowUtil.updateEDeliveryError(metadata, Workflow.PROV_CORP_MPIN);
        	}
        	if (StringUtils.isEmpty(tin)) {
                WorkFlowUtil.updateEDeliveryError(metadata, Workflow.TIN);
        	}
    		documentMetaDataService.saveDocumentMetaData(document);
    	}
        
    	
    }
    
    public void updateDocumentListWithEmail(List<String> providerEmailList, List<String> documentIdsUpdateList, String documentId) {
    	
    	Map<String, Object> updateMap = new HashMap<>();
    	
    	DocumentMetaData document = documentMetaDataService.getDocumentMetaData(documentId);
    	
    	org.bson.Document metadata = document.getMetadata();
    	if (providerEmailList != null && !providerEmailList.isEmpty()) {
    		updateMap.put(METADATA_PREFIX + Workflow.PROVIDER_EMAIL_ID_LIST, providerEmailList);
    		updateMap.put(METADATA_PREFIX + Workflow.PROVIDER_EMAIL_ID, String.join("|", providerEmailList));
    		if ( (providerEmailList.get(0) == null || providerEmailList.get(0).isEmpty()) || (providerEmailList.get(0) != null && !Utilities.validateProviderEmail(providerEmailList.get(0))) ) {
    			// if providerEmail is invalid, add eDeliveryError
    			addEDeliverErrorToUpdateMap(updateMap, Workflow.PROVIDER_EMAIL_ID, metadata);
    		}
    		
        } else {
        	addEDeliverErrorToUpdateMap(updateMap, Workflow.PROVIDER_EMAIL_ID, metadata);
        }
    	
    	LOGGER.info("updateDocWithEDeliveryError documentId={}, metadata={}, updateMap={}, docIdsUpdateList={}",
				documentId, metadata, updateMap, documentIdsUpdateList);  		
		if (!updateMap.isEmpty()) {
			documentMetaDataService.saveDocumentMetaDataMulti(documentIdsUpdateList, updateMap);
		}
    	
    }

    public DocumentMetaData updateDocumentWithEmail(List<String> providerEmailList, String id) {
    	
        DocumentMetaData document = documentMetaDataService.getDocumentMetaData(id);
        Document metadata = document.getMetadata();
        if (providerEmailList != null && !providerEmailList.isEmpty()) {
            metadata.put(Workflow.PROVIDER_EMAIL_ID_LIST, providerEmailList);
            metadata.put(Workflow.PROVIDER_EMAIL_ID, String.join("|", providerEmailList));
            
            if (!Utilities.validateProviderEmail(providerEmailList.get(0))) {
    			// if providerEmail is invalid, add eDeliveryError
            	WorkFlowUtil.updateEDeliveryError(metadata, Workflow.PROVIDER_EMAIL_ID);
    		}
            
        } else {
            WorkFlowUtil.updateEDeliveryError(metadata, Workflow.PROVIDER_EMAIL_ID);
        }
        documentMetaDataService.saveDocumentMetaData(document);
        
        
        return document;
    }
}
