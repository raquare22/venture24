package com.optum.fds.paperless.java.delegate;


import com.optum.fds.paperless.constants.WorkflowConstants;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class OptumJavaDelegateBase implements JavaDelegate {
    private static final Logger LOGGER = LoggerFactory.getLogger(OptumJavaDelegateBase.class);

    protected List<String> reqVars;
    protected Document errorMap;

    protected OptumJavaDelegateBase() {}

    protected OptumJavaDelegateBase(List<String> reqVars) {
        this.reqVars = reqVars;
    }

    @SuppressWarnings("unchecked")
    private static Object createErrorMap(String x, Object y) {
        if (y == null) {
            return new Document().append(WorkflowConstants.NEW_ERRORS, 0);
        } else if (y instanceof Map && !(y instanceof Document)) {
            return new Document((Map<String, Object>) y);
        }
        return y;
    }

    public void execute(DelegateExecution execution)  {
    	errorMap = getErrorMap(execution.getVariables());
    	DateTimeFormatter dtf = DateTimeFormatter.ISO_DATE_TIME;
    	String now = OffsetDateTime.now().format(dtf);
    	execution.setTransientVariable("execStartTime", now);
    	execution.setTransientVariable("podName", getPodName());
        if ((!newErrors()) && errorMap.size() <= 1 && !isExitNow(execution)) {
        	checkRequiredVars(reqVars, execution.getVariables(), this.getClass().getSimpleName());
        	if ((!newErrors()) && errorMap.size() <= 1) {
                doExecute(execution);        		
        	}
            execution.setTransientVariable(WorkflowConstants.ERROR_MAP, errorMap);
            logErrorMsgs();
        }
    }

    protected abstract void doExecute(DelegateExecution execution);

    protected void addErrorMsg(String msgDescription, String errorMsg) {
        errorMap.append(msgDescription, errorMsg)
                .computeIfPresent(WorkflowConstants.NEW_ERRORS, (key, value) -> (int)value + 1);
    }

    protected boolean isExitNow(DelegateExecution execution) {
        return Boolean.TRUE.equals(execution.getVariable("exitNow", Boolean.class));
    }

    /*
     * If the variable is not present or the value of the variable is null or an
     * empty string an error message is added to the error map.
     */
    void checkRequiredVars(List<String> requiredVars, Map<String, Object> execVars, String activityName) {
        int newErrors = errorMap.get(WorkflowConstants.NEW_ERRORS, Integer.class);
        if (requiredVars != null) {
            var map = requiredVars
                    .stream()
                    .filter(x -> !execVars.containsKey(x) || execVars.get(x) == null || "".equals(execVars.get(x)))
                    .collect(Collectors.toMap(key -> "In " +  activityName + ", " + key, key -> "Required var missing"));
            errorMap.putAll(map);
            newErrors += map.size();
        }
        errorMap.append(WorkflowConstants.NEW_ERRORS, newErrors);
    }

    protected boolean newErrors() {
        return errorMap != null && errorMap.get(WorkflowConstants.NEW_ERRORS, 0) > 0;
    }

    /*
     * Check if errorMap is passed in from upstream task in workflow; if exists,
     * then use it If it does not exists, create a new errorMap for subsequent use.
     */
    @SuppressWarnings("unchecked")
    static Document getErrorMap(Map<String, Object> execVars) {
        return (Document) execVars.compute(Workflow.ERROR_MAP, OptumJavaDelegateBase::createErrorMap);
    }

    void logErrorMsgs() {
        if (newErrors()) {
            errorMap.toJson();
            LOGGER.error("Failed to execute {} due to following errors:" , this.getClass().getSimpleName() );
            errorMap.entrySet()
                    .stream()
                    .filter(errMsg -> !("newErrors").equals(errMsg.getKey()))
                    .forEach(errMsg -> LOGGER.error("{} : {}", errMsg.getKey(),  errMsg.getValue()));
        }
    }
    protected void setExitNow(DelegateExecution execution) {
        execution.setTransientVariable("exitNow", true);
    }
    
    String getPodName() {
        var hostname = "unknown";
        try {
            hostname = InetAddress.getLocalHost().getHostName();
        } catch(UnknownHostException e) {
            LOGGER.error("Did not obtain pod name");
        }
        return hostname;
    }

}
