package com.optum.fds.paperless.java.delegate;

import com.google.common.base.Strings;
import com.optum.fds.paperless.constants.CommonConstants;
import com.optum.fds.paperless.model.FixedLengthMetadata;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.beanio.StreamFactory;
import org.beanio.builder.FixedLengthParserBuilder;
import com.optum.fds.paperless.model.FixedLengthMetadataOCM;
import org.beanio.builder.StreamBuilder;
import org.eclipse.collections.api.list.MutableList;
import org.eclipse.collections.api.multimap.Multimap;
import org.eclipse.collections.impl.factory.Lists;
import org.eclipse.collections.impl.factory.Maps;
import org.eclipse.collections.impl.factory.Sets;
import org.eclipse.collections.impl.utility.LazyIterate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

import static com.optum.fds.paperless.workflow.constants.Workflow.*;

@Service("CreateShutterflyDocuments")
public class CreateShutterflyDocuments extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreateShutterflyDocuments.class);
    private static final SecureRandom random = new SecureRandom();
    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MMddyyyyHHmmSS");
    private static final List<String> REQ_VARS = List.of(
            LIST_DOCUMENT_METADATA
    );
    public CreateShutterflyDocuments() {
        super(REQ_VARS);
    }

    @SuppressWarnings("unchecked")
    @Override
    protected void doExecute(DelegateExecution execution) {
        Map<String, String> correlationIds = (Map<String, String>) execution.getVariable(CORRELATION_IDS);
        LOGGER.debug("CreateShutterflyDocuments-->doExecute-->START");
        String docID = StringUtils.EMPTY;
        var docIdList = Lists.mutable.<String>empty();
        try {

            var listDocumentMetaData = (List<DocumentMetaData>) execution.getVariable(LIST_DOCUMENT_METADATA);
            var defaultOriginalPrintTrail = execution.getVariable(ORIGINAL_PRINT_TRAIL, String.class);
            var createOriginalCompanionFile = execution.getVariable(CREATE_ORIGINAL_COMPANION_FILE);
            
            
            var targetWorkingDir = execution.getVariable(Workflow.OUTPUT_FILE_DIR_SHUTTERFLY, String.class);
            if (targetWorkingDir == null || targetWorkingDir.isEmpty()) {
        		targetWorkingDir = execution.getVariable(OUTPUT_FILE_DIR_BOUNCE, String.class);
        	}
            

            var fileNameEndString = String.join("_", getSecureRandomNumber(), getFormattedDate());
            var printServicesManifestFile = Lists.mutable.<String>empty();

            // collect to multimap where key will be FDS_RPRNT or FDS_NO_RPRNT and values will be unique based on fileName
            var listDocumentMetaDataMultiMap = getMultiMapValuesBasedOnFileName(listDocumentMetaData, defaultOriginalPrintTrail);


            for (var entry : listDocumentMetaDataMultiMap.keyMultiValuePairsView()) {
                var fileName = entry.getOne() + fileNameEndString;
                var listDocumentMetaDataBasedOnFileName = entry.getTwo().toList();
                var listDocIds = listDocumentMetaDataBasedOnFileName.asLazy()
                        .collect(DocumentMetaData::getId)
                        .toList();
                LOGGER.info("CreateShutterflyDocuments-->doExecute-->Processing fileName: {} for CorrelationIDs {} and Document IDs: {}, targetWorkingDir={}",
                        fileName,
                        Optional.ofNullable(correlationIds).map(o -> listDocIds.collect(o::get).makeString()).orElse(StringUtils.EMPTY),
                        listDocIds.makeString(),
                        targetWorkingDir);
                
                var doc =  listDocumentMetaData.iterator().next();
                var mData = doc.getMetadata();

                if(mData.containsKey(CREATE_APPLICATION) && "OCM".equals(mData.getString(CREATE_APPLICATION))) {
                    var factory = getStreamFactoryOCMInstance();

                    var fixedLengthMetadataOCM = listDocumentMetaDataBasedOnFileName.asLazy()
                            .tap(docMetaData -> docIdList.add(docMetaData.getId()))
                            .collect(documentMetaData ->  convertToFixedLengthMetadataOCM(documentMetaData, defaultOriginalPrintTrail, correlationIds), Lists.mutable.empty());
                    createTxtResponseFileOCM(factory, targetWorkingDir, fileName, fixedLengthMetadataOCM);

                } else {
                    var factory = getStreamFactoryInstance();
                    var fixedLengthMetadata = listDocumentMetaDataBasedOnFileName.asLazy()
                            .tap(docMetaData -> docIdList.add(docMetaData.getId()))
                            .collect(documentMetaData ->  convertToFixedLengthMetadata(documentMetaData, defaultOriginalPrintTrail, correlationIds), Lists.mutable.empty());
                    createTxtResponseFile(factory, targetWorkingDir, fileName, fixedLengthMetadata);
                }
                createOriginalCompanionFile(createOriginalCompanionFile, listDocumentMetaDataBasedOnFileName, targetWorkingDir, fileName, execution);
                printServicesManifestFile.add(fileName);
            }
			
			
			if (listDocumentMetaDataMultiMap.isEmpty()) {
				setExitNow(execution);
			} else {
				execution.setTransientVariable(PRINT_SERVICES_MANIFEST, printServicesManifestFile);
                LOGGER.info("CreateShutterflyDocuments.doExecute: printServicesManifestFile={}",
                        printServicesManifestFile.makeString(", "));
			}
			 

            execution.setTransientVariable(PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP, listDocumentMetaDataMultiMap);
        } catch (Exception e) {
            LOGGER.error("doExecute Exception while executing CreateShutterflyDocuments task {}={}, {}={} {}",
                    "delegateExecutionId", getDelegateExecutionId(execution), "documentId", docID, ExceptionUtils.getStackTrace(e));
            LOGGER.error("CreateShutterflyDocuments-->doExecute-->Exception while executing CreateShutterflyDocuments task for CorrelationID {} and error:{}",
                    Optional.ofNullable(correlationIds).map(o -> docIdList.collect(o::get).makeString()).orElse(StringUtils.EMPTY), e.getMessage());
            addErrorMsg("CreateShutterflyDocuments-->doExecute-->Exception while executing CreateShutterflyDocuments task for document ID: " + docID, e.getMessage());
            return;
        }
        LOGGER.debug("CreateShutterflyDocuments-->doExecute-->END");
    }

    private StreamFactory getStreamFactoryInstance() {
       var fixedLengthParserBuilder = new FixedLengthParserBuilder()
               .recordTerminator(StringUtils.EMPTY);
       var builderTXT = new StreamBuilder("textBuilder")
               .format("fixedlength")
               .parser(fixedLengthParserBuilder)
               .addRecord(FixedLengthMetadata.class);

       var streamFactory = StreamFactory.newInstance();
       streamFactory.define(builderTXT);
       return streamFactory;
    }

    private StreamFactory getStreamFactoryOCMInstance() {
        var fixedLengthParserBuilder = new FixedLengthParserBuilder()
                .recordTerminator(StringUtils.EMPTY);
        var builderTXT = new StreamBuilder("textBuilder")
                .format("fixedlength")
                .parser(fixedLengthParserBuilder)
                .addRecord(FixedLengthMetadataOCM.class);

        var streamFactory = StreamFactory.newInstance();
        streamFactory.define(builderTXT);
        return streamFactory;
    }

    private void createTxtResponseFile(StreamFactory factory, String targetWorkingDir, String fileName, MutableList<FixedLengthMetadata> fixedLengthMetadataList) {
        var out = factory.createWriter("textBuilder", new File(targetWorkingDir + fileName + TXT_FINAL_EXTENSION));
        fixedLengthMetadataList.forEach(out::write);
        out.flush();
        out.close();
    }

    private void createTxtResponseFileOCM(StreamFactory factory, String targetWorkingDir, String fileName, MutableList<FixedLengthMetadataOCM> fixedLengthMetadataList) {
        var out = factory.createWriter("textBuilder", new File(targetWorkingDir + fileName + TXT_FINAL_EXTENSION));
        fixedLengthMetadataList.forEach(out::write);
        out.flush();
        out.close();
    }

    private void createOriginalCompanionFile(Object createOriginalCompanionFile, MutableList<DocumentMetaData> listDocumentMetaData,
                                             String targetWorkingDir, String fileName, DelegateExecution execution) {

    	LOGGER.debug("createOriginalCompanionFile={}", createOriginalCompanionFile);
        if (createOriginalCompanionFile != null && (boolean) createOriginalCompanionFile) {
        	
            var docID = listDocumentMetaData.asLazy().collect(DocumentMetaData::getId).makeString();
            var templateName = execution.getVariable(TEMPLATE_NAME, String.class);

            LOGGER.debug("createOriginalCompanionFile file templateName{}", templateName);
            try (var fileWriter = new FileWriter(targetWorkingDir + fileName + CMP_FINAL_EXTENSION)) {
            	LOGGER.debug("fileWriter={}", fileName);
                var documentListJsonString = Parser.toJson(Maps.fixedSize.of(DOCUMENTS, listDocumentMetaData));

                LOGGER.debug("documentListJsonString = {}", documentListJsonString);
                
                String companionFileData = TemplateFactory.getInstance(templateName).convertWithTemplate(documentListJsonString);
                LOGGER.info("companionFileData = {}", companionFileData);
                
                fileWriter.write(companionFileData);
            } catch (Exception e) {
                LOGGER.error("doExecute createOriginalCompanionFileObject exception {}={}, {}={} {}",
                        "delegateExecutionId", getDelegateExecutionId(execution),
                        "documentId", docID,
                        ExceptionUtils.getStackTrace(e));
                addErrorMsg("CreateShutterflyDocuments-->doExecute-->Unable to create companion file data using companion template: "
                                + "file=" + targetWorkingDir + fileName + CMP_FINAL_EXTENSION + ", templateName=" + templateName,
                        WorkFlowUtil.getStackTrace(e));
                return;
            }
            execution.setTransientVariable(ORIGINAL_COMPANION_FILENAME, fileName);
        }
    }

    private Multimap<String, DocumentMetaData> getMultiMapValuesBasedOnFileName(List<DocumentMetaData> listDocumentMetaData, String defaultOriginalPrintTrail) {
        var fileSet = Sets.mutable.<String>empty();
        return LazyIterate.adapt(listDocumentMetaData)
                .select(x -> fileSet.add(x.getMetadata().getString(FILE_NAME)))
                .groupBy(x -> getFileName(x, defaultOriginalPrintTrail));
    }

    protected String getFileName(DocumentMetaData documentMetaData, String defaultOriginalPrintTrail) {
        var x = documentMetaData.getMetadata();
        var postCardInd = (boolean) x.getOrDefault(POST_CARD_IND, false);
        var providerEmailId = x.getString(PROVIDER_EMAIL_ID);
        var originalPrintTrail = (String) x.getOrDefault(ORIGINAL_PRINT_TRAIL, defaultOriginalPrintTrail);
        String fileName;
        if (postCardInd && (Strings.isNullOrEmpty(x.getString(TIN)) || Strings.isNullOrEmpty(x.getString(PROV_CORP_MPIN)) || Strings.isNullOrEmpty(x.getString(MPIN)) || CommonConstants.DEFAULT_SUBCATEGORY_LIST.contains(x.getString(Workflow.SUBCATEGORY)) )) {
            fileName = FDS_RPRNT_APPLICATION_NAME;
        } else if (postCardInd && Strings.isNullOrEmpty(providerEmailId)) {
            fileName = FDS_NO_RPRNT_APPLICATION_NAME + "_" + originalPrintTrail;
        } else {
            fileName = (postCardInd) ? FDS_NO_RPRNT_APPLICATION_NAME + "_" + originalPrintTrail : FDS_RPRNT_APPLICATION_NAME;
        }
        LOGGER.debug("CreateShutterflyDocuments shutterfly fileName = {}", fileName);
        return fileName;
    }

    private FixedLengthMetadata convertToFixedLengthMetadata(DocumentMetaData documentMetaData, String defaultOriginalPrintTrail, Map<String, String> correlationIds) {

        var doc = documentMetaData.getMetadata();
        var mailToAddress1 = doc.getString(MAIL_TO_ADDRESSONE);
        var physicianName = doc.getString(PHYSICIAN_NAME);
        var createApp = doc.getString(CREATE_APPLICATION);
        var providerName = doc.getString(PROVIDER_NAME);
        var passThruData = doc.getString(PASS_THRU_DATA);

        var fixedLengtMetaData = new FixedLengthMetadata()
                .setTagLine(doc.getString(TAG_LINE))
                .setProviderId(doc.getString(TIN))
                .setMpin(doc.getString(MPIN))
                .setPatientName(doc.getString(PATIENT_FIRST_NAME), doc.getString(PATIENT_LAST_NAME))
                .setPatientDateOfBirth(doc.getString(PATIENT_DATE_OF_BIRTH))
                .setRecipientName(Stream.of(mailToAddress1, providerName, physicianName)
                        .filter(StringUtils::isNotBlank).findFirst().orElse(null))
                .setCheckAmount(doc.getString(CHECK_AMT))
                .setCheckNumber(doc.getString(CHECK_TRACE_NUMBER))
                .setSubCategory(doc.getString(SUBCATEGORY))
                .setCategory(doc.getString(CATEGORY))
                .setRecipientAddressLine1(doc.getString(MAIL_TO_ADDRESSTWO))
                .setRecipientAddressLine2(doc.getString(MAIL_TO_ADDRESSTHREE))
                .setRecipientAddressLine3(doc.getString(MAIL_TO_ADDRESSFOUR))
                .setRecipientAddressLine4(doc.getString(MAIL_TO_ADDRESSFIVE))
                .setRecipientAddressLine5(doc.getString(MAIL_TO_ADDRESSSIX))
                .setConfigKey(doc.getString(CONFIGKEY))
                .setOriginalPrintTrail(Optional.ofNullable(doc.getString(ORIGINAL_PRINT_TRAIL)).orElse(defaultOriginalPrintTrail))
                .setEdeliveryError(doc.getString(EDELIVERY_ERROR))
                .setEmailAddress(doc.getString(EMAIL_ADDRESS))
                .setFileName(doc.getString(FILE_NAME))
                .setNextLine(RECORD_TERMINATOR_CHAR);

        if (Lists.fixedSize.with("1Click", "CCS Manual", "NextGen").contains(createApp)) {
            fixedLengtMetaData.setApplicationPassThru(passThruData,
                    Optional.ofNullable(doc.getString(LETTER_HISTORY_ID)).orElse(doc.getString(HISTORY_ID)));
        } else {
            fixedLengtMetaData.setApplicationPassThru(passThruData);
        }

        LOGGER.debug("CreateFixedLengthManifest write all fixedLengthMetaData fields for CorrelationID {}",
                Optional.ofNullable(correlationIds).map(o -> o.get(documentMetaData.getId())));
        return fixedLengtMetaData;
    }

    private FixedLengthMetadataOCM convertToFixedLengthMetadataOCM(DocumentMetaData documentMetaData, String defaultOriginalPrintTrail, Map<String, String> correlationIds) {

        var doc = documentMetaData.getMetadata();
        var mailToAddress1 = doc.getString(MAIL_TO_ADDRESSONE);
        var physicianName = doc.getString(PHYSICIAN_NAME);
        var createApp = doc.getString(CREATE_APPLICATION);
        var providerName = doc.getString(PROVIDER_NAME);
        var passThruData = doc.getString(PASS_THRU_DATA);

        var fixedLengtMetaDataOCM = new FixedLengthMetadataOCM()
                .setTagLine(doc.getString(TAG_LINE))
                .setProviderId(doc.getString(TIN))
                .setMpin(doc.getString(MPIN))
                .setPatientName(doc.getString(PATIENT_FIRST_NAME), doc.getString(PATIENT_LAST_NAME))
                .setPatientDateOfBirth(doc.getString(PATIENT_DATE_OF_BIRTH))
                .setRecipientName(Stream.of(mailToAddress1, providerName, physicianName)
                        .filter(StringUtils::isNotBlank).findFirst().orElse(null))
                .setCheckAmount(doc.getString(CHECK_AMT))
                .setCheckNumber(doc.getString(CHECK_TRACE_NUMBER))
                .setSubCategory(doc.getString(SUBCATEGORY))
                .setCategory(doc.getString(CATEGORY))
                .setRecipientAddressLine1(doc.getString(MAIL_TO_ADDRESSTWO))
                .setRecipientAddressLine2(doc.getString(MAIL_TO_ADDRESSTHREE))
                .setRecipientAddressLine3(doc.getString(MAIL_TO_ADDRESSFOUR))
                .setRecipientAddressLine4(doc.getString(MAIL_TO_ADDRESSFIVE))
                .setRecipientAddressLine5(doc.getString(MAIL_TO_ADDRESSSIX))
                .setConfigKey(doc.getString(CONFIGKEY))
                .setOriginalPrintTrail(Optional.ofNullable(doc.getString(ORIGINAL_PRINT_TRAIL)).orElse(defaultOriginalPrintTrail))
                .setEdeliveryError(doc.getString(EDELIVERY_ERROR))
                .setEmailAddress(doc.getString(EMAIL_ADDRESS))
                .setFileName(doc.getString(FILE_NAME))
                .setNotificationLetterID(doc.getString("NotificationLetterID"))
                .setNextLine(RECORD_TERMINATOR_CHAR);

        if (Lists.fixedSize.with("1Click", "CCS Manual", "NextGen").contains(createApp)) {
            fixedLengtMetaDataOCM.setApplicationPassThru(passThruData,
                    Optional.ofNullable(doc.getString(LETTER_HISTORY_ID)).orElse(doc.getString(HISTORY_ID)));
        } else {
            fixedLengtMetaDataOCM.setApplicationPassThru(passThruData);
        }

        LOGGER.debug("CreateFixedLengthManifest write all fixedLengthMetaDataOCM fields for CorrelationID {}",
                Optional.ofNullable(correlationIds).map(o -> o.get(documentMetaData.getId())));
        return fixedLengtMetaDataOCM;
    }

    private String getFormattedDate() {
        // thread safe
        return dateFormatter.format(LocalDateTime.now());
    }

    private String getSecureRandomNumber() {
        return String.format("%05d", random.nextInt(100000));
    }

    protected String getDelegateExecutionId(DelegateExecution execution) {
        return execution != null ? execution.getId() : "NULL";
    }
}