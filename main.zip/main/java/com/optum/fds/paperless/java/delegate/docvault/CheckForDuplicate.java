package com.optum.fds.paperless.java.delegate.docvault;

import com.optum.fds.paperless.java.delegate.OptumJavaDelegateBase;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;


@Service("CheckForDuplicate")
public class CheckForDuplicate extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(CheckForDuplicate.class);

    private static final List<String> REQ_VARS = List.of(
            Workflow.DOCUMENT
    );


    public CheckForDuplicate() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
        var document = (DocumentMetaData) execution.getVariable(Workflow.DOCUMENT);
        
        // add list of docIds to execution bus for reconciliation error message 
		List<String> documentIds = List.of(document.getId());
		 execution.setTransientVariable("documentIds", documentIds);
        
        var fileName = (String) document.getMetadata().get(Workflow.FILE_NAME);
        var documentAttachmentMetaData = document.getDocumentAttachments().get(0);
        var fsId = documentAttachmentMetaData.getFsId();
        var sentToDocvault = documentAttachmentMetaData.isSentToDocVault();
        var documentId = document.getId();
        var podName = execution.getVariable(Workflow.POD_NAME, String.class);
        if (sentToDocvault) {
            LOGGER.warn("document id {}, fileName {}, fsId {} is duplicate in pod {}", documentId, fileName, fsId, podName);
            addErrorMsg("duplicateAttachment", fsId);
            execution.setTransientVariable("duplicateDetected", fsId);
            setExitNow(execution);
        } else {
            LOGGER.debug("document id {}, fileName {} Not a duplicate, fsId: {} in pod {}", documentId, fileName, fsId, podName);
            execution.setTransientVariable("noDuplicate", fsId);
        }
    }
}