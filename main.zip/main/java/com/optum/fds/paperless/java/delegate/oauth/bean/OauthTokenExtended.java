/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 4/13/17.
 */

package com.optum.fds.paperless.java.delegate.oauth.bean;

import java.io.Serializable;
import java.time.Instant;
import java.util.Date;

public class OauthTokenExtended implements Serializable {

	private static final long MILLISECOND_CONVERSION_MULTIPLIER = 1000;
    private static final long serialVersionUID = 1L;
    // expire token 10 minutes before actual expiry
    private static final long TOKEN_EXPIRY_LATENT_TIME = 600000;

    private String accessToken;
    private Integer expiresIn;
    private long expiryTime;
    private Date obtainedOn;
    private String tokenType;
    private String password;
    private String applicationId;
    private String url;
    private String grantType;
    private String scope;

    public OauthTokenExtended(String applicationId, String password) {
        this.applicationId = applicationId;
        this.password = password;
    }

    public OauthTokenExtended(String applicationId, String password, String url, String grantType, String scope) {
        this(applicationId, password);
        this.url = url;
        this.grantType = grantType;
        this.scope = scope;
    }

    public OauthTokenExtended(OauthTokenExtended oauthTokenExtended) {
        this(oauthTokenExtended.applicationId, oauthTokenExtended.password);
        this.url = oauthTokenExtended.url;
        this.grantType = oauthTokenExtended.grantType;
        this.scope = oauthTokenExtended.scope;
    }

    public OauthTokenExtended(String token, Integer expiresIn) {
        // Create OauthToken with accessToken and set expiryTime to be current time + expiresIn
        this.accessToken = token;
        this.expiresIn = expiresIn;
        this.expiryTime = Instant.now().plusSeconds(expiresIn.longValue()).toEpochMilli();
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public String getPassword() {
        return password;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public Date getObtainedOn() {
        return (Date) obtainedOn.clone();
    }

    public void setObtainedOn(Date obtainedOn) {
        this.obtainedOn = (obtainedOn != null) ? (Date) obtainedOn.clone() : null;
    }

    public Integer getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(Integer expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getGrantType() {
        return grantType;
    }

    public void setGrantType(String grantType) {
        this.grantType = grantType;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public boolean isTokenGoingToExpire() {
        // We will get a new token 10 minutes before the actual expiry
        var now = new Date();
        if (obtainedOn == null) {
            return true;
        }
        return now.getTime() > (expiresIn * MILLISECOND_CONVERSION_MULTIPLIER + obtainedOn.getTime() - TOKEN_EXPIRY_LATENT_TIME);
    }

    public void setExpiryTime(Long expiryTime) {
        this.expiryTime = expiryTime;
    }

    public Long getExpiryTime() {
        return expiryTime;
    }

    public boolean isEmpty() {
        return (this.accessToken == null || this.accessToken.isEmpty());
    }
    
    @Override
	public String toString() {
		return "OauthTokenExtended [accessToken=" + accessToken + ", expiresIn=" + expiresIn + ", obtainedOn="
				+ obtainedOn + ", tokenType=" + tokenType + ", password=" + password + ", applicationId="
				+ applicationId + ", url=" + url + ", grantType=" + grantType + ", scope=" + scope + "]";
	}
}
