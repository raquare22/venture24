package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;

import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;

import com.optum.fds.paperless.mongo.executions.UnprocessedRecord;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.util.csv.CsvToJsonUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.flowable.engine.delegate.DelegateExecution;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

import java.nio.file.Paths;
import java.util.*;

@Service("CsvToJsonFile")
public class CsvToJsonFile extends OptumJavaDelegateBase{ //implements JavaDelegate
	private static int lf = 10;
	private static int cr = 13;
	private static final String PROCESSED_SUCCESSFULLY = "Processed Successfully";
	private static final Logger LOG = LoggerFactory.getLogger(CsvToJsonFile.class);
	
	@Autowired
	private CsvToJsonUtil csvToJsonUtil;
	
	@Autowired
	private CsvProcessorsService csvProcessorsService;
	
	@Autowired
	private CsvProcessorService csvProcessorService;
	
	@Autowired
	ErrorMetaDataService errorMetaDataService;
	
	private static final List<String> REQ_VARS = Arrays.asList (
			Workflow.APP_IDENTIFIER,
			Workflow.JOB
	);

	public CsvToJsonFile() {
		super(REQ_VARS);
	}

	@Override
	public void doExecute(DelegateExecution execution) {
		LOG.info("Processing CsvToJsonFileTask delegate");

		var processorMetaData = (ProcessorMetaData) execution.getVariable("processorMetaData");
		var processConfigMap = (Map) processorMetaData.getProcess().get("config");
		Boolean companionTRL = (Boolean) processConfigMap.get("companionTRL");
		String dlmt = (String) processConfigMap.get("delimit");
		String templateName = (String) processConfigMap.get(Workflow.TEMPLATE_NAME);
		csvToJsonUtil.setTemplateName(templateName);

		var csvProcessorTransaction = (CsvProcessorTransaction) execution.getVariable(Workflow.CSV_PROCESSOR_TRANSACTION);
		
		// add list of csvProcessorTransactionIds to execution bus for reconciliation error message 
		List<String> csvProcessorTransactionIds = List.of(csvProcessorTransaction.getId());
		 execution.setTransientVariable("csvProcessorTransactionIds", csvProcessorTransactionIds);
				
		String locationDirectory = csvProcessorTransaction.getLocation();
		String csvFileName = csvProcessorTransaction.getFileName();

		LOG.info("locationDirectory={}, csvFileName={}", locationDirectory, csvFileName);

		var delimit = ',';
		if(dlmt!= null && !dlmt.isEmpty()){
			delimit = dlmt.charAt(0);
		}

		var executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Converting csv records to json file", csvProcessorTransaction);
		try {
			List<UnprocessedRecord> unprocessedRecords = new ArrayList<>();
			String jsonFileName = null;
			if (companionTRL != null && companionTRL.booleanValue())
			{
				String removed = removeTrailer(locationDirectory, csvFileName);
				if (removed != null) {
					LOG.info("Trailer removed={}, locationDirectory={}, csvFileName={}", removed, locationDirectory, csvFileName);
				}
			}

			LOG.info("locationDirectory={}, csvFileName={}, delimit={}", locationDirectory, csvFileName, delimit);
			jsonFileName = csvToJsonUtil.convertCsvToJson(locationDirectory, csvFileName, delimit, 0, unprocessedRecords);
			
			if(!unprocessedRecords.isEmpty())
			{
				csvProcessorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
				for (UnprocessedRecord unprocessedRecord : unprocessedRecords) {
					LOG.error("unprocessedRecord={}", unprocessedRecord);
				}
			}

			csvProcessorTransaction.setJsonFileName(jsonFileName);
			csvProcessorsService.updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
			var location = Paths.get(locationDirectory);
			var jsonFileToProcess = new File(location.toFile(), jsonFileName);
			 execution.setTransientVariable("jsonFileName", jsonFileName);

			ProcessorTaskUtil.updateFileMetrics(csvProcessorTransaction, jsonFileToProcess, csvProcessorService);
			ProcessorTaskUtil.updateServerMetrics(csvProcessorTransaction, csvProcessorService);
			ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(csvProcessorService, csvProcessorTransaction, executionRecord);
			ProcessorTaskUtil.updateProcessTransactionWithUnprocessedRecord(csvProcessorService, csvProcessorTransaction, unprocessedRecords);
			csvProcessorsService.updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
			 execution.setTransientVariable(Workflow.CSVTOJSON_SUCCESS_MESSAGE, PROCESSED_SUCCESSFULLY);
		} catch (Exception e) {
			csvProcessorTransaction.setStatus(MetaDataStatus.FATAL_ERROR);
			var executionErrorRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Error while coverting csv records to json file" +  ExceptionUtils.getStackTrace(e), csvProcessorTransaction);
			ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(csvProcessorService, csvProcessorTransaction, executionErrorRecord);
			LOG.error("Exception raised while converting Csv to Json file : {}", ExceptionUtils.getStackTrace(e));
			 execution.setTransientVariable(Workflow.CSVTOJSON_ERROR_MESSAGE, ExceptionUtils.getStackTrace(e));
			
			errorMetaDataService.writeToErrorCollection(execution, "CsvToJsonFile --> doExecute: " + e.getMessage());
		}
	}

	public static String removeTrailer(String locationDirectory, String csvFileName) throws IOException
	{
		// Bottom up seek
		// Remove the last row in a file where new line is composed of <cr><lf> or <lf>
		// Skips new line if found on first seek and last line contains TRL|
		// Return <cr><lf><row> or null if only one row or null if last line not TRL
		var file = new File(locationDirectory, csvFileName);
		var randomAccessFile = new RandomAccessFile(file, "rw");
		LOG.debug("file={}", file);
		byte[] byteArray = null;
		try
		{
			byte b;
			long pos = randomAccessFile.length() - 1;
			var first = true;
			var found = false;
			while (pos > 0)
			{
				randomAccessFile.seek(pos);
				b = randomAccessFile.readByte();
				LOG.debug("pos={}, b={}", pos, b);
				if (b == lf && !first)
				{
					LOG.debug("Found LF: pos={}, b=lf; b={}, lf={}", pos, b, lf);
					found = true;
					if (pos >= 1)
					{
						pos -= 1;
						randomAccessFile.seek(pos);
						b = randomAccessFile.readByte();
						LOG.debug("Next: pos={}, b={}, cr={}", pos, b, cr);
						if (b != cr)
						{
							pos++;
							LOG.debug("Not Found CR: pos={}, b={}, cr={}", pos, b, cr);
						}
					}
					LOG.debug("Break: pos={}, b={}", pos, b);
					break;
				}
				first = false;
				pos -= 1;
			}
			if (pos >= 0 && found)
			{
				LOG.debug("randomAccessFile.length()={}, pos={}, randomAccessFile.length()-pos={}",
					randomAccessFile.length(), pos, randomAccessFile.length()-pos);
				byteArray = new byte[Math.toIntExact(randomAccessFile.length()-pos)];
				randomAccessFile.seek(pos);
				randomAccessFile.readFully(byteArray);
				String lastLine = new String(byteArray);
				if (lastLine.contains("TRL|")) {
					LOG.warn("Have TRL: lastLine={}, file={}, randomAccessFile.length()={}, pos={}, randomAccessFile.length()-pos={}",
						lastLine, file, randomAccessFile.length(), pos, randomAccessFile.length()-pos);
				} else {
					LOG.info("NOT TRL: lastLine={}, file={}", lastLine, file);
					return null;
				}
				randomAccessFile.setLength(pos);
			}
		}
		finally
		{
			randomAccessFile.close();
		}
		return byteArray == null ? null : new String(byteArray);
	}
}
