package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorTransactionService;
import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.eclipse.collections.impl.list.mutable.ListAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

@Service("UpdateProcessorTransactionMetadata")
public class UpdateProcessorTransactionMetadata extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateProcessorTransactionMetadata.class);

    @Autowired
    ProcessorTransactionService processorTransactionService;

    @Autowired
    EmailService emailService;


    private static final List<String> REQ_VARS = List.of(
            Workflow.JSON_FILE,
            Workflow.OUTPUT_FILE_DIR,
            Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH,
            Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE
    );

    public UpdateProcessorTransactionMetadata() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("UpdateProcessorTransactionMetadata-->doExecute-->ENTER");
        try {
            String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
            List<ProcessorTransactionMetadata> processorTransactionList = getProcessorTransactionMetadata(jsonFile, execution);

            String processorTransactionMetadataFlagPath = execution.getVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_PATH, String.class);
            String processorTransactionMetadataFlagValue = execution.getVariable(Workflow.PROCESSOR_TRANSACTION_METADATA_FLAG_VALUE, String.class);

            ListAdapter.adapt(processorTransactionList)
                    .tap(x -> x.getClient().put(processorTransactionMetadataFlagPath, processorTransactionMetadataFlagValue))
                    .forEach(processorTransactionService::updateProcessorTransactionMetaData);

        } catch (Exception e) {
            LOGGER.error("UpdateProcessorTransactionMetadata-->doExecute-->Exception while executing UpdateProcessorTransactionMetadata task", e);
            addErrorMsg("UpdateProcessorTransactionMetadata-->doExecute-->Exception while executing UpdateProcessorTransactionMetadata task", WorkFlowUtil.getStackTrace(e));
        } finally {
        	var jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
			if(!StringUtils.isEmpty(jsonFile)) {
				Utilities.deleteWorkingDirectory(jsonFile);
			}
            if (newErrors() && errorMap.size() > 1) {
                DelegateUtils.sendErrorNotification(execution, errorMap, DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution), emailService);
            }
        }
        LOGGER.debug("UpdateProcessorTransactionMetadata-->doExecute-->EXIT");
    }

    private List<ProcessorTransactionMetadata> getProcessorTransactionMetadata(String jsonFile, DelegateExecution execution) {
        List<ProcessorTransactionMetadata> processorTransactionList;
        try {
            processorTransactionList = WorkFlowUtil.readProcessorTransactionMetadataFromJsonFile(jsonFile);
        } catch (IOException e) {
            LOGGER.error("UpdateProcessorTransactionMetadata-->doExecute-->Unable to read documents from JSON File", e);
            addErrorMsg("UpdateProcessorTransactionMetadata-->doExecute-->Unable to read documents from JSON File", WorkFlowUtil.getStackTrace(e));
            return List.of();
        }
        return processorTransactionList;
    }

}