package com.optum.fds.paperless.java.delegate.common;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.StringUtils;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import org.flowable.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class DelegateUtils {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DelegateUtils.class);
	protected Map<String, Object> errorMap;
	
	/**
	 * Method to add document Id in error map
	 * @param execution
	 */
	public static String addDocumentIdInErrors(DelegateExecution execution) {
		var result ="";
		if (execution.getVariable(Workflow.DOCUMENT, DocumentMetaData.class) != null) {
			result =  "Error while processing for Document Id:" + execution.getVariable(Workflow.DOCUMENT, DocumentMetaData.class).getId() ;
		}
		return result ;
	}

	/**
	 * Method to add hook Id in error map
	 * @param execution
	 */
	public static String generateMessageforCronExpressionHookWorkflow(DelegateExecution execution) {
		var result ="";
		if (execution.getVariable(Workflow.DOCUMENT, DocumentMetaData.class) != null && execution.getVariable(Workflow.HOOK_EXECUTION_ID, String.class) != null) {
			result =  "Error while executing hook with Id " + execution.getVariable(Workflow.DOCUMENT, DocumentMetaData.class).getId() + " at " + new Date() 
					+ ". \n" + "Hook Execution Id for the execution is " + execution.getVariable(Workflow.HOOK_EXECUTION_ID, String.class) 
					+ ". \n" + "Please check hook transaction in cronExpressionHook collection in Mongo DB for more details.";
		}
		return result ;
	}
	
	/**
	 * Method to add error map in hook transaction
	 *
	 */
	public static Map<String, String> generateErrorMessageforCronExpressionHookWorkflow(Map<String, Object> errorMap) {
		var result = "";
		Map<String, String> errorResult= new HashMap<>();
		if (errorMap != null && !errorMap.isEmpty()) {
			for (Map.Entry<String, Object> errMsg : errorMap.entrySet()) {
				result = errMsg.getKey().concat(": ").concat(errMsg.getValue().toString());
			}
		}
		errorResult.put(Workflow.ERROR_MESSAGE, result);
		return errorResult;
	}
	
	/**
	 * Method to send notifications to the support on workflow failures.
	 * * @param execution
	 * @param errorMap 
	 * @param emailService 
	 */
	
	public static void sendErrorNotification(DelegateExecution execution, Map<String, Object> errorMap, String message, EmailService emailService) {
		String emailReceiver = execution.getVariable(Workflow.EMAIL_RECEIVER, String.class);
		String environment = execution.getVariable(Workflow.ENVIRONMENT, String.class);
		if(!StringUtils.isNullOrEmpty(emailReceiver) && !StringUtils.isNullOrEmpty(environment)) {
			emailService.sendEmail(execution, errorMap, message);
		}
		
	}
	
	public static void updateProcessorTransactionList(DelegateExecution execution, ProcessorService processorService) {
		LOGGER.debug("Entering UpdateProcessorTransactionList doExecute");
		try {
			String processorTransactionUpdateList = execution.getVariable(Workflow.PROCESSOR_TRANSACTION_UPDATE, String.class);
			var gson = new Gson();
			List<JsonObject> metadataObjlist ;
			var type = new TypeToken<List<JsonObject>>() {}.getType();
			metadataObjlist = gson.fromJson(processorTransactionUpdateList, type);
			Map<String, Object> map = new HashMap<>();
			for (JsonObject jsonObject : metadataObjlist) {
				map = gson.fromJson(jsonObject.toString(), map.getClass());
				String id = (String)map.get(Workflow.MONGO_ID);
				String ackStatus = (String)map.get(Workflow.ACK_STATUS);
				processorService.setAckStatus(id, ackStatus);
			}
		} catch (Exception e) {
			LOGGER.error("Update Processor Transaction error", e);
        } 
		LOGGER.debug("Exiting UpdateProcessorTransactionList doExecute");
	}
}