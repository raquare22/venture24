package com.optum.fds.paperless.java.delegate;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.optum.fds.paperless.mongo.processors.*;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

@Service("CreateACKFile")
public class CreateACKFile extends OptumJavaDelegateBase {

	private static final Logger log = LoggerFactory.getLogger(CreateACKFile.class);
	
	private static final String FILE_NAME = "FileName";
	private static final String ERROR_CODE = "ErrorCode";
	private static final String ERROR = "Error";
	private static final String DELEGATE_EXECUTION_ID = "delegateExecutionId";
	private static final String DESCRIPTION = "Description";
	private static final String PROCESSOR_TRANSACTION_ID = "processorTransactionId";
	private static final String NGSID = "NGSID";
	
	@Autowired
	ProcessorsService processorsService;
	
	@Autowired
	ProcessorService processorService;
	
	private DelegateExecution tempExecution = null;
	
	private static final List<String> REQ_VARS = Arrays.asList(
			Workflow.PROCESSOR_TRANSACTION, Workflow.ACK_FLAG, Workflow.GENERATE_SINGLE_ACK_SUMMARY_FILE_FLAG
	);
	
	public CreateACKFile() {
		super(REQ_VARS);
	}
	
	@Override
	public void doExecute(DelegateExecution execution) {
		log.info("CreateACKFile-->doExecute-->ENTER");
		tempExecution = execution;
		
		ProcessorTransaction processorTransaction = null;
		ProcessorExecutionRecord executionRecord = null;
		Map<String, String> message = new HashMap<>();
		try {
			executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Initializing CreateACKFile task");
			message = new HashMap<>();
			processorTransaction = execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class);
			List<ProcessorFileTask> processorFileTaskList = processAllFileTasksForTransaction(processorTransaction);
			Boolean ackFlag = execution.getVariable(Workflow.ACK_FLAG, Boolean.class);
			Boolean generateSingleAckSummaryFile = execution.getVariable(Workflow.GENERATE_SINGLE_ACK_SUMMARY_FILE_FLAG, Boolean.class);
			message.put(Workflow.OUTCOME_KEY, "CreateACKFile task initialized successfully");
			ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
			if(Boolean.TRUE.equals(ackFlag)) {
				if(Boolean.TRUE.equals(generateSingleAckSummaryFile)) {
					if(!createSingleAckSummaryFile(execution, processorTransaction, processorFileTaskList)) {
						return;
					}
				}
				else {
					if(!createAckZipFile(execution, processorTransaction, processorFileTaskList)) {
						return;
					}
				}
			} else {
				log.warn("CreateACKFile-->doExecute-->ackWorkingDir is not defined, Suppressing creation ACK file; processorTransactionId={}", processorTransaction.getId());
			}
		} catch(Exception e) {
			log.error("doExecute Exception while executing CreateACKFile task {}={}, {}={} {}",
        			DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution), PROCESSOR_TRANSACTION_ID, getProcessorTransactionId(processorTransaction),
        			ExceptionUtils.getStackTrace(e));
			addErrorMsg("CreateACKFile-->doExecute-->Exception while executing CreateACKFile task", WorkFlowUtil.getStackTrace(e));
			message.put(Workflow.OUTCOME_KEY, "There was Exception while executing CreateACKFile task");
			message.put(Workflow.ERROR_KEY, WorkFlowUtil.getStackTrace(e));
			if (processorTransaction != null)
			{
			  //	String msg = ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1807.getErrorMessage() + " " + e.getClass().getSimpleName() + ": " + e.getMessage() + "; CreateACKFile";
			 //	processorTransaction.getSummary().addError(new ProcessorError(msg, ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1808.getErrorCode()));
			}
			ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
			return;
		} finally {
			if(processorTransaction != null) {
				 execution.setTransientVariable(Workflow.PROCESSOR_TRANSACTION, processorTransaction);
				processorService.updateProcessorTransactionMetaData(processorTransaction);
			}
		}
		log.info("CreateACKFile-->doExecute-->EXIT");
	}

	private boolean createSingleAckSummaryFile(DelegateExecution execution, ProcessorTransaction processorTransaction,
			List<ProcessorFileTask> processorFileTaskList) {
		ProcessorExecutionRecord executionRecord = null;
		Map<String, String> message = new HashMap<>();
		try {
				String ackFileName = Utilities.stripFileExtension(processorTransaction.getFileName()) + Workflow.ACK_SUMMARY_FILE_EXTENSION;
				String location = processorTransaction.getLocation();
								
				executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Generating summary ACK XL for processorTransaction");
				message = new HashMap<>();
				byte[] summaryJSon = null;
				try {
					summaryJSon = generateSummaryFileForTransactionInReady(processorTransaction, processorFileTaskList);
					message.put(Workflow.OUTCOME_KEY, "Summary ACK file generated");
				} catch (IOException e) {
					log.error("createSingleAckSummaryFile IOException while Generating summary ACK XL for processorTransaction {}={}, {}={} {}",
							DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution), PROCESSOR_TRANSACTION_ID, getProcessorTransactionId(processorTransaction),
							ExceptionUtils.getStackTrace(e));
					addErrorMsg("CreateACKFile-->createSingleAckSummaryFile-->IOException while Generating summary ACK XL for processorTransaction", WorkFlowUtil.getStackTrace(e));
					message.put(Workflow.OUTCOME_KEY, "There was an error generating summary ack file");
					message.put(Workflow.ERROR_KEY, e.toString());
					//String msg = ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1809.getErrorMessage() + " " + e.getClass().getSimpleName() + ": " + e.getMessage() + "; createSingleAckSummaryFile";
					//processorTransaction.getSummary().addError(new ProcessorError(msg, ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1810.getErrorCode()));
					return false;
				}
		        finally {
		            ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
		        }
				
				executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Writing ACK Summary file to local folder");
				message = new HashMap<>();
				ackFileName = location + File.separator + ackFileName;
				try (OutputStream fs = new BufferedOutputStream(Files.newOutputStream(Paths.get(ackFileName))) ){
		            fs.write(summaryJSon);
		            message.put(Workflow.OUTCOME_KEY, "ACK Summary file written to local folder");
		        }
		        catch (IOException e) {
		        	log.error("createSingleAckSummaryFile IOException while Writing ACK Summary file to local folder {}={}, {}={} {}",
		        			DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution), PROCESSOR_TRANSACTION_ID, getProcessorTransactionId(processorTransaction),
		        			ExceptionUtils.getStackTrace(e));
		        	addErrorMsg("CreateACKFile-->createSingleAckSummaryFile-->IOException while Writing ACK Summary file to local folder", WorkFlowUtil.getStackTrace(e));
		            message.put(Workflow.OUTCOME_KEY, "There was an error creating ACK Summary file.");
		            message.put(Workflow.ERROR_KEY, e.toString());
		            //  String msg = ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1811.getErrorMessage() + " " + e.getClass().getSimpleName() + ": " + e.getMessage() + "; createSingleAckSummaryFile-1";
		            //  processorTransaction.getSummary().addError(new ProcessorError(msg, ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1812.getErrorCode()));
		            return false;
		        }
		        finally {
		            ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
		        }
				 execution.setTransientVariable(Workflow.ACK_FILE, ackFileName);
		} catch(Exception e) {
			log.error("createSingleAckSummaryFile Exception while creating ACK Summary file {}={}, {}={} {}",
					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution), PROCESSOR_TRANSACTION_ID, getProcessorTransactionId(processorTransaction),
					ExceptionUtils.getStackTrace(e));
			addErrorMsg("CreateACKFile-->createSingleAckSummaryFile-->Exception while creating ACK Summary file", WorkFlowUtil.getStackTrace(e));
			message.put(Workflow.OUTCOME_KEY, "There was Exception while creating ACK Summary file");
			message.put(Workflow.ERROR_KEY, WorkFlowUtil.getStackTrace(e));
			if (processorTransaction != null)
			{
			//	String msg = ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1813.getErrorMessage() + " " + e.getClass().getSimpleName() + ": " + e.getMessage() + "; createSingleAckSummaryFile-2";
			//	processorTransaction.getSummary().addError(new ProcessorError(msg, ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1814.getErrorCode()));
			}
			ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
			return false;
		}
		return true;
	}

	private boolean createAckZipFile(DelegateExecution execution, ProcessorTransaction processorTransaction,
			List<ProcessorFileTask> processorFileTaskList) {
		ProcessorExecutionRecord executionRecord = null;
		Map<String, String> message = new HashMap<>();
		try {
				String zipFileName = Utilities.stripFileExtension(processorTransaction.getFileName()) + Workflow.ACK_ZIP_FILE_EXTENSION;
				String location = processorTransaction.getLocation();
				
				executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Openning Zip Stream for ACK files");
				message = new HashMap<>();
				var baos = new ByteArrayOutputStream();
				var zipOuts = new ZipOutputStream(baos);
				message.put(Workflow.OUTCOME_KEY, "Zip Stream for ACK files openned");
				ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
				
				executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Summarizing processorFileTask records and Generating an ACK file for each FileTask");
				message = new HashMap<>();
			try {
				if (!MetaDataStatus.FATAL_ERROR.equals(processorTransaction.getStatus())) {
					if (!CollectionUtils.isEmpty(processorFileTaskList)) {
						Boolean ackWithErrorsOnly = execution.getVariable(Workflow.ACK_WITH_ERRORS_ONLY, Boolean.class);

						if (BooleanUtils.isTrue(ackWithErrorsOnly)) {
							addProcessorFileTasksErrorToACK(processorTransaction, zipOuts, processorFileTaskList);
						} else {
							addProcessorFileTasksToACK(processorTransaction, zipOuts, processorFileTaskList);
						}
					}
					message.put(Workflow.OUTCOME_KEY, "FileTask Summarized and ACK files generated");
					ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction,
							executionRecord, message);
				}
			} catch (IOException e) {
				log.error("createAckZipFile IOException while Summarizing processorFileTask records and Generating an ACK file for each FileTask {}={}, {}={} {}",
						DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution), PROCESSOR_TRANSACTION_ID, getProcessorTransactionId(processorTransaction),
						ExceptionUtils.getStackTrace(e));
				addErrorMsg(
						"CreateACKFile-->CreateACKZipFile-->IOException while Summarizing processorFileTask records and Generating an ACK file for each FileTask",
						WorkFlowUtil.getStackTrace(e));
				message.put(Workflow.OUTCOME_KEY, "There was an error generating fileTask ack files");
				message.put(Workflow.ERROR_KEY, e.toString());
				//String msg = ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1815.getErrorMessage() + " " + e.getClass().getSimpleName() + ": " + e.getMessage() + "; createAckZipFile";
				//processorTransaction.getSummary().addError(new ProcessorError(msg, ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1816.getErrorCode()));
				ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction,
						executionRecord, message);
				closeZipStream(zipOuts, processorTransaction);
				return false;
			}
				
				executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Generating summary ACK XL for processorTransaction and add it to the zip stream");
				message = new HashMap<>();
				try {
					byte[] summaryJSon = generateSummaryFileForTransactionInReady(processorTransaction, processorFileTaskList);
					addACKToZip(zipOuts, "summary", summaryJSon);
					message.put(Workflow.OUTCOME_KEY, "Summary ACK file generated and added to zip stream");
					ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
 					if(closeZipStream(zipOuts, processorTransaction)) {
						return false;
					}
				} catch (IOException e) {
					log.error("createAckZipFile IOException while Generating summary ACK XL for processorTransaction and add it to the zip stream {}={}, {}={} {}",
							DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution), PROCESSOR_TRANSACTION_ID, getProcessorTransactionId(processorTransaction),
							ExceptionUtils.getStackTrace(e));
					addErrorMsg("CreateACKFile-->CreateACKZipFile-->IOException while Generating summary ACK XL for processorTransaction and add it to the zip stream", WorkFlowUtil.getStackTrace(e));
					message.put(Workflow.OUTCOME_KEY, "There was an error generating summary ack file");
					message.put(Workflow.ERROR_KEY, e.toString());
					//String msg = ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1817.getErrorMessage() + " " + e.getClass().getSimpleName() + ": " + e.getMessage() + "; createAckZipFile-1";
					//processorTransaction.getSummary().addError(new ProcessorError(msg, ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1818.getErrorCode()));
					ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
					closeZipStream(zipOuts, processorTransaction);
					return false;
				}
				
				executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Writing zip file to local folder");
				message = new HashMap<>();
				byte[] acks = baos.toByteArray();
				zipFileName = location + File.separator + zipFileName;
				var zipFile = new File(zipFileName);
				if (!zipFile.exists()) {
					zipFile.getParentFile().mkdirs();
					zipFile.createNewFile();
					log.info("ack file created for absolute path: {} ", zipFile.getAbsolutePath());
				}
				
				try (OutputStream fs = new BufferedOutputStream(Files.newOutputStream(zipFile.toPath())) ){
		            fs.write(acks);
		            message.put(Workflow.OUTCOME_KEY, "Zip file written to local folder");
		        }
		        catch (IOException e) {
		        	log.error("createAckZipFile IOException while Writing zip file to local folder {}={}, {}={} {}",
		        			DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution), PROCESSOR_TRANSACTION_ID, getProcessorTransactionId(processorTransaction),
		        			ExceptionUtils.getStackTrace(e));
		        	addErrorMsg("CreateACKFile-->CreateACKZipFile-->IOException while Writing zip file to local folder", WorkFlowUtil.getStackTrace(e));
		            message.put(Workflow.OUTCOME_KEY, "There was an error creating Ack zip file.");
		            message.put(Workflow.ERROR_KEY, e.toString());
		            // String msg = ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1819.getErrorMessage() + " " + e.getClass().getSimpleName() + ": " + e.getMessage() + "; createAckZipFile-2";
		           // processorTransaction.getSummary().addError(new ProcessorError(msg, ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1820.getErrorCode()));
		            return false;
		        }
		        finally {
		            ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
		            baos.close();
		        }
				 execution.setTransientVariable(Workflow.ACK_FILE, zipFile.getAbsolutePath());
		} catch(Exception e) {
			log.error("createAckZipFile Exception while creating ACK zip file {}={}, {}={} {}",
					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution), PROCESSOR_TRANSACTION_ID, getProcessorTransactionId(processorTransaction),
					ExceptionUtils.getStackTrace(e));
			addErrorMsg("CreateACKFile-->CreateACKZipFile-->Exception while creating ACK zip file", WorkFlowUtil.getStackTrace(e));
			message.put(Workflow.OUTCOME_KEY, "There was Exception while creating ACK zip file");
			message.put(Workflow.ERROR_KEY, e.toString());
			if (processorTransaction != null) {
				//String msg = ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1821.getErrorMessage() + " " + e.getClass().getSimpleName() + ": " + e.getMessage() + "; createAckZipFile-3";
				//processorTransaction.getSummary().addError(new ProcessorError(msg, ProcessorErrorCode.UNKNOWN_ERROR_POSTING_TO_FDS_1822.getErrorCode()));
			}
			ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
			return false;
		}
		return true;
	}

	private void resetProcessingMetrics (ProcessorTransaction processorTransaction) {
		processorTransaction.getSummary().getProcessingMetrics().setFileCount(0);
		processorTransaction.getSummary().getProcessingMetrics().setAverageRunTime(0L);
		processorTransaction.getSummary().getProcessingMetrics().setAverageFileSize(0L);

		processorTransaction.getSummary().getProcessingMetrics().setBytesProcessed(0L);
		processorTransaction.getSummary().getProcessingMetrics().setTotalRunTime(0L);
		
	}
	
	private List<ProcessorFileTask> processAllFileTasksForTransaction(ProcessorTransaction processorTransaction) {
		log.info("CreateACKFile-->processAllFileTasksForTransaction-->ENTER");
		List<ProcessorFileTask> processorFileTasks = processorsService.getProcessorFileTasksForTransactionId(processorTransaction.getId());
		if (processorFileTasks != null && !processorFileTasks.isEmpty()) {
			// reset the file count to 0 here.
			resetProcessingMetrics(processorTransaction);
			for (ProcessorFileTask processorFileTask : processorFileTasks) {
				summarizeFileTask(processorTransaction, processorFileTask);
			}
			// set Average Runtime
			var processingMetrics = processorTransaction.getSummary().getProcessingMetrics();
			if (processingMetrics.getFileCount() > 0) {
				processingMetrics.setAverageRunTime(
					processorTransaction.getSummary().getRunTime() / processingMetrics.getFileCount()
				);
				// Set Average File Size
				processingMetrics.setAverageFileSize(
					processingMetrics.getBytesProcessed() / processingMetrics.getFileCount()
				);
			} else {
				processingMetrics.setAverageRunTime(0L);
				processingMetrics.setAverageFileSize(0L);
			}
		}
		log.info("CreateACKFile-->processAllFileTasksForTransaction-->EXIT");
		return processorFileTasks;
	}

	private void summarizeFileTask(ProcessorTransaction processorTransaction, ProcessorFileTask processorFileTask){
		log.info("CreateACKFile-->summarizeFileTask-->ENTER");
		if (MetaDataStatus.FATAL_ERROR.equals(processorFileTask.getStatus()) || MetaDataStatus.SEVERE_ERROR.equals(processorFileTask.getStatus()) ){
			summarizeFileTaskError(processorTransaction, processorFileTask);
		}
		else {
			summarizeProcessingMetricsForFileTask(processorTransaction, processorFileTask);
			summarizeFileTaskError(processorTransaction, processorFileTask, false);
		}
		log.info("CreateACKFile-->summarizeFileTask-->EXIT");
	}
	
	private void summarizeFileTaskError(ProcessorTransaction processorTransaction, ProcessorFileTask processorFileTask) {
		summarizeFileTaskError(processorTransaction,  processorFileTask, true);
	}

	private void summarizeFileTaskError(ProcessorTransaction processorTransaction, ProcessorFileTask processorFileTask, boolean callSummarizeProcessingMetricsForFileTask) {
		log.info("CreateACKFile-->summarizeFileTaskError-->ENTER");
		if (processorFileTask.getSummary()!= null && processorFileTask.getSummary().getErrorList() != null) {
			processorFileTask.getSummary().getErrorList().forEach(error -> {
				if (! MetaDataStatus.SEVERE_ERROR.equals(processorFileTask.getStatus()) && error.getErrorCode() == 18 && ! StringUtils.isEmpty(processorFileTask.getTargetId()))
				{
					// US28568: Don't count errCode18 if posted to docVault and then error e.g. mysql deadlock/conflict
					log.warn("summarizeFileTask Skipping {}; {}={}, {}={}", error.getErrorMessage(),
							PROCESSOR_TRANSACTION_ID, getProcessorTransactionId(processorTransaction), "processorFileTaskId", processorFileTask.getId());
					if (callSummarizeProcessingMetricsForFileTask)
					{
						summarizeProcessingMetricsForFileTask(processorTransaction, processorFileTask);
					}
					return;
				}
				error.setFileName(processorFileTask.getFileName());
				processorTransaction.getSummary().addError(error);
				processorTransaction.getSummary().getProcessingMetrics().incrementErrorCodeCount(error.getErrorCode());
			});
		}
		log.info("CreateACKFile-->summarizeFileTaskError-->EXIT");
	}

	private void summarizeProcessingMetricsForFileTask(ProcessorTransaction processorTransaction, ProcessorFileTask processorFileTask) {
		log.info("CreateACKFile-->summarizeProcessingMetricsForFileTask-->ENTER");
		var processingMetrics = processorTransaction.getSummary().getProcessingMetrics();
		processingMetrics.setTotalRunTime(processingMetrics.getTotalRunTime() + Optional.ofNullable(processorFileTask.getSummary()).map(ProcessorSummaryCore::getRunTime).orElse(0L));
		processingMetrics.setBytesProcessed(
			processingMetrics.getBytesProcessed() + processorFileTask.getFileSize()
		);
		processingMetrics.setFileCount(processingMetrics.getFileCount() + 1);
		log.info("CreateACKFile-->summarizeProcessingMetricsForFileTask-->EXIT");
	}

	/**
	 * @param processorTransaction
	 * @param zipOuts
	 * @param processorFileTaskList
	 * @throws IOException
	 */
	private void addProcessorFileTasksToACK(ProcessorTransaction processorTransaction, ZipOutputStream zipOuts,
			List<ProcessorFileTask> processorFileTaskList) throws IOException {
		for(ProcessorFileTask processorFileTask : processorFileTaskList){
			log.info("CreateACKFile --> addProcessorFileTasksToACK processorFileTask id={}, status={}", processorFileTask.getId(), processorFileTask.getStatus());
			byte[] fileTaskXMLBytes = generateFileTaskACK(processorTransaction, processorFileTask);
			addACKToZip(zipOuts, processorFileTask.getFileName(), fileTaskXMLBytes);				
		}
	}
	
	private void addProcessorFileTasksErrorToACK(ProcessorTransaction processorTransaction, ZipOutputStream zipOuts,
			List<ProcessorFileTask> processorFileTaskList) throws IOException {
		for(ProcessorFileTask processorFileTask : processorFileTaskList){
			log.info("CreateACKFile --> addProcessorFileTasksErrorToACK processorFileTask id={}, status={}", processorFileTask.getId(), processorFileTask.getStatus());
			if(processorFileTask.getSummary()!= null && processorFileTask.getSummary().getErrorList() != null && processorFileTask.getStatus() != MetaDataStatus.COMPLETE){
				byte[] fileTaskXMLBytes = generateFileTaskAckErrorsWithFileName(processorTransaction, processorFileTask);
				addACKToZip(zipOuts, processorFileTask.getFileName(), fileTaskXMLBytes);				
			}
			
		}
	}
	
	@SuppressWarnings("rawtypes")
	private byte[] generateFileTaskAckErrorsWithFileName(ProcessorTransaction processorTransaction, ProcessorFileTask processorFileTask) throws IOException {
		log.info("CreateACKFile-->generateFileTaskACK-->ENTER");
		ArrayList<HashMap> errors = new ArrayList<>();
		if (processorFileTask.getSummary()!= null && processorFileTask.getSummary().getErrorList() != null) {
			processorFileTask.getSummary().getErrorList().forEach(processorError -> {
				if (! MetaDataStatus.SEVERE_ERROR.equals(processorFileTask.getStatus()) && processorError.getErrorCode() == 18 && ! StringUtils.isEmpty(processorFileTask.getTargetId()))
				{
					// US30615: Don't count errCode18 if posted to docVault and then error e.g. mysql deadlock/conflict - extending this logic to individual ack files for MR Appeals
					log.warn("individualFileTask Skipping {}; {}={}, {}={}", processorError.getErrorMessage(),
							PROCESSOR_TRANSACTION_ID, getProcessorTransactionId(processorTransaction), "processorFileTaskId", processorFileTask.getId());
					return;
				}
				HashMap<String, HashMap<String, String>> oneError = new HashMap<>();
				errors.add(oneError);
				HashMap<String, String> error = new HashMap<>();
				oneError.put(ERROR, error);
				error.put(FILE_NAME, processorError.getFileName());
				error.put(ERROR_CODE, processorError.getErrorCode().toString());
				error.put(DESCRIPTION, processorError.getErrorMessage());
			});
		}
		byte[] fileTaskJSonBytes = generateAckFileDetails(processorTransaction, processorFileTask, errors);
		log.info("CreateACKFile-->generateFileTaskACK-->EXIT");
		return fileTaskJSonBytes;
	}
	
	private byte[] generateAckFileDetails(ProcessorTransaction processorTransaction, ProcessorFileTask processorFileTask, ArrayList<HashMap> errors ) throws IOException {
		HashMap<String, Object> jMap = new HashMap<>();
		jMap.put("Errors", errors);
		jMap.put(FILE_NAME, processorFileTask.getFileName());
		
		// adding NGS ID to MR Appeals individual ack files
		if(processorFileTask.getMetadata() != null && processorFileTask.getMetadata().get(Workflow.NGSID) != null) {
			jMap.put(NGSID, processorFileTask.getMetadata().get(Workflow.NGSID).toString());
	    }
		
		if(processorFileTask.getMetadata() != null && processorFileTask.getMetadata().get(Workflow.EMAIL_ALERT_REQUEST) != null) {
				jMap.put("IsPrintSuppressed", processorFileTask.getMetadata().get(Workflow.EMAIL_ALERT_REQUEST).toString());
		}	else { 
				jMap.put("IsPrintSuppressed", StringUtils.EMPTY);
		}
		jMap.put("DocumentId", processorFileTask.getTargetId());
		if (processorFileTask.getDateProcessed() != null) {
			jMap.put("DateProcessed", processorFileTask.getDateProcessed());
		} else {
			jMap.put("DateProcessed", processorTransaction.getSummary().getStartTime());
		}

		String fileTaskJSon = Parser.toJson(jMap, "E MMM dd HH:mm:ss z yyyy", TimeZone.getTimeZone("UTC"));
		return fileTaskJSon.getBytes();
		//return fileTaskJSonBytes;
	}
	

	@SuppressWarnings("rawtypes")
	private byte[] generateFileTaskACK(ProcessorTransaction processorTransaction, ProcessorFileTask processorFileTask) throws IOException {
		log.info("CreateACKFile-->generateFileTaskACK-->ENTER");
		ArrayList<HashMap> errors = new ArrayList<>();
		if (processorFileTask.getSummary()!= null && processorFileTask.getSummary().getErrorList() != null) {
			processorFileTask.getSummary().getErrorList().forEach(processorError -> {
				HashMap<String, HashMap<String, String>> oneError = new HashMap<>();
				errors.add(oneError);
				HashMap<String, String> error = new HashMap<>();
				oneError.put(ERROR, error);
				error.put(ERROR_CODE, processorError.getErrorCode().toString());
				error.put(DESCRIPTION, processorError.getErrorMessage());
			});
		}
		byte[] fileTaskJSonBytes = generateAckFileDetails(processorTransaction, processorFileTask, errors);
		log.info("CreateACKFile-->generateFileTaskACK-->EXIT");
		return fileTaskJSonBytes;
	}

	private void addACKToZip(ZipOutputStream zos, String fileName, byte[] fileTaskJSonBytes) throws IOException {
		log.info("CreateACKFile-->addACKToZip-->ENTER");
		try {
			String newFileName = Utilities.stripFileExtension(fileName) + ".ack";
			var entry = new ZipEntry(newFileName);
			entry.setSize(fileTaskJSonBytes.length);
			zos.putNextEntry(entry);
			zos.write(fileTaskJSonBytes);
			zos.closeEntry();
		} catch (IOException e) {
			log.error("addACKToZip Exception while adding ack file to zip {}={} {}",
        			"fileName", fileName ,
	                ExceptionUtils.getStackTrace(e));
		}
		log.info("CreateACKFile-->addACKToZip-->EXIT");
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private final boolean closeZipStream(ZipOutputStream zipOuts, ProcessorTransaction processorTransaction) {
		var error = false;
		var executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Closing zip stream");
		Map zipMessage = new HashMap<>();
		try {
			zipOuts.close();
			log.info("CreateACKFile-->closeZipStream-->Zip stream closed successfully");
			zipMessage.put(Workflow.OUTCOME_KEY, "Zip stream closed successfully");
		} catch (IOException e) {
			log.error("closeZipStream There was an error closing zip stream {}={} {}",
        			PROCESSOR_TRANSACTION_ID, getProcessorTransactionId(processorTransaction),
	                ExceptionUtils.getStackTrace(e));
			addErrorMsg("CreateACKFile-->closeZipStream-->There was an error closing zip stream", WorkFlowUtil.getStackTrace(e));
			error = true;
			zipMessage.put(Workflow.OUTCOME_KEY, "There was an error closing zip stream");
			zipMessage.put(Workflow.ERROR_KEY, e.toString());
		} finally {
			ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, zipMessage);
		}
		return error;
	}

	@SuppressWarnings("rawtypes")
	private byte[] generateSummaryFileForTransactionInReady(ProcessorTransaction processorTransaction,
			List<ProcessorFileTask> processorFileTaskList) throws IOException {
		log.info("CreateACKFile-->generateSummaryFileForTransactionInReady-->ENTER");
		Map<String, Object> jMap = new HashMap<>();
		Map<String, Object> sumMap = new HashMap<>();
		ArrayList<Map> errors = new ArrayList<>();
		ArrayList<Map> files = new ArrayList<>();
		ArrayList<Map> filesWithoutError12 = new ArrayList<>();
		
		if (processorTransaction.getSummary().getErrorList() != null) {
			processorTransaction.getSummary().getErrorList().forEach(processorError -> {
				Map<String, Map<String, String>> oneError = new HashMap<>();
				errors.add(oneError);
				HashMap<String, String> error = new HashMap<>();
				oneError.put(ERROR, error);
				error.put(FILE_NAME, processorError.getFileName());
				error.put(ERROR_CODE, processorError.getErrorCode().toString());
				
				if (!CollectionUtils.isEmpty(processorFileTaskList)) {
					for (ProcessorFileTask processorFileTask : processorFileTaskList) {
						if (processorFileTask.getMetadata() != null
								&& processorFileTask.getMetadata().get(Workflow.NGSID) != null && processorError.getFileName() != null && processorFileTask.getFileName().contains(processorError.getFileName()) ) {
							error.put(NGSID, processorFileTask.getMetadata().get(Workflow.NGSID).toString());
						}
					}
				}
				 
				error.put(DESCRIPTION, processorError.getErrorMessage());
			});
		}
		

		List<ProcessorError> processorErrors = processorTransaction.getSummary().getErrorList();
		if (processorErrors != null && processorTransaction.getFileToProcessList() != null) {
			processorTransaction.getFileToProcessList().forEach(fileName -> {
				var processorError = findFileNameInErrorList(processorErrors, fileName);
				if (processorError != null) {
					HashMap<String, HashMap<String, String>> error = new HashMap<>();
					files.add(error);
					HashMap<String, String> oneError = new HashMap<>();
					error.put("File", oneError);
					oneError.put(FILE_NAME, processorError.getFileName());
					
					if (processorError.getErrorCode() != 12) {
						filesWithoutError12.add(error);
					}
				}
			});
		}

		ArrayList<Map> uniqueErrors = new ArrayList<>(new HashSet<>(errors));

		ArrayList<Map> uniqueErrorFiles = new ArrayList<>(new HashSet<>(files));
		
		ArrayList<Map> uniqueErrorFilesWithoutError12 = new ArrayList<>(new HashSet<>(filesWithoutError12));

		Integer totalFiles = 0;
		if (processorTransaction.getFileToProcessList() != null) {
			totalFiles = processorTransaction.getFileToProcessList().size();
		}
		if (processorTransaction.getMissingFileList() != null) {
			totalFiles += processorTransaction.getMissingFileList().size();
		}

		if ((processorTransaction.getFileToProcessList() == null) && (processorTransaction.getMissingFileList() == null)
				&& (processorTransaction.getSummary().getProcessingMetrics().getFileCount() > 0)) {
			totalFiles = processorTransaction.getSummary().getProcessingMetrics().getFileCount();
		}
		
		sumMap.put(FILE_NAME, processorTransaction.getFileName());
		sumMap.put("TotalFiles", totalFiles.toString());
		sumMap.put("RunTime", processorTransaction.getSummary().getProcessingMetrics().getTotalRunTime().toString());
		if (processorTransaction.getSummary().getProcessingMetrics().getFileCount() > 0) {
			long averageRuntime = processorTransaction.getSummary().getProcessingMetrics().getTotalRunTime()
					/ processorTransaction.getSummary().getProcessingMetrics().getFileCount();
			sumMap.put("AverageRunTime", String.valueOf(averageRuntime));
			long averageByteProcessed = processorTransaction.getSummary().getProcessingMetrics().getBytesProcessed()
					/ processorTransaction.getSummary().getProcessingMetrics().getFileCount();
			sumMap.put("AverageBytesProcessed", String.valueOf(averageByteProcessed));
			sumMap.put("TotalBytes", processorTransaction.getSummary().getProcessingMetrics().getTotalBytes());
			sumMap.put("AverageFileSize", processorTransaction.getSummary().getProcessingMetrics().getTotalBytes()
					/ processorTransaction.getSummary().getProcessingMetrics().getFileCount());
		}
		sumMap.put("BytesProcessed",
				processorTransaction.getSummary().getProcessingMetrics().getBytesProcessed().toString());
		var trailId = "";
		if (!CollectionUtils.isEmpty(processorFileTaskList)) {
			for (ProcessorFileTask processorFileTask : processorFileTaskList) {
				if (processorFileTask != null && !MetaDataStatus.FATAL_ERROR.equals(processorFileTask.getStatus())
						&& processorFileTask.getMetadata() != null
						&& processorFileTask.getMetadata().get(Workflow.ORIGINAL_PRINT_TRAIL) != null) {
					trailId = (String) processorFileTask.getMetadata().get(Workflow.ORIGINAL_PRINT_TRAIL);
					break;
				}
			}
		}
		
		sumMap.put("TrailID", trailId);
		sumMap.put("FilesProcessed", totalFiles - uniqueErrorFilesWithoutError12.size());
		jMap.put("Errors", uniqueErrors);
		jMap.put("Files", uniqueErrorFiles);
		jMap.put("TransactionSummary", sumMap);

		String summaryJSon = Parser.toJson(jMap);
		byte[] summaryJSonBytes = summaryJSon.getBytes();
		log.info("CreateACKFile-->generateSummaryFileForTransactionInReady-->EXIT");
		return summaryJSonBytes;
	}

	private ProcessorError findFileNameInErrorList(List<ProcessorError> errors, String fileName) {
		log.info("CreateACKFile-->findFileNameInErrorList-->ENTER");
		ProcessorError processorError = null;
		var i = 0;
		while (processorError == null && errors.size() > i) {
			ProcessorError error = errors.get(i++);
			if (error.getFileName() != null && error.getFileName().equals(fileName)) {
				processorError = error;
			}
		}
		log.info("CreateACKFile-->findFileNameInErrorList-->EXIT");
		return processorError;
	}
	
	protected String getDelegateExecutionId(DelegateExecution execution)
	{
		return execution != null ? execution.getId() : "NULL";
	}

	protected String getProcessorTransactionId(ProcessorTransaction processorTransaction)
	{
		return processorTransaction != null ? processorTransaction.getId() : "NULL";
	}
}