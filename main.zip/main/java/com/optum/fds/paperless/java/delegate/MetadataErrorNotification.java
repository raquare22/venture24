package com.optum.fds.paperless.java.delegate;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.flowable.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Service("MetadataErrorNotification")
public class MetadataErrorNotification extends OptumJavaDelegateBase {

    @Autowired
    ProcessConvertMetadata processConvertMetadata;

    @Autowired
    EmailService emailService;

    @Autowired
    DocumentMetaDataService documentMetaDataService;



    private static final Logger LOGGER = LoggerFactory.getLogger(MetadataErrorNotification.class);

    @Override
    protected void doExecute(DelegateExecution execution) {

        String clientName = execution.getVariable(Workflow.CLIENT_NAME, String.class);
        String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
        List<DocumentMetaData> documentList;
        try {
            documentList = WorkFlowUtil.readDocumentsFromJsonFile(jsonFile);
        } catch (IOException e) {
            LOGGER.error("doExecute Unable to get DocumentMetadata from file, {}={} {}", "jsonFile", jsonFile, ExceptionUtils.getStackTrace(e));
            addErrorMsg("MetadataErrorNotification-->doExecute-->Unable to get DocumentMetadata", WorkFlowUtil.getStackTrace(e));
            return;
        }

        Class<?> enumClass = processConvertMetadata.getErrEnumFromClientName(clientName);
        Map<String, Object> templateData = new HashMap<>();
        templateData.put("documents", documentList);
        templateData.put("enumClass", enumClass);
        String htmlBody = TemplateFactory.getInstance("sendMetadataErrorEmailNotification").convertWithTemplate(templateData);

        boolean mailSent = emailService.sendEmailFormatted(execution, htmlBody);
        if (mailSent) {
            List<String> docIdList = new ArrayList<>();
            Map<String, Object> updateMap = new HashMap<String, Object>();
            updateMap.put(Workflow.ERROR_NOTIFICATION_SENT, true);

            for (DocumentMetaData document : documentList) {
                docIdList.add(document.getId());
            }
            documentMetaDataService.saveDocumentMetaDataMulti(docIdList, updateMap);
        }
    }

}
