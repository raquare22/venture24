package com.optum.fds.paperless.java.delegate;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.FileSystemException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.cxf.common.util.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.FilestoreService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.HookTransactionUtil;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;


@Service("IdentifyStorageErrorDocuments")
public class IdentifyStorageErrorDocuments extends OptumJavaDelegateBase {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(IdentifyStorageErrorDocuments.class);

	@Value("${INGEST_ROOT}")
	private String ingestRoot;
	
	Map<String, String> correlationIds;
	String documentId;	
	private static final String DATE_FORMAT = "yyyyMMddHHmmssSSS";
	private static final String FILENAME = "fileName";
	private static final String PROCESS_KEY = "sendStorageErrorToShutterflyProcess";
	List<String> documentIds = new ArrayList<>();
	
	@Autowired
	DocumentMetaDataService documentMetaDataService;
	
    @Autowired
    HookService hookService;
    
    @Autowired
    FilestoreService fileStoreService;

	private static final List<String> REQ_VARS = Arrays.asList(
			Workflow.APP_ID, 
			Workflow.SPACE_ID,
			Workflow.CLIENT_ID,
			Workflow.SEARCH_CRITERIA, 
			Workflow.SEARCH_WINDOW, 
			Workflow.MAX_DOCUMENTS_OCCURS
	);

	public IdentifyStorageErrorDocuments() {
		super(REQ_VARS);
	}
	
	@Override
	public void doExecute(DelegateExecution execution) {
		LOGGER.debug("IdentifyStorageErrorDocuments-->doExecute-->Enter");
		
		try {
			correlationIds = new HashMap<>();
			var appIdentifier = "";
			Set<String> metadataFileSet = new HashSet<>();
			String documentSearchCriteria = execution.getVariable(Workflow.SEARCH_CRITERIA,String.class);           
			String documentSearchWindow = execution.getVariable(Workflow.SEARCH_WINDOW,String.class);
			Integer maxDocumentsOccurs = execution.getVariable(Workflow.MAX_DOCUMENTS_OCCURS, Integer.class);
			Integer clientId = execution.getVariable(Workflow.CLIENT_ID, Integer.class);
			String hookId = execution.getVariable(Workflow.HOOK_ID, String.class);

			HashMap<String,Object> windowMap = validateInput(documentSearchWindow, execution);
			if(windowMap==null) {
            	addErrorMsg("IdentifyStorageErrorDocuments-->doExecute-->documentSearchWindow variable is null or invalid", "documentSearchWindow object is null or invalid");
            	return;
            }
			var documentCriteriaFilter = WorkFlowUtil.getSearchWindowCriteria(documentSearchWindow);
        	if(documentCriteriaFilter == null) {
    			LOGGER.error("IdentifyStorageErrorDocuments-->doExecute-->search_window is invalid");
    			addErrorMsg("IdentifyStorageErrorDocuments-->doExecute-->search_window is invalid", "search_window is invalid");
    			return;
    		}
        	LOGGER.debug("search criteria: {}", documentSearchCriteria);
        	
			List<DocumentMetaData> listDocumentMetaDataDB = documentMetaDataService
					.getDocumentMetaData(documentSearchCriteria, documentCriteriaFilter, maxDocumentsOccurs);
			if (CollectionUtils.isEmpty(listDocumentMetaDataDB)) {
				LOGGER.debug(
						"IdentifyStorageErrorDocuments-->doExecute-->listDocumentMetaDataDB is null or empty; delegateExecutionId={}, documentSearchCriteria={}",
						execution.getId(), documentSearchCriteria);
				String messgeKey = (String) execution.getVariable(Workflow.PROCESS_KEY) + "_message";
				 execution.setTransientVariable(messgeKey, "IdentifyStorageErrorDocuments documentList is null or empty");
				setExitNow(execution);
				return;
			}
			
			// add list of documentIds to execution bus for reconciliation error message 
			List<String> docIds = new ArrayList<>();
			listDocumentMetaDataDB.forEach(e -> docIds.add(e.getId()));
			 execution.setTransientVariable("documentIds", docIds);
			 if(listDocumentMetaDataDB.size() > 0) {
				LOGGER.debug("IdentifyStorageErrorDocuments -> size: {}", listDocumentMetaDataDB.size());
				listDocumentMetaDataDB = listDocumentMetaDataDB.stream()
					.filter(e -> metadataFileSet.add(e.getMetadata().get(FILENAME).toString()))
					.collect(Collectors.toList());
			 }
			List<DocumentMetaData> listDocumentMetaData ;	
			
			String spaceId = execution.getVariable(Workflow.SPACE_ID, String.class);
			String appId = execution.getVariable(Workflow.APP_ID, String.class);
			appIdentifier = appId;
			String currentDateFormatted = getCurrentDateFormatted(DATE_FORMAT);
			String ingestWorkingDir = ingestRoot;

			try {
				//Creates Working Directory
				var tempWorkingPath = Utilities.createWorkingDirectoryWithParams(Workflow.DEFAULT_FILE_SEPARATOR,
						ingestWorkingDir, "shutterfly_storage_error", appId, spaceId, currentDateFormatted, StringUtils.EMPTY);
				
				listDocumentMetaData = listDocumentMetaDataDB
						.stream()
						.map(x -> updateDocumentMetaDataAndDownloadAttachMents(x, tempWorkingPath, execution))
						.collect(Collectors.toList());
				
				 execution.setTransientVariable(Workflow.CORRELATION_IDS, correlationIds);
				 execution.setTransientVariable(Workflow.LIST_DOCUMENT_METADATA, listDocumentMetaData);
				 execution.setTransientVariable(Workflow.OUTPUT_FILE_DIR_SHUTTERFLY, tempWorkingPath.toString() + Workflow.DEFAULT_FILE_SEPARATOR);
				 execution.setTransientVariable(Workflow.OUTPUT_FILE_DIR_MESSAGE , tempWorkingPath.toString() + Workflow.DEFAULT_FILE_SEPARATOR);
				documentIds = listDocumentMetaData.stream().map(DocumentMetaData::getId).collect(Collectors.toList());
				var hookExecutionMessage = new HashMap<>(Map.of(
						Workflow.UPDATE_DOCUMENT_WITH_API_SUCCESS_MESSAGE, documentIds.toString()
	            ));
				var hookExecutionRecord = new HashMap<>(Map.of(
	                    Workflow.SPACE_ID, spaceId,
	                    Workflow.HOOK_ID, hookId,
	                    Workflow.APP_IDENTIFIER, appIdentifier,
	                    Workflow.CLIENTID, clientId.toString()
	            ));
				var hookExecutionRecordMetaData = HookTransactionUtil
						.getHookExecutionRecord(hookExecutionRecord, hookExecutionMessage, PROCESS_KEY);
				var hookTransactionMetaData = hookService
						.saveHookTransaction(HookTransactionUtil.createCronHookTransaction(hookExecutionRecordMetaData));
				 execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA, hookTransactionMetaData);
				LOGGER.debug("IdentifyStorageErrorDocuments set outputFileDir for CorrelationIDs {}", correlationIds);

								
			} catch(FileSystemException fse){
				LOGGER.error("IdentifyStorageErrorDocuments-->doExecute-->FileSystemException while executing IdentifyStorageErrorDocuments task for documentId: {} and error: {}", documentId, WorkFlowUtil.getStackTrace(fse));
				LOGGER.error("IdentifyStorageErrorDocuments-->doExecute-->FileSystemException for CorrelationID {} and error:{}",
						Optional.ofNullable(correlationIds).map(o -> o.get(documentId)).orElse(""), fse.getMessage());
				addErrorMsg("IdentifyStorageErrorDocuments-->doExecute-->FileSystemException", WorkFlowUtil.getStackTrace(fse));
			}
			
		} catch (Exception e) {
			LOGGER.error("IdentifyStorageErrorDocuments-->doExecute-->Exception while executing IdentifyStorageErrorDocuments task for documentId: {} and error: {}", documentId, WorkFlowUtil.getStackTrace(e));
			LOGGER.error("IdentifyStorageErrorDocuments-->doExecute-->Exception while executing IdentifyStorageErrorDocuments task for CorrelationID {} and error: {}",
					Optional.ofNullable(correlationIds).map(o -> o.get(documentId)).orElse(""), e.getMessage());
			addErrorMsg("IdentifyStorageErrorDocuments-->doExecute-->Exception while executing IdentifyStorageErrorDocuments task", WorkFlowUtil.getStackTrace(e));

		} finally {
			if (newErrors() && errorMap.size() > 1) {
				var warningErrorMap =  errorMap.get(0).toString();
				LOGGER.error("IdentifyStorageErrorDocuments delegates finished with error {}",warningErrorMap);
			}
		}
		
		LOGGER.debug("IdentifyStorageErrorDocuments-->doExecute-->EXIT");
	}

	private DocumentMetaData updateDocumentMetaDataAndDownloadAttachMents(DocumentMetaData document, Path tempWorkingPath, DelegateExecution execution) {
		documentId = document.getId();
		var metadata = document.getMetadata();
		// Add absolutePath metadata field --> formerly done in ConnectAndRetrieveDocuments
		correlationIds.put(document.getId(), document.getId() + "_" + document.getSpaceId());
		metadata.put(Workflow.IS_POST_CARD, false);
		metadata.put(Workflow.DOCUMENT_ABSOLUTE_PATH, tempWorkingPath.toString() + Workflow.DEFAULT_FILE_SEPARATOR);
		
		String awsFilePath = document.getS3FilePath(); // document.getFilePath()
		String fileName = document.getFileName(); // document.getFileName()
		
		// get documentAttachment from API and store in temp dir
		downloadAttachMents(awsFilePath, fileName, tempWorkingPath, execution);

		return document;
	}

	private void downloadAttachMents(String awsFilePath, String fileName, Path tempWorkingPath, DelegateExecution execution) {
		// download pdf files when corporateMpin and tin is missing
		try {
			byte[] pdfByteArray = fileStoreService.downloadFile(awsFilePath, fileName);
			
			if (pdfByteArray != null) {
				try (OutputStream output = new BufferedOutputStream(Files.newOutputStream(Paths.get(tempWorkingPath +
						Workflow.DEFAULT_FILE_SEPARATOR + fileName))))  {
					IOUtils.write(pdfByteArray, output);
				}
			}
		} catch (Exception e) {
			LOGGER.error("IdentifyStorageErrorDocuments-->downloadAttachMents --> error: {}", ExceptionUtils.getStackTrace(e));
		}
	}
	
    @SuppressWarnings("unchecked")
	private HashMap<String,Object> validateInput(String executionBusData, DelegateExecution execution) { 
        HashMap<String,Object> map = null;
        try {
			map = Parser.parseJson(executionBusData, HashMap.class);
		} catch (IOException e) {
      		LOGGER.error("validateInput Input format is incorrect for the variable {}={} {}",
					"executionBusData", executionBusData,
					ExceptionUtils.getStackTrace(e));
    		addErrorMsg("IdentifyStorageErrorDocuments-->validateInput-->Input format is incorrect for the variable " + executionBusData, WorkFlowUtil.getStackTrace(e));
		}
        return map;
    }
    
	private String getCurrentDateFormatted(String format) {
		var now = LocalDateTime.now();
		var formatter = DateTimeFormatter.ofPattern(format);
		return now.format(formatter);
	}

	
}
