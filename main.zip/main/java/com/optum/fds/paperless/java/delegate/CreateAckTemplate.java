package com.optum.fds.paperless.java.delegate;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.AckStatus;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorTransactions;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service("CreateAckTemplate")
public class CreateAckTemplate extends OptumJavaDelegateBase {
    private static final Logger LOGGER = LoggerFactory.getLogger(CreateAckTemplate.class);
    private static final String SUMMARY ="summary";
    private static final String XMLOBJECT = "xmlObject";
    private static final String FILENAME = "fileName";
    private static final String BATCHID = "batchId";
    private static final String DATE_MODIFIED ="dateModified";
    private static final String DELEGATE_EXECUTION_ID = "delegateExecutionId";
    private static final String FAILED = "Failed";
    private static final String FILE_NAME = "FileName";
    private static final String STATUS = "Status";
    private static final String FILE_PATH = "filePath";
    private static final String JSON_FILE = "jsonFile";
    private static final String CLIENT_ID = "clientId";
    private static final String SPACE_ID = "spaceId";
    private static final List<String> REQ_VARS = Arrays.asList(
    	Workflow.TEMPLATE_NAME, Workflow.JSON_FILE,  Workflow.OUTPUT_FILE_DIR, Workflow.OUTPUT_FILE_EXTENSION, Workflow.ZIP_OUTPUT_FILE
    );

    @Autowired
    ProcessorService processorService;
    
    @Autowired
   	DocumentMetaDataService documentMetaDataService;

	@Autowired
    EmailService emailService;
	
	@Autowired
	ErrorMetaDataService errorMetaDataService;


    public CreateAckTemplate() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
        String processTransactionIngestFolder = null;
    	LOGGER.debug("Entering CreateAckTemplate doExecute");
    	
    	try {
            var templateName = execution.getVariable(Workflow.TEMPLATE_NAME).toString();

            String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);

            var jsonFileToProcess = new File(jsonFile);

            processTransactionIngestFolder = execution.getVariable(Workflow.OUTPUT_FILE_DIR, String.class);

            var processorTransactions =new ProcessorTransactions();

            String mappingValueJson=null;
            var gson = new Gson();

            try (InputStream is = new BufferedInputStream(Files.newInputStream(jsonFileToProcess.toPath()))){
            	  mappingValueJson = Parser.inputStreamToStringNoBomExclusion(is);
            }catch(IOException e){
                LOGGER.error("doExecute Unable to parse JSON File {}={}, {}={}, {}={} {}",
    					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution), Workflow.TEMPLATE_NAME, templateName, JSON_FILE, jsonFile,
    					ExceptionUtils.getStackTrace(e));
                addErrorMsg("CreateAckTemplate-->doExecute-->Unable to parse JSON File", e.getMessage());
                errorMetaDataService.writeToErrorCollection(execution,  "CreateACKTemplate --> doExecute: " + e.getMessage());
                return;
            }

            try{
                processorTransactions = gson.fromJson(mappingValueJson, ProcessorTransactions.class);
            }catch(JsonSyntaxException e){
                LOGGER.error("doExecute Unable to convert Json to Object {}={}, {}={}, {}={} {}",
    					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution), Workflow.TEMPLATE_NAME, templateName, JSON_FILE, jsonFile,
    					ExceptionUtils.getStackTrace(e));
                addErrorMsg("CreateAckTemplate-->doExecute-->Unable to Json to Object", e.getMessage());
                errorMetaDataService.writeToErrorCollection(execution, "CreateACKTemplate --> doExecute: " + e.getMessage());
                return;
            }
            
            String outputFileExtension = execution.getVariable(Workflow.OUTPUT_FILE_EXTENSION, String.class);
            Boolean zipOutputFile = execution.getVariable(Workflow.ZIP_OUTPUT_FILE, Boolean.class);

            if (processorTransactions != null) {
            	ArrayList<String> ackFileList = new ArrayList<>();
                for(var i=0; i<processorTransactions.getProcessorTransactions().size(); i++){
                    try {
                        JsonObject processorTransaction = processorTransactions.getProcessorTransactions().get(i);
                        HashMap<String, Object> fileStatus = new HashMap<>();
                        try {
                            fileStatus = prepareTemplateData(fileStatus, processorTransaction, execution);
                            if (fileStatus == null) {
                            	LOGGER.error("createAckTemplate-->doExecute-->processorFileTasks list is empty");
                            	addErrorMsg("processorFileTasks list is empty", "createAckTemplate-->doExecute-->processorFileTasks list is empty");
                            	continue;
                            }
                            
                        }catch(Exception e){
                            LOGGER.error("doExecute cannot prepare template {}={}, {}={}, {}={} {}",
                					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution), Workflow.TEMPLATE_NAME, templateName, JSON_FILE, jsonFile,
                					ExceptionUtils.getStackTrace(e));
                            addErrorMsg("createAckTemplate-->doExecute-->cannot prepare template", e.getMessage());
                            errorMetaDataService.writeToErrorCollection(execution, "CreateACKTemplate --> doExecute: " + e.getMessage());
                            continue;
                        }
                        String jsonprocessorTransaction = new Gson().toJson(fileStatus);
                        String ackString = null;
                        try {
                        	ackString = TemplateFactory.getInstance(templateName).convertWithTemplate(jsonprocessorTransaction);
                        }catch(Exception e){
                            LOGGER.error("doExecute cannot convert with template {}={}, {}={}, {}={} {}",
                					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution), Workflow.TEMPLATE_NAME, templateName, JSON_FILE, jsonFile,
                					ExceptionUtils.getStackTrace(e));
                            addErrorMsg("createAckTemplate-->doExecute-->cannot convert with template", e.getMessage());
                            errorMetaDataService.writeToErrorCollection(execution, "CreateACKTemplate --> doExecute: " + e.getMessage());
                            continue;
                        }
                        String ackFile = null;
                        if(processTransactionIngestFolder!=null && !ackString.isEmpty()) {
                            String ackFileName = Utilities.replaceExtension(processorTransaction.get(FILENAME).toString(), outputFileExtension);
                            ackFileName = ackFileName.substring(1);
                            ackFile = generateAckFile(ackString, processTransactionIngestFolder, ackFileName, zipOutputFile, execution);
                        }
                        else {
                            LOGGER.error("createAckTemplate-->doExecute-->filePath is null");
                            addErrorMsg("createAckTemplate-->doExecute-->filePath is null", "filePath is null");
                            errorMetaDataService.writeToErrorCollection(execution, "CreateAckTemplate --> doExecute: filePath is null");
                            continue;
                        }
                        if(ackFile != null) {
                        	ackFileList.add(ackFile);
                        }
                        else {
                            LOGGER.error("CreateAckTemplate-->doExecute-->ackFile is null");
                            addErrorMsg("CreateAckTemplate-->doExecute-->ackFile is null", "ackFile is null");
                            errorMetaDataService.writeToErrorCollection(execution, "CreateAckTemplate --> doExecute: ackFile is null");
                            continue;
                        }
                    } catch (Exception e) {
                        LOGGER.error("doExecute processorTransaction is null {}={}, {}={}, {}={} {}",
            					DELEGATE_EXECUTION_ID, execution != null ? execution.getId() : "NULL", Workflow.TEMPLATE_NAME, templateName, JSON_FILE, jsonFile,
            					ExceptionUtils.getStackTrace(e));
                        addErrorMsg("CreateAckTemplate-->doExecute-->processorTransaction is null", e.getMessage());
                        errorMetaDataService.writeToErrorCollection(execution, "CreateACKTemplate --> doExecute: " + e.getMessage());
                        continue;
                    }
                }
                execution.setTransientVariable(Workflow.SFTP_FILE_LIST, ackFileList);
            }else{
                LOGGER.error("CreateAckTemplate-->doExecute-->processorTransactionList is null");
                addErrorMsg("CreateAckTemplate-->doExecute-->processorTransactionList is null", "processorTransactionList is null");
                errorMetaDataService.writeToErrorCollection(execution, "CreateACKTemplate --> doExecute: processorTransactionList is null");
                return;
            }
            String activitiJobId = execution.getCurrentActivityId();
            ProcessorTransactions processorTransactionsUpdatedList = null;
            processorTransactionsUpdatedList = updateProcessorTransaction(processorTransactions, activitiJobId, execution);
            if(processorTransactionsUpdatedList != null) {
                LOGGER.debug("doExecute posting {}", Workflow.PROCESSOR_TRANSACTION_UPDATE);
                execution.setTransientVariable(Workflow.PROCESSOR_TRANSACTION_UPDATE, processorTransactionsUpdatedList.getProcessorTransactions().toString());
            }

    	} catch (Exception e) {
			LOGGER.error("doExecute Exception while executing CreateAckTemplate task {}={} {}",
					DELEGATE_EXECUTION_ID, execution != null ? execution.getId() : "NULL",
					ExceptionUtils.getStackTrace(e));
			errorMetaDataService.writeToErrorCollection(execution, "CreateACKTemplate --> doExecute: " + e.getMessage());
			addErrorMsg("CreateAckTemplate-->doExecute-->Exception while executing CreateAckTemplate task", e.getMessage());
        } finally {
        	if (newErrors() && errorMap.size() > 1 ) {
        		DelegateUtils.sendErrorNotification(execution, errorMap, DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution), emailService);
    		}
        }
    	
        LOGGER.debug("CreateAckTemplate-->doExecute-->EXIT");
    }


    private ProcessorTransactions updateProcessorTransaction(ProcessorTransactions processorTransactions, String activitiJobId, DelegateExecution execution) {

        LOGGER.debug("Entering createAckTemplate updateProcessorTransaction");

        var processorTransactions1 =new ProcessorTransactions();

        ArrayList<JsonObject> pT = new ArrayList<>();

        var dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

        dateFormatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        var d = new Date();

        if (processorTransactions != null) {

            for(var i=0; i<processorTransactions.getProcessorTransactions().size(); i++){

                try {

                    var processorTransactionNew = new JsonObject();
                    JsonObject processorTransaction = processorTransactions.getProcessorTransactions().get(i);

                    if(processorTransaction != null) {

                        if(processorTransaction.get("id") != null){
                            processorTransactionNew.addProperty(Workflow.MONGO_ID, processorTransaction.get("id").getAsString());
                        }
                        processorTransactionNew.addProperty("ackStatus", AckStatus.COMPLETE.toString());
                        var processExec = new JsonObject();

                        var processorExecutionRecordList = processorTransaction.getAsJsonArray("processorExecutionRecordList");
                        if (((JsonPrimitive) ((JsonObject) processorExecutionRecordList.get(0)).get(CLIENT_ID)) != null) {

                            processExec.addProperty(CLIENT_ID, ((JsonObject) processorExecutionRecordList.get(0)).get(CLIENT_ID).toString());
                        }
                        if (((JsonPrimitive) ((JsonObject) processorExecutionRecordList.get(0)).get(SPACE_ID)) != null) {
                            processExec.addProperty(SPACE_ID, ((JsonObject) processorExecutionRecordList.get(0)).get(SPACE_ID).toString());
                        }
                        //get from execution bus
                        processExec.addProperty("activitiJobId", activitiJobId);
                        processExec.addProperty("activitiJobStatus", "COMPLETED");
                        processExec.addProperty("activitiProcessKey", "cleanupFilesCreateACKTemplateProcess");
                        processExec.addProperty("dateActivitiJobCompleted", dateFormatter.format(d));
                        processExec.addProperty("dateActivitiJobCreated", dateFormatter.format(d));
                        processorExecutionRecordList.add(processExec);
                        processorTransactionNew.add("processorExecutionRecordList", processorExecutionRecordList);
                        pT.add(processorTransactionNew);
                    }
                } catch (Exception e) {
                    LOGGER.error("updateProcessorTransaction Unable to update ProcessorTransaction {}={} {}",
        					"activitiJobId", activitiJobId,
        					ExceptionUtils.getStackTrace(e));
                    addErrorMsg("createAckTemplate:updateProcessorTransaction-->doExecute-->Unable to update ProcessorTransaction", e.getMessage());
                    errorMetaDataService.writeToErrorCollection(execution, "CreateACKTemplate --> updateProcessorTransaction: " + e.getMessage());
                    return null;

                }
            }
        }
        else {
            LOGGER.debug("updateProcessorTransaction; processorTransactions == null");
        }
        processorTransactions1.setProcessorTransactions(pT);
        LOGGER.debug("Exiting createAckTemplate updateProcessorTransaction");
        return processorTransactions1;

    }
    
    private HashMap<String, Object> prepareTemplateData(HashMap<String, Object> fileStatus, JsonObject processorTransaction, DelegateExecution execution) throws ParseException {
    	if(processorTransaction.getAsJsonObject(SUMMARY) != null 
    			&& processorTransaction.getAsJsonObject(SUMMARY).getAsJsonObject(XMLOBJECT) != null 
    			&& StringUtils.isNotBlank(processorTransaction.getAsJsonObject(SUMMARY).getAsJsonObject(XMLOBJECT).get(BATCHID).getAsString()) ) {
    		fileStatus.put("BatchID", processorTransaction.getAsJsonObject(SUMMARY).getAsJsonObject(XMLOBJECT).get(BATCHID).getAsString());
    	} 
    	else {
    		fileStatus.put("BatchID", Utilities.stripFileExtension(processorTransaction.get(FILENAME).getAsString()));
    	}
        List<ProcessorFileTask> processorFileTasks = processorService.getProcessorFileTasksForTransactionId(processorTransaction.get("id").getAsString(), processorTransaction.get("serverType").getAsString());
        if(processorFileTasks.isEmpty()) {
        	LOGGER.info("CreateAckTemplate-->updateProcessorTransaction processorFileTasks list is empty, exiting workflow");
        	return null;
        }
        ArrayList<HashMap<String, Object>> files = new ArrayList<>();
    	List<DocumentMetaData> documentMetaDataList = new ArrayList<>();
    	for (ProcessorFileTask fileTask : processorFileTasks) {
    		var documentMetadata = documentMetaDataService.getDocumentMetaData(fileTask.getTargetId());
    		if(fileTask.getMetadata() == null || Workflow.Y.equals(fileTask.getMetadata().get("emailAlertReq"))) {
    			if(MetaDataStatus.FATAL_ERROR.equals(fileTask.getStatus()) || MetaDataStatus.SEVERE_ERROR.equals(fileTask.getStatus())) {
    				HashMap<String,Object> fileDetails = new HashMap<>();
    				fileDetails.put(STATUS, FAILED);
    				fileDetails.put(FILE_NAME, fileTask.getFileName());
    				files.add(fileDetails);
    				if (documentMetadata != null) {
    				    documentMetadata.getMetadata().put("addedToStatusFile", true);
    				}
        		}
    			else {
    				files.add(checkForEDeliveryFailure(documentMetadata, fileTask.getFileName()));
    			}
    		}
    		if (documentMetadata != null) {
    			LOGGER.debug("Adding documentMetadata");
    			documentMetaDataList.add(documentMetadata);
    		}
    	}
    	 execution.setTransientVariable(Workflow.LIST_DOCUMENT_METADATA, documentMetaDataList);
    	fileStatus.put("Count", files.size());
    	fileStatus.put("FileNameList", files);    	
    	String oldDate = processorTransaction.get(DATE_MODIFIED).getAsString();
    	SimpleDateFormat sdfOld = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
    	SimpleDateFormat sdfNew = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    	Date dateModifiedOld = sdfOld.parse(oldDate);
    	String dateModified = sdfNew.format(dateModifiedOld);
    	fileStatus.put("UploadDate", dateModified);
        return fileStatus;
    }
    
    private HashMap<String, Object> checkForEDeliveryFailure(DocumentMetaData documentMetadata, String filName) {
    	LOGGER.debug("Entering checkForEDeliveryFailure;  fileName={}", filName);
    	HashMap<String, Object> fileDetails = new HashMap<>();
		if(documentMetadata != null && documentMetadata.getMetadata() != null) {
			var sendToDocVault =  documentMetadata.getMetadata().getBoolean(Workflow.SEND_TO_DOCVAULT, true);
			String docSentTo = (String) documentMetadata.getMetadata().get(Workflow.METADATA_DOCSENTTO_FIELD);
			var metadata = documentMetadata.getMetadata();
			LOGGER.debug("sendToDocVault={}, docSentTo={}",sendToDocVault, docSentTo);
			if (sendToDocVault && Workflow.METADATA_DOCSENTTO_DOCLIB.equalsIgnoreCase(docSentTo)) {
				fileDetails.put(STATUS, "Success");
			}
			else {
				fileDetails.put(STATUS, FAILED);
			}
			if (metadata != null) {
				metadata.put("addedToStatusFile", true);
				fileDetails.put(FILE_NAME, metadata.get(FILENAME).toString());
				documentMetadata.setMetadata(metadata);
			}
		}
		else {
			fileDetails.put(STATUS, FAILED);
			fileDetails.put(FILE_NAME, filName);
		}
		LOGGER.debug("Exiting checkForEDeliveryFailure");
		return fileDetails;
	}

    private String generateAckFile(String ackString, String filePath, String ackFileName, boolean zipOutputFile, DelegateExecution execution) {
    	String zipFile = null;
    	try {
    		var ackFile = new File(filePath+File.separator+ackFileName);
    		if(!ackFile.exists()) {
    			ackFile.getParentFile().mkdirs();
    			if (!ackFile.exists()) {
    				ackFile.createNewFile();
    			}
    		}else{
    			LOGGER.warn("generateAckFile; File already exists; ackFile={}", ackFile);
    		}
    		try(OutputStream fos = new BufferedOutputStream(Files.newOutputStream(Paths.get(filePath+File.separator+ackFileName)));
    				var bw = new BufferedWriter(new OutputStreamWriter(fos));) {
    			bw.write(ackString);
    		}
    		if(zipOutputFile) {
    			byte[] fileTaskJSonBytes = ackString.getBytes();
    			zipFile = generateZip(ackFile, filePath, ackFileName, fileTaskJSonBytes, execution);
    		}
    		else {
    			zipFile = ackFile.getAbsolutePath();
    		}
    	}
    	catch(IOException e) {
    		zipFile = null;
    		LOGGER.error("generateAckFile Unable to generate ack file {}={}, {}={} {}",
    				FILE_PATH, filePath, "ackFileName", ackFileName,
    				ExceptionUtils.getStackTrace(e));
    		addErrorMsg("CreateAckTemplate--->doExecute-->Unable to generate ack file", e.getMessage());
    		errorMetaDataService.writeToErrorCollection(execution, "CreateACKTemplate --> generateAckFile: " + e.getMessage());
    	}
    	return zipFile;
    }
    
    private String generateZip(File f, String filePath, String ackfileName, byte[] bytes, DelegateExecution execution) throws IOException{


        var buffer = new byte[1024];
        String zName = Utilities.stripFileExtension(ackfileName);
        String zipFilePath = filePath+File.separator+zName+"_ack.zip";
        try (OutputStream fos = new BufferedOutputStream(Files.newOutputStream(Paths.get(zipFilePath)));
        		 var zos = new ZipOutputStream(fos);
        		 InputStream in = new BufferedInputStream(Files.newInputStream(f.toPath())) )  {

        var ze= new ZipEntry(ackfileName);
        zos.putNextEntry(ze);

        int len;
        while ((len = in.read(buffer)) > 0) {
            zos.write(buffer, 0, len);
        }
        }
        catch (IOException e) {
        		LOGGER.error("generateZip {}={}, {}={}, {}={} {}",
        				"f", f != null ? f.toString() : "NULL",
                		FILE_PATH, filePath, "ackfileName", ackfileName,
    					ExceptionUtils.getStackTrace(e));
        		errorMetaDataService.writeToErrorCollection(execution, "CreateACKTemplate --> generateZip: " + e.getMessage());
        }

        return zipFilePath;
    }
    
    protected String getDelegateExecutionId(DelegateExecution execution)
    {
        return execution != null ? execution.getId() : "NULL";
    }

}