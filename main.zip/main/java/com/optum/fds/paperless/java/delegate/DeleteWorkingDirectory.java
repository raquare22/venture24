package com.optum.fds.paperless.java.delegate;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.workflow.constants.Workflow;

@Service("DeleteWorkingDirectory")
public class DeleteWorkingDirectory extends OptumJavaDelegateBase {

	private static final Logger LOGGER = LoggerFactory.getLogger(DeleteWorkingDirectory.class);
	
	
	ProcessorService processorService=null;
	
	private static final List<String> REQ_VARS = Arrays.asList(
		Workflow.PROCESSOR_TRANSACTION
	);
	
	public DeleteWorkingDirectory() {
		super(REQ_VARS);
	}
	@Autowired
	public DeleteWorkingDirectory(ProcessorService processorService) {
		this.processorService=processorService;
	}
	
	@Override
	protected void doExecute(DelegateExecution execution) {
		LOGGER.debug("DeleteWorkingDirectory-->doExecute-->ENTER");
		ProcessorTransaction processorTransaction = null;
		ProcessorExecutionRecord executionRecord = null;
		Map<String, String> message = new HashMap<>();
		try {
			processorTransaction = execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class);
			executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Deleting working directory");
			String outputFileDir = processorTransaction.getLocation();
			LOGGER.debug("doExecute; delegateExecutionId: {}, outputFileDir: {}", execution.getId(), outputFileDir);
			var fileDir = new File(outputFileDir);
			if (fileDir.exists()) {
				deleteDirectory(fileDir);
				message.put(Workflow.OUTCOME_KEY, "Working directory deleted");
				LOGGER.info("Working directory deleted: {}", outputFileDir);
			}
			else {
				message.put(Workflow.OUTCOME_KEY, "Working directory was not present");
				LOGGER.info("Working directory was not present: {}", outputFileDir);
			}
		} catch(Exception e) {
			LOGGER.error("doExecute Exception while executing Clean Ingest Task {}={}, {}={} {}",
					"delegateExecutionId", execution.getId(),
					"processorTransaction", processorTransaction != null ? processorTransaction.getId() : "NULL",
					ExceptionUtils.getStackTrace(e));
			message.put(Workflow.OUTCOME_KEY, "Exception while deleting working directory");
			message.put(Workflow.ERROR_KEY, e.toString());
		} finally {
			if (processorTransaction != null) {
				ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction,
						executionRecord, message);
				processorService.updateProcessorTransactionMetaData(processorTransaction);
			}
		}
		LOGGER.debug("DeleteWorkingDirectory-->doExecute-->EXIT");
	}

	void deleteDirectory(File fileDir) throws IOException {
		FileUtils.deleteDirectory(fileDir);
	}

}