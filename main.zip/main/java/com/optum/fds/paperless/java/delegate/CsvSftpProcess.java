package com.optum.fds.paperless.java.delegate;

import java.util.Arrays;
import java.util.List;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optum.fds.paperless.constants.WorkflowConstants;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;

@Service("CsvSftpProcess")
public class CsvSftpProcess extends OptumJavaDelegateBase{
	private static final Logger LOGGER = LoggerFactory.getLogger(CsvSftpProcess.class);
	
	@Autowired
	ScheduledCsvSftpMonitor scheduledCsvSftpMonitor;
	
	@Autowired
	ErrorMetaDataService errorMetaDataService;
	
	public CsvSftpProcess() {
		super(REQ_VARS);
	}

	public CsvSftpProcess(ScheduledCsvSftpMonitor scheduledCsvSftpMonitor) {
		super(REQ_VARS);
		this.scheduledCsvSftpMonitor = scheduledCsvSftpMonitor;
	}
	
	private static final List<String> REQ_VARS = Arrays.asList (
		Workflow.PROCESSOR_METADATA
	);

	@Override
	public void doExecute(DelegateExecution execution) {
		var processorMetaData = (ProcessorMetaData) execution.getVariable("processorMetaData");
		try {
			LOGGER.debug("Calling runCsvSFTPMonitor; process={}", processorMetaData.getProcess());
			scheduledCsvSftpMonitor.runCsvSFTPMonitor(execution, processorMetaData);
		} catch (Exception e) {
			LOGGER.error("doExecute Error Occured while running CSVSftpMonitor {}={}, {}={} {}",
					"delegateExecutionId", execution.getId(),
					"processorMetaDataId", processorMetaData.getId(),
					ExceptionUtils.getStackTrace(e));
			addErrorMsg(e.toString(), "Error Occured while running CSVSftpMonitor.");
			errorMetaDataService.writeToErrorCollection(execution, "CsvSftpProcess --> doExecute: " + e.getMessage());
		}
		 execution.setTransientVariable("Monitor_Message", "SUCCESS");
		 execution.setTransientVariable(WorkflowConstants.PROCESSOR_METADATA, processorMetaData);
		LOGGER.debug("Csv Sftp executed");
	}
}
