package com.optum.fds.paperless.java.delegate;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.mongodb.client.result.UpdateResult;
import com.optum.fds.paperless.java.delegate.docvault.OutOfRetriesException;
import com.optum.fds.paperless.java.delegate.docvault.RetryOnExceptionHandler;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.Parser;

@Service("UpdateDocsWithSecondaryEmail")
public class UpdateDocsWithSecondaryEmail extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateDocsWithSecondaryEmail.class);

    private static final List<String> REQ_VARS = List.of(
            "PDO_OAUTH_URL",
            "PDO_API_URL",
            "PDO_CLIENT_ID",
            "PDO_CLIENT_SECRET",
            "NUM_RETRIES",
            "TIME_TO_WAIT"
    );

    private static final int DEFAULT_NUM_RETRIES = 3;
    private static final long DEFAULT_TIME_TO_WAIT_MS = 250L;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private OauthManagerUtil oauthManagerUtil;

    @Autowired
    private DocumentMetaDataService documentMetaDataService;

    public UpdateDocsWithSecondaryEmail() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("UpdateDocsWithSecondaryEmail-->doExecute-->Enter");
        String jsonFilePath = null;

        try {
            jsonFilePath = execution.getVariable("JSON_FILE", String.class);
            String pdoOauthUrl = execution.getVariable("PDO_OAUTH_URL", String.class);
            String pdoClientId = execution.getVariable("PDO_CLIENT_ID", String.class);
            String pdoClientSecret = execution.getVariable("PDO_CLIENT_SECRET", String.class);
            String pdoApiUrlFromVar = execution.getVariable("PDO_API_URL", String.class);

            if (!StringUtils.hasText(jsonFilePath)) {
                addErrorMsg("UpdateDocsWithSecondaryEmail-->doExecute-->JSON_FILE is null or empty",
                        "JSON_FILE variable is missing");
                return;
            }

            String jsonContent = Files.readString(Paths.get(jsonFilePath));
            List<DocumentMetaData> documents = Parser.parseJson(
                    jsonContent, new TypeReference<List<DocumentMetaData>>() {}
            );

            if (documents == null || documents.isEmpty()) {
                LOGGER.warn("UpdateDocsWithSecondaryEmail-->No documents found in JSON file: {}", jsonFilePath);
                return;
            }

            String token = oauthManagerUtil.getOauthToken(
                    "tokenStargate", pdoClientId, pdoClientSecret,
                    "client_credentials", pdoOauthUrl, false, null
            );

            if (!StringUtils.hasText(token)) {
                addErrorMsg("UpdateDocsWithSecondaryEmail-->doExecute-->Failed to obtain bearer token",
                        "Bearer token is null or empty");
                return;
            }
            String bearerToken = "Bearer " + token;

            int updatedCount = 0;
            for (DocumentMetaData doc : documents) {
                try {
                    if (updateDocument(doc, bearerToken, pdoOauthUrl, pdoApiUrlFromVar, pdoClientId, pdoClientSecret, execution)) {
                        updatedCount++;
                    }
                } catch (Exception e) {
                    LOGGER.error("UpdateDocsWithSecondaryEmail-->Failed to update document with ID: {}", doc.getId(), e);
                }
            }

            LOGGER.info("UpdateDocsWithSecondaryEmail-->Successfully updated {} out of {} documents",
                    updatedCount, documents.size());
            execution.setVariable("UPDATED_DOCS_COUNT", updatedCount);

        } catch (Exception e) {
            LOGGER.error("UpdateDocsWithSecondaryEmail-->doExecute Exception while executing task: {}",
                    ExceptionUtils.getStackTrace(e));
            addErrorMsg("UpdateDocsWithSecondaryEmail-->doExecute-->Exception", e.getMessage());
        }
        LOGGER.debug("UpdateDocsWithSecondaryEmail-->doExecute-->Exit");
    }

    private boolean updateDocument(DocumentMetaData doc, String bearerToken, String pdoOauthUrl, String pdoApiUrlFromVar, String pdoClientId, String pdoClientSecret, DelegateExecution execution) throws Exception {

        if (!StringUtils.hasText(doc.getId())) {
            LOGGER.warn("UpdateDocsWithSecondaryEmail-->Invalid or null document ID");
            return false;
        }

        Document metadata = doc.getMetadata();
        if (metadata == null) {
            LOGGER.warn("UpdateDocsWithSecondaryEmail-->Document {} has no metadata", doc.getId());
            return false;
        }

        String mpin = metadata.getString("mpin");
        String tin = metadata.getString("tin");
        if (!StringUtils.hasText(mpin) || !StringUtils.hasText(tin)) {
            LOGGER.warn("UpdateDocsWithSecondaryEmail-->Document {} missing mpin or tin", doc.getId());
            return false;
        }

        String subcategory = metadata.getString("subcategory");
        if (!StringUtils.hasText(subcategory)) {
            LOGGER.warn("UpdateDocsWithSecondaryEmail-->Document {} missing subcategory", doc.getId());
            return false;
        }

        List<String> secondaryEmails;
        try {
            secondaryEmails = getSecondaryEmailsWithRetry(
                    mpin, tin, subcategory, bearerToken, pdoOauthUrl, pdoApiUrlFromVar, pdoClientId, pdoClientSecret, execution
            );
        } catch (OutOfRetriesException e) {
            LOGGER.error("UpdateDocsWithSecondaryEmail-->Out of retries getting secondary emails for MPIN={}, TIN={}",
                    Encode.forJava(mpin), Encode.forJava(tin), e);
            return false;
        }

        if (secondaryEmails == null) {
            LOGGER.error("UpdateDocsWithSecondaryEmail-->Failed to retrieve secondary emails for MPIN: {}, TIN: {}", Encode.forJava(mpin), Encode.forJava(tin));
            return false;
        }

        if (secondaryEmails.isEmpty()) {
            LOGGER.info("UpdateDocsWithSecondaryEmail-->No secondary emails found for MPIN: {}, TIN: {}. Updating document with empty list.",
                    Encode.forJava(mpin), Encode.forJava(tin));
        } else {
            LOGGER.info("UpdateDocsWithSecondaryEmail-->Found {} secondary email(s) for MPIN: {}, TIN: {}: {}",
                    secondaryEmails.size(), Encode.forJava(mpin), Encode.forJava(tin), secondaryEmails);
        }

        Map<String, Object> fieldsToUpdate = new HashMap<>();
        fieldsToUpdate.put("metadata.secondaryEmails", secondaryEmails);
        fieldsToUpdate.put("metadata.secondaryEmailsUpdated", true);

        try {
            DocumentMetaData updatedDoc = documentMetaDataService.updateDocumentMetadataFields(fieldsToUpdate, doc.getId());
            if (updatedDoc != null) {
                LOGGER.info("Successfully updated document _id: {} with {} secondary email(s)", doc.getId(), secondaryEmails.size());
                return true;
            } else {
                LOGGER.warn("No document updated for _id: {}, MPIN: {}, TIN: {}", doc.getId(), Encode.forJava(mpin), Encode.forJava(tin));
                return false;
            }
        } catch (Exception e) {
            LOGGER.error("Service update failed for _id: {}, MPIN: {}, TIN: {}. Error: {}", doc.getId(), Encode.forJava(mpin), Encode.forJava(tin), ExceptionUtils.getStackTrace(e));
            return false;
        }

    }

    private List<String> getSecondaryEmailsWithRetry(String mpin, String tin, String subcategory, String initialBearerToken, String pdoOauthUrl, String pdoApiUrlFromVar, String pdoClientId, String pdoClientSecret, DelegateExecution execution) throws OutOfRetriesException {

        Number numRetriesVar = execution.getVariable(Workflow.NUM_RETRIES, Number.class);
        Number timeToWaitVar = execution.getVariable(Workflow.TIME_TO_WAIT, Number.class);

        int numRetries = (numRetriesVar != null) ? numRetriesVar.intValue() : DEFAULT_NUM_RETRIES;
        long timeToWaitMS = (timeToWaitVar != null) ? timeToWaitVar.longValue() : DEFAULT_TIME_TO_WAIT_MS;

        var retryHandler = new RetryOnExceptionHandler(numRetries, timeToWaitMS);
        String msg;

        while (retryHandler.shouldRetry()) {
            try {
                try {
                    String bearerToUse = initialBearerToken;

                    if (retryHandler.isRetry()) {
                        String newToken = oauthManagerUtil.getOauthToken(
                                "tokenStargate", pdoClientId, pdoClientSecret,
                                "client_credentials", pdoOauthUrl, true, null
                        );
                        bearerToUse = "Bearer " + newToken;
                        LOGGER.info("UpdateDocsWithSecondaryEmail-->Retrying PDO API call with new token for MPIN: {}, TIN: {}",
                                Encode.forJava(mpin), Encode.forJava(tin));
                    }

                    ResponseEntity<String> response = getSecondaryEmails(mpin, tin, bearerToUse, pdoApiUrlFromVar);

                    return parseSecondaryEmailsFromResponse(response, mpin, tin, subcategory);

                } catch (HttpClientErrorException.Unauthorized e) {
                    LOGGER.error("UpdateDocsWithSecondaryEmail-->Unauthorized (401) for MPIN={}, TIN={}, body={}, status={}",
                            Encode.forJava(mpin), Encode.forJava(tin), Encode.forJava(e.getResponseBodyAsString()), e.getStatusCode());
                    retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
                    retryHandler.exceptionOccurred();

                } catch (HttpClientErrorException e) {
                    LOGGER.error("UpdateDocsWithSecondaryEmail-->HttpClientErrorException for MPIN={}, TIN={}, body={}, status={}",
                            Encode.forJava(mpin), Encode.forJava(tin), Encode.forJava(e.getResponseBodyAsString()), e.getStatusCode());
                    return null;

                } catch (HttpServerErrorException e) {
                    if (e instanceof HttpServerErrorException.GatewayTimeout
                            || e instanceof HttpServerErrorException.BadGateway) {
                        LOGGER.error("UpdateDocsWithSecondaryEmail-->Transient server error for MPIN={}, TIN={}, body={}, status={}",
                                Encode.forJava(mpin), Encode.forJava(tin), Encode.forJava(e.getResponseBodyAsString()), e.getStatusCode());
                        retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
                        retryHandler.exceptionOccurred();
                    } else {
                        LOGGER.error("UpdateDocsWithSecondaryEmail-->{} for MPIN={}, TIN={}, body={}, status={}",
                                e.getClass().getSimpleName(), Encode.forJava(mpin), Encode.forJava(tin), Encode.forJava(e.getResponseBodyAsString()), e.getStatusCode());
                        return null;
                    }

                } catch (RestClientException e) {
                    LOGGER.error("UpdateDocsWithSecondaryEmail-->RestClientException for MPIN={}, TIN={}, exception={}",
                            Encode.forJava(mpin), Encode.forJava(tin), ExceptionUtils.getStackTrace(e));
                    retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
                    retryHandler.exceptionOccurred();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }

            } catch (OutOfRetriesException e) {
                msg = String.format(
                        "PDO API call exhausted %s retries with retry time %s millis for MPIN=%s, TIN=%s",
                        retryHandler.getNumRetries(), retryHandler.getTimeToWaitMS(), Encode.forJava(mpin), Encode.forJava(tin)
                );
                LOGGER.error(msg);
                addErrorMsg("PDO API OutOfRetries", msg);
                throw new OutOfRetriesException(msg);
            }
        }
        return null;
    }

    private ResponseEntity<String> getSecondaryEmails(String mpin, String tin, String bearerToken, String pdoApiUrlFromVar) throws Exception {
        LOGGER.debug("UpdateDocsWithSecondaryEmail-->Getting secondary emails for MPIN: {}, TIN: {}", Encode.forJava(mpin), Encode.forJava(tin));
        long start = System.currentTimeMillis();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", bearerToken);

        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("mpin", mpin);
        requestBody.put("tin", tin);

        HttpEntity<Map<String, String>> entity = new HttpEntity<>(requestBody, headers);

        ResponseEntity<String> response = restTemplate.exchange(
                pdoApiUrlFromVar,
                HttpMethod.POST,
                entity,
                String.class
        );
        long latencyMs = System.currentTimeMillis() - start;
        LOGGER.info("UpdateDocsWithSecondaryEmail-->PDO API call for secondaryEmails SUCCESS - mpin={}, tin={}, latencyMs={}, httpStatus={}, requestBody={}, responseBody={}",
                Encode.forJava(mpin), Encode.forJava(tin), latencyMs, response.getStatusCode(), Encode.forJava(String.valueOf(requestBody)), Encode.forJava(response.getBody()));

        return response;
    }

    private List<String> parseSecondaryEmailsFromResponse(ResponseEntity<String> response, String mpin, String tin, String subcategory) throws Exception {
        if (response == null) {
            LOGGER.error("UpdateDocsWithSecondaryEmail-->Null response for MPIN: {}, TIN: {}", Encode.forJava(mpin), Encode.forJava(tin));
            return null;
        }

        if (!response.getStatusCode().is2xxSuccessful() || !StringUtils.hasText(response.getBody())) {
            LOGGER.error("UpdateDocsWithSecondaryEmail-->PDO API call failed for MPIN: {}, TIN: {}. Status: {} Body: {}",
                    Encode.forJava(mpin), Encode.forJava(tin), response.getStatusCode(), Encode.forJava(response.getBody()));
            return null;
        }

        JsonNode jsonResponse = objectMapper.readTree(response.getBody());
        JsonNode preferenceTypes = jsonResponse.get("preferenceTypes");

        if (preferenceTypes == null || !preferenceTypes.isArray()) {
            LOGGER.warn("UpdateDocsWithSecondaryEmail-->No preferenceTypes in response for MPIN: {}, TIN: {}",
                    Encode.forJava(mpin), Encode.forJava(tin));
            return List.of();
        }

        for (JsonNode preference : preferenceTypes) {
            String classifier = preference.has("classifier") ? preference.get("classifier").asText() : null;
            if (subcategory != null && subcategory.equals(classifier)) {
                if (preference.has("secondaryEmails") && preference.get("secondaryEmails").isArray()) {
                    ArrayNode emailsArray = (ArrayNode) preference.get("secondaryEmails");
                    List<String> emails = new ArrayList<>();
                    for (JsonNode emailNode : emailsArray) {
                        emails.add(emailNode.asText());
                    }
                    LOGGER.info("UpdateDocsWithSecondaryEmail-->Found {} secondary email(s) for classifier={}, MPIN={}, TIN={}",
                            emails.size(), Encode.forJava(classifier), Encode.forJava(mpin), Encode.forJava(tin));
                    return emails;
                }
            }
        }

        LOGGER.warn("UpdateDocsWithSecondaryEmail-->No secondaryEmails field in PDO API response for MPIN: {}, TIN: {}",
                Encode.forJava(mpin), Encode.forJava(tin));
        return List.of();
    }
}