package com.optum.fds.paperless.java.delegate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;
import com.optum.fds.paperless.constants.WorkflowConstants;
import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.CsvProcessorsService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.domain.service.SendQueueService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.processors.CsvProcessorsMonitor;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.util.SftpMonitorUtil;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import java.util.regex.Pattern;

@Component
public class ScheduledCsvSftpMonitor {
	@Value("${FDSPostPDODocumentsUrl}")
	private String fDSPostPDODocumentsUrl;
	
	@Autowired
	ProcessorService processorService;

	@Autowired
	ProcessorsService processorsService;

	@Autowired
	SftpMonitorUtil sftpMonitorUtil;

	@Autowired
	CsvToJsonFile csvToJsonFile;

	@Autowired
	CsvProcessorsService csvProcessorsService;

	@Autowired
	CsvProcessorService csvProcessorService;

	@Autowired
	CsvProcessorsMonitor csvProcessorsMonitor;

	@Autowired
	SendQueueService sendQueueService;

	@Autowired
	CsvCleanupFilesProcess csvCleanupFilesProcess;

	private static final Logger LOGGER = LoggerFactory.getLogger(ScheduledCsvSftpMonitor.class);

	private static final String HOST_NAME_SOURCE = "host_name_source";
	private static final String USER_NAME_SOURCE = "username_source";
	private static final String USER_CREDENTIALS_SOURCE = "pw_source";
	private static final String FTP_ROOT_DIR = "ftp_rootdir";
	public static final String INGEST_PATH_PROPERTY_NAME = "INGEST_ROOT";
	private static final String DIRECTORY_LISTING = "directoryListing";
	private static final String CHANNEL_SFTP = "channelSftp";
	private static final String SFTP_SESSION = "sftpSession";
	private static final String CHANNEL = "channel";
	private static final String INCLUDE_FILENAME_REGEX_PATTERN = "includeFileNameRegExPattern";
	private static final String EXCLUDE_FILENAME_REGEX_PATTERN = "excludeFileNameRegExPattern";	

	@Value("${PDOSpaceId}")
	private Integer PDOSpaceId;

	@Value("${PDOAppId}")
	private String PDOAppId;

	@Value("${IsRedisMsgBroker}")
	private Boolean isRedisMsgBroker;

	public ScheduledCsvSftpMonitor() {
		// Required constructor
	}

	public ScheduledCsvSftpMonitor(ProcessorsService processorsService, SftpMonitorUtil sftpMonitorUtil,
			CsvProcessorsService csvProcessorsService) {
		this.processorsService = processorsService;
		this.sftpMonitorUtil = sftpMonitorUtil;
		this.csvProcessorsService = csvProcessorsService;
	}

	public static boolean validateFileExtn(String fileName, String includeRegEx, String excludeRegEx) {
		var valid1 = false;
		var valid2 = false;
		if (StringUtils.isEmpty(includeRegEx)) {
			includeRegEx = "([^\\s]+(\\.(?i)(csv))$)";
		}
		var fileExtnPtrn = Pattern.compile(includeRegEx);
		var mtch = fileExtnPtrn.matcher(fileName);
		if (mtch.matches())
			valid1 = true;
		LOGGER.debug("validateFileExtn RegExPattern: {}{}{}{}{}", includeRegEx, " filename:", fileName, "matched: ",
				valid1);

		if (!StringUtils.isEmpty(excludeRegEx)) {
			var fileExtnPtrn2 = Pattern.compile(excludeRegEx);
			var mtch2 = fileExtnPtrn2.matcher(fileName);
			if (!mtch2.matches())
				valid2 = true;
		} else {
			valid2 = true;
		}
		return (valid1 && valid2);
	}

	@SuppressWarnings("unchecked")
	public void runCsvSFTPMonitor(DelegateExecution execution, ProcessorMetaData inProcessor) throws IOException {
		LOGGER.debug("ScheduledCsvSftpMonitor-->runCsvSFTPMonitor-->ENTER");

		var processMap = inProcessor.getProcess();
		var processConfigMap = (Map) inProcessor.getProcess().get("config");
		LOGGER.debug("processMap={}", processMap);
		LOGGER.debug("processConfigMap={}", processConfigMap);
		String spaceId = (String) processConfigMap.get("space_id");
		String appIdentifier = (String) processConfigMap.get("appIdentifier");
		String sftpHost = (String) processConfigMap.get(HOST_NAME_SOURCE);
		String sftpUSER = (String) processConfigMap.get(USER_NAME_SOURCE);
		String sftpPASS = (String) processConfigMap.get(USER_CREDENTIALS_SOURCE);
		String includeRegEx = (String) processConfigMap.get(INCLUDE_FILENAME_REGEX_PATTERN);
		String excludeRegEx = (String) processConfigMap.get(EXCLUDE_FILENAME_REGEX_PATTERN);
		String sftpWorkingDir = (String) processConfigMap.get(FTP_ROOT_DIR);
		String ftpArchiveDir = (String) processConfigMap.get("ftp_archivedir");
		var configSpaceId = Integer.valueOf(spaceId);

		ProcessorMetaData processor = null;
		String processorId;
		var processorTransactionId = "";

		LOGGER.debug("sftpHost={}, sftpUSER={}, sftpWorkingDir={}", sftpHost, sftpUSER, sftpWorkingDir);
		if (Boolean.TRUE.equals(sftpMonitorUtil.isMissingLoginCredential(sftpHost, sftpUSER, sftpPASS, sftpWorkingDir))) {
			LOGGER.info("runCsvSFTPMonitor Login credentials must be supplied ; not able to login to SFTP host={}", sftpHost);
			// throw new errors
			throw new IOException("Missing login credentials host=" + sftpHost);
		}

		LOGGER.debug("Calling getProcessor: appIdentifier={}, id={}", inProcessor.getAppIdentifier(), inProcessor.getId());
		inProcessor.setConfigSpaceId(Integer.getInteger(spaceId));
		processor = inProcessor;
		processorId = processor != null ? processor.getId() : "";
		LOGGER.debug("hasValidStatus={}", sftpMonitorUtil.hasValidStatus(processor));
		if (Boolean.TRUE.equals(sftpMonitorUtil.hasValidStatus(processor))) {
			LOGGER.debug("hasValidStatus; Processing");
			Map<String, Object> processSftpResults = null;
			try {
				var workDone = false;
				LOGGER.debug("sftpHost={}, sftpUSER={}, sftpWorkingDir={}", sftpHost, sftpUSER, sftpWorkingDir);
				processSftpResults = sftpMonitorUtil.proccessSFTPDirectory(sftpUSER, sftpPASS, sftpHost, sftpWorkingDir);
				LOGGER.debug("directoryListing={}", processSftpResults.get(DIRECTORY_LISTING));

				// for each csv file in remote drop directory
				for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) processSftpResults.get(DIRECTORY_LISTING)) {
					LOGGER.debug("ScheduledCsvSftpMonitor-->runCsvSFTPMonitor-->filename=[{}], entry={}", entry.getFilename(), entry);
					if (validateFileExtn(entry.getFilename(), includeRegEx, excludeRegEx) &&
						csvProcessorsService.findProcessorMetaDataByFileName(entry.getFilename(),
						processor.getAppIdentifier()) == null) {
						// Search processorTransaction for existing csv file entry
						var transactionMetaData = processorsService.createTransactionRecord(processor);
						LOGGER.debug("createdTransactionRecord: id={}, transactionId={}, dateCreated={}, spaceId={}",
								transactionMetaData.getId(), transactionMetaData.getTransactionId(),
								transactionMetaData.getDateCreated(), transactionMetaData.getSpaceId());

						// Set Create File OutPut Directory
						String dir = sftpMonitorUtil.createFileOutputDirectoryPath(processConfigMap, processor, entry.getFilename());
						LOGGER.debug("dir={}", dir);
						if (!Paths.get(dir).toFile().exists()) {
							workDone = true;
							var filePath = Utilities.createWorkingDirectory(dir);

							// Downloading the specified file from the remote directory to the specified folder path
							((ChannelSftp) processSftpResults.get(CHANNEL_SFTP)).get(entry.getFilename(),
									filePath.toAbsolutePath().toString());

							// Create processorTransaction entry
							var csvProcessorTransaction = csvProcessorsService
									.createCsvProcessorTransaction(processor, entry.getFilename(),
											filePath.toAbsolutePath().toString(),
											transactionMetaData.getTransactionId());
							processorTransactionId = csvProcessorTransaction.getId();

							LOGGER.debug("CREATED: csvProcessorTransactionId={}, id={}, fileName={}, jsonFileName={}",
									processorTransactionId, csvProcessorTransaction.getProcessorId(),
									csvProcessorTransaction.getFileName(), csvProcessorTransaction.getJsonFileName());

							execution.setTransientVariable(WorkflowConstants.APP_IDENTIFIER, appIdentifier);
							execution.setTransientVariable(Workflow.CSV_PROCESSOR_TRANSACTION, csvProcessorTransaction);

							LOGGER.debug("Calling: CSV_TO_FDS_DOCUMENT_PROCESS");
							csvToJsonFile.doExecute(execution);

							String jsonFileName = (String) execution.getVariable("jsonFileName");
							String locationDirectory = csvProcessorTransaction.getLocation();
							LOGGER.debug("csvProcessorTransaction: locationDirectory={}, jsonFileName={}", locationDirectory, jsonFileName);

							var location = Paths.get(locationDirectory);
							var jsonFileToProcess = new File(location.toFile(), jsonFileName);

							LOGGER.debug("Send records to document collection; jsonFileToProcess={}", jsonFileToProcess);
							execution.setTransientVariable(Workflow.SFTP_HOSTNAME, sftpHost);
							execution.setTransientVariable(Workflow.SFTP_USERNAME, sftpUSER);
							execution.setTransientVariable(Workflow.SFTP_PW, sftpPASS);
							execution.setTransientVariable(Workflow.SFTP_ROOT_DIRECTORY, sftpWorkingDir);
							execution.setTransientVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, ftpArchiveDir);
							execution.setTransientVariable(Workflow.MAX_SFTP_TRIES, (Integer) 3);
							execution.setTransientVariable(Workflow.RETRY_TIME_SECS, (Integer) 10);

							String fileName = entry.getFilename();
							traverseCsvFile(csvProcessorTransaction, configSpaceId, fileName, jsonFileName, jsonFileToProcess, appIdentifier);
							csvProcessorTransaction.setStatus("COMPLETE");
							csvProcessorsService.updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
						} else {
							LOGGER.warn("runCsvSFTPMonitor Directory already exists. Do not process. {}", dir);
						}
					} else {
						LOGGER.warn("Not validateFileExtn; exiting");
					}
				}
				if (workDone) {
					csvCleanupFilesProcess.doExecute(execution);
				} else {
					LOGGER.warn("workDone={}", workDone);
				}
			} catch (Exception e) {
				LOGGER.error("runCsvSFTPMonitor Exception {}={}, {}={}, {}={}, {}:{}", "transactionId",
						inProcessor.getTransactionId(), "processorId", processorId, "processorTransactionId",
						processorTransactionId, e.getClass().getSimpleName(), e.getMessage());
				LOGGER.error("runCsvSFTPMonitor Stack {}", ExceptionUtils.getStackTrace(e));
				if (e.getMessage() != null && !e.getMessage().contains("No such file")
						&& !e.getMessage().endsWith("Failure")) {
					LOGGER.error("runCsvSFTPMonitor Stack {}", ExceptionUtils.getStackTrace(e));
				}
			} finally {
				if (processSftpResults != null) {
					sftpMonitorUtil.closeSFTPChannel((ChannelSftp) processSftpResults.get(CHANNEL_SFTP),
						(Session) processSftpResults.get(SFTP_SESSION), (Channel) processSftpResults.get(CHANNEL));
				}
				// update processor lastRun.
				processorsService.setLastRunAndStatus(processor.getId(), MetaDataStatus.IN_PROCESS);
			}
		}
		else
		if (LOGGER.isInfoEnabled() && processor != null) {
			LOGGER.debug("runCsvSFTPMonitor Processor: {}{}{}{}{}{}", processor.getName(), ", ID: ",
					processor.getId(), ", is in status of ", processor.getStatus(),
					". CSV SFTP process will not move files from the SFTP folder to the working folder.");
		}
		LOGGER.debug("ScheduledCsvSftpMonitor-->runCsvSFTPMonitor-->EXIT");
	}

	protected boolean traverseCsvFile(CsvProcessorTransaction csvProcessorTransaction, Integer configSpaceId, String fileName,
			String jsonFileName, File jsonFileToProcess, String appId) {
		try {
			String jsonFileStr = FileUtils.readFileToString(jsonFileToProcess, Charset.forName("utf-8"));
			LOGGER.debug("jsonFileStr={}", jsonFileStr);
			ObjectMapper objectMapper = new ObjectMapper();
			ArrayList<Map<String, Object>> arrayList;
			Map<String, Object> requestMap = null;
			arrayList = objectMapper.readValue(jsonFileStr, new TypeReference<>(){});
			LOGGER.debug("Processing jsonFileName={}: recordCnt={}", jsonFileName, arrayList.size());
			var rowNumber = 1;
			int arrayListSize = arrayList.size();
			boolean lastRow = false;
			Iterator<Map<String, Object>> itr = arrayList.iterator();
			while (itr.hasNext()) {
				requestMap = itr.next();
				LOGGER.debug("row={}", requestMap);
				if (rowNumber >= arrayListSize) {
					lastRow = true;
				}
				if (flushRecord(requestMap, csvProcessorTransaction, configSpaceId, fileName, jsonFileName, rowNumber, lastRow, appId)) {
					rowNumber++;
				}
			}
			return true;
		} catch (IOException e) {
			LOGGER.error("Process exception: {}", ExceptionUtils.getStackTrace(e));
			return false;
		}
	}

	protected boolean flushRecord(Map<String, Object> requestMap, CsvProcessorTransaction csvProcessorTransaction, Integer configSpaceId, String fileName,
			String jsonFileName, int rowNumber, boolean lastRecord, String appId) {
		if (requestMap.isEmpty()) {
			return false;
		}

		var documentMetaData = createCsvRecord(requestMap, configSpaceId, appId);
		csvProcessorsService.createCsvProcessorRowTask(csvProcessorTransaction, configSpaceId, fileName, jsonFileName, rowNumber, requestMap.toString(), documentMetaData.getId(), MetaDataStatus.COMPLETE);

		if (rowNumber == 1 && ! lastRecord) {
			LOGGER.debug("Have firstRecord");
			var executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Posted first CSV documents to PRUN", csvProcessorTransaction);
			ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(csvProcessorService, csvProcessorTransaction, executionRecord);
		}
		if (lastRecord) {
			LOGGER.debug("Have lastRecord={}, rowNumber={}", lastRecord, rowNumber);
			var executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Posted " + rowNumber + " CSV documents to PRUN", csvProcessorTransaction);
			ProcessorTaskUtil.updateProcessTransactionWithExecutionRecord(csvProcessorService, csvProcessorTransaction, executionRecord);
		}
		return true;
	}

	protected DocumentMetaData createCsvRecord(Map<String, Object> requestMap, Integer spaceId, String appId) {
		LOGGER.debug("requestMap={}", requestMap);
		Iterator<Map.Entry<String, Object>> iterator = requestMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry<String, Object> entry = iterator.next();
			Object value = entry.getValue();
			if (value.getClass().equals(String.class) && ((String) value).isBlank())
			{
				iterator.remove();
			}
		}
		var documentMetaData = csvProcessorsService.createCsvRecord(spaceId, appId, MetaDataStatus.AVAILABLE, requestMap);
		LOGGER.debug("CSV: createdCsvRecord; id={}", documentMetaData.getId());
		return documentMetaData;
	}

	protected DocumentMetaData createPdoRecord(String request) {
		try {
			Map<String, Object> requestMap = Parser.readValue(request, HashMap.class);
			String tin = (String) requestMap.get(Workflow.TIN);
			String mpin = (String) requestMap.get(Workflow.MPIN);
			String fileName = (String) requestMap.get(Workflow.FILE_NAME);
			String fileType = (String) requestMap.get(Workflow.FILE_TYPE);
			String providerEmailId = (String) requestMap.get(Workflow.PROVIDER_EMAIL_ID);
			String frequency = (String) requestMap.get(Workflow.FREQUENCY);
			String deliveryMethod = (String) requestMap.get(Workflow.DELIVERY_METHOD);
			String okToChangePdoInd = (String) requestMap.get(Workflow.OK_TO_CHANGE_PDO_IND);
			String autoEdelUpdateInd = (String) requestMap.get(Workflow.AUTO_EDEL_UPDATE_IND);
			
			var documentMetaData = csvProcessorsService.createCsvRecord(PDOSpaceId, PDOAppId, tin, mpin, fileName, fileType, providerEmailId, frequency, deliveryMethod,
					okToChangePdoInd, autoEdelUpdateInd, MetaDataStatus.AVAILABLE);
			LOGGER.debug("PDO: createPdoRecord={}", documentMetaData.getId());
			return documentMetaData;
		} catch (IOException e) {
			LOGGER.error("createPdoRecord failed: {}", ExceptionUtils.getStackTrace(e));
		}
		return null;
	}
}
