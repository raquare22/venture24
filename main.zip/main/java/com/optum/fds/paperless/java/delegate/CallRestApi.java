/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2018
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 * *************************************************************
 * Modification History
 * When           Who                 Why
 * March 3 2018    Vinata Gangolli	 Initial version
 ****************************************************************/

package com.optum.fds.paperless.java.delegate;



import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.CsvProcessorsService;

import com.optum.fds.paperless.mongo.jobs.RestApiJob;
import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import com.optum.fds.paperless.util.ApplicationUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;



@Service("CallRestApi")
public class CallRestApi extends OptumJavaDelegateBase {
	private static final Logger LOGGER = LoggerFactory.getLogger(CallRestApi.class);
	@Autowired
	CsvProcessorsService csvProcessorsSvc;

	@Autowired
	CsvProcessorService csvProcessorSvc;

	private RestTemplate restTemplate = new RestTemplate();

	private static final List<String> REQ_VARS = Arrays.asList(Workflow.JOB, Workflow.OAUTH_TOKEN_V1);

	public CallRestApi() {
		super(REQ_VARS);
	}

	public CallRestApi(RestTemplate restTemplate, CsvProcessorsService csvProcessorsSvc,
			CsvProcessorService csvProcessorSvc) {
		super(REQ_VARS);
		this.restTemplate = restTemplate;
		this.csvProcessorsSvc = csvProcessorsSvc;
		this.csvProcessorSvc = csvProcessorSvc;
	}

	public void doExecute(DelegateExecution execContext) {
		LOGGER.debug("CallRestApi-->doExecute-->ENTER");
		if (!validateAndMapRestInput(execContext)) {
			LOGGER.debug("CallRestApi Completed with errors.");
		} else {
			if (execRestApi(execContext)) {
				LOGGER.debug("CallRestApi Completed successfully.");
			} else {
				LOGGER.debug("CallRestApi Completed with errors.");
			}
		}
		convertRestRequestForDbSerialzation(execContext);
		LOGGER.debug("CallRestApi-->doExecute-->EXIT");
	}

	private void convertRestRequestForDbSerialzation(DelegateExecution execContext) {

		Map<String, Object> varsMap = ((Map<String, Object>) execContext.getVariable(Workflow.REST_API_JOB_ATTRS));
		Object request = varsMap.get(Workflow.REST_REQUEST);
		if (ApplicationUtil.isNotNull(request)) {
			varsMap.put(Workflow.REST_REQUEST, varsMap.get(Workflow.REST_REQUEST).toString());
			execContext.setVariable(Workflow.REST_API_JOB_ATTRS, varsMap);
		}
	}

	/**
	 * Method to start execution of the REST API that is requested in the
	 * Activiti Job
	 * 
	 * @param execCtxt
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private boolean execRestApi(DelegateExecution execCtxt) {
		LOGGER.debug("CallRestApi-->execRestApi-->ENTER");
		var result = false;
		var method = ((Map<String, Object>) execCtxt.getVariable(Workflow.REST_API_JOB_ATTRS))
				.get(Workflow.REST_METHOD).toString();
		switch (method) {
		case "POST":
		case "PUT":
			result = doPostOrPut(execCtxt);
			break;
		default:
			addErrorMsg(Workflow.REST_ERROR_MSG,
					String.format("Method %s not supported.", Workflow.UNSUPPORTED_METHOD));
			break;
		}
		LOGGER.debug("CallRestApi-->execRestApi-->EXIT");
		return result;
	}

	/**
	 * Method to perform HTTP POST/PUT transaction
	 * 
	 * @param execCtxt
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private boolean doPostOrPut(DelegateExecution execCtxt) {
		LOGGER.debug("CallRestApi-->doPostOrPut-->ENTER");
		var result = false;
		Map<String, Object> restApiJobAttrs = ((Map<String, Object>) execCtxt.getVariable(Workflow.REST_API_JOB_ATTRS));
		var uri = (URI) restApiJobAttrs.get(Workflow.REST_URI);
		HttpMethod method = (HttpMethod) restApiJobAttrs.get(Workflow.REST_METHOD);
		HttpEntity request = (HttpEntity) restApiJobAttrs.get(Workflow.REST_REQUEST);
		try {
			ResponseEntity<String> sr = restTemplate.exchange(uri, method, request, String.class);
			restApiJobAttrs.put(Workflow.REST_RESPONSE, sr.toString());
			if (!StringUtils.isEmpty(sr.getHeaders().toString()) && sr.getHeaders().get(Workflow.REST_X_TRX_HEADER) != null) {
				restApiJobAttrs.put(Workflow.REST_TRX_ID, sr.getHeaders().get(Workflow.REST_X_TRX_HEADER).get(0));
			}

		} catch (Exception e) {
			LOGGER.error("doPostOrPut {}={} {}",
					"delegateExecutionId", execCtxt.getId(),
					ExceptionUtils.getStackTrace(e));
			restApiJobAttrs.put(Workflow.REST_RESPONSE, e.getMessage());
			restApiJobAttrs.put(Workflow.REST_STATUS, "COMPLETE_WITH_ERRORS");
			addErrorMsg(Workflow.REST_ERROR_MSG, Workflow.REST_HTTP_REQUEST_EXECUTION_ERROR);
			addErrorMsg(Workflow.REST_ERROR_MSG, ExceptionUtils.getStackTrace(e));
		}
		writeCsvProcessorRowTask(execCtxt);
		result = (execCtxt.getVariable(Workflow.ERROR_MAP) == null) ;
		LOGGER.debug("CallRestApi-->doPostOrPut-->EXIT");
		return result;
	}

	/**
	 * Method to validate that the Job being called is of type 'RestApiJob' and
	 * to set a RestApiJobAttributes Map.
	 * 
	 * @return boolean
	 */
	private boolean validateAndMapRestInput(DelegateExecution execCtxt) {
		LOGGER.debug("CallRestApi-->validateAndMapRestInput-->ENTER");
		var result = false;
		execCtxt.setVariable(Workflow.REST_API_JOB_ATTRS, new HashMap<String, Object>());
		Object oJob = execCtxt.getVariable(REQ_VARS.get(0));
		if (RestApiJob.class.isAssignableFrom(oJob.getClass())) {
			result = getRestApiJobMap(execCtxt, (RestApiJob) oJob);
		} else {
			LOGGER.warn("validateAndMapRestInput; delegateExecutionId={}, Object of type {}", execCtxt.getId(), oJob.getClass().getName());
			addErrorMsg(Workflow.REST_ERROR_MSG, Workflow.INVALID_JOB_TYPE);
		}
		LOGGER.debug("CallRestApi-->validateAndMapRestInput-->EXIT");
		return result;
	}

	/**
	 * Method to create a Map of variables being set by RestApiJob
	 * 
	 * @param execCtxt
	 * 
	 * @param rApiJob
	 * @return boolean
	 */
	@SuppressWarnings("unchecked")
	private boolean getRestApiJobMap(DelegateExecution execCtxt, RestApiJob rApiJob) {
		LOGGER.debug("CallRestApi-->getRestApiJobMap-->ENTER");
		var result = true;
		Map<String, Object> varsMap = ((Map<String, Object>) execCtxt.getVariable(Workflow.REST_API_JOB_ATTRS));
		varsMap.put(Workflow.REST_URI, rApiJob.getUri());
		varsMap.put(Workflow.REST_SOURCE_ID, rApiJob.getSourceType());
		varsMap.put(Workflow.REST_TRX_ID, rApiJob.getTransactionId());
		varsMap.put(Workflow.REST_CONFIG_SPACE_ID, rApiJob.getSpaceId());
		varsMap.put(Workflow.REST_CLIENT_ID, rApiJob.getClientId());
		varsMap.put(Workflow.REST_APP_IDENTIFIER, rApiJob.getAppIdentifier());
		varsMap.put(Workflow.REST_VERSION, "1");
		varsMap.put(Workflow.REST_CSV_FILE_NAME, rApiJob.getCsvFileName());
		varsMap.put(Workflow.REST_JSON_FILE_NAME, rApiJob.getJsonFileName());
		varsMap.put(Workflow.REST_TARGET_TYPE, rApiJob.getTargetType());
		varsMap.put(Workflow.REST_DB_STATUS_OBJ_ID, rApiJob.getDbStatusObjectId());

		String[] reqdAttrs = { Workflow.REST_METHOD, Workflow.REST_REQUEST, Workflow.REST_URI };
		for (var i = 0; i < reqdAttrs.length; i++) {
			if (varsMap.get(reqdAttrs[i]) == null) {
				addErrorMsg(Workflow.REST_ERROR_MSG, String.format("Null %s", reqdAttrs[i]));
				result = false;
			}
		}
		LOGGER.debug("CallRestApi-->getRestApiJobMap-->EXIT");
		return result;
	}

	/**
	 * Method to write CsvProcessorRowTask to MongoDB->CsvProcessor Collection
	 * 
	 * @param execCtxt
	 */
	@SuppressWarnings("unchecked")
	public void writeCsvProcessorRowTask(DelegateExecution execCtxt) {
		LOGGER.debug("CallRestApi-->writeCsvProcessorRowTask-->ENTER");
		Map<String, Object> restApiJobAttrs = ((Map<String, Object>) execCtxt.getVariable(Workflow.REST_API_JOB_ATTRS));
		var csvProcessorRowTask = csvProcessorSvc.getCsvProcessorRowTask(
				restApiJobAttrs.get(Workflow.REST_DB_STATUS_OBJ_ID).toString(),
				restApiJobAttrs.get(Workflow.REST_APP_IDENTIFIER).toString(),
				restApiJobAttrs.get(Workflow.REST_SERVER_TYPE).toString());
		boolean csvProcessorRowTaskDoesNotExist = (csvProcessorRowTask == null) ;
		if (csvProcessorRowTaskDoesNotExist) {
			addErrorMsg(Workflow.REST_ERROR_MSG, Workflow.REST_CSV_PROCESSOR_ROW_TASK_RECORD_NOT_LOCATED);
			return;
		}
		if (ApplicationUtil.isNotNull(restApiJobAttrs.get(Workflow.REST_APP_IDENTIFIER))) {
			csvProcessorRowTask.setAppIdentifier(restApiJobAttrs.get(Workflow.REST_APP_IDENTIFIER).toString());
		}
		if (ApplicationUtil.isNotNull(restApiJobAttrs.get(Workflow.REST_JSON_FILE_NAME))) {
			csvProcessorRowTask.setJsonFileName(restApiJobAttrs.get(Workflow.REST_JSON_FILE_NAME).toString());
		}
		if (ApplicationUtil.isNotNull(restApiJobAttrs.get(Workflow.REST_CSV_FILE_NAME))) {
			csvProcessorRowTask.setCsvFileName(restApiJobAttrs.get(Workflow.REST_CSV_FILE_NAME).toString());
		}
		if (ApplicationUtil.isNotNull(restApiJobAttrs.get(Workflow.REST_REQUEST))) {
			csvProcessorRowTask.setRequest(restApiJobAttrs.get(Workflow.REST_REQUEST).toString());
		}
		if (ApplicationUtil.isNotNull(restApiJobAttrs.get(Workflow.REST_RESPONSE))) {
			csvProcessorRowTask.setResponse(restApiJobAttrs.get(Workflow.REST_RESPONSE).toString());
		}
		if (ApplicationUtil.isNotNull(restApiJobAttrs.get(Workflow.REST_STATUS))) {
			csvProcessorRowTask.setStatus(restApiJobAttrs.get(Workflow.REST_STATUS).toString());
		}
		if (ApplicationUtil.isNotNull(restApiJobAttrs.get(Workflow.REST_TARGET_ID))) {
			csvProcessorRowTask.setTargetId(restApiJobAttrs.get(Workflow.REST_TARGET_ID).toString());
		}
		if (ApplicationUtil.isNotNull(restApiJobAttrs.get(Workflow.REST_TARGET_TYPE))) {
			csvProcessorRowTask.setTargetType(restApiJobAttrs.get(Workflow.REST_TARGET_TYPE).toString());
		}
		if (ApplicationUtil.isNotNull(restApiJobAttrs.get(Workflow.REST_TRX_ID))) {
			csvProcessorRowTask.setTransactionId(restApiJobAttrs.get(Workflow.REST_TRX_ID).toString());
		}
		csvProcessorRowTask.setProcessorRecordType(ProcessorRecordTypes.csvProcessorRowTask);
		if (ApplicationUtil.isNotNull(restApiJobAttrs.get(Workflow.REST_CONFIG_SPACE_ID))) {
			csvProcessorRowTask.setConfigSpaceId((Integer) (restApiJobAttrs.get(Workflow.REST_CONFIG_SPACE_ID)));
		}
		if (ApplicationUtil.isNotNull(restApiJobAttrs.get(Workflow.REST_CLIENT_ID))) {
			csvProcessorRowTask.setClientId((Integer) (restApiJobAttrs.get(Workflow.REST_CLIENT_ID)));
		}

		try {
			csvProcessorsSvc.createCsvProcessorRowTask(csvProcessorRowTask);
		} catch (Exception e) {
			LOGGER.error("writeCsvProcessorRowTask {}={}, {}={} {}",
					"delegateExecutionId", execCtxt.getId(),
					"csvProcessorRowTaskId", csvProcessorRowTask.getId(),
					ExceptionUtils.getStackTrace(e));
			addErrorMsg(Workflow.REST_ERROR_MSG, Workflow.REST_CSV_PROCESSOR_ROW_TASK_RECORD_NOT_UPDATED);
			addErrorMsg(Workflow.REST_ERROR_MSG, ExceptionUtils.getStackTrace(e));
		}
		LOGGER.debug("CallRestApi-->writeCsvProcessorRowTask-->EXIT");


	}

	/**
	 * Method to extract targetId from Http response Body string
	 * 
	 *
	 * @return
	 */
	private String getTargetIdFromResponseBody(String respBody) {
		LOGGER.debug("CallRestApi-->getTargetIdFromResponseBody-->ENTER");
		var response = Document.parse(respBody);
		LOGGER.debug("CallRestApi-->getTargetIdFromResponseBody-->EXIT");
		return response.get("id", String.class);
	}

	/**
	 * 
	 * @param restApiJob
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	private HttpEntity reconstructRequest(RestApiJob restApiJob, String oauthToken) {
		LOGGER.debug("CallRestApi-->reconstructRequest-->ENTER");

		MultiValueMap<String, String> multiPartMap = new LinkedMultiValueMap<>();
		var headers = new HttpHeaders();
		if (restApiJob.getRequest() == null) {
			return null;
		}
		Map documentBody = (Map) restApiJob.getRequest().getBody();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		headers.set("authorization", "Bearer " + oauthToken);
		LOGGER.debug("CallRestApi-->reconstructRequest-->EXIT");

		return new HttpEntity<>(multiPartMap, headers);

	}

}
