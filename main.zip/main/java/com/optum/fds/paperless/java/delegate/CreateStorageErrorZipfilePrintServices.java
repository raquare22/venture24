package com.optum.fds.paperless.java.delegate;


import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.util.ProcessorTaskUtil;
import com.optum.fds.paperless.workflow.beans.ZipUtilBean;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.ZipUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.eclipse.collections.api.factory.Lists;
import org.eclipse.collections.api.list.MutableList;
import org.eclipse.collections.api.multimap.Multimap;
import org.eclipse.collections.api.tuple.primitive.BooleanObjectPair;
import org.eclipse.collections.impl.tuple.primitive.PrimitiveTuples;
import org.eclipse.collections.impl.utility.LazyIterate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.optum.fds.paperless.workflow.constants.Workflow.*;

@Service("CreateStorageErrorZipfilePrintServices")
public class CreateStorageErrorZipfilePrintServices extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreateStorageErrorZipfilePrintServices.class);

    private static final List<String> REQ_VARS = List.of(
            PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP,
            PRINT_SERVICES_MANIFEST
    );
    private Map<String, String> correlationIDs;

    @Autowired
    private ZipUtil zipUtil;

    private Params params;

    public CreateStorageErrorZipfilePrintServices() {
        super(REQ_VARS);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void doExecute(DelegateExecution execution) {
        LOGGER.debug("CreateStorageErrorZipfilePrintServices-->doExecute-->START");
        try {
        	
        	var targetManifestWorkingDir = execution.getVariable(Workflow.OUTPUT_FILE_DIR_SHUTTERFLY, String.class);
            if (targetManifestWorkingDir == null || targetManifestWorkingDir.isEmpty()) {
            	targetManifestWorkingDir = execution.getVariable(OUTPUT_FILE_DIR_BOUNCE, String.class);
        	}
            
            var originalCompanionFileName = execution.getVariable(ORIGINAL_COMPANION_FILENAME, String.class);
            var deliveryMethod = execution.getVariable(DELIVERY_METHOD, String.class);
            correlationIDs = (Map<String, String>) execution.getVariable(CORRELATION_IDS);

            var targetManifestFileNameList = (List<String>) execution.getVariable(PRINT_SERVICES_MANIFEST);
            var targetManifestFileNameIterator = targetManifestFileNameList.iterator();
            var listDocumentMetaDataMultiMap = (Multimap<String, DocumentMetaData>)
                    execution.getVariable(PRINT_SERVICES_MANIFEST_GROUPED_MULTIMAP);
            params = new Params(originalCompanionFileName, targetManifestWorkingDir, deliveryMethod);


            if (!listDocumentMetaDataMultiMap.isEmpty()) {
                for (var entry : listDocumentMetaDataMultiMap.keyMultiValuePairsView()) {

                    var targetManifestFile = targetManifestFileNameIterator.next();
                    boolean isFileNameFDSRePrint = targetManifestFile.startsWith(FDS_RPRNT_APPLICATION_NAME);

                    var listFilesToZip = entry.getTwo()
                            .flatCollect(documentMetaData -> createPdfZipForFdsReprint(documentMetaData, isFileNameFDSRePrint, execution),
                                    Lists.mutable.empty());

                    zipTxtAndPdfFiles(targetManifestFile, listFilesToZip);
                }
            } else {
                String targetManifestFile = targetManifestFileNameIterator.next();
                zipTxtAndPdfFiles(targetManifestFile, Lists.mutable.empty());
            }
            execution.setTransientVariable(SFTP_FILE_LIST, params.zipFileList);
            execution.setTransientVariable(COMPANION_ZIP_FILE_NAME_MESSAGE, String.join(",", params.zipFileNameListForHookExecutionRecord));
        } catch (Exception e) {
            LOGGER.error("doExecute Exception while executing CreateStorageErrorZipfilePrintServices task {}={} {}",
                    "delegateExecutionId", Optional.ofNullable(execution).map(DelegateExecution::getId).orElse("NULL"),
                    ExceptionUtils.getStackTrace(e));
            LOGGER.error("CreateStorageErrorZipfilePrintServices-->doExecute-->Exception while executing CreateStorageErrorZipfilePrintServices task for CorrelationID {} and error:{}",
                    Optional.ofNullable(correlationIDs).map(o -> params.docList.asLazy().collect(o::get).makeString()).orElse(StringUtils.EMPTY), e.getMessage());
            addErrorMsg("CreateStorageErrorZipfilePrintServices-->doExecute-->Exception while executing CreateStorageErrorZipfilePrintServices task", e.getMessage());
            return;
        }
        LOGGER.debug("CreateStorageErrorZipfilePrintServices-->doExecute-->END");
    }

    private void zipTxtAndPdfFiles(String targetManifestFile, MutableList<ZipUtilBean> listFilesToZip) throws IOException {
        String txtFileName = targetManifestFile + TXT_FINAL_EXTENSION;
        String targetManifestWorkingDir = params.targetManifestWorkingDirectory;

        String finalZipFileName;
        String zipFileNameForHookExecutionRecord;
        if (targetManifestFile.startsWith(FDS_RPRNT_APPLICATION_NAME)) {
            // adding txt file to zip
            listFilesToZip.add(ZipUtilBean.from(txtFileName, txtFileName, targetManifestWorkingDir));

            // adding companion file to zip
            var originalCompanionFileName = params.originalCompanionFileName;
            if (StringUtils.isNotBlank(originalCompanionFileName)) {
                String companionFileName = originalCompanionFileName + CMP_FINAL_EXTENSION;
                listFilesToZip.add(ZipUtilBean.from(companionFileName, companionFileName, targetManifestWorkingDir));
            }
            var zipFileName = targetManifestFile + ZIP_FINAL_EXTENSION;
            var uniqueListFilesToZip = listFilesToZip.distinctBy(ZipUtilBean::getFileName);

            // adding all the pdf and txt in zip file
            zipUtil.zipFiles(uniqueListFilesToZip, targetManifestWorkingDir, zipFileName);

            // for RPRNT HookExecutionRecord should display the zip file and not the txt file
            zipFileNameForHookExecutionRecord = targetManifestFile + ZIP_FINAL_EXTENSION;
            finalZipFileName = targetManifestWorkingDir + zipFileName;
        } else {
            // for FDSNoRePrint HookExecutionRecord should display the txt file and not the zip file
            zipFileNameForHookExecutionRecord = targetManifestFile + TXT_FINAL_EXTENSION;

            // for FDSNoRePrint just adding the txt file only
            finalZipFileName = targetManifestWorkingDir + txtFileName;
        }
        params.zipFileNameListForHookExecutionRecord.add(zipFileNameForHookExecutionRecord);
        params.zipFileList.add(finalZipFileName);
    }

    private Iterable<ZipUtilBean> createPdfZipForFdsReprint(DocumentMetaData documentMetaData, boolean isFileNameFDSRePrint, DelegateExecution execution) {
        Iterable<ZipUtilBean> zipUtilBeanStream = Lists.fixedSize.of();
        params.docList.add(documentMetaData.getId());
        var appIdentifier = documentMetaData.getAppIdentifier();
        var targetWorkingDir = documentMetaData.getMetadata().get(DOCUMENT_ABSOLUTE_PATH, String.class);
        var processKey = execution.getVariable(Workflow.PROCESS_KEY, String.class);
        
        if (isFileNameFDSRePrint) {               
            zipUtilBeanStream = LazyIterate.adapt(Arrays.asList(ZipUtilBean.from(documentMetaData.getFileName(), documentMetaData.getFileName(), targetWorkingDir)));
        }
           
        return zipUtilBeanStream;
    }

    static class Params {
        private final MutableList<String> zipFileList;
        private final MutableList<String> zipFileNameListForHookExecutionRecord;
        private final MutableList<String> docList;
        private final String originalCompanionFileName;
        private final String targetManifestWorkingDirectory;
        private final BooleanObjectPair<String> deliveryMethod;

        public Params(String originalCompanionFileName, String targetManifestWorkingDirectory, String deliveryMethod) {
            this.zipFileList = Lists.mutable.empty();
            this.zipFileNameListForHookExecutionRecord = Lists.mutable.empty();
            this.docList = Lists.mutable.empty();
            this.originalCompanionFileName = originalCompanionFileName;
            this.targetManifestWorkingDirectory = targetManifestWorkingDirectory;
            this.deliveryMethod = PrimitiveTuples.pair(DELIVERY_METHOD.equalsIgnoreCase(deliveryMethod), deliveryMethod);
        }
    }
}