package com.optum.fds.paperless.java.delegate;

import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.flowable.engine.delegate.DelegateExecution;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.workflow.constants.Workflow;

@Service("CsvCleanupFilesProcess")
public class CsvCleanupFilesProcess extends OptumJavaDelegateBase {
	@Autowired
	CsvMoveOriginalToArchiveFolder csvMoveOriginalToArchiveFolder;

	@Autowired
	CSVDeleteWorkingDirectory csvDeleteWorkingDirectory;

	private static final Logger LOGGER = LoggerFactory.getLogger(CsvCleanupFilesProcess.class);
	private static final List<String> REQ_VARS = Arrays.asList(Workflow.CSV_PROCESSOR_TRANSACTION);

	public CsvCleanupFilesProcess() {
		super(REQ_VARS);
	}

	@Override
	protected void doExecute(DelegateExecution execution) {
		LOGGER.debug("CsvCleanupFilesProcess-->doExecute-->ENTER");

		var csvProcessorTransaction = execution.getVariable(Workflow.CSV_PROCESSOR_TRANSACTION,
				CsvProcessorTransaction.class);
		
		// add list of csvProcessorTransactionIds to execution bus for reconciliation error message 
		List<String> csvProcessorTransactionIds = List.of(csvProcessorTransaction.getId());
		 execution.setTransientVariable("csvProcessorTransactionIds", csvProcessorTransactionIds);
		
		String location = csvProcessorTransaction.getLocation();
		LOGGER.debug("location={}", location);
		if (!Paths.get(location).toFile().exists()) {
			LOGGER.debug("CsvCleanupFilesProcess-->doExecute-->EXIT; File does not exist no work to do");
			return;
		}
		csvMoveOriginalToArchiveFolder.doExecute(execution);
		csvDeleteWorkingDirectory.doExecute(execution);
		LOGGER.debug("CsvCleanupFilesProcess-->doExecute-->EXIT");
	}
}