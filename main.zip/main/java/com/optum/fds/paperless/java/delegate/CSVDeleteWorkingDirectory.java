package com.optum.fds.paperless.java.delegate;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optum.fds.paperless.domain.service.CsvProcessorService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.workflow.constants.Workflow;


@Service("CSVDeleteWorkingDirectory")
public class CSVDeleteWorkingDirectory extends OptumJavaDelegateBase {

	private static final Logger LOGGER = LoggerFactory.getLogger(CSVDeleteWorkingDirectory.class);
	
	@Autowired
	CsvProcessorService csvProcessorService;
	
	@Autowired
	ErrorMetaDataService errorMetaDataService;
	
	private static final List<String> REQ_VARS = Arrays.asList(
		Workflow.CSV_PROCESSOR_TRANSACTION
	);
	
	public CSVDeleteWorkingDirectory() {
		super(REQ_VARS);
	}
	
	@Override
	protected void doExecute(DelegateExecution execution) {
		LOGGER.debug("CSVDeleteWorkingDirectory-->doExecute-->ENTER");
		CsvProcessorTransaction csvProcessorTransaction = null;
		ProcessorExecutionRecord executionRecord = null;
		Map<String, String> message = new HashMap<>();
		try {
			csvProcessorTransaction = execution.getVariable(Workflow.CSV_PROCESSOR_TRANSACTION, CsvProcessorTransaction.class);
			executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Deleting working directory");
			String outputFileDir = csvProcessorTransaction.getLocation();
			LOGGER.debug("doExecute; delegateExecutionId: {}, outputFileDir: {}", execution.getId(), outputFileDir);
			var fileDir = new File(outputFileDir);
			if (fileDir.exists()) {
				deleteDirectory(fileDir);
				message.put(Workflow.OUTCOME_KEY, "Working directory deleted");
			}
			else {
				message.put(Workflow.OUTCOME_KEY, "Working directory was not present");
			}
		} catch(Exception e) {
			LOGGER.error("doExecute Exception while executing Clean Ingest Task {}={} {}",
				"delegateExecutionId", execution.getId(), ExceptionUtils.getStackTrace(e));
			message.put(Workflow.OUTCOME_KEY, "Exception while deleting working directory");
			message.put(Workflow.ERROR_KEY, e.toString());
			errorMetaDataService.writeToErrorCollection(execution, "CSVDeleteWorkingDirectory --> doExecute: " + e.getMessage());
		} finally {
			////ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(csvProcessorTransaction, executionRecord, message);
			if (csvProcessorService != null)
			{
				csvProcessorService.updateCsvProcessorTransactionMetaData(csvProcessorTransaction);
			}
		}
		LOGGER.debug("CSVDeleteWorkingDirectory-->doExecute-->EXIT");
	}

	void deleteDirectory(File fileDir) throws IOException {
		FileUtils.deleteDirectory(fileDir);
	}


}
