package com.optum.fds.paperless.java.delegate;

import static com.optum.fds.paperless.workflow.constants.Workflow.ACTIVITI_PROCESS_DELEGATE;
import static com.optum.fds.paperless.workflow.constants.Workflow.APP_ID;
import static com.optum.fds.paperless.workflow.constants.Workflow.CLOUD_CLIENT_ID;
import static com.optum.fds.paperless.workflow.constants.Workflow.CLOUD_CLIENT_SECRET;
import static com.optum.fds.paperless.workflow.constants.Workflow.CLOUD_GRANT_TYPE;
import static com.optum.fds.paperless.workflow.constants.Workflow.CORRELATION_IDS;
import static com.optum.fds.paperless.workflow.constants.Workflow.DATE_EMAIL_SENT;
import static com.optum.fds.paperless.workflow.constants.Workflow.DEFAULT_FILE_SEPARATOR;
import static com.optum.fds.paperless.workflow.constants.Workflow.DOCUMENT;
import static com.optum.fds.paperless.workflow.constants.Workflow.DOCUMENTS_COLLECTION;
import static com.optum.fds.paperless.workflow.constants.Workflow.DOCUMENT_ABSOLUTE_PATH;
import static com.optum.fds.paperless.workflow.constants.Workflow.DOCUMENT_STATUS_AVAILABLE;
import static com.optum.fds.paperless.workflow.constants.Workflow.EFT_IND;
import static com.optum.fds.paperless.workflow.constants.Workflow.EMAIL_ALERT_REQUEST;
import static com.optum.fds.paperless.workflow.constants.Workflow.FDS_CLOUD_AUTH_URL;
import static com.optum.fds.paperless.workflow.constants.Workflow.FDS_CLOUD_GET_ATTACHMENT_URL;
import static com.optum.fds.paperless.workflow.constants.Workflow.LIST_DOCUMENT_METADATA;
import static com.optum.fds.paperless.workflow.constants.Workflow.MAX_DOCUMENTS_OCCURS;
import static com.optum.fds.paperless.workflow.constants.Workflow.MESSAGE_ID;
import static com.optum.fds.paperless.workflow.constants.Workflow.METADATA_SEND_PEN_API_REQUEST;
import static com.optum.fds.paperless.workflow.constants.Workflow.N;
import static com.optum.fds.paperless.workflow.constants.Workflow.OUTPUT_FILE_DIR_BOUNCE;
import static com.optum.fds.paperless.workflow.constants.Workflow.OUTPUT_FILE_DIR_MESSAGE;
import static com.optum.fds.paperless.workflow.constants.Workflow.PROCESSOR_FILE_TASK_ID;
import static com.optum.fds.paperless.workflow.constants.Workflow.PROVIDER_EMAIL_ID;
import static com.optum.fds.paperless.workflow.constants.Workflow.REPRNT_SENT_TO_SHUTTERFLY;
import static com.optum.fds.paperless.workflow.constants.Workflow.SEND_EMAIL_NOTIFICATIONS;
import static com.optum.fds.paperless.workflow.constants.Workflow.SEND_TO_SHUTTERFLY;
import static com.optum.fds.paperless.workflow.constants.Workflow.SPACE_ID;
import static com.optum.fds.paperless.workflow.constants.Workflow.START_DATE_IN_DAYS;
import static com.optum.fds.paperless.workflow.constants.Workflow.STOP_PROCESSING_KEY;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.optum.fds.paperless.mongo.DocumentAttachmentDoc360;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.util.Strings;
import org.bson.Document;
import org.eclipse.collections.api.factory.Lists;
import org.eclipse.collections.api.list.MutableList;
import org.eclipse.collections.api.tuple.Pair;
import org.eclipse.collections.impl.block.factory.Procedures;
import org.eclipse.collections.impl.tuple.Tuples;
import org.eclipse.collections.impl.utility.LazyIterate;
import org.flowable.engine.delegate.DelegateExecution;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.util.RetryUtil;
import com.optum.fds.paperless.util.SanitizeUtil;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.HookTransactionUtil;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

@Service("IdentifyDocuments")
public class IdentifyDocuments extends OptumJavaDelegateBase {
    private static final String DATE_FORMAT = "yyyyMMddHHmmssSSS";
	private static final Logger LOGGER = LoggerFactory.getLogger(IdentifyDocuments.class);
	private static final Integer LIST_DOCUMENTS_DEFAULT_START = 0;
	private static final String IND_835 = "Ind_835";
    public static final String DOC_360 = "doc360";
    public static final String EMAIL_BOUNCED = "email bounced";

    @Value("${INGEST_ROOT}")
	private String ingestRoot;

	@Value("${skipEFT_spaceIds}")
	protected List<Integer> skipEFT_spaceIds;

	@Value("${skipEFT_categories}")
	protected List<String> skipEFT_categories;

	@Value("${checkInd_835_spaceIds}")
	protected List<Integer> checkInd_835_spaceIds;

	@Value("${checkInd_835_ExcludedCategories}")
	protected List<String> checkInd_835_ExcludedCategories;

	@Autowired
	private DocumentMetaDataService documentMetaDataService;

	@Autowired
	private ProcessorService processorService;
	
	@Autowired
	private ConfigData config;

	private static final String PROCESS_KEY = "bouncedProviderEmailAddressProcess";

	private static final List<String> REQ_VARS = List.of(
			APP_ID,
			SPACE_ID,
			DOCUMENT,
			START_DATE_IN_DAYS,
			FDS_CLOUD_GET_ATTACHMENT_URL,
			FDS_CLOUD_AUTH_URL,
			CLOUD_CLIENT_ID,
			CLOUD_CLIENT_SECRET,
			CLOUD_GRANT_TYPE,
			MAX_DOCUMENTS_OCCURS
	);
	
	@Value("${IHR_SPACEID_LIST}")
	private List<String> ihrSpaceIdList;
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private OauthManagerUtil oauthManagerUtil;
	@Autowired
	private RetryUtil retryUtil;
	@Autowired
	HookService hookService;

	public IdentifyDocuments() {
		super(REQ_VARS);
	}

	@Override
	public void doExecute(DelegateExecution execution) {

		LOGGER.debug("IdentifyDocuments-->doExecute-->START");
        List<String> documentIds = new ArrayList<>();
		Map<String, String> correlationIDs = new HashMap<>();
		var docId = StringUtils.EMPTY;
		try {
			var spaceId = execution.getVariable(SPACE_ID, String.class);
			String hookId = execution.getVariable(Workflow.HOOK_ID, String.class);
			Integer clientId = execution.getVariable(Workflow.CLIENT_ID, Integer.class);
			String cloudClientId = execution.getVariable(CLOUD_CLIENT_ID, String.class);
			var appId = execution.getVariable(APP_ID, String.class);
			var maxDocumentsOccurs = execution.getVariable(MAX_DOCUMENTS_OCCURS, Integer.class);
//			var bounceEmailCheckEFTIND = Boolean.parseBoolean(String.valueOf(execution.getVariable(BOUNCE_EMAIL_CHECK_EFT_IND)));
			var documentMetaDataObject = execution.getVariable(DOCUMENT, DocumentMetaData.class);
			var url = execution.getVariable(Workflow.FDS_CLOUD_GET_ATTACHMENT_URL, String.class);
			var skipSendToShutterfly = Boolean.parseBoolean(String.valueOf(execution.getVariable(Workflow.SKIP_SEND_TO_SHUTTERFLY)));
			Boolean useDoc360 = execution.getVariable(Workflow.USE_DOC360, Boolean.class);
			Params params = new Params(url);
			
			if(skipSendToShutterfly(documentMetaDataObject, spaceId, appId))
                return;

            var bouncedProviderEmailAddress = getBouncedProviderEmailAddress(documentMetaDataObject);
            var messageId = getMessageId(documentMetaDataObject);
			LOGGER.info("search_window = {}", execution.getVariable(Workflow.SEARCH_WINDOW));
			
			String searchWindow = execution.getVariable(Workflow.SEARCH_WINDOW, String.class);
			Criteria searchWindowCriteria = WorkFlowUtil.getSearchWindowCriteria(searchWindow);

			List<DocumentMetaData> listDocumentMetaDataDB = getDocumentMetaDataListFromDB(searchWindowCriteria, messageId, spaceId, bouncedProviderEmailAddress, maxDocumentsOccurs, execution);

			if (listDocumentMetaDataDB.isEmpty()) {
				LOGGER.info("spaceId= {}, messageId= {}, listDocumentMetaDataDB is empty", spaceId, messageId);
				return;
			}
			
			if (Boolean.TRUE.equals(skipSendToShutterfly)) {
				LOGGER.info("Skipping send to shutterfly, updating documents with eDeliveryError for bounce email docId ={}", documentMetaDataObject.getId());			
				for (DocumentMetaData doc : listDocumentMetaDataDB) {
					WorkFlowUtil.updateEDeliveryError(doc.getMetadata(), EMAIL_BOUNCED);
					documentMetaDataService.saveDocumentMetaData(doc);
				}
				// set bounce email doc status COMPLETE
				documentMetaDataService.updateDocumentMetaDataStatus(documentMetaDataObject.getId(), "COMPLETE");
				setExitNow(execution);
				return;
			}

			LOGGER.info("spaceId= {}, messageId= {}, listDocumentMetaDataDB size = {}", spaceId, messageId, listDocumentMetaDataDB.size());

			// add list of documentIds to execution bus for reconciliation error message 
			List<String> docIds = new ArrayList<String>();
			listDocumentMetaDataDB.forEach(e -> docIds.add(e.getId()));
			LOGGER.info("setting doc status to IN_PROCESS spaceId={}, docIds={}", spaceId, docIds);
			 execution.setTransientVariable("documentIds", docIds);

			// set bounce email doc status IN_PROCESS
			documentMetaDataService.updateDocumentMetaDataStatus(documentMetaDataObject.getId(), "IN_PROCESS");

			// Create Working Directory
			var tempWorkingPath = Utilities.createWorkingDirectoryWithParams(DEFAULT_FILE_SEPARATOR,
					ingestRoot, "bounce", appId, spaceId, getCurrentDateFormattedWithUUIdFormat());
			documentIds = listDocumentMetaDataDB.stream().map(DocumentMetaData::getId).collect(Collectors.toList());
			var hookExecutionMessage = new HashMap<>(Map.of(
					Workflow.UPDATE_DOCUMENT_WITH_API_SUCCESS_MESSAGE, documentIds.toString()
			));
			for (var documentMetaData : listDocumentMetaDataDB) {
				docId =  documentMetaData.getId();
				correlationIDs.putIfAbsent(docId, String.join("_", docId, docId));
				// Handle for UHCWest to check emailAlertReq 'Y', EFT_IND 'Y'.
				if (doesDocSatisfiesCondition(documentMetaData)) {
					LOGGER.info("doc satisfies conditions docId={}", docId);
					var processorFileTask = processorService.getProcessorFileTaskForTargetId(docId, DOCUMENTS_COLLECTION, appId);
					
					String processorTransactionId = null;
					String processorFileTaskId = null;
					
					// for OCM documents processorFileTask is null
					if (processorFileTask != null) {
						processorTransactionId = processorFileTask.getProcessorTransactionId();
						processorFileTaskId = processorFileTask.getId();
					} else {
						processorTransactionId = documentMetaData.getId();
						processorFileTaskId = "";
					}
					
				    var directoryPath = String.join(DEFAULT_FILE_SEPARATOR, tempWorkingPath.toString(), processorTransactionId);
					addDocumentMetaDataIfSatisfied(documentMetaData, processorFileTaskId, directoryPath, execution, params, useDoc360);
					var hookExecutionRecord = new HashMap<>(Map.of(
							Workflow.SPACE_ID, spaceId,
							Workflow.HOOK_ID, hookId,
							Workflow.APP_IDENTIFIER, appId,
							Workflow.CLIENTID, clientId.toString(),
							CLOUD_CLIENT_ID, cloudClientId
					));
					var hookExecutionRecordMetaData = HookTransactionUtil
							.getHookExecutionRecord(hookExecutionRecord, hookExecutionMessage, PROCESS_KEY);
					var hookTransactionMetaData = hookService
							.saveHookTransaction(HookTransactionUtil.createCronHookTransaction(hookExecutionRecordMetaData));
					execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA, hookTransactionMetaData);
				}
			}

			if (params.newListDocumentMetaData.isEmpty()) {
				LOGGER.debug("IdentifyDocuments-->doExecute-->newListDocumentMetaData is null or empty no documents identified to be sent to Printservices; delegateExecutionId={}, spaceId={}", execution.getId(), spaceId);
				var messageKey = execution.getVariable(PROCESS_KEY) + "_message";
				 execution.setTransientVariable(messageKey, "IdentifyDocuments listDocumentMetaDataDB is null or empty no documents identified to be sent to Printservices");
				documentMetaDataService.updateDocumentMetaDataStatus(documentMetaDataObject.getId(), "COMPLETE");
				setExitNow(execution);
				return;
			}
			 execution.setTransientVariable(LIST_DOCUMENT_METADATA, params.newListDocumentMetaData);
			 execution.setTransientVariable(OUTPUT_FILE_DIR_BOUNCE, tempWorkingPath + DEFAULT_FILE_SEPARATOR);
			 execution.setTransientVariable(OUTPUT_FILE_DIR_MESSAGE, tempWorkingPath + DEFAULT_FILE_SEPARATOR);
			 execution.setTransientVariable(CORRELATION_IDS, correlationIDs);
		} catch (Exception e) {
			String documentId = docId;
			LOGGER.error("IdentifyDocuments-->doExecute-->Exception while executing IdentifyDocuments task for CorrelationID {}, exception ={}",
					Optional.of(correlationIDs).map(o -> o.get(documentId)), e);
			addErrorMsg("IdentifyDocuments-->doExecute-->Exception while executing IdentifyDocuments task", WorkFlowUtil.getStackTrace(e));
			return;
		}
		LOGGER.debug("IdentifyDocuments-->doExecute-->END");
	}

    private boolean skipSendToShutterfly(DocumentMetaData documentMetaDataObject, String spaceId, String appId) {
        if (documentMetaDataObject == null) {
            return true;
        }

        var bouncedProviderEmailAddress = getBouncedProviderEmailAddress(documentMetaDataObject);
        if (bouncedProviderEmailAddress == null) {
            return true;
        }

        LOGGER.info("spaceId={}, appId={}, bouncedProviderEmailAddress={}, documentId={}", spaceId, appId, bouncedProviderEmailAddress, documentMetaDataObject != null ? documentMetaDataObject.getId() : "NULL");

        //			var documentsQry = createDocumentQuery(spaceId, bouncedProviderEmailAddress);
        var messageId = getMessageId(documentMetaDataObject);
        return messageId == null;
    }


	private List<DocumentMetaData> getDocumentMetaDataListFromDB(Criteria documentsQry, String messageId, String spaceId, String bouncedProviderEmailAddress, Integer maxDocumentsOccurs, DelegateExecution execution) throws NumberFormatException {

		documentsQry.and(SPACE_ID).is(Integer.parseInt(spaceId))
				.and("status").is("AVAILABLE")
				.and("metadata.prepostEnded").exists(true)
				.and("metadata.eDeliveryError").exists(false);

		if (ihrSpaceIdList.contains(spaceId)) {
			documentsQry.orOperator(Criteria.where("metadata.messageId").regex(messageId), Criteria.where("metadata.providerEmailId").regex(bouncedProviderEmailAddress));
		} else {
			documentsQry.orOperator(Criteria.where("metadata.messageId").is(messageId), Criteria.where("metadata.providerEmailId").is(bouncedProviderEmailAddress));
		}
		
		var listDocumentMetaDataDB = documentMetaDataService.getDocumentMetaDataListWithPagingNew(
				DOCUMENT_STATUS_AVAILABLE, Collections.singletonList(Integer.parseInt(spaceId)), documentsQry, LIST_DOCUMENTS_DEFAULT_START,
				maxDocumentsOccurs);
		LOGGER.debug("IdentifyDocuments-->doExecute-->Documents to print services: spaceId={}, listDocumentMetaDataDB={}", spaceId, listDocumentMetaDataDB);

		if (CollectionUtils.isEmpty(listDocumentMetaDataDB)) {
			LOGGER.debug("IdentifyDocuments-->doExecute-->listDocumentMetaDataDB is null or empty; {}={}, spaceId={}, messageId={}",
					"delegateExecutionId", execution.getId(), spaceId, messageId);
			var messgeKey = execution.getVariable(PROCESS_KEY) + "_message";
			execution.setTransientVariable(messgeKey, "IdentifyDocuments listDocumentMetaDataDB is null or empty");
			setExitNow(execution);
			return Collections.emptyList();
		}
		return listDocumentMetaDataDB;

	}

	private String getMessageId(DocumentMetaData documentMetaDataObject) {
		var messageId = Optional.ofNullable(documentMetaDataObject)
				.map(DocumentMetaData::getMetadata)
				.map(metadata -> metadata.getString(MESSAGE_ID))
				.filter(StringUtils::isNotEmpty)
				.orElse(null);

		if (messageId == null) {
			LOGGER.error("IdentifyDocuments-->doExecute-->Message ID not found in bounced email document");
			addErrorMsg("IdentifyDocuments-->doExecute-->Message ID not found in bounced email document",
					"Message ID not found in bounced email document");

			return null;
		}
		return messageId;
	}

	private String getBouncedProviderEmailAddress(DocumentMetaData documentMetaDataObject) {
		var bouncedProviderEmailAddress = Optional.ofNullable(documentMetaDataObject)
				.map(DocumentMetaData::getMetadata)
				.map(metadata -> metadata.getString(PROVIDER_EMAIL_ID))
				.filter(StringUtils::isNotEmpty)
				.orElse(null);

		if (bouncedProviderEmailAddress == null) {
			LOGGER.error("IdentifyDocuments-->doExecute-->Provider email address not found in bounced email document");
			addErrorMsg("IdentifyDocuments-->doExecute-->Provider email address not found in bounced email document",
					"Provider email address not found in bounced email document");
		}
		return bouncedProviderEmailAddress;
	}


	private void addDocumentMetaDataIfSatisfied(DocumentMetaData documentMetaData, String processorFileTaskId, String tempWorkingPath, DelegateExecution execution, Params params, boolean useDoc360) throws IOException, URISyntaxException {

		var doc = documentMetaData.getMetadata();
		var docId = documentMetaData.getId();
		// Create Document Directory
		var filePath = Utilities.createWorkingDirectoryWithParams(DEFAULT_FILE_SEPARATOR, tempWorkingPath, docId);

		int spaceId = documentMetaData.getSpaceId();
		String fdsDocumentId = documentMetaData.getFdsDocumentId();
		String doc360DocumentId = documentMetaData.getDoc360DocumentId();
		MutableList<Pair<String, byte[]>> responseEntityLazyIterable = null;

		if (checkLoadPDF(doc)) {
            processWithPdfLoad(documentMetaData, processorFileTaskId, execution, params, useDoc360, filePath, doc360DocumentId, fdsDocumentId, spaceId, doc, docId);
        } else {
			updatePENMetadata(doc);
			doc.putIfAbsent(Workflow.SKIP_MANIPULATE_PDF_FILE, true);
			doc.computeIfPresent(SEND_TO_SHUTTERFLY, (x, y) -> true);
			doc.append(REPRNT_SENT_TO_SHUTTERFLY, true);
			WorkFlowUtil.updateEDeliveryError(doc, EMAIL_BOUNCED);
			params.newListDocumentMetaData.add(documentMetaData);
		}
				
	}

    private void processWithPdfLoad(DocumentMetaData documentMetaData, String processorFileTaskId, DelegateExecution execution, Params params, boolean useDoc360, Path filePath, String doc360DocumentId, String fdsDocumentId, int spaceId, Document doc, String docId) {
        MutableList<Pair<String, byte[]>> responseEntityLazyIterable;
        try {
            // downloading attachments/pdfs
            responseEntityLazyIterable = LazyIterate.adapt(documentMetaData.getDocumentAttachments())
                    .tap(documentAttachmentMetaData -> LOGGER.debug("IdentifyDocuments-->doExecute-->Getting Attachment"))
                    .collectIf(Objects::nonNull, documentAttachmentMetaData -> {
                        try {
                            return Boolean.TRUE.equals(useDoc360) ? Tuples.pair(filePath + DEFAULT_FILE_SEPARATOR + documentAttachmentMetaData.getName(),
                                    getAttachmentDoc360(doc360DocumentId, execution))
                                    : Tuples.pair(filePath + DEFAULT_FILE_SEPARATOR + documentAttachmentMetaData.getName(),
                                    getAttachment(fdsDocumentId, documentAttachmentMetaData.getAttachmentId(), spaceId, execution, params));
                        } catch (URISyntaxException | InterruptedException e) {
                            if (e instanceof InterruptedException) {
                                Thread.currentThread().interrupt();
                            }
                            LOGGER.error("IdentifyDocuments --> addDocumentMetaDataIfSatisfied e={}", ExceptionUtils.getStackTrace(e));
                            return null;
                        }
                    })
                    .select(pair -> pair.getTwo() != null && pair.getTwo().length > 0, Lists.mutable.empty());

            if (responseEntityLazyIterable.notEmpty()) {

                // writing to local file
                responseEntityLazyIterable.forEach(Procedures.throwing(this::writeToFile));

                updatePENMetadata(doc);
                doc.computeIfPresent(SEND_TO_SHUTTERFLY, (x, y) -> true);
                doc.append(DOCUMENT_ABSOLUTE_PATH, filePath + DEFAULT_FILE_SEPARATOR)
                        .append(PROCESSOR_FILE_TASK_ID, processorFileTaskId)
                        .append(REPRNT_SENT_TO_SHUTTERFLY, true);

                WorkFlowUtil.updateEDeliveryError(doc, EMAIL_BOUNCED);
                params.newListDocumentMetaData.add(documentMetaData);
            }
        }catch (Exception e){
            LOGGER.error("IdentifyDocuments-->addDocumentMetaDataIfSatisfied-->Exception while processing document with id {}, exception ={}, UseDoc360={}",
                    docId, ExceptionUtils.getStackTrace(e), useDoc360);
             addErrorMsg("IdentifyDocuments-->addDocumentMetaDataIfSatisfied-->Exception while processing document with id " + docId, WorkFlowUtil.getStackTrace(e));
        }
    }

    private void updatePENMetadata(Document doc) {
		var sendEmailNotifications = doc.getBoolean(SEND_EMAIL_NOTIFICATIONS, false);
		var sendPENAPIRequest = doc.getBoolean(METADATA_SEND_PEN_API_REQUEST, false);
		var dateEmailSent = doc.get(DATE_EMAIL_SENT);
		if (!sendEmailNotifications || dateEmailSent == null) {
			doc.append(SEND_EMAIL_NOTIFICATIONS, true)
					.append(DATE_EMAIL_SENT, getCurrentDate());
		}
	}

	private void writeToFile(Pair<String, byte[]> pair) {
		try {
			try (OutputStream output = new BufferedOutputStream(Files.newOutputStream(Paths.get(pair.getOne())))) {
				IOUtils.write(pair.getTwo(), output);
			}
		} catch (IOException e) {
			LOGGER.error("IdentifyDocuments-->writeToFile-->Error={}", ExceptionUtils.getStackTrace(e));
		}
	}
	
	
	protected boolean checkLoadPDF(Document metadata) {
		var loadPDF = false;
		boolean isPostCard = true;
		if (BooleanUtils.isTrue(metadata.getBoolean(Workflow.POST_CARD_IND)) ) {
			if (Strings.isBlank(metadata.getString(Workflow.PROV_CORP_MPIN)) ){
				loadPDF = true;
				isPostCard = false;
			}
		} else {
				loadPDF = true;
				isPostCard = false;
		}
		metadata.put(Workflow.IS_POST_CARD, isPostCard);
		LOGGER.info("loadPDF={} and isPostCard={} for pdf={}", loadPDF, isPostCard, metadata.getString(Workflow.FILE_NAME));
		return loadPDF;
	}

	protected boolean doesDocSatisfiesCondition(DocumentMetaData document) {
		Document doc = document.getMetadata();
		Predicate<Document> isEmailAlertReqY = docm -> !N.equals(docm.get(EMAIL_ALERT_REQUEST)); 
		
		Predicate<Document> isStopProcessingNullOrFalse = docm -> Boolean.FALSE.equals(doc.getOrDefault(STOP_PROCESSING_KEY, false)); 
		
		LOGGER.info("docId={}, emailAlertReq={}, isStopProcessingNullOrFalse={}", document.getId(),
				document.getMetadata().get(EMAIL_ALERT_REQUEST), document.getMetadata().get(STOP_PROCESSING_KEY));
		
		// IF PRA document, only sendToShutterfly when Ind_835 = N or EFT_Ind = Y
		if (skipEFT_spaceIds != null && skipEFT_spaceIds.contains(document.getSpaceId())) {
			Predicate<Document> isEftIndNullOrN = docm -> N.equalsIgnoreCase((String)docm.getOrDefault(EFT_IND, N));
			LOGGER.info("EFT check for docid={}, EFT_IND={}", document.getId(), document.getMetadata().get(EFT_IND));
			return isEmailAlertReqY.and(isEftIndNullOrN).and(isStopProcessingNullOrFalse).test(doc);
		}

		if (checkInd_835_spaceIds != null && checkInd_835_spaceIds.contains(document.getSpaceId())) {				
			Predicate<Document> isInd835NullOrN = docm -> N.equalsIgnoreCase((String) doc.getOrDefault(Workflow.IND_835, N)); // true
			LOGGER.info("Ind 835 check for docId={}, IND_835={}", document.getId(), document.getMetadata().get(IND_835));
			return isEmailAlertReqY.and(isInd835NullOrN).and(isStopProcessingNullOrFalse).test(doc);
		}
		
		return isEmailAlertReqY.and(isStopProcessingNullOrFalse).test(doc);
	}

	private String getCurrentDate() {
		var now = LocalDateTime.now();
		var formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		return now.format(formatter);
	}

	private String getCurrentDateFormattedWithUUIdFormat() {
		var now = LocalDateTime.now();
		var formatter = DateTimeFormatter.ofPattern(IdentifyDocuments.DATE_FORMAT);
		return now.format(formatter) + UUID.randomUUID();
	}

	private boolean wasDocumentSentToPrintServicesBefore(ProcessorFileTask processorFileTask, String bouncedProviderEmailAddress) {
	    return LazyIterate.adapt(processorFileTask.getProcessorExecutionRecordList())
				.select(executionRecord -> Optional.ofNullable(executionRecord.getActivitiProcessKey()).filter(ACTIVITI_PROCESS_DELEGATE::equals).isPresent())
				.flatCollect(executionRecord -> Optional.ofNullable(executionRecord.getMessageList()).orElseGet(Collections::emptyList))
				.collectIf(Objects::nonNull, x -> x.get(PROVIDER_EMAIL_ID))
				.anySatisfy(bouncedProviderEmailAddress::equals);
	}
	
	private byte[] getAttachment(String fdsDocumentId, String attachmentId, int spaceId, DelegateExecution execution, Params params) throws URISyntaxException, InterruptedException {
		
		String fdsCloudOauthUrl = (String) execution.getVariable(Workflow.FDS_CLOUD_AUTH_URL);
		String clientId = (String) execution.getVariable(Workflow.CLOUD_CLIENT_ID);
		String clientSecret = (String) execution.getVariable(Workflow.CLOUD_CLIENT_SECRET);
		String grantType = (String) execution.getVariable(Workflow.CLOUD_GRANT_TYPE);
		
		String token = oauthManagerUtil.getOauthToken("tokenFDSCloudPrun", clientId, clientSecret, grantType, fdsCloudOauthUrl, false, null);
		
//		var token = getOauthToken(false);
		
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.set("fds-authorization", token);
		HttpEntity<?> entity = new HttpEntity<>(headers);
		
		String fdsCloudSpaceId = (String) config.getCredentials(spaceId).get("fdsCloudSpaceId");
		
		Map<String, String> pathParams = new HashMap<>();
		pathParams.put("spaceId", fdsCloudSpaceId);
		pathParams.put("documentId", fdsDocumentId);
		pathParams.put("attachmentId", attachmentId);
		
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(params.url);

		URI uri = uriBuilder.buildAndExpand(pathParams).encode().toUri();
		
		ResponseEntity<DocumentAttachmentMetaData> response;
		
		long startTime = System.nanoTime();
		try {
			response = restTemplate.exchange(uri, HttpMethod.GET, entity, DocumentAttachmentMetaData.class);
			long latency = (System.nanoTime() - startTime) / 1000000;
			
			LOGGER.info("getFDSCloudDocumentAttachment fdsCloudDocumentId={}, Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
					fdsDocumentId, Encode.forJava(params.url), HttpMethod.GET.toString(), response.getStatusCode().value(), latency );
			
			
		} catch (HttpStatusCodeException e) {
			long latency = (System.nanoTime() - startTime) / 1000000;
			LOGGER.error("getFDSCloudDocumentAttachment HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, fdsCloudDocumentId={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
					fdsDocumentId, Encode.forJava(params.url), HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );			
			
			String newAccessToken = oauthManagerUtil.getOauthToken("tokenFDSCloudPrun", clientId, clientSecret, grantType, fdsCloudOauthUrl, true, null);
			
			response = retryUtil.retryFDSCloudCall(uri, newAccessToken, restTemplate);
		} catch (Exception e) {
			LOGGER.error("getFDSCloudDocumentAttachment Exception Consumer=fds.paperless, ServiceName=fds.cloud, fdsCloudDocumentId={}, err={}", 
					fdsDocumentId, ExceptionUtils.getStackTrace(e) );			
			response = null;
		}
		
		DocumentAttachmentMetaData attachment = response != null ? response.getBody() : null;
		
		if (attachment == null) {
			throw new URISyntaxException("attachment", "null");
		}
		String attachmentUrl = attachment.getUrl();
		String attachmentUrlToken = attachment.getUrlToken();
		var attachmentHeaders = new HttpHeaders();
		attachmentHeaders.set("Authorization", attachmentUrlToken);
		HttpEntity<?> attachmentEntity = new HttpEntity<>(attachmentHeaders);
		
		ResponseEntity<byte[]> attachmentResponse = null;
		
		startTime = System.nanoTime();
		try {
			attachmentResponse = restTemplate.exchange(new URI(Encode.forJava(attachmentUrl)), HttpMethod.GET, attachmentEntity, byte[].class);
			long latency = (System.nanoTime() - startTime) / 1000000;
			
			LOGGER.info("downloadFDSCloudDocumentAttachment fdsCloudDocumentId={}, Consumer=fds.paperless, ServiceName=fds.cloud, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
					fdsDocumentId, HttpMethod.GET.toString(), attachmentResponse.getStatusCode().value(), latency );
			
		} catch (HttpStatusCodeException e) {
			long latency = (System.nanoTime() - startTime) / 1000000;
			LOGGER.error("downloadFDSCloudDocumentAttachment HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, fdsCloudDocumentId={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
					fdsDocumentId, HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );			
			
			attachmentResponse = retryUtil.retryGetAttachment(SanitizeUtil.sanitizeAttachmentURL(uri), attachmentUrlToken, restTemplate);
			
		} catch (Exception e) {
			LOGGER.error("downloadFDSCloudDocumentAttachment Exception Consumer=fds.paperless, ServiceName=fds.cloud, fdsCloudDocumentId={}, err={}", 
					fdsDocumentId, ExceptionUtils.getStackTrace(e) );
		}

		if (attachmentResponse == null || attachmentResponse.getBody() == null) {
			LOGGER.warn("downloadFDSCloudDocumentAttachment returned no attachment content for fdsCloudDocumentId={}", fdsDocumentId);
			return new byte[0];
		}

		return attachmentResponse.getBody();
	}

/**
 * Retrieves the attachment from Doc360 using the provided document ID and execution context.
 * @param doc360DocumentId The Doc360 document ID
 * @param execution The workflow execution context
 * @return The attachment content as a byte array
 * @throws URISyntaxException if the URI is malformed
 * @throws InterruptedException if the thread is interrupted
 */
	private byte[] getAttachmentDoc360(String doc360DocumentId, DelegateExecution execution) {
		var doc360AppId = execution.getVariable(Workflow.DOC360_APP_ID, String.class);
		var doc360AppSecret = execution.getVariable(Workflow.DOC360_APP_SECRET, String.class);
		var oauthUrl = execution.getVariable(Workflow.DOC360_OAUTH_URL, String.class);
		var doc360GrantType = execution.getVariable(Workflow.GRANT_TYPE, String.class);
		var doc360Scope = execution.getVariable(Workflow.DOC360_SCOPE, String.class);
		var x_upstream_env = execution.getVariable(Workflow.X_UPSTREAM_ENV, String.class);
		String doc360Url = execution.getVariable(Workflow.DOC360_GET_ATTACHMENT_URL, String.class);

		String newToken = oauthManagerUtil.getOauthToken(DOC_360, doc360AppId, doc360AppSecret, doc360GrantType, oauthUrl, false, doc360Scope);
		String newAccessToken = "Bearer " + newToken;
		ResponseEntity<DocumentAttachmentDoc360> response = null;
		try {
			response = getAttachmentDoc360(newAccessToken, doc360Url, doc360DocumentId, x_upstream_env, oauthUrl, doc360AppId, doc360AppSecret, doc360GrantType, doc360Scope);
		}catch (Exception e) {
			LOGGER.error("IdentifyDocuments-->downloadAttachments from Doc360 --> error: {}", ExceptionUtils.getStackTrace(e));
			return null;
		}
		return Objects.requireNonNull(Objects.requireNonNull(response).getBody()).getContentStream();
	}

	private ResponseEntity<DocumentAttachmentDoc360> getAttachmentDoc360(String token, String doc360Url, String doc360DocumentId, String x_upstream_env, String oauthUrl, String clientId, String clientSecret, String grantType, String scope) throws URISyntaxException, InterruptedException {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.set(Workflow.AUTHORIZATION, token);
		headers.set(Workflow.X_UPSTREAM_ENV, x_upstream_env);
		HttpEntity<?> entity = new HttpEntity<>(headers);
		DocumentMetaData documentMetaData = documentMetaDataService.getDocumentMetaData(doc360DocumentId);

		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(doc360Url)
				.pathSegment(doc360DocumentId)
				.queryParam("type-name", documentMetaData.getDoc360DocClass()) //TODO Add to hook-config/vault if needed
				.queryParam("enable-base64-output", true);
		URI uri = uriBuilder.build().encode().toUri();

		ResponseEntity<DocumentAttachmentDoc360> response;

		long startTime = System.nanoTime();
		try {
			response = restTemplate.exchange(uri, HttpMethod.GET, entity, DocumentAttachmentDoc360.class);
			long latency = (System.nanoTime() - startTime) / 1000000;

			LOGGER.info("getDoc360DocumentAttachment Doc360DocumentId={}, Consumer=fds.paperless, ServiceName=Doc360, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}",
					Encode.forJava(doc360DocumentId), Encode.forJava(doc360Url), HttpMethod.GET, response.getStatusCode().value(), latency );


		} catch (HttpClientErrorException e) {
			long latency = (System.nanoTime() - startTime) / 1000000;

			if (e.getStatusCode() == HttpStatus.UNAUTHORIZED) {
				LOGGER.error("getDoc360DocumentAttachment HttpClientErrorException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=Doc360, Doc360DocumentId={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
						Encode.forJava(doc360DocumentId), Encode.forJava(doc360Url), HttpMethod.GET, e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
				String 			newAccessToken = oauthManagerUtil.getOauthToken(DOC_360, clientId, clientSecret, grantType, oauthUrl, true, scope);
				response = retryUtil.retryDoc360Call(uri, newAccessToken, restTemplate, x_upstream_env);
			}
			else {
				LOGGER.error("getDoc360DocumentAttachment HttpClientErrorException Consumer=fds.paperless, ServiceName=Doc360, Doc360DocumentId={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
						Encode.forJava(doc360DocumentId), Encode.forJava(doc360Url), HttpMethod.GET, e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
				return new ResponseEntity<>(e.getStatusCode());
			}
		} catch (HttpServerErrorException e){
			long latency = (System.nanoTime() - startTime) / 1000000;

			if (e.getStatusCode() == HttpStatus.BAD_GATEWAY || e.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
				LOGGER.error("getDoc360DocumentAttachment HttpServerErrorException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=Doc360, Doc360DocumentId={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
						Encode.forJava(doc360DocumentId), Encode.forJava(doc360Url), HttpMethod.GET, e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );

				String newAccessToken = oauthManagerUtil.getOauthToken(DOC_360, clientId, clientSecret, grantType, oauthUrl, true, scope);
				response = retryUtil.retryDoc360Call(uri, newAccessToken, restTemplate, x_upstream_env);
			}
			else {
				LOGGER.error("getDoc360DocumentAttachment HttpServerErrorException Consumer=fds.paperless, ServiceName=Doc360, Doc360DocumentId={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}",
						Encode.forJava(doc360DocumentId), Encode.forJava(doc360Url), HttpMethod.GET, e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
				return new ResponseEntity<>(e.getStatusCode());
			}
		} catch (Exception e) {
			LOGGER.error("getDoc360DocumentAttachment Exception Consumer=fds.paperless, ServiceName=Doc360, Doc360DocumentId={}, err={}",
					Encode.forJava(doc360DocumentId), ExceptionUtils.getStackTrace(e) );
			response = null;
		}
		return response;
	}


	static class Params {
		private final String url;
		private final MutableList<DocumentMetaData> newListDocumentMetaData;
		public Params(String url) {
			this.url = url;
			this.newListDocumentMetaData = Lists.mutable.empty();
		}
	}
}

