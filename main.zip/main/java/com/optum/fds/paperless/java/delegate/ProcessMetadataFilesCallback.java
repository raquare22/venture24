package com.optum.fds.paperless.java.delegate;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorSummary;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.constants.ProcessKeys;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.FilestoreService;
import com.optum.fds.paperless.domain.service.ProcessorFileTaskService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;


import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorError;
import com.optum.fds.paperless.mongo.processors.ProcessorErrorCode;

import com.optum.fds.paperless.util.ProcessorTaskUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;

@Service("ProcessMetadataFilesCallback")
public class ProcessMetadataFilesCallback extends OptumJavaDelegateBase {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessMetadataFilesCallback.class);
	
	
	@Autowired
	ProcessorsService processorsService;
	
	@Autowired
	ProcessorFileTaskService processorFileTaskService;
	
	@Autowired
	DocumentMetaDataService documentMetaDataService;
	
	@Autowired
	ErrorMetaDataService errorMetaDataService;
	
	@Autowired
	FilestoreService filestoreService;
	
	private static final List<String> REQ_VARS = Arrays.asList(
			"appIdentifier",
			"processorFileTaskId",
			"response",
			"prunDocumentId"
	);

	public ProcessMetadataFilesCallback() {
        super(REQ_VARS);
	}
	
	
	@Override
	public void doExecute(DelegateExecution execution) {
		
		execution.setTransientVariable(Workflow.PROCESS_KEY, ProcessKeys.PROCESS_METADATA_CALLBACK_PROCESS_KEY);
		
		String processorFileTaskId = (String) execution.getVariable("processorFileTaskId");
		String prunDocumentId = (String) execution.getVariable("prunDocumentId");
		String appId = (String) execution.getVariable("appIdentifier");
		
		var processorFileTask = processorFileTaskService.getProcessorFileTaskById(processorFileTaskId, appId);
		var prunDocument = documentMetaDataService.getDocumentMetaData(prunDocumentId);
		
		if (processorFileTask == null) {
			LOGGER.error("CALLBACK ProcessMetadataFilesCallback -- doExecute processorFileTask NULL; delegateExecutionId={}, appIdentifier={}, processorFileTaskId={}, prunDocumentId={}", execution.getId(), appId, processorFileTaskId, prunDocumentId);
			return;
		}
		
		if (prunDocument == null) {
			LOGGER.error("CALLBACK ProcessMetadataFilesCallback -- doExecute prunDocument NULL; delegateExecutionId={}, appIdentifier={}, processorFileTaskId={}, prunDocumentId={}", execution.getId(), appId, processorFileTaskId, prunDocumentId);
			return;
		}

		GenericResponse response = (GenericResponse) execution.getVariable("response");
		LOGGER.info("CALLBACK ProcessMetadataFilesCallback: service layer response status code={}, response msg={}, processorFileTaskId={}, documentId={}",
			response.getStatusCode(), response.getStatusMessage(), processorFileTaskId, prunDocumentId);
		
		var getCurrentProcessorFileTaskStatus = processorFileTaskService.getProcessorFileTask(
				processorFileTask.getId(), processorFileTask.getAppIdentifier(), processorFileTask.getServerType());
		
		var executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Updating processorFileTask from callback");
		Map<String, String>message = new HashMap<>();
		
		
		
		
		
		if (response.getStatusCode().equalsIgnoreCase("200") || response.getStatusCode().equalsIgnoreCase("201")) {
			LOGGER.info("CALLBACK ProcessMetadataFilesCallback: Response is 200 or 201, processorFileTaskId={}, documentId={}", processorFileTaskId, prunDocumentId);
			
			var mapper = new ObjectMapper();
			Map<String, Object> documentResponse = (Map<String, Object>) response.getResponse();
			
			
			if(documentResponse.containsKey("globalDocId")) {
				
				prunDocument.setDoc360DocumentId((String)documentResponse.get("globalDocId"));
//				prunDocument.setDoc360DocClass((String)documentResponse.get("indexName"));
				
				
				LOGGER.debug("CALLBACK ProcessMetadataFilesCallback --  doc360 response ={}", documentResponse);
				
				documentMetaDataService.saveDocumentMetaData(prunDocument);
				
				
				processorFileTask.setDoc360DocumentId((String)documentResponse.get("globalDocId"));
				
				
				LOGGER.debug("CALLBACK ProcessMetadataFilesCallback, doc360DocId={}", processorFileTask.getDoc360DocumentId());
				
				if (processorFileTask.getStatus() != MetaDataStatus.COMPLETE_WITH_ERRORS && processorFileTask.getStatus() != MetaDataStatus.SEVERE_ERROR) {
					processorFileTask.setStatus(MetaDataStatus.COMPLETE);
				}
				
				message.put("outcome", "DOC360 response 200, document updated successfully");
				ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask,
						executionRecord, message);
				
			}
			
			else {
			
			// set document
			Object attachmentsMap = documentResponse.get("attachments");
			var fsId = "";
			String fdsDocumentId = (String) documentResponse.get("documentId");
			
			if (!documentResponse.isEmpty() && attachmentsMap != null) {
				List<DocumentAttachmentMetaData> attachments = mapper.convertValue(documentResponse.get("attachments"),  new TypeReference<List<DocumentAttachmentMetaData>>() { });
				fsId = attachments.get(0).getAttachmentId();
				prunDocument.setDocumentAttachments(attachments);
				prunDocument.setFsId(fsId);
				prunDocument.setFdsAttachmentId(fsId);
				prunDocument.setFdsDocumentId(fdsDocumentId);
				LOGGER.debug("CALLBACK ProcessMetadataFilesCallback -- fds response attachments={}", attachments);
				
				documentMetaDataService.saveDocumentMetaData(prunDocument);

			} else {
				LOGGER.error("CALLBACK ProcessMetadataFilesCallback fds response did not contain attachment information, processorFileTaskId={}, response={}", processorFileTaskId, response);
			}

			processorFileTask.setFsId(fsId);
			processorFileTask.setFdsDocumentId(fdsDocumentId);
			processorFileTask.setPostFDSResponse(true);
			
			LOGGER.debug("CALLBACK ProcessMetadataFilesCallback, fdsDocId={}, postFdsResp={}", processorFileTask.getFdsDocumentId(), processorFileTask.isPostFDSResponse());

			if (processorFileTask.getStatus() != MetaDataStatus.COMPLETE_WITH_ERRORS && processorFileTask.getStatus() != MetaDataStatus.SEVERE_ERROR) {
				processorFileTask.setStatus(MetaDataStatus.COMPLETE);
			}

			message.put("outcome", "FDS response 200, document updated successfully");
			ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask,
					executionRecord, message);
		 }
		} else {
			LOGGER.error("CALLBACK ProcessMetadataFilesCallback {}: service layer response is not 200, error; processorFileTaskId={}, documentId={}",
				MetaDataStatus.STORAGE_ERROR, processorFileTaskId, prunDocument.getId());
			
			String[] parts = processorFileTask.getLocation().split("/");
			String s3FilePath = parts[3] + "/" + parts[4] + "/";
			
			prunDocument.setS3FilePath(s3FilePath);
			prunDocument.setFileName(processorFileTask.getFileName());
			prunDocument.setStatus(MetaDataStatus.STORAGE_ERROR);
			documentMetaDataService.saveDocumentMetaData(prunDocument);
//			documentMetaDataService.updateDocumentMetaDataStatus(prunDocument.getId(),MetaDataStatus.STORAGE_ERROR.toString());
			
			// Store pdf in filestore
			filestoreService.insertFile(processorFileTask.getLocation(), processorFileTask.getFileName());
			
			processorFileTask.setPostFDSResponse(false);
			processorFileTask.setStatus(MetaDataStatus.FATAL_ERROR);
			LOGGER.info("ProcessFileTask-->status = {}", MetaDataStatus.FATAL_ERROR);
			LOGGER.error("sendDocumentToFDS/sendDocumentToDoc360 Error out for ID={}, pdf={}, documentId={}", processorFileTask.getId(), processorFileTask.getFileName(), prunDocument.getId());
			if (processorFileTask.getSummary() == null) {
				processorFileTask.setSummary(new ProcessorSummary());
			}
			processorFileTask.getSummary().addError(new ProcessorError(ProcessorErrorCode.STORAGE_ERROR));
			message.put("outcome", "FDS/DOC360 returned error response, document updated successfully");
			ProcessorTaskUtil.updateProcessFileTaskWithExecutionRecord(processorFileTaskService, processorFileTask,
					executionRecord, message);
		}
	}
}
