package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.mongo.*;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.security.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static com.optum.fds.paperless.workflow.constants.Workflow.XML_FINAL_EXTENSION;

@Service("GenerateDataFileForELGS")
public class GenerateDataFileForELGS extends OptumJavaDelegateBase {

    private static final String BATCHREQUEST_TXGC = "BatchRequest_TXGC_";
    private static final String DELEGATE_EXECUTION_ID= "delegateExecutionId";
    private static final String MF_FILE_EXTENSION = ".MF";
    private static final String METADATA_PREFIX = "metadata.";

    private static final Logger LOGGER = LoggerFactory.getLogger(GenerateDataFileForELGS.class);


    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("GenerateDataFileForELGS-->doExecute-->ENTER");

        String templateName = execution.getVariable(Workflow.TEMPLATE_NAME, String.class);
        String tempWorkingPath = execution.getVariable(Workflow.OUTPUT_FILE_DIR, String.class);
        List<DocumentMetaData> documentMetaDataList = execution.getVariable("updatedDocumentMetadataList", List.class);

        String batchRequestString = null;
        List<String> elgsFileList = new ArrayList<>();
        List<String> docResponseStringList = new ArrayList<>();
        
        List<String> documentUpdateList = new ArrayList<>();
        
        Map<String, Object> successUpdateMap = new HashMap<>(Map.of(
    			METADATA_PREFIX + "addedToBatchFile", true
    	));


        try {
        	batchRequestString = TemplateFactory.getInstance(templateName).convertWithTemplate(documentMetaDataList);

        } catch (Exception e) {
            LOGGER.error("doExecute GenerateDataFileForELGS exception {}", ExceptionUtils.getStackTrace(e));
        }

        docResponseStringList.add(batchRequestString);
        String fileName = getFileName(tempWorkingPath);
        String xmlFileName = fileName + XML_FINAL_EXTENSION;
        String mfFileName = fileName + MF_FILE_EXTENSION;
        File responseFile = null;
        File mfFile = null;

        try {
            responseFile = WorkFlowUtil.generateFileFromString(batchRequestString, xmlFileName);
            mfFile = WorkFlowUtil.generateFileFromString("done", mfFileName);

            elgsFileList.add(responseFile.getAbsolutePath());
            elgsFileList.add(mfFile.getAbsolutePath());
            
            
        } catch (Exception e) {
            LOGGER.error("doExecute Error creating ELGS-TXGC BatchRequest file {}={},{}",
                    DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
                    ExceptionUtils.getStackTrace(e));
        }
        
        for (DocumentMetaData doc : documentMetaDataList) {
        	documentUpdateList.add(doc.getId());
        }
        
        
        LOGGER.info("elgsFileList={}", elgsFileList);
        
        execution.setTransientVariable("successDocumentList", documentUpdateList);
        execution.setTransientVariable("successUpdateMap", successUpdateMap);
        
        execution.setVariable("elgsFileList", elgsFileList);
        execution.setVariable("documentMetaDataListStr", docResponseStringList);
        execution.setTransientVariable(Workflow.SFTP_FILE_LIST, elgsFileList);
    }

    public String getFileName(String tempWorkingPath){
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        return tempWorkingPath + File.separator + BATCHREQUEST_TXGC + now.format(formatter);
    }
    private String getDelegateExecutionId(DelegateExecution execution) {
        return execution != null ? execution.getId() : "NULL";
    }

}