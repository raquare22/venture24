package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.io.FileUtils;
import org.apache.tika.utils.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;


@Service("CleanIngestFiles")
public class CleanIngestFiles extends OptumJavaDelegateBase {

    private static final Logger LOGGER = LoggerFactory.getLogger(CleanIngestFiles.class);

    private static final List<String> REQ_VARS = List.of();

    public CleanIngestFiles() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("CleanIngestTask-->doExecute-->Start");
        
        var outputFileDir = "";
        
        try {            
        	outputFileDir = execution.getVariable(Workflow.OUTPUT_FILE_DIR, String.class);
        	if (outputFileDir != null && !outputFileDir.isEmpty()) {
        		LOGGER.debug("CleanIngestTask-->doExecute-->outputFileDir: {}", outputFileDir);
                deleteDirectory(outputFileDir, execution);
        	}
        	
        	outputFileDir = execution.getVariable(Workflow.OUTPUT_FILE_DIR_SHUTTERFLY, String.class);
        	if (outputFileDir != null && !outputFileDir.isEmpty()) {
        		LOGGER.debug("CleanIngestTask-->doExecute-->outputFileDirShutterfly: {}", outputFileDir);
                deleteDirectory(outputFileDir, execution);
        	}
        	
        	outputFileDir = execution.getVariable(Workflow.OUTPUT_FILE_DIR_BOUNCE, String.class);
        	if (outputFileDir != null && !outputFileDir.isEmpty()) {
        		LOGGER.debug("CleanIngestTask-->doExecute-->outputFileDirBounce: {}", outputFileDir);
                deleteDirectory(outputFileDir, execution);
        	}
        	
            
        } catch (Exception e) {
            LOGGER.error("doExecute Exception while executing Clean Ingest Task for outputFileDir={}, {}={} {}", 
            		outputFileDir, "delegateExecutionId", execution.getId(), ExceptionUtils.getStackTrace(e));
        }

    	LOGGER.debug("CleanIngestTask-->doExecute-->End");
    }

//    void deleteDirectory(File fileDir) throws IOException {
//        FileUtils.deleteDirectory(fileDir);
//    }
    
    void deleteDirectory(String outputFileDir, DelegateExecution execution) {
    	try (Stream<Path> files = Files.walk(Paths.get(outputFileDir)).onClose(() -> {LOGGER.debug("Stream closed");})) {            
            
    	    // delete directory including files and sub-folders
    	    files.sorted(Comparator.reverseOrder())
    	            .forEach((path) -> {
    	            	try {
    	            		LOGGER.info("CleanIngestFiles --> Deleting filepath={}", path);
							Files.delete(path);
						} catch (IOException e) {
							LOGGER.error("doExecute Exception while executing Clean Ingest Task for filePath={}, error={}", 
				            		path, ExceptionUtils.getStackTrace(e));
						}
    	            });
            
        } catch (Exception e) {
            LOGGER.error("doExecute Exception while executing Clean Ingest Task for outputFileDir={}, {}={} {}", 
            		outputFileDir, "delegateExecutionId", execution.getId(), ExceptionUtils.getStackTrace(e));
        }
    }

}