package com.optum.fds.paperless.java.delegate.docvault;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.java.delegate.OptumJavaDelegateBase;
import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;


@Service("UpdateDocumentListDocvault")
public class UpdateDocumentListDocvault extends OptumJavaDelegateBase {
    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateDocumentListDocvault.class);
    private static final List<String> REQ_VARS = List.of();

    Map<String, String> correlationIds;

    @Autowired
    private DocumentMetaDataService documentMetaDataService;

    @Autowired
    private EmailService emailService;

    public UpdateDocumentListDocvault() {
        super(REQ_VARS);
    }

    @SuppressWarnings("unchecked")
    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("UpdateDocumentListDocvault-->doExecute-->ENTER");
        try {
            correlationIds = (Map<String, String>) execution.getVariable(Workflow.CORRELATION_IDS);
            var documentMetaDataList = getDocumentListFromExecutionBus(execution);
            if (CollectionUtils.isEmpty(documentMetaDataList)) {
                LOGGER.error("UpdateDocumentListDocvault-->doExecute-->documentMetaDataList is empty");
                addErrorMsg("NoData", "documentMetaDataList is empty");
                return;
            }

            // for docSendTo flag will be null
            var dataFieldToUpdate = execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, String.class);
            var dataFieldValueToUpdate = execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, Boolean.class);
            updateDocumentsInDocumentMetaDataListIfRequired(documentMetaDataList, dataFieldToUpdate, dataFieldValueToUpdate);

            updateDocumentsWithService(execution, documentMetaDataList);

        } catch (Exception e) {
            LOGGER.error("doExecute Exception while executing UpdateDocumentListDocvault task {}={} {}", "delegateExecutionId", execution.getId(), ExceptionUtils.getStackTrace(e));
            addErrorMsg("UpdateDocumentListDocvault-->doExecute-->Exception while executing UpdateDocumentListDocvault task", WorkFlowUtil.getStackTrace(e));
        } finally {
            if (newErrors()) {
                DelegateUtils.sendErrorNotification(execution, errorMap,
                        DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution), emailService);
            }
        }

        LOGGER.debug("UpdateDocumentListDocvault-->doExecute-->correlationsId: {}", correlationIds);
        LOGGER.debug("UpdateDocumentListDocvault-->doExecute-->EXIT");
    }

    @SuppressWarnings("unchecked")
    List<DocumentMetaData> getDocumentListFromExecutionBus(DelegateExecution execution) throws IOException {
        var listDocumentMetaData = (List<DocumentMetaData>) execution.getVariable(Workflow.LIST_DOCUMENT_METADATA);
        if (CollectionUtils.isEmpty(listDocumentMetaData)) {
            String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
            if (StringUtils.isNotEmpty(jsonFile)) {
                listDocumentMetaData = WorkFlowUtil.readDocumentsFromJsonFile(jsonFile);
            }
        }
        return listDocumentMetaData;
    }

    private void updateDocumentsInDocumentMetaDataListIfRequired(List<DocumentMetaData> documentMetaDataList, String dataFieldToUpdate, Boolean dataFieldValueToUpdate) {
        if (StringUtils.isNotEmpty(dataFieldToUpdate)) {
            Object value = Objects.requireNonNullElse(dataFieldValueToUpdate, true);
            documentMetaDataList.forEach(document -> document.getMetadata().append(dataFieldToUpdate, value));
        }
    }

    void updateDocumentsWithService(DelegateExecution execution, List<DocumentMetaData> documentMetaDataList) {
        List<String> updatedDocuments = new ArrayList<>();
        for (DocumentMetaData documentMetaData : documentMetaDataList) {
            Optional.ofNullable(documentMetaData.getDocumentAttachments()).orElse(List.of()).forEach(x -> x.setSentToDocVault(true));
            String correlationId = Optional.ofNullable(correlationIds).map(o -> o.get(documentMetaData.getId())).orElse(StringUtils.EMPTY);
               var updatedDocumentMetaData = documentMetaDataService.saveDocumentMetaData(documentMetaData);
 
            if (updatedDocumentMetaData != null) {
                updatedDocuments.add(updatedDocumentMetaData.getId());
                LOGGER.debug("UpdateDocumentListDocvault-->updateDocumentsWithApi-->Document {} updated succssefully in mongo db for CorrelationID {}", documentMetaData.getId(), correlationId);
            } else {
                LOGGER.error("UpdateDocumentListDocvault-->updateDocumentsWithApi-->FDS PUT Document failed for the Document {} for CorrelationID {}",
                        documentMetaData.getId(), correlationId);
                addErrorMsg(String.format("UpdateDocumentListDocvault-->doExecute-->FDS PUT Document failed for the Document %s", documentMetaData.getId()),
                        String.format("FDS PUT Document failed for the Document %s", documentMetaData.getId()));
            }
        }
        if (!updatedDocuments.isEmpty()) {
        	 execution.setTransientVariable(Workflow.UPDATE_DOCUMENT_WITH_API_SUCCESS_MESSAGE, String.format("Documents %s updated succssefully in mongo db", updatedDocuments.toString()));
        }
    }

}