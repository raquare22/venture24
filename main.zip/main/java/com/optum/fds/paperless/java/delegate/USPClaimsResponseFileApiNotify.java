package com.optum.fds.paperless.java.delegate;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;


import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.java.delegate.docvault.OutOfRetriesException;
import com.optum.fds.paperless.java.delegate.docvault.RetryOnExceptionHandler;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.util.SanitizeUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;

@Service("USPClaimsResponseFileApiNotify")
public class USPClaimsResponseFileApiNotify extends OptumJavaDelegateBase {


	private static final String TEMPLATENAME="USPClaimsResponseApiNotify";
	
	
	private static final Logger LOGGER = LoggerFactory.getLogger(USPClaimsResponseFileApiNotify.class);
	
	  private static final List<String> REQ_VARS = List.of(
				Workflow.USPCLAIMS_REST_URL,
				Workflow.NOTIFY_API_OAUTH_URL,
				Workflow.NOTIFY_API_CLIENT_ID,
				Workflow.NOTIFY_API_CLIENT_SECRET

		);
	   
	

	@Autowired
	private RestTemplate restTemplate;
    
    @Autowired
	private OauthManagerUtil oauthManagerUtil;
  
	
    public USPClaimsResponseFileApiNotify() {
		super(REQ_VARS);
		
	}

	@Override
	protected void doExecute(DelegateExecution execution) {
		try {
			notify(execution);
		} catch (Exception e) {
			LOGGER.error("msg: {}", e.getMessage());
			setExitNow(execution);
		}
	}

	@SuppressWarnings("unchecked")
	void notify(DelegateExecution execution) throws OutOfRetriesException {

		ArrayList<HashMap<String,Object>> apiNotifyList= execution.getVariable("USPClaimsNotifyList", ArrayList.class); 
		
		String endpoint=  execution.getVariable(Workflow.USPCLAIMS_REST_URL, String.class);
		
		var url = execution.getVariable(Workflow.NOTIFY_API_OAUTH_URL, String.class);
        var clientId = execution.getVariable(Workflow.NOTIFY_API_CLIENT_ID, String.class);
        var clientSecret = execution.getVariable(Workflow.NOTIFY_API_CLIENT_SECRET, String.class);
        
		
		for(HashMap<String,Object> apiNotifyMap : apiNotifyList)
		{
			String token = oauthManagerUtil.getOauthToken("tokenStargate", clientId, clientSecret, "client_credentials", url, false, null);
			var accessToken = "Bearer " + token;

			String jsonNotifyStr = TemplateFactory.getInstance(TEMPLATENAME).convertWithTemplate(apiNotifyMap);
			
			notifyToUSPClaimsWithRetry(endpoint,accessToken,jsonNotifyStr,execution,(String)apiNotifyMap.get("zipFileName")); 
			
			
		}
		

	}

	


	ResponseEntity<String> notifyToUSPClaimsWithRetry(String endpoint, String accessToken, String jsonNotifyStr,
			DelegateExecution execution, String batchId) throws OutOfRetriesException {
		ResponseEntity<String> response = null;

		var numRetries = execution.getVariable(Workflow.NUM_RETRIES, Number.class);
		var timeToWaitMS = execution.getVariable(Workflow.TIME_TO_WAIT, Number.class);
		
		var url = execution.getVariable(Workflow.NOTIFY_API_OAUTH_URL, String.class);
        var clientId = execution.getVariable(Workflow.NOTIFY_API_CLIENT_ID, String.class);
        var clientSecret = execution.getVariable(Workflow.NOTIFY_API_CLIENT_SECRET, String.class);
        

		var retryHandler = new RetryOnExceptionHandler(numRetries, timeToWaitMS);
		String msg;
		while (retryHandler.shouldRetry()) {
			try {
				try {
					if (retryHandler.isRetry()) {
						String newToken = oauthManagerUtil.getOauthToken("tokenStargate", clientId, clientSecret, "client_credentials", url, true, null);
						String newAccessToken = "Bearer " + newToken;
						response = notifyToUSPClaims(endpoint, newAccessToken, jsonNotifyStr);
					} else {
						response = notifyToUSPClaims(endpoint, accessToken, jsonNotifyStr);
					}
					LOGGER.info("Response from mission control {}", Encode.forJava(response.getBody()));
					break;
				} catch (HttpClientErrorException.Unauthorized e) {
					LOGGER.error("HttpClientErrorException Unauthorized for batchId={}, responseBody={}, statusCode={}", batchId, e.getResponseBodyAsString(), e.getStatusCode());
					retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
					retryHandler.exceptionOccurred();
				}catch (HttpClientErrorException e) {
					LOGGER.error("HttpClientErrorException for batchId={}, responseBody={}, statusCode={}", batchId, e.getResponseBodyAsString(), e.getStatusCode());
					return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());					
				} catch (HttpServerErrorException e) {
					if (e instanceof HttpServerErrorException.GatewayTimeout || e instanceof HttpServerErrorException.BadGateway) {
						LOGGER.error("HttpClientErrorException for batchId={}, responseBody={}, statusCode={}", batchId, e.getResponseBodyAsString(), e.getStatusCode());
						retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
						retryHandler.exceptionOccurred();
					}
					else {
						LOGGER.error("{} exception for batchId={}, responseBody={}, statusCode={}", e.getClass().getSimpleName(), batchId, e.getResponseBodyAsString(), e.getStatusCode());
						return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
					}
				} catch (RestClientException e) {
					LOGGER.error("RestClientException for batchId {} and exception {} ", batchId,
							ExceptionUtils.getStackTrace(e));
					retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
					retryHandler.exceptionOccurred();
				}
			} catch (OutOfRetriesException e) {
				msg = String.format(
						"RestClientException to endpoint %s and exhausted %s retries with retry time %s millis",
						endpoint, retryHandler.getNumRetries(), retryHandler.getTimeToWaitMS());
				LOGGER.error(msg);
				addErrorMsg("RestClientException", msg);
				throw new OutOfRetriesException(msg);
			}
		}
		return response;
	}

	ResponseEntity<String> notifyToUSPClaims(String endpoint, String accessToken, String jsonNotifyStr)
			throws RestClientException {
		var headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("accept", "application/json");
		headers.set("Authorization", accessToken);
		HttpEntity<String> request = new HttpEntity<>(jsonNotifyStr, headers);
		
		LOGGER.info("JsonStr={}", jsonNotifyStr);
		LOGGER.info("Sending request to USPClaimsResponseFileApi");
		
		return restTemplate.exchange(endpoint,HttpMethod.POST, request, String.class);
	}


}