package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.java.delegate.docvault.OutOfRetriesException;
import com.optum.fds.paperless.java.delegate.docvault.RetryOnExceptionHandler;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.HttpConstants;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.owasp.encoder.Encode;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("SendEmailRequestToPEN")
public class SendEmailRequestToPEN extends OptumJavaDelegateBase{

    private static final Logger LOGGER = LoggerFactory.getLogger(SendEmailRequestToPEN.class);
    private static String AUTHORIZATION_STRING = "Authorization";

    @Autowired
    RestTemplate restTemplate;
    
    @Autowired
    private OauthManagerUtil oauthManagerUtil;
    
    @Value("${OAUTHENABLED}")
    private String oauthEnabled;

    @Value("${penMultiCloudEnvHeader}")
    private String penMultiCloudEnv;

    private static final List<String> REQ_VARS = Arrays.asList(
            Workflow.PEN_API_URL,
            Workflow.TEMPLATE_NAME,
            Workflow.DOCUMENT_UPDATE_FLAG_VALUE,
            Workflow.DOCUMENT_UPDATE_FLAG_PATH,
            Workflow.MAX_RETRIES,
            Workflow.RETRY_SLEEP_TIME,
            Workflow.JSON_FILE,
            Workflow.OUTPUT_FILE_DIR,
            Workflow.PEN_API_MULTI_CLOUD_URL,
            Workflow.PEN_OAUTH_URL,
            Workflow.PEN_APP_ID,
            Workflow.PEN_APP_SECRET,
            Workflow.PEN_GRANT_TYPE
    );

    private static final String DELEGATE_EXECUTION_ID = "delegateExecutionId";
    private static final String METADATA_PREFIX = "metadata.";

    public SendEmailRequestToPEN() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
       
        try {
            String templateName = execution.getVariable(Workflow.TEMPLATE_NAME, String.class);

            List<DocumentMetaData> documentList = readDocumentsFromJsonFile(execution);
            if (documentList == null) {
                LOGGER.error("doExecute documentList is null {}={}", DELEGATE_EXECUTION_ID, getExecutionId(execution));
                String messageKey = (String) execution.getVariable(Workflow.PROCESS_KEY) + "_message";
                execution.setTransientVariable(messageKey, "documentList is null");
                return;
            }

            // Used to update sendPENAPIRequest=true in next task
            List<String> documentUpdateList = processDocumentList(execution, documentList, templateName);
            if(documentUpdateList.isEmpty()) {
                LOGGER.error("doExecute documentUpdateList is empty {}={}", DELEGATE_EXECUTION_ID, getExecutionId(execution));
                String messageKey = (String) execution.getVariable(Workflow.PROCESS_KEY) + "_message";
                execution.setTransientVariable(messageKey, "documentUpdateList is empty");
                setExitNow(execution);
            }
            else {
                Map<String, Object> successUpdateMap = new HashMap<>(Map.of(
            			METADATA_PREFIX + Workflow.METADATA_SEND_PEN_API_REQUEST, true
            	));

                LOGGER.info("successDocumentList = {}, successUpdateMap = {}", documentUpdateList, successUpdateMap);
                execution.setTransientVariable("successDocumentList", documentUpdateList);
                execution.setTransientVariable("successUpdateMap", successUpdateMap);
                
            }
        } catch (Exception e) {
            LOGGER.error("doExecute {}={} Exception while executing SendEmailRequestToPEN task {}",
                    DELEGATE_EXECUTION_ID, getExecutionId(execution), ExceptionUtils.getStackTrace(e));
        }
        LOGGER.debug("doExecute EXIT {}={}", DELEGATE_EXECUTION_ID, getExecutionId(execution));
    }

    protected List<DocumentMetaData> readDocumentsFromJsonFile(DelegateExecution execution) {
        String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
        try {
            return WorkFlowUtil.readDocumentsFromJsonFile(jsonFile);
        } catch (IOException e) {
            LOGGER.error("readDocumentsFromJsonFile Unable to read documents from JSON File {}={} {}",
                    DELEGATE_EXECUTION_ID, getExecutionId(execution), ExceptionUtils.getStackTrace(e));
            return null;
        }
    }


	protected List<String> processDocumentList(DelegateExecution execution, List<DocumentMetaData> documentList,
			String templateName) {
		LOGGER.info("processDocumentList {}={} Processing documentList.size={}, templateName={}", DELEGATE_EXECUTION_ID,
				getExecutionId(execution), documentList.size(), templateName);
		String documentId;
		Document metadata;
		Boolean metadataUpdateFlagValue;
		var documentSkipCount = 0;
		String penAPIUrl;
		if(oauthEnabled.equals("true")) {
		  penAPIUrl = execution.getVariable(Workflow.PEN_API_MULTI_CLOUD_URL, String.class);
		}
		else {
		penAPIUrl = execution.getVariable(Workflow.PEN_API_URL, String.class);
		}
		
		Boolean updateFlagValue = (Boolean) execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE);
		String updateFlagPath = (String) execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH);
		Number retryCountMax = (Number) execution.getVariable(Workflow.MAX_RETRIES);
		Number threadSleepTime = (Number) execution.getVariable(Workflow.RETRY_SLEEP_TIME);
		List<String> documentUpdateList = new ArrayList<>();
		boolean first = true;
		for (DocumentMetaData document : documentList) {
			try {
				documentId = document.getId();
				metadata = document.getMetadata();
				metadataUpdateFlagValue = (Boolean) metadata.get(updateFlagPath);

                LOGGER.info("retrieved metadata and metadataUpdateFlagValue {} {}", documentId, metadataUpdateFlagValue);

                if (metadataUpdateFlagValue != null
						&& updateFlagValue.booleanValue() == metadataUpdateFlagValue.booleanValue()) {
					// Another delegate picked up the document
					documentSkipCount++;
					LOGGER.warn("processDocumentList Skipping; {}={}, documentId={}, {}={}, documentSkipCount={}",
							DELEGATE_EXECUTION_ID, getExecutionId(execution), documentId, updateFlagPath,
							metadataUpdateFlagValue, documentSkipCount);
					continue;
				}

                LOGGER.info("starting string template process documentId={}", documentId);

				if (first && metadata.get("dayOfWeek") == null) {
					// First entry in list use dayOfWeek to instruct PEN to first check if document already exists to exclude duplicate entry ERRORS
					// This is due to another delegate executing when sendEmailNotifications=N for the entire list has not been traversed by first
					// delegate and sendEmailNotifications has not yet been updated to Y
					metadata.put("dayOfWeek", "X");
					document.setMetadata(metadata);
					first = false;
					LOGGER.info("First element in list set flag for PEN findByDocumentId={}", documentId);
				}

				String jsonDocument = TemplateFactory.getInstance(templateName).convertWithTemplate(document);

                LOGGER.info("finished string template process documentId={}", documentId);

                if (jsonDocument == null) {
					documentSkipCount++;
					LOGGER.error(
							"processDocumentList convertJsonWithTemplate returned empty json string; {}={}, documentId={}, documentSkipCount={}",
							DELEGATE_EXECUTION_ID, getExecutionId(execution), documentId, documentSkipCount);
					continue;
				}

				ResponseEntity<String> response;
				try {
					response = postDocumentWithRetry(execution, penAPIUrl, jsonDocument, document.getId(),
							retryCountMax, threadSleepTime);
				} catch (OutOfRetriesException e) {
					var msg = String.format("documentId=%s, endpoint=%s, retries=%s, retryTime=%s millis",
							document.getId(), penAPIUrl, retryCountMax, threadSleepTime);
					LOGGER.error("postDocumentWithRetry {}={}, {}", DELEGATE_EXECUTION_ID, getExecutionId(execution),
							msg);
					continue;
				}

                HttpStatusCode responseStatus = response.getStatusCode();
				if (responseStatus == HttpStatus.OK || responseStatus == HttpStatus.CREATED) {
					LOGGER.info("processDocumentList {}={}, documentId={}, responseStatus={}",
							DELEGATE_EXECUTION_ID, getExecutionId(execution), documentId, responseStatus);
				} else {
					LOGGER.error("processDocumentList {}={}, documentId={}, responseStatus={}",
							DELEGATE_EXECUTION_ID, getExecutionId(execution), documentId, responseStatus);
					continue;
				}
				documentUpdateList.add(document.getId());
			} catch (Exception e) {
				LOGGER.error("Error to send to PEN for documentId {} {} {} {}", document.getId(),
                        ExceptionUtils.getStackTrace(e), ExceptionUtils.getRootCauseStackTrace(e), e.toString());
			}
		}
		return documentUpdateList;
	}

    protected ResponseEntity<String> postDocumentWithRetry(DelegateExecution execution, String endpoint, String jsonDocument,
                                                           String docId, Number retryCountMax, Number threadSleepTime) throws OutOfRetriesException {
        ResponseEntity<String> response = null;
        var retryHandler = new RetryOnExceptionHandler(retryCountMax, threadSleepTime);
        while (retryHandler.shouldRetry()) {
            try {
                response = postDocument(execution, endpoint, jsonDocument);
                LOGGER.info("postDocumentWithRetry {}={}, documentId={}, statusCode={}", DELEGATE_EXECUTION_ID, getExecutionId(execution), docId, response.getStatusCode());
                break;
            } catch (RestClientException e) {
                LOGGER.error("postDocumentWithRetry {}={}, documentId={}, request={} {}",
                        DELEGATE_EXECUTION_ID, getExecutionId(execution), docId, getRequest(jsonDocument), ExceptionUtils.getStackTrace(e));
                if(ExceptionUtils.getMessage(e).contains("HttpClientErrorException.BadRequest")) {
                    response = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
                    break;
                }

                retryHandler.exceptionOccurred();
            }
        }
        return response;
    }

    protected ResponseEntity<String> postDocument(DelegateExecution execution, String endpoint, String document) throws RestClientException {
        
    	HttpEntity<String> request = null;  
        
        if(oauthEnabled.equals("true")) {
        	
        	UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(endpoint);
        	
        	var penAppId = execution.getVariable(Workflow.PEN_APP_ID, String.class);
            var penAppSecret = execution.getVariable(Workflow.PEN_APP_SECRET, String.class);
            var penOauthUrl = execution.getVariable(Workflow.PEN_OAUTH_URL, String.class);
            var penGrantType = execution.getVariable(Workflow.PEN_GRANT_TYPE, String.class);
            var penScope = execution.getVariable(Workflow.PEN_SCOPE, String.class);
        	
        	String token = oauthManagerUtil.getOauthToken("multiCloudStargateToken", penAppId, penAppSecret, penGrantType, penOauthUrl, true, penScope );
        	String newAccessToken = "Bearer " + token;
        	request = getMultiCloudRequest(document, newAccessToken);
        	LOGGER.info("postDocument {}={}, endpoint={}, request={}", DELEGATE_EXECUTION_ID, getExecutionId(execution), builder.toUriString(), Encode.forJava(request.toString()));
        	return restTemplate.exchange(builder.toUriString(), HttpMethod.POST, request, String.class);
        	
        } else {
            request = getRequest(document);
            LOGGER.info("postDocument {}={}, endpoint={}, request={}", DELEGATE_EXECUTION_ID, getExecutionId(execution), endpoint, Encode.forJava(request.toString()));
            return restTemplate.postForEntity(endpoint, request, String.class);
        }
    }
    
	
    protected HttpEntity<String> getMultiCloudRequest(String document, String token) {
			
		    var headers = new HttpHeaders();
	        headers.set(AUTHORIZATION_STRING, token);
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(HttpConstants.HEADER_ACCEPT, MediaType.APPLICATION_JSON_VALUE);
	        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
	        headers.setConnection("keep-alive");
            headers.set("x-upstream-env", penMultiCloudEnv);
	        return new HttpEntity<>(document, headers);
	}

    protected HttpEntity<String> getRequest(String document) {
        var headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(HttpConstants.HEADER_ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(document, headers);
    }

    protected String getExecutionId(DelegateExecution execution) {
        return execution != null ? execution.getId() : "NULL";
    }
}
