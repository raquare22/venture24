package com.optum.fds.paperless.java.delegate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.java.delegate.docvault.OutOfRetriesException;
import com.optum.fds.paperless.java.delegate.docvault.RetryOnExceptionHandler;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.HttpConstants;
import com.optum.fds.paperless.model.PENRealTimeResponse;
import com.optum.fds.paperless.model.PENRealTimeTemplateResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import com.google.common.util.concurrent.RateLimiter;

import org.apache.commons.lang3.StringUtils;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service("SendDocumentToPENRealTime")
public class SendDocumentToPENRealTime extends OptumJavaDelegateBase{

    private static final Logger LOGGER = LoggerFactory.getLogger(SendDocumentToPENRealTime.class);
    private static String AUTHORIZATION_STRING = "Authorization";

    @Value("${DynamicSpaceIds}")
    private List<String> dynamicMetadataSpaceIdList;

    @Value("${PEN_TPS:5}")
    private int PEN_TPS;

    @Value("${penMultiCloudEnvHeader}")
    private String penMultiCloudEnv;

    @Value("${penBatchMultiCloudUrl}")
    private String penBatchMultiCloudUrl;

    @Value("${penBatchMultiCloudDynamicTemplateUrl}")
    private String penBatchMultiCloudDynamicTemplateUrl;

    @Value("${bounceEmailSpaceId}")
    private Integer bounceEmailSpaceId;

    @Value("${bounceEmailQueryTimeWindow}")
    private Integer bounceEmailQueryTimeWindow;
    
    @Autowired
    private OauthManagerUtil oauthManagerUtil;
    
    @Autowired
    RestTemplate restTemplate;

    @Autowired
    private DocumentMetaDataService documentMetaDataService;

    private static final String DELEGATE_EXECUTION_ID = "delegateExecutionId";
    private static final String METADATA_PREFIX = "metadata.";
    private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    private static final String MISSING_OR_INVALID_DATA = "Missing or invalid data: ";
    private static final String CLIENT_SSBCI = "SSBCI";
    private static final String CLIENT_PCP_MEMBER_REFERRAL = "PCPMEMBERREFERRAL";

    @Override
    protected void doExecute(DelegateExecution execution) {
        RateLimiter rateLimiter = RateLimiter.create(PEN_TPS); 
        try {
            String templateName = "emailRequestToPEN";
            String spaceId = execution.getVariable(Workflow.SPACE_ID).toString();
            boolean isSecondaryEmail = Boolean
                    .parseBoolean(String.valueOf(execution.getVariable(Workflow.IS_SECONDARY_EMAIL, String.class)));
            boolean skipDocumentGrouping = Boolean
                    .parseBoolean(String.valueOf(execution.getVariable(Workflow.SKIP_DOCUMENT_GROUPING, String.class)));
            List<DocumentMetaData> documentList = (dynamicMetadataSpaceIdList.contains(spaceId)? execution.getVariable("uniqueFieldDocumentList", List.class) : execution.getVariable("updatedDocumentMetadataList", List.class));
            documentList = (isSecondaryEmail)?execution.getVariable("uniqueFieldDocumentList", List.class): documentList;
            Map<String, List<String>> uniqueFieldMap =  execution.getVariable("uniqueFieldMap", HashMap.class);

            if (documentList.isEmpty()) {
                LOGGER.error("doExecute documentList is null {}={}", DELEGATE_EXECUTION_ID, getExecutionId(execution));
                String messageKey = (String) execution.getVariable(Workflow.PROCESS_KEY) + "_message";
                execution.setTransientVariable(messageKey, "documentList is null");
                return;
            }

            List<String> documentUpdateList = processDocumentList(execution, documentList, templateName, uniqueFieldMap, rateLimiter, skipDocumentGrouping, isSecondaryEmail);
            if(documentUpdateList.isEmpty()) {
                LOGGER.error("doExecute documentUpdateList is empty {}={}", DELEGATE_EXECUTION_ID, getExecutionId(execution));
                String messageKey = (String) execution.getVariable(Workflow.PROCESS_KEY) + "_message";
                execution.setTransientVariable(messageKey, "documentUpdateList is empty");
                setExitNow(execution);
            }
        } catch (Exception e) {
            LOGGER.error("doExecute {}={} Exception while executing SendEmailRequestToPEN task {}",
                    DELEGATE_EXECUTION_ID, getExecutionId(execution), ExceptionUtils.getStackTrace(e));
        }
        LOGGER.debug("doExecute EXIT {}={}", DELEGATE_EXECUTION_ID, getExecutionId(execution));
    }

    
    private Set<String> checkDuplicateEmails(Set<String> providerEmailsSent, List<String> providerEmailList) {
    	Set<String> cleanedEmailList = new HashSet<>();
    	
    	for (String email : providerEmailList) {
    		if (!providerEmailsSent.contains(email)) {
    			cleanedEmailList.add(email);
    		}
    	}
    	return cleanedEmailList;
    }

    protected List<String> processDocumentList(DelegateExecution execution, List<DocumentMetaData> documentList,
                                               String templateName, Map<String, List<String>> uniqueFieldMap, RateLimiter rateLimiter, boolean skipDocumentGrouping, boolean isSecondaryEmail) {
        LOGGER.info("processDocumentList {}={} Processing documentList.size={}, templateName={}", DELEGATE_EXECUTION_ID,
                getExecutionId(execution), documentList.size(), templateName);
        String documentId;
        Set<String> providerEmailsSent = new HashSet<>();
        var documentSkipCount = 0;
        Number retryCountMax = 3;
        Number threadSleepTime = 500;
        List<String> documentUpdateList = new ArrayList<>();
        String clientName = (String) execution.getVariable(Workflow.CLIENT_NAME);
        for (DocumentMetaData document : documentList) {
            try {
                documentId = document.getId();
                String uniqueFieldForPEN = execution.getVariable(Workflow.UNIQUEFIELDTOGROUPDOCS, String.class);
                String spaceId = Integer.toString(document.getSpaceId());
                
                String jsonDocument = "";
        		String penUrl = "";
                Integer size = 0;
                List<String> ids = new ArrayList<>();

                if (dynamicMetadataSpaceIdList.contains(spaceId)) {
                    if (clientName == null || clientName.isEmpty()) {
                        LOGGER.error("CLIENT_NAME variable is missing in execution context. Skipping document processing.");
                        continue;
                    }


                    if (checkEmailDateForSSBCIOrPCPReferral(clientName, document, execution, documentUpdateList)) {
                        // For SSBCI or PCP referral documents check if the reminder window has elapsed or if the termination window has been exceeded. If true, skip processing this document.
                        continue;
                    }

                    if (clientName.equals("TRACKITADT") || clientName.equals("MNR") || clientName.equals(CLIENT_SSBCI) || clientName.equals(CLIENT_PCP_MEMBER_REFERRAL) || clientName.equals("TRACKIT")) {

                        String uniqueMetadataField = null;
                        uniqueMetadataField = document.getMetadata().getString(uniqueFieldForPEN);

                        // Do not compute or store TinDocumentCount for SSBCI or TrackIt emails
                        if (!skipDocumentGrouping) {
                            size = getNumberOfDocs(uniqueMetadataField, uniqueFieldMap);
                            document.getMetadata().put("TinDocumentCount", size);
                        }

                        // Filter out invalid emails, and duplicates. If no valid emails remain, skip processing this document.
                        List<String> validEmails = validateAndFilterEmails(execution, document, documentId, clientName, skipDocumentGrouping, uniqueFieldForPEN, uniqueFieldMap);
                        if (validEmails == null || validEmails.isEmpty() )
                            continue;

                        // If email is bounce email, then skip sending and just update the document metadata with eDeliveryError and sendEmailNotifications
                        if (validateAndFilterSingleBounceEmail(execution, document, documentId, clientName, uniqueFieldForPEN, skipDocumentGrouping, uniqueFieldMap)) {
                            continue;
                        }

                        jsonDocument = prepareTemplatePayload(document, execution);

                        penUrl = penBatchMultiCloudDynamicTemplateUrl;
                    }
                    if (clientName.equals("AppealsStatus")) {

                        String uniqueMetadataField = document.getMetadata().getString(uniqueFieldForPEN);

                        List<DocumentMetaData> documentMetaDataList = null;
                        try {
                            List<String> docList = uniqueFieldMap.get(uniqueMetadataField);
                            documentMetaDataList = documentMetaDataService.getDocumentMetaDataList(docList);
                        } catch (Exception e) {
                            LOGGER.error("processDocumentList [AppealsStatus] error fetching documentMetaDataList, documentId={}",
                                    documentId, e);
                            continue;
                        }

                        // Filter out invalid emails, duplicates, and bounce emails. If no valid emails remain, skip processing this document.
                        List<String> validEmails = validateAndFilterEmails(execution, document, documentId, clientName, skipDocumentGrouping, uniqueFieldForPEN, uniqueFieldMap);
                        if (validEmails == null || validEmails.isEmpty()) continue;

                        try {
                            jsonDocument = prepareDynamicTemplatePayload(documentMetaDataList, execution);
                        } catch (Exception e) {
                            LOGGER.error("processDocumentList [AppealsStatus] error preparing dynamic template payload, documentId={}",
                                    documentId, e);
                            continue;
                        }
                        penUrl = penBatchMultiCloudDynamicTemplateUrl;
                    }

                } else if (isSecondaryEmail) {
                    // for secondaryEmails we don't need to add any eDeliveryError metadata for invalid emails, we just skip sending to PEN and log a warning
                	List<String> providerEmailList = (List<String>) document.getMetadata().get(Workflow.SECONDARY_PROVIDER_EMAIL_ID);
                    if (providerEmailList == null || providerEmailList.isEmpty()) {
                    	LOGGER.warn("processDocumentList providerEmailList is empty skipping send to PEN, documentId={}", documentId);
                    	continue;
                    }
                    // remove all invalid emails and duplicates from the list
                    Set<String> validEmailsList = providerEmailList.stream()
                            .filter(Utilities::validateProviderEmail)
                            .collect(Collectors.toSet());

            		jsonDocument = prepareSecondaryEmailPayload(document, validEmailsList, execution);
                    penUrl = penBatchMultiCloudDynamicTemplateUrl;
                } else {
                    // Else condition to cover sending emails for IHR, CC etc.
                    List<String> providerEmailList = (List<String>) document.getMetadata().get(Workflow.PROVIDER_EMAIL_ID_LIST);
                    if (providerEmailList == null || providerEmailList.isEmpty()) {
                        LOGGER.warn("processDocumentList providerEmailList is empty skipping send to PEN, documentId={}", documentId);
                        continue;
                    }

                    List<String> validEmailsFormat = providerEmailList.stream()
                            .filter(Utilities::validateProviderEmail)
                            .collect(Collectors.toList());

                    if (validEmailsFormat.isEmpty()) {
                        // only want to update the eDeliveryError for primary emails
                        WorkFlowUtil.updateEDeliveryError(document.getMetadata(), Workflow.PROVIDER_EMAIL_ID);
                        LOGGER.warn("Provider emailId is invalid, skipping send to PEN, documentId={}", documentId);
                        documentMetaDataService.updateDocMetaData(document, document.getId());
                        continue;
                    }

                    // check for duplicates and remove all duplicate emails from the list
                    Set<String> cleanedEmailList = checkDuplicateEmails(providerEmailsSent, validEmailsFormat);
                    if (cleanedEmailList.isEmpty()) {
                        documentSkipCount++;
                        updateDocumentMetaDataForDuplicateEmail(document);
                        LOGGER.warn(
                                "processDocumentList duplicate email found, skipping send to PEN and updating metadata; {}={}, documentId={}, documentSkipCount={}",
                                DELEGATE_EXECUTION_ID, getExecutionId(execution), documentId, documentSkipCount);
                        continue;
                    }

                    // add remaining emails to email sent list
                    providerEmailsSent.addAll(cleanedEmailList);
                    jsonDocument = preparePayload(document, cleanedEmailList, execution);
                    penUrl = penBatchMultiCloudUrl;
                }
                
        		
                if (jsonDocument == null || jsonDocument.isEmpty()) {
                    documentSkipCount++;
                    LOGGER.error(
                            "processDocumentList convertJsonWithTemplate returned empty json string; {}={}, documentId={}, documentSkipCount={}",
                            DELEGATE_EXECUTION_ID, getExecutionId(execution), documentId, documentSkipCount);
                    continue;
                }

                ResponseEntity<String> response;
                
                try {
                    response = postDocumentWithRetry(execution, penUrl, jsonDocument, document.getId(), retryCountMax, threadSleepTime, rateLimiter);
                } catch (OutOfRetriesException e) {
                    var msg = String.format("documentId=%s, endpoint=%s, retries=%s, retryTime=%s millis",
                            document.getId(), penUrl, retryCountMax, threadSleepTime);
                    LOGGER.error("postDocumentWithRetry {}={}, {}", DELEGATE_EXECUTION_ID, getExecutionId(execution),
                            msg);
                    continue;
                }

                HttpStatusCode responseStatus = response.getStatusCode();
                if (responseStatus == HttpStatus.OK || responseStatus == HttpStatus.CREATED) {
                	// Email sent successfully for document, update metadata with sendPENAPIRequest: true, dateEmailSent and sendEmailNotifications
                	
                	ObjectMapper mapper = new ObjectMapper();
                	if(!isSecondaryEmail) {
                        if (dynamicMetadataSpaceIdList.contains(spaceId)) {
                            PENRealTimeTemplateResponse responseBody = mapper.readValue(response.getBody(), PENRealTimeTemplateResponse.class);
                            updateDocument(execution, document, responseBody, uniqueFieldMap, uniqueFieldForPEN, skipDocumentGrouping);
                        } else {
                            PENRealTimeResponse responseBody = mapper.readValue(response.getBody(), PENRealTimeResponse.class);
                            updateDocument(document, responseBody, isSecondaryEmail);
                        }
                    }else{
                        updateSecondaryEmailSentMetadata(document);
                    }

                    LOGGER.info("processDocumentList send to PEN success {}={}, documentId={}, responseStatus={}, response={}",
                            DELEGATE_EXECUTION_ID, Encode.forJava(getExecutionId(execution)), Encode.forJava(documentId), Encode.forJava(String.valueOf(responseStatus)),
                            Encode.forJava(response.getBody()));
                } else {
                    if(!isSecondaryEmail) {
                        // Document failed sending to PEN, update metadata with sendPENAPIRequest: true
                        Document metadata = document.getMetadata();
                        metadata.put(Workflow.METADATA_SEND_PEN_API_REQUEST, true);
                        documentMetaDataService.updateDocMetaData(document, document.getId());
                        LOGGER.error("processDocumentList error sending to PEN {}={}, documentId={}, responseStatus={}, response={}",
                                DELEGATE_EXECUTION_ID, Encode.forJava(getExecutionId(execution)), Encode.forJava(documentId), Encode.forJava(String.valueOf(responseStatus)),
                                Encode.forJava(response.getBody()));
                        continue;
                    }
                }
                documentUpdateList.add(document.getId());
            } catch (Exception e) {
                LOGGER.error("Error to send to PEN for documentId {} {}", Encode.forJava(document.getId()),
                        ExceptionUtils.getStackTrace(e));
            }
        }
        return documentUpdateList;
    }

    /**
     * Checks if given document has providerEmailId that will bounce back by querying the database
     * Return true is bounce email doc is found, false otherwise
     * Only checks for ADT/Trackit email notifications
     * @param execution
     * @param document
     * @param documentId
     * @param clientName
     * @param uniqueFieldForPEN
     * @param skipDocumentGrouping
     * @param uniqueFieldMap
     * @return
     */
    private Boolean validateAndFilterSingleBounceEmail(DelegateExecution execution, DocumentMetaData document, String documentId, String clientName, String uniqueFieldForPEN, Boolean skipDocumentGrouping, Map<String, List<String>> uniqueFieldMap) {
        if (clientName.equals("TRACKITADT") || clientName.equals("MNR")  || clientName.equals("TRACKIT")) {
            String providerEmailId = document.getMetadata().getString(Workflow.PROVIDER_EMAIL_ID);
            if (providerEmailId == null || providerEmailId.isEmpty()) {
                LOGGER.warn("processDocumentList [{}] providerEmailId is empty, skipping send to PEN, documentId={}",
                        clientName, documentId);
                return true;
            }
            if (checkBounceEmail(providerEmailId)) {
                LOGGER.info("processDocumentList [{}] bounce email found, skipping send to PEN, documentId={}, providerEmailId={}",
                        clientName, documentId, providerEmailId);
                // Update bounce email eDeliveryError in all the documents
                Document metadata = document.getMetadata();

                Map<String, Object> updateMap = new HashMap<>();

                updateMap.put(Workflow.METADATA_SEND_EMAIL_NOTIFICATIONS, true);
                updateMap.put(Workflow.METADATA_SEND_PENAPI_REQUEST, true);
                updateMap.put(Workflow.PREPOSTENDED, true);
                String date = new SimpleDateFormat(DATE_TIME_FORMAT).format(new Date());
                updateMap.put(Workflow.METADATA_DATE_EMAIL_SENT, date);

                addEDeliverErrorToUpdateMap(updateMap, "email bounced", metadata);

                updateDocumentsWithUpdateMap(execution, document, uniqueFieldForPEN, skipDocumentGrouping, uniqueFieldMap, updateMap);

                return true;
            }
        }
        return false;
    }

    private void updateDocumentsWithUpdateMap(DelegateExecution execution, DocumentMetaData document, String uniqueFieldForPEN, Boolean skipDocumentGrouping, Map<String, List<String>> uniqueFieldMap, Map<String, Object> updateMap) {
        List<String> sameFieldDocIds = null;
        Set<String> docIdSet = new HashSet<String>();
        Document metadata = document.getMetadata();
        String uniqueFieldValue = metadata.getString(uniqueFieldForPEN);
        if(!skipDocumentGrouping) {
            if (StringUtils.isNotBlank(uniqueFieldValue) && uniqueFieldMap != null && uniqueFieldMap.containsKey(uniqueFieldValue)) {
                sameFieldDocIds = uniqueFieldMap.get(uniqueFieldValue);
            }

            List<String> sameFieldDocIdsFromDb = new ArrayList<>();
            try {
                String documentSearchCriteria = execution.getVariable(Workflow.SEARCH_CRITERIA, String.class);
                String documentSearchWindow = execution.getVariable(Workflow.SEARCH_WINDOW, String.class);
                var documentCriteriaFilter = WorkFlowUtil.getSearchWindowCriteria(documentSearchWindow);

                Criteria uniqueMetadataQuery = Criteria.where(METADATA_PREFIX + uniqueFieldForPEN).is(uniqueFieldValue);

                sameFieldDocIdsFromDb = documentMetaDataService.getDocumentMetaDataIds(documentSearchCriteria, documentCriteriaFilter, uniqueMetadataQuery);
            } catch (Exception e) {
                LOGGER.warn("Error to find other documents with same unique metadata field, documentId={} {}", Encode.forJava(document.getId()),
                        ExceptionUtils.getStackTrace(e));
            }

            if (sameFieldDocIds != null) {
                docIdSet.addAll(sameFieldDocIds);
            }
            docIdSet.addAll(sameFieldDocIdsFromDb);
        }else{
            docIdSet.add(document.getId());
        }
        List<String> finalDocIdList = docIdSet.stream().toList();
        documentMetaDataService.saveDocumentMetaDataMulti(finalDocIdList, updateMap);
    }

    private List<String> validateAndFilterEmails(DelegateExecution execution, DocumentMetaData document, String documentId, String clientName, Boolean skipDocumentGrouping, String uniqueFieldForPEN, Map<String, List<String>> uniqueFieldMap) {

        String providerEmailId = document.getMetadata().getString(Workflow.PROVIDER_EMAIL_ID);

        if (providerEmailId == null || providerEmailId.isEmpty()) {
            LOGGER.warn("processDocumentList [{}] providerEmailId is empty, skipping send to PEN, documentId={}",
                    clientName, documentId);
            return null;
        }

        String[] emailIds = providerEmailId.contains("|") ? providerEmailId.split("\\|") : new String[]{providerEmailId};
        LOGGER.info("processDocumentList [{}] email validation START documentId={}, providerEmailId=[{}]",
                clientName, documentId, providerEmailId);

        List<String> validEmailsFormat = Arrays.stream(emailIds)
                .filter(Utilities::validateProviderEmail)
                .toList();

        if (validEmailsFormat.isEmpty()) {
            // update eDeliveryError for all documents in the map if skipDocumentGrouping is false, else update only for this document
            Map<String, Object> updateMap = new HashMap<>();
            addEDeliverErrorToUpdateMap(updateMap, Workflow.PROVIDER_EMAIL_ID, document.getMetadata());
            updateDocumentsWithUpdateMap(execution, document, uniqueFieldForPEN, skipDocumentGrouping, uniqueFieldMap, updateMap);
            LOGGER.warn("processDocumentList [{}] all emails invalid, skipping send to PEN, documentId={}",
                    clientName, documentId);
            return Collections.emptyList();
        }

        Set<String> validEmailsSet = new HashSet<>(validEmailsFormat);
        List<String> removedEmails = Arrays.stream(emailIds)
                .filter(e -> !validEmailsSet.contains(e))
                .collect(Collectors.toList());

        document.getMetadata().put(Workflow.PROVIDER_EMAIL_ID, String.join("|", validEmailsFormat));
        LOGGER.info("processDocumentList [{}] email validation END documentId={}, validEmails=[{}], removedEmails=[{}]",
                clientName,
                documentId,
                String.join("|", validEmailsFormat),
                String.join("|", removedEmails));

        return validEmailsFormat;
    }

    private void addEDeliverErrorToUpdateMap(Map<String, Object> updateMap, String field, org.bson.Document metadata) {
        String eDeliveryError = metadata.getString(Workflow.E_DELIVERY_ERROR);
        String errorMessage = MISSING_OR_INVALID_DATA + field;
        if (StringUtils.isBlank(eDeliveryError)) {
            updateMap.put(METADATA_PREFIX + Workflow.E_DELIVERY_ERROR, errorMessage);
        } else {
            if (!eDeliveryError.contains(errorMessage)) {
                updateMap.put(METADATA_PREFIX + Workflow.E_DELIVERY_ERROR, eDeliveryError + "|" + errorMessage);
            }
        }
    }


    private boolean checkBounceEmail(String providerEmailId) {
        // Mongodb query to check if email is a bounce email
        // Return true if bounce email doc is found, false otherwise
        DocumentMetaData bounceEmailDoc = documentMetaDataService.getBounceEmailDocumentMetaData(providerEmailId, bounceEmailSpaceId, bounceEmailQueryTimeWindow);
        if (bounceEmailDoc != null) {
            LOGGER.warn("checkBounceEmail bounce email found for providerEmailId={}", providerEmailId);
            return true;
        } else {
            LOGGER.info("checkBounceEmail no bounce email found for providerEmailId={}", providerEmailId);
            return false;
        }
    }

    protected Boolean checkEmailDateForSSBCIOrPCPReferral(String clientName, DocumentMetaData document, DelegateExecution execution, List<String> documentUpdateList) {
        if (!isReferralClient(clientName)) {
            return false;
        }

        DatePair emailDates = extractEmailSentDates(document);
        boolean useBusinessDays = CLIENT_SSBCI.equals(clientName);
        int reminderWindow = getReminderWindow(execution, useBusinessDays);
        int terminationWindowDays = execution.getVariable(Workflow.EMAIL_TERMINATION_WINDOW, Integer.class);

        if (shouldTerminate(emailDates.firstDate(), terminationWindowDays)) {
            terminateEmailSending(document, terminationWindowDays);
            documentUpdateList.add(document.getId());
            return true;
        }

        if (shouldSend(emailDates.lastDate(), reminderWindow, useBusinessDays)) {
            String sendType = emailDates.lastDate() == null ? "initial" : "reminder";
            LOGGER.info("processDocumentList {}={} sending {} email for documentId={}",
                    DELEGATE_EXECUTION_ID, getExecutionId(execution), sendType, document.getId());
            return false;
        }

        LOGGER.info("processDocumentList {}={} skipping {} email for documentId={}, waiting for reminder window",
                DELEGATE_EXECUTION_ID, getExecutionId(execution), clientName, document.getId());
        return true;
    }

    private boolean isReferralClient(String clientName) {
        return CLIENT_SSBCI.equals(clientName) || CLIENT_PCP_MEMBER_REFERRAL.equals(clientName);
    }

    private int getReminderWindow(DelegateExecution execution, boolean useBusinessDays) {
        return useBusinessDays
                ? execution.getVariable(Workflow.NO_OF_BUSINESS_DAYS, Integer.class)
                : execution.getVariable(Workflow.NO_OF_DAYS, Integer.class);
    }

    private boolean shouldTerminate(Date firstEmailSentDate, int terminationWindowDays) {
        return firstEmailSentDate != null && isTerminationWindowExceeded(firstEmailSentDate, terminationWindowDays);
    }

    private boolean shouldSend(Date lastEmailSentDate, int reminderWindow, boolean useBusinessDays) {
        return lastEmailSentDate == null || hasReminderWindowElapsed(lastEmailSentDate, reminderWindow, useBusinessDays);
    }

    private DatePair extractEmailSentDates(DocumentMetaData document) {
        String dateSentStr = null;
        List<String> emailSentDates = null;
        try {
            dateSentStr = document.getMetadata().getString(Workflow.DATE_EMAIL_SENT);
            emailSentDates = document.getMetadata().getList(Workflow.LAST_DATE_EMAIL_SENT_LIST, String.class);
        } catch (Exception e) {
            LOGGER.warn("Error extracting email sent dates for documentId={}: {}", document.getId(), e.getMessage());
        }

        String firstSentStr = (emailSentDates != null && !emailSentDates.isEmpty()) ? emailSentDates.get(0) : null;
        Date firstEmailSentDate = null;
        Date lastEmailSentDate = null;

        SimpleDateFormat iso = new SimpleDateFormat(DATE_TIME_FORMAT);
        iso.setTimeZone(TimeZone.getTimeZone("UTC"));
        try {
            if (StringUtils.isNotBlank(firstSentStr)) {
                firstEmailSentDate = iso.parse(firstSentStr);
            }
            if (StringUtils.isNotBlank(dateSentStr)) {
                lastEmailSentDate = iso.parse(dateSentStr);
            }
        } catch (ParseException pe) {
            LOGGER.warn("Unable to parse email‐sent date(s) for documentId={} – will treat as first send", document.getId());
        }

        return new DatePair(firstEmailSentDate, lastEmailSentDate);
    }

    private record DatePair(Date firstDate, Date lastDate) {
    }

    private void terminateEmailSending(DocumentMetaData document, int emailTerminationWindow) {
        document.getMetadata().put("stopSendingEmail", true);
        LOGGER.info("Stopping the process of sending an email to PEN as email termination window of {} days has passed, documentId={}", emailTerminationWindow, document.getId());
        documentMetaDataService.saveDocumentMetaData(document);
    }

    private Integer getNumberOfDocs(String uniqueField, Map<String, List<String>> uniqueFieldMap) {
        List<String> sameFieldDocList = uniqueFieldMap
                .get(uniqueField);
        return sameFieldDocList.size();
    }

    protected ResponseEntity<String> postDocumentWithRetry(DelegateExecution execution, String endpoint, String jsonDocument,
                                                           String docId, Number retryCountMax, Number threadSleepTime, RateLimiter rateLimiter) throws OutOfRetriesException {
        ResponseEntity<String> response = null;
        var retryHandler = new RetryOnExceptionHandler(retryCountMax, threadSleepTime);
        while (retryHandler.shouldRetry()) {
            try {
                rateLimiter.acquire();
                response = postDocument(execution, endpoint, jsonDocument);
                LOGGER.info("postDocumentWithRetry {}={}, documentId={}, statusCode={}", DELEGATE_EXECUTION_ID, getExecutionId(execution), docId, response.getStatusCode());
                break;
            } catch (RestClientException e) {
                LOGGER.error("postDocumentWithRetry {}={}, documentId={}, request={} {}",
                        DELEGATE_EXECUTION_ID, getExecutionId(execution), docId, getRequest(jsonDocument), ExceptionUtils.getStackTrace(e));
                if(ExceptionUtils.getMessage(e).contains("HttpClientErrorException.BadRequest")) {
                    response = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
                    break;
                }

                retryHandler.exceptionOccurred();
            }
        }
        return response;
    }

    protected ResponseEntity<String> postDocument(DelegateExecution execution, String endpoint, String document) throws RestClientException {

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(endpoint);

        var penAppId = execution.getVariable(Workflow.PEN_APP_ID, String.class);
        var penAppSecret = execution.getVariable(Workflow.PEN_APP_SECRET, String.class);
        var penOauthUrl = execution.getVariable(Workflow.PEN_OAUTH_URL, String.class);
        var penGrantType = execution.getVariable(Workflow.PEN_GRANT_TYPE, String.class);
        var penScope = execution.getVariable(Workflow.PEN_SCOPE, String.class);

        String token = oauthManagerUtil.getOauthToken("multiCloudStargateToken", penAppId, penAppSecret, penGrantType, penOauthUrl, true, penScope);
        String newAccessToken = "Bearer " + token;
        HttpEntity<String> request = getMultiCloudRequest(document, newAccessToken);
        LOGGER.info("postDocument {}={}, endpoint={}, request={}", DELEGATE_EXECUTION_ID, getExecutionId(execution), builder.toUriString(), Encode.forJava(request.toString()));
        return restTemplate.exchange(builder.toUriString(), HttpMethod.POST, request, String.class);
    }
    
    protected HttpEntity<String> getMultiCloudRequest(String document, String token) {
		
	    var headers = new HttpHeaders();
        headers.set(AUTHORIZATION_STRING, token);
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(HttpConstants.HEADER_ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        headers.setConnection("keep-alive");
        headers.set("x-upstream-env", penMultiCloudEnv);
        return new HttpEntity<>(document, headers);
}

    protected HttpEntity<String> getRequest(String document) {
        var headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(HttpConstants.HEADER_ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(document, headers);
    }

    protected String getExecutionId(DelegateExecution execution) {
        return execution != null ? execution.getId() : "NULL";
    }

    protected String preparePayload(DocumentMetaData documentMetaData, Set<String> providerEmailList, DelegateExecution execution) throws JsonProcessingException{
        ObjectMapper objectMapper = new ObjectMapper();
        String docId = documentMetaData.getId();
        String appId =  Integer.toString(documentMetaData.getSpaceId());
        Document metadata = documentMetaData.getMetadata();
        
        Map<String, Object> query = new HashMap<>();
        query.put("documentId", docId);
        query.put("appId", appId);
        query.put(Workflow.PROVIDER_EMAIL_ID_LIST, providerEmailList);
        query.put("category", metadata.get("category", String.class));
        
        return objectMapper.writeValueAsString(query);
    }

    protected String prepareSecondaryEmailPayload(DocumentMetaData documentMetaData, Set<String> providerEmailList, DelegateExecution execution) throws JsonProcessingException{
        LOGGER.info("Preparing payload for secondary email processing. Document id: {}", documentMetaData.getId());
        String appId =  Integer.toString(documentMetaData.getSpaceId());
        String template = execution.getVariable(Workflow.TEMPLATE_NAME, String.class);
        String secEmails = String.join("|",providerEmailList);

        Map<String, Object> query = new HashMap<>();
        query.put("appId", appId);
        query.put(Workflow.PROVIDER_EMAIL_ID_LIST, secEmails);
        query.put(Workflow.TEMPLATE_NAME, template);
        query.put("category", documentMetaData.getMetadata().get("category", String.class));

        return TemplateFactory.getInstance(template).convertWithTemplate(query);
    }
    
    
    protected String prepareTemplatePayload(DocumentMetaData documentMetaData, DelegateExecution execution) {
        String templateName = execution.getVariable(Workflow.TEMPLATE_NAME, String.class);
        String requestStr = TemplateFactory.getInstance(templateName).convertWithTemplate(documentMetaData);
        return requestStr;
    }

    protected String prepareDynamicTemplatePayload(List<DocumentMetaData> documentMetaDataList, DelegateExecution execution) {
        String templateName = execution.getVariable(Workflow.TEMPLATE_NAME, String.class);
        return TemplateFactory.getInstance(templateName).convertWithTemplate(documentMetaDataList);
    }

    
    protected String updateDocument(DocumentMetaData document, PENRealTimeResponse response, Boolean isSecondaryEmail) {
        Document metadata = document.getMetadata();
        String messageIdStr = "";
        List<String> messageIds = new ArrayList<>();

        Map<String, String> messageIdList = response.getResponseMessage().getMessageIdList();

        for (String key : messageIdList.keySet()) {
            messageIds.add(messageIdList.get(key));
        }
        messageIdStr = String.join("|", messageIds);
        metadata.put("messageId", messageIdStr);
        metadata.put("messageIdList", messageIdList);

        updateDocumentMetaDataForPEN(document);
    	
    	return document.getId();    	
    }

    protected void updateSecondaryEmailSentMetadata(DocumentMetaData document) {
        Document metadata = document.getMetadata();
        metadata.put(Workflow.SECONDARY_EMAIL_SENT, true);
        documentMetaDataService.updateDocMetaData(document, document.getId());
    }

    protected boolean checkbusinessDaysPassed(LocalDateTime lastEmailSentDate, int noOfBusinessDays) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(Date.from(lastEmailSentDate.toInstant(ZoneOffset.UTC)));

        int businessDaysPassed = 0;
        //Increment the date until the required number of business days have passed
        while (businessDaysPassed < noOfBusinessDays) {
            calendar.add(Calendar.DAY_OF_MONTH, 1);
            if (isBusinessDay(LocalDateTime.ofInstant(calendar.toInstant(), ZoneOffset.UTC))) {
                businessDaysPassed++;
            }
        }
        // Check if the current date is after the calculated date
        return new Date().after(calendar.getTime());
    }

    protected String updateDocument(DelegateExecution execution, DocumentMetaData document, PENRealTimeTemplateResponse response, Map<String, List<String>> uniqueFieldMap, String uniqueFieldForPEN, boolean skipDocumentGrouping) {
        String date = new SimpleDateFormat(DATE_TIME_FORMAT).format(new Date());
        Map<String, Object> updateMap = new HashMap<>();
    	String responseMessage = response.getResponseMessage();
    	HashMap<String,String> responseMap = new Gson().fromJson(responseMessage, new TypeToken<HashMap<String, String>>(){}.getType());
    	updateMap.put(Workflow.METADATA_MESSAGE_ID, responseMap.get("messageId"));
        updateMap.put(Workflow.METADATA_SEND_EMAIL_NOTIFICATIONS, true);
        updateMap.put(Workflow.METADATA_SEND_PENAPI_REQUEST, true);
        updateMap.put(Workflow.PREPOSTENDED, true);

       String clientName = execution.getVariable(Workflow.CLIENT_NAME).toString();
        if (clientName.equals(CLIENT_SSBCI) || clientName.equals(CLIENT_PCP_MEMBER_REFERRAL)) {
            updateDocumentDateEmailSentSSBCIPCPReferralHelper(clientName, document, updateMap, execution, date);
        } else {
            updateMap.put(Workflow.METADATA_DATE_EMAIL_SENT, date);
        }

        updateDocumentsWithUpdateMap(execution, document, uniqueFieldForPEN, skipDocumentGrouping, uniqueFieldMap, updateMap);
        return document.getId();
    }

    protected void updateDocumentDateEmailSentSSBCIPCPReferralHelper(String clientName, DocumentMetaData document, Map<String, Object> updateMap, DelegateExecution execution, String date) {
        List<String> dateEmailSentList = (List<String>) document.getMetadata().get(Workflow.LAST_DATE_EMAIL_SENT_LIST);
        if (dateEmailSentList == null) {
            dateEmailSentList = new ArrayList<>();
            dateEmailSentList.add(date);
            updateMap.put(METADATA_PREFIX + Workflow.LAST_DATE_EMAIL_SENT_LIST, dateEmailSentList);
            updateMap.put(Workflow.METADATA_DATE_EMAIL_SENT, date);
        } else {
            var isoFormatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
            Integer noOfBusinessDays = execution.getVariable(Workflow.NO_OF_BUSINESS_DAYS, Integer.class);
            String latestDateString = dateEmailSentList.stream()
                    .max(Comparator.naturalOrder())
                    .orElse(LocalDateTime.now(ZoneOffset.UTC).format(isoFormatter));
            LocalDateTime latestDate;
            try {
                latestDate = LocalDateTime.parse(latestDateString, isoFormatter);
            } catch (Exception ex) {
                LOGGER.error("Error while parsing the date for documentId={}, using current date.", document.getId(), ex);
                latestDate = LocalDateTime.now(ZoneOffset.UTC);
            }
            if(clientName.equals(CLIENT_SSBCI)) {
                if (checkbusinessDaysPassed(latestDate, noOfBusinessDays)){
                    dateEmailSentList.add(date);
                    updateMap.put(METADATA_PREFIX + Workflow.LAST_DATE_EMAIL_SENT_LIST, dateEmailSentList);
                    updateMap.put(Workflow.METADATA_DATE_EMAIL_SENT, date);
                }
            } else{
                Integer noOfDays = execution.getVariable(Workflow.NO_OF_DAYS, Integer.class);
                if (checkCalendarDaysPassed(latestDate, noOfDays)){
                    dateEmailSentList.add(date);
                    updateMap.put(METADATA_PREFIX + Workflow.LAST_DATE_EMAIL_SENT_LIST, dateEmailSentList);
                    updateMap.put(Workflow.METADATA_DATE_EMAIL_SENT, date);
                }
            }
        }
    }
    
    
    protected String updateDocumentMetaDataForDuplicateEmail(DocumentMetaData document) {
    	document.getMetadata().put("hasDuplicateEmail", true);
    	return updateDocumentMetaDataForPEN(document);
    }

    protected String updateDocumentMetaDataForPEN(DocumentMetaData document){
    	String date = new SimpleDateFormat(DATE_TIME_FORMAT).format(new Date());
    	// 2023-09-13T20:30:00.000Z
        Document metadata = document.getMetadata();
        metadata.put(Workflow.SEND_EMAIL_NOTIFICATIONS, true);
        metadata.put(Workflow.METADATA_SEND_PEN_API_REQUEST, true);
        metadata.put(Workflow.DATE_EMAIL_SENT, date);
        metadata.put("prepostEnded", true);
        documentMetaDataService.updateDocMetaData(document, document.getId());
        return document.getId();
    }

    private boolean isBusinessDay(LocalDateTime date) {
        java.time.DayOfWeek dayOfWeek = date.getDayOfWeek();
        return dayOfWeek != java.time.DayOfWeek.SATURDAY && dayOfWeek != java.time.DayOfWeek.SUNDAY;
    }

    private boolean checkCalendarDaysPassed(LocalDateTime lastSent, int days) {
        LocalDateTime nextDate = lastSent.plusDays(days);
        return LocalDateTime.now(ZoneOffset.UTC).isAfter(nextDate);
    }

    private boolean hasReminderWindowElapsed(Date lastEmailSentDate, int reminderWindow, boolean useBusinessDays) {
        if (useBusinessDays) {
            return checkbusinessDaysPassed(LocalDateTime.ofInstant(lastEmailSentDate.toInstant(), ZoneOffset.UTC), reminderWindow);
        } else {
            Instant next = lastEmailSentDate.toInstant().plus(reminderWindow, ChronoUnit.DAYS);
            return Instant.now().isAfter(next);
        }
    }

    private boolean isTerminationWindowExceeded(Date firstEmailSentDate, int terminationWindowDays) {
        Calendar terminator = Calendar.getInstance();
        terminator.setTime(firstEmailSentDate);
        terminator.add(Calendar.DAY_OF_MONTH, terminationWindowDays);
        return new Date().after(terminator.getTime());
    }
}
