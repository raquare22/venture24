package com.optum.fds.paperless.java.delegate;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.java.delegate.docvault.OutOfRetriesException;
import com.optum.fds.paperless.java.delegate.docvault.RetryOnExceptionHandler;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.workflow.constants.Workflow;

@Service("PutDocumentDataDocLib")
public class PutDocumentDataDocLib extends OptumJavaDelegateBase {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PutDocumentDataDocLib.class);
	
	private static final List<String> REQ_VARS = List.of(
			Workflow.DOCLIB_PUT_DOCUMENT_IDS,
			Workflow.DOCLIB_PUT_URL,
			Workflow.DOCLIB_OAUTH_URL,
            Workflow.DOCLIB_CLIENT_ID,
            Workflow.DOCLIB_CLIENT_SECRET
	);
	
	private final DateFormat df;

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private DocumentMetaDataService documentMetaDataService;

    @Autowired
	private OauthManagerUtil oauthManagerUtil;

	@Autowired
	private EhCache ehCache;
    
    private static final String METADATA_PREFIX = "metadata.";
  
	public PutDocumentDataDocLib() {
		super(REQ_VARS);
		df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		df.setTimeZone(TimeZone.getTimeZone("UTC"));
	}
	
	@Override
	protected void doExecute(DelegateExecution execution) {
		try {
			putDocumentDataDocLib(execution);
		} catch (Exception e) {
			LOGGER.error("msg: {}", e.getMessage());
			addErrorMsg("Exception", e.getMessage());
			setExitNow(execution);
		}
	}
	
	@SuppressWarnings("unchecked")
	void putDocumentDataDocLib(DelegateExecution execution) {
		List<String> successDocumentList = new ArrayList<>();
		List<String> failureDocumentList = new ArrayList<>();
		try {
			String localUploadTime = df.format(new Date());
			
			Map<String, Object> successUpdateMap = new HashMap<>(
					Map.of(METADATA_PREFIX + Workflow.METADATA_UPDATE_DOCLIB_API_RESPONSE, true,
							METADATA_PREFIX + Workflow.METADATA_UPDATE_DOCLIB_UPLOAD_DATE, localUploadTime,
							METADATA_PREFIX + Workflow.METADATA_DOCSENTTO_FIELD, Workflow.METADATA_DOCSENTTO_DOCLIB));
			
			Map<String, Object> failureUpdateMap = new HashMap<>(
					Map.of(METADATA_PREFIX + Workflow.METADATA_UPDATE_DOCLIB_API_RESPONSE, false
					));
			

			execution.setTransientVariable("successUpdateMap", successUpdateMap);
			execution.setTransientVariable("failureUpdateMap", failureUpdateMap);
			
			String docLibURL = execution.getVariable(Workflow.DOCLIB_PUT_URL, String.class);
			
			List<String> documentIds = execution.getVariable(Workflow.DOCLIB_PUT_DOCUMENT_IDS, List.class);
			
			if (documentIds.isEmpty()) {
				LOGGER.debug("PutDocumentDataDocLib documentIds is null or empty");
        		setExitNow(execution);
        		return;
			}

			var docLibUrl = execution.getVariable(Workflow.DOCLIB_OAUTH_URL, String.class);
			var docLibClientId = execution.getVariable(Workflow.DOCLIB_CLIENT_ID, String.class);
			var docLibClientSecret = execution.getVariable(Workflow.DOCLIB_CLIENT_SECRET, String.class);


			List<DocumentMetaData> documentMetaDataList = documentMetaDataService.getDocumentMetaDataList(documentIds);
			
			for (DocumentMetaData doc : documentMetaDataList) {
				try {
					String jsonStringBody = TemplateFactory.getInstance(Templates.DOCLIB_PUT_REQUEST.getTemplate()).convertWithTemplate(doc);
					String token = oauthManagerUtil.getOauthToken("tokenStargate", docLibClientId,
							docLibClientSecret, "client_credentials", docLibUrl, false, null);
					
					ResponseEntity<String> response = putDocumentToDocLibWithRetry(docLibURL, token, jsonStringBody, execution,
							doc.getId());

					int responseStatus = response.getStatusCode().value();
					
					if (responseStatus == 200) {
						successDocumentList.add(doc.getId());
					} else {
						LOGGER.error("PutDocumentDataDocLib error sending PUT request to docLib for docId={}", doc.getId());
						failureDocumentList.add(doc.getId());
					}
					
				} catch (OutOfRetriesException e) {
					LOGGER.error("OutOfRetriesException to PUT docLib docId={}, exception {}", doc.getId(), ExceptionUtils.getStackTrace(e));
					addErrorMsg("Exception", e.getMessage());
					failureDocumentList.add(doc.getId());
				} catch (Exception e) {
					LOGGER.error("Exception to PUT docLib docId={}, exception {}", doc.getId(), ExceptionUtils.getStackTrace(e));
					addErrorMsg("Exception", e.getMessage());
					failureDocumentList.add(doc.getId());
				}
			}
			
			execution.setTransientVariable("successDocumentList", successDocumentList);
			execution.setTransientVariable("failureDocumentList", failureDocumentList);
		} catch (Exception e) {
			LOGGER.error("PutDocumentDataDocLib Exception to PUT DocLib e={}", ExceptionUtils.getStackTrace(e));
		} finally {
			execution.setTransientVariable("successDocumentList", successDocumentList);
			execution.setTransientVariable("failureDocumentList", failureDocumentList);
		}
	}
	
	
	private ResponseEntity<String> putDocumentToDocLibWithRetry(String endpoint, String accessToken, String jsonStringBody, DelegateExecution execution, String docId) throws OutOfRetriesException {
		ResponseEntity<String> response = null;

		var numRetries = execution.getVariable(Workflow.NUM_RETRIES, Number.class);
		var timeToWaitMS = execution.getVariable(Workflow.TIME_TO_WAIT, Number.class);

		var docLibUrl = execution.getVariable(Workflow.DOCLIB_OAUTH_URL, String.class);
		var docLibClientId = execution.getVariable(Workflow.DOCLIB_CLIENT_ID, String.class);
		var docLibClientSecret = execution.getVariable(Workflow.DOCLIB_CLIENT_SECRET, String.class);


		var retryHandler = new RetryOnExceptionHandler(numRetries, timeToWaitMS);
		String msg;
		while (retryHandler.shouldRetry()) {
			try {
				try {
					if (retryHandler.isRetry()) {
//						String newToken = getOauthToken(execution, true);
						String newToken = oauthManagerUtil.getOauthToken("tokenStargate", docLibClientId,
								docLibClientSecret, "client_credentials", docLibUrl, true, null);
						String newAccessToken = "Bearer " + newToken;
						LOGGER.info("putDocumentToDocLibWithRetry retrying doclib call with new token");
						response = putRequest(endpoint, newAccessToken, jsonStringBody);
					} else {
						response = putRequest(endpoint, accessToken, jsonStringBody);
					}
					break;
				} catch (HttpClientErrorException.Unauthorized e) {
					LOGGER.error("HttpClientErrorException Unauthorized for documentId={}, responseBody={}, statusCode={}", docId, e.getResponseBodyAsString(), e.getStatusCode());
					retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
					retryHandler.exceptionOccurred();
				} catch (HttpServerErrorException e) {
					if (e instanceof HttpServerErrorException.GatewayTimeout || e instanceof HttpServerErrorException.BadGateway) {
						LOGGER.error("HttpClientErrorException for documentId={}, responseBody={}, statusCode={}", docId, e.getResponseBodyAsString(), e.getStatusCode());
						retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
						retryHandler.exceptionOccurred();
					}
					else {
					LOGGER.error("{} exception for documentId={}, responseBody={}, statusCode={}", e.getClass().getSimpleName(), docId, e.getResponseBodyAsString(), e.getStatusCode());
					return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());
					}
				} catch (HttpClientErrorException e) {
					LOGGER.error("{} exception for documentId={}, responseBody={}, statusCode={}", e.getClass().getSimpleName(), docId, e.getResponseBodyAsString(), e.getStatusCode());
					return new ResponseEntity<>(e.getResponseBodyAsString(), e.getStatusCode());					
				} catch (RestClientException e) {
					LOGGER.error("RestClientException for document {} and exception {} ", docId,
							ExceptionUtils.getStackTrace(e));
					retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
					retryHandler.exceptionOccurred();
				}
			} catch (OutOfRetriesException e) {
				msg = String.format(
						"RestClientException to endpoint %s and exhausted %s retries with retry time %s millis",
						endpoint, retryHandler.getNumRetries(), retryHandler.getTimeToWaitMS());
				LOGGER.error(msg);
				throw new OutOfRetriesException(msg);
			}
		}
		return response;
	}
	
	
	ResponseEntity<String> putRequest(String endpoint, String accessToken, String document)
			throws RestClientException {
		var headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("accept", "application/json");
		headers.set("Authorization", accessToken);
		HttpEntity<String> request = new HttpEntity<>(document, headers);
		
		LOGGER.info("putRequest endpoint={}, document={}", Encode.forJava(endpoint), Encode.forJava(document));
		return restTemplate.exchange(endpoint, HttpMethod.PUT, request, String.class);
	}

}
