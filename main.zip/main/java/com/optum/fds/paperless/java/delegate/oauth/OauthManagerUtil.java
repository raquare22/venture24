package com.optum.fds.paperless.java.delegate.oauth;

import java.util.Optional;

import org.flowable.engine.delegate.DelegateExecution;

import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;

public interface OauthManagerUtil {
	
	String getOauthToken(String tokenType, String clientId, String clientSecret, String grantType, String oauthUrl, boolean getNewToken, String scope);
	
    OauthTokenExtended refreshToken(OauthTokenExtended tokenExtended) throws InterruptedException;
    
    Optional<OauthTokenExtended> getOauthTokenExtended(String appId, String appSecret, String url, String grantType, String scope);
}

