package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import com.optum.fds.paperless.util.Utilities;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service("UpdateDocumentListInMongo")
public class UpdateDocumentListInMongo extends OptumJavaDelegateBase {

	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateDocumentListInMongo.class);

	private static final String DATE_FORMATTER = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

	private static final String ERROR = "ERROR";

	private static final String COMPLETE = "COMPLETE";

	private static final List<String> REQ_VARS = Collections.emptyList();
	
	List<String> updatedDocumentIds = new ArrayList<>();

	@Autowired
	private ProcessorService processorService;

    @Autowired
    private DocumentMetaDataService documentMetaDataService;

    @Autowired
    private EmailService emailService;
    
    @Autowired
    private HookService hookService;

    private Map<String, String> correlationIDs;

    public UpdateDocumentListInMongo() {
        super(REQ_VARS);
    }

    /**
     * This executor will be called from multiple workflows. Response workflow will
     * file path where documents are kept as json. COSMOS Ack workflow will send the
     * data in execution bus as list of documentMetadata. Repsonse workflow will
     * needs to update the document with flag addedToResponseFile COSMOS Ack
     * workflow just need to send update the document in MongoDB.
     */
    public void doExecute(DelegateExecution execution) {
    	updatedDocumentIds = new ArrayList<>();
    	String documentId;
        LOGGER.debug("UpdateDocumentListInMongo-->doExecute-->ENTER");
        HookTransactionMetaData hookTransactionMetaData = null;
        try {
            hookTransactionMetaData = execution.getVariable(Workflow.HOOK_TRANSACTION_METADATA, HookTransactionMetaData.class);
            var documentMetaDataList = getDocumentListFromExecutionBus(execution);
            
            List<String> successDocumentList = (ArrayList<String>) execution.getVariable("successDocumentList");
            List<String> failureDocumentList = (ArrayList<String>) execution.getVariable("failureDocumentList");
            
            Map<String, Object> successUpdateMap = (Map<String, Object>) execution.getVariable("successUpdateMap");
            
            Map<String, Object> responseFileMap = new HashMap<>();
            String responseFileName = (String)execution.getVariable("responseFileName");
            if(responseFileName != null) {
            	responseFileMap.put(Workflow.METADATA_RESPONSE_FILE_NAME, responseFileName);
            }
            
            Map<String, List<String>> responseFileNames = (Map<String, List<String>>) execution.getVariable("responseFileNameUSPClaims");
            
            Map<String, Object> failureUpdateMap = (Map<String, Object>) execution.getVariable("failureUpdateMap");
            
            Map<String, String> msg = new HashMap<>();

			LOGGER.debug("successDocumentList = {}, successUpdateMap = {}", successDocumentList, successUpdateMap);


			if (!CollectionUtils.isEmpty(successDocumentList) || !CollectionUtils.isEmpty(failureDocumentList)) {
            	LOGGER.debug("Document id list is not empty, using multi update");
            	
            	long countSuccessUpdated = 0;
            	long countFailureUpdated = 0;
            	
            	if (!CollectionUtils.isEmpty(successDocumentList) && !MapUtils.isEmpty(successUpdateMap)) {
            		countSuccessUpdated = documentMetaDataService.saveDocumentMetaDataMulti(successDocumentList, successUpdateMap);
            	}
            	
            	if (!CollectionUtils.isEmpty(failureDocumentList) && !MapUtils.isEmpty(failureUpdateMap)) {
            		countFailureUpdated = documentMetaDataService.saveDocumentMetaDataMulti(failureDocumentList, failureUpdateMap);
            	}
            	
            	if (!CollectionUtils.isEmpty(successDocumentList) && !MapUtils.isEmpty(responseFileMap)) {
            		documentMetaDataService.saveDocumentMetaDataMulti(successDocumentList, responseFileMap);
            	}
            	
            	if (!CollectionUtils.isEmpty(successDocumentList) && !MapUtils.isEmpty(responseFileNames)) {
            		responseFileNames.forEach((fileName,docList) -> {
            			Map<String , Object> responseFileNameUSPClaims =  new HashMap<>();
            			responseFileNameUSPClaims.put(Workflow.METADATA_RESPONSE_FILE_NAME,fileName);
            			documentMetaDataService.saveDocumentMetaDataMulti(docList, responseFileNameUSPClaims);
            		});
            		
            	}
            	
            	msg.put("count_success_documents_updated", Long.toString(countSuccessUpdated));
            	msg.put("count_failure_documents_updated", Long.toString(countFailureUpdated));
            	
            	updateHookTransaction(execution, hookTransactionMetaData, msg);
            } else {
            	
            	if (CollectionUtils.isEmpty(documentMetaDataList)) {
                    LOGGER.error("UpdateDocumentListInMongo-->doExecute-->documentMetaDataList is empty");
                    addErrorMsg("UpdateDocumentListInMongo-->doExecute-->documentMetaDataList is empty", "documentMetaDataList is empty");
                return;
                }
            	
                var dataFieldToUpdate = execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, String.class);
                var dataFieldValueToUpdate = execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, Boolean.class);
                               
                var dataFieldToFormat = execution.getVariable(Workflow.DOCUMENT_FORMAT_FIELD, String.class);
                if (StringUtils.isNotEmpty(dataFieldToFormat)) {
                    LOGGER.warn("we are getting document_format_field");
                    updateDateField(dataFieldToFormat, documentMetaDataList, execution);
                } else {
                    LOGGER.warn("document_format_field is empty");
                }
                    
                updateDocumentsInDocumentMetaDataListIfRequired(documentMetaDataList, dataFieldToUpdate, dataFieldValueToUpdate);
                List<String> shutterflyList = new ArrayList<String>();
                for (var document : documentMetaDataList) {
                    documentId = document.getId();
                    shutterflyList.add(documentId);
                }
            	Map<String, Object> shutterflyFileMap = new HashMap<>();
            	String shutterflyFileName  = (String)execution.getVariable("shutterflyFileName");
            	if(shutterflyFileName != null) {
            		shutterflyFileMap.put(Workflow.METADATA_SHUTTERFLY_FILE_NAME, shutterflyFileName);
            	}
                
                if (!CollectionUtils.isEmpty(shutterflyList) && !MapUtils.isEmpty(shutterflyFileMap)) {
                	documentMetaDataService.saveDocumentMetaDataMulti(shutterflyList, shutterflyFileMap );
                }
                var processorTransUpdate = execution.getVariable(Workflow.PROCESSOR_TRANSACTION_UPDATE, String.class); 
                if(StringUtils.isNotBlank(processorTransUpdate)) {
                	DelegateUtils.updateProcessorTransactionList(execution, processorService);
                }
                
                msg.put(Workflow.UPDATE_DOCUMENT_WITH_API_SUCCESS_MESSAGE, updatedDocumentIds.toString());
                updateHookTransaction(execution, hookTransactionMetaData, msg);
            }
            
            DocumentMetaData bounceEmailDoc = execution.getVariable(Workflow.DOCUMENT, DocumentMetaData.class);
			LOGGER.info("setting doc status to COMPLETE");

            if (bounceEmailDoc != null) {
            	List<String> bouncedEmailList = new ArrayList<String>();
                for (var document : documentMetaDataList) {
                    documentId = document.getId();
                    bouncedEmailList.add(documentId);
                }
            	Map<String, Object> bouncedEmailFileMap = new HashMap<>();
            	String bouncedEmailFileName = (String)execution.getVariable("bouncedEmailFileName");
            	if(bouncedEmailFileName != null) {
            		bouncedEmailFileMap.put(Workflow.METADATA_BOUNCED_EMAIL_FILE_NAME, bouncedEmailFileName);
            	}
                
                if (!CollectionUtils.isEmpty(bouncedEmailList) && !MapUtils.isEmpty(bouncedEmailFileMap)) {
                	documentMetaDataService.saveDocumentMetaDataMulti(bouncedEmailList, bouncedEmailFileMap );
                }
				LOGGER.info("completing bounce email process, doc id = {}", bounceEmailDoc.getId());
                documentMetaDataService.updateDocumentMetaDataStatus(bounceEmailDoc.getId(), COMPLETE);
            }          
		} catch (Exception e) {
			LOGGER.error("doExecute Exception while executing UpdateDocumentListInMongo task {}={} {}",
					"delegateExecutionId", execution.getId(), ExceptionUtils.getStackTrace(e));
			addErrorMsg(
					"UpdateDocumentListInMongo-->doExecute-->Exception while executing UpdateDocumentListInMongo task",
					WorkFlowUtil.getStackTrace(e));
		} finally {
			var jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
			if(!StringUtils.isEmpty(jsonFile)) {
				Utilities.deleteWorkingDirectory(jsonFile);
			}
			if (newErrors() && errorMap.size() > 1) {
				DelegateUtils.sendErrorNotification(execution, errorMap,
						DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution), emailService);
				if (hookTransactionMetaData != null) {
					hookTransactionMetaData.getHookExecutionList().get(0).addMessage(
							DelegateUtils.generateErrorMessageforCronExpressionHookWorkflow( errorMap));
					hookTransactionMetaData.setStatus(ERROR);
					hookService.updateHookTransaction(hookTransactionMetaData);
				}
			}
		}


        LOGGER.debug("UpdateDocumentListInMongo-->doExecute-->correlationsId: {}", correlationIDs);
        LOGGER.debug("UpdateDocumentListInMongo-->doExecute-->EXIT");
    }


    private void updateDateField(String dataFieldToUpdateString, List<DocumentMetaData> documentMetaDataList, DelegateExecution execution) {
        var dateFormat = new SimpleDateFormat(DATE_FORMATTER);
        documentMetaDataList.forEach(documentMetaData -> extractDataField(dataFieldToUpdateString, dateFormat, documentMetaData, execution));
    }

    private void extractDataField(String dataFieldToUpdateString, SimpleDateFormat dateFormat, DocumentMetaData document, DelegateExecution execution) {
        var metaData = document.getMetadata();
        if (!metaData.containsKey(dataFieldToUpdateString)) {
            return;
        }
        var dataFieldToUpdate = metaData.get(dataFieldToUpdateString);
        var isLong = dataFieldToUpdate instanceof Long;
        var isDouble = dataFieldToUpdate instanceof Double;
        var isDate = dataFieldToUpdate instanceof Date;
        if (isLong) {
            LOGGER.debug("we are converting document_format_field to long for documentId {}, dataFieldToUpdateString={}", document.getId(), dataFieldToUpdateString);
            metaData.append(dataFieldToUpdateString, dateFormat.format(new Date(Long.parseLong(dataFieldToUpdate.toString()))));
        } else if (isDouble) {
            LOGGER.debug("we are converting document_format_field to double for documentId {}, dataFieldToUpdateString={}", document.getId(), dataFieldToUpdateString);
            metaData.append(dataFieldToUpdateString, dateFormat.format(new Date((long)Double.parseDouble(dataFieldToUpdate.toString()))));
        } else if (isDate) {
            try {
                LOGGER.debug("we are converting document_format_field date to String for documentId {}, dataFieldToUpdateString={}", document.getId(), dataFieldToUpdateString);
                metaData.append(dataFieldToUpdateString, dateFormat.format(dataFieldToUpdate));
            } catch (Exception e) {
                LOGGER.error("we are converting document_format_field date to String for documentId {}, dataFieldToUpdateString={} and getting exception{}",
                        document.getId(), dataFieldToUpdateString, ExceptionUtils.getStackTrace(e));
            }
        } else {
            try {
                LOGGER.debug("we are not converting to any format {} for documentId {}, dataFieldToUpdateString={}", dataFieldToUpdate.getClass().getName(),
                        document.getId(), dataFieldToUpdateString);
            } catch (Exception e) {
                LOGGER.error("we are not converting to any format for documentId {}, dataFieldToUpdateString={} and getting exception{}",
                        document.getId(), dataFieldToUpdateString, ExceptionUtils.getStackTrace(e));
            }
        }
    }


	@SuppressWarnings("unchecked")
	private List<DocumentMetaData> getDocumentListFromExecutionBus(DelegateExecution execution)
			throws IOException, JSONException {
		var listDocumentMetaData = (List<DocumentMetaData>) execution.getVariable(Workflow.LIST_DOCUMENT_METADATA);
		if (CollectionUtils.isEmpty(listDocumentMetaData)) {
			var jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
			if (StringUtils.isEmpty(jsonFile)) {
				return List.of();
			}
			listDocumentMetaData = WorkFlowUtil.readDocumentsFromJsonFile(jsonFile);
		}

		return listDocumentMetaData;
	}

	private void updateDocumentsInDocumentMetaDataListIfRequired(List<DocumentMetaData> documentMetaDataList,
			String dataFieldToUpdate, Boolean dataFieldValueToUpdate) {
		if (StringUtils.isNotEmpty(dataFieldToUpdate)) {
			updateDocumentsInDocumentMetaDataList(documentMetaDataList, dataFieldToUpdate,
					Objects.requireNonNullElse(dataFieldValueToUpdate, true));
		} else {
			updateDocumentsInDocumentMetaDataList(documentMetaDataList);
		}
	}
	
	private void updateDocumentsInDocumentMetaDataList(List<DocumentMetaData> documentList) {
		for (var document : documentList) {
			documentMetaDataService.saveDocumentMetaData(document);
			updatedDocumentIds.add(document.getId());
		}
	}

	private <T> void updateDocumentsInDocumentMetaDataList(List<DocumentMetaData> documentList, String key, T value) {
		for (var document : documentList) {
			document.getMetadata().append(key, value);
			documentMetaDataService.saveDocumentMetaData(document);
			updatedDocumentIds.add(document.getId());
		}
	}
	
	private void updateHookTransaction(DelegateExecution execution, HookTransactionMetaData hookTransactionMetaData, Map<String, String> msg) {
		
		if (hookTransactionMetaData != null) {
        	var fileName="";
        	var fileList = (List<String>) execution.getVariable(Workflow.SFTP_FILE_LIST);

        	if (fileList != null) {
        		for (var file : fileList) {
        			File objfileName = new File(file);
        			fileName = fileName.join(" ", fileName, objfileName.getName());
        		}
        	} else {
        		LOGGER.warn("Sftp file list is empty hookTransactionMetaData.id={}, filename={}", hookTransactionMetaData.getId(), fileName);
        	}

			if (!fileName.isEmpty()) {
				msg.put(Workflow.FILE_NAME, fileName);
				LOGGER.info("Hook transaction update fileName: {}", fileName);
			}

        	var hookExecutionList = hookTransactionMetaData.getHookExecutionList();

        	
        	Map<String, String> hookExecutionMessage = null;
        	if (hookExecutionList != null && !hookExecutionList.isEmpty() && hookExecutionList.get(0) != null
        			&& hookExecutionList.get(0).getMessageList() != null && !hookExecutionList.get(0).getMessageList().isEmpty() 
        			&& hookExecutionList.get(0).getMessageList().get(0) != null) {
        		hookExecutionMessage = hookTransactionMetaData.getHookExecutionList().get(0).getMessageList().get(0);
        		hookExecutionMessage.putAll(msg);
        	} else {
        		hookExecutionMessage = new HashMap<>();
        		hookExecutionMessage.putAll(msg);
        	}

        	hookTransactionMetaData.getHookExecutionList().get(0).updateMessage(hookExecutionMessage);
        	hookTransactionMetaData.setStatus(COMPLETE);
        	hookService.updateHookTransaction(hookTransactionMetaData);
        }
		
	}
}
