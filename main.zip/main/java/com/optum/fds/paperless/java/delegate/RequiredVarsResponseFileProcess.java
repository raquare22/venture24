package com.optum.fds.paperless.java.delegate;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.tika.utils.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.workflow.constants.Workflow;

@Service("RequiredVarsResponseFileProcess")
public class RequiredVarsResponseFileProcess extends OptumJavaDelegateBase {
    private static final Logger LOGGER = LoggerFactory.getLogger(RequiredVarsResponseFileProcess.class);

    private static final List<String> REQ_VARS = Arrays.asList(
            Workflow.SEARCH_CRITERIA,
            Workflow.SEARCH_WINDOW,
            Workflow.TEMPLATE_NAME,
//            Workflow.DOCUMENT_FORMAT_FIELD, // not required for appeals
            Workflow.DOCUMENT_UPDATE_FLAG_PATH,
//            Workflow.DOCUMENT_UPDATE_FLAG_VALUE, // not required for cosmos pra
            Workflow.SFTP_HOSTNAME,
            Workflow.SFTP_USERNAME,
            Workflow.SFTP_PW,
            Workflow.SFTP_DIRECTORY,
            Workflow.SFTP_FILENAME,
            Workflow.SFTP_ARCHIVE_DIRECTORY
    );

    public RequiredVarsResponseFileProcess() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("Entering RequiredVarsResponseFileProcess doExecute");
        try {
            Map<String, Object> varMap = execution.getVariables();
            for(Entry<String, Object> entry : varMap.entrySet()) {
                LOGGER.debug("key: {}, value: {}", entry.getKey(), entry.getValue());
            }
        }
        catch (Exception e) {
            LOGGER.error("RequiredVarsResponseFilesProcess doExecute exception caught e={}", ExceptionUtils.getStackTrace(e));
            addErrorMsg("RequiredVarsResponseFilesProcess doExecute exception caught", e.getMessage());
        }

    }

}