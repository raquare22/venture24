package com.optum.fds.paperless.java.delegate;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.io.IOException;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.util.NasDriveUtil;
import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.workflow.constants.Workflow;

import com.hierynomus.protocol.transport.TransportException;
import com.hierynomus.smbj.common.SMBRuntimeException;

@Service("MoveOriginalZipToArchiveFolder")
public class MoveOriginalZipToArchiveFolder extends OptumJavaDelegateBase {

	private static final Logger log = LoggerFactory.getLogger(MoveOriginalZipToArchiveFolder.class);


	private static final String DELEGATE_EXECUTION_ID = "delegateExecutionId";
	private static final String PROCESSOR_TRANSACTION = "processorTransaction";
	private static final String INGEST_PATH = "ingestPath";

	@Autowired
	ProcessorService processorService;
	
	@Autowired
	ErrorMetaDataService errorMetaDataService;
	
	
	@Autowired
	private NasDriveUtil nasDriveUtil;
	
	private DelegateExecution tempExecution = null;
	
    private static final List<String> REQ_VARS = Arrays.asList(
    	Workflow.PROCESSOR_TRANSACTION
    );
    
    public MoveOriginalZipToArchiveFolder() {
    	super(REQ_VARS);
	}

	@Override
	public void doExecute(DelegateExecution execution) {
		log.info("MoveOriginalZipToArchiveFolder-->doExecute-->ENTER");
		tempExecution = execution;
		ProcessorTransaction processorTransaction = null;
		ProcessorExecutionRecord executionRecord = null;
		Map<String, String> message = new HashMap<>();
		try {
			processorTransaction = execution.getVariable(Workflow.PROCESSOR_TRANSACTION, ProcessorTransaction.class);
			String archiveWorkingDir = execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, String.class);

            log.info("processorTransaction:{}", getProcessorTransactionId(processorTransaction));
            log.info("NAS_ARCHIVE_DIRECTORY:{}",archiveWorkingDir);
            
			
			executionRecord = ProcessorTaskUtil.createProcessorExecutionRecord("Moving source zip file to archive folder");
			message = new HashMap<>();
			processorTransaction = Optional.ofNullable(processorTransaction).orElseThrow(NullPointerException::new);
			final String fileName = processorTransaction.getFileName();

			archiveZipFile(processorTransaction ,fileName,execution,message);

		} catch(Exception e) {
			log.error("doExecute Exception while executing MoveOriginalZipToArchiveFolder task {}={}, {}={}, {}={} {}",
					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
					PROCESSOR_TRANSACTION, getProcessorTransactionId(processorTransaction),
					INGEST_PATH, getIngestPath(processorTransaction),
					ExceptionUtils.getStackTrace(e));
			
			errorMetaDataService.writeToErrorCollection(execution, "MoveOriginalZipToArchiveFolder --> doExecute: " + e.getMessage());

			message.put(Workflow.OUTCOME_KEY, "File did not archived correctly");

		} finally {
			ProcessorTaskUtil.addMessageToProcessorExecutionRecordToProcessorTransaction(processorTransaction, executionRecord, message);
			execution.setTransientVariable(Workflow.PROCESSOR_TRANSACTION, processorTransaction);
			processorService.updateProcessorTransactionMetaData(processorTransaction);
		}
		log.info("MoveOriginalZipToArchiveFolder-->doExecute-->EXIT");
	}

	private void archiveZipFile(ProcessorTransaction processorTransaction ,String fileName,DelegateExecution execution,Map<String, String> message ) throws Exception{
		String archiveWorkingDir = execution.getVariable(Workflow.SFTP_ARCHIVE_DIRECTORY, String.class);
		Integer maxSftpTriesVar = execution.getVariable(Workflow.MAX_SFTP_TRIES, Integer.class);
		Long retryTimeSecsVar = execution.getVariable(Workflow.RETRY_TIME_SECS, Long.class);
		int maxSftpTries = maxSftpTriesVar != null ? maxSftpTriesVar : 10;
		long retryTimeSecs = retryTimeSecsVar != null ? retryTimeSecsVar: 360;  // 6 minutes
		try {
			log.info("INGEST_PATH:{}", getIngestPath(processorTransaction));
			var zipFile = new File(getIngestPath(processorTransaction));
			if (zipFile.exists()) {
				moveFileFromLocalToNAS( archiveWorkingDir, getIngestPath(processorTransaction), maxSftpTries, retryTimeSecs);
				message.put(Workflow.OUTCOME_KEY, String.format("File %s archive correctly", fileName));
			} else {
				message.put(Workflow.OUTCOME_KEY, String.format("File %s is not present in ingest folder", fileName));
			}
		}  catch (TransportException e) {
			log.error("NAS transport error while archiving file from Source zip to NAS archive folder {}={}, {}={}, {}={} {}", 
					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
					PROCESSOR_TRANSACTION, getProcessorTransactionId(processorTransaction),
					INGEST_PATH, getIngestPath(processorTransaction),
					ExceptionUtils.getStackTrace(e));
			message.put(Workflow.OUTCOME_KEY, "NAS transport failure: fileName="
					+ getIngestPath(processorTransaction));
			errorMetaDataService.writeToErrorCollection(tempExecution, "MoveOriginalZipToArchiveFolder --> doExecute --> TransportException: " + e.getMessage());
		} catch (SMBRuntimeException e) {
			
			log.error("SMB runtime error while archiving file from Source zip to NAS archive folder {}={}, {}={}, {}={} {}", 
					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
					PROCESSOR_TRANSACTION, getProcessorTransactionId(processorTransaction),
					INGEST_PATH, getIngestPath(processorTransaction),
					ExceptionUtils.getStackTrace(e));
			message.put(Workflow.OUTCOME_KEY, "NAS SMB failure: fileName="
					+ getIngestPath(processorTransaction));
			errorMetaDataService.writeToErrorCollection(tempExecution, "MoveOriginalZipToArchiveFolder --> doExecute --> SMBRuntimeException: " + e.getMessage());
			
		} catch (IOException e) {
			
			log.error("I/O error while archiving file from Source zip to NAS archive folder {}={}, {}={}, {}={} {}", 
					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
					PROCESSOR_TRANSACTION, getProcessorTransactionId(processorTransaction),
					INGEST_PATH, getIngestPath(processorTransaction),
					ExceptionUtils.getStackTrace(e));
			message.put(Workflow.OUTCOME_KEY, "NAS I/O failure: fileName="
					+ getIngestPath(processorTransaction));
			errorMetaDataService.writeToErrorCollection(tempExecution, "MoveOriginalZipToArchiveFolder --> doExecute --> IOException: " + e.getMessage());
			
		} catch (SecurityException e) {
			
			log.error("Authentication/permission error while archiving file from Source zip to NAS archive folder {}={}, {}={}, {}={} {}", 
					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
					PROCESSOR_TRANSACTION, getProcessorTransactionId(processorTransaction),
					INGEST_PATH, getIngestPath(processorTransaction),
					ExceptionUtils.getStackTrace(e));
			message.put(Workflow.OUTCOME_KEY, "NAS authentication failure: fileName="
					+ getIngestPath(processorTransaction));
			errorMetaDataService.writeToErrorCollection(tempExecution, "MoveOriginalZipToArchiveFolder --> doExecute --> Authentication failure: " + e.getMessage());
		} catch (Exception e) {
			log.error("doExecute Exception moving from Source zip to NAS archive folder {}={}, {}={}, {}={} {}",
					DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
					PROCESSOR_TRANSACTION, getProcessorTransactionId(processorTransaction),
					INGEST_PATH, getIngestPath(processorTransaction),
					ExceptionUtils.getStackTrace(e));

			message.put(Workflow.OUTCOME_KEY, "File did not archived correctly: fileName="
					+ getIngestPath(processorTransaction));
			errorMetaDataService.writeToErrorCollection(tempExecution, "MoveOriginalZipToArchiveFolder --> doExecute: " + e.getMessage());
		}
	}




	void moveFileFromLocalToNAS(String archiveWorkingDir, String fileName, int maxSftpTries, long retryTimeSecs) throws Exception {
		nasDriveUtil.moveFileFromLocalToNAS(archiveWorkingDir, fileName, maxSftpTries, retryTimeSecs);
	}
	
	protected String getDelegateExecutionId(DelegateExecution execution) {
		return execution != null ? execution.getId() : "NULL";
	}

	protected String getProcessorTransactionId(ProcessorTransaction processorTransaction) {
		return processorTransaction != null ? processorTransaction.getId() : "NULL";
	}

	protected String getIngestPath(ProcessorTransaction processorTransaction) {
		return processorTransaction != null ? processorTransaction.getLocation() + File.separator + processorTransaction.getFileName() : "NULL";
	}
}