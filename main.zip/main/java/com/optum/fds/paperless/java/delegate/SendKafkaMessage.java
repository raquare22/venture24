package com.optum.fds.paperless.java.delegate;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.kafka.KafkaProducer;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.java.TemplateFactory;
import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

@Service("SendKafkaMessage")
public class SendKafkaMessage extends OptumJavaDelegateBase {

   private static final Logger LOGGER = LoggerFactory.getLogger(SendKafkaMessage.class);
   
   private static final String DELEGATE_EXECUTION_ID= "delegateExecutionId";
   private static final String DATE_EMAIL_SENT = "dateEmailSent";
   private static final String CREATE_APPLICATION_CNS = "TrackItCnS";
   
   @Autowired
   KafkaProducer kafkaProducer;
   
   @Autowired
   EmailService emailService;
   
   @Autowired
	DocumentMetaDataService documentMetaDataService;

   private static final String DATE_FORMATTER = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

   private static final List<String> REQ_VARS = Arrays.asList(
           Workflow.TEMPLATE_NAME, Workflow.JSON_FILE, Workflow.KAFKA_TOPIC_NAME
   );
   
   public SendKafkaMessage(){
   
	   super(REQ_VARS);   
   }
   
   @Override
   protected void doExecute(DelegateExecution execution) {
	   LOGGER.debug("SendKafkaMessage-->doExecute-->ENTER");
	   
	   try {
		   String templateName = execution.getVariable(Workflow.TEMPLATE_NAME, String.class);
		   String kafkaTopic = execution.getVariable(Workflow.KAFKA_TOPIC_NAME, String.class);
		   String jsonFile = execution.getVariable(Workflow.JSON_FILE, String.class);
          
           List<DocumentMetaData> documentList = null;
           
           try {
               documentList = WorkFlowUtil.readDocumentsFromJsonFile(jsonFile);
           } catch (IOException e) {
               LOGGER.error("SendKafkaMessage -- doExecute Unable to get DocumentMetadata {}={}, {}={} {}",
                       DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
                       "jsonFile", jsonFile,
                       ExceptionUtils.getStackTrace(e));
               addErrorMsg("SendKafkaMessage-->doExecute-->Unable to get DocumentMetadata", WorkFlowUtil.getStackTrace(e));
               return;
           }
           

           for(DocumentMetaData document : documentList)
           {

               var documentFromDB = documentMetaDataService.getDocumentMetaData(document.getId());

               boolean addedToResponseFile = documentFromDB.getMetadata().getBoolean("addedToResponseFile", false);
               String eDeliveryError = (String) documentFromDB.getMetadata().get(Workflow.E_DELIVERY_ERROR);
               if (!addedToResponseFile || (addedToResponseFile && eDeliveryError != null && eDeliveryError.contains("email bounced")) ) {
                   // if the addedToResponseFile = false or null
                   // if addedToResponseFile = true and eDeliveryError is email bounced, then send second response
                   responseStringAssignment(execution, documentFromDB, templateName, kafkaTopic);
               } else {
                   LOGGER.info("SendKafkaMessage - skipping kafka message already sent id={}",  document.getId());
               }

             
           }

	   }
	   catch(Exception e) {
           LOGGER.error("doExecute Unable to convert JSON File to response {}={} {}",
                  DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),

                   ExceptionUtils.getStackTrace(e));
           addErrorMsg("SendKafkaMessage-->doExecute-->Unable to convert JSON File to response", WorkFlowUtil.getStackTrace(e));
       }finally {
           if (newErrors() && errorMap.size() > 1) {
               DelegateUtils.sendErrorNotification(execution, errorMap, DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution), emailService);
           }
       }
       LOGGER.debug("SendKafkaMessage-->doExecute-->EXIT");
	
  }
   
   private void responseStringAssignment(DelegateExecution execution,DocumentMetaData documentMetaData, String templateName, String kafkaTopic) {

	   String responseString=null;
	   try {

           if (documentMetaData.getMetadata().containsKey(DATE_EMAIL_SENT)) {
               boolean isLong = isDataFieldLong(documentMetaData.getMetadata().get(DATE_EMAIL_SENT));
               boolean isDouble = isDataFieldDouble(documentMetaData.getMetadata().get(DATE_EMAIL_SENT));
               if (isLong) {
                   Long longDate = Long.parseLong(documentMetaData.getMetadata().get(DATE_EMAIL_SENT).toString());
                   documentMetaData.getMetadata().append(DATE_EMAIL_SENT, dateCasting(longDate));
               } else if (isDouble) {
                   Double epochDate = Double.parseDouble(documentMetaData.getMetadata().get(DATE_EMAIL_SENT).toString());
                   var longDate = epochDate.longValue();
                   documentMetaData.getMetadata().append(DATE_EMAIL_SENT, dateCasting(longDate));
               }
           }

           responseString = TemplateFactory.getInstance(templateName).convertWithTemplate(documentMetaData);
           sendResponseStringToKafka(documentMetaData.getId(), responseString, kafkaTopic);
           
           String eDeliveryError = (String) documentMetaData.getMetadata().get(Workflow.E_DELIVERY_ERROR);
           
           if ( eDeliveryError != null && eDeliveryError.contains("email bounced")) {
        	   documentMetaData.getMetadata().append("addedToResponseFileForBounceEmail", true);
        	   documentMetaDataService.saveDocumentMetaData(documentMetaData);
           } else {
               var dataFieldToUpdate = execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_PATH, String.class);
               var dataFieldValueToUpdate = execution.getVariable(Workflow.DOCUMENT_UPDATE_FLAG_VALUE, Boolean.class);
               documentMetaData.getMetadata().append(dataFieldToUpdate, dataFieldValueToUpdate);
               documentMetaDataService.saveDocumentMetaData(documentMetaData);
           }
       } catch (Exception e) {
           LOGGER.error("doExecute Exception while executing SendKafkaMessage task docId={}, {}={} {}",
                   documentMetaData.getId(),
                   DELEGATE_EXECUTION_ID, getDelegateExecutionId(execution),
                   ExceptionUtils.getStackTrace(e));
           addErrorMsg("SendKafkaMessage-->doExecute-->Exception while executing SendKafkaMessage task", WorkFlowUtil.getStackTrace(e));
       }

  }

   private void sendResponseStringToKafka(String docId, String responseString, String topic) {
	   LOGGER.info("SendKafkaMessage -- sending kafka message, docId={}, responseMessageStr={}", docId, Encode.forJava(responseString));
	   kafkaProducer.send(responseString, topic);

   }
   
   
   private String getDelegateExecutionId(DelegateExecution execution) {
       return execution != null ? execution.getId() : "NULL";
   }
   
   public boolean isDataFieldLong(Object dataField) {
       return dataField instanceof Long;
   }

   public boolean isDataFieldDouble(Object dataField) {
       return dataField instanceof Double;
   }
   
   public String dateCasting(Long longDate) {
       var date = new Date(longDate);
       var dateFormat = new SimpleDateFormat(DATE_FORMATTER);
       return dateFormat.format(date);
   }

}