package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.constants.CommonConstants;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.domain.util.ProcessorTaskUtil;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.mongo.executions.HookExecutionRecordMetaData;
import com.optum.fds.paperless.workflow.constants.OptumProcessEnum;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.HookTransactionUtil;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("ProcessRequiredFieldRule")
public class ProcessRequiredFieldRule extends OptumJavaDelegateBase {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessRequiredFieldRule.class);

	private static final List<String> REQ_VARS = Arrays.asList(Workflow.DOCID, Workflow.RULES);

	public ProcessRequiredFieldRule() {
		super(REQ_VARS);
	}
	private static final String IND_835 = "Ind_835";
	
	@Autowired
	DocumentMetaDataService documentMetaDataService;

	@Autowired
	private HookService hookService;
	 
	@Value("${skipEFT_spaceIds}")
	private List<Integer> skipEFT_spaceIds;

	@Value("${skipEFT_categories}")
	private List<String> skipEFT_categories;

	@Value("${checkInd_835_spaceIds}")
	private List<Integer> checkInd_835_spaceIds;

	@SuppressWarnings("unchecked")
	protected void doExecute(DelegateExecution execution) {
		LOGGER.debug("ProcessRequiredFieldRule-->doExecute-->ENTER");
		var docId = execution.getVariable(Workflow.DOCID, String.class);
		var hookId = execution.getVariable(Workflow.HOOK_ID, String.class);
		String[] docArr = docId.split(",");
		List<String> docList = Arrays.asList(docArr);
		var documentMetaDataObjectList = documentMetaDataService.getDocumentMetaDataList(docList);
        Boolean skipRetrieveEmail = execution.getVariable(Workflow.SKIP_RETRIEVE_EMAIL, Boolean.class) != null ? execution.getVariable(Workflow.SKIP_RETRIEVE_EMAIL, Boolean.class) : false;
		List<String> successIds = new ArrayList<>();
		LOGGER.info("Prepost doc list {}", StringUtils.join(docList, ","));
		for (DocumentMetaData documentMetaDataObject : documentMetaDataObjectList) {
			HookTransactionMetaData hookTransactionMetaData = null;
			var metaData = documentMetaDataObject.getMetadata();
			try {

                if (BooleanUtils.isTrue(skipRetrieveEmail)) {
                    metaData.put(Workflow.SKIP_RETRIEVE_EMAIL, true);
                    // only validate corpMpin exists, and then set sendToDocVault true
                    if (metaData.get("corporateMpin", String.class) != null && !metaData.getString("corporateMpin").isEmpty()) {
                        metaData.put(Workflow.SEND_TO_DOCVAULT, true);
                    } else {
                        metaData.put(Workflow.SEND_TO_DOCVAULT, false);
                    }
                    execution.setTransientVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE,
                            metaData.getBoolean(Workflow.SEND_TO_DOCVAULT, false));
                    execution.setTransientVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE,
                            metaData.getBoolean(Workflow.SEND_TO_SHUTTERFLY, false));

                    LOGGER.debug("Skipping retrieve email for docId={}, sendToDocVault={}, sendToShutterfly={}",
                            documentMetaDataObject.getId(), metaData.getBoolean(Workflow.SEND_TO_DOCVAULT, false), metaData.getBoolean(Workflow.SEND_TO_SHUTTERFLY, false));
            		
            		metaData.append("prepostEnded", true);
            		
                    documentMetaDataService.saveDocumentMetaData(documentMetaDataObject);
                    continue;
                }

				// add list of docIds to execution bus for reconciliation error message
				execution.setTransientVariable("documentIds", docList);

				ArrayList<Document> rulesList = execution.getVariable(Workflow.RULES, ArrayList.class);
				sendToDocumentVaultIfPresentOrShutterflyIfMissing(metaData, rulesList);
				
				executePostCardRules(metaData);
				
				sendToShutterflyIfInvalidProviderEmail(metaData);
				
				executeZeroPayPraRules(metaData, documentMetaDataObject.getSpaceId());


				execution.setTransientVariable(Workflow.SEND_TO_DOCVAULT_MESSAGE,
						metaData.getBoolean(Workflow.SEND_TO_DOCVAULT, false));
				execution.setTransientVariable(Workflow.SEND_TO_SHUTTERFLY_MESSAGE,
						metaData.getBoolean(Workflow.SEND_TO_SHUTTERFLY, false));

				documentMetaDataService.saveDocumentMetaData(documentMetaDataObject);
				
				LOGGER.info("requiredFieldRule process complete for docId={}, sendToDocVault={}, sendToShutterfly={}, eDeliveryError={}",
						documentMetaDataObject.getId(), metaData.getBoolean(Workflow.SEND_TO_DOCVAULT, false), metaData.getBoolean(Workflow.SEND_TO_SHUTTERFLY, false), metaData.getString(Workflow.EDELIVERY_ERROR)
						);
				
				var hookExecutionMessage = new HashMap<>(Map.of(Workflow.SEND_TO_SHUTTERFLY_MESSAGE,
						"" + metaData.getBoolean(Workflow.SEND_TO_DOCVAULT, false) + "",
						Workflow.SEND_TO_DOCVAULT_MESSAGE,
						"" + metaData.getBoolean(Workflow.SEND_TO_SHUTTERFLY, false) + ""

				));

				hookTransactionMetaData = hookService.saveHookTransaction(HookTransactionUtil
						.createHookTransactionWithHookId(documentMetaDataObject, hookExecutionMessage,
								OptumProcessEnum.REQUIRED_FIELD_RULE_PROCESS.toString(), hookId));
				execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA_ID,
						hookTransactionMetaData.getId());
				successIds.add(documentMetaDataObject.getId());

				LOGGER.info("end of required field process, documentId={}", documentMetaDataObject.getId());
			} catch (Exception e) {
				LOGGER.error("doExecute Exception while executing ProcessRequiredFieldRule task {}={} {} documentId={}",
						"delegateExecutionId", execution.getId(), ExceptionUtils.getStackTrace(e), documentMetaDataObject.getId());
				
				if (hookTransactionMetaData == null) {
					var hookExecutionMessage = new HashMap<>(Map.of(Workflow.ERROR_MESSAGE, e.getMessage(), 
							Workflow.SEND_TO_SHUTTERFLY_MESSAGE, "" + metaData.getBoolean(Workflow.SEND_TO_DOCVAULT, false) + "",
							Workflow.SEND_TO_DOCVAULT_MESSAGE, "" + metaData.getBoolean(Workflow.SEND_TO_SHUTTERFLY, false) + "",
							Workflow.COMMON_STATUS, "ERROR"
							));


					hookTransactionMetaData = hookService.saveHookTransaction(HookTransactionUtil
							.createHookTransactionWithHookId(documentMetaDataObject, hookExecutionMessage,
									OptumProcessEnum.REQUIRED_FIELD_RULE_PROCESS.toString(), hookId));
					
				} else {
					var hookExecutionMessage = new HashMap<>(Map.of(Workflow.ERROR_MESSAGE, e.getMessage(),
							Workflow.SEND_TO_SHUTTERFLY_MESSAGE,
							"" + metaData.getBoolean(Workflow.SEND_TO_DOCVAULT, false) + "",
							Workflow.SEND_TO_DOCVAULT_MESSAGE,
							"" + metaData.getBoolean(Workflow.SEND_TO_SHUTTERFLY, false) + ""
		
					));
					var hookExecutionRecord = new HashMap<>(Map.of(Workflow.SPACE_ID,
							String.valueOf(hookTransactionMetaData.getSpaceId()), Workflow.CLIENTID,
							String.valueOf(hookTransactionMetaData.getClientId()), Workflow.APP_IDENTIFIER,
							hookTransactionMetaData.getAppIdentifier(), Workflow.HOOK_ID, hookId));
		
					var hookExecutionRecordMetaData = HookTransactionUtil.getHookExecutionRecord(hookExecutionRecord,
							hookExecutionMessage, OptumProcessEnum.REQUIRED_FIELD_RULE_PROCESS.toString());
		
					List<HookExecutionRecordMetaData> objhookExecutionRecordMetaData = hookTransactionMetaData
							.getHookExecutionList();
					objhookExecutionRecordMetaData.add(hookExecutionRecordMetaData);
		
					hookTransactionMetaData.setHookExecutionList(objhookExecutionRecordMetaData);
					hookService.updateHookTransaction(hookTransactionMetaData);
					
				}
				
				execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA_ID, hookTransactionMetaData.getId());
				addErrorMsg(
						"ProcessRequiredFieldRule-->doExecute-->Exception while executing ProcessRequiredFieldRule task",
						e.getMessage());

				LOGGER.info("end of required field process inside catch, documentId={}", documentMetaDataObject.getId());

				continue;
			}
		}
		Map<String, Object> updateMap = new HashMap<>();
		updateMap.put(Workflow.PREPOSTENDED, true);
		LOGGER.info("Prepost success list {}", StringUtils.join(successIds, ","));
		documentMetaDataService.saveDocumentMetaDataMulti(successIds, updateMap);
		
		LOGGER.debug("ProcessRequiredFieldRule-->doExecute-->EXIT");
	}

	void executeZeroPayPraRules(Document metaData, Integer spaceId) {
		 
		boolean spaceIdEFTInd = skipEFT_spaceIds != null && skipEFT_spaceIds.contains(spaceId) ? true : false;
		boolean spaceIdInd835 = checkInd_835_spaceIds!= null && checkInd_835_spaceIds.contains(spaceId) ? true : false;		
		
		if (spaceIdEFTInd || spaceIdInd835) {
			LOGGER.debug("ProcessRequiredFieldRule-->executeZeroPayPraRules-->ENTER");
			String emailAlertReq = metaData.getString(Workflow.EMAIL_ALERT_REQUEST);
			  
			String ind_835 = spaceIdInd835 && metaData.getString(Workflow.IND_835) == null ? "N" :  metaData.getString(Workflow.IND_835);
			  
			boolean skipEFTCategories = skipEFT_categories != null && skipEFT_categories.contains(metaData.getString(Workflow.SUBCATEGORY)) ? true : false;
			  
			if (emailAlertReq.equalsIgnoreCase(Workflow.Y) && 
					((spaceIdInd835 && skipEFTCategories && StringUtils.equalsIgnoreCase(ind_835, "Y")) || (spaceIdEFTInd && skipEFTCategories && "Y".equals(metaData.getString(Workflow.EFT_IND)))) ) {
				LOGGER.info(ind_835);
				
				metaData.put(Workflow.SEND_TO_SHUTTERFLY, false); 
			 }
			  
			if (emailAlertReq.equalsIgnoreCase(Workflow.Y) && 
					((spaceIdInd835 && skipEFTCategories && StringUtils.equalsIgnoreCase(ind_835, "N")) || (spaceIdEFTInd && skipEFTCategories && "N".equals(metaData.getString(Workflow.EFT_IND)))) ) {
				String edeliveryError= metaData.getString(Workflow.EDELIVERY_ERROR) == null ? "" : metaData.getString(Workflow.EDELIVERY_ERROR);
				   
				if (StringUtils.isEmpty(metaData.getString(Workflow.PROV_CORP_MPIN)) || StringUtils.isEmpty(metaData.getString(Workflow.TIN)) || StringUtils.isEmpty(metaData.getString(Workflow.PROVIDER_EMAIL_ID)) 
						|| (!StringUtils.isEmpty(metaData.getString(Workflow.PROVIDER_EMAIL_ID)) && edeliveryError.contains(Workflow.PROVIDER_EMAIL_ID))) {
					metaData.put(Workflow.SEND_TO_SHUTTERFLY, true);
				} else {
					metaData.put(Workflow.SEND_TO_SHUTTERFLY, false); 
				}
				   
			}
			  
		}
		
	}

	void executePostCardRules(Document metaData) {
		LOGGER.debug("ProcessRequiredFieldRule-->executePostCardRules-->ENTER");
		
		if (!StringUtils.isEmpty(metaData.getString(Workflow.EMAIL_ALERT_REQUEST))
				&& metaData.getString(Workflow.EMAIL_ALERT_REQUEST).equalsIgnoreCase(Workflow.Y)
				&& !StringUtils.isEmpty(metaData.getString(Workflow.PROV_CORP_MPIN))) {
			metaData.put(Workflow.SEND_TO_DOCVAULT, true);
		}
		else if ( StringUtils.isEmpty(metaData.getString(Workflow.PROV_CORP_MPIN)) ) {
			metaData.put(Workflow.SEND_TO_DOCVAULT, false);
		}

		LOGGER.debug("ProcessRequiredFieldRule-->executePostCardRules-->EXIT");
	}

	void sendToShutterflyIfInvalidProviderEmail(Document metaData){
		LOGGER.debug("ProcessRequiredFieldRule --> sendToShutterflyIfInvalidProciderEmail --> ENTER");
		
		if(!StringUtils.isEmpty(metaData.getString(Workflow.PROVIDER_EMAIL_ID))
				&& !(metaData.getString(Workflow.PROVIDER_EMAIL_ID).equals("Opt out"))
			&& !StringUtils.isEmpty(metaData.getString(Workflow.EDELIVERY_ERROR))
			&& metaData.getString(Workflow.EDELIVERY_ERROR).contains("Missing or invalid data: providerEmailId")
			&& Boolean.FALSE.equals(metaData.getBoolean(Workflow.SEND_TO_SHUTTERFLY))){
			metaData.put(Workflow.SEND_TO_SHUTTERFLY, true);
		}

		LOGGER.debug("ProcessRequiredFieldRule --> sendToShutterflyIfInvalidProciderEmail --> EXIT ");
	}

	@SuppressWarnings("unchecked")
	void sendToDocumentVaultIfPresentOrShutterflyIfMissing(Document metaData, ArrayList<Document> rulesList) {
		if (rulesList.isEmpty()) {
			return;
		}
		for (Document rule : rulesList) {
			String criteria = (String) rule.get(Workflow.CRITERIA);
			if (ProcessorTaskUtil.validateCriteriaMatch(criteria, metaData)) {
				metaData.put(Workflow.SEND_TO_DOCVAULT, true);
				metaData.put(Workflow.SEND_TO_SHUTTERFLY, false);
				ArrayList<String> requiredFieldsList = (ArrayList<String>) rule.get(Workflow.REQUIRED_FIELDS);

				// made a new method to reduce the complexity
				checkRequiredFields(requiredFieldsList, metaData);

				if (metaData.getBoolean(Workflow.SEND_TO_DOCVAULT, false)) {
					continue;
				}
				Boolean sendToShutterfly = rule.getBoolean(Workflow.SEND_TO_SHUTTERFLY, false);
				if (Boolean.TRUE.equals(sendToShutterfly)) {
					metaData.put(Workflow.SEND_TO_SHUTTERFLY, true);
				}
			}
		}
	}

	protected void checkRequiredFields(ArrayList<String> requiredFieldsList, Document metaData) {
		for (String requiredField : requiredFieldsList) {
			if (metaData.get(requiredField) instanceof Boolean)
			{
				LOGGER.debug("Boolean: requiredField={}", requiredField);
				continue;
			}
			if (StringUtils.isBlank(metaData.getString(requiredField))) {
				WorkFlowUtil.updateEDeliveryError(metaData, requiredField);
				metaData.put(Workflow.SEND_TO_DOCVAULT, false);
			}
		}
	}
}
