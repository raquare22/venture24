package com.optum.fds.paperless.java.delegate;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.*;

import com.google.common.util.concurrent.RateLimiter;
import com.optum.fds.paperless.model.Org;
import com.optum.fds.paperless.model.PreferenceType;
import com.optum.fds.paperless.model.ProviderPreference;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.flowable.engine.delegate.DelegateExecution;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.*;
import org.springframework.web.util.UriComponentsBuilder;

import com.optum.fds.paperless.constants.CommonConstants;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.domain.service.HookService;
import com.optum.fds.paperless.java.delegate.docvault.OutOfRetriesException;
import com.optum.fds.paperless.java.delegate.docvault.RetryOnExceptionHandler;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.mongo.executions.HookExecutionRecordMetaData;
import com.optum.fds.paperless.util.HttpUtils;
import com.optum.fds.paperless.util.SanitizeUtil;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.beans.FDSCloudGetDocumentsResponse;
import com.optum.fds.paperless.workflow.beans.ProviderDocument;
import com.optum.fds.paperless.workflow.beans.ProviderDocumentMetaData;
import com.optum.fds.paperless.workflow.constants.OptumProcessEnum;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.HookTransactionUtil;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

@Service("RetrieveProviderEmailAddress")
public class RetrieveProviderEmailAddress extends OptumJavaDelegateBase {

	private static final Logger LOGGER = LoggerFactory.getLogger(RetrieveProviderEmailAddress.class);

	private static final List<String> REQ_VARS = List.of(Workflow.DOCID);

	@Autowired
	private HookService hookService;

	@Autowired
	private OauthManagerUtil oauthManagerUtil;

	@Autowired
	private DocumentMetaDataService documentMetaDataService;

	@Autowired
	private RestTemplate restTemplate;

	private String correlationID = StringUtils.EMPTY;

	@Value("${FDSCloudPDOSpaceId}")
	private String cloudSpaceId;

	@Value("${skipEFT_spaceIds}")
	private List<Integer> skipEFT_spaceIds;

	@Value("${skipEFT_categories}")
	private List<String> skipEFT_categories;

	@Value("${checkInd_835_spaceIds}")
	private List<Integer> checkInd_835_spaceIds;

    @Value("${PDO_TPS:2}")
    private int PDO_TPS;

	DelegateExecution tempExecution;

	public RetrieveProviderEmailAddress() {
		super(REQ_VARS);
	}

	protected void doExecute(DelegateExecution execution) {
		LOGGER.debug("Entering RetrieveProviderEmailAddress delegate");

		tempExecution = execution;

        RateLimiter rateLimiter = RateLimiter.create(PDO_TPS);
		String providerEmail = StringUtils.EMPTY;
		String tin = StringUtils.EMPTY;
		String mpin = StringUtils.EMPTY;
		HookTransactionMetaData hookTransactionMetaData = null;
		var hookId = execution.getVariable(Workflow.HOOK_ID, String.class);
		var docId = execution.getVariable(Workflow.DOCID, String.class);
        var fetchSecondaryEmail = execution.getVariable(Workflow.FETCH_SECONDARY_EMAIL, Boolean.class);
		String[] docArr = docId.split(",");
		List<String> docList = Arrays.asList(docArr);
		Boolean useFDSCloud = execution.getVariable("useFDSCloud", Boolean.class);
		var documentMetaDataObjectList = documentMetaDataService.getDocumentMetaDataList(docList);
		
		for (DocumentMetaData documentMetaDataObject : documentMetaDataObjectList) {
			try {
				LOGGER.info("start of retrieve email process, documentId={}", documentMetaDataObject.getId());
				var metaData = documentMetaDataObject.getMetadata();
				tin = metaData.getString(Workflow.TIN);
				mpin = metaData.getString(Workflow.MPIN);
				var hookExecutionMessage = new HashMap<>(Map.of(Workflow.TIN, tin, Workflow.MPIN, mpin));
				hookTransactionMetaData = hookService.saveHookTransaction(HookTransactionUtil
						.createHookTransactionWithHookId(documentMetaDataObject, hookExecutionMessage,
								OptumProcessEnum.RETRIEVE_PROVIDER_EMAIL_ADDRESS_PROCESS.toString(), hookId));
				execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA_ID, hookTransactionMetaData.getId());

				
				if (checkConditions(documentMetaDataObject.getSpaceId(), metaData, execution)) {
					LOGGER.info("RetrieveProviderEmailAddresss, checkConditions not satisified, skipping retrieveProviderEmail spaceId={}, emailAlertReq={}, subCategory={}, EFT_Ind={}, Ind_835={}",
							documentMetaDataObject.getSpaceId(), metaData.getString(Workflow.EMAIL_ALERT_REQUEST), 
							metaData.getString(Workflow.SUBCATEGORY),
							metaData.getString(Workflow.EFT_IND),
							metaData.getString(Workflow.IND_835)
					);
					continue;
				}
				
				correlationID = documentMetaDataObject.getId() + "_" + documentMetaDataObject.getSpaceId();

				var providerEmailParams = createProviderEmailParams(execution, metaData);
				tin = providerEmailParams.getTin();
				mpin = providerEmailParams.getMpin();
				String subCategory = providerEmailParams.getSubCategory();

				if (tin != null && !tin.isEmpty() && tin.length() < 9) {
					tin = StringUtils.leftPad(tin, 9, '0');
				}
				if (mpin != null && !mpin.isEmpty() && mpin.length() < 9) {
					mpin = StringUtils.leftPad(mpin, 9, '0');
				}


				List<ProviderDocument> providerDocumentList = new ArrayList<>();
                List<ProviderPreference> preferenceList;
				if (Boolean.TRUE.equals(useFDSCloud) && !(StringUtils.isEmpty(tin) || StringUtils.isEmpty(mpin))) {
					providerDocumentList = getDocumentsFromFDSCloud(execution, tin, mpin, subCategory);
				} else if (!Boolean.TRUE.equals(useFDSCloud)) {
                    preferenceList = fetchEmailIdFromPreferences(execution, tin, mpin, rateLimiter);
                    String providerEmailId = "";
                    List<String> secondaryEmails = null;
                    if(preferenceList != null) {
                        var preferenceType = preferenceList.stream()
                                .filter(pref -> pref.getPreferenceTypes() != null)
                                .flatMap(pref -> pref.getPreferenceTypes().stream())
                                .filter(pt -> StringUtils.equalsIgnoreCase(pt.getClassifier(), subCategory))
                                .findFirst()
                                .orElse(null);

                        if (preferenceType != null) {
                            providerEmailId = preferenceType.getProviderEmailId();
                            secondaryEmails = preferenceType.getSecondaryEmails();
                        }

                    }

                    LOGGER.info("SubCategory={}, providerEmailId={}, correlationID={}",
                            Encode.forJava(subCategory),
                            Encode.forJava(providerEmailId),
                            Encode.forJava(correlationID));


                    if (providerEmailId != null ) {
                        metaData.put(Workflow.PROVIDER_EMAIL_ID, providerEmailId);
                        if (!Utilities.validateProviderEmail(providerEmailId)) {
                            // if providerEmail is invalid, add eDeliveryError
                            WorkFlowUtil.updateEDeliveryError(metaData, Workflow.PROVIDER_EMAIL_ID);
                        }
                    }
                    if (secondaryEmails != null && fetchSecondaryEmail) {
                        metaData.put("secondaryEmails", secondaryEmails);
                    }
                    documentMetaDataService.saveDocumentMetaData(documentMetaDataObject);
                }

				if (providerDocumentList == null) {
					providerDocumentList = new ArrayList<>();
				}

				LOGGER.info("tin={}, mpin={}, documentCount={}, correlationID={}", providerEmailParams.getTin(),
						providerEmailParams.getMpin(), providerDocumentList.size(), correlationID);

				if (!providerDocumentList.isEmpty()) {
					extracted(documentMetaDataObject, providerDocumentList, providerEmailParams, execution);
				} else {
					WorkFlowUtil.updateEDeliveryError(metaData, Workflow.PROVIDER_EMAIL_ID);
					LOGGER.info("No email found for CorrelationID {}", correlationID);
				}

				LOGGER.info("end of retrieve email process correlationID={}", correlationID);
			} catch (Exception e) {
				LOGGER.error("doExecute Retrieve Email terminated with an ERROR {}={}, {}={} {}", "delegateExecutionId",
						execution.getId(), "CorrelationID", correlationID, ExceptionUtils.getStackTrace(e));
				var hookExecutionMessage = new HashMap<>(Map.of(Workflow.PROVIDER_EMAIL, providerEmail,
						Workflow.ERROR_MESSAGE, ExceptionUtils.getStackTrace(e), Workflow.TIN, tin, Workflow.MPIN, mpin,
						Workflow.COMMON_STATUS, "ERROR"));
				var hookExecutionRecord = new HashMap<>(Map.of(Workflow.SPACE_ID,
						String.valueOf(hookTransactionMetaData.getSpaceId()), Workflow.CLIENTID,
						String.valueOf(hookTransactionMetaData.getClientId()), Workflow.APP_IDENTIFIER,
						hookTransactionMetaData.getAppIdentifier(), Workflow.HOOK_ID, hookId));

				var hookExecutionRecordMetaData = HookTransactionUtil.getHookExecutionRecord(hookExecutionRecord,
						hookExecutionMessage, OptumProcessEnum.RETRIEVE_PROVIDER_EMAIL_ADDRESS_PROCESS.toString());

				List<HookExecutionRecordMetaData> objhookExecutionRecordMetaData = hookTransactionMetaData
						.getHookExecutionList();
				objhookExecutionRecordMetaData.add(hookExecutionRecordMetaData);

				hookTransactionMetaData.setHookExecutionList(objhookExecutionRecordMetaData);
				hookService.updateHookTransaction(hookTransactionMetaData);
				execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA_ID, hookTransactionMetaData.getId());
				addErrorMsg("RetrieveProviderEmailAddress-->doExecute-->Exception while executing Retrieve Email task",
						e.getMessage());

				LOGGER.info("end of retrieve email process inside catch, correlationID={}", correlationID);
			}
		}
	}

	private List<ProviderDocument> getDocumentsFromFDSCloud(DelegateExecution execution, String tin, String mpin,
			String subCategory) throws URISyntaxException, InterruptedException, IOException {

		String fdsCloudOauthUrl = (String) execution.getVariable(Workflow.FDS_CLOUD_AUTH_URL);
		String clientId = (String) execution.getVariable(Workflow.CLOUD_CLIENT_ID);
		String clientSecret = (String) execution.getVariable(Workflow.CLOUD_CLIENT_SECRET);
		String grantType = (String) execution.getVariable(Workflow.CLOUD_GRANT_TYPE);
		
		
		String accessToken = oauthManagerUtil.getOauthToken("tokenFDSCloudPDO", clientId, clientSecret, grantType, fdsCloudOauthUrl, false, null);

		if (accessToken == null || accessToken.isEmpty()) {
			return null;
		}

		String url = (String) execution.getVariable(Workflow.FDS_CLOUD_GET_DOCUMENT_URL);

		Map<String, Object> query = new HashMap<>();
		query.put("tin", tin);
		query.put("mpin", mpin);
		query.put("fileName", subCategory);

		String queryString = createSearchTermsFromMap(query);

		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(url).queryParam("searchTerms", queryString);

		String uriString = uriBuilder.buildAndExpand(cloudSpaceId).toUriString() + "&sort=%7BmodifiedOn%3Adesc%7D";

		URI uri = new URI(uriString);

		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.set("fds-authorization", accessToken);
		HttpEntity<?> entity = new HttpEntity<>(headers);
		LOGGER.info("queryString={}", SanitizeUtil.sanitizeToString(queryString) );
		ResponseEntity<FDSCloudGetDocumentsResponse> response;
		
		
		long startTime = System.nanoTime();
		try {

			  response = restTemplate.exchange(uri, HttpMethod.GET, entity, FDSCloudGetDocumentsResponse.class);
			  long latency = (System.nanoTime() - startTime) / 1000000;
			  LOGGER.info("getFDSCloudSearchTerms Consumer=fds.paperless, ServiceName=fds.cloud, FDSCloudSpaceId={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
					  Encode.forJava(cloudSpaceId), Encode.forJava(url), HttpMethod.GET.toString(), response.getStatusCode().value(), latency );
				
		} catch (HttpStatusCodeException e) {
			long latency = (System.nanoTime() - startTime) / 1000000;
			
			LOGGER.info("getFDSCloudSearchTerms HttpStatusCodeException Consumer=fds.paperless, ServiceName=fds.cloud, FDSCloudSpaceId={}, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
					  Encode.forJava(cloudSpaceId), Encode.forJava(url), HttpMethod.GET.toString(), e.getStatusCode().value(), latency );
			
			String newAccessToken = oauthManagerUtil.getOauthToken("tokenFDSCloudPDO", clientId, clientSecret, grantType, fdsCloudOauthUrl, true, null);
			
			response = retryGetDocumentsFromFDSCloud(execution, uri, newAccessToken);

		} catch (Exception e) {
			LOGGER.error("getDocumentsFromFDSCloud Error while retrieving provider email queryString={}, err={}", queryString, ExceptionUtils.getStackTrace(e));
			return null;
		}
		
		Objects.requireNonNull(response);
		Objects.requireNonNull(response.getBody());

		return response.getBody().getDocuments();
	}


    private List<ProviderPreference> fetchEmailIdFromPreferences(DelegateExecution execution, String tin, String mpin, RateLimiter rateLimiter) throws InterruptedException, OutOfRetriesException {
        ResponseEntity<ProviderPreference> response;

        long startTime = System.nanoTime();
        try {

            response = retryFetchEmailIdFromPreferences(execution, tin, mpin, rateLimiter);
            long latency = (System.nanoTime() - startTime) / 1000000;
            LOGGER.info(" Consumer=fds.paperless, ServiceName=fds.paperless.pdo, HTTPMethod={}, HTTPStatus={}, TotalLatency={}" , HttpMethod.POST, response.getStatusCode().value(), latency );
        }catch (Exception e){
            LOGGER.error("Error while retrieving provider email , err={}", ExceptionUtils.getStackTrace(e));
            return null;
        }

        Objects.requireNonNull(response);
        Objects.requireNonNull(response.getBody());

        return List.of(response.getBody());
    }


    private ResponseEntity<ProviderPreference> retryFetchEmailIdFromPreferences(DelegateExecution execution, String tin, String mpin, RateLimiter rateLimiter) throws InterruptedException, OutOfRetriesException {
        rateLimiter.acquire();
        String clientId = (String) execution.getVariable(Workflow.PDO_CLIENT_ID);
        String clientSecret = (String) execution.getVariable(Workflow.PDO_CLIENT_SECRET);
        String grantType = (String) execution.getVariable(Workflow.CLOUD_GRANT_TYPE);
        String pdoOauthUrl = (String) execution.getVariable(Workflow.PDO_TOKEN_URL);
        var endpoint = execution.getVariable("pdoFetchPreferencesUrl", String.class);


        var retryInterval = 500L;
        var retryCount = 3;
        var retryHandler = new RetryOnExceptionHandler(retryCount, retryInterval);
        ResponseEntity<ProviderPreference> response = null;
        String msg;
        while (retryHandler.shouldRetry()) {
            try {
                try {
                    if (retryHandler.isRetry()) {
                        String newAccessToken = oauthManagerUtil.getOauthToken("PDOAuthToken", clientId, clientSecret, grantType, pdoOauthUrl, true, null);
                        LOGGER.info("retryFetchEmailIdFromPreferences  with new token Consumer=fds.paperless, ServiceName=fds.paperless.pdo, Endpoint={}, HTTPMethod={}, HTTPStatus={}",
                                Encode.forJava(endpoint), HttpMethod.POST, response.getStatusCode().value());
                        response = postRequestToPDOAPI(endpoint, tin, mpin, newAccessToken);

                    } else {
                        String accessToken = oauthManagerUtil.getOauthToken("PDOAuthToken", clientId, clientSecret, grantType, pdoOauthUrl, false, null);
                        response = postRequestToPDOAPI(endpoint, tin, mpin, accessToken);
                    }
                    break;
                } catch (HttpClientErrorException.Unauthorized e) {
                    LOGGER.error("HttpClientErrorException Unauthorized for Preferences call, responseBody={}, statusCode={}", e.getResponseBodyAsString(), e.getStatusCode());
                    retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
                    retryHandler.exceptionOccurred();
                } catch (HttpClientErrorException e) {
                    if (e instanceof HttpClientErrorException.BadRequest) {
                        LOGGER.warn("HttpClientErrorException for Preferences call: responseBody={}, statusCode={}", e.getResponseBodyAsString(), e.getStatusCode());
                    } else {
                        LOGGER.error("HttpClientErrorException for  Preferences call: responseBody={}, statusCode={}", e.getResponseBodyAsString(), e.getStatusCode());
                    }
                    return new ResponseEntity<>(e.getStatusCode());
                } catch (HttpServerErrorException e) {
                    if (e instanceof HttpServerErrorException.GatewayTimeout || e instanceof HttpServerErrorException.BadGateway) {
                        LOGGER.error("HttpClientErrorException for  Preferences call: responseBody={}, statusCode={}", e.getResponseBodyAsString(), e.getStatusCode());
                        retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
                        retryHandler.exceptionOccurred();
                    } else {
                        LOGGER.error("{} exception for  Preferences call: responseBody={}, statusCode={}", e.getClass().getSimpleName(), e.getResponseBodyAsString(), e.getStatusCode());
                        return new ResponseEntity<>(e.getStatusCode());
                    }
                } catch (RestClientException e) {
                    LOGGER.error("RestClientException for  Preferences call: and exception {} ",
                            ExceptionUtils.getStackTrace(e));

                    retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
                    retryHandler.exceptionOccurred();
                } catch (RuntimeException e) {
                    LOGGER.error("{} for  Preferences call: and exception {} ", e.getClass().getSimpleName(),
                            ExceptionUtils.getStackTrace(e));
                    retryHandler.setTimeToWaitMS(Long.sum(retryHandler.getTimeToWaitMS(), 250L));
                    retryHandler.exceptionOccurred();
                }

            } catch (OutOfRetriesException e) {
                msg = String.format(
                        "RestClientException to fetch preferences exhausted %s retries with retry time %s millis",
                        retryHandler.getNumRetries(), retryHandler.getTimeToWaitMS());
                LOGGER.error(msg);
                addErrorMsg("RestClientException", msg);
                throw new OutOfRetriesException(msg);
            }
        }
        return response;
    }


    ResponseEntity<ProviderPreference> postRequestToPDOAPI(String endpoint, String tin, String mpin, String accessToken)
            throws RestClientException {


        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.set("Authorization", accessToken);
        Map<String, String> requestBodyMap = new HashMap<>();
        requestBodyMap.put("tin", tin);
        requestBodyMap.put("mpin", mpin);
        HttpEntity<?> entity = new HttpEntity<>(requestBodyMap,headers);
        LOGGER.info("Pdo call for tin{} and mpin {} :", Encode.forJava(tin),Encode.forJava(mpin));
        return restTemplate.exchange(endpoint, HttpMethod.POST, entity, ProviderPreference.class);
    }


    private ResponseEntity<FDSCloudGetDocumentsResponse> retryGetDocumentsFromFDSCloud(DelegateExecution execution, URI uri, String newAccessToken) throws InterruptedException {

		var retryInterval = 500L;
		var retryCount = 3;
		
		var retryHandler = new RetryOnExceptionHandler(retryCount, retryInterval);
		
		// get new token for retry
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.set("fds-authorization", newAccessToken);
		HttpEntity<?> entity = new HttpEntity<>(headers);
		
		ResponseEntity<FDSCloudGetDocumentsResponse> response = null;
		
		long startTime = System.nanoTime();
		
		while (retryHandler.shouldRetry()) {
			try {
				try {
					response = restTemplate.exchange(uri, HttpMethod.GET, entity, FDSCloudGetDocumentsResponse.class);
					
					long latency = (System.nanoTime() - startTime) / 1000000;
					
					LOGGER.info("retryGetDocumentsFromFDSCloud Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}", 
							 Encode.forJava(uri.toString()), HttpMethod.GET.toString(), response.getStatusCode().value(), latency );
					break;
				} catch (HttpStatusCodeException e) {
					long latency = (System.nanoTime() - startTime) / 1000000;
				
					if (HttpUtils.validateStatusCode(e.getStatusCode())) {
						
						LOGGER.error("retryGetDocumentsFromFDSCloud HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								Encode.forJava(uri.toString()), HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						
						retryHandler.exceptionOccurred();
					} else {
						LOGGER.error("retryGetDocumentsFromFDSCloud HttpStatusCodeException Invoking Retry Mechanism Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, HTTPStatus={}, TotalLatency={}, responseBody={}, err={}", 
								Encode.forJava(uri.toString()), HttpMethod.GET.toString(), e.getStatusCode().value(), latency, e.getResponseBodyAsString(), ExceptionUtils.getStackTrace(e) );
						
						ResponseEntity<FDSCloudGetDocumentsResponse> errorResponse = new ResponseEntity<FDSCloudGetDocumentsResponse>(null, headers, e.getStatusCode().value());
						return errorResponse;
					}
				}
			} catch (OutOfRetriesException e) {

				LOGGER.error("retryFDSCloudGetCall HttpStatusCodeException 3 retries exhausted Consumer=fds.paperless, ServiceName=fds.cloud, URI={}, HTTPMethod={}, err={}", 
						Encode.forJava(uri.toString()), HttpMethod.GET.toString(), ExceptionUtils.getStackTrace(e));
				ResponseEntity<FDSCloudGetDocumentsResponse> errorResponse = new ResponseEntity<FDSCloudGetDocumentsResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
				return errorResponse;
			}
		}
		return null;
	}


	protected String createSearchTermsFromMap(Map<String, Object> metadata) {
		String searchTerms = "";
		List<String> searchConcat = new ArrayList<>();
		for (String key : metadata.keySet()) {
			String formatKey = new StringBuilder("(").append(key).append("%3D").append(metadata.get(key)).append(")")
					.toString();
			searchConcat.add(formatKey);
		}
		if (!searchConcat.isEmpty()) {
			searchTerms = String.join("%2B", searchConcat);
		}
		return searchTerms;
	}

	private RetrieveProviderEmailParams createProviderEmailParams(DelegateExecution execution, Document metaData) {
		String providerPreferenceSpaceId = execution.getVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID, String.class);
		String providerPreferenceSpaceIdV2 = execution.getVariable(Workflow.PROVIDER_PREFERENCE_SPACE_ID_V2,
				String.class);

		return new RetrieveProviderEmailParams.RetrieveProviderEmailParamsBuilder()
				.setTin(metaData.getString(Workflow.TIN)).setMpin(metaData.getString(Workflow.MPIN))
				.setSubCategory(metaData.getString(Workflow.SUBCATEGORY))
				.setProviderPreferenceSpaceId(providerPreferenceSpaceId)
				.setProviderPreferenceSpaceIdV2(providerPreferenceSpaceIdV2).build();
	}

	
	protected boolean checkConditions(Integer spaceId, Document metaData, DelegateExecution execution) {
		
		// if emailAlertReq = N, skip retrieve email
		if ("N".equals(metaData.getString(CommonConstants.EMAIL_ALERT_REQ))) {
			LOGGER.debug("exiting RetrieveProviderEmailAddress workflow with metadata.emailAlertReq: N");
			return true;
		}
		
		// if emailAlertReq = Y, it's a zero pay subCategory and EFT_Ind == Y, skip retrieve email
		boolean skipEFTCategories = skipEFT_categories != null && skipEFT_categories.contains(metaData.getString(Workflow.SUBCATEGORY)) ? true : false;
		
		boolean spaceIdEFTInd = skipEFT_spaceIds != null && skipEFT_spaceIds.contains(spaceId) ? true : false;
		
		if (spaceIdEFTInd && !skipEFTCategories && StringUtils.equalsIgnoreCase( metaData.getString(Workflow.EFT_IND), "Y")) {
			LOGGER.debug("exiting RetrieveProviderEmailAddress workflow with emailAlertReq: Y, EFT_Ind: Y, not a zero pay category");
			return true;
		}

		// if emailAlertReq = Y, it's a zero pay subCategory and Ind_835 == Y, skip retrieve email
		boolean spaceIdInd835 = checkInd_835_spaceIds!= null && checkInd_835_spaceIds.contains(spaceId) ? true : false;
		String ind_835 = spaceIdInd835 && metaData.getString(Workflow.IND_835) == null ? "N" :  metaData.getString(Workflow.IND_835);			
		
		if (spaceIdInd835 && !skipEFTCategories && StringUtils.equalsIgnoreCase(ind_835, "Y")) {
			LOGGER.debug("exiting RetrieveProviderEmailAddress workflow with emailAlertReq: Y, Ind_835: Y, not a zero pay category");
			return true;
		}
		

		
		return false;
	}


	private void extracted(DocumentMetaData documentMetaDataObject, List<ProviderDocument> providerDocumentList,
			RetrieveProviderEmailParams providerEmailParams, DelegateExecution execution) {
		String providerEmail = null;
		String frequency = null;
		String weekDay = null;
		String subscribeToEmail = "Y";
		String tin = providerEmailParams.getTin();
		String mpin = providerEmailParams.getMpin();

		var metaData = documentMetaDataObject.getMetadata();
		int documentCount = providerDocumentList.size();

		var currentDate = ZonedDateTime.now(ZoneOffset.UTC);
		AutoEnrollment autoEnrollment1;
		var autoEnrollment0 = determineDocumentIndex(providerDocumentList, documentCount, 0, currentDate);
		int index = -1;

		if (documentCount == 1) {
			if (autoEnrollment0.isValidAutoEnrollment() || autoEnrollment0.isNotAutoEnrollment()) {
				index = 0;
			}
		} else {
			autoEnrollment1 = determineDocumentIndex(providerDocumentList, documentCount, 1, currentDate);
			index = determineMulti(autoEnrollment0, autoEnrollment1);
		}

		if (index >= 0) {
			var providerDocumentMetaData = providerDocumentList.get(index).getMetadata();
			subscribeToEmail = StringUtils.isEmpty(providerDocumentMetaData.getSubscribeToEmail()) ? "Y" : providerDocumentMetaData.getSubscribeToEmail();
			providerEmail = providerDocumentMetaData.getProviderEmailId();
			frequency = StringUtils.isEmpty(providerDocumentMetaData.getFrequency()) ? "D"
					: providerDocumentMetaData.getFrequency();
			weekDay = providerDocumentMetaData.getWeekday();

		}
		LOGGER.info("index={}, tin={}, mpin={}, providerEmail={}, subscribeToEmail={}, frequency={}, weekDay={}, correlationID={}", index, tin, mpin,
				providerEmail, subscribeToEmail, frequency, weekDay, correlationID);

		if (StringUtils.isEmpty(providerEmail)) {
			LOGGER.info("updating edelivery error in extracted, providerEmail={}, correlationID={}", providerEmail, correlationID);
			WorkFlowUtil.updateEDeliveryError(metaData, Workflow.PROVIDER_EMAIL_ID);
			metaData.put(Workflow.SUBSCRIBE_TO_EMAIL,subscribeToEmail);
			documentMetaDataService.saveDocumentMetaData(documentMetaDataObject);
		} else if (providerEmail.equals("Opt out") && subscribeToEmail.equals("Y")) {
			// if providerEmail is "Opt out" and subscribeToEmail is "Y", update subscribeToEmail to "N"
			LOGGER.info("Updating opt out providerEmailId in extracted, providerEmail={}, correlationID={}", providerEmail, correlationID);
			metaData.put(Workflow.PROVIDER_EMAIL, providerEmail);
			metaData.put(Workflow.SUBSCRIBE_TO_EMAIL,"N");
			documentMetaDataService.saveDocumentMetaData(documentMetaDataObject);
		} else if(!Utilities.validateProviderEmail(providerEmail) && subscribeToEmail.equals("Y")){
			LOGGER.info("updating providerEmail in extracted, providerEmail={}, subscribeToEmail={}, correlationID={}", providerEmail, subscribeToEmail, correlationID);
			WorkFlowUtil.updateEDeliveryError(metaData,Workflow.PROVIDER_EMAIL_ID);
			metaData.put(Workflow.PROVIDER_EMAIL, providerEmail);
			metaData.put(Workflow.SUBSCRIBE_TO_EMAIL,subscribeToEmail);
			documentMetaDataService.saveDocumentMetaData(documentMetaDataObject);
		}
		else {
			metaData.put(Workflow.PROVIDER_EMAIL, providerEmail);
			metaData.put(Workflow.SUBSCRIBE_TO_EMAIL,subscribeToEmail);
			var hookExecutionMessage = new HashMap<>(Map.of(Workflow.PROVIDER_EMAIL, providerEmail, Workflow.SUBSCRIBE_TO_EMAIL,subscribeToEmail,
					Workflow.FREQUENCY,
					frequency, Workflow.TIN, providerEmailParams.getTin(), Workflow.MPIN, providerEmailParams.getMpin(),
					"fileName", providerEmailParams.getSubCategory(), "providerPreferenceSpaceId",
					providerEmailParams.getProviderPreferenceSpaceId(), "providerPreferenceSpaceIdV2",
					providerEmailParams.getProviderPreferenceSpaceIdV2(), "documentCount",
					String.valueOf(documentCount)));

			if (StringUtils.isNotEmpty(weekDay)) {
				hookExecutionMessage.put(Workflow.WEEK_DAY, weekDay);
				metaData.put(Workflow.WEEK_DAY, weekDay);
			}
			documentMetaDataService.saveDocumentMetaData(documentMetaDataObject);
			var hookId = execution.getVariable(Workflow.HOOK_ID, String.class);
			var hookTransactionId = execution.getVariable(Workflow.HOOK_TRANSACTION_METADATA_ID, String.class);
			HookTransactionMetaData hookTransactionMetaData = hookService.getHookTransactionById(hookTransactionId);

			var hookExecutionRecord = new HashMap<>(
					Map.of(Workflow.SPACE_ID, String.valueOf(hookTransactionMetaData.getSpaceId()), Workflow.CLIENTID,
							String.valueOf(hookTransactionMetaData.getClientId()), Workflow.APP_IDENTIFIER,
							hookTransactionMetaData.getAppIdentifier(), Workflow.HOOK_ID, hookId));

			var hookExecutionRecordMetaData = HookTransactionUtil.getHookExecutionRecord(hookExecutionRecord,
					hookExecutionMessage, OptumProcessEnum.RETRIEVE_PROVIDER_EMAIL_ADDRESS_PROCESS.toString());

			List<HookExecutionRecordMetaData> objhookExecutionRecordMetaData = hookTransactionMetaData
					.getHookExecutionList();
			objhookExecutionRecordMetaData.add(hookExecutionRecordMetaData);

			hookTransactionMetaData.setHookExecutionList(objhookExecutionRecordMetaData);
			hookService.updateHookTransaction(hookTransactionMetaData);
			execution.setTransientVariable(Workflow.HOOK_TRANSACTION_METADATA_ID, hookTransactionMetaData.getId());
		}

	}



	protected AutoEnrollment determineDocumentIndex(List<ProviderDocument> documentList, int documentCount, int index,
			ZonedDateTime currentDate) {
		LOGGER.debug("Entering determineDocumentIndex: documentCount={}, index={}", documentCount, index);

		// PDO have the assumption that a maximum of 2 documents will exist for a given
		// MPIN/TIN/LetterType combination
		// them being the AutoEnrollment and the pre-AutoEnrollment records.
		// The niche scenario occurs where a preference only has an AutoEnrollment
		// record with no
		// pre-AutoEnrollment record for
		// it will create a new pre-AutoEnrollment record to store client changes
		// between now and
		// AutoEnrollment date.
		// Thus if we have > 2 records they will be ignore.
		String activeDateStr = documentList.get(index).getMetadata().getActiveDate();
		if (StringUtils.isEmpty(activeDateStr)) {
			LOGGER.debug("AutoEnrollment not found: documentCount={}, index={}, {}", documentCount, index,
					getBodyFields(documentList.get(index).getMetadata()));
			return new AutoEnrollment(false, index);
		}

		ZonedDateTime activeDate;
		try {
			activeDate = ZonedDateTime.parse(activeDateStr);
		} catch (Exception e) {
			LOGGER.error("checkDocumentIndex: ZonedDateTime; {}: {}",
					getBodyFields(documentList.get(index).getMetadata()), ExceptionUtils.getStackTrace(e));
			return new AutoEnrollment(true, -1);
		}
		if (currentDate.isAfter(activeDate)) {
			LOGGER.debug("AutoEnrollment active: documentCount={}, index={}, {}", documentCount, index,
					getBodyFields(documentList.get(index).getMetadata()));
			return new AutoEnrollment(true, index);
		}
		LOGGER.debug("AutoEnrollment not active: documentCount={}, index={}, {}", documentCount, index,
				getBodyFields(documentList.get(index).getMetadata()));
		return new AutoEnrollment(true, -1);
	}

	protected int determineMulti(AutoEnrollment autoEnrollment0, AutoEnrollment autoEnrollment1) {
		if (autoEnrollment0.isValidAutoEnrollment()) {
			return 0;
		}
		if (autoEnrollment1.isValidAutoEnrollment()) {
			return 1;
		}
		if (autoEnrollment0.isNotAutoEnrollment()) {
			return 0;
		}
		if (autoEnrollment1.isNotAutoEnrollment()) {
			return 1;
		}
		return -1;
	}

	protected String getBodyFields(ProviderDocumentMetaData providerDocumentMetaData) {
		return "providerEmailId=" + providerDocumentMetaData.getProviderEmailId() + ", mpin="
				+ providerDocumentMetaData.getMpin();
	}

	public static class AutoEnrollment {

		private final boolean isAutoEnrollment;
		private final int index;

		AutoEnrollment(boolean isAutoEnrollment, int index) {
			this.isAutoEnrollment = isAutoEnrollment;
			this.index = index;
		}

		boolean isNotAutoEnrollment() {
			return !isAutoEnrollment;
		}

		public boolean isValidAutoEnrollment() {
			return isAutoEnrollment && index != -1;
		}
	}

	private static class RetrieveProviderEmailParams {
		private final String tin;
		private final String mpin;
		private final String subCategory;
		private final String providerPreferenceSpaceId;
		private final String providerPreferenceSpaceIdV2;
		private Document criteria;

		public RetrieveProviderEmailParams(RetrieveProviderEmailParamsBuilder builder) {
			this.tin = Optional.ofNullable(builder.tin).orElse(StringUtils.EMPTY);
			this.mpin = Optional.ofNullable(builder.mpin).orElse(StringUtils.EMPTY);
			this.subCategory = Optional.ofNullable(builder.subCategory).orElse(StringUtils.EMPTY);
			this.providerPreferenceSpaceId = Optional.ofNullable(builder.providerPreferenceSpaceId)
					.orElse(StringUtils.EMPTY);
			this.providerPreferenceSpaceIdV2 = Optional.ofNullable(builder.providerPreferenceSpaceIdV2)
					.orElse(StringUtils.EMPTY);
		}

		public static class RetrieveProviderEmailParamsBuilder {
			private String tin;
			private String mpin;
			private String subCategory;
			private String providerPreferenceSpaceId;
			private String providerPreferenceSpaceIdV2;

			public RetrieveProviderEmailParamsBuilder setTin(String tin) {
				this.tin = tin;
				return this;
			}

			public RetrieveProviderEmailParamsBuilder setMpin(String mpin) {
				this.mpin = mpin;
				return this;
			}

			public RetrieveProviderEmailParamsBuilder setSubCategory(String subCategory) {
				this.subCategory = subCategory;
				return this;
			}

			public RetrieveProviderEmailParamsBuilder setProviderPreferenceSpaceId(String providerPreferenceSpaceId) {
				this.providerPreferenceSpaceId = providerPreferenceSpaceId;
				return this;
			}

			public RetrieveProviderEmailParamsBuilder setProviderPreferenceSpaceIdV2(
					String providerPreferenceSpaceIdV2) {
				this.providerPreferenceSpaceIdV2 = providerPreferenceSpaceIdV2;
				return this;
			}

			public RetrieveProviderEmailParams build() {
				return new RetrieveProviderEmailParams(this);
			}
		}

		public String getTin() {
			return tin;
		}

		public String getMpin() {
			return mpin;
		}

		public String getSubCategory() {
			return subCategory;
		}

		public String getProviderPreferenceSpaceId() {
			return providerPreferenceSpaceId;
		}

		public String getProviderPreferenceSpaceIdV2() {
			return providerPreferenceSpaceIdV2;
		}

		public Document getCriteria() {

			if (criteria == null) {
				criteria = new Document();
				if (StringUtils.isEmpty(providerPreferenceSpaceIdV2)) {
					criteria.append("spaceId", Integer.parseInt(providerPreferenceSpaceId));
				} else {
					criteria.append("spaceId", Integer.parseInt(providerPreferenceSpaceIdV2)).append("metadata.mpin",
							mpin);
				}
				criteria.append("metadata.tin", tin).append("metadata.fileName", subCategory);
			}
			return criteria;
		}
	}
}
