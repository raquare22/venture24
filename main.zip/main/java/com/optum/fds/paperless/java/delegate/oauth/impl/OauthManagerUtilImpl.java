package com.optum.fds.paperless.java.delegate.oauth.impl;

import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.EhCache;
import com.optum.fds.paperless.java.delegate.oauth.AuthorizationOauthProvider;
import com.optum.fds.paperless.java.delegate.oauth.OauthManagerUtil;
import com.optum.fds.paperless.java.delegate.oauth.bean.HttpConstants;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

import org.flowable.engine.delegate.DelegateExecution;
import org.owasp.encoder.Encode;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Component
public class OauthManagerUtilImpl implements OauthManagerUtil {
    private static final Logger logger = LoggerFactory.getLogger(OauthManagerUtilImpl.class);

    @Autowired
    private EhCache ehCache;

    @Autowired
    private AuthorizationOauthProvider authorizationProvider;
    
    @Value("${TOKEN_EXPIRY_IN_SECONDS:60}")
    private Integer token_expiry_in_seconds;
    
    
    public String getOauthToken(String tokenType, String clientId, String clientSecret, String grantType, String oauthUrl, boolean getNewToken, String scope) {
    	Optional<OauthTokenExtended> oauthTokenExtendedOptional = null ;
        
        String docToken = ehCache.getOauthTokenCache(tokenType);
        
		if ( docToken == null || getNewToken ) {
			oauthTokenExtendedOptional = getOauthTokenExtended(clientId, clientSecret, oauthUrl, grantType, scope);
			
			// got new token so put it in cache
			var accessTokenOptional = oauthTokenExtendedOptional.map(OauthTokenExtended::getAccessToken);
			var expiresInOptional = oauthTokenExtendedOptional.map(OauthTokenExtended::getExpiresIn);
			
			var accessToken = accessTokenOptional.isPresent() ? accessTokenOptional.get() : null;
			
			var expiresIn = expiresInOptional.isPresent() ? expiresInOptional.get() : 3600;
			
			// expire token before actual expiry
			if (expiresIn > token_expiry_in_seconds) {
				expiresIn = expiresIn - token_expiry_in_seconds;
			}

            ehCache.putOauthTokenWithExpiry(tokenType, accessToken, expiresIn);
			
			return accessToken;
			
		}
        return docToken;
    }
    
    public Optional<OauthTokenExtended> getOauthTokenExtended(String appId, String appSecret, String url, String grantType, String scope) {
    	var tokenExtended = new OauthTokenExtended(appId, appSecret, url, grantType, scope);
        if(scope != null && !scope.isEmpty())
        {
            tokenExtended.setScope(scope);
        }
        try {
            tokenExtended = refreshToken(tokenExtended);
        } catch (InterruptedException e) {
            logger.error("OauthManagerUtilImpl-->getOauthTokenExtended-->Error getting the OauthToken", e);
            return Optional.empty();
        }
        return Optional.of(tokenExtended);
    }


    public OauthTokenExtended refreshToken(OauthTokenExtended oauthTokenExtended) throws InterruptedException {
        try {
            var url = oauthTokenExtended.getUrl();
            var optionalToken = authorizationProvider.getOauth2Token(url, oauthTokenExtended);
            if (optionalToken.isPresent()) {
                var token = optionalToken.get();
                oauthTokenExtended.setAccessToken(token.getAccessToken());
                oauthTokenExtended.setTokenType(token.getTokenType());
                oauthTokenExtended.setObtainedOn(new Date());
                oauthTokenExtended.setExpiresIn(token.getExpiresIn());
            } else {
                oauthTokenExtended.setAccessToken(null);
                oauthTokenExtended.setObtainedOn(null);
                oauthTokenExtended.setExpiresIn(null);
            }
        } catch (InterruptedException e) {
            logger.error("refreshToken Error retrieving Token {}",ExceptionUtils.getStackTrace(e));
            throw e;

        }
        return oauthTokenExtended;
    }
}
