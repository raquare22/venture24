package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.workflow.constants.Workflow;
import org.flowable.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("RequiredVarsForMatchAndMergeDocumentsFromDb")
public class RequiredVarsForMatchAndMergeDocumentsFromDb extends OptumJavaDelegateBase{
    private static final Logger LOGGER = LoggerFactory.getLogger(RequiredVarsForMatchAndMergeDocumentsFromDb.class);

    private static final List<String> REQ_VARS = List.of(
            Workflow.SEARCH_CRITERIA,
            Workflow.SEARCH_WINDOW,
            Workflow.MATCH_CRITERIA,
            Workflow.DOCUMENT_UPDATE_FLAG_PATH,
            Workflow.DOCUMENT_UPDATE_FLAG_VALUE,
            Workflow.TEMPLATE_NAME
    );

    public RequiredVarsForMatchAndMergeDocumentsFromDb() {
        super(REQ_VARS);
    }

    @Override
    protected void doExecute(DelegateExecution execution) {
        LOGGER.debug("RequiredVarsForMatchAndMergeDocumentsFromDb-->doExecute-->Required variables are present in execution bus");
    }
}