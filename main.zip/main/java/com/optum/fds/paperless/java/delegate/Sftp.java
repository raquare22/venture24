package com.optum.fds.paperless.java.delegate;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.newrelic.api.agent.Trace;
import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.domain.service.ProcessorsService;
import com.optum.fds.paperless.domain.service.ScheduledSftpMonitor;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.SftpMonitorUtil;
import com.optum.fds.paperless.util.SftpUtil;
import com.optum.fds.paperless.util.Utilities;
import com.optum.fds.paperless.workflow.constants.Workflow;

@Service("Sftp")
public class Sftp extends OptumJavaDelegateBase {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(Sftp.class);
	
	@Value("${INGEST_ROOT}")
    private String ingestRoot;
	
	@Autowired
    ScheduledSftpMonitor scheduledSftpMonitor;
    
    @Autowired
    ErrorMetaDataService errorMetaDataService;
    
    @Autowired
    SftpUtil sftpUtil;
    
    @Autowired
    SftpMonitorUtil sftpMonitorUtil;
    
    @Autowired
    ProcessorService processorService;
    
    @Autowired
    ProcessorsService processorsService;
    
    private static final String HOST_NAME_SOURCE = "host_name_source";
    private static final String USER_NAME_SOURCE = "username_source";
    private static final String USER_CREDENTIALS_SOURCE = "pw_source";
    private static final String FTP_ROOT_DIR = "ftp_rootdir";
    private static final String FTP_ARCHIVE_DIR = "ftp_archivedir";
    public static final String INGEST_PATH_PROPERTY_NAME = "INGEST_ROOT";
    private static final String FILE_TYPE = "fileType";
    private static final String DIRECTORY_LISTING = "directoryListing";
    private static final String CHANNEL_SFTP = "channelSftp";

    private static final List<String> REQ_VARS = Arrays.asList(
            Workflow.PROCESSOR_METADATA
    );
    
    public Sftp() {
        super(REQ_VARS);
    }
    
    @Override
    @Trace(dispatcher = true, metricName = "execute")
    public void doExecute(DelegateExecution execution) {
    	var processor = (ProcessorMetaData) execution.getVariable(Workflow.PROCESSOR_METADATA);
        var processorConfig = (Map<String, Object>) processor.getProcessConfig();
    	try {
    		Map<String, Object> processSftpResults = null;

            Path ingestFilePath = new File(ingestRoot).toPath();
            boolean isFreeSpaceSufficient = sftpUtil.isEnoughFreeSpace(ingestFilePath, false);
            if (! isFreeSpaceSufficient) {
                LOGGER.error("FREESPACE: Not enough returning; filePath={}", ingestFilePath);
                setExitNow(execution);
                return;
            }

            String appIdentifier = processor.getAppIdentifier();
            String sftpHost = (String) processorConfig.get(HOST_NAME_SOURCE);
            String sftpUSER = (String) processorConfig.get(USER_NAME_SOURCE);
            String sftpPASS = (String) processorConfig.get(USER_CREDENTIALS_SOURCE);
            String sftpWorkingDir = (String) processorConfig.get(FTP_ROOT_DIR);
            String sftpArchiveDir = (String) processorConfig.get(FTP_ARCHIVE_DIR);
            String fileType = (String) processorConfig.get(FILE_TYPE);
            

            sftpMonitorUtil.exceptionForMissingLoginCredential(sftpHost, sftpUSER, sftpPASS, sftpWorkingDir);
            
        	// connect to ECG and download filetype based on processor config to ingest folder
            String processorTransactionId = null;
            String fullFilePath = null;
            if (sftpMonitorUtil.hasValidStatus(processor)) {
                processSftpResults = sftpMonitorUtil.proccessSFTPDirectory(sftpUSER, sftpPASS, sftpHost, sftpWorkingDir);

                List<ChannelSftp.LsEntry> directoryListing = (ArrayList<ChannelSftp.LsEntry>) processSftpResults.get(DIRECTORY_LISTING);
                if (directoryListing.isEmpty()) {
                    LOGGER.debug("Sftp --> no files in directory listing");
                    setExitNow(execution);
                    return;
                }

                ChannelSftp.LsEntry entry = getDirectoryEntryForFileType(directoryListing, fileType, appIdentifier);
                if (entry == null) {
                    LOGGER.warn("Sftp --> no new files of fileType={}", fileType);
                    setExitNow(execution);
                    return;
                }
                String entryFileName = entry.getFilename();
                execution.setTransientVariable(Workflow.FILE_NAME, entryFileName);
                String dir = sftpMonitorUtil.createFileOutputDirectoryPath(processorConfig, processor, entryFileName);

                if (!Paths.get(dir).toFile().exists()) {
                    Path filePath = Utilities.createWorkingDirectory(dir);

                    // Downloading the specified file from the remote directory to the specified folder path
                    ((ChannelSftp) processSftpResults.get(CHANNEL_SFTP)).get(entryFileName, filePath.toString());
                    LOGGER.info("Sftp --> downloaded zip file to ingest directory filePath={}, fileName={}, filesInDirectory={}", filePath, entryFileName, Files.list(filePath));
                    Transaction transactionMetaData = processorsService.createTransactionRecord(processor);
                    // Create processorTransaction entry
                    ProcessorTransaction processorTransaction = processorsService.createProcessorTransaction(processor, entryFileName, filePath.toString(), transactionMetaData.getTransactionId());
                    processorTransactionId = processorTransaction.getId();
                    LOGGER.debug("Sftp --> processorTransaction created, entryFilename={}, processorTransactionId={}", entryFileName, processorTransactionId);
                    fullFilePath = filePath.toAbsolutePath().toString() + "/" + entryFileName;
                    execution.setTransientVariable(Workflow.OUTPUT_FILE_DIR, filePath.toAbsolutePath().toString());

                } else {
                    LOGGER.warn("Sftp --> ingest directory already exists. Do not process. {}", dir);
                }
            }
        	execution.setTransientVariable(Workflow.FILE_PATH, fullFilePath);
            execution.setTransientVariable("processorTransactionId", processorTransactionId);
        } catch (Exception e) {
            LOGGER.error("doExecute {}={} {}",
                    "processorMetaDataId", processor != null ? processor.getTransactionId() : "NULL",
                    ExceptionUtils.getStackTrace(e));
            execution.setTransientVariable("Monitor_Message", "FAILURE");
            addErrorMsg("Sftp Exception", e.getMessage());
            
            errorMetaDataService.writeToErrorCollection(execution, "Sftp --> doExecute: " + e.getMessage());
        }
    }
    
    
    private ChannelSftp.LsEntry getDirectoryEntryForFileType(List<ChannelSftp.LsEntry> directoryListing, String fileType, String appIdentifier) {
    	for (ChannelSftp.LsEntry directoryEntry : directoryListing) {
    		// find file of type txt that hasn't already been processed
    		if (directoryEntry.getFilename().endsWith(fileType) && 
    				processorsService.findProcessorMetaDataByFileName(directoryEntry.getFilename(), appIdentifier) == null) {
    			return directoryEntry;
    		}
    	}
    	return null;
    }

}
