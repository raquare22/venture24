package com.optum.fds.paperless.java.delegate;

import com.optum.fds.paperless.domain.service.ErrorMetaDataService;
import com.optum.fds.paperless.java.delegate.common.DelegateUtils;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import com.optum.fds.paperless.processing.service.ProcessorTransactionsService;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.service.EmailService;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


@Service("IdentifyProcessorTransactionMetadataFromDb")
public class IdentifyProcessorTransactionMetadataFromDb  extends OptumJavaDelegateBase {

	private static final Logger LOGGER = LoggerFactory.getLogger(IdentifyProcessorTransactionMetadataFromDb.class);

	private static final String DOCUMENTS_JSON_FILE_NAME = "ProcessorTransactions.json";

	private static final List<String> REQ_VARS = List.of(Workflow.SEARCH_CRITERIA, Workflow.SEARCH_WINDOW);

	@Autowired
	ProcessorTransactionsService processorTransactionsService;

	@Autowired
	EmailService emailService;
	
	@Autowired
	ErrorMetaDataService errorMetaDataService;

	public IdentifyProcessorTransactionMetadataFromDb() {
		super(REQ_VARS);
	}

	@Override
	protected void doExecute(DelegateExecution execution) {
		LOGGER.debug("IdentifyProcessorTransactionMetadataFromDb-->doExecute-->Enter");
		try {
			String processorTransactionSearchCriteria = execution.getVariable(Workflow.SEARCH_CRITERIA, String.class);
			HashMap<String, Object> criteriaMap = validateInput(processorTransactionSearchCriteria, execution);
			if (criteriaMap == null) {
				LOGGER.error(
						"IdentifyProcessorTransactionMetadataFromDb-->doExecute-->processorTransactionSearchCriteria variable is null or invalid");
				addErrorMsg(
						"IdentifyProcessorTransactionMetadataFromDb-->doExecute-->processorTransactionSearchCriteria variable is null or invalid",
						"processorTransactionSearchCriteria object is null or invalid");
				errorMetaDataService.writeToErrorCollection(execution, "IdentifyProcessorTransactionMetadataFromDb-->doExecute-->processorTransactionSearchCriteria object is null or invalid");
				return;
			}
			Integer configSpaceId = (Integer) criteriaMap.get(Workflow.REST_CONFIG_SPACE_ID);
			if (configSpaceId == null) {
				LOGGER.error("IdentifyProcessorTransactionMetadataFromDb-->doExecute-->configSpaceId is null");
				addErrorMsg("IdentifyProcessorTransactionMetadataFromDb-->doExecute-->configSpaceId is null",
						"configSpaceId is null");
				errorMetaDataService.writeToErrorCollection(execution, "IdentifyProcessorTransactionMetadataFromDb-->doExecute-->configSpaceId is null");
				return;
			}
			String processorTransactionSearchWindow = execution.getVariable(Workflow.SEARCH_WINDOW, String.class);
			HashMap<String, Object> windowMap = validateInput(processorTransactionSearchWindow, execution);
			if (windowMap == null) {
				LOGGER.error(
						"IdentifyProcessorTransactionMetadataFromDb-->doExecute-->processorTransactionSearchWindow variable is null or invalid");
				addErrorMsg(
						"IdentifyProcessorTransactionMetadataFromDb-->doExecute-->processorTransactionSearchWindow variable is null or invalid",
						"processorTransactionSearchWindow object is null or invalid");
				errorMetaDataService.writeToErrorCollection(execution, "IdentifyProcessorTransactionMetadataFromDb-->doExecute-->processorTransactionSearchWindow object is null or invalid");
				return;
			}
			var processorTransactionCriteriaFilter = WorkFlowUtil.getSearchWindowCriteria(processorTransactionSearchWindow);
			if (processorTransactionCriteriaFilter == null) {
				LOGGER.error("IdentifyProcessorTransactionMetadataFromDb-->doExecute-->search_window is invalid");
				addErrorMsg("IdentifyProcessorTransactionMetadataFromDb-->doExecute-->search_window is invalid",
						"search_window is invalid");
				errorMetaDataService.writeToErrorCollection(execution, "IdentifyProcessorTransactionMetadataFromDb-->doExecute-->search_window is invalid");
				return;
			}

			List<ProcessorTransactionMetadata> processorTransactionList = processorTransactionsService.getProcessorTransactionMetaData(processorTransactionSearchCriteria,
							processorTransactionCriteriaFilter);
			if (CollectionUtils.isEmpty(processorTransactionList)) {
				LOGGER.debug(
						"IdentifyProcessorTransactionMetadataFromDb-->doExecute-->processorTransactionList is null or empty; delegateExecutionId={}, spaceId={}, documentSearchCriteria={}",
						execution.getId(), configSpaceId, processorTransactionSearchCriteria);
				String messgeKey = execution.getVariable(Workflow.PROCESS_KEY) + "_message";
				 execution.setTransientVariable(messgeKey,
						"IdentifyProcessorTransactionMetadataFromDb processorTransactionList is null or empty");
				setExitNow(execution);
				return;
			}
			
			// add list of processorTransactionIds to execution bus for reconciliation error message 
			List<String> processorTransactionIds = new ArrayList<String>();
			processorTransactionList.forEach(e -> processorTransactionIds.add(e.getId()));
			 execution.setTransientVariable("processorTransactionIds", processorTransactionIds);

			String tempWorkingPath = WorkFlowUtil.getTemporaryWorkingPath(configSpaceId);

			var jsonFile = WorkFlowUtil.processorTransactionMetadataListToFile(processorTransactionList,
					tempWorkingPath, DOCUMENTS_JSON_FILE_NAME);

			 execution.setTransientVariable(Workflow.OUTPUT_FILE_DIR, tempWorkingPath);
			 execution.setTransientVariable(Workflow.JSON_FILE, jsonFile.getAbsolutePath());

		} catch (Exception e) {
			LOGGER.error("doExecute Exception while executing IdentifyProcessorTransactionMetadataFromDb task {}={} {}",
					"delegateExecutionId", execution.getId() ,
					ExceptionUtils.getStackTrace(e));
			addErrorMsg(
					"IdentifyProcessorTransactionMetadataFromDb-->doExecute-->Exception while executing IdentifyProcessorTransactionMetadataFromDb task",
					WorkFlowUtil.getStackTrace(e));
			errorMetaDataService.writeToErrorCollection(execution, "IdentifyProcessorTransactionMetadataFromDb-->doExecute: " + e.getMessage());
		} finally {
			if (newErrors() && errorMap.size() > 1) {
				DelegateUtils.sendErrorNotification(execution, errorMap,
						DelegateUtils.generateMessageforCronExpressionHookWorkflow(execution), emailService);
			}
		}
		LOGGER.debug("IdentifyProcessorTransactionMetadataFromDb-->doExecute-->Exit");
	}

	@SuppressWarnings("unchecked")
	private HashMap<String, Object> validateInput(String executionBusData, DelegateExecution execution) {
		HashMap<String, Object> map = null;
		try {
			map = Parser.parseJson(executionBusData, HashMap.class);
		} catch (IOException e) {
			LOGGER.error("validateInput Input format is incorrect for the variable {}={} {}", executionBusData,
					executionBusData, ExceptionUtils.getStackTrace(e));
			addErrorMsg(
					"IdentifyProcessorTransactionMetadataFromDb-->validateInput-->Input format is incorrect for the variable "
							+ executionBusData,
					WorkFlowUtil.getStackTrace(e));
			errorMetaDataService.writeToErrorCollection(execution, "IdentifyProcessorTransactionMetadataFromDb-->validateInput: " + e.getMessage());
		}
		return map;
	}
}
