package com.optum.fds.paperless.redis.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.model.GenericResponse;
import org.apache.commons.lang3.exception.ExceptionUtils;

public class Payload {
	private String key;
	private String url;
	private String delegate;
	private String request;
	private Map<?, ?> response;
	private Map<?, ?> callback;
	private StringBuilder jsonStrBuilder;

	private static final Logger LOGGER = LoggerFactory.getLogger(Payload.class);

	public Payload(List<String> jsonStrList) {
		ctor(jsonStrList, true);
	}

	public void ctor(List<String> jsonStrList, boolean excludeRetryCnt) {
		for (String jsonStr : jsonStrList) {
			LOGGER.debug("jsonStr={}", jsonStr);
			if (jsonStr.contains("QUEUE")) {
				continue;
			}
			convert(jsonStr, excludeRetryCnt);
		}
	}

	public Payload(String jsonStr) {
		convert(jsonStr, true);
	}
	
	public Payload(String jsonStr, boolean excludeRetryCnt) {
		convert(jsonStr, excludeRetryCnt);
	}
	
	public void convert(String jsonStr) {
		convert(jsonStr, true);
	}

	@SuppressWarnings("unchecked")
	public void convert(String jsonStr, boolean excludeRetryCnt) {
		LOGGER.debug("jsonStr={}", jsonStr);
		try {
			jsonStrBuilder = new StringBuilder(jsonStr);
			Map<String, Object> payloadMap = new ObjectMapper().readValue(jsonStr, HashMap.class);

			key = (String) payloadMap.get("key");
			LOGGER.debug("key={}", key);

			ArrayList<String> arrayList = (ArrayList<String>) payloadMap.get("url");
			if (arrayList != null && ! arrayList.isEmpty()) {
				url = arrayList.get(0);
				LOGGER.debug("urlArrayList[0]={}", url);
			}
			arrayList = (ArrayList<String>) payloadMap.get("delegate");
			if (arrayList != null && ! arrayList.isEmpty()) {
				delegate = arrayList.get(0);
				LOGGER.debug("delegateArrayList[0]={}", delegate);
			}
			arrayList = (ArrayList<String>) payloadMap.get("request");
			if (arrayList != null && ! arrayList.isEmpty()) {
				request = arrayList.get(0);
				LOGGER.debug("requestArrayList[0]={}", request);
			}
			response = (Map) payloadMap.get("response");
			LOGGER.debug("response={}", response);

			ArrayList<Map> callbackArrayList = (ArrayList<Map>) payloadMap.get("callbackMap");
			if (callbackArrayList != null && ! callbackArrayList.isEmpty()) {
				callback = callbackArrayList.get(0);
				LOGGER.debug("callbackArrayList[0]={}", callback);
			}
		} catch (JsonProcessingException e) {
			LOGGER.error("Convert Error: {}", ExceptionUtils.getStackTrace(e));
		}
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDelegate() {
		return delegate;
	}

	public void setDelegate(String delegate) {
		this.delegate = delegate;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public Map<?, ?> getResponse() {
		return response;
	}

	public GenericResponse getGenericResponse() {
		if (response == null) {
			return null;
		}
		String statusCode = null;
		String statusMessage = null;
		String responseMsg = null;
		try {
			statusCode = (String) response.get("statusCode");
			statusMessage = (String) response.get("statusMessage");
			try {
				Map<?, ?> responseMsgMap = (Map<?, ?>) response.get("responseMsg");
				responseMsg = new ObjectMapper().writeValueAsString(responseMsgMap);
			} catch (ClassCastException e) {
				LOGGER.info("GenericResponse: {}", e.getMessage());
				responseMsg = (String) response.get("responseMsg");
			}
		} catch(ClassCastException | JsonProcessingException e) {
			LOGGER.error("GenericResponse Error: {}", ExceptionUtils.getStackTrace(e));
			responseMsg = "{\"GenericResponse\":" +  "\"" + e.getMessage() + "\"}";
		}
		return new GenericResponse(statusCode, statusMessage, responseMsg);
	}

	public void setResponse(Map<?, ?> response) {
		this.response = response;
	}

	public Map<?, ?> getCallback() {
		return callback;
	}

	public void setCallback(Map<?, ?> callback) {
		this.callback = callback;
	}

	public String getJsonStr() {
		return jsonStrBuilder.toString();
	}

	@Override
	public String toString() {
		return "Packet [key=" + key + ", url=" + url + ", delegate=" + delegate + ", request=" + request + ", callback="
				+ callback + ", jsonStr=" + jsonStrBuilder.toString() + "]";
	}
}
