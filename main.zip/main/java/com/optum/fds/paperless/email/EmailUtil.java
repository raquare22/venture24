package com.optum.fds.paperless.email;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.optum.fds.paperless.util.Parser;

public class EmailUtil {

	private static final String HTML_DOUBLE_LINE_BREAK = "<br><br>";
	private static final String HTML_KEY_NAME = "<b> %s: </b>";
	private static final String HTML_VALUE = "&nbsp; %s";
	private static final String HTML_DIV_PADDING_START = "<div style=\"padding-left: 40px;\">";
	private static final String HTML_DIV_PADDING_END = "</div>";
	public static final String HTML_EMPTY = "<html></html>";
	static StringBuilder htmlResult = new StringBuilder();

	private EmailUtil() {
	};

	public static String jsonToHtml(String jsonStr) throws IOException {
		if (StringUtils.isEmpty(jsonStr)) {
			return HTML_EMPTY;
		}
		LinkedHashMap<String, Object> jsonMap = Parser.parseJson(jsonStr, LinkedHashMap.class);
		htmlResult.delete(0, htmlResult.length());
		jsonMapToHtml(jsonMap);
		htmlResult.insert(0, "<html>");
		htmlResult.append("</html>");
		return htmlResult.toString();
	}

	private static void jsonMapToHtml(Map<String, Object> jsonMap) throws IOException {

		for (Map.Entry<String, Object> entry : jsonMap.entrySet()) {
			if (entry.getValue() instanceof LinkedHashMap<?, ?>) {
				htmlResult.append(String.format(HTML_KEY_NAME, entry.getKey()));
				htmlResult.append(HTML_DOUBLE_LINE_BREAK);
				htmlResult.append(HTML_DIV_PADDING_START);
				jsonMapToHtml((LinkedHashMap<String, Object>) entry.getValue());
				htmlResult.append(HTML_DIV_PADDING_END);
			} else if (entry.getValue() instanceof ArrayList) {
				htmlResult.append(String.format(HTML_KEY_NAME, entry.getKey()));
				htmlResult.append(HTML_DIV_PADDING_START);
				for (Object element : (ArrayList) entry.getValue()) {
					jsonMapToHtml((LinkedHashMap<String, Object>) element);
				}
			} else {
				htmlResult.append(String.format(HTML_KEY_NAME, entry.getKey()));
				jsonMapToHtml(String.valueOf(entry.getValue()));
			}
		}
		;
	}

	private static void jsonMapToHtml(String value) {
		htmlResult.append(String.format(HTML_VALUE, value));
		htmlResult.append(HTML_DOUBLE_LINE_BREAK);
	}
}
