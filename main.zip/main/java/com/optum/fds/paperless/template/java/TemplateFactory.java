package com.optum.fds.paperless.template.java;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.impl.*;
import org.eclipse.collections.impl.map.mutable.UnifiedMap;

import java.util.Map;

public final class TemplateFactory {
	private static final Map<String, TemplateHandler> TEMPLATE_HANDLERS = new UnifiedMap<>();

	/**
	 * Register your templates here. extend TemplateHandler class to override your
	 * own implementation. add that impl in the map
	 */
	static {
		TEMPLATE_HANDLERS.put(Templates.CHECK_WRITE_PRA_RESPONSE.getTemplate(), new CheckWritePRAResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.CHECK_WRITE_PRA_COMPANION.getTemplate(), new CheckWritePRACompanionTemplate());
		TEMPLATE_HANDLERS.put(Templates.MATCH_AND_MERGE.getTemplate(), new CheckWritePRAMatchAndMergeTemplate());
		TEMPLATE_HANDLERS.put(Templates.CHECK_WRITE_PRA_EMAIL_ALERT.getTemplate(), new CheckWritePRAEmailAlertTemplate());
	    TEMPLATE_HANDLERS.put(Templates.FILTER_REQ_FIELD_FOR_DOCVAULT.getTemplate(), new FilterReqFieldForDocvaultTemplate());
		TEMPLATE_HANDLERS.put(Templates.PDO_CSV.getTemplate(), new PDOCSVTemplate());
		TEMPLATE_HANDLERS.put(Templates.EMAIL_REQUEST_TO_PEN.getTemplate(), new EmailRequestToPENTemplate());
		TEMPLATE_HANDLERS.put(Templates.TRACK_IT_RESPONSE.getTemplate(), new TrackItResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.ADT_CNS_EMAIL_REQUEST_TO_PEN.getTemplate(), new ADTCNSEmailRequestToPENTemplate());
		TEMPLATE_HANDLERS.put(Templates.TRACKIT_EMAIL_REQUEST_TO_PEN.getTemplate(), new TrackItEmailRequestToPENTemplate());
		TEMPLATE_HANDLERS.put(Templates.COSMOS_DOC1_STATUS.getTemplate(), new COSMOSDoc1StatusTemplate());
		TEMPLATE_HANDLERS.put(Templates.COSMOS_ACK.getTemplate(), new COSMOSAckTemplate());
		TEMPLATE_HANDLERS.put(Templates.ETS_APPEALS_RESPONSE.getTemplate(), new ETSAppealsResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.MR_APPEALS_RESPONSE.getTemplate(), new MRAppealsResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.ODAR_RESPONSE.getTemplate(), new ODARResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.PRIOR_AUTH_RESPONSE.getTemplate(), new PriorAuthResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.COSMOS_PRA_COMPANION.getTemplate(), new CosmosPRACompanionTemplate());
		TEMPLATE_HANDLERS.put(Templates.CSP_CLAIMS_RESPONSE.getTemplate(), new CSPClaimsResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.FDS_CLOUD_SEARCH_TERMS.getTemplate(), new FDSCloudSearchTermsTemplate());
		TEMPLATE_HANDLERS.put(Templates.DOC360_METADATA_TEMPLATE.getTemplate(), new Doc360MetadataTemplate());
		TEMPLATE_HANDLERS.put(Templates.OPTUM_PAY_NUMBER_DOCUMENT.getTemplate(), new OptumPayNumberDocumentTemplate());
		TEMPLATE_HANDLERS.put(Templates.DOCLIB_PUT_REQUEST.getTemplate(), new DocLibPutRequestTemplate());
		TEMPLATE_HANDLERS.put(Templates.OCM_RESPONSE.getTemplate(), new OCMResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.USP_CLAIMS_RESPONSE.getTemplate(), new USPClaimsResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.USP_CLAIMS_RESPONSE_API_NOTIFY.getTemplate(), new USPClaimsResponseApiNotify());
		TEMPLATE_HANDLERS.put(Templates.IHR_DOCUMENT_TEMPLATE.getTemplate(), new IHRDocumentTemplate());
		TEMPLATE_HANDLERS.put(Templates.IHR_RESPONSE.getTemplate(), new IHRResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.NGS_RESPONSE.getTemplate(), new NGSResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.CC_RESPONSE.getTemplate(), new CCResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.TXGC_CSV_DOCUMENT.getTemplate(), new TXGCCsvDocumentTemplate());	
		TEMPLATE_HANDLERS.put(Templates.CC_DOCUMENT_TEMPLATE.getTemplate(), new CCDocumentTemplate());
		TEMPLATE_HANDLERS.put(Templates.TXGC_ELGS_FILE.getTemplate(), new TexasGoldELGSTemplate());
		TEMPLATE_HANDLERS.put(Templates.TXGC_JSON_DOCUMENT.getTemplate(), new TXGCJsonDocumentTemplate());
		TEMPLATE_HANDLERS.put(Templates.CAP_RESPONSE.getTemplate(), new CAPResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.CNS_RESPONSE.getTemplate(),new CNSResponseTemplate());
//		TEMPLATE_HANDLERS.put(Templates.MNR_RESPONSE.getTemplate(), new MNRResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.HOUSE_CALLS_RESPONSE.getTemplate(), new HouseCallsResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.APPEALS_NOTIFICATION.getTemplate(), new AppealsEmailRequestToPENTemplate());
		TEMPLATE_HANDLERS.put(Templates.NGS_CLAIMS_RESPONSE.getTemplate(), new NGSClaimsResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.APPEALS_NOTIFICATIONS_RESPONSE.getTemplate(), new AppealsNotificationsResponseTemplate());
        TEMPLATE_HANDLERS.put(Templates.PCP_EMAIL_REQUEST_TO_PEN.getTemplate(), new PCPEmailRequestToPENTemplate());
        TEMPLATE_HANDLERS.put(Templates.SSBCI_EMAIL_REQUEST_TO_PEN.getTemplate(), new SSBCIEmailRequestToPENTemplate());
		TEMPLATE_HANDLERS.put(Templates.SSBCI_RESPONSE.getTemplate(), new SSBCIResponseTemplate());
		TEMPLATE_HANDLERS.put(Templates.SECONDARY_PROVIDER_EMAIL_REQUEST_TO_PEN.getTemplate(), new SecondaryProviderEmailRequestToPENTemplate());
	}
		

	private TemplateFactory() {
		throw new AssertionError("Cannot instantiate");
	}

	public static TemplateHandler getInstance(String templates) {
		if (templates.equals(Templates.OPTUM_PAY_NUMBER_DOCUMENT.getTemplate())) {
			return new OptumPayNumberDocumentTemplate();
		}
		return TEMPLATE_HANDLERS.get(templates);
	}
}