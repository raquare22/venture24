package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.list.mutable.FastList;


import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoField;
import java.util.List;

public class ETSAppealsResponseTemplate extends TemplateHandler {

    private static final String GMT = "GMT-00:00";
    private static final String STR_NULL = "NULL";
    

    @Override
    public String convertWithTemplate(String jsonString) {
        var st = this.templateLoader.getTemplate(Templates.ETS_APPEALS_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<ETSAppealsResponseTemplate.Params>newList();
        var counter = new Counter();
        for (var documentMetaData : documentMetaDataList) {
            var metaData = documentMetaData.getMetadata();
            var caseId = metaData.getString(Workflow.CASE_ID);
            var historyId = metaData.getString(Workflow.HISTORYID);
            var originalZipFileName = metaData.getString(Workflow.ORIGINAL_ZIP_FILE_NAME);
            var docLibUploadDate = metaData.getString(Workflow.METADATA_DOCLIB_UPLOAD_DATE);
            var dateEmailSent = metaData.getString(Workflow.DATE_EMAIL_SENT);

            paramsList.add(new ETSAppealsResponseTemplate.Params(caseId, historyId, originalZipFileName, docLibUploadDate, dateEmailSent));
        }

        return st.add("list", paramsList).add("counter", counter.toString()).render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        var st = this.templateLoader.getTemplate(Templates.ETS_APPEALS_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<ETSAppealsResponseTemplate.Params>newList();
        var counter = new Counter();
        for (var documentMetaData : documentMetaDataList) {
            var metaData = documentMetaData.getMetadata();
            var caseId = metaData.getString(Workflow.CASE_ID);
            var historyId = metaData.getString(Workflow.HISTORYID);
            var originalZipFileName = metaData.getString(Workflow.ORIGINAL_ZIP_FILE_NAME);
            var docLibUploadDate = metaData.getString(Workflow.METADATA_DOCLIB_UPLOAD_DATE);
            var dateEmailSent = metaData.getString(Workflow.DATE_EMAIL_SENT);

            paramsList.add(new ETSAppealsResponseTemplate.Params(caseId, historyId, originalZipFileName, docLibUploadDate, dateEmailSent));
        }

        return st.add("list", paramsList).add("counter", counter.toString()).render();
    }

    static class Params {
    	DateTimeFormatter outFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    	String format = "MM-dd-yyyy HH:mm:ss";
        private final String caseId;
        private final String historyId;
        private final String originalZipFileName;
        private String docLibUploadDate;
		private final String dateEmailSent;

        public Params(String caseId, String historyId, String originalZipFileName, String docLibUploadDate, String dateEmailSent) {
            this.caseId = caseId;
            this.historyId = historyId;
            this.originalZipFileName = originalZipFileName.trim();
            if (docLibUploadDate != null && !docLibUploadDate.isEmpty()) {
            	this.docLibUploadDate = getDate(format, outFormat, docLibUploadDate);
            } else {
            	this.docLibUploadDate = docLibUploadDate;
            }
            if (dateEmailSent != null && !dateEmailSent.isEmpty()) {
            	this.dateEmailSent = getDate(format, outFormat, dateEmailSent);
            } else {
            	this.dateEmailSent = dateEmailSent;
            }
            
        }

        public String getCaseId() {
            return caseId;
        }

        public String getHistoryId() {
            return historyId;
        }

        public String getOriginalZipFileName() {
            return originalZipFileName;
        }

        public String getDateEmailSent() {
            return dateEmailSent;
        }
        public String getDocLibUploadDate() {
			return docLibUploadDate;
		}
    }

    public static String getDate(String outputFormat, DateTimeFormatter formatter, String date) {
    	DateTimeFormatter outFormat = DateTimeFormatter.ofPattern(outputFormat);
        LocalDateTime localtime = LocalDateTime.parse(date, formatter);
        ZonedDateTime zonedDateTime = localtime.atZone(ZoneId.of(GMT));
        ZonedDateTime zonedDateTimeCST = zonedDateTime.withZoneSameInstant(ZoneId.of("America/Chicago"));
		/*
			System.out.println("localtime :" + localtime.format(outFormat));
			System.out.println("zonedDateTime :" + zonedDateTime.format(outFormat));
			System.out.println("zonedDateTimeCST :"+zonedDateTimeCST.format(outFormat));
		*/
        return zonedDateTimeCST.format(outFormat);

    }
    public static String apply(String context) {

        DateTimeFormatter formatter = new DateTimeFormatterBuilder().appendPattern("[MMddyyyy]")
                .appendPattern("[MMddyy]").appendPattern("[MM dd yy]").appendPattern("[M/d/yyyy]")
                .appendPattern("[M/dd/yyyy]").appendPattern("[MM/dd/yyyy]").appendPattern("[MM/dd/yy]")
                .appendPattern("[dd /MM /yyyy]").appendPattern("[yyyy-MM-dd'T'HH:mm:ss.SSSXXX]").appendPattern("[yyyy-MM-dd'T'HH:mm:ss.SSS'Z']")
                .appendPattern("[yyyy/MM/dd HH:mm:ss.SSSSSS]").appendPattern("[yyyy-MM-dd HH:mm:ss[.SSS]]")
                .appendPattern("[ddMMMyyyy:HH:mm:ss.SSS[ Z]]").appendPattern("[EEE MMM dd HH:mm:ss zzz yyyy]")
                .parseDefaulting(ChronoField.MONTH_OF_YEAR, 01).parseDefaulting(ChronoField.DAY_OF_MONTH, 01)
                .parseDefaulting(ChronoField.HOUR_OF_DAY, 0).parseDefaulting(ChronoField.MINUTE_OF_HOUR, 00)
                .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 00).parseDefaulting(ChronoField.MILLI_OF_SECOND, 000)
                .toFormatter();

        DateTimeFormatter formatter2 = new DateTimeFormatterBuilder().appendPattern("[M/dd/yyyy h:mm:ss a]")
                .appendPattern("[M/d/yyyy h:mm:ss a]").appendPattern("[MM/d/yyyy h:mm:ss a]")
                .appendPattern("[MM/dd/yyyy h:mm:ss a]").parseDefaulting(ChronoField.MONTH_OF_YEAR, 01)
                .parseDefaulting(ChronoField.DAY_OF_MONTH, 01).parseDefaulting(ChronoField.MINUTE_OF_HOUR, 00)
                .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 00).parseDefaulting(ChronoField.MILLI_OF_SECOND, 000)
                .toFormatter();

        DateTimeFormatter formatter3 = new DateTimeFormatterBuilder().appendPattern("[d/MM/yyyy h:mm:ss a]")
                .appendPattern("[dd/M/yyyy h:mm:ss a]").appendPattern("[dd/MM/yyyy h:mm:ss a]")
                .appendPattern("[d/M/yyyy h:mm:ss a]").parseDefaulting(ChronoField.MONTH_OF_YEAR, 01)
                .parseDefaulting(ChronoField.DAY_OF_MONTH, 01).parseDefaulting(ChronoField.MINUTE_OF_HOUR, 00)
                .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 00).parseDefaulting(ChronoField.MILLI_OF_SECOND, 000)
                .toFormatter();

        if ((context != null && context.equals(STR_NULL))) {
            return context.toString().trim();
        }

        String format = "MM-dd-yyyy HH:mm:ss";
        String date = (context == null) ? "" : context.trim();

        String resutlDate = "";
        if (StringUtils.isEmpty(date) || date.length() < 3) {
            return resutlDate;
        } else {
            try {
                resutlDate = getDate(format, formatter, date);
            } catch (DateTimeParseException e) {
                try {
                    resutlDate = getDate(format, formatter2, date);
                } catch (DateTimeParseException dtpe) {
                    try {
                        resutlDate = getDate(format, formatter3, date);
                    } catch (DateTimeParseException dtpe2) {
                        return resutlDate;
                    }
                }
            }
        }
        return resutlDate;
    }
    @Override
    public String convertWithTemplate(Object pojo) {
        // TODO Auto-generated method stub
        return null;
    }



}