package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.list.mutable.FastList;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CSPClaimsResponseTemplate extends TemplateHandler {

    @Override
    public String convertWithTemplate(String jsonString) {
        var st = this.templateLoader.getTemplate(Templates.CSP_CLAIMS_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<CSPClaimsResponseTemplate.Params>newList();
        var counter = new Counter();
        for (var documentMetaData : documentMetaDataList) {
            var metaData = documentMetaData.getMetadata();

            var createApplication = metaData.getString(Workflow.CREATE_APPLICATION);
            Date createdDate = formatDate(metaData.getString(Workflow.CREATED_DATE));

            var PassThruData = metaData.getString(Workflow.PASS_THRU_DATA);
            var deliveryMethod = metaData.getString(Workflow.E_DELIVERY_ERROR);
            var providerEmailId = metaData.getString(Workflow.PROVIDER_EMAIL_ID);

            var dateEmailSent = (metaData.getString(Workflow.DATE_EMAIL_SENT) != null && metaData.getString(Workflow.DATE_EMAIL_SENT).length() > 0)? dateEmailSentFormat(metaData.getString(Workflow.DATE_EMAIL_SENT)) : "";

            paramsList.add(new CSPClaimsResponseTemplate.Params(createApplication, createdDate, PassThruData,
                    deliveryMethod, providerEmailId, dateEmailSent));

        }
        counter.add(paramsList.size());
        return st.add("list", paramsList).add("counter", counter.toString()).add("date", new Date()).render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        var st = this.templateLoader.getTemplate(Templates.CSP_CLAIMS_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<CSPClaimsResponseTemplate.Params>newList();
        var counter = new Counter();
        for (var documentMetaData : documentMetaDataList) {
            var metaData = documentMetaData.getMetadata();

            var createApplication = metaData.getString(Workflow.CREATE_APPLICATION);
            Date createdDate =  formatDate(metaData.getString(Workflow.CREATED_DATE));

            var PassThruData = metaData.getString(Workflow.PASS_THRU_DATA);
            var deliveryMethod = metaData.getString(Workflow.E_DELIVERY_ERROR);
            var providerEmailId = metaData.getString(Workflow.PROVIDER_EMAIL_ID);

            var dateEmailSent = "";
            if (metaData.getString(Workflow.DATE_EMAIL_SENT) != null
                    && metaData.getString(Workflow.DATE_EMAIL_SENT).length() > 0)
                dateEmailSent = dateEmailSentFormat(metaData.getString(Workflow.DATE_EMAIL_SENT));

            paramsList.add(new CSPClaimsResponseTemplate.Params(createApplication, createdDate, PassThruData,
                    deliveryMethod, providerEmailId, dateEmailSent));

        }
        counter.add(paramsList.size());
        return st.add("list", paramsList).add("counter", counter.toString()).add("date", new Date()).render();
    }

    private String dateEmailSentFormat(String string) {
        SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        SimpleDateFormat targetFormat = new SimpleDateFormat("yyyyMMdd'T'HH:mm:ss.SSS'Z'");
        Date date = null;
        try {
            date = originalFormat.parse(string);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        String formattedDate = targetFormat.format(date);
        return formattedDate;
    }

    private Date formatDate(String string) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        Date date = null;
        try {
            date = formatter.parse(string);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return date;
    }

    static class Params {

        private final String createApplication;
        private final Date createdDate;
        private final String passThruData;
        private final String deliveryError;
        private final String providerEmailId;
        private final String dateEmailSent;

        public Params(String createApplication, Date createdDate, String PassThruData, String deliveryError,
                      String providerEmailId, String dateEmailSent) {
            this.createApplication = createApplication;
            this.createdDate = createdDate;
            this.passThruData = PassThruData != null ? PassThruData : " ";
            this.deliveryError = deliveryError;
            this.providerEmailId = providerEmailId != null ? providerEmailId : " ";
            this.dateEmailSent = dateEmailSent.length() > 0 ? dateEmailSent : " ";
        }

        public String getCreateApplication() {
            return createApplication;
        }

        public Date getCreatedDate() {
            return createdDate;
        }

        public String getPassThruData() {
            return passThruData;
        }

        public String getDeliveryError() {
            return deliveryError;
        }

        public String getProviderEmailId() {
            return providerEmailId;
        }

        public String getDateEmailSent() {
            return dateEmailSent;
        }
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        return null;
    }
}