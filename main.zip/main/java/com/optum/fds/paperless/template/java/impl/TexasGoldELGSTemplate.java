package com.optum.fds.paperless.template.java.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.mongo.BatchInfoTXGC;
import com.optum.fds.paperless.mongo.CodesTXGC;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ItemListTXGC;
import com.optum.fds.paperless.template.Templates;

import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.lang.StringEscapeUtils;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TexasGoldELGSTemplate extends TemplateHandler {
	
	private int counter = 1;

    @Override
    public String convertWithTemplate(String jsonString) {
        var st = this.templateLoader.getTemplate(Templates.TXGC_ELGS_FILE);

        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        
        return convertWithDocumentMetaData(documentMetaDataList);
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return null;
    }

    @Override
    public String convertWithTemplate(Object pojo) {
    	List<DocumentMetaData> document = (List<DocumentMetaData>) pojo;
    	return convertWithDocumentMetaData(document);
    }
    
    private String convertWithDocumentMetaData(List<DocumentMetaData> documentList) {
    	
    	List<ItemListTXGC> providerDataList = new ArrayList<>();
        this.counter = 1;
    	
       	var st = this.templateLoader.getTemplate(Templates.TXGC_ELGS_FILE);
           	
    	for (DocumentMetaData document : documentList) {    	
            var metadata = document.getMetadata();
            setData(metadata, providerDataList);
    	}

    	String totalCount = String.format("%03d", providerDataList.size());
    	
    	String timeStamp = getTimeStamp();
    	
    	String batchId = getBatchID();
    			
        return st.add("provData",providerDataList)
        		.add("count", totalCount)
        		.add("timestamp", timeStamp)
        		.add("batchId", batchId)
        		.render();
    }

    public String getTimeStamp() {
        long timestampInMillis = System.currentTimeMillis();
        return String.valueOf(timestampInMillis);
    }

    public String getBatchID() {
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return "TXGC"+today.format(formatter);
    }

    public void setData(org.bson.Document metadata, List<ItemListTXGC> itemList) {

        List<Map<String, Object>> codesList = (List<Map<String, Object>>) metadata.get("Codes");
        List<Map<String, Object>> providerData = (List<Map<String, Object>>) metadata.get("ProviderData");

        for (Map<String, Object> pd : providerData) {
            ItemListTXGC item = new ItemListTXGC();
            
            item.setNpi(StringEscapeUtils.escapeXml((String) metadata.get("providerNPI")));
            item.setExemptionEffectiveStartDate(StringEscapeUtils.escapeXml((String) metadata.get("exemptionEffectiveStartDate")));
            item.setExemptionEffectiveEndDate(StringEscapeUtils.escapeXml((String) metadata.get("exemptionEffectiveEndDate")));
            item.setCycleStartDate(StringEscapeUtils.escapeXml((String) metadata.get("cycleStartDate"))); 
            item.setCycleEndDate(StringEscapeUtils.escapeXml((String) metadata.get("cycleEndDate")));
            
            if (metadata.get("exemptionFlag").equals("N")) {
            	item.setTemplateName("TXGC002");
            } else {
            	item.setTemplateName("TXGC001");
            }
            
            item.setTXGCID((String) pd.get("UniqueID"));
            item.setGroupName(StringEscapeUtils.escapeXml((String) pd.get("GroupName")));
            item.setProvFirstName(StringEscapeUtils.escapeXml((String) pd.get("ProviderFirstName")));
            item.setProvLastName(StringEscapeUtils.escapeXml((String) pd.get("ProviderLastName")));
            item.setProvFullName(StringEscapeUtils.escapeXml((String) pd.get("ProviderFullName")));
            item.setProvAddr1(StringEscapeUtils.escapeXml((String) pd.get("ProviderAddressLine1")));
            item.setProvAddr2(StringEscapeUtils.escapeXml((String) pd.get("ProviderAddressLine2")));
            item.setProvCity(StringEscapeUtils.escapeXml((String) pd.get("ProviderCity")));
            item.setProvSt(StringEscapeUtils.escapeXml((String) pd.get("ProviderState")));
            item.setProvZip(StringEscapeUtils.escapeXml((String) pd.get("ProviderZip")));
            item.setProvCountry(StringEscapeUtils.escapeXml((String) pd.get("ProviderCountry")));
            item.setProvProvinceRegion(StringEscapeUtils.escapeXml((String) pd.get("ProviderProvince")));
            item.setTin(StringEscapeUtils.escapeXml((String) pd.get("tin")));
            item.setProviderType((String) pd.get("providerType"));
            item.setCount(this.counter);
            
            item.setCodes(getCodes(codesList));
            
            itemList.add(item);
            this.counter++;
        }
        
    }

    public List<CodesTXGC> getCodes(List<Map<String, Object>> codes){
        List<CodesTXGC> codeList = new ArrayList<>();

        for (Map<String, Object> cd : codes) {
            CodesTXGC code = new CodesTXGC();
            code.setProcedureCodeType(StringEscapeUtils.escapeXml((String) cd.get("procCodes")));
            code.setProcCodeDescription(StringEscapeUtils.escapeXml((String) cd.get("procCodesDescription")));
            code.setApprovalRate(StringEscapeUtils.escapeXml((String) cd.get("approvalRate")));
            code.setNumberOfCodesInCluster(StringEscapeUtils.escapeXml(String.valueOf((cd.get("nbrOfCodes")))));
            codeList.add(code);
        }
        
        return codeList;
    }
}


