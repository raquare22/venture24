package com.optum.fds.paperless.template.java.impl;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.util.StringUtils;

public class IHRDocumentTemplate extends TemplateHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(IHRDocumentTemplate.class);

    @Override
    public String convertWithTemplate(String content) {
        return null;
    }
    
    private boolean checkIfRowIsEmpty(Row row) {
        if (row == null) {
            return true;
        }
        if (row.getLastCellNum() <= 0) {
            return true;
        }
        for (int cellNum = row.getFirstCellNum(); cellNum < row.getLastCellNum(); cellNum++) {
            Cell cell = row.getCell(cellNum);
            if (cell != null && cell.getCellType() != CellType.BLANK && !StringUtils.isNullOrEmpty(cell.toString())) {
                return false;
            }
        }
        return true;
    }
    
    private String getCellValueAsString(Row row, int cellNumber) {
    	String str = "";
    	
    	Cell c = row.getCell(cellNumber);
    	
    	if (c == null || c.getCellType() == CellType.BLANK) {
    		return str;
    	}
    	
    	if (c.getCellType().equals(CellType.NUMERIC)) {
    	    str = NumberToTextConverter.toText(c.getNumericCellValue()).strip();
    	} else {
    		str = c.getStringCellValue().strip();
    	}
    	return str;
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
    	var st = this.templateLoader.getTemplate(Templates.IHR_DOCUMENT_TEMPLATE);
    	
    	List<Map<String, String>> contentList = new ArrayList<>();

        try {
            FileInputStream fis = new FileInputStream(filePath);
            Workbook workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheetAt(0);
            sheet.removeRow(sheet.getRow(0));
            
            for (Row row : sheet) {
            	if (checkIfRowIsEmpty(row)) {
            		continue;
            	}
            	Map<String, String> rowMap = new HashMap<>();
                String PROVIDER_NAME = getCellValueAsString(row, 0);
                String PROVIDER_ID = getCellValueAsString(row, 1);
                String NPI = getCellValueAsString(row, 2);
                String TIN = getCellValueAsString(row, 3);
                String GROUP_PROVIDER_ID = getCellValueAsString(row, 4);
                String CORPMPIN = getCellValueAsString(row, 5);
                String GROUP_NPI = getCellValueAsString(row, 6);
                String GROUP_TAX_ID = getCellValueAsString(row, 7);
                String EMAIL = getCellValueAsString(row, 8);
                String PROV_ADDRESS_LINE_1 = getCellValueAsString(row, 9);
                String PROV_ADDRESS_LINE_2 = getCellValueAsString(row, 10);
                String PCP_FLAG = getCellValueAsString(row, 11);
                String PROVIDER_SPECIALITY = getCellValueAsString(row, 12);
                String PROVIDER_TYPE = getCellValueAsString(row, 13);
               
                rowMap.put("providerName", PROVIDER_NAME);
                rowMap.put("providerId", PROVIDER_ID );
                rowMap.put("npi", NPI);
                rowMap.put("tin", TIN);
                rowMap.put("groupProviderId", GROUP_PROVIDER_ID);
                rowMap.put("corporateMpin", CORPMPIN);
                rowMap.put("groupNpi", GROUP_NPI);
                rowMap.put("groupTaxId", GROUP_TAX_ID);
                rowMap.put("email", EMAIL);
                rowMap.put("provAddressLine1", PROV_ADDRESS_LINE_1);
                rowMap.put("provAddressLine2", PROV_ADDRESS_LINE_2);
                rowMap.put("pcpFlag", PCP_FLAG);
                rowMap.put("providerSpecialty", PROVIDER_SPECIALITY);
                rowMap.put("providerType", PROVIDER_TYPE);
                
                contentList.add(rowMap);            
            }
            workbook.close();
            fis.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return st.add("list", contentList)
                .render();
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        return null;
    }

}
