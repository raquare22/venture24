package com.optum.fds.paperless.template.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.stringtemplate.v4.STErrorListener;
import org.stringtemplate.v4.misc.STMessage;

public class ErrorListener implements STErrorListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(ErrorListener.class);

    private void logError(STMessage stMessage, String errorType) {
        var error = String.format("String template %s error, %s", errorType, stMessage.toString());
        LOGGER.error(error);
        throw new RuntimeException(error);
    }

    @Override
    public void compileTimeError(STMessage msg) {
        this.logError(msg, "compile time");
    }

    @Override
    public void runTimeError(STMessage msg) {
        this.logError(msg, "run time");
    }

    @Override
    public void IOError(STMessage msg) {
        this.logError(msg, "IO");
    }

    @Override
    public void internalError(STMessage msg) {
        this.logError(msg, "internal");
    }
}
