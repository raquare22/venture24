package com.optum.fds.paperless.template.java.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.client.P360TXGCCodes;
import com.optum.fds.paperless.client.P360TXGCDocument;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class TXGCJsonDocumentTemplate extends TemplateHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(TXGCJsonDocumentTemplate.class);

    ObjectMapper mapper = new ObjectMapper();


    @Override
    public String convertWithTemplate(String jsonStr){
        var st = this.templateLoader.getTemplate(Templates.TXGC_JSON_DOCUMENT);

        List<Map<String, String>> metadataListMainDoc = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new StringReader(jsonStr))) {
            String line;
            while ((line = reader.readLine()) != null) {

                JSONObject obj = new JSONObject(line);
                JSONArray codesArrayObj = new JSONArray();
                if(obj.get("Codes").getClass()!=JSONArray.class){
                    codesArrayObj.put(obj.get("Codes"));
                }
                else{
                    codesArrayObj = (JSONArray) obj.get("Codes");
                }
                P360TXGCCodes[] codes = mapper.readValue(codesArrayObj.toString(), P360TXGCCodes[].class);
                String strCodes;
                try {
                    strCodes = mapper.writeValueAsString(codes);
                } catch (JsonProcessingException e) {
                    throw new RuntimeException(e);
                }
                Map<String, String> metadataMap = new HashMap<>();

                metadataMap.put("providerNPI", obj.get("npi").toString());
                metadataMap.put("ExemptionApprovalStatus", obj.get("ExemptionApprovalStatus").toString());
                metadataMap.put("ExemptionStartDt", obj.get("ExemptionStartDt").toString());
                metadataMap.put("ExemptionEndDt", obj.get("ExemptionEndDt").toString());
                metadataMap.put("ExemptionCycleStartDt", obj.get("ExemptionCycleStartDt").toString());
                metadataMap.put("ExemptionCycleEndDt", obj.get("ExemptionCycleEndDt").toString());
                metadataMap.put("Codes",strCodes);

                metadataListMainDoc.add(metadataMap);
            }
            }catch (IOException e) {
                throw  new RuntimeException(e);
            }

        return st.add("list", metadataListMainDoc)
                .render();

    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        try{
            byte[] jsonData = Files.readAllBytes(Paths.get(filePath));
            String jsonString = new String(jsonData);
            return convertWithTemplate(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String convertWithTemplate(Object obj) {
        return null;
    }

}
