package com.optum.fds.paperless.template.java.impl;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bson.Document;
import org.json.JSONObject;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class CNSResponseTemplate extends TemplateHandler {
	
	private static final String DATE_FORMATTER="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

	@Override
	public String convertWithTemplate(String jsonString) {
		
		DocumentMetaData document;
		
		try {
			document = WorkFlowUtil.readDocumentFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
		
		return convertWithTemplate(document);
	}

	@Override
	public String convertWithTemplateFromFilePath(String filePath) {

		return null;
	}

	@Override
	public String convertWithTemplate(Object pojo) {
		var st=this.templateLoader.getTemplate(Templates.CNS_RESPONSE);

		Map<String,Object> responseMap=new HashMap<>();

		DocumentMetaData document = (DocumentMetaData) pojo;

		Document metadata = document.getMetadata();

		Map<String, Object> providerDetailsResponseMap = new HashMap<>();

		Map<String, String> providerDetails = (Map<String, String>) metadata.get("providerDetails");

		Map<String, String> memberDetails = (Map<String, String>) metadata.get("memberDetails");
		responseMap.put("patientFirstName", memberDetails.get(Workflow.PATIENT_FIRST_NAME));
		responseMap.put("patientLastName", memberDetails.get(Workflow.PATIENT_LAST_NAME));
		responseMap.put("patientDateOfBirth", memberDetails.get(Workflow.PATIENT_DATE_OF_BIRTH));
		responseMap.put("lob", memberDetails.get("lob"));
		responseMap.put("state", memberDetails.get("state"));
		responseMap.put("transactionId",metadata.getString("transactionId"));

		if (metadata.getString(Workflow.DATE_EMAIL_SENT) != null && metadata.getString(Workflow.DATE_EMAIL_SENT).length() != 0)
		{
			providerDetailsResponseMap.put("dateEmailSent", formatDate(metadata.getString(Workflow.DATE_EMAIL_SENT)));
		}

		providerDetailsResponseMap.put("providerEmailId", metadata.getString(Workflow.PROVIDER_EMAIL_ID));
		providerDetailsResponseMap.put("notificationStatus","success");

		if(metadata.getString(Workflow.E_DELIVERY_ERROR) != null && metadata.getString(Workflow.E_DELIVERY_ERROR).length() != 0)
		{
			providerDetailsResponseMap.put("notificationStatus","failure");
			providerDetailsResponseMap.put("eDeliveryError", metadata.getString(Workflow.E_DELIVERY_ERROR));
		}

		List<Map<String, Object>> providerDetailsList = new ArrayList<>();

		providerDetailsResponseMap.put("corporateMpin", metadata.getString(Workflow.PROV_CORP_MPIN));
		providerDetailsResponseMap.put("providerTin", metadata.getString(Workflow.TIN));
		providerDetailsResponseMap.put("admittingProviderName", providerDetails.get("admittingProviderName"));
		providerDetailsResponseMap.put("facilityProvider", providerDetails.get("facilityProvider"));
		providerDetailsResponseMap.put("providerName", providerDetails.get(Workflow.PROVIDER_NAME));
		providerDetailsResponseMap.put("providerNpi", providerDetails.get("providerNpi"));
		providerDetailsResponseMap.put("isBHProvider", metadata.get("isBHProvider"));

		providerDetailsList.add(providerDetailsResponseMap);

		return st.add("documentInfo", responseMap).add("list", providerDetailsList).render();
	}

	
	private String formatDate(String string) {
        SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMATTER);
        Date date = null;
        try {
            date = formatter.parse(string);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return formatter.format(date);   
    }
}
