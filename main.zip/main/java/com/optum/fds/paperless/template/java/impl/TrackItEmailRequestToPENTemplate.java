package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class TrackItEmailRequestToPENTemplate extends TemplateHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(TrackItEmailRequestToPENTemplate.class);

    @Override
    public String convertWithTemplate(String jsonString) {

        DocumentMetaData document;
        try {
            document = WorkFlowUtil.readDocumentFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        
        return convertWithTemplate(document);
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {

        DocumentMetaData document;
        try {
            document = WorkFlowUtil.readDocumentFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return convertWithTemplate(document);
    }

    @Override
	public String convertWithTemplate(Object pojo) {
		var st = this.templateLoader.getTemplate(Templates.TRACKIT_EMAIL_REQUEST_TO_PEN);

        DocumentMetaData document = (DocumentMetaData) pojo;

        org.bson.Document metadata = document.getMetadata();

        List<Map<String, Object>> recordsList = new ArrayList<>();

        List<Map<String, Object>> metadataRecordsList = (List<Map<String, Object>>) metadata.get("recordsCountList");

        if (metadataRecordsList != null && !metadataRecordsList.isEmpty()) {
            for (Map<String, Object> record : metadataRecordsList) {
                Map<String, Object> newRecord = new HashMap<>();

                String tin = (String) record.get("tin");
                if (tin.length() < 9) {
                    tin = StringUtils.leftPad(tin, 9, "0");
                }
                String formattedTin = "XXXXX" + tin.substring(tin.length() - 4);

                String corporateMpin = (String) record.get("corpMpin");
                if (corporateMpin.length() < 9) {
                    corporateMpin = StringUtils.leftPad(corporateMpin, 9, "0");
                }
                String formattedCorporateMpin = "XXXXX" + corporateMpin.substring(corporateMpin.length() - 4);
                String providerOrganizationName = (String) record.get("providerName");

                newRecord.put("formattedTin", formattedTin);
                newRecord.put("formattedCorpMpin", formattedCorporateMpin);
                newRecord.put("providerOrganizationName", providerOrganizationName);
				newRecord.put("rejectedClaims", record.get("dailyRejectedClaimsActionRequiredCount"));
				newRecord.put("documentationEdits", record.get("dailySmartEditsCount"));
				newRecord.put("priorAuthorizations", record.get("dailyPaanAdditionalInfoCount"));
				newRecord.put("referrals", record.get("referralBothCount"));
				newRecord.put("pendingClaims", record.get("bothPendingClaimsCount"));
				int recon = Integer.parseInt(String.valueOf(record.getOrDefault("dailyReconCount", "0")));
				int dispute = Integer.parseInt(String.valueOf(record.getOrDefault("dailyDisputeCount", "0")));
				newRecord.put("reconsiderations", recon + dispute);
				newRecord.put("pendedTickets", record.get("dailyPendCount"));
				newRecord.put("priorAuthAppeals", record.get("dailyPaanAppealsCount"));
				newRecord.put("expiringReferrals", record.get("referralAboutToExpireCount"));
				newRecord.put("recordType", record.get("recordType"));
				recordsList.add(newRecord);
            }


            return st.add("document", document)
                    .add("list", recordsList)
                    .render();
        }
        return null;

	}
}