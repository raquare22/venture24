package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.AckFileBean;
import com.optum.fds.paperless.mongo.FileDetail;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class COSMOSAckTemplate extends TemplateHandler {

    @Override
    public String convertWithTemplate(String jsonString) {

        var st = this.templateLoader.getTemplate(Templates.COSMOS_ACK);

        AckFileBean ackFileBean;

        try {
            ackFileBean = WorkFlowUtil.readAckFileBeanFromJsonFile(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        List<FileDetail> list;
        list = ackFileBean.getFileList();
        return st.add("batch", ackFileBean).add("list", list).render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return null;
    }

    @Override
    public String convertWithTemplate(Object pojo) {

        var st = this.templateLoader.getTemplate(Templates.COSMOS_ACK);

        AckFileBean ackFileBean = (AckFileBean) pojo;
        List<FileDetail> list;
        list = ackFileBean.getFileList();
        return st.add("batch", ackFileBean).add("list", list).render();
    }
}