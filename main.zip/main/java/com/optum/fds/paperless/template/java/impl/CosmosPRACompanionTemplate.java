package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class CosmosPRACompanionTemplate extends TemplateHandler {
    private static final String  HEADER ="BARCODE|DIV|MEMBER NUMBER|MEMBER NAME|CLAIM NUMBER|MEDIA TYPE|CLAIM SYSTEM|";
    private static final Logger LOG = LoggerFactory.getLogger(CosmosPRACompanionTemplate.class);
    @Override
    public String convertWithTemplate(String jsonFile) {
        var st = this.templateLoader.getTemplate(Templates.COSMOS_PRA_COMPANION);
        List<Params> paramList;
        try {
            paramList = fetchData(jsonFile);
        } catch (IOException  e) {
            throw new RuntimeException(e);
        }
        return st.add("list", paramList).render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return null;
    }

    private List<Params> fetchData(String jsonFile) throws IOException {
        LOG.info("jsonFile={}", jsonFile);
        List <Params> listOfData = new ArrayList<>();
        InputStream fileInputStream =  new BufferedInputStream(new FileInputStream(jsonFile));
        String line;
        try (var br = new BufferedReader(new InputStreamReader(fileInputStream))) {
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if(!line.equalsIgnoreCase(HEADER))
                {
                    String[] arrayData= StringUtils.split(line, '|');
                    listOfData.add(new Params(arrayData));
                }
            }
        }
        LOG.debug("jsonFile={}, listOfData={}", jsonFile, listOfData);
        return listOfData;
    }



    static class Params {

    	private final String barcode;
    	private final String barcode_fifteen;
        private final String div;
        private final String memberNumber;
        private final String memberName;
        private final String claimNumber;
        private final String mediaType;
        private final String claimSystem;
        public Params(String barcode,String barcode_fifteen, String div, String memberNumber, String memberName, String claimNumber,
                      String mediaType, String claimSystem) {
            super();
            this.barcode = barcode;
            this.barcode_fifteen=barcode_fifteen;
            this.div = div;
            this.memberNumber = memberNumber;
            this.memberName = memberName;
            this.claimNumber = claimNumber;
            this.mediaType = mediaType;
            this.claimSystem = claimSystem;
        }

        public Params(String[] data) {
            this.barcode = data[0];
            this.barcode_fifteen=(data[0]!=null)?(data[0].length()>15)?data[0].substring(0, 15):data[0]:"";
            this.div = data[1];
            this.memberNumber = data[2];
            this.memberName = data[3];
            this.claimNumber = data[4];
            this.mediaType = data[5];
            this.claimSystem = data[6];

        }

        public String getBarcode() {
            return barcode;
        }
        public String getDiv() {
            return div;
        }
        public String getMemberNumber() {
            return memberNumber;
        }
        public String getMemberName() {
            return memberName;
        }
        public String getClaimNumber() {
            return claimNumber;
        }
        public String getMediaType() {
            return mediaType;
        }
        public String getClaimSystem() {
            return claimSystem;
        }

		public String getBarcode_fifteen() {
			return barcode_fifteen;
		}

		@Override
		public String toString() {
			return "Params [barcode=" + barcode + ", barcode_fifteen=" + barcode_fifteen + ", div=" + div
					+ ", memberNumber=" + memberNumber + ", memberName=" + memberName + ", claimNumber=" + claimNumber
					+ ", mediaType=" + mediaType + ", claimSystem=" + claimSystem + "]";
		}
    }



    @Override
    public String convertWithTemplate(Object pojo) {
        // TODO Auto-generated method stub
        return null;
    }

}