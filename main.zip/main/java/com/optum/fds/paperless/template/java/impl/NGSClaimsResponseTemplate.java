package com.optum.fds.paperless.template.java.impl;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.list.mutable.FastList;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class NGSClaimsResponseTemplate extends TemplateHandler {

    private static final String GMT = "GMT-00:00";

    @Override
    public String convertWithTemplate(String jsonString) {
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return convertWithTemplate(documentMetaDataList);
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

       return convertWithTemplate(documentMetaDataList);
    }

    static class Params {
        DateTimeFormatter outFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        String format = "MM-dd-yyyy HH:mm:ss";

        private final String caseId;
        private final String subCategory;
        private final String ngsId;
        private final String fileName;
        private final String originalZipFileName;
        private final String emailAlertReq;
        private String docLibAPIResponse;
        private final String providerEmailId;
        private String docLibUploadDate;
        private final String dateEmailSent;
        private final String eDeliveryError;

        public Params(String caseId, String subCategory, String ngsId, String fileName, String originalZipFileName, String emailAlertReq, String docLibAPIResponse, String providerEmailId, String docLibUploadDate, String dateEmailSent, String eDeliveryError) {
            this.caseId = caseId != null ? caseId.trim() : "";
            this.subCategory = subCategory.trim();
            this.ngsId = ngsId.trim();
            this.fileName = fileName.trim();
            this.originalZipFileName = originalZipFileName != null ? originalZipFileName.trim() : "";
            this.emailAlertReq = emailAlertReq.trim();
            this.docLibAPIResponse = docLibAPIResponse != null ? docLibAPIResponse.trim() : docLibAPIResponse;
            this.providerEmailId = providerEmailId != null ? providerEmailId.trim() : providerEmailId;
            this.docLibUploadDate = docLibUploadDate != null ? docLibUploadDate.trim() : docLibUploadDate;
            this.dateEmailSent = dateEmailSent;
            this.eDeliveryError = eDeliveryError != null ? eDeliveryError.trim() : eDeliveryError;
        }

        public String getCaseId() {
            return caseId;
        }

        public String getSubCategory() {
            return subCategory;
        }

        public String getNgsId() {
            return ngsId;
        }

        public String getFileName() {
            return fileName;
        }

        public String getOriginalZipFileName() {
            return originalZipFileName;
        }

        public String getEmailAlertReq() {
            return emailAlertReq;
        }

        public String getProviderEmailId() {
            return providerEmailId;
        }

        public String getDateEmailSent() {
            return dateEmailSent;
        }

        public String getEDeliveryError() {
            return eDeliveryError;
        }

        public String getDocLibAPIResponse() {
            return docLibAPIResponse;
        }
        public String getDocLibUploadDate() {
            return docLibUploadDate;
        }
    }


    private String convertDateToCSTFormat(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) {
            return "";
        }
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        DateFormat format2 = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
        format2.setTimeZone(TimeZone.getTimeZone("CST"));
        try {
            Date date = format.parse(dateStr);
            return format2.format(date);
        } catch (ParseException e) {
            return null;
        }
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        var st = this.templateLoader.getTemplate(Templates.NGS_CLAIMS_RESPONSE);

        List<DocumentMetaData> documentMetaDataList = (List<DocumentMetaData>) pojo;

        var paramsList = FastList.<NGSClaimsResponseTemplate.Params>newList();
        var counter = new Counter();
        for (var documentMetaData : documentMetaDataList) {
            var metaData = documentMetaData.getMetadata();
            var caseId = metaData.getString(Workflow.CASE_ID);
            var subCategory = metaData.getString(Workflow.SUBCATEGORY);
            var ngsId = metaData.getString(Workflow.NSG_ID);
            var fileName = metaData.getString(Workflow.FILE_NAME);
            var originalZipFileName = metaData.getString(Workflow.ORIGINAL_ZIP_FILE_NAME);
            var emailAlertReq ="";
            if (metaData.getString(Workflow.EMAIL_ALERT_REQUEST).equalsIgnoreCase("Y")) {
                emailAlertReq = "E";
            } else {
                emailAlertReq = "E";
            }
            var docLibAPIResponse = "FAILED";
            if (metaData.getBoolean(Workflow.METADATA_DOCLIB_API_RESPONSE, false)) {
                docLibAPIResponse = "UPLOADED";
            }
            var providerEmailId = metaData.getString(Workflow.PROVIDER_EMAIL_ID);
            var docVaultUploadDate = convertDateToCSTFormat(metaData.getString(Workflow.METADATA_DOCLIB_UPLOAD_DATE));
            var dateEmailSent = convertDateToCSTFormat(metaData.getString(Workflow.DATE_EMAIL_SENT));
            var eDeliveryError = metaData.getString(Workflow.EDELIVERY_ERROR);

            paramsList.add(new Params(caseId, subCategory, ngsId, fileName, originalZipFileName, emailAlertReq, docLibAPIResponse, providerEmailId, docVaultUploadDate, dateEmailSent, eDeliveryError));
        }

        return st.add("list", paramsList).add("counter", counter.toString()).render();
    }

}
