package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.template.java.impl.CheckWritePRAResponseTemplate.Params;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.factory.Lists;
import org.eclipse.collections.impl.list.mutable.FastList;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CAPResponseTemplate extends TemplateHandler {

    @Override
    public String convertWithTemplate(String jsonString) {
        var st = this.templateLoader.getTemplate(Templates.CAP_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        
        var paramsList = FastList.<CAPResponseTemplate.Params>newList();
        var counter = new Counter();
        for (var documentMetaData : documentMetaDataList) {
            paramsList.add(new CAPResponseTemplate.Params(documentMetaData));
            
        }
        return st.add("list", paramsList).render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        var st = this.templateLoader.getTemplate(Templates.CAP_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<CAPResponseTemplate.Params>newList();
        for (var documentMetaData : documentMetaDataList) {
        	paramsList.add(new CAPResponseTemplate.Params(documentMetaData));
        	
        }
        return st.add("list", paramsList).render();
    }

    private static String formatDateEmailSent(String string) {
    	if (string == null || string.length() == 0) {
    		return "";
    	}
        SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        SimpleDateFormat targetFormat = new SimpleDateFormat("yyyyMMdd'T'HH:mm:ss.SSS'Z'");
        Date date = null;
        try {
            date = originalFormat.parse(string);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        String formattedDate = targetFormat.format(date);
        return formattedDate;
    }
    
    @Override
    public String convertWithTemplate(Object pojo) {
        return null;
    }
    
    protected static class Params {

        private final String dateEmailSent;
        private final String docLibUploadDate;
        private final String letterId;
        private final String id;
        private final String eDeliveryError;
        private String deliveryFormat = "";
        private String eDeliverySuccessful = "";
        private String emailAlertReq = "";

		public Params(String dateEmailSent, String docLibUploadDate, String letterId, String id,  
				 String eDeliveryError, String deliveryFormat, String eDeliverySuccessful,String emailAlertReq) {
			this.dateEmailSent = dateEmailSent;
			this.docLibUploadDate = docLibUploadDate;
			this.letterId = letterId;
			this.id = id;
			this.eDeliveryError = eDeliveryError;
			this.deliveryFormat = deliveryFormat;
			this.eDeliverySuccessful = eDeliverySuccessful;
			this.emailAlertReq = emailAlertReq;
		}
		
		public Params(  DocumentMetaData documentMetaData) {
			var metadata = documentMetaData.getMetadata();
			this.dateEmailSent = formatDateEmailSent(metadata.getString("dateEmailSent"));
			this.docLibUploadDate = formatDateEmailSent(metadata.getString("docLibUploadDate"));
			this.letterId = metadata.getString("letterId");
			this.id = documentMetaData.getId();
			this.eDeliveryError = metadata.getString("eDeliveryError");
			this.emailAlertReq = metadata.getString("emailAlertReq");
			if(emailAlertReq.equals("N")) {
				this.deliveryFormat = "paper";
				this.eDeliverySuccessful = "no";	
			}
			else {	
				this.deliveryFormat = dateEmailSent == null || dateEmailSent.isEmpty() ? "postcard" : "emailed";
				this.eDeliverySuccessful = eDeliveryError == null || eDeliveryError.isEmpty() ? "yes": "no";	
			}
		}

		
		
		@Override
		public String toString() {
			return "Params [dateEmailSent=" + dateEmailSent + ", docLibUploadDate=" + docLibUploadDate + ", letterId=" + letterId
					+ ", id=" + id + ", eDeliveryError=" + eDeliveryError + ", deliveryFormat=" + deliveryFormat + ", eDeliverySuccessful=" + eDeliverySuccessful + ", emailAlertReq=" + emailAlertReq + "]";
		}

		public String getDateEmailSent() {
			return dateEmailSent;
		}

		public String getDocLibUploadDate() {
			return docLibUploadDate;
		}

		public String getLetterId() {
			return letterId;
		}
		
		public String getId() {
			return id;
		}

		public String getEDeliveryError() {
			return eDeliveryError;
		}
		public String getDeliveryFormat() {
			return deliveryFormat;
		}

		public String getEDeliverySuccessful() {
			return eDeliverySuccessful;
		}

		public String getEmailAlertReq() {
			return emailAlertReq;
		}

    }
}