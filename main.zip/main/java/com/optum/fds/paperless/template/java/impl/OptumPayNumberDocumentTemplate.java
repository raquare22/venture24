package com.optum.fds.paperless.template.java.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.util.FileSplitUtil;
import com.optum.fds.paperless.util.StringUtils;

public class OptumPayNumberDocumentTemplate extends TemplateHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(OptumPayNumberDocumentTemplate.class);

	private int splitPerMbSize = 4;
	private int splitFileMaxBytesNewLineWithin = 1024;

	private int splitListSize = 0;
	private int currentSplitIndex = 0;
	private List<StringBuilder> splitList = null;
	private boolean removeFirstElement = false;
	private boolean removeLastElement = false;

	@Override
	public String convertWithTemplate(String content) {
		if (StringUtils.isNullOrEmpty(content)) {
			LOGGER.error("OptumPayNumberDocumentTemplate --> file is empty");
			return null;
		}

		var st = this.templateLoader.getTemplate(Templates.OPTUM_PAY_NUMBER_DOCUMENT);
		String[] contentArr = content.split("\\n");
		List<String> stringList = Arrays.asList(contentArr);
		ArrayList<String> list = new ArrayList<String>();
		list.addAll(stringList);

		if (list.isEmpty()) {
			LOGGER.error("OptumPayNumberDocumentTemplate --> file is empty");
			return null;
		}

		// ignore first line of file and last line of file
		if (removeFirstElement) {
			list.remove(0);
		}
		if (removeLastElement) {
			list.remove(list.size() - 1);
		}
		return st.add("list", list).render();
	}

	@Override
	public String convertWithTemplateFromFilePath(String filePath) {
		String content = null;
		if (splitPerMbSize != 0 && splitFileMaxBytesNewLineWithin != 0) {
			try {
				if (splitListSize == 0) {
					LOGGER.info("Checking if split is required; file={}, splitPerMbSize={}, splitFileMaxBytesNewLineWithin={}", filePath, splitPerMbSize, splitFileMaxBytesNewLineWithin);
					splitList = FileSplitUtil.checkAndSplitFile(filePath, splitPerMbSize, splitFileMaxBytesNewLineWithin);
					splitListSize = splitList.size();
				}
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
			if (splitListSize != 0) {
				return getNextSplit();
			}
		}

		LOGGER.info("Split is not required; file={}", filePath);
		setRemoveElements(-1, 0);
		try {
			Path path = Path.of(filePath);
			content = Files.readString(path);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return convertWithTemplate(content);
	}

	@Override
	public String convertWithTemplate(Object pojo) {
		return null;
	}

	public void setSplitPerMbSize(int splitPerMbSize) {
		this.splitPerMbSize  = splitPerMbSize;
	}

	public void setSplitFileMaxBytesNewLineWithin(int splitFileMaxBytesNewLineWithin) {
		this.splitFileMaxBytesNewLineWithin  = splitFileMaxBytesNewLineWithin;
	}

	public boolean isDone() {
		return removeLastElement;
	}

	protected String getNextSplit() {
		setRemoveElements(currentSplitIndex, splitListSize);
		LOGGER.info("currentSplitIndex={}, splitList.size={}", currentSplitIndex, splitListSize);
		StringBuilder splitStringBuilder = splitList.get(currentSplitIndex);
		currentSplitIndex++;
		return convertWithTemplate(splitStringBuilder.toString());
	}

	protected void setRemoveElements(int i, int splitListSize) {
		if (i == -1) {
			removeFirstElement = true;
			removeLastElement = true;
		}
		else
		if (i == 0) {
			removeFirstElement = true;
			removeLastElement = false;
		}
		else
		if (i + 1 >= splitListSize) {
			removeFirstElement = false;
			removeLastElement = true;
		}
		else
		{
			removeFirstElement = false;
			removeLastElement = false;
		}
	}
}