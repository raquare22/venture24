package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.list.mutable.FastList;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CCResponseTemplate extends TemplateHandler {

    @Override
    public String convertWithTemplate(String jsonString) {
        var st = this.templateLoader.getTemplate(Templates.CC_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<CCResponseTemplate.Params>newList();
        for (var documentMetaData : documentMetaDataList) {
            paramsList.add(new CCResponseTemplate.Params(documentMetaData.getMetadata()));
        }
        return st.add("list", paramsList).render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        var st = this.templateLoader.getTemplate(Templates.CC_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<CCResponseTemplate.Params>newList();
        for (var documentMetaData : documentMetaDataList) {
        	paramsList.add(new CCResponseTemplate.Params(documentMetaData.getMetadata()));
        }
        return st.add("list", paramsList).render();
    }

    private static String formatDateEmailSent(String string) {
    	if (string == null || string.length() == 0) {
    		return "";
    	}
        SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        SimpleDateFormat targetFormat = new SimpleDateFormat("yyyyMMdd'T'HH:mm:ss.SSS'Z'");
        Date date = null;
        try {
            date = originalFormat.parse(string);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        String formattedDate = targetFormat.format(date);
        return formattedDate;
    }
    
    @Override
    public String convertWithTemplate(Object pojo) {
        return null;
    }
    
    protected static class Params {

        private final String tin;
        private final String corporateMpin;
        private final String providerEmailId;
        private final String dateEmailSent;
        private final String eDeliveryError;
        
		public Params(String tin, String corporateMpin, String providerEmailId, 
				String dateEmailSent, String eDeliveryError) {
			this.tin = tin;
			this.providerEmailId = providerEmailId;
			this.corporateMpin = corporateMpin;
			this.dateEmailSent = dateEmailSent;
			this.eDeliveryError = eDeliveryError;
		}
		
		public Params(org.bson.Document metadata) {
			this.tin = metadata.getString("tin");
			this.providerEmailId = metadata.getString("providerEmailId");
			this.corporateMpin = metadata.getString("corporateMpin");
			this.dateEmailSent = formatDateEmailSent(metadata.getString("dateEmailSent"));
			this.eDeliveryError = metadata.getString("eDeliveryError");			
		}

		
		
		@Override
		public String toString() {
			return "Params [tin=" + tin + ", corporateMpin=" + corporateMpin + ", providerEmailId=" + providerEmailId
					+ ", dateEmailSent=" + dateEmailSent + ", eDeliveryError=" + eDeliveryError + "]";
		}

		public String getTin() {
			return tin;
		}

		public String getCorporateMpin() {
			return corporateMpin;
		}

		public String getProviderEmailId() {
			return providerEmailId;
		}

		public String getEDeliveryError() {
			return eDeliveryError;
		}

		public String getDateEmailSent() {
			return dateEmailSent;
		}		

    }
}