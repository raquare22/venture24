package com.optum.fds.paperless.template.java.impl;

import java.io.IOException;
import java.util.List;

import org.eclipse.collections.impl.list.mutable.FastList;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class SSBCIResponseTemplate extends TemplateHandler {

    @Override
    public String convertWithTemplate(String jsonString) {
        var st = this.templateLoader.getTemplate(Templates.SSBCI_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<Params>newList();

        for (var documentMetaData : documentMetaDataList) {
            var metaData = documentMetaData.getMetadata();
            paramsList.add(new SSBCIResponseTemplate.Params(metaData));
        }

        return st.add("list", paramsList).render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        var st = this.templateLoader.getTemplate(Templates.SSBCI_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<Params>newList();

        for (var documentMetaData : documentMetaDataList) {
            var metaData = documentMetaData.getMetadata();
            paramsList.add(new SSBCIResponseTemplate.Params(metaData));
        }

        return st.add("list", paramsList).render();
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        // TODO Auto-generated method stub
        return null;
    }

    static class Params {
        private final String providerTin;
        private final String corporateMpin;
        private final String providerEmailId;
        private final String type;
        private final String dateEmailSent;
        private final String eDeliveryError;
        private final String transactionId;
        private final String householdId;
        private final String insuredPlanId;
        private final String effectiveDate;
        private final String endDate;
        private final String eventType;
        private final String providerName;
        private final String providerNpi;

        public Params(org.bson.Document metadata) {
            this.providerTin = sanitize(metadata.getString(Workflow.TIN));
            this.corporateMpin = sanitize(metadata.getString(Workflow.PROV_CORP_MPIN));
            this.providerEmailId = escapeCsv(sanitize(metadata.getString(Workflow.PROVIDER_EMAIL_ID)));
            this.type = sanitize(metadata.getString(Workflow.TYPE));
            this.dateEmailSent = sanitize(metadata.getString(Workflow.DATE_EMAIL_SENT));
            this.eDeliveryError = sanitize(metadata.getString(Workflow.E_DELIVERY_ERROR));
            this.transactionId = sanitize(metadata.getString(Workflow.METADATA_TRANSACTION_ID));
            this.householdId = sanitize(metadata.getString(Workflow.HOUSEHOLD_ID));
            this.insuredPlanId = sanitize(metadata.getString(Workflow.INSURED_PLAN_ID));
            this.effectiveDate = sanitize(metadata.getString(Workflow.EFFECTIVE_DATE));
            this.endDate = sanitize(metadata.getString(Workflow.END_DATE));
            this.eventType = sanitize(metadata.getString(Workflow.EVENT_TYPE));
            this.providerName = escapeCsv(sanitize(metadata.getString(Workflow.PROVIDER_NAME)));
            this.providerNpi = extractProviderNpi(metadata);
        }

        private String extractProviderNpi(org.bson.Document metadata) {
            Object providersObj = metadata.get("providers");
            if (providersObj instanceof org.bson.Document) {
                return sanitize(((org.bson.Document) providersObj).getString("npi"));
            } else if (providersObj instanceof java.util.Map) {
                return sanitize(new org.bson.Document((java.util.Map) providersObj).getString("npi"));
            }
            return "";
        }

        private String sanitize(String value) {
            return (value != null && !value.trim().isEmpty()) ? value : "";
        }

        private String escapeCsv(String value) {
            if (value == null || value.isEmpty()) return "";
            String escaped = value.replace("\"", "\"\"");
            boolean needsQuotes = escaped.contains(",") || escaped.contains("\"") || escaped.contains("\n") || escaped.contains("\r") || escaped.contains("\t");
            escaped = escaped.replace("\r", "").replace("\n", "").replace("\t", "");
            if (needsQuotes) {
                return "\"" + escaped + "\"";
            }
            return escaped;
        }

        public String getProviderTin() {
            return providerTin;
        }

        public String getCorporateMpin() {
            return corporateMpin;
        }

        public String getProviderEmailId() {
            return providerEmailId;
        }

        public String getType() {
            return type;
        }

        public String getDateEmailSent() {
            return dateEmailSent;
        }

        public String getEDeliveryError() {
            return eDeliveryError;
        }

        public String getTransactionId() {
            return transactionId;
        }

        public String getHouseholdId() {
            return householdId;
        }

        public String getInsuredPlanId() {
            return insuredPlanId;
        }

        public String getEffectiveDate() {
            return effectiveDate;
        }

        public String getEndDate() {
            return endDate;
        }

        public String getEventType() {
            return eventType;
        }

        public String getProviderName() {
            return providerName;
        }

        public String getProviderNpi() {
            return providerNpi;
        }
    }

}