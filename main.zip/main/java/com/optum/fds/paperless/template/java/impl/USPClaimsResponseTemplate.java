package com.optum.fds.paperless.template.java.impl;


import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.optum.fds.paperless.mongo.BatchInfo;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.ItemList;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;


public class USPClaimsResponseTemplate extends TemplateHandler {
	
	private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	private static final String RPRNTSENTTOSF="rprntSentToSF";
	private static final String ISPOSTCARD="isPostCard";
	private static final String DATE_FORMATTER="yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
	private static final String  DELIVERYMETHOD_MAILED="MAILED";
	

	@Override
	public String convertWithTemplate(String jsonString) {
       
		var st = this.templateLoader.getTemplate(Templates.USP_CLAIMS_RESPONSE);
		
		List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        
        BatchInfo batchInfo= new BatchInfo();
        List<ItemList> itemList= new ArrayList<>();
        String zipFileName=documentMetaDataList.get(0).getMetadata().getString("zipFileName");
        if(zipFileName.contains("_"))
        {
        zipFileName=zipFileName.substring(0, zipFileName.indexOf("_"));
        }
        else
        {
        	zipFileName=zipFileName.substring(0, zipFileName.lastIndexOf("."));
        }
        batchInfo.setZipFileName(zipFileName);
        String convertedDate = null; 
        if(documentMetaDataList.get(0).getMetadata().getLong("zipFileCreatedDate") != null)
         {
         convertedDate =formatCreationDate(documentMetaDataList.get(0).getMetadata().getLong("zipFileCreatedDate"));
         }
        batchInfo.setZipFileCreationDate(convertedDate); 
        batchInfo.setItemsCount(documentMetaDataList.size()); 
        
        for (var documentMetaData : documentMetaDataList) {
        	 ItemList item=new ItemList();
        	
        	var metaData = documentMetaData.getMetadata();

            var passThroughData=metaData.getString("PassThruData");
            String createdDate = formatDate(metaData.getString(Workflow.CREATED_DATE));
            
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
    		ZonedDateTime currentDate = ZonedDateTime.now(ZoneOffset.UTC);
    		String dispatchedDate =currentDate.format(formatter); 
            
            var dateEmailSent = "";
            var filedeliveryMethod="";
            var deliveryMethod1="";
            if (metaData.getBoolean(Workflow.METADATA_DOCLIB_API_RESPONSE)!=null && (metaData.getBoolean(Workflow.METADATA_DOCLIB_API_RESPONSE)) && metaData.getString(Workflow.DATE_EMAIL_SENT) != null
                    && metaData.getString(Workflow.DATE_EMAIL_SENT).length() != 0) 
            {
                dateEmailSent = formatDate(metaData.getString(Workflow.DATE_EMAIL_SENT));
                filedeliveryMethod="EOnly";
                deliveryMethod1="EOnly";
                 
            }
            
            
           
            Integer successCount = 1;
            var deliveryTypeValue="";
            if(metaData.getBoolean(ISPOSTCARD) !=null && metaData.getBoolean(ISPOSTCARD) 
            		
            		&& metaData.getBoolean(RPRNTSENTTOSF) !=null && Boolean.TRUE.equals(metaData.getBoolean(RPRNTSENTTOSF)))
            {
            	
            	
            	filedeliveryMethod=DELIVERYMETHOD_MAILED;
            	deliveryTypeValue="Postcard";
            	deliveryMethod1=DELIVERYMETHOD_MAILED;
            	
            }
            
            if(metaData.getBoolean(ISPOSTCARD) !=null && !metaData.getBoolean(ISPOSTCARD) 		
            		&& metaData.getBoolean(RPRNTSENTTOSF) !=null && Boolean.TRUE.equals(metaData.getBoolean(RPRNTSENTTOSF)))
            {
            	
            	
            	filedeliveryMethod=DELIVERYMETHOD_MAILED;
            	deliveryTypeValue="";
            	deliveryMethod1=DELIVERYMETHOD_MAILED;
            	
            }
            String recipientId=metaData.getString("recipientId");
            
            
            
            item.setPassThroughData(passThroughData); 
            item.setFilecreationDate(createdDate); 
            item.setFiledateEmailSent(dateEmailSent);
            item.setDispatchedDate(dispatchedDate);
            item.setReceivedDate(convertedDate);  
            item.setRecipientId(recipientId);
            item.setFiledeliveryMethod(filedeliveryMethod); 
            item.setSuccesscount(successCount);
            item.setDeliveryTypeValue(deliveryTypeValue);
            item.setDeliveryMethod1(deliveryMethod1);
            
            itemList.add(item);
          
            
        }
        
        
        return st.add("batchInfo", batchInfo).add("itemList", itemList).render();
	}

	public String formatCreationDate(Long date) {
		 SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMATTER);
		return formatter.format(new Date(date));	 
	}

	@Override
	public String convertWithTemplateFromFilePath(String filePath) {

		return null;
	}

	@Override
	public String convertWithTemplate(Object pojo) {

		return null;
	}
	
	private String formatDate(String string) {
        SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMATTER);
        Date date = null;
        try {
            date = formatter.parse(string);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return formatter.format(date);   
    }
	
	
}