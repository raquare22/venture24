package com.optum.fds.paperless.template.java.impl;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.eclipse.collections.impl.Counter;
import org.eclipse.collections.impl.list.mutable.FastList;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class CheckWritePRAEmailAlertTemplate extends TemplateHandler {
	
	ObjectMapper mapper = new ObjectMapper();

	@Override
	public String convertWithTemplate(String jsonString) {
		var st = this.templateLoader.getTemplate(Templates.CHECK_WRITE_PRA_EMAIL_ALERT);
		List<ProcessorTransactionMetadata>  processorMetaDataList;
		
		try {
			processorMetaDataList = WorkFlowUtil.readOneProcessorTransactionMetadataFromJsonString(jsonString);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		var paramsList = FastList.<Params>newList();
		for (var processorMetaData : processorMetaDataList) {
			var sampleZipFileName = processorMetaData.getClient().get("sampleZipFileName").toString();
			var environment = processorMetaData.getClient().get("sampleZipFileName").toString();
			var dateCreated = processorMetaData.getDateCreated();
			var sendCompanionFileMissingEmail = (boolean) processorMetaData.getClient()
					.get(Workflow.SEND_COMPANION_FILE_MISSING_EMAIL);
	
			var fileName = processorMetaData.getFileName();
			var companionFileDateReceived =  processorMetaData.getDateCreated();
			//(Date) processorMetaData.getClient().get(Workflow.COMPANION_FILE_DATE_RECEIVED);
			var sendCompanionFileUnreadableEmail = (boolean) processorMetaData.getClient()
					.get(Workflow.SEND_COMPANION_FILE_UNREADABLE_EMAIL);
	
			paramsList.add(new Params(sampleZipFileName, environment, dateCreated, sendCompanionFileMissingEmail, fileName,
					companionFileDateReceived, sendCompanionFileUnreadableEmail));
		}
		return st.add("list", paramsList).add("counter", 1).render();
	}

	@Override
	public String convertWithTemplateFromFilePath(String filePath) {
		var st = this.templateLoader.getTemplate(Templates.CHECK_WRITE_PRA_EMAIL_ALERT);
		List<ProcessorTransactionMetadata>  processorMetaDataList;

		try {
			processorMetaDataList = WorkFlowUtil.readProcessorTransactionMetadataFromJsonFile(filePath);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		var paramsList = FastList.<Params>newList();
		for (var processorMetaData : processorMetaDataList) {
			var sampleZipFileName = processorMetaData.getClient().get("sampleZipFileName").toString();
			var environment = processorMetaData.getClient().get("sampleZipFileName").toString();
			var dateCreated = processorMetaData.getDateCreated();
			var sendCompanionFileMissingEmail = (boolean) processorMetaData.getClient()
					.get(Workflow.SEND_COMPANION_FILE_MISSING_EMAIL);

			var fileName = processorMetaData.getFileName();
			var companionFileDateReceived =  processorMetaData.getDateCreated();
			//(Date) processorMetaData.getClient().get(Workflow.COMPANION_FILE_DATE_RECEIVED);
			var sendCompanionFileUnreadableEmail = (boolean) processorMetaData.getClient()
					.get(Workflow.SEND_COMPANION_FILE_UNREADABLE_EMAIL);

			paramsList.add(new Params(sampleZipFileName, environment, dateCreated, sendCompanionFileMissingEmail, fileName,
					companionFileDateReceived, sendCompanionFileUnreadableEmail));
		}
		return st.add("list", paramsList).add("counter", 1).render();
	}

	@Override
	public String convertWithTemplate(Object pojo) {
		// TODO Auto-generated method stub
		return null;
	}

	static class Params {
		private final String sampleZipFileName;
		private final String environment;
		private final Date dateCreated;
		private final boolean sendCompanionFileMissingEmail;
		private final String fileName;
		private final Date companionFileDateReceived;
		private final boolean sendCompanionFileUnreadableEmail;

		public Params(String sampleZipFileName, String environment, Date dateCreated,
				boolean sendCompanionFileMissingEmail, String fileName, Date companionFileDateReceived,
				boolean sendCompanionFileUnreadableEmail) {
			super();
			this.sampleZipFileName = sampleZipFileName;
			this.environment = environment;
			this.dateCreated = dateCreated;
			this.sendCompanionFileMissingEmail = sendCompanionFileMissingEmail;
			this.fileName = fileName;
			this.companionFileDateReceived = companionFileDateReceived;
			this.sendCompanionFileUnreadableEmail = sendCompanionFileUnreadableEmail;
		}

		public String getSampleZipFileName() {
			return sampleZipFileName;
		}

		public String getEnvironment() {
			return environment;
		}

		public Date getDateCreated() {
			return dateCreated;
		}

		public boolean isSendCompanionFileMissingEmail() {
			return sendCompanionFileMissingEmail;
		}

		public String getFileName() {
			return fileName;
		}

		public Date getCompanionFileDateReceived() {
			return companionFileDateReceived;
		}

		public boolean isSendCompanionFileUnreadableEmail() {
			return sendCompanionFileUnreadableEmail;
		}

	}
}
