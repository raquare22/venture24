package com.optum.fds.paperless.template.java.impl;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.fds.paperless.document.util.DocumentResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

public class DocLibPutRequestTemplate extends TemplateHandler {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DocLibPutRequestTemplate.class);
	
	@Override
    public String convertWithTemplateFromFilePath(String filePath) {
		DocumentMetaData document;
        try {
            document = WorkFlowUtil.readDocumentFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return convertWithTemplate(document);
	}
	
	@Override
	public String convertWithTemplate(Object pojo) {
		var st = this.templateLoader.getTemplate(Templates.DOCLIB_PUT_REQUEST);
		DocumentMetaData doc = (DocumentMetaData) pojo;
		return st.add("document", doc)
                .render();
	}
	
	@Override
    public String convertWithTemplate(String content) {
		return null;
	}

}
