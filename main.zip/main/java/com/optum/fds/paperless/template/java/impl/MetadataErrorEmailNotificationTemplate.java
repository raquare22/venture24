package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.client.ErrorMessage;
import com.optum.fds.paperless.java.delegate.ProcessConvertMetadata;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import static org.apache.commons.text.StringEscapeUtils.escapeXml11;



@Component
public class MetadataErrorEmailNotificationTemplate extends TemplateHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(MetadataErrorEmailNotificationTemplate.class);
    private static final String TD_START_TAG = "<td>";
    private static final String TD_END_TAG = "</td>";

    @Override
    public String convertWithTemplate(String jsonString) {
        DocumentMetaData document;

        try {
            document = WorkFlowUtil.readDocumentFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return convertWithTemplate(document);
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {

        return null;
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        try {
            var st = this.templateLoader.getTemplate(Templates.SEND_METADATA_ERROR_EMAIL_NOTIFICATION);

            if (st == null) {
                LOGGER.error("MetadataErrorEmailNotificationTemplate-->convertWithTemplate-->Template is null for: {}", Templates.SEND_METADATA_ERROR_EMAIL_NOTIFICATION.getTemplate());
            }

            Map<String, Object> map = (Map<String, Object>) pojo;
            List<DocumentMetaData> documents = (List<DocumentMetaData>) map.get("documents");
            Class<?> enumClass = (Class<?>) map.get("enumClass");
            StringBuilder tableRows = new StringBuilder();

            if (documents != null) {
                for (DocumentMetaData document : documents) {
                    List<String> errorList = document.getMetadata().get("errorList", List.class);
                    String originalPrintTrail = document.getMetadata().get("originalPrintTrail", String.class);
                    String pdfFileName = document.getMetadata().get("fileName", String.class);
                    List<String> errorDetails = new ArrayList<>();
                    if (errorList != null) {
                        for (String errorMessage : errorList) {
                            String errorCode = getErrorCodeFromMessage(errorMessage, enumClass);
                            errorDetails.add(escapeXml11("Error Code: " + errorCode + ", Error: " + errorMessage));
                        }
                    }

                    String errors = errorDetails.isEmpty() ? "None" : String.join("<br/>", errorDetails);
                            tableRows.append("<tr>")
                                    .append(TD_START_TAG).append(escapeXml11(pdfFileName == null ? "" : pdfFileName)).append(TD_END_TAG)
                                    .append(TD_START_TAG).append(escapeXml11(originalPrintTrail == null ? "" : originalPrintTrail)).append(TD_END_TAG)
                                    .append(TD_START_TAG).append(errors).append(TD_END_TAG)
                                    .append("</tr>");
                }
            }

            return st.add("tableRows", tableRows.toString())
                    .render();

        } catch (Exception e) {
            LOGGER.error("MetadataErrorEmailNotificationTemplate-->convertWithTemplate-->Error rendering template", e);
            throw new RuntimeException("Error rendering metadata error email notification template", e);
        }
    }


    public String getErrorCodeFromMessage(String errorMessage, Class<?> enumClass) {
        if (errorMessage == null || enumClass == null || !enumClass.isEnum()) {
            return "";
        }
        String searchMessage = normalizeErrorMessage(errorMessage);
        for (Object enumConstant : enumClass.getEnumConstants()) {
            ErrorMessage error = (ErrorMessage) enumConstant;
            String enumMessage = normalizeErrorMessage(error.getErrorMessage());
            String enumName = ((Enum<?>) enumConstant).name().trim();
            if (enumMessage.equalsIgnoreCase(searchMessage)
                    || enumName.equalsIgnoreCase(searchMessage)) {
                return String.valueOf(error.getErrorCode());
            }
        }
        return "";
    }


    private String normalizeErrorMessage(String message) {
        if (message == null) {
            return "";
        }
        return message.trim().replace("(SEVERE)", "").trim();
    }


}
