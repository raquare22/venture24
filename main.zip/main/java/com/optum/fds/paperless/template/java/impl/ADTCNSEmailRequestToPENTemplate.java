package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.*;

@Component
public class ADTCNSEmailRequestToPENTemplate extends TemplateHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(ADTCNSEmailRequestToPENTemplate.class);
    
    @Value("${AdtCnsPortalDefaultLink}")
	private String adtCnsPortalDefaultLink;
    
    @Value("${AdtCnsPortalAdmitLink}")
	private String adtCnsPortalAdmitLink;
    
    @Value("${AdtCnsPortalDischargeLink}")
	private String adtCnsPortalDischargeLink;
    
    @Value("${AdtCnsPortalEmergencyLink}")
	private String adtCnsPortalEmergencyLink;
    
    

    @Override
    public String convertWithTemplate(String jsonString) {

        DocumentMetaData document;
        try {
            document = WorkFlowUtil.readDocumentFromJsonFile(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        
        return convertWithTemplate(document);
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return null;
    }

    @Override
	public String convertWithTemplate(Object pojo) {
		var st = this.templateLoader.getTemplate(Templates.ADT_CNS_EMAIL_REQUEST_TO_PEN);

        DocumentMetaData document = (DocumentMetaData) pojo;
        
        String tin = document.getMetadata().getString("tin");
        String corporateMpin = document.getMetadata().getString("corporateMpin");
        
        Map<String, String> recordInfo = (Map<String, String>) document.getMetadata().get("recordInfo");
        
        String recordType = recordInfo.get("recordType");
        
        String recordTypeUrl = adtCnsPortalDefaultLink;
        
        switch(recordType) {
        	case "DISCHARGE":
        		recordTypeUrl = adtCnsPortalDischargeLink;
        		break;
        	case "ADMIT": 
        		recordTypeUrl = adtCnsPortalAdmitLink;
        		break;
        	case "EMERGENCY": 
        		recordTypeUrl = adtCnsPortalEmergencyLink;
        		break;
        }
        
        
        if (tin.length() < 9) {
        	tin = StringUtils.leftPad(tin, 9, "0");
        }
        
        if (corporateMpin.length() < 9) {
        	corporateMpin = StringUtils.leftPad(corporateMpin, 9, "0");
        }
        
        String formattedTin = "XXXXX" + tin.substring(tin.length() - 4);
        String formattedCorporateMpin = "XXXXX" + corporateMpin.substring(corporateMpin.length() - 4);
        String numberOfUpdates = String.valueOf(document.getMetadata().get("TinDocumentCount"));
        		
        return st.add("document", document)
        		.add("formattedTin", formattedTin)
        		.add("formattedCorpMpin", formattedCorporateMpin)
        		.add("recordTypeUrl", recordTypeUrl)
                .add("numberOfUpdates", numberOfUpdates)
        		.render();

	}
}