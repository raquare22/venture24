package com.optum.fds.paperless.template.java.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.util.StringUtils;

public class TXGCCsvDocumentTemplate extends TemplateHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(TXGCCsvDocumentTemplate.class);

    @Override
    public String convertWithTemplate(String content) {
    	
    	LOGGER.info("convert file={}", content);    	
    	
    	if (StringUtils.isNullOrEmpty(content)) {
			LOGGER.error("TXGCCsvDocumentTemplate --> file is empty");
			return null;
		}

		var st = this.templateLoader.getTemplate(Templates.TXGC_CSV_DOCUMENT);
		String[] contentArr = content.split("\\n");
		List<String> stringList = Arrays.asList(contentArr);
		ArrayList<String> list = new ArrayList<String>();
		list.addAll(stringList);

		if (list.isEmpty()) {
			LOGGER.error("TXGCCsvDocumentTemplate --> file is empty");
			return null;
		}

		// ignore header line of file
		list.remove(0);
		List<Map<String, String>> metadataList = new ArrayList<>();
		
		for (String row : list) {
			
			Map<String, String> metadataMap = new HashMap<>();
			String[] rowContent = row.split(",");
			
			metadataMap.put("providerNPI", rowContent[0]);
			metadataMap.put("procedureCodeType", rowContent[1]);
			metadataMap.put("stateCode", rowContent[2]);
			metadataMap.put("exemptionEffectiveStartDate", rowContent[3]);
			metadataMap.put("exemptionEffectiveEndDate", rowContent[4]);
			metadataMap.put("exemptionFlag", rowContent[5]);
			metadataMap.put("procedureClinicalGroupType", rowContent[6]);
			metadataMap.put("procedureClinicalGroupId", rowContent[7]);

			metadataMap.put("cycleStartDate", rowContent[8]);
			metadataMap.put("cycleEndDate", rowContent[9]);

			metadataMap.put("numberOfCodesInCluster", rowContent[10]);
			metadataMap.put("procCodeDescription", rowContent[11]);
			metadataMap.put("approvalRate", rowContent[12]);
			
			metadataList.add(metadataMap);
		}
		
		
		return st.add("list", metadataList)
				.render();
    }
    

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
    	String content = null;
		try {
			Path path = Path.of(filePath);
			content = Files.readString(path);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return convertWithTemplate(content);
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        return null;
    }

}
