package com.optum.fds.paperless.template.java.impl;



import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.constants.Workflow;


public class USPClaimsResponseApiNotify extends TemplateHandler {
	
	private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	private static final String RPRNTSENTTOSF="rprntSentToSF";
	private static final String ISPOSTCARD="isPostCard";
	private static final String DELIVERYMETHOD="deliveryMethodCd";
	

	@Override
	public String convertWithTemplate(String jsonString) {
       
		return null;
	}

	@Override
	public String convertWithTemplateFromFilePath(String filePath) {

		return null;
	}

	@Override
	public String convertWithTemplate(Object pojo) {

		
        var st = this.templateLoader.getTemplate(Templates.USP_CLAIMS_RESPONSE_API_NOTIFY);
		
         HashMap<String,Object> apiNotifyMap =(HashMap<String, Object>) pojo;
         List<DocumentMetaData> docList=(List<DocumentMetaData>) apiNotifyMap.get("docList");
        
         
         DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
 		ZonedDateTime currentDate = ZonedDateTime.now(ZoneOffset.UTC);
 		String dispatchedDate =currentDate.format(formatter); 
        
 		apiNotifyMap.put("dispatchedDate", dispatchedDate);
 		apiNotifyMap.put("statusCode", "Accepted"); 
 		
 		
 		
 		
 		
        
        return st.add("responseFileInfo", apiNotifyMap).render(); 
		
	}
	
	
}
