package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.eclipse.collections.impl.list.mutable.FastList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class HouseCallsResponseTemplate extends TemplateHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(HouseCallsResponseTemplate.class);

    @Override
    public String convertWithTemplate(String jsonString) {
        var st = this.templateLoader.getTemplate(Templates.HOUSE_CALLS_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<HouseCallsResponseTemplate.Params>newList();
        for (var documentMetaData : documentMetaDataList) {
            paramsList.add(new HouseCallsResponseTemplate.Params(documentMetaData));
        }
        return st.add("list", paramsList).render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        var st = this.templateLoader.getTemplate(Templates.HOUSE_CALLS_RESPONSE);
        List<DocumentMetaData> documentMetaDataList;
        try {
            documentMetaDataList = WorkFlowUtil.readDocumentsFromJsonFile(filePath);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        var paramsList = FastList.<HouseCallsResponseTemplate.Params>newList();
        for (var documentMetaData : documentMetaDataList) {
            paramsList.add(new HouseCallsResponseTemplate.Params(documentMetaData));
        }
        return st.add("list", paramsList).render();
    }

    private static String formatDateEmailSent(String string) {
        if (string == null || string.length() == 0) {
            return "";
        }
        SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        SimpleDateFormat targetFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss 'UTC' yyyy");
        Date date = null;
        try {
            date = originalFormat.parse(string);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        String formattedDate = targetFormat.format(date);
        return formattedDate;
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        return null;
    }

    protected static class Params {

        private final String fileName;
        private final String memberId;
        private final String id;
        private final String dateCreated;
        private final String docLibUploadDate;
        private final String dateEmailSent;
        private final String eDeliveryError;

        public Params(String fileName, String memberId, String id, String dateCreated, String docLibUploadDate,
                      String dateEmailSent, String eDeliveryError) {
            this.fileName = fileName;
            this.memberId = memberId;
            this.id = id;
            this.docLibUploadDate = docLibUploadDate;
            this.dateCreated = dateCreated;
            this.dateEmailSent = dateEmailSent;
            this.eDeliveryError = eDeliveryError;
        }

        public Params(DocumentMetaData documentMetaData) {
            var metadata = documentMetaData.getMetadata();
            this.fileName = metadata.getString("fileName");
            this.memberId = metadata.getString("memberId");
            this.id = documentMetaData.getId();
            this.docLibUploadDate = formatDateEmailSent(metadata.getString("docLibUploadDate"));
            Date dateCreatedValue = documentMetaData.getDateCreated();
            SimpleDateFormat targetFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss 'UTC' yyyy");
            this.dateCreated = targetFormat.format(dateCreatedValue);
            this.dateEmailSent = formatDateEmailSent(metadata.getString("dateEmailSent"));
            this.eDeliveryError = metadata.getString("eDeliveryError");
        }



        @Override
        public String toString() {
            return "Params [fileName=" + fileName + ", memberId=" + memberId + ", id=" + id + ", dateCreated=" + dateCreated + ", docLibUploadDate=" + docLibUploadDate
                    + ", dateEmailSent=" + dateEmailSent + ", eDeliveryError=" + eDeliveryError + "]";
        }

        public String getFileName() {
            return fileName;
        }

        public String getMemberId() {
            return memberId;
        }

        public String getDocLibUploadDate() { return docLibUploadDate; }

        public String getId() { return id; }

        public String getDateCreated() {
            return dateCreated;
        }

        public String getEDeliveryError() {
            return eDeliveryError;
        }

        public String getDateEmailSent() {
            return dateEmailSent;
        }

    }
}
