package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class SecondaryProviderEmailRequestToPENTemplate extends TemplateHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(SecondaryProviderEmailRequestToPENTemplate.class);

    @Override
    public String convertWithTemplate(String jsonString) {
        return null;
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return null;
    }

    @Override
    public String convertWithTemplate(Object pojo) {
        var st = this.templateLoader.getTemplate(Templates.SECONDARY_PROVIDER_EMAIL_REQUEST_TO_PEN);

        return st.add("request", pojo)
                .render();
    }
}
