package com.optum.fds.paperless.template.java.impl;

import com.optum.fds.paperless.mongo.Batch;
import com.optum.fds.paperless.mongo.FileDetail;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.List;

public class COSMOSDoc1StatusTemplate extends TemplateHandler {
    @Override
    public String convertWithTemplate(String jsonString) {

        var st = this.templateLoader.getTemplate(Templates.COSMOS_DOC1_STATUS);

        Batch batch = null;
        
        try {
            batch = WorkFlowUtil.readBatchFromJsonFile(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        List<FileDetail> list;
        list = batch.getFileList();
        return st.add("batch", batch).add("list", list).render();
    }

    @Override
    public String convertWithTemplateFromFilePath(String filePath) {
        return null;
    }

    @Override
    public String convertWithTemplate(Object pojo) {

        var st = this.templateLoader.getTemplate(Templates.COSMOS_DOC1_STATUS);

        Batch batch = (Batch) pojo;
        List<FileDetail> list;
        list = batch.getFileList();
        return st.add("batch", batch).add("list", list).render();
    }


}