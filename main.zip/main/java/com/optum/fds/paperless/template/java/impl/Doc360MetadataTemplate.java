package com.optum.fds.paperless.template.java.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.template.Templates;
import com.optum.fds.paperless.template.java.TemplateHandler;
import com.optum.fds.paperless.workflow.util.WorkFlowUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class Doc360MetadataTemplate extends TemplateHandler {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(Doc360MetadataTemplate.class);
	private static final String PATIENT_ACCOUNT_NUMBER = "patientAccountNumber";
	private static final String CHECK_ID = "checkId";
	private static final String CHECK_AMOUNT = "checkAmount";
	private static final String CHECK_NUMBER = "checkNumber";
	private static final String CHECK_TRACE_NUMBER = "CheckTraceNumber";
	private static final String PIPE_DELIMITER = "|";
	
	ObjectMapper mapper = new ObjectMapper();
	
	@Override
	public String convertWithTemplate(Object pojo) {
		var st = this.templateLoader.getTemplate(Templates.DOC360_METADATA_TEMPLATE);
		
		LOGGER.info("string template loaded, st={}", st);
		
		org.bson.Document metadata = (org.bson.Document) pojo;
		
		Map<String, String> searchTermsMap = createMetadataMap(metadata);
		
		return st.add("map", searchTermsMap).render();
	}
	
	@Override
    public String convertWithTemplate(String jsonString) {
		org.bson.Document metadata;
        try {
        	metadata = WorkFlowUtil.readMetadataFromJsonString(jsonString);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        
        return convertWithTemplate(metadata);
		
	}
	
	@Override
    public String convertWithTemplateFromFilePath(String filePath) {
		return null;
	}
	
	
	public String getDoc360MetadataString(org.bson.Document metadata) {
		Map<String, String> searchTermsMap = createMetadataMap(metadata);
		String str = "";		
		try {
			str = mapper.writeValueAsString(searchTermsMap);
		} catch (JsonProcessingException e) {
			LOGGER.error("Doc360MetadataTemplate error converting map to json string, e={}", ExceptionUtils.getStackTrace(e));
		}
		return str;
	}
	
	public String filterDuplicates(String inputString) {
        String joinedInputString = "";

        try {
            if (!StringUtils.isEmpty(inputString)) {
                Set<String> unique = new java.util.LinkedHashSet<>(Arrays.asList(inputString.split("\\|")));
                joinedInputString = unique.stream()
                        .filter(StringUtils::isNotBlank)
                        .collect(Collectors.joining(PIPE_DELIMITER, PIPE_DELIMITER, PIPE_DELIMITER));
            }
        } catch (Exception e) {
            LOGGER.error("getting exception to filter duplicates {} {} ", inputString, ExceptionUtils.getStackTrace(e));
            joinedInputString = "";
        }

        return joinedInputString;
    }
	
	public Map<String, String> createMetadataMap(org.bson.Document metadata) {
		
		Map<String, String> doc360MetadataMap = new HashMap<>();
        if (metadata == null || metadata.isEmpty()) {
            return doc360MetadataMap;
        }
        String createApplication = metadata.getString("createApplication");
		String createdDate = metadata.getString("createdDate");
		doc360MetadataMap.put("u_doc_creation_dt", createdDate);
		doc360MetadataMap.put("u_filename", metadata.getString("fileName"));
		doc360MetadataMap.put("u_expiry_dt", metadata.getString("expiryDate"));
		doc360MetadataMap.put("u_category", metadata.getString("category"));
		doc360MetadataMap.put("u_sub_category", metadata.getString("subCategory"));
		doc360MetadataMap.put("u_file_path", metadata.getString("filePath"));
		doc360MetadataMap.put("u_email_alert_req", metadata.getString("emailAlertReq"));
		doc360MetadataMap.put("u_tin", metadata.getString("tin"));
		doc360MetadataMap.put("u_mpin", metadata.getString("mpin"));
		doc360MetadataMap.put("u_file_desc", metadata.getString("fileDescription"));
		doc360MetadataMap.put("u_trail_id", metadata.getString("originalPrintTrail"));
		doc360MetadataMap.put("u_privilege", metadata.getString("privilege"));

		switch (createApplication) {
//			case "ELGS":
//				doc360MetadataMap.put("policyNumber", metadata.getString("policyNumber"));
//	            doc360MetadataMap.put("physicianName", metadata.getString("providerName"));
//	            doc360MetadataMap.put("patientName", metadata.getString("PatientName"));
//	            doc360MetadataMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
//	            doc360MetadataMap.put("memberName", metadata.getString("memberName"));
//	            doc360MetadataMap.put("claimNumber", metadata.getString("claimNumber"));
//
//	            if (metadata.getString("MemberAltID") != null) {
//	                doc360MetadataMap.put("memberId", metadata.getString("MemberAltID"));
//	            } else {
//	                doc360MetadataMap.put("memberId", metadata.getString("memberId"));
//	            }
//	            break;
//
			case "LETGEN":
	            doc360MetadataMap.put("u_pol_nbr", metadata.getString("policyNumber"));
	            doc360MetadataMap.put("u_phy_nm", metadata.getString("physicianName"));
	            doc360MetadataMap.put("u_mbr_nm", metadata.getString("memberName"));
	            doc360MetadataMap.put("u_clm_nbr", metadata.getString("claimNumber"));
	            doc360MetadataMap.put("u_ptnt_acct_nbr", metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            if (metadata.getString("MemberAltID") != null) {
	                doc360MetadataMap.put("u_mbr_id", metadata.getString("MemberAltID"));
	            } else {
	                doc360MetadataMap.put("u_mbr_id", metadata.getString("memberId"));
	            }
	            break;
//			case "NextGen":
//	            doc360MetadataMap.put("physicianName", metadata.getString("providerName"));
//	            doc360MetadataMap.put("policyNumber", metadata.getString("policyNumber"));
//	            doc360MetadataMap.put("memberName", metadata.getString("memberName"));
//	            doc360MetadataMap.put("notificationId", metadata.getString("notificationNumber"));
//	            doc360MetadataMap.put("letterHistoryId", metadata.getString("LetterHistoryID"));
//	            if (metadata.getString("MemberAltID") != null) {
//	                doc360MetadataMap.put("memberId", metadata.getString("MemberAltID"));
//	            } else {
//	                doc360MetadataMap.put("memberId", metadata.getString("memberId"));
//	            }
//	            break;
//
//			case "CCSManual", "1Click":
//	            doc360MetadataMap.put("physicianName", metadata.getString("physicianName"));
//	            doc360MetadataMap.put("policyNumber", metadata.getString("policyNumber"));
//	            doc360MetadataMap.put("memberName", metadata.getString("memberName"));
//	            doc360MetadataMap.put("notificationId", metadata.getString("notificationNumber"));
//	            doc360MetadataMap.put("letterHistoryId", metadata.getString("LetterHistoryID"));
//	            if (metadata.getString("MemberAltID") != null) {
//	                doc360MetadataMap.put("memberId", metadata.getString("MemberAltID"));
//	            } else {
//	                doc360MetadataMap.put("memberId", metadata.getString("memberId"));
//	            }
//
//	            break;
//
//			case "PmntEng", "Payment Engine":
//				doc360MetadataMap.put("EFT_Ind", metadata.getString("EFT_Ind"));
//	            doc360MetadataMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
//	            doc360MetadataMap.put("physicianName", metadata.getString("physicianName"));
//	            doc360MetadataMap.put(CHECK_NUMBER, metadata.getString(CHECK_TRACE_NUMBER));
//	            doc360MetadataMap.put(CHECK_ID, metadata.getString(CHECK_TRACE_NUMBER));
//	            doc360MetadataMap.put(CHECK_AMOUNT, metadata.getString("CheckAmt"));
//	            break;
//
//			case "CheckWrite", "CDC":
//	        	doc360MetadataMap.put("EFT_Ind", metadata.getString("EFT_Ind"));
//	            doc360MetadataMap.put("physicianName", metadata.getString("physicianName"));
//	            doc360MetadataMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
//	            doc360MetadataMap.put(CHECK_NUMBER, metadata.getString(CHECK_TRACE_NUMBER));
//	            doc360MetadataMap.put(CHECK_ID, metadata.getString(CHECK_TRACE_NUMBER));
//	            doc360MetadataMap.put(CHECK_AMOUNT, metadata.getString("CheckAmt"));
//	            break;
//
//	        case "DOC1":
//	            doc360MetadataMap.put("claimNumber", metadata.getString("claimNumber"));
//	            doc360MetadataMap.put("physicianName", metadata.getString("physicianName"));
//	            doc360MetadataMap.put("policyNumber", metadata.getString("policyNumber"));
//	            doc360MetadataMap.put("memberName", metadata.getString("memberName"));
//	            doc360MetadataMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
//
//	            if (metadata.getString("MemberAltID") != null) {
//	                doc360MetadataMap.put("memberId", metadata.getString("MemberAltID"));
//	            } else {
//	                doc360MetadataMap.put("memberId", metadata.getString("memberId"));
//	            }
//	            break;
//
//	        case "NICE":
//	        	doc360MetadataMap.put("physicianName", metadata.getString("physicianName"));
//	        	doc360MetadataMap.put(CHECK_AMOUNT, metadata.getString("CheckAmt"));
//	        	doc360MetadataMap.put(CHECK_ID, metadata.getString(CHECK_TRACE_NUMBER));
//	        	break;
//
//	        case "CSP-PRA":
//	            doc360MetadataMap.put("physicianName", metadata.getString("physicianName"));
//	            doc360MetadataMap.put("memberName", metadata.getString("memberName"));
//
//	            String ind_835 = metadata.get("Ind_835") != null ? metadata.get("Ind_835").toString() : "";
//	            doc360MetadataMap.put("Ind_835", ind_835);
//	            doc360MetadataMap.put(CHECK_NUMBER, metadata.getString(CHECK_TRACE_NUMBER));
//	            doc360MetadataMap.put(CHECK_ID, metadata.getString(CHECK_TRACE_NUMBER));
//	            doc360MetadataMap.put(CHECK_AMOUNT, metadata.getString("checkAmt"));
//	            doc360MetadataMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
//	            break;
//
//	        case "ODAR":
//	            doc360MetadataMap.put("policyNumber", metadata.getString("policyNumber"));
//	            doc360MetadataMap.put("physicianName", metadata.getString("physicianName"));
//	            doc360MetadataMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
//	            doc360MetadataMap.put(CHECK_NUMBER, metadata.getString("multCheckNumber"));
//	            doc360MetadataMap.put("memberName", filterDuplicates(metadata.getString("multMemberName")) );
//	            doc360MetadataMap.put("claimNumber", filterDuplicates(metadata.getString("multClaimNumber")) );
//	            doc360MetadataMap.put("memberId", filterDuplicates(metadata.getString("multMemberId")) );
//	        break;
//
//	        case "NGS":
//            case "MnR":
//            case "ENI":
//            case "CnS":
//            case "NGSCNS":
//            case "ATS":
//	            doc360MetadataMap.put("memberId", metadata.getString("memberId"));
//	            doc360MetadataMap.put("physicianName", metadata.getString("physicianName"));
//	            doc360MetadataMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
//	            doc360MetadataMap.put("caseId", metadata.getString("caseId"));
//	            doc360MetadataMap.put("memberName", metadata.getString("memberName"));
//	            break;
//
//	        case "ETS":
//	        	doc360MetadataMap.put("physicianName", metadata.getString("physicianName"));
//	        	doc360MetadataMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
//	        	doc360MetadataMap.put("caseId", metadata.getString("caseId"));
//	        	doc360MetadataMap.put("memberName", metadata.getString("memberName"));
//	        	doc360MetadataMap.put("memberId", metadata.getString("memberId"));
//	        	doc360MetadataMap.put("memberName", metadata.getString("memberName"));
//	        	break;
//
//			case "USP-COM-PRS":
//				doc360MetadataMap.put("EFT_Ind", metadata.getString("EFT_Ind"));
//	        	doc360MetadataMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
//	            doc360MetadataMap.put("physicianName", metadata.getString("physicianName"));
//	            doc360MetadataMap.put(CHECK_NUMBER, metadata.getString(CHECK_TRACE_NUMBER));
//	            doc360MetadataMap.put(CHECK_AMOUNT, metadata.getString("CheckAmt"));
//	            break;
//
//			case "CIRRUS":
//	        	doc360MetadataMap.put("policyNumber", metadata.getString("policyNumber"));
//	            doc360MetadataMap.put("physicianName", metadata.getString("providerName"));
//	            doc360MetadataMap.put("memberName", metadata.getString("memberName"));
//	            doc360MetadataMap.put("memberId", metadata.getString("memberId"));
//	            doc360MetadataMap.put("claimNumber", metadata.getString("claimNumber"));
//	            doc360MetadataMap.put("patientName", metadata.getString("PatientName"));
//	            doc360MetadataMap.put(PATIENT_ACCOUNT_NUMBER, metadata.getString(PATIENT_ACCOUNT_NUMBER));
//	            if (metadata.getString("MemberAltID") != null) {
//	                doc360MetadataMap.put("memberId", metadata.getString("MemberAltID"));
//	            } else {
//	                doc360MetadataMap.put("memberId", metadata.getString("memberId"));
//	            }
//	            break;
	        case "MACESS":
	            doc360MetadataMap.put("u_physician_nm", metadata.getString("providerName"));
	            doc360MetadataMap.put("u_clm_nbr", metadata.getString("claimNumber"));
	            doc360MetadataMap.put("u_mbr_id", metadata.getString("memberId"));
	            doc360MetadataMap.put("u_macess_sf_id", metadata.getString("Macess_SF_ID"));
	            doc360MetadataMap.put("u_ptnt_acct_nbr", metadata.getString(PATIENT_ACCOUNT_NUMBER));
	            break;
//	        case "TXGC":
//	        	String providerName = metadata.getString("providerName");
//            	if (providerName == null || providerName.isEmpty()) {
//            		providerName = metadata.getString("providerGroupName");
//            	}
//            	doc360MetadataMap.put("physicianName", providerName);
//            	break;
			default:
	        	break;
	    }
		
		return doc360MetadataMap;
	}

}
