package com.optum.fds.paperless;

import com.optum.fds.paperless.java.delegate.oauth.OauthTokenCacheExpiryPolicy;
import com.optum.fds.paperless.java.delegate.oauth.bean.OauthTokenExtended;
import org.ehcache.Cache;
import org.ehcache.CacheManager;
import org.ehcache.config.builders.CacheConfigurationBuilder;
import org.ehcache.config.builders.CacheManagerBuilder;
import org.ehcache.config.builders.ExpiryPolicyBuilder;
import org.ehcache.config.builders.ResourcePoolsBuilder;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableCaching
public class EhCache {

	private static final Logger LOGGER = LoggerFactory.getLogger(EhCache.class);

	protected CacheManager cacheManager;

	public EhCache() {
		cacheManager = CacheManagerBuilder.newCacheManagerBuilder()
				.withCache("oauthToken",
						CacheConfigurationBuilder.newCacheConfigurationBuilder(
										String.class,
										OauthTokenExtended.class,
										ResourcePoolsBuilder.heap(100)
								)
								.withExpiry(new OauthTokenCacheExpiryPolicy())
						)
				.withCache("providerCorpMpin",
						CacheConfigurationBuilder.newCacheConfigurationBuilder(
										String.class,
										String.class,
										ResourcePoolsBuilder.heap(150000)
								)
								.withExpiry(ExpiryPolicyBuilder.timeToIdleExpiration(java.time.Duration.ofSeconds(14400)))
				)
				.build(true);
	}

	public Cache<String, String> getProviderCorpMpinCacheFromCacheManager() {
		return cacheManager.getCache("providerCorpMpin", String.class, String.class);
	}

	public Cache<String, OauthTokenExtended> getOauthTokenCacheFromCacheManager() {
		return cacheManager.getCache("oauthToken", String.class, OauthTokenExtended.class);
	}


	public String getCorpMpinCache(String tin) {
		var cache = getProviderCorpMpinCacheFromCacheManager();
		String output;
		if (cache.containsKey(tin)) {
			String cacheEle = null;
			try {
				cacheEle = cache.get(tin);
			} catch (Exception e) {
				LOGGER.error("Failure providerCorpMpin cache.get removeAll tin; {}", ExceptionUtils.getStackTrace(e));
			}
			output = (cacheEle == null ? StringUtils.EMPTY : cacheEle);

			if (LOGGER.isDebugEnabled() && output.isEmpty()) {
				LOGGER.debug("Corporate mpin is not in cache with tin, and corpMpin : {}", output);
			} else {
				LOGGER.debug("Corporate mpin is in cache with tin, and corpMpin : {}", output);
			}

		} else {
			LOGGER.debug("Corporate mpin is not in cache for Tin");
			return StringUtils.EMPTY;
		}
		return output;
	}

	public void putCorpMpinCache(String tin, String corpMpin) {
		try {
			var cache = getProviderCorpMpinCacheFromCacheManager();
			if (StringUtils.isNotEmpty(corpMpin) && StringUtils.isNotEmpty(tin)) {
				cache.put(tin, corpMpin);
			}
		} catch (Exception e) {
			LOGGER.warn("EhCache putCorpMpinCache failed err={}", ExceptionUtils.getStackTrace(e));
		}
	}


	public String getOauthTokenCache(String token) {
		var cache = getOauthTokenCacheFromCacheManager();
		if (cache.containsKey(token)) {
			OauthTokenExtended cacheEle = null;
			try {
				cacheEle = cache.get(token);
			} catch (Exception e) {
				LOGGER.error("Failure oauthToken cache.get removeAll token; {}", ExceptionUtils.getStackTrace(e));
			}
			if (cacheEle != null && !cacheEle.isEmpty() && cacheEle.getAccessToken() != null && !cacheEle.getAccessToken().isEmpty()) {
				LOGGER.info("Token is in cache and not expired");
				return cacheEle.getAccessToken();
			} else {
				LOGGER.warn("Token is not in cache or it is expired");
				return null;
			}

		} else {
			LOGGER.warn("Token is not in cache.");
			return null;
		}
	}
	
	public void putOauthTokenWithExpiry(String key, String token, Integer expiresIn) {
		try {
			if (key != null && !key.isEmpty() && token != null && !token.isEmpty()) {
				var cache = getOauthTokenCacheFromCacheManager();
				var oauthToken = new OauthTokenExtended(token, expiresIn);
				LOGGER.info("Putting OAuth token in cache with expiry={} seconds", expiresIn);
				cache.put(key, oauthToken);
			}
		} catch (Exception e) {
			LOGGER.warn("EhCache putOauthToken failed err={}", ExceptionUtils.getStackTrace(e));
		}
	}

}