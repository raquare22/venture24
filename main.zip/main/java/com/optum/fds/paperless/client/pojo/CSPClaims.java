package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

import java.util.Objects;

public class CSPClaims extends ClientMetadata{

    @JsonProperty("LETTERTYPE")
    private String subCategory;

    @JsonProperty("PROVIDERTAXID")
    private String tin;

    @JsonProperty("IndivProvMPIN")
    private String mpin;

    @JsonProperty("isPrintSuppressed")
    private String emailAlertReq;

    @JsonProperty("PHYSICIANNAME")
    private String providerName;

    @JsonProperty("EMPLOYEEID")
    private String memberId;

    @JsonProperty("ICNNUMBER")
    private String claimNumber;

    @JsonProperty("PassThruData")
    private String PassThruData;

    @JsonProperty("originalPrintTrail")
    private String originalPrintTrail;

    @JsonProperty("CONFIGKEY")
    private String CONFIGKEY;

    @JsonProperty("MailToAddress1")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    private String MailToAddress6;

    @JsonProperty("Macess_SF_ID")
    private String Macess_SF_ID;



    public CSPClaims(){
        this.subCategory = "CP";
        this.category = getCategory();
        this.fileType = "Letter";
        this.tenant = "Link";
        this.fileDescription = getFileDescription();
        this.createApplication = "MACESS";
        this.providerEmailId = "";
        this.postCardInd = true;
        this.privilege = "Claim Status";
        Subcategory subCat =Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }

    public void setCategory(String subCategory){
        this.category = ((Objects.equals(getSubCategory(), "X2"))? "Appeals and Disputes": "Claim");
    }

    public String getCategory() {
        return category;
    }

    public void setFileDescription(String subCategory){
        this.fileDescription = ((Objects.equals(getSubCategory(), "X2"))? "Appeals and Disputes Letters": "Claim Letters");
    }

    public String getFileDescription() {
        return fileDescription;
    }



    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "CP";
            this.setFilePath(Subcategory.CP.getFilePath());
        } else {
            this.subCategory = subCategory;
            CSPClaims.Subcategory subCat = null;
            try {
                subCat = CSPClaims.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = Subcategory.CP;
            }
            this.setFilePath(subCat.getFilePath());
        }
        setCategory(this.subCategory);
        setFileDescription(this.subCategory);
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getMpin() {
        return mpin;
    }
    public void setMpin(String mpin) {
        if (mpin != null){
            this.mpin = mpin;
        }
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }
    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()){
            this.emailAlertReq = emailAlertReq;
        }
    }


    public String getClaimNumber() {
        return claimNumber;
    }

    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }


    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String passThruData) {
        PassThruData = passThruData;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String CONFIGKEY) {
        this.CONFIGKEY = CONFIGKEY;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String mailToAddress1) {
        MailToAddress1 = mailToAddress1;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String mailToAddress2) {
        MailToAddress2 = mailToAddress2;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String mailToAddress3) {
        MailToAddress3 = mailToAddress3;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String mailToAddress4) {
        MailToAddress4 = mailToAddress4;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String mailToAddress5) {
        MailToAddress5 = mailToAddress5;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String mailToAddress6) {
        MailToAddress6 = mailToAddress6;
    }

    public String getMacess_SF_ID() {
        return Macess_SF_ID;
    }

    public void setMacess_SF_ID(String macess_SF_ID) {
        Macess_SF_ID = macess_SF_ID;
    }


    public enum ErrorMsg implements ErrorMessage {

        PROCESSDATE (12, "Missing or invalid data: PROCESSDATE"),
        LETTERTYPE (12, "Missing or invalid data: LETTERTYPE"),
        PROVIDERTAXID (12, "Missing or invalid data: Provider TIN"),
        IndivProvMPIN (12, "Missing or invalid data: ProviderMPIN"),
        isPrintSuppressed (12,"Missing or invalid data: isPrintSuppressed"),
        ICNNUMBER(12,"Missing or invalid data: Claim Number"),

        PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"),
        CONFIGKEY (22, "Missing or invalid data: CONFIGKEY(SEVERE)"),
        originalPrintTrail (22, "Missing or invalid data: OriginalPrintTrail(SEVERE)"),
        MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"),
        MailToAddress2 (22, "Missing or invalid data: MailToAddress2(SEVERE)"),
        MailToAddress4 (22, "Missing or invalid data: MailToAddress4(SEVERE)"),
        MailToAddress5 (22, "Missing or invalid data: MailToAddress5(SEVERE)"),
        MailToAddress6 (22, "Missing or invalid data: MailToAddress6(SEVERE)");

        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }
        public String getErrorMessage() {
            return errorMessage;
        }
    }

    public enum Subcategory {
        // CPS Claims
        S1 ("S1", "Community Plan/Additional Info Needed"),
        S2 ("S2", "Community Plan/Medical Reimbursement"),
        S6 ("S6", "Community Plan/Medical Claim Review"),
        S7 ("S7", "Community Plan/Medicaid Reconsiderations"),
        S8 ("S8", "Commercial/Individual & Family Plan Reconsiderations"),
        S9 ("S9", "Community Plan/DSNP Reconsiderations"),
        S0 ("S0", "Community Plan/Miscellaneous"),
        O5 ("O5", "Community Plan/Optum Rx"),
        CP ("CP", "Other Community Plan Letters/Other"),
        X2 ("X2", "Community Plan/Acknowledgement, Notification, and Response");

        private String subCat;
        private String filePath;

        Subcategory(String subCat, String filePath){
            this.subCat = subCat;
            this.filePath = filePath;
        }
        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }
}
