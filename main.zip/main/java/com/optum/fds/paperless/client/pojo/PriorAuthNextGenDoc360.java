package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;

import static com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil.normalizeMemberName;

public class PriorAuthNextGenDoc360 extends ClientMetadata {

	private static final long serialVersionUID = 1L;

	private static final String DEFAULT_CATEGORY = "Prior Auth Notification";
	private static final String FILE_TYPE = "Letter";
	private static final String DEFAULT_TENANT = "Link";
	private static final String CREATE_APPLICATION = "NextGen";
	private static final String EMPTY = "";
	private static final String DEFAULT_PRIVILEGE = "Notification/Prior Authorization Status Inquiry/Update";
	private static final String DEFAULT_SUBCATEGORY = "ZZ";

	@JsonProperty("notificationNumber")
	@JsonAlias("u_ntfy_nbr")
	private String notificationNumber;

	@JsonProperty("subCategory")
	@JsonAlias("u_sub_category")
	private String subCategory;

	@JsonProperty("tin")
	@JsonAlias("u_prov_tin")
	private String tin;

	@JsonProperty("mpin")
	@JsonAlias("u_mpin")
	private String mpin = "";

	@JsonProperty("emailAlertReq")
	@JsonAlias("u_email_alert_req")
	private String emailAlertReq = "Y";

	@JsonProperty("providerName")
	@JsonAlias("u_rcip_nm")
	private String providerName;

	@JsonProperty("ELGSLETTERGENID")
	@JsonAlias("u_elgs_ltr_gen_id")
	private String elgsLetterGenId;

	@JsonProperty("HISTORYID")
	@JsonAlias("u_ltr_hist_id")
	private String letterHistoryId;

	@JsonProperty("OriginPrintTrail")
	@JsonAlias("u_trl_id")
	private String originalPrintTrail;

	@JsonProperty("PassThruData")
	@JsonAlias("u_pass_thru_data")
	private String passThruData;

	@JsonProperty("CONFIGKEY")
	@JsonAlias("u_config_key")
	private String configKey;

	@JsonProperty("MailToAddress1")
	@JsonAlias("u_rcip_nm")
	private String mailToAddress1;

	@JsonProperty("MailToAddress2")
	@JsonAlias("u_adr1")
	private String mailToAddress2;

	@JsonProperty("MailToAddress3")
	@JsonAlias("u_adr2")
	private String mailToAddress3;

	@JsonProperty("MailToAddress4")
	@JsonAlias("u_cty")
	private String mailToAddress4;

	@JsonProperty("MailToAddress5")
	@JsonAlias("u_st")
	private String mailToAddress5;

	@JsonProperty("MailToAddress6")
	@JsonAlias("u_zip")
	private String mailToAddress6;

	@JsonProperty("memberFirstName")
	@JsonAlias("u_fst_nm")
	private String memberFirstName;

	@JsonProperty("memberLastName")
	@JsonAlias("u_lst_nm")
	private String memberLastName;

	@JsonProperty("memberName")
	@JsonAlias("u_mbr_nm")
	private String memberName;

	@JsonProperty("RELATEDID")
	@JsonAlias("u_rel_ltr_id")
	private String relatedId;

	@JsonProperty("MemberID")
	@JsonAlias("u_mbr_id")
	private String memberId;

	@JsonProperty("ProviderDEC")
	@JsonAlias("u_prov_dec_nbr")
	private String providerDec;

	@JsonProperty("NotificationLetterID")
	@JsonAlias("u_ntfy_ltr_id")
	private String notificationLetterId;

	@JsonProperty("npi")
	@JsonAlias("u_npi")
	private String npi;

	@JsonProperty("ELGSREQUESTID")
	@JsonAlias("u_elgs_req_id")
	private String elgsRequestId;

	@JsonProperty("GenerationType")
	@JsonAlias("u_gen_typ")
	private String generationType;

	@JsonProperty("LetterPriority")
	@JsonAlias("u_ltr_pr")
	private String letterPriority;

	@JsonProperty("BusinessSegment")
	@JsonAlias("u_bus_seg")
	private String businessSegment;

	@JsonProperty("RequesterID")
	@JsonAlias("u_rqstr_id")
	private String requesterId;

	public PriorAuthNextGenDoc360() {

		this.category = DEFAULT_CATEGORY;
		this.fileType = FILE_TYPE;
		this.tenant = DEFAULT_TENANT;
		this.createApplication = CREATE_APPLICATION;
		this.docSentTo = EMPTY;
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.providerEmailId = EMPTY;
		this.postCardInd = true;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.privilege = DEFAULT_PRIVILEGE;

		this.subCategory = DEFAULT_SUBCATEGORY;

		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}

	public String getNotificationNumber() {
		return notificationNumber;
	}

	public void setNotificationNumber(String notificationNumber) {
		this.notificationNumber = notificationNumber;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		if (subCategory == null || subCategory.isEmpty()) {
			this.subCategory = DEFAULT_SUBCATEGORY;
			this.setFilePath(Subcategory.ZZ.getFilePath());
		} else {
			this.subCategory = subCategory;
			Subcategory subCat;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.ZZ;
			}
			this.setFilePath(subCat.getFilePath());
		}
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		if (mpin != null && !mpin.isEmpty()) {
			this.mpin = StringUtils.leftPad(mpin, 9, '0');
		}
	}

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()) {
			this.emailAlertReq = emailAlertReq;
		}
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getElgsLetterGenId() {
		return elgsLetterGenId;
	}

	public void setElgsLetterGenId(String elgsLetterGenId) {
		this.elgsLetterGenId = elgsLetterGenId;
	}

	public String getLetterHistoryId() {
		return letterHistoryId;
	}

	public void setLetterHistoryId(String letterHistoryId) {
		this.letterHistoryId = letterHistoryId;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getPassThruData() {
		return passThruData;
	}

	public void setPassThruData(String passThruData) {
		this.passThruData = passThruData;
	}

	public String getConfigKey() {
		return configKey;
	}

	public void setConfigKey(String configKey) {
		this.configKey = configKey;
	}

	public String getMailToAddress1() {
		// Copy recipient name from providerName (u_rcip_nm) if mailToAddress1 is not set
		return mailToAddress1 != null ? mailToAddress1 : providerName;
	}

	public void setMailToAddress1(String mailToAddress1) {
		this.mailToAddress1 = mailToAddress1;
	}

	public String getMailToAddress2() {
		return mailToAddress2;
	}

	public void setMailToAddress2(String mailToAddress2) {
		this.mailToAddress2 = mailToAddress2;
	}

	public String getMailToAddress3() {
		return mailToAddress3;
	}

	public void setMailToAddress3(String mailToAddress3) {
		this.mailToAddress3 = mailToAddress3;
	}

	public String getMailToAddress4() {
		return mailToAddress4;
	}

	public void setMailToAddress4(String mailToAddress4) {
		this.mailToAddress4 = mailToAddress4;
	}

	public String getMailToAddress5() {
		return mailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		this.mailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return mailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		this.mailToAddress6 = mailToAddress6;
	}

	public String getMemberFirstName() {
		return memberFirstName;
	}

	public void setMemberFirstName(String memberFirstName) {
		this.memberFirstName = memberFirstName;
	}

    public String getMemberLastName() {
		return memberLastName;
	}

	public void setMemberLastName(String memberLastName) {
		this.memberLastName = memberLastName;
        this.memberName = normalizeMemberName(this.memberFirstName, this.memberLastName);
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getRelatedId() {
		return relatedId;
	}

	public void setRelatedId(String relatedId) {
		this.relatedId = relatedId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getProviderDec() {
		return providerDec;
	}

	public void setProviderDec(String providerDec) {
		this.providerDec = providerDec;
	}

	public String getNotificationLetterId() {
		return notificationLetterId;
	}

	public void setNotificationLetterId(String notificationLetterId) {
		this.notificationLetterId = notificationLetterId;
	}

	public String getNpi() {
		return npi;
	}

	public void setNpi(String npi) {
		this.npi = npi;
	}

	public String getElgsRequestId() {
		return elgsRequestId;
	}

	public void setElgsRequestId(String elgsRequestId) {
		this.elgsRequestId = elgsRequestId;
	}

	public String getGenerationType() {
		return generationType;
	}

	public void setGenerationType(String generationType) {
		this.generationType = generationType;
	}

	public String getLetterPriority() {
		return letterPriority;
	}

	public void setLetterPriority(String letterPriority) {
		this.letterPriority = letterPriority;
	}

	public String getBusinessSegment() {
		return businessSegment;
	}

	public void setBusinessSegment(String businessSegment) {
		this.businessSegment = businessSegment;
	}

	public String getRequesterId() {
		return requesterId;
	}

	public void setRequesterId(String requesterId) {
		this.requesterId = requesterId;
	}


	public enum ErrorMsg implements ErrorMessage {

		u_ntfy_nbr(12, "Missing or invalid data: u_ntfy_nbr"),
		u_sub_category(12, "Missing or invalid data: u_sub_category"),
		u_prov_tin(12, "Missing or invalid data: u_prov_tin"), 
		u_mpin(12, "Missing or invalid data: u_mpin"),
		u_email_alert_req(12, "Missing or invalid data: u_email_alert_req"),

		u_ltr_hist_id(22, "Missing or invalid data: u_ltr_hist_id(SEVERE)"),
		u_pass_thru_data(22, "Missing or invalid data: u_pass_thru_data(SEVERE)"),
		u_trl_id(22, "Missing or invalid data: u_trl_id(SEVERE)"),
		u_config_key(22, "Missing or invalid data: u_config_key(SEVERE)"),
        u_rcip_nm(22, "Missing or invalid data: u_rcip_nm(SEVERE)"),
		u_adr1(22, "Missing or invalid data: u_adr1(SEVERE)"),
		u_cty(22, "Missing or invalid data: u_cty(SEVERE)"),
		u_st(22, "Missing or invalid data: u_st(SEVERE)"),
		u_zip(22, "Missing or invalid data: u_zip(SEVERE)"),
		u_ltr_gen_date(12, "Missing or invalid data: u_ltr_gen_date");

		private int errorCode;
		private String errorMessage;

		ErrorMsg(int code, String message) {
			this.errorCode = code;
			this.errorMessage = message;
		}

		public int getErrorCode() {
			return errorCode;
		}

		public String getErrorMessage() {
			return errorMessage;
		}
	}

	public enum Subcategory {

		A1("A1", "Commercial Prior Auth/Approved"), 
		A2("A2", "Commercial Prior Auth/Denied"),
		A3("A3", "Commercial Prior Auth/Lack of Information"), 
		A4("A4", "Medicare Prior Auth/Approved"),
		A5("A5", "Medicare Prior Auth/Denied"), 
		A6("A6", "Medicare Prior Auth/Lack of Information"),
		A7("A7", "UHC West Prior Auth/Approved"), 
		A8("A8", "UHC West Prior Auth/Denied"),
		A9("A9", "UHC West Prior Auth/Lack of Information"), 
		N1("N1", "Community Plan Prior Auth/Approved"),
		N2("N2", "Community Plan Prior Auth/Denied"),
		N3("N3", "Community Plan Prior Auth/Lack of Information"),
		ZZ("ZZ", "Misc. Prior Auth/Other");

		private String subCat;
		private String filePath;

		Subcategory(String subCat, String filePath) {
			this.subCat = subCat;
			this.filePath = filePath;
		}

		public String getSubCat() {
			return subCat;
		}

		public String getFilePath() {
			return filePath;
		}
	}

}
