package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;
import com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil;

public class MRAppealsDoc360 extends ClientMetadata {

    private static final long serialVersionUID = -8828132794031341312L;

    @JsonProperty("caseId")
    @JsonAlias({"u_case_id", "u_cse_id"})
    private String caseId;

    @JsonProperty("NGSID")
    @JsonAlias("u_uniq_ltr_id")
    private String ngsId;

    @JsonProperty("tin")
    @JsonAlias({"u_tin", "u_prov_tin"})
    private String tin;

    @JsonProperty("mpin")
    @JsonAlias("u_mpin")
    private String mpin="";

    @JsonProperty("isPrintSuppressed")
    @JsonAlias({"u_is_print_suppressed" })
    private String emailAlertReq="N";

    @JsonProperty("lob")
    @JsonAlias("u_lob")
    private String lob;

    @JsonProperty("memberDOB")
    @JsonAlias("u_mbr_dob")
    private String memberDOB;

    @JsonProperty("memberFirstName")
    @JsonAlias("u_mbr_fst_nm")
    private String memberFirstName;

    @JsonProperty("memberLastName")
    @JsonAlias("u_mbr_lst_nm")
    private String memberLastName;

    @JsonProperty("memberName")
    private String memberName;

    @JsonProperty("patientAccountNumber")
    @JsonAlias("u_ptnt_acct_nbr")
    private String patientAccountNumber;

    @JsonProperty("physicianName")
    @JsonAlias("u_phy_nm")
    private String physicianName;

    @JsonProperty("memberId")
    @JsonAlias("u_mbr_id")
    private String memberId;

    @JsonProperty("CONFIGKEY")
    @JsonAlias("u_config_key")
    private String CONFIGKEY;

    @JsonProperty("originalPrintTrail")
    @JsonAlias("u_trl_id")
    private String originalPrintTrail;

    @JsonProperty("PassThruData")
    @JsonAlias("u_pass_thru_data")
    private String PassThruData;

    @JsonProperty("subCategory")
    @JsonAlias("u_sub_category")
    protected String subCategory;

    @JsonProperty("MailToAddress1")
    @JsonAlias("u_mail_to_adr1")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    @JsonAlias("u_mail_to_adr2")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    @JsonAlias("u_mail_to_adr3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    @JsonAlias("u_mail_to_adr4")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    @JsonAlias("u_mail_to_st")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    @JsonAlias("u_mail_to_zip")
    private String MailToAddress6;

    public MRAppealsDoc360() {
        this.category = "Appeals and Disputes";
        this.fileType = "Letter";
        this.tenant = "Link";
        this.fileDescription = "Appeals and Disputes";
        this.createApplication = "NGS";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.subCategory = "XX";
        MRAppeals.Subcategory subCat = MRAppeals.Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }

    public String getCaseId() { return caseId; }

    public void setCaseId(String caseId) { this.caseId = caseId; }

    public String getNgsId() { return ngsId; }

    public void setNgsId(String ngsId) { this.ngsId = ngsId; }

    public String getTin() { return tin; }

    public void setTin(String tin) { this.tin = tin; }

    public String getMpin() { return mpin; }

    public void setMpin(String mpin) { if(mpin != null){ this.mpin = mpin; }}

    public String getEmailAlertReq() { return emailAlertReq; }

    public void setEmailAlertReq(String emailAlertReq) { if (emailAlertReq != null && !emailAlertReq.isEmpty()){ this.emailAlertReq = emailAlertReq; }}

    public String getLob() { return lob; }

    public void setLob(String lob) { this.lob = lob; }

    public String getMemberDOB() { return memberDOB; }

    public void setMemberDOB(String memberDOB) { this.memberDOB = memberDOB; }

    public String getMemberFirstName() {
        return memberFirstName;
    }

    public void setMemberFirstName(String memberFirstName) {
        this.memberFirstName = memberFirstName;
        this.memberName = NormalizeUtil.normalizeMemberName(this.memberFirstName, this.memberLastName);
    }

    public String getMemberLastName() { return memberLastName; }

    public void setMemberLastName(String memberLastName) {
        this.memberLastName = memberLastName;
        this.memberName = NormalizeUtil.normalizeMemberName(this.memberFirstName, this.memberLastName);
    }

    public String getPatientAccountNumber() { return patientAccountNumber; }

    public void setPatientAccountNumber(String patientAccountNumber) { this.patientAccountNumber = patientAccountNumber; }

    public String getPhysicianName() { return physicianName; }

    public void setPhysicianName(String physicianName) { this.physicianName = physicianName; }

    public String getMemberId() { return memberId; }

    public void setMemberId(String memberId) { this.memberId = memberId; }

    public String getCONFIGKEY() { return CONFIGKEY; }

    public void setCONFIGKEY(String cONFIGKEY) { CONFIGKEY = cONFIGKEY; }

    public String getOriginalPrintTrail() { return originalPrintTrail; }

    public void setOriginalPrintTrail(String originalPrintTrail) { this.originalPrintTrail = originalPrintTrail; }

    public String getPassThruData() { return PassThruData; }

    public void setPassThruData(String passThruData) { PassThruData = passThruData; }

    public String getMailToAddress1() { return MailToAddress1; }

    public void setMailToAddress1(String mailToAddress1) { MailToAddress1 = mailToAddress1; }

    public String getMailToAddress2() { return MailToAddress2; }

    public void setMailToAddress2(String mailToAddress2) { MailToAddress2 = mailToAddress2; }

    public String getMailToAddress3() { return MailToAddress3; }

    public void setMailToAddress3(String mailToAddress3) { MailToAddress3 = mailToAddress3; }

    public String getMailToAddress4() { return MailToAddress4; }

    public void setMailToAddress4(String mailToAddress4) { MailToAddress4 = mailToAddress4; }

    public String getMailToAddress5() { return MailToAddress5; }

    public void setMailToAddress5(String mailToAddress5) { MailToAddress5 = mailToAddress5; }

    public String getMailToAddress6() { return MailToAddress6; }

    public void setMailToAddress6(String mailToAddress6) { MailToAddress6 = mailToAddress6; }

    public String getSubCategory() { return subCategory; }

    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "XX";
            this.setFilePath(MRAppeals.Subcategory.XX.getFilePath());
        } else {
            this.subCategory = subCategory;
            MRAppeals.Subcategory subCat = null;
            try {
                subCat = MRAppeals.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = MRAppeals.Subcategory.XX;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }


    public enum ErrorMsg implements ErrorMessage {
        u_tin (12, "Missing or invalid data: tin"),
        u_mpin(12, "Missing or invalid data: mpin"), // emailAlertReq == \"Y\"
        u_sub_category (12, "Missing or invalid data: subCategory"),
        u_is_print_suppressed (12,"Missing or invalid data: isPrintSuppressed"),
        u_doc_creation_dt (12, "Missing or invalid data: createdDate"),
        u_case_id (12, "Missing or invalid data: caseId"),
        u_uniq_id (12, "Missing or invalid data: NGSID"),

        u_privilege (22, "Missing or invalid data: privilege(SEVERE)"),
        u_config_key (22, "Missing or invalid data: CONFIGKEY(SEVERE)"), // emailAlertReq == \"Y\"
        u_trl_id (22, "Missing or invalid data: originalPrintTrail(SEVERE)"), // emailAlertReq == \"Y\"
        u_pass_thru_data (22, "Missing or invalid data: PassThruData(SEVERE)"), // emailAlertReq == \"Y\"
        u_mail_to_adr1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"), // emailAlertReq == \"Y\"
        u_mail_to_adr2 (22, "Missing or invalid data: MailToAddress2(SEVERE)"), // emailAlertReq == \"Y\"
        u_mail_to_adr4 (22, "Missing or invalid data: MailToAddress4(SEVERE)"); // emailAlertReq == \"Y\"


        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }
        public String getErrorMessage() {
            return errorMessage;
        }

    }

    public enum Subcategory {
        // MR Appeals
        Y2 ("Y2", "Medicare Appeals and Disputes / Additional Information Needed (Rx)"),
        Y3 ("Y3", "Medicare  Appeals and Disputes / Resolution (Rx)"),
        Y4 ("Y4", "Medicare  Appeals and Disputes / Notification and Acknowledgement (Rx)"),
        Y5 ("Y5", "Special Needs Plan Appeals and Disputes / Additional Information Needed"),
        Y6 ("Y6", "Special Needs Plan Appeals and Disputes / Resolution"),
        Y7 ("Y7", "Special Needs Plan Appeals and Disputes / Notification and Acknowledgement"),
        X1 ("X1", "Commercial Appeals and Disputes / Acknowledgement, Notification, and Response"),
        X2 ("X2", "Community Plan Appeals and Disputes / Acknowledgement, Notification, and Response"),
        X5 ("X5", "Medicare Appeals and Disputes / Additional Information Needed"),
        X6 ("X6", "Medicare Appeals and Disputes / Resolution"),
        X7 ("X7", "Medicare Appeals and Disputes / Notification and Acknowledgement"),
        X8 ("X8", "UHCWest Appeals and Disputes / Additional Information Needed"),
        X9 ("X9", "UHCWest Appeals and Disputes / Resolution"),
        X0 ("X0", "UHCWest Appeals and Disputes / Notification and Acknowledgement"),
        XX ("XX", "Other Appeals and Disputes / Other");

        private String subCat;
        private String filePath;

        Subcategory(String subCat, String filePath){
            this.subCat = subCat;
            this.filePath = filePath;
        }
        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }

}
