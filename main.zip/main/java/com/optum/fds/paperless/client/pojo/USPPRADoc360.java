package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

import java.util.Date;

import static com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil.normalizeMemberName;
import static com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil.normalizePipeDelimitedValue;

@JsonIgnoreProperties(ignoreUnknown = true)
public class USPPRADoc360 extends ClientMetadata {

    private static final long serialVersionUID = -8737265368684222974L;
    @JsonProperty("tin")
    @JsonAlias("u_tin")
    private String tin;

    @JsonProperty("mpin")
    @JsonAlias("u_indiv_prov_mpin")
    private String mpin="";

    @JsonProperty("emailAlertReq")
    @JsonAlias("u_email_alert_req")
    private String emailAlertReq="Y";

    @JsonProperty("EFT_Ind")
    @JsonAlias("u_eft_ind")
    private String EFT_Ind;

    @JsonProperty("835_Ind")
    @JsonAlias("u_835_ind")
    private String Ind_835;
    
    @JsonProperty("physicianName")
    @JsonAlias("u_phy_nm")
    private String physicianName;

    @JsonProperty("CheckTraceNumber")
    @JsonAlias("u_pay_nbr")
    private String CheckTraceNumber;

    @JsonProperty("multClaimNumber")
    @JsonAlias("u_claim_nbr")
    private String multClaimNumber;

    @JsonProperty("multMemberId")
    @JsonAlias("u_mbr_id")
    private String multMemberId;  // added newly

    @JsonProperty("DefaultUsed")
    private String DefaultUsed;

    @JsonProperty("CheckAmt")
    @JsonAlias("u_chk_amt")
    private String CheckAmt;

    @JsonProperty("CONFIGKEY")
    @JsonAlias("u_config_key")
    private String CONFIGKEY;

    @JsonProperty("originalPrintTrail")
    @JsonAlias("u_trl_id")
    private String originalPrintTrail;

    @JsonProperty("PassThruData")
    @JsonAlias("u_pass_thru_data")
    private String PassThruData;

    @JsonProperty("MailToAddress1")
    @JsonAlias("u_mailing_adr1")
    private String MailToAddress1;

    @JsonProperty("paymentNumber")
    @JsonAlias("u_vendor_pay_id")
    private String paymentNumber;

    public String getMultMemberId() {
        return multMemberId;
    }

    public void setMultMemberId(Object raw) {
        this.multMemberId = normalizePipeDelimitedValue(raw);
    }

    @JsonProperty("MailToAddress2")
    @JsonAlias("u_mailing_adr2")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    @JsonAlias("u_mailing_adr3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    @JsonAlias("u_mail_to_cty")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    @JsonAlias("u_mail_to_st")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    @JsonAlias("u_mail_to_zip")
    private String MailToAddress6;

    @JsonProperty("subCategory")
    @JsonAlias("u_sub_category")
    protected String subCategory;

    private String memberName;

    @JsonProperty("memberFirstName")
    @JsonAlias("u_mbr_fst_nm")
    private String memberFirstName;

    @JsonProperty("memberLastName")
    @JsonAlias("u_mbr_lst_nm")
    private String memberLastName;

    @JsonProperty("dateOfService")
    @JsonAlias("u_srvc_dt")
    private Date dateOfService;

    @JsonProperty("dcnNumber")
    @JsonAlias("u_dcn")
    private String dcnNumber;

    @JsonProperty("div")
    @JsonAlias("u_div")
    private String div;

    @JsonProperty("praDocumentTypeCode")
    @JsonAlias("u_doc_typ_cd")
    private String praDocumentTypeCode;

    @JsonProperty("enterpriseId")
    @JsonAlias("u_enterprise_id")
    private String enterpriseId;

    @JsonProperty("fulfillmentRequestHeaderIdentifier")
    @JsonAlias("u_flfl_req_head_id")
    private String fulfillmentRequestHeaderIdentifier;

    @JsonProperty("globalDocId")
    @JsonAlias("u_gbl_doc_id")
    private String globalDocId;

    @JsonProperty("legalHold")
    @JsonAlias("u_legal_hold")
    private String legalHold;

    @JsonProperty("mailToGroupName")
    @JsonAlias("u_mail_to_grp_nm")
    private String mailToGroupName;

    @JsonProperty("paymentCycleDate")
    @JsonAlias("u_pay_cyc_dt")
    private Date paymentCycleDate;

    @JsonProperty("paymentType")
    @JsonAlias("u_pay_type")
    private String paymentType;

    @JsonProperty("policyNumber")
    @JsonAlias("u_pol_nbr")
    private String policyNumber;

    @JsonProperty("state")
    @JsonAlias("u_st")
    private String state;

    @JsonProperty("templateIdentifier")
    @JsonAlias("u_tmplt_id")
    private String templateIdentifier;

    @JsonProperty("templateName")
    @JsonAlias("u_tmplt_nm")
    private String templateName;

    @JsonProperty("trailName")
    @JsonAlias("u_trl_nm")
    private String trailName;

    @JsonProperty("saOi")
    @JsonAlias("u_sa_oi")
    private String saOi;

    @JsonProperty("npi")
    @JsonAlias("u_npi")
    private String npi;
    
    @JsonProperty("multPatientAccountNumber")
    @JsonAlias("u_ptnt_acct_nbr")
    private String multPatientAccountNumber;


    public USPPRADoc360() {
        this.category = "Payment Document";
        this.fileType = "Letter";
        this.tenant = "Link";
        this.fileDescription = "Provider Remittance Advice";
        this.createApplication = "USP-COM-PRS";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.privilege = "Claim Status";
        this.subCategory = "PR";
        this.memberFirstName = "";
        this.memberLastName = "";
        this.memberName = normalizeMemberName(this.memberFirstName, this.memberLastName);
        Subcategory subCat = Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        if (mpin != null){
            this.mpin = mpin;
        }
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()){
            this.emailAlertReq = emailAlertReq;
        }
    }

    public String getEFT_Ind() {
        return EFT_Ind;
    }

    public void setEFT_Ind(String eFT_Ind) {
        EFT_Ind = eFT_Ind;
    }

    public String getPhysicianName() {
        return physicianName;
    }

    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public String getCheckTraceNumber() {
        return CheckTraceNumber;
    }

    public void setCheckTraceNumber(String checkTraceNumber) {
        CheckTraceNumber = checkTraceNumber;
    }

    public String getMultClaimNumber() {
        return multClaimNumber;
    }

    @JsonSetter("multClaimNumber")
    @JsonAlias("u_claim_nbr")
    public void setMultClaimNumber(Object raw) {
        this.multClaimNumber = normalizePipeDelimitedValue(raw);
    }

    public String getDefaultUsed() {
        return DefaultUsed;
    }

    public void setDefaultUsed(String defaultUsed) {
        DefaultUsed = defaultUsed;
    }

    public String getCheckAmt() {
        return CheckAmt;
    }

    public void setCheckAmt(String checkAmt) {
        CheckAmt = checkAmt;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String cONFIGKEY) {
        CONFIGKEY = cONFIGKEY;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String passThruData) {
        PassThruData = passThruData;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String mailToAddress1) {
        MailToAddress1 = mailToAddress1;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String mailToAddress2) {
        MailToAddress2 = mailToAddress2;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String mailToAddress3) {
        MailToAddress3 = mailToAddress3;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String mailToAddress4) {
        MailToAddress4 = mailToAddress4;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String mailToAddress5) {
        MailToAddress5 = mailToAddress5;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String mailToAddress6) {
        MailToAddress6 = mailToAddress6;
    }

    public String getInd_835() {
        return Ind_835;
    }

    public void setInd_835(String ind_835) {
        Ind_835 = ind_835;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "PR";
            this.setFilePath(Subcategory.PR.getFilePath());
        } else {
            this.subCategory = subCategory;
            Subcategory subCat = null;
            try {
                subCat = Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = Subcategory.PR;
            }
            this.setFilePath(subCat.getFilePath());
        }

        if (this.getExpiryDate() != null && this.getExpiryDate().length() == 7) {
            this.setExpiryDate(this.vcpExpiryDateFormat(this.getExpiryDate(), this.subCategory));
        }
    }

    public String getPaymentNumber() {
        return paymentNumber;
    }

    public void setPaymentNumber(String paymentNumber) {
        this.paymentNumber = paymentNumber;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getMemberFirstName() {
        return memberFirstName;
    }

    public void setMemberFirstName(String memberFirstName) {
        this.memberFirstName = memberFirstName;
        this.memberName = normalizeMemberName(this.memberFirstName, this.memberLastName);
    }

    public String getMemberLastName() {
        return memberLastName;
    }

    public void setMemberLastName(String memberLastName) {
        this.memberLastName = memberLastName;
        this.memberName = normalizeMemberName(this.memberFirstName, this.memberLastName);
    }

    public String getMemberName(){
        return memberName;
    }


    public Date getDateOfService() {
        return dateOfService;
    }

    public void setDateOfService(Date dateOfService) {
        this.dateOfService = dateOfService;
    }

    public String getDcnNumber() {
        return dcnNumber;
    }

    public void setDcnNumber(String dcnNumber) {
        this.dcnNumber = dcnNumber;
    }

    public String getDiv() {
        return div;
    }

    public void setDiv(String div) {
        this.div = div;
    }

    public String getPraDocumentTypeCode() {
        return praDocumentTypeCode;
    }

    public void setPraDocumentTypeCode(String praDocumentTypeCode) {
        this.praDocumentTypeCode = praDocumentTypeCode;
    }

    public String getEnterpriseId() {
        return enterpriseId;
    }

    public void setEnterpriseId(String enterpriseId) {
        this.enterpriseId = enterpriseId;
    }

    public String getFulfillmentRequestHeaderIdentifier() {
        return fulfillmentRequestHeaderIdentifier;
    }

    public void setFulfillmentRequestHeaderIdentifier(String fulfillmentRequestHeaderIdentifier) {
        this.fulfillmentRequestHeaderIdentifier = fulfillmentRequestHeaderIdentifier;
    }

    public String getGlobalDocId() {
        return globalDocId;
    }

    public void setGlobalDocId(String globalDocId) {
        this.globalDocId = globalDocId;
    }

    public String getLegalHold() {
        return legalHold;
    }

    public void setLegalHold(String legalHold) {
        this.legalHold = legalHold;
    }

    public String getMailToGroupName() {
        return mailToGroupName;
    }

    public void setMailToGroupName(String mailToGroupName) {
        this.mailToGroupName = mailToGroupName;
    }

    public Date getPaymentCycleDate() {
        return paymentCycleDate;
    }

    public void setPaymentCycleDate(Date paymentCycleDate) {
        this.paymentCycleDate = paymentCycleDate;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getTemplateIdentifier() {
        return templateIdentifier;
    }

    public void setTemplateIdentifier(String templateIdentifier) {
        this.templateIdentifier = templateIdentifier;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getTrailName() {
        return trailName;
    }

    public void setTrailName(String trailName) {
        this.trailName = trailName;
    }

    public String getSaOi() {
        return saOi;
    }

    public void setSaOi(String saOi) {
        this.saOi = saOi;
    }

    public enum ErrorMsg implements ErrorMessage {
    	u_eft_ind (22, "Missing or invalid data: u_eft_ind(SEVERE)"),
        u_pay_nbr (12, "Missing or invalid data: u_pay_nbr"),
        u_tin_22 (22, "Missing or invalid data: u_tin (SEVERE)"),
        u_tin_12 (12, "Missing or invalid data: Provider u_tin"),
        u_indiv_prov_mpin (12, "Missing or invalid data: u_indiv_prov_mpin"),
        u_sub_category (12, "Missing or invalid data: u_sub_category"),
        u_email_alert_req (12,"Missing or invalid data: u_email_alert_req"),
        u_orig_creation_date (12, "Missing or invalid data: u_orig_creation_date"),

        u_config_key(22, "Missing or invalid data: u_config_key(SEVERE)"),
        u_trl_id (22, "Missing or invalid data: u_trl_id(SEVERE)"),
        u_pass_thru_data (22, "Missing or invalid data: u_pass_thru_data(SEVERE)"),

        u_mailing_adr1 (22, "Missing or invalid data: u_mailing_adr1(SEVERE)"),
        u_mailing_adr2 (22, "Missing or invalid data: u_mailing_adr2(SEVERE)"),

        u_claim_nbr (12, "Missing or invalid data: u_claim_nbr");


        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }
        public String getErrorMessage() {
            return errorMessage;
        }

    }

    public enum Subcategory {

        P1 ("P1", "Commercial/Detailed PRAs"),
        P2 ("P2", "Commercial/Virtual Card Payments and Info Only PRAs"),
        P3 ("P3", "Medicare/Detail PRAs"),
        P4 ("P4", "Medicare/Virtual Card Payments & Info Only"),
        P5 ("P5", "UHC West Payment Packages/Detailed Pmt Docs"),
        P6 ("P6", "Community Plan/PRAs"),
        P7 ("P7", "Community Plan/Virtual Card Payments"),
        P8 ("P8", "Commercial/Zero-Dollar PRAs"),
        P9 ("P9", "Medicare/Zero-Dollar PRAs"),
        P0 ("P0", "Community Plan/Zero-Dollar PRAs"),
        E1 ("E1", "Other/Zero-Dollar PRAs"),
        E2 ("E2", "Student Resources/Detailed PRAs"),
        E3 ("E3", "Student Resources/Virtual Card Payments"),
        E4 ("E4", "Student Resources/Zero Dollar PRAs"),
        PR ("PR", "Other PRAs/Other");

        private String subCat;
        private String filePath;

        Subcategory(String subCat, String filePath){
            this.subCat = subCat;
            this.filePath = filePath;
        }
        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }
}

