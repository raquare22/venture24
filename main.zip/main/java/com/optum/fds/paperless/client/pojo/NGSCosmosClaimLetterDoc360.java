package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

import java.io.Serial;

import static com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil.normalizePipeDelimitedValue;


@JsonIgnoreProperties(ignoreUnknown = true)
public class NGSCosmosClaimLetterDoc360 extends ClientMetadata {

    @Serial
    private static final long serialVersionUID = -3847162894472819356L;




    @JsonProperty("ngsId")
    @JsonAlias("u_document_id")
    private String ngsId;

    @JsonProperty("subCategory")
    @JsonAlias("u_div")
    private String subCategory;

    @JsonProperty("tin")
    @JsonAlias({"u_tin"})
    private String tin;

    @JsonProperty("mpin")
    @JsonAlias({"u_mpin"})
    private String mpin = "";

    @JsonProperty("npi")
    @JsonAlias({"u_npi"})
    private String npi;

    @JsonProperty("providerName")
    @JsonAlias("u_prov_nm")
    private String providerName;

    @JsonProperty("memberName")
    @JsonAlias({"u_mbr_nm"})
    private String memberName;

    @JsonProperty("patientDOB")
    @JsonAlias({"u_mbr_dob_dt"})
    private String patientDOB;

    @JsonProperty("policyNumber")
    @JsonAlias({"u_pol_nbr"})
    private String policyNumber;

    @JsonProperty("dateOfService")
    @JsonAlias({"u_dos_dt"})
    private String dateOfService;

    @JsonProperty("emailAlertReq")
    @JsonAlias("u_is_print_suppressed")
    private String emailAlertReq = "Y";

    @JsonProperty("originalPrintTrail")
    @JsonAlias({"u_trl_id"})
    private String originalPrintTrail;

    @JsonProperty("PassThruData")
    @JsonAlias("u_pass_thru_data")
    private String PassThruData;

    @JsonProperty("ConfigKey")
    @JsonAlias({"u_config_key"})
    private String CONFIGKEY;

    @JsonProperty("MailToAddress1")
    @JsonAlias("u_mail_to_adr1")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    @JsonAlias("u_mail_to_adr2")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    @JsonAlias("u_mail_to_adr3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    @JsonAlias("u_mail_to_adr4")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    @JsonAlias("u_mail_to_adr5")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    @JsonAlias("u_mail_to_adr6")
    private String MailToAddress6;

    @JsonProperty("claimNumber")
    @JsonAlias({"u_clm_nbr"})
    private String claimNumber;

    @JsonProperty("memberId")
    @JsonAlias({"u_mbr_id"})
    private String memberId;

    @JsonProperty("patientAccountNumber")
    @JsonAlias({"u_ptnt_acct_nbr"})
    private String patientAccountNumber;

    public NGSCosmosClaimLetterDoc360() {
        this.category = "Claim";
        this.fileDescription = "Claim Letter";
        this.fileType = "Letter";
        this.privilege = "Claim Status";
        this.tenant = "Link";
        this.createApplication = "NGS";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        setSubCategory("RR");
    }


    public String getNgsId() {
        return ngsId;
    }

    public void setNgsId(String ngsId) {
        this.ngsId = ngsId;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public final void setSubCategory(String subCategory) {
        Subcategory subCat;
        try {
            subCat = Subcategory.valueOf(subCategory);
            this.subCategory = subCategory;
        } catch (Exception e) {
            subCat = Subcategory.RR;
            this.subCategory = "RR";
        }
        this.setFilePath(subCat.getFilePath());
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        if (mpin != null) {
            this.mpin = mpin;
        }
    }

    public String getNpi() {
        return npi;
    }

    public void setNpi(String npi) {
        this.npi = npi;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getPatientDOB() {
        return patientDOB;
    }

    public void setPatientDOB(String patientDOB) {
        this.patientDOB = patientDOB;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getDateOfService() {
        return dateOfService;
    }

    public void setDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()) {
            this.emailAlertReq = emailAlertReq;
        }
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String passThruData) {
        PassThruData = passThruData;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String configKey) {
        CONFIGKEY = configKey;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String mailToAddress1) {
        MailToAddress1 = mailToAddress1;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String mailToAddress2) {
        MailToAddress2 = mailToAddress2;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String mailToAddress3) {
        MailToAddress3 = mailToAddress3;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String mailToAddress4) {
        MailToAddress4 = mailToAddress4;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String mailToAddress5) {
        MailToAddress5 = mailToAddress5;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String mailToAddress6) {
        MailToAddress6 = mailToAddress6;
    }

    public String getClaimNumber() {
        return claimNumber;
    }

    public void setClaimNumber(Object raw) {
        this.claimNumber = normalizePipeDelimitedValue(raw);
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(Object raw) {
        this.memberId = normalizePipeDelimitedValue(raw);
    }

    public String getPatientAccountNumber() {
        return patientAccountNumber;
    }

    public void setPatientAccountNumber(Object raw) {
        this.patientAccountNumber = normalizePipeDelimitedValue(raw);
    }

    @Override
    public void setCorporateMpin(String value) {
        if (value != null) {
            String trimmed = value.trim();
            if (!trimmed.isEmpty()) {
                super.setCorporateMpin(trimmed);
            } else {
                super.setCorporateMpin(null);
            }
        } else {
            super.setCorporateMpin(null);
        }
    }

    public enum ErrorMsg implements ErrorMessage {
        u_div(12, "Missing or invalid data: u_div"),
        u_tin(12, "Missing or invalid data: u_tin"),
        u_mpin(12, "Missing or invalid data: u_mpin"),
        u_npi(12, "Missing or invalid data: u_npi"),
        u_is_print_suppressed(12, "Missing or invalid data: u_is_print_suppressed"),
        u_mbr_id(12, "Missing or invalid data: u_mbr_id"),
        u_ptnt_acct_nbr(12, "Missing or invalid data: u_ptnt_acct_nbr"),
        u_clm_nbr(12, "Missing or invalid data: u_clm_nbr"),
        u_prov_nm(12, "Missing or invalid data: u_prov_nm"),
        u_orig_creation_date(12, "Missing or invalid data: u_orig_creation_date"),
        u_pass_thru_data(22, "Missing or invalid data: u_pass_thru_data(SEVERE)"),
        u_trl_id(22, "Missing or invalid data: u_trl_id(SEVERE)"),
        u_config_key(22, "Missing or invalid data: u_config_key(SEVERE)"),
        u_mail_to_adr1(22, "Missing or invalid data: u_mail_to_adr1(SEVERE)"),
        u_mail_to_adr2(22, "Missing or invalid data: u_mail_to_adr2(SEVERE)"),
        u_mail_to_adr4(22, "Missing or invalid data: u_mail_to_adr4(SEVERE)");

        private final int errorCode;
        private final String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        @Override
        public int getErrorCode() {
            return errorCode;
        }

        @Override
        public String getErrorMessage() {
            return errorMessage;
        }
    }

    public enum Subcategory {
        R1("R1", "Medicare/Action Required"),
        R2("R2", "Medicare/Claim Reconsideration"),
        R3("R3", "Medicare/Balance Billing"),
        R7("R7", "Medicare/Denials"),
        R8("R8", "Medicare/Approvals"),
        R9("R9", "Medicare/Please Review (FYI)"),
        R0("R0", "Medicare/Copy of Member Letters"),
        RR("RR", "Medicare/Other");

        private final String subCat;
        private final String filePath;

        Subcategory(String subCat, String filePath) {
            this.subCat = subCat;
            this.filePath = filePath;
        }

        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }
}
