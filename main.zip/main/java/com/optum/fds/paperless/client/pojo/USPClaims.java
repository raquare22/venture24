package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;
import org.apache.commons.lang3.StringUtils;

public class USPClaims extends ClientMetadata {


    @JsonProperty("LETTERTYPE")
    private String subCategory;

    @JsonProperty("PROVIDERTAXID")
    private String tin;

    @JsonProperty("IndivProvMPIN")
    private String mpin;

    @JsonProperty("isPrintSuppressed")
    private String emailAlertReq;

    @JsonProperty("DATEOFSERVICE")
    private String dateOfService;

    @JsonProperty("POLICYNBR")
    private String policyNumber;

    @JsonProperty("PATIENTNAME")
    private String PatientName;

    @JsonProperty("PATDOB")
    private String patientDOB;

    @JsonProperty("ICNNUMBER")
    private String claimNumber;

    @JsonProperty("PHYSICIANNAME")
    private String providerName;

    @JsonProperty("EMPLOYEEID")
    private String memberId;

    @JsonProperty("EMPLOYEENAME")
    private String memberName;

    @JsonProperty("EmplAltId")
    private String MemberAltId;

    @JsonProperty("PassThruData")
    private String PassThruData;

    @JsonProperty("OriginPrintTrail")
    private String originalPrintTrail;

    @JsonProperty("ConfigKey")
    private String CONFIGKEY;

    @JsonProperty("MailToAddress1")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    private String MailToAddress6;

    @JsonProperty("RecipientID")
    private String recipientId;


    public USPClaims(){
        this.category = "Claim";
        this.fileType = "Letter";
        this.tenant = "Link";
        this.fileDescription = "";
        this.createApplication = "CIRRUS";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.privilege = "Claim Status";
        this.subCategory = "CC";
        Subcategory subCat =Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }


    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "CC";
            this.setFilePath(Subcategory.CC.getFilePath());
        } else {
            this.subCategory = subCategory;
            USPClaims.Subcategory subCat = null;
            try {
                subCat = USPClaims.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = USPClaims.Subcategory.CC;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getMpin() {
        return mpin;
    }
    
    public void setMpin(String mpin) {
        if (mpin != null && !mpin.isEmpty()) {
            String paddedMpin = StringUtils.leftPad(mpin, 9, '0');
            this.mpin = paddedMpin;
        }
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }
    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()){
            this.emailAlertReq = emailAlertReq;
        }
    }

    public String getDateOfService() {
        return dateOfService;
    }

    public void setDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getPatientName() {
        return PatientName;
    }

    public void setPatientName(String patientName) {
        PatientName = patientName;
    }

    public String getPatientDOB() {
        return patientDOB;
    }

    public void setPatientDOB(String patientDOB) {
        this.patientDOB = patientDOB;
    }

    public String getClaimNumber() {
        return claimNumber;
    }

    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberAltId() {
        return MemberAltId;
    }

    public void setMemberAltId(String memberAltId) {
    	this.MemberAltId = memberAltId;
    }

    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String passThruData) {
    	this.PassThruData = passThruData;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String CONFIGKEY) {
        this.CONFIGKEY = CONFIGKEY;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String mailToAddress1) {
    	this.MailToAddress1 = mailToAddress1;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String mailToAddress2) {
    	this.MailToAddress2 = mailToAddress2;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String mailToAddress3) {
    	this.MailToAddress3 = mailToAddress3;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String mailToAddress4) {
    	this.MailToAddress4 = mailToAddress4;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String mailToAddress5) {
        this.MailToAddress5 = mailToAddress5;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String mailToAddress6) {
        this.MailToAddress6 = mailToAddress6;
    }

    public String getRecipientId() { return recipientId; }

    public void setRecipientId(String recipientId) { this.recipientId = recipientId; }

    public enum ErrorMsg implements ErrorMessage {

        PROVIDERTAXID (12, "Missing or invalid data: Provider TIN"),
        IndivProvMPIN (12, "Missing or invalid data: Provider MPIN"),
        LETTERTYPE (12, "Missing or invalid data: subCategory"),
        isPrintSuppressed (12,"Missing or invalid data: isPrintSuppressed"),
        PROCESSDATE (12, "Missing or invalid data: CreateDate"),
        DATEOFSERVICE(12, "Missing or invalid data:  Date of Service"),
        ICNNUMBER(12,"Missing or invalid data: Claim Number"),
        SUBJECT(12, "Missing or invalid data: Subject"),
        RecipientID(12, "Missing or invalid data: Recipient ID"),

        ConfigKey (22, "Missing or invalid data: CONFIGKEY(SEVERE)"),
        OriginPrintTrail (22, "Missing or invalid data: OriginalPrintTrail(SEVERE)"),
        PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"),
        MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"),
        MailToAddress2 (22, "Missing or invalid data: MailToAddress2(SEVERE)"),
        MailToAddress4 (22, "Missing or invalid data: MailToAddress4(SEVERE)");

        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }
        public String getErrorMessage() {
            return errorMessage;
        }
    }

    public enum Subcategory {
        // USP Claims
        C1 ("C1", "Commercial/Action Required"),
        C2 ("C2", "Commercial/Claim Receipt Acknowledgement"),
        C3 ("C3", "Commercial/Denials"),
        C4 ("C4", "Commercial/Please Review (FYI)"),
        C6 ("C6", "Commercial/Claim Reconsideration Upheld"),
        C7 ("C7", "Commercial/Therapy Approvals"),
        C8 ("C8", "Commercial/Copy of Member Letters"),
        CC ("CC", "Commercial/Other");

        private String subCat;
        private String filePath;

        Subcategory(String subCat, String filePath){
            this.subCat = subCat;
            this.filePath = filePath;
        }
        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }
}
