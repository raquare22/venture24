package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.CustomDateDeserializer;
import com.optum.fds.paperless.client.CustomDateSerializer;
import com.optum.fds.paperless.client.CustomizeDateDeserializer;
import com.optum.fds.paperless.client.ErrorMessage;
import org.apache.commons.lang.StringUtils;
import java.util.Date;

public class UNET extends ClientMetadata {

	private static final long serialVersionUID = -2745167202889686149L;

	@JsonProperty("ICNNUMBER")
	@JsonAlias("claimNumber")
	private String claimNumber;

	@JsonProperty("LETTERTYPE")
	@JsonAlias("subCategory")
	private String subCategory;

	@JsonProperty("PROVIDERTAXID")
	@JsonAlias("tin")
	private String tin;

	@JsonProperty("tinSuff")
	private String tinSuff;

	@JsonProperty("EmplAltId")
	@JsonAlias("MemberAltID")
	private String MemberAltID;

	@JsonProperty("isPrintSuppressed")
	@JsonAlias("emailAlertReq")
	private String emailAlertReq="Y";

	@JsonProperty("PHYSICIANNAME")
	@JsonAlias("providerName")
	private String providerName;

	@JsonProperty("POLICYNBR")
	@JsonAlias("policyNumber")
	private String policyNumber;

	@JsonProperty("EMPLOYEENAME")
	@JsonAlias("memberName")
	private String memberName;

	@JsonProperty("DATEOFSERVICE")
	@JsonAlias("dateOfService")
	@JsonDeserialize(using = CustomizeDateDeserializer.class)
	@CustomDateFormat(dateFormat = "MM/dd/yyyy")
	private Date dateOfService;

	@JsonProperty("PATIENTNAME")
	@JsonAlias("PatientName")
	private String PatientName;

	@JsonProperty("PATDOB")
	@JsonAlias("patientDOB")
	private String patientDOB;
	
	@JsonProperty("PatNbr")
	@JsonAlias("patientAccountNumber")
	private String patientAccountNumber;

	@JsonProperty("ProvNPI")
	@JsonAlias("npi")
	private String npi;

	@JsonProperty("IndivProvMPIN")
	@JsonAlias("mpin")
	private String mpin="";

	@JsonProperty("EMPLOYEEID")
	@JsonAlias("memberId")
	private String memberId;

	@JsonProperty("ELGSLETTERGENID")
	private String ELGSLETTERGENID;

	@JsonProperty("DefaultUsed")
	private String DefaultUsed;

	@JsonProperty("PassThruData")
	private String PassThruData;

	@JsonProperty("HistoryID")
	@JsonAlias("LetterHistoryID")
	private String LetterHistoryID;

	@JsonProperty("OriginPrintTrail")
	@JsonAlias("originalPrintTrail")
	private String originalPrintTrail;

	@JsonProperty("ConfigKey")
	@JsonAlias("CONFIGKEY")
	private String CONFIGKEY;

	@JsonProperty("MailToAddress1")
	private String MailToAddress1;

	@JsonProperty("MailToAddress2")
	private String MailToAddress2;

	@JsonProperty("MailToAddress3")
	private String MailToAddress3;

	@JsonProperty("MailToAddress4")
	private String MailToAddress4;

	@JsonProperty("MailToAddress5")
	private String MailToAddress5;

	@JsonProperty("MailToAddress6")
	private String MailToAddress6;

	@JsonProperty("providerId")
	private String providerId;

	public UNET(){
		
		
		this.fileType = "Letter";
		this.tenant = "Link";
		this.createApplication = "ELGS";
		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.providerEmailId = "";
		this.postCardInd = true;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.privilege = "Claim Status";
		this.providerId = "ELGS";
		this.subCategory = "CC";
		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}

	public String getTinSuff() {
		return tinSuff;
	}

	public void setTinSuff(String tinSuff) {
		this.tinSuff = tinSuff;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		if(subCategory == null || subCategory.isEmpty()){
			this.subCategory = "CC";
			this.setFilePath(Subcategory.CC.getFilePath());
			this.setCategory("Claim");
		} else {
			this.subCategory = subCategory;
			Subcategory subCat = null;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.CC;
			}
			if(subCategory.equalsIgnoreCase("C5"))
			{
				this.setCategory("Overpayment Documents");
			}
			else
				this.setCategory("Claim");

			
			this.setFilePath(subCat.getFilePath());
		}
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		if (tin.length() > 9) {
			this.tin = tin.substring(0, 9);
			this.tinSuff = tin.substring(9);
		} else {
			this.tin = tin;
		}
	}

	public String getMemberAltID() {
		return MemberAltID;
	}

	public void setMemberAltID(String memberAltID) {
		MemberAltID = memberAltID;
	}

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()){
			this.emailAlertReq = emailAlertReq;
		}
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public Date getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getPatientName() {
		return PatientName;
	}

	public void setPatientName(String patientName) {
		PatientName = patientName;
	}

	public String getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}
	
	private String getPatientAccountNumber() {
		return patientAccountNumber;
	}

	private void setPatientAccountNumber(String patientAccountNumber) {
		this.patientAccountNumber = patientAccountNumber;
	}

	public String getNpi() {
		return npi;
	}
	
	public void setNpi(String npi) {
		this.npi = npi;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		if (mpin != null && !mpin.isEmpty()) {
			String paddedMpin = StringUtils.leftPad(mpin, 9, '0');
			this.mpin = paddedMpin;
		}
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getELGSLETTERGENID() {
		return ELGSLETTERGENID;
	}

	public void setELGSLETTERGENID(String ELGSLETTERGENID) {
		this.ELGSLETTERGENID = ELGSLETTERGENID;
	}

	public String getDefaultUsed() {
		return DefaultUsed;
	}

	public void setDefaultUsed(String defaultUsed) {
		DefaultUsed = defaultUsed;
	}

	public String getPassThruData() {
		return PassThruData;
	}

	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}

	public String getLetterHistoryID() {
		return LetterHistoryID;
	}

	public void setLetterHistoryID(String letterHistoryID) {
		LetterHistoryID = letterHistoryID;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getCONFIGKEY() {
		return CONFIGKEY;
	}

	public void setCONFIGKEY(String CONFIGKEY) {
		this.CONFIGKEY = CONFIGKEY;
	}

	public String getMailToAddress1() {
		return MailToAddress1;
	}

	public void setMailToAddress1(String mailToAddress1) {
		MailToAddress1 = mailToAddress1;
	}

	public String getMailToAddress2() {
		return MailToAddress2;
	}

	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}

	public String getMailToAddress3() {
		return MailToAddress3;
	}

	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}

	public String getMailToAddress4() {
		return MailToAddress4;
	}

	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}

	public String getMailToAddress5() {
		return MailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return MailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

	public enum ErrorMsg implements ErrorMessage {
		SUBJECT (12, "Missing or invalid data: SUBJECT"),
		PROCESSDATE (12, "Missing or invalid data: PROCESSDATE"),
		ICNNUMBER (12, "Missing or invalid data: ICNNUMBER"),
		LETTERTYPE (12,"Missing or invalid data: LETTERTYPE"),
		PROVIDERTAXID (12, "Missing or invalid data: PROVIDERTAXID"),
		isPrintSuppressed (12, "Missing or invalid data: isPrintSuppressed"),
		DATEOFSERVICE (12, "Missing or invalid data: DATEOFSERVICE"),
		IndivProvMPIN (12, "Missing or invalid data: IndivProvMPIN"), // "emailAlertReq!=\"N\""

		PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"), // "emailAlertReq!=\"N\""
		HistoryID (22, "Missing or invalid data: HistoryID(SEVERE)"), //  "emailAlertReq!=\"N\""
		OriginPrintTrail (22, "Missing or invalid data: OriginPrintTrail(SEVERE)"), // "emailAlertReq!=\"N\""
		MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"), // "emailAlertReq!=\"N\""
		MailToAddress2 (22, "Missing or invalid data: MailToAddress2(SEVERE)"), // "emailAlertReq!=\"N\""
		MailToAddress4 (22, "Missing or invalid data: MailToAddress4(SEVERE)"), // "emailAlertReq!=\"N\""
		MailToAddress5 (22, "Missing or invalid data: MailToAddress5(SEVERE)"), // "emailAlertReq!=\"N\""
		MailToAddress6 (22, "Missing or invalid data: MailToAddress6(SEVERE)"); // "emailAlertReq!=\"N\""

		private int errorCode;
		private String errorMessage;

		ErrorMsg(int code, String message) {
			this.errorCode = code;
			this.errorMessage = message;
		}

		public int getErrorCode() {
			return errorCode;
		}
		public String getErrorMessage() {
			return errorMessage;
		}

	}

	public enum Subcategory {

		// UNET (ELGS)
		C1 ("C1", "Commercial/Action Required"),
		C2 ("C2", "Commercial/Claim Receipt Acknowledgement"),
		C3 ("C3", "Commercial/Denials"),
		C4 ("C4", "Commercial/Please Review (FYI)"),
		C5 ("C5", "Commercial Overpayment Letters/Overpayment Identified"),
		C6 ("C6", "Commercial/Claim Reconsideration"),
		C7 ("C7", "Commercial/Approvals"),
		C8 ("C8", "Commercial/Copy of Member Letters"),
		CC ("CC", "Commercial/Other");

		private String subCat;
		private String filePath;

		Subcategory(String subCat, String filePath){
			this.subCat = subCat;
			this.filePath = filePath;
			
		}
		public String getSubCat() {
			return subCat;
		}

		public String getFilePath() {
			return filePath;
		}
		
	}
}
