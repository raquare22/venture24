package com.optum.fds.paperless.client.pojo;


import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

public class UNETPRA extends ClientMetadata {
	
	private static final long serialVersionUID = 2458995411009671654L;
	
	@JsonProperty("tin")
	@JsonAlias("ProviderTAXID")
	private String tin;
	
	@JsonProperty("mpin")
	@JsonAlias("IndivProviderMPIN")
	private String mpin="";
	
	@JsonProperty("emailAlertReq")
	@JsonAlias("IsPrintSuppressed")
	private String emailAlertReq="Y";
	
	@JsonProperty("EFT_Ind")
	private String EFT_Ind;

	@JsonProperty("835_Ind")
	private String Ind_835;

	@JsonProperty("physicianName")
	@JsonAlias("PHYSICIANNAME")
	private String physicianName;
	
	@JsonProperty("CheckTraceNumber")
	private String CheckTraceNumber;
	
	@JsonProperty("multClaimNumber")
	@JsonAlias("ICNNUMBER")
	private String multClaimNumber;
	
	@JsonProperty("memberId")
	@JsonAlias("MemberID")
	private String memberId;
	
	@JsonProperty("DefaultUsed")
	private String DefaultUsed;
	
	@JsonProperty("CheckAmt")
	private String CheckAmt;
	
	@JsonProperty("CONFIGKEY")
	private String CONFIGKEY;
	
	@JsonProperty("originalPrintTrail")
	private String originalPrintTrail;
	
	@JsonProperty("PassThruData")
	private String PassThruData;
	
	@JsonProperty("MailToAddress1") 
	private String MailToAddress1;
	
	@JsonProperty("MailToAddress2") 
	private String MailToAddress2;
	
	@JsonProperty("MailToAddress3") 
	private String MailToAddress3;
	
	@JsonProperty("MailToAddress4") 
	private String MailToAddress4;
	
	@JsonProperty("MailToAddress5") 
	private String MailToAddress5;
	
	@JsonProperty("MailToAddress6") 
	private String MailToAddress6;
	
	@JsonProperty("LETTERTYPE")
//	@JsonAlias("LETTERTYPE")
	protected String subCategory;
	
	@JsonProperty("NPI")
	@JsonAlias("BillingNPI")
	private String NPI;
	
	@JsonProperty("paymentNumber")
	@JsonAlias("vendor_pay_id")
	private String paymentNumber;
	
	public UNETPRA() {
		this.category = "Payment Document";
		this.fileType = "Letter";
		this.tenant = "Link";
		this.fileDescription = "Provider Remittance Advice";
		this.createApplication = "PmntEng";
		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.providerEmailId = "";
		this.postCardInd = true;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.privilege = "Claim Status";
		this.subCategory = "PR";
		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		if (mpin != null){
			this.mpin = mpin;
		}
	}

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()){
			this.emailAlertReq = emailAlertReq;
		}
	}

	public String getEFT_Ind() {
		return EFT_Ind;
	}

	public void setEFT_Ind(String eFT_Ind) {
		EFT_Ind = eFT_Ind;
	}

	public String getPhysicianName() {
		return physicianName;
	}

	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}

	public String getCheckTraceNumber() {
		return CheckTraceNumber;
	}

	public void setCheckTraceNumber(String checkTraceNumber) {
		CheckTraceNumber = checkTraceNumber;
	}

	public String getMultClaimNumber() {
		return multClaimNumber;
	}

	public void setMultClaimNumber(String multClaimNumber) {
		this.multClaimNumber = multClaimNumber;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getDefaultUsed() {
		return DefaultUsed;
	}

	public void setDefaultUsed(String defaultUsed) {
		DefaultUsed = defaultUsed;
	}

	public String getCheckAmt() {
		return CheckAmt;
	}

	public void setCheckAmt(String checkAmt) {
		CheckAmt = checkAmt;
	}

	public String getCONFIGKEY() {
		return CONFIGKEY;
	}

	public void setCONFIGKEY(String cONFIGKEY) {
		CONFIGKEY = cONFIGKEY;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getPassThruData() {
		return PassThruData;
	}

	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}

	public String getMailToAddress1() {
		return MailToAddress1;
	}

	public void setMailToAddress1(String mailToAddress1) {
		MailToAddress1 = mailToAddress1;
	}

	public String getMailToAddress2() {
		return MailToAddress2;
	}

	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}

	public String getMailToAddress3() {
		return MailToAddress3;
	}

	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}

	public String getMailToAddress4() {
		return MailToAddress4;
	}

	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}

	public String getMailToAddress5() {
		return MailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return MailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}
	
	public String getInd_835() {
		return Ind_835;
	}

	public void setInd_835(String ind_835) {
		Ind_835 = ind_835;
	}

	public String getSubCategory() {
		return subCategory;
	}
	
	public String getNPI() {
		return NPI;
	}
	
	public String getPaymentNumber() {
		return paymentNumber;
	}
	
	public void setPaymentNumber(String paymentNumber) {
		this.paymentNumber = paymentNumber;
	}
	
	public void setSubCategory(String subCategory) {
		if(subCategory == null || subCategory.isEmpty()){
			this.subCategory = "PR";
			this.setFilePath(Subcategory.PR.getFilePath());
		} else {
			this.subCategory = subCategory;
			Subcategory subCat = null;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.PR;
			}
			this.setFilePath(subCat.getFilePath());
		}
		
		if(this.getExpiryDate() != null && this.getExpiryDate().length() == 7){
			this.setExpiryDate(this.vcpExpiryDateFormat(this.getExpiryDate(), this.subCategory));}
	}
	
	
	public enum ErrorMsg implements ErrorMessage {
		ProviderTAXID_12 (12, "Missing or invalid data: ProviderTAXID"), // can be 12 or 22??
		// err 12: EFT_Ind==\"Y\" && emailAlertReq==\"N\" || EFT_Ind==\"N\" && emailAlertReq==\"Y\" || EFT_Ind==\"N\" && emailAlertReq==\"N\"		
		ProviderTAXID_22 (22, "Missing or invalid data: ProviderTAXID(SEVERE)"), // can be 12 or 22??
		//err 22: EFT_Ind==\"Y\" && emailAlertReq==\"Y\"
		
		IndivProviderMPIN (12, "Missing or invalid data: IndivProviderMPIN"),
		LETTERTYPE (12, "Missing or invalid data: LETTERTYPE"),
		IsPrintSuppressed (12,"Missing or invalid data: isPrintSuppressed"),
		PROCESSDATE (12, "Missing or invalid data: PROCESSDATE"),
		
		CONFIGKEY (22, "Missing or invalid data: CONFIGKEY(SEVERE)"), // "EFT_Ind==\"N\" && emailAlertReq==\"Y\"
		originalPrintTrail (22, "Missing or invalid data: originalPrintTrail(SEVERE)"), // "EFT_Ind==\"N\" && emailAlertReq==\"Y\"
		PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"), // "EFT_Ind==\"N\" && emailAlertReq==\"Y\"

		MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"), // "EFT_Ind==\"N\" && emailAlertReq==\"Y\"
		MailToAddress3 (22, "Missing or invalid data: MailToAddress3(SEVERE)"), // "EFT_Ind==\"N\" && emailAlertReq==\"Y\"
		
		CheckTraceNumber (12, "Missing or invalid data: CheckTraceNumber"),
		EFT_Ind (22, "Missing or invalid data: EFT_Ind(SEVERE)"),
		ICNNUMBER (12, "Missing or invalid data: ICNNUMBER");
		
		
		private int errorCode;
	    private String errorMessage;

	    ErrorMsg(int code, String message) {
	        this.errorCode = code;
	        this.errorMessage = message;
	    }

	    public int getErrorCode() {
	        return errorCode;
	    }
	    public String getErrorMessage() {
	        return errorMessage;
	    }

	}
	
	public enum Subcategory {
		
		P1 ("P1", "Commercial/Detailed PRAs"),
		P2 ("P2", "Commercial/Virtual Card Payments and Info Only PRAs"),
		P8 ("P8", "Commercial/Zero-Dollar PRAs"),
		P9 ("P9", "Medicare/Zero-Dollar PRAs"),
		P0 ("P0", "Community Plan/Zero-Dollar PRAs"),
		E1 ("E1", "Other/Zero-Dollar PRAs"),
		PR ("PR", "Other PRAs/Other");
		
		private String subCat;
		private String filePath;
		
		Subcategory(String subCat, String filePath){
			this.subCat = subCat;
			this.filePath = filePath;
		}
		public String getSubCat() {
	        return subCat;
	    }
		
		public String getFilePath() {
			return filePath;
		}
	}
	
}

