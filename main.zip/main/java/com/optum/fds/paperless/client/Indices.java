package com.optum.fds.paperless.client;

import java.util.List;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;


public class Indices {
	@JacksonXmlProperty(localName = "IndexField")
    @JacksonXmlElementWrapper(useWrapping = false)
	public List<IndexField> IndexField;
	
	public List<com.optum.fds.paperless.client.IndexField> getIndexField() {
		return IndexField;
	}

	public void setIndexField(List<com.optum.fds.paperless.client.IndexField> indexField) {
		IndexField = indexField;
	}
}
