package com.optum.fds.paperless.client.pojo;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

public class PECOSMOSPRA extends ClientMetadata {
	
	private static final long serialVersionUID = -797273316412247183L;
	
	@JsonProperty("TIN")
	@JsonAlias("tin")
	private String tin;

	@JsonProperty("ProviderMPIN")
	@JsonAlias("mpin")
	private String mpin="";
	
	@JsonProperty("isPrintSuppressed")
	@JsonAlias("emailAlertReq")
	private String emailAlertReq="Y";
	
	@JsonProperty("CHECKNUMBER")
	@JsonAlias("CheckTraceNumber")
	private String CheckTraceNumber;
	
	@JsonProperty("PHYSICIANNAME")
	@JsonAlias("providerName")
	private String providerName;

	@JsonProperty("EFT_Ind")
	private String EFT_Ind;
	
	@JsonProperty("835_Ind")
	@JsonAlias("ind_835")
	private String ind_835;
	
	@JsonProperty("DIV")
	private String DIV;
	
	@JsonProperty("CLAIMNUMBER")
	@JsonAlias("multClaimNumber")
	private String multClaimNumber;

	@JsonProperty("MemberID")
	@JsonAlias("multMemberId")
	private String multMemberId;

	@JsonProperty("DefaultUsed")
	private String DefaultUsed;
	
	@JsonProperty("CheckAmt")
	private String CheckAmt;
	
	@JsonProperty("CONFIGKEY")
	private String CONFIGKEY;
	
	@JsonProperty("originalPrintTrail")
	private String originalPrintTrail;
	
	@JsonProperty("PassThruData")
	private String PassThruData;
	
	@JsonProperty("MailToAddress1") 
	private String MailToAddress1;
	
	@JsonProperty("MailToAddress2") 
	private String MailToAddress2;

	@JsonProperty("MailToAddress3")
	private String MailToAddress3;
	
	@JsonProperty("MailToAddress4") 
	private String MailToAddress4;

	@JsonProperty("MailToAddress5")
	private String MailToAddress5;

	@JsonProperty("MailToAddress6")
	private String MailToAddress6;

	@JsonProperty("patientAcountNumber") 
	private String patientAcountNumber;
	
	@JsonAlias("subCategory")
	@JsonProperty("SubCategory")
	protected String subCategory;

	@JsonAlias("billingNPI")
	@JsonProperty("npi")
	protected String npi;
	

	public PECOSMOSPRA() {
		this.tenant = "Link";
		this.category = "Payment Document";
		this.fileDescription = "Payment Document";
		this.fileType = "Letter";
		this.privilege = "Claim Status";
		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.providerEmailId = "";
		this.postCardInd = true;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.subCategory = "PR";
		this.createApplication = "CheckWrite";
		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		if (mpin != null) {
			this.mpin = mpin;
		}
	}

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()){
			this.emailAlertReq = emailAlertReq;
		}
	}
	
	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getEFT_Ind() {
		return EFT_Ind;
	}

	public void setEFT_Ind(String eFT_Ind) {
		EFT_Ind = eFT_Ind;
	}

	public String getInd_835() {
		return ind_835;
	}

	public void setInd_835(String ind_835) {
		this.ind_835 = ind_835;
	}

	public String getDIV() {
		return DIV;
	}

	public void setDIV(String dIV) {
		DIV = dIV;
	}

	public String getMultClaimNumber() {
		return multClaimNumber;
	}

	public void setMultClaimNumber(String multClaimNumber) {
		this.multClaimNumber = multClaimNumber;
	}

	public String getDefaultUsed() {
		return DefaultUsed;
	}

	public void setDefaultUsed(String defaultUsed) {
		DefaultUsed = defaultUsed;
	}

	public String getCheckAmt() {
		return CheckAmt;
	}

	public void setCheckAmt(String checkAmt) {
		CheckAmt = checkAmt;
	}

	public String getCONFIGKEY() {
		return CONFIGKEY;
	}

	public void setCONFIGKEY(String cONFIGKEY) {
		CONFIGKEY = cONFIGKEY;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getPassThruData() {
		return PassThruData;
	}

	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}

	public String getMailToAddress1() {
		return MailToAddress1;
	}

	public void setMailToAddress1(String mailToAddress1) {
		MailToAddress1 = mailToAddress1;
	}

	public String getMailToAddress2() {
		return MailToAddress2;
	}

	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}

	public String getMailToAddress3() {
		return MailToAddress3;
	}

	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}

	public String getMailToAddress4() {
		return MailToAddress4;
	}

	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}

	public String getMailToAddress5() {
		return MailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return MailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public String getNpi() {
		return npi;
	}

	public void setNpi(String npi) {
		this.npi = npi;
	}
	
	public String getMultMemberId() {
		return multMemberId;
	}

	public void setMultMemberId(String multMemberId) {
		this.multMemberId = multMemberId;
	}
	
	public String getPatientAcountNumber() {
		return patientAcountNumber;
	}

	public void setPatientAcountNumber(String patientAcountNumber) {
		this.patientAcountNumber = patientAcountNumber;
	}
	
	public void setSubCategory(String subCategory) {
		if(subCategory == null || subCategory.isEmpty()){
			this.subCategory = "PR";
			this.setFilePath(Subcategory.PR.getFilePath());
		} else {
			this.subCategory = subCategory;
			Subcategory subCat = null;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.PR;
			}
			this.setFilePath(subCat.getFilePath());
		}
		
		if(this.getExpiryDate() != null && this.getExpiryDate().length() == 7){
			this.setExpiryDate(this.vcpExpiryDateFormat(this.getExpiryDate(), this.subCategory));}

	}
	
	public String getCheckTraceNumber() {
		return CheckTraceNumber;
	}

	public void setCheckTraceNumber(String checkTraceNumber) {
		CheckTraceNumber = checkTraceNumber;
	}

	public enum ErrorMsg implements ErrorMessage {
		TIN (12, "Missing or invalid data: TIN"), // EFT_Ind==\"Y\"
		ProviderMPIN (12, "Missing or invalid data: ProviderMPIN"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
		SubCategory (12, "Missing or invalid data: SubCategory"), // EFT_Ind==\"N\"
		isPrintSuppressed (12,"Missing or invalid data: isPrintSuppressed"),
		CHECKDATE (12, "Missing or invalid data: CHECKDATE"),
		
		CONFIGKEY (22, "Missing or invalid data: CONFIGKEY(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
		originalPrintTrail (22, "Missing or invalid data: originalPrintTrail(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
		PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"

		MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
		MailToAddress2 (22, "Missing or invalid data: MailToAddress2(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
		MailToAddress4 (22, "Missing or invalid data: MailToAddress4(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
		
		CHECKNUMBER (12, "Missing or invalid data: CHECKNUMBER"), // EFT_Ind==\"N\" && subCategory != \"P4\"
		EFT_Ind (22, "Missing or invalid data: EFT_Ind(SEVERE)"),
		CLAIMNUMBER (12, "Missing or invalid data: CLAIMNUMBER"),
		patientAcountNumber (12, "Missing or invalid data: patientAcountNumber");
		
		
		private int errorCode;
	    private String errorMessage;

	    ErrorMsg(int code, String message) {
	        this.errorCode = code;
	        this.errorMessage = message;
	    }

	    public int getErrorCode() {
	        return errorCode;
	    }
	    public String getErrorMessage() {
	        return errorMessage;
	    }

	}
	
	public enum Subcategory {
		P1 ("P1", "Commercial PRAs/Detail PRA"),
		P2 ("P2", "Commercial PRAs/Virtual Card Payment and Info Only PRAs"),
		P3 ("P3", "Medicare PRAs/Detail PRA"),
		P4 ("P4", "Medicare PRAs/Virtual Card Payment and Info Only PRAs"),
		P5 ("P5", "UHC West Payment Packages/Detailed Pmt Docs"),
		P6 ("P6", "Community Plans/PRA"),
		P7 ("P7", "Special Needs/PRAs"),
		PR ("PR", "Other PRAs/Other");
		
		private String subCat;
		private String filePath;
		
		Subcategory(String subCat, String filePath){
			this.subCat = subCat;
			this.filePath = filePath;
		}
		public String getSubCat() {
	        return subCat;
	    }
		
		public String getFilePath() {
			return filePath;
		}
	}
}

