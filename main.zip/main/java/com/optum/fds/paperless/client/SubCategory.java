package com.optum.fds.paperless.client;

public enum SubCategory {;

	private String subCat;
	private String filePath;

	SubCategory(String subCat, String filePath) {
		this.subCat = subCat;
		this.filePath = filePath;
	}

	public String getSubCat() {
		return subCat;
	}

	public String getFilePath() {
		return filePath;
	}

//	// COSMOS PRA (CheckWrite PRA)
//	P3 ("P3", "Medicare PRAs/Detail PRA"),
//	P4 ("P4", "Medicare PRAs/Info Only"),

	// UHCWest
//	P5 ("P5", "UHC West Payment Packages/Detailed Pmt Docs"),

	// CSP-PRA and UNET PRA 
//	P1 ("P1", "Commercial PRAs/Detail PRA"),
//	P2 ("P2", "Commercial PRAs/Info Only"),
//	P6 ("P6", "Community Plans/PRA"),
//	P7 ("P7", "Special Needs/PRA"),
//	PR ("PR", "Other PRAs/Other"),

//	// ODAR
//	C5 ("C5", "Commercial Overpayment Letters/Overpayment Identified"),
//	O1 ("O1", "Commercial Overpayment Letters/Overpayment Reconsideration Requests"),
//	O2 ("O2", "Commercial Overpayment Letters/Overpayment Reconsideration Responses"),
//	R4 ("R4", "Medicare Overpayment Letters/Overpayment Identified"),
//	R5 ("R5", "Medicare Overpayment Letters/Overpayment Reconsideration Requests"),
//	R6 ("R6", "Medicare Overpayment Letters/Overpayment Reconsideration Responses"),
//	S3 ("S3", "Community Plan Overpayment Letters/Overpayment Identified"),
//	S4 ("S4", "Community Plan Overpayment Letters/Overpayment Reconsideration Requests"),
//	S5 ("S5", "Community Plan Overpayment Letters/Overpayment Reconsideration Responses"),
//	W4 ("W4", "UHC West Overpayment Letters/Overpayment Identified"),
//	W5 ("W5", "UHC West Overpayment Letters/Overpayment Reconsideration Requests"),
//	W6 ("W6", "UHC West Overpayment Letters/Overpayment Reconsideration Responses"),
//	OP ("OP", "Other Overpayment Letters/Other Overpayment Letters"),

	// COSMOS and COSMOSDoc1
//	R1 ("R1", "Medicare Claim Letters/Additional Info Needed"),
//	R2 ("R2", "Medicare Claim Letters/Reconsideration"),
//	R3 ("R3", "Medicare Claim Letters/Balance Billing"),
//	R4 ("R4", "Medicare Claim Letters/Reimbursement Requests"),
//	R7 ("R7", "Medicare Claim Letters/ Initial Denial Letter"),
//	R8 ("R8", "Medicare Claim Letters/Post Payment Approval"),
//	R9 ("R9", "Medicare Claim Letters/Coding and Billing"),
//	R0 ("R0", "Medicare Claim Letters/Excluded from Readmission"),
//	RR ("RR", "Medicare Claim Letters/Other"),

	// UNET (ELGS)
//	C1 ("C1", "Commercial Claim Letters/Additional Info Needed"),
//	C2 ("C2", "Commercial Claim Letters/Acknowledgements"),
//	C3 ("C3", "Commercial Claim Letters/Medicaid - non-covered"),
//	C4 ("C4", "Commercial Claim Letters/Resubmit"),
//	C5 ("C5", "Commercial Claim Letters/Reimbursement Requests"),
//	C6 ("C6", "Commercial Claim Letters/Claims Recon Responses"),
//	C7 ("C7", "Commercial Claim Letters/Therapy Authorizations"),
//	CC ("CC", "Commercial Claim Letters/Other"),

	// PriorAuthCCSManual and PriorAuth1Click and PriorAuthNextGen
//	A1 ("A1", "Commercial Prior Auth/Approved"),
//	A2 ("A2", "Commercial Prior Auth/Denied"),
//	A3 ("A3", "Commercial Prior Auth/Lack of Information"),
//	A4 ("A4", "Medicare Prior Auth/Approved"),
//	A5 ("A5", "Medicare Prior Auth/Denied"),
//	A6 ("A6", "Medicare Prior Auth/Lack of Information"),
//	A7 ("A7", "UHC West Prior Auth/Approved"),
//	A8 ("A8", "UHC West Prior Auth/Denied"),
//	A9 ("A9", "UHC West Prior Auth/Lack of Information"),
//	N1 ("N1", "Medicaid Prior Auth/Approved"),
//	N2 ("N2", "Medicaid Prior Auth/Denied"),
//	N3 ("N3", "Medicaid Prior Auth/Lack of Information"),
//	ZZ ("ZZ", "Misc. Prior Auth/Other"),

	// MR Appeals
//	Y2 ("Y2", "Medicare Appeals and Disputes / Additional Information Needed (Rx)"),			
//	Y3 ("Y3", "Medicare  Appeals and Disputes / Resolution (Rx)"),		
//	Y4 ("Y4", "Medicare  Appeals and Disputes / Notification and Acknowledgement (Rx)"),		
//	Y5 ("Y5", "Special Needs Plan Appeals and Disputes / Additional Information Needed"),			
//	Y6 ("Y6", "Special Needs Plan Appeals and Disputes / Resolution"),
//	Y7 ("Y7", "Special Needs Plan Appeals and Disputes / Notification and Acknowledgement"),			
//	X5 ("X5", "Medicare Appeals and Disputes / Additional Information Needed"),		
//	X6 ("X6", "Medicare Appeals and Disputes / Resolution"),	
//	X7 ("X7", "Medicare Appeals and Disputes / Notification and Acknowledgement"),			
//	X8 ("X8", "UHCWest Appeals and Disputes / Additional Information Needed"),		
//	X9 ("X9", "UHCWest Appeals and Disputes / Resolution"),		
//	X0 ("X0", "UHCWest Appeals and Disputes / Notification and Acknowledgement"),

//	// ETS Appeals
//	X1 ("X1", "Commercial Appeals and Disputes / Acknowledgement, Notification, and Response"),
//	X2 ("X2", "Community Plan Appeals and Disputes / Acknowledgement, Notification, and Response"),
//	XX ("XX", "Other Appeals and Disputes / Other");

}