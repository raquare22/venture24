package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.CustomizeDateDeserializer;
import com.optum.fds.paperless.client.ErrorMessage;

import java.util.Date;

public class LetGen extends ClientMetadata {

	private static final long serialVersionUID = 4152993441800407752L;

	@JsonProperty("claimNumber")
	@JsonAlias("Claim Number")
	private String claimNumber;

	@JsonProperty("subCategory")
	@JsonAlias("Sub Category")
	private String subCategory;

	@JsonProperty("tin")
	@JsonAlias("ProviderTaxID")
	private String tin;

	@JsonProperty("mpin")
	@JsonAlias("Mpin")
	private String mpin="";

	@JsonProperty("memberId")
	@JsonAlias("Member ID")
	private String memberId;

	@JsonProperty("emailAlertReq")
	@JsonAlias("isPrintSuppressed")
	private String emailAlertReq="Y";

	@JsonProperty("physicianName")
	@JsonAlias("Provider Name")
	private String physicianName;

	@JsonProperty("policyNumber")
	@JsonAlias("Policy Number")
	private String policyNumber;

	@JsonProperty("dateOfService")
	@JsonAlias("DATEOFSERVICE")
	@JsonDeserialize(using = CustomizeDateDeserializer.class)
	@CustomDateFormat(dateFormat = "MMddyyyy") //11292017
	private Date dateOfService;

	@JsonProperty("memberName")
	@JsonAlias("Member Name")
	private String memberName;

	@JsonProperty("patientDOB")
	@JsonAlias("PATIENT DOB")
	private String patientDOB;

	@JsonProperty("PassThruData")
	private String PassThruData;

	@JsonProperty("originalPrintTrail")
	private String originalPrintTrail;

	@JsonProperty("CONFIGKEY")
	private String CONFIGKEY;

	@JsonProperty("MailToAddress1")
	private String MailToAddress1;

	@JsonProperty("MailToAddress2")
	private String MailToAddress2;

	@JsonProperty("MailToAddress3")
	private String MailToAddress3;

	@JsonProperty("MailToAddress4")
	private String MailToAddress4;

	@JsonProperty("MailToAddress5")
	private String MailToAddress5;

	@JsonProperty("MailToAddress6")
	private String MailToAddress6;

	@JsonProperty("patientAccountNumber")
	@JsonAlias("PatientAccountNumber")
	private String patientAccountNumber;

	public LetGen(){
		this.category = "Claim";
		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.postCardInd = true;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.privilege = "Claim Status";
		this.subCategory = "RR";
		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		if(subCategory == null || subCategory.isEmpty()){
			this.subCategory = "RR";
			this.setFilePath(Subcategory.RR.getFilePath());
		} else {
			this.subCategory = subCategory;
			Subcategory subCat = null;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.RR;
			}
			this.setFilePath(subCat.getFilePath());
		}
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		if (mpin != null){
			this.mpin = mpin;
		}
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()){
			this.emailAlertReq = emailAlertReq;
		}
	}

	public String getPhysicianName() {
		return physicianName;
	}

	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Date getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(Date dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getPassThruData() {
		return PassThruData;
	}

	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getCONFIGKEY() {
		return CONFIGKEY;
	}

	public void setCONFIGKEY(String CONFIGKEY) {
		this.CONFIGKEY = CONFIGKEY;
	}

	@Override
	public String getTenant() {
		return tenant;
	}

	@Override
	public void setTenant(String tenant) {
		this.tenant = tenant;
	}

	public String getMailToAddress1() {
		return MailToAddress1;
	}

	public void setMailToAddress1(String mailToAddress1) {
		MailToAddress1 = mailToAddress1;
	}

	public String getMailToAddress2() {
		return MailToAddress2;
	}

	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}

	public String getMailToAddress3() {
		return MailToAddress3;
	}

	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}

	public String getMailToAddress4() {
		return MailToAddress4;
	}

	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}

	public String getMailToAddress5() {
		return MailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return MailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}

	public String getPatientAccountNumber() {
		return patientAccountNumber;
	}

	public void setPatientAccountNumber(String patientAccountNumber) {
		this.patientAccountNumber = patientAccountNumber;
	}

	public enum ErrorMsg implements ErrorMessage {
		CreatingApp (12, "Missing or invalid data: CreatingApp"),
		Tenant (12, "Missing or invalid data: Tenant"),
		ClaimNumber (12, "Missing or invalid data: Claim Number"),
		FileType (12,"Missing or invalid data: FileType"),
		Category (12, "Missing or invalid data: Category"),
		ProviderTaxID (12, "Missing or invalid data: ProviderTaxID"),
		Mpin (12, "Missing or invalid data: Mpin"), // "emailAlertReq!=\"N\""
		isPrintSuppressed (12,"Missing or invalid data: isPrintSuppressed"),
		DATEOFSERVICE (12, "Missing or invalid data: DATEOFSERVICE"),

		PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"), // "emailAlertReq!=\"N\""
		originalPrintTrail (22, "Missing or invalid data: originalPrintTrail(SEVERE)"), // "emailAlertReq!=\"N\""
		CONFIGKEY (22, "Missing or invalid data: CONFIGKEY(SEVERE)"), // "emailAlertReq!=\"N\""
		MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"), // "emailAlertReq!=\"N\""
		MailToAddress2 (22, "Missing or invalid data: MailToAddress2(SEVERE)"), // "emailAlertReq!=\"N\""
		MailToAddress4 (22, "Missing or invalid data: MailToAddress4(SEVERE)"), // "emailAlertReq!=\"N\""
		MailToAddress5 (22, "Missing or invalid data: MailToAddress5(SEVERE)"), // "emailAlertReq!=\"N\""
		MailToAddress6 (22, "Missing or invalid data: MailToAddress6(SEVERE)"); // "emailAlertReq!=\"N\""

		private int errorCode;
		private String errorMessage;

		ErrorMsg(int code, String message) {
			this.errorCode = code;
			this.errorMessage = message;
		}

		public int getErrorCode() {
			return errorCode;
		}
		public String getErrorMessage() {
			return errorMessage;
		}

	}

	public enum Subcategory {

		// LetGen (COSMOS)
		R1 ("R1", "Medicare/Action Required"),
		R2 ("R2", "Medicare/Claim Reconsideration Upheld"),
		R3 ("R3", "Medicare/Informational"),
		R4 ("R4", "Medicare/Reimbursement Requests"),
		R7 ("R7", "Medicare/Denials"),
		R8 ("R8", "Medicare/Claim Receipt Acknowledgement"),
		R9 ("R9", "Medicare/Therapy Approvals"),
		R0 ("R0", "Medicare/Copy of Member Letters"),
		RR ("RR", "Medicare/Other");

		private String subCat;
		private String filePath;

		Subcategory(String subCat, String filePath){
			this.subCat = subCat;
			this.filePath = filePath;
		}
		public String getSubCat() {
			return subCat;
		}

		public String getFilePath() {
			return filePath;
		}
	}
}
