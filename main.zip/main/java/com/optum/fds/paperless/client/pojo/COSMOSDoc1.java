package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

public class COSMOSDoc1 extends ClientMetadata {

	private static final long serialVersionUID = 1330162657697493613L;

	@JsonProperty("Claim Number")
	@JsonAlias("claimNumber")
	private String claimNumber;

	@JsonProperty("Sub Category")
	@JsonAlias("subCategory")
	private String subCategory;

	@JsonProperty("ProviderTaxID")
	@JsonAlias("tin")
	private String tin;

	@JsonProperty("Mpin")
	@JsonAlias("mpin")
	private String mpin="";

	@JsonProperty("Provider Name")
	@JsonAlias("physicianName")
	private String physicianName;
	
	@JsonProperty("patientAccountNumber")
	@JsonAlias("patientAccountNumber")
	private String patientAccountNumber;

	@JsonProperty("Member ID")
	@JsonAlias("memberId")
	private String memberId;

	@JsonProperty("Member Name")
	@JsonAlias("memberName")
	private String memberName;

	@JsonProperty("Policy Number")
	@JsonAlias("policyNumber")
	private String policyNumber;

	@JsonProperty("date of service")
	@JsonAlias("dateOfService")
	private String dateOfService;

	@JsonProperty("Patient DOB")
	@JsonAlias("patientDOB")
	private String patientDOB;

	@JsonProperty("isPrintSuppressed")
	@JsonAlias("emailAlertReq")
	private String emailAlertReq="Y";

	@JsonProperty("Default Ind")
	@JsonAlias("DefaultUsed")
	private String DefaultUsed;

	@JsonProperty("originalPrintTrail")
	private String originalPrintTrail;

	@JsonProperty("PassThruData")
	private String PassThruData;

	@JsonProperty("CONFIGKEY")
	private String CONFIGKEY;

	public COSMOSDoc1(){
		this.category = "Claim";
		this.fileType = "Letter";
		this.tenant = "Link";
		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.providerEmailId = "";
		this.postCardInd = false;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.fileDescription = "Medicare Claim Letter";
		this.privilege = "Claim Status";
		this.subCategory = "R1";
		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		if(subCategory == null || subCategory.isEmpty()){
			this.subCategory = "RR";
			this.setFilePath(Subcategory.RR.getFilePath());
		} else {
			this.subCategory = subCategory;
			Subcategory subCat = null;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.RR;
			}
			this.setFilePath(subCat.getFilePath());
		}
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		this.mpin = mpin;
	}

	public String getPhysicianName() {
		return physicianName;
	}

	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(String dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()){
			this.emailAlertReq = emailAlertReq;
		}
	}

	public String getDefaultUsed() {
		return DefaultUsed;
	}

	public void setDefaultUsed(String defaultUsed) {
		DefaultUsed = defaultUsed;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getPassThruData() {
		return PassThruData;
	}

	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}

	public String getCONFIGKEY() {
		return CONFIGKEY;
	}

	public void setCONFIGKEY(String CONFIGKEY) {
		this.CONFIGKEY = CONFIGKEY;
	}
	
	public String getPatientAccountNumber() {
		return patientAccountNumber;
	}
	
	public void setPatientAccountNumber(String patientAccountNumber) {
		this.patientAccountNumber = patientAccountNumber;
	}

	public enum ErrorMsg implements ErrorMessage {
		CreationDate (12, "Missing or invalid data: Creation Date"),
		ClaimNumber (12, "Missing or invalid data: Claim Number"),
		SubCategory (12, "Missing or invalid data: Sub Category"),
		ProviderTaxID (12,"Missing or invalid data: ProviderTaxID"),
		Mpin (12, "Missing or invalid data: Mpin"), // "emailAlertReq!=\"N\""
		dateofservice (12, "Missing or invalid data: date of service"),
		isPrintSuppressed (12,"Missing or invalid data: isPrintSuppressed"),

		originalPrintTrail (22, "Missing or invalid data: originalPrintTrail(SEVERE)"), // "emailAlertReq!=\"N\""
		PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"), // "emailAlertReq!=\"N\""
		CONFIGKEY (22, "Missing or invalid data: CONFIGKEY(SEVERE)"); // "emailAlertReq!=\"N\""

		private Integer errorCode;
		private String errorMessage;

		ErrorMsg(Integer code, String message) {
			this.errorCode = code;
			this.errorMessage = message;
		}

		public int getErrorCode() {
			return errorCode;
		}
		public String getErrorMessage() {
			return errorMessage;
		}

	}

	public enum Subcategory {

		// COSMOSDoc1

		R1 ("R1", "Medicare/Action Required"),
		RR ("RR", "Medicare/Other");

		private String subCat;
		private String filePath;

		Subcategory(String subCat, String filePath){
			this.subCat = subCat;
			this.filePath = filePath;
		}
		public String getSubCat() {
			return subCat;
		}

		public String getFilePath() {
			return filePath;
		}
	}
}
