package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;


@JsonIgnoreProperties(ignoreUnknown = true)
public class ODARDoc360 extends ClientMetadata {

    private static final long serialVersionUID = -8737265368684222974L;

    @JsonProperty("subCategory")
    protected String subCategory;

    @JsonProperty("tin")
    @JsonAlias("u_attch_ctl_id")
    private String tin;

    @JsonProperty("mpin")
    @JsonAlias("u_attch_prov_id")
    private String mpin = "";

    @JsonProperty("emailAlertReq")
    @JsonAlias("u_batch_id")
    private String emailAlertReq = "N";

    @JsonProperty("multDivisionCode")
    @JsonAlias("u_dcc_nbr")
    private String multDivisionCode;

    @JsonProperty("patientAccountNumber")
    @JsonAlias("u_div")
    private String patientAccountNumber;

    @JsonProperty("physicianName")
    @JsonAlias("u_document_id")
    private String physicianName;

    @JsonProperty("multMemberName")
    @JsonAlias("u_doc_catgy_cd")
    private String multMemberName;

    @JsonProperty("multCheckNumber")
    @JsonAlias("u_doc_src_cd")
    private String multCheckNumber;

    @JsonProperty("letterGroupId")
    @JsonAlias("u_doc_sub_typ_cd")
    private String letterGroupId;

    @JsonProperty("multClaimNumber")
    @JsonAlias("u_doc_typ_cd")
    private String multClaimNumber;

    @JsonProperty("source")
    @JsonAlias("u_email_addr")
    private String source;

    @JsonProperty("letterType")
    @JsonAlias("u_gbl_doc_id")
    private String letterType;

    @JsonProperty("facilityType")
    @JsonAlias("u_int_chnl")
    private String facilityType;

    @JsonProperty("CONFIGKEY")
    @JsonAlias("u_mbr_fst_nm")
    private String CONFIGKEY;

    @JsonProperty("originalPrintTrail")
    @JsonAlias("u_mbr_id")
    private String originalPrintTrail;

    @JsonProperty("PassThruData")
    @JsonAlias("u_mbr_lst_nm")
    private String passThruData;

    @JsonProperty("MailToAddress1")
    @JsonAlias("u_payloc_engine")
    private String mailToAddress1;

    @JsonProperty("MailToAddress2")
    @JsonAlias("u_pol_grp_nbr")
    private String mailToAddress2;

    @JsonProperty("MailToAddress3")
    @JsonAlias("u_pol_nbr")
    private String mailToAddress3;

    @JsonProperty("MailToAddress4")
    @JsonAlias("u_received_dt")
    private String mailToAddress4;

    @JsonProperty("MailToAddress5")
    @JsonAlias("u_sa_oi")
    private String mailToAddress5;

    @JsonProperty("MailToAddress6")
    @JsonAlias("u_seq_nbr")
    private String mailToAddress6;

    @JsonProperty("ReturnAddress1")
    @JsonAlias("u_st")
    private String returnAddress1;

    @JsonProperty("ReturnAddress2")
    @JsonAlias("u_st_cd")
    private String returnAddress2;

    @JsonProperty("ReturnAddress3")
    @JsonAlias("u_queue")
    private String returnAddress3;

    public ODARDoc360() {
        this.category = "Overpayment Documents";
        this.fileType = "Letter";
        this.tenant = "Link";
        this.fileDescription = "Overpayment Document";
        this.createApplication = "ODAR";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.privilege = "Claim Status";
        setSubCategory("OP");
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        if (subCategory == null || subCategory.isEmpty()) {
            this.subCategory = "OP";
            this.setFilePath(ODAR.Subcategory.OP.getFilePath());
        } else {
            this.subCategory = subCategory;
            ODAR.Subcategory subCat;
            try {
                subCat = ODAR.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = ODAR.Subcategory.OP;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }


    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        if (mpin != null) {
            this.mpin = mpin;
        }
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()) {
            this.emailAlertReq = emailAlertReq;
        }
    }

    public String getMultDivisionCode() {
        return multDivisionCode;
    }

    public void setMultDivisionCode(String multDivisionCode) {
        this.multDivisionCode = multDivisionCode;
    }

    public String getPatientAccountNumber() {
        return patientAccountNumber;
    }

    public void setPatientAccountNumber(String patientAccountNumber) {
        this.patientAccountNumber = patientAccountNumber;
    }

    public String getPhysicianName() {
        return physicianName;
    }

    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public String getMultMemberName() {
        return multMemberName;
    }

    public void setMultMemberName(String multMemberName) {
        this.multMemberName = multMemberName;
    }

    public String getMultCheckNumber() {
        return multCheckNumber;
    }

    public void setMultCheckNumber(String multCheckNumber) {
        this.multCheckNumber = multCheckNumber;
    }

    public String getLetterGroupId() {
        return letterGroupId;
    }

    public void setLetterGroupId(String letterGroupId) {
        this.letterGroupId = letterGroupId;
    }

    public String getMultClaimNumber() {
        return multClaimNumber;
    }

    public void setMultClaimNumber(String multClaimNumber) {
        this.multClaimNumber = multClaimNumber;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getLetterType() {
        return letterType;
    }

    public void setLetterType(String letterType) {
        this.letterType = letterType;
    }

    public String getFacilityType() {
        return facilityType;
    }

    public void setFacilityType(String facilityType) {
        this.facilityType = facilityType;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String CONFIGKEY) {
        this.CONFIGKEY = CONFIGKEY;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getPassThruData() {
        return passThruData;
    }

    public void setPassThruData(String passThruData) {
        this.passThruData = passThruData;
    }

    public String getMailToAddress1() {
        return mailToAddress1;
    }

    public void setMailToAddress1(String mailToAddress1) {
        this.mailToAddress1 = mailToAddress1;
    }

    public String getMailToAddress2() {
        return mailToAddress2;
    }

    public void setMailToAddress2(String mailToAddress2) {
        this.mailToAddress2 = mailToAddress2;
    }

    public String getMailToAddress3() {
        return mailToAddress3;
    }

    public void setMailToAddress3(String mailToAddress3) {
        this.mailToAddress3 = mailToAddress3;
    }

    public String getMailToAddress4() {
        return mailToAddress4;
    }

    public void setMailToAddress4(String mailToAddress4) {
        this.mailToAddress4 = mailToAddress4;
    }

    public String getMailToAddress5() {
        return mailToAddress5;
    }

    public void setMailToAddress5(String mailToAddress5) {
        this.mailToAddress5 = mailToAddress5;
    }

    public String getMailToAddress6() {
        return mailToAddress6;
    }

    public void setMailToAddress6(String mailToAddress6) {
        this.mailToAddress6 = mailToAddress6;
    }

    public String getReturnAddress1() {
        return returnAddress1;
    }

    public void setReturnAddress1(String returnAddress1) {
        this.returnAddress1 = returnAddress1;
    }

    public String getReturnAddress2() {
        return returnAddress2;
    }

    public void setReturnAddress2(String returnAddress2) {
        this.returnAddress2 = returnAddress2;
    }

    public String getReturnAddress3() {
        return returnAddress3;
    }

    public void setReturnAddress3(String returnAddress3) {
        this.returnAddress3 = returnAddress3;
    }


    public enum ErrorMsg implements ErrorMessage {
        u_attch_ctl_id(12, "Missing or invalid data: u_attch_ctl_id"),
        u_attch_prov_id(12, "Missing or invalid data: u_attch_prov_id"),
        u_batch_id(12, "Missing or invalid data: u_batch_id"),
        u_doc_sub_typ_cd(12, "Missing or invalid data: u_doc_sub_typ_cd"),
        u_doc_typ_cd(12, "Missing or invalid data: u_doc_typ_cd"),
        u_email_addr(12, "Missing or invalid data: u_email_addr"),
        u_gbl_doc_id(12, "Missing or invalid data: u_gbl_doc_id"),
        u_int_chnl(12, "Missing or invalid data: u_int_chnl"),
        u_mbr_lst_nm(12, "Missing or invalid data: u_mbr_lst_nm"),
        u_orig_creation_date(12, "Missing or invalid data: u_orig_creation_date"),
        u_srt_typ(12, "Missing or invalid data: u_srt_typ"),
        u_mbr_fst_nm(22, "Missing or invalid data: u_mbr_fst_nm(SEVERE)"),
        u_mbr_id(22, "Missing or invalid data: u_mbr_id(SEVERE)"),
        u_payloc_engine(22, "Missing or invalid data: u_payloc_engine(SEVERE)"),
        u_pol_grp_nbr(22, "Missing or invalid data: u_pol_grp_nbr(SEVERE)"),
        u_received_dt(22, "Missing or invalid data: u_received_dt(SEVERE)");

        private final int errorCode;
        private final String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }
}

