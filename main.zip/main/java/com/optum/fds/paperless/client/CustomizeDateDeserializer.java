package com.optum.fds.paperless.client;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.optum.fds.paperless.util.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.optum.fds.paperless.client.pojo.CustomDateFormat;


public class CustomizeDateDeserializer extends StdDeserializer<Date> implements ContextualDeserializer {
	
	private static final long serialVersionUID = 5875147769183417249L;

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomizeDateDeserializer.class);

	private String customDateFormat = null;
	 
	public CustomizeDateDeserializer() {
		super(Date.class);
	}

	public CustomizeDateDeserializer(String customDateFormat) {
		super(Date.class);
		this.customDateFormat = customDateFormat;
	}
	
	@Override
	public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property)
			throws JsonMappingException {
		CustomDateFormat cusAnn = property.getAnnotation(CustomDateFormat.class);
        if (cusAnn != null) {
            String cusDateFormat = cusAnn.dateFormat();
            // return a new instance, so that different properties will not share the same deserializer instance
            return new CustomizeDateDeserializer(cusDateFormat);
        }
        return this;
	}

	@Override
	public Date deserialize(JsonParser jsonParser, DeserializationContext context)
			throws IOException {

		Date date = null;
		String dateStg = jsonParser.getText();

		try {
			if (StringUtils.isNullOrEmpty(dateStg)) {
				return null;
			}
			SimpleDateFormat formatter = new SimpleDateFormat(this.customDateFormat);
			formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
			try {
				date = formatter.parse(dateStg);
			} catch (ParseException e) {
				// if the first format fails, try the second format
				SimpleDateFormat formatter2 = new SimpleDateFormat("MMMM dd, yyyy");
				formatter2.setTimeZone(TimeZone.getTimeZone("UTC"));
				date = formatter2.parse(dateStg);
			}

		} catch (ParseException e) {
			LOGGER.error("CustomJsonDateDeserializer {} dateStg {}", ExceptionUtils.getStackTrace(e), dateStg);
		}
		return date;
	}

}
