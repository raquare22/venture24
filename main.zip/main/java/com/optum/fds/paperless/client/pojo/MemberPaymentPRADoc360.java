package com.optum.fds.paperless.client.pojo;


import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;


public class MemberPaymentPRADoc360 extends ClientMetadata {

    private static final long serialVersionUID = -1234567890123456789L;


    @JsonProperty("subCategory")
    @JsonAlias("u_sub_category")
    private String subCategory;

    @JsonProperty("mpin")
    @JsonAlias("u_mpin")
    private String mpin;

    @JsonProperty("emailAlertReq")
    @JsonAlias("u_email_alert_req")
    private String emailAlertReq = "Y";

    @JsonProperty("CheckAmt")
    @JsonAlias("u_chk_amt")
    private String CheckAmt;

    @JsonProperty("CheckTraceNumber")
    @JsonAlias("u_chk_trc_nbr")
    private String CheckTraceNumber;

    @JsonProperty("ClaimNumber")
    @JsonAlias("u_clm_nbr")
    private String claimNumber;

    @JsonProperty("memberId")
    @JsonAlias("u_mbr_id")
    private String memberId;

    @JsonProperty("memberFirstName")
    @JsonAlias("u_mbr_fst_nm")
    private String memberFirstName;

    @JsonProperty("memberLastName")
    @JsonAlias("u_mbr_lst_nm")
    private String memberLastName;

    @JsonProperty("memberName")
    private String memberName;

    @JsonProperty("npi")
    @JsonAlias("u_npi")
    private String npi;

    @JsonProperty("patientAccountNumber")
    @JsonAlias("u_patient_acct_nbr")
    private String patientAccountNumber;

    @JsonProperty("physicianName")
    @JsonAlias("u_provider_name")
    private String physicianName;

    @JsonProperty("tin")
    @JsonAlias("u_tin")
    private String tin;

    @JsonProperty("CONFIGKEY")
    @JsonAlias("u_config_key")
    private String CONFIGKEY;

    @JsonProperty("originalPrintTrail")
    @JsonAlias("u_trl_id")
    private String originalPrintTrail;

    @JsonProperty("PassThruData")
    @JsonAlias("u_pass_thru_data")
    private String PassThruData;

    @JsonProperty("MailToAddress1")
    @JsonAlias({"u_mail_to_adr1","u_mailing_adr1"})
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    @JsonAlias({"u_mail_to_adr2","u_mailing_adr2"})
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    @JsonAlias({"u_mail_to_adr3","u_mailing_adr3"})
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    @JsonAlias({"u_mail_to_adr4","u_mailing_adr4"})
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    @JsonAlias({"u_mail_to_adr5","u_mailing_adr5"})
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    @JsonAlias({"u_mail_to_adr6","u_mailing_adr6"})
    private String MailToAddress6;

    @JsonProperty("renderingProviderNPI")
    @JsonAlias("u_rend_prov_id")
    private String renderingProviderNPI;

    @JsonProperty("memberClaimSourceSystem")
    @JsonAlias("u_src_sys")
    private String memberClaimSourceSystem;

    @JsonProperty("dateOfService")
    @JsonAlias("u_srvc_dt")
    private String dateOfService;

    @JsonProperty("trailName")
    @JsonAlias("u_trl_nm")
    private String trailName;

    @JsonProperty("paymentType")
    @JsonAlias("u_payment_src")
    private String paymentType;

    @JsonProperty("policyNumber")
    @JsonAlias("u_pol_nbr")
    private String policyNumber;

    @JsonProperty("providerId")
    @JsonAlias("u_provider_id")
    private String providerId;

    @JsonProperty("enterpriseId")
    @JsonAlias("u_enterprise_id")
    private String enterpriseId;


    public MemberPaymentPRADoc360() {
        this.category = "Payment from Members";
        this.fileType = "Letter";
        this.tenant = "Link";
        this.fileDescription = "Payment from Members";
        this.createApplication = "Payment Engine";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.privilege = "Claim Status";
        this.subCategory = "MM";
    }

    public String getSubCategory() {
        return subCategory;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        this.mpin = mpin;
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        this.emailAlertReq = emailAlertReq;
    }

    public String getCheckAmt() {
        return CheckAmt;
    }

    public void setCheckAmt(String CheckAmt) {
        this.CheckAmt = CheckAmt;
    }

    public String getCheckTraceNumber() {
        return CheckTraceNumber;
    }

    public void setCheckTraceNumber(String CheckTraceNumber) {
        this.CheckTraceNumber = CheckTraceNumber;
    }

    public String getClaimNumber() {
        return claimNumber;
    }

    public void setClaimNumber(String ClaimNumber) {
        this.claimNumber = ClaimNumber;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMemberFirstName() { return memberFirstName; }

    public void setMemberFirstName(String memberFirstName) {
        this.memberFirstName = memberFirstName;
        this.normalizeMemberName();
    }

    public String getMemberLastName() { return memberLastName; }

    public void setMemberLastName(String memberLastName) {
        this.memberLastName = memberLastName;
        this.normalizeMemberName();
    }

    public String getMemberName() {
        return memberName;
    }

    private void normalizeMemberName() {
        String firstName = this.memberFirstName == null ? "" : this.memberFirstName.trim();
        String lastName = this.memberLastName == null ? "" : this.memberLastName.trim();
        this.memberName = (firstName + " " + lastName).trim();
    }

    public String getNPI() {
        return npi;
    }

    public void setNPI(String NPI) {
        this.npi = NPI;
    }

    public String getPatientAccountNumber() {
        return patientAccountNumber;
    }

    public void setPatientAccountNumber(String patientAccountNumber) {
        this.patientAccountNumber = patientAccountNumber;
    }

    public String getPhysicianName() {
        return physicianName;
    }

    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String CONFIGKEY) {
        this.CONFIGKEY = CONFIGKEY;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String PassThruData) {
        this.PassThruData = PassThruData;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String MailToAddress1) {
        this.MailToAddress1 = MailToAddress1;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String MailToAddress2) {
        this.MailToAddress2 = MailToAddress2;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String MailToAddress3) {
        this.MailToAddress3 = MailToAddress3;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String MailToAddress4) {
        this.MailToAddress4 = MailToAddress4;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String MailToAddress5) {
        this.MailToAddress5 = MailToAddress5;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String MailToAddress6) {
        this.MailToAddress6 = MailToAddress6;
    }

    public String getRenderingProviderNPI() {  return renderingProviderNPI; }

    public void setRenderingProviderNPI(String RenderingProviderNPI) { this.renderingProviderNPI = RenderingProviderNPI; }

    public String getMemberClaimSourceSystem() { return memberClaimSourceSystem; }

    public void setMemberClaimSourceSystem(String MemberClaimSourceSystem) { this.memberClaimSourceSystem = MemberClaimSourceSystem; }

    public String getDateOfService() { return dateOfService; }

    public void setDateOfService(String DateOfService) { this.dateOfService = DateOfService; }

    public String getTrailName() { return trailName; }

    public void setTrailName(String TrailName) { this.trailName = TrailName; }

    public String getPaymentType() { return paymentType; }

    public void setPaymentType(String PaymentType) { this.paymentType = PaymentType; }

    public String getPolicyNumber() { return policyNumber; }

    public void setPolicyNumber(String PolicyNumber) { this.policyNumber = PolicyNumber; }

    public String getProviderId() { return providerId; }

    public void setProviderId(String ProviderId) { this.providerId = ProviderId; }

    public String getEnterpriseId() { return enterpriseId; }

    public void setEnterpriseId(String EnterpriseId) { this.enterpriseId = EnterpriseId; }

    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "MM";
            this.setFilePath(MemberPaymentPRA.Subcategory.MM.getFilePath());
        } else {
            this.subCategory = subCategory;
            MemberPaymentPRA.Subcategory subCat = null;
            try {
                subCat = MemberPaymentPRA.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = MemberPaymentPRA.Subcategory.MM;
            }
            this.setFilePath(subCat.getFilePath());
        }

        if(this.getExpiryDate() != null && this.getExpiryDate().length() == 7){
            this.setExpiryDate(this.vcpExpiryDateFormat(this.getExpiryDate(), this.subCategory));}
    }

    public enum ErrorMsg implements ErrorMessage {
        // errorCode 12 — enum names match the u_* schema field names (extracted by AbstractMetadataTestUtil.getErrors())
        u_sub_category (12, "Missing or invalid data: LETTERTYPE"),
        u_mpin (12, "Missing or invalid data: ProviderMPIN"),
        u_email_alert_req (12, "Missing or invalid data: isPrintSuppressed"),
        u_chk_amt (12, "Missing or invalid data: Claim Amount"),
        u_chk_trc_nbr (12, "Missing or invalid data: Check Trace Number"),
        u_clm_nbr (12, "Missing or invalid data: Claim Number"),
        u_orig_creation_date (12, "Missing or invalid data: PROCESSDATE"),
        u_tin (12, "Missing or invalid data: Provider TIN"),

        // errorCode 22 — SEVERE, triggered when u_email_alert_req=Y
        u_pass_thru_data (22, "Missing or invalid data: PassThruData(SEVERE)"),
        u_trl_id (22, "Missing or invalid data: originalPrintTrail(SEVERE)"),
        u_config_key (22, "Missing or invalid data: ConfigKey(SEVERE)"),
        u_mailing_adr1 (22, "Missing or invalid data: u_mailing_adr1(SEVERE)"),
        u_mailing_adr2 (22, "Missing or invalid data: u_mailing_adr2(SEVERE)");

        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

    }

    public enum Subcategory {
        M1("M1", "Commercial/Direct Deposit Remittance Documents"),
        M2("M2", "Commercial/Virtual Card Payment Remittance Documents"),
        M3("M3", "Medicare/Direct Deposit Remittance Documents"),
        M4("M4", "Medicare/Virtual Card Payment Remittance Documents"),
        M5("M5", "UHC West/Direct Deposit Remittance Documents"),
        M6("M6", "Community Plan/Direct Deposit Remittance Documents"),
        M7("M7", "Community Plan/Virtual Card Payments Remittance Documents"),
        MM("MM", "Other Payments from Members/Other");

        private final String subCat;
        private final String filePath;

        Subcategory(String subCat, String filePath) {
            this.subCat = subCat;
            this.filePath = filePath;
        }

        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }

        public static MemberPaymentPRADoc360.Subcategory fromSubCat(String subCat) {
            for (MemberPaymentPRADoc360.Subcategory subcategory : values()) {
                if (subcategory.subCat.equalsIgnoreCase(subCat)) {
                    return subcategory;
                }
            }
            return MM;
        }
    }
}