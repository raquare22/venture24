package com.optum.fds.paperless.client;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ClientRootMetadata implements Serializable {
	
	    private static final long serialVersionUID = -7434707899998405768L;
	    public ClientMetadata metadata;
	    @JsonProperty("ApplicationID") 
	    public String applicationID;
	    @JsonProperty("Datagroup") 
	    public String datagroup;
	    @JsonProperty("FileFormat") 
	    public String fileFormat;
}
