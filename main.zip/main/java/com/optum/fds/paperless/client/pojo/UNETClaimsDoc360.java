package com.optum.fds.paperless.client.pojo;

import java.io.Serial;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;
import com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UNETClaimsDoc360 extends ClientMetadata{

	private static final String DEFAULT_CREATE_APPLICATION = "ELGS";
	private static final String DEFAULT_FILE_TYPE = "Letter";
	private static final String DEFAULT_TENANT = "Link";
	private static final String DEFAULT_DOC_SENT_TO = "";
	private static final boolean DEFAULT_SEND_TO_DOC_VAULT = false;
	private static final boolean DEFAULT_SEND_TO_SHUTTERFLY = false;
	private static final String DEFAULT_PROVIDER_EMAIL_ID = "";
	private static final boolean DEFAULT_POST_CARD_IND = true;
	private static final boolean DEFAULT_SEND_EMAIL_NOTIFICATIONS = false;
	private static final boolean DEFAULT_SEND_PEN_API_REQUEST = false;
	private static final String DEFAULT_PRIVILEGE = "Claim Status";
	private static final String DEFAULT_PROVIDER_ID = "";
	private static final String DEFAULT_SUBCATEGORY = "CC";

	@Serial
	private static final long serialVersionUID = 1L;

	@JsonProperty("claimNumber")
	@JsonAlias("u_clm_nbr")
	private String claimNumber;

	@JsonProperty("subCategory")
	@JsonAlias("u_sub_category")
	private String subCategory;

	@JsonProperty("tin")
	@JsonAlias("u_tin")
	private String tin;

	@JsonProperty("emailAlertReq")
	@JsonAlias("u_email_alert_req")
	private String emailAlertReq = "Y";

	@JsonProperty("providerName")
	@JsonAlias("u_physician_provider_nm")
	private String providerName;

	@JsonProperty("policyNumber")
	@JsonAlias("u_policy_nbr")
	private String policyNumber;

	@JsonProperty("memberFirstName")
	@JsonAlias("u_fst_nm")
	private String memberFirstName;

	@JsonProperty("memberLastName")
	@JsonAlias("u_lst_nm")
	private String memberLastName;

	@JsonProperty("memberName")
	private String memberName;

	@JsonProperty("dateOfService")
	@JsonAlias("u_dos_dt")
	private String dateOfService;

	@JsonProperty("PatientName")
	@JsonAlias("u_patient_fn_ln")
	private String PatientName;

	@JsonProperty("patientDOB")
	@JsonAlias("u_dob")
	private String patientDOB;

	@JsonProperty("patientAccountNumber")
	@JsonAlias("u_ptnt_acct_nbr")
	private String patientAccountNumber;

	@JsonProperty("npi")
	@JsonAlias("u_npi")
	private String npi;

	@JsonProperty("mpin")
	@JsonAlias("u_mpin")
	private String mpin = "";

	@JsonProperty("memberId")
	@JsonAlias("u_mbr_id")
	private String memberId;

	@JsonProperty("ELGSLETTERGENID")
	@JsonAlias("u_elgs_ltr_gen_id")
	private String ELGSLETTERGENID;

	@JsonProperty("PassThruData")
	@JsonAlias("u_pass_thru_data")
	private String PassThruData;

	@JsonProperty("LetterHistoryID")
	@JsonAlias("u_ltr_hist_id")
	private String LetterHistoryID;

	@JsonProperty("originalPrintTrail")
	@JsonAlias("u_trl_id")
	private String originalPrintTrail;

	@JsonProperty("CONFIGKEY")
	@JsonAlias("u_config_key")
	private String CONFIGKEY;

	@JsonProperty("MailToAddress1")
	@JsonAlias("u_rcip_nm")
	private String MailToAddress1;

	@JsonProperty("MailToAddress2")
	@JsonAlias("u_mail_to_adr1")
	private String MailToAddress2;

	@JsonProperty("MailToAddress3")
	@JsonAlias("u_mail_to_adr2")
	private String MailToAddress3;

	@JsonProperty("MailToAddress4")
	@JsonAlias("u_cty")
	private String MailToAddress4;

	@JsonProperty("MailToAddress5")
	@JsonAlias("u_st")
	private String MailToAddress5;

	@JsonProperty("MailToAddress6")
	@JsonAlias("u_zip")
	private String MailToAddress6;

	@JsonProperty("providerId")
	@JsonAlias("u_prov_id")
	private String providerId;


    public UNETClaimsDoc360() {

		this.fileType = DEFAULT_FILE_TYPE;
		this.tenant = DEFAULT_TENANT;
		this.createApplication = DEFAULT_CREATE_APPLICATION;
		this.docSentTo = DEFAULT_DOC_SENT_TO;
		this.sendToDocVault = DEFAULT_SEND_TO_DOC_VAULT;
		this.sendToShutterfly = DEFAULT_SEND_TO_SHUTTERFLY;
		this.providerEmailId = DEFAULT_PROVIDER_EMAIL_ID;
		this.postCardInd = DEFAULT_POST_CARD_IND;
        this.dateEmailSent = null;
		this.sendEmailNotifications = DEFAULT_SEND_EMAIL_NOTIFICATIONS;
		this.sendPENAPIRequest = DEFAULT_SEND_PEN_API_REQUEST;
		this.privilege = DEFAULT_PRIVILEGE;
		this.providerId = DEFAULT_PROVIDER_ID;
		this.subCategory = DEFAULT_SUBCATEGORY;
    }

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getSubCategory() {
		return subCategory;
	}

    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "CC";
            this.setFilePath(UNETClaimsDoc360.Subcategory.CC.getFilePath());
            this.setCategory("Claim");
        } else {
            this.subCategory = subCategory;
			UNETClaimsDoc360.Subcategory subCat;
            try {
                subCat = UNETClaimsDoc360.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = UNETClaimsDoc360.Subcategory.CC;
            }
            if(subCategory.equalsIgnoreCase("C5"))
            {
                this.setCategory("Overpayment Documents");
            }
            else
                this.setCategory("Claim");


            this.setFilePath(subCat.getFilePath());
        }
    }
    public enum Subcategory {

        // UNETClaims (ELGS)
        C1 ("C1", "Commercial/Action Required"),
        C2 ("C2", "Commercial/Claim Receipt Acknowledgement"),
        C3 ("C3", "Commercial/Denials"),
        C4 ("C4", "Commercial/Please Review (FYI)"),
        C5 ("C5", "Commercial Overpayment Letters/Overpayment Identified"),
        C6 ("C6", "Commercial/Claim Reconsideration"),
        C7 ("C7", "Commercial/Approvals"),
        C8 ("C8", "Commercial/Copy of Member Letters"),
        CC ("CC", "Commercial/Other");

		private final String subCat;
		private final String filePath;

        Subcategory(String subCat, String filePath){
            this.subCat = subCat;
            this.filePath = filePath;

        }
        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }

    }

	public String getTin() {
		return tin;
	}

    public void setTin(String tin) {
		if (tin == null) {
			this.tin = null;
			return;
		}

		String normalizedTin = tin.trim();
		if (normalizedTin.length() == 15 && (normalizedTin.startsWith("1") || normalizedTin.startsWith("2"))) {
			this.tin = normalizedTin.substring(0, 10);
		} else {
			this.tin = normalizedTin;
		}
    }

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()) {
			this.emailAlertReq = emailAlertReq;
		}
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getMemberFirstName() {
		return memberFirstName;
	}

	public void setMemberFirstName(String memberFirstName) {
        this.memberFirstName = memberFirstName == null ? "" : memberFirstName.trim();
        this.memberName = NormalizeUtil.normalizeMemberName(memberFirstName,memberLastName);
	}

	public String getMemberLastName() {
		return memberLastName;
	}

	public void setMemberLastName(String memberLastName) {
        this.memberLastName = memberLastName == null ? "" : memberLastName.trim();
        this.memberName = NormalizeUtil.normalizeMemberName(memberFirstName,memberLastName);
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getDateOfService() {
		return dateOfService;
	}

	public void setDateOfService(String dateOfService) {
		this.dateOfService = dateOfService;
	}

	public String getPatientName() {
		return PatientName;
	}

	public void setPatientName(String patientName) {
		PatientName = patientName;
	}

	public String getPatientDOB() {
		return patientDOB;
	}

	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}

	public String getPatientAccountNumber() {
		return patientAccountNumber;
	}

	public void setPatientAccountNumber(String patientAccountNumber) {
		this.patientAccountNumber = patientAccountNumber;
	}

	public String getNpi() {
		return npi;
	}

	public void setNpi(String npi) {
		this.npi = npi;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		if (mpin != null) {
			this.mpin = mpin;
		}
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getELGSLETTERGENID() {
		return ELGSLETTERGENID;
	}

	public void setELGSLETTERGENID(String ELGSLETTERGENID) {
		this.ELGSLETTERGENID = ELGSLETTERGENID;
	}

	public String getPassThruData() {
		return PassThruData;
	}

	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}

	public String getLetterHistoryID() {
		return LetterHistoryID;
	}

	public void setLetterHistoryID(String letterHistoryID) {
		LetterHistoryID = letterHistoryID;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getCONFIGKEY() {
		return CONFIGKEY;
	}

	public void setCONFIGKEY(String CONFIGKEY) {
		this.CONFIGKEY = CONFIGKEY;
	}

	public String getMailToAddress1() {
		return MailToAddress1;
	}

	public void setMailToAddress1(String mailToAddress1) {
		MailToAddress1 = mailToAddress1;
	}

	public String getMailToAddress2() {
		return MailToAddress2;
	}

	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}

	public String getMailToAddress3() {
		return MailToAddress3;
	}

	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}

	public String getMailToAddress4() {
		return MailToAddress4;
	}

	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}

	public String getMailToAddress5() {
		return MailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return MailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}

	public String getProviderId() {
		return providerId;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}

    public enum ErrorMsg implements ErrorMessage {
        u_clm_nbr (12, "Missing or invalid data: u_clm_nbr"),
        u_sub_category (12, "Missing or invalid data: u_sub_category"),
        u_tin (12, "Missing or invalid data: u_tin"),
        u_email_alert_req (12,"Missing or invalid data: u_email_alert_req  "),
        u_dos_dt (12, "Missing or invalid data: u_dos_dt"),
        u_mpin (12, "Missing or invalid data: u_mpin  "),
        u_doc_creation_dt (12, "Missing or invalid data: u_doc_creation_dt"),
        u_pass_thru_data (22, "Missing or invalid data: u_pass_thru_data(SEVERE)"),
        u_ltr_hist_id (22, "Missing or invalid data: u_ltr_hist_id(SEVERE)"),
        u_trl_id (22, "Missing or invalid data: u_trl_id(SEVERE)"),
        u_rcip_nm (22, "Missing or invalid data: u_rcip_nm(SEVERE)"),
        u_mail_to_adr1 (22, "Missing or invalid data: u_mail_to_adr1(SEVERE)"),
        u_cty (22, "Missing or invalid data: u_cty(SEVERE)"),
        u_st (22, "Missing or invalid data: u_st(SEVERE)"),
        u_zip (22, "Missing or invalid data: u_zip(SEVERE)");

        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }
        public String getErrorMessage() {
            return errorMessage;
        }

    }

    }
