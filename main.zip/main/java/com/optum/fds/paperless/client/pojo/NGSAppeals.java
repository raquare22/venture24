package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

public class NGSAppeals extends ClientMetadata {

	private static final long serialVersionUID = -4890498803122150036L;

	@JsonProperty("caseId")
	private String caseId;

	@JsonProperty("ngsId")
	@JsonAlias("NGSID")
	private String ngsId;
	
    @JsonProperty("tin")
    private String tin;

    @JsonProperty("mpin")
    private String mpin="";

    @JsonProperty("emailAlertReq")
    @JsonAlias({"isPrintSuppressed" })
    private String emailAlertReq="Y";

    @JsonProperty("physicianName")
    private String physicianName;

    @JsonProperty("memberId")
    @JsonAlias("employeeId")
    private String memberId;

    @JsonProperty("CONFIGKEY")
    private String CONFIGKEY;

    @JsonProperty("originalPrintTrail")
    private String originalPrintTrail;

    @JsonProperty("PassThruData")
    @JsonAlias("PassThruData")
    private String PassThruData;

    @JsonProperty("patientAccountNumber")
    @JsonAlias("ClinicAccountNumber")
    private String patientAccountNumber;

    @JsonProperty("MailToAddress1")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    private String MailToAddress6;

    @JsonProperty("subCategory")
    protected String subCategory;


    public NGSAppeals() {
        this.category = "Appeals and Disputes";
        this.fileType = "Letter";
        this.tenant = "Link";
        this.fileDescription = "Appeals and Disputes";
        this.createApplication = "NGS";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = true;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.subCategory = "XX";
        Subcategory subCat = Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }

    public String getCaseId() { return caseId; }

    public void setCaseId(String caseId) { this.caseId = caseId; }

    public String getNgsId() {
		return ngsId;
	}
	public void setNgsId(String ngsId) {
		this.ngsId = ngsId;
	}

    public String getTin() { return tin; }

    public void setTin(String tin) { this.tin = tin; }

    public String getMpin() { return mpin; }

    public void setMpin(String mpin) {
        if(mpin != null){
            this.mpin = mpin;
        }
    }
    public String getEmailAlertReq() { return emailAlertReq; }

    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()){
            this.emailAlertReq = emailAlertReq;
        }
    }

    public String getPhysicianName() { return physicianName; }

    public void setPhysicianName(String physicianName) { this.physicianName = physicianName; }

    public String getMemberId() { return memberId; }

    public void setMemberId(String memberId) { this.memberId = memberId; }

    public String getCONFIGKEY() { return CONFIGKEY; }

    public void setCONFIGKEY(String cONFIGKEY) { CONFIGKEY = cONFIGKEY;	}

    public String getOriginalPrintTrail() {	return originalPrintTrail; }

    public void setOriginalPrintTrail(String originalPrintTrail) { this.originalPrintTrail = originalPrintTrail; }

    public String getPassThruData() {
        return PassThruData;
    }
    public void setPassThruData(String passThruData) {
        PassThruData = passThruData;
    }
    public String getMailToAddress1() {
        return MailToAddress1;
    }
    public void setMailToAddress1(String mailToAddress1) {
        MailToAddress1 = mailToAddress1;
    }
    public String getMailToAddress2() {
        return MailToAddress2;
    }
    public void setMailToAddress2(String mailToAddress2) {
        MailToAddress2 = mailToAddress2;
    }
    public String getMailToAddress3() {
        return MailToAddress3;
    }
    public void setMailToAddress3(String mailToAddress3) {
        MailToAddress3 = mailToAddress3;
    }
    public String getMailToAddress4() {
        return MailToAddress4;
    }
    public void setMailToAddress4(String mailToAddress4) {
        MailToAddress4 = mailToAddress4;
    }
    public String getMailToAddress5() {
        return MailToAddress5;
    }
    public void setMailToAddress5(String mailToAddress5) {
        MailToAddress5 = mailToAddress5;
    }
    public String getMailToAddress6() {
        return MailToAddress6;
    }
    public void setMailToAddress6(String mailToAddress6) {
        MailToAddress6 = mailToAddress6;
    }

    public String getSubCategory() {
        return subCategory;
    }
    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "XX";
            this.setFilePath(Subcategory.XX.getFilePath());
        } else {
            this.subCategory = subCategory;
            Subcategory subCat = null;
            try {
                subCat = Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = Subcategory.XX;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }

    public String getPatientAccountNumber() {
        return patientAccountNumber;
    }

    public void setPatientAccountNumber(String patientAccountNumber) {
        this.patientAccountNumber = patientAccountNumber;
    }

    public enum ErrorMsg implements ErrorMessage {
        tin (12, "Missing or invalid data: tin"),
        mpin (12, "Missing or invalid data: mpin"), // emailAlertReq == \"Y\"
        subCategory (12, "Missing or invalid data: subCategory"),
        isPrintSuppressed (12,"Missing or invalid data: isPrintSuppressed"),
        createdDate (12, "Missing or invalid data: createdDate"),
        caseId (12, "Missing or invalid data: caseId"),
        NGSID (12, "Missing or invalid data: NGSID"),

        privilege (22, "Missing or invalid data: privilege(SEVERE)"),
        CONFIGKEY (22, "Missing or invalid data: CONFIGKEY(SEVERE)"), // emailAlertReq == \"Y\"
        originalPrintTrail (22, "Missing or invalid data: originalPrintTrail(SEVERE)"), // emailAlertReq == \"Y\"
        PassThruData (22, "Missing or invalid data: PassThruData(SEVERE)"), // emailAlertReq == \"Y\"

        MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"), // emailAlertReq == \"Y\"
        MailToAddress2 (22, "Missing or invalid data: MailToAddress2(SEVERE)"), // emailAlertReq == \"Y\"
        MailToAddress4 (22, "Missing or invalid data: MailToAddress4(SEVERE)"), // emailAlertReq == \"Y\"
        MailToAddress5 (22, "Missing or invalid data: MailToAddress5(SEVERE)"), // emailAlertReq == \"Y\"
        MailToAddress6 (22, "Missing or invalid data: MailToAddress6(SEVERE)"); // emailAlertReq == \"Y\"

        private int errorCode;
        private String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        @Override
        public int getErrorCode() {
            return errorCode;
        }

        @Override
        public String getErrorMessage() {
            return errorMessage;
        }

    }

    public enum Subcategory {
        // NGS Appeals
    	Y2 ("Y2", "Medicare Appeals and Disputes / Additional Information Needed (Rx)"),			
		Y3 ("Y3", "Medicare  Appeals and Disputes / Resolution (Rx)"),		
		Y4 ("Y4", "Medicare  Appeals and Disputes / Notification and Acknowledgement (Rx)"),		
		Y5 ("Y5", "Special Needs Plan Appeals and Disputes / Additional Information Needed"),			
		Y6 ("Y6", "Special Needs Plan Appeals and Disputes / Resolution"),
		Y7 ("Y7", "Special Needs Plan Appeals and Disputes / Notification and Acknowledgement"),
		X1 ("X1", "Commercial Appeals and Disputes / Acknowledgement, Notification, and Response"),
		X2 ("X2", "Community Plan Appeals and Disputes / Acknowledgement, Notification, and Response"),
		X5 ("X5", "Medicare Appeals and Disputes / Additional Information Needed"),		
		X6 ("X6", "Medicare Appeals and Disputes / Resolution"),	
		X7 ("X7", "Medicare Appeals and Disputes / Notification and Acknowledgement"),			
		X8 ("X8", "UHCWest Appeals and Disputes / Additional Information Needed"),		
		X9 ("X9", "UHCWest Appeals and Disputes / Resolution"),		
		X0 ("X0", "UHCWest Appeals and Disputes / Notification and Acknowledgement"),
		XX ("XX", "Other Appeals and Disputes / Other");

        private String subCat;
        private String filePath;

        Subcategory(String subCat, String filePath){
            this.subCat = subCat;
            this.filePath = filePath;
        }
        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }
}
