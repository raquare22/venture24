package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;
import com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil;

public class COSMOSDoc1Doc360 extends ClientMetadata {

    private static final long serialVersionUID = 1330162657697492529L;

    @JsonProperty("Claim Number")
    @JsonAlias("u_clm_nbr")
    private String claimNumber;

    @JsonProperty("Sub Category")
    @JsonAlias("u_sub_category")
    private String subCategory;

    @JsonProperty("ProviderTaxID")
    @JsonAlias("u_tin")
    private String tin;

    @JsonProperty("Mpin")
    @JsonAlias("u_mpin")
    private String mpin="";

    @JsonProperty("Member ID")
    @JsonAlias("u_mbr_id")
    private String memberId;

    @JsonProperty("isPrintSuppressed")
    @JsonAlias("u_email_alert_req")
    private String emailAlertReq="Y";

    @JsonProperty("Provider Name")
    @JsonAlias("u_phy_nm")
    private String physicianName;

    @JsonProperty("patientAccountNumber")
    @JsonAlias("u_patient_acct_nbr")
    private String patientAccountNumber;

    @JsonProperty("Policy Number")
    @JsonAlias("u_pol_nbr")
    private String policyNumber;

    @JsonProperty("memberName")
    private String memberName;

    @JsonProperty("memberFirstName")
    @JsonAlias("u_mbr_fst_nm")
    private String memberFirstName;

    @JsonProperty("memberLastName")
    @JsonAlias("u_mbr_lst_nm")
    private String memberLastName;

    @JsonProperty("date of service")
    @JsonAlias("u_srvc_dt")
    private String dateOfService;

    @JsonProperty("Patient DOB")
    @JsonAlias("u_ptnt_dob_dt")
    private String patientDOB;

    @JsonProperty("Default Ind")
    @JsonAlias("DefaultUsed")
    private String DefaultUsed;

    @JsonProperty("originalPrintTrail")
    @JsonAlias("u_trl_id")
    private String originalPrintTrail;

    @JsonProperty("PassThruData")
    @JsonAlias("u_pass_thru_data")
    private String PassThruData;

    @JsonProperty("CONFIGKEY")
    @JsonAlias("u_config_key")
    private String CONFIGKEY;

    @JsonProperty("MailToAddress1")
    @JsonAlias("u_mailing_adr1")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    @JsonAlias("u_mailing_adr2")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    @JsonAlias("u_mailing_adr3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    @JsonAlias("u_mailing_adr4")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    @JsonAlias("u_mailing_adr5")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    @JsonAlias("u_mailing_adr6")
    private String MailToAddress6;

    public COSMOSDoc1Doc360(){
        this.category = "Claim";
        this.fileType = "Letter";
        this.tenant = "Link";
        this.docSentTo = "";
        this.sendToDocVault = false;
        this.sendToShutterfly = false;
        this.providerEmailId = "";
        this.postCardInd = false;
        this.dateEmailSent = null;
        this.sendEmailNotifications = false;
        this.sendPENAPIRequest = false;
        this.fileDescription = "Medicare Claim Letter";
        this.privilege = "Claim Status";
        this.subCategory = "R1";
        COSMOSDoc1.Subcategory subCat = COSMOSDoc1.Subcategory.valueOf(this.subCategory);
        this.setFilePath(subCat.getFilePath());
    }

    public String getClaimNumber() {
        return claimNumber;
    }

    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        if(subCategory == null || subCategory.isEmpty()){
            this.subCategory = "RR";
            this.setFilePath(COSMOSDoc1.Subcategory.RR.getFilePath());
        } else {
            this.subCategory = subCategory;
            COSMOSDoc1.Subcategory subCat = null;
            try {
                subCat = COSMOSDoc1.Subcategory.valueOf(this.subCategory);
            } catch (Exception e) {
                subCat = COSMOSDoc1.Subcategory.RR;
            }
            this.setFilePath(subCat.getFilePath());
        }
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        this.mpin = mpin;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()){
            this.emailAlertReq = emailAlertReq;
        }
    }

    public String getPhysicianName() {
        return physicianName;
    }

    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public String getPatientAccountNumber() {
        return patientAccountNumber;
    }

    public void setPatientAccountNumber(String patientAccountNumber) {
        this.patientAccountNumber = patientAccountNumber;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getMemberFirstName() {
        return memberFirstName;
    }

    public void setMemberFirstName(String memberFirstName) {
        this.memberFirstName = memberFirstName;
        this.memberName = NormalizeUtil.normalizeMemberName(this.memberFirstName, this.memberLastName);
    }

    public String getMemberLastName() {
        return memberLastName;
    }

    public void setMemberLastName(String memberLastName) {
        this.memberLastName = memberLastName;
        this.memberName = NormalizeUtil.normalizeMemberName(this.memberFirstName, this.memberLastName);
    }

    public String getDateOfService() {
        return dateOfService;
    }

    public void setDateOfService(String dateOfService) {
        this.dateOfService = dateOfService;
    }

    public String getPatientDOB() {
        return patientDOB;
    }

    public void setPatientDOB(String patientDOB) {
        this.patientDOB = patientDOB;
    }

    public String getDefaultUsed() {
        return DefaultUsed;
    }

    public void setDefaultUsed(String defaultUsed) {
        DefaultUsed = defaultUsed;
    }

    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String passThruData) {
        PassThruData = passThruData;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getCONFIGKEY() {
        return CONFIGKEY;
    }

    public void setCONFIGKEY(String CONFIGKEY) {
        this.CONFIGKEY = CONFIGKEY;
    }

    public String getMailToAddress1() { return MailToAddress1; }

    public void setMailToAddress1(String mailToAddress1) { MailToAddress1 = mailToAddress1; }

    public String getMailToAddress2() { return MailToAddress2; }

    public void setMailToAddress2(String mailToAddress2) { MailToAddress2 = mailToAddress2; }

    public String getMailToAddress3() { return MailToAddress3; }

    public void setMailToAddress3(String mailToAddress3) { MailToAddress3 = mailToAddress3; }

    public String getMailToAddress4() { return MailToAddress4; }

    public void setMailToAddress4(String mailToAddress4) { MailToAddress4 = mailToAddress4; }

    public String getMailToAddress5() { return MailToAddress5; }

    public void setMailToAddress5(String mailToAddress5) { MailToAddress5 = mailToAddress5; }

    public String getMailToAddress6() { return MailToAddress6; }

    public void setMailToAddress6(String mailToAddress6) { MailToAddress6 = mailToAddress6; }

    public enum ErrorMsg implements ErrorMessage {
        u_doc_creation_dt (12, "Missing or invalid data: Creation Date"),
        u_clm_nbr (12, "Missing or invalid data: Claim Number"),
        u_sub_category (12, "Missing or invalid data: Sub Category"),
        u_tin (12,"Missing or invalid data: ProviderTaxID"),
        u_mpin (12, "Missing or invalid data: Mpin"), // "emailAlertReq!=\"N\""
        u_srvc_dt (12, "Missing or invalid data: date of service"),
        u_email_alert_req (12,"Missing or invalid data: isPrintSuppressed"),


        u_trl_id (22, "Missing or invalid data: originalPrintTrail(SEVERE)"), // "emailAlertReq!=\"N\""
        u_pass_thru_data (22, "Missing or invalid data: PassThruData(SEVERE)"), // "emailAlertReq!=\"N\""
        u_config_key (22, "Missing or invalid data: CONFIGKEY(SEVERE)"); // "emailAlertReq!=\"N\""

        private Integer errorCode;
        private String errorMessage;

        ErrorMsg(Integer code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }
        public String getErrorMessage() {
            return errorMessage;
        }

    }

    public enum Subcategory {

        R1 ("R1", "Medicare/Action Required"),
        RR ("RR", "Medicare/Other");

        private String subCat;
        private String filePath;

        Subcategory(String subCat, String filePath){
            this.subCat = subCat;
            this.filePath = filePath;
        }
        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }

}
