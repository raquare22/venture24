package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

public class MCRClaims extends ClientMetadata {
    private static final String DEFAULT_CATEGORY = "Medicare Letters";
    private static final String DEFAULT_FILE_TYPE = "Letter";
    private static final String DEFAULT_TENANT = "Link";
    private static final String DEFAULT_FILE_DESCRIPTION = "Medicare Letter";
    private static final String DEFAULT_CREATE_APPLICATION = "MCR";
    private static final String DEFAULT_SUBCATEGORY = "MCR";
    private static final String DEFAULT_PRIVILEGE = "Claim Status";
    private static final String DEFAULT_DOC_SENT_TO = "";
    private static final boolean DEFAULT_SEND_TO_DOC_VAULT = false;
    private static final boolean DEFAULT_SEND_TO_SHUTTERFLY = false;
    private static final boolean DEFAULT_POST_CARD_IND = true;
    private static final boolean DEFAULT_SEND_EMAIL_NOTIFICATIONS = false;
    private static final boolean DEFAULT_SEND_PEN_API_REQUEST = false;
    private static final String DEFAULT_PROVIDER_EMAIL_ID = "";
    private static final long serialVersionUID = 1L;

    @JsonProperty("tin")
    @JsonAlias("u_prov_tin")
    private String tin;

    @JsonProperty("npi")
    @JsonAlias("u_prov_npi")
    private String npi;

    @JsonProperty("mpin")
    @JsonAlias("u_mpin")
    private String mpin = "";

    @JsonProperty("emailAlertReq")
    private String emailAlertReq = "Y";

    @JsonProperty("physicianName")
    @JsonAlias("u_prov_nm")
    private String physicianName;

    @JsonProperty("memberId")
    @JsonAlias("u_alt_id")
    private String memberId;

    @JsonProperty("memberFirstName")
    @JsonAlias("u_mbr_fst_nm")
    private String memberFirstName;

    @JsonProperty("memberLastName")
    @JsonAlias("u_mbr_lst_nm")
    private String memberLastName;

    @JsonProperty("claimNumber")
    @JsonAlias("u_clm_nbr")
    private String claimNumber;

    @JsonProperty("PassThruData")
    @JsonAlias("PassThruData")
    private String PassThruData;

    @JsonProperty("originalPrintTrail")
    @JsonAlias("originalPrintTrail")
    private String originalPrintTrail;

    @JsonProperty("CONFIGKEY")
    private String CONFIGKEY;

    @JsonProperty("MailToAddress1")
    @JsonAlias("u_prov_nm")
    private String MailToAddress1;

    @JsonProperty("MailToAddress2")
    @JsonAlias("u_adr1")
    private String MailToAddress2;

    @JsonProperty("MailToAddress3")
    private String MailToAddress3;

    @JsonProperty("MailToAddress4")
    @JsonAlias("u_cty")
    private String MailToAddress4;

    @JsonProperty("MailToAddress5")
    @JsonAlias("u_st")
    private String MailToAddress5;

    @JsonProperty("MailToAddress6")
    @JsonAlias("u_zip")
    private String MailToAddress6;

    @JsonProperty("subCategory")
    private String subCategory;

    @JsonProperty("recipient")
    private String recipient;

    private String memberName;


    public MCRClaims() {

        this.category = DEFAULT_CATEGORY;
        this.fileType = DEFAULT_FILE_TYPE;
        this.tenant = DEFAULT_TENANT;
        this.fileDescription = DEFAULT_FILE_DESCRIPTION;
        this.createApplication = DEFAULT_CREATE_APPLICATION;
        this.docSentTo = DEFAULT_DOC_SENT_TO;
        this.sendToDocVault = DEFAULT_SEND_TO_DOC_VAULT;
        this.sendToShutterfly = DEFAULT_SEND_TO_SHUTTERFLY;
        this.providerEmailId = DEFAULT_PROVIDER_EMAIL_ID;
        this.postCardInd = DEFAULT_POST_CARD_IND;
        this.dateEmailSent = null;
        this.sendEmailNotifications = DEFAULT_SEND_EMAIL_NOTIFICATIONS;
        this.sendPENAPIRequest = DEFAULT_SEND_PEN_API_REQUEST;
        this.subCategory = DEFAULT_SUBCATEGORY;
        this.privilege = DEFAULT_PRIVILEGE;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getNpi() {
        return npi;
    }

    public void setNpi(String npi) {
        this.npi = npi;
    }

    public String getMpin() {
        return mpin;
    }

    public void setMpin(String mpin) {
        this.mpin = mpin;
    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        if (emailAlertReq != null && !emailAlertReq.isEmpty()){
            this.emailAlertReq = emailAlertReq;
        }
    }

    public String getPhysicianName() {
        return physicianName;
    }

    public void setPhysicianName(String physicianName) {
        this.physicianName = physicianName;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMemberFirstName() {
        return memberFirstName;
    }

    public void setMemberFirstName(String memberFirstName) {
      this.memberFirstName = memberFirstName == null ? "" : memberFirstName.trim();
      this.normalizeMemberName();
    }
    public String getMemberLastName() {
        return memberLastName;
    }

    public void setMemberLastName(String memberLastName) {
       this.memberLastName = memberLastName == null ? "" : memberLastName.trim();
       this.normalizeMemberName();
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    private void normalizeMemberName() {
        String firstName = this.memberFirstName == null ? "" : this.memberFirstName;
        String lastName = this.memberLastName == null ? "" : this.memberLastName;
        this.memberName = (firstName + " " + lastName);
    }

    public String getClaimNumber() {
        return claimNumber;
    }

    public void setClaimNumber(String claimNumber) {
        this.claimNumber = claimNumber;
    }

    public String getPassThruData() {
        return PassThruData;
    }

    public void setPassThruData(String PassThruData) {
        this.PassThruData = PassThruData;
    }

    public String getOriginalPrintTrail() {
        return originalPrintTrail;
    }

    public void setOriginalPrintTrail(String originalPrintTrail) {
        this.originalPrintTrail = originalPrintTrail;
    }

    public String getConfigKey() {
        return CONFIGKEY;
    }

    public void setConfigKey(String CONFIGKEY) {
        this.CONFIGKEY = CONFIGKEY;
    }

    public String getMailToAddress1() {
        return MailToAddress1;
    }

    public void setMailToAddress1(String MailToAddress1) {
        this.MailToAddress1 = MailToAddress1;
    }

    public String getMailToAddress2() {
        return MailToAddress2;
    }

    public void setMailToAddress2(String MailToAddress2) {
        this.MailToAddress2 = MailToAddress2;
    }

    public String getMailToAddress3() {
        return MailToAddress3;
    }

    public void setMailToAddress3(String MailToAddress3) {
        this.MailToAddress3 = MailToAddress3;
    }

    public String getMailToAddress4() {
        return MailToAddress4;
    }

    public void setMailToAddress4(String MailToAddress4) {
        this.MailToAddress4 = MailToAddress4;
    }

    public String getMailToAddress5() {
        return MailToAddress5;
    }

    public void setMailToAddress5(String MailToAddress5) {
        this.MailToAddress5 = MailToAddress5;
    }

    public String getMailToAddress6() {
        return MailToAddress6;
    }

    public void setMailToAddress6(String MailToAddress6) {
        this.MailToAddress6 = MailToAddress6;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        Subcategory subCatEnum;
        if (subCategory == null || subCategory.isEmpty()) {
            subCatEnum = Subcategory.OTHER;
            this.subCategory = subCatEnum.getSubCat();
        } else {
            try {
                subCatEnum = Subcategory.valueOf(subCategory);
            } catch (Exception e) {
                subCatEnum = Subcategory.OTHER;
            }
            this.subCategory = subCatEnum.getSubCat();
        }
        this.setFilePath(subCatEnum.getFilePath());
    }

    public enum ErrorMsg implements ErrorMessage {

        u_prov_tin(12, "Missing or invalid data: u_prov_tin"),
        u_orig_creation_date(12, "Missing or invalid data: u_orig_creation_date"),
        u_mpin(12, "Missing or invalid data: u_mpin"),
        emailAlertReq(12, "Missing or invalid data: emailAlertReq"),
        u_clm_nbr(12, "Missing or invalid data: u_clm_nbr"),
        PassThruData(22, "Missing or invalid data: PassThruData (SEVERE)"),
        originalPrintTrail(22, "Missing or invalid data: originalPrintTrail (SEVERE)"),
        CONFIGKEY(22, "Missing or invalid data: CONFIGKEY (SEVERE)"),
        u_prov_nm(22, "Missing or invalid data: MailToAddress1 (SEVERE)"),
        u_adr1(22, "Missing or invalid data: MailToAddress2 (SEVERE)"),
        MailToAddress3(22, "Missing or invalid data: MailToAddress3 (SEVERE)"),
        u_cty(22, "Missing or invalid data: MailToAddress4 (SEVERE)"),
        u_st(22, "Missing or invalid data: MailToAddress5 (SEVERE)"),
        u_zip(22, "Missing or invalid data: MailToAddress6 (SEVERE)"),
        subCategory(12, "Missing or invalid data: subCategory");

        private final int errorCode;
        private final String errorMessage;

        ErrorMsg(int code, String message) {
            this.errorCode = code;
            this.errorMessage = message;
        }

        public int getErrorCode() {
            return errorCode;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }

    public enum Subcategory {

        C1("C1", "Medicare Letters/Action Required"),
        C3("C3", "Medicare Letters/Denials"),
        C4("C4", "Medicare Letters/Please Review (FYI)"),
        C6("C6", "Medicare Letters/Claim Reconsideration"),
        C7("C7", "Medicare Letters/Approvals"),
        C8("C8", "Medicare Letters/Copy of Members Letters"),
        C9("C9", "Medicare Letters/Review Decision"),
        OTHER("CC", "Medicare Letters/Other");

        private final String subCat;
        private final String filePath;

        Subcategory(String subCat, String filePath) {
            this.subCat = subCat;
            this.filePath = filePath;
        }

        public String getSubCat() {
            return subCat;
        }

        public String getFilePath() {
            return filePath;
        }
    }
}

