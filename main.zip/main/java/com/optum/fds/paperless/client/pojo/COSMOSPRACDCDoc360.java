package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;
import com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;
import java.util.stream.Collectors;

public class COSMOSPRACDCDoc360 extends ClientMetadata {

    private static final ObjectMapper LOCAL_MAPPER = new ObjectMapper();
	private static final long serialVersionUID = -797273316412247184L;
	@JsonProperty("tin")
	@JsonAlias("u_tin")
	private String tin;

	@JsonProperty("mpin")
	@JsonAlias("u_prov_mpin")
	private String mpin = "";

	@JsonProperty("emailAlertReq")
	@JsonAlias("u_email_alert_req")
	private String emailAlertReq = "Y";

	@JsonProperty("CheckTraceNumber")
	@JsonAlias("u_check_nbr")
	private String CheckTraceNumber;

	@JsonProperty("physicianName")
	@JsonAlias("u_phy_nm")
	private String physicianName;

	@JsonProperty("EFT_Ind")
    @JsonAlias("u_eft_ind")
	private String EFT_Ind;

	@JsonProperty("ind_835")
    @JsonAlias("u_835_ind")
	private String ind_835;

	@JsonProperty("PTRS")
    @JsonAlias("u_ptrs")
	private String PTRS;

	@JsonProperty("DIV")
    @JsonAlias("u_div")
	private String DIV;

	@JsonProperty("multClaimNumber")
	@JsonAlias("u_claim_nbr")
	private String multClaimNumber;

    @JsonProperty("multPatientAccountNumber")
    @JsonAlias("u_ptnt_acct_nbr")
    private String multPatientAccountNumber;

    @JsonProperty("multMemberId")
    @JsonAlias("u_mbr_id")
    private String multMemberId;

	@JsonProperty("DefaultUsed")
	private String DefaultUsed;

	@JsonProperty("CheckAmt")
    @JsonAlias("u_chk_amt")
	private String CheckAmt;

	@JsonProperty("CONFIGKEY")
    @JsonAlias("u_config_key")
	private String CONFIGKEY;

	@JsonProperty("originalPrintTrail")
    @JsonAlias("u_trl_id")
	private String originalPrintTrail;

	@JsonProperty("PassThruData")
    @JsonAlias("u_pass_thru_data")
	private String PassThruData;

	@JsonProperty("MailToAddress1")
    @JsonAlias("u_mailing_adr1")
	private String MailToAddress1;

	@JsonProperty("MailToAddress2")
    @JsonAlias("u_mailing_adr2")
	private String MailToAddress2;

	@JsonProperty("MailToAddress3")
    @JsonAlias("u_mailing_adr3")
	private String MailToAddress3;

	@JsonProperty("MailToAddress4")
    @JsonAlias("u_mailing_adr4")
	private String MailToAddress4;

	@JsonProperty("MailToAddress5")
    @JsonAlias("u_mailing_adr5")
	private String MailToAddress5;

	@JsonProperty("MailToAddress6")
    @JsonAlias("u_mailing_adr6")
	private String MailToAddress6;

	@JsonProperty("subCategory")
    @JsonAlias("u_sub_category")
	protected String subCategory;

	@JsonProperty("paymentNumber")
	@JsonAlias("vendor_pay_id")
	private String paymentNumber;

    @JsonProperty("u_checkbox")
    private String checkBox;

    @JsonProperty("u_check_dt")
    private String checkDate;

    @JsonProperty("u_compound_doc")
    private String compoundDoc;

    @JsonProperty("u_compound_seq")
    private String compoundSeq;

    @JsonProperty("u_gbl_doc_id")
    private String gblDocId;

    @JsonProperty("u_legal_case_id")
    private String legalCaseId;

    @JsonProperty("u_legal_hold")
    private String legalHold;

    @JsonProperty("u_pay_type")
    private String payType;

    @JsonProperty("u_provider_nbr")
    private String providerNumber;

    @JsonProperty("npi")
    @JsonAlias("u_npi")
    private String npi;

	private boolean addedToCosmosPraResponseFile;

	private boolean merged;

	private String PTRS_FIFTEEN;

	public COSMOSPRACDCDoc360() {
		this.tenant = "Link";
		this.category = "Payment Document";
		this.fileDescription = "Payment Document";
		this.fileType = "Letter";
		this.privilege = "Claim Status";
		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.providerEmailId = "";
		this.postCardInd = true;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.addedToCosmosPraResponseFile = false;
		this.merged = false;
		this.subCategory = "PR";
		this.createApplication = "CheckWrite";
		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		if (mpin != null) {
			this.mpin = mpin;
		}
	}

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()) {
			this.emailAlertReq = emailAlertReq;
		}
	}

	public String getPhysicianName() {
		return physicianName;
	}

	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}

	public String getEFT_Ind() {
		return EFT_Ind;
	}

	public void setEFT_Ind(String eFT_Ind) {
		EFT_Ind = eFT_Ind;
	}

	public String getInd_835() {
		return ind_835;
	}

	public void setInd_835(String ind_835) {
		this.ind_835 = ind_835;
	}

	public String getPTRS() {
		return PTRS;
	}

	public void setPTRS(String pTRS) {
		PTRS = pTRS;
	}

	public String getDIV() {
		return DIV;
	}

	public void setDIV(String dIV) {
		DIV = dIV;
	}

	public String getMultClaimNumber() {
		return multClaimNumber;
	}

    public String getMultMemberId() {
        return multMemberId;
    }

    public String getMultPatientAccountNumber() { return multPatientAccountNumber; }

    public String getProviderNumber(){return providerNumber;}

    public String getNpi(){return npi;}

    public void setMultClaimNumber(Object raw) {
        this.multClaimNumber = NormalizeUtil.normalizePipeDelimitedValue(raw);
    }

    public void setMultMemberId(Object raw) {
        this.multMemberId = NormalizeUtil.normalizePipeDelimitedValue(raw);
    }

    public void setMultPatientAccountNumber(Object raw) {
        this.multPatientAccountNumber = NormalizeUtil.normalizePipeDelimitedValue(raw);
    }

	public String getDefaultUsed() {
		return DefaultUsed;
	}

	public void setDefaultUsed(String defaultUsed) {
		DefaultUsed = defaultUsed;
	}

	public String getCheckAmt() {
		return CheckAmt;
	}

	public void setCheckAmt(String checkAmt) {
		CheckAmt = checkAmt;
	}

	public String getCONFIGKEY() {
		return CONFIGKEY;
	}

	public void setCONFIGKEY(String cONFIGKEY) {
		CONFIGKEY = cONFIGKEY;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getPassThruData() {
		return PassThruData;
	}

	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}

	public String getMailToAddress1() {
		return MailToAddress1;
	}

	public void setMailToAddress1(String mailToAddress1) {
		MailToAddress1 = mailToAddress1;
	}

	public String getMailToAddress2() {
		return MailToAddress2;
	}

	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}

	public String getMailToAddress3() {
		return MailToAddress3;
	}

	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}

	public String getMailToAddress4() {
		return MailToAddress4;
	}

	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}

	public String getMailToAddress5() {
		return MailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return MailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}

	public String getSubCategory() {
		return subCategory;
	}
	
	public String getPaymentNumber() {
		return paymentNumber;
	}
	
	public void setPaymentNumber(String paymentNumber) {
		this.paymentNumber = paymentNumber;
	}

	public String getPTRS_FIFTEEN() {
		return PTRS_FIFTEEN;
	}

	public void setPTRS_FIFTEEN(String pTRS_FIFTEEN) {
		PTRS_FIFTEEN = pTRS_FIFTEEN;
	}

    public String getCheckBox() {
        return checkBox;
    }

    public void setCheckBox(String checkBox) {
        this.checkBox = checkBox;
    }

    public String getCheckDate() {
        return checkDate;
    }

    public void setCheckDate(String checkDate) {
        this.checkDate = checkDate;
    }

    public String getCompoundDoc() {
        return compoundDoc;
    }

    public void setCompoundDoc(String compoundDoc) {
        this.compoundDoc = compoundDoc;
    }

    public String getCompoundSeq() {
        return compoundSeq;
    }

    public void setCompoundSeq(String compoundSeq) {
        this.compoundSeq = compoundSeq;
    }

    public String getGblDocId() {
        return gblDocId;
    }

    public void setGblDocId(String gblDocId) {
        this.gblDocId = gblDocId;
    }

    public String getLegalCaseId() {
        return legalCaseId;
    }

    public void setLegalCaseId(String legalCaseId) {
        this.legalCaseId = legalCaseId;
    }

    public String getLegalHold() {
        return legalHold;
    }

    public void setLegalHold(String legalHold) {
        this.legalHold = legalHold;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public boolean isAddedToCosmosPraResponseFile() {
		return addedToCosmosPraResponseFile;
	}

	public void setAddedToCosmosPraResponseFile(boolean addedToCosmosPraResponseFile) {
		this.addedToCosmosPraResponseFile = addedToCosmosPraResponseFile;
	}

	public boolean isMerged() {
		return merged;
	}

	public void setMerged(boolean merged) {
		this.merged = merged;
	}

    public void setProviderNumber(String providerNumber) {this.providerNumber = providerNumber; }

    public void setNpi(String npi) {this.npi = npi; }

	public void setSubCategory(String subCategory) {
		if (subCategory == null || subCategory.isEmpty()) {
			this.subCategory = "PR";
			this.setFilePath(Subcategory.PR.getFilePath());
		} else {
			this.subCategory = subCategory;
			Subcategory subCat = null;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.PR;
			}
			this.setFilePath(subCat.getFilePath());
		}

		if (PTRS != null && subCategory != null && !subCategory.isEmpty() && PTRS.length() > 15) {
			this.setPTRS_FIFTEEN(StringUtils.left(PTRS, 15));
		} else {
			this.setPTRS_FIFTEEN(PTRS);
		}

		if (this.getExpiryDate() != null && this.getExpiryDate().length() == 7) {
			this.setExpiryDate(this.vcpExpiryDateFormat(this.getExpiryDate(), this.subCategory));
		}

	}

	public String getCheckTraceNumber() {
		return CheckTraceNumber;
	}

	public void setCheckTraceNumber(String checkTraceNumber) {
		CheckTraceNumber = checkTraceNumber;
	}

	public enum ErrorMsg implements ErrorMessage {
		u_tin(12, "Missing or invalid data: u_tin"), // EFT_Ind==\"Y\"
        u_prov_mpin(12, "Missing or invalid data: u_prov_mpin"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
        u_check_nbr(12, "Missing or invalid data: u_check_nbr"), // EFT_Ind==\"N\" && subCategory != \"P4\"
        u_claim_nbr(12, "Missing or invalid data: u_claim_nbr"),
        u_sub_category(12, "Missing or invalid data: u_sub_category"), // EFT_Ind==\"N\"
        u_email_alert_req(12, "Missing or invalid data: u_email_alert_req"),
        u_doc_creation_dt(12, "Missing or invalid data: u_doc_creation_dt"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"

        u_config_key(22, "Missing or invalid data: u_config_key(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
        u_trl_id(22, "Missing or invalid data: u_trl_id(SEVERE)"), // EFT_Ind==\"N\" &&// emailAlertReq!=\"N\"
        u_pass_thru_data(22, "Missing or invalid data: u_pass_thru_data(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
        u_mailing_adr1(22, "Missing or invalid data: u_mailing_adr1(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
        u_mailing_adr2(22, "Missing or invalid data: u_mailing_adr2(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
        u_eft_ind(22, "Missing or invalid data: u_eft_ind(SEVERE)");

		private int errorCode;
		private String errorMessage;

		ErrorMsg(int code, String message) {
			this.errorCode = code;
			this.errorMessage = message;
		}

		@Override
		public int getErrorCode() {
			return errorCode;
		}

		@Override
		public String getErrorMessage() {
			return errorMessage;
		}

	}

	public enum Subcategory {
		P3("P3", "Medicare/Detailed PRAs"), P4("P4", "Medicare/Virtual Card Payments and Info Only PRAs"),
		P8("P8", "Commercial/Zero-Dollar PRAs"), P9("P9", "Medicare/Zero-Dollar PRAs"),
		P0("P0", "Community Plan/Zero-Dollar PRAs"), E1("E1", "Other/Zero-Dollar PRAs"), PR("PR", "Other PRAs/Other");

		private String subCat;
		private String filePath;

		Subcategory(String subCat, String filePath) {
			this.subCat = subCat;
			this.filePath = filePath;
		}

		public String getSubCat() {
			return subCat;
		}

		public String getFilePath() {
			return filePath;
		}
	}

}
