package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;
import java.util.stream.Collectors;

public class COSMOSPRACDCDoc360 extends ClientMetadata {

    private static final ObjectMapper LOCAL_MAPPER = new ObjectMapper();
	private static final long serialVersionUID = -797273316412247184L;
	@JsonProperty("TIN")
	@JsonAlias("u_tin")
	private String tin;

	@JsonProperty("ProviderMPIN")
	@JsonAlias("mpin")
	private String mpin = "";

	@JsonProperty("isPrintSuppressed")
	@JsonAlias("emailAlertReq")
	private String emailAlertReq = "Y";

	@JsonProperty("CHECKNUMBER")
	@JsonAlias("u_check_nbr")
	private String CheckTraceNumber;

	@JsonProperty("physicianName")
	@JsonAlias("PHYSICIANNAME")
	private String physicianName;

	@JsonProperty("EFT_Ind")
	private String EFT_Ind;

	@JsonProperty("835_Ind")
	private String ind_835;

	@JsonProperty("PTRS")
    @JsonAlias("u_ptrs")
	private String PTRS;

	@JsonProperty("DIV")
    @JsonAlias("u_div")
	private String DIV;

	@JsonProperty("CLAIMNUMBER")
	@JsonAlias("u_claim_nbr")
	private String multClaimNumber;

    @JsonProperty("patientAccountNumber")
    private String multPatientAccountNumber;

    @JsonProperty("memberId")
    private String multMemberId;

	@JsonProperty("DefaultUsed")
	private String DefaultUsed;

	@JsonProperty("CheckAmt")
	private String CheckAmt;

	@JsonProperty("CONFIGKEY")
	private String CONFIGKEY;

	@JsonProperty("originalPrintTrail")
	private String originalPrintTrail;

	@JsonProperty("PassThruData")
	private String PassThruData;

	@JsonProperty("MailToAddress1")
	private String MailToAddress1;

	@JsonProperty("MailToAddress2")
	private String MailToAddress2;

	@JsonProperty("MailToAddress3")
	private String MailToAddress3;

	@JsonProperty("MailToAddress4")
	private String MailToAddress4;

	@JsonProperty("MailToAddress5")
	private String MailToAddress5;

	@JsonProperty("MailToAddress6")
	private String MailToAddress6;

	@JsonAlias("subCategory")
	@JsonProperty("SubCategory")
	protected String subCategory;

	@JsonProperty("paymentNumber")
	@JsonAlias("vendor_pay_id")
	private String paymentNumber;

    @JsonProperty("u_checkbox")
    private String checkBox;

    @JsonProperty("u_check_dt")
    private String checkDate;

    @JsonProperty("u_compound_doc")
    private String compoundDoc;

    @JsonProperty("u_compound_seq")
    private String compoundSeq;

    @JsonProperty("u_gbl_doc_id")
    private String gblDocId;

    @JsonProperty("u_legal_case_id")
    private String legalCaseId;

    @JsonProperty("u_legal_hold")
    private String legalHold;

    @JsonProperty("u_pay_type")
    private String payType;

    @JsonProperty("u_orig_creation_date")
    private String origCreationDate;

	private boolean addedToCosmosPraResponseFile;

	private boolean merged;

	private String PTRS_FIFTEEN;

	public COSMOSPRACDCDoc360() {
		this.tenant = "Link";
		this.category = "Payment Document";
		this.fileDescription = "Payment Document";
		this.fileType = "Letter";
		this.privilege = "Claim Status";
		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.providerEmailId = "";
		this.postCardInd = true;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.addedToCosmosPraResponseFile = false;
		this.merged = false;
		this.subCategory = "PR";
		this.createApplication = "CheckWrite";
		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		if (mpin != null) {
			this.mpin = mpin;
		}
	}

	public String getEmailAlertReq() {
		return emailAlertReq;
	}

	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()) {
			this.emailAlertReq = emailAlertReq;
		}
	}

	public String getPhysicianName() {
		return physicianName;
	}

	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}

	public String getEFT_Ind() {
		return EFT_Ind;
	}

	public void setEFT_Ind(String eFT_Ind) {
		EFT_Ind = eFT_Ind;
	}

	public String getInd_835() {
		return ind_835;
	}

	public void setInd_835(String ind_835) {
		this.ind_835 = ind_835;
	}

	public String getPTRS() {
		return PTRS;
	}

	public void setPTRS(String pTRS) {
		PTRS = pTRS;
	}

	public String getDIV() {
		return DIV;
	}

	public void setDIV(String dIV) {
		DIV = dIV;
	}

	public String getMultClaimNumber() {
		return multClaimNumber;
	}

    public String getMultMemberId() {
        return multMemberId;
    }

    public String getMultPatientAccountNumber() { return multPatientAccountNumber; }

    @JsonSetter("CLAIMNUMBER")
    @JsonAlias("u_claim_nbr")
    public void setMultClaimNumber(Object raw) {
        this.multClaimNumber = normalizePipeDelimitedValue(raw);
    }

    @JsonSetter("memberId")
    public void setMultMemberId(Object raw) {
        this.multMemberId = normalizePipeDelimitedValue(raw);
    }


    @JsonSetter("patientAccountNumber")
    public void setMultPatientAccountNumber(Object raw) {
        this.multPatientAccountNumber = normalizePipeDelimitedValue(raw);
    }


    protected String normalizePipeDelimitedValue(Object raw) {
        if (raw == null) {
            return null;
        }

        if (raw instanceof Collection<?> col) {
            return col.stream()
                    .filter(Objects::nonNull)
                    .map(String::valueOf)
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.joining("|"));
        }

        if (raw instanceof String s && !s.isBlank()) {
            String trimmed = s.trim();

            if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
                String inner = trimmed.substring(1, trimmed.length() - 1).trim();

                // 1) Try real JSON array first: ["a","b"]
                try {
                    Collection<String> parsed = LOCAL_MAPPER.readValue(
                            trimmed, new TypeReference<Collection<String>>() {});
                    return parsed.stream()
                            .filter(Objects::nonNull)
                            .map(String::trim)
                            .filter(v -> !v.isEmpty())
                            .collect(Collectors.joining("|"));
                } catch (Exception ignored) {
                    // 2) Fallback for non-JSON bracketed strings like:
                    // [1000000005183680, 1000000005184807, ...]
                    // or [T8749958]
                    return Arrays.stream(inner.split("\\s*,\\s*"))
                            .map(part -> part.replaceAll("^\"|\"$", "").trim())
                            .filter(part -> !part.isEmpty())
                            .collect(Collectors.joining("|"));
                }
            }

            return trimmed;
        }

        return String.valueOf(raw);
    }

	public String getDefaultUsed() {
		return DefaultUsed;
	}

	public void setDefaultUsed(String defaultUsed) {
		DefaultUsed = defaultUsed;
	}

	public String getCheckAmt() {
		return CheckAmt;
	}

	public void setCheckAmt(String checkAmt) {
		CheckAmt = checkAmt;
	}

	public String getCONFIGKEY() {
		return CONFIGKEY;
	}

	public void setCONFIGKEY(String cONFIGKEY) {
		CONFIGKEY = cONFIGKEY;
	}

	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}

	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}

	public String getPassThruData() {
		return PassThruData;
	}

	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}

	public String getMailToAddress1() {
		return MailToAddress1;
	}

	public void setMailToAddress1(String mailToAddress1) {
		MailToAddress1 = mailToAddress1;
	}

	public String getMailToAddress2() {
		return MailToAddress2;
	}

	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}

	public String getMailToAddress3() {
		return MailToAddress3;
	}

	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}

	public String getMailToAddress4() {
		return MailToAddress4;
	}

	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}

	public String getMailToAddress5() {
		return MailToAddress5;
	}

	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}

	public String getMailToAddress6() {
		return MailToAddress6;
	}

	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}

	public String getSubCategory() {
		return subCategory;
	}
	
	public String getPaymentNumber() {
		return paymentNumber;
	}
	
	public void setPaymentNumber(String paymentNumber) {
		this.paymentNumber = paymentNumber;
	}

	public String getPTRS_FIFTEEN() {
		return PTRS_FIFTEEN;
	}

	public void setPTRS_FIFTEEN(String pTRS_FIFTEEN) {
		PTRS_FIFTEEN = pTRS_FIFTEEN;
	}

    public String getCheckBox() {
        return checkBox;
    }

    public void setCheckBox(String checkBox) {
        this.checkBox = checkBox;
    }

    public String getCheckDate() {
        return checkDate;
    }

    public void setCheckDate(String checkDate) {
        this.checkDate = checkDate;
    }

    public String getCompoundDoc() {
        return compoundDoc;
    }

    public void setCompoundDoc(String compoundDoc) {
        this.compoundDoc = compoundDoc;
    }

    public String getCompoundSeq() {
        return compoundSeq;
    }

    public void setCompoundSeq(String compoundSeq) {
        this.compoundSeq = compoundSeq;
    }

    public String getGblDocId() {
        return gblDocId;
    }

    public void setGblDocId(String gblDocId) {
        this.gblDocId = gblDocId;
    }

    public String getLegalCaseId() {
        return legalCaseId;
    }

    public void setLegalCaseId(String legalCaseId) {
        this.legalCaseId = legalCaseId;
    }

    public String getLegalHold() {
        return legalHold;
    }

    public void setLegalHold(String legalHold) {
        this.legalHold = legalHold;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getOrigCreationDate() {
        return origCreationDate;
    }

    public void setOrigCreationDate(String origCreationDate) {
        this.origCreationDate = origCreationDate;
    }

    public boolean isAddedToCosmosPraResponseFile() {
		return addedToCosmosPraResponseFile;
	}

	public void setAddedToCosmosPraResponseFile(boolean addedToCosmosPraResponseFile) {
		this.addedToCosmosPraResponseFile = addedToCosmosPraResponseFile;
	}

	public boolean isMerged() {
		return merged;
	}

	public void setMerged(boolean merged) {
		this.merged = merged;
	}

	public void setSubCategory(String subCategory) {
		if (subCategory == null || subCategory.isEmpty()) {
			this.subCategory = "PR";
			this.setFilePath(Subcategory.PR.getFilePath());
		} else {
			this.subCategory = subCategory;
			Subcategory subCat = null;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.PR;
			}
			this.setFilePath(subCat.getFilePath());
		}

		if (PTRS != null && subCategory != null && !subCategory.isEmpty() && PTRS.length() > 15) {
			this.setPTRS_FIFTEEN(StringUtils.left(PTRS, 15));
		} else {
			this.setPTRS_FIFTEEN(PTRS);
		}

		if (this.getExpiryDate() != null && this.getExpiryDate().length() == 7) {
			this.setExpiryDate(this.vcpExpiryDateFormat(this.getExpiryDate(), this.subCategory));
		}

	}

	public String getCheckTraceNumber() {
		return CheckTraceNumber;
	}

	public void setCheckTraceNumber(String checkTraceNumber) {
		CheckTraceNumber = checkTraceNumber;
	}

	public enum ErrorMsg implements ErrorMessage {
		u_tin(12, "Missing or invalid data: u_tin"), // EFT_Ind==\"Y\"
        ProviderMPIN(12, "Missing or invalid data: ProviderMPIN"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
        SubCategory(12, "Missing or invalid data: SubCategory"), // EFT_Ind==\"N\"
        isPrintSuppressed(12, "Missing or invalid data: isPrintSuppressed"),
        u_check_dt(12, "Missing or invalid data: u_check_dt"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"

		CONFIGKEY(22, "Missing or invalid data: CONFIGKEY(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
        originalPrintTrail(22, "Missing or invalid data: originalPrintTrail(SEVERE)"), // EFT_Ind==\"N\" &&
																						// emailAlertReq!=\"N\"
        PassThruData(22, "Missing or invalid data: PassThruData(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"

        MailToAddress1(22, "Missing or invalid data: MailToAddress1(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
        MailToAddress2(22, "Missing or invalid data: MailToAddress2(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"
        MailToAddress3(22, "Missing or invalid data: MailToAddress3(SEVERE)"), // EFT_Ind==\"N\" && emailAlertReq!=\"N\"

        u_check_nbr(12, "Missing or invalid data: u_check_nbr"), // EFT_Ind==\"N\" && subCategory != \"P4\"
        EFT_Ind(22, "Missing or invalid data: EFT_Ind(SEVERE)"),
        u_claim_nbr(12, "Missing or invalid data: u_claim_nbr");

		private int errorCode;
		private String errorMessage;

		ErrorMsg(int code, String message) {
			this.errorCode = code;
			this.errorMessage = message;
		}

		@Override
		public int getErrorCode() {
			return errorCode;
		}

		@Override
		public String getErrorMessage() {
			return errorMessage;
		}

	}

	public enum Subcategory {
		P3("P3", "Medicare/Detailed PRAs"), P4("P4", "Medicare/Virtual Card Payments and Info Only PRAs"),
		P8("P8", "Commercial/Zero-Dollar PRAs"), P9("P9", "Medicare/Zero-Dollar PRAs"),
		P0("P0", "Community Plan/Zero-Dollar PRAs"), E1("E1", "Other/Zero-Dollar PRAs"), PR("PR", "Other PRAs/Other");

		private String subCat;
		private String filePath;

		Subcategory(String subCat, String filePath) {
			this.subCat = subCat;
			this.filePath = filePath;
		}

		public String getSubCat() {
			return subCat;
		}

		public String getFilePath() {
			return filePath;
		}
	}

}
