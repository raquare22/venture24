package com.optum.fds.paperless.client;

public interface ErrorMessage {
	int getErrorCode();
	String getErrorMessage();
}
