package com.optum.fds.paperless.client.pojo;


import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

public class ODAR extends ClientMetadata {
	
	private static final long serialVersionUID = 7491350014803217820L;

	@JsonProperty("tin")
	@JsonAlias("TIN")
	private String tin;
	
	@JsonProperty("mpin")
	private String mpin="";
	
	@JsonProperty("emailAlertReq")
	@JsonAlias("isPrintSuppressed")
	private String emailAlertReq="N";
	
	@JsonProperty("multDivisionCode")
	@JsonAlias("divisionCode")
	private String multDivisionCode;
	
	@JsonProperty("patientAccountNumber")
	@JsonAlias("PatAcctNumber")
	private String patientAccountNumber;
	
	@JsonProperty("physicianName")
	@JsonAlias("PHYSICIANNAME")
	private String physicianName;
	
	@JsonProperty("multMemberName")
	@JsonAlias("EMPLOYEENAME")
	private String multMemberName;
	
	@JsonProperty("multCheckNumber")
	@JsonAlias("ChkNumber")
	private String multCheckNumber;
	
	@JsonProperty("letterGroupId")
	private String letterGroupId;
	
	@JsonProperty("multClaimNumber")
	@JsonAlias("ICNNUMBER")
	private String multClaimNumber;
	
	@JsonProperty("source")
	private String source;
	
	@JsonProperty("letterType")
	private String letterType;
	
	@JsonProperty("facilityType")
	private String facilityType;
	
	@JsonProperty("CONFIGKEY")
	@JsonAlias("ConfigKey")
	private String CONFIGKEY;
	
	@JsonProperty("originalPrintTrail")
	private String originalPrintTrail;
	
	@JsonProperty("PassThruData")
	private String PassThruData;
	
	@JsonProperty("MailToAddress1") 
	private String MailToAddress1;
	
	@JsonProperty("MailToAddress2") 
	private String MailToAddress2;
	
	@JsonProperty("MailToAddress3") 
	private String MailToAddress3;
	
	@JsonProperty("MailToAddress4") 
	private String MailToAddress4;
	
	@JsonProperty("MailToAddress5") 
	private String MailToAddress5;
	
	@JsonProperty("MailToAddress6") 
	private String MailToAddress6;
	
	@JsonProperty("ReturnAddress1")
	private String ReturnAddress1;
	
	@JsonProperty("ReturnAddress2") 
	private String ReturnAddress2;
	
	@JsonProperty("ReturnAddress3") 
	private String ReturnAddress3;
	
	@JsonProperty("ReturnAddress4") 
	private String ReturnAddress4;
	
	@JsonProperty("ReturnAddress5") 
	private String ReturnAddress5;
	
	@JsonProperty("ReturnAddress6") 
	private String ReturnAddress6;
	
	@JsonAlias("SubCategory")
	@JsonProperty("subCategory")
	protected String subCategory;
	
	
	public ODAR() {
		this.category = "Overpayment Documents";
		this.fileType = "Letter";
		this.tenant = "Link";
		this.fileDescription = "Overpayment Document";
		this.createApplication = "ODAR";
		this.docSentTo = "";
		this.sendToDocVault = false;
		this.sendToShutterfly = false;
		this.providerEmailId = "";
		this.postCardInd = true;
		this.dateEmailSent = null;
		this.sendEmailNotifications = false;
		this.sendPENAPIRequest = false;
		this.subCategory = "OP";
		this.privilege = "Claim Status";
		Subcategory subCat = Subcategory.valueOf(this.subCategory);
		this.setFilePath(subCat.getFilePath());
	}
	
	public String getTin() {
		return tin;
	}
	public void setTin(String tin) {
		this.tin = tin;
	}
	public String getMpin() {
		return mpin;
	}
	public void setMpin(String mpin) {
		if (mpin != null){
			this.mpin = mpin;
		}
	}
	public String getEmailAlertReq() {
		return emailAlertReq;
	}
	public void setEmailAlertReq(String emailAlertReq) {
		if (emailAlertReq != null && !emailAlertReq.isEmpty()){
			this.emailAlertReq = emailAlertReq;
		}
	}
	public String getMultDivisionCode() {
		return multDivisionCode;
	}
	public void setMultDivisionCode(String multDivisionCode) {
		this.multDivisionCode = multDivisionCode;
	}

	private String getPatientAccountNumber() {
		return patientAccountNumber;
	}

	private void setPatientAccountNumber(String patientAccountNumber) {
		this.patientAccountNumber = patientAccountNumber;
	}
	
	public String getPhysicianName() {
		return physicianName;
	}
	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}
	public String getMultMemberName() {
		return multMemberName;
	}
	public void setMultMemberName(String multMemberName) {
		this.multMemberName = multMemberName;
	}
	public String getMultCheckNumber() {
		return multCheckNumber;
	}
	public void setMultCheckNumber(String multCheckNumber) {
		this.multCheckNumber = multCheckNumber;
	}
	public String getLetterGroupId() {
		return letterGroupId;
	}
	public void setLetterGroupId(String letterGroupId) {
		this.letterGroupId = letterGroupId;
	}
	public String getMultClaimNumber() {
		return multClaimNumber;
	}
	public void setMultClaimNumber(String multClaimNumber) {
		this.multClaimNumber = multClaimNumber;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getLetterType() {
		return letterType;
	}
	public void setLetterType(String letterType) {
		this.letterType = letterType;
	}
	public String getFacilityType() {
		return facilityType;
	}
	public void setFacilityType(String facilityType) {
		this.facilityType = facilityType;
	}
	public String getCONFIGKEY() {
		return CONFIGKEY;
	}
	public void setCONFIGKEY(String cONFIGKEY) {
		CONFIGKEY = cONFIGKEY;
	}
	public String getOriginalPrintTrail() {
		return originalPrintTrail;
	}
	public void setOriginalPrintTrail(String originalPrintTrail) {
		this.originalPrintTrail = originalPrintTrail;
	}
	public String getPassThruData() {
		return PassThruData;
	}
	public void setPassThruData(String passThruData) {
		PassThruData = passThruData;
	}
	public String getMailToAddress1() {
		return MailToAddress1;
	}
	public void setMailToAddress1(String mailToAddress1) {
		MailToAddress1 = mailToAddress1;
	}
	public String getMailToAddress2() {
		return MailToAddress2;
	}
	public void setMailToAddress2(String mailToAddress2) {
		MailToAddress2 = mailToAddress2;
	}
	public String getMailToAddress3() {
		return MailToAddress3;
	}
	public void setMailToAddress3(String mailToAddress3) {
		MailToAddress3 = mailToAddress3;
	}
	public String getMailToAddress4() {
		return MailToAddress4;
	}
	public void setMailToAddress4(String mailToAddress4) {
		MailToAddress4 = mailToAddress4;
	}
	public String getMailToAddress5() {
		return MailToAddress5;
	}
	public void setMailToAddress5(String mailToAddress5) {
		MailToAddress5 = mailToAddress5;
	}
	public String getMailToAddress6() {
		return MailToAddress6;
	}
	public void setMailToAddress6(String mailToAddress6) {
		MailToAddress6 = mailToAddress6;
	}
	public String getReturnAddress1() {
		return ReturnAddress1;
	}
	public void setReturnAddress1(String returnAddress1) {
		ReturnAddress1 = returnAddress1;
	}
	public String getReturnAddress2() {
		return ReturnAddress2;
	}
	public void setReturnAddress2(String returnAddress2) {
		ReturnAddress2 = returnAddress2;
	}
	public String getReturnAddress3() {
		return ReturnAddress3;
	}
	public void setReturnAddress3(String returnAddress3) {
		ReturnAddress3 = returnAddress3;
	}
	public String getReturnAddress4() {
		return ReturnAddress4;
	}
	public void setReturnAddress4(String returnAddress4) {
		ReturnAddress4 = returnAddress4;
	}
	public String getReturnAddress5() {
		return ReturnAddress5;
	}
	public void setReturnAddress5(String returnAddress5) {
		ReturnAddress5 = returnAddress5;
	}
	public String getReturnAddress6() {
		return ReturnAddress6;
	}
	public void setReturnAddress6(String returnAddress6) {
		ReturnAddress6 = returnAddress6;
	}
	public String getSubCategory() {
		return subCategory;
	}
	public void setSubCategory(String subCategory) {
		if(subCategory == null || subCategory.isEmpty()){
			this.subCategory = "OP";
			this.setFilePath(Subcategory.OP.getFilePath());
		} else {
			this.subCategory = subCategory;
			Subcategory subCat = null;
			try {
				subCat = Subcategory.valueOf(this.subCategory);
			} catch (Exception e) {
				subCat = Subcategory.OP;
			}
			this.setFilePath(subCat.getFilePath());
		}
	}

	public enum ErrorMsg implements ErrorMessage {
		TIN (12, "Missing or invalid data: TIN"), //verify
		mpin (12, "Missing or invalid data: mpin"), // emailAlertReq==\"Y\"
		SubCategory (12, "Missing or invalid data: SubCategory"),
		isPrintSuppressed (12,"Missing or invalid data: isPrintSuppressed"),
		createdDate (12, "Missing or invalid data: createdDate"),

		CONFIGKEY (22, "Missing or invalid data: CONFIGKEY(SEVERE)"), // emailAlertReq==\"Y\"
		originalPrintTrail (22, "Missing or invalid data: originalPrintTrail(SEVERE)"), // emailAlertReq==\"Y\"
		PassThruData (12, "Missing or invalid data: PassThruData"), // emailAlertReq==\"Y\"

		MailToAddress1 (22, "Missing or invalid data: MailToAddress1(SEVERE)"), // emailAlertReq==\"Y\"
		MailToAddress2 (22, "Missing or invalid data: MailToAddress2(SEVERE)"), // emailAlertReq==\"Y\"
		MailToAddress4 (22, "Missing or invalid data: MailToAddress4(SEVERE)"), // emailAlertReq==\"Y\"
		
		letterGroupId (12, "Missing or invalid data: letterGroupId"),
		ICNNUMBER (12, "Missing or invalid data: ICNNUMBER"),
		source (12, "Missing or invalid data: source"),
		letterType (12, "Missing or invalid data: letterType"),
		facilityType (12, "Missing or invalid data: facilityType");
		
		
		private int errorCode;
	    private String errorMessage;

	    ErrorMsg(int code, String message) {
	        this.errorCode = code;
	        this.errorMessage = message;
	    }

	    public int getErrorCode() {
	        return errorCode;
	    }
	    public String getErrorMessage() {
	        return errorMessage;
	    }
	}
	
	public enum Subcategory {
		// ODAR
		C5 ("C5", "Commercial Overpayment Letters/Overpayment Identified"),
		O1 ("O1", "Commercial Overpayment Letters/Overpayment Reconsideration Requests"),
		O2 ("O2", "Commercial Overpayment Letters/Overpayment Reconsideration Responses"),
		R4 ("R4", "Medicare Overpayment Letters/Overpayment Identified"),
		R5 ("R5", "Medicare Overpayment Letters/Overpayment Reconsideration Requests"),
		R6 ("R6", "Medicare Overpayment Letters/Overpayment Reconsideration Responses"),
		S3 ("S3", "Community Plan Overpayment Letters/Overpayment Identified"),
		S4 ("S4", "Community Plan Overpayment Letters/Overpayment Reconsideration Requests"),
		S5 ("S5", "Community Plan Overpayment Letters/Overpayment Reconsideration Responses"),
		W4 ("W4", "UHC West Overpayment Letters/Overpayment Identified"),
		W5 ("W5", "UHC West Overpayment Letters/Overpayment Reconsideration Requests"),
		W6 ("W6", "UHC West Overpayment Letters/Overpayment Reconsideration Responses"),
		OP ("OP", "Other Overpayment Letters/Other Overpayment Letters");
		
		private String subCat;
		private String filePath;
		
		Subcategory(String subCat, String filePath){
			this.subCat = subCat;
			this.filePath = filePath;
		}
		public String getSubCat() {
	        return subCat;
	    }
		
		public String getFilePath() {
			return filePath;
		}
	}
	
}

