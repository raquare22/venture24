package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

import java.io.Serial;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class PaymentSummary extends ClientMetadata {

    @Serial
    private static final long serialVersionUID = 7841029384756120498L;
    private static final ObjectMapper LOCAL_MAPPER = new ObjectMapper();
    private static final String CATEGORY = "Payment Documents";
    private static final String CREATE_APPLICATION = "PmntEng";
    private static final String PRIVILEGE = "Claim Status";
    private static final String SOURCE = "PRUN";

    @JsonProperty("tin")
    @JsonAlias("u_tax_id")
    private String tin;

    @JsonProperty("paymentDate")
    @JsonAlias("u_payment_summary_dt")
    private String paymentDate;

    @JsonProperty("paymentType")
    @JsonAlias("u_payment_typ")
    private String paymentType;

    @JsonProperty("paymentNumber")
    @JsonAlias("u_payment_nbr")
    private String paymentNumber;

    @JsonProperty("source")
    private String source;

    @JsonProperty("emailAlertReq")
    private String emailAlertReq="N";


    public PaymentSummary(){
        this.category = CATEGORY;
        this.createApplication = CREATE_APPLICATION;
        this.privilege = PRIVILEGE;
        this.source = SOURCE;
        this.emailAlertReq="N";
        // Routing flags
        this.sendToDocVault = false;


    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        this.emailAlertReq = emailAlertReq;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        Objects.requireNonNull(paymentType, "paymentType must not be null");
        if(paymentType.isBlank()){
            throw new IllegalArgumentException("paymentType must not be blank");
        }
        this.paymentType = paymentType;
        this.setFilePath(PaymentTypeFilePath.from(paymentType).getFilePath());
    }

    public String getPaymentNumber() {
        return paymentNumber;
    }

    @JsonSetter("paymentNumber")
    @JsonAlias("u_payment_nbr")
    public void setPaymentNumber(Object raw) {
        this.paymentNumber = normalizePaymentNumber(raw);
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    protected String normalizePaymentNumber(Object raw) {
        // Convert paymentNumber field from List<String> to pipe delimited string
        if (raw == null) {
            return null;
        }

        if (raw instanceof Collection<?> col) {
            return col.stream()
                    .filter(Objects::nonNull)
                    .map(String::valueOf)
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.joining("|"));
        }

        if (raw instanceof String s && !s.isBlank()) {
            String trimmed = s.trim();

            if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
                String inner = trimmed.substring(1, trimmed.length() - 1).trim();

                // 1) Try real JSON array first: ["a","b"]
                try {
                    Collection<String> parsed = LOCAL_MAPPER.readValue(
                            trimmed, new TypeReference<Collection<String>>() {});
                    return parsed.stream()
                            .filter(Objects::nonNull)
                            .map(String::trim)
                            .filter(v -> !v.isEmpty())
                            .collect(Collectors.joining("|"));
                } catch (Exception ignored) {
                    // 2) Fallback for non-JSON bracketed strings like:
                    // [1000000005183680, 1000000005184807, ...]
                    // or [T8749958]
                    return Arrays.stream(inner.split("\\s*,\\s*"))
                            .map(part -> part.replaceAll("^\"|\"$", "").trim())
                            .filter(part -> !part.isEmpty())
                            .collect(Collectors.joining("|"));
                }
            }

            return trimmed;
        }

        return String.valueOf(raw);
    }

    public enum PaymentTypeFilePath {
        DLY("Payment Summary Reports/Daily"),
        MTY("Payment Summary Reports/Monthly");

        private final String filePath;

        PaymentTypeFilePath(String filePath){
            this.filePath=filePath;
        }

        public String getFilePath(){
            return filePath;
        }

        public static PaymentTypeFilePath from(String code){
            try{
                return PaymentTypeFilePath.valueOf(code);
            }catch (IllegalArgumentException e){
                throw new IllegalArgumentException(
                "Unsupported paymentType '" + code + " '.Expected one of " + Arrays.toString(values()),e);
            }
        }

    }


    public enum ErrorMsg implements ErrorMessage {
        u_tax_id (12,"Missing or invalid data: Tax ID"),
        u_payment_summary_dt (12,"Missing or invalid data: Payment Summary Date"),
        u_payment_typ (12,"Missing or invalid data: Payment Type"),
        u_payment_nbr (12,"Missing or invalid data: Payment Number");

        private final int errorCode;
        private final String errorMessage;

        ErrorMsg(int code, String message){
            this.errorCode=code;
            this.errorMessage=message;
        }

        @Override
        public int getErrorCode(){
            return errorCode;
        }

        @Override
        public String getErrorMessage(){
            return errorMessage;
        }

    }

}