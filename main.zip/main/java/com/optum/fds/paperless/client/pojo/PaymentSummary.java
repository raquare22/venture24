package com.optum.fds.paperless.client.pojo;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.client.ClientMetadata;
import com.optum.fds.paperless.client.ErrorMessage;

import java.io.Serial;
import java.text.ParseException;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.optum.fds.paperless.util.handlebar.helper.pojo.NormalizeUtil.normalizePipeDelimitedValue;

public class PaymentSummary extends ClientMetadata {

    @Serial
    private static final long serialVersionUID = 7841029384756120498L;
    private static final ObjectMapper LOCAL_MAPPER = new ObjectMapper();
    private static final String CATEGORY = "Payment Document";
    private static final String CREATE_APPLICATION = "PmntEng";
    private static final String PRIVILEGE = "Claim Status";
    private static final String SOURCE = "PRUN";
    private static final DateTimeFormatter UTC_FORMATTER = new DateTimeFormatterBuilder().appendInstant(3).toFormatter();


    @JsonProperty("tin")
    @JsonAlias("u_tax_id")
    private String tin;

    @JsonProperty("paymentDate")
    @JsonAlias("u_payment_summary_dt")
    private String paymentDate;

    @JsonProperty("paymentType")
    @JsonAlias("u_payment_typ")
    private String paymentType;

    @JsonProperty("paymentNumber")
    @JsonAlias("u_payment_nbr")
    private String paymentNumber;

    @JsonProperty("source")
    private String source;

    @JsonProperty("emailAlertReq")
    private String emailAlertReq="N";
    
    @JsonProperty("subCategory")
    private String subCategory;


    public PaymentSummary() {
        this.category = CATEGORY;
        this.createApplication = CREATE_APPLICATION;
        this.privilege = PRIVILEGE;
        this.source = SOURCE;
        this.emailAlertReq="N";
        // Routing flags
        this.sendToDocVault = false;
       
        
        Instant nowUtc = Instant.now().truncatedTo(java.time.temporal.ChronoUnit.MILLIS);
        
        Instant twoYearsLaterUtc = nowUtc.atZone(java.time.ZoneOffset.UTC)
                                         .plusYears(2)
                                         .toInstant();
        String formattedExpiryDate = UTC_FORMATTER.format(twoYearsLaterUtc);

        
        super.setExpiryDate(formattedExpiryDate);


    }

    public String getEmailAlertReq() {
        return emailAlertReq;
    }

    public void setEmailAlertReq(String emailAlertReq) {
        this.emailAlertReq = emailAlertReq;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        Objects.requireNonNull(paymentType, "paymentType must not be null");
        if(paymentType.isBlank()){
            throw new IllegalArgumentException("paymentType must not be blank");
        }
        this.paymentType = paymentType;
        this.setFilePath(PaymentTypeFilePath.from(paymentType).getFilePath());
        this.subCategory = paymentType;
    }

    public String getPaymentNumber() {
        return paymentNumber;
    }

    @JsonSetter("paymentNumber")
    @JsonAlias("u_payment_nbr")
    public void setPaymentNumber(Object raw) {
        this.paymentNumber = normalizePipeDelimitedValue(raw);
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
    

	public String getSubCategory() {
		return subCategory;
	}

    public enum PaymentTypeFilePath {
        DLY("Payment Summary Reports/Daily"),
        MLY("Payment Summary Reports/Monthly");

        private final String filePath;

        PaymentTypeFilePath(String filePath){
            this.filePath=filePath;
        }

        public String getFilePath(){
            return filePath;
        }

        public static PaymentTypeFilePath from(String code){
            try{
                return PaymentTypeFilePath.valueOf(code);
            }catch (IllegalArgumentException e){
                throw new IllegalArgumentException(
                "Unsupported paymentType '" + code + " '.Expected one of " + Arrays.toString(values()),e);
            }
        }

    }


    public enum ErrorMsg implements ErrorMessage {
        u_tax_id (12,"Missing or invalid data: Tax ID"),
        u_payment_summary_dt (12,"Missing or invalid data: Payment Summary Date"),
        u_payment_typ (12,"Missing or invalid data: Payment Type"),
        u_payment_nbr (12,"Missing or invalid data: Payment Number");

        private final int errorCode;
        private final String errorMessage;

        ErrorMsg(int code, String message){
            this.errorCode=code;
            this.errorMessage=message;
        }

        @Override
        public int getErrorCode(){
            return errorCode;
        }

        @Override
        public String getErrorMessage(){
            return errorMessage;
        }

    }

}