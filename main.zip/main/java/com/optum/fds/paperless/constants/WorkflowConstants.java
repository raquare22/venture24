package com.optum.fds.paperless.constants;

public interface WorkflowConstants {
	
	
	static final String APP_ID = "appId";
	static final String APP_SECRET = "appSecret";
	static final String GRANT_TYPE = "grant_type";
	
	static final String APP_IDENTIFIER = "appIdentifier";
	static final String JOB = "job";
	
	
    /* Generic OATH vars */
    static final String OAUTH_ERROR_MESSAGE = "oauth_error_message";
    static final String OAUTH_URL = "fdsAuthUrl";
    static final String OAUTH_TOKEN = "oauth_token";
    static final String CORRELATION_IDS = "CorrelationID";
    static final String OAUTH_TOKEN_V1 = "oauthToken";

	
	static final String PROCESSOR_METADATA = "processorMetaData";
	
	
	// Manipulate PDF
    static final String ERROR_MAP = "errorMap";
    static final String NEW_ERRORS = "newErrors";
    
    
    // Transform JSON File with template
    static final String DOCUMENTS = "Documents";
    
    
    // cleanupFilesCreateAckProcess
    static final String E_DELIVERY_ERROR = "eDeliveryError";
	
	
	// Retrieve processorTransaction
    static final String SEARCH_WINDOW = "search_window";
    static final String SEARCH_WINDOW_TIMEWINDOW = "time_window";
    static final String SEARCH_WINDOW_FORMAT = "format";
    static final String SEARCH_WINDOW_START_DATE = "start_date";
    static final String SEARCH_WINDOW_START_DATE_OFFSET = "start_date_offset";
    static final String SEARCH_WINDOW_END_DATE = "end_date";
    static final String SEARCH_WINDOW_END_DATE_OFFSET = "end_date_offset";
    static final String INGEST_ROOT = "INGEST_ROOT";
    static final String PROCESSOR_DATE_CREATED = "dateCreated";
    
    // Email alert workflow
    static final String PROCESSOR_TRANSACTIONS = "ProcessorTransactions";
    
    
    
    static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

}
