/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/7/17.
 */

////package com.optum.fs.domain.service;
package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.jobs.ProcessorCoreJob;
import com.optum.fds.paperless.mongo.jobs.RestApiJob;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorMapping;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface ProcessorService {
    JobMetaData deleteProcessorJobFromStack(String jobId);

    boolean deleteProcessorMetaData(String id, String appIdentifier);

    List<ProcessorMetaData> findAllAvailableProcessorMetaData();

    ProcessorMetaData saveProcessor(ProcessorMetaData processorMetaData);

    void updateProcessor(ProcessorMetaData processorMetaData, Map<String, Object> map);

    ProcessorMetaData getProcessorById(String id);

    ProcessorMetaData deleteProcessor(String id);

    List<ProcessorMetaData> findAllUnplannedProcessorLockMetaData();

    List<ProcessorMetaData> findAllAvailableProcessorMetaData(Date startDate, Date endDate);

    ProcessorMetaData findProcessorMetaDataByFileName(String zipFilename, String appId);

    ProcessorMetaData findProcessorMetaDataById(String processorId, String appId);

    JobMetaData findTopOfProcessorJobQueueForProcessors(String serverType, List activeProcessorIds);

    JobMetaData findTopOfRestApiJobQueueForProcessors(String serverType, List activeProcessorIds);

    ProcessorMetaData getProcessorMetaData(String id, String appIdentifier);

    ProcessorFileTask getProcessorFileTask(String id, String appIdentifier, String serverType);

    ProcessorFileTask getProcessorFileTaskByProcessorTransactionIdRowNumber(String id, Integer rowNumber);

    ProcessorFileTask getProcessorFileTaskForTargetId(String targetId, String targetType, String appIdentifier);

    ProcessorTransaction getProcessorTransaction(String id, String appIdentifier, String serverType);

    ProcessorTransaction getProcessorTransactionById(String id);

    void lockProcessor(String id);

    boolean nameIsUnique(String name, String appIdentifier);

    ProcessorFileTask saveProcessorFileTask(ProcessorFileTask processorFileTask);

    JobMetaData saveProcessorJobRecord(JobMetaData jobMetaData);

    ProcessorMetaData saveProcessorMetaData(ProcessorMetaData processorMetaData);

    ProcessorTransaction saveProcessorTransactionMetaData(ProcessorTransaction processorTransaction);

    void setLastCleanRun(String id);

    void updateOneProcessorTransactionField(String id, String key, Object value);

    void setLastRunAndStatus(String id, MetaDataStatus status);

    void unlockProcessor(String id);

    ProcessorTransaction updateProcessorExecutionRecordOfProcessorTransactionRecord(ProcessorTransaction processorTransaction, Map<String, Object> resultMap, ProcessorCoreJob job);

    ProcessorTransaction updateProcessorExecutionRecordOfProcessorTransactionRecord(ProcessorTransaction processorTransaction, Map<String, Object> resultMap, RestApiJob job);

    ProcessorFileTask updateProcessorExecutionRecordOfProcessorFileTaskRecord(ProcessorFileTask processorTransaction, Map<String, Object> resultMap, ProcessorCoreJob job);

    ProcessorFileTask updateProcessorExecutionRecordOfProcessorFileTaskRecord(ProcessorFileTask processorTransaction, Map<String, Object> resultMap, RestApiJob job);

    ProcessorFileTask updateProcessorFileTask(ProcessorFileTask processorFileTask);

    ProcessorMetaData updateProcessorMetaData(ProcessorMetaData processorMetaData);

    ProcessorTransaction updateProcessorTransactionMetaData(ProcessorTransaction processorTransaction);

    JobMetaData findJobByProcessorTransactionIdByWorkflow(String processorTransactionId, String workFlow, String serverType);

    boolean findProcessorJobByTransactionIdFromQueue(String jobId, String serverType);

    List<ProcessorFileTask> getProcessorFileTasksForTransactionId(String transactionId, String serverType);

    List<ProcessorFileTask> getProcessorFileTasksForTransactionIdByStatus(String transactionId, String status);

    List<ProcessorTransaction> getAllProcessorTransactionInStatus(String status, String serverType);

    List<ProcessorTransaction> getAllProcessorTransactionInStatus(List<String> status, String serverType, int startTimeOffset);

    List<ProcessorTransaction> getAllProcessorTransactionInStatus(String status, String serverType, int startTimeOffset);

    void startProcessor(String id);

    void shutdownProcessor(String id);

    List<ProcessorMetaData> findAllAvailableProcessorsToStart();

    List<ProcessorMetaData> findAllAvailableProcessorsForShutdown();

    List<JobMetaData> findProcessorJobsByTransactionIdFromQueue(String processorTransactionId, String serverType);

    void updateJobStatus(String id, String status);

    List<ProcessorFileTask> getLastProcessorFileTaskForTransactionId(String transactionId, String serverType);

    List<ProcessorTransaction> getAllPendingProcessorTransactions(int processorTransactionPendingTime, List<String> statusList, String serverType);

    List<ProcessorFileTask> getPendingProcessorFileTaskForTransactionId(String transactionId, String serverType, String status, int processorTransactionPendingTime);

    ProcessorMapping getProcessorMapping(String appIdentifier, Integer spaceId);

    ProcessorMapping deleteProcessorMapping(String appIdentifier, Integer spaceId);

    ProcessorMapping saveProcessorMapping(ProcessorMapping processorMapping);

    //ProcessorMapping			  updateProcessorMapping(ProcessorMapping mapping);
    void updateProcessorTransactionFields(String id, Map<String, Object> updateMap) throws InvalidExpressionException;

    void lockIncompleteProcessorFlag(String id);

    void unlockIncompleteProcessorFlag(String id);

    void updateProcessorLastRun(String id);

    void findAndUpdateJobsByStatusINProcess(String status, String jobType);

    boolean deleteProcessor(String processorRecordType, String processorType, int processorPendingTime);

    //	boolean                    areAllProcessorFileTasksCompletedForTransactionId(String transactionId);
    void setAckStatus(String id, String ackStatus) throws InvalidExpressionException;

    ProcessorTransaction findProcessorTransactionByFileName(String zipFileName, Integer configSpaceId);

    List<String> findAllAvailableProcessorIds(Date start, Date end);

    List<String> retrieveJobIdList(int limit);

    JobMetaData findProcessorJob(String jobId);

    ProcessorMetaData findProcessor(String processorId);

    List<String> retrieveRestApiJobIdList(int limit);

}
