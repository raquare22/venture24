package com.optum.fds.paperless.domain.service;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Map.Entry;

import org.flowable.engine.delegate.DelegateExecution;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.optum.fds.paperless.exception.ValidationException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.constants.CommonConstants;
import com.optum.fds.paperless.exception.ErrorCode;
import com.optum.fds.paperless.exception.ProcessException;
import com.optum.fds.paperless.mongo.ErrorMetaData;
import com.optum.fds.paperless.mongo.ProcessKeyToErrorCode;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.util.Parser;
import com.optum.fds.paperless.workflow.constants.Workflow;

@Service
public class ErrorMetaDataServiceImpl implements ErrorMetaDataService {

	static final Logger logger = LoggerFactory.getLogger(ErrorMetaDataServiceImpl.class);

	private static final String DATE_MODIFIED = "dateModified";
	private static final String IDENTIFIER = "identifier";
	private static final String TARGET_ID = "targetId";
	private static final String METADATA = "metadata";
	private static final String STATUS = "status";
	private static final String ID = "id";
	private static final String ERROR_MESSEGAE = "errorMessage";
	private static final String REVISIONS = "revisions";
	private static final String QUERY_STRING = "{} query={}";
	private static final String QUERY_EXCEPTION_STRING = "{} query={} {}";
	private static final String DOCUMENT_COLLECTION = "appError";
	private static final String GET_DOCUMENT = "getErrorMetaData";

	@Autowired
	MongoTemplate mongoTemplate;

	@Value("${MONGO_QUERY_MAX_MILLIS:90000}")
	String mongoQueryMaxMillis;
	
	@Value("${PRUN_ACTIVITI_URL}")
	String prunActivitUrl;

	@Value("${SupportedDelegatesIndex}")
	String supportedDelegatesIndex;

	public void setMongoQueryMaxMillis(String mongoQueryMaxMillis) {
		this.mongoQueryMaxMillis = mongoQueryMaxMillis;
	}
	
	ObjectMapper mapper = new ObjectMapper();
	
	@Override
	public ErrorMetaData writeToErrorCollection(DelegateExecution execution, String exception) {
		
		String process = (String) execution.getVariable(Workflow.PROCESS_KEY);
		
		if (process == null || process.isEmpty()) {
			process = "GENERIC_WORKFLOW_PROCESS_KEY";
		}
		
		 execution.setTransientVariable("reconciliation", true);
		 execution.setTransientVariable("reconciliationRetryCount", 6);
		
		List<String> urlList = new ArrayList<>();
		urlList.add(prunActivitUrl + "/api/services/run/workflow");
        
		Document metadata = new Document();
        metadata.put("url", urlList);
        metadata.put("exceptionMessage", exception);
        metadata.put("processKey", process);
        
        Map<String, Object> callbackMap = execution.getVariables();
        callbackMap.remove("errorMap");
        
        for (Map.Entry<String, Object> entry : callbackMap.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            
            // If execution bus variable is not a string or list (i.e. it's a POJO), then it causes an error when saving the object to mongodb
            // Convert to json string here instead
            if (!(value instanceof String)) {
            	String jsonStr;
				try {
					jsonStr = mapper.writeValueAsString(value);
					callbackMap.put(key, jsonStr);
				} catch (JsonProcessingException e) {
					logger.debug("Error saving errorMetaData, could not convert POJO to json string: key={}, value={}, e={}", key, value, ExceptionUtils.getStackTrace(e));
					callbackMap.put(key, "Error saving errorMetaData, could not convert object to json string e: " + e.getMessage());
				}
            }
        }
        
        metadata.put("callbackMap", callbackMap);
        
        String targetId = execution.getVariable(Workflow.HOOK_ID) != null ? (String) execution.getVariable(Workflow.HOOK_ID) : (String) execution.getVariable(Workflow.DOCID);
        String targetType = execution.getVariable(Workflow.HOOK_ID) != null ? "hook" : "document";

        return writeToErrorCollection(process, targetId, targetType, ProcessKeyToErrorCode.getErrorCodeFromProcessKey(process),  metadata);
	}
	
	@Override
	public ErrorMetaData writeToErrorCollection(String identifier, String targetId, String targetType, ErrorCode errorCode, Document metadata) {
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setIdentifier(identifier);
		errorMetaData.setTargetId(targetId);
		errorMetaData.setTargetType(targetType);
		errorMetaData.setMetadata(metadata);
		errorMetaData.setRetryCount(0);
		errorMetaData.setErrorCodeAndErrorMessageAndDefaultErrorStatus(errorCode);
		return saveErrorMetaData(errorMetaData);
		
	}

	@Override
	public ErrorMetaData saveErrorMetaData(ErrorMetaData errorMetaData) {
		logger.debug("errorMetaData={}", errorMetaData);
		MongoOperations op = mongoTemplate;
		ErrorMetaData updatedDoc = null;
		String id = errorMetaData.getId();
		if (id == null || id.isEmpty()) {
			logger.debug("Entering saveErrorMetaData; id == null || id.isEmpty()");
			// document doesn't exist, insert
			updatedDoc = mongoTemplate.insert(errorMetaData, DOCUMENT_COLLECTION);
			return updatedDoc;
		} else {
			// check document already exists in collection
			logger.debug("Entering saveErrorMetaData; NOT id == null || id.isEmpty()");
			ErrorMetaData document = mongoTemplate.findOne(query(where(ID).is(id)), ErrorMetaData.class);
			if (document != null) {
				mongoTemplate.save(errorMetaData, DOCUMENT_COLLECTION);
				return errorMetaData;
			} else {
				updatedDoc = op.insert(errorMetaData, DOCUMENT_COLLECTION);
				return updatedDoc;
			}
		}
	}

	@Override
	public ErrorMetaData getErrorMetaData(String id) {
		logger.debug("id={}", id);
		return mongoTemplate.find(query(where(ID).is(id)), ErrorMetaData.class).stream().findFirst().orElse(null);
	}

	@Override
	public ErrorMetaData getErrorMetaDataByTargetId(String id) {
		logger.debug("id={}", id);
		return mongoTemplate.find(query(where(TARGET_ID).is(id)), ErrorMetaData.class).stream().findFirst().orElse(null);
	}

	/**
	 * Used to set mongoTemplate in JUnit test
	 * 
	 * @param mongoTemplate
	 */
	public void setMongoTemplate(MongoTemplate mongoTemplate) {
		this.mongoTemplate = mongoTemplate;
	}

	public ErrorMetaData updateErrorMetaDataStatus(String id, String status) {
		return updateErrorMetaDataStatus(id, status, null);
	}

	public ErrorMetaData updateErrorMetaDataStatus(String id, String status, String errorMessage) {
		logger.debug("id={}, status={}, errorMessage={}", id, status, errorMessage);
		if (StringUtils.isEmpty(status) || StringUtils.isEmpty(id)) {
			return null;
		}
		var query = new Query();
		query.addCriteria(Criteria.where(ID).is(id));
		MongoOperations op = mongoTemplate;
		ErrorMetaData errorMetaData = op.findOne(query, ErrorMetaData.class);
		if (errorMetaData == null) {
			return errorMetaData;
		}
		errorMetaData.setStatus(status);
		errorMetaData.setErrorMessage(errorMessage);
		errorMetaData.setDateModified(new java.util.Date());
		op.save(errorMetaData);
		logger.debug("errorMetaData={}", errorMetaData);
		return errorMetaData;
	}

	@Override
	public List<ErrorMetaData> getErrorListById(String id) {
		return mongoTemplate.find(query(where(ID).is(id)), ErrorMetaData.class);
	}

	@Override
	public List<ErrorMetaData> getErrorListByIdentifier(String identifier) {
		return mongoTemplate.find(query(where(IDENTIFIER).is(identifier)), ErrorMetaData.class);
	}

	private static final List<SimpleDateFormat> dateFormatList = List.of(
			new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"),
			new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS'Z'"),
			new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS"),
			new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
	);

	public Date convertISOStringToDate(String isoDate) {
		if (StringUtils.isNotEmpty(isoDate)) {
			var itr = dateFormatList.iterator();
			while (itr.hasNext()) {
				var format = itr.next();
				try {
					return format.parse(isoDate);
				} catch (ParseException e) {

				}
			}
		}
		return null;
	}

	@Override
	public ErrorMetaData updateErrorMetaData(ErrorMetaData errorMetaData) {
		logger.debug("errorMetaData={}", errorMetaData);
		ErrorMetaData savedErrorMetaData = null;
		var status = errorMetaData.getStatus().toString();
		String id = errorMetaData.getId();
		String errorMessage = errorMetaData.getErrorMessage();
		if (StringUtils.isNotEmpty(status) && StringUtils.isNotEmpty(id)) {
			var query = new Query();
			query.addCriteria(Criteria.where(ID).is(id));
			MongoOperations op = mongoTemplate;
			savedErrorMetaData = op.findOne(query, ErrorMetaData.class);
			if (savedErrorMetaData != null) {
				savedErrorMetaData.setStatus(status);
				savedErrorMetaData.setDateModified(new java.util.Date());
				savedErrorMetaData.setErrorMessage(errorMessage);
				op.save(savedErrorMetaData);
			}
		}
		logger.debug("Leaving updateErrorMetaData");
		return savedErrorMetaData;
	}

	@Override
	public ErrorMetaData putErrorMetadata(ErrorMetaData errorMetaData) {
		logger.debug("errorMetaData={}", errorMetaData);
		MongoOperations op = mongoTemplate;
		String id = errorMetaData.getId();

		var update = new Update();
		update.set(STATUS, errorMetaData.getStatus());
		update.set(DATE_MODIFIED, new java.util.Date());
		update.set(REVISIONS, errorMetaData.getRevisions());

		if (MapUtils.isNotEmpty(errorMetaData.getMetadata())) {
			update.set(METADATA, errorMetaData.getMetadata());
		} else if (errorMetaData.getMetadata() != null && errorMetaData.getMetadata().isEmpty()) {
			update.unset(METADATA);
		}

		if (StringUtils.isNotEmpty(errorMetaData.getIdentifier())) {
			update.set(IDENTIFIER, errorMetaData.getIdentifier());
		} else {
			update.unset(IDENTIFIER);
		}

		if (StringUtils.isNotEmpty(errorMetaData.getErrorMessage())) {
			update.set(ERROR_MESSEGAE, errorMetaData.getErrorMessage());
		} else {
			update.unset(ERROR_MESSEGAE);
		}

		var retVal = Optional.ofNullable(op.findAndModify(query(where(ID).is(id)), update,
				new FindAndModifyOptions().returnNew(true), ErrorMetaData.class));
		if (logger.isDebugEnabled()) {
			logger.debug("Updated id: {} New Status: {}", retVal.map(ErrorMetaData::getId).orElse("no id"), retVal.map(ErrorMetaData::getStatus)
					.map(String::valueOf).orElse("no status"));
		}
		return retVal.orElse(null);
	}

	/**
	 * Input : searchCriteria can be NULL but not empty
	 * additionalFilters can be added as criteria, should be not NULL,
	 * Return List of errorMetaData
	 * throws InvalidExpressionException if documentFilter is null
	 */
	@Override
	public List<ErrorMetaData> getErrorMetaData(String documentSearchCriteriaJson, Criteria documentFilter) throws ValidationException{
		logger.debug("documentSearchCriteriaJson={}, documentFilter={}", documentSearchCriteriaJson, documentFilter);

		if (Objects.isNull(documentFilter)) {
			throw new ValidationException("filter should be logical query expression");
		}
		var query = new BasicQuery(documentSearchCriteriaJson).addCriteria(documentFilter);
		logger.debug(QUERY_STRING, GET_DOCUMENT, query);
		logger.debug("ErrorMetaDataServiceImpl-->getErrorMetaData-->EXIT");

		try {
			return mongoTemplate.find(query, ErrorMetaData.class, DOCUMENT_COLLECTION);
		} catch (Exception e) {
			logger.error(QUERY_EXCEPTION_STRING, GET_DOCUMENT, query, ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}

	@Override
	public ErrorMetaData updateErrorMetadataFields(Map<String, Object> fieldsToUpdate, String documentId) {
		MongoOperations op = mongoTemplate;
		var query = new Query(Criteria.where("id").is(documentId));
		var update = new Update();
		update.set(DATE_MODIFIED, new Date());
		for (Entry<String, Object> entry : fieldsToUpdate.entrySet()) {
			update.set(entry.getKey(), entry.getValue());
		}
		return op.findAndModify(query, update, new FindAndModifyOptions().returnNew(true), ErrorMetaData.class);
	}

	@Override
	public ErrorMetaData writeToMessageServiceErrorCollection(String queue, String identifier, String targetId, Integer spaceId, Map<String, Object> variables, String errorMsg, MetaDataStatus status) {
		String requestMapJson = "";
		try {
			requestMapJson = getMultiValueMapToJson(identifier, variables);
			logger.debug("requestMapJson={}", requestMapJson);
		} catch (ProcessException e) {
			logger.error("{}", e.getMessage());
			requestMapJson = "{\"delegate\":[\"" + identifier + "\"]}";
			errorMsg = errorMsg + ": " + e.getMessage();
			status = MetaDataStatus.MANUAL;
		}
		return writeToMessageServiceErrorCollection(queue, identifier, targetId, spaceId, errorMsg, requestMapJson, status);
	}

	@Override
	public ErrorMetaData writeToMessageServiceErrorCollection(String queue, String identifier, String targetId, Integer spaceId, String errorMsg,
			String jsonStr, MetaDataStatus status) {
		ErrorMetaData errorMetaData = new ErrorMetaData();
		errorMetaData.setIdentifier(identifier);
		errorMetaData.setTargetId(targetId);
		errorMetaData.setSpaceId(spaceId);
		errorMetaData.setQueue(queue);
		errorMetaData.setRetryCount(0);
		errorMetaData.setReplyTo(CommonConstants.ENGINE_DELIGATE_URL);
		errorMetaData.setReplyToIndex(supportedDelegatesIndex);
		errorMetaData.setErrorMessage(errorMsg);
		errorMetaData.setErrorCode(ErrorCode.REST_API_ERROR);
		errorMetaData.setMetadata(org.bson.Document.parse(jsonStr));
		errorMetaData.setRetryCount(0);
		errorMetaData.setStatus(status);
		logger.warn("errorMetaData={}", errorMetaData);
		return saveErrorMetaData(errorMetaData);
	}

	protected String getMultiValueMapToJson(String delegate, Map<String, Object> delegateParams) throws ProcessException {
		MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<>();
		requestMap.add("delegate", delegate);
		requestMap.add("callbackMap", delegateParams);
		try {
			return Parser.toJson(requestMap);
		} catch (IOException e) {
			throw new ProcessException("Failure getMultiValueMapToJson: delegate=" + delegate + ", delegateParams=" + delegateParams + ": " + e.getMessage());
		}
	}
}
