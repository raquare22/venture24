/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2013.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ***********************************************
 * Modification History
 * When         Who                   Revision
 * Dec 02 2014  Vinata Gangolli		    Initial version
 * Nov 08 2016	Suman Halder			Adding listing documents with paging functionality
 * Nov 16 2016  Will Herrera            Adding PUT functionality for documents 
 ****************************************************************/
package com.optum.fds.paperless.domain.service;

import java.util.List;
import java.util.Map;

import org.bson.Document;
import org.springframework.data.mongodb.core.query.Criteria;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.model.MultiPutResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.workflow.beans.ProviderDocument;

public interface DocumentMetaDataService {

    DocumentMetaData saveDocumentMetaData(DocumentMetaData metadata);

    DocumentMetaData saveDocMetaDataWithRevisions(DocumentMetaData metadata, String id);
    
    DocumentMetaData getDocumentMetaData(String id);

    List<DocumentMetaData> getGPSDocumentMetaData(String key, int spaceId, int queryTimeWindow);

    DocumentMetaData getATSDocumentMetaData(String caseNum, int spaceId, int queryTimeWindow);
    
    DocumentMetaData getReferralDocumentMetaData(String requestId, int spaceId, String referralStatus, int queryTimeWindow);
   
    List<DocumentMetaData> getDocumentMetaDataList(List<String> ids);
    
    DocumentMetaData getCsvDocumentMetaData(String id);

    DocumentMetaData savePDODocumentMetaData(DocumentMetaData metadata);

    DocumentMetaData updateDocumentMetaDataStatus(String docId, String status);

    DocumentMetaData updatePDODocumentMetaData(DocumentMetaData metadata, String id);
    
    List<DocumentMetaData> insertMultiPDODocuments(List<DocumentMetaData> documentMetaDataList);
    
    MultiPutResponse updateMultiPDODocuments(List<String> docIds, DocumentMetaData document);

    List<DocumentMetaData> insertMultiDocuments(List<DocumentMetaData> documentMetaDataList);
    
    List<DocumentMetaData> insertMultiDocumentsWithSpaceId(List<DocumentMetaData> documentMetaDataList, int spaceId);

    MultiPutResponse updateMultiDocuments(List<String> docIds, DocumentMetaData document);
    
    DocumentMetaData getPDODocumentById(String id);
    
    List<DocumentMetaData> getPDODocuments(Map<String, String> queryParams) throws JsonProcessingException;

    List<DocumentMetaData> getDocuments(Map<String, String> queryParams) throws JsonProcessingException;

    DocumentMetaData updateDocumentMetaDataStatus(String docId, String status, String trxId);

    List<DocumentMetaData> getDocumentListById(String id);

    List<DocumentMetaData> getDocumentListByExternalId(String appId, String externalId);

    List<DocumentMetaData> getDocumentListByExternalIdAndSpaceId(String externalId, int spaceId);

    List<DocumentMetaData> getDocumentListMetadata(String appId, Map<String, String> metadataMap);

    List<DocumentMetaData> getDocumentListAppId(String appIdentifier);

//   	public List<DocumentMetaData> getDocumentMetaDataListWithPaging(String status, List<Integer> spaceIdList, DocumentsQuery documentsQry, int startAt, int maxRecords) throws InvalidExpressionException, MongoDBApiException;

//   	public Long getDocumentMetaDataListWithPagingCount(String status, List<Integer> spaceIdList, DocumentsQuery documentsQry) throws InvalidExpressionException, MongoDBApiException;

    DocumentMetaData updateDocumentMetaData(DocumentMetaData documentMetaData, String trxId);

    DocumentMetaData updateDocMetaData(DocumentMetaData documentMetaData, String id);

    DocumentMetaData putDocumentMetadata(DocumentMetaData metadata);

    List<DocumentMetaData> getDocumentMetaDataListWithPagingNew(String status, List<Integer> spaceIdList, Criteria documentsQry, int startPosition, int countToReturn);

    List<DocumentMetaData> getDocumentMetaData(String documentSearchCriteriaJson, Criteria documentsFilter) throws InvalidExpressionException;

    List<String> getDocumentMetaDataIds(String documentSearchCriteriaJson, Criteria documentFilter, Criteria uniqueMetadataQuery) throws InvalidExpressionException;
    
    List<DocumentMetaData> getCsvDocumentMetaData(String documentSearchCriteriaJson, Criteria documentsFilter) throws InvalidExpressionException;

    List<DocumentMetaData> getDocumentMetaData(String documentSearchCriteriaJson, Criteria documentFilter, Integer countToReturn) throws InvalidExpressionException;

    DocumentMetaData updateDocumentMetadataFields(Map<String, Object> fieldsToUpdate, String documentId);

    List<ProviderDocument> getPDODocuments(Document criteriaDocument);

	DocumentMetaData putDocumentMetadata(DocumentMetaData documentMetaData, String docId);

	MultiPutResponse updateMultiDocument(List<String> docIds, DocumentMetaData document);

	DocumentMetaData deleteDocument(String id);
	
	long saveDocumentMetaDataMulti(List<String> docIdList, Map<String, Object> updateMap);
	
	List<DocumentMetaData> getDocumentMetaDataByZipFileName(String documentSearchCriteriaJson, Criteria documentsFilter, String zipFileName, int spaceId) throws InvalidExpressionException;
	
	DocumentMetaData updateReferralDocumentStatus(String docId, Document metadata);

}
