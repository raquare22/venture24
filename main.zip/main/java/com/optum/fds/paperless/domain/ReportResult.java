////package com.optum.fs.domain;
package com.optum.fds.paperless.domain;

import java.io.Serializable;

public class ReportResult implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private Long count;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }
}
