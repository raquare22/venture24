/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who              Revision
 * Now 16 2016  Will Herrera     Initial version
 ****************************************************************/
////package com.optum.fs.domain.revision;
package com.optum.fds.paperless.domain.revision;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
////import com.optum.fs.mongo.DocumentAttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentAttachmentMetaData;

/**
 * 
 * @author tviolett.
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentRevision extends Revision implements Serializable{
    private static final long serialVersionUID = 1L;

    private Date dateAttachmentUpdated;
    @JsonProperty("attachments")
    private List<DocumentAttachmentMetaData> documentAttachments;
    private String errorMessage;
    private String externalId;
    private transient Document metadata;

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public Date getDateAttachmentUpdated() {
        return dateAttachmentUpdated==null?null:(Date)dateAttachmentUpdated.clone();
    }

    public void setDateAttachmentUpdated(Date dateAttachmentUpdated) {
         this.dateAttachmentUpdated = dateAttachmentUpdated==null?null:(Date)dateAttachmentUpdated.clone();
    }

    public Document getMetadata() {
        return metadata;
    }

    public void setMetadata(Document metadata) {
        this.metadata = metadata;
    }

    @JsonProperty("attachments")
    public List<DocumentAttachmentMetaData> getDocumentAttachments() {
        return documentAttachments==null?null:new ArrayList<>(documentAttachments);
    }

    @JsonProperty("attachments")
    public void setDocumentAttachments(List<DocumentAttachmentMetaData> documentAttachments) {
        this.documentAttachments = documentAttachments==null?null:new ArrayList<>(documentAttachments);
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
