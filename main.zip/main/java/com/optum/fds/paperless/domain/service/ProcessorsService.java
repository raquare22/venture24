/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/7/17.
 */

////package com.optum.fs.fs_batch_processing.service;
package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorMapping;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;

import java.util.Date;
import java.util.List;

public interface ProcessorsService {
    ProcessorMetaData createProcessor(
            ProcessorMetaData processor
    );

    ProcessorMetaData getProcessor(
            String appIdentifier,
            String processorId
    );

    ProcessorFileTask createProcessorFileTaskEntries(ProcessorTransaction processorTransaction, String fileName);

    JobMetaData createProcessorJobEntry(ProcessorMetaData processor, ProcessorTransaction processorTransaction, String jobType, String wrkFlow);

    ProcessorTransaction createProcessorTransaction(ProcessorMetaData processor, String fileName, String fileLocation, String transactionID);

    Transaction createTransactionRecord(ProcessorMetaData processor);

    List<ProcessorMetaData> findAllAvailableProcessorMetaData();

    List<ProcessorMetaData> findAllAvailableProcessorMetaData(Date startDate, Date endDate);

    ProcessorMetaData findProcessorMetaDataByFileName(String processorId, String appId);

    ProcessorMetaData findProcessorMetaDataById(String zipFilename, String appId);


    boolean findProcessorJobByTransactionIdFromQueue(String processorTransactionId);

    String getCleanupWorkFlowForProcessorTransaction(ProcessorTransaction processorTransaction);

    ProcessorFileTask getProcessorFileTask(String appIdentifier, String processorId);

    ProcessorTransaction getTransactionProcessor(String appIdentifier, String processorId, String serverType);

    ProcessorTransaction getTransactionProcessorById(String Id);

    boolean isProcessorLocked(ProcessorMetaData processorMetaData);

    void lockProcessor(ProcessorMetaData processorMetaData);

    boolean nameIsUnique(String name, String appIdentifier);

    void setLastCleanRun(String id);

    void setLastRunAndStatus(String id, MetaDataStatus status);

    void unlockProcessor(ProcessorMetaData processor);

    ProcessorMetaData updateProcessorMetaData(ProcessorMetaData processorMetaData, ProcessorMetaData processorMetaDataInDB, String appIdentifier);

    ProcessorTransaction updateProcessorTransactionMetaData(ProcessorTransaction processorTransaction);

    List<ProcessorTransaction> getAllTransactionProcessorsFatalErrorAndReady();

    List<ProcessorTransaction> getAllTransactionProcessorsShutdown();

    List<ProcessorFileTask> getProcessorFileTasksForTransactionId(String transactionId);

    boolean allProcessorFileTasksCompletedForTransactionId(String transactionId);

    void startProcessor(String id);

    void shutdownProcessor(String id);

    void startMultipleProcessors();

    void shutdownMultipleProcessors();

    List<ProcessorFileTask> getLastProcessorFileTaskForTransactionId(String transactionId);

    List<ProcessorFileTask> getProcessorFileTasksForTransactionIdByStatus(String transactionId, String status);

    List<ProcessorTransaction> getAllPendingProcessorsTransactions(int processorTransactionPendingTime);

    List<ProcessorTransaction> getAllProcessorTransactionInStatus(List<String> status, String serverType, int startTimeOffset);

    List<ProcessorFileTask> getPendingProcessorFileTaskForTransactionId(String transactionId, String status, int processorTransactionPendingTime);

    boolean deleteProcessorMetaData(String id, String appIdentifier);

    ProcessorMapping getProcessorMapping(String appIdentifier, Integer spaceId);

    ProcessorMapping deleteProcessorMapping(String appIdentifier, Integer spaceId);

    ProcessorMapping createProcessorMapping(ProcessorMapping processorMapping);


    JobMetaData createProcessorJobEntry(ProcessorTransaction processorTransaction, String jobType, String wrkFlow);

    boolean isIncompleteProcessorFlagLocked(ProcessorMetaData processorMetaData);

    void lockIncompleteProcessorFlag(ProcessorMetaData processorMetaData);

    void unlockIncompleteProcessorFlag(ProcessorMetaData processor);

    void updateProcessorLastRun(ProcessorMetaData processor);

    void findAndUpdateJobsByStatusINProcess(String status, String jobType);

    boolean deleteProcessor(String processorRecordType, String processorType, int processorPendingTime);

    List<String> findAllAvailableProcessorIds(Date start, Date end);

    List<String> retrieveJobIdList(int limit);

    ProcessorMetaData findProcessor(String processorId);


    List<String> retrieveRestApiJobIdList(Integer theLimit);

    //public List<ProcessorMetaData>    findAllAvailableProcessorMetaData();
    //public List<ProcessorMetaData>    findAllAvailableProcessorMetaData(Date startDate , Date endDate);
    //List<String> findAllAvailableProcessorIds(Date start, Date end);
    //public void setLastRunAndStatus(String id, MetaDataStatus status);
    ProcessorTransaction getProcessorTransactionById(String id);

}
