package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorRowTask;
import com.optum.fds.paperless.mongo.csvProcessors.CsvProcessorTransaction;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import org.springframework.http.HttpEntity;

import java.net.URI;
import java.util.List;
import java.util.Map;

public interface CsvProcessorsService {

    DocumentMetaData createCsvRecord(int spaceId, String appIndentifier, String tin, String mpin, String fileName, String fileType, String providerEmailId, String frequency, String deliveryMethod,
                                     String okToChangePdoInd, String autoEdelUpdateInd, MetaDataStatus status);

    CsvProcessorRowTask createCsvProcessorRowTask(CsvProcessorTransaction processorTransaction,
                                                  String csvFileName, String csvJsonFileName, Integer rowNumber, String request, String targetType);

    CsvProcessorRowTask createCsvProcessorRowTask(CsvProcessorTransaction processorTransaction,
                                                  Integer configSpaceId, String csvFileName, String csvJsonFileName, Integer rowNumber, String request, MetaDataStatus status);

    CsvProcessorRowTask createCsvProcessorRowTask(CsvProcessorTransaction processorTransaction,
                                                  Integer configSpaceId, String csvFileName, String csvJsonFileName, Integer rowNumber, String request, String targetId, MetaDataStatus status);

    CsvProcessorRowTask createCsvProcessorRowTask(CsvProcessorRowTask csvProcessorRowTask);

    CsvProcessorRowTask updateCsvProcessorRowTask(CsvProcessorRowTask csvProcessorRowTask);

    CsvProcessorTransaction createCsvProcessorTransaction(ProcessorMetaData processor, String fileName,
														  String fileLocation, String transactionID);

    ProcessorMetaData findProcessorMetaDataById(String id);

    ProcessorMetaData findProcessorMetaDataByFileName(String csvFilename, String appId);

    CsvProcessorTransaction getCsvTransactionProcessor(String appIdentifier, String processorId);

    CsvProcessorTransaction getCsvProcessorTransactionWithFileName(String appIdentifier, String processorId, String fileName);

    CsvProcessorTransaction getCsvProcessorTransactionWithFileName(String appIdentifier, String processorId, String fileName, String serverType);

    CsvProcessorTransaction updateCsvProcessorTransactionMetaData(
			CsvProcessorTransaction csvProcessorTransaction);

    List<CsvProcessorTransaction> getAllTransactionProcessorsShutdown();

    List<CsvProcessorTransaction> getAllPendingCsvProcessorsTransactions(int processorTransactionPendingTime);

    List<CsvProcessorTransaction> getAllCsvProcessorsTransactions(List<String> statusList, int processorTransactionSearchTimeWindow);

    CsvProcessorTransaction getCsvProcessorTransactionWithFileName(String fileName);

    List<CsvProcessorRowTask> getAllCompleteWithErrorsCsvProcessorsRowTasks(String csvProcessorTransactionId);

    Boolean isAllCsvProcessorRowTasksWithCsvProcessorTransactionIdComplete(String csvProcessorTransactionId);

    Boolean isAllCsvProcessorRowTasksProcessed(CsvProcessorTransaction csvProcessorTransaction);

    JobMetaData createRestApiJobEntry(ProcessorMetaData processor,
									  CsvProcessorTransaction csvProcessorTransaction, String csvProcessorRowTaskId, String jobType, String wrkFlow,
									  org.springframework.http.HttpMethod method, HttpEntity<Object> request, ProcessorRecordTypes sourceType,
									  URI uri);

    JobMetaData createCsvProcessorJobEntry(ProcessorMetaData processor, CsvProcessorTransaction csvProcessorTransaction,
                                           String jobType, String wrkFlow);

	DocumentMetaData createCsvRecord(int spaceId, String appIdentifier, MetaDataStatus status, Map<String, Object> requestMap);
}
