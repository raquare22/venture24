/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who              Revision
 * 03.Feb.2016  Terry J. Violette 	 Initial version
 ****************************************************************/
////package com.optum.fs.domain.revision;
package com.optum.fds.paperless.domain.revision;

import java.util.Date;

/**
 * 
 * @author tviolett.
 *
 */
public class AttachmentRevision extends Revision {
    private static final long serialVersionUID = 1L;

    private String adapterId;
    private String adapterTypeId;
    private String adapterName;
    private String contentType;
    private Date dateAttachmentUpdated;
    private Date expires;
    private String externalId;
    private String filename;
    private long fileSize;
    private String fsId;
    boolean isAsync = false;
    private Date originalStorageDate;
    private String sourceSystemName;
    private Date sourceSystemDateCreated;
    private String stAdapterDocId;

    public String getAdapterId() {
        return adapterId;
    }

    public void setAdapterId(String adapterId) {
        this.adapterId = adapterId;
    }

    public String getAdapterName() {
        return adapterName;
    }

    public void setAdapterName(String adapterName) {
        this.adapterName = adapterName;
    }

    public String getAdapterTypeId() {
        return adapterTypeId;
    }

    public void setAdapterTypeId(String adapterTypeId) {
        this.adapterTypeId = adapterTypeId;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public Date getDateAttachmentUpdated() {
    	return dateAttachmentUpdated==null?null:(Date)dateAttachmentUpdated.clone();
        
    }

    public void setDateAttachmentUpdated(Date dateAttachmentUpdated) {
    	this.dateAttachmentUpdated = dateAttachmentUpdated==null?null:(Date)dateAttachmentUpdated.clone();
        
    }

    public Date getExpires() {
    	return expires==null?null:(Date)expires.clone();
        }

    public void setExpires(Date expires) {
    	this.expires = expires==null?null:(Date)expires.clone();
        }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String fileName) {
        this.filename = fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public String getFsId() {
        return fsId;
    }

    public void setFsId(String fsId) {
        this.fsId = fsId;
    }

    public Date getOriginalStorageDate() {
    	return originalStorageDate==null?null:(Date)originalStorageDate.clone();
       }

    public void setOriginalStorageDate(Date originalStorageDate) {
    	this.originalStorageDate = originalStorageDate==null?null:(Date)originalStorageDate.clone();
        }

    public Date getSourceSystemDateCreated() {
    	return sourceSystemDateCreated==null?null:(Date)sourceSystemDateCreated.clone();
        }

    public void setSourceSystemDateCreated(Date sourceSystemDateCreated) {
    	this.sourceSystemDateCreated = sourceSystemDateCreated==null?null:(Date)sourceSystemDateCreated.clone();
        }

    public String getSourceSystemName() {
        return sourceSystemName;
    }

    public void setSourceSystemName(String sourceSystemName) {
        this.sourceSystemName = sourceSystemName;
    }

    public String getStAdapterDocId() {
        return stAdapterDocId;
    }

    public void setStAdapterDocId(String stAdapterDocId) {
        this.stAdapterDocId = stAdapterDocId;
    }
}
