package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.mongo.ProcessorUtil;
import com.optum.fds.paperless.mongo.jobs.ProcessorCoreJob;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;


@Service("processorTransactionService")
public class ProcessorTransactionServiceImpl implements ProcessorTransactionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessorTransactionServiceImpl.class);
    private static final String PROCESSOR_COLLECTION_NAME = "processorTransaction";
    private static final String QUERY_STRING = "query {}";
    private static final String SERVER_TYPE = "serverType";
    private static final String FILE_NAME = "fileName";
    private static final String QUERY_EXCEPTION_STRING = "{} query={} {}";
    private static final String CONFIG_SPACE_ID = "configSpaceId";
    private static final String PROCESSOR_TRANSACTION_COLLECTION_NAME = "processorTransaction";
    private static final String PROCESSOR_TRANSACTION_ID = "processorTransactionId";



    @Autowired
    MongoTemplate mongoTemplate;

    public ProcessorTransactionServiceImpl() {
        // Required Constructor
    }

    public ProcessorTransactionServiceImpl(MongoTemplate mongoTemplate) {
    	this.mongoTemplate = mongoTemplate;
    }

	@Override
    public List<ProcessorTransactionMetadata> getProcessorTransactionMetaData(String documentSearchCriteriaJson,Criteria documentsFilter) throws InvalidExpressionException
    {
		LOGGER.debug("ProcessorTransactionServiceImpl-->getProcessorTransactionMetaData-->ENTER");

		if(Objects.isNull(documentsFilter))
			throw new InvalidExpressionException("filter should be logical query expresssion");
    	Query query = new BasicQuery(documentSearchCriteriaJson);
		query.addCriteria(documentsFilter);
		query.addCriteria(
                Criteria.where("processorRecordType").is(ProcessorRecordTypes.processorTransactionMetadata)
        );
		LOGGER.debug("ProcessorTransactionServiceImpl-->getProcessorTransactionMetaData-->query: {} ", query);
		LOGGER.debug("ProcessorTransactionServiceImpl-->getProcessorTransactionMetaData-->EXIT");
		try {
			List<ProcessorTransactionMetadata> processorTransactionMetadata =  mongoTemplate.find(query, ProcessorTransactionMetadata.class, PROCESSOR_COLLECTION_NAME);
			LOGGER.debug("ProcessorTransactionServiceImpl-->getProcessorTransactionMetaData-->size {} ", processorTransactionMetadata.size());
			return processorTransactionMetadata;
		} catch (Exception e) {
			LOGGER.error("getProcessorTransactionMetaData {}={} {}", "query", query, ExceptionUtils.getStackTrace(e));
			throw e;
		}
    }

    @Override
    public ProcessorTransactionMetadata updateProcessorTransactionMetaData(ProcessorTransactionMetadata processorTransactionMetadata)
    {
        LOGGER.debug("ProcessorTransactionService-->updateProcessorTransactionMetaData-->ENTER");
        processorTransactionMetadata.setDateModified(new Date());
        LOGGER.debug("ProcessorTransactionService-->updateProcessorTransactionMetaData-->EXIT");
        return saveProcessorTransactionMetaData(processorTransactionMetadata);
    }

	@Override
	public ProcessorTransactionMetadata saveProcessorTransactionMetaData(ProcessorTransactionMetadata processorTransactionMetadata) {
		LOGGER.debug("ProcessorTransactionService-->saveProcessorTransactionMetaData-->ENTER");
        mongoTemplate.save(processorTransactionMetadata, PROCESSOR_COLLECTION_NAME);
        LOGGER.debug("csvProcessorService-->saveProcessorTransactionMetaData-->EXIT");
        return processorTransactionMetadata;
	}

	@Override
	public ProcessorTransactionMetadata findProcessorTransactionMetadataByClientCompanionFileName(String fileName, String serverType) {

		LOGGER.debug("ProcessorTransactionService-->getProcessorTransactionWithFileName-->ENTER");
		ProcessorTransactionMetadata retVal = null;

		Query query = getProcessorTransMetadataWithFileName(fileName, serverType);

		try {
			List<ProcessorTransactionMetadata> hmds = mongoTemplate.find(query, ProcessorTransactionMetadata.class,
				PROCESSOR_COLLECTION_NAME);
			if (hmds != null && !hmds.isEmpty()) {
				retVal = hmds.get(0);
			}
			LOGGER.debug("csvProcessorService-->getProcessorTransactionWithFileName-->EXIT");
			return retVal;
		} catch (Exception e) {
			LOGGER.error("findProcessorTransactionMetadataByClientCompanionFileName {}={} {}", "query", query, ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}

	public Query getProcessorTransMetadataWithFileName(String fileName, String serverType) {

		LOGGER.debug("ProcessorTransactionService-->getProcessorTransMetadataWithFileName-->ENTER");
		Query query = new Query();

		query.addCriteria(Criteria.where("processorRecordType").is(ProcessorRecordTypes.processorTransactionMetadata)
				.and(FILE_NAME).is(fileName).and(SERVER_TYPE).is(serverType));
		LOGGER.debug(QUERY_STRING, query);
		LOGGER.debug("ProcessorTransactionService-->getProcessorTransMetadataWithFileName-->EXIT");
		return query;
	}
	
	@Override
    public ProcessorTransactionMetadata updateProcessorExecutionRecordOfProcessorTransactionRecord(ProcessorTransactionMetadata processorTransactionMetadata, Map<String, Object> resultMap, ProcessorCoreJob job) {
        ProcessorUtil.setExecutionRecordForActiviti(processorTransactionMetadata, resultMap, job);
        if(!processorTransactionMetadata.getStatus().equals(MetaDataStatus.FATAL_ERROR)){
        	processorTransactionMetadata.setStatus(MetaDataStatus.IN_PROCESS);
        }
        return updateProcessorTransactionMetaData(processorTransactionMetadata);
    }
	
	@Override
	 public ProcessorTransaction findProcessorTransactionByFileName(String zipFileName, Integer configSpaceId) {
	    	MongoOperations op = mongoTemplate;
	        Query query = new Query();
	        query.addCriteria(Criteria.where("fileName").is(zipFileName))
	        	.addCriteria(Criteria.where(CONFIG_SPACE_ID).is(configSpaceId));
	        LOGGER.debug(QUERY_STRING, "findProcessorTransactionByFileName", query);
	        try
	        {
	        	return op.findOne(query, ProcessorTransaction.class, PROCESSOR_TRANSACTION_COLLECTION_NAME);
	        }
	        catch (Exception e)
	        {
	        	LOGGER.error(QUERY_EXCEPTION_STRING, "findProcessorTransactionByFileName", query, ExceptionUtils.getStackTrace(e));
	        	throw e;
	        }
	    }
	 
	 
	@Override
	    public List<ProcessorFileTask> getProcessorFileTasksForTransactionId(String transactionId, String serverType){
	        Query query = processorTransactionIdAndServerTypeQuery(transactionId, serverType);
	        LOGGER.debug(QUERY_STRING, "getProcessorFileTasksForTransactionId", query);
	        try
	        {
	        	return mongoTemplate.find (query, ProcessorFileTask.class, PROCESSOR_COLLECTION_NAME);
	        }
	        catch (Exception e)
	        {
	        	LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorFileTasksForTransactionId", query, ExceptionUtils.getStackTrace(e));
	        	throw e;
	        }
	    }

	 public Query processorTransactionIdAndServerTypeQuery(String transactionId, String serverType) {
	        Query query = new Query();
	        query.addCriteria(
	          Criteria.where(PROCESSOR_TRANSACTION_ID).is(transactionId)
	        );

//	        ProcessorUtil.addServerTypeCriteria(serverType, query);
	        LOGGER.debug(QUERY_STRING, "processorTransactionIdAndServerTypeQuery", query);
	        return query;
	    }

	@Override
	public ProcessorTransaction getProcessTransactionInfoByTransactionId(String transactionId) {
		
		MongoOperations op = mongoTemplate;
		ObjectId objectId=new ObjectId(transactionId);
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(objectId));
        
        LOGGER.debug(QUERY_STRING, "findProcessorTransactionByObjectId", query);
        try
        {
        	return op.findOne(query, ProcessorTransaction.class, PROCESSOR_TRANSACTION_COLLECTION_NAME);
        }
        catch (Exception e)
        {
        	LOGGER.error(QUERY_EXCEPTION_STRING, "findProcessorTransactionByFileName", query, ExceptionUtils.getStackTrace(e));
        	throw e;
        }
        	
	}
	    
}

