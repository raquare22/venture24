/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/8/17.
 */

package com.optum.fds.paperless.domain.service;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;
import com.optum.fds.paperless.domain.util.FSConstants;
import com.optum.fds.paperless.exception.InvalidExpressionException;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.jobs.ProcessorCoreJob;
import com.optum.fds.paperless.mongo.jobs.RestApiJob;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.mongo.processors.ProcessorMapping;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.util.ProcessorUtil;
import com.optum.fds.paperless.workflow.constants.Workflow;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

@Service("processorService")
public class ProcessorServiceImpl implements ProcessorService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessorServiceImpl.class);
    private static final String PROCESSOR_COLLECTION_NAME = "processor";
    private static final String PROCESSOR_TRANSACTION_COLLECTION_NAME = "processorTransaction";
    private static final String PROCESSOR_FILE_TASK_COLLECTION = "processorFileTask";
    private static final String PROCESSOR_MAPPING_COLLECTION_NAME = "processorMapping";
    private static final String APP_IDENTIFIER = "appIdentifier";
    private static final String SPACE_ID = "spaceId";
    private static final String TARGET_ID = "targetId";
    private static final String TARGET_TYPE = "targetType";
    private static final String QUERY_STRING = "{} query={}";
    private static final String QUERY_ADDITIONAL_INFO_STRING = "{} query={}, {}={}";
    private static final String PROCESSOR_RECORD_TYPE_FIELD_NAME = "processorRecordType";
    private static final String PROCESSOR_JOB_TYPE = "processorJobType";
    private static final String STATUS_KEY = "status";
    private static final String ACK_STATUS_KEY = "ackStatus";
    private static final String LOCKED_KEY = "locked";
    private static final String JOB_COLLECTION_NAME = "job";
    private static final String JOBTYPE = "jobType";
    private static final String DATE_MODIFIED = "dateModified";
    private static final String PROCESSOR_TYPE = "processorType";
    private static final String PROCESSOR_TRANSACTION_ID = "processorTransactionId";
    private static final String CSV_PROCESSOR_TRANSACTION_ID = "csvProcessorTransactionId";
    private static final String FILE_ROW_NUMBER = "fileRowNumber";
    private static final String CONFIG_SPACE_ID = "configSpaceId";
    private static final String QUERY_EXCEPTION_STRING = "{} query={} {}";
	private static final String STATUS = "status";
	private static final String ID = "id";



    @Autowired
    MongoTemplate mongoTemplate;
    private static final ThreadLocal<SimpleDateFormat> sdf = ThreadLocal.withInitial(
            () -> new SimpleDateFormat("MM/dd/yyyy HH:mm:ss"));

    @Override
    public boolean deleteProcessor(String processorRecordType, String processorType, int startTimeOffset) {
        MongoOperations op = mongoTemplate;
        Date processorLastModifiedDate = new Date(System.currentTimeMillis() - ((long) startTimeOffset * FSConstants.MILLISECONDS_IN_A_DAY));

        Query query = new Query().addCriteria(
                Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(processorRecordType)
                        .and(STATUS_KEY).in(MetaDataStatus.IN_PROCESS, MetaDataStatus.NEW)
                        .and(PROCESSOR_TYPE).is(processorType).and(DATE_MODIFIED).lte(processorLastModifiedDate)
        );

        LOGGER.debug(QUERY_ADDITIONAL_INFO_STRING, "deleteProcessor", query, "processorLastModifiedDate", sdf.get().format(processorLastModifiedDate));
        try {
            op.findAllAndRemove(query, ProcessorMapping.class, PROCESSOR_COLLECTION_NAME);
            return true;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "deleteProcessor", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public JobMetaData deleteProcessorJobFromStack(String jobId) {
        String msg = String.format("processor job to delete from Stack: %s", jobId);
        LOGGER.debug(msg);
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(jobId));
        LOGGER.debug(QUERY_STRING, "deleteProcessorJobFromStack", query);
        try {
            return op.findAndRemove(query, JobMetaData.class, "job");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "deleteProcessorJobFromStack", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public boolean deleteProcessorMetaData(String id, String appIdentifier) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(id))
                .addCriteria(Criteria.where(APP_IDENTIFIER).is(appIdentifier));
        LOGGER.debug(QUERY_STRING, "deleteProcessorMetaData", query);
        try {
            return op.findAndRemove(query, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME) != null;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "deleteProcessorMetaData", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<ProcessorMetaData>findAllAvailableProcessorMetaData(Date startDate, Date endDate) {
        LOGGER.debug("Entering findAllAvailableProcessorMetaData");

        Query query = new Query();
        Criteria endDateCriteria = new Criteria().orOperator(
                Criteria.where("endDate").gt(endDate),
                Criteria.where("endDate").exists(false)
        );

        Criteria statusCriteria = getValidStatusCriteria();

        Criteria criterias = new Criteria().andOperator(endDateCriteria, statusCriteria);

        query.addCriteria(Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processor))
                .addCriteria(Criteria.where("startDate").lte(startDate))
                .addCriteria(criterias);

        LOGGER.debug(QUERY_STRING, "findAllAvailableProcessorMetaData", query);
        List<ProcessorMetaData> processorMetaData;
        try {
            processorMetaData = mongoTemplate.find(query, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findAllAvailableProcessorMetaData", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
        String msg = String.format("Number of docs returned: %d", processorMetaData.size());
        LOGGER.debug(msg);
        LOGGER.debug("Leaving processor by startDate and endDate");

        return processorMetaData;
    }

    @Override
    public List<ProcessorMetaData> findAllAvailableProcessorMetaData() {
        LOGGER.debug("Entering findAllAvailableProcessorMetaData");

        Query query = new Query();

        Criteria statusCriteria = getValidStatusCriteria();

        Criteria criterias = new Criteria().andOperator(statusCriteria);

        query.addCriteria(Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processor))
                .addCriteria(criterias);

        LOGGER.debug(QUERY_STRING, "findAllAvailableProcessorMetaData", query);
        try {
            List<ProcessorMetaData> processorMetaData = mongoTemplate.find(query, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
            String msg = String.format("Number of docs returned: %d", processorMetaData.size());
            LOGGER.debug(msg);
            LOGGER.debug("Leaving processor by startDate and endDate");

            return processorMetaData;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findAllAvailableProcessorMetaData", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<ProcessorMetaData> findAllUnplannedProcessorLockMetaData() {
        LOGGER.debug("findAllUnplannedProcessorLockMetaData-->Enter");

        Query query = new Query();

        Criteria statusCriteria = new Criteria();
        statusCriteria = statusCriteria.and(STATUS_KEY).in(MetaDataStatus.IN_PROCESS);
        statusCriteria = statusCriteria.and(LOCKED_KEY).is(true);

        query.addCriteria(Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processor))
                .addCriteria(statusCriteria);

        LOGGER.debug(QUERY_STRING, "findAllUnplannedProcessorLockMetaData", query);
        try {
            List<ProcessorMetaData> processorMetaData = mongoTemplate.find(query, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
            LOGGER.debug("Number of locked processor returned: {}", processorMetaData.size());
            LOGGER.debug("findAllUnplannedProcessorLockMetaData--Exit");
            return processorMetaData;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findAllUnplannedProcessorLockMetaData", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public ProcessorMetaData findProcessorMetaDataByFileName(String zipFilename, String appId) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("fileName").is(zipFilename))
                .addCriteria(Criteria.where(APP_IDENTIFIER).is(appId));
        LOGGER.debug(QUERY_STRING, "findProcessorMetaDataByFileName", query);
        try {
            return op.findOne(query, ProcessorMetaData.class, PROCESSOR_TRANSACTION_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findProcessorMetaDataByFileName", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public ProcessorTransaction findProcessorTransactionByFileName(String zipFileName, Integer configSpaceId) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("fileName").is(zipFileName))
                .addCriteria(Criteria.where(CONFIG_SPACE_ID).is(configSpaceId));
        LOGGER.debug(QUERY_STRING, "findProcessorTransactionByFileName", query);
        try {
            return op.findOne(query, ProcessorTransaction.class, PROCESSOR_TRANSACTION_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findProcessorTransactionByFileName", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public ProcessorMetaData findProcessorMetaDataById(String processorId, String appId) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(processorId))
                .addCriteria(Criteria.where(APP_IDENTIFIER).is(appId));
        LOGGER.debug(QUERY_STRING, "findProcessorMetaDataById", query);
        try {
            return op.findOne(query, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findProcessorMetaDataById", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }


    @Override
    @SuppressWarnings("rawtypes")
    public JobMetaData findTopOfProcessorJobQueueForProcessors(String serverType, List activeProcessorIds) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(STATUS_KEY).is("ACTIVE"))
                .addCriteria(Criteria.where(JOBTYPE).in("zipFileProcessor", "metadataFileProcessor",
                        "cleanUpProcessor", "csvFileProcessor", "processorRestApiJob"))
                .addCriteria(Criteria.where(PROCESSOR_JOB_TYPE).in("processorJob", "csvProcessorJob", null));
        LOGGER.debug(QUERY_STRING, "findTopOfProcessorJobQueueForProcessors", query);
        Update update = new Update();
        update.set(STATUS_KEY, "IN_PROCESS");
        update.set(DATE_MODIFIED, new Date());
        try {
            return op.findAndModify(query.limit(1), update, JobMetaData.class, "job");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findTopOfProcessorJobQueueForProcessors", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    @SuppressWarnings("rawtypes")
    public JobMetaData findTopOfRestApiJobQueueForProcessors(String serverType, List activeProcessorIds) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(STATUS_KEY).is("ACTIVE"))
                .addCriteria(Criteria.where(PROCESSOR_JOB_TYPE).is("processorRestApiJob"))
                .addCriteria(Criteria.where(JOBTYPE).in("zipFileProcessor", "metadataFileProcessor",
                        "cleanUpProcessor", "csvFileProcessor", "processorRestApiJob"));
        LOGGER.debug(QUERY_STRING, "findTopOfRestApiJobQueueForProcessors", query);
        Update update = new Update();
        update.set(STATUS_KEY, "IN_PROCESS");
        update.set(DATE_MODIFIED, new Date());
        try {
            return op.findAndModify(query.limit(1), update, JobMetaData.class, "job");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findTopOfRestApiJobQueueForProcessors", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<String> retrieveJobIdList(int limit) {
        Query query = new Query();
        query.addCriteria(Criteria.where(STATUS_KEY).is("ACTIVE"))
                .addCriteria(Criteria.where(JOBTYPE).in("zipFileProcessor", "metadataFileProcessor",
                        "cleanUpProcessor", "csvFileProcessor", "processorRestApiJob"))
                .addCriteria(Criteria.where(PROCESSOR_JOB_TYPE).in("processorJob", "csvProcessorJob", null));
        query.limit(limit).fields().include("_id");
        return mongoTemplate.find(query, JobMetaData.class, JOB_COLLECTION_NAME)
                .stream().map(JobMetaData::getId).collect(Collectors.toList());
    }

    @Override
    public List<String> retrieveRestApiJobIdList(int limit) {
        Query query = new Query();
        query.addCriteria(Criteria.where(STATUS_KEY).is("ACTIVE"))
                .addCriteria(Criteria.where(PROCESSOR_JOB_TYPE).is("processorRestApiJob"))
                .addCriteria(Criteria.where(JOBTYPE).in("zipFileProcessor", "metadataFileProcessor",
                        "cleanUpProcessor", "csvFileProcessor", "processorRestApiJob"));
        query.limit(limit).fields().include("_id");
        return mongoTemplate.find(query, JobMetaData.class, JOB_COLLECTION_NAME)
                .stream().map(JobMetaData::getId).collect(Collectors.toList());
    }

    @Override
    public boolean findProcessorJobByTransactionIdFromQueue(String processorTransactionId, String serverType) {
        LOGGER.debug("Entering findProcessorJobByTransactionIdFromQueue");
        Query query = processorTransactionIdAndServerTypeQuery(processorTransactionId, serverType);
        LOGGER.debug(QUERY_STRING, "findProcessorJobByTransactionIdFromQueue", query);
        try {
            return mongoTemplate.exists(query, ProcessorMetaData.class, "job");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findProcessorJobByTransactionIdFromQueue", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<JobMetaData> findProcessorJobsByTransactionIdFromQueue(String processorTransactionId, String serverType) {
        MongoOperations op = mongoTemplate;
        LOGGER.debug("Entering findProcessorJobByTransactionIdFromQueue");
        Query query = processorTransactionIdAndServerTypeQuery(processorTransactionId, serverType);
        LOGGER.debug(QUERY_STRING, "findProcessorJobsByTransactionIdFromQueue", query);
        try {
            return op.find(query, JobMetaData.class, JOB_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findProcessorJobsByTransactionIdFromQueue", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public ProcessorMapping getProcessorMapping(String appIdentifier, Integer spaceId) {
        Query query = new Query();
        query.addCriteria(Criteria.where(APP_IDENTIFIER).is(appIdentifier)
                .and(SPACE_ID).is(spaceId)
                .and(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processorMapping)
        );

        LOGGER.debug(QUERY_STRING, "getProcessorMapping", query);
        try {
            List<ProcessorMapping> hmds = mongoTemplate.find(query, ProcessorMapping.class, PROCESSOR_MAPPING_COLLECTION_NAME);
            if (!hmds.isEmpty()) {
                return hmds.get(0);
            }
            return null;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorMapping", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public ProcessorMetaData getProcessorMetaData(String id, String appIdentifier) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where("id").is(id)
                        .and(APP_IDENTIFIER).is(appIdentifier)
        );
        LOGGER.debug(QUERY_STRING, "getProcessorMetaData", query);
        try {
            List<ProcessorMetaData> hmds = mongoTemplate.find(query, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
            if (!hmds.isEmpty()) {
                return hmds.get(0);
            }
            return null;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorMapping", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public ProcessorFileTask getProcessorFileTask(String id, String appIdentifier, String serverType) {
        Query query = ProcessorUtil.getProcessorByServerTypeQuery(id, appIdentifier, serverType);
        LOGGER.debug(QUERY_STRING, "getProcessorFileTask", query);
        try {
            List<ProcessorFileTask> hmds = mongoTemplate.find(query, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION);
            if (!hmds.isEmpty()) {
                return hmds.get(0);
            }
            return null;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorFileTask", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public ProcessorFileTask getProcessorFileTaskByProcessorTransactionIdRowNumber(String id, Integer rowNumber) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where(CSV_PROCESSOR_TRANSACTION_ID).is(id)
                        .and(FILE_ROW_NUMBER).is(rowNumber)
        );
        LOGGER.debug(QUERY_STRING, "getProcessorFileTaskForTargetId", query);
        List<ProcessorFileTask> hmds = mongoTemplate.find(query, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION);
        if (!hmds.isEmpty()) {
            return hmds.get(0);
        }
        return null;
    }

    @Override
    public ProcessorFileTask getProcessorFileTaskForTargetId(String targetId, String targetType, String appIdentifier) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where(TARGET_ID).is(targetId)
                        .and(TARGET_TYPE).is(targetType)
                        .and(APP_IDENTIFIER).is(appIdentifier)
        );
        LOGGER.debug(QUERY_STRING, "getProcessorFileTaskForTargetId", query);
        List<ProcessorFileTask> hmds = mongoTemplate.find(query, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION);
        if (!hmds.isEmpty()) {
            return hmds.get(0);
        }
        return null;
    }


    @Override
    public List<ProcessorFileTask> getProcessorFileTasksForTransactionId(String transactionId, String serverType) {
        Query query = processorTransactionIdAndServerTypeQuery(transactionId, serverType);
        LOGGER.debug(QUERY_STRING, "getProcessorFileTasksForTransactionId", query);
        try {
            return mongoTemplate.find(query, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorFileTasksForTransactionId", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<ProcessorFileTask> getPendingProcessorFileTaskForTransactionId(String transactionId, String serverType, String status, int processorTransactionPendingTime) {
        Query query = pendingprocessorTransactionIdAndServerTypeQuery(transactionId, serverType, status, processorTransactionPendingTime);
        LOGGER.debug(QUERY_STRING, "getPendingProcessorFileTaskForTransactionId", query);
        try {
            return mongoTemplate.find(query, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getPendingProcessorFileTaskForTransactionId", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<ProcessorFileTask> getLastProcessorFileTaskForTransactionId(String transactionId, String serverType) {
        Query query = processorTransactionIdAndServerTypeQuery(transactionId, serverType);
        ////query.with(new Sort(Sort.Direction.DESC, DATE_CREATED)); //TODO
        LOGGER.debug(QUERY_STRING, "getLastProcessorFileTaskForTransactionId", query);
        try {
            return mongoTemplate.find(query.limit(1), ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getLastProcessorFileTaskForTransactionId", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public Query processorTransactionIdAndServerTypeQuery(String transactionId, @SuppressWarnings("unused") String serverType) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where(PROCESSOR_TRANSACTION_ID).is(transactionId)
        );

//        ProcessorUtil.addServerTypeCriteria(serverType, query);
        LOGGER.debug(QUERY_STRING, "processorTransactionIdAndServerTypeQuery", query);
        return query;
    }


    public Query pendingprocessorTransactionIdAndServerTypeQuery(String transactionId, @SuppressWarnings("unused") String serverType, String status, int processorTransactionPendingTime) {
        Date currentDate = new Date(System.currentTimeMillis() - processorTransactionPendingTime * 1000L);
        Query query = new Query();
        query.addCriteria(
                Criteria.where(PROCESSOR_TRANSACTION_ID).is(transactionId)
                        .and(STATUS_KEY).is(status)
                        .and(DATE_MODIFIED).lte(currentDate)
        );

//        ProcessorUtil.addServerTypeCriteria(serverType, query);
        LOGGER.debug(QUERY_STRING, "pendingprocessorTransactionIdAndServerTypeQuery", query);
        return query;
    }

    @Override
    public ProcessorTransaction getProcessorTransaction(String id, String appIdentifier, String serverType) {
        Query query = ProcessorUtil.getProcessorByServerTypeQuery(id, appIdentifier, serverType);
        LOGGER.debug(QUERY_STRING, "getProcessorTransaction", query);
        try {
            List<ProcessorTransaction> hmds = mongoTemplate.find(query, ProcessorTransaction.class, PROCESSOR_TRANSACTION_COLLECTION_NAME);
            if (!hmds.isEmpty()) {
                return hmds.get(0);
            }
            return null;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorTransaction", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<ProcessorTransaction> getAllProcessorTransactionInStatus(String status, String serverType) {
        Query query = processorTransactionStatusAndServerTypeQuery(status, serverType);

        LOGGER.debug(QUERY_STRING, "getAllProcessorTransactionInStatus", query);
        try {
            return mongoTemplate.find(query, ProcessorTransaction.class, PROCESSOR_TRANSACTION_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getAllProcessorTransactionInStatus", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    private Query processorTransactionStatusListAndServerTypeQuery(List<String> statusList, @SuppressWarnings("unused") String serverType) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processorTransaction)
//                        .and(SERVER_TYPE).is(serverType)
                        .and(STATUS_KEY).in(statusList)
        );

        LOGGER.debug(QUERY_STRING, "processorTransactionStatusListAndServerTypeQuery", query);
        return query;
    }

    public Query processorTransactionStatusListAndServerTypeQuery(List<String> statusList, @SuppressWarnings("unused") String serverType, int startTimeOffset) {
        Query query = new Query();
        Date currentDate = new Date(System.currentTimeMillis() - ((long) startTimeOffset * 24 * 60 * 60 * 1000));
        query.addCriteria(
                Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processorTransaction)
//                        .and(SERVER_TYPE).is(serverType)
                        .and(STATUS_KEY).in(statusList)
                        .and(DATE_MODIFIED).gte(currentDate)
        );

        LOGGER.debug(QUERY_STRING, "processorTransactionStatusListAndServerTypeQuery", query);
        return query;
    }

    public Query processorTransactionStatusAndServerTypeQuery(String status, @SuppressWarnings("unused") String serverType) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processorTransaction)
//                        .and(SERVER_TYPE).is(serverType)
                        .and(STATUS_KEY).is(status)
        );

        LOGGER.debug(QUERY_STRING, "processorTransactionStatusAndServerTypeQuery", query);
        return query;
    }

    @Override
    public List<ProcessorTransaction> getAllProcessorTransactionInStatus(List<String> status, String serverType, int startTimeOffset) {
        Query query;
        if (startTimeOffset > 0) {
            query = processorTransactionStatusListAndServerTypeQuery(status, serverType, startTimeOffset);
        } else {
            query = processorTransactionStatusListAndServerTypeQuery(status, serverType);
        }
        LOGGER.debug(QUERY_STRING, "getAllProcessorTransactionInStatus", query);

        try {
            return mongoTemplate.find(query, ProcessorTransaction.class, PROCESSOR_TRANSACTION_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getAllProcessorTransactionInStatus", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<ProcessorTransaction> getAllProcessorTransactionInStatus(String status, String serverType, int startTimeOffset) {
        Query query;
        if (startTimeOffset > 0) {
            query = processorTransactionStatusAndServerTypeQuery(status, serverType, startTimeOffset);
        } else {
            query = processorTransactionStatusAndServerTypeQuery(status, serverType);
        }
        LOGGER.debug(QUERY_STRING, "getAllProcessorTransactionInStatus", query);
        try {
            return mongoTemplate.find(query, ProcessorTransaction.class, PROCESSOR_TRANSACTION_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getAllProcessorTransactionInStatus", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public Query processorTransactionStatusAndServerTypeQuery(String status, @SuppressWarnings("unused") String serverType, int startTimeOffset) {
        Query query = new Query();
        Date currentDate = new Date(System.currentTimeMillis() - ((long) startTimeOffset * 24 * 60 * 60 * 1000));
        query.addCriteria(
                Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processorTransaction)
//                        .and(SERVER_TYPE).is(serverType)
                        .and(STATUS_KEY).is(status)
                        .and(DATE_MODIFIED).gte(currentDate)
        );

        LOGGER.debug(QUERY_STRING, "processorTransactionStatusAndServerTypeQuery", query);
        return query;
    }

    @Override
    public List<ProcessorTransaction> getAllPendingProcessorTransactions(int processorTransactionPendingTime, List<String> statuses, String serverType) {
        Query query = pendingProcessorTransactionsQuery(processorTransactionPendingTime, statuses, serverType);
        LOGGER.debug(QUERY_STRING, "getAllPendingProcessorTransactions", query);
        try {
            return mongoTemplate.find(query, ProcessorTransaction.class, PROCESSOR_TRANSACTION_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getAllPendingProcessorTransactions", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public Query pendingProcessorTransactionsQuery(int processorTransactionPendingTime, List<String> statusList, @SuppressWarnings("unused") String serverType) {
        Query query = new Query();
        Date currentDate = new Date(System.currentTimeMillis() - processorTransactionPendingTime * 1000L);

        query.addCriteria(
                Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processorTransaction)
//                        .and(SERVER_TYPE).is(serverType)
                        .and(STATUS_KEY).in(statusList)
                        .and(DATE_MODIFIED).lte(currentDate)
        );
        LOGGER.debug(QUERY_STRING, "pendingProcessorTransactionsQuery", query);
        return query;
    }

    @Override
    public void lockProcessor(String id) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_STRING, "lockProcessor", query);

        Update update = getUpdate();
        update.set(LOCKED_KEY, true);

        updateProcessor(query, update);
    }

    @Override
    public boolean nameIsUnique(String name, String appIdentifier) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where("name").is(name)
                        .and(APP_IDENTIFIER).is(appIdentifier)
        );
        return !mongoTemplate.exists(query, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
    }

    @Override
    public ProcessorFileTask saveProcessorFileTask(ProcessorFileTask processorFileTask) {
        LOGGER.trace("Entering Processor File Task Save");
        mongoTemplate.save(processorFileTask, PROCESSOR_FILE_TASK_COLLECTION);
        LOGGER.trace("Exiting Processor File Task Save");

        return processorFileTask;
    }

    @Override
    public JobMetaData saveProcessorJobRecord(JobMetaData jobMetaData) {
        LOGGER.trace("Entering saveProccessorJobRecord");
        LOGGER.trace("jobMetaData = {}", jobMetaData);

        MongoOperations op = mongoTemplate;
        op.insert(jobMetaData, "job");
        return jobMetaData;
    }

    @Override
    public ProcessorMetaData saveProcessorMetaData(ProcessorMetaData processorMetaData) {
        LOGGER.debug("Entering Processor Save");

        mongoTemplate.save(processorMetaData, PROCESSOR_COLLECTION_NAME);

        LOGGER.trace("Exiting Processor Save");
        return processorMetaData;
    }

    @Override
    public ProcessorTransaction saveProcessorTransactionMetaData(ProcessorTransaction processorTransaction) {
        LOGGER.trace("Entering Processor Save");

        mongoTemplate.save(processorTransaction, PROCESSOR_TRANSACTION_COLLECTION_NAME);

        LOGGER.trace("Exiting Processor Save");
        return processorTransaction;
    }

    @Override
    public void setLastCleanRun(String id) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_STRING, "setLastCleanRun", query);

        Update update = getUpdate();
        update.set("lastCleanUpRun", new Date());

        updateProcessor(query, update);
    }

    @Override
    public void updateOneProcessorTransactionField(String id, String key, Object value) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_STRING, "updateOneProcessorTransactionField", query);
        Update update = getUpdate();
        update.set(key, value);

        updateProcessor(query, update);
    }

    @Override
    public void setLastRunAndStatus(String id, MetaDataStatus status) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_STRING, "setLastRunAndStatus", query);

        Update update = getUpdate();
        update.set("lastRun", new Date());
        update.set(STATUS_KEY, status.toString());

        try {
            mongoTemplate.updateMulti(query, update, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "setLastRunAndStatus", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public void unlockProcessor(String id) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_STRING, "unlockProcessor", query);

        Update update = getUpdate();
        update.set(LOCKED_KEY, false);

        updateProcessor(query, update);
    }

    @Override
    public void startProcessor(String id) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_STRING, "startProcessor", query);

        Update update = getUpdate();
        update.set(STATUS_KEY, MetaDataStatus.IN_PROCESS);

        updateProcessor(query, update);
    }

    @Override
    public void shutdownProcessor(String id) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_STRING, "shutdownProcessor", query);

        Update update = getUpdate();
        update.set(STATUS_KEY, MetaDataStatus.SHUTDOWN);

        updateProcessor(query, update);
    }

    @Override
    public void updateJobStatus(String id, String status) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_STRING, "updateJobStatus", query);

        Update update = getUpdate();
        update.set(STATUS_KEY, status);

        updateJob(query, update);
    }

    @Override
    public ProcessorFileTask updateProcessorExecutionRecordOfProcessorFileTaskRecord(ProcessorFileTask processorFileTask, Map<String, Object> resultMap, ProcessorCoreJob job) {
        ProcessorUtil.setExecutionRecordForActiviti(processorFileTask, resultMap, job);
        return updateProcessorFileTask(processorFileTask);
    }

    @Override
    public ProcessorTransaction updateProcessorExecutionRecordOfProcessorTransactionRecord(ProcessorTransaction processorTransaction, Map<String, Object> resultMap, ProcessorCoreJob job) {
        ProcessorUtil.setExecutionRecordForActiviti(processorTransaction, resultMap, job);
        if (!processorTransaction.getStatus().equals(MetaDataStatus.FATAL_ERROR)) {
            processorTransaction.setStatus(MetaDataStatus.IN_PROCESS);
        }
        return updateProcessorTransactionMetaData(processorTransaction);
    }


    @Override
    public ProcessorFileTask updateProcessorExecutionRecordOfProcessorFileTaskRecord(ProcessorFileTask processorFileTask, Map<String, Object> resultMap, RestApiJob job) {
        ProcessorUtil.setExecutionRecordForActiviti(processorFileTask, resultMap, job);
        return updateProcessorFileTask(processorFileTask);
    }

    @Override
    public ProcessorTransaction updateProcessorExecutionRecordOfProcessorTransactionRecord(ProcessorTransaction processorTransaction, Map<String, Object> resultMap, RestApiJob job) {
        ProcessorUtil.setExecutionRecordForActiviti(processorTransaction, resultMap, job);
        if (!processorTransaction.getStatus().equals(MetaDataStatus.FATAL_ERROR)) {
            processorTransaction.setStatus(MetaDataStatus.IN_PROCESS);
        }
        return updateProcessorTransactionMetaData(processorTransaction);
    }

    @Override
    public ProcessorFileTask updateProcessorFileTask(ProcessorFileTask processorFileTask) {
        processorFileTask.setDateModified(new Date());
        return saveProcessorFileTask(processorFileTask);
    }

    @Override
    public ProcessorMetaData updateProcessorMetaData(ProcessorMetaData processorMetaData) {
        processorMetaData.setDateModified(new Date());
        return saveProcessorMetaData(processorMetaData);
    }

    @Override
    public ProcessorTransaction updateProcessorTransactionMetaData(ProcessorTransaction processorTransaction) {
        processorTransaction.setDateModified(new Date());
        return saveProcessorTransactionMetaData(processorTransaction);
    }

    @Override
    public JobMetaData findJobByProcessorTransactionIdByWorkflow(String processorTransactionId, String workFlow, String serverType) {
        MongoOperations op = mongoTemplate;
        Query query = findJobByProcessorTransactionIdByWorkflowQuery(workFlow, processorTransactionId, serverType);
        LOGGER.debug(QUERY_STRING, "findJobByProcessorTransactionIdByWorkflow", query);
        return op.findOne(query, JobMetaData.class, "job");
    }

    public Query findJobByProcessorTransactionIdByWorkflowQuery(String workFlow, String processorTransactionId, @SuppressWarnings("unused") String serverType) {
        Query query = new Query();
        query.addCriteria(Criteria.where("processorProcessorTransactionId").is(null))
                .addCriteria(Criteria.where("workFlow").is(workFlow))
                .addCriteria(Criteria.where(PROCESSOR_TRANSACTION_ID).is(processorTransactionId));
//        ProcessorUtil.addServerTypeCriteria(serverType, query);
        ////query.with(new Sort(Sort.Direction.ASC, DATE_CREATED)); ////TODO
        LOGGER.debug(QUERY_STRING, "findJobByProcessorTransactionIdByWorkflowQuery", query);
        return query;
    }


    @Override
    public List<ProcessorMetaData> findAllAvailableProcessorsToStart() {
        Query query = new Query();

        Criteria statusCriteria = new Criteria().orOperator(
                Criteria.where(STATUS_KEY).is(MetaDataStatus.SHUTDOWN)
        );

        query.addCriteria(Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processor))
                .addCriteria(statusCriteria);
        LOGGER.debug(QUERY_STRING, "findAllAvailableProcessorsToStart", query);
        try {
            return mongoTemplate.find(query, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findAllAvailableProcessorsToStart", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }


    @Override
    public List<ProcessorMetaData> findAllAvailableProcessorsForShutdown() {
        Query query = new Query();

        Criteria statusCriteria = new Criteria().orOperator(
                Criteria.where(STATUS_KEY).is(MetaDataStatus.NEW),
                Criteria.where(STATUS_KEY).is(MetaDataStatus.ACTIVE),
                Criteria.where(STATUS_KEY).is(MetaDataStatus.IN_PROCESS)
        );

        query.addCriteria(Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processor))
                .addCriteria(statusCriteria);
        LOGGER.debug(QUERY_STRING, "findAllAvailableProcessorsForShutdown", query);
        try {
            return mongoTemplate.find(query, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findAllAvailableProcessorsForShutdown", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }


    private Update getUpdate() {
        Update update = new Update();
        update.set(DATE_MODIFIED, new Date());

        return update;
    }

    private void updateProcessor(Query query, Update update) {
        mongoTemplate.updateFirst(query, update, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
    }

    private void updateJob(Query query, Update update) {
        mongoTemplate.updateFirst(query, update, JobMetaData.class, JOB_COLLECTION_NAME);
    }

    @Override
    public List<ProcessorFileTask> getProcessorFileTasksForTransactionIdByStatus(String transactionId, String status) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where(PROCESSOR_TRANSACTION_ID).is(transactionId)
                        .and(STATUS_KEY).is(status)
        );
        LOGGER.debug(QUERY_STRING, "getProcessorFileTasksForTransactionIdByStatus", query);
        try {
            return mongoTemplate.find(query, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorFileTasksForTransactionIdByStatus", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    /**
     * This method will update the field specified in map.
     * Object can be of type array,date,int,String
     *
     * @param id the processor id
     * @param updateMap the map with fields to update
     * @throws InvalidExpressionException if id or updateMap is invalid
     */
    @Override
    public void updateProcessorTransactionFields(String id, Map<String, Object> updateMap) throws InvalidExpressionException {
        // This method changes the processorExecutionRecordList Integer and Date fields to Double and String respectfully
        if (!StringUtils.hasText(id))
            throw new InvalidExpressionException("Given string id is not valid, Not updating processor collection");
        if (CollectionUtils.isEmpty(updateMap))
            throw new InvalidExpressionException("Given map for update is not valid, Not updating processor collection");
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_STRING, "updateProcessorTransactionFields", query);
        Update update = new Update();
        for (Entry<String, Object> entryMap : updateMap.entrySet()) {
            update.set(entryMap.getKey(), entryMap.getValue());
        }
        updateProcessor(query, update);
    }

    public ProcessorMapping deleteProcessorMapping(String appIdentifier, Integer spaceId) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(SPACE_ID).is(spaceId));
        if (StringUtils.hasText(appIdentifier))
            query.addCriteria(Criteria.where(APP_IDENTIFIER).is(appIdentifier));
        LOGGER.debug(QUERY_STRING, "deleteProcessorMapping", query);
        return op.findAndRemove(query, ProcessorMapping.class, PROCESSOR_COLLECTION_NAME);
    }

    @Override
    public ProcessorMapping saveProcessorMapping(ProcessorMapping processorMapping) {
        LOGGER.trace("Entering ProcessorMapping Save");
        mongoTemplate.save(processorMapping, PROCESSOR_COLLECTION_NAME);
        LOGGER.trace("Exiting ProcessorMapping Save");
        return processorMapping;
    }

    private Criteria getValidStatusCriteria() {
        return new Criteria().orOperator(Criteria.where(STATUS_KEY)
                .in(MetaDataStatus.ACTIVE,
                        MetaDataStatus.NEW,
                        MetaDataStatus.IN_PROCESS,
                        MetaDataStatus.READY)
        );
    }

    @Override
    public void lockIncompleteProcessorFlag(String id) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_STRING, "lockIncompleteProcessorFlag", query);

        Update update = getUpdate();
        update.set("resolveIncompleteProcessorTransactionLocked", true);

        updateProcessor(query, update);

    }

    @Override
    public void unlockIncompleteProcessorFlag(String id) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_STRING, "unlockIncompleteProcessorFlag", query);

        Update update = getUpdate();
        update.set("resolveIncompleteProcessorTransactionLocked", false);

        updateProcessor(query, update);
    }

    @Override
    public void updateProcessorLastRun(String id) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_STRING, "updateProcessorLastRun", query);

        Update update = getUpdate();
        update.set("resolveIncompleteProcessorTransactionLastRun", new Date());

        updateProcessor(query, update);

    }

    @Override
    public void findAndUpdateJobsByStatusINProcess(String status, String jobType) {
        LOGGER.debug("Entering findJobsByStatusINProcess");
        Query query = new Query();
        query.addCriteria(Criteria.where(STATUS_KEY).is(status)).addCriteria(Criteria.where(JOBTYPE).nin(jobType));
        LOGGER.debug(QUERY_STRING, "findAndUpdateJobsByStatusINProcess", query);
        Update update = new Update();
        update.set(STATUS_KEY, MetaDataStatus.ACTIVE);
        mongoTemplate.updateMulti(query, update, JobMetaData.class, JOB_COLLECTION_NAME);
    }

    @Override
    public ProcessorTransaction getProcessorTransactionById(String id) {
        Query query = ProcessorUtil.getProcessorById(id);
        List<ProcessorTransaction> hmds = mongoTemplate.find(query, ProcessorTransaction.class, PROCESSOR_TRANSACTION_COLLECTION_NAME);
        if (!hmds.isEmpty()) {
            return hmds.get(0);
        }
        return null;
    }


//	@Override
//	public boolean areAllProcessorFileTasksCompletedForTransactionId(String transactionId) {
//		Query query = new Query().addCriteria(Criteria.where(PROCESSOR_TRANSACTION_ID).is(transactionId).and(STATUS_KEY)
//				.in(MetaDataStatus.IN_PROCESS, MetaDataStatus.NEW));
//		boolean jobAllComplete = false;
//
//		LOGGER.info(QUERY_STRING, "areAllProcessorFileTasksCompletedForTransactionId", query);
//		try {
//			List<ProcessorFileTask> processorFileTaskList = mongoTemplate.find(query.limit(1), ProcessorFileTask.class,
//					PROCESSOR_COLLECTION_NAME);
//			if (ProcessorUtil.isEmpty(processorFileTaskList)) {
//				jobAllComplete = true;
//			}
//		} catch (Exception e) {
//			LOGGER.error(QUERY_EXCEPTION_STRING, "areAllProcessorFileTasksCompletedForTransactionId", query,
//					ExceptionUtils.getStackTrace(e));
//
//		}
//		return jobAllComplete;
//	}

    @Override
    public void setAckStatus(String id, String ackStatus) throws InvalidExpressionException {
        if (!StringUtils.hasText(id)) {
            throw new InvalidExpressionException("Given string id is not valid, Not updating ackStatus");
        }
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));
        LOGGER.debug(QUERY_ADDITIONAL_INFO_STRING, "setAckStatus", query, ACK_STATUS_KEY, ackStatus);
        Update update = getUpdate();
        update.set(ACK_STATUS_KEY, ackStatus);
        try {
            mongoTemplate.updateFirst(query, update, ProcessorMetaData.class, Workflow.PROCESSOR_TRANSACTION);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "setAckStatus", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<String> findAllAvailableProcessorIds(Date start, Date end) {
        Query query = new Query();
        Criteria endDateCriteria = new Criteria().orOperator(
                Criteria.where("endDate").gt(end),
                Criteria.where("endDate").exists(false)
        );

        Criteria statusCriteria = getValidStatusCriteria();

        Criteria criterias = new Criteria().andOperator(endDateCriteria, statusCriteria);

        query.addCriteria(Criteria.where(PROCESSOR_RECORD_TYPE_FIELD_NAME).is(ProcessorRecordTypes.processor))
                .addCriteria(Criteria.where("startDate").lte(start))
                .addCriteria(criterias)
                .fields().include("_id");

        return mongoTemplate.find(query, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME)
                .stream().map(ProcessorMetaData::getId).collect(Collectors.toList());
    }


    @Override
    public JobMetaData findProcessorJob(String jobId) {
        return mongoTemplate.findById(jobId, JobMetaData.class, JOB_COLLECTION_NAME);
    }

    @Override
    public ProcessorMetaData findProcessor(String processorId) {
        return mongoTemplate.findById(processorId, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
    }

    @Override
    public ProcessorMetaData saveProcessor(ProcessorMetaData processorMetaData) {
        LOGGER.debug("Entering saveProcessor");
        MongoOperations op = mongoTemplate;
        op.insert(processorMetaData);
        LOGGER.debug("Leaving saveProcessor");
        return processorMetaData;
    }

    @Override
    public void updateProcessor(ProcessorMetaData processorMetaData, Map<String, Object> map) {
        try {
            if (map == null || !map.containsKey("processor")) {
                throw new InvalidExpressionException("Invalid map structure: 'processor' key is missing");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> processor = (Map<String, Object>) map.get("processor");
            if (processor == null || !processor.containsKey("action")) {
                throw new InvalidExpressionException("Invalid processor structure: 'action' key is missing");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> action = (Map<String, Object>) processor.get("action");
            if (action == null || !action.containsKey("config")) {
                throw new InvalidExpressionException("Invalid action structure: 'config' key is missing");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> objConfig = (Map<String, Object>) action.get("config");
            Query query = new Query();
            query.addCriteria(Criteria.where("id").is(processorMetaData.getId()));
            Update update = new Update().set("processor.action.config", objConfig);
            LOGGER.debug(QUERY_STRING, "updateProcessor", query);
            mongoTemplate.updateFirst(query, update, ProcessorMetaData.class, PROCESSOR_COLLECTION_NAME);
        } catch (InvalidExpressionException e) {
            LOGGER.error("Invalid expression in updateProcessor: {}", ExceptionUtils.getStackTrace(e));
            throw new RuntimeException(e);
        } catch (Exception e) {
            LOGGER.error("Error in updateProcessor: {}", ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public ProcessorMetaData getProcessorById(String id) {
        LOGGER.debug("Entering getProcessorById");
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));

        LOGGER.debug(QUERY_STRING, "getProcessorById", query);
        try {
            List<ProcessorMetaData> hmds = op.find(query, ProcessorMetaData.class,PROCESSOR_COLLECTION_NAME);
            if (!hmds.isEmpty()) {
                LOGGER.debug("Leaving getProcessorById");
                return hmds.get(0);
            }
            LOGGER.debug("Leaving getProcessorById");
            return null;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorById", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public ProcessorMetaData deleteProcessor(String id) {
        MongoOperations op = mongoTemplate;
        Update update = new Update();
        update.set(STATUS, MetaDataStatus.DELETED);
        LOGGER.debug(QUERY_STRING, "deleteProcessor", update);

        return op.findAndModify(query(where(ID).is(id)), update,
				new FindAndModifyOptions().returnNew(true), ProcessorMetaData.class,PROCESSOR_COLLECTION_NAME);
    }

}

