/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2013.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************/
//package com.optum.fs.domain.service;
package com.optum.fds.paperless.domain.service;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.optum.fds.paperless.mongo.ActionMetaData;
import com.optum.fds.paperless.mongo.AttachmentMetaData;
import com.optum.fds.paperless.mongo.FileMetaData;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.TransactionAttachmentInfo;
import com.optum.fds.paperless.mongo.TransactionDocumentListInfo;
import com.optum.fds.paperless.mongo.TransactionHookListInfo;
import com.optum.fds.paperless.mongo.TransactionListAttachmentsInfo;
import com.optum.fds.paperless.mongo.TransactionReportListInfo;
import com.optum.fds.paperless.mongo.VirusscanResult;

//import com.optum.fs.mongo.ActionMetaData;
//import com.optum.fs.mongo.AttachmentMetaData;
//import com.optum.fs.mongo.FileMetaData;
//import com.optum.fs.mongo.Transaction;
//import com.optum.fs.mongo.TransactionAttachmentInfo;
//import com.optum.fs.mongo.TransactionDocumentInfo;
//import com.optum.fs.mongo.TransactionDocumentListInfo;
//import com.optum.fs.mongo.TransactionHookInfo;
//import com.optum.fs.mongo.TransactionHookListInfo;
//import com.optum.fs.mongo.TransactionListAttachmentsInfo;
//import com.optum.fs.mongo.TransactionReportListInfo;
//import com.optum.fs.mongo.VirusscanResult;

/**
 * This class provides the implementation for Transaction Services.
 * 
 * @author VGangolli
 */
@Service
public class TransactionServiceImpl implements TransactionService {

	private static final Logger logger = LoggerFactory
			.getLogger(TransactionServiceImpl.class);

	@Autowired
	MongoTemplate mongoTemplate;

	
	@Override
	public void saveFileMetaData(String transactionId,
			List<FileMetaData> metadata, long totalFileSize) {
// US22532 TEMPORARILY TURN OFF MONGO TRANSACTIONS
//
//		logger.debug("Called saveFileMetaData");
//
//		MongoOperations op = mongoTemplate;
//		Transaction tranx = getTransactionMetaData(transactionId);
//
//		if (tranx.getFiles() == null) {
//			tranx.setFiles(new ArrayList<FileMetaData>());
//			;
//		}
//		for (FileMetaData f : metadata) {
//			tranx.getFiles().add(f);
//		}
//		tranx.setTotalFileSize(totalFileSize);
//		op.save(tranx);
//
//		logger.debug("saveFileMetaData completed successfully");
	}

	@Override
	public void saveActionMetaData(String transactionId,
			ActionMetaData metadata, List<VirusscanResult> virusScanResults) {
// US22532 TEMPORARILY TURN OFF MONGO TRANSACTIONS
//		MongoOperations op = mongoTemplate;
//		Transaction tranx = getTransactionMetaData(transactionId);
//
//		if (tranx.getActions() == null) {
//			tranx.setActions(new ArrayList<ActionMetaData>());
//		}
//		if (virusScanResults != null && virusScanResults.size() > 0) {
//			metadata.setVirusScanResults(virusScanResults);
//		}
//		tranx.getActions().add(metadata);
//		op.save(tranx);
	}

	public Transaction getTransactionMetaData(String transactionId) {
// US22532 TEMPORARILY TURN OFF MONGO TRANSACTIONS
//		MongoOperations op = mongoTemplate;
//		List<Transaction> tranx = op.find(query(where("transactionId").is(transactionId)),
//				Transaction.class);
//		if (tranx == null || tranx.size() < 1) {
//			Transaction transaction = new Transaction();
//			transaction.setTransactionId(transactionId);
//			return transaction;
//		}
//		return tranx.get(0);
// US22532 TEMPORARILY Return unsaved transaction so existing calling code will work.
		Transaction transaction = new Transaction();
		transaction.setTransactionId(transactionId);
		return transaction;
	}

	@Override
	public Transaction insertTransactionMetaData(Transaction transactionMetaData) {
		logger.debug("Insert: transactionMetaData.spaceId={}, appId={}", transactionMetaData.getSpaceId(), transactionMetaData.getAppIdentifier());
		//MongoOperations op = mongoTemplate;
		//op.insert(transactionMetaData);
		//logger.debug("Inserted mongo transaction");
		//return transactionMetaData;
// US22532 TEMPORARILY Return input(unsaved) transaction so existing calling code will work.
		if (transactionMetaData.getTransactionId() == null)
			transactionMetaData.setTransactionId(UUID.randomUUID().toString());
		// US22532 TEMPORARILY TURN OFF MONGO TRANSACTIONS
		MongoOperations op = mongoTemplate;
		if (op!= null){
			op.insert(transactionMetaData);
			logger.debug("Inserted mongo transaction");}
		return transactionMetaData;
	}


	@Override
	public Transaction saveTransactionMetaData(Transaction transactionMetaData) {
// US22532 TEMPORARILY TURN OFF MONGO TRANSACTIONS
 		MongoOperations op = mongoTemplate;
		op.save(transactionMetaData);
		logger.debug("Saved mongo transaction");
		return transactionMetaData;
// US22532 TEMPORARILY Return input(unsaved) transaction so existing calling code will work.
		////return transactionMetaData;
	}

	@Override
	public void deleteTransactionMetaData(String transactionId) {
// US22532 TEMPORARILY TURN OFF MONGO TRANSACTIONS
//		MongoOperations op = mongoTemplate;
//		Transaction tranx = getTransactionMetaData(transactionId);
//		if (tranx.getId() == null) {
//			return;// doesn't exist in mongo
//		} else {
//			op.remove(tranx);
//		}

	}

	@Override
	public Transaction saveTransationMetaData(String transactionId,
			List<TransactionAttachmentInfo> attachments) {
		MongoOperations op = mongoTemplate;
		Transaction tranx = getTransactionMetaData(transactionId);
		tranx.setAttachments(attachments);
// US22532 TEMPORARILY TURN OFF MONGO TRANSACTIONS
//		op.save(tranx);
// US22532 TEMPORARILY Return input(unsaved) transaction so existing calling code will work.
		return tranx;
	}

	/**
	 * Method to update field from the AttachmentMetaData in to the Transaction
	 * record as needed
	 */
	@Override
	public Transaction saveTransationMetaData(String transactionId,
			List<TransactionAttachmentInfo> attachments, List<AttachmentMetaData> amdList, boolean updateSpaceId) {

		logger.debug("Entering saveTransactionMetadata");
		MongoOperations op = mongoTemplate;
		Transaction trnsctn = getTransactionMetaData(transactionId);
		long totFileSize = 0;
		if(attachments == null || attachments.isEmpty()){
			return trnsctn;
		}
		for(AttachmentMetaData amd: amdList) {
			totFileSize += amd.getFileSize();
		}
		trnsctn.setAttachments(attachments);
		if (trnsctn.getClientId() == 0) {
			trnsctn.setClientId(amdList.get(0).getClientId());
		}
		if (trnsctn.getSpaceId() == 0 && updateSpaceId) {
			trnsctn.setSpaceId(amdList.get(0).getSpaceId());
		}
		trnsctn.setTotalFileSize(totFileSize);
// US22532 TEMPORARILY TURN OFF MONGO TRANSACTIONS
//		op.save(trnsctn);
		logger.debug("Leaving saveTransactionMetadata");
// US22532 TEMPORARILY Return unsaved transaction so existing calling code will work.
		return trnsctn;

	}

	/*
	public Transaction saveTransationMetaData(String transactionId,
			TransactionListAttachmentsInfo listAttsInfo,
			int clientId, String spaceId) {
		logger.info("Entering saveTransactionMetadata");
		MongoOperations op = mongoTemplate;
		Transaction trnsctn = getTransactionMetaData(transactionId);
		long totFileSize = 0;
		if(listAttsInfo.getAttachments() == null || listAttsInfo.getAttachments().isEmpty()){
			return trnsctn;
		}
		trnsctn.setTotalFileSize(totFileSize);
		trnsctn.setListAttachments(listAttsInfo);
		if (trnsctn.getClientId() == 0) {
			trnsctn.setClientId(clientId);
		}
		if (trnsctn.getSpaceId() == 0 ) {
			trnsctn.setSpaceId(spaceId);
		}
		
		op.save(trnsctn);
		logger.info("Leaving saveTransactionMetadata");

		return trnsctn;
	}
*/
	
	public Transaction saveTransationMetaData(String transactionId,
			TransactionListAttachmentsInfo listAttsInfo,  int clientId, String spaceId) {
		logger.debug("Entering saveTransactionMetadata");
		MongoOperations op = mongoTemplate;
		Transaction trnsctn = getTransactionMetaData(transactionId);

		if(listAttsInfo.getAttachments() == null || listAttsInfo.getAttachments().isEmpty()){
			return trnsctn;
		}

		trnsctn.setListAttachments(listAttsInfo);
		trnsctn.setTotalFileSize(getTotalFileSize(listAttsInfo));
		if(clientId != 0) {
			trnsctn.setClientId(clientId);
		}

		if(StringUtils.isNotEmpty(spaceId)){
			trnsctn.setSpaceId(Integer.parseInt(spaceId) );
		}
// US22532 TEMPORARILY TURN OFF MONGO TRANSACTIONS
//		op.save(trnsctn);
		logger.debug("Leaving saveTransactionMetadata");
// US22532 TEMPORARILY Return unsaved transaction so existing calling code will work.
		return trnsctn;
	}
	
	/**
	 * 
	 * @param listAttsInfo
	 * @return
	 */
	private long getTotalFileSize(TransactionListAttachmentsInfo listAttsInfo) {
		long totalFileSize = 0;
		List<TransactionAttachmentInfo> txAttInfoList = listAttsInfo.getAttachments();
		for(TransactionAttachmentInfo attInfo: txAttInfoList){
			totalFileSize += attInfo.getFileSize();
		}
		return totalFileSize;
	}

	
	
	   /**
     * 
     * @param listAttsInfo
     * @return
     */
    private Document getDocMetaData(TransactionDocumentListInfo trnsctnDocListInfo) {
    	Document docMetaData = null ;
       ////for(TransactionDocumentInfo transactionDocumentInfo: trnsctnDocListInfo){  //TODO
           // could change to return first value if multiple
            ////docMetaData = transactionDocumentInfo.getMetadata() ;
        ////}
        return docMetaData;
    }
	
	
	
	/**
	 * Method to Save TransactionDocumentInfo Object in a Given Transaction
	 * for POST Documents
	 */
	public Transaction saveTransationMetaData(String transactionId,
			int spaceId, int clientId, TransactionDocumentListInfo trnsctnDocListInfo) {

		logger.debug("Entering saveTransactionMetadata");
		MongoOperations op = mongoTemplate;
		Transaction trnsctn = getTransactionMetaData(transactionId);
		//Save spaceId and clientId info
		trnsctn.setSpaceId(spaceId);
		trnsctn.setClientId(clientId);

		//Set DocumentInfo in the Transaction
		trnsctn.setDocumentListInfo(trnsctnDocListInfo);
		Document docMetaData = getDocMetaData(trnsctnDocListInfo) ;
		if (docMetaData != null) {
		    trnsctn.setMetadata(docMetaData);
		}
// US22532 TEMPORARILY TURN OFF MONGO TRANSACTIONS
//		op.save(trnsctn);
		logger.debug("Leaving saveTransactionMetadata");
// US22532 TEMPORARILY Return unsaved transaction so existing calling code will work.
		return trnsctn;
	}
	

	
	/**
	 * Method to Save TransactionHookInfo Object in a Given Transaction
	 * for GET/PUT Documents
	 */
	@Override
	public Transaction saveTransationMetaData(String transactionId,
			int spaceId, int clientId, TransactionHookListInfo trnsctnHookListInfo) {
		logger.debug("Entering saveTransactionMetadata");
		MongoOperations op = mongoTemplate;
		Transaction trnsctn = getTransactionMetaData(transactionId);
		//Save spaceId and clientId info
		trnsctn.setSpaceId(spaceId);
		trnsctn.setClientId(clientId);

		//Set HookInfo in the Transaction
		trnsctn.setHookListInfo(trnsctnHookListInfo);
		Document hook = getHook(trnsctnHookListInfo) ;
		if (hook != null) {
		    trnsctn.setHook(hook);
		}
// US22532 TEMPORARILY TURN OFF MONGO TRANSACTIONS
//		op.save(trnsctn);
		logger.debug("Leaving saveTransactionMetadata");
// US22532 TEMPORARILY Return unsaved transaction so existing calling code will work.
		return trnsctn;
	}
	
	 private Document getHook(TransactionHookListInfo trnsctnHookListInfo) {
		 Document hook = null ;
	       ////for(TransactionHookInfo transactionDocumentInfo: trnsctnHookListInfo){ //TODO
	           // could change to return first value if multiple
	            ////hook = transactionDocumentInfo.getHook() ;
	        ////}
	        return hook;
	    }
		/**
		 * Method to Save TransactionReportInfo Object in a Given Transaction
		 * for GET
		 */
		@Override
		public Transaction saveTransationMetaData(String transactionId,
				int spaceId, int clientId, TransactionReportListInfo trnsctnReportListInfo) {
			logger.debug("Entering saveTransactionMetadata");
			MongoOperations op = mongoTemplate;
			Transaction trnsctn = getTransactionMetaData(transactionId);
			//Save spaceId and clientId info
			trnsctn.setSpaceId(spaceId);
			trnsctn.setClientId(clientId);

			//Set ReportInfo in the Transaction
			trnsctn.setReportListInfo(trnsctnReportListInfo);
			//org.bson.Document hook = getHook(trnsctnReportListInfo) ;
			//if (hook != null) {
			//    trnsctn.setHook(hook);
			//}
// US22532 TEMPORARILY TURN OFF MONGO TRANSACTIONS
//			op.save(trnsctn);
			logger.debug("Leaving saveTransactionMetadata");
// US22532 TEMPORARILY Return unsaved transaction so existing calling code will work.
			return trnsctn;
		}
		
		public void setMongoTemplate (MongoTemplate mongoTemplate) {
			this.mongoTemplate = mongoTemplate;
		}

		
}
