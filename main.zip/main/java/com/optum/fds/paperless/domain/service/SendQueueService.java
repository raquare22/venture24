package com.optum.fds.paperless.domain.service;

import java.util.Map;

import org.springframework.util.MultiValueMap;

import com.optum.fds.paperless.exception.HttpServerException;
import com.optum.fds.paperless.exception.ProcessException;

public interface SendQueueService {
	public String getPriorityQueue(Integer spaceId);

	public void sendRequestToQueue(Integer spaceId, String identifier, String targetId, String delegate, Map<String, Object> callbackMap) throws ProcessException, HttpServerException;

	public boolean addSendDocumentRequestToFds(Integer spaceId, String identifier, String targetId, String delegate, MultiValueMap<String, Object> requestMap,
		Map<String, Object> callbackMap, Map<String, Object> restApiMsgServiceCallbackParams) throws HttpServerException;

	public boolean addSendDocumentRequestToFds(Integer spaceId, String identifier, String targetId, String delegate, MultiValueMap<String, Object> requestMap,
		Map<String, Object> callbackMap, Map<String, Object> restApiMsgServiceCallbackParams, int retryCnt) throws HttpServerException;
	
	public boolean addSendDocumentRequestToDoc360(Integer spaceId, String identifier, String targetId, String delegate, MultiValueMap<String, Object> requestMap,
			Map<String, Object> callbackMap, Map<String, Object> restApiMsgServiceCallbackParams) throws HttpServerException;
	
	public boolean addSendDocumentRequestToDoc360(Integer spaceId, String identifier, String targetId, String delegate, MultiValueMap<String, Object> requestMap,
			Map<String, Object> callbackMap, Map<String, Object> restApiMsgServiceCallbackParams, int retryCnt) throws HttpServerException;
}