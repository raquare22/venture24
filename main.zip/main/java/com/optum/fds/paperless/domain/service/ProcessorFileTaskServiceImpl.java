package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.jobs.ProcessorCoreJob;
import com.optum.fds.paperless.mongo.jobs.RestApiJob;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorFileTask;
import com.optum.fds.paperless.util.ProcessorUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service("processorFileTaskService")
public class ProcessorFileTaskServiceImpl implements ProcessorFileTaskService {


    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessorFileTaskServiceImpl.class);

    private static final String PROCESSOR_COLLECTION_NAME = "processor";
    private static final String PROCESSOR_FILE_TASK_COLLECTION_NAME = "processorFileTask";
    private static final String APP_IDENTIFIER = "appIdentifier";
    private static final String TARGET_ID = "targetId";
    private static final String TARGET_TYPE = "targetType";
    private static final String QUERY_STRING = "{} query={}";
    private static final String PROCESSOR_RECORD_TYPE_FIELD_NAME = "processorRecordType";
    private static final String STATUS_KEY = "status";
    private static final String ACK_STATUS_KEY = "ackStatus";
    private static final String LOCKED_KEY = "locked";
    private static final String SERVER_TYPE = "serverType";
    private static final String DATE_MODIFIED = "dateModified";
    private static final String PROCESSOR_TYPE = "processorType";
    private static final String PROCESSOR_TRANSACTION_ID = "processorTransactionId";
    private static final String CONFIG_SPACE_ID = "configSpaceId";
    private static final String QUERY_EXCEPTION_STRING = "{} query={} {}";

    @Autowired
    MongoTemplate mongoTemplate;

    private SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

    public ProcessorFileTask getProcessorFileTaskById(String processorFileTaskId, String appIdentifier) {
        ProcessorFileTask retVal = null;
        Query query = new Query();
        query.addCriteria(
                Criteria.where("id").is(processorFileTaskId)
                        .and(APP_IDENTIFIER).is(appIdentifier)
        );
        LOGGER.debug(QUERY_STRING, "getProcessorFileTaskById", query);
        try {
            // processor
            List<ProcessorFileTask> hmds = mongoTemplate.find(query, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION_NAME);
            if (hmds != null && !hmds.isEmpty()) {
                retVal = hmds.get(0);
            }
            return retVal;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorFileTask", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public ProcessorFileTask updateProcessorExecutionRecordOfProcessorFileTaskRecord(ProcessorFileTask processorFileTask, Map<String, Object> resultMap, ProcessorCoreJob job) {
        ProcessorUtil.setExecutionRecordForActiviti(processorFileTask, resultMap, job);
        return updateProcessorFileTask(processorFileTask);

    }

    public ProcessorFileTask updateProcessorExecutionRecordOfProcessorFileTaskRecord(ProcessorFileTask processorFileTask, Map<String, Object> resultMap, RestApiJob job) {
        ProcessorUtil.setExecutionRecordForActiviti(processorFileTask, resultMap, job);
        return updateProcessorFileTask(processorFileTask);
    }


    public ProcessorFileTask updateProcessorFileTask(ProcessorFileTask processorFileTask) {
        processorFileTask.setDateModified(new Date());
        return saveProcessorFileTask(processorFileTask);
    }

    public ProcessorFileTask updateProcessorFileTask(String id, String appId, String key, String value) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where("id").is(id)
                        .and(APP_IDENTIFIER).is(appId)
        );
        Update update = new Update();
        update.set(key, value);
        update.set(DATE_MODIFIED, new Date());

        try {
            return mongoTemplate.findAndModify(query.limit(1), update, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "updateProcessorFileTask", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public ProcessorFileTask getProcessorFileTask(String id, String appIdentifier, String serverType) {
        ProcessorFileTask retVal = null;
        Query query = ProcessorUtil.getProcessorByServerTypeQuery(id, appIdentifier, serverType);
        LOGGER.debug(QUERY_STRING, "getProcessorFileTask", query);
        try {
            List<ProcessorFileTask> hmds = mongoTemplate.find(query, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION_NAME);
            if (hmds != null && !hmds.isEmpty()) {
                retVal = hmds.get(0);
            }
            return retVal;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorFileTask", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }

    }

    public ProcessorFileTask getProcessorFileTaskForTargetId(String targetId, String targetType, String appIdentifier) {
        ProcessorFileTask retVal = null;
        Query query = new Query();
        query.addCriteria(
                Criteria.where(TARGET_ID).is(targetId)
                        .and(TARGET_TYPE).is(targetType)
                        .and(APP_IDENTIFIER).is(appIdentifier)
        );
        LOGGER.debug(QUERY_STRING, "getProcessorFileTaskForTargetId", query);
        List<ProcessorFileTask> hmds = mongoTemplate.find(query, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION_NAME);
        if (hmds != null && !hmds.isEmpty()) {
            retVal = hmds.get(0);
        }
        return retVal;
    }

    public ProcessorFileTask saveProcessorFileTask(ProcessorFileTask processorFileTask) {
        LOGGER.trace("Entering Processor File Task Save");
        mongoTemplate.save(processorFileTask, PROCESSOR_FILE_TASK_COLLECTION_NAME);
        LOGGER.trace("Exiting Processor File Task Save");

        return processorFileTask;
    }

    public List<ProcessorFileTask> getProcessorFileTasksForTransactionId(String transactionId, String serverType) {
        Query query = processorTransactionIdAndServerTypeQuery(transactionId, serverType);
        LOGGER.debug(QUERY_STRING, "getProcessorFileTasksForTransactionId", query);
        try {
            return mongoTemplate.find(query, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorFileTasksForTransactionId", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public List<ProcessorFileTask> getProcessorFileTasksForTransactionIdByStatus(String transactionId, String status) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where(PROCESSOR_TRANSACTION_ID).is(transactionId)
                        .and(STATUS_KEY).is(status)
        );
        LOGGER.debug(QUERY_STRING, "getProcessorFileTasksForTransactionIdByStatus", query);
        try {
            return mongoTemplate.find(query, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getProcessorFileTasksForTransactionIdByStatus", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public List<ProcessorFileTask> getLastProcessorFileTaskForTransactionId(String transactionId, String serverType) {
        Query query = processorTransactionIdAndServerTypeQuery(transactionId, serverType);
        ////query.with(new Sort(Sort.Direction.DESC, DATE_CREATED)); ////TODO
        LOGGER.debug(QUERY_STRING, "getLastProcessorFileTaskForTransactionId", query);
        try {
            return mongoTemplate.find(query.limit(1), ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getLastProcessorFileTaskForTransactionId", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public List<ProcessorFileTask> getPendingProcessorFileTaskForTransactionId(String transactionId, String serverType, String status, int processorTransactionPendingTime) {
        Query query = pendingProcessorTransactionIdAndServerTypeQuery(transactionId, serverType, status, processorTransactionPendingTime);
        LOGGER.debug(QUERY_STRING, "getPendingProcessorFileTaskForTransactionId", query);
        try {
            return mongoTemplate.find(query, ProcessorFileTask.class, PROCESSOR_FILE_TASK_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getPendingProcessorFileTaskForTransactionId", query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }


    public boolean areAllProcessorFileTasksCompletedForTransactionId(String transactionId) {
        Query query = new Query().addCriteria(Criteria.where(PROCESSOR_TRANSACTION_ID).is(transactionId).and(STATUS_KEY)
                .in(MetaDataStatus.IN_PROCESS, MetaDataStatus.NEW));
        boolean jobAllComplete = false;

        LOGGER.debug(QUERY_STRING, "areAllProcessorFileTasksCompletedForTransactionId", query);
        try {
            List<ProcessorFileTask> processorFileTaskList = mongoTemplate.find(query.limit(1), ProcessorFileTask.class,
                    PROCESSOR_FILE_TASK_COLLECTION_NAME);
            if (ProcessorUtil.isEmpty(processorFileTaskList)) {
                jobAllComplete = true;
            }
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "areAllProcessorFileTasksCompletedForTransactionId", query,
                    ExceptionUtils.getStackTrace(e));

        }
        return jobAllComplete;

    }


    public Query processorTransactionIdAndServerTypeQuery(String transactionId, String serverType) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where(PROCESSOR_TRANSACTION_ID).is(transactionId)
        );

//        ProcessorUtil.addServerTypeCriteria(serverType, query);
        LOGGER.debug(QUERY_STRING, "processorTransactionIdAndServerTypeQuery", query);
        return query;
    }

    public Query pendingProcessorTransactionIdAndServerTypeQuery(String transactionId, String serverType, String status, int processorTransactionPendingTime) {
        Date currentDate = new Date(System.currentTimeMillis() - processorTransactionPendingTime * 1000L);
        Query query = new Query();
        query.addCriteria(
                Criteria.where(PROCESSOR_TRANSACTION_ID).is(transactionId)
                        .and(STATUS_KEY).is(status)
                        .and(DATE_MODIFIED).lte(currentDate)
        );

//        ProcessorUtil.addServerTypeCriteria(serverType, query);
        LOGGER.debug(QUERY_STRING, "pendingprocessorTransactionIdAndServerTypeQuery", query);
        return query;
    }


}
