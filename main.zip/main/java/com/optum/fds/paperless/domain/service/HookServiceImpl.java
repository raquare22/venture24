/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2017.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who                  Revision
 * Dec 2016		Larry Lewandowski    Initial version
 * Jan 19 2017  Suman Halder 	 	 Updating hookExecutionRecord in hookTransaction while the processing of the job is done
 ****************************************************************/

package com.optum.fds.paperless.domain.service;

import com.optum.fds.paperless.mongo.AttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.HookEventType;
import com.optum.fds.paperless.mongo.HookEventType.Status;
import com.optum.fds.paperless.mongo.HookMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

@Service("hookService")
public class HookServiceImpl implements HookService {

    private static final Logger LOGGER = LoggerFactory.getLogger(HookServiceImpl.class);

    private static final String DEFAULT_STATUS = "AVAILABLE";

    private static final String DELETED_STATUS = "DELETED";

    private static final String JOB_COLLECTION_NAME = "job";

    private static final String CRON_EXPRESSION_HOOK_COLLECTION = "cronExpressionHook";

    private static final String HOOK_COLLECTION = "hook";

    private static final String LOCKED = "locked";
    private static final String QUERY_STRING = "{} query={}";
    private static final String QUERY_EXCEPTION_STRING = "{} query={} {}";

    private static final String ACTIVE = "ACTIVE";
    private static final String LEAVING_BY_HOOKID = "Leaving searchForJobs by hookId";
    private static final String ACTIVITI_JOB_ID = "activitiJobId";
    private static final String ACTIVITI_JOB_STATUS = "activitiJobStatus";
    private static final String APP_IDENTIFIER = "appIdentifier";
    private static final String SPACE_ID = "spaceId";
    private static final String STATUS = "status";
    private static final String HOOK_EVENT = "hookEvent";
    private static final String DATE_CREATED = "dateCreated";
    private static final String DATE_MODIFIED = "dateModified";
    private static final String JOB_TYPE = "jobType";
    private static final String GET_HOOK_BY_ID = "getHookById";
    private static final String TRANSACTION_ID = "transactionId";

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public HookMetaData saveHook(HookMetaData hookMetaData) {
        LOGGER.debug("Entering saveHook");
        MongoOperations op = mongoTemplate;
        op.insert(hookMetaData);
        LOGGER.debug("Leaving saveHook");
        return hookMetaData;
    }

    @Override
    public List<HookMetaData> findAllAvailableHookMetaData() {
        Query query = new Query();
        query.addCriteria(Criteria.where(STATUS).is(DEFAULT_STATUS));
        LOGGER.debug(QUERY_STRING, "findAllAvailableHookMetaData", query);
        try {
            return mongoTemplate.find(query, HookMetaData.class);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findAllAvailableHookMetaData", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public void registerEventOfInterest(HookEventType hookEventType) {
        MongoOperations op = mongoTemplate;
        Date now = new Date();
        hookEventType.setDateCreated(now);
        hookEventType.setDateModified(now);
        hookEventType.setStatus(Status.NEW);
        op.insert(hookEventType, HOOK_EVENT);
    }

    /**
     * N.B. this will filter out cron jobs and return only standard jobs
     */
    @Override
    public HookEventType findTopOfStackNewHookEvent() {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(STATUS).is(Status.NEW));
        query.with(Sort.by(Sort.Direction.ASC, DATE_CREATED));
        Update update = new Update();
        update.set(STATUS, Status.IN_PROCESS);
        update.set(DATE_MODIFIED, new Date());
        LOGGER.debug(QUERY_STRING, "findTopOfStackNewHookEvent", query);
        try {
            return op.findAndModify(query, update, HookEventType.class, HOOK_EVENT);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findTopOfStackNewHookEvent", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public DocumentMetaData findDocumentByTransactionId(String transactionId) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(TRANSACTION_ID).is(transactionId));
        LOGGER.debug(QUERY_STRING, "findDocumentByTransactionId", query);
        try {
            return op.findOne(query, DocumentMetaData.class, "document");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findDocumentByTransactionId", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<AttachmentMetaData> findAttachmentsByTransactionId(String transactionId) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(TRANSACTION_ID).is(transactionId));
        LOGGER.debug(QUERY_STRING, "findAttachmentsByTransactionId", query);
        try {
            return op.find(query, AttachmentMetaData.class, "attachment");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findAttachmentsByTransactionId", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public AttachmentMetaData findAttachmentByFsId(String fsId) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("fsId").is(fsId));
        LOGGER.debug(QUERY_STRING, "findAttachmentByFsId", query);
        try {
            return op.findOne(query, AttachmentMetaData.class, "attachment");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findAttachmentByFsId", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<HookMetaData> findAllHooksThatMatchTopLevelCriteria(HookEventType hookEvent) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria
                .where(SPACE_ID)
                .is(hookEvent.getSpaceId())
                .andOperator(
                        Criteria.where("hook.trigger.on_event.target").is(hookEvent.getTarget()),
                        Criteria.where("hook.trigger.on_event.method").is(hookEvent.getMethod()),
                        Criteria.where(STATUS).is(DEFAULT_STATUS),
                        Criteria.where("hookRecordType").is("hook")));
        if (HookEventType.EvalTime.PRE_PROCESS == hookEvent.getEvalTime()) {
            query.addCriteria(
                    Criteria.where("hook.eval_time").is(HookEventType.EvalTime.PRE_PROCESS.name()));
        } else {
            query.addCriteria(
                    Criteria.where("hook.eval_time").ne(HookEventType.EvalTime.PRE_PROCESS.name()));
        }

        query.with(Sort.by(Sort.Direction.ASC, "executionOrder"));
        LOGGER.debug(QUERY_STRING, "findAllHooksThatMatchTopLevelCriteria", query);
        try {
            return op.find(query, HookMetaData.class, "hook");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findAllHooksThatMatchTopLevelCriteria", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<HookTransactionMetaData> findIfHookTransactionExistsForDoc(
            DocumentMetaData document) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(SPACE_ID).is(document.getSpaceId())
                .andOperator(Criteria.where("targetId").is(document.getId())));
        LOGGER.debug(QUERY_STRING, "findIfHookTransactionExistsForDoc", query);
        try {
            return op.find(query, HookTransactionMetaData.class, "hook");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findIfHookTransactionExistsForDoc", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public List<HookTransactionMetaData> findHookTransactionMetaDataForDocAndHook(
            DocumentMetaData document, String hookId) {
        MongoOperations op = mongoTemplate;

        Query query = new Query();
        query.addCriteria(Criteria.where(SPACE_ID).is(document.getSpaceId())
                .andOperator(Criteria.where("targetId").is(document.getId()))
                .andOperator(Criteria.where("hookExecutionList.hookId").is(hookId)));
        LOGGER.debug(QUERY_STRING, "findDocumentByTransactionId", query);
        try {
            return op.find(query, HookTransactionMetaData.class, "hook");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findHookTransactionMetaDataForDocAndHook", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public HookMetaData getHookById(String appId, int spaceId, String id) {
        LOGGER.debug("Entering getHookById");
        HookMetaData retVal = null;
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(APP_IDENTIFIER).is(appId));
        query.addCriteria(Criteria.where(SPACE_ID).is(spaceId).and("id").is(id));

        LOGGER.debug(QUERY_STRING, GET_HOOK_BY_ID, query);
        try {
            List<HookMetaData> hmds = op.find(query, HookMetaData.class);
            if (CollectionUtils.isNotEmpty(hmds)) {
                retVal = hmds.get(0);
            }
            LOGGER.debug("Leaving getHookById");
            return retVal;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, GET_HOOK_BY_ID, query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public HookMetaData getHookById(String appId, String id) {
        LOGGER.debug("Entering getHookById");
        HookMetaData retVal = null;
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(APP_IDENTIFIER).is(appId));
        query.addCriteria(Criteria.where("id").is(id));

        LOGGER.debug(QUERY_STRING, GET_HOOK_BY_ID, query);
        try {
            List<HookMetaData> hmds = op.find(query, HookMetaData.class);
            if (CollectionUtils.isNotEmpty(hmds)) {
                retVal = hmds.get(0);
            }
            LOGGER.debug("Leaving getHookById");
            return retVal;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, GET_HOOK_BY_ID, query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<HookMetaData> getHooksByName(String appId, int spaceId, String name) {
        LOGGER.debug("Entering getHooksByName");
        Query query = new Query();
        query.addCriteria(Criteria.where(APP_IDENTIFIER).is(appId));
        query.addCriteria(Criteria.where(SPACE_ID).is(spaceId).and("name").is(name).and(STATUS)
                .is(DEFAULT_STATUS));

        LOGGER.debug(QUERY_STRING, "getHooksByName", query);
        try {
            List<HookMetaData> hmds = mongoTemplate.find(query, HookMetaData.class);
            LOGGER.debug("Leaving getHooksByName = list size: {}", hmds.size());
            return hmds;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getHooksByName", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }
    
	@Override
	public List<HookMetaData> getHookByNameAndSpaceId(String appId, int spaceId, String name) {
		
		LOGGER.debug("Entering getHooksByName");
        Query query = new Query();
        query.addCriteria(Criteria.where(APP_IDENTIFIER).is(appId));
        query.addCriteria(Criteria.where(SPACE_ID).is(spaceId).and("hook.name").is(name).and(STATUS)
                .is(DEFAULT_STATUS));

        LOGGER.debug(QUERY_STRING, "getHooksByName", query);
        try {
            List<HookMetaData> hmds = mongoTemplate.find(query, HookMetaData.class);
            LOGGER.debug("Leaving getHooksByName = list size: {}", hmds.size());
            return hmds;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getHooksByName", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
		
	}

    @Override
    public List<HookMetaData> getHooks(String appId, int spaceId, String status) {
        LOGGER.debug("Entering getHooks");
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(APP_IDENTIFIER).is(appId)
                .andOperator(Criteria.where(SPACE_ID).is(spaceId),
                        Criteria.where("hookRecordType").is("hook")));
        if (!StringUtils.isEmpty(status)) {
            query.addCriteria(new Criteria().and(STATUS).is(status));
        } else {
            query.addCriteria(new Criteria().and(STATUS).is(DEFAULT_STATUS));
        }
        LOGGER.debug(QUERY_STRING, "getHooks", query);
        try {
            List<HookMetaData> hmds = op.find(query, HookMetaData.class);
            LOGGER.debug("Leaving getHooks");

            return hmds;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "getHooks", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public HookMetaData putHookMetaData(HookMetaData hookMetaData) {
        LOGGER.debug("Entering putHookMetaData");
        MongoOperations op = mongoTemplate;
        String hookId = hookMetaData.getId();

        Update update = new Update();
        update.set(STATUS, hookMetaData.getStatus());
        update.set(DATE_MODIFIED, new Date());
        update.set(TRANSACTION_ID, hookMetaData.getTransactionId());
        update.set("revisions", hookMetaData.getRevisions());
        update.set("executionOrder", hookMetaData.getExecutionOrder());

        if (MapUtils.isNotEmpty(hookMetaData.getHook())) {
            update.set("hook", hookMetaData.getHook());
        }
        if (StringUtils.isNotEmpty(hookMetaData.getErrorMessage())) {
            update.set("errorMessage", hookMetaData.getErrorMessage());
        } else {
            update.unset("errorMessage");
        }

        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(hookId));

        // get the updated Hook object but do not go for fresh insertion
        FindAndModifyOptions options = new FindAndModifyOptions().returnNew(true).upsert(false);

        HookMetaData retVal;
        LOGGER.debug(QUERY_STRING, "putHookMetaData", query);
        try {
            retVal = op.findAndModify(query, update, options, HookMetaData.class);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "putHookMetaData", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }

        // after hook is deleted delete any jobs that remain for any non-post
        // hook
        List<JobMetaData> jmd = searchForJobs(hookId);
        if (jmd != null && !jmd.isEmpty()) {
            LOGGER.debug("Jobs exist, deleting entries:");
            deleteJobs(jmd);
        }
        if (LOGGER.isInfoEnabled()) {
            LOGGER.debug("Leaving putHookMetaData: hookId: {}, New Status: {}", retVal != null ? retVal.getId() : "NULL", retVal != null ? retVal.getStatus(): "NULL");
        }
        return retVal;
    }

    @Override
    public HookMetaData deleteHook(String appId, int spaceId, String id) {
        LOGGER.debug("Entering deleteHookById");
        HookMetaData retVal = null;
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(APP_IDENTIFIER).is(appId));
        query.addCriteria(Criteria.where(SPACE_ID).is(spaceId).and("id").is(id));

        Update update = new Update();
        update.set(STATUS, DELETED_STATUS);
        update.set(DATE_MODIFIED, new Date());
        // FindAndModifyOptions().returnNew(true) = newly updated document
        // FindAndModifyOptions().returnNew(false) = old document (not update
        // yet)
        LOGGER.debug(QUERY_STRING, "deleteHook", query);
        try {
            retVal = op.findAndModify(query, update, new FindAndModifyOptions().returnNew(true),
                    HookMetaData.class);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "deleteHook", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }

        // after hook is deleted delete any jobs that remain for any non-post
        // hook
        List<JobMetaData> jmd = searchForJobs(id);
        if (jmd != null && !jmd.isEmpty()) {
            LOGGER.debug("Jobs exist, deleting entries:");
            deleteJobs(jmd);
        }

        LOGGER.debug("Leaving deleteHookById");
        return retVal;
    }

    @Override
    public JobMetaData saveJobRecord(JobMetaData jobMetaData) {
        MongoOperations op = mongoTemplate;
        op.insert(jobMetaData, "job");
        return jobMetaData;
    }

    @Override
    public HookTransactionMetaData saveHookTransaction(
            HookTransactionMetaData hookTransactionMetaData) {
        MongoOperations op = mongoTemplate;
        op.insert(hookTransactionMetaData, "hookTransaction");
        return hookTransactionMetaData;
    }

    @Override
    public HookTransactionMetaData updateHookTransaction(
            HookTransactionMetaData hookTransactionMetaData) {
        MongoOperations op = mongoTemplate;

        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(hookTransactionMetaData.getId()));
        Update update = new Update();
        update.set(STATUS, ACTIVE);
        update.set(DATE_MODIFIED, new Date());
        update.set("hookExecutionList", hookTransactionMetaData.getHookExecutionList());
        LOGGER.debug(QUERY_STRING, "updateHookTransaction", query);
        try {
            return op.findAndModify(query, update, HookTransactionMetaData.class, "hookTransaction");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "updateHookTransaction", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public HookEventType deleteHookEventFromStack(String hookEventId) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(hookEventId));
        LOGGER.debug(QUERY_STRING, "deleteHookEventFromStack", query);
        try {
            return op.findAndRemove(query, HookEventType.class, HOOK_EVENT);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "deleteHookEventFromStack", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public JobMetaData deleteJobFromStack(String jobId) {
        LOGGER.debug("job to delete from Stack: {}", jobId);
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(jobId));
        LOGGER.debug(QUERY_STRING, "deleteJobFromStack", query);
        try {
            return op.findAndRemove(query, JobMetaData.class, "job");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "deleteJobFromStack", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public void deleteJobs(List<JobMetaData> jobIdList) {
        LOGGER.debug("Entering deleteJobs");
        for (JobMetaData job : jobIdList) {
            LOGGER.debug(deleteJobFromStack(job.getId()).toString());
        }
        LOGGER.debug("Leaving deleteJobs");
    }

    @Override
    public List<JobMetaData> searchAllJobs(int spaceId) {
        LOGGER.debug("Entering searchAllJobs");
        Query query = new Query();
        query.addCriteria(Criteria.where(SPACE_ID).is(spaceId));
        LOGGER.debug(QUERY_STRING, "searchAllJobs", query);
        try {
            List<JobMetaData> jobmetadata = mongoTemplate.find(query, JobMetaData.class, "jobs");
            LOGGER.debug("Number of jobs returned: {}", jobmetadata.size());
            LOGGER.debug(LEAVING_BY_HOOKID);
            return jobmetadata;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "searchStandardJobs", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<JobMetaData> searchStandardJobs(int spaceId) {
        LOGGER.debug("Entering searchStandardJobs");
        Query query = new Query();
        query.addCriteria(Criteria.where(SPACE_ID).is(spaceId));
        LOGGER.debug(QUERY_STRING, "searchStandardJobs", query);
        try {
            List<JobMetaData> jobmetadata = mongoTemplate.find(query, JobMetaData.class, "job");
            LOGGER.debug("Number of jobs returned: {}", jobmetadata.size());
            LOGGER.debug("Leaving searchStandardJobs by hookId");
            return jobmetadata;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "searchStandardJobs", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<JobMetaData> searchCronJobs(int spaceId) {
        LOGGER.debug("Entering searchCronJobs");
        Query query = new Query();
        query.addCriteria(Criteria.where(SPACE_ID).is(spaceId));
        LOGGER.debug(QUERY_STRING, "searchCronJobs", query);
        try {
            List<JobMetaData> jobmetadata = mongoTemplate.find(query, JobMetaData.class, "job");
            LOGGER.debug("Number of jobs returned: {}", jobmetadata.size());
            LOGGER.debug(LEAVING_BY_HOOKID);
            return jobmetadata;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "searchCronJobs", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<JobMetaData> searchAllJobsBySpaceIdHookId(int spaceId, String hookId) {
        LOGGER.debug("Entering searchAllJobsBySpaceIdHookId");
        Query query = new Query();
        query.addCriteria(Criteria.where(SPACE_ID).is(spaceId))
                .addCriteria(Criteria.where("hookId").is(hookId))
                .addCriteria(Criteria.where("hook.hook.trigger.on-event.method").is("cron"));
        LOGGER.debug(QUERY_STRING, "searchAllJobsBySpaceIdHookId", query);
        try {
            List<JobMetaData> jobmetadata = mongoTemplate.find(query, JobMetaData.class, "job");
            LOGGER.debug("Number of jobs returned: {}", jobmetadata.size());
            LOGGER.debug(LEAVING_BY_HOOKID);
            return jobmetadata;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "searchAllJobsBySpaceIdHookId", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<DocumentMetaData> searchDocumentsBySpaceIdAndDateField(int spaceId,
            String dateFieldName, String dateValueString) {
        LOGGER.debug("Entering searchDocumentsBySpaceIdAndDateField");
        Query query = new Query();
        query.addCriteria(Criteria.where(SPACE_ID).is(spaceId))
                .addCriteria(Criteria.where(STATUS).is(DEFAULT_STATUS))
                .addCriteria(Criteria.where(dateFieldName).gte(dateValueString));
        LOGGER.debug(QUERY_STRING, "searchDocumentsBySpaceIdAndDateField", query);
        try {
            List<DocumentMetaData> docmetadata = mongoTemplate
                    .find(query, DocumentMetaData.class, "document");
            LOGGER.debug("Number of docs returned: {}", docmetadata.size());
            LOGGER.debug("Leaving documents by datefield");
            return docmetadata;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "searchDocumentsBySpaceIdAndDateField", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<JobMetaData> searchForJobs(String hookId) {
        LOGGER.debug("Entering searchForJobs by hookId");
        Query query = new Query();
        query.addCriteria(Criteria.where("hookId").is(hookId))
                .addCriteria(Criteria.where("hook.hook.trigger.on-event.method").is("cron"));
        LOGGER.debug(QUERY_STRING, "searchForJobs", query);
        try {
            List<JobMetaData> jobmetadata = mongoTemplate.find(query, JobMetaData.class, "job");
            LOGGER.debug("Number of jobs returned: {}", jobmetadata.size());
            LOGGER.debug(LEAVING_BY_HOOKID);
            return jobmetadata;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "searchForJobs", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<JobMetaData> searchForJobs(String targetType, String targetId) {
        LOGGER.debug("Entering searchForJobs by targetId");
        Query query = new Query();
        query.addCriteria(Criteria.where("targetId").is(targetId))
                .addCriteria(Criteria.where("targetType").is(targetType))
                .addCriteria(Criteria.where("hook.hook.trigger.on_event.method").ne("post"));
        LOGGER.debug(QUERY_STRING, "searchForJobs", query);
        try {
            List<JobMetaData> jobmetadata = mongoTemplate.find(query, JobMetaData.class, "job");
            LOGGER.debug("Number of jobs returned: {}", jobmetadata.size());
            LOGGER.debug("Leaving searchForJobs by targetId");
            return jobmetadata;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "searchForJobs", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<JobMetaData> searchForAllJobs(String targetType, String targetId) {
        LOGGER.debug("Entering searchForAllJobs by targetId");
        Query query = new Query();
        query.addCriteria(Criteria.where("targetId").is(targetId))
                .addCriteria(Criteria.where("targetType").is(targetType))
                .addCriteria(Criteria.where("hook.hook.trigger.on_event.method").ne("post"));
        LOGGER.debug(QUERY_STRING, "searchForAllJobs", query);
        try {
            List<JobMetaData> jobmetadata = mongoTemplate.find(query, JobMetaData.class, "job");
            LOGGER.debug("Number of jobs returned: {}", jobmetadata.size());
            LOGGER.debug("Leaving searchForAllJobs by targetId");
            return jobmetadata;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "searchForAllJobs", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<JobMetaData> searchForAllJobTypes(String targetType, String targetId) {
        LOGGER.debug("Entering searchForAllJobTypes by targetId");
        Query query = new Query();
        query.addCriteria(Criteria.where("targetId").is(targetId))
                .addCriteria(Criteria.where("targetType").is(targetType));
        LOGGER.debug(QUERY_STRING, "searchForAllJobTypes", query);
        try {
            List<JobMetaData> jobmetadata = mongoTemplate.find(query, JobMetaData.class, "job");
            LOGGER.debug("Number of jobs returned: {}", jobmetadata.size());
            LOGGER.debug("Leaving searchForAllJobTypes by targetId");
            return jobmetadata;
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "searchForAllJobTypes", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<String> retrieveHookJobIdList(int limit) {
        Query query = findTopOfStackNewJobQuery();
        query.limit(limit)
                .fields().include("_id");
        return mongoTemplate.find(query, JobMetaData.class, JOB_COLLECTION_NAME)
                .stream().map(JobMetaData::getId).collect(Collectors.toList());
    }

    @Override
    public JobMetaData findHookJob(String jobId) {
        return mongoTemplate.findById(jobId, JobMetaData.class);
    }

    @Override
    public JobMetaData findTopOfStackNewJob() {
        MongoOperations op = mongoTemplate;
        Query query = findTopOfStackNewJobQuery();
        Update update = new Update();
        update.set(STATUS, "IN_PROCESS");
        update.set(DATE_MODIFIED, new Date());
        try {
            return op.findAndModify(query.limit(1), update, JobMetaData.class, "job");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findTopOfStackNewJob", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    Query findTopOfStackNewJobQuery() {
        Query query = new Query();
        query.addCriteria(Criteria.where(STATUS).is(ACTIVE))
                .addCriteria(Criteria.where(JOB_TYPE).in(
                        "typeOne",
                        "now",
                        "typeOneChanged",
                        "typeTwoChanged",
                        "typeTwo",
                        "standard",
                        "typeThree"));
        query.with(Sort.by(Sort.Direction.ASC, DATE_CREATED));
        return query;
    }

    @Override
    public List<JobMetaData> findJobsByStatus(MetaDataStatus status) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(STATUS).is(status.toString()))
                .addCriteria(Criteria.where(JOB_TYPE).in(
                        "typeOne",
                        "now",
                        "typeOneChanged",
                        "typeTwoChanged",
                        "typeTwo",
                        "standard",
                        "typeThree"));
        query.with(Sort.by(Sort.Direction.ASC, DATE_CREATED));
        LOGGER.debug(QUERY_STRING, "findJobsByStatus", query);
        try {
            return op.find(query, JobMetaData.class, "job");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findJobsByStatus", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public JobMetaData findTopOfStackNewCronJob() {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where(STATUS).is(ACTIVE))
                .addCriteria(Criteria.where(JOB_TYPE).is("cron"))
                .addCriteria(Criteria.where("executionDateTime").lte(new Date()));
        query.with(Sort.by(Sort.Direction.ASC, "executionDateTime"));
        Update update = new Update();
        update.set(STATUS, "IN_PROCESS");
        update.set(DATE_MODIFIED, new Date());
        LOGGER.debug(QUERY_STRING, "findTopOfStackNewCronJob", query);
        try {
            return op.findAndModify(query, update, JobMetaData.class, "job");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findTopOfStackNewCronJob", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<String> retrieveNewCronJobIdList(int limit) {
        Query query = new Query();
        query.addCriteria(Criteria.where(STATUS).is(ACTIVE))
                .addCriteria(Criteria.where(JOB_TYPE).is("cron"))
                .addCriteria(Criteria.where("executionDateTime").lte(new Date()));
        query.with(Sort.by(Sort.Direction.ASC, "executionDateTime"));
        query.limit(limit)
                .fields().include("_id");
        return mongoTemplate.find(query, JobMetaData.class, JOB_COLLECTION_NAME)
                .stream().map(JobMetaData::getId).collect(Collectors.toList());
    }

    @Override
    public void markHookInvalid(String id) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria.where("_id").is(id));
        Update update = new Update();
        update.set(STATUS, "INVALID");
        update.set(DATE_MODIFIED, new Date());
        LOGGER.debug(QUERY_STRING, "markHookInvalid", query);
        try {
            op.findAndModify(query, update, HookMetaData.class, "hook");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "markHookInvalid", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    /**
     * Method to update the updateHookExecutionRecord object of HookTransactionRecord related to
     * specific targetId and hookId
     *
     * @param hookExecutionRecordId
     * @param targetId
     * @param hookId
     * @param resultMap
     * @return
     */
    @Override
    public HookTransactionMetaData updateHookExecutionRecordOfHookTransactionRecord(
            String hookExecutionRecordId, String targetId, String hookId,
            Map<String, Object> resultMap) {
        LOGGER.debug("Entering updateHookExecutionRecordOfHookTransactionRecord method");
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria
                .where("hookRecordType")
                .is("hookTransaction")
                .andOperator(Criteria.where("targetId").is(targetId),
                        Criteria.where("hookExecutionList.hookId").is(hookId),
                        Criteria.where("hookExecutionList.hookExecutionId")
                                .is(hookExecutionRecordId)));
        Update update = new Update();
        update.set(DATE_MODIFIED, new Date());
        update.set("hookExecutionList.$.status", resultMap.get(ACTIVITI_JOB_STATUS));
        update.set("hookExecutionList.$.dateModified", new Date());
        update.set("hookExecutionList.$.activitiProcessKey", resultMap.get("activitiProcessKey"));
        if (resultMap.get(ACTIVITI_JOB_ID) != null) {
            update.set("hookExecutionList.$.activitiJobId", resultMap.get(ACTIVITI_JOB_ID));
            update.set("hookExecutionList.$.activitiJobStatus", resultMap.get(ACTIVITI_JOB_STATUS));
            if (resultMap.get("dateActivitiJobCreated") != null) {
                update.set("hookExecutionList.$.dateActivitiJobCreated",
                        resultMap.get("dateActivitiJobCreated"));
            }
            if (resultMap.get("dateActivitiJobCompleted") != null) {
                update.set("hookExecutionList.$.dateActivitiJobCompleted",
                        resultMap.get("dateActivitiJobCompleted"));
            }
        }
        update.addToSet("hookExecutionList.$.messageList").each(resultMap.get("messageList"));
        LOGGER.debug("Mongo update statement: {}", update);
        LOGGER.debug(
                "Returning result from updateHookExecutionRecordOfHookTransactionRecord method");
        LOGGER.debug(QUERY_STRING, "updateHookExecutionRecordOfHookTransactionRecord", query);
        try {
            return op.findAndModify(query, update, HookTransactionMetaData.class, "hook");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "updateHookExecutionRecordOfHookTransactionRecord",
                    query, ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public HookTransactionMetaData findHookTransactionByTargetIdHookIdHookExecutionId(
            String hookExecutionRecordId, String targetId, String hookId) {
        LOGGER.debug("Entering findHookTransactionByTargetIdHookIdHookExecutionId method");
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria
                .where("hookRecordType")
                .is("hookTransaction")
                .andOperator(Criteria.where("targetId").is(targetId),
                        Criteria.where("hookExecutionList.hookId").is(hookId),
                        Criteria.where("hookExecutionList.hookExecutionId")
                                .is(hookExecutionRecordId)));
        LOGGER.debug(
                "Returning result from findHookTransactionByTargetIdHookIdHookExecutionId method");
        LOGGER.debug(QUERY_STRING, "findHookTransactionByTargetIdHookIdHookExecutionId", query);
        try {
            return op.findOne(query, HookTransactionMetaData.class, "hook");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING,
                    "findHookTransactionByTargetIdHookIdHookExecutionId", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    public DocumentMetaData findModifiedDocument(String documentId, Date dateModified) {
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria
                .where("id").is(documentId)
                .andOperator(Criteria.where(DATE_MODIFIED).ne(dateModified)));
        LOGGER.debug(QUERY_STRING, "findModifiedDocument", query);
        try {
            return op.findOne(query, DocumentMetaData.class, "document");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "findModifiedDocument", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public List<JobMetaData> searchAllActiveJobsBySpaceIdHookId(int spaceId, String hookId) {
        Query query = new Query();
        query.addCriteria(Criteria.where(SPACE_ID).is(spaceId))
                .addCriteria(Criteria.where("hookId").is(hookId))
                .addCriteria(Criteria.where(JOB_TYPE).is("cron"))
                .addCriteria(Criteria.where(STATUS).is(ACTIVE));
        LOGGER.debug(QUERY_STRING, "searchAllActiveJobsBySpaceIdHookId", query);
        try {
            return mongoTemplate.find(query, JobMetaData.class, "job");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "searchAllActiveJobsBySpaceIdHookId", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public void updateJobStatus(String id, String status) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(id));

        Update update = getUpdate();
        update.set(STATUS, status);

        updateJob(query, update);
    }

    private Update getUpdate() {
        Update update = new Update();
        update.set(DATE_MODIFIED, new Date());

        return update;
    }

    private void updateJob(Query query, Update update) {
        LOGGER.debug(QUERY_STRING, "updateJob", query);
        try {
            mongoTemplate.updateFirst(query, update, JobMetaData.class, JOB_COLLECTION_NAME);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "updateJob", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public HookTransactionMetaData saveCronExpressionHookTransaction(
            HookTransactionMetaData hookTransactionMetaData) {
        MongoOperations op = mongoTemplate;
        op.insert(hookTransactionMetaData, CRON_EXPRESSION_HOOK_COLLECTION);
        return hookTransactionMetaData;
    }

    /**
     * Method to update the updateHookExecutionRecord object of HookTransactionRecord related to
     * specific hookId, targetId and transactionId
     *
     * @param hookExecutionRecordId
     * @param targetId
     * @param hookId
     * @param transactionId
     * @param resultMap
     * @return
     */
    @Override
    public HookTransactionMetaData updateHookExecutionRecordOfCronExpressionHookTransactionRecord(
            String hookExecutionRecordId, String targetId, String hookId, String jobId,
            Map<String, Object> resultMap) {
        LOGGER.debug("Entering updateHookExecutionRecordOfHookTransactionRecord method");
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria
                .where("hookRecordType")
                .is("hookTransaction")
                .andOperator(Criteria.where("targetId").is(targetId),
                        Criteria.where("jobId").is(jobId),
                        Criteria.where("hookExecutionList.hookId").is(hookId),
                        Criteria.where("hookExecutionList.hookExecutionId")
                                .is(hookExecutionRecordId)));
        Update update = new Update();
        update.set(DATE_MODIFIED, new Date());
        update.set("hookExecutionList.$.status", resultMap.get(ACTIVITI_JOB_STATUS));
        update.set("hookExecutionList.$.dateModified", new Date());
        update.set("hookExecutionList.$.activitiProcessKey", resultMap.get("activitiProcessKey"));
        if (resultMap.get(ACTIVITI_JOB_ID) != null) {
            update.set("hookExecutionList.$.activitiJobId", resultMap.get(ACTIVITI_JOB_ID));
            update.set("hookExecutionList.$.activitiJobStatus", resultMap.get(ACTIVITI_JOB_STATUS));
            if (resultMap.get("dateActivitiJobCreated") != null) {
                update.set("hookExecutionList.$.dateActivitiJobCreated",
                        resultMap.get("dateActivitiJobCreated"));
            }
            if (resultMap.get("dateActivitiJobCompleted") != null) {
                update.set("hookExecutionList.$.dateActivitiJobCompleted",
                        resultMap.get("dateActivitiJobCompleted"));
            }
        }
        update.addToSet("hookExecutionList.$.messageList").each(resultMap.get("messageList"));
        LOGGER.debug("Mongo update statement: {}", update);
        LOGGER.debug(
                "Returning result from updateHookExecutionRecordOfHookTransactionRecord method");
        LOGGER.debug(QUERY_STRING, "updateHookExecutionRecordOfCronExpressionHookTransactionRecord",
                query);
        try {
            return op.findAndModify(query, update, HookTransactionMetaData.class,
                    CRON_EXPRESSION_HOOK_COLLECTION);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING,
                    "updateHookExecutionRecordOfCronExpressionHookTransactionRecord", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    @Override
    public void lockHook(String hookId) {
        Map<String, Object> map = new HashMap<>();
        map.put(LOCKED, true);
        updateHook(hookId, map);
    }

    @Override
    public void unlockHook(String hookId) {
        Map<String, Object> map = new HashMap<>();
        map.put(LOCKED, false);
        updateHook(hookId, map);
    }
    
    @Override
    public void updateHook(HookMetaData hookMetaData, Map<String, Object> map) {
        Map hook = (Map) map.get("hook");
        Map action = (Map) hook.get("action");
        Map objConfig = (Map) action.get("config");
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(hookMetaData.getId()));
        Update update = new Update().set("hook.action.config", objConfig);
        LOGGER.debug(QUERY_STRING, "updateHook", query);
        try {
            mongoTemplate.updateFirst(query, update, HookMetaData.class, HOOK_COLLECTION);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "updateHook", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

    private void updateHook(String hookId, Map<String, Object> map) {
        Query query = new Query();
        query.addCriteria(Criteria.where("id").is(hookId));
        Update update = getUpdate();
        for (Entry<String, Object> entrySet : map.entrySet()) {
            update.set(entrySet.getKey(), entrySet.getValue());
        }
        LOGGER.debug(QUERY_STRING, "updateHook", query);
        try {
            mongoTemplate.updateFirst(query, update, HookMetaData.class, HOOK_COLLECTION);
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING, "updateHook", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }

	@Override
	public HookMetaData getHookById(String id) {
		LOGGER.debug("Entering getHookById");
		HookMetaData retVal = null;
		MongoOperations op = mongoTemplate;
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(id));

		LOGGER.debug(QUERY_STRING, GET_HOOK_BY_ID, query);
		try {
			List<HookMetaData> hmds = op.find(query, HookMetaData.class);
			if (CollectionUtils.isNotEmpty(hmds)) {
				retVal = hmds.get(0);
			}
			LOGGER.debug("Leaving getHookById");
			return retVal;
		} catch (Exception e) {
			LOGGER.error(QUERY_EXCEPTION_STRING, GET_HOOK_BY_ID, query, ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}

	@Override
	public HookMetaData deleteHook(String id) {
		MongoOperations op = mongoTemplate;
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(id));
		LOGGER.debug(QUERY_STRING, "deleteHook", query);
		try {
			return op.findAndRemove(query, HookMetaData.class, HOOK_COLLECTION);
		} catch (Exception e) {
			LOGGER.error(QUERY_EXCEPTION_STRING, "deleteHook", query, ExceptionUtils.getStackTrace(e));
			throw e;
		}
	}

	@Override
	public HookTransactionMetaData findHookTransactionByTargetIdHookId(String targetId, String hookId) {
		LOGGER.debug("Entering findHookTransactionByTargetIdHookIdHookExecutionId method");
        MongoOperations op = mongoTemplate;
        Query query = new Query();
        query.addCriteria(Criteria
                .where("hookRecordType")
                .is("hookTransaction")
                .andOperator(Criteria.where("targetId").is(targetId),
                        Criteria.where("hookExecutionList.hookId").is(hookId)));
        LOGGER.debug(
                "Returning result from findHookTransactionByTargetIdHookIdHookExecutionId method");
        LOGGER.debug(QUERY_STRING, "findHookTransactionByTargetIdHookIdHookExecutionId", query);
        try {
            return op.findOne(query, HookTransactionMetaData.class, "hookTransaction");
        } catch (Exception e) {
            LOGGER.error(QUERY_EXCEPTION_STRING,
                    "findHookTransactionByTargetIdHookIdHookExecutionId", query,
                    ExceptionUtils.getStackTrace(e));
            throw e;
        }
    }
	

	@Override
	public HookTransactionMetaData getHookTransactionById(String hookTransactionId) {
		LOGGER.debug("Entering getHookTransactionById method");
		Query query = new Query();
		try {
			MongoOperations op = mongoTemplate;
			query.addCriteria(Criteria.where("id").is(new ObjectId(hookTransactionId)));
			return op.findOne(query, HookTransactionMetaData.class, "hookTransaction");
		} catch (Exception e) {
			LOGGER.error(QUERY_EXCEPTION_STRING, "getHookTransactionById", query, ExceptionUtils.getStackTrace(e));
			return null;
		}
	}
}
