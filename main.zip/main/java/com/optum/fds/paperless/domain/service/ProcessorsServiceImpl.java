/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/7/17.
 */

////package com.optum.fs.fs_batch_processing.service;
package com.optum.fds.paperless.domain.service;


import com.optum.fds.paperless.ConfigData;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.Transaction;
import com.optum.fds.paperless.mongo.processors.*;
import com.optum.fds.paperless.util.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.ws.rs.NotFoundException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;



@Service("processorsService")
public class ProcessorsServiceImpl implements ProcessorsService {
	
	@Value("${serverType}")
	protected String serverType;
	
    private static final String VERSION = "1";
    private static final String ACTIVE = "ACTIVE";
    private static final String PROCESSOR_NOT_FOUND_TEMPLATE = "Processor with id of %s not found";
    private static final String PROCESSOR_TRANSACTION_NOT_FOUND_TEMPLATE = "Processor transaction with id of %s not found";
   
    
    @Autowired
    ProcessorFileTaskService processorFileTaskService;
    @Autowired
    ProcessorService processorService;
    @Autowired
    TransactionService transactionService;
    
    

    // Constructor
    public ProcessorsServiceImpl(){
        // Required constructor
    }

    public ProcessorsServiceImpl(ProcessorService processorService) {
        this.processorService = processorService;
    }

    public ProcessorsServiceImpl(ProcessorService processorService, TransactionService transactionService) {
        this.processorService = processorService;
        this.transactionService = transactionService;
    }
    
    public ProcessorsServiceImpl(ProcessorService processorService, TransactionService transactionService, ProcessorFileTaskService processorFileTaskService) {
        this.processorService = processorService;
        this.transactionService = transactionService;
        this.processorFileTaskService = processorFileTaskService;
    }
    
    @Override
    public ProcessorMetaData createProcessor(ProcessorMetaData processorMetaData) {
        // Setting Values
        processorMetaData.setVersion("1");
        processorMetaData.setProcessorRecordType(ProcessorRecordTypes.processor);
        processorMetaData.setStatus(MetaDataStatus.NEW);

        setCleanupWorkflow(processorMetaData);
        return processorService.saveProcessorMetaData(processorMetaData);
    }
    
    @Override
    public ProcessorFileTask createProcessorFileTaskEntries(ProcessorTransaction processorTransaction, String fileName) {
        ProcessorMetaData processor = new ProcessorMetaData();
        Integer priority = 0;
        processor.setAppIdentifier(processorTransaction.getAppIdentifier());
        processor.setClientId(processorTransaction.getClientId());
        processor.setConfigSpaceId(processorTransaction.getConfigSpaceId());
        Transaction transactionMetaData = createTransactionRecord(processor);

        ProcessorFileTask processorFileTask = createProcessorFileTask(processorTransaction, fileName, transactionMetaData);
        processorFileTask = processorFileTaskService.saveProcessorFileTask(processorFileTask);
		/*
		 * ProcessorMetaData
		 * processorPriority=processorService.getProcessorMetaData(processorTransaction.
		 * getProcessorId(), processorTransaction.getAppIdentifier());
		 * if(processorPriority!=null) { priority =processorPriority.getPriority(); }
		 * JobMetaData jobEntry = new JobMetaData(); jobEntry.setDateCreated(new
		 * Date()); jobEntry.setDateModified(new Date()); jobEntry.setStatus(ACTIVE);
		 * jobEntry.setJobType(jobType);
		 * jobEntry.setSpaceId(processorFileTask.getConfigSpaceId());
		 * jobEntry.setClientId(processorFileTask.getClientId());
		 * jobEntry.setAppIdentifier(processorFileTask.getAppIdentifier());
		 * jobEntry.setFileName(processorFileTask.getFileName());
		 * jobEntry.setFilePath(processorFileTask.getLocation());
		 * jobEntry.setWorkFlow(wrkFlow);
		 * jobEntry.setProcessorId(processorFileTask.getProcessorId());
		 * jobEntry.setProcessorTransactionId(processorFileTask.getId());
		 * jobEntry.setServerName(FileUtil.getInstance().getLocalHostName());
		 * jobEntry.setServerType(ApplicationProperty.get(SERVER_TYPE));
		 * if(priority!=null) { jobEntry.setPriority(priority); }
		 * processorService.saveProcessorJobRecord(jobEntry);
		 */

        return processorFileTask;
    }

    private ProcessorFileTask createProcessorFileTask(ProcessorTransaction processorTransaction, String fileName, Transaction transactionMetaData) {
        ProcessorFileTask processorFileTask = new ProcessorFileTask();
        processorFileTask.setAppIdentifier(processorTransaction.getAppIdentifier());
        processorFileTask.setClientId(processorTransaction.getClientId());
        processorFileTask.setFileName(fileName);
        processorFileTask.setLocation(processorTransaction.getLocation());
        processorFileTask.setConfigSpaceId(processorTransaction.getConfigSpaceId());
        processorFileTask.setTransactionId(transactionMetaData.getTransactionId());
        processorFileTask.setVersion(VERSION);
        processorFileTask.setProcessorId(processorTransaction.getProcessorId());
        processorFileTask.setStatus(MetaDataStatus.NEW);
        processorFileTask.setProcessorTransactionId(processorTransaction.getId());
        processorFileTask.setProcessorRecordType(ProcessorRecordTypes.processorFileTask);
       // processorFileTask.setServerType(ApplicationProperty.get(SERVER_TYPE));
        return processorFileTask;
    }

    @Override
    public JobMetaData createProcessorJobEntry(ProcessorMetaData processor, ProcessorTransaction processorTransaction, String jobType, String wrkFlow) {

        JobMetaData jobEntry = new JobMetaData();
        jobEntry.setDateCreated(new Date());
        jobEntry.setDateModified(new Date());
        jobEntry.setStatus(ACTIVE);
        jobEntry.setJobType(jobType);
        jobEntry.setSpaceId(processor.getConfigSpaceId());
        jobEntry.setClientId(processor.getClientId());
        jobEntry.setAppIdentifier(processor.getAppIdentifier());
        jobEntry.setFileName(processorTransaction.getFileName());
        jobEntry.setFilePath(processorTransaction.getLocation());
        jobEntry.setWorkFlow(wrkFlow);
        jobEntry.setProcessorId(processor.getId());
        jobEntry.setProcessorTransactionId(processorTransaction.getId());
        jobEntry.setServerName(FileUtil.getInstance().getLocalHostName());
      //  jobEntry.setServerType(ApplicationProperty.get(SERVER_TYPE));
        if(processor.getPriority()!= null) {
        	jobEntry.setPriority(processor.getPriority());
        }
        processorService.saveProcessorJobRecord(jobEntry);

        return jobEntry;
    }

	@Override
    public JobMetaData createProcessorJobEntry(ProcessorTransaction processorTransaction, String jobType, String wrkFlow) {

        JobMetaData jobEntry = new JobMetaData();
        jobEntry.setDateCreated(new Date());
        jobEntry.setDateModified(new Date());
        jobEntry.setStatus(ACTIVE);
        jobEntry.setJobType(jobType);
        jobEntry.setSpaceId(processorTransaction.getConfigSpaceId());
        jobEntry.setClientId(processorTransaction.getClientId());
        jobEntry.setAppIdentifier(processorTransaction.getAppIdentifier());
        jobEntry.setFileName(processorTransaction.getFileName());
        jobEntry.setFilePath(processorTransaction.getLocation());
        jobEntry.setWorkFlow(wrkFlow);
        jobEntry.setProcessorId(processorTransaction.getProcessorId());
        jobEntry.setProcessorTransactionId(processorTransaction.getId());
        jobEntry.setServerName(FileUtil.getInstance().getLocalHostName());
      //  jobEntry.setServerType(ApplicationProperty.get(SERVER_TYPE));
        processorService.saveProcessorJobRecord(jobEntry);

        return jobEntry;
    }
    
    @Override
    public ProcessorTransaction createProcessorTransaction(ProcessorMetaData processor, String fileName, String fileLocation, String transactionID) {

        ProcessorTransaction processorTransaction = new ProcessorTransaction();
        processorTransaction.setAppIdentifier(processor.getAppIdentifier());
        processorTransaction.setClientId(processor.getClientId());
        processorTransaction.setFileName(fileName);
        processorTransaction.setLocation(fileLocation);
        processorTransaction.setConfigSpaceId(processor.getConfigSpaceId());
        processorTransaction.setTransactionId(transactionID);
        processorTransaction.setVersion(VERSION);
        processorTransaction.setProcessorId(processor.getId());
        processorTransaction.setStatus(MetaDataStatus.NEW);
        processorTransaction.setProcessorRecordType(ProcessorRecordTypes.processorTransaction);
        processorTransaction.setServerType(serverType);
        processorService.saveProcessorTransactionMetaData(processorTransaction);

        return processorTransaction;
    }

    @Override
    public Transaction createTransactionRecord(ProcessorMetaData processor) {
        Transaction transactionMetadata = com.optum.fds.paperless.mongo.ProcessorUtil.setTransactionRecord(processor);
        return transactionService.insertTransactionMetaData(transactionMetadata);
    }

    @Override
    public List<ProcessorMetaData> findAllAvailableProcessorMetaData(Date startDate, Date endDate) {
        return processorService.findAllAvailableProcessorMetaData(startDate, endDate);
    }

    @Override
    public List<ProcessorMetaData> findAllAvailableProcessorMetaData() {
        return processorService.findAllAvailableProcessorMetaData();
    }

    @Override
    public ProcessorMetaData findProcessorMetaDataByFileName(String zipFilename, String appId) {
        return processorService.findProcessorMetaDataByFileName(zipFilename, appId);
    }

    @Override
    public ProcessorMetaData findProcessorMetaDataById(String processorId, String appId) {
        return processorService.findProcessorMetaDataById(processorId, appId);
    }

    @Override
    public void startProcessor(String id) {
        processorService.startProcessor(id);
    }

    @Override
    public void shutdownProcessor(String id) {
        processorService.shutdownProcessor(id);
    }
    
    
    @Override
    public void startMultipleProcessors() {

    	Date today  = new Date();
    	List<ProcessorMetaData>  processorMetaData = null;
    	processorMetaData = processorService.findAllAvailableProcessorsToStart();

    	for(int i=0;i<processorMetaData.size();i++){
    		if(processorMetaData.get(i)!=null && processorMetaData.get(i).getEndDate()!=null){
    			if(processorMetaData.get(i).getEndDate().before(today)){
    				processorMetaData.get(i).setStatus(MetaDataStatus.COMPLETE);
    				processorService.updateProcessorMetaData(processorMetaData.get(i));
    			}else{
    				processorMetaData.get(i).setStatus(MetaDataStatus.IN_PROCESS);
    				processorService.updateProcessorMetaData(processorMetaData.get(i));
    			}
    		}
    	}
    }
    
    
    @Override
    public void shutdownMultipleProcessors() {

    	Date today  = new Date();
    	List<ProcessorMetaData>  processorMetaData = null;
    	processorMetaData = processorService.findAllAvailableProcessorsForShutdown();

    	for(int i=0;i<processorMetaData.size();i++){
    		if(processorMetaData.get(i)!=null && processorMetaData.get(i).getEndDate()!=null){
    			if(processorMetaData.get(i).getEndDate().before(today)){
    				processorMetaData.get(i).setStatus(MetaDataStatus.COMPLETE);
    				processorService.updateProcessorMetaData(processorMetaData.get(i));
    			}else{
    				processorMetaData.get(i).setStatus(MetaDataStatus.SHUTDOWN);
    				processorService.updateProcessorMetaData(processorMetaData.get(i));
    			}
    		}
    	}
    }

    @Override
    public boolean findProcessorJobByTransactionIdFromQueue(String processorTransactionId) {
        return processorService.findProcessorJobByTransactionIdFromQueue(processorTransactionId, serverType);
    }
    

    @Override
    public String getCleanupWorkFlowForProcessorTransaction(ProcessorTransaction processorTransaction) {
        ProcessorMetaData processorMetaData = getProcessor(processorTransaction.getAppIdentifier(), processorTransaction.getProcessorId());
        return getCleanupWorkFlowForProcessor(processorMetaData);
    }

    @Override
    public ProcessorMetaData getProcessor(String appIdentifier, String processorId) {
        ProcessorMetaData processorMetaData = processorService.getProcessorMetaData(processorId, appIdentifier);

        if(processorMetaData == null){
            throw new NotFoundException(String.format(PROCESSOR_NOT_FOUND_TEMPLATE, processorId));
        }

    	return processorMetaData;
    }

    @Override
    public ProcessorFileTask getProcessorFileTask(String appIdentifier, String processorId){
        ProcessorFileTask processorFileTask = processorFileTaskService.getProcessorFileTask(processorId, appIdentifier, serverType);

        if(processorFileTask == null){
            throw new NotFoundException(String.format(PROCESSOR_NOT_FOUND_TEMPLATE, processorId));
        }

        return processorFileTask;
    }

    @Override
    public ProcessorTransaction getTransactionProcessor(String appIdentifier, String processorId, String serverType) {
        ProcessorTransaction processorTransaction = processorService.getProcessorTransaction(processorId, appIdentifier, serverType);

        if(processorTransaction == null){
            throw new NotFoundException(String.format(PROCESSOR_NOT_FOUND_TEMPLATE, processorId));
        }

        return processorTransaction;
    }

    @Override
    public List<ProcessorTransaction> getAllTransactionProcessorsFatalErrorAndReady() {
    	
        List<ProcessorTransaction> processorTransactionsFatalError = processorService.getAllProcessorTransactionInStatus(MetaDataStatus.FATAL_ERROR.toString(), serverType);
        List<ProcessorTransaction> processorTransactionsReady = processorService.getAllProcessorTransactionInStatus(MetaDataStatus.READY.toString(), serverType);

        processorTransactionsReady.addAll(processorTransactionsFatalError);
        return processorTransactionsReady;
    }

    @Override
    public List<ProcessorTransaction> getAllTransactionProcessorsShutdown() {
    	
        List<ProcessorTransaction> processorTransactionsShutDown = processorService.getAllProcessorTransactionInStatus(MetaDataStatus.SHUTDOWN.toString(), serverType);

        return processorTransactionsShutDown;
    }
    
    @Override
    public List<ProcessorTransaction> getAllPendingProcessorsTransactions(int processorTransactionPendingTime) { 	
    	List<String> statusList = new ArrayList<>();
    	statusList.add(MetaDataStatus.NEW.toString());
    	statusList.add(MetaDataStatus.IN_PROCESS.toString());
    	
		return processorService.getAllPendingProcessorTransactions(processorTransactionPendingTime, statusList, serverType);
    }

    @Override
    public List<ProcessorFileTask> getProcessorFileTasksForTransactionId(String transactionId) {
        return processorFileTaskService.getProcessorFileTasksForTransactionId(transactionId, serverType);
    }
    
    
    @Override
    public List<ProcessorFileTask> getPendingProcessorFileTaskForTransactionId(String transactionId,String status,int processorTransactionPendingTime) {
        return processorFileTaskService.getPendingProcessorFileTaskForTransactionId(transactionId, serverType,status,processorTransactionPendingTime);
    }


    @Override
    public List<ProcessorFileTask> getLastProcessorFileTaskForTransactionId(String transactionId) {
        return processorFileTaskService.getLastProcessorFileTaskForTransactionId(transactionId, serverType);
    }

    @Override
    public boolean isProcessorLocked(ProcessorMetaData processor){
        ProcessorMetaData current = getProcessor(processor.getAppIdentifier(), processor.getId());
        return current.isLocked();
    }

    @Override
    public void lockProcessor(ProcessorMetaData processor){
        processorService.lockProcessor(processor.getId());
    }

    @Override
    public boolean nameIsUnique(String name, String appIdentifier) {
        return processorService.nameIsUnique(name, appIdentifier);
    }

    @Override
    public void setLastCleanRun(String id){
        processorService.setLastCleanRun(id);
    }

    @Override
    public void setLastRunAndStatus(String id, MetaDataStatus status){
        processorService.setLastRunAndStatus(id, status);
    }

    @Override
    public void unlockProcessor(ProcessorMetaData processor){
        processorService.unlockProcessor(processor.getId());
    }
    
    @Override
    public ProcessorTransaction updateProcessorTransactionMetaData(ProcessorTransaction processorTransaction){
    	return processorService.updateProcessorTransactionMetaData(processorTransaction);
    }

    @Override
    public ProcessorMetaData updateProcessorMetaData(ProcessorMetaData processorMetaData, ProcessorMetaData processorMetaDataInDB, String transactionId){
        // Storing Revision
        processorMetaDataInDB.addRevision(com.optum.fds.paperless.processing.service.util.ProcessorUtil.createRevision(processorMetaDataInDB));
        processorMetaData.setRevisions(processorMetaDataInDB.getRevisions());

        // Setting unmodifiable fields
        processorMetaData.setLastRun(processorMetaDataInDB.getLastRun());
        processorMetaData.setDateCreated(processorMetaDataInDB.getDateCreated());
        processorMetaData.setId(processorMetaDataInDB.getId());
        processorMetaData.setStatus(processorMetaDataInDB.getStatus());
        processorMetaData.setProcessorRecordType(processorMetaDataInDB.getProcessorRecordType());
        processorMetaData.setVersion(processorMetaDataInDB.getVersion());
        processorMetaData.incrementVersion();

        setCleanupWorkflow(processorMetaData);
        return processorService.updateProcessorMetaData(processorMetaData);
    }

    private void setCleanupWorkflow(ProcessorMetaData processorMetaData){
        processorMetaData.setCleanupWorkflow(getCleanupWorkFlowForProcessor(processorMetaData));
    }

	private String getCleanupWorkFlowForProcessor(ProcessorMetaData processorMetaData) {
		String workflow = (String) processorMetaData.getProcess().get("process_key");

        ProcessorMapping processorMapping = processorService.getProcessorMapping("cleanup", processorMetaData.getConfigSpaceId());
        List<ProcessorMap> mapping = processorMapping.getMapping().stream().filter(processorMap -> processorMap.getKey().equals(workflow)).collect(Collectors.toList());

        return mapping.isEmpty() ? null : mapping.get(0).getNewKey();
	}
	
	
	@Override
	public ProcessorTransaction getProcessorTransactionById(String id) {
		 ProcessorTransaction processorTransaction = processorService.getProcessorTransactionById(id);

	        if(processorTransaction == null){
	            throw new NotFoundException(String.format(PROCESSOR_TRANSACTION_NOT_FOUND_TEMPLATE, id));
	        }

	        return processorTransaction;
	}

	@Override
	public boolean allProcessorFileTasksCompletedForTransactionId(String transactionId) {
		return processorFileTaskService.areAllProcessorFileTasksCompletedForTransactionId(transactionId);
	}

	@Override
	public boolean deleteProcessorMetaData(String id, String appIdentifier) {
		return processorService.deleteProcessorMetaData(id, appIdentifier);
	}
	
	@Override
	public boolean deleteProcessor(String processorRecordType, String processorType, int processorPendingTime) {
		return processorService.deleteProcessor(processorRecordType, processorType, processorPendingTime);
	}

	@Override
    public List<ProcessorFileTask> getProcessorFileTasksForTransactionIdByStatus (String transactionId, String status) {
        return processorFileTaskService.getProcessorFileTasksForTransactionIdByStatus(transactionId, status);
    }

	@Override
	public ProcessorMapping getProcessorMapping(String appIdentifier, Integer spaceId) {
		return processorService.getProcessorMapping(appIdentifier, spaceId);
	}

	@Override
	public ProcessorMapping deleteProcessorMapping(String appIdentifier, Integer spaceId) {
		return processorService.deleteProcessorMapping(appIdentifier, spaceId);
	}

	@Override
	public ProcessorMapping createProcessorMapping(ProcessorMapping processorMapping) {
		return processorService.saveProcessorMapping(processorMapping);
	}


	@Override
	public List<ProcessorTransaction> getAllProcessorTransactionInStatus(List<String> status, String serverType,
			int startTimeOffset) {
		return processorService.getAllProcessorTransactionInStatus(status, serverType, startTimeOffset);
	}

	@Override
	public boolean isIncompleteProcessorFlagLocked(ProcessorMetaData processor) {
		 ProcessorMetaData current = getProcessor(processor.getAppIdentifier(), processor.getId());
	     return current.getResolveIncompleteProcessorTransactionLocked() !=null ? current.getResolveIncompleteProcessorTransactionLocked() : false;
	}

	@Override
	public void lockIncompleteProcessorFlag(ProcessorMetaData processor) {
		processorService.lockIncompleteProcessorFlag(processor.getId());
		
	}

	@Override
	public void unlockIncompleteProcessorFlag(ProcessorMetaData processor) {
		processorService.unlockIncompleteProcessorFlag(processor.getId());
		
	}

	@Override
	public void updateProcessorLastRun(ProcessorMetaData processor) {
		processorService.updateProcessorLastRun(processor.getId());
	}
	
	@Override
	public void findAndUpdateJobsByStatusINProcess(String status, String jobType) {
		processorService.findAndUpdateJobsByStatusINProcess(status, jobType);
	}

	@Override
	public ProcessorTransaction getTransactionProcessorById(String Id) {
		 ProcessorTransaction processorTransaction = processorService.getProcessorTransactionById(Id);

	        if(processorTransaction == null){
	            throw new NotFoundException(String.format(PROCESSOR_TRANSACTION_NOT_FOUND_TEMPLATE, Id));
	        }

	        return processorTransaction;
	}

    @Override
    public List<String> findAllAvailableProcessorIds(Date start, Date end) {
        return processorService.findAllAvailableProcessorIds(start, end);
    }

    @Override
    public List<String> retrieveJobIdList(int limit) {
        return processorService.retrieveJobIdList(limit);
    }
    
    @Override
    public ProcessorMetaData findProcessor(String processorId) {
        return processorService.findProcessor(processorId);
    }


    @Override
    public List<String> retrieveRestApiJobIdList(Integer theLimit) {
        return processorService.retrieveRestApiJobIdList(theLimit);
    }

}
