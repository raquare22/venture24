package com.optum.fds.paperless.domain.service.exception;

public class ServiceException extends Exception {

	
	private static final long serialVersionUID = 1L;
	private int errorCode;
	
	public ServiceException() {
		super();
	}
	
	
	public ServiceException(int errorCode, String message, Throwable cause){
		super(message, cause);
		this.errorCode = errorCode;
	}
	
	public ServiceException(int errorCode, Throwable cause){
		super(cause);
		this.errorCode = errorCode;
	}
	
	
	public ServiceException(int errorCode, String message){
		super(message);
		this.errorCode = errorCode;
	}
	public ServiceException(int errorCode) {
		super("");
		this.errorCode = errorCode;
	}

	public ServiceException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public ServiceException(String message) {
		super(message);
	}
	
	public ServiceException(Throwable cause) {
		super(cause);
	}
	
	public int getErrorCode() {
		return errorCode;
	}
    
}
