package com.optum.fds.paperless.domain.service;


import com.optum.fds.paperless.mongo.AttachmentMetaData;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.mongo.HookEventType;
import com.optum.fds.paperless.mongo.HookMetaData;
import com.optum.fds.paperless.mongo.HookTransactionMetaData;
import com.optum.fds.paperless.mongo.JobMetaData;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import java.util.Date;
import java.util.List;
import java.util.Map;

public interface HookService {

    HookMetaData saveHook(HookMetaData hookMetaData);

    List<HookMetaData> findAllAvailableHookMetaData();

    void registerEventOfInterest(HookEventType hookEventType);

    HookMetaData getHookById(String appId, int spaceId, String id);

    HookMetaData getHookById(String appId, String id);
    
    HookMetaData getHookById(String id);

    List<HookMetaData> getHooksByName(String appId, int spaceId, String name);
    
    List<HookMetaData> getHookByNameAndSpaceId(String appId, int spaceId, String name);

    List<HookMetaData> getHooks(String appId, int spaceId, String status);

    HookMetaData putHookMetaData(HookMetaData hookMetaData);

    HookEventType findTopOfStackNewHookEvent();

    DocumentMetaData findDocumentByTransactionId(String transactionId);

    List<AttachmentMetaData> findAttachmentsByTransactionId(String transactionId);

    AttachmentMetaData findAttachmentByFsId(String fsId);

    List<HookMetaData> findAllHooksThatMatchTopLevelCriteria(HookEventType hookEvent);

    HookEventType deleteHookEventFromStack(String hookEventId);

    JobMetaData saveJobRecord(JobMetaData jobMetaData);

    HookTransactionMetaData saveHookTransaction(HookTransactionMetaData hookTransactionMetaData);

    JobMetaData findTopOfStackNewJob();

    JobMetaData findTopOfStackNewCronJob();

    JobMetaData deleteJobFromStack(String jobId);

    void deleteJobs(List<JobMetaData> jobIdList);
    
    void updateHook(HookMetaData hookMetaData, Map<String, Object> map);

    List<JobMetaData> searchForJobs(String hookId);

    List<JobMetaData> searchForJobs(String targetType, String targetId);

    List<HookTransactionMetaData> findIfHookTransactionExistsForDoc(DocumentMetaData document);

    HookTransactionMetaData updateHookTransaction(HookTransactionMetaData hookTransactionMetaData);

    void markHookInvalid(String id);

    HookMetaData deleteHook(String appId, int spaceId, String id);
    
    HookMetaData deleteHook(String id);

    HookTransactionMetaData updateHookExecutionRecordOfHookTransactionRecord(
            String hookExecutionRecordId, String targetId, String hookId,
            Map<String, Object> resultMap);

    List<JobMetaData> searchAllJobs(int spaceId);

    List<JobMetaData> searchAllJobsBySpaceIdHookId(int spaceId, String hookId);

    List<JobMetaData> searchForAllJobs(String targetType, String targetId);

    List<JobMetaData> searchStandardJobs(int spaceId);

    List<JobMetaData> searchCronJobs(int spaceId);

    List<JobMetaData> searchForAllJobTypes(String targetType, String targetId);

    List<DocumentMetaData> searchDocumentsBySpaceIdAndDateField(int spaceId, String dateFieldName,
            String dateValueString);

    DocumentMetaData findModifiedDocument(String documentId, Date dateModified);

    List<JobMetaData> searchAllActiveJobsBySpaceIdHookId(int spaceId, String hookId);

    List<JobMetaData> findJobsByStatus(MetaDataStatus status);

    void updateJobStatus(String id, String status);

    HookTransactionMetaData findHookTransactionByTargetIdHookIdHookExecutionId(
            String hookExecutionRecordId, String targetId, String hookId);

    HookTransactionMetaData saveCronExpressionHookTransaction(
            HookTransactionMetaData hookTransactionMetaData);
    
    HookTransactionMetaData findHookTransactionByTargetIdHookId(String targetId, String hookId);
    
    HookTransactionMetaData getHookTransactionById(String hookTransactionId);

    HookTransactionMetaData updateHookExecutionRecordOfCronExpressionHookTransactionRecord(
            String hookExecutionRecordId, String targetId, String hookId, String jobId,
            Map<String, Object> resultMap);

    void lockHook(String hookId);

    void unlockHook(String hookId);

    List<String> retrieveNewCronJobIdList(int limit);

    List<String> retrieveHookJobIdList(int limit);

    JobMetaData findHookJob(String jobId);
}

