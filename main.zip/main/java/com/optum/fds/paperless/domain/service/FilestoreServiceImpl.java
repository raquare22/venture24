package com.optum.fds.paperless.domain.service;

import org.owasp.encoder.Encode;
import org.springframework.stereotype.Service;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;

import java.io.File;
import java.util.Arrays;

import jakarta.annotation.PostConstruct;

import org.apache.commons.io.IOUtils;
import org.apache.tika.utils.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

@Service
public class FilestoreServiceImpl implements FilestoreService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FilestoreServiceImpl.class); 
	
	@Value("${AWSS3Secret}")
	private String awsS3Access;
	
	@Value("${AWSS3Access}")
	private String awsS3Secret;
	
	@Value("${AWSS3Url}")
	private String awsS3Url;
	
	@Value("${AWSS3Region}")
	private String awsS3Region;
	
	@Value("${AWSS3Bucket}")
	private String awsS3Bucket;

	private AmazonS3 amazonS3;
	
	@PostConstruct
	public void init() {		
		BasicAWSCredentials credentials = new BasicAWSCredentials(awsS3Access, awsS3Secret);
    	
    	this.amazonS3 = AmazonS3ClientBuilder.standard()
//                .withRegion(Regions.SA_EAST_1)
                .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(awsS3Url, awsS3Region))
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .build();
	}
	
	@Override
	public boolean insertFile(String location, String fileName) {    
		String filePath = getBucketFilePathFromLocation(location);
		LOGGER.info("filePath={}", filePath);		
		String path = awsS3Bucket + "/" + filePath;
    	File file = new File(location + "/" + fileName);
    	try {
    		amazonS3.putObject(new PutObjectRequest(path, fileName, file)
                    .withCannedAcl(CannedAccessControlList.PublicRead));
    		return true;
    	} catch (Exception e) {
    		LOGGER.error("Error posting file={} to bucket={}, err={}", fileName, path, ExceptionUtils.getStackTrace(e));
    		return false;
    	}
	}
	
	@Override
	public byte[] downloadFile(String filePath, String fileName) {
		String path = filePath + fileName;
		LOGGER.debug("downloadFile path={}", Encode.forJava(path));
		try {
			S3Object object = amazonS3.getObject(awsS3Bucket, path); 
			byte[] byteArray = IOUtils.toByteArray(object.getObjectContent());
			return byteArray;
		} catch (Exception e) {
			LOGGER.error("Error downloading path={}, err={}", Encode.forJava(path), ExceptionUtils.getStackTrace(e));
    		return null;
		}
	}


	@Override
	public boolean deleteFile(String bucketName, String fileName) {
		try {
			amazonS3.deleteObject(new DeleteObjectRequest(bucketName, fileName));
			return true;
		} catch (Exception e) {
			LOGGER.error("Error removing file={} from bucket={}, err={}", fileName, bucketName, ExceptionUtils.getStackTrace(e));
			return false;
		}
		
	}
	
	
	public String getBucketFilePathFromLocation(String location) {
		String[] parts = location.split("/");
		return parts[3] + "/" + parts[4];
		
	}
}
