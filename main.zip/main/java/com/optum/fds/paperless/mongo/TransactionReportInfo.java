/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When          Who              Revision
 * Dec 13,2016  Suman Halder		 	 Initial version
 ****************************************************************/
////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.optum.fds.paperless.domain.ReportResult;

////import com.optum.fs.domain.ReportResult;

public class TransactionReportInfo {
	private String parentId;
	private String externalId;
	private Integer spaceId;
    private Integer clientId;
    private String  appId;
	private String status;
	private String version;
	private Date expires;

    private List<ReportResult> reportResult ;


	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Date getExpires() {
		return expires==null?null:(Date)expires.clone();
	}

	public void setExpires(Date expires) {
		this.expires = expires==null?null:(Date)expires.clone();
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public Integer getSpaceId() {
		return spaceId;
	}

	public void setSpaceId(Integer spaceId) {
		this.spaceId = spaceId;
	}

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

	public List<ReportResult> getReportResult() {
		return reportResult==null?null:new ArrayList<>(reportResult);
	}

	public void setReportResult(List<ReportResult> reportResult) {
		this.reportResult = reportResult==null?null:new ArrayList<>(reportResult);

	}
}
