/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/8/17.
 */

////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.mongo.processors.MetaDataStatus;

import org.apache.commons.lang.StringUtils;
////import com.optum.fs.mongo.processors.MetaDataStatus;
import org.springframework.data.annotation.Id;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class MetaData implements Serializable {
            @Id
            String          id;
            String          appIdentifier;
            int             clientId;
            Date            dateCreated;
            Date            dateModified;
    private String          name;
          transient List            revisions;

            MetaDataStatus  status;
            String          transactionId;
            String          version;

    public MetaData(){
        dateCreated = new Date();
        dateModified = new Date();
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getAppIdentifier() {
        return appIdentifier;
    }
    public void setAppIdentifier(String appIdentifier) {
        this.appIdentifier = appIdentifier;
    }
    public int getClientId() {
        return clientId;
    }
    public void setClientId(int clientId) {
        this.clientId = clientId;
    }
    public Date getDateCreated() {
        return dateCreated;
    }
    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }
    public Date getDateModified() {
        return dateModified;
    }
    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public List getRevisions() {
        return revisions;
    }
    public void setRevisions(List revisions) {
        this.revisions = revisions;
    }
    public MetaDataStatus getStatus() {
        return status;
    }
    @JsonIgnore
    public void setStatus(MetaDataStatus status) {
        this.status = status;
    }
    @JsonProperty("status")
    public void setStatus(String status){
        this.status = MetaDataStatus.valueOf(status);
    }
    public String getTransactionId() {
        return transactionId;
    }
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
    public String getVersion() {
        return version;
    }
    public void setVersion(String version) throws NumberFormatException {
        String versionString = StringUtils.isEmpty(version) ? "1" : version;

        if(Integer.parseInt(versionString) > 0) {
            this.version = versionString;
        }
    }

    public void incrementVersion() {
        Integer versionInteger = Integer.parseInt(version);
        versionInteger++;
        version = versionInteger.toString();
    }
}
