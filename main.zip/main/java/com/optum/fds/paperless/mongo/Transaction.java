////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

/**
 * The Mongo file metadata.
 * 
 */
@Document(collection = "transaction")
public class Transaction implements Serializable {
	private static final long serialVersionUID = 1L;

	private String id;
	private String transactionId;

	private long totalFileSize;
    	 
	private String appIdentifier;
	private String protocol;
	private String method;
	private String uri;
	private String parameters;
	private String payload;
	private String headers;	
	private String userIp;
	private String serverIp; 
	
	private int spaceId; 
	private int clientId;
	private int responseStatusCode;
	private String responseHeader;

	private Date dateCreated;
	private Date dateModified;
	
	private List<ActionMetaData> actions;
	private List<TransactionAttachmentInfo>attachments;
	private TransactionListAttachmentsInfo listAttachments;
	private TransactionDocumentListInfo documentListInfo;
	private TransactionHookListInfo hookListInfo;
	private TransactionReportListInfo reportListInfo;
//    private TransactionProcessListInfo processListInfo;
	
	private List<FileMetaData>files;
	boolean isAsync = false;
	
	private transient org.bson.Document metadata ;
	private transient org.bson.Document hook;

	public List<ActionMetaData> getActions() {
		return actions==null?null:new ArrayList<>(actions);
	}
	public void setActions(List<ActionMetaData> actions) {
		this.actions = actions==null?null:new ArrayList<>(actions);
	}
	public List<FileMetaData> getFiles() {
		return files==null?null:new ArrayList<>(files);
	}
	public void setFiles(List<FileMetaData> files) {
		this.files = files==null?null:new ArrayList<>(files);
	}
	public Date getDateModified() {
		return dateModified==null?null:(Date)dateModified.clone();
	}
	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified==null?null:(Date)dateModified.clone();
	}
	public Date getDateCreated() {
		return dateCreated==null?null:(Date)dateCreated.clone();
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated==null?null:(Date)dateCreated.clone();
	}
	 
	public String getAppIdentifier() {
		return appIdentifier;
	}
	public void setAppIdentifier(String identifier) {
		this.appIdentifier = identifier;
	}
	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getParameters() {
		return parameters;
	}
	public void setParameters(String parameters) {
		this.parameters = parameters;
	}
	public String getPayload() {
		return payload;
	}
	public void setPayload(String payload) {
		this.payload = payload;
	}
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}
	public String getHeaders() {
		return headers;
	}
	public void setHeaders(String headers) {
		this.headers = headers;
	}
	public String getUserIp() {
		return userIp;
	}
	public void setUserIp(String userIp) {
		this.userIp = userIp;
	}
	public String getServerIp() {
		return serverIp;
	}
	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}
	public int getSpaceId() {
		return spaceId;
	}
	public void setSpaceId(int spaceId) {
		this.spaceId = spaceId;
	}
	public int getResponseStatusCode() {
		return responseStatusCode;
	}
	public void setResponseStatusCode(int responseStatusCode) {
		this.responseStatusCode = responseStatusCode;
	}
	public String getResponseHeader() {
		return responseHeader;
	}
	public void setResponseHeader(String responseHeader) {
		this.responseHeader = responseHeader;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTransactionId() { return transactionId;}
	public void setTransactionId(String transactionId) {this.transactionId = transactionId;}
	public long getTotalFileSize() {
		return totalFileSize;
	}
	public void setTotalFileSize(long totalFileSize) {
		this.totalFileSize = totalFileSize;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public boolean isAsync() {
		return isAsync;
	}
	public void setAsync(boolean isAsync) {
		this.isAsync = isAsync;
	}
	public List<TransactionAttachmentInfo> getAttachments() {
		return attachments==null?null:new ArrayList<>(attachments);
	}
	public void setAttachments(List<TransactionAttachmentInfo> attachments) {
		this.attachments = attachments==null?null:new ArrayList<>(attachments);
	}
	public TransactionListAttachmentsInfo getListAttachments() {
		return listAttachments;
	}
	public void setListAttachments(TransactionListAttachmentsInfo listAttachments) {
		this.listAttachments = listAttachments;
	}
	public TransactionDocumentListInfo getDocumentListInfo() {
		return documentListInfo == null?null:(TransactionDocumentListInfo)documentListInfo.clone();
	}
	public void setDocumentListInfo(TransactionDocumentListInfo documentInfo) {
		this.documentListInfo = documentInfo == null?null:(TransactionDocumentListInfo)documentInfo.clone();
	}
    public org.bson.Document getMetadata() {
        return metadata;
    }
    public void setMetadata(org.bson.Document metadata) {
        this.metadata = metadata;
    }

	public TransactionHookListInfo getHookListInfo() {
		return hookListInfo == null?null:(TransactionHookListInfo)hookListInfo.clone();
	}
	public void setHookListInfo(TransactionHookListInfo hookListInfo) {
		this.hookListInfo = hookListInfo == null?null:(TransactionHookListInfo)hookListInfo.clone();
	}
	public org.bson.Document getHook() {
		return hook;
	}
	public void setHook(org.bson.Document hook) {
		this.hook = hook;
	}
	public TransactionReportListInfo getReportListInfo() {
		return reportListInfo == null?null:(TransactionReportListInfo)reportListInfo.clone();
	}
	public void setReportListInfo(TransactionReportListInfo reportListInfo) {
		this.reportListInfo = reportListInfo == null?null:(TransactionReportListInfo)reportListInfo.clone();
	}
	
}