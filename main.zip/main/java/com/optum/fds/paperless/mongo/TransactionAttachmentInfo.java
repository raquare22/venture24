/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2013.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ***********************************************
 * Modification History
 * When         Who                   Revision
 * Dec 17 2014  Chida Jeyabalan		    Initial version
 ****************************************************************/

////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import java.io.Serializable;
import java.util.Date;

public class TransactionAttachmentInfo implements Serializable {
	private static final long serialVersionUID = 1L;
	private String id;
	private int spaceId;
	private String status;
	private Date expires;
	private String fileName;
	private long fileSize;
	private String externalId;
	private String contentType;
	private Date dateCreated;
	private Date dateModified;
	private String sourceSystemName;
	private Date sourceSystemDateCreated;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getSpaceId() {
		return spaceId;
	}

	public void setSpaceId(int spaceId) {
		this.spaceId = spaceId;
	}

	public Date getExpires() {
		return expires==null?null:(Date)expires.clone();
	}

	public void setExpires(Date expires) {
		 this.expires = expires==null?null:(Date)expires.clone();
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public Date getDateCreated() {
		return dateCreated==null?null:(Date)dateCreated.clone();
	}

	public void setDateCreated(Date dateCreated) {
		 this.dateCreated = dateCreated==null?null:(Date)dateCreated.clone();
	}

	public String getSourceSystemName() {
		return sourceSystemName;
	}

	public void setSourceSystemName(String sourceSystemName) {
		this.sourceSystemName = sourceSystemName;
	}
	
	public Date getSourceSystemDateCreated() {
		return sourceSystemDateCreated==null?null:(Date)sourceSystemDateCreated.clone();
	}

	public void setSourceSystemDateCreated(Date sourceSystemDateCreated) {
		 this.sourceSystemDateCreated = sourceSystemDateCreated==null?null:(Date)sourceSystemDateCreated.clone();
	}

	public Date getDateModified() {
		return dateModified==null?null:(Date)dateModified.clone();
	}

	public void setDateModified(Date dateModified) {
		 this.dateModified = dateModified==null?null:(Date)dateModified.clone();
	}



}
