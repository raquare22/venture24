package com.optum.fds.paperless.mongo.executions;

import java.util.Date;

public class HookExecutionRecordMetaData extends ExecutionRecord {

    private Date expires;
    private String hookExecutionId;
    private String hookId;

    public Date getExpires() {
        return expires == null ? null : (Date) expires.clone();
    }

    public void setExpires(Date expires) {
        this.expires = expires == null ? null : (Date) expires.clone();
    }

    public String getHookExecutionId() {
        return hookExecutionId;
    }

    public void setHookExecutionId(String hookExecutionId) {
        this.hookExecutionId = hookExecutionId;
    }

    public String getHookId() {
        return hookId;
    }

    public void setHookId(String hookId) {
        this.hookId = hookId;
    }

    @Override
    public String toString() {
        return "HookExecutionRecordMetaData [hookExecutionId=" + hookExecutionId + ", clientId=" + getClientId() +
                ", spaceId=" + getSpaceId() + ", appIdentifier=" + getAppIdentifier() + ", status=" + getStatus() +
                ", version=" + getVersion() + ", expires=" + expires + ", dateCreated=" + getDateCreated() +
                ", dateModified=" + getDateModified() + ", messageList=" + getMessageList() + ", hookId=" + hookId +
                ", activitiProcessKey=" + getActivitiProcessKey() + ", activitiJobId=" + getActivitiJobId() +
                ", dateActivitiJobCreated=" + getDateActivitiJobCreated() + ", dateActivitiJobModified=" +
                getDateActivitiJobModified() + ", activitiJobStatus=" + getActivitiJobStatus() +
                ", dateActivitiJobCompleted=" + getDateActivitiJobCompleted() + "]";
    }

}
