package com.optum.fds.paperless.mongo;




import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;


public class ItemList extends MetaData{


    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@JsonProperty("passThroughData")
    String passThroughData;
    
    @JsonProperty("filecreationDate")
    @JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    String filecreationDate;
    
    @JsonProperty("filedateEmailSent")
    String filedateEmailSent;
    
    @JsonProperty("dispatchedDate")
    String dispatchedDate;

    @JsonProperty("recipientId")
    String recipientId;
    
    @JsonProperty("filedeliveryMethod")
    String filedeliveryMethod;
    
    @JsonProperty("successcount")
    Integer successcount;
   
    @JsonProperty("deliveryTypeValue")
    String deliveryTypeValue;
    
    @JsonProperty("receivedDate")
    String receivedDate;
    
    @JsonProperty("deliveryMethod1")
    String deliveryMethod1;

	public String getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getPassThroughData() {
		return passThroughData;
	}

	public void setPassThroughData(String fileName) {
		this.passThroughData = fileName;
	}

	public String getFilecreationDate() {
		return filecreationDate;
	}

	public void setFilecreationDate(String filecreationDate) {
		this.filecreationDate = filecreationDate;
	}

	public String getFiledateEmailSent() {
		return filedateEmailSent;
	}

	public void setFiledateEmailSent(String filedateEmailSent) {
		this.filedateEmailSent = filedateEmailSent;
	}

	public String getDispatchedDate() {
		return dispatchedDate;
	}

	public void setDispatchedDate(String dispatchedDate) {
		this.dispatchedDate = dispatchedDate;
	}

	public String getRecipientId() {
		return recipientId;
	}

	public void setRecipientId(String recipientId) {
		this.recipientId = recipientId;
	}

	public String getFiledeliveryMethod() {
		return filedeliveryMethod;
	}

	public void setFiledeliveryMethod(String filedeliveryMethod) {
		this.filedeliveryMethod = filedeliveryMethod;
	}

	public Integer getSuccesscount() {
		return successcount;
	}

	public void setSuccesscount(Integer successcount) {
		this.successcount = successcount;
	}

	public String getDeliveryTypeValue() {
		return deliveryTypeValue;
	}

	public void setDeliveryTypeValue(String deliveryTypeValue) {
		this.deliveryTypeValue = deliveryTypeValue;
	}

	public String getDeliveryMethod1() {
		return deliveryMethod1;
	}

	public void setDeliveryMethod1(String deliveryMethod1) {
		this.deliveryMethod1 = deliveryMethod1;
	}
    

   
}