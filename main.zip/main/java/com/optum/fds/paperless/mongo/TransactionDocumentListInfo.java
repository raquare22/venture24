////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import java.util.ArrayList;

import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "documentListInfo")
public class TransactionDocumentListInfo extends ArrayList<TransactionDocumentInfo>{
    private static final long serialVersionUID = 1L;
}
