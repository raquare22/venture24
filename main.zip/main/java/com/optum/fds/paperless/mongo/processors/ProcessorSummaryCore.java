////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProcessorSummaryCore implements Serializable {

	static final long serialVersionUID = 1L;
	private List<ProcessorError> errorList;
	Long runTime;
	Date startTime;
	Date endTime;

	public ProcessorSummaryCore() {
		this.runTime = 0L;
	}

	public List<ProcessorError> getErrorList() {
		return errorList == null ? null : new ArrayList<>(errorList);
	}

	public void setErrorList(List<ProcessorError> errorList) {
		this.errorList = errorList == null ? null : new ArrayList<>(errorList);
	}

	public Long getRunTime() {
		return runTime;
	}

	public void setRunTime(Long runTime) {
		this.runTime = runTime;
	}

	public Date getStartTime() {
		return startTime == null ? null : (Date) startTime.clone();
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime == null ? null : (Date) startTime.clone();
	}

	public Date getEndTime() {
		return endTime == null ? null : (Date) endTime.clone();
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime == null ? null : (Date) endTime.clone();
	}

	public void addError(ProcessorError error) {
		if (errorList == null) {
			errorList = new ArrayList<>();
		}

		errorList.add(error);
	}

}
