/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/13/17
 */

////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
////import com.optum.fs.mongo.MetaData;

public class ProcessorCore extends MetaData {
    private Integer              configSpaceId;
    private ProcessorRecordTypes processorRecordType;
    private ProcessorSummary     summary;


    public Integer getConfigSpaceId() {
        return configSpaceId;
    }
    public void setConfigSpaceId(Integer configSpaceId) {
        if(configSpaceId != null) {
            this.configSpaceId = configSpaceId;
        }
    }
    public ProcessorRecordTypes getProcessorRecordType() {
        return processorRecordType;
    }
    public void setProcessorRecordType(ProcessorRecordTypes processorRecordType) {
        this.processorRecordType = processorRecordType;
    }
    @JsonProperty("summary")
    public ProcessorSummary getSummaryForDB(){
        // Check and see if summary is Null
        if(summary == null || summary.getErrorList() == null && summary.getProcessingMetrics() == null && summary.getRunTime() == null){
            summary = null;
        }
        return summary;
    }
    @JsonIgnore
    public ProcessorSummary getSummary() {
        if(summary == null){
            summary = new ProcessorSummary();
        }

        return summary;
    }
    @JsonProperty("summary")
    public void setSummary(ProcessorSummary summary) {
        this.summary = summary;
    }
}
