//package com.optum.fs.mongo.jobs;
package com.optum.fds.paperless.mongo.jobs;

public class ProcessorCoreJob extends Job {

    private static final long serialVersionUID = 1L;
    private String workFlow;
    private String filePath;
    private String fileName;
    private String processorId;
    private String processorJobType;
    private String appIdentifier;
    private int clientId;
    private int spaceId;

    public ProcessorCoreJob() {
    }

    public String getWorkFlow() {
        return workFlow;
    }

    public void setWorkFlow(String workFlow) {
        this.workFlow = workFlow;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getProcessorId() {
        return processorId;
    }

    public void setProcessorJobType(String processorJobType) {
        this.processorJobType = processorJobType;
    }

    public String processorJobType() {
        return processorJobType;
    }

    public void setProcessorId(String processorId) {
        this.processorId = processorId;
    }

    @Override
    public String toString() {
        return "Job [jobId=" + getJobId() + ", jobType=" + getJobType() + ", processorId=" + processorId
                + ", fileName=" + fileName + ", filePath=" + filePath + ", workFlow=" + workFlow + "]";
    }

    public String getAppIdentifier() {
        return appIdentifier;
    }

    public void setAppIdentifier(String appIdentifier) {
        this.appIdentifier = appIdentifier;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public int getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(int spaceId) {
        this.spaceId = spaceId;
    }
}
