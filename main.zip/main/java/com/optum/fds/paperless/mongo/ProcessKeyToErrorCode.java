package com.optum.fds.paperless.mongo;
import java.util.HashMap;
import java.util.Map;

import com.optum.fds.paperless.constants.ProcessKeys;
import com.optum.fds.paperless.exception.ErrorCode;


public class ProcessKeyToErrorCode {
	private ProcessKeyToErrorCode () {}
	
	private static Map<String, ErrorCode> processKeyErrorCodeMap = new HashMap<>();
	
	
	static {
		processKeyErrorCodeMap.put(ProcessKeys.STATUSFILE_PROCESS_KEY, ErrorCode.STATUS_FILE_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.SHUTTERFLY_PROCESS_KEY, ErrorCode.SHUTTERFLY_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.STORAGE_ERROR_SHUTTERFLY_PROCESS_KEY, ErrorCode.STORAGE_ERROR_SHUTTERFLY_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.RESPONSEFILE_PROCESS_KEY, ErrorCode.RESPONSE_FILE_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.BOUNCE_PROCESS_KEY, ErrorCode.BOUNCE_EMAIL_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.REQUIRED_FIELD_RULE_PROCESS_KEY, ErrorCode.REQUIRE_FIELD_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.PROVIDER_EMAIL_NOTIFICATION_PROCESS_KEY, ErrorCode.PEN_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.RETRIEVE_CORPORATE_MPIN_PROCESS_KEY, ErrorCode.PREPOST_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.RETRIEVE_PROVIDER_EMAIL_PROCESS_KEY, ErrorCode.PREPOST_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.MATCH_AND_MERGE_PROCESS_KEY, ErrorCode.MATCH_AND_MERGE_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.EMAIL_PROCESSOR_TRANSACTION_METADATA_PROCESS_KEY, ErrorCode.COMPANION_FILE_EMAIL_ALERT_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.CLEANUP_PROCESS_KEY, ErrorCode.CLEANUP_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.DOCLIB_PROCESS_KEY, ErrorCode.DOCLIB_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.CSV_CLEANUP_PROCESS_KEY, ErrorCode.CSV_CLEANUP_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.SFTP_PROCESS_KEY, ErrorCode.SFTP_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.UNZIP_FILE_PROCESS_KEY, ErrorCode.FILE_UNZIP_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.PROCESS_METADATA_PROCESS_KEY, ErrorCode.PROCESS_METADATA_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.PROCESS_METADATA_CALLBACK_PROCESS_KEY, ErrorCode.PROCESS_METADATA_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.GENERIC_WORKFLOW_PROCESS_KEY, ErrorCode.WORKFLOW_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.PROCESS_TEXT_FILE, ErrorCode.PROCESS_TEXT_FILE_ERROR);
		processKeyErrorCodeMap.put(ProcessKeys.RESPONSEFILE_PROCESS_KEY_USP_CLAIMS, ErrorCode.PROCESS_USPCLAIMS_RESPONSE_FILE);
		processKeyErrorCodeMap.put(ProcessKeys.PROCESS_SFTP_SEND_EMAIL, ErrorCode.PROCESS_SFTP_SEND_EMAIL);
		
	}
			
	public static ErrorCode getErrorCodeFromProcessKey(String processKey) {
		return processKeyErrorCodeMap.get(processKey);
	}

}