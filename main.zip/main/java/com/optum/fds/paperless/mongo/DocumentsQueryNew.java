package com.optum.fds.paperless.mongo;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;

import java.util.Optional;

public class DocumentsQueryNew {
    private String startDateCreation;
    private String endDateCreation;
    private String startDateModified;
    private String endDateModified;
    private Document metaDataMap = new Document();
    private String spaceId;

    public DocumentsQueryNew add(String key, Object value) {
        this.metaDataMap.put(key, value);
        return this;
    }

    public DocumentsQueryNew addJsonCriteria(String searchCriteria) {
        this.metaDataMap.putAll(
                Document.parse(
                        Optional.ofNullable(searchCriteria)
                                .map(String::trim)
                                .filter(StringUtils::isNotEmpty)
                                .orElseThrow(NullPointerException::new)
                )
        );
        return this;
    }

    public String getStartDateCreation() {
        return startDateCreation;
    }

    public DocumentsQueryNew setStartDateCreation(String startDateCreation) {
        this.startDateCreation = startDateCreation;
        return this;
    }

    public String getEndDateCreation() {
        return endDateCreation;
    }

    public DocumentsQueryNew setEndDateCreation(String endDateCreation) {
        this.endDateCreation = endDateCreation;
        return this;
    }

    public String getStartDateModified() {
        return startDateModified;
    }

    public DocumentsQueryNew setStartDateModified(String startDateModified) {
        this.startDateModified = startDateModified;
        return this;
    }

    public String getEndDateModified() {
        return endDateModified;
    }

    public DocumentsQueryNew setEndDateModified(String endDateModified) {
        this.endDateModified = endDateModified;
        return this;
    }

    public Document getMetaDataMap() {
        return metaDataMap;
    }

    public DocumentsQueryNew setMetaDataMap(Document metaDataMap) {
        this.metaDataMap = metaDataMap;
        return this;
    }

    public String getSpaceId() {
        return spaceId;
    }

    public DocumentsQueryNew setSpaceId(String spaceId) {
        this.spaceId = spaceId;
        return this;
    }
}