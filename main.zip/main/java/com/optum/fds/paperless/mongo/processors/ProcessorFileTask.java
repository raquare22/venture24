/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/13/17.
 */

////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;

import java.util.Date;
import java.util.Map;

public class ProcessorFileTask extends ProcessorTask {

    Date dateProcessed; // Date when FDS returned a response.
    String targetId;
    ProcessorTargetType targetType;

    Long fileSize;
    String fileType;
    transient Map metadata;
    String processorTransactionId;
    
    private String request;
	private String response;
	
	private String fdsDocumentId;
	private boolean postFDSResponse;
	private String fsId;
	
	private String doc360DocumentId;
	
	public String getDoc360DocumentId() {
        return doc360DocumentId;
    }

    public void setDoc360DocumentId(String doc360DocumentId) {
        this.doc360DocumentId = doc360DocumentId;
    }
    public String getFsId() {
		return fsId;
	}
	public void setFsId(String fsId) {
		this.fsId = fsId;
	}
	public String getFdsDocumentId() {
		return fdsDocumentId;
	}
	public void setFdsDocumentId(String fdsDocumentId) {
		this.fdsDocumentId = fdsDocumentId;
	}
	public boolean isPostFDSResponse() {
		return postFDSResponse;
	}
	public void setPostFDSResponse(boolean postFDSResponse) {
		this.postFDSResponse = postFDSResponse;
	}
	public Date getDateProcessed() {
        return dateProcessed;
    }
    public void setDateProcessed(Date dateProcessed) {
        this.dateProcessed = dateProcessed;
    }
    public Long getFileSize() {
        return fileSize;
    }
    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }
    public String getFileType() {
        return fileType;
    }
    public void setFileType(String fileType) {
        this.fileType = fileType;
    }
    public Map getMetadata() {
        return metadata;
    }
    public void setMetadata(Map metadata) {
        this.metadata = metadata;
    }
    public String getProcessorTransactionId() {
        return processorTransactionId;
    }
    public void setProcessorTransactionId(String processorTransactionId) {
        this.processorTransactionId = processorTransactionId;
    }
    public String getTargetId() {
        return targetId;
    }
    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }
    public ProcessorTargetType getTargetType() {
        return targetType;
    }
    public void setTargetType(ProcessorTargetType targetType) {
        this.targetType = targetType;
    }
	public String getRequest() {
		return request;
	}
	public void setRequest(String request) {
		this.request = request;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ProcessorFileTask [dateProcessed=" + dateProcessed + ", targetId=" + targetId + ", targetType="
				+ targetType + ", fileSize=" + fileSize + ", fileType=" + fileType + ", processorTransactionId="
				+ processorTransactionId + ", request=" + request + ", response=" + response + ", fdsDocumentId="
				+ fdsDocumentId + ", postFDSResponse=" + postFDSResponse + ", fsId=" + fsId + "]";
	}
	
	
}
