package com.optum.fds.paperless.mongo;

import java.util.Date;

public class HookEventType {

    private String id;
    private int spaceId;
    private String method;
    private String target;
    private String transactionId;
    private Date dateCreated;
    private Date dateModified;
    private Status status;
    private EvalTime evalTime;
    private DocumentMetaData documentMetaData;

    public HookEventType() {
    }

    public HookEventType(EvalTime evalTime, int spaceId, String method, String target) {
        setEvalTime(evalTime);
        setSpaceId(spaceId);
        setMethod(method);
        setTarget(target);
    }

    public EvalTime getEvalTime() {
        return evalTime;
    }

    public void setEvalTime(EvalTime evalTime) {
        this.evalTime = evalTime;
    }

    public DocumentMetaData getDocumentMetaData() {
        return documentMetaData;
    }

    public void setDocumentMetaData(DocumentMetaData documentMetaData) {
        this.documentMetaData = documentMetaData;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(int spaceId) {
        this.spaceId = spaceId;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method == null ? null : method.toLowerCase();
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target == null ? null : target.toLowerCase();
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public Date getDateCreated() {
        return dateCreated == null ? null : (Date) dateCreated.clone();
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated == null ? null : (Date) dateCreated.clone();
    }

    public Date getDateModified() {
        return dateModified == null ? null : (Date) dateModified.clone();
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified == null ? null : (Date) dateModified.clone();
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "HookEventType [spaceId=" + spaceId + ", method=" + method + ", target=" + target
                + ", transactionId=" + transactionId + ", evalTime=" + evalTime + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((evalTime == null) ? 0 : evalTime.hashCode());
        result = prime * result + ((method == null) ? 0 : method.hashCode());
        result = prime * result + spaceId;
        result = prime * result + ((target == null) ? 0 : target.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        HookEventType other = (HookEventType) obj;
        if (!evalTime.equals(other.evalTime)) {
            return false;
        }
        if (method == null) {
            if (other.method != null) {
                return false;
            }
        } else if (!method.equals(other.method)) {
            return false;
        }
        if (spaceId != other.spaceId) {
            return false;
        }
        if (target == null) {
            return other.target == null;
        } else {
            return target.equals(other.target);
        }
    }

    public enum Status {
        NEW, IN_PROCESS, DONE
    }

    public enum EvalTime {
        PRE_PROCESS, POST_PROCESS
    }


}
