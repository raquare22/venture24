package com.optum.fds.paperless.mongo;
import com.fasterxml.jackson.annotation.JsonProperty;
public class CodesTXGC extends MetaData{

    @JsonProperty("procedureCodeType")
    String procedureCodeType;

    @JsonProperty("procCodeDescription")
    String procCodeDescription;

    @JsonProperty("approvalRate")
    String approvalRate;

    @JsonProperty("numberOfCodesInCluster")
    String numberOfCodesInCluster;

    public String getApprovalRate() {
        return approvalRate;
    }
    public void setApprovalRate(String approvalRate) {
        this.approvalRate = approvalRate;
    }

    public String getNumberOfCodesInCluster() {
        return numberOfCodesInCluster;
    }
    public void setNumberOfCodesInCluster(String numberOfCodesInCluster) {
        this.numberOfCodesInCluster = numberOfCodesInCluster;
    }
    public String getProcedureCodeType() {
        return procedureCodeType;
    }
    public void setProcedureCodeType(String procedureCodeType) {
        this.procedureCodeType = procedureCodeType;
    }
    public String getProcCodeDescription() {
        return procCodeDescription;
    }
    public void setProcCodeDescription(String procCodeDescription) {
        this.procCodeDescription = procCodeDescription;
    }
	@Override
	public String toString() {
		return "CodesTXGC [procedureCodeType=" + procedureCodeType + ", procCodeDescription=" + procCodeDescription
				+ ", approvalRate=" + approvalRate + ", numberOfCodesInCluster=" + numberOfCodesInCluster + "]";
	}
    
    
}
