/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who                 Revision
 * 12.Dec.2016  Terry J. Violette   Initial version
 ****************************************************************/
////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

////import com.optum.fs.mongo.executions.HookExecutionRecordMetaData;
////import com.optum.fs.mongo.processors.OptumHttpEntity;
import org.springframework.http.HttpMethod;

import com.optum.fds.paperless.mongo.executions.HookExecutionRecordMetaData;
import com.optum.fds.paperless.mongo.processors.OptumHttpEntity;

import java.net.URI;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class JobMetaData {

    private String id;
    private String parentId;
    private int clientId;
    private int spaceId;
    private String appIdentifier;
    private String status;
    private String version;
    private Date expires;
    private Date dateCreated;
    private Date dateModified;
    private Date executionDateTime;
    private int executionOrder;
    private String transactionId;
    private String jobType;
    private Integer priority;
    private String processorJobType;
    private String errorMessage;
    private String processorId;
    private String processorTransactionId;
    private String csvProcessorRowTaskId;
    private String fileName;
    private String filePath;
    private String workFlow;
    private String serverName;
    private String serverType;

    private String targetType ; // e.g. documents
    private String targetId ;   // e.g docId or fsId in case of attachment     

    private String hookId ;
    private HookMetaData hook;
    private DocumentMetaData document;
    private List<AttachmentMetaData> attachments;
    
    private HookExecutionRecordMetaData hookExecution;

    /* csvProcessorJob */
    private String csvProcessorTransactionId;
    private String templateDefinition;
    private String templateId;
    private String delimit;
    private Boolean companionTRL;

    /* restApiJob */
    private HttpMethod method;
    private OptumHttpEntity request;
    private String sourceType;
    private URI uri;
    
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }


    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public int getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(int spaceId) {
        this.spaceId = spaceId;
    }

    public String getAppIdentifier() {
        return appIdentifier;
    }

    public void setAppIdentifier(String appIdentifier) {
        this.appIdentifier = appIdentifier;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Date getExpires() {
    	return expires==null?null:(Date)expires.clone();
    }

    public void setExpires(Date expires) {
       this.expires = expires==null?null:(Date)expires.clone();
    }

    public Date getDateCreated() {
    	return dateCreated==null?null:(Date)dateCreated.clone();
    }

    public void setDateCreated(Date dateCreated) {
    	this.dateCreated = dateCreated==null?null:(Date)dateCreated.clone();
    }

    public Date getDateModified() {
    	return dateModified==null?null:(Date)dateModified.clone();
    }

    public void setDateModified(Date dateModified) {
    	this.dateModified = dateModified==null?null:(Date)dateModified.clone();
    }

    public Date getExecutionDateTime() {
    	return executionDateTime==null?null:(Date)executionDateTime.clone();
    }

    public void setExecutionDateTime(Date executionDateTime) {
    	this.executionDateTime = executionDateTime==null?null:(Date)executionDateTime.clone();
    }

    public int getExecutionOrder() {
        return executionOrder;
    }

    public void setExecutionOrder(int executionOrder) {
        this.executionOrder = executionOrder;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public Integer isPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public String getProcessorJobType() {
        return processorJobType;
    }

    public void setProcessorJobType(String processorJobType) {
        this.processorJobType = processorJobType;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getTargetType() {
        return targetType;
    }

    public void setTargetType(String targetType) {
        this.targetType = targetType;
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }


    public HookMetaData getHook() {
        return hook;
    }

    public void setHook(HookMetaData hook) {
        this.hook = hook;
    }

    public HookExecutionRecordMetaData getHookExecution() {
        return hookExecution;
    }

    public void setHookExecution(HookExecutionRecordMetaData hookExecution) {
        this.hookExecution = hookExecution;
    }

    public String getHookId() {
        return hookId;
    }

    public void setHookId(String hookId) {
        this.hookId = hookId;
    }

    @Override
    public String toString() {
        return "JobMetaData [id=" + id + ", parentId=" + parentId + ", clientId=" + clientId + ", spaceId=" + spaceId
                + ", appIdentifier=" + appIdentifier + ", status=" + status + ", version=" + version + ", expires=" + expires
                + ", dateCreated=" + dateCreated + ", dateModified=" + dateModified + ", transactionId=" + transactionId
                + ", errorMessage=" + errorMessage + ", targetType=" + targetType + ", targetId=" + targetId + ", hookId=" + hookId
                + ", hook=" + hook + ", hookExecution=" + hookExecution + ", serverName =" + serverName
                + ", serverType=" + serverType + "]";
    }

	public DocumentMetaData getDocument() {
		return document;
	}

	public void setDocument(DocumentMetaData document) {
		this.document = document;
	}

    public List<AttachmentMetaData> getAttachments() {
    	return attachments==null?null:new ArrayList<>(attachments);
    }

    public void setAttachments(List<AttachmentMetaData> attachments) {
    	this.attachments = attachments==null?null:new ArrayList<>(attachments);
    }

    public String getProcessorId() {
        return processorId;
    }

    public void setProcessorId(String processorId) {
        this.processorId = processorId;
    }

    public void setProcessorTransactionId(String processorTransactionId) {
        this.processorTransactionId = processorTransactionId;
    }

    public String getProcessorTransactionId() {
        return processorTransactionId;
    }

    public void setCsvProcessorTransactionId(String csvProcessorTransactionId) {
        this.csvProcessorTransactionId = csvProcessorTransactionId;
    }

    public String getCsvProcessorTransactionId() {
        return csvProcessorTransactionId;
    }

    public void setCsvProcessorRowTaskId(String csvProcessorRowTaskId) {
        this.csvProcessorRowTaskId = csvProcessorRowTaskId;
    }

    public String getCsvProcessorRowTaskId() {
        return csvProcessorRowTaskId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getWorkFlow() {
        return workFlow;
    }

    public void setWorkFlow(String workFlow) {
        this.workFlow = workFlow;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }
    public String getServerName() {
        return serverName;
    }

    public void setServerType(String serverType) {
        this.serverType = serverType;
    }

    public String getServerType() {
        return serverType;
    }

    public String getTemplateDefinition() {
        return templateDefinition;
    }

    public void setTemplateDefinition(String templateDefinition) {
        this.templateDefinition = templateDefinition;
    }

    public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	
	public String getDelimit() {
		return this.delimit;
	}
	
	public void setDelimit(String delimit) {
		this.delimit = delimit;
	}
	
	public Boolean getCompanionTRL() {
		return this.companionTRL;
	}
	
	public void setCompanionTRL(Boolean companionTRL) {
		this.companionTRL = companionTRL;
	}

	/**
	 * @return the method
	 */
	public HttpMethod getMethod() {
		return method;
	}

	/**
	 * @param method the method to set
	 */
	public void setMethod(HttpMethod method) {
		this.method = method;
	}

	/**
	 * @return the request
	 */
	public OptumHttpEntity getRequest() {
		return request;
	}

	/**
	 * @param request the request to set
	 */
	public void setRequest(OptumHttpEntity request) {
	    this.request = request;
	}

	/**
	 * @return the sourceType
	 */
	public String getSourceType() {
		return sourceType;
	}

	/**
	 * @param sourceType the source to set
	 */
	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	/**
	 * @return the uri
	 */
	public URI getUri() {
		return uri;
	}

	/**
	 * @param uri the uri to set
	 */
	public void setUri(URI uri) {
		this.uri = uri;
	}
    
  
}
