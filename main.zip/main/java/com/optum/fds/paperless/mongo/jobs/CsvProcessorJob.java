////package com.optum.fs.mongo.jobs;
package com.optum.fds.paperless.mongo.jobs;

public class CsvProcessorJob extends ProcessorCoreJob{
	
	private static final long serialVersionUID = 1L;
	
	private String csvProcessorTransactionId;
	private String templateDefintion;
	private String templateId;
	private String delimit;
	private Boolean companionTRL;
	
	public CsvProcessorJob() {
    }
	/**
	 * @return the csvProcessorTransactionId
	 */
	public String getCsvProcessorTransactionId() {
		return csvProcessorTransactionId;
	}

	/**
	 * @param csvProcessorTransactionId the csvProcessorTransactionId to set
	 */
	public void setCsvProcessorTransactionId(String csvProcessorTransactionId) {
		this.csvProcessorTransactionId = csvProcessorTransactionId;
	}

	/**
	 * @return the templateDefintion
	 */
	public String getTemplateDefinition() {
		return templateDefintion;
	}

	/**
	 * @param templateDefintion the csvProcessorTransactionId to set
	 */
	public void setTemplateDefinition(String templateDefintion) {
		this.templateDefintion = templateDefintion;
	}

	/**
	 * @return the delimit
	 */
	public String getDelimit() {
		return delimit;
	}

	/**
	 * @param delimit to set
	 */
	public void setDelimit(String delimit) {
		this.delimit = delimit;
	}

	/**
	 * @return the companionTRL
	 */
	public Boolean getCompanionTRL() {
		return companionTRL;
	}

	/**
	 * @param companionTRL to set
	 */
	public void setCompanionTRL(Boolean companionTRL) {
		this.companionTRL = companionTRL;
	}

	@Override
	 public String toString() {
		 return "CsvProcessorJob [csvProcessorTransactionId=" + getCsvProcessorTransactionId() + "]";
	 }
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	
}
