/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/13/17.
 */

////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;

import com.google.gson.JsonObject;

import java.util.List;

public class ProcessorTransactions{

	List<JsonObject> ProcessorTransactions;

    public List<JsonObject> getProcessorTransactions() {
        return ProcessorTransactions;
    }

    public void setProcessorTransactions(List<JsonObject> processorTransactions) {
        ProcessorTransactions = processorTransactions;

    }
}
