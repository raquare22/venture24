/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When         Who                 Revision
 * 12.Dec.2016  Terry J. Violette   Initial version
 ****************************************************************/
package com.optum.fds.paperless.mongo;

import com.optum.fds.paperless.mongo.executions.HookExecutionRecordMetaData;

import java.util.*;

public class HookTransactionMetaData {

    private String id;
    private String parentId;
    private int clientId;
    private int spaceId;
    private String appIdentifier;
    private String status;
    private String version;
    private Date expires;
    private Date dateCreated;
    private Date dateModified;
    private String transactionId;
    private String errorMessage;

    private String hookRecordType;  // value will be "hookTransaction" in this case
    private String targetType; /// e.g. document
    private String targetId;   /// e.g docId or fsId in case of attachment

    private String jobId;

    private List<HookExecutionRecordMetaData> hookExecutionList;

    public String getId() {
        return id;
    }

    public HookTransactionMetaData setId(String id) {
        this.id = id;
        return this;
    }

    public String getParentId() {
        return parentId;
    }

    public HookTransactionMetaData setParentId(String parentId) {
        this.parentId = parentId;
        return this;
    }

    public int getClientId() {
        return clientId;
    }

    public HookTransactionMetaData setClientId(int clientId) {
        this.clientId = clientId;
        return this;
    }

    public int getSpaceId() {
        return spaceId;
    }

    public HookTransactionMetaData setSpaceId(int spaceId) {
        this.spaceId = spaceId;
        return this;
    }

    public String getAppIdentifier() {
        return appIdentifier;
    }

    public HookTransactionMetaData setAppIdentifier(String appIdentifier) {
        this.appIdentifier = appIdentifier;
        return this;
    }

    public String getStatus() {
        return status;
    }

    public HookTransactionMetaData setStatus(String status) {
        this.status = status;
        return this;
    }

    public String getVersion() {
        return version;
    }

    public HookTransactionMetaData setVersion(String version) {
        this.version = version;
        return this;
    }

    public Date getExpires() {
        return expires == null? null : (Date) expires.clone();
    }

    public HookTransactionMetaData setExpires(Date expires) {
        this.expires = (expires == null) ? null : (Date) expires.clone();
        return this;
    }

    public Date getDateCreated() {
        return dateCreated == null? null : (Date) dateCreated.clone();
    }

    public HookTransactionMetaData setDateCreated(Date dateCreated) {
        this.dateCreated = (dateCreated == null) ? null : (Date) dateCreated.clone();
        return this;
    }

    public Date getDateModified() {
        return dateModified == null? null : (Date) dateModified.clone();
    }

    public HookTransactionMetaData setDateModified(Date dateModified) {
        this.dateModified = (dateModified == null) ? null : (Date) dateModified.clone();
        return this;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public HookTransactionMetaData setTransactionId(String transactionId) {
        this.transactionId = transactionId;
        return this;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public HookTransactionMetaData setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
        return this;
    }

    public String getHookRecordType() {
        return hookRecordType;
    }

    public HookTransactionMetaData setHookRecordType(String hookRecordType) {
        this.hookRecordType = hookRecordType;
        return this;
    }

    public String getTargetType() {
        return targetType;
    }

    public HookTransactionMetaData setTargetType(String targetType) {
        this.targetType = targetType;
        return this;
    }

    public String getTargetId() {
        return targetId;
    }

    public HookTransactionMetaData setTargetId(String targetId) {
        this.targetId = targetId;
        return this;
    }

    public String getJobId() {
        return jobId;
    }

    public HookTransactionMetaData setJobId(String jobId) {
        this.jobId = jobId;
        return this;
    }

    public List<HookExecutionRecordMetaData> getHookExecutionList() {
        return hookExecutionList == null? Collections.emptyList() : new ArrayList<>(hookExecutionList);
    }

    public HookTransactionMetaData setHookExecutionList(List<HookExecutionRecordMetaData> hookExecutionList) {
        this.hookExecutionList = (hookExecutionList == null) ? Collections.emptyList() : new ArrayList<>(hookExecutionList);
        return this;
    }

    @Override
    public String toString() {
        return "HookTransactionMetaData [id=" + id + ", parentId=" + parentId + ", clientId="
                + clientId + ", spaceId=" + spaceId + ", appIdentifier=" + appIdentifier
                + ", status=" + status
                + ", version=" + version + ", expires=" + expires + ", dateCreated=" + dateCreated
                + ", dateModified=" + dateModified + ", transactionId=" + transactionId
                + ", errorMessage="
                + errorMessage + ", hookRecordType=" + hookRecordType + ", targetType=" + targetType
                + ", targetId=" + targetId + ", jobId=" + jobId + ", hookExecutionList="
                + hookExecutionList + "]";
    }

}
