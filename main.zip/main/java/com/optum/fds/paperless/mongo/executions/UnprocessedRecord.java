/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 */

////package com.optum.fs.mongo.executions;
package com.optum.fds.paperless.mongo.executions;
import java.io.Serializable;

public class UnprocessedRecord extends ExecutionRecord implements Serializable{
    
	public UnprocessedRecord(String unprocessedRecord, int index) {
		super();
		this.unprocessRecord = unprocessedRecord;
		this.index = index;
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String unprocessRecord;
	
	private int index;

	public String getUnprocessRecord() {
		return unprocessRecord;
	}
	public void setUnprocessRecord(String unprocessRecord) {
		this.unprocessRecord = unprocessRecord;
	}
    public int getIndex() {
        return index;
    }
    public void setIndex(int index) {
        this.index = index;
    }
}
