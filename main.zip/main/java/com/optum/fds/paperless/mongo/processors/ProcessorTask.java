/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/13/17.
 */

////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;

////import com.optum.fs.mongo.executions.ProcessorExecutionRecord;
////import com.optum.fs.mongo.executions.UnprocessedRecord;

import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.executions.UnprocessedRecord;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProcessorTask extends ProcessorCore {
    String processorId;
    String fileName;
    String location;
    String processedByHost;
    String serverType;
    transient List<ProcessorExecutionRecord> processorExecutionRecordList;
    transient List<UnprocessedRecord> unprocessedRecordList;

    public String getProcessorId() {
        return processorId;
    }

    public void setProcessorId(String processorId) {
        this.processorId = processorId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getProcessedByHost() {
        return processedByHost;
    }

    public void setProcessedByHost(String processedByHost) {
        this.processedByHost = processedByHost;
    }

    public String getServerType() {
        return serverType;
    }

    public void setServerType(String serverType) {
        this.serverType = serverType;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public List<ProcessorExecutionRecord> getProcessorExecutionRecordList() {
        if (processorExecutionRecordList == null) {
            processorExecutionRecordList = new ArrayList<>();
        }
        return processorExecutionRecordList;
    }

    public void setProcessorExecutionRecordList(List<ProcessorExecutionRecord> processorExecutionRecordList) {
        this.processorExecutionRecordList = processorExecutionRecordList;
    }

    public void addProcessorExecutionRecord(ProcessorExecutionRecord processorExecutionRecord) {
        if (processorExecutionRecordList == null) {
            processorExecutionRecordList = new ArrayList<>();
        }

        processorExecutionRecordList.add(processorExecutionRecord);
    }

    public List<UnprocessedRecord> getUnprocessedRecordList() {
        return unprocessedRecordList;
    }

    public void setUnprocessedRecordList(List<UnprocessedRecord> unprocessedRecordList) {
        this.unprocessedRecordList = unprocessedRecordList;
    }

    public void setStartTime() {
        getSummary().setStartTime(new Date());
    }

    public void setEndTime() {
        ProcessorSummary summary = getSummary();
        if (summary.getStartTime() == null) {
            summary.setStartTime(new Date());
        }
        summary.setEndTime(new Date());
        summary.setRunTime(summary.getEndTime().getTime() - summary.getStartTime().getTime());
    }
}
