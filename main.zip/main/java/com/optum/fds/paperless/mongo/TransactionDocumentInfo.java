/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2013.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When          Who              Revision
 * June 05 2015  Vinata Gangolli 	 Initial version
 ****************************************************************/
////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;

public class TransactionDocumentInfo {
	private String documentId;
	private String parentId;
	private String externalId;
	private Integer spaceId;
	private String status;
	private String version;
	private Date expires;
	private List<TransactionAttachmentInfo> attachments;
	private Document metadata ;

	

	public String getDocumentId() {
		return documentId;
	}

	public void setId(String documentId) {
		this.documentId = documentId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	

	public List<TransactionAttachmentInfo> getAttachments() {
		return attachments==null?null:new ArrayList<>(attachments);
	}

	public void setAttachments(List<TransactionAttachmentInfo> attachments) {
		this.attachments = attachments==null?null:new ArrayList<>(attachments);
	}

	public Date getExpires() {
		return expires==null?null:(Date)expires.clone();
	}

	public void setExpires(Date expires) {
		this.expires = expires==null?null:(Date)expires.clone();
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public Integer getSpaceId() {
		return spaceId;
	}

	public void setSpaceId(Integer spaceId) {
		this.spaceId = spaceId;
	}

    public Document getMetadata() {
        return metadata;
    }

    public void setMetadata(Document metadata) {
        this.metadata = metadata;
    }


}
