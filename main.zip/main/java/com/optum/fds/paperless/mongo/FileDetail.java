package com.optum.fds.paperless.mongo;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class FileDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("FileName")
    String fileName;

    @JsonProperty("Status")
    String Status;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }
}