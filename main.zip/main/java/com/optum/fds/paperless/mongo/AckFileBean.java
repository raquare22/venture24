package com.optum.fds.paperless.mongo;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.List;

public class AckFileBean implements Serializable {

    private static final long serialVersionUID = 1L;
    @JsonProperty("BatchID")
    String batchId;
    @JsonProperty("Count")
    Integer count;
    @JsonProperty("FileNameList")
    List<FileDetail> fileList;
    @JsonProperty("UploadDate")
    String UploadDate;

    public String getUploadDate() {
        return UploadDate;
    }

    public void setUploadDate(String uploadDate) {
        UploadDate = uploadDate;
    }

    public List<FileDetail> getFileList() {
        return fileList;
    }
    public void setFileList(List<FileDetail> fileList) {
        this.fileList = fileList;
    }

    public String getBatchId() {
        return batchId;
    }
    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }
    public Integer getCount() {
        return count;
    }
    public void setCount(Integer count) {
        this.count = count;
    }
}