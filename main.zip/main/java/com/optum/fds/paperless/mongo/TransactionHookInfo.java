/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When          Who              Revision
 * Dec 13,2016  Suman Halder		 	 Initial version
 ****************************************************************/
////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;


import java.util.Date;

import org.bson.Document;

public class TransactionHookInfo {
	private String hookId;
	private String parentId;
	private String externalId;
	private Integer spaceId;
	private String status;
	private String version;
	private Date expires;
	private Document hook ;

	public String getHookId() {
		return hookId;
	}

	public void setHookId(String hookId) {
		this.hookId = hookId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Date getExpires() {
		return expires==null?null:(Date)expires.clone();
	}

	public void setExpires(Date expires) {
		this.expires = expires==null?null:(Date)expires.clone();
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public Integer getSpaceId() {
		return spaceId;
	}

	public void setSpaceId(Integer spaceId) {
		this.spaceId = spaceId;
	}

    public Document getHook() {
        return hook;
    }

    public void setMetadata(Document hook) {
        this.hook = hook;
    }


}
