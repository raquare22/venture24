/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 4/5/17.
 */

////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;

public class ProcessorMap {
    private String  key;
    private String  newKey;
    private Boolean required = false;
    private String  description;
    private String  requiredCriteria;
    private Boolean severeError = false;
    private String valueRegex;
    
	public ProcessorMap(){}
    public ProcessorMap(String key){
        this.key = key;
    }
    public ProcessorMap(String key, String newKey) {
        this.key = key;
        this.newKey = newKey;
    }
    public ProcessorMap(String key, String newKey, Boolean required) {
        this.key = key;
        this.newKey = newKey;
        this.required = required;
    }
    public ProcessorMap(String key, String newKey, Boolean required, String description) {
        this.key = key;
        this.newKey = newKey;
        this.required = required;
        this.description = description;
    }
    public ProcessorMap(String key, String newKey, Boolean required, String description, String requiredCriteria) {
        this.key = key;
        this.newKey = newKey;
        this.required = required;
        this.description = description;
        this.requiredCriteria = requiredCriteria;
    }
    public ProcessorMap(String key, String newKey, Boolean required, String description, String requiredCriteria, Boolean severeError) {
        this.key = key;
        this.newKey = newKey;
        this.required = required;
        this.description = description;
        this.requiredCriteria = requiredCriteria;
        this.severeError = severeError;
    }
    public ProcessorMap(String key, String newKey, Boolean required, String description, String requiredCriteria,
			Boolean severeError, String valueRegex) {
		super();
		this.key = key;
		this.newKey = newKey;
		this.required = required;
		this.description = description;
		this.requiredCriteria = requiredCriteria;
		this.severeError = severeError;
		this.valueRegex = valueRegex;
	}

    public String getKey() {
        return key;
    }
    public void setKey(String key) {
        this.key = key;
    }
    public String getNewKey() {
        return newKey;
    }
    public void setNewKey(String newKey) {
        this.newKey = newKey;
    }
    public Boolean getRequired() {
        return required;
    }
    public void setRequired(Boolean required) {
        this.required = required;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getRequiredCriteria() {
		return requiredCriteria;
	}
	public void setRequiredCriteria(String requiredCriteria) {
		this.requiredCriteria = requiredCriteria;
	}
	public Boolean getSevereError() {
		return severeError;
	}
	public void setSevereError(Boolean severeError) {
		this.severeError = severeError;
	}
	public String getValueRegex() {
		return valueRegex;
	}
	public void setValueRegex(String valueRegex) {
		this.valueRegex = valueRegex;
	}

}