////package com.optum.fs.mongo.jobs;
package com.optum.fds.paperless.mongo.jobs;

public class ProcessorJob extends ProcessorCoreJob {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
   
    private String processorTransactionId;    

    public ProcessorJob() {
    }
   
    public String getProcessorTransactionId() {
        return processorTransactionId;
    }

    public void setProcessorTransactionId(String processorTransactionId) {
        this.processorTransactionId = processorTransactionId;
    }

    @Override
    public String toString() {
        return "Job [jobId=" + getJobId() + ", jobType=" + getJobType() + ", "
        		+ "processorTransactionId=" + processorTransactionId+ "]";
    }
    
}
