/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/13/17.
 */

////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;

////import com.optum.fs.mongo.ProcessorTransactionCore;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.optum.fds.paperless.mongo.ProcessorTransactionCore;

public class ProcessorTransaction extends ProcessorTransactionCore implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Integer fileCount;
	transient List<String> missingFileList;
	transient List<String> extraFileList;
	transient List<String> fileToProcessList;
	transient List<String> documentIds;
	AckStatus ackStatus;
	
	
	public List<String> getDocumentIds() {
		return documentIds;
	}
	public void setDocumentIds(List<String> documentIds) {
		this.documentIds = documentIds;
	}
	public Integer getFileCount() {
        return fileCount;
    }
    public void setFileCount(Integer fileCount) {
        this.fileCount = fileCount;
    }
    public List<String> getMissingFileList() {
        return missingFileList;
    }
    public void setMissingFileList(List<String> missingFileList) {
        this.missingFileList = missingFileList;
    }
    public List<String> getExtraFileList() {
        return extraFileList;
    }
    public void setExtraFileList(List<String> extraFileList) {
        this.extraFileList = extraFileList;
    }
    public List<String> getFileToProcessList() {
        return fileToProcessList;
    }
    public void setFileToProcessList(List<String> fileToProcessList) {
        this.fileToProcessList = fileToProcessList;
    }

    public void addMissingFile(String fileName){
        if(missingFileList == null){
            missingFileList = new ArrayList<>();
        }

        missingFileList.add(fileName);
    }
    public void addExtraFile(String fileName){
        if(extraFileList == null){
            extraFileList = new ArrayList<>();
        }

        extraFileList.add(fileName);
    }
    public void addFileToProcess(String fileName){
        if(fileToProcessList == null){
            fileToProcessList = new ArrayList<>();
        }

        fileToProcessList.add(fileName);
    }
    
    public AckStatus getAckStatus() {
		return ackStatus;
	}
	public void setAckStatus(AckStatus ackStatus) {
		this.ackStatus = ackStatus;
	}
}
