/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2018.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 */

//package com.optum.fs.mongo.csvProcessors;
package com.optum.fds.paperless.mongo.csvProcessors;

public enum CsvProcessorRecordTypes {
    csvProcessorTransaction
}
