package com.optum.fds.paperless.mongo.processors;

//import javax.persistence.Transient;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.optum.fds.paperless.util.Converters;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProcessorMetaData extends ProcessorCore {
  private static final long serialVersionUID = 1L;

    private String  cleanupWorkflow;
    @JsonProperty("end_date")
    private Date    endDate;
    private Date    lastRun;
    private Date    lastCleanUpRun;
    private Date 	resolveIncompleteProcessorTransactionLastRun;
    private Boolean locked = false;
    private Boolean resolveIncompleteProcessorTransactionLocked = false;
    private transient Map   process;
    private Date    startDate;
    private String processorType;
    private int retryCount;
    private Integer priority;

    public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	//@Transient
    private transient String endDateString;
    //@Transient
    private transient String startDateString;

    public ProcessorMetaData(){
        // Required Constructor
    }

    public Date getStartDate() {
    	return startDate==null?null:(Date)startDate.clone();
    }

    public String getProcessorType() {
		return processorType;
	}

	public void setProcessorType(String processorType) {
		this.processorType = processorType;
	}
	
	@JsonProperty("start_date")
    public void setStartDate(String startDate){
        setStartDate(startDate, true);
    }
    @JsonIgnore
    public void setStartDate(Date startDate) {
    	 this.startDate = startDate==null?null:(Date)startDate.clone();
    }
    @JsonIgnore
    public void setStartDate(String startDate, Boolean setPersistent){
        this.startDateString = startDate;
        if(setPersistent) {
            Date startDateConverted = Converters.convertISOStringToDate(startDate);
            // If date is not parseable default to now
            setStartDate(startDateConverted != null ? startDateConverted : new Date());

            this.startDateString = null;
        }
    }

    public Date getEndDate() {
    	return endDate==null?null:(Date)endDate.clone();
    }

    public String getCleanupWorkflow() {
        return cleanupWorkflow;
    }

    public void setCleanupWorkflow(String cleanupWorkflow) {
        this.cleanupWorkflow = cleanupWorkflow;
    }

//    @JsonIgnore
    public void setEndDate(Date endDate) {
    	this.endDate = endDate == null ? null : (Date) endDate.clone();
    }
//    @JsonProperty("end_date")
    @JsonIgnore
    public void setEndDate(String endDate){
        setEndDate(endDate, false);
    }
    @JsonIgnore
    public void setEndDate(String endDate, Boolean setPersistent){
        this.endDateString = endDate;
        if(setPersistent) {
            //setEndDate(Converters.convertISOStringToDate(endDate));
            this.endDateString = null;
        }
    }

    public Map getProcessConfig() {
        if (process==null) {
            return null;
        }
        return (Map) process.get("config");
    }

    public Map getProcess() {
        return process;
    }
    public void setProcess(Map process) {
        this.process = process;
    }
    public Date getLastRun(){
    	return lastRun==null?null:(Date)lastRun.clone();
    }
    public void setLastRun(Date lastRun){
    	 this.lastRun = lastRun==null?null:(Date)lastRun.clone();
    }

    public Date getLastCleanUpRun() {
    	return lastCleanUpRun==null?null:(Date)lastCleanUpRun.clone();
    }

    public void setLastCleanUpRun(Date lastCleanUpRun) {
        this.lastCleanUpRun = lastCleanUpRun==null?null:(Date)lastCleanUpRun.clone();
    }

    public boolean isLocked() {
        return locked == null ? false : locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    @Override
    public List<ProcessorRevision> getRevisions(){
        List<ProcessorRevision> revisions = new ArrayList<>();

        final List<ProcessorRevision> metaDataRevisions = super.getRevisions();
        if(metaDataRevisions != null) {
            metaDataRevisions.forEach(
                    revision -> revisions.add((ProcessorRevision) revision)
            );
        }

        return revisions;
    }

    public void addRevision(ProcessorRevision revision) {
        List<ProcessorRevision> revisions =  this.getRevisions();
        revisions.add(revision);
        setRevisions(revisions);
    }

    @JsonIgnore
    public String getEndDateString() {
        return endDateString;
    }
    @JsonIgnore
    public String getStartDateString() {
        return startDateString;
    }

    public void setDates() {
        setStartDate(startDateString, true);
        setEndDate(endDateString, true);
    }

	public int getRetryCount() {
		return retryCount;
	}

	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}

	public Date getResolveIncompleteProcessorTransactionLastRun() {
		return resolveIncompleteProcessorTransactionLastRun;
	}

	public void setResolveIncompleteProcessorTransactionLastRun(Date resolveIncompleteProcessorTransactionLastRun) {
		this.resolveIncompleteProcessorTransactionLastRun = resolveIncompleteProcessorTransactionLastRun;
	}

	public Boolean getResolveIncompleteProcessorTransactionLocked() {
		return resolveIncompleteProcessorTransactionLocked;
	}

	public void setResolveIncompleteProcessorTransactionLocked(Boolean resolveIncompleteProcessorTransactionLocked) {
		this.resolveIncompleteProcessorTransactionLocked = resolveIncompleteProcessorTransactionLocked;
	}
}
