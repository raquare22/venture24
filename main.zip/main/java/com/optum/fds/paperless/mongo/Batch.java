package com.optum.fds.paperless.mongo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.optum.fds.paperless.client.CustomDateDeserializer;
import com.optum.fds.paperless.client.CustomDateSerializer;

import java.util.Date;
import java.util.List;

public class Batch extends MetaData{


    @JsonProperty("BatchID")
    String batchId;
    @JsonProperty("Count")
    Integer count;
    @JsonProperty("FileNameList")
    List<FileDetail> fileList;

    @JsonProperty("UploadDate")
    @JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private Date uploadDate;

    public Date getUploadDate() {
        return uploadDate;
    }
    public void setUploadDate(Date uploadDate) {
        this.uploadDate = uploadDate;
    }
    public List<FileDetail> getFileList() {
        return fileList;
    }
    public void setFileList(List<FileDetail> fileList) {
        this.fileList = fileList;
    }

    public String getBatchId() {
        return batchId;
    }
    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }
    public Integer getCount() {
        return count;
    }
    public void setCount(Integer count) {
        this.count = count;
    }

}