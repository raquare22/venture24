//package com.optum.fs.workflow.java.delegate;
////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;


import org.springframework.http.HttpEntity;
import org.springframework.util.MultiValueMap;

import java.io.Serializable;

public class OptumHttpEntity extends HttpEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    public OptumHttpEntity(){
        super();
    };

    public OptumHttpEntity(MultiValueMap<String, String> body, MultiValueMap<String, String> headers) {
        super(body, headers);
    }
}
