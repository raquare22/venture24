/****************************************************************
 * Copyright UNITEDHEALTH GROUP CORPORATION 2016.
 * This software and documentation contain confidential and
 * proprietary information owned by United HealthCare Corporation.
 * Unauthorized use and distribution are prohibited.
 ****************************************************************
 * Modification History
 * When          Who              Revision
 * Dec 13,2016  Suman Halder		 	 Initial version
 ****************************************************************/
////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

import java.util.ArrayList;

import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "hookListInfo")
public class TransactionHookListInfo extends ArrayList<TransactionHookInfo>{
    private static final long serialVersionUID = 1L;
}
