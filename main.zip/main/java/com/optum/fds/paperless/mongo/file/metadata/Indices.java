/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 4/10/17.
 */

package com.optum.fds.paperless.mongo.file.metadata;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 *
 */
public class Indices {
    @JsonProperty("IndexField")
    List<IndexField> indexField;

    public List<IndexField> getIndexField() {
        return indexField;
    }

    public void setIndexField(List<IndexField> indexField) {
        this.indexField = indexField;
    }
}
