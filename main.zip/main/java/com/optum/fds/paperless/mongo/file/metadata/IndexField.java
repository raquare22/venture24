/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 4/10/17.
 */

package com.optum.fds.paperless.mongo.file.metadata;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IndexField {

    @JsonProperty("idxName")
    String idxName;

    @JsonProperty("idxValue")
    String idxValue;

    public String getIdxName() {
        return idxName;
    }

    public void setIdxName(String idxName) {
        this.idxName = idxName;
    }

    public String getIdxValue() {
        return idxValue;
    }

    public void setIdxValue(String idxValue) {
        this.idxValue = idxValue;
    }
}
