/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/31/17.
 */

////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;

import java.io.Serializable;
import java.util.Map;

public class ProcessingMetricsCore implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long                  totalRunTime;
    private Long                  totalBytes;
    private Long                  bytesProcessed;
    private Map<Integer, Integer> errorCount;

    public Long getTotalRunTime() {
        return totalRunTime;
    }
    public void setTotalRunTime(Long totalRunTime) {
        this.totalRunTime = totalRunTime;
    }
    public Long getTotalBytes() {
        return totalBytes;
    }
    public void setTotalBytes(Long totalBytes) {
        this.totalBytes = totalBytes;
    }
    public Long getBytesProcessed() {
        return bytesProcessed;
    }
    public void setBytesProcessed(Long bytesProcessed) {
        this.bytesProcessed = bytesProcessed;
    }
    public Map<Integer, Integer> getErrorCount() {
        return errorCount;
    }
    public void setErrorCount(Map<Integer, Integer> errorCount) {
        this.errorCount = errorCount;
    }

    public void incrementErrorCodeCount(Integer errorCode){
        Integer count = errorCount.get(errorCode);
        count = (count == null) ? 0 : count;

        count++;
        errorCount.put(errorCode, count);
    }
}
