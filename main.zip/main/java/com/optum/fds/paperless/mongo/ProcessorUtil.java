/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2018.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 */
////package com.optum.fs.mongo;
package com.optum.fds.paperless.mongo;

////import com.optum.fs.mongo.executions.ProcessorExecutionRecord;
////import com.optum.fs.mongo.jobs.ProcessorCoreJob;
////import com.optum.fs.mongo.jobs.RestApiJob;
////import com.optum.fs.mongo.processors.ProcessorMetaData;
////import com.optum.fs.mongo.processors.ProcessorTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.optum.fds.paperless.mongo.executions.ProcessorExecutionRecord;
import com.optum.fds.paperless.mongo.jobs.ProcessorCoreJob;
import com.optum.fds.paperless.mongo.jobs.RestApiJob;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import com.optum.fds.paperless.mongo.processors.ProcessorTask;

import java.util.Collection;
import java.util.Date;
import java.util.Map;

public class ProcessorUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessorUtil.class);
    private static final String APP_IDENTIFIER = "appIdentifier";
    private static final String QUERY_STRING = "query {}";
    private static final String SERVER_TYPE = "serverType";

    private ProcessorUtil() {}

    public static Query getProcessorByServerTypeQuery(String id, String appIdentifier, String serverType) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where("id").is(id)
                        .and(APP_IDENTIFIER).is(appIdentifier)
        );
        addServerTypeCriteria(serverType, query);
        return query;
    }

    public static void addServerTypeCriteria(String serverType, Query query) {
      query.addCriteria(Criteria.where(SERVER_TYPE).is(serverType));
    }
    
    public static Query getProcessorById(String id) {
        Query query = new Query();
        query.addCriteria(
                Criteria.where("id").is(id)
        );
        return query;
    }

    public static <T extends ProcessorTask> void setExecutionRecordForActiviti(T processorAction, Map<String, Object> resultMap, ProcessorCoreJob job){
        LOGGER.info("ProcessorUtil-->setExecutionRecordForActiviti-->ENTER");
        ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
        processorExecutionRecord.setActivitiProcessKey((String) resultMap.get("activitiProcessKey"));
        processorExecutionRecord.setActivitiJobId((String) resultMap.get("activitiJobId"));
        processorExecutionRecord.setDateActivitiJobCreated((Date) resultMap.get("dateActivitiJobCreated"));
        processorExecutionRecord.setActivitiJobStatus((String) resultMap.get("activitiJobStatus"));
        processorExecutionRecord.setDateActivitiJobCompleted((Date) resultMap.get("dateActivitiJobCompleted"));
        processorExecutionRecord.setClientId(job.getClientId());
        processorExecutionRecord.setSpaceId(job.getSpaceId());

        processorAction.addProcessorExecutionRecord(processorExecutionRecord);
        LOGGER.info("ProcessorUtil-->setExecutionRecordForActiviti-->EXIT");
    }

    public static <T extends ProcessorTask> void setExecutionRecordForActiviti(T processorAction, Map<String, Object> resultMap, RestApiJob job){
        LOGGER.info("ProcessorUtil-->setExecutionRecordForActiviti-->ENTER");
        ProcessorExecutionRecord processorExecutionRecord = new ProcessorExecutionRecord();
        processorExecutionRecord.setActivitiProcessKey((String) resultMap.get("activitiProcessKey"));
        processorExecutionRecord.setActivitiJobId((String) resultMap.get("activitiJobId"));
        processorExecutionRecord.setDateActivitiJobCreated((Date) resultMap.get("dateActivitiJobCreated"));
        processorExecutionRecord.setActivitiJobStatus((String) resultMap.get("activitiJobStatus"));
        processorExecutionRecord.setDateActivitiJobCompleted((Date) resultMap.get("dateActivitiJobCompleted"));
        //processorExecutionRecord.setClientId(job.getClientId());
        processorExecutionRecord.setSpaceId(job.getSpaceId());

        processorAction.addProcessorExecutionRecord(processorExecutionRecord);
        LOGGER.info("ProcessorUtil-->setExecutionRecordForActiviti-->EXIT");
    }
    public static Transaction setTransactionRecord(ProcessorMetaData processor) {
        LOGGER.info("ProcessorUtil-->setTransactionRecord-->ENTER");
        Transaction transactionMetaData = new Transaction();
        transactionMetaData.setAppIdentifier(processor.getAppIdentifier());
        transactionMetaData.setClientId(processor.getClientId());
        transactionMetaData.setDateCreated(new Date());
        transactionMetaData.setDateModified(new Date());
        transactionMetaData.setSpaceId(processor.getConfigSpaceId());
        LOGGER.info("ProcessorUtil-->setTransactionRecord-->EXIT");
        return transactionMetaData;
    }
    
    public static boolean isEmpty(Collection<?> collection) {
	    return (collection == null || collection.isEmpty());
	}

}
