package com.optum.fds.paperless.mongo.processortransaction;

import java.io.Serializable;
import java.util.Map;

import com.optum.fds.paperless.mongo.processors.ProcessorTask;

public class ProcessorTransactionMetadata extends ProcessorTask implements Serializable
{
	private static final long serialVersionUID = 1L;
	private transient Map<String, Object> client;
	
	public Map<String, Object> getClient() {
		return client;
	}
	public void setClient(Map<String, Object> client) {
		this.client = client;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
