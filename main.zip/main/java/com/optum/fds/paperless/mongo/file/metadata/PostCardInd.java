package com.optum.fds.paperless.mongo.file.metadata;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PostCardInd {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PostCardInd.class);
	
	@Value("${COSMOSDoc1.postCardInd}")
	private Boolean cosmosDoc1PostCardInd;
	
	@Value("${COSMOSPRA.postCardInd}")
	private Boolean cosmosPRAPostCardInd;
	
	@Value("${COSMOSPRACDC.postCardInd}")
	private Boolean cosmosPRACDCPostCardInd;
	
	@Value("${CSPPRA.postCardInd}")
	private Boolean cspPRAPostCardInd;

	@Value("${CSPClaims.postCardInd}")
	private Boolean cspClaimsPostCardInd;
	
	@Value("${CSPPRA835.postCardInd}")
	private Boolean cspPRA835PostCardInd;
	
	@Value("${ETSAppeals.postCardInd}")
	private Boolean etsAppealsPostCardInd;
	
	@Value("${LetGen.postCardInd}")
	private Boolean letGenPostCardInd;
	
	@Value("${MRAppeals.postCardInd}")
	private Boolean mrAppealsPostCardInd;
	
	@Value("${ODAR.postCardInd}")
	private Boolean odarPostCardInd;
	
	@Value("${PriorAuth1Click.postCardInd}")
	private Boolean priorAuth1ClickPostCardInd;
	
	@Value("${PriorAuthCCSManual.postCardInd}")
	private Boolean priorAuthCCSManualPostCardInd;
	
	@Value("${PriorAuthNextGen.postCardInd}")
	private Boolean priorAuthNextGenPostCardInd;
	
	@Value("${UHCWest.postCardInd}")
	private Boolean uhcWestPostCardInd;
	
	@Value("${UNET.postCardInd}")
	private Boolean unetPostCardInd;
	
	@Value("${UNETPRA.postCardInd}")
	private Boolean unetPRAPostCardInd;

	@Value("${USPClaims.postCardInd}")
	private Boolean uspClaimsPostCardInd;
	
	@Value("${USPPRA.postCardInd}")
	private Boolean uspPRAPostCardInd;

	@Value("${NGSAppeals.postCardInd}")
	private Boolean ngsAppealsPostCardInd;

	@Value("${TXGC.postCardInd}")
	private Boolean txgcPostCardInd;

	@Value("${HouseCalls.postCardInd}")
	private Boolean houseCallsPostCardInd;

	@Value("${NGSClaims.postCardInd}")
	private Boolean ngsClaimsPostCardInd;

	@Value(("${MemberPaymentPRA.postCardInd}"))
	private Boolean memberPaymentPRAPostCardInd;
	
	Map<String, Boolean> postCardIndMap = new HashMap<String, Boolean>();
	
	public void createMap() {
		postCardIndMap.put("COSMOSDoc1", cosmosDoc1PostCardInd);
		postCardIndMap.put("COSMOSPRA", cosmosPRAPostCardInd);
		postCardIndMap.put("COSMOSPRACDC", cosmosPRACDCPostCardInd);
		postCardIndMap.put("CSPPRA", cspPRAPostCardInd);
		postCardIndMap.put("CSPClaims", cspClaimsPostCardInd);
		postCardIndMap.put("CSPPRA835", cspPRA835PostCardInd);
		postCardIndMap.put("ETSAppeals", etsAppealsPostCardInd);
		postCardIndMap.put("LetGen", letGenPostCardInd);
		
		postCardIndMap.put("MRAppeals", mrAppealsPostCardInd);
		postCardIndMap.put("ODAR", odarPostCardInd);
		postCardIndMap.put("PriorAuth1Click", priorAuth1ClickPostCardInd);
		postCardIndMap.put("PriorAuthCCSManual", priorAuthCCSManualPostCardInd);
		postCardIndMap.put("PriorAuthNextGen", priorAuthNextGenPostCardInd);
		
		postCardIndMap.put("UHCWest", uhcWestPostCardInd);
		postCardIndMap.put("UNET", unetPostCardInd);
		postCardIndMap.put("UNETPRA", unetPRAPostCardInd);
		postCardIndMap.put("USPClaims", uspClaimsPostCardInd);
		postCardIndMap.put("USPPRA", uspPRAPostCardInd);

		postCardIndMap.put("NGSAppeals", ngsAppealsPostCardInd);
		postCardIndMap.put("TXGC", txgcPostCardInd);
		postCardIndMap.put("HouseCalls", houseCallsPostCardInd);
		postCardIndMap.put("NGSClaims", ngsClaimsPostCardInd);

		postCardIndMap.put("MemberPaymentPRA", memberPaymentPRAPostCardInd);

	}
	
	public Boolean getPostCardInd(String clientName) {
		createMap();
		Boolean postCardInd = true; 
		try {
			postCardInd = postCardIndMap.get(clientName);
		}
		catch (Exception e) {
			LOGGER.error("PostCardInd --> no postCardInd found for client: {}, defaulting as true", clientName);
			return true;
		}
		return postCardInd;
	}

}
