/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/31/17.
 */

////package com.optum.fs.mongo.processors;
package com.optum.fds.paperless.mongo.processors;

public class ProcessingMetrics extends ProcessingMetricsCore {
    private Long                  averageRunTime;
    private Long                  averageFileSize;
    private Integer               fileCount;

    public Long getAverageRunTime() {
        return averageRunTime;
    }
    public void setAverageRunTime(Long averageRunTime) {
        this.averageRunTime = averageRunTime;
    }
    public Long getAverageFileSize() {
        return averageFileSize;
    }
    public void setAverageFileSize(Long averageFileSize) {
        this.averageFileSize = averageFileSize;
    }
    public Integer getFileCount() {
        return fileCount;
    }
    public void setFileCount(Integer fileCount) {
        this.fileCount = fileCount;
    }

}
