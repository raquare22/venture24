package com.optum.fds.paperless.mongo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class ItemListTXGC extends MetaData {

    private static final long serialVersionUID = 1L;
    
    BatchInfoTXGC batchInfo;
    
    List<CodesTXGC> codes;
    
    @JsonProperty("TXGCID")
    String TXGCID;
    @JsonProperty("CLLibraryNme")
    String CLLibraryNme;
    @JsonProperty("GroupName")
    String GroupName;
    @JsonProperty("TemplateName")
    String TemplateName;
    @JsonProperty("ProvFirstName")
    String ProvFirstName;

    @JsonProperty("ProvLastName")
    String ProvLastName;

    @JsonProperty("ProvFullName")
    String ProvFullName;
    @JsonProperty("ProvAddr1")
    String ProvAddr1;

    @JsonProperty("ProvAddr2")
    String ProvAddr2;

    @JsonProperty("ProvCity")
    String ProvCity;
    @JsonProperty("ProvSt")
    String ProvSt;

    @JsonProperty("ProvZip")
    String ProvZip;

    @JsonProperty("ProvProvinceRegion")
    String ProvProvinceRegion;
    @JsonProperty("ProvCountry")
    String ProvCountry;


    @JsonProperty("Count")
    int Count;

    @JsonProperty("tin")
    String tin;

	@JsonProperty("npi")
    String npi;

    @JsonProperty("exemptionEffectiveStartDate")
    String exemptionEffectiveStartDate;
    @JsonProperty("exemptionEffectiveEndDate")
    String exemptionEffectiveEndDate;

    @JsonProperty("cycleStartDate")
    String cycleStartDate;

    @JsonProperty("cycleEndDate")
    String cycleEndDate;
    
    @JsonProperty("providerType")
    String providerType;
    
    

    public String getProviderType() {
		return providerType;
	}

	public void setProviderType(String providerType) {
		if (providerType != null && providerType.equals("P")) {
			this.providerType = "Provider";
		} else if (providerType != null && providerType.equals("O")) {
			this.providerType = "Facility";
		} else {
			this.providerType = "";
		}
		
	}

	public BatchInfoTXGC getBatchInfo() {
		return batchInfo;
	}

	public void setBatchInfo(BatchInfoTXGC batchInfo) {
		this.batchInfo = batchInfo;
	}

	public List<CodesTXGC> getCodes() {
		return codes;
	}

	public void setCodes(List<CodesTXGC> codes) {
		this.codes = codes;
	}

	public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }


    public String getCount() {
        return String.format("%03d", Count);
    }

    public void setCount(int count) {
        Count = count;
    }

    public String getTXGCID() {
        return TXGCID;
    }

    public void setTXGCID(String TXGCID) {
        this.TXGCID = TXGCID;
    }

    public String getCLLibraryNme() {
        return CLLibraryNme;
    }

    public void setCLLibraryNme(String CLLibraryNme) {
        this.CLLibraryNme = CLLibraryNme;
    }

    public String getGroupName() {
        return GroupName;
    }

    public void setGroupName(String groupName) {
        GroupName = groupName;
    }

    public String getTemplateName() {
        return TemplateName;
    }

    public void setTemplateName(String templateName) {
        TemplateName = templateName;
    }

    public String getProvFirstName() {
        return ProvFirstName;
    }

    public void setProvFirstName(String provFirstName) {
        ProvFirstName = provFirstName;
    }

    public String getProvFullName() {
        return ProvFullName;
    }
    public void setProvFullName(String provFullName) {
        ProvFullName = provFullName;
    }

    public String getProvLastName() {
        return ProvLastName;
    }

    public void setProvLastName(String provLastName) {
        ProvLastName = provLastName;
    }

    public String getProvAddr1() {
        return ProvAddr1;
    }

    public void setProvAddr1(String provAddr1) {
        ProvAddr1 = provAddr1;
    }

    public String getProvAddr2() {
        return ProvAddr2;
    }

    public void setProvAddr2(String provAddr2) {
        ProvAddr2 = provAddr2;
    }

    public String getProvCity() {
        return ProvCity;
    }

    public void setProvCity(String provCity) {
        ProvCity = provCity;
    }

    public String getProvSt() {
        return ProvSt;
    }

    public void setProvSt(String provSt) {
        ProvSt = provSt;
    }

    public String getProvZip() {
        return ProvZip;
    }

    public void setProvZip(String provZip) {
        ProvZip = provZip;
    }

    public String getProvProvinceRegion() {
        return ProvProvinceRegion;
    }

    public void setProvProvinceRegion(String provProvinceRegion) {
        ProvProvinceRegion = provProvinceRegion;
    }

    public String getProvCountry() {
        return ProvCountry;
    }

    public void setProvCountry(String provCountry) {
        ProvCountry = provCountry;
    }

	public String getNpi() {
		return npi;
	}

	public void setNpi(String npi) {
		this.npi = npi;
	}

	public String getExemptionEffectiveStartDate() {
		return exemptionEffectiveStartDate;
	}

	public void setExemptionEffectiveStartDate(String exemptionEffectiveStartDate) {
		this.exemptionEffectiveStartDate = exemptionEffectiveStartDate;
	}

	public String getExemptionEffectiveEndDate() {
		return exemptionEffectiveEndDate;
	}

	public void setExemptionEffectiveEndDate(String exemptionEffectiveEndDate) {
		this.exemptionEffectiveEndDate = exemptionEffectiveEndDate;
	}

	public String getCycleStartDate() {
		return cycleStartDate;
	}

	public void setCycleStartDate(String cycleStartDate) {
		this.cycleStartDate = cycleStartDate;
	}

	public String getCycleEndDate() {
		return cycleEndDate;
	}

	public void setCycleEndDate(String cycleEndDate) {
		this.cycleEndDate = cycleEndDate;
	}

    

}
