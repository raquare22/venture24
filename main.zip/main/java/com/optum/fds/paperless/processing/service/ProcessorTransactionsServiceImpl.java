package com.optum.fds.paperless.processing.service;

import com.optum.fds.paperless.domain.service.ProcessorTransactionService;
import com.optum.fds.paperless.domain.service.TransactionService;
import com.optum.fds.paperless.exception.InvalidExpressionException;

import com.optum.fds.paperless.mongo.processors.MetaDataStatus;
import com.optum.fds.paperless.mongo.processors.ProcessorRecordTypes;
import com.optum.fds.paperless.mongo.processors.ProcessorTransaction;
import com.optum.fds.paperless.mongo.processortransaction.ProcessorTransactionMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("processorTransactionsService")
public class ProcessorTransactionsServiceImpl implements ProcessorTransactionsService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessorTransactionsServiceImpl.class);
	private static final String SERVER_TYPE = "SERVER_TYPE";
	private static final String VERSION = "1";

	@Autowired
	ProcessorTransactionService processorTransactionService;
	
	@Autowired
	TransactionService transactionService;



	// Constructor
	public ProcessorTransactionsServiceImpl() {
		// Required constructor
	}

	@Override
	public ProcessorTransactionMetadata createProcessorTransactionMetadata(Map<String, Object> client,
			String processorId, Integer configSpaceId, String fileName) {
		var processorTransactionMetadata=new ProcessorTransactionMetadata();
		processorTransactionMetadata.setClient(client);
		processorTransactionMetadata.setProcessorId(processorId);
		processorTransactionMetadata.setConfigSpaceId(configSpaceId);
		processorTransactionMetadata.setFileName(fileName);
		processorTransactionMetadata.setStatus(MetaDataStatus.ACTIVE);
		processorTransactionMetadata.setVersion(VERSION);
		processorTransactionMetadata.setProcessorRecordType(ProcessorRecordTypes.processorTransactionMetadata);
		return processorTransactionService.saveProcessorTransactionMetaData(processorTransactionMetadata);
	}

	@Override
	public Map<String, Object> createProcessorTransactionMetadataClientHashmap(boolean sendCompanionFileMissingEmail,
			boolean sendCompanionFileUnreadableEmail, String sampleZipFileName, Date companionFileDateReceived) {
		Map<String,Object> map=new HashMap<>();
		map.put("sendCompanionFileMissingEmail", sendCompanionFileMissingEmail);
		map.put("sendCompanionFileUnreadableEmail", sendCompanionFileUnreadableEmail);
		map.put("sampleZipFileName", sampleZipFileName);
		map.put("companionFileDateReceived", companionFileDateReceived);
		return map;
	}

	@Override
	public ProcessorTransactionMetadata updateProcessorTransactionMetadata(
			ProcessorTransactionMetadata processorTransactionMetadata) {
		LOGGER.debug("processorsTransactionsService-->updateProcessorTransactionMetadata-->ENTER");
		return processorTransactionService.updateProcessorTransactionMetaData(processorTransactionMetadata);
	}

	@Override
	public ProcessorTransactionMetadata getProcessorTransactionMetadataWithFileName(String fileName) {
		LOGGER.debug("processorsTransactionsService-->getProcessorTransactionMetadataWithFileName-->ENTER");
		var processorTransactionMetadata = processorTransactionService.findProcessorTransactionMetadataByClientCompanionFileName(fileName, SERVER_TYPE);
		LOGGER.debug("csvProcessorsService-->getCsvProcessorTransactionWithFileName-->EXIT");
		return processorTransactionMetadata;
	}
	
	@Override
    public List<ProcessorTransactionMetadata> getProcessorTransactionMetaData(String searchCriteriaJson,Criteria filter) throws InvalidExpressionException
    {
		LOGGER.debug("processorsTransactionsService-->getProcessorTransactionMetaData-->ENTER");
		List<ProcessorTransactionMetadata> processorTransactionList  = processorTransactionService.getProcessorTransactionMetaData(searchCriteriaJson, filter);
		LOGGER.debug("csvProcessorsService-->getProcessorTransactionMetaData-->EXIT");
		return processorTransactionList;	
    }

	
	@Override
    public ProcessorTransaction findProcessorTransactionByFileName(String zipFileName, Integer configSpaceId)
    {
		LOGGER.debug("processorsTransactionsService-->getProcessorTransaction-->ENTER");
		var processorTransaction  = processorTransactionService.findProcessorTransactionByFileName(zipFileName, configSpaceId);
		LOGGER.debug("csvProcessorsService-->getProcessorTransaction-->EXIT");
		return processorTransaction;	
    }

}
