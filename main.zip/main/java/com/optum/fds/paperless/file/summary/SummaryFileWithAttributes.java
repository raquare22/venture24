/*
 * ***************************************************************
 *  Copyright (c) Optum, Inc 2017.
 *  This software and documentation contain confidential and
 *  proprietary information owned by Optum, Inc.
 *  Unauthorized use and distribution are prohibited.
 * **************************************************************
 *
 * Created by Eleazar Castellanos on 3/31/17.
 */

package com.optum.fds.paperless.file.summary;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;

public class SummaryFileWithAttributes implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonProperty("BatchID")
    String batchId;
    @JsonProperty("Datagroup")
    String dataGroup;
    @JsonProperty("Count")
    String count;
  //  @JsonProperty("Files")
  //  SummaryFiles files;
    
    @JsonProperty("FileName")
    transient List<Files> fileList;
     
     static class Files  {
     	
     	@JacksonXmlProperty(isAttribute = true,localName="Status")
     	String status;
     	@JacksonXmlText
     	String value;
     }


     public List<String> getFileListAsStringNames() {
     	ArrayList<String> fileListAsString = new ArrayList<>();
     	if(!CollectionUtils.isEmpty(fileList)) {
     		for(int i=0;i<fileList.size();i++) 
     			fileListAsString.add(fileList.get(i).value);
     	}
     	return fileListAsString;
     }
    
    public List<Files> getFileList() {
        return fileList;
    }
    public void setFileList(List<Files> fileList) {
        this.fileList = fileList;
}

    public String getBatchId() {
        return batchId;
    }
    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }
    public String getDataGroup() {
        return dataGroup;
    }
    public void setDataGroup(String dataGroup) {
        this.dataGroup = dataGroup;
    }
    public String getCount() {
        return count;
    }
    public void setCount(String count) {
        this.count = count;
    }
/*    public SummaryFiles getFiles() {
        return files;
    }
    public void setFiles(SummaryFiles files) {
        this.files = files;
    }*/
}
