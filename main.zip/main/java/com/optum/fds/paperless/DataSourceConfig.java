package com.optum.fds.paperless;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.optum.fds.paperless.domain.service.ServiceBase;
import com.optum.fds.paperless.util.DocumentUtil;
import com.optum.fds.paperless.util.Utility;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@Configuration
public class DataSourceConfig {

    @ConfigurationProperties(prefix = "app.datasource")
    @Bean
    public HikariDataSource getDataSource() {
        return DataSourceBuilder.create().type(HikariDataSource.class).build();
    }

        @Bean
    public HttpHeaders httpHeaders() {
        return new HttpHeaders();
    }

    @Bean
    public ServiceBase serviceBase() {
        return new ServiceBase();
    }

    @Bean
    public JavaMailSender javaMailSender() {
        return new JavaMailSenderImpl();
    }
    
    @Bean
    public ConfigData getConfigData() {
    	return new ConfigData();
    }
    
    @Bean
    public FDSHelper fdsHelper() { 
    	return new FDSHelper();
    }
    
    @Bean
    public DocumentUtil documentUtil() { 
    	return new DocumentUtil();
    }

    @Bean
    public ObjectMapper objectMapper() {
    	 ObjectMapper mapper = new ObjectMapper();
    	 mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    	 mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    	 
        return mapper;
    }
    
}