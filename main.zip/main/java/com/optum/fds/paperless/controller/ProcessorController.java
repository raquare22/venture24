package com.optum.fds.paperless.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.ProcessorService;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.mongo.processors.ProcessorMetaData;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Component
@RestController
@RequestMapping("/api")
public class ProcessorController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessorController.class);

    private static final String INVALID_REQUEST = "Invalid request";
    private static final String EMPTY_REQUEST_BODY = "Null or empty request body";
    private static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
    private static final String NO_PROCESSOR_FOUND = "No processor found for this ProcessorId";

    private ObjectMapper mapper = new ObjectMapper();

    @Autowired
    private ProcessorService processorService;

    @PostMapping(value = "/processor", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> postProcessor(@RequestBody String jsonStr) {

        LOGGER.info("Entering post processor jsonStr={}", Encode.forJava(jsonStr));

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<GenericResponse>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }

        try {
            var processorMetaData = mapper.readValue(jsonStr, ProcessorMetaData.class);
            var insertedProcessor = processorService.saveProcessorMetaData(processorMetaData);
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), insertedProcessor));
        }
        catch (Exception ex) {
            LOGGER.error("Error to process workflow:Processor, HTTPStatus={}, apiPath=/processor, method=POST, jsonstr={} error={}", 
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<GenericResponse>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping(value = "/processor", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> updateProcessor(@RequestBody String jsonStr) {

        LOGGER.info("Entering update processor jsonStr={}", Encode.forJava(jsonStr));

        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<GenericResponse>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }

        try {
            var processorMetaData = mapper.readValue(jsonStr, ProcessorMetaData.class);
            Map<String, Object> requestMap = new ObjectMapper().readValue(jsonStr, HashMap.class);

            if (processorMetaData.getId() == null || processorMetaData.getId().isEmpty()) {
                return new ResponseEntity<GenericResponse>(
                        GenericResponse.from("400", INVALID_REQUEST, "Null or empty processor id"),
                        HttpStatus.BAD_REQUEST);
            }

            processorService.updateProcessor(processorMetaData, requestMap);
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), "Updated successfully"));
        } catch (Exception e) {
            LOGGER.error("Error to process workflow:Processor, HTTPStatus={}, apiPath=/processor, method=PUT, jsonstr={} error={}", 
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(e));
            return new ResponseEntity<GenericResponse>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/processor/{id}")
    public ResponseEntity<GenericResponse> getProcessorById(@PathVariable String id) {

        if (StringUtils.isEmpty(id)) {
            return new ResponseEntity<GenericResponse>(GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }

        ProcessorMetaData processorMetaData = null;

        try {
            processorMetaData = processorService.getProcessorById(id);
            if (processorMetaData != null) {
                return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), processorMetaData));
            } else {
                return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), NO_PROCESSOR_FOUND));
            }
        } catch (Exception e) {
            LOGGER.error("Error to process workflow:Processor, HTTPStatus={}, apiPath=/processor/{}, method=GET, error={}", 
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(id), ExceptionUtils.getStackTrace(e));           
        	return new ResponseEntity<GenericResponse>(GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping(value = "/processor/delete/{id}")
    public ResponseEntity<GenericResponse> deleteProcessor(@PathVariable String id) {

        if (StringUtils.isEmpty(id)) {
            return new ResponseEntity<GenericResponse>(GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }

        ProcessorMetaData processorMetaData = null;

        try {
            processorMetaData = processorService.deleteProcessor(id);
            if (processorMetaData != null) {
                return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), processorMetaData));
            } else {
                return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), NO_PROCESSOR_FOUND));
            }
        } catch (Exception e) {
            LOGGER.error("Error to process workflow:Processor, HTTPStatus={}, apiPath=/processor/delete/{}, method=DELETE, error={}", 
            		HttpStatus.INTERNAL_SERVER_ERROR, Encode.forJava(id), ExceptionUtils.getStackTrace(e));
            return new ResponseEntity<>(GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}