package com.optum.fds.paperless.controller;

import java.io.Serializable;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentRecord implements Serializable {


	private static final long serialVersionUID = -5857780910978544828L;

	@JsonProperty("documents")
	private String documents;

	public String getDocuments() {
		return documents;
	}

	@Override
	public String toString() {
		return documents;
	}
}
