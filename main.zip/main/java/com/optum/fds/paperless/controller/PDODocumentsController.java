package com.optum.fds.paperless.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.fds.paperless.domain.service.DocumentMetaDataService;
import com.optum.fds.paperless.model.GenericResponse;
import com.optum.fds.paperless.model.MultiPostResponse;
import com.optum.fds.paperless.mongo.DocumentMetaData;
import com.optum.fds.paperless.util.DocumentUtil;

@Component
@RestController
@RequestMapping("/api")
public class PDODocumentsController {

	@Autowired 
	private DocumentUtil documentUtil;
	
    private static final Logger LOGGER = LoggerFactory.getLogger(PDODocumentsController.class);

    private static final String INVALID_REQUEST = "Invalid request";
    private static final String EMPTY_REQUEST_BODY = "Null or empty request body";
    private static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";

    private ObjectMapper mapper = new ObjectMapper();

    @Autowired
    private DocumentMetaDataService documentMetaDataService;


    @PostMapping(value = "/documents", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> postPDODocument(@RequestBody String jsonStr) {
        LOGGER.info("Entering postPDODocument jsonStr={}", Encode.forJava(jsonStr));
        if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<GenericResponse>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
        try {
            var documentMetaData = mapper.readValue(jsonStr, DocumentMetaData.class);
            documentUtil.appendDefaultValues(documentMetaData);
            var insertedDocument = documentMetaDataService.savePDODocumentMetaData(documentMetaData);
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), insertedDocument));
        }
        catch (Exception ex) {
            LOGGER.error("Error posting PDO document for jsonStr {} and error {}", Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(ex));
            return new ResponseEntity<GenericResponse>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, ex.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping(value = "/documents", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> updatePDODocument(@RequestBody String jsonStr) {
    	
    	LOGGER.info("Entering updatePDODocument jsonStr={}", Encode.forJava(jsonStr));
    	
    	if (StringUtils.isEmpty(jsonStr)) {
            return new ResponseEntity<GenericResponse>(
                    GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY),
                    HttpStatus.BAD_REQUEST);
        }
    	
    	try {
    		var documentMetaData = mapper.readValue(jsonStr, DocumentMetaData.class);
    		
    		if (documentMetaData.getId() == null || documentMetaData.getId().isEmpty()) {
    			return new ResponseEntity<GenericResponse>(
                        GenericResponse.from("400", INVALID_REQUEST, "Null or empty document id"),
                        HttpStatus.BAD_REQUEST);
    		}
    		var updatedDocument = documentMetaDataService.updatePDODocumentMetaData(documentMetaData, documentMetaData.getId());
    		if (updatedDocument == null) {
    			throw new NullPointerException("No document found with id: " + documentMetaData.getId());
    		}
            return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), updatedDocument));
    		
    	} catch (Exception e) {
    		LOGGER.error("Error updating PDO document for jsonStr {} and error {}", Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(e));
            return new ResponseEntity<GenericResponse>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    }
    
    @PostMapping(value = "/documents/multi", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> postMultiPDODocument(@RequestBody String jsonStr) {
    	if (StringUtils.isEmpty(jsonStr)) {
    		return new ResponseEntity<GenericResponse>(GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY), HttpStatus.BAD_REQUEST);
    	}
    	
    	try {
    		var documentMetaDataList = Arrays.asList(mapper.readValue(jsonStr, DocumentMetaData[].class));
    		var insertedDocList = documentMetaDataService.insertMultiPDODocuments(documentMetaDataList);
    		
    		List<String> docIds = new ArrayList<String>();
    		insertedDocList.forEach(doc -> docIds.add(doc.getId()));
    		
    		MultiPostResponse response = new MultiPostResponse(docIds);
    		
    		return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), response));
    		
    	} catch (Exception e) {
    		LOGGER.error("Error posting multi PDO documents for payload {} and error {}", Encode.forJava(jsonStr), ExceptionUtils.getStackTrace(e));
    		return new ResponseEntity<GenericResponse>(
                    GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    }


    @PutMapping(value = "/documents/multi", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<GenericResponse> putMultiPDODocument(@RequestBody Map<String, Object> requestMap) {
    	
    	if (MapUtils.isEmpty(requestMap)) {
    		return new ResponseEntity<GenericResponse>(GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY), HttpStatus.BAD_REQUEST);
    	}
    	
    	try {
    		List<String> documentIds = (List<String>) requestMap.get("documentIds");
    		DocumentMetaData document = mapper.convertValue(requestMap.get("document"), DocumentMetaData.class);
    		var response = documentMetaDataService.updateMultiPDODocuments(documentIds, document);
    		return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), response));
    	} catch (Exception e) {
    		LOGGER.error("Error updating multi PDO documents error {}", ExceptionUtils.getStackTrace(e));
    		return new ResponseEntity<GenericResponse>(GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    }
    
    @GetMapping(value = "/documents/{id}")
    public ResponseEntity<GenericResponse> getPDODocumentById(@PathVariable String id) {
    	DocumentMetaData document = null;
    	try {
    		document = documentMetaDataService.getPDODocumentById(id);
    		return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), document));
    	} catch (Exception e) {
    		return new ResponseEntity<GenericResponse>(GenericResponse.from("500", INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	
    }

    @GetMapping(value = "/documents")
    public ResponseEntity<GenericResponse> getPDODocuments(@RequestParam Map<String, String> queryParams) {
    	if (MapUtils.isEmpty(queryParams)) {
    		return new ResponseEntity<GenericResponse>(GenericResponse.from("400", INVALID_REQUEST, EMPTY_REQUEST_BODY), HttpStatus.BAD_REQUEST);
    	}
    	
    	List<DocumentMetaData> documents = null;
    	
    	try {
    		documents = documentMetaDataService.getPDODocuments(queryParams);
    		return ResponseEntity.ok(GenericResponse.from("200", HttpStatus.OK.getReasonPhrase(), documents));
    	} catch (Exception e) {
    		LOGGER.error("Error finding PDO documents with error={}", ExceptionUtils.getStackTrace(e));
    		return new ResponseEntity<GenericResponse>(GenericResponse.from("500", INTERNAL_SERVER_ERROR, documents), HttpStatus.INTERNAL_SERVER_ERROR);
    	}

    }

}
