//package com.optum.providerpreferences.autoenrollment;
//
//import java.io.IOException;
//
//import java.util.Date;
//import java.util.Properties;
//
//import javax.mail.Message;
//import javax.mail.MessagingException;
//import javax.mail.Multipart;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMessage;
//import javax.mail.internet.MimeMultipart;
//
//import org.apache.commons.lang3.exception.ExceptionUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//public final class EmailUtils {
//
//	/**
//	 * Utility method to send simple HTML email
//	 *
//	 * @param session
//	 * @param toEmail
//	 * @param subject
//	 * @param body
//	 */
//
//	private static final String PRUN_EMAIL_HOST = "emailHost";
//	private static final String PRUN_EMAIL_FROM = "sender";
//	private static final String PRUN_EMAIL_TO = "recepient";
//	private static final String PRUN_EMAIL_SUBJECT = "emailSubject";
//	private static final String PRUN_EMAIL_MSG = "emailMsg";
//
//	private static final String prunEmailFrom="PRUN_EMAIL_FROM";
//	private static final String prunEmailMessage="PRUN_EMAIL_MSG";
//	private static final String prunEmailHost="PRUN_EMAIL_HOST";
//	private static final String prunEmailTo="PRUN_EMAIL_TO";
//	private static final String prunEmailSubject="PRUN_EMAIL_SUBJECT";
//
//	private static final String mailSmtpHost = "mail.smtp.host";
//	private static final String sendEmailSuccess = "sendEmail: Email Sent Successfully";
//	private static final String sendEmailMessage = "sendEmail: Message is ready";
//	private static final String textHTML = "text/html";
//	private static final String dateTimeFormat = "[dateTime]";
//	private static final String emailFile = "sendEmail One File  {}={},{}={}, {}={}, {}={}, {}={} {}";
//	private static final String prunEmailToPODM = "PRUN_EMAIL_TO_PODM";
//
//	private static final String PRUN_EMAIL_TO_PODM = "recepientPODM";
//	private static final String PRUN_EMAIL_SUBJECT_PODM = "emailSubjectPODM";
//	private static final String PRUN_EMAIL_MSG_PODM = "emailMsgPODM";
//
//
//	// sendEmail env variables:
//	// PRUN_EMAIL_SUBJECT=PDO Autoenrollment Automation - TIN List - [dateTime]
//	// PRUN_EMAIL_MSG=Hello!<br><br>Attached is the list of unique TINs for <mark>[dateTime]</mark>. If there are any issues, please reply all to the PDO_AutoEnroll DL.<br><br>Regards,<br>PDO Team
///*
// * PRUN_EMAIL_FROM=pdo_autoenrollment@uhc.com
//PRUN_EMAIL_HOST=mailo2.uhc.com
//PRUN_EMAIL_MSG=Hello!<br><br>You have new <mark>AutoEnrollment Files</mark> . Please find in attachment.<br><br>Regards,<br>PDO Team
//PRUN_EMAIL_MSG_PODM=Hello!<br><br>You have new <mark>OptOut Tin : [Tin] </mark><br><br>Regards,<br>PDO Team
//PRUN_EMAIL_SUBJECT=Testing Pdo AutoEnrollment
//PRUN_EMAIL_SUBJECT_PODM=Testing Pdo AutoEnrollment for PODM : [Tin] and date is [dateTime]
//PRUN_EMAIL_TO=ankur_kumar90@optum.com,lauren.ngai@optum.com
//PRUN_EMAIL_TO_PODM=ankur_kumar90@optum.com
// */
//	private static final Logger LOGGER = LoggerFactory.getLogger(EmailUtils.class);
//
//	private EmailUtils() {
//	}
//
//	public static void sendEmailMultiAttachments(String sender, String recepient, String emailSubject, String emailMsg,
//			String[] attachFiles) throws MessagingException {
//		try {
//
//			final Properties props = System.getProperties();
//			Session session;
//			props.put(mailSmtpHost, System.getenv(prunEmailHost));
//			session = Session.getInstance(props, null);
//			Message msg = new MimeMessage(session);
//			msg.setFrom(new InternetAddress(sender));
//			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recepient, false));
//			msg.setSubject(emailSubject);
//			msg.setSentDate(new Date());
//
//			MimeBodyPart messageBodyPart = new MimeBodyPart();
//			messageBodyPart.setContent(emailMsg, textHTML);
//
//			Multipart multipart = new MimeMultipart();
//			multipart.addBodyPart(messageBodyPart);
//
//			if (attachFiles != null && attachFiles.length > 0) {
//				for (String filePath : attachFiles) {
//					MimeBodyPart attachPart = new MimeBodyPart();
//
//					try {
//						attachPart.attachFile(filePath);
//					} catch (IOException ex) {
//						LOGGER.error("sendEmailMultiAttachments   {}={},{}={}, {}={}, {}={}, {}={} {}", PRUN_EMAIL_HOST,
//								System.getenv(prunEmailHost), PRUN_EMAIL_FROM, System.getenv(prunEmailFrom),
//								PRUN_EMAIL_TO, System.getenv(prunEmailTo), PRUN_EMAIL_SUBJECT,
//								System.getenv(prunEmailSubject), PRUN_EMAIL_MSG, System.getenv(prunEmailMessage),
//								ExceptionUtils.getStackTrace(ex));
//					}
//
//					multipart.addBodyPart(attachPart);
//				}
//			}
//
//			msg.setContent(multipart);
//			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recepient, false));
//			LOGGER.info(sendEmailMessage);
//			Transport.send(msg);
//			LOGGER.info(sendEmailSuccess);
//		} catch (Exception e) {
//			LOGGER.error("sendEmailMultiAttachments  {}={},{}={}, {}={}, {}={}, {}={} {}", PRUN_EMAIL_HOST,
//					System.getenv(prunEmailHost), PRUN_EMAIL_FROM, System.getenv(prunEmailFrom), PRUN_EMAIL_TO,
//					System.getenv(prunEmailTo), PRUN_EMAIL_SUBJECT, System.getenv(prunEmailSubject),
//					PRUN_EMAIL_MSG, System.getenv(prunEmailMessage), ExceptionUtils.getStackTrace(e));
//			throw(e);
//		}
//	}
//
//
//	public static void sendEmailSingleAttachment(String sender, String recepient, String emailSubject, String emailMsg,
//			String fileLocation) throws MessagingException {
//		try {
//
//			final Properties props = System.getProperties();
//			Session session;
//			props.put(mailSmtpHost, System.getenv(prunEmailHost));
//			session = Session.getInstance(props, null);
//			Message msg = new MimeMessage(session);
//			msg.setFrom(new InternetAddress(sender));
//			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recepient, false));
//			msg.setSubject(emailSubject);
//			msg.setSentDate(new Date());
//			MimeBodyPart messageBodyPart = new MimeBodyPart();
//			messageBodyPart.setContent(emailMsg, textHTML);
//
//			Multipart multipart = new MimeMultipart();
//			multipart.addBodyPart(messageBodyPart);
//			if (fileLocation != null) {
//				MimeBodyPart attachPart = new MimeBodyPart();
//
//				try {
//					attachPart.attachFile(fileLocation);
//				} catch (IOException ex) {
//					LOGGER.error("sendEmailSingleAttachment   {}={},{}={}, {}={}, {}={}, {}={} {}", PRUN_EMAIL_HOST,
//							System.getenv(prunEmailHost), PRUN_EMAIL_FROM, System.getenv(prunEmailFrom),
//							PRUN_EMAIL_TO, System.getenv(prunEmailTo), PRUN_EMAIL_SUBJECT,
//							System.getenv(prunEmailSubject), PRUN_EMAIL_MSG, System.getenv(prunEmailMessage),
//							ExceptionUtils.getStackTrace(ex));
//				}
//
//				multipart.addBodyPart(attachPart);
//			}
//			msg.setContent(multipart);
//			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recepient, false));
//			LOGGER.info(sendEmailMessage);
//			Transport.send(msg);
//			LOGGER.info(sendEmailSuccess);
//		} catch (Exception e) {
//			LOGGER.error("sendEmailSingleAttachment  {}={},{}={}, {}={}, {}={}, {}={} {}", PRUN_EMAIL_HOST,
//					System.getenv(prunEmailHost), PRUN_EMAIL_FROM, System.getenv(prunEmailFrom), PRUN_EMAIL_TO,
//					System.getenv(prunEmailTo), PRUN_EMAIL_SUBJECT, System.getenv(prunEmailSubject),
//					PRUN_EMAIL_MSG, System.getenv(prunEmailMessage), ExceptionUtils.getStackTrace(e));
//		}
//	}
//
//	public static void sendEmail(String[] attachFiles) {
//		try {
//
//			final Properties props = System.getProperties();
//			Session session;
//			props.put(mailSmtpHost, System.getenv(prunEmailHost));
//			session = Session.getInstance(props, null);
//			Message msg = new MimeMessage(session);
//			msg.setFrom(new InternetAddress(System.getenv(prunEmailFrom)));
//			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(System.getenv(prunEmailTo), false));
//			msg.setSubject(System.getenv(prunEmailSubject));
//			msg.setSentDate(new Date());
//
//			MimeBodyPart messageBodyPart = new MimeBodyPart();
//			messageBodyPart.setContent(System.getenv(prunEmailMessage), textHTML);
//			Multipart multipart = new MimeMultipart();
//			multipart.addBodyPart(messageBodyPart);
//
//			if (attachFiles != null && attachFiles.length > 0) {
//				for (String filePath : attachFiles) {
//					MimeBodyPart attachPart = new MimeBodyPart();
//
//					try {
//						attachPart.attachFile(filePath);
//					} catch (IOException ex) {
//						LOGGER.error("sendEmail Multiple Files {}={},{}={}, {}={}, {}={}, {}={} {}", PRUN_EMAIL_HOST,
//								System.getenv(prunEmailHost), PRUN_EMAIL_FROM, System.getenv(prunEmailFrom),
//								PRUN_EMAIL_TO, System.getenv(prunEmailTo), PRUN_EMAIL_SUBJECT,
//								System.getenv(prunEmailSubject), PRUN_EMAIL_MSG, System.getenv(prunEmailMessage),
//								ExceptionUtils.getStackTrace(ex));
//					}
//
//					multipart.addBodyPart(attachPart);
//				}
//			}
//			msg.setContent(multipart);
//			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(System.getenv(prunEmailTo), false));
//			LOGGER.info(sendEmailMessage);
//			Transport.send(msg);
//			LOGGER.info(sendEmailSuccess);
//
//		} catch (Exception e) {
//			LOGGER.error("sendEmail Multiple Files  {}={},{}={}, {}={}, {}={}, {}={} {}", PRUN_EMAIL_HOST,
//					System.getenv(prunEmailHost), PRUN_EMAIL_FROM, System.getenv(prunEmailFrom), PRUN_EMAIL_TO,
//					System.getenv(prunEmailTo), PRUN_EMAIL_SUBJECT, System.getenv(prunEmailSubject),
//					PRUN_EMAIL_MSG, System.getenv(prunEmailMessage), ExceptionUtils.getStackTrace(e));
//		}
//	}
//
//	public static void sendEmail(String fileLocation, String dateTime) throws MessagingException {
//		try {
//
//			final Properties props = System.getProperties();
//			Session session;
//			props.put(mailSmtpHost, System.getenv(prunEmailHost));
//			session = Session.getInstance(props, null);
//
//			Message msg = new MimeMessage(session);
//			msg.setFrom(new InternetAddress(System.getenv(prunEmailFrom)));
//			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(System.getenv(prunEmailTo), false));
//			msg.setSubject(System.getenv(prunEmailSubject).replace(dateTimeFormat, dateTime));
//			msg.setSentDate(new Date());
//
//			MimeBodyPart messageBodyPart = new MimeBodyPart();
//			messageBodyPart.setContent(System.getenv(prunEmailMessage).replace(dateTimeFormat, dateTime), textHTML);
//			Multipart multipart = new MimeMultipart();
//			multipart.addBodyPart(messageBodyPart);
//
//			if (fileLocation != null) {
//				MimeBodyPart attachPart = new MimeBodyPart();
//
//				try {
//					attachPart.attachFile(fileLocation);
//				} catch (IOException ex) {
//					LOGGER.error("sendEmail One File {}={},{}={}, {}={}, {}={}, {}={} {}", PRUN_EMAIL_HOST,
//							System.getenv(prunEmailHost), PRUN_EMAIL_FROM, System.getenv(prunEmailFrom),
//							PRUN_EMAIL_TO, System.getenv(prunEmailTo), PRUN_EMAIL_SUBJECT,
//							System.getenv(prunEmailSubject), PRUN_EMAIL_MSG, System.getenv(prunEmailMessage),
//							ExceptionUtils.getStackTrace(ex));
//				}
//
//				multipart.addBodyPart(attachPart);
//			}
//			msg.setContent(multipart);
//			LOGGER.info(sendEmailMessage);
//			Transport.send(msg);
//			LOGGER.info(sendEmailSuccess);
//		} catch (Exception e) {
//			LOGGER.error(emailFile, PRUN_EMAIL_HOST,
//					System.getenv(prunEmailHost), PRUN_EMAIL_FROM, System.getenv(prunEmailFrom), PRUN_EMAIL_TO,
//					System.getenv(prunEmailTo), PRUN_EMAIL_SUBJECT, System.getenv(prunEmailSubject),
//					PRUN_EMAIL_MSG, System.getenv(prunEmailMessage), ExceptionUtils.getStackTrace(e));
//		}
//	}
//
//	// sendEmailWithoutAttachment env variables:
//		// PRUN_EMAIL_SUBJECT_PODM=PDO Autoenrollment Automation - TIN List - [dateTime]
//		// PRUN_EMAIL_MSG_PODM=Hello!<br><br>Attached is the list of unique TINs for <mark>[dateTime]</mark>. If there are any issues, please reply all to the PDO_AutoEnroll DL.<br><br>Regards,<br>PDO Team
//
//
//	// PRUN_OPTOUT_EXPIRE_EMAIL_MSG=Hello!<br><br>Please remove <mark>TINS : [Tin]</mark> from PODM rules, the TINS have expired from the Opt Out process.<br><br>Regards,<br>PDO Team
//	// PRUN_OPTOUT_EXPIRE_EMAIL_SUBJECT=[dateTime] - PDO-PODM Opt Out Expired - TINS: [Tin]
//	public static void sendEmailWithoutAttachment(String tins, String dateTime, String emailSubject, String emailMsg) throws MessagingException {
//		try {
//
//			final Properties props = System.getProperties();
//			Session session;
//			props.put(mailSmtpHost, System.getenv(prunEmailHost));
//			session = Session.getInstance(props, null);
//
//			Message msg = new MimeMessage(session);
//			msg.setFrom(new InternetAddress(System.getenv(prunEmailFrom)));
//			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(System.getenv(prunEmailToPODM), false));
//			msg.setSubject(emailSubject.replace(dateTimeFormat, dateTime).replace("[Tin]", tins));
//			msg.setSentDate(new Date());
//
//			MimeBodyPart messageBodyPart = new MimeBodyPart();
//			messageBodyPart.setContent(emailMsg.replace(dateTimeFormat, dateTime).replace("[Tin]", tins), textHTML);
//			Multipart multipart = new MimeMultipart();
//			multipart.addBodyPart(messageBodyPart);
//			msg.setContent(multipart);
//			LOGGER.info(sendEmailMessage);
//			Transport.send(msg);
//			LOGGER.info("sendEmail: Email Sent Successfully!!");
//		} catch (MessagingException e) {
//			LOGGER.error(emailFile, PRUN_EMAIL_HOST,
//					System.getenv(prunEmailHost), PRUN_EMAIL_FROM, System.getenv(prunEmailFrom), PRUN_EMAIL_TO_PODM,
//					System.getenv(prunEmailToPODM), PRUN_EMAIL_SUBJECT_PODM, emailSubject,
//					PRUN_EMAIL_MSG_PODM, emailMsg, ExceptionUtils.getStackTrace(e));
//		} catch (Exception e) {
//			LOGGER.error(emailFile, PRUN_EMAIL_HOST,
//					System.getenv(prunEmailHost), PRUN_EMAIL_FROM, System.getenv(prunEmailFrom), PRUN_EMAIL_TO_PODM,
//					System.getenv(prunEmailToPODM), PRUN_EMAIL_SUBJECT_PODM, emailSubject,
//					PRUN_EMAIL_MSG_PODM, emailMsg, ExceptionUtils.getStackTrace(e));
//		}
//	}
//
//}
