package com.optum.providerpreferences.autoenrollment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.optum.digitalsecurity.model.request.User;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentObj;
import com.optum.providerpreferences.rs.model.autoenroll.AutoenrollmentRequest;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.fds.PDOConstants;
import com.optum.providerpreferences.rs.service.AutoenrollmentServiceImpl;
import com.optum.providerpreferences.rs.service.DigitalSecurityServiceImpl;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;

@Component
public final class SftpUtil {
	
	private SftpUtil() {
		//private constructor to hide public one
	}

	private static final Logger LOGGER = LogManager.getLogger(SftpUtil.class);

	private static final int SFTP_PORT = 22;
	public static final String INGEST_PATH_PROPERTY_NAME = "INGEST_ROOT";
	private static final String DIRECTORY_LISTING = "directoryListing";
	private static final String CHANNEL_SFTP = "channelSftp";
	private static final String SFTP_SESSION = "sftpSession";
	private static final String CHANNEL = "channel";
	private static final String FILE_NAME = "fileName";
	private static final String MAX_TRIES = "maxTries";
	private static final String RETRY_TIME_SECS = "retryTimeSecs";
	private static final String SFTP_HOST = "sftpHost";
	private static final String SFTP_USER = "sftpUSER";
	private static final String SFTP_RESULT = "sftpResult";
	private static final String TARGET_DIR = "targetDir";
	private static final String ARCHIVE_DIR = "archiveDir";
	private static final String COMMA_DELIMITER = ",";
	private static final String FILE_EXTENSION = ".csv";
	private static final String MPIN = "MPIN";
	private static final String TIN = "TAX ID";
	private static final String LETTERTYPE = "LETTER TYPE";
	private static final String CORPORATE_MPIN = "CORP MPIN";
	private static final String SHELL_COMMAND = "sudo -s";
	private static final String THREADS_DIGISEC_GET = "THREADS_DIGISEC_GET";
	private static final String THREADING_FAILED = "Threading failed, error={}";
	private static final String AUTOENROLL_SEND_FAILURE = "sftpFileStream -> Error sending autoenrollment docs, error={}";
	private static final String READ_FILE_ERROR = "readFile {}={}, {}={}, {}={}, {}={} {}";
	
	static String destDir="DestinationDirectory";
	static String localDir="LocalDirectory";
	
	private static final List<String> headers = new ArrayList<>();
	
	private static List<String> records = null;
	private static List<FDSCloudRequest> missingDocList = null;
	private static AutoenrollmentRequest autoEnrollReq = null;
	private static List<AutoenrollmentObj> resendAEList = null;
	
	static ObjectMapper mapper = new ObjectMapper();
	
	static String readFileVal="readFile -> Failed validation: invalidValue={}, fullRecord={}";
	
	static FDSCloudHandler fdsCloudHandler = new FDSCloudHandler();
	
	static AutoenrollmentServiceImpl autoenrollmentServiceImpl = new AutoenrollmentServiceImpl();
	
	static DigitalSecurityServiceImpl digitalSecurityServiceImpl = new DigitalSecurityServiceImpl();
	
	private static ExecutorService digiSecGetExecutorService = Executors.newFixedThreadPool(ApplicationUtil.parseWithDefault(System.getenv(THREADS_DIGISEC_GET), ApplicationUtil.THREADS_DIGISEC_GET_DEFAULT));
	private static ExecutorService sendGetExecutorService = Executors.newFixedThreadPool(ApplicationUtil.parseWithDefault(System.getenv("THREADS_FDSCLOUD_GET"), ApplicationUtil.THREADS_FDSCLOUD_GET_DEFAULT));

	@SuppressWarnings("unchecked")
	public static Map<String, Object> sftpDirectory(String sftpUSER, String sftpPASS, String sftpHost,
			String sftpWorkingDir) throws JSchException, SftpException {
		Map<String, Object> result = new HashMap<>();
		Session sftpSession;
		Channel channel;
		ChannelSftp channelSftp;
		sftpSession = createSession(sftpUSER, sftpPASS, sftpHost, SFTP_PORT);
		channel = createSFTPChannel(sftpSession);
		channelSftp = (ChannelSftp) channel;
		try {
			channelSftp.cd(sftpWorkingDir);
		} catch (SftpException e) {
			LOGGER.error("processSFTPDirectory Failure: cd to sftpWorkingDir: {}, errMsg={}", sftpWorkingDir,
					e.getMessage());
//			throw e;
		}

		Comparator<ChannelSftp.LsEntry> c = Comparator.comparingInt((ChannelSftp.LsEntry o) -> o.getAttrs().getMTime());
		ArrayList<ChannelSftp.LsEntry> directoryListing = new ArrayList<ChannelSftp.LsEntry>(
				channelSftp.ls(channelSftp.pwd()));
		directoryListing.sort(c);
		result.put(DIRECTORY_LISTING, directoryListing);
		result.put(CHANNEL_SFTP, channelSftp);
		result.put(SFTP_SESSION, sftpSession);
		result.put(CHANNEL, channel);
		return result;
	}
	

	public static boolean exceptionForMissingLoginCredential(String sftpHost, String sftpUSER, String sftpPASS,
			String sftpWorkingDir) throws IOException {

		if (isMissingLoginCredential(sftpHost, sftpUSER, sftpPASS, sftpWorkingDir)) {
			LOGGER.info("runCsvSFTPMonitor Login credentials must be supplied ; not able to login to SFTP host={}",
					sftpHost);
			throw new IOException("Missing login credentials host=" + sftpHost);
		}
		return false;

	}

	public static boolean isMissingLoginCredential(String sftpHost, String sftpUSER, String sftpPASS,
			String sftpWorkingDir) {
		return StringUtils.isEmpty(sftpHost) || StringUtils.isEmpty(sftpUSER) || StringUtils.isEmpty(sftpPASS)
				|| StringUtils.isEmpty(sftpWorkingDir);
	}

	public static void closeSFTPChannel(ChannelSftp channelSftp, Session sftpSession, Channel channel) {
		if (channelSftp != null && channelSftp.isConnected()) {
			try {
				channel.disconnect();
				channelSftp.disconnect();
				channelSftp.quit();
				if (sftpSession == null || !sftpSession.isConnected()) {
					sftpSession = channelSftp.getSession();
				}
				sftpSession.disconnect();
			} catch (JSchException e) {
				LOGGER.error("closeSFTPChannel IOException Error Message {}", ExceptionUtils.getStackTrace(e));
			}
		}
	}

	public static void moveFileFromSFTPDirToArchive(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort,
			String fromDir, String archiveDir, String fileName, int maxTries, long retryTimeSecs)
			throws JSchException, SftpException {

		Session sftpSession = null;
		ChannelSftp channel = null;
		for (int tries = 0; tries < maxTries; tries++) {
			try {
				LOGGER.info("sftp tries {}, fromDir {}, archiveDir {}, fileName {}", tries + 1, fromDir, archiveDir,
						fileName);
				sftpSession = createSession(sftpUSER, sftpPASS, sftpHost, sftpPort);
				channel = (ChannelSftp) createSFTPChannel(sftpSession);
				moveFileToLocation(channel, fromDir, archiveDir, fileName);
				break;
			} catch (JSchException e) {
				if (tries >= maxTries - 1) {
					LOGGER.error(
							"moveFileFromSFTPDirToArchive {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={} {}",
							SFTP_USER, sftpUSER, SFTP_HOST, sftpHost, SFTP_PORT, sftpPort, "fromDir", fromDir,
							ARCHIVE_DIR, archiveDir, FILE_NAME, fileName, MAX_TRIES, maxTries, RETRY_TIME_SECS,
							retryTimeSecs, ExceptionUtils.getStackTrace(e));
					throw e;
				}
			} catch (SftpException e) {
				if (tries >= maxTries - 1) {
					LOGGER.error(
							"moveFileFromSFTPDirToArchive: {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={}, {}={} {}",
							SFTP_USER, sftpUSER, SFTP_HOST, sftpHost, SFTP_PORT, sftpPort, "fromDir", fromDir,
							ARCHIVE_DIR, archiveDir, FILE_NAME, fileName, MAX_TRIES, maxTries, RETRY_TIME_SECS,
							retryTimeSecs, ExceptionUtils.getStackTrace(e));
					throw new SftpException(e.id, "sftp exception", e);
				}
			} finally {
				if (channel != null) {
					channel.disconnect();
					channel.quit();
				}
				if (sftpSession != null) {
					sftpSession.disconnect();
				}
				retryWaitHelper(archiveDir, fileName, retryTimeSecs);
			}
		}

	}

	public static void retryWaitHelper(String archiveDir, String fileName,  long retryTimeSecs) {
	try {
		TimeUnit.SECONDS.sleep(retryTimeSecs);
	} catch (InterruptedException e) {
		LOGGER.warn("moveFileFromSFTPDirToArchive; Time delay interrupted {}={}, {}={}", ARCHIVE_DIR,
				archiveDir, FILE_NAME, fileName);
		Thread.currentThread().interrupt();
	}
	}
	public static Session createSession(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort)
			throws JSchException {
		Session sftpSession;
		JSch jsch = new JSch();
		sftpSession = jsch.getSession(sftpUSER, sftpHost, sftpPort);
		sftpSession.setPassword(sftpPASS);
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		sftpSession.setConfig(config);
		sftpSession.connect();
		return sftpSession;
	}

	public static Channel createSFTPChannel(Session sftpSession) throws JSchException {
		Channel channel = sftpSession.openChannel("sftp");
		try {
			channel.connect();
		} catch (JSchException e) {
			String stackTrace= ExceptionUtils.getStackTrace(e);
			LOGGER.error("createSFTPChannel -> Error connecting channel, error={}", stackTrace);
		}
		return channel;
	}

	private static void moveFileToLocation(ChannelSftp channel, String fromDir, String targetDir, String fileName)
			throws SftpException {
		channel.cd(fromDir);
		if (channel.get(fileName) != null) {
			channel.rename(fromDir + File.pathSeparator + fileName, targetDir + File.pathSeparator + fileName);
			channel.chmod(640, targetDir + File.pathSeparator + fileName);
			channel.cd(fromDir);
		}

	}

	public static void removeFileFromSFTPLocation(String sftpUSER, String sftpPASS, String sftpHost, int sftpPort,
			String targetDir, String fileName) throws JSchException, SftpException {
		Session sftpSession = null;
		ChannelSftp channel = null;
		try {
			sftpSession = createSession(sftpUSER, sftpPASS, sftpHost, sftpPort);
			channel = (ChannelSftp) createSFTPChannel(sftpSession);
			channel.cd(targetDir);
			removeFileInSFTPLocation(channel, targetDir, fileName);
		} catch (JSchException | SftpException e) {
			LOGGER.error("removeFileFromSFTPLocation {}={}, {}={}, {}={}, {}={}, {}={} {}", SFTP_USER, sftpUSER,
					SFTP_HOST, sftpHost, SFTP_PORT, sftpPort, TARGET_DIR, targetDir, FILE_NAME, fileName,
					ExceptionUtils.getStackTrace(e));
		} finally {

			if (channel != null) {
				channel.disconnect();
				channel.quit();
			}
			if (sftpSession != null) {
				sftpSession.disconnect();
			}
		}
	}

	private static void removeFileInSFTPLocation(ChannelSftp channel, String location, String fileName)
			throws SftpException {
		removeFileInSFTPLocation(channel, location + File.separator + fileName);
	}

	public static void removeFileInSFTPLocation(ChannelSftp channel, String fileNameWithPath) throws SftpException {
		channel.rm(fileNameWithPath);
	}

	public static void copyFileToArchive(String workingDir, String destination, String localDirectory, String filename,
			Map<String, Object> sftpResult) throws FileNotFoundException, SftpException {

		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);

		validateDirectory(sftpChannel, destination);

		try {
			moveFilefromsftpTolocalToArchive(sftpChannel, filename, workingDir, localDirectory, destination);
		} catch (SftpException e) {
			LOGGER.error("copyFileToArchive {}={}, {}={}, {}={}, {}={}, {}={} {}", "WorkingDirectory", workingDir,
					destDir, destination, localDir, localDirectory, FILE_NAME, filename, "SFTP",
					sftpResult, ExceptionUtils.getStackTrace(e));
			String stackTrace=ExceptionUtils.getStackTrace(e);
			LOGGER.error("copyfileToArchive Unable to copy file{}", stackTrace);
		}
	}
	
	public static void validateDirectoryCall(ChannelSftp sftpChannel, String destination) throws SftpException {
		validateDirectory(sftpChannel, destination);
	}

	private static void validateDirectory(ChannelSftp sftpChannel, String destination) throws SftpException {

		String folderName = createDateintoString();
		SftpATTRS attrs = null;
		try {
			sftpChannel.cd(destination);
			attrs = sftpChannel.stat(destination + File.separator + folderName);
		} catch (SftpException e) {
			LOGGER.error("validateDirectory not found {}={}, {}={}, {}={} {}", "sftpChannel", sftpChannel,
					destDir, destination, "folderName", folderName, ExceptionUtils.getStackTrace(e));
		}

		if (attrs != null) {
			LOGGER.info("Directory exists Dir{}", attrs.isDir());
		} else {
			LOGGER.info("Creating dir{}", folderName);
			sftpChannel.mkdir(folderName);
		}

	}

	private static final List<SimpleDateFormat> SIMPLE_DATE_FORMAT = Collections
			.singletonList(new SimpleDateFormat("yyyyMMdd"));

	public static String createDateintoString() {
		return SIMPLE_DATE_FORMAT.get(0).format(new Date());
	}

	private static void moveFilefromsftpTolocalToArchive(ChannelSftp sftpChannel, String filename, String workingDir,
			String localDirectory, String destination) throws SftpException, FileNotFoundException {
		LOGGER.info(
				"moveFilefromsftpTolocalToArchive  sftpChannel{}, filename{}, workingDir{},localDirectory{},destination{}",
				sftpChannel, filename, workingDir, localDirectory, destination);

		sftpChannel.get(workingDir + File.separator + filename, localDirectory);
		File localFile = new File(localDirectory + File.separator + filename);
		sftpChannel.cd(destination + File.separator + createDateintoString() + File.separator);
		String direc=destination + File.separator + createDateintoString() + File.separator;
		LOGGER.info("cd into this directory {}", direc);
		try {
			FileInputStream localStream = new FileInputStream(localFile);
			sftpChannel.put(localStream, localFile.getName());
			localStream.close();
		}
		catch (IOException e ){
			LOGGER.error("moveFilefromsftpTolocalToArchive -> Error moving file to archive, error={}", e.getMessage());
		}
	}

	private static final Map<Integer, Predicate<String>> predicateMap;
	static {
		predicateMap = new HashMap<>();
		predicateMap.put(0, x -> x.length() == 9);
		predicateMap.put(1, x -> x.length() == 9);
		predicateMap.put(2, x -> x.length() == 2);
		predicateMap.put(3, x -> x.length() == 9);

	}

	
	public static List<String> readFile(String destination, String localDirectory, String filename,
			Map<String, Object> sftpResult) throws FileNotFoundException, SftpException {
		headerValidation();
		copyFileToLocal(destination, localDirectory, filename, sftpResult);

		List<String> records = new ArrayList<>();
		try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(localDirectory + File.separator + filename)))) {
			String line;
			while ((line = br.readLine()) != null) {

				String[] values = line.split(COMMA_DELIMITER);
				boolean allFieldsGood = true;
				for (int i = 0; i < values.length; i++) {
					if (!predicateMap.getOrDefault(i, x -> true).test(values[i].trim())) {
						if(!headers.contains(values[i].trim())) {
							String value=values[i].trim();
							LOGGER.error(readFileVal, value, i);
						}
						allFieldsGood = false;
					}
				}
				if (allFieldsGood && values.length > 1) {
					records.add(values[1].trim());
				}

			}
		} catch (IOException e) {
			LOGGER.error(READ_FILE_ERROR, destDir, destination,
					localDir, localDirectory, FILE_NAME, filename, SFTP_RESULT, sftpResult,
			ExceptionUtils.getStackTrace(e));
		}
		return records;
	}
	

	// extracts records, grabs corresponding email, sends back to write CSV. 
	public static List<String> readFileStoreData(String destination, String localDirectory, String filename,
			Map<String, Object> sftpResult, Boolean isDailyScheduler) throws FileNotFoundException, SftpException, ApplicationException {
		records = Collections.synchronizedList(new ArrayList<String>());
		
		if (digiSecGetExecutorService.isShutdown()) {
			digiSecGetExecutorService = Executors.newFixedThreadPool(ApplicationUtil.parseWithDefault(System.getenv(THREADS_DIGISEC_GET), ApplicationUtil.THREADS_DIGISEC_GET_DEFAULT));
		}
		headerValidation();
		if (isDailyScheduler) {
			copyFileToLocalNoDate(destination, localDirectory, filename, sftpResult);
		}
		else {
			copyFileToLocal(destination, localDirectory, filename, sftpResult);
		}
			List<List<String>> recordLines = new ArrayList<List<String>>();
			try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(localDirectory + File.separator + filename)))) {
				recordLines = parseBufferReader(br);
				
				digitalSecurityServiceImpl.getDigiSecToken("autoenrollmentPAAEmail", "");
				LOGGER.info("Processing count={}", recordLines.size());
				for (List<String> record : recordLines) {
					digiSecGetExecutorService.execute(new getDigiSecEmailRequest(record));
				}
				serviceDigiSecGetShutdown();
				
			} catch (IOException e) {
				LOGGER.error(READ_FILE_ERROR, destDir, destination,
						localDir, localDirectory, FILE_NAME, filename, SFTP_RESULT, sftpResult,
				ExceptionUtils.getStackTrace(e));
			}
	        catch (Exception e) {
	        	LOGGER.error("readFileStoreData -> error processing data, error={}", ExceptionUtils.getStackTrace(e));
	        }
			
		LOGGER.info("readFileStoreData -> DigiSec emails found, updatedCount={}", records.size());
		

		return records;
	}
	
	public static List<String> readRetryData(String destination, String localDirectory, String filename,
			Map<String, Object> sftpResult, Boolean isDailyScheduler) throws FileNotFoundException, SftpException, ApplicationException {
		records = Collections.synchronizedList(new ArrayList<String>());
		copyFileToLocalNoDate(destination, localDirectory, filename, sftpResult);
		
		
		List<List<String>> recordLines = new ArrayList<List<String>>();
		try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(localDirectory + File.separator + filename)))) {
			recordLines = parseRetryReader(br);
			LOGGER.info("recordLines={}, isDailyScheduler={}", recordLines, isDailyScheduler);
		} catch (IOException e) {
			LOGGER.error(READ_FILE_ERROR, destDir, destination,
					localDir, localDirectory, FILE_NAME, filename, SFTP_RESULT, sftpResult,
			ExceptionUtils.getStackTrace(e));
		}
        catch (Exception e) {
        	LOGGER.error("readRetryData -> error processing retry data, error={}", ExceptionUtils.getStackTrace(e));
        }
		return records;
	}
	
public static List<String> readFileSendAutoEnroCloud(List<String> recordList) {
		
		HttpHeaders httpHeaders = new HttpHeaders(); 
		AutoenrollmentRequest autoEnrollReq = new AutoenrollmentRequest();
		List<AutoenrollmentObj> autoEnrollList = Collections.synchronizedList(new ArrayList<>());
		
		for (String record : recordList) {
			AutoenrollmentObj autoEnrollObj = new AutoenrollmentObj();
			if (record == null) {
				continue;
			}
			String[] values = record.split(COMMA_DELIMITER);
			
			autoEnrollObj.setMpin(values[0].trim());
			autoEnrollObj.setTin(values[1].trim());
			autoEnrollObj.setFileName(values[2].trim()); 			
			try {
				autoEnrollObj.setProviderEmailId(values[4].trim());
			}
			catch (ArrayIndexOutOfBoundsException e) {
				autoEnrollObj.setProviderEmailId("");
			}
			
			autoEnrollList.add(autoEnrollObj);
		}
		autoEnrollReq.setAutoenrollDocuments(autoEnrollList);
		
		List<String> response = Collections.synchronizedList(new ArrayList<String>());
		try {
			response = autoenrollmentServiceImpl.createAutoenrollmentDocumentsFDSCloud(autoEnrollReq, httpHeaders);

		} catch (ApplicationException e) {
			LOGGER.error(AUTOENROLL_SEND_FAILURE, e.getMessage());
		}
		catch (Exception e) {
        	throw e;
        }
		LOGGER.info("readFileSendAutoEnroCloud -> processed Autoenrollment, updatedCount={}", response.size());
		
		records = null;
		missingDocList = null;
		autoEnrollReq = null;
		resendAEList = null;
		return response;
	}

public static List<String> checkAutoenrollmentSetup(String sftpUSER, String sftpPASS, String sftpHost, String checkDir, String checkFileName) throws IOException, ApplicationException, JSchException        {
	
	if (sendGetExecutorService.isShutdown()) {
		sendGetExecutorService = Executors.newFixedThreadPool(ApplicationUtil.parseWithDefault(System.getenv("THREADS_FDSCLOUD_GET"), ApplicationUtil.THREADS_FDSCLOUD_GET_DEFAULT));
	}
	if (digiSecGetExecutorService.isShutdown()) {
		digiSecGetExecutorService = Executors.newFixedThreadPool(ApplicationUtil.parseWithDefault(System.getenv(THREADS_DIGISEC_GET), ApplicationUtil.THREADS_DIGISEC_GET_DEFAULT));
	}
	
	List<FDSCloudRequest> docIdList = Collections.synchronizedList(new ArrayList<FDSCloudRequest>());
	
	ChannelSftp channelSftp= sftpFileHelper(sftpUSER, sftpPASS, sftpHost);	
	
	try {
		channelSftp.cd(checkDir);
		
		Integer fileRowCount = 0;
		InputStream fileStream = channelSftp.get(checkDir + "/" + checkFileName);
		LOGGER.info("Grabbing file={}", checkDir + "/" + checkFileName);
		
		InputStream getFileStream = channelSftp.get(checkDir + "/" + checkFileName);
		try (BufferedReader getReadFile = new BufferedReader(new InputStreamReader(getFileStream))) {
			docIdList = checkAutoenrollmentGET(getReadFile, fileStream, fileRowCount);
		} catch (IOException  e) {
			String getTrace=(ExceptionUtils.getStackTrace(e));
			LOGGER.error("readLoadTest Error, error={}", getTrace);
		}
		catch (Exception e) {
        	throw e;
        }
		
	} catch (SftpException e) {
		LOGGER.error("Load Test dir not found, loadTestDir={}", checkDir);
	}
	catch (Exception e) {
    	throw e;
    }
	
	List<String> searchTermResp = new ArrayList<String>();	
	if (!docIdList.equals(null) && docIdList.size() > 0) {
		for(FDSCloudRequest req: docIdList) {
			searchTermResp.add(fdsCloudHandler.encodeToUTF(req.getRequest().get(PDOConstants.SEARCH_TERMS).toString())); 
		}
	}
	else {
		
	}
	
	return searchTermResp;
}
	public static List<FDSCloudRequest> checkAutoenrollmentGET(BufferedReader readFile, InputStream fileStream, Integer fileRowCount) throws IOException, ApplicationException {
		String line;
		//HttpHeaders httpHeaders = new HttpHeaders(); 
//		List<FDSCloudRequest> fdsCloudList = new ArrayList<>();
		autoEnrollReq = new AutoenrollmentRequest();
		resendAEList = Collections.synchronizedList(new ArrayList<AutoenrollmentObj>());
		records = Collections.synchronizedList(new ArrayList<String>());
		List<AutoenrollmentObj> autoEnrollList = Collections.synchronizedList(new ArrayList<AutoenrollmentObj>());
		
		while ((line = readFile.readLine()) != null) {
			if (line.contains("MPIN") || line.contains("TIN") || line.contains("LETTER")) {
				continue;
			}
			AutoenrollmentObj metadata = new AutoenrollmentObj();
			
			String[] values = line.split(COMMA_DELIMITER);
			
			metadata.setMpin(values[0].trim());
			metadata.setTin(values[1].trim());
			metadata.setFileName(values[2].trim());
			
			try {
				metadata.setCorpMpin(values[3].trim());
			}
			catch (ArrayIndexOutOfBoundsException e) {
				LOGGER.warn("checkAutoenrollmentGET -> Corporate MPIN null, record={}, fileRowCount={}", line, fileRowCount);
				continue;
			}
			
			autoEnrollList.add(metadata);
		}
		
		
		missingDocList = Collections.synchronizedList(new ArrayList<FDSCloudRequest>());
		try {
			fdsCloudHandler.getFDSCloudToken("checkAutoenrollment");
			// get all the documents, replace the email in subsequent put

			for (AutoenrollmentObj request : autoEnrollList) {
				sendGetExecutorService.execute(new sendFDSCloudGetRequest(request));
			}
			serviceSendGetShutdown();
			LOGGER.info("DigiSec PAA complete, resendAEList={}, missingDocList={}, requestedList={}", resendAEList.size(), missingDocList.size(), autoEnrollList.size());
			
		}
		catch (Exception e) {
			LOGGER.error("Error processing sendFDSCloudGetRequest, error={}", ExceptionUtils.getStackTrace(e));
        	throw e;
        }
		
		if(resendAEList.size() > 0) {
			
			// updates records
			
			LOGGER.info("Resending {} records -> DigiSec", resendAEList.size());
			digitalSecurityServiceImpl.getDigiSecToken("autoenrollmentPAAEmail", "");
			
			processResendAEList();
			
			serviceDigiSecGetShutdown();
			
			LOGGER.info("Sending {} records -> AutoEnrollment POST", records.size());
			List<String> response = readFileSendAutoEnroCloud(records);
			LOGGER.info("Sent {} records -> Completed check", response.size());
		}

		return missingDocList; 
		
	}



	public static void copyFileToLocal(String destination, String localDirectory, String filename,
			Map<String, Object> sftpResult) throws SftpException {

		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);

		copyFilefromsftpTolocal(sftpChannel, filename, localDirectory,
				destination + File.separator + createDateintoString());
	}
	
	public static void copyFileToLocalNoDate(String destination, String localDirectory, String filename,
			Map<String, Object> sftpResult) throws SftpException {

		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);

		copyFilefromsftpTolocal(sftpChannel, filename, localDirectory,
				destination);
	}

	private static void copyFilefromsftpTolocal(ChannelSftp sftpChannel, String filename, String localDirectory,
			String sftpDirectory) throws SftpException {
		checkFileExistsOrNot(filename, localDirectory);
		LOGGER.info("Destination = {}", sftpDirectory + File.separator + filename);
		LOGGER.info("local = {}",  localDirectory);
		sftpChannel.get(sftpDirectory + File.separator + filename, localDirectory);

	}

	public static void checkFileExistsOrNot(String filename, String localDirectory) {
		try {
			if (Files.deleteIfExists(Paths.get(localDirectory + File.separator + filename))) {
				LOGGER.info("File Deleted: FileName={}, Directory={}", filename, localDirectory);
			}
		} catch (IOException e) {
			LOGGER.error("checkFileExistsOrNot  {}={}, {}={} {}", localDir, localDirectory, FILE_NAME,
					filename, ExceptionUtils.getStackTrace(e));
		}
	}

	public static void writeInCSVFile(Collection<String> completeData, String localDirectory) throws IOException {

		String result = completeData.stream().map(String::valueOf).collect(Collectors.joining("\n"));
		checkFileExistsOrNot(createDateintoString() + FILE_EXTENSION, localDirectory);

		try (FileWriter writer = new FileWriter(
				localDirectory + File.separator + createDateintoString() + "_PAAEmails" + FILE_EXTENSION)) {
			writer.write(result);
		} catch (IOException e) {
			LOGGER.error("writeInCSVFile  {}={}, {}={} {}", "completeData", completeData, localDir,
					localDirectory, ExceptionUtils.getStackTrace(e));
		}
	}

	public static void movefileFromlocalToServer(String localFilePath, Map<String, Object> sftpResult,
			String destination) throws SftpException, FileNotFoundException {
		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);
		File localFile = new File(localFilePath);
		
		LOGGER.info("File: " + destination + File.separator + createDateintoString() + File.separator);
		sftpChannel.cd(destination + File.separator + createDateintoString() + File.separator);
		try {
			FileInputStream localStream = new FileInputStream(localFile);
			sftpChannel.put(localStream, localFile.getName());
			localStream.close();
		}
		catch (IOException e ){
			LOGGER.error("movefileFromlocalToServer -> Error moving file to server, error={}", e.getMessage());
		}
	}

	public static void readFileFromServer(String destination, Map<String, Object> sftpResult, String workingDir) throws SftpException {
		readFileFromServer(destination, sftpResult, workingDir, false);
	}

	public static String readFileFromServer(String destination, Map<String, Object> sftpResult, String workingDir, boolean forceDelete) throws SftpException {
		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);
		sftpChannel.cd(destination);

		@SuppressWarnings("unchecked")
		List<ChannelSftp.LsEntry> listFiles = (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING);
		for (ChannelSftp.LsEntry entry : listFiles) {
			String fileName = entry.getFilename();
			if (fileName.endsWith(FILE_EXTENSION)) {
				String originalPath = workingDir + File.separator + fileName;
				String newPath = String.join(File.separator, destination, fileName);
				Boolean renameSuccess = rename(sftpChannel, originalPath, newPath, forceDelete);
				if (!renameSuccess) {
					return originalPath;
				}
			}
		}
		return "";
	}

	protected static Boolean rename(ChannelSftp sftpChannel, String originalPath, String newPath, boolean forceDelete) {
		try {
			sftpChannel.rename(originalPath, newPath);
			sftpChannel.stat(newPath);
		} catch(SftpException e) {
			LOGGER.error("Exception rename: originalPath={}, newPath={}, error={}", originalPath, newPath, e.getMessage());
			if (e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE) {
				Boolean retryCheck = retryRename(sftpChannel, originalPath, newPath);
				if (!retryCheck) {
					return retryCheck;
				}
			}
		}
		if (forceDelete) {
			try {  
				sftpChannel.rm(originalPath);
				LOGGER.error("ERROR: Removed originalPath={}", originalPath);
			} catch(SftpException e) {
				return retryRemove(sftpChannel, originalPath);
			}
		}
		return true;
	}
	
	protected static Boolean retryRename(ChannelSftp channel, String originalPath, String newPath) {
		for(int i = 0 ; i < 5; i++) {
			LOGGER.warn("LOOPING retryRename try: {}, originalPath:{}, newPath: {}", i, originalPath, newPath);
			try {
				channel.rename(originalPath, newPath);
				channel.stat(newPath);
				return true;
			}
			catch (SftpException e) {
				LOGGER.warn("rename -> Rename failure, retrying originalPath:{}, newPath: {}", originalPath, newPath);
			}
		}
		return false;
	}
	
	protected static Boolean retryRemove(ChannelSftp channel, String path) {
		for(int i = 0 ; i < 5; i++) {
			LOGGER.warn("LOOPING retryRemove try: {}, path: {}", i, path);
			try {
				channel.stat(path);
				channel.rm(path);
			}
			catch (SftpException e) {
				if (e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE) {
					return true; 
				}
				LOGGER.warn("rename -> Remove failure, retrying path: {}", path);
			}
		}
		return false;
	}

	public static Map<String, String> parseEmailList(ChannelSftp channelSftp, String emailFileDir,
			String emailListFilename) {
		Map<String, String> emailList = new HashMap<String, String>();
		try {
			InputStream fileStream = channelSftp.get(emailFileDir + "/" + emailListFilename);

			try (BufferedReader readFile = new BufferedReader(new InputStreamReader(fileStream))) {
				String line;
				while ((line = readFile.readLine()) != null) {
					String[] parseSplit = line.split(",");

					if (parseSplit[0].length() == 9 && parseSplit[1].length() > 0 && validateEmail(parseSplit[1])) {
						emailList.put(parseSplit[0], parseSplit[1]);
					}

				}
				LOGGER.info("parseEmailList ->Created email object, emailList={}", emailList.values());

			} catch (IOException e) {
				LOGGER.error("sftpFileStream -> Error reading file stream, emailListFilename={}, error={}",
						emailListFilename, e.getStackTrace());
			}
		} catch (SftpException e) {
			String eMessage = e.getMessage();
			if (("No such file").equals(eMessage)) {
				String emailDir=emailFileDir + "/" + emailListFilename;
				LOGGER.warn("Email List not found, emailFileDir={}", emailDir);
			}
		}
		return emailList;
	}

	public static Boolean validateEmail(String email) {

		EmailValidator emailValidator = EmailValidator.getInstance();
		return emailValidator.isValid(email);

	}
	
	public static void headerValidation() {
		headers.add(MPIN);
		headers.add(TIN);
		headers.add(LETTERTYPE);
		headers.add(CORPORATE_MPIN);
	}
	
	public static ChannelSftp sftpFileHelper(String sftpUSER, String sftpPASS, String sftpHost) throws JSchException {
		Session sftpSession;
		Channel channel;
		sftpSession = createSession(sftpUSER, sftpPASS, sftpHost, SFTP_PORT);
		channel = createSFTPChannel(sftpSession);
		return (ChannelSftp) channel;
	}

	public static void removeFileFromServer(Map<String, Object> sftpResult,
			String destination, String fileName) throws SftpException {
		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);
		sftpChannel.rm(destination + File.separator + createDateintoString() + File.separator + fileName);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Removed file from server: file={}", destination + File.separator + createDateintoString() + File.separator + fileName);
		}
	}

	public static Map<String, Long> readFileFromServerCheckSize(String destination, Map<String, Object> sftpResult, String workingDir)
			throws SftpException {
		ChannelSftp sftpChannel = (ChannelSftp) sftpResult.get(CHANNEL_SFTP);
		sftpChannel.cd(destination);
		try {
			sftpChannel.mkdir(createDateintoString());
		} catch (SftpException e) {
			LOGGER.debug("readFileFromServer  {}={}, {}={}, {}={} {}", "destination", destination, SFTP_RESULT,
					sftpResult, "workingDirectory", workingDir, "Folder already present");
		}
		Map<String, Long> fileSizeMap = new HashMap<>();
		List<ChannelSftp.LsEntry> listFiles = (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING);
		for (ChannelSftp.LsEntry entry : listFiles) {
			String fileName = entry.getFilename();
			if (fileName.endsWith(FILE_EXTENSION)) {
				fileSizeMap.put(fileName, entry.getAttrs().getSize());
				String originalPath = workingDir + File.separator + fileName;
				String newPath = String.join(File.separator, destination, createDateintoString(), fileName);
				sftpChannel.rename(originalPath, newPath);
			}
		}
		return fileSizeMap;
	}

	protected static Map<String, Long> getFilesToSplit(int splitPerMbSize, Map<String, Long> fileSizeMap) {
		Long fileSize;
		Map<String, Long> fileSplitMap = new HashMap<String, Long>();
		final long bytesPerSplit = 1024L * 1024L * splitPerMbSize;
		for (Map.Entry<String, Long> entry : fileSizeMap.entrySet()) {
			fileSize = entry.getValue();
			if (fileSize != null && fileSize >= bytesPerSplit) {
				fileSplitMap.put(entry.getKey(), fileSize);
			}
		}
		return fileSplitMap;
	}

	// If the file was not fully split i.e had an IOException it deletes any split file and returns empty List<Path>
	public static List<Path> splitFilePerMbPerNewLine(final String fileName, final int splitPerMbSize, int maxBytesNewLineWithin, String toDir, boolean delete) {
		List<Path> splitFiles = new ArrayList<>();
		if (splitPerMbSize <= 0) {
			return splitFiles;
		}

		long sourceSize;
		Path fileNamePath = Paths.get(fileName);
		try {
			sourceSize = Files.size(fileNamePath);
		} catch (IOException e) {
			LOGGER.error("Exception file.size: fileName={}; {}", fileName, ExceptionUtils.getStackTrace(e));
			return splitFiles;
		}

		final long bytesPerSplit = 1024L * 1024L * splitPerMbSize;
		if (sourceSize < bytesPerSplit) {
			LOGGER.info("Not splitting: fileName={}, sourceSize={}, bytesPerSplit={}", fileName, sourceSize, bytesPerSplit);
			return splitFiles;
		}
		LOGGER.info("Splitting: fileName={}, sourceSize={}, bytesPerSplit={}", fileName, sourceSize, bytesPerSplit);

		int i = 0;
		long offset = 0;
		long numSplits = sourceSize / bytesPerSplit;
		long remainingBytes = sourceSize % bytesPerSplit;
		long writtenByteSize = 0;
		long sourceSizeOrig = sourceSize;
		long writtenByteSizeTotal = 0;
		LOGGER.info("fileName={}, sourceSize={}, bytesPerSplit={}, numSplits={}, remainingBytes={}, splitPerMbSize={}, maxBytesNewLineWithin={}, toDir={}, delete={}",
				fileName, sourceSize, bytesPerSplit, numSplits, remainingBytes, splitPerMbSize, maxBytesNewLineWithin, toDir, delete);
		try {
			try (RandomAccessFile sourceFile = new RandomAccessFile(fileName, "r");
				FileChannel sourceChannel = sourceFile.getChannel()) {
				while (numSplits > 0) {
					LOGGER.info("PRE: fileName={}, i={}, sourceSize={}, offset={}, bytesPerSplit={}, numSplits={}, remainingBytes={}, writtenByteSize={}, writtenByteSizeTotal={}",
							fileName, i, sourceSize, offset, bytesPerSplit, numSplits, remainingBytes, writtenByteSize, writtenByteSizeTotal);
					writtenByteSize = writePartToSplitFile(fileName, ++i, offset, bytesPerSplit, maxBytesNewLineWithin, sourceChannel, splitFiles, toDir, false);
					writtenByteSizeTotal = writtenByteSizeTotal + writtenByteSize;
					sourceSize = sourceSize - writtenByteSize;
					offset = offset + writtenByteSize;
					numSplits = sourceSize / bytesPerSplit;
					remainingBytes = sourceSize % bytesPerSplit;
					LOGGER.info("POST: fileName={}, i={}, sourceSize={}, offset={}, bytesPerSplit={}, numSplits={}, remainingBytes={}, writtenByteSize={}, writtenByteSizeTotal={}",
						fileName, i, sourceSize, offset, bytesPerSplit, numSplits, remainingBytes, writtenByteSize, writtenByteSizeTotal);
				}
				if (remainingBytes > 0) {
					writtenByteSize = writePartToSplitFile(fileName,  ++i, offset, remainingBytes, maxBytesNewLineWithin, sourceChannel, splitFiles, toDir, true);
					writtenByteSizeTotal = writtenByteSizeTotal + writtenByteSize;
				}
			}
		} catch(IOException e) {
			LOGGER.error("Exception while splitting fileName={}: Backing out any splitFiles={}; msg={}", fileName,  splitFiles, e.getMessage());
			return backoutSplit(splitFiles);
		}
		if (sourceSizeOrig != writtenByteSizeTotal) {
			LOGGER.error("Done: Backing out any splitFiles; Bytes written splitFiles mismatch; fileName={}, sourceSizeOrig={}, writtenByteSizeTotal={}",
				fileName, sourceSizeOrig, writtenByteSizeTotal);
			return backoutSplit(splitFiles);
		} else {
			LOGGER.info("Done: fileName={}, sourceSizeOrig={}, writtenByteSizeTotal={}, splitFiles.size={}", fileName, sourceSizeOrig, writtenByteSizeTotal, splitFiles.size());
		}
		if (delete) {
			deleteFile(fileNamePath);
			LOGGER.info("Deleted original unsplit file={}", fileNamePath);
		}
		return splitFiles;
	}

	protected static long writePartToSplitFile(String origFile, int i, long offset, long bytesPerSplit, int maxBytesNewLineWithin, FileChannel sourceChannel,
			List<Path> splitFiles, String toDir, boolean remaining) throws IOException {
		LOGGER.info("origFile={}, i={}, offset={}, bytesPerSplit={}, remaining={}", origFile, i, offset, bytesPerSplit, remaining);
		File origFileName = new File(origFile);
		Path fileName = Paths.get(toDir + File.separator + origFileName.getName() + "." + i + FILE_EXTENSION);
		if (! remaining) {
			ByteBuffer buf = ByteBuffer.allocate(maxBytesNewLineWithin);
			LOGGER.info("origFile={}, fileName={}, i={}, offset={}, bytesPerSplit={}, newOffset={}",
				origFile, fileName, i, offset, bytesPerSplit, offset + bytesPerSplit - maxBytesNewLineWithin);
			int noOfBytesRead = sourceChannel.read(buf, offset + bytesPerSplit - maxBytesNewLineWithin);
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("origFile={}, i={}, noOfBytesRead={}, fileContent=<{}>", origFile, i, noOfBytesRead, new String(buf.array(), StandardCharsets.UTF_8));
			}
			boolean foundNewLine = false;
			for (int index = maxBytesNewLineWithin - 1; index >= 0; index--) {
				byte currentByte = buf.get(index);
				if (currentByte == '\n') {
					LOGGER.info("NEWLINE found: origFile={}, i={}, offset={}, bytesPerSplit={}, index={}", origFile, i, offset, bytesPerSplit, index);
					foundNewLine = true;
					break;
				}
				bytesPerSplit--;
			}
			LOGGER.info("origFile={}, i={}, offset={}, bytesPerSplit={}, foundNewLine={},", origFile, i, offset, bytesPerSplit, foundNewLine);
		}
		try (RandomAccessFile toFile = new RandomAccessFile(fileName.toFile(), "rw");
				FileChannel toChannel = toFile.getChannel()) {
			sourceChannel.position(offset);
			toChannel.transferFrom(sourceChannel, 0, bytesPerSplit);
		}
		splitFiles.add(fileName);
		return bytesPerSplit;
	}

	protected static List<Path> backoutSplit(List<Path> splitFiles) {
		LOGGER.warn("Backing out splitFile={}", splitFiles);
		for (Path path : splitFiles) {
			if (deleteFile(path)) {
				LOGGER.warn("Deleted splitFile={}", path);
			}
		}
		return new ArrayList<>();
	}

	protected static boolean deleteFile(Path path) {
		try {
			Files.delete(path);
			return true;
		} catch (IOException e) {
			LOGGER.error("Exception: Could not delete path={}; msg={}", path, e.getMessage());
			return false;
		}
	}

	public static class getDigiSecEmailRequest implements Runnable{
		List<String> record;
		
		public getDigiSecEmailRequest(List<String> record) {
			this.record = record;
		}
		
		@Override
		public void run() {
			List<String> emailRecord = new ArrayList<String>(record);
			try {
				String email = "";
				HttpHeaders httpHeaders = new HttpHeaders();
				try {
					// thread this

					if (!record.get(3).equals(null) && record.get(3).length() > 0) {
						ResponseEntity<User> emailResponse = digitalSecurityServiceImpl.getEmailsByCorporate(record.get(3).trim(), httpHeaders);
						if (emailResponse != null && 
								emailResponse.getBody() != null &&
								emailResponse.getBody().getEmail() != null &&
								emailResponse.toString().contains("email")) {
							email = emailResponse.getBody().getEmail();
						}
						else {
							email = "";
							SchedulerAutoEnrollment.emailNotFound.incrementAndGet();
//							LOGGER.warn("Email not found request={}", record.toString());
						}
					}
					else {
						LOGGER.info("Skipping record={}", record.toString());
					}
					
				}

				catch (OAuthProblemException | OAuthSystemException | ApplicationException | HttpClientErrorException e) {
					LOGGER.warn("readFile -> Digital Security email call failed, email left as blank String"); 
				}
				catch (Exception e) {
					throw e;
				}
				
				
				emailRecord.add(email); 
				records.add(String.join(",", emailRecord));

			}	

			catch (Exception e) {
				 LOGGER.error("getDigiSecEmailRequest -> Error getting PAA email, record={}, error={}", emailRecord.toString(), ExceptionUtils.getStackTrace(e));
			}
			if (SchedulerAutoEnrollment.emailCount.incrementAndGet() % ApplicationUtil.parseWithDefault(System.getenv("THREAD_COUNT_HEALTHCHECK"), ApplicationUtil.THREAD_COUNT_HEALTHCHECK_DEFAULT) == 0) {
				LOGGER.info("getDigiSecEmailRequest emailCount={}", SchedulerAutoEnrollment.emailCount);
			}
		}
		
	}
	
	
	public static class sendFDSCloudGetRequest implements Runnable{
		AutoenrollmentObj request;
		
		public sendFDSCloudGetRequest(AutoenrollmentObj request) {
			this.request = request;
		}
		
		@Override
		public void run() {
			try {
				Metadata metadata = new Metadata();
				
				metadata.setMpin(request.getMpin());
				metadata.setTin(request.getTin());
				metadata.setFileName(request.getFileName());
//				metadata.setProviderEmailId(request.getProviderEmailId());
				
				Map<String, Object> metadataMap = mapper.convertValue(metadata, new TypeReference<Map<String, Object>>() {});
				metadataMap.put("autoEdelUpdateInd", "Y");
				FDSCloudRequest fdsCloudRequest = fdsCloudHandler.createSearchTermsRequestFromMap(mapper.convertValue(metadata, new TypeReference<Map<String, Object>>() {}));
				
				FDSCloudGETResponse getDocResponse = fdsCloudHandler.FDSCloudGetRequest("getLoadTestCloud", fdsCloudRequest, "", "");
				if (getDocResponse.getDocuments().size() == 0) {
					missingDocList.add(fdsCloudRequest);
					LOGGER.warn("GET DOCUMENT not found, request={}", request.toString());
					
					resendAEList.add(request);
					
				}
				
			}	

			catch (Exception e) {
				
				LOGGER.error("sendFDSCloudGetRequest -> error sending FDSCloud GET, error={}", ExceptionUtils.getStackTrace(e));
			}
			if (SchedulerAutoEnrollment.getCount.incrementAndGet() % ApplicationUtil.parseWithDefault(System.getenv("THREAD_COUNT_HEALTHCHECK"), ApplicationUtil.THREAD_COUNT_HEALTHCHECK_DEFAULT) == 0) {
				LOGGER.warn("existingEmailRequest getCount={}", SchedulerAutoEnrollment.getCount);
			}
		}
	}
	
	private static List<List<String>> parseRetryReader(BufferedReader br) throws ApplicationException, IOException {
		String line;
		List<List<String>> exportBufferLines = new ArrayList<List<String>>();
			try {
				while ((line = br.readLine()) != null) {

					Map<String, Object> values = retryLineFormat(line);
					 
					FDSCloudRequest retryPostReq = new FDSCloudRequest();
					retryPostReq.setRequest(values);
					
					Gson gson = new Gson();
                	String requestString = gson.toJson(retryPostReq.getRequest());
					LOGGER.info("Retry Resend FDS Cloud -> request={}", requestString);
					
					fdsCloudHandler.FDSCloudPostRequest("retryFDSCloud", retryPostReq, "");

					
			}
			} catch (ApplicationException | IOException e) {
				throw e; 
			}
			
		return exportBufferLines;
	
		
	}
	
	private static Map<String, Object> retryLineFormat(String line) {
		Map<String, Object> exportMap = new HashMap<String, Object>();
		
		line = line.replace("\"\"", "");
		String[] exportLine = line.split("}}");
		exportLine = exportLine[0].split("-> ");
		exportLine = exportLine[1].split("\\{");
		exportLine = exportLine[1].split(COMMA_DELIMITER);
		
		for (String field : exportLine) {
			String[] tempField = field.split(":");
			exportMap.put(tempField[0], tempField[1]);
		}
		
	
//		[0].split("-> ")[1].split("{")[1].split(COMMA_DELIMITER);
		
		return exportMap;
	}
	
	private static List<List<String>> parseBufferReader(BufferedReader br) throws IOException {
		String line;
		List<List<String>> exportBufferLines = new ArrayList<List<String>>();
			try {
				while ((line = br.readLine()) != null) {
					if (line.contains("MPIN") || line.contains("TIN") || line.contains("LETTER")) {
						continue;
					}
					String[] values = line.split(COMMA_DELIMITER);
					
					List<String> recordLine = new ArrayList<String>();
					boolean allFieldsGood = validateBuffer(values, line);
					if (allFieldsGood && values.length > 1) {
						
						recordLine.add(values[0].trim()); // MPIN
						recordLine.add(values[1].trim()); // TIN
						recordLine.add(values[2].trim()); // FILENAME
						try {
							recordLine.add(values[3].trim()); // CORPMPIN
						}
						catch (ArrayIndexOutOfBoundsException e) {
							LOGGER.warn("readFileStoreData -> Corporate MPIN null, record={}", line);
							continue;
						}
						exportBufferLines.add(recordLine);
					}
//					LOGGER.info("Adding record={}", recordLine.toString());
			}
			} catch (IOException e) {
				throw e; 
			}
			
		return exportBufferLines;
	
		
	}
	
	private static Boolean validateBuffer(String[] values, String line) {
		boolean validation = true;
		for (int i = 0; i < values.length; i++) {
			if (!predicateMap.getOrDefault(i, x -> true).test(values[i].trim())) {
				if(!headers.contains(values[i].trim())) {
					String value=values[i].trim();
					LOGGER.error(readFileVal, value, line);
				}
				else {
					continue;
				}
				validation = false;
				continue;
			}
		}
		return validation;
	}
	
	private static void serviceDigiSecGetShutdown() {
		digiSecGetExecutorService.shutdown();
		
		try { 
			digiSecGetExecutorService.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			LOGGER.error(THREADING_FAILED, ExceptionUtils.getStackTrace(e));
		}
        catch (Exception e) {
        	throw e;
        }
	}
	
	private static void serviceSendGetShutdown() {
		sendGetExecutorService.shutdown();
		
		try { 
			sendGetExecutorService.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			LOGGER.error(THREADING_FAILED, ExceptionUtils.getStackTrace(e));
		}
	}
	
	private static void processResendAEList() {
		for (AutoenrollmentObj record : resendAEList) {
			//MPIN, TIN, FILENAME, CORPMPIN
			String mpin = !record.getMpin().equals(null) ? record.getMpin() : "";
			String tin = !record.getTin().equals(null) ? record.getTin() : "";
			String fileName = !record.getFileName().equals(null) ? record.getFileName() : "";
			String corpMpin = !record.getCorpMpin().equals(null) ? record.getCorpMpin() : "";
			List<String> retryAuto = Arrays.asList(mpin, tin, fileName, corpMpin);
			digiSecGetExecutorService.execute(new getDigiSecEmailRequest(retryAuto));
		}
	}

//	public static ChannelSftp getInstance(Channel channel) {
//		if (channel instanceof ChannelSftp) {
//			return (ChannelSftp) channel;
//		}
//		return null;
//	}
}