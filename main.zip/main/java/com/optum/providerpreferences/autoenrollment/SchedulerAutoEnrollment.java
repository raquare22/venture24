package com.optum.providerpreferences.autoenrollment;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.service.OptOutServiceImpl;

@Component
@ConfigurationProperties(prefix = "spring.datasource")
@ConditionalOnProperty(name = "SCHEDULER_AUTO_ENROLLMENT", havingValue = "true")
public final class SchedulerAutoEnrollment {

	private SchedulerAutoEnrollment() {
		//private constructor to hide public one
	}
	private static Logger logger = LogManager.getLogger(SchedulerAutoEnrollment.class);
	private static final String DIRECTORY_LISTING = "directoryListing";
	private static final String CHANNEL_SFTP = "channelSftp";
	private static final String SFTP_SESSION = "sftpSession";
	private static final String CHANNEL = "channel";
	private static final String FILE_EXTENSION = ".csv";

	private static final String PRUN_HOST = "prunhost";
	private static final String PRUN_USERNAME = "userName";
	private static final String PRUN_KEY = "prunPassword";
	private static final String LOCAL_DIRECTORY_STRING = "localDirectory";

	private static String prunHost="PRUN_HOST";
	private static String prunKey="PRUN_PASSWORD";
	private static String prunUserName="PRUN_USERNAME";
		
	private static final String retryWorkingDirec = "RETRY_WORKING_DIRECTORY";
	private static final String retryProcessedDirec = "RETRY_PROCESSED_DIRECTORY";
	private static final String MISSING_SFTP = "Scheduler : processFiles - Missing some of the sftp credentials";
	private static final String PROCESSFILES_EXCEPTION = "Exception while processFiles  {}={}, {}={}, {}={}, {}={}, {}={} {}";

	private static final String PRUN_WORKING_DIRECTORY = "PRUN_AUTO_ENROLLMENT_WORKING_DIRECTORY";
	private static final String PRUN_DESTINATION_DIRECTORY = "PRUN_AUTO_ENROLLMENT_DESTINATION_DIRECTORY";
	private static final String PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY="PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY";
	private static final String SPLIT_CSV_PER_MAX_MB_SIZE = "SPLIT_CSV_PER_MAX_MB_SIZE";
	private static final String SPLIT_MAX_BYTES_NEW_LINE_WITHIN = "SPLIT_MAX_BYTES_NEW_LINE_WITHIN";
	
	private static final int SPLIT_PER_MB_SIZE_DEFAULT = 20;
	private static final int MAX_BYTES_NEWLINE_WITHIN_DEFAULT = 256;
	
    public static AtomicInteger getCount = new AtomicInteger(0);
    public static AtomicInteger postCount = new AtomicInteger(0);
    public static AtomicInteger emailCount = new AtomicInteger(0);
    public static AtomicInteger emailNotFound = new AtomicInteger(0);
    static AtomicInteger lastSchedulerCount = new AtomicInteger(0);

	static AtomicBoolean lock = new AtomicBoolean(false);

	@Autowired
	NDBHandler ndbHandler;

	@Autowired
	OptOutServiceImpl optOutService;

	private static final String LOCAL_DIRECTORY;
	static {
		String path = String.join(File.separator, System.getProperty("user.home"), "auto_enrollment");
		File directory = new File(path);
		if (! directory.mkdir()) {
			logger.error("Failed: mkdir={}", path);
		}
		LOCAL_DIRECTORY = path;
	}

	// Pickup dropped files:
	// PRUN_AUTOENROLLMENT_WORKING_DIRECTORY=/dropzone/prod/autoenrollment
	// Partition CSV, if needed, and move to following for processFiles:
	// PRUN_AUTOENROLLMENT_DESTINATION_DIRECTORY=/dropzone/prod/autoenrollment/processFiles
	// When processFiles completes move to:
	// PRUN_AUTOENROLLMENT_ARCHIVE_DIRECTORY=/dropzone/prod/autoenrollment/processed

	// default = "0 0,15,30,45 0-6,20-23 * * MON-FRI")
	@Scheduled(cron = "${SCHEDULER_AUTO_ENROLLMENT_WEEKDAY_CRON}")
	public static void pollCSVFilesWeekdays() {	
		executeScheduledJob("Weekday");
	}

	// default = "0 0,15,30,45 0-23 * * SAT,SUN"
	@Scheduled(cron = "${SCHEDULER_AUTO_ENROLLMENT_WEEKEND_CRON}")
	public static void pollCSVFilesWeekends() {
		executeScheduledJob("Weekend");
	}

	private static void executeScheduledJob(String identifier) {
		

		try {
			
			logger.debug("lastSchedulerCount={}, postCount={}, emailCheck size={}, getCount size={}, postCount size={}", 
					lastSchedulerCount, postCount, emailCount, getCount, postCount);
			if (lock.get()) { 
				if (lastSchedulerCount.get() != 0 && postCount.get() != 0 && lastSchedulerCount.get() == postCount.get()) {
					if (postCount.get() == getCount.get()) {
						logger.warn("Counts matched, restarting scheduler, getCount={}, postCount={}", getCount, postCount);
					}
					else {
						logger.warn("Counts got stuck, restarting scheduler, getCount={}, postCount={}", getCount, postCount);
					}
					lock.set(false);
					getCount.set(0);
				    postCount.set(0);
				    emailCount.set(0);
				    lastSchedulerCount.set(0);
				}
				else {
					logger.info("Count do not match, still processing posts, lastSchedulerCount={},  getCount={}, postCount={}",lastSchedulerCount, getCount, postCount);
					return;
				}
			}
			
			if (lock.get()) {
				logger.info("Skipping {}: Scheduler already locked and running", identifier);
				return;
			}
			
			lock.set(true);
//			logger.info("Start {} Scheduler", identifier);
			if (SftpUtil.exceptionForMissingLoginCredential(System.getenv(prunHost), System.getenv(prunUserName),
					System.getenv(prunKey), System.getenv(PRUN_WORKING_DIRECTORY))) {
				logger.warn("Scheduler : pollCSVFiles - Missing some of the sftp credentials");
				lock.set(false);
				return;
			}
			if (! createNewDirectoryAndMoveFiles(PRUN_WORKING_DIRECTORY, PRUN_DESTINATION_DIRECTORY)) {
				logger.debug("Done {} Scheduler; No work to do", identifier);
				lock.set(false);
				return;
			}
			processFiles();
			createNewDirectoryAndMoveFiles(PRUN_DESTINATION_DIRECTORY, PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY);
		} catch (IOException e) {
			logger.error("pollCSVFiles {}={}, {}={}, {}={}, {}={} {}", PRUN_HOST, System.getenv(prunHost),
				PRUN_USERNAME, System.getenv(prunUserName), PRUN_KEY, System.getenv(prunKey),
				PRUN_WORKING_DIRECTORY, System.getenv(PRUN_WORKING_DIRECTORY), ExceptionUtils.getStackTrace(e));
		} finally {
			lastSchedulerCount.set(postCount.get());
//			logger.info("Done {} Scheduler", identifier);
		}
		
	}
	
	@SuppressWarnings("unchecked") // Thursday before processsing
	@Scheduled(cron = "${SCHEDULER_RETRY_CRON}")
	public static void pollRetry() {
		
		if (lock.get()) {
			return;
		}
		else {
			try {
				if (!SftpUtil.exceptionForMissingLoginCredential(System.getenv(prunHost), System.getenv(prunUserName),
						System.getenv(prunKey), retryWorkingDirec)) {
					processRetry();
				} else {
					logger.warn("Scheduler : pollCSVFiles - Missing some of the sftp credentials");
				}
			} catch (IOException e) {
				logger.error("pollCSVFiles  {}={}, {}={}, {}={}, {}={} {}", PRUN_HOST, System.getenv(prunHost),
						PRUN_USERNAME, System.getenv(prunUserName), PRUN_KEY, System.getenv(prunKey),
						"retryWorkingDirec", retryWorkingDirec, ExceptionUtils.getStackTrace(e));
			}
			finally {
				lock.set(false);
			}
		}

	}
	
	private static void processRetry() {

		Map<String, Object> sftpResult = null;
		
		try {
			lock.set(true);
			
			if (SftpUtil.exceptionForMissingLoginCredential(System.getenv(prunHost), System.getenv(prunUserName),
					System.getenv(prunKey), System.getenv(retryWorkingDirec))) {
				logger.warn(MISSING_SFTP);
				throw new IOException();
			}
			//retryProcessedDirec
			
			sftpResult = SftpUtil.sftpDirectory(System.getenv(prunUserName), System.getenv(prunKey),
					System.getenv(prunHost), System.getenv(retryWorkingDirec));
			 
			for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult
					.get(DIRECTORY_LISTING)) {
				try {

						String fileName = entry.getFilename();
						if (fileName.endsWith(FILE_EXTENSION)) {
							
							logger.info("Processing File {}", fileName);
							List<String> data = SftpUtil.readRetryData(System.getenv(retryWorkingDirec),
									LOCAL_DIRECTORY, fileName, sftpResult, true);
							
							String originPath = String.join(File.separator, System.getenv(retryWorkingDirec), fileName);
							String destPath = String.join(File.separator, System.getenv(retryProcessedDirec), fileName);
							SftpUtil.rename((ChannelSftp) sftpResult.get(CHANNEL_SFTP), originPath, destPath, true);
							
						}
					
				} catch (IOException | ApplicationException e) {
					logger.error("Exception while processFiles  {}={}, {}={}, {}={}, {}={}, {}={}, {}", PRUN_HOST,
							System.getenv(prunHost), PRUN_USERNAME, System.getenv(prunUserName), PRUN_KEY,
							System.getenv(prunKey), retryWorkingDirec,
							System.getenv(retryWorkingDirec), LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
							ExceptionUtils.getStackTrace(e));
				} 
			} 
		} catch (IOException | JSchException | SftpException e) {
			lock.set(false);

			logger.error(PROCESSFILES_EXCEPTION, PRUN_HOST,
					System.getenv(prunHost), PRUN_USERNAME, System.getenv(prunUserName), PRUN_KEY,
					System.getenv(prunKey), retryWorkingDirec,
					System.getenv(retryWorkingDirec), LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
					ExceptionUtils.getStackTrace(e));
		}
		finally {
			lock.set(false);

			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
						(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
			}
		}
		
		
	}

	private static boolean createNewDirectoryAndMoveFiles(String directoryFromEnv, String directoryToEnv) {
		logger.debug("createNewDirectoryAndMoveFiles: directoryFromEnv={}, directoryToEnv={}", directoryFromEnv, directoryToEnv);
		Map<String, Object> sftpResult = null;
		String directoryFrom = System.getenv(directoryFromEnv);
		try {
			if (! PRUN_WORKING_DIRECTORY.equals(directoryFromEnv)) {
				String dateString = SftpUtil.createDateintoString();
				directoryFrom = directoryFrom + File.separator + dateString;
				String directoryTo = System.getenv(directoryToEnv);
				sftpResult = SftpUtil.sftpDirectory(System.getenv(prunUserName), System.getenv(prunKey), System.getenv(prunHost), directoryFrom);
				logger.debug("createNewDirectoryAndMoveFiles: {} != {}; directoryFrom={}, directoryTo={}", PRUN_WORKING_DIRECTORY, directoryFromEnv, directoryFrom, directoryTo);
				String renameSuccess = SftpUtil.readFileFromServer(directoryTo, sftpResult, directoryFrom, true);
				if (renameSuccess.length() > 0) {
					String[] resendSplit = renameSuccess.split(File.separator); // originalPath + fileName with / separator
					SftpUtil.removeFileFromSFTPLocation(System.getenv(prunUserName), System.getenv(prunKey),
							System.getenv(prunHost), Integer.parseInt(System.getenv("PRUN_PORT")), resendSplit[0], resendSplit[1]);
				}
				return true;
			}

			String directoryTo = System.getenv(directoryToEnv);
			logger.debug("createNewDirectoryAndMoveFiles: {} == {}; directoryFrom={}, directoryTo={}", PRUN_WORKING_DIRECTORY, directoryFromEnv, directoryFrom, directoryTo);
			sftpResult = SftpUtil.sftpDirectory(System.getenv(prunUserName), System.getenv(prunKey), System.getenv(prunHost), directoryFrom);
			String splitPerMbSizeStr = System.getenv(SPLIT_CSV_PER_MAX_MB_SIZE);
			String maxBytesNewLineWithinStr = System.getenv(SPLIT_MAX_BYTES_NEW_LINE_WITHIN);
			int splitPerMbSize = SPLIT_PER_MB_SIZE_DEFAULT;
			int maxBytesNewLineWithin = MAX_BYTES_NEWLINE_WITHIN_DEFAULT;
			try {
				splitPerMbSize = Integer.parseInt(splitPerMbSizeStr);
				maxBytesNewLineWithin = Integer.parseInt(maxBytesNewLineWithinStr);
			} catch(NumberFormatException e) {
				logger.error("Exception: Defaulting splitPerMbSize={}, maxBytesNewLineWithin={}; {}", splitPerMbSize, maxBytesNewLineWithin, e.getMessage());
			}
			Map<String, Long> fileSizeMap = SftpUtil.readFileFromServerCheckSize(directoryTo, sftpResult, directoryFrom);
			if (fileSizeMap.isEmpty()) {
				return false;
			}
			Map<String, Long> splitFileMap = SftpUtil.getFilesToSplit(splitPerMbSize, fileSizeMap);
			if (! splitFileMap.isEmpty()) {
				splitFiles(splitPerMbSize, maxBytesNewLineWithin, splitFileMap);
			}
			return true;
		} catch (JSchException | SftpException e) {
			logger.error("createNewDirectoryAndMoveFiles: {}={}, {}={}, {}={}, {}={} {}", PRUN_HOST, System.getenv(prunHost),
				PRUN_USERNAME, System.getenv(prunUserName), PRUN_KEY, System.getenv(prunKey),
				directoryFromEnv, directoryFrom, ExceptionUtils.getStackTrace(e));
			return false;
		} finally {
			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP), (Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
//				logger.info("End of createNewDirectoryAndMoveFiles: finally method - sftp connection closed");
			}
		}
	}

	protected static void splitFiles(int splitPerMbSize, int maxBytesNewLineWithin, Map<String, Long> splitFileMap) {
		try {
			String destinationPath = System.getenv(PRUN_DESTINATION_DIRECTORY) + File.separator + SftpUtil.createDateintoString();
			logger.info("Start of splitFiles: splitFileMap={}, destinationPath={}", splitFileMap, destinationPath);
			if (! SftpUtil.exceptionForMissingLoginCredential(System.getenv(prunHost), System.getenv(prunUserName), System.getenv(prunKey), destinationPath)) {
				checkAndSplit(destinationPath, splitPerMbSize, maxBytesNewLineWithin, splitFileMap);
			}
		} catch (IOException e) {
			logger.error("Exception splitFiles: {}={}, {}={}, {}={}, {}={}, {}={} {}", PRUN_HOST,
				System.getenv(prunHost), PRUN_USERNAME, System.getenv(prunUserName), PRUN_KEY,
				System.getenv(prunKey), PRUN_DESTINATION_DIRECTORY,
				System.getenv(PRUN_DESTINATION_DIRECTORY), LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
				ExceptionUtils.getStackTrace(e));
		}
	}

	protected static void checkAndSplit(String destinationPath, int splitPerMbSize, int maxBytesNewLineWithin, Map<String, Long> fileSizeMap) {
		Map<String, Object> sftpResult = null;
		try {
			sftpResult = SftpUtil.sftpDirectory(System.getenv(prunUserName), System.getenv(prunKey), System.getenv(prunHost), destinationPath);
			for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING)) {
				String fileName = entry.getFilename();
				if (fileName.endsWith(FILE_EXTENSION)) {
					Long fileSize = fileSizeMap.get(fileName);
					if (fileSize == null) {
						continue;
					}
					String localFile = LOCAL_DIRECTORY + File.separator + fileName;
					logger.info("Splitting file={}, size={}, destinationPath={}, localFile={}", fileName, fileSize, destinationPath, localFile);
					SftpUtil.copyFileToLocal(System.getenv(PRUN_DESTINATION_DIRECTORY), LOCAL_DIRECTORY, fileName, sftpResult);
					List<Path> pathList = SftpUtil.splitFilePerMbPerNewLine(localFile, splitPerMbSize, maxBytesNewLineWithin, LOCAL_DIRECTORY, false);
					if (! pathList.isEmpty()) {
						for (Path path : pathList) {
							logger.info("Copying file from local to server: file={}", path.toFile().getPath());
							SftpUtil.movefileFromlocalToServer(path.toFile().getPath(), sftpResult, System.getenv(PRUN_DESTINATION_DIRECTORY));
							SftpUtil.checkFileExistsOrNot(path.toFile().getName(), LOCAL_DIRECTORY);
						}
						SftpUtil.removeFileFromServer(sftpResult, System.getenv(PRUN_DESTINATION_DIRECTORY), fileName);
						SftpUtil.checkFileExistsOrNot(fileName, LOCAL_DIRECTORY);
					}
				}
			}
		}
		catch (IOException | JSchException | SftpException  e) {
			logger.error("Exception while processFiles  {}={}, {}={}, {}={}, {}={}, {}={},{}={} {}", PRUN_HOST,
					System.getenv(prunHost), PRUN_USERNAME, System.getenv(prunUserName), PRUN_KEY,
					System.getenv(prunKey), PRUN_DESTINATION_DIRECTORY,
					System.getenv(PRUN_DESTINATION_DIRECTORY), LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
					"destinationPath", destinationPath, ExceptionUtils.getStackTrace(e));
		} finally {
			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
						(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
				logger.info("Processing Files finally method -sftp connection closed");
				logger.info("End of Scheduler : processFiles");
			}
		}
	}

	@SuppressWarnings("unchecked")
	private static void processFiles() {
		logger.debug("Start of Scheduler : processFiles");
		Map<String, Object> sftpResult = null;
		try {
			String destinationPath = System.getenv(PRUN_DESTINATION_DIRECTORY) + File.separator + SftpUtil.createDateintoString();
			if (!SftpUtil.exceptionForMissingLoginCredential(System.getenv(prunHost), System.getenv(prunUserName), System.getenv(prunKey), destinationPath)) {
				
				sftpResult = SftpUtil.sftpDirectory(System.getenv(prunUserName), System.getenv(prunKey), System.getenv(prunHost), destinationPath);
				for (ChannelSftp.LsEntry entry : (ArrayList<ChannelSftp.LsEntry>) sftpResult.get(DIRECTORY_LISTING)) {
					try {
						String fileName = entry.getFilename();
						if (fileName.endsWith(FILE_EXTENSION)) {
							logger.info("Processing File {}", fileName);
							List<String> data = SftpUtil.readFileStoreData(System.getenv(PRUN_DESTINATION_DIRECTORY),
									LOCAL_DIRECTORY, fileName, sftpResult, false);
							SftpUtil.readFileSendAutoEnroCloud(data);
							logger.info("data list size={}", data.size());
							logger.info("emailCheck size={}", emailCount);
							logger.info("getCount size={}", getCount);
							logger.info("postCount size={}", postCount);
							
//							String originPath = String.join(File.separator, System.getenv(PRUN_DESTINATION_DIRECTORY), fileName);
//							String destPath = String.join(File.separator, System.getenv(PRUN_AUTO_ENROLLMENT_ARCHIVE_DIRECTORY), fileName);
//							SftpUtil.rename((ChannelSftp) sftpResult.get(CHANNEL_SFTP), originPath, destPath, true);
							
						}
						// Scheduled check after large oneshots, currently commented out and is being done manually for monitoring
//						scheduler.scheduledCheckAutoenrollment(String.join(destinationPath));


					} catch (IOException | ApplicationException e) {
						logger.error("Exception while processFiles  {}={}, {}={}, {}={}, {}={}, {}={},{}={} {}", PRUN_HOST,
								System.getenv(prunHost), PRUN_USERNAME, System.getenv(prunUserName), PRUN_KEY,
								System.getenv(prunKey), PRUN_DESTINATION_DIRECTORY,
								System.getenv(PRUN_DESTINATION_DIRECTORY), LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
								"destinationPath", destinationPath, ExceptionUtils.getStackTrace(e));
					} 
				} 
				
			} else {
				logger.warn(MISSING_SFTP);
			}
		} catch (IOException | JSchException | SftpException e) {
			logger.error(PROCESSFILES_EXCEPTION, PRUN_HOST,
					System.getenv(prunHost), PRUN_USERNAME, System.getenv(prunUserName), PRUN_KEY,
					System.getenv(prunKey), PRUN_DESTINATION_DIRECTORY,
					System.getenv(PRUN_DESTINATION_DIRECTORY), LOCAL_DIRECTORY_STRING, LOCAL_DIRECTORY,
					ExceptionUtils.getStackTrace(e));
		}
		finally {
			if (sftpResult != null) {
				SftpUtil.closeSFTPChannel((ChannelSftp) sftpResult.get(CHANNEL_SFTP),
						(Session) sftpResult.get(SFTP_SESSION), (Channel) sftpResult.get(CHANNEL));
				logger.info("Processing Files finally method -sftp connection closed");
				logger.info("End of Scheduler : processFiles");
			}
		}
	}
	
	
}
