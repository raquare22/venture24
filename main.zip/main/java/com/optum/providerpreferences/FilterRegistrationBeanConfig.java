package com.optum.providerpreferences;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterRegistrationBeanConfig {

    private final StargateJWTFilter jwtFilter;

    public FilterRegistrationBeanConfig(StargateJWTFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }

    @Bean
    public FilterRegistrationBean<StargateJWTFilter> jwtFilterRegistration() {
        FilterRegistrationBean<StargateJWTFilter> registrationBean = new FilterRegistrationBean<>();
        registrationBean.setFilter(jwtFilter);
        registrationBean.addUrlPatterns("/api/providers/v1/*"); // Define URL patterns
        registrationBean.setOrder(1); // Set filter order
        return registrationBean;
    }
}