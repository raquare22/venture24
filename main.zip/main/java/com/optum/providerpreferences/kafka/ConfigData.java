package com.optum.providerpreferences.kafka;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class ConfigData {
	public static String appAskid;

	public static String producerType;

	public static String appname;

	public  static String devicevendor;

	public  static String deviceproduct;

	public static String tag;

	public static String brokerlist;

	public static  String kafkatopic;

	public static String kafkaKeypass;

	public static  String kafkaKeystorepass;

	public static  String kafkaclientId;

	public static String Kafkaprotocol;

	public static String kafkaKeyStorepath;

	public static boolean enableNess;


	@Value("${nk.brokers}")
	public void setBrokerList(String brokerList) {
		brokerlist = brokerList;
	}

	@Value("${nk.topic}")
	public void setKafkaTopic(String kafkaTopic) {
		kafkatopic = kafkaTopic;
	}

	@Value("${nk.kafkaKeyPass}")
	public void setKafkaKeyPass(String kafkaKeyPass) {
		kafkaKeypass = kafkaKeyPass;
	}

	@Value("${nk.kafkaKeystorePass}")
	public void setKafkaKeystorePass(String kafkaKeystorePass) {
		kafkaKeystorepass = kafkaKeystorePass;
	}

	@Value("${tags}")
	public void setTags(String tags) {
		tag = tags;
	}

	@Value("${nk.askId}")
	public void setAppAskId(String appAskId) {
		appAskid = appAskId;
	}

	@Value("${nk.appName}")
	public void setAppName(String appName) {
		appname = appName;
	}

	@Value("${nk.vendor}")
	public void setDeviceVendor(String deviceVendor) {
		devicevendor = deviceVendor;
	}

	@Value("${nk.product}")
	public void setDeviceProduct(String deviceProduct) {
		deviceproduct = deviceProduct;
	}

	@Value("${nk.clientId}")
	public void setKafkaClientId(String kafkaClientId) {
		kafkaclientId = kafkaClientId;
	}

	@Value("${nk.protocol}")
	public void setKafkaProtocol(String kafkaProtocol) {
		Kafkaprotocol = kafkaProtocol;
	}

	@Value("${nk.kafkaKeyStorePath}")
	public void setKafkaKeyStorePath(String kafkaKeyStorePath) {
		kafkaKeyStorepath = kafkaKeyStorePath;
	}

	@Value("${nk.producerType}")
	public void setProducerType(String producerType) {
		ConfigData.producerType = producerType;
	}
	@Value("${feature.toggle.ness}")
	public void setEnableNess(boolean enableNess)
	{
		ConfigData.enableNess = enableNess;
	}


	public boolean getEnableNess() { return enableNess; }
}