package com.optum.providerpreferences.kafka;

import com.optum.eis.event.model.environment;
import com.optum.eis.event.model.logClass;
import com.optum.eis.event.model.outcome;
import com.optum.eis.event.model.severity;
import com.optum.eis.kraken.core.NessLog;
import com.optum.eis.kraken.core.constants.RequiredFieldsConstants;
import com.optum.eis.kraken.kafka.producers.NessKafkaAsyncProducer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class NessAppLog {
	private static final Logger LOGGER = LogManager.getLogger(NessAppLog.class);

	protected static final Properties requiredFields = getDefaultProperties();

	protected static KafkaProducer kafkaProducer;
	protected static NessKafkaAsyncProducer kafkaAsyncProducer;
	protected static environment applicationEnvironment;
	protected static boolean shutdown = false;

	private NessAppLog() {}

	public static Properties getDefaultProperties() {
		Properties requiredFields = new Properties();
		// Setting required fields for the NessLog
		requiredFields.put(RequiredFieldsConstants.APPLICATION_ASK_ID, ConfigData.appAskid);
		requiredFields.put(RequiredFieldsConstants.APPLICATION_NAME, ConfigData.appname);
		requiredFields.put(RequiredFieldsConstants.DEVICE_VENDOR, ConfigData.devicevendor);
		requiredFields.put(RequiredFieldsConstants.DEVICE_PRODUCT, ConfigData.deviceproduct);

		if (kafkaAsyncProducer == null) {
			try {
				kafkaProducer = new com.optum.providerpreferences.kafka.KafkaProducer(); // ✅ correct class
				kafkaAsyncProducer = kafkaProducer.getNewNessKafkaAsyncProducer();
			} catch (Exception e) {
				// ✅ Prevent test crash
				kafkaAsyncProducer = null;
			}
		}

		return requiredFields;
	}

	protected static NessLog.NessLogBuilder getNessLogBuilder() {
		return new NessLog.NessLogBuilder()
				.setRequiredFields(requiredFields)
				.setReceivedTime(System.currentTimeMillis())
				.setApplicationEnvironment(applicationEnvironment)
				.setSeverity(severity.INFO)
				.setLogClass(logClass.SECURITY_AUDIT);
	}

	public static void startup() {
		NessLog nessLog = getNessLogBuilder().setMsg("SystemStart:SUCCESS").buildLog();
		LOGGER.info("{}", nessLog.getLog());
		publishLog(nessLog);
	}

	public static void shutdown() {
		NessLog nessLog = getNessLogBuilder().setMsg("SystemStop:SUCCESS").buildLog();
		LOGGER.info("{}", nessLog.getLog());
		publishLog(nessLog);
		shutdown = true;
		LOGGER.warn("SHUTDOWN: true");
		if (kafkaAsyncProducer != null) {
			LOGGER.warn("Closing the kafkaAsyncProducer");
			kafkaAsyncProducer.closeNessAsyncProducer();

		}

	}

	public static void createHttpLogEvent(HttpHeaders headers, String message, String response) {
		createHttpLogEvent(headers, message, response, true);
	}

	public static void createHttpLogEvent(HttpHeaders headers, String message, String response, boolean success) {
		if (KafkaProducer.getSetUp()) {
			NessLog.NessLogBuilder logBuilder = getNessLogBuilder().setMsg("Message received: " + message);
			if (success) {
				logBuilder.setOutcome(outcome.SUCCESS);
				logBuilder.setReason("responseSize=" + response.length());
			} else {
				logBuilder.setOutcome(outcome.FAILURE);
				logBuilder.setReason("response=" + response);
			}

			InetSocketAddress host = headers.getHost();
			if (host != null) {
				logBuilder.setSourceHostHostname(host.getHostName());
				logBuilder.setSourceHostPort(host.getPort());
			}
			NessLog nessLog = logBuilder.buildLog();
			LOGGER.debug("{}", nessLog.getLog());
			publishLog(nessLog);
		}
	}

	public static void createHttpLogEvent(HttpHeaders headers, String message, ResponseEntity<?> responseEntity) {
		if (KafkaProducer.getSetUp()) {

			NessLog.NessLogBuilder logBuilder = getNessLogBuilder().setMsg("Message received: " + message);
			if (responseEntity != null && responseEntity.getStatusCode().is2xxSuccessful()) {
				logBuilder.setOutcome(outcome.SUCCESS);
				logBuilder.setReason("responseSize=" + Integer.toString(responseEntity.toString().length()));
			} else {
				logBuilder.setOutcome(outcome.FAILURE);
				String responseEntityString = responseEntity != null ? responseEntity.getStatusCode().toString() : "NULL";
				logBuilder.setReason("response=" + responseEntityString);
			}
			InetSocketAddress host = headers.getHost();
			if (host != null) {
				logBuilder.setSourceHostHostname(host.getHostName());
				logBuilder.setSourceHostPort(host.getPort());
			}
			NessLog nessLog = logBuilder.buildLog();
			LOGGER.debug("{}", nessLog.getLog());
			publishLog(nessLog);
		}
	}

	protected static void publishLog(NessLog nessLog ) {
		if (shutdown) {
			LOGGER.warn("SHUTDOWN: return");
			return;
		}
		if (kafkaAsyncProducer != null) {
			kafkaAsyncProducer.publishNessLogsAsync(nessLog);
		}
	}
}