package com.optum.providerpreferences.kafka;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.optum.eis.kraken.core.exceptions.NessLoggerValidationException;
import com.optum.eis.kraken.kafka.producers.NessKafkaAsyncProducer;
import com.optum.eis.kraken.kafka.producers.NessKafkaProducer;

public class KafkaProducer {
	private static final Logger LOGGER = LogManager.getLogger(KafkaProducer.class);
	private static boolean setUp = ConfigData.enableNess;
	private static final String NULL = "NULL";
	private static final String NOT_NULL = "! NULL";

	protected NessKafkaAsyncProducer nessKafkaAsyncProducer = null;

	public static void setUpOff() {
		setUp = false;
	}

	public static boolean getSetUp() {
		return setUp;
	}

	public NessKafkaAsyncProducer getNewNessKafkaAsyncProducer()
	{

		nessKafkaAsyncProducer = getKafkaProducer();
		return nessKafkaAsyncProducer;

	}

	protected NessKafkaAsyncProducer getKafkaProducer() {
		LOGGER.info("Creating NessKafkaAsyncProducer with ConfigData: kafkaKeyStorepath={}, brokerlist={}, kafkatopic={}, kafkaclientId={}, Kafkaprotocol={}",
				ConfigData.kafkaKeyStorepath, ConfigData.brokerlist, ConfigData.kafkatopic, ConfigData.kafkaclientId, ConfigData.Kafkaprotocol);
		LOGGER.info("kafkaKeystorepass: {}", ConfigData.kafkaKeystorepass != null ? "is set" : "Not Set");
		LOGGER.info("kafkaKeypass: {}", ConfigData.kafkaKeypass != null ? "is set" : "Not Set");

		NessKafkaAsyncProducer.NessKafkaAsyncProducerBuilder kafkaProducerBuilder =
				new NessKafkaAsyncProducer.NessKafkaAsyncProducerBuilder()
						.setKafkaBrokerList(ConfigData.brokerlist)
						.setKafkaTopic(ConfigData.kafkatopic)
						.setKafkaKeyPassword(ConfigData.kafkaKeypass)
						.setKafkaKeystoreLocation(ConfigData.kafkaKeyStorepath)
						.setKafkaKeystorePassword(ConfigData.kafkaKeystorepass)
						.setKafkaClientId(ConfigData.kafkaclientId)
						.setKafkaProtocol(ConfigData.Kafkaprotocol);

		return kafkaProducerBuilder.buildNessAsyncProducer();
	}
}