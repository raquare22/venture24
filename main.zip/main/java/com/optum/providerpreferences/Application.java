package com.optum.providerpreferences;

import com.optum.providerpreferences.kafka.ConfigData;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.kafka.NessAppLog;
import com.optum.providerpreferences.rs.handler.RequestFactory;



@EnableAutoConfiguration
@SpringBootApplication
@EnableScheduling
public class Application
{

    private static Logger logger = LogManager.getLogger(Application.class);

    @Bean
    public ObjectMapper getMapper()
    {
        return new ObjectMapper();
    }


    @Bean
    public HttpHeaders getHttpHeaders()
    {
        return new HttpHeaders();
    }

    public static void main(String[] args)
    {
        SpringApplication application = new SpringApplication(Application.class);
        application.addListeners(new AppListener());
        application.run(args);
        if(ConfigData.enableNess) {
            NessAppLog.startup();
        }

    }
}