package com.optum.providerpreferences.rs.mongo.document;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "deliveryPreference")
public class DeliveryPreference {

	@Id
	private String id;
	private String classifier;
	private String tin;
	private String mpin;
	private String corporateMpin;
	private String tinType;
	private String lob;
	private String description;
	private String documentId;
	private String deliveryMethod;
	private String okToChangePdoInd;
	private String subscribeToEmail;
	private String providerEmailId;
	private Date dateCreated;
	private Date dateModified;
	private String fileName;
	private String activeDate;
	private String corpMpin;
	private String okTochangePDOInd;
	private String autoEdelUpdateInd;
	private String fileType;
	private String frequency;
	private String lastUpdatedBy;
	private String lastUpdatedById;
	private Integer optedOutDuration;
	private String optedOutDateTime;
	private String expiryDate;
	private Long expiryDateEpoch;
	private String autoOptOutInd;
	private Object searchTerms;
	private String spaceId;
	private Long modifiedOn;
	private String modifiedBy;
	private String createdBy;
	private Long createdOn;
	private String metadata;
	private String externalId;
	private List<Object> attachments;
	private String workflow;
	private String accessToken;
	private String status;
	private String transactionId;
	private String onPremSpaceId;
	private String onPremRecordType;
	private String providerName;
	private String lastOONPopUpDate;
	private List<String> secondaryProviderEmailIds;
	private String oonModalFlag;

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getLastOONPopUpDate() {
		return lastOONPopUpDate;
	}

	public void setLastOONPopUpDate(String lastOONPopUpDate) {
		this.lastOONPopUpDate = lastOONPopUpDate;
	}

	public List<String> getSecondaryProviderEmailIds() {
		return secondaryProviderEmailIds;
	}

	public void setSecondaryProviderEmailIds(List<String> secondaryProviderEmailIds) {
		this.secondaryProviderEmailIds = secondaryProviderEmailIds;
	}

	public Object getSearchTerms() {
		return searchTerms;
	}

	public void setSearchTerms(Object searchTerms) {
		this.searchTerms = searchTerms;
	}

	public String getSpaceId() {
		return spaceId;
	}

	public void setSpaceId(String spaceId) {
		this.spaceId = spaceId;
	}

	public Long getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Long modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Long getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Long createdOn) {
		this.createdOn = createdOn;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public List<Object> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<Object> attachments) {
		this.attachments = attachments;
	}

	public String getWorkflow() {
		return workflow;
	}

	public void setWorkflow(String workflow) {
		this.workflow = workflow;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getOnPremSpaceId() {
		return onPremSpaceId;
	}

	public void setOnPremSpaceId(String onPremSpaceId) {
		this.onPremSpaceId = onPremSpaceId;
	}

	public String getOnPremRecordType() {
		return onPremRecordType;
	}

	public void setOnPremRecordType(String onPremRecordType) {
		this.onPremRecordType = onPremRecordType;
	}

	public String getLastUpdatedById() {
		return lastUpdatedById;
	}

	public void setLastUpdatedById(String lastUpdatedById) {
		this.lastUpdatedById = lastUpdatedById;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Integer getOptedOutDuration() {
		return optedOutDuration;
	}

	public void setOptedOutDuration(Integer optedOutDuration) {
		this.optedOutDuration = optedOutDuration;
	}

	public String getOptedOutDateTime() {
		return optedOutDateTime;
	}

	public void setOptedOutDateTime(String optedOutDateTime) {
		this.optedOutDateTime = optedOutDateTime;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Long getExpiryDateEpoch() {
		return expiryDateEpoch;
	}

	public void setExpiryDateEpoch(Long expiryDateEpoch) {
		this.expiryDateEpoch = expiryDateEpoch;
	}

	public String getAutoOptOutInd() {
		return autoOptOutInd;
	}

	public void setAutoOptOutInd(String autoOptOutInd) {
		this.autoOptOutInd = autoOptOutInd;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClassifier() {
		return classifier;
	}

	public void setClassifier(String classifier) {
		this.classifier = classifier;
	}

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		this.mpin = mpin;
	}

	public String getCorporateMpin() {
		return corporateMpin;
	}

	public void setCorporateMpin(String corporateMpin) {
		this.corporateMpin = corporateMpin;
	}

	public String getTinType() {
		return tinType;
	}

	public void setTinType(String tinType) {
		this.tinType = tinType;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getDeliveryMethod() {
		return deliveryMethod;
	}

	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	public String getOkToChangePdoInd() {
		return okToChangePdoInd;
	}

	public void setOkToChangePdoInd(String okToChangePdoInd) {
		this.okToChangePdoInd = okToChangePdoInd;
	}

	public String getSubscribeToEmail() {
		return subscribeToEmail;
	}

	public void setSubscribeToEmail(String subscribeToEmail) {
		this.subscribeToEmail = subscribeToEmail;
	}

	public String getProviderEmailId() {
		return providerEmailId;
	}

	public void setProviderEmailId(String providerEmailId) {
		this.providerEmailId = providerEmailId;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public Date getDateModified() {
		return dateModified;
	}

	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getActiveDate() {
		return activeDate;
	}

	public void setActiveDate(String activeDate) {
		this.activeDate = activeDate;
	}

	public String getCorpMpin() {
		return corpMpin;
	}

	public void setCorpMpin(String corpMpin) {
		this.corpMpin = corpMpin;
	}

	public String getOkTochangePDOInd() {
		return okTochangePDOInd;
	}

	public void setOkTochangePDOInd(String okTochangePDOInd) {
		this.okTochangePDOInd = okTochangePDOInd;
	}

	public String getAutoEdelUpdateInd() {
		return autoEdelUpdateInd;
	}

	public void setAutoEdelUpdateInd(String autoEdelUpdateInd) {
		this.autoEdelUpdateInd = autoEdelUpdateInd;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public void setOonModalFlag(String y) {
		this.oonModalFlag = y;
	}

	public String getOonModalFlag() {
		return oonModalFlag;
	}
}