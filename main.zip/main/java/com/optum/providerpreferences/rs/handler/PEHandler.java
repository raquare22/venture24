package com.optum.providerpreferences.rs.handler;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import org.apache.cxf.jaxrs.utils.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.*;

import java.util.Objects;

@Component
public class PEHandler {

    protected int numRetries = 3;
    protected int timeToWaitMs = 100;

    private static final Logger LOGGER = LogManager.getLogger(PEHandler.class);

    @Autowired
    protected Oauth2Handler oauth2handler;

    private static String successRequest = "Request successful after retries statusCode={}, responseBody={}";
    private static String exceptionRequest = "sendRequest caught exception, throwing error not retrying: uri={}, responseEntity={}, error={}";
    private static String requestRetry = "Request retry: requestBody={}";
    private static String firstRequestFail = "First request failed";
    private static String retryCountStr = "retryCount={}";
    private static String timeToWait = "time to wait={}";
    private static String requestFailed = "Request failed after retries with error code={}, request={}";
    private static String serviceCallError = "ERROR DURING SERVICE CALL: uri={}, requestEntity={}, error={}";
    private static String INVALID_GRANT = "invalid_grant";
    private static String SEND_REQUEST_LOG = "sendRequest caught exception, retrying: uri={}, responseEntity={}, error={}";


    private ApplicationUtil app = new ApplicationUtil();

    @Autowired
    RestTemplate restTemplate;

    public ResponseEntity<?> sendRequestPaymentEngine(String uri, HttpEntity<?> requestEntity, HttpMethod httpMethod) {

        ResponseEntity<?> responseEntity = null;
        String message = "Service sendRequestPaymentEngine: requestEntity=" + requestEntity.getBody().toString();

        LOGGER.info(message);
        try {

            responseEntity = retryRequestPaymentEngine(uri, requestEntity, httpMethod);

            if (checkPaymentEngineResponseEntity(responseEntity)) {
                return responseEntity;
            }

            LOGGER.info(firstRequestFail);

            int retryCount = numRetries;
            while (!checkPaymentEngineResponseEntity(responseEntity) && (retryCount-- > 0)) {

                LOGGER.info(retryCountStr, retryCount);
                LOGGER.info(timeToWait, timeToWaitMs);

                try {
                    synchronized(this) {
                        this.wait(timeToWaitMs);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                responseEntity = retryRequestPaymentEngine(uri, requestEntity, httpMethod);
                LOGGER.warn(requestRetry, Encode.forJava((String) requestEntity.getBody()), retryCount);
            }

            // if responseEntity is null, throw a NullPointerException
            Objects.requireNonNull(responseEntity);

            if (!HttpStatus.OK.equals(responseEntity.getStatusCode())) {
                LOGGER.error(requestFailed, responseEntity.getStatusCode(), Encode.forJava((String) requestEntity.getBody()));
                return responseEntity;
            }

			LOGGER.info(successRequest, responseEntity.getStatusCode(), Encode.forJava((String) requestEntity.getBody()));
            return responseEntity;
        } catch (Exception e) {
            LOGGER.error(serviceCallError, uri, Encode.forJava((String) requestEntity.getBody()), ExceptionUtils.getStackTrace(e));
            throw(e);
        }

    }

    public ResponseEntity<?> retryRequestPaymentEngine(String uri, HttpEntity<?> requestEntity, HttpMethod httpMethod){

        ResponseEntity<?> retryResponse = null;
        try {
            retryResponse = restTemplate.exchange(uri, httpMethod, requestEntity, String.class);
        } catch (HttpServerErrorException e) {
            if (e.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR) && e.getStatusText() == null) {
                LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
                throw(e);
            } else {
                LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, ExceptionUtils.getStackTrace(e));
            }
        } catch (HttpClientErrorException e) {
            if (e.getStatusCode().equals(HttpStatus.BAD_REQUEST) && e.getResponseBodyAsString().contains(INVALID_GRANT)) {
                LOGGER.error("sendRequest caught invalid_grant exception, oauth token expired, retrying: uri={}, responseEntity={}, error={}.",
                        uri, retryResponse, ExceptionUtils.getStackTrace(e));
                throw(e);
            } else {
                LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, ExceptionUtils.getStackTrace(e));
            }
        } catch (ResourceAccessException e) {
            LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, ExceptionUtils.getStackTrace(e));
        } catch (RestClientException e) {
            LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
        } catch (Exception e) {
            LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
            throw(e);
        }

        return retryResponse;

    }

    private static Boolean checkPaymentEngineResponseEntity(ResponseEntity<?> responseEntity) {
        if (responseEntity != null && (HttpStatus.OK.equals(responseEntity.getStatusCode()) || HttpStatus.CREATED.equals(responseEntity.getStatusCode()))) {
            return true;
        }
        return false;
    }



}
