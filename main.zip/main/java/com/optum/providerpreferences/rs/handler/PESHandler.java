package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.pes.PESResponse;
import com.optum.providerpreferences.rs.model.pes.PESTinRequest;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import com.optum.providerpreferences.rs.utility.SanitizeUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;

@Component
public class PESHandler extends ServiceBase {
	
	private static final Logger logger = LogManager.getLogger(PESHandler.class);

	@Autowired
	RestTemplate client;

    @Autowired
    private HttpHeaders headers;
    
    private ApplicationUtil app = new ApplicationUtil();
    
    private Token token = null;

	@Value("${PES_TIN_URL}")
	protected String pesTinUrl;
	
	public PESResponse getTins(PESTinRequest tinRequest, String cid) throws ApplicationException {
		logger.info("PESHandler --> ENTER getTins, tinRequest={}, CID={}", tinRequest, Encode.forJava(cid));
		
		try {
			
			pesWebServicePrep();
			
			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(pesTinUrl);

			HttpEntity<PESTinRequest> requestEntity = new HttpEntity<>(tinRequest, headers);
	        String uri = builder.toUriString();
	        logger.info("Sending request to PES - get tins, requestEntity={}, uri={}, CID={}", Encode.forJava(requestEntity.getBody().toString()), uri, Encode.forJava(cid));
	        ResponseEntity<PESResponse> response = (ResponseEntity<PESResponse>) sendRequest(uri, requestEntity, PESResponse.class, HttpMethod.POST, Encode.forJava(cid));
	        logger.info("Response received from PES - get tins");
	        String success=app.rerSuccess("PES tins response={}");
	        logger.info(success+"CID={}", SanitizeUtil.sanitizeResponseEntityBody(response), Encode.forJava(cid));
	        return response.getBody();
			
		} catch (Exception e) {
			throw new ApplicationException(e.toString());
		}
	}
	
	
    public Token getToken()
    {
        return token;
    }

    public void setToken(Token token)
    {
        this.token = token;
    }
	
	public void pesWebServicePrep() throws IOException, OAuthSystemException, OAuthProblemException, ApplicationException {
        try
        {
            setToken((Token) oauth2handler.getOauthToken("PDO", "PES"));
            
            int retryCount = numRetries;
            while (token == null && (retryCount-- > 0)) {
				
            	logger.info("retryCount={}", retryCount);
				logger.info("time to wait={}", timeToWaitMsArr[retryCount]);
				
				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				setToken((Token) oauth2handler.getOauthToken("PDO", "PES"));
				logger.warn("NDB token request retry: retryCount={}", retryCount);
			}
            
        }
        catch (IOException | OAuthSystemException | OAuthProblemException | ApplicationException e)
        {
            logger.error("Could not retrieve OAuth Token - NDB, error:{}.", ExceptionUtils.getStackTrace(e));
            throw e;
        }
        headers.set("Authorization", "bearer " + getToken().getAccessToken());
        headers.setContentType(MediaType.APPLICATION_JSON);
	}

}
