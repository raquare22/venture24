/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.handler;

import java.io.IOException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import org.apache.commons.lang3.exception.ExceptionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.TokenAbst;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesRequest;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinRequest;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import com.optum.providerpreferences.rs.utility.SanitizeUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;
/**
 * This handler contains methods to call UPM/AE web services.
 * 
 * @author Provider Paperless Letters
 */
@Component
public class NDBHandler extends ServiceBase
{
	
    @Autowired
    RestTemplate client;


    @Autowired
    private HttpHeaders headers = new HttpHeaders();

    @Autowired
    private ObjectMapper mapper = new ObjectMapper();

    private static final Logger logger = LogManager.getLogger(NDBHandler.class);

    private Token token = null;
    
    private ApplicationUtil app = new ApplicationUtil();
    
    
    @Value("${NDB_LETTER_PREFS}")
    protected String ndbLetterPrefsURL;
    

    @Value("${NDB_CORP_MPIN_URL}")
    protected String ndbCorpMpinURL;


    // Centralized log sanitization
    private static String sanitize(Object input) {
        if (input == null) {
            return "";
        }
        String s = input.toString().replaceAll("[\\r\\n]", "_");
        return Encode.forJava(s);
    }

    public LetterPreferencesResponse getProviderLetterPreferences(com.optum.providerpreferences.rs.model.ndb.preferences.RequestData requestData, String cid)
            throws ApplicationException
    {
        final String safeCid = sanitize(cid);
        try
        {
            ndbWebServicePrep();

            LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
            webRequest.setRequest(requestData);
            webRequest.setRequestHeader(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestHeader("PDO", "PDO", "938", "0"));

            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(ndbLetterPrefsURL);
            HttpEntity<String> requestEntity = new HttpEntity<>(mapper.writeValueAsString(webRequest), headers);

            logger.info("NDB Provider Preferences request: CID={}, request={}", safeCid, sanitize(webRequest));
            String uri = builder.toUriString();
            ResponseEntity<LetterPreferencesResponse> webResponse = (ResponseEntity<LetterPreferencesResponse>) sendRequest(uri, requestEntity, LetterPreferencesResponse.class, HttpMethod.POST, safeCid);
            logger.info("Response received from NDB - Provider Preferences, CID={}", safeCid);
            String success=app.rerSuccess("Response={}");
            logger.info(success + "CID={}", sanitize(webResponse), safeCid);

            return webResponse.getBody();
        }
        catch (Exception e)
        {
            logger.error("NDB Provider Preferences call failed: CID={}, error={}", safeCid, sanitize(e.getMessage()), e);
            throw new ApplicationException(e.toString());
        }
    }

    /**
     * Retrieves Provider data based on a tin and an mpin
     *
     * @param requestData
     * @param cid
     * @return
     * @throws ApplicationException
     */
    public CorpMpinResponse getProviderData(RequestData requestData, String cid)
            throws ApplicationException, IOException, OAuthSystemException, OAuthProblemException, RestClientException
    {
        final String safeCid = sanitize(cid);
        ndbWebServicePrep();

        CorpMpinRequest request = new CorpMpinRequest();
        com.optum.providerpreferences.rs.model.ndb.provider.RequestHeader headerData = new com.optum.providerpreferences.rs.model.ndb.provider.RequestHeader();
        headerData.setApplicationId("Paperless");
        headerData.setClientId("PDO");
        headerData.setSubscriber("Paperless");
        headerData.setCallingEntity("");
        headerData.setUserId("PDO");
        headerData.setUserOfficeCode("938");
        headerData.setLastUpdateTypeCode("lastUpdateTypeCode");

        request.setRequestHeader(headerData);
        request.setRequestData(requestData);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(ndbCorpMpinURL);
        HttpEntity<CorpMpinRequest> requestEntity;
        ResponseEntity<CorpMpinResponse> response = null;
        requestEntity = new HttpEntity<>(request, headers);
        logger.info("Sending request to NDB - Corporate Mpin for CID={}", Encode.forJava(cid));
        String uri = builder.toUriString();
        logger.info("URL={}, CID={}", uri, Encode.forJava(cid));

        try {
            response = (ResponseEntity<CorpMpinResponse>) sendRequest(uri, requestEntity, CorpMpinResponse.class, HttpMethod.POST, safeCid);
        } catch (RestClientException | NullPointerException e) {
            logger.error("NDB Corporate MPIN call failed: CID={}, error={}", safeCid, sanitize(e.getMessage()), e);
            throw e;
        }
        logger.info("NDB Corporate MPIN response received: CID={}", safeCid);
        logger.debug("NDB Corporate MPIN response body: CID={}, body={}", safeCid, sanitize(response));
        return response.getBody();
    }

    public boolean updateProviderLetterPreferences(LetterPreferencesRequest request, String currentMpin, String currentTin, String cid)
    		throws JsonProcessingException, ApplicationException, OAuthProblemException, OAuthSystemException, IOException
    {
        String message = "NDBHandler updateProviderLetterPreferences: currentMpin=" + currentMpin + ", currentTin=" + currentTin;
        try
        {
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(ndbLetterPrefsURL);
            HttpEntity<String> requestEntity = new HttpEntity<>(mapper.writeValueAsString(request), headers);
            logger.info("CID={}, DBrequest={}", Encode.forJava(cid) ,Encode.forJava((String) requestEntity.getBody()));
            logger.info("Sending request to NDB -  Update Provider Preferences - CID={}",Encode.forJava(cid));

            ResponseEntity<LetterPreferencesResponse> webResponse = (ResponseEntity<LetterPreferencesResponse>) sendRequest(

            		builder.toUriString(), requestEntity, LetterPreferencesResponse.class, HttpMethod.POST, request, Encode.forJava(cid));

            Objects.requireNonNull(webResponse);

            if (webResponse.getBody().getResponseHeader().getReturncode().equals("99")) {

            }

            logger.info(app.rerSuccess("Response received from NDB - Update Provider Preferences")+" CID={}",  Encode.forJava(cid));
            if (logger.isInfoEnabled()) {
                logger.info("CID={}, NDBresponse={}, statusCode={}",  Encode.forJava(cid) ,Encode.forJava(webResponse.getBody().toString()),Encode.forJava(webResponse.getStatusCode().toString()));
            }
            if (webResponse.getBody().getResponseHeader().getReturncode().equals("99") || !webResponse.getStatusCode().equals(HttpStatus.OK) && !webResponse.getBody().getResponseHeader().getMessage().equalsIgnoreCase("ALREADY EXIST IN DB"))
            {
            	String failure=app.rerFailure("Failed to make update call to NDB, returncode={}, CID={}-> mpin, tin, fileName, deliveryMethod -> {},{},{},{}");
            	if (logger.isErrorEnabled()) {
            		logger.error(failure,  Encode.forJava(cid) ,Encode.forJava(webResponse.getBody().getResponseHeader().getReturncode()), Encode.forJava(currentMpin),
            				Encode.forJava(currentTin), Encode.forJava(request.getRequest().getLetterTypeList().get(0).toString()), Encode.forJava(request.getRequest().getMailPref()));
            	}
                return false;
            }
        }
        catch (JsonProcessingException | NullPointerException e)
        {
            logger.error("Update Provider Preferences call exception: CID={}, error={}", Encode.forJava(cid), sanitize(e.getMessage()), e);
            throw e;
        }
        return true;
    }

//    public boolean updateProviderLetterPreferences(List<LetterPreferencesRequest> requestList)
//    		throws IOException, OAuthSystemException, OAuthProblemException, ApplicationException
//    {
//        try
//        {
//            ndbWebServicePrep();
//
//            for (LetterPreferencesRequest currentRequest : requestList)
//            {
//                logger.info("UPDATING LETTER TYPE, letterType={}",currentRequest.getRequest().getLetterTypeList().get(0).getLetterType());
//                logger.info("Temp update request, request={}", currentRequest);
//                UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(ndbLetterPrefsURL);
//                HttpEntity<String> requestEntity = new HttpEntity<>(mapper.writeValueAsString(currentRequest), headers);
//                logger.info("Sending request to NDB -  Update Provider Preferences");
//                String message = "NDBHandler updateProviderLetterPreferences list: letterType=" + currentRequest.getRequest().getLetterTypeList().get(0).getLetterType();
//                ResponseEntity<LetterPreferencesResponse> webResponse =
//                        client.exchange(builder.toUriString(), HttpMethod.POST, requestEntity, LetterPreferencesResponse.class);
//                String success=app.rerSuccess("Response received from NDB - Update Provider Preferences");
//                logger.info(success);
//
//                String webStatusCode=webResponse.getStatusCode().toString();
//                logger.info("Response Status={}", webStatusCode);
//                if (!webResponse.getStatusCode().equals(HttpStatus.OK)&&!webResponse.getBody().getResponseHeader().getMessage().equalsIgnoreCase("ALREADY EXIST IN DB"))
//                {
//                    	String error=app.rerFailure("Failed to make update call to NDB for MPIN, mpin={}");
//                        logger.error(error, currentRequest.getRequest().getProviderId());
//                        return false;
//
//                }
//
//            }
//
//        }
//        catch (IOException | OAuthSystemException| OAuthProblemException | ApplicationException e)
//        {
//            logger.error(app.rerFailure("Failed to make NDB web service call - Update Provider Preferences, error={}"), e);
//        }
//        return true;
//
//    }

    public void ndbWebServicePrep()
    		throws IOException, OAuthSystemException, OAuthProblemException, ApplicationException
    {
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd").format(new Date());
        try
        {
            setToken(getOauth2handlerOauthToken("PDO", "NDB"));
            
            int retryCount = numRetries;
            while (token == null && (retryCount-- > 0)) {
				
            	logger.info("retryCount={}", retryCount);
				logger.info("time to wait={}", timeToWaitMsArr[retryCount]);
				
				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				setToken(getOauth2handlerOauthToken("PDO", "NDB"));
				logger.warn("NDB token request retry: retryCount={}", retryCount);
			}
            
        }
        catch (IOException | OAuthSystemException | OAuthProblemException | ApplicationException e)
        {
            logger.error("OAuth token retrieval failed for NDB: error={}", sanitize(e.getMessage()), e);
            throw e;
        }

        headers.set("Authorization", "Bearer " + getToken().getAccessToken());
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("timestamp", timeStamp);
        headers.set("actor", "test");
        headers.set("scope", "read");

    }

    public Token getOauth2handlerOauthToken(String sessionId, String serviceIndicator) throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException {
        return (Token) oauth2handler.getOauthToken(sessionId, serviceIndicator);
    }

    public Token getToken()
    {
        return token;
    }

    public void setToken(Token token)
    {
        this.token = token;
    }
    
    public ResponseEntity<?> sendRequest(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod, LetterPreferencesRequest request, String cid)
    		throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException 
    {
		
		ResponseEntity<?> responseEntity = null;
		HttpEntity<?> reqEntity = requestEntity;
		
		try {
			
			responseEntity = retryRequest(uri, reqEntity, clazz, httpMethod, Encode.forJava(cid));

			if (responseEntity != null && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				if (logger.isInfoEnabled()) {
					logger.info("sendRequestNDB -> Request successful: CID={}, responseEntity={}",Encode.forJava(cid) , sanitize(responseEntity.toString()));
				}
				return responseEntity;
			}
			
			logger.info("sendRequestNDB -> First request failed, retrying for CID= {}",Encode.forJava(cid) );
			
			int retryCount = numRetries;
			while ((responseEntity == null || !HttpStatus.OK.equals(responseEntity.getStatusCode())) && (retryCount-- > 0)) {
				
				logger.info("sendRequestNDB -> CID={}, retryCount={}", Encode.forJava(cid) ,retryCount);
				logger.info("sendRequestNDB -> CID={}, time to wait={}", Encode.forJava(cid) ,timeToWaitMsArr[retryCount]);
				
				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				
				TokenAbst newToken;
				newToken = getOauth2handlerOauthTokenRefresh("PDO", "NDB");
				logger.info("sendRequestNDB -> Request entity change, CID={}, requestEntity={}", Encode.forJava(cid) ,sanitize(reqEntity.getBody()));

				headers.set("Authorization", "Bearer " + newToken.getAccessToken());

				headers.setContentType(MediaType.APPLICATION_JSON);
				logger.info("sendRequestNDB -> New access token added to requestEntity,  CID={}, requestEntity={}", Encode.forJava(cid) ,sanitize(reqEntity.getBody()));
				
				reqEntity = new HttpEntity<String>(mapper.writeValueAsString(request), headers);
				
				logger.info("sendRequestNDB -> Calling retryRequest, uri={}, CID={}, reqEntity={}", uri, Encode.forJava(cid) ,sanitize(reqEntity.getBody()));

				responseEntity = retryRequest(uri, reqEntity, clazz, httpMethod, Encode.forJava(cid));
				logger.warn("sendRequestNDB -> Request retry:  CID={}, requestBody={}, retryCount={}", Encode.forJava(cid) ,sanitize(reqEntity.getBody()), retryCount);
			}
			
			// if responseEntity is null, throw a NullPointerException
			Objects.requireNonNull(responseEntity);
			
			if (!HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				logger.error("sendRequestNDB -> Request failed after retries with error  CID={}, code={}, request={}",  Encode.forJava(cid) ,responseEntity.getStatusCode(), sanitize(reqEntity.getBody()));
				return responseEntity;
			}

			if (logger.isInfoEnabled()) {
				logger.info("sendRequestNDB -> Request successful after retries  CID={}, statusCode={}, responseBody={}",  Encode.forJava(cid) ,responseEntity.getStatusCode(), sanitize(responseEntity.getBody().toString()));
			}
			return responseEntity;
		}
		catch (ApplicationException | OAuthProblemException | OAuthSystemException | IOException e) {
			logger.error("sendRequestNDB -> ERROR DURING SERVICE CALL:  CID={}, uri={}, request={}, reqEntity={}, error={}",  Encode.forJava(cid) ,uri, request, sanitize(reqEntity.getBody()), e);
			throw(e);
		}
	}

    protected TokenAbst getOauth2handlerOauthTokenRefresh(String pdo, String ndb) throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException {
        return oauth2handler.getOauthTokenRefresh("PDO", "NDB");
    }


}
