package com.optum.providerpreferences.rs.handler;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.kafka.NessAppLog;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.PDOConstants;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import com.optum.providerpreferences.rs.mongo.document.DeliveryPreference;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import com.optum.providerpreferences.rs.utility.SanitizeUtil;
import kong.unirest.HttpRequestWithBody;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.json.JSONException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;


@Component
public class FDSCloudHandler extends ServiceBase {
	
    ObjectMapper tempMapper = new ObjectMapper();
    
    @Autowired
    private HttpHeaders headers = new HttpHeaders();
	@Autowired
	RestTemplate newRestTemplate;
    

    private ApplicationUtil app = new ApplicationUtil();
    
    private static final  Logger logger = LogManager.getLogger(FDSCloudHandler.class);
    
    
    @Value("${FDSCLOUD_SPACEID}")
    protected String fdsCloudSpaceId;
    
    @Value("${FDSCLOUD_URL}")
    protected String fdsCloudURL;
    
    
    private static String OAUTH_FAILURE="Failed to make FDS OAUTH service call: ";
//    private static String SPACE_ID = "FDSCLOUD_SPACEID";
//    private static String FDSCLOUD_URL = "FDSCLOUD_URL";
    private static String AUTH_HEADER="fds-authorization";
    private static String SEARCH_TERMS="searchTerms";
    private static String SPACE_ID_QUERY="{spaceId}";
    private static String METADATA_KEY = "metadata";

    
    String failedDocuments=app.rerFailure("Failed to make FDS OAUTH Web Service Call - Get Documents");

    //unused
//    public Map<String, Boolean> FDSCloudDelete(String sessionId, String searchCriteria) throws ApplicationException{
//    	Token token = getFDSCloudToken(sessionId);
//
//    	String uri = fdsCloudURL.concat("/{docId}");
//
//    	String message = "FDSCloudHandler FDSCloudDelete: spaceId=" + fdsCloudSpaceId + ", docId=" + searchCriteria;
//    	HttpResponse<JsonNode> uniResponse = Unirest.delete(uri)
//        		.header(AUTH_HEADER, token.getAccessToken())
//        		.routeParam("spaceId", fdsCloudSpaceId)
//        		.routeParam("docId", searchCriteria)
//        		.asJson();
//
//    	Map<String, Boolean> response = new HashMap<>();
//    	if (!uniResponse.equals(null) && !uniResponse.getBody().equals(null)) {
//    		try {
//    			response = tempMapper.readValue(uniResponse.getBody().toString(), HashMap.class);
//    			if(KafkaProducer.getSetUp()){NessAppLog.createNessLogEvent(message + " Response = " + response.toString());}
//    		} catch (IOException e) {
//    			if(KafkaProducer.getSetUp()){NessAppLog.createNessLogEvent(message + " Exception = " + e.getMessage(), false);}
//    			logger.error("FDSCloudDelete -> Error mapping response, {}", ExceptionUtils.getStackTrace(e));
//    		}
//    	} else {
//			if(KafkaProducer.getSetUp()){NessAppLog.createNessLogEvent(message + " uniResponse=NULL", false);}
//    	}
//
//    	return response;
//
//    }
    
	public FDSCloudGETResponse FDSCloudGetRequest(String sessionId, FDSCloudRequest fdsCloudRequest, String sort, String cid) throws ApplicationException {
		
		String searchCriteria = fdsCloudRequest.getRequest().get(SEARCH_TERMS).toString();
		
		Token token = getFDSCloudToken(sessionId);
        
		URI uriRequest;
		ResponseEntity<FDSCloudGETResponse> response;

        String message = "FDSCloudHandler FDSCloudGetRequest: fdsCloudRequest=" + fdsCloudRequest;

		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.set("fds-authorization", token.getAccessToken());
		HttpEntity<?> entity = new HttpEntity<>(headers);

        try {
			UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(fdsCloudURL).queryParam("searchTerms", searchCriteria);
			String uriString = uriBuilder.buildAndExpand(fdsCloudSpaceId).toUriString() + "&sort=%7BmodifiedOn%3Adesc%7D";
			uriRequest = new URI(uriString);
			response = (ResponseEntity<FDSCloudGETResponse>) sendRequestURI(uriRequest, entity, FDSCloudGETResponse.class, HttpMethod.GET, Encode.forJava(cid));
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }	catch (Exception e) {
			throw e;
		}

		return response.getBody();

//      FDSCloudGETResponse response = new FDSCloudGETResponse();
//		try {
////			response = tempMapper.readValue(responsenew.getBody().toString(), FDSCloudGETResponse.class);
////		} catch (IOException e) {
////////			logger.error("FDSCloudGetRequest -> Error mapping response, {}", ExceptionUtils.getStackTrace(e));
//		}
//		catch (Exception e) {
////			throw e;
//		}
//        return response;
	     
	}
	
//    public FDSCloudGETResponse getOptOutDocuments(String sessionId, String mpin, String cid) throws ApplicationException, IOException, OAuthSystemException, OAuthProblemException, RestClientException, NullPointerException {
//        	FDSCloudRequest fdsCloudRequest = new FDSCloudRequest();
//
//        	Map<String, Object> optOutRequest = new HashMap<String, Object>();
//
//	    	optOutRequest.put("deliveryMethod", "P");
//	    	optOutRequest.put("autoOptOutInd", "N");
//            if (mpin != null) {
//            	optOutRequest.put("mpin", mpin);
//            }
//
//
//	    	fdsCloudRequest.setRequest(optOutRequest);
//
//	    	FDSCloudGETResponse response = FDSCloudGetRequest(sessionId, fdsCloudRequest, PDOConstants.CREATED_ON, Encode.forJava(cid));
//
//	    	return response;
//
//    }
	
    public List<OptOutFDSCloudDocument> getAvailableAutoenrolledForOptOut(String tin, String mpin, String fileName, String sessionId, String cid)
			throws ApplicationException, IOException, OAuthSystemException, OAuthProblemException, RestClientException, NullPointerException {
            // update with FDS Cloud call
		Map<String, Object> optOutRequest = new HashMap<String, Object>();
		optOutRequest.put("tin", tin);
		optOutRequest.put("mpin",mpin);
		optOutRequest.put("deliveryMethod", "E");
		optOutRequest.put("okToChangePDOInd", "N");
		optOutRequest.put("fileName", fileName);

		FDSCloudRequest fdsCloudRequest = createSearchTermsRequestFromMap(tempMapper.convertValue(optOutRequest, new TypeReference<Map<String, Object>>() {}));
//	    	FDSCloudGETResponse response = FDSCloudGetRequest(sessionId, fdsCloudRequest, PDOConstants.CREATED_ON.toString());
		FDSCloudGETResponse response = FDSCloudGetRequest(sessionId, fdsCloudRequest, "", Encode.forJava(cid));

		try {
			OptOutFDSCloudDocument documentFound = response.getDocuments().get(0);
			Map<String, Object> metadataFound = getSearchTermsFromDocument(documentFound);
			logger.info(">>>> Found document: CID={}, docId={}, tin={}, mpin={}, fileName={}", Encode.forJava(cid), documentFound.getDocumentId() , metadataFound.get("tin"), metadataFound.get("mpin"), metadataFound.get("fileName"));
		}
		catch (NullPointerException | IndexOutOfBoundsException e) {
			logger.info("Autoenrollment record not found for CID={} tin/mpin/fileName: {} {} {}",Encode.forJava(cid),
					Encode.forJava(tin), Encode.forJava(mpin), Encode.forJava(fileName));
		}

		if(response == null || response.getDocuments().isEmpty()) {
			logger.info("No autoenrollment records found for CID={} tin/mpin/fileName: {} {} {}",Encode.forJava(cid),
					Encode.forJava(tin), Encode.forJava(mpin), Encode.forJava(fileName));
			return null;
		}
		return response.getDocuments();
            
    }
    
	
//	public OptOutFDSCloudDocument FDSCloudGetDocument(String sessionId, String documentId) throws ApplicationException, IOException{
//		Token token = getFDSCloudToken(sessionId);
//
//        String uri = fdsCloudURL.replace(SPACE_ID_QUERY, "").concat(fdsCloudSpaceId).concat("/").concat(documentId.trim());
//
//        HttpRequestWithBody uniRequest = Unirest.request("GET", uri);
//        uniRequest.header(AUTH_HEADER, token.getAccessToken());
//
//        String message = "FDSCloudHandler FDSCloudGetDocument: documentId=" + documentId;
//		HttpResponse<JsonNode> uniResponse = sendUnirestRequest(uniRequest);
//
//        logger.info("Received {} response from FDS Cloud, recordCount={}", uniResponse.getStatus(),  uniResponse.getBody().getArray().length());
//
//        OptOutFDSCloudDocument response = new OptOutFDSCloudDocument();
//
//		try {
//			response = tempMapper.readValue(uniResponse.getBody().toString(), OptOutFDSCloudDocument.class);
//		} catch (IOException e) {
//			if(KafkaProducer.getSetUp()){NessAppLog.createNessLogEvent(message + " Exception = " + e.getMessage(), false);}
//			logger.error("FDSCloudGetDocument -> Error mapping response, {}", ExceptionUtils.getStackTrace(e));
//			throw(e);
//		} catch (Exception e) {
//			if(KafkaProducer.getSetUp()){NessAppLog.createNessLogEvent(message + " Exception = " + e.getMessage(), false);}
//			throw e;
//		}
//		if(KafkaProducer.getSetUp()){NessAppLog.createNessLogEvent(message + " Response = " + response.toString());}
//        return response;
//
//	}
	

	public ResponseEntity<OptOutFDSCloudPOSTResponse> FDSCloudPostRequest(String sessionId, FDSCloudRequest request, String cid) throws ApplicationException{

		
		Token token = getFDSCloudToken(sessionId);
		
        String searchKey = SEARCH_TERMS;
			
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<OptOutFDSCloudPOSTResponse> response = null;
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL.replace(SPACE_ID_QUERY, "")).path(fdsCloudSpaceId);
        
        MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<String, Object>();
        requestMap.add(METADATA_KEY, request.getRequest());
        requestMap.add(searchKey, request.getRequest());
       
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set(AUTH_HEADER, token.getAccessToken());
        
       
        HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<MultiValueMap<String, Object>>(requestMap, headers);
        
        String message = "FDSCloudHandler FDSCloudPostRequest: documentId=" + request.getDocumentId();
        try {
        	response = (ResponseEntity<OptOutFDSCloudPOSTResponse>) sendRequest(builder.toUriString(), entity, OptOutFDSCloudPOSTResponse.class, HttpMethod.POST, Encode.forJava(cid));
            logger.info(app.rerSuccess("FDSCloudPostRequest -> Received response from FDS Cloud, CID={}, response={}"), Encode.forJava(cid), response.toString());
        }
        catch (JSONException e) {
        	logger.error(app.rerFailure("FDSCloudPostRequest -> Error processing request, CID={}, request={}, headers={}"), Encode.forJava(cid), requestMap.toString(), headers.toString());
        }
        catch (Exception e) {
        	throw e;
        }
       
        return response;
	     
	}
	
	// PUT replaces entire metadata, proceed with caution. 
	public ResponseEntity<OptOutFDSCloudPOSTResponse> FDSCloudPutRequest(String sessionId, FDSCloudRequest request, String cid) throws ApplicationException{
		
		Token token = getFDSCloudToken(sessionId);
		

        String searchKey = SEARCH_TERMS;
        String documentId = request.getDocumentId();
			
		HttpHeaders headers = new HttpHeaders();
		ResponseEntity<OptOutFDSCloudPOSTResponse> response = null;
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL.replace(SPACE_ID_QUERY, "")).path(fdsCloudSpaceId).path("/").path(documentId.trim());
        
      
        MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<String, Object>();
        requestMap.add(METADATA_KEY, request.getRequest());	//putting in metadata and search terms in map
        requestMap.add(searchKey, request.getRequest());
        
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set(AUTH_HEADER, token.getAccessToken());
       
        HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<MultiValueMap<String, Object>>(requestMap, headers); //request creation
        String message = "FDSCloudHandler FDSCloudPutRequest: documentId=" + request.getDocumentId();
        try {
        	logger.info("Entity created, CID={}, request={}, headers={}", Encode.forJava(cid), request, SanitizeUtil.sanitizeHttpHeaders(headers)); //send request
        	response = (ResponseEntity<OptOutFDSCloudPOSTResponse>) sendRequest(builder.toUriString(), entity, OptOutFDSCloudPOSTResponse.class, HttpMethod.PUT, Encode.forJava(cid));
        	if (logger.isInfoEnabled()) {
                logger.info(app.rerSuccess("FDSCloudPutRequest -> Received PUT response from FDS Cloud, CID={} response={}"), Encode.forJava(cid), response.getStatusCode().toString());
        	}
        }
        catch (JSONException e) {
        	logger.warn(app.rerFailure("FDSCloudPutRequest -> Error processing PUT request, CID={}, request={}, headers={}"), Encode.forJava(cid), requestMap.toString(), headers.toString());
        }
        
        return response;
	     
	}
	
	// PUT replaces entire metadata, proceed with caution. 
//	public ResponseEntity<OptOutFDSCloudPOSTResponse> FDSCloudResendPUT(FDSCloudRequest request) throws ApplicationException{
//
//		Token token = getFDSCloudToken("resend");
//
//        String searchKey = SEARCH_TERMS;
//        String documentId = request.getDocumentId();
//
//		HttpHeaders headers = new HttpHeaders();
//		ResponseEntity<OptOutFDSCloudPOSTResponse> response = null;
//        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdsCloudURL.replace(SPACE_ID_QUERY, "")).path(fdsCloudSpaceId).path("/").path(documentId.trim());
//
//
//        MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<String, Object>();
//        requestMap.add(METADATA_KEY, request.getRequest());	//putting in metadata and search terms in map
//        requestMap.add(searchKey, request.getRequest());
//
//        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
//        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
//        headers.set(AUTH_HEADER, token.getAccessToken());
//
//        HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<MultiValueMap<String, Object>>(requestMap, headers); //request creation
//        String message = "FDSCloudHandler FDSCloudResendPUT: documentId=" + request.getDocumentId();
//
//        try {
//
//        	logger.info("Entity created, request={}, headers={}", request, SanitizeUtil.sanitizeHttpHeaders(headers)); //send request
//        	response = (ResponseEntity<OptOutFDSCloudPOSTResponse>) sendRequest(builder.toUriString(), entity, OptOutFDSCloudPOSTResponse.class, HttpMethod.PUT, "");
////        	NessAppLog.createHttpLogEvent(headers, message, response);
//        	if (logger.isInfoEnabled()) {
//                logger.info(app.rerSuccess("FDSCloudPutRequest -> Received PUT response from FDS Cloud, response={}"), response.getStatusCode().toString());
//        	}
//        }
//        catch (JSONException e) {
//        	if(KafkaProducer.getSetUp()){NessAppLog.createNessLogEvent(message + " Exception = " + e.getMessage(), false);}
//        	logger.warn(app.rerFailure("FDSCloudPutRequest -> Error processing PUT request, request={}, headers={}"), requestMap.toString(), headers.toString());
//        }
//
//        return response;
//
//	}
	   
	public Token getFDSCloudToken(String sessionId) throws ApplicationException{
		Token tempToken = null; 
        try
        {
            tempToken = (Token) oauth2handler.getOauthToken(sessionId, "FDSCLOUD");
            Objects.requireNonNull(tempToken.getAccessToken());
        }
        catch (IOException | OAuthSystemException | OAuthProblemException e)
        {
            logger.error(failedDocuments);
            throw new ApplicationException(OAUTH_FAILURE + e.toString());
        }
        catch (Exception e) {
        	throw e;
        }
        return tempToken;
	}
	
	public String createSearchTermsFromMap(Map<String, Object> metadata) {
		String searchTerms = "";
		List<String> searchConcat = new ArrayList<String>();
		
		for (String key: metadata.keySet()) {
			String formatKey = new StringBuilder("(").append(key).append("%3D").append(metadata.get(key)).append(")").toString();
			searchConcat.add(formatKey);
		}
		if (searchConcat.size() > 0) {
			searchTerms = String.join("%2B", searchConcat);
		}
		
		return searchTerms;
		
	}
	
	public FDSCloudRequest createSearchTermsRequestFromMap(Map<String, Object> metadata) {
		FDSCloudRequest fdsCloudRequest = new FDSCloudRequest();
		Map<String, Object> requestMap = new HashMap<String, Object>();
		String searchTerms = createSearchTermsFromMap(metadata);
		
		requestMap.put(SEARCH_TERMS, searchTerms);
		fdsCloudRequest.setRequest(requestMap);
		
		return fdsCloudRequest;
		
	}
	
	public Map<String, Object> getSearchTermsFromString(String metadata) {
		Map<String, Object> searchTerms = null;
		Objects.requireNonNull(metadata);
		String searchTermsJson = metadata.replace("\\\\", "");
		try {
			searchTerms = tempMapper.readValue(searchTermsJson, Map.class);
		}
		catch (Exception e) {
			logger.error("Error mapping searchTerms");
		}
		return searchTerms;
		
	}
	
	public Map<String, Object> getSearchTermsFromDocument(OptOutFDSCloudDocument document) {
		Map<String, Object> searchTerms = null;
		Objects.requireNonNull(document.getMetadata());
		String searchTermsJson = document.getMetadata();
		searchTerms = getSearchTermsFromString(searchTermsJson);
		return searchTerms;
		
	}
	
	public Map<String, Object> createMapFromPOJO (Object pojo) {
		
		Map<String, Object> mapRequest = tempMapper.convertValue(pojo, new TypeReference<Map<String, Object>>() {});
		return mapRequest;
		
	}
	
	
	public String encodeToUTF(String encode) {
		String encodedString = "";
		try {
			encodedString = URLEncoder.encode(encode, StandardCharsets.UTF_8.toString());
		}
		catch (UnsupportedEncodingException e) {
			logger.error("encodeToUTF -> Failed to encode string={}", encode);
		}
		
		return encodedString;
	}
	

}

