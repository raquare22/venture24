package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.PasswordOwner;
import com.optum.providerpreferences.rs.model.PasswordOwnerInfo;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.ndb.*;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class CACFHandler extends ServiceBase
{
    @Autowired
    RestTemplate restTemplate;

    @Autowired
    private HttpHeaders headers = new HttpHeaders();
    
    private ApplicationUtil app = new ApplicationUtil();

    private static final Logger logger = LogManager.getLogger(CACFHandler.class);
    
    
    @Value("${LINK_CORPORATES_URL}")
    protected String linkCorporatesURL;
    
    @Value("${LINK_TINS_URL}")
    protected String linkTinsURL;
    
    @Value("${LINK_PROVIDERS_URL}")
    protected String linkProvidersURL;
    
    
    String authorization="Authorization";
    
    String bearer="Bearer ";
    
    String uHCID="uhcId";
    
    String optumuId="optumUuid";
    
//    public List<PasswordOwnerInfo> getCorporatesForUser(String optumUUID, String uhcId, String sessionId) throws ApplicationException
//    {
//
//        Token token = null;
//        try
//        {
//            token = (Token) oauth2handler.getOauthToken(sessionId, "LINK");
//        }
//        catch (Exception e)
//        {
//            logger.error(app.rerFailure("ERROR WITH OAUTH CALL TO CACF, error={}"), e);
//            throw new ApplicationException("Failed to retrieve OAuth Token - CACF");
//        }
//        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(linkCorporatesURL).queryParam(optumuId, optumUUID);
//        if (uhcId != null && !uhcId.isEmpty())
//        {
//        	builder.queryParam(uHCID, uhcId);
//        }
//        headers.set(authorization, bearer + token.getAccessToken());
//
//        HttpEntity<String> requestEntity = new HttpEntity<>(headers);
//        logger.info("Sending request to CACF -  Corporate Entities");
//        ResponseEntity<CorporateEntities> response = null;
//        try
//        {
//            response = sendCACFCorporatesRequest(builder.toUriString(), requestEntity, HttpMethod.GET);
//        }
//        catch (Exception e)
//        {
//            logger.error(app.rerFailure("ERROR DURING WEB SERVICE CALL - CACF CORPORATES, error={}"), e);
//            throw new ApplicationException("Failed to make web serivce call for CACF Corporates");
//        }
//        String corporateEntitiesResponse=app.rerSuccess("Recieved response from CACF - Corporate Entities");
//        logger.info(corporateEntitiesResponse);
//        CorporateEntities corporateEntities = response.getBody();
//        List<Corporate> corporateEntitiesList = corporateEntities.getCorporates();
//        List<PasswordOwnerInfo> passwordOwnerInfos = new ArrayList<>();
//
//        for (Corporate corporate : corporateEntitiesList)
//        {
//            PasswordOwnerInfo passwordOwnerInfo = new PasswordOwnerInfo();
//            passwordOwnerInfo.setCorporateName(corporate.getName());
//            passwordOwnerInfo.setMpin(corporate.getMpin());
//            passwordOwnerInfo.setUhcID(uhcId);
//            passwordOwnerInfos.add(passwordOwnerInfo);
//        }
//
//        return passwordOwnerInfos;
//
//    }

    /*
     * RESTful API call to CACF GET provider_tax_ids Service /v1/provider_tax_ids/search{?optumUuid,uhcId,mpin,appCode}
     * 
     * @param optumUUID
     * @param uhcId
     * @param mpin
     * @param sessionId
     * @return a POwner object with a list of associated TINS inside
     * @throws JsonParseException
     * @throws JsonMappingException
     * @throws IOException
     * @throws ApplicationException
     */
//    public PasswordOwner getTaxIDNumbers(String optumUUID, String uhcId, String mpin, String sessionId, String cid) throws ApplicationException {
//        Token token = null;
//        try {
//            token = (Token) oauth2handler.getOauthToken(sessionId, "LINK");
//        } catch (Exception e) {
//            logger.error(app.rerFailure("Failed to get OAuth Token for CACF, error={}, CID={}"), e, Encode.forJava(cid));
//            throw new ApplicationException("Failed to make CACF web service call");
//        }
//        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(linkTinsURL).queryParam(optumuId, optumUUID);
//        builder.queryParam(uHCID, uhcId);
//        builder.queryParam("mpin", mpin);
//
//        headers.set(authorization, bearer + token.getAccessToken());
//        HttpEntity<String> requestEntity = new HttpEntity<>(headers);
//        logger.info("Sending request to CACF - Tax Id Numbers, CID={}", Encode.forJava(cid));
//        ResponseEntity<Tins> response = null;
//        try {
//            response = (ResponseEntity<Tins>) sendRequest(builder.toUriString(), requestEntity, Tins.class, HttpMethod.GET, Encode.forJava(cid));
//        } catch (Exception e) {
//            logger.error(app.rerFailure("Failed to make web service call for CACF, error={}, CID={}"), e, Encode.forJava(cid));
//            throw new ApplicationException("Failed to make CACF web service call");
//        }
//        String taxIdResponse = app.rerSuccess("Response received from CACF - Tax Id Numbers, CID={}");
//        logger.info(taxIdResponse, Encode.forJava(cid));
//        List<Tin> tinList = response.getBody().getTinList();
//
//        PasswordOwner passwordOwnerInfoWithTaxIds = new PasswordOwner();
//        passwordOwnerInfoWithTaxIds.setMpin(mpin);
//        passwordOwnerInfoWithTaxIds.setOptumUUID(optumUUID);
//        passwordOwnerInfoWithTaxIds.setUhcID(uhcId);
//        List<PasswordOwnerInfo> providerInfos = passwordOwnerInfoWithTaxIds.getProviders();
//
//        for (Tin tin : tinList) {
//            PasswordOwnerInfo providerInfo = new PasswordOwnerInfo();
//            providerInfo.setTin(tin.getTin());
//            providerInfos.add(providerInfo);
//        }
//
//        if (providerInfos.isEmpty()) {
//            logger.error("No Tax Ids for given UUID, CID={}", Encode.forJava(cid));
//            throw new ApplicationException("Error: LINK Tax ID Numbers");
//        }
//
//        return passwordOwnerInfoWithTaxIds;
//    }
//
//    public List<PasswordOwnerInfo> getProviders(String optumUUID, String uhcId, String mpin, String tin, String sessionId, String cid)
//    		throws ApplicationException, IOException, OAuthSystemException, OAuthProblemException, RestClientException
//    {
//
//        Token token = null;
//
//        try
//        {
//            token = (Token) oauth2handler.getOauthToken(sessionId, "LINK");
//        }
//        catch (IOException | OAuthSystemException | OAuthProblemException e)
//        {
//            logger.error(app.rerFailure("Failed to get OAuth Token for LINK - getProviders, error={}"), e);
//            throw new ApplicationException("Failed to get OAuth Token for LINK - getProviders");
//        }
//
//        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(linkProvidersURL).queryParam(optumuId, optumUUID);
//        builder.queryParam(uHCID, uhcId);
//        builder.queryParam("mpin", mpin);
//        builder.queryParam("tin", tin);
//
//        headers.set(authorization, bearer + token.getAccessToken());
//        HttpEntity<String> requestEntity = new HttpEntity<>(headers);
//        ResponseEntity<NDBProviders> response = null;
//        try
//        {
//            response = (ResponseEntity<NDBProviders>) sendRequest(builder.toUriString(), requestEntity, NDBProviders.class, HttpMethod.GET, Encode.forJava(cid));
//        }
//        catch (RestClientException e)
//        {
//            logger.error(app.rerFailure("Failed to make web service call for LINK - getProviders, error={}"),e);
//            throw new ApplicationException("Failed to make web service call for LINK - getProviders");
//        }
//        String getProviders = app.rerSuccess("Successfully called LINK - getProviders");
//        logger.info(getProviders);
//        List<NDBProvider> ndbProviders = response.getBody().getProviderList();
//        List<PasswordOwnerInfo> providerInfos = new ArrayList<>();
//
//        if (ndbProviders.isEmpty())
//        {
//            logger.error("LINK - GET PROVIDERS FOUND NO USEABLE DATA");
//            throw new ApplicationException("NDB PROVIDERS WAS EMPTY");
//        }
//
//        for (NDBProvider ndbProvider : ndbProviders)
//        {
//            PasswordOwnerInfo providerInfo = new PasswordOwnerInfo();
//            providerInfo.setProviderName(ndbProvider.getName());
//            providerInfo.setTin(tin);
//            providerInfos.add(providerInfo);
//        }
//
//        return providerInfos;
//    }
}
