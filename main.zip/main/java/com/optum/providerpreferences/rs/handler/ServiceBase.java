package com.optum.providerpreferences.rs.handler;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.autoenroll.FDSMultiPostResponse;
import com.optum.providerpreferences.rs.model.ndb.CorporateEntities;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import com.optum.providerpreferences.rs.utility.SanitizeUtil;
import kong.unirest.HttpRequestWithBody;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import org.apache.cxf.jaxrs.utils.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.*;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
public class ServiceBase {

	protected int numRetries = 6;
	protected long[] timeToWaitMsArr = {60000, 30000, 5000, 1000, 500, 50, 20};
	protected int numRetriesAutoEnroll = 12;
	protected long[] timeToWaitMsArrAutoEnroll = {60000*60, 60000*30, 60000*60, 60000*30, 60000*20, 60000*10, 60000, 30000, 5000, 1000, 500, 50, 20};
	

	private static final Logger LOGGER = LogManager.getLogger(ServiceBase.class);
	
	public static final String HEADER_ACCEPT = "Accept";
	
	private ApplicationUtil app = new ApplicationUtil();

    @Autowired
	RestTemplate restTemplate;
    
    @Autowired
    RestTemplate restTemplateAutoEnroll;

	@Autowired
    protected Oauth2Handler oauth2handler;
    
    private static String successRequest = "Request successful after retries statusCode={}, responseBody={}, CID={}";
    private static String exceptionRequest = "sendRequest caught exception, throwing error not retrying: uri={}, responseEntity={}, error={}, CID={}";
    private static String requestRetry = "Request retry: requestBody={}, retryCount={}, CID={}";
    private static String successRequest2 = "Request successful: responseEntity={}, CID={}";
    private static String firstRequestFail = "First request failed, retrying CID={}";
    private static String retryCountStr = "retryCount={}, CID={}";
    private static String timeToWait = "time to wait={}, CID={}";
    private static String requestFailed = "Request failed after retries with error code={}, request={}, CID={}";
    private static String serviceCallError = "ERROR DURING SERVICE CALL: uri={}, requestEntity={}, error={}, CID={}";
    private static String auth="Authorization";
    private static String bearer="Bearer ";
    private static String oauthFailure="Failed to make FDS OAUTH service call: ";
    private static Integer ok = HttpStatus.OK.value();
    private static Integer unauthorized = HttpStatus.UNAUTHORIZED.value();
    private static String INVALID_GRANT = "invalid_grant";
    private static String DOCUMENT_NOT_FOUND = "document not found";
    private static String DETAILS = "details";
    private static String SEND_REQUEST_LOG = "sendRequest caught exception, retrying: uri={}, responseEntity={}, error={}, CID={}";


	public ResponseEntity<?> sendRequest(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod, String cid) throws ApplicationException {

		ResponseEntity<?> responseEntity = null;

		String message = "Service sendRequest: requestEntity=" + requestEntity.getBody().toString();
		try {
			responseEntity = retryRequest(uri, requestEntity, clazz, httpMethod, Encode.forJava(cid));

			if (responseEntity != null && (HttpStatus.OK.equals(responseEntity.getStatusCode()) || HttpStatus.CREATED.equals(responseEntity.getStatusCode()))) {

				LOGGER.info(successRequest2, SanitizeUtil.sanitizeResponseEntityBody(responseEntity), Encode.forJava(cid));
				return responseEntity;
			}

			LOGGER.info(firstRequestFail, Encode.forJava(cid));

			int retryCount = numRetries;
			while ((responseEntity == null || !HttpStatus.OK.equals(responseEntity.getStatusCode()) || !HttpStatus.CREATED.equals(responseEntity.getStatusCode())) && (retryCount-- > 0)) {
				LOGGER.info(retryCountStr, retryCount, Encode.forJava(cid));
				LOGGER.info(timeToWait, timeToWaitMsArr[retryCount], Encode.forJava(cid));

				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				responseEntity = retryRequest(uri, requestEntity, clazz, httpMethod, Encode.forJava(cid));
				LOGGER.warn(requestRetry, Encode.forJava((String) requestEntity.getBody()), retryCount, Encode.forJava(cid));
			}

			// if responseEntity is null, throw a NullPointerException
			Objects.requireNonNull(responseEntity);

			if (!HttpStatus.OK.equals(responseEntity.getStatusCode()) || !HttpStatus.CREATED.equals(responseEntity.getStatusCode())) {
				LOGGER.error(requestFailed, responseEntity.getStatusCode(), Encode.forJava((String) requestEntity.getBody()), Encode.forJava(cid));
				return responseEntity;
			}

			LOGGER.info(successRequest, responseEntity.getStatusCode(), SanitizeUtil.sanitizeResponseEntityBody(responseEntity), Encode.forJava(cid));
			return responseEntity;
		} catch (Exception e) {
			LOGGER.error(serviceCallError, uri, Encode.forJava((String) requestEntity.getBody()), ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
		}
		return responseEntity;
	}


	public ResponseEntity<?> sendDigiSecRequest(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod, String cid) {
		List<HttpStatus> digiSecPass = new ArrayList<>();
		digiSecPass.add(HttpStatus.OK);
		digiSecPass.add(HttpStatus.CREATED);
		digiSecPass.add(HttpStatus.BAD_REQUEST);

		ResponseEntity<?> responseEntity = null;
		String message = "Service sendDigiSecRequest: requestEntity=" + requestEntity.getBody().toString();
		try {
			responseEntity = retryDigiSecRequest(uri, requestEntity, clazz, httpMethod, Encode.forJava(cid));

			if ((responseEntity == null && uri.contains("paa")) ||
					(responseEntity != null && digiSecPass.contains(responseEntity.getStatusCode()))) {
				return responseEntity;
			}

			LOGGER.info("First request failed, retrying. CID={}", Encode.forJava(cid));

			int retryCount = numRetries;

			while ((responseEntity == null && !uri.contains("paa")) ||
					(responseEntity != null && !digiSecPass.contains(responseEntity.getStatusCode()) && (retryCount-- > 0))) {

				LOGGER.info("Retry count: {}. CID={}", retryCount, Encode.forJava(cid));
				LOGGER.info("Time to wait: {} ms. CID={}", timeToWaitMsArr[retryCount], Encode.forJava(cid));

				try {
					synchronized (this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				responseEntity = retryDigiSecRequest(uri, requestEntity, clazz, httpMethod, Encode.forJava(cid));
				if (LOGGER.isWarnEnabled()) {
					LOGGER.warn("Request retry: requestEntity={}, retryCount={}, CID={}", Encode.forJava((String) requestEntity.getBody()), retryCount, Encode.forJava(cid));
				}
			}

			if (checkDigiSecResponseEntity(responseEntity, digiSecPass, uri)) {
				String statusCode = responseEntity != null ? responseEntity.getStatusCode().toString() : "no Status code";
				LOGGER.error("Request failed after retries with error code={}, request={}, CID={}", statusCode, Encode.forJava((String) requestEntity.getBody()), Encode.forJava(cid));
				return responseEntity;
			}
			return responseEntity;
		} catch (ResourceAccessException | HttpServerErrorException e) {
			LOGGER.error("ERROR DURING SERVICE CALL: uri={}, requestEntity={}, error={}, CID={}", uri, Encode.forJava((String) requestEntity.getBody()), ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
			throw e;
		}
	}

	public ResponseEntity<?> sendRequestFDS(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod) {
		
		ResponseEntity<?> responseEntity = null;
		String message = "Service sendRequestFDS: requestEntity=" + requestEntity.getBody().toString();
		
		try {
			
			responseEntity = retryRequestFDS(uri, requestEntity, clazz, httpMethod);

			if (checkFDSResponseEntity(responseEntity)) {
//				LOGGER.info(successRequest2, responseEntity);
				return responseEntity;
			}
			
			LOGGER.info(firstRequestFail);
			
			int retryCount = numRetries;
			while (!checkFDSResponseEntity(responseEntity) && (retryCount-- > 0)) {
				
				LOGGER.info(retryCountStr, retryCount);
				LOGGER.info(timeToWait, timeToWaitMsArr[retryCount]);
				
				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				responseEntity = retryRequestFDS(uri, requestEntity, clazz, httpMethod);
				LOGGER.warn(requestRetry, Encode.forJava((String) requestEntity.getBody()), retryCount);
			}
			
			// if responseEntity is null, throw a NullPointerException
			Objects.requireNonNull(responseEntity);
			
			if (!HttpStatus.OK.equals(responseEntity.getStatusCode())) {
				LOGGER.error(requestFailed, responseEntity.getStatusCode(), Encode.forJava((String) requestEntity.getBody()));
				return responseEntity;
			}

//			LOGGER.info(successRequest, responseEntity.getStatusCode(), responseEntity.getBody());
			return responseEntity;
		} catch (HttpClientErrorException e) {
			Token token = null;
			if (e.getStatusCode().equals(HttpStatus.BAD_REQUEST) && e.getResponseBodyAsString().contains(INVALID_GRANT)) {
				try {
					LOGGER.info("Token expired, retrying token call");
		            token = (Token) oauth2handler.getOauthToken("FDS_OAUTH_RETRY", "FDSCLOUD");
		            HttpHeaders oldHeaders = requestEntity.getHeaders();
		            HttpHeaders headers = new HttpHeaders();
		            headers.putAll(oldHeaders);
		            headers.set(auth, bearer + token.getAccessToken());
		            HttpEntity<?> newRequest = new HttpEntity(requestEntity.getBody(), headers);
					return sendRequestFDS(uri, newRequest, clazz, httpMethod);
				} catch (ApplicationException | IOException | OAuthSystemException | OAuthProblemException | NullPointerException ex) {
					throw(e);
				}
			} else {
				throw(e);
			}
		} catch (Exception e) {
			LOGGER.error(serviceCallError, uri, Encode.forJava((String) requestEntity.getBody()), ExceptionUtils.getStackTrace(e));
			throw(e);
		}
		
	}
	
//	public ResponseEntity<CorporateEntities> sendCACFCorporatesRequest(String uri, HttpEntity<?> requestEntity, HttpMethod httpMethod) throws ApplicationException {
//
//		ResponseEntity<CorporateEntities> responseEntity = null;
//
//		String message = "Service sendCACFCorporatesRequest: requestEntity=" + requestEntity.getBody().toString();
//		try {
//			responseEntity = restTemplate.exchange(uri, httpMethod, requestEntity, CorporateEntities.class);
//
//			if (HttpStatus.OK.equals(responseEntity.getStatusCode())) {
////				LOGGER.info(successRequest2, responseEntity);
//				return responseEntity;
//			}
//
//			CorporateEntities corporateEntities = responseEntity.getBody();
//	        // TODO: figure out successful response status code and converse this logic
//	        if ("ERR002".equals(corporateEntities.getStatusCode()))
//	        {
//	        	String err=app.rerFailure("ERROR CACF - CORPORATE ENTITIES, error={}");
//	        	if (LOGGER.isErrorEnabled()) {
//	        		LOGGER.error(err, Encode.forJava(corporateEntities.getStatusMessage()));
//	        	}
//	            throw new ApplicationException(corporateEntities.getStatusMessage());
//	        }
//
//			LOGGER.info(firstRequestFail);
//
//			int retryCount = numRetries;
//			while ((! (HttpStatus.OK.equals(responseEntity.getStatusCode()))) && (retryCount-- > 0)) {
//
//				LOGGER.info(retryCountStr, retryCount);
//				LOGGER.info(timeToWait, timeToWaitMsArr[retryCount]);
//
//				try {
//					synchronized(this) {
//						this.wait(timeToWaitMsArr[retryCount]);
//					}
//				} catch (InterruptedException e) {
//					Thread.currentThread().interrupt();
//				}
//				responseEntity = restTemplate.exchange(uri, httpMethod, requestEntity, CorporateEntities.class);
//				LOGGER.warn(requestRetry, SanitizeUtil.sanitizeHttpEntityHeader(requestEntity).getBody(), retryCount);
//			}
//
//			// if responseEntity is null, throw a NullPointerException
//			Objects.requireNonNull(responseEntity);
//
//			if (!HttpStatus.OK.equals(responseEntity.getStatusCode())) {
//				LOGGER.error(requestFailed, responseEntity.getStatusCode(), SanitizeUtil.sanitizeHttpEntityHeader(requestEntity));
//				return responseEntity;
//			}
//
////			LOGGER.info(successRequest, responseEntity.getStatusCode(), responseEntity.getBody());
//			return responseEntity;
//		}
//		catch (Exception e) {
//			LOGGER.error(serviceCallError, uri, Encode.forJava((String) requestEntity.getBody()), ExceptionUtils.getStackTrace(e));
//			throw(e);
//		}
//
//	}
	
//	public ResponseEntity<?> sendRequestAutoEnrollment(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod) throws ApplicationException {
////		LOGGER.info("ENTER -- sendRequestAutoEnrollment");
//
//		ResponseEntity<?> responseEntity = null;
//
//		String message = "Service sendRequestAutoEnrollment: requestEntity=" + requestEntity.getBody().toString();
//		try {
//
//			responseEntity = retryRequestAutoEnroll(uri, requestEntity, clazz, httpMethod);
//
//			if (responseEntity != null && HttpStatus.OK.equals(responseEntity.getStatusCode())) {
////				LOGGER.info(successRequest2, responseEntity);
//				return responseEntity;
//			}
//			LOGGER.info(firstRequestFail);
//
//			int retryCount = numRetriesAutoEnroll;
//			while ((responseEntity == null || !HttpStatus.OK.equals(responseEntity.getStatusCode())) && (retryCount-- > 0)) {
//
//				LOGGER.info(retryCountStr, retryCount);
//				// extended time for autoenrollment
//				LOGGER.info(timeToWait, timeToWaitMsArrAutoEnroll[retryCount]);
//
//				try {
//					synchronized(this) {
//						this.wait(timeToWaitMsArrAutoEnroll[retryCount]);
//					}
//				} catch (InterruptedException e) {
//					Thread.currentThread().interrupt();
//				}
//
//				responseEntity = retryRequestAutoEnroll(uri, requestEntity, clazz, httpMethod);
//				if (LOGGER.isWarnEnabled()) {
//					LOGGER.warn(requestRetry, SanitizeUtil.sanitizeHttpEntityHeader(requestEntity).toString(), retryCount);
//				}
//			}
//
//			// if responseEntity is null, throw a NullPointerException
//			Objects.requireNonNull(responseEntity);
//			if (!HttpStatus.OK.equals(responseEntity.getStatusCode())) {
//				LOGGER.error(requestFailed, responseEntity.getStatusCode(), SanitizeUtil.sanitizeHttpEntityHeader(requestEntity));
//				return responseEntity;
//			}
//
////			LOGGER.info(successRequest, responseEntity.getStatusCode(), responseEntity.getBody());
//			return responseEntity;
//		} catch (HttpClientErrorException e) {
//			Token token = null;
//
//			if (!e.getStatusCode().equals(HttpStatus.BAD_REQUEST) && !e.getResponseBodyAsString().contains(INVALID_GRANT)) {
//				throw e;
//			}
//			try {
//				LOGGER.info("Token expired, retrying token call");
//	            token = (Token) oauth2handler.getOauthToken("FDS_OAUTH_RETRY", "FDS");
//	            HttpHeaders oldHeaders = requestEntity.getHeaders();
//	            HttpHeaders headers = new HttpHeaders();
//	            headers.putAll(oldHeaders);
//	            headers.set(auth, bearer + token.getAccessToken());
//	            HttpEntity<?> newRequest = new HttpEntity(requestEntity.getBody(), headers);
//				return sendRequestFDS(uri, newRequest, clazz, httpMethod);
//			} catch (ApplicationException | IOException | OAuthSystemException | OAuthProblemException | NullPointerException ex) {
//				throw(e);
//			}
//		} catch (Exception e) {
//			LOGGER.error(serviceCallError, uri, Encode.forJava((String) requestEntity.getBody()), ExceptionUtils.getStackTrace(e));
//			throw(e);
//		}
//
//	}
//
//	public HttpResponse<JsonNode> sendUnirestRequest(HttpRequestWithBody requestEntity) throws ApplicationException {
////		LOGGER.info("ENTER -- sendUnirestRequest");
//
//		HttpResponse<JsonNode> responseEntity;
//
//		try {
//
//			responseEntity = retryUnirestRequest(requestEntity);
//
//			if (checkUnirestResponseEntity(responseEntity)) {
////				LOGGER.info(successRequest2, responseEntity.getBody());
//				return responseEntity;
//			}
//
//			LOGGER.info(firstRequestFail);
//
//			int retryCount = numRetries;
//			while ((responseEntity == null || checkUnirestResponseEntity(responseEntity)) && (retryCount-- > 0)) {
//
//				if (responseEntity != null && unauthorized.equals(responseEntity.getStatus()) && responseEntity.getBody().toString().contains("Expired JWT")) {
//					Token refreshToken = new Token();
//		            try {
//		            	refreshToken = (Token) oauth2handler.getOauthTokenRefresh("retryUnirestRequest", "FDSCLOUD");
//		            }
//		            catch (IOException | OAuthSystemException | OAuthProblemException e)
//		            {
//		                LOGGER.error("sendRequestAutoEnrollment");
//		                throw new ApplicationException(oauthFailure + e.toString());
//		            }
//
//					//add token to header
//		            requestEntity.headerReplace("fds-authorization", refreshToken.getAccessToken());
//				}
//
//				LOGGER.info(retryCountStr, retryCount);
//				LOGGER.info(timeToWait, timeToWaitMsArr[retryCount]);
//
//				try {
//					synchronized(this) {
//						this.wait(timeToWaitMsArr[retryCount]);
//					}
//				} catch (InterruptedException e) {
//					Thread.currentThread().interrupt();
//				}
//
//				responseEntity = retryUnirestRequest(requestEntity);
//				if (LOGGER.isWarnEnabled()) {
//					LOGGER.warn(requestRetry, SanitizeUtil.sanitizeHttpRequestWithBody(requestEntity).toString(), retryCount);
//				}
//			}
//
////			 if responseEntity is null, throw a NullPointerException
//			Objects.requireNonNull(responseEntity);
//
//			if (!ok.equals(responseEntity.getStatus()) &&
//					(responseEntity != null &&
//					!checkDocNotFound(responseEntity))
//					) {
//				LOGGER.error(requestFailed, responseEntity.getStatus(), SanitizeUtil.sanitizeHttpRequestWithBody(requestEntity));
//				return responseEntity;
//			}
//
////			LOGGER.info(successRequest, responseEntity.getStatus(), responseEntity.getBody());
//			return responseEntity;
//		}
//		catch (Exception e) {
//			LOGGER.error(serviceCallError, requestEntity.getUrl(), SanitizeUtil.sanitizeHttpRequestWithBody(requestEntity), ExceptionUtils.getStackTrace(e));
//			responseEntity = null;
//			return responseEntity;
//		}
//
//	}
	
	public HttpResponse<JsonNode> retryUnirestRequest(HttpRequestWithBody requestEntity){
		
		HttpResponse<JsonNode> retryResponse = null;
		try {
			retryResponse = requestEntity.asJson();
		} catch (ResourceAccessException | HttpClientErrorException | HttpServerErrorException e) {
			LOGGER.warn("sendUnirestRequest caught exception, retrying: uri={}, responseEntity={}, error={}.", requestEntity.getUrl(), retryResponse, e.getMessage());
		} catch (RestClientException e) {
			LOGGER.error(exceptionRequest, requestEntity.getUrl(), retryResponse, ExceptionUtils.getStackTrace(e));
		} catch (Exception e) {
			LOGGER.error(exceptionRequest, requestEntity.getUrl(), retryResponse, ExceptionUtils.getStackTrace(e));
		}
		
		return retryResponse;
		
	}
	
	public ResponseEntity<?> retryRequest(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod, String cid){
		
		ResponseEntity<?> retryResponse = null;
		try {
			retryResponse = restTemplate.exchange(uri, httpMethod, requestEntity, clazz);
		} catch (HttpServerErrorException e) {
			// If PES API receives invalid corporateMpin, then it returns 500 null, and should not be retried
			if (e.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR) && e.getStatusText() == null) {
				LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
				throw(e);
			} else {
				LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
			}
		} catch (ResourceAccessException | HttpClientErrorException e) {
			LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, e.getMessage(), Encode.forJava(cid));
		} catch (RestClientException e) {
			LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
		} catch (Exception e) {
			LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
			throw(e);
		}
		
		return retryResponse;
		
	}
	
	public ResponseEntity<?> retryRequestFDS(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod){
		
		ResponseEntity<?> retryResponse = null;
		try {
			retryResponse = restTemplate.exchange(uri, httpMethod, requestEntity, clazz);
		} catch (HttpServerErrorException e) {
			// If PES API receives invalid corporateMpin, then it returns 500 null, and should not be retried
			if (e.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR) && e.getStatusText() == null) {
				LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
				throw(e);
			} else {
				LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, ExceptionUtils.getStackTrace(e));
			}
		} catch (HttpClientErrorException e) {
			if (e.getStatusCode().equals(HttpStatus.BAD_REQUEST) && e.getResponseBodyAsString().contains(INVALID_GRANT)) {
				LOGGER.error("sendRequest caught invalid_grant exception, oauth token expired, retrying: uri={}, responseEntity={}, error={}.",
						uri, retryResponse, ExceptionUtils.getStackTrace(e));
				throw(e);
			} else {
				LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, ExceptionUtils.getStackTrace(e));
			}
		} catch (ResourceAccessException e) {
			LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, ExceptionUtils.getStackTrace(e));
		} catch (RestClientException e) {
			LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
		} catch (Exception e) {
			LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
			throw(e);
		}
		
		return retryResponse;
		
	}
	
//	public ResponseEntity<?> retryRequestAutoEnroll(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod){
//
//		ResponseEntity<?> retryResponse = null;
//		try {
//			retryResponse = restTemplateAutoEnroll.exchange(uri, httpMethod, requestEntity, clazz);
//
//		} catch (HttpServerErrorException e ) {
//			LOGGER.error("Error gateway check, error={}", e.getStatusCode());
//			if (e.getStatusCode().equals(HttpStatus.GATEWAY_TIMEOUT)) {
//				List<String> gatewayInserted = new ArrayList<String>();
//				gatewayInserted.add("Documents sent to FDS to be processed");
//				FDSMultiPostResponse gatewayResponse = new FDSMultiPostResponse();
//				gatewayResponse.setInserted(gatewayInserted);
//				retryResponse = new ResponseEntity<>(gatewayResponse, HttpStatus.OK);
//				return retryResponse;
//			}
//			else {
//				LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
//				throw(e);
//			}
//		} catch (HttpClientErrorException e) {
//			if (e.getStatusCode().equals(HttpStatus.BAD_REQUEST) && e.getResponseBodyAsString().contains(INVALID_GRANT)) {
//				LOGGER.error("sendRequest caught invalid_grant exception, oauth token expired, retrying: uri={}, responseEntity={}, error={}.",
//						uri, retryResponse, ExceptionUtils.getStackTrace(e));
//				throw(e);
//			} else {
//				LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, ExceptionUtils.getStackTrace(e));
//			}
//		} catch (ResourceAccessException e) {
//			LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, ExceptionUtils.getStackTrace(e));
//		} catch (RestClientException e) {
//			LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
//			throw(e);
//		} catch (Exception e) {
//			LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e));
//			throw(e);
//		}
//
//		return retryResponse;
//
//	}

	public ResponseEntity<?> retryDigiSecRequest(String uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod, String cid) {
		ResponseEntity<?> retryResponse = null;
		try {
			retryResponse = restTemplate.exchange(uri, httpMethod, requestEntity, clazz);
		} catch (HttpClientErrorException e) {
			// If PES API receives invalid corporateMpin, then it returns 500 null, and should not be retried
			if (e.getStatusCode().equals(HttpStatus.BAD_REQUEST) || uri.contains("paa")) {
				LOGGER.error("sendRequest caught exception, not retrying: e={}, CID={}", e.getMessage(), Encode.forJava(cid));
				return retryResponse;
			}
		} catch (ResourceAccessException e) {
			if (uri.contains("paa")) {
				return retryResponse;
			}
			LOGGER.error("ResourceAccessException -> sendRequest caught exception, retrying: uri={}, requestEntity={}, responseEntity={}, error={}, CID={}",
					uri,Encode.forJava((String) requestEntity.getBody()), retryResponse, e.getMessage(), Encode.forJava(cid));
		} catch (RestClientException e) {
			LOGGER.error("RestClientException -> sendRequest caught exception, retrying: uri={}, requestEntity={}, responseEntity={}, error={}, CID={}",
					uri, Encode.forJava((String) requestEntity.getBody()), retryResponse, ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
		} catch (Exception e) {
			LOGGER.error("Exception -> sendRequest caught exception, retrying: uri={}, requestEntity={}, responseEntity={}, error={}, CID={}",
					uri, Encode.forJava((String) requestEntity.getBody()), retryResponse, ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
		}

		return retryResponse;
	}

	public ResponseEntity<?> sendRequestURI(URI uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod, String cid) throws ApplicationException {

		ResponseEntity<?> responseEntity = null;

		String message = "Service sendRequest: requestEntity=" + requestEntity;
		try {

			responseEntity = retryRequestURI(uri, requestEntity, clazz, httpMethod, Encode.forJava(cid));

			if (responseEntity != null && (HttpStatus.OK.equals(responseEntity.getStatusCode()) || HttpStatus.CREATED.equals(responseEntity.getStatusCode()))) {
				return responseEntity;
			}

			LOGGER.info(firstRequestFail, Encode.forJava(cid));

			int retryCount = numRetries;
			while ((responseEntity == null || !HttpStatus.OK.equals(responseEntity.getStatusCode()) || !HttpStatus.CREATED.equals(responseEntity.getStatusCode())) && (retryCount-- > 0)) {

				LOGGER.info(retryCountStr, retryCount, Encode.forJava(cid));
				LOGGER.info(timeToWait, timeToWaitMsArr[retryCount], Encode.forJava(cid));

				try {
					synchronized(this) {
						this.wait(timeToWaitMsArr[retryCount]);
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				responseEntity = retryRequestURI(uri, requestEntity, clazz, httpMethod, Encode.forJava(cid));
				LOGGER.warn(requestRetry, Encode.forJava((String) requestEntity.getBody()), retryCount, Encode.forJava(cid));
			}

			// if responseEntity is null, throw a NullPointerException
			Objects.requireNonNull(responseEntity);

			if (!HttpStatus.OK.equals(responseEntity.getStatusCode()) || !HttpStatus.CREATED.equals(responseEntity.getStatusCode())) {
				LOGGER.warn(requestFailed, responseEntity.getStatusCode(), Encode.forJava((String) requestEntity.getBody()), Encode.forJava(cid));
				return responseEntity;
			}

//			LOGGER.info(successRequest, responseEntity.getStatusCode(), responseEntity.getBody());
//			NessAppLog.createNessLogEvent(message + " Response = " + responseEntity);
			return responseEntity;

		}
		catch (Exception e) {
			LOGGER.error(serviceCallError, uri, Encode.forJava((String) requestEntity.getBody()), ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
		}
		return responseEntity;

	}

	public ResponseEntity<?> retryRequestURI(URI uri, HttpEntity<?> requestEntity, Class<?> clazz, HttpMethod httpMethod, String cid) {
		ResponseEntity<?> retryResponse = null;
		try {
			retryResponse = restTemplate.exchange(uri, httpMethod, requestEntity, clazz);
		} catch (HttpServerErrorException e) {
			if (e.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR) && e.getStatusText() == null) {
				LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
				throw(e);
			} else {
				LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
			}
		} catch (ResourceAccessException | HttpClientErrorException e) {
			LOGGER.error(SEND_REQUEST_LOG, uri, retryResponse, e.getMessage(), Encode.forJava(cid));
		} catch (RestClientException e) {
			LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
		} catch (Exception e) {
			LOGGER.error(exceptionRequest, uri, retryResponse, ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
			throw(e);
		}

		return retryResponse;
	}

	private static Boolean checkDigiSecResponseEntity(ResponseEntity<?> responseEntity, List<HttpStatus> digiSecPass, String uri) {
		if ((responseEntity == null && !uri.contains("paa")) || 
		(responseEntity != null && !digiSecPass.contains(responseEntity.getStatusCode()))) {
			return true;
		}
		return false;
	}
	
	private static Boolean checkFDSResponseEntity(ResponseEntity<?> responseEntity) {
		if (responseEntity != null && (HttpStatus.OK.equals(responseEntity.getStatusCode()) || HttpStatus.CREATED.equals(responseEntity.getStatusCode()))) {
			return true;
		}
		return false;
	}
	
//	public static Boolean checkUnirestResponseEntity(HttpResponse<JsonNode> responseEntity) {
//		if ((responseEntity != null && ok.equals(responseEntity.getStatus())) ||
//				(checkDocNotFound(responseEntity))) {
//			return true;
//		}
//		return false;
//	}
	
//	public static Boolean checkDocNotFound(HttpResponse<JsonNode> responseEntity) {
//		try {
//			if (responseEntity != null && responseEntity.getBody() != null && responseEntity.getBody().getObject() != null && responseEntity.getBody().getObject().get(DETAILS) != null &&
//					responseEntity.getBody().getObject().get(DETAILS).toString().toLowerCase().contains(DOCUMENT_NOT_FOUND)) {
//						return true;
//					}
//		}
//		catch (Exception e) {
//			return false;
//		}
//		return true;
//	}
}