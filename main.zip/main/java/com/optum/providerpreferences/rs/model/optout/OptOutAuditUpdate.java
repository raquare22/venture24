package com.optum.providerpreferences.rs.model.optout;

public class OptOutAuditUpdate {
	
	private String deliveryMethod;
	private String okToChangePDOInd;
	private String autoEdelUpdateInd;
	
	private String lastUpdatedBy;
	private String lastUpdatedById;
	private String autoOptOutInd;
	
	private Integer optedOutDuration;
	private String optedOutDateTime;
	private String expiryDate;
	private Long expiryDateEpoch;

	private String subscribeToEmail;
	
	public String getDeliveryMethod() {
		return deliveryMethod;
	}
	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}
	public String getOkToChangePDOInd() {
		return okToChangePDOInd;
	}
	public void setOkToChangePDOInd(String okToChangePDOInd) {
		this.okToChangePDOInd = okToChangePDOInd;
	}
	public String getAutoEdelUpdateInd() {
		return autoEdelUpdateInd;
	}
	public void setAutoEdelUpdateInd(String autoEdelUpdateInd) {
		this.autoEdelUpdateInd = autoEdelUpdateInd;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public String getLastUpdatedById() {
		return lastUpdatedById;
	}
	public void setLastUpdatedById(String lastUpdatedById) {
		this.lastUpdatedById = lastUpdatedById;
	}
	public String getAutoOptOutInd() {
		return autoOptOutInd;
	}
	public void setAutoOptOutInd(String autoOptOutInd) {
		this.autoOptOutInd = autoOptOutInd;
	}
	public Integer getOptedOutDuration() {
		return optedOutDuration;
	}
	public void setOptedOutDuration(Integer optedOutDuration) {
		this.optedOutDuration = optedOutDuration;
	}
	public String getOptedOutDateTime() {
		return optedOutDateTime;
	}
	public void setOptedOutDateTime(String optedOutDateTime) {
		this.optedOutDateTime = optedOutDateTime;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public Long getExpiryDateEpoch() {
		return expiryDateEpoch;
	}
	public void setExpiryDateEpoch(Long expiryDateEpoch) {
		this.expiryDateEpoch = expiryDateEpoch;
	}
	public String getSubscribeToEmail() {
		return subscribeToEmail;
	}
	public void setSubscribeToEmail(String subscribeToEmail) {
		this.subscribeToEmail = subscribeToEmail;
	}
	@Override
	public String toString() {
		return "OptOutAuditUpdate [deliveryMethod=" + deliveryMethod + ", okToChangePDOInd=" + okToChangePDOInd
				+ ", autoEdelUpdateInd=" + autoEdelUpdateInd + ", lastUpdatedBy=" + lastUpdatedBy + ", lastUpdatedById="
				+ lastUpdatedById + ", autoOptOutInd=" + autoOptOutInd + ", optedOutDuration=" + optedOutDuration
				+ ", optedOutDateTime=" + optedOutDateTime + ", expiryDate=" + expiryDate + ", expiryDateEpoch="
				+ expiryDateEpoch + ", subscribeToEmail=" + subscribeToEmail + "]";
	}
	
	

}
