package com.optum.providerpreferences.rs.model.ndb.provider;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ResponseHeader
{

    private int returnCode;

    private String[] explanationCode;

    public String[] getExplanationCode() {
        return explanationCode;
    }

    public void setExplanationCode(String[] explanationCode) {
        this.explanationCode = explanationCode;
    }

    public int getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(int returnCode) {
        this.returnCode = returnCode;
    }

}
