package com.optum.providerpreferences.rs.model.optout;

import java.util.List;

public class OptOutTinResponse {
	
	private List<String> tins;
	
	public OptOutTinResponse(List<String> tins) {
		this.tins = tins;
	}

	public List<String> getTins() {
		return tins;
	}

	public void setTins(List<String> tins) {
		this.tins = tins;
	}

	@Override
	public String toString() {
		return "OptOutTinResponse [tins=" + tins + "]";
	}
}
