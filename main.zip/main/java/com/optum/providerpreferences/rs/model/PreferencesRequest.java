package com.optum.providerpreferences.rs.model;

public class PreferencesRequest { 
	
	private String tin;
	private String mpin;
	
	public String getTin() {
		return tin;
	}
	public void setTin(String tin) {
		this.tin = tin;
	}
	public String getMpin() {
		return mpin;
	}
	public void setMpin(String mpin) {
		this.mpin = mpin;
	}
	@Override
	public String toString() {
		return "PreferencesRequest [tin=" + tin + ", mpin=" + mpin + "]";
	} 
	
	

}
