package com.optum.providerpreferences.rs.model.ndb.provider;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CorpMpinResponse
{
    // NDB has SOAP style JSON objects in use for RESTful services
    // meaning the response object contains the request information as well
    // just like a SOAP service uses the same XML structure throughout
    private RequestHeader requestHeader;

    private RequestData requestData;

    private ResponseHeader responseHeader;

    private ResponseData response;

    public RequestHeader getRequestHeader()
    {
        return requestHeader;
    }

    public void setRequestHeader(RequestHeader requestHeader)
    {
        this.requestHeader = requestHeader;
    }

    public ResponseHeader getResponseHeader()
    {
        return responseHeader;
    }

    public void setResponseHeader(ResponseHeader responseHeader)
    {
        this.responseHeader = responseHeader;
    }

    public RequestData getRequestData()
    {
        return requestData;
    }

    public void setRequestData(RequestData requestData)
    {
        this.requestData = requestData;
    }

    public ResponseData getResponse()
    {
        return response;
    }

    public void setResponse(ResponseData response)
    {
        this.response = response;
    }

}
