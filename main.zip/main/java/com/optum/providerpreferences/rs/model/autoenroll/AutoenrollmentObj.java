package com.optum.providerpreferences.rs.model.autoenroll;

public class AutoenrollmentObj {
	
	private String tin;
	
	private String mpin;
	
	private String fileName;
	
	private String providerEmailId;
	
	private String activeDate;
	
	private String corpMpin;

	public String getTin() {
		return tin;
	}

	public void setTin(String tin) {
		this.tin = tin;
	}

	public String getMpin() {
		return mpin;
	}

	public void setMpin(String mpin) {
		this.mpin = mpin;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getProviderEmailId() {
		return providerEmailId;
	}

	public void setProviderEmailId(String providerEmailId) {
		this.providerEmailId = providerEmailId;
	}

	public String getActiveDate() {
		return activeDate;
	}

	public void setActiveDate(String activeDate) {
		this.activeDate = activeDate;
	}

	public String getCorpMpin() {
		return corpMpin;
	}

	public void setCorpMpin(String corpMpin) {
		this.corpMpin = corpMpin;
	}

	@Override
	public String toString() {
		return "AutoenrollmentObj [tin=" + tin + ", mpin=" + mpin + ", fileName=" + fileName + ", providerEmailId="
				+ providerEmailId + ", activeDate=" + activeDate + ", corpMpin=" + corpMpin + "]";
	}
	
	

}
