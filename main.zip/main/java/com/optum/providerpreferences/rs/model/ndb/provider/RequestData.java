package com.optum.providerpreferences.rs.model.ndb.provider;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;


@JsonInclude(Include.NON_NULL)
public class RequestData
{
    @Pattern(regexp = "^[0-9]{9}$")
    @Size(min = 9, max = 9, message = "Tax Id must be 9 digits")
    private String taxIdNumber;

    @Pattern(regexp = "^[0-9]{9}$")
    @Size(min = 9, max = 9, message = "CorpOwner Id must be 9 digits")
    private String corpOwnerId;

    public RequestData()
    {
    }

    public RequestData(String taxIdNumber, String corpOwnerId)
    {
        super();
        this.taxIdNumber = taxIdNumber;
        this.corpOwnerId = corpOwnerId;
    }

    public String getTaxIdNumber()
    {
        return taxIdNumber;
    }

    public void setTaxIdNumber(String taxIdNumber)
    {
        this.taxIdNumber = taxIdNumber;
    }

    public String getCorpOwnerId()
    {
        return corpOwnerId;
    }

    public void setCorpOwnerId(String corpOwnerId)
    {
        this.corpOwnerId = corpOwnerId;
    }

	@Override
	public String toString() {
		return "RequestData [taxIdNumber=" + taxIdNumber + ", corpOwnerId=" + corpOwnerId + "]";
	}

}
