package com.optum.providerpreferences.rs.model;

public class LogRequest {
	
	private String log;
	private String timestamp;
	
	public String getLog() {
		return log;
	}
	public void setLog(String log) {
		this.log = log;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	@Override
	public String toString() {
		return "LogRequest [log=" + log + ", timestamp=" + timestamp + "]";
	}
	
	

}
