package com.optum.providerpreferences.rs.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.util.Date;

@Document(collection = "paymentPreference")
public class PaymentPreference implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;
    private String tin;
    private String mpin;
    private String corporateMpin;
    private String paymentPref;
    private String accountNumber;
    private String updatedBy;
    private String updatedByName;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private Date dateCreated;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    private Date dateModified;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTin() {
        return tin;
    }
    public void setTin(String tin) {
        this.tin = tin;
    }
    public String getMpin() {
        return mpin;
    }
    public void setMpin(String mpin) {
        this.mpin = mpin;
    }
    public String getPaymentPref() {
        return paymentPref;
    }
    public void setPaymentpref(String paymentPref) {
        this.paymentPref = paymentPref;
    }

    public String getAccountNumber() {
        return accountNumber;
    }
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Date getDateCreated() {
        return dateCreated==null?null:(Date)dateCreated.clone();
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated==null?null:(Date)dateCreated.clone();
    }

    public Date getDateModified() {
        return dateModified==null?null:(Date)dateModified.clone();
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified==null?null:(Date)dateModified.clone();
    }


    public String getCorporateMpin() {
        return corporateMpin;
    }

    public void setCorporateMpin(String corporateMpin) {
        this.corporateMpin = corporateMpin;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdatedByName() {
        return updatedByName;
    }

    public void setUpdatedByName(String updatedByName) {
        this.updatedByName = updatedByName;
    }

    @Override
    public String toString() {
        return "PaymentPreference [id=" + id + ", tin=" + tin + ", mpin=" + mpin + ", paymentPref=" + paymentPref +
                ", accountNumber=" + accountNumber + ", updatedBy=" + updatedBy + ", dateCreated=" + dateCreated + ", dateModified=" + dateModified +
                ", corporateMpin=" + corporateMpin +
                ", updatedByName=" + updatedByName + "]";
    }
}
