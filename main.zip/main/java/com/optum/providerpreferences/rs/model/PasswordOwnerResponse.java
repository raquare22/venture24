package com.optum.providerpreferences.rs.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class PasswordOwnerResponse {
	
		private String optumUUID;
		
	    @JsonInclude(Include.NON_EMPTY)
	    private List<PasswordOwnerInfo> corporates;
	    
	    

}
