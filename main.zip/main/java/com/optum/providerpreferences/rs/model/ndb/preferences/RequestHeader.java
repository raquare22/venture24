package com.optum.providerpreferences.rs.model.ndb.preferences;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class RequestHeader
{
    private String callingprogram;

    private String userid;

    private String userofccd;
    
    private String sqlCode;

    public RequestHeader()
    {
    }

    public RequestHeader(String callingprogram, String userid, String userofccd, String sqlCode)
    {
        this.callingprogram = callingprogram;
        this.userid = userid;
        this.userofccd = userofccd;
        this.sqlCode = sqlCode;
    }


    public String getcallingprogram()
    {
        return callingprogram;
    }

    public void setcallingprogram(String callingprogram)
    {
        this.callingprogram = callingprogram;
    }

    public String getUserid()
    {
        return userid;
    }

    public void setUserid(String userid)
    {
        this.userid = userid;
    }

    public String getUserofccd()
    {
        return userofccd;
    }

    public void setUserofccd(String userofccd)
    {
        this.userofccd = userofccd;
    }

	public String getSqlCode() {
		return sqlCode;
	}

	public void setSqlCode(String sqlCode) {
		this.sqlCode = sqlCode;
	}

	@Override
	public String toString() {
		return "RequestHeader [callingprogram=" + callingprogram + ", userid=" + userid + ", userofccd=" + userofccd
				+ ", sqlCode=" + sqlCode + "]";
	}
}
