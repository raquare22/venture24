package com.optum.providerpreferences.rs.model.fds;

public final class PDOConstants {
	
	public static final String CORP_MPIN = "corpMpin";
	public static final String UUID = "uuid";
	
	public static final String SEARCH_TERMS = "searchTerms";
	public static final String DOCUMENT_ID = "documentId";
	
	public static final String TIN = "tin";
	public static final String MPIN = "mpin";
	public static final String PROVIDER_EMAIL_ID = "providerEmailId";
	
	public static final String FILENAME = "fileName";
	public static final String DELIVERY_METHOD = "deliveryMethod";
	public static final String FILE_TYPE = "fileType";
	
	public static final String ACTIVE_DATE = "activeDate";
	public static final String OK_TO_CHANGE_PDO_IND = "okToChangePDOInd";
	public static final String AUTO_EDEL_UPDATE_IND = "autoEdelUpdateInd";
	public static final String FREQUENCY = "frequency";
	
	// opt out fields
	
	public static final String LAST_UPDATED_BY = "lastUpdatedBy";
	public static final String LAST_UPDATED_BY_ID = "lastUpdatedById";
	public static final String OPTED_OUT_DATE_TIME = "optedOutDateTime";	
	public static final String OPTED_OUT_DURATION = "optedOutDuration";	
	
	public static final String EXPIRY_DATE = "expiryDate";
	public static final String EXPIRY_DATE_EPOCH = "expiryDateEpoch";
	public static final String AUTO_OPT_OUT_IND = "autoOptOutInd";
	public static final String SUBSCRIBE_TO_EMAIL = "subscribeToEmail";
	
	public static final String CREATED_ON = "createdOn";
	
	private PDOConstants(){}
}
