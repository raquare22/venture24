package com.optum.providerpreferences.rs.model;

public class ProviderEmailRequest {
	
	private String corpMpin;

	public String getCorpMpin() {
		return corpMpin;
	}

	public void setCorpMpin(String corpMpin) {
		this.corpMpin = corpMpin;
	}

	@Override
	public String toString() {
		return "ProviderEmailRequest [corpMpin=" + corpMpin + "]";
	}
	
	

}
