package com.optum.providerpreferences.rs.model;

import java.util.List;

public class OONProviderPopUpDate {

    private boolean responseFlag;
    private String providerEmailId;

    public OONProviderPopUpDate(boolean responseFlag, String providerEmailId){
        this.responseFlag = responseFlag;
        this.providerEmailId = providerEmailId;
    }

    public OONProviderPopUpDate() {
    }

    public boolean isResponseFlag(){ return responseFlag; }

    public void setResponseFlag(boolean responseFlag){ this.responseFlag = responseFlag; }

    public String getProviderEmailId(){ return providerEmailId; }

    public void setProviderEmailId(String providerEmailId)
    {
        this.providerEmailId = providerEmailId;
    }

    @Override
    public String toString()
    {
        return "OONProviderPopUpDate [responseFlag=" + responseFlag +
                ", providerEmailId=" + providerEmailId + "]" ;
    }


}
