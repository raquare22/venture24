package com.optum.providerpreferences.rs.model.optout;

public class OptOutTinRequest {
	
	private String corporateMpin;

	public String getCorporateMpin() {
		return corporateMpin;
	}

	public void setCorporateMpin(String corporateMpin) {
		this.corporateMpin = corporateMpin;
	}

	@Override
	public String toString() {
		return "OptOutTinRequest[ corporateMpin=" + corporateMpin + "]";
	}
}
