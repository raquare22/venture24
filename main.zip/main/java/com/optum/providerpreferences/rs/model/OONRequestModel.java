package com.optum.providerpreferences.rs.model;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class OONRequestModel {
    @Pattern(regexp = "^[0-9]{9}$")
    @Size(min = 9, max = 9, message = "CorpOwner Id must be 9 digits")
    String corpOwnerId;
    @Pattern(regexp = "^[0-9]{9}$")
    @Size(min = 9, max = 9, message = "Tax Id must be 9 digits")
    String taxIdNumber;
    String providerEmail;
    Boolean convertToElectronic;

    public String getCorpOwnerId() {
        return corpOwnerId;
    }

    public void setCorpOwnerId(String corpOwnerId) {
        this.corpOwnerId = corpOwnerId;
    }

    public String getTaxIdNumber() {
        return taxIdNumber;
    }

    public void setTaxIdNumber(String taxIdNumber) {
        this.taxIdNumber = taxIdNumber;
    }

    public String getProviderEmail() {
        return providerEmail;
    }

    public void setProviderEmail(String providerEmail) {
        this.providerEmail = providerEmail;
    }

    public Boolean getConvertToElectronic() {
        return convertToElectronic;
    }

    public void setConvertToElectronic(Boolean convertToElectronic) {
        this.convertToElectronic = convertToElectronic;
    }

    @Override
    public String toString() {
        return "OONModel{" +
                "corpMpin='" + corpOwnerId + '\'' +
                ", tin='" + taxIdNumber + '\'' +
                ", providerEmail='" + providerEmail + '\'' +
                ", convertToElectronic=" + convertToElectronic +
                '}';
    }
}
