package com.optum.providerpreferences.rs.model;

public class TinRequest {

	private String uhcID;
	private String mpin;
	private String optumUUID;
	
	public String getUhcID() {
		return uhcID;
	}
	public void setUhcID(String uhcID) {
		this.uhcID = uhcID;
	}
	public String getMpin() {
		return mpin;
	}
	public void setMpin(String mpin) {
		this.mpin = mpin;
	}
	public String getOptumUUID() {
		return optumUUID;
	}
	public void setOptumUUID(String optumUUID) {
		this.optumUUID = optumUUID;
	}
	
	@Override
	public String toString() {
		return "TinRequest [uhcID=" + uhcID + ", mpin=" + mpin + ", optumUUID=" + optumUUID + "]";
	}
	
	
	
}
