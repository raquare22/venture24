package com.optum.providerpreferences.rs.model.fds;

import java.util.ArrayList;
import java.util.List;

import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;

public class FDSCloudGETResponse {

	private String total_records;		
	private String count;
	private String start; 
	private List<OptOutFDSCloudDocument> documents;		
	
	public String getTotal_records() {
		return total_records;
	}
	public void setTotal_records(String total_records) {
		this.total_records = total_records;
	}
	public String getCount() {		
		return count;		
	}		
	public void setCount(String count) {		
		this.count = count;		
	}
	
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public List<OptOutFDSCloudDocument> getDocuments() {		
       if (documents == null)		
       {		
           documents = new ArrayList<>();		
       }		
       return documents;		
	}		
	public void setDocuments(List<OptOutFDSCloudDocument> documents) {		
		this.documents = documents;		
	}		
	@Override		
	public String toString() {		
		return "FDSCloudGETResponse [totalRecords=" + total_records + ", count=" + count + ", documents=" + documents + "]";		
	}		
	
}

