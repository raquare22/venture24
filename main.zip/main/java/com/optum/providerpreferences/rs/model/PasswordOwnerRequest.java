package com.optum.providerpreferences.rs.model;

public class PasswordOwnerRequest {
	
	private String optumUUID;

	public String getOptumUUID() {
		return optumUUID;
	}

	public void setOptumUUID(String optumUUID) {
		this.optumUUID = optumUUID;
	}

	@Override
	public String toString() {
		return "PasswordOwnerRequest [optumUUID=" + optumUUID + "]";
	}
	
	

}
