/**
 *  Copyright Optum Services Inc., 2017. All rights reserved.
 *  This software and documentation contain confidential and proprietary information owned by Optum Services Inc.,
 *  Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.exception;

public class ApplicationException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public ApplicationException(String message) {
		super(message); 
	}

	public ApplicationException(String message, Throwable cause) {
		super(message, cause);
	}

}
