package com.optum.providerpreferences.rs.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.kafka.NessAppLog;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.model.GenericResponse;
import com.optum.providerpreferences.rs.model.OONProviderPopUpDate;
import com.optum.providerpreferences.rs.model.OONRequestModel;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinData;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import com.optum.providerpreferences.rs.mongo.document.DeliveryPreference;
import com.optum.providerpreferences.rs.service.AsyncComponent;
import com.optum.providerpreferences.rs.service.DocumentService;
import com.optum.providerpreferences.rs.service.ProviderPreferencesService;
import com.optum.providerpreferences.rs.utility.MessageBuilder;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Refill;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;


@RestController
@RequestMapping(value="/api/providers/v1/popup", produces="application/json")
public class OONPopUpController {
    private static final long OON_POPUP_TIMEOUT_SECONDS = 5;
    private static final ExecutorService OON_POPUP_EXECUTOR = java.util.concurrent.Executors.newFixedThreadPool(10);
    private final Bucket bucket1;
    private final Bucket bucket2;
    private final Bucket bucket3;

    public OONPopUpController() {
        Bandwidth limit1 = Bandwidth.classic(60, Refill.greedy(600, Duration.ofMinutes(1)));
        this.bucket1 = Bucket.builder().addLimit(limit1).build();
        this.bucket2 = Bucket.builder().addLimit(limit1).build();
        this.bucket3 = Bucket.builder().addLimit(limit1).build();
    }

    @Autowired
    ProviderPreferencesService providerPreferencesService;
    @Autowired
    MessageBuilder messageBuilder;
    @Autowired
    AsyncComponent asyncComponent;
    @Autowired
    ObjectMapper mapper;
    @Autowired
    FDSCloudHandler fdsCloudHandler;
    @Autowired
    DocumentService documentService;

    @Value("${USE_FDSCLOUD}")
    protected boolean useFDSCloud;

    String username="username";
    private static final String TEST_ID = "testId";
    private static final Logger LOGGER = LogManager.getLogger(OONPopUpController.class);
    private NDBHandler ndbHandler;


    @PutMapping(path = "/update")
    @ResponseBody
    public ResponseEntity<GenericResponse> updateOONPopUpDate(@Valid @RequestBody OONRequestModel oonRequest, @RequestHeader HttpHeaders headers, HttpServletRequest requestContext) throws ApplicationException {
        String cid = headers.getFirst("optum-cid-ext");
        long startTime = System.nanoTime();

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("invoking OON Provider Pop up functionality - updateprovider delivery setting - CorpMpin={}, Tin={}, ProviderEmail={}, UpdateToElectronic={}, CID={}",
                    Encode.forJava(oonRequest.getCorpOwnerId()), Encode.forJava(oonRequest.getTaxIdNumber()), Encode.forJava(oonRequest.getProviderEmail()), Encode.forJava(String.valueOf(oonRequest.getConvertToElectronic())), Encode.forJava(cid));
        }

        String message;
        CorpMpinResponse mpinResponse = new CorpMpinResponse();
        List<String> mpinList = new ArrayList<>();
        ndbHandler = new NDBHandler();

        if (bucket2.tryConsume(1)) {
            message = "OON Provider Delivery Update Request " + oonRequest.toString();
            RequestData requestData = new RequestData();
            requestData.setCorpOwnerId(oonRequest.getCorpOwnerId());
            requestData.setTaxIdNumber(oonRequest.getTaxIdNumber());

            try {
                checkFDSCloudForOONDocument(oonRequest.getTaxIdNumber(), Encode.forJava(cid));

                mpinResponse = providerPreferencesService.getProviderData(requestData, headers,
                        messageBuilder.build(requestContext.getRemoteAddr(), headers.getFirst("uuid"), headers.getFirst(username)));
                if (LOGGER.isInfoEnabled()) {
                    LOGGER.info("MPINS RESPONSE, UUID={}, OptumID={}, ProviderTIN={}, CorporateOwnerID={}, providerMPINs={}, CID={}",
                            Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
                            Encode.forJava(requestData.getTaxIdNumber()), Encode.forJava(requestData.getCorpOwnerId()), mpinResponse.getResponse().getMpinList().get(0).getProviderId(), Encode.forJava(cid));
                }
                mpinList = asyncComponent.getMpinsFromResponse(mpinResponse);
                asyncComponent.updatePopup(mpinList, oonRequest, headers);
            } catch (Exception e) {
                long latency = (System.nanoTime() - startTime) / 1000000;
                LOGGER.error("updateOONPopUpDate -> CorpMpin={}, Tin={}, ProviderEmail={}, UpdateToElectronic={}, exception={}, CID={}, Latency={}ms",                        Encode.forJava(oonRequest.getCorpOwnerId()), Encode.forJava(oonRequest.getTaxIdNumber()), Encode.forJava(oonRequest.getProviderEmail()),
                        Encode.forJava(String.valueOf(oonRequest.getConvertToElectronic())), ExceptionUtils.getStackTrace(e), Encode.forJava(cid), latency);
                return new ResponseEntity<GenericResponse>(new GenericResponse("500", "Error updating PopUp Date"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
            ResponseEntity<GenericResponse> responseEntity = new ResponseEntity<GenericResponse>(new GenericResponse("200", "Preferences updated"), HttpStatus.OK);
            long latency = (System.nanoTime() - startTime) / 1000000;
            LOGGER.info("updateOONPopUpDate request received successfully-> CorpMpin={}, Tin={}, ProviderEmail={}, UpdateToElectronic={}, CID={}, Latency={}ms", Encode.forJava(oonRequest.getCorpOwnerId()), Encode.forJava(oonRequest.getTaxIdNumber()), Encode.forJava(oonRequest.getProviderEmail()), Encode.forJava(String.valueOf(oonRequest.getConvertToElectronic())), Encode.forJava(cid), latency);
            NessAppLog.createHttpLogEvent(headers, message, responseEntity);
            return responseEntity;
        } else {
            LOGGER.info("Too many requests made. Wait for 1 minute and try again. CID={}", Encode.forJava(cid));
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
        }
    }

    private OONProviderPopUpDate fetchOONPopUpDate(RequestData request, HttpHeaders headers, HttpServletRequest requestContext, String cid) throws ApplicationException, IOException, OAuthProblemException, OAuthSystemException, ParseException {
        LOGGER.info("Invoking getOONPopUpDate - POST, CID={}", Encode.forJava(cid));
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("OON POPUP REQUEST, UUID={}, OptumID={}, ProviderTIN={}, CorporateOwnerID={}, CID={}",
                    Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
                    Encode.forJava(request.getTaxIdNumber()), Encode.forJava(request.getCorpOwnerId()), Encode.forJava(cid));
        }
        CorpMpinResponse mpinListResponse = providerPreferencesService.getProviderData(request, headers,
                messageBuilder.build(requestContext.getRemoteAddr(), headers.getFirst("uuid"), headers.getFirst(username)));
        List<MpinData> mpinListData = mpinListResponse.getResponse().getMpinList();
        List<String> mpins = new ArrayList<>();
        for (MpinData mpindata : mpinListData) {
            mpins.add(mpindata.getProviderId());
        }
        return providerPreferencesService.getProviderOONPopUpDateFDSCloud(request.getTaxIdNumber(), request.getCorpOwnerId(), mpins, headers);
    }


    @PostMapping(path = "/getPopup")
    @ResponseBody
    public ResponseEntity<OONProviderPopUpDate> getOONPopUpDate(@Valid @RequestBody RequestData request,
                                             @RequestHeader HttpHeaders headers, HttpServletRequest requestContext) throws ApplicationException {
        String cid = headers.getFirst("optum-cid-ext");
        long startTime = System.nanoTime();

        if (bucket3.tryConsume(1)) {
            String message = "POST getOONPopUpDate=" + request.toString();
            try {
                CompletableFuture<OONProviderPopUpDate> future = CompletableFuture.supplyAsync(() -> {
                try {
                    return fetchOONPopUpDate(request, headers, requestContext, cid);
                } catch (ApplicationException ae) {
                    LOGGER.error("ApplicationException in async OONPopUp fetch: {}", ExceptionUtils.getStackTrace(ae));
                    throw new RuntimeException(ae);
                } catch (Exception e) {
                    LOGGER.error("Unexpected exception in async OONPopUp fetch: {}", ExceptionUtils.getStackTrace(e));
                    throw new RuntimeException(e);
                }
            }, OON_POPUP_EXECUTOR);

                OONProviderPopUpDate popUpResponse = future.get(OON_POPUP_TIMEOUT_SECONDS, java.util.concurrent.TimeUnit.SECONDS);
                NessAppLog.createHttpLogEvent(headers, message, popUpResponse.toString());
                long latency = (System.nanoTime() - startTime) / 1000000;
                LOGGER.info("getOONPopUpDate request processed successfully, CID={}, Latency={}ms", Encode.forJava(cid), latency);
                return new ResponseEntity<>(popUpResponse, HttpStatus.OK);

            } catch (java.util.concurrent.TimeoutException te) {
                LOGGER.warn("getOONPopUpDate timed out after 5 seconds, CID={}", Encode.forJava(cid));
                OONProviderPopUpDate popUpResponse = new OONProviderPopUpDate();
                popUpResponse.setResponseFlag(false);
                return new ResponseEntity<>(popUpResponse, HttpStatus.OK);
            } catch (Exception e) {
                long latency = (System.nanoTime() - startTime) / 1000000;
                LOGGER.error("getOONPopUpDate ApplicationException={}, CID={}, Latency={}ms", ExceptionUtils.getStackTrace(e), Encode.forJava(cid), latency);
                NessAppLog.createHttpLogEvent(headers, message, e.getMessage(), false);
                throw new ApplicationException("Error at getOONPopUpDate" + e.toString());
            }
        } else {
            LOGGER.info("Too many requests made. Wait for 1 minute and try again. CID={}", Encode.forJava(cid));
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
        }
    }


    public void checkFDSCloudForOONDocument(String tin, String cid) {
        try {
            Date currentDate = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            String presentDate = dateFormat.format(currentDate);

            Map<String, Object> metadataPutMap = new HashMap<>();
            metadataPutMap.put("tin", tin);
            metadataPutMap.put("oonModalFlag", "Y");
            metadataPutMap.put("dateLastModalPopup", presentDate);

            Map<String, Object> metadataSearchMap = new HashMap<>();
            metadataSearchMap.put("tin", tin);
            metadataSearchMap.put("oonModalFlag", "Y");
            if(!useFDSCloud){
                List<DeliveryPreference> deliveryPreferences = documentService.getDocumentsBySearchTerms(metadataSearchMap);
                if (deliveryPreferences != null && !deliveryPreferences.isEmpty()) {
                    DeliveryPreference newDoc = new DeliveryPreference();
                    newDoc.setTin(tin);
                    newDoc.setOonModalFlag("Y");
                    newDoc.setLastOONPopUpDate(presentDate);
                    documentService.updateDocument(deliveryPreferences.get(0).getDocumentId(), newDoc);
                }else{
                    DeliveryPreference newDoc = new DeliveryPreference();
                    newDoc.setTin(tin);
                    newDoc.setOonModalFlag("Y");
                    newDoc.setLastOONPopUpDate(presentDate);
                    documentService.createDocument(newDoc);
                }
            }else {
                FDSCloudRequest searchTerms = fdsCloudHandler.createSearchTermsRequestFromMap(metadataSearchMap);
                FDSCloudGETResponse fdsResponse = fdsCloudHandler.FDSCloudGetRequest(TEST_ID, searchTerms, "", Encode.forJava(cid));

                if (!fdsResponse.getDocuments().isEmpty() && fdsResponse.getDocuments().get(0).getMetadata().contains("oonModalFlag")) {
                    //Update the doc
                    FDSCloudRequest postRequest = new FDSCloudRequest();
                    postRequest.setRequest(metadataPutMap);
                    postRequest.setDocumentId(fdsResponse.getDocuments().get(0).getDocumentId());
                    ResponseEntity<OptOutFDSCloudPOSTResponse> response = fdsCloudHandler.FDSCloudPutRequest(TEST_ID, postRequest, Encode.forJava(cid));
                    LOGGER.info("OON UpdatePopup -> FDSCloud OONModal-Document found : Response={} .\nUpdating the document with current date, CID={}", response.toString(), Encode.forJava(cid));
                } else {
                    FDSCloudRequest postRequest = new FDSCloudRequest();
                    postRequest.setRequest(metadataPutMap);
                    ResponseEntity<OptOutFDSCloudPOSTResponse> response = fdsCloudHandler.FDSCloudPostRequest(TEST_ID, postRequest, Encode.forJava(cid));
                    LOGGER.info("OON UpdatePopup -> NO FDSCloud OONModal-Document present for the tin.\nCreating a new OONModal-Document for request:{}, CID={}", postRequest.toString(), Encode.forJava(cid));
                }
            }
        } catch (Exception e) {
            LOGGER.error("Error checking FDSCloud for OONModal-Document, error={}, CID={}", ExceptionUtils.getStackTrace(e), Encode.forJava(cid));
        }
    }
}