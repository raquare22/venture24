package com.optum.providerpreferences.rs.controller;

import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.model.OONRequestModel;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponse;
import com.optum.providerpreferences.rs.model.ndb.preferences.MailPref;
import com.optum.providerpreferences.rs.model.ndb.preferences.ResponseData;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinData;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.service.ProviderPreferencesService;
import com.optum.providerpreferences.rs.utility.MessageBuilder;
import com.optum.providerpreferences.rs.utility.ProviderPreferencesUtil;
import jakarta.servlet.http.HttpServletRequest;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Refill;

import jakarta.validation.Valid;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.kafka.NessAppLog;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.GenericResponse;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinResponse;
import com.optum.providerpreferences.rs.service.AsyncComponent;
import com.optum.providerpreferences.rs.service.OptOutService;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;


@RestController
@RequestMapping(value="/api/providers/v1/optout", produces="application/json")
public class OptOutController {

	private final Bucket bucket1;
	private final Bucket bucket2;
	private static final Set<String> PREDEFINED_CATEGORIES = new HashSet<>(Arrays.asList("appeals", "claims", "overpayment", "payment", "priorauth", "housecalls"));

	public OptOutController() {
		Bandwidth limit1 = Bandwidth.classic(60, Refill.greedy(60, Duration.ofMinutes(1)));
		this.bucket1 = Bucket.builder().addLimit(limit1).build();
		this.bucket2 = Bucket.builder().addLimit(limit1).build();
	}
	@Autowired
	private ProviderPreferencesUtil provPrefUtil;
	@Autowired
	OptOutService optOutService;

	@Autowired
	ProviderPreferencesService providerPreferencesService;
	@Autowired
	MessageBuilder messageBuilder;
	@Autowired
	AsyncComponent asyncComponent;
	@Autowired
	AsyncComponent asyncComp;
    
    @Autowired
    ObjectMapper mapper;

    private static final Logger LOGGER = LogManager.getLogger(OptOutController.class);
	private NDBHandler ndbHandler;
	String username="username";

    @PostMapping(path = "/tins")
    @ResponseBody
	public ResponseEntity<OptOutTinResponse> getTinsByCorpMpin(@RequestBody OptOutTinRequest tinRequest, @RequestHeader HttpHeaders headers) throws ApplicationException {
		String cid = headers.getFirst("optum-cid-ext");
		long startTime = System.nanoTime();

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Invoking getTinsFromCorpMpin: {}, CID={}", Encode.forJava(tinRequest.getCorporateMpin()), Encode.forJava(cid));
		}
		if (bucket1.tryConsume(1)) {
			String message = "getTinsFromCorpMpin " + tinRequest.toString();
			try {
				OptOutTinResponse optOutTinResponse = optOutService.getTins(tinRequest, Encode.forJava(cid));
				NessAppLog.createHttpLogEvent(headers, message, optOutTinResponse.toString());
				long latency = (System.nanoTime() - startTime) / 1000000;
				LOGGER.info("getTinsFromCorpMpin -> /tins: {}, CID={}, latency={}", Encode.forJava(tinRequest.getCorporateMpin()), Encode.forJava(cid), latency);
				return ResponseEntity.of(Optional.of(optOutTinResponse));
			} catch (Exception e) {
				long latency = (System.nanoTime() - startTime) / 1000000;
				NessAppLog.createHttpLogEvent(headers, message, e.getMessage());
				LOGGER.error("Error getting tins from corpMpin, pesTinRequest={}, error={}, latency={}ms, CID={}", Encode.forJava(tinRequest.getCorporateMpin()), ExceptionUtils.getStackTrace(e), latency, Encode.forJava(cid));
				throw new ApplicationException("Error at getTinsByCorpMpin: " + e.toString());
			}
		} else {
			LOGGER.info("Too many requests made. Wait for 1 minute and try again. CID={}", Encode.forJava(cid));
			return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
		}
	}

    @PostMapping(path = "/update")
    @ResponseBody
	public ResponseEntity<GenericResponse> updateMultiDocuments(@RequestBody OptOutRequest optOutRequest, @RequestHeader HttpHeaders headers, HttpServletRequest requestContext) throws ApplicationException {
		String cid = headers.getFirst("optum-cid-ext");
		long startTime = System.nanoTime();

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("invoking async optout updateMultiDocuments, optOutRequest.getCorpMpin={}, optOutRequest.getTin={}, optOutRequest.headers={}, CID={}",
					Encode.forJava(optOutRequest.getCorpMpin()), Encode.forJava(optOutRequest.getTin()), Encode.forJava(headers.toString()), Encode.forJava(cid));
		}

		if (bucket2.tryConsume(1)) {
			String message = "OPTOUT UPDATE REQUEST " + optOutRequest.toString();
			ResponseEntity<GenericResponse> responseEntity = null;
			for (String category : optOutRequest.getCategories()) {
				if (!PREDEFINED_CATEGORIES.contains(category.toLowerCase())) {
					long latency = (System.nanoTime() - startTime) / 1000000;
					LOGGER.error("Failed optout update: Invalid category: {}, CID={}, Latency={}ms", Encode.forJava(category), Encode.forJava(cid), latency);
					return new ResponseEntity<>(new GenericResponse("400", "Invalid category: " + category), HttpStatus.BAD_REQUEST);
				}
			}
			try {
				asyncComp.updateOptOutDocumentsVoid(optOutRequest, headers, Encode.forJava(cid));
				responseEntity = new ResponseEntity<>(new GenericResponse("200", "Optout update request received"), HttpStatus.OK);
				NessAppLog.createHttpLogEvent(headers, message, responseEntity);
				long latency = (System.nanoTime() - startTime) / 1000000;
				LOGGER.info("Optout update request received, optOutRequest={}, latency={}ms, CID={}", Encode.forJava(optOutRequest.toString()), latency, Encode.forJava(cid));
				return responseEntity;
			} catch (Exception e) {
				long latency = (System.nanoTime() - startTime) / 1000000;
				LOGGER.error("Failed optout update, tin={}, lastUpdatedBy={}, lastUpdatedById={}, optedOutDuration={}, error={}, CID={}, Latency={}ms",						Encode.forJava(optOutRequest.getTin()),
						Encode.forJava(optOutRequest.getLastUpdatedBy()),
						Encode.forJava(optOutRequest.getLastUpdatedById()),
						optOutRequest.getOptedOutDuration(), e.toString(), Encode.forJava(cid), latency);
				responseEntity = new ResponseEntity<>(new GenericResponse("500", "Error updating optout"), HttpStatus.INTERNAL_SERVER_ERROR);
				NessAppLog.createHttpLogEvent(headers, message, responseEntity);
				return responseEntity;
			}
		} else {
			LOGGER.info("Too many requests made. Wait for 1 minute and try again. CID={}", Encode.forJava(cid));
			return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
		}
	}

}