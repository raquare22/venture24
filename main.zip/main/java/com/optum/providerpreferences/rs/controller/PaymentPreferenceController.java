package com.optum.providerpreferences.rs.controller;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.GenericResponse;
import com.optum.providerpreferences.rs.model.PaymentPreference;
import com.optum.providerpreferences.rs.service.PaymentPreferenceService;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Refill;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.util.Date;


@RestController
@RequestMapping(value="/api/providers/v1/payment", produces="application/json" )
public class PaymentPreferenceController {

    private final Bucket bucket1;
    private final Bucket bucket2;

    public PaymentPreferenceController() {
        Bandwidth limit = Bandwidth.classic(60, Refill.greedy(300, Duration.ofMinutes(1)));
        this.bucket1 = Bucket.builder().addLimit(limit).build();
        this.bucket2 = Bucket.builder().addLimit(limit).build();
    }

    @Autowired
    private PaymentPreferenceService paymentPreferenceService;

    private static final Logger logger = LogManager.getLogger(PaymentPreferenceController.class);

    @SuppressWarnings("squid:S4684")
    @PostMapping(path = "/preferences")
    @ResponseBody
    public ResponseEntity<PaymentPreference> getPaymentPreference(@RequestBody PaymentPreference preference, @RequestHeader HttpHeaders headers,
                                                                  HttpServletRequest requestContext,  @RequestHeader(value = "optum-cid-ext", required = false) String optumCidExt) throws ApplicationException
    {
        long startTime = System.nanoTime();
        if (bucket1.tryConsume(1)) {
        try {
            logger.info("Invoking getPaymentPreference - POST, CID={}", Encode.forJava(optumCidExt));

            if (preference.getTin() == null || preference.getTin().isEmpty() || preference.getMpin().isEmpty() || preference.getMpin() == null) {
                logger.error("TIN or MPIN values missing in the request headers, CID={}", Encode.forJava(optumCidExt));
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }

            PaymentPreference response = paymentPreferenceService.getPaymentPreferenceByTinAndMpin(preference.getTin(), preference.getMpin());

            if (response == null) {
                response = new PaymentPreference();
                response.setTin(preference.getTin());
                response.setMpin(preference.getMpin());
                response.setDateCreated(new Date());
                response.setPaymentpref("VCP");
                // All other fields remain null

                paymentPreferenceService.insertPaymentPreference(response);

                logger.info("No data found for TIN={}, MPIN={}. Returning default VCP and Inserting in the DB , CID={}",
                        Encode.forJava(preference.getTin()), Encode.forJava(preference.getMpin()), Encode.forJava(optumCidExt));
            }


            long latency = (System.nanoTime() - startTime) / 1000000;
            if (logger.isInfoEnabled()) {
                logger.info("PAYMENT PREFERENCES POST REQUEST, UUID={}, ProviderTIN={}, ProviderMPIN={}, CID={}, Latency={}ms",
                        Encode.forJava(headers.getFirst("uuid")),
                        Encode.forJava(preference.getTin()),
                        Encode.forJava(preference.getMpin()),
                        Encode.forJava(optumCidExt),
                        latency);
            }
            return ResponseEntity.of(java.util.Optional.of(response));
            
        } catch (IllegalArgumentException e) {
            long latency = (System.nanoTime() - startTime) / 1000000;
            logger.error("Invalid argument provided: {}, apiPath=/preferences POST call, error: {}, CID={}, Latency={}ms", e.getMessage(), ExceptionUtils.getStackTrace(e), Encode.forJava(optumCidExt), latency);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        } catch (Exception e) {
            long latency = (System.nanoTime() - startTime) / 1000000;
            logger.error("ApplicationException={}, CID={}, Latency={}ms", ExceptionUtils.getStackTrace(e), Encode.forJava(optumCidExt), latency);
            throw new ApplicationException("Error at getPaymentPreference" + e.toString());
        }
        } else {
            logger.info("Too many requests made. Wait for 1 minute and try again.");
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
        }
    }



    @SuppressWarnings("squid:S4684")
    @PutMapping(path = "/preferences")
    @ResponseBody
    public ResponseEntity<GenericResponse> updatePaymentPreference(@Valid @RequestBody PaymentPreference request,
            @RequestHeader HttpHeaders headers) {
        long startTime = System.nanoTime();
        if (request.getTin() == null || request.getTin().isEmpty() || request.getMpin().isEmpty() || request.getMpin() == null ||
                request.getPaymentPref().isEmpty()  || request.getPaymentPref() == null || request.getUpdatedBy().isEmpty() || request.getUpdatedBy() == null || request.getUpdatedByName().isEmpty() || request.getUpdatedByName() == null) {
            logger.error("TIN or MPIN or PaymentPref or updatedBy or updatedByName values missing in the request headers,  CID={}",
                    Encode.forJava(headers.getFirst("optum-cid-ext")));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new GenericResponse("400", "Invalid request"));
        }
        if (bucket2.tryConsume(1)) {
            try {
                logger.info("Invoking updatePaymentPreference - PUT , CID={}",
                        Encode.forJava(headers.getFirst("optum-cid-ext")));

                paymentPreferenceService.updatePaymentPreference(
                        request.getTin(),request.getMpin(),request.getPaymentPref(), String.valueOf(request.getUpdatedBy()), request.getUpdatedByName());

                long latency = (System.nanoTime() - startTime) / 1000000;
                if (logger.isInfoEnabled()) {
                    logger.info("PAYMENT PREFERENCES PUT REQUEST, UUID={}, ProviderTIN={}, ProviderMPIN={}, PaymentPref={}, UpdatedByName={}, CID={}, latency={} ms",
                            Encode.forJava(headers.getFirst("uuid")),
                            Encode.forJava(request.getTin()),
                            Encode.forJava(request.getMpin()),
                            Encode.forJava(request.getPaymentPref()),
                            Encode.forJava(request.getUpdatedByName()),
                            Encode.forJava(headers.getFirst("optum-cid-ext")),
                            latency);
                }
                // Call service to update the payment preference

                logger.info("Successfully updated preference, TIN={}, MPIN={}, CID={}, Latency={}ms",
                        Encode.forJava(request.getTin()), Encode.forJava(request.getMpin()), Encode.forJava(headers.getFirst("optum-cid-ext")), latency);

                return ResponseEntity.ok(new GenericResponse("200", "Payment Preference updated successfully"));
            } catch (Exception e) {
                long latency = (System.nanoTime() - startTime) / 1000000;
                logger.error("Error updating payment preference, TIN={}, MPIN={}, Error={}, CID={}, Latency={}ms",
                        Encode.forJava(request.getTin()), Encode.forJava(request.getMpin()), e.getMessage(), Encode.forJava(headers.getFirst("optum-cid-ext")), latency);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(new GenericResponse("500", "Error updating Payment Preference"));
            }
        } else {
            logger.info("Too many requests made. Wait for 1 minute and try again.");
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
        }
    }

}
