package com.optum.providerpreferences.rs.controller;

import java.io.IOException;
import java.text.ParseException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.optum.providerpreferences.kafka.KafkaProducer;
import com.optum.providerpreferences.rs.model.*;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinData;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.ndb.provider.ResponseData;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Refill;
import jakarta.servlet.http.HttpServletRequest;

import jakarta.validation.Valid;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.optum.digitalsecurity.model.request.User;
import com.optum.digitalsecurity.model.response.PDOCorporates;
import com.optum.digitalsecurity.model.response.PDOTins;
import com.optum.providerpreferences.kafka.NessAppLog;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.fds.PDOConstants;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.service.AsyncComponent;
import com.optum.providerpreferences.rs.service.DigitalSecurityService;
import com.optum.providerpreferences.rs.service.ProviderPreferencesService;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;
import com.optum.providerpreferences.rs.utility.MessageBuilder;
import com.optum.providerpreferences.rs.utility.SanitizeUtil;
import com.optum.providerpreferences.rs.utility.ClassifierDescription;

@PropertySource(value = "classpath:application.properties", ignoreResourceNotFound = true)
@RestController
@RequestMapping(value="/api/providers/v1", produces="application/json" )
public class ProvPrefDigiSecController
{

    private final Bucket bucket1;
    private final Bucket bucket2;
    private final Bucket bucket3;
    private final Bucket bucket4;
    private final Bucket bucket5;

    public ProvPrefDigiSecController() {
        Bandwidth limit1 = Bandwidth.classic(60, Refill.greedy(300, Duration.ofMinutes(1)));
        this.bucket1 = Bucket.builder().addLimit(limit1).build();
        this.bucket2 = Bucket.builder().addLimit(limit1).build();
        this.bucket3 = Bucket.builder().addLimit(limit1).build();
        this.bucket4 = Bucket.builder().addLimit(limit1).build();
        this.bucket5 = Bucket.builder().addLimit(limit1).build();
    }

    @Autowired
    DigitalSecurityService digitalSecService;
    
    @Autowired
    ProviderPreferencesService providerPreferencesService;

    @Autowired
    MessageBuilder messageBuilder;
    
    @Autowired
    AsyncComponent asyncComponent;
    
    private ApplicationUtil app = new ApplicationUtil();
    
    String username="username";

    private static final  Logger logger = LogManager.getLogger(ProvPrefDigiSecController.class);

    /*
     * An endpoint for the PDO UI (ppl client) to call to log to splunk
     */
    @PostMapping(path = "/log", consumes = "application/json")
    public GenericResponse log(@RequestBody Map<String, String> logMap) {
    	String logMsg = logMap.get("log");
    	String timestamp = logMap.get("timestamp");
    	
    	if (logMsg == null || logMsg.isEmpty()) {
    		return new GenericResponse("400", "Null or empty log message");
    	}
    	
    	if (logger.isInfoEnabled()) {
    		logger.info("PPL CLIENT -- {}, timestamp: {}", Encode.forJava(logMsg), Encode.forJava(timestamp));
    	}
    	return new GenericResponse("200", "Log message received: " + logMsg);
    }

    @PostMapping(path = "/emails")
    @ResponseBody
    public ResponseEntity<User> getEmails(@RequestBody Map<String, String> req, @RequestHeader HttpHeaders headers, HttpServletRequest requestContext) throws ApplicationException {
        String cid = headers.getFirst("optum-cid-ext");
        long startTime = System.nanoTime();

        if (logger.isInfoEnabled()) {
            logger.info("Invoking getEmails, CID={}, req={}, headers={}", Encode.forJava(cid), SanitizeUtil.sanitizeString(req.toString()), SanitizeUtil.sanitizeHttpHeaders(headers));
        }
        ResponseEntity<User> response = null;
        try {
            response = digitalSecService.getEmailsByCorporate(req.get(PDOConstants.CORP_MPIN), headers);
            long latency = (System.nanoTime() - startTime) / 1000000;
            logger.info("Returning response -> /emails CID={}, Latency={}", Encode.forJava(cid),latency);
            return response;
        } catch (ApplicationException | HttpClientErrorException e) {
            long latency = (System.nanoTime() - startTime) / 1000000;
            logger.warn("getEmailsByCorporate -> could not find email, CID={}, error={}, Latency={}ms", Encode.forJava(cid), e.getMessage(), latency);
            return response;
        } catch (Exception e) {
            long latency = (System.nanoTime() - startTime) / 1000000;
            throw new ApplicationException("Error at getEmails, CID=" + Encode.forJava(cid) + ", " + ExceptionUtils.getStackTrace(e)+" Latency="+ latency+ "ms");
        }
    }
   
    /**
     * This resource gives a list of corporate entities associated with a given OptumUUID.
     * 
     * @param providers
     * @param headers
     * @return
     * @throws JsonParseException
     * @throws JsonMappingException
     * @throws IOException
     * @throws ApplicationException
     * @throws OAuthProblemException
     * @throws OAuthSystemException
     */
    @PostMapping(path = "/corporates")
    @ResponseBody
    public ResponseEntity<PDOCorporates> getCorporatesByPasswordOwner(@RequestBody PasswordOwner providers, @RequestHeader HttpHeaders headers,
                                                                      HttpServletRequest requestContext) throws ApplicationException, IOException, OAuthSystemException, OAuthProblemException {
        String cid = headers.getFirst("optum-cid-ext");
        long startTime = System.nanoTime();

        logger.info("Invoking getCorporatesByPasswordOwner, CID={}", Encode.forJava(cid));
        if (logger.isInfoEnabled()) {
            logger.info("CORPORATES REQUEST, UUID={}, CID={}", Encode.forJava(providers.getOptumUUID()), Encode.forJava(cid));
        }
        if (bucket1.tryConsume(1)) {
            PDOCorporates response = digitalSecService.getCorporatesByPasswordOwner(providers.getOptumUUID(), headers,
                    messageBuilder.build(requestContext.getRemoteAddr(), headers.getFirst("uuid"), headers.getFirst(username)));
            long latency = (System.nanoTime() - startTime) / 1000000;
            logger.info("Returning response - '/corporates', CID={}, Latency={}ms", Encode.forJava(cid), latency);
            if (logger.isInfoEnabled()) {
                logger.info("\n" + "CORPORATES RESPONSE: \n" +
                        "UUID: " + Encode.forJava(providers.getOptumUUID()) + " \n" +
                        "OptumID: " + Encode.forJava(headers.getFirst(username)) + " \n" +
                        "UhcID: " + Encode.forJava(response.getCorporates().get(0).getUhcID()) + " \n" +
                        "Provider MPIN: " + Encode.forJava(response.getCorporates().get(0).getMpin()) + " \n" +
                        "Corporate Name: " + Encode.forJava(response.getCorporates().get(0).getCorporateName()) + " \n" +
                        "CID: " + Encode.forJava(cid) + " \n" +
                        "Latency: " + latency + "ms \n");
            }
            String message = "getCorporatesByPasswordOwner: mpin=" + providers.getMpin() + ", tin=" + providers.getTin() + ", CID=" + Encode.forJava(cid);
            NessAppLog.createHttpLogEvent(headers, message, response.toString());
            return ResponseEntity.of(java.util.Optional.of(response));
        } else {
            logger.info("Too many requests made. Wait for 1 minute and try again, CID={}", Encode.forJava(cid));
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
        }
    }

    /**
     * This resource gives the list of TIN's associated with a given mpin.
     * 
     * @param providers
     * @return
     * @throws IOException
     * @throws JsonParseException
     * @throws ApplicationException
     */
    @PostMapping(path = "/tins")
    @ResponseBody
    public ResponseEntity<PDOTins> getProvidersByCorporate(@RequestBody PasswordOwner providers, @RequestHeader HttpHeaders headers, HttpServletRequest requestContext, @RequestHeader(value = "optum-cid-ext", required = false) String optumCidExt)
            throws IOException, ApplicationException {
        long startTime = System.nanoTime();

        if (logger.isInfoEnabled()) {
            logger.info("Invoking getProvidersByCorporate: TINS REQUEST, CID={}, UUID={}, UhcID={}, CorporateMPIN={}",
                    Encode.forJava(optumCidExt), Encode.forJava(providers.getOptumUUID()), Encode.forJava(providers.getUhcID()),
                    Encode.forJava(providers.getMpin()));
        }
        if (bucket2.tryConsume(1)) {
            PDOTins response = digitalSecService.getProvidersByCorporate(providers.getOptumUUID(), providers.getUhcID(), providers.getMpin(),
                    headers, messageBuilder.build(requestContext.getRemoteAddr(), Encode.forJava(headers.getFirst("uuid")),
                            Encode.forJava(headers.getFirst(username))));
            long latency = (System.nanoTime() - startTime) / 1000000;
            String responseformat = response.getProviders().toString();
            if (logger.isInfoEnabled()) {
                logger.info("TINS RESPONSE, CID={}, UUID={}, UhcID={}, CorporateMPIN={}, ProviderTIN={}, Latency={}ms",
                        Encode.forJava(optumCidExt), Encode.forJava(providers.getOptumUUID()), Encode.forJava(providers.getUhcID()),
                        Encode.forJava(providers.getMpin()), responseformat, latency);
            }
            return ResponseEntity.of(java.util.Optional.of(response));
        } else {
            logger.info("Too many requests made. Wait for 1 minute and try again, CID={}", Encode.forJava(optumCidExt));
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
        }
    }

        /**
         * This resource gives the provider preferences associated with a given TIN.
         */
        @PostMapping(path = "/preferences")
        @ResponseBody
        public ResponseEntity<ProviderPreferencesObj> getFileTypesByProviderMpin(@RequestBody PasswordOwner providers, @RequestHeader HttpHeaders headers,
                                                                                 HttpServletRequest requestContext, @RequestHeader(value = "optum-cid-ext", required = false) String optumCidExt) throws ApplicationException {
            long startTime = System.nanoTime();
            if (bucket3.tryConsume(1)) {
                String message = "POST getFileTypesByProviderMpin=" + providers.getMpin();
                try {
                    logger.info("Invoking getProviderPreferences - POST, CID={}", Encode.forJava(optumCidExt));

                    if (providers.getTin() == null || providers.getTin().isEmpty() || providers.getMpin() == null || providers.getMpin().isEmpty()) {
                        logger.error("TIN or MPIN values missing in the request headers, CID={}", Encode.forJava(optumCidExt));
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
                    }

                    if (logger.isInfoEnabled()) {
                        logger.info("PREFERENCES POST REQUEST, CID={}, UUID={}, OptumID={}, ProviderTIN={}, ProviderMPIN={}",
                                Encode.forJava(optumCidExt), Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
                                Encode.forJava(providers.getTin()), Encode.forJava(providers.getMpin()));
                    }

                    ProviderPreferencesObj response = providerPreferencesService.getProviderPreferencesFDSCloud(providers.getTin(), providers.getMpin(), headers,
                            messageBuilder.build(requestContext.getRemoteAddr(), headers.getFirst("uuid"), headers.getFirst(username)));

                    long latency = (System.nanoTime() - startTime) / 1000000;
                    String responseFormat = response.getPreferenceTypes().toString();
                    if (logger.isInfoEnabled()) {
                        logger.info("PREFERENCES POST RESPONSE, CID={}, UUID={}, OptumID={}, ProviderTIN={}, ProviderMPIN={}, PreferenceType={}, Latency={}ms",
                                Encode.forJava(optumCidExt), Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
                                Encode.forJava(response.getCorporateTin()), Encode.forJava(providers.getMpin()), responseFormat, latency);
                    }

                    if (response.getPreferenceTypes().size() < ClassifierDescription.classifierDescriptionHash.size()) {
                        List<String> classifierList = getPreferenceTypesClassifiers(response.getPreferenceTypes());
                        logger.warn("Missing subCategories: CID={}, providers.getTin={}, providers.getMpin={}, response.getPreferenceTypes.size={} < {}, response.getPreferenceTypesClassifiers={}, Latency={}ms",
                                Encode.forJava(optumCidExt), SanitizeUtil.sanitizeStringConatinsOnlyDigits(providers.getTin()), SanitizeUtil.sanitizeStringConatinsOnlyDigits(providers.getMpin()), response.getPreferenceTypes().size(),
                                ClassifierDescription.classifierDescriptionHash.size(), SanitizeUtil.sanitizeToString(classifierList.toString()), latency);
                    }

                    return ResponseEntity.of(java.util.Optional.of(response));
                } catch (IllegalArgumentException e) {
                    long latency = (System.nanoTime() - startTime) / 1000000;
                    logger.error("Invalid argument provided: {}, CID={}, apiPath=/preferences POST call, error: {}, Latency={}ms", e.getMessage(), Encode.forJava(optumCidExt), ExceptionUtils.getStackTrace(e), latency);
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
                } catch (JsonParseException | JsonMappingException e) {
                    long latency = (System.nanoTime() - startTime) / 1000000;
                    logger.error("JSON parsing/mapping error: {}, CID={}, apiPath=/preferences POST call, error: {}, Latency={}ms", e.getMessage(), Encode.forJava(optumCidExt), ExceptionUtils.getStackTrace(e), latency);
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
                } catch (IOException e) {
                    long latency = (System.nanoTime() - startTime) / 1000000;
                    logger.error("IO error occurred: {}, CID={}, apiPath=/preferences POST call, error: {}, Latency={}ms", e.getMessage(), Encode.forJava(optumCidExt), ExceptionUtils.getStackTrace(e), latency);
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
                } catch (OAuthSystemException | OAuthProblemException e) {
                    long latency = (System.nanoTime() - startTime) / 1000000;
                    logger.error("OAuth error occurred: {}, CID={}, apiPath=/preferences POST call, error: {}, Latency={}ms", e.getMessage(), Encode.forJava(optumCidExt), ExceptionUtils.getStackTrace(e), latency);
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
                } catch (Exception e) {
                    long latency = (System.nanoTime() - startTime) / 1000000;
                    logger.error("ApplicationException={}, CID={}, Latency={}ms", ExceptionUtils.getStackTrace(e), Encode.forJava(optumCidExt), latency);
                    throw new ApplicationException("Error at getFileTypesByProviderMpin, CID=" + Encode.forJava(optumCidExt) + ", " + e.toString());
                }
            } else {
                logger.info("Too many requests made. Wait for 1 minute and try again, CID={}", Encode.forJava(optumCidExt));
                return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
            }
        }

    
    public List<String> getPreferenceTypesClassifiers(List<PreferenceType> preferenceTypes)
    {
        List<String > classifierList = new ArrayList<>();
        if (preferenceTypes == null) {
            return classifierList;
        }
        for (PreferenceType preferenceType : preferenceTypes) {
            classifierList.add(preferenceType.getClassifier());
        }
        return classifierList;
    }

    /**
     * This resource is used to update all provider preference documents associated with a given TIN.
     * 
     * @param providerPreferences
     * @return
     * @throws IOException
     * @throws JsonMappingException
     * @throws JsonParseException
//     * @throws com.uhc.upm3.provider.updateletterpreferences.v3.ServiceException_Exception
//     * @throws ServiceException_Exception
     * @throws ParseException
     * @throws ApplicationException
     * @throws OAuthProblemException
     * @throws OAuthSystemException
     */
    @PutMapping(path = "/preferences")
    @ResponseBody
    public ResponseEntity<GenericResponse> updateFileTypesByProviderTin(@RequestBody ProviderPreferencesObj providerPreferences, @RequestHeader HttpHeaders headers,
                                                                        HttpServletRequest requestContext) throws IOException, ParseException, ApplicationException,
            OAuthSystemException, OAuthProblemException {
        long startTime = System.nanoTime();
        String cid = headers.getFirst("optum-cid-ext"); // Extract CID from headers

        if (bucket4.tryConsume(1)) {
            String message = "PUT updateFileTypesByProviderTin " + providerPreferences.toString();
            ResponseEntity<GenericResponse> responseEntity = null;
            try {
                if (logger.isInfoEnabled()) {
                    logger.info("PREFERENCES PUT REQUEST, CID={}, UUID={}, OptumID={}, ProviderTIN={}, ProviderMPIN={}, PreferenceType={}",
                            Encode.forJava(cid), Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
                            Encode.forJava(providerPreferences.getCorporateTin()), Encode.forJava(providerPreferences.getSelectedProviders().toString()),
                            Encode.forJava(providerPreferences.getPreferenceTypes().toString()));
                }
                asyncComponent.updateProviderPreferencesFDSCloudAsync(providerPreferences, headers);
            } catch (Exception e) {
                long latency = (System.nanoTime() - startTime) / 1000000;
                logger.error("Failed to update provider preferences, CID={}, UUID={}, OptumID={}, ProviderPreferenceObj={}, error={}, Latency={}ms",
                        Encode.forJava(cid), Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
                        Encode.forJava(providerPreferences.toString()), e.toString(), latency);
                responseEntity = new ResponseEntity<>(new GenericResponse("500", "Error updating preferences"), HttpStatus.INTERNAL_SERVER_ERROR);
                createHttpLogEvent(headers, message, (ResponseEntity<?>) responseEntity);
            }
            long latency = (System.nanoTime() - startTime) / 1000000;
            String res = app.rerSuccess("Returning PUT response - '/preferences', CID=" + Encode.forJava(cid) + ", Latency=" + latency + "ms");
            logger.info(res);

            responseEntity = new ResponseEntity<>(new GenericResponse("200", "Preferences updated"), HttpStatus.OK);
            createHttpLogEvent(headers, message, (ResponseEntity<?>) responseEntity);

            return responseEntity;
        } else {
            logger.info("Too many requests made. Wait for 1 minute and try again, CID={}", Encode.forJava(cid));
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
        }
    }

    /**
     * This service retrieves Provider Data for the given Corporate MPIN and Tax ID
     *
     * @param request
     * @param headers
     * @param requestContext
     * @return
     * @throws JsonParseException
     * @throws JsonMappingException
     * @throws IOException
//     * @throws ServiceException_Exception
     * @throws ApplicationException
     */
    @PostMapping(path = "/mpins")
    @ResponseBody
    public ResponseEntity<CorpMpinResponse> getProviderData( @Valid @RequestBody com.optum.providerpreferences.rs.model.ndb.provider.RequestData request,
            @RequestHeader HttpHeaders headers, HttpServletRequest requestContext, @RequestHeader(value = "optum-cid-ext", required = false) String optumCidExt)
            throws IOException, ApplicationException {
        if (logger.isInfoEnabled()) {
            logger.info("Invoking getProviderData\n" + "MPINS REQUEST: \n" +
                    "CID: " + Encode.forJava(optumCidExt) + " \n" +
                    "UUID: " + Encode.forJava(headers.getFirst("uuid")) + " \n" +
                    "OptumID: " + Encode.forJava(headers.getFirst(username)) + " \n" +
                    "Provider Tax ID/TIN: " + Encode.forJava(request.getTaxIdNumber()) + " \n" +
                    "Corporate Owner ID: " + Encode.forJava(request.getCorpOwnerId()));
        }

        if (bucket5.tryConsume(1)) {
            CorpMpinResponse response = new CorpMpinResponse();
            try {
                response = providerPreferencesService.getProviderData(request, headers,
                        messageBuilder.build(requestContext.getRemoteAddr(), headers.getFirst("uuid"), headers.getFirst(username)));

                if (logger.isInfoEnabled()) {
                    logger.info("MPINS RESPONSE, CID={}, UUID={}, OptumID={}, ProviderTIN={}, CorporateOwnerID={}, providerMPINs={}",
                            Encode.forJava(optumCidExt), Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
                            Encode.forJava(request.getTaxIdNumber()), Encode.forJava(request.getCorpOwnerId()), response.getResponse().getMpinList().get(0).getProviderId());
                }
            } catch (Exception e) {
                logger.info("MPINS RESPONSE, CID={}, UUID={}, OptumID={}, ProviderTIN={}, CorporateOwnerID={}",
                        Encode.forJava(optumCidExt), Encode.forJava(headers.getFirst("uuid")), Encode.forJava(headers.getFirst(username)),
                		Encode.forJava(request.getTaxIdNumber()), Encode.forJava(request.getCorpOwnerId()));
            }
            return ResponseEntity.of(java.util.Optional.of(response));
        } else {
            logger.info("Too many requests made. Wait for 1 minute and try again, CID={}", Encode.forJava(optumCidExt));
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).build();
        }
    }

	protected void createHttpLogEvent(HttpHeaders headers, String message, ResponseEntity<?> resp) {
		try {
			NessAppLog.createHttpLogEvent(headers, message, resp);
		} catch (Throwable t) {
		}
	}

	protected void createHttpLogEvent(HttpHeaders headers, String message, String desc) {
		try {
			NessAppLog.createHttpLogEvent(headers, message, desc);
		} catch (Throwable t) {
		}
	}

}