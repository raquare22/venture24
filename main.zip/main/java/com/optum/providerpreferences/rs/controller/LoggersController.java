package com.optum.providerpreferences.rs.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.optum.providerpreferences.rs.model.GenericResponse;


@RestController
@RequestMapping(value="/api/loggers/v1", produces="application/json")
public class LoggersController {
	
	@GetMapping(path="/healthcheck")
    public GenericResponse healthCheck() {    
		return new GenericResponse("200", "OK");
    }

}