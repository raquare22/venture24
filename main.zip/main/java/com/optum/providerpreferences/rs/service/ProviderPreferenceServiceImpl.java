/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.optum.digitalsecurity.model.request.User;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.model.OONProviderPopUpDate;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesRequest;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponse;
import com.optum.providerpreferences.rs.model.ndb.preferences.MailPref;
import com.optum.providerpreferences.rs.model.ndb.preferences.RequestHeader;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.mongo.document.DeliveryPreference;
import com.optum.providerpreferences.rs.utility.*;
import com.optum.providerpreferences.rs.utility.ProviderPreferencesUtil.AutoEnrollment;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * This handler contains the main implementation methods for API resources.
 * 
 * @author Provider Paperless Letters
 */
@Service
public class ProviderPreferenceServiceImpl implements ProviderPreferencesService
{

    ObjectMapper mapper = new ObjectMapper();

    @Autowired
    private NDBHandler ndbHandler;

    @Autowired
    private FDSCloudHandler fdsCloudHandler;

    @Autowired
    DigitalSecurityService digitalSecService;

    @Autowired
    DocumentService documentService;

    private PasswordOwnerUtil pwUtil;

    private ApplicationUtil app = new ApplicationUtil();

    @Autowired
    private AsyncComponent asyncComponent;

    @Autowired
    private ProviderPreferencesUtil provPrefUtil;
    
    @Value("${EXCEPTION_LIST}")
    protected String EXCEPTION_LIST;

    @Value("${USE_FDSCLOUD}")
    protected boolean useFDSCloud;

    private static final Logger logger = LogManager.getLogger(ProviderPreferenceServiceImpl.class);

    private static final String SESSION_ID_ALL = "allUpdate";


    @Override
    public CorpMpinResponse getProviderData(RequestData request, HttpHeaders headers, LogMessage logMessage) throws ApplicationException
    {
        String cid = headers.getFirst("optum-cid-ext");

        if (logger.isInfoEnabled()) {
            logger.info("Getting Provider Data from NDB, CID={} session={}",Encode.forJava(cid), Encode.forJava(headers.getFirst("sm_serversessionid")));
        }

        try
        {
            return ndbHandler.getProviderData(request, Encode.forJava(cid));
        }
        catch (ApplicationException | IOException| OAuthSystemException| OAuthProblemException| RestClientException e)
        {
            logger.error("Error retrieving Provider Data from NDB, CID={} error={}", Encode.forJava(cid), e);
            throw new ApplicationException("Error making service call to NDB");
        }

    }

    @Override
    public ProviderPreferencesObj getProviderPreferencesFDSCloud(String tin, String mpin, HttpHeaders headers, LogMessage logMessage) throws ApplicationException {
        String cid = headers.getFirst("optum-cid-ext");

        try {
            mpin = provPrefUtil.padWithLeadingZeros(mpin);
        } catch (ApplicationException e) {
            logger.error("ERROR PADDING MPIN WITH LEADING ZEROS, CID={} error={}", Encode.forJava(cid), e);
            throw e;
        }

        try {

            if (logger.isInfoEnabled()) {
                logger.info("Getting preferences by TIN, CID={} session={}", Encode.forJava(cid), Encode.forJava(headers.getFirst("sm_serversessionid")));
            }

            ProviderPreferencesObj providerPreferences = new ProviderPreferencesObj();
            List<PreferenceType> preferenceTypeList = new ArrayList<>();

            if (logger.isInfoEnabled()) {
                logger.info("Calling NDB Letter Preferences, CID={}, session={}", Encode.forJava(cid), Encode.forJava(headers.getFirst("sm_serversessionid")));
            }
            LetterPreferencesResponse ndbLetterPreferencesResponse = null;

            if (logMessage.getUsername() != null && logMessage.getUsername().equals("CUCUMBERTEST")) {
                PreferenceType preferenceType = new PreferenceType();
                preferenceType.setClassifier(logMessage.getActor());
                preferenceType.setDeliveryMethod("E");
                preferenceTypeList.add(preferenceType);
            } else {
                try {
                    ndbLetterPreferencesResponse = ndbHandler.getProviderLetterPreferences(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(mpin, tin, "I"), Encode.forJava(cid));
                } catch (ApplicationException e) {
                    logger.error("ERROR CALLING NDB GET PREFS, CID={} error={}", Encode.forJava(cid), e);
                    throw new ApplicationException("ERROR CALLING NDB");
                }

                if (ndbLetterPreferencesResponse.getResponseHeader().getMessage() == null) {
                    logger.error("NDB RESPONSE MESSAGE IS NULL - ERROR, CID={}", Encode.forJava(cid));
                    throw new ApplicationException("ERROR CALLING NDB");
                }
                if (!ndbLetterPreferencesResponse.getResponseHeader().getMessage().equals("SUCCESSFUL")) {
                    if (logger.isErrorEnabled()) {
                        logger.error("Error with web service call to NDB Letter Preferences - POST, CID={} message={}", Encode.forJava(cid), Encode.forJava(ndbLetterPreferencesResponse.getResponseHeader().getMessage()));
                    }
                    throw new ApplicationException("ERROR CALLING NDB");
                }
                for (MailPref pref : ndbLetterPreferencesResponse.getRequestResponse().getLtrTypMailPrfList()) {
                    PreferenceType preferenceType = new PreferenceType();
                    preferenceType.setClassifier(pref.getLetterType());
                    preferenceType.setDeliveryMethod(pref.getMailingPref());
                    preferenceTypeList.add(preferenceType);
                }
            }

            List<List<PreferenceType>> prefTypeListArray = Lists.partition(preferenceTypeList, 10);
            List<CompletableFuture<List<PreferenceType>>> completableFutures = new ArrayList<>();
            for (List<PreferenceType> prefTypeSubList : prefTypeListArray) {
                var subListFuture = asyncComponent.getProviderPreferencesFDSCloudAsync(tin, mpin, prefTypeSubList, Encode.forJava(cid));
                completableFutures.add(subListFuture);
            }

            CompletableFuture<Void> combinedFuture = CompletableFuture.allOf(completableFutures.toArray(new CompletableFuture[completableFutures.size()]));
            var combinedFutureResults = combinedFuture.thenApply(t -> completableFutures.stream().map(CompletableFuture::join).collect(Collectors.toList())).join();
            List<PreferenceType> finalPreferenceTypeList = combinedFutureResults.stream().flatMap(List::stream).collect(Collectors.toList());

            providerPreferences.setCorporateTin(tin);
            providerPreferences.setPreferenceTypes(finalPreferenceTypeList);

			int prefCount = (finalPreferenceTypeList == null) ? 0 : finalPreferenceTypeList.size();
			int secCount = (finalPreferenceTypeList == null || finalPreferenceTypeList.isEmpty()) ? 0
					: finalPreferenceTypeList.stream().mapToInt(pt -> pt.getSecondaryProviderEmailIds() == null ? 0
							: pt.getSecondaryProviderEmailIds().size()).max().orElse(0);

			logger.info(
					"Returning ProviderPreferences: CID={}, ProviderTIN={}, MPIN={}, PreferenceTypesCount={}",
					Encode.forJava(cid), Encode.forJava(tin), Encode.forJava(mpin), prefCount);

            return providerPreferences;

        } catch (ApplicationException | RestClientException | NullPointerException | IOException | ParseException e) {
            logger.error("ERROR RETRIEVING PREFERENCES FOR MPIN, CID={} mpin={}, error={}", Encode.forJava(cid), Encode.forJava(mpin), e);
            throw new ApplicationException("ERROR RETRIEVING PREFERENCES FOR MPIN");
        }
    }


    @Override
    public OONProviderPopUpDate getProviderOONPopUpDateFDSCloud(String tin, String corpMpin, List<String> mpins, HttpHeaders headers)
            throws IOException, ApplicationException, ParseException {

        OONProviderPopUpDate popUpResponse = new OONProviderPopUpDate(false,null);
        String cid = headers.getFirst("optum-cid-ext");
        //Returning false if OONModal-document is found with date modified within last 24 hours, skipping all other checks
        Map<String, Object> metadataMapOONDocument = new HashMap<>();
        metadataMapOONDocument.put("tin", tin);
        metadataMapOONDocument.put("oonModalFlag", "Y");
        List<OptOutFDSCloudDocument> oonDocs;
        List<DeliveryPreference> mongoDocs = documentService.getDocumentsBySearchTerms(metadataMapOONDocument);
        if(mongoDocs != null && !mongoDocs.isEmpty()){
            oonDocs = provPrefUtil.convertDeliveryPrefsToOptOutDocs(mongoDocs);
        }
        else {
            FDSCloudRequest searchTerms = fdsCloudHandler.createSearchTermsRequestFromMap(metadataMapOONDocument);
            FDSCloudGETResponse response = fdsCloudHandler.FDSCloudGetRequest("testId", searchTerms, "", Encode.forJava(cid));
            oonDocs = (response != null && response.getDocuments() != null) ? response.getDocuments() : Collections.emptyList();
        }
        try {
            logger.info("OON GetPopup -> OONModal docs found count={}, CID={}", oonDocs.size(), Encode.forJava(cid));
            if (!oonDocs.isEmpty() && oonDocs.get(0).getModifiedOn() != null) {
                Long oonDocDateModified = oonDocs.get(0).getModifiedOn();
                long twentyFourHoursAgo = System.currentTimeMillis() - (24 * 60 * 60 * 1000);

                if (oonDocDateModified >= twentyFourHoursAgo) {
                    popUpResponse.setResponseFlag(false);
                    popUpResponse.setProviderEmailId(null);
                    return popUpResponse;}
            }}catch (Exception e){
            logger.error("OON GetPopup -> FDSCloud OONModal-Document NOT found -> Error : {}", e.getMessage());
        }
        for(String mpin: mpins){

            mpin = StringUtils.leftPad(mpin, 9, "0");
            String subCategory = checkNDBForDeliveryPreference(mpin, tin);

            if(subCategory!=null){

                Map<String, Object> metadataMap = new HashMap<>();
                metadataMap.put("mpin", mpin);
                metadataMap.put("tin", tin);
                metadataMap.put("fileName",subCategory);
                String popUpDate = checkFDSCloudDocumentsForPopUpDate(metadataMap, Encode.forJava(cid));

                if (popUpDate == null) {
                    popUpResponse.setResponseFlag(true);
                    popUpResponse.setProviderEmailId(getPAAEmailFromDigisec(corpMpin,headers));
                }
                else {
                    Date currentDate = new Date();
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
                    Date popUpParsedDate = dateFormat.parse(popUpDate);
                    long millisecondsInDay = 24 * 60 * 60 * 1000;
                    long daysSinceLastPopUp = (currentDate.getTime() - popUpParsedDate.getTime()) / millisecondsInDay;
                    if(daysSinceLastPopUp > 30) {
                        popUpResponse.setResponseFlag(true);
                        popUpResponse.setProviderEmailId(getPAAEmailFromDigisec(corpMpin,headers));
                    }
                }
                return popUpResponse;

            }

        }

        return popUpResponse;
    }

    public String checkNDBForDeliveryPreference(String mpin, String tin) throws ApplicationException {

        LetterPreferencesResponse ndbLetterPreferencesResponse = null;

        try
        {
            ndbLetterPreferencesResponse =
                    ndbHandler.getProviderLetterPreferences(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(mpin, tin, "I"), "");
        }
        catch (ApplicationException e)
        {
            logger.error("ERROR CALLING NDB GET PREFS, error={}", e);
            throw new ApplicationException("ERROR CALLING NDB");
        }

        if (ndbLetterPreferencesResponse.getResponseHeader().getMessage() == null)
        {
            logger.error("NDB RESPONSE MESSAGE IS NULL - ERROR");
            throw new ApplicationException("ERROR CALLING NDB");
        }
        if (!(ndbLetterPreferencesResponse.getResponseHeader().getMessage().equals("SUCCESSFUL")))
        {
            if (logger.isErrorEnabled()) {
                logger.error("Error with web service call to NDB Letter Preferences - POST, message={}",
                        Encode.forJava(ndbLetterPreferencesResponse.getResponseHeader().getMessage()));
            }
            throw new ApplicationException("ERROR CALLING NDB");
        }

        //checking for P delivery value in NDB - if found return the subcategory
        for (MailPref pref : ndbLetterPreferencesResponse.getRequestResponse().getLtrTypMailPrfList())
        {
            String deliveryPref = pref.getMailingPref();
            if(deliveryPref.equals("P")){
                logger.info("checkNDBForDeliveryPreference -> P delivery document found, subcategory={}", Encode.forJava(pref.getLetterType()));
                return pref.getLetterType();
            }
        }
        return null;
    }

    public String checkFDSCloudDocumentsForPopUpDate(Map<String,Object> metadataMap, String cid)
            throws ApplicationException, IOException {

        List<OptOutFDSCloudDocument> sortedDocsList;
        try {
            List<DeliveryPreference> mongoDocs = documentService.getDocumentsBySearchTerms(metadataMap);
            if (mongoDocs != null && !mongoDocs.isEmpty()) {
                sortedDocsList = provPrefUtil.convertDeliveryPrefsToOptOutDocs(mongoDocs);
            }else{
                FDSCloudRequest searchTerms = fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap);
                FDSCloudGETResponse sortedDocs = fdsCloudHandler.FDSCloudGetRequest("testId", searchTerms, "", Encode.forJava(cid));
                sortedDocsList = (sortedDocs != null && sortedDocs.getDocuments() != null)
                        ? sortedDocs.getDocuments()
                        : Collections.emptyList();
            }
        }catch (Exception e) {
                logger.error("checkFDSCloudDocumentsForPopUpDate -> Error retrieving documents: CID={}, error={}", Encode.forJava(cid), e.getMessage());
                return null;
            }

        int lenSortedDocs = sortedDocsList.size();
        String popUpDate = null;

        if (lenSortedDocs > 0) {
            int docIndex = -1;
            OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);

            AutoEnrollment doc0 = provPrefUtil.determineDocumentIndexCloud(
                    sortedDocsList, lenSortedDocs, 0, currentDate, Encode.forJava(cid));

            if (lenSortedDocs == 1) {
                if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {
                    docIndex = 0;
                }
            } else {
                AutoEnrollment doc1 = provPrefUtil.determineDocumentIndexCloud(
                        sortedDocsList, lenSortedDocs, 1, currentDate, Encode.forJava(cid));
                docIndex = provPrefUtil.determineMulti(doc0, doc1);
            }

            if (docIndex >= 0) {
                OptOutFDSCloudDocument doc = sortedDocsList.get(docIndex);
                Metadata metadataObj = mapper.readValue(doc.getMetadata(), Metadata.class);
                logger.info("checkFDSCloudDocumentsForPopUpDate -> metadata={}, CID={}",
                        metadataObj.toString(), Encode.forJava(cid));
                popUpDate = metadataObj.getLastOONPopUpDate();
            }
        }

        return popUpDate;
    }

    public String getPAAEmailFromDigisec(String corpMpin, HttpHeaders headers) throws ApplicationException {
        ResponseEntity<User> response = null;
        String cid = headers.getFirst("optum-cid-ext");

        try {
            response = digitalSecService.getEmailsByCorporate(corpMpin, headers);
            String email = Objects.requireNonNull(response.getBody()).getEmail();
            logger.info("email paa = {}",email);
            return email;
        }
        catch (ApplicationException | NullPointerException | HttpClientErrorException e) {
            logger.warn("getPAAEmailFromDigisec -> could not find email, CID={}, error={}", Encode.forJava(cid),e.getMessage());
            return null;
        }
        catch (Exception e) {
            logger.error("getPAAEmailFromDigisec -> Error: CID={}, error={}", Encode.forJava(cid),ExceptionUtils.getStackTrace(e));
            throw new ApplicationException("Error at getPAAEmailFromDigisec" + ExceptionUtils.getStackTrace(e));
        }
    }


    //unused
//    @Override
//    public void updateProviderPreferencesFDSCloud(ProviderPreferencesObj providerPreferences, HttpHeaders headers)
//    		throws IOException, ApplicationException, OAuthProblemException, OAuthSystemException, ParseException {
//    	logger.info("updateProviderPreferences --> providerPreferences={}, headers={}", providerPreferences, SanitizeUtil.sanitizeHttpHeaders(headers));
//        String cid = headers.getFirst("optum-cid-ext");
//    	headers.setContentType(MediaType.MULTIPART_FORM_DATA);
//        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//        try {
//
//        	ndbHandler = new NDBHandler();
//        	fdsCloudHandler = new FDSCloudHandler();
//
//            if (providerPreferences.getPreferenceTypes().size() == 1 && providerPreferences.getPreferenceTypes().get(0).getClassifier().equalsIgnoreCase("ALL")) {
//                // update all letter types to same prefs
//                PreferenceType masterPref = providerPreferences.getPreferenceTypes().get(0);
//
//                // get oauth tokens and start timer
//                //long startTime = System.currentTimeMillis();
//                ndbHandler.ndbWebServicePrep();
//
//                // FOR EVERY PROVIDER....
//                for (String currentMpin : providerPreferences.getSelectedProviders()) {
//                    currentMpin = provPrefUtil.padWithLeadingZeros(currentMpin);
//                    String currentTin = provPrefUtil.padWithLeadingZeros(providerPreferences.getCorporateTin());
//
//                    // FOR EVERY CLASSIFIER FOR THE CURRENT PROVIDER...
//                    for (String classifier : ClassifierDescription.classifierDescriptionHash.keySet())
//                    {
//                        // UPDATE NDB FOR EVERY CLASSIFIER FOR CURRENT PROVIDER
//
//                        LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
//                        webRequest.setRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(currentMpin, currentTin, "U",
//                                masterPref.getDeliveryMethod(), classifier));
//                        webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));
//
//                        try {
//                            ndbHandler.updateProviderLetterPreferences(webRequest, currentMpin, currentTin, Encode.forJava(cid));
//                        } catch (JsonProcessingException e) {
//                            logger.error("ERROR UPDATING TO NDB, mpin={}, tin={}, error={}", currentMpin, currentTin, e);
//                            throw e;
//                        }
//
//                        // UPDATE FDS FOR EVERY CLASSIFIER FOR CURRENT PROVIDER
//                        // get the current document in fds for the classifier, mpin, and tin
//
//                        Map<String, Object> metadataMap = new HashMap<>();
//                        metadataMap.put("tin", currentTin);
//                        metadataMap.put("mpin", currentMpin);
//                        metadataMap.put("fileName", classifier);
//                        FDSCloudRequest searchTerms=fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap);
//    	                FDSCloudGETResponse response=fdsCloudHandler.FDSCloudGetRequest("testId", searchTerms, "", Encode.forJava(cid));
//                        // build document to add/update
//                        Map<String, Object> docToSend;
//            			FDSCloudRequest postRequest = new FDSCloudRequest();
//
//
//                        String docId;
//                        String activeDateStr;
//                        String subscribeToEmail;
//
//                        int lenDocs = response.getDocuments().size();
//
//                        if (lenDocs > 0) {
//                        	int docIndex = -1;
//                        	OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);
//
//                        	AutoEnrollment doc0 = provPrefUtil.determineDocumentIndexCloud(response.getDocuments(), lenDocs, 0, currentDate, Encode.forJava(cid));
//                        	AutoEnrollment doc1;
//
//                        	if (lenDocs == 1) {
//                        		// only 1 document
//                        		if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {  // document is pre-autoenrollment doc or autoenrollment doc and its past active date
//                        			docIndex = 0;
//                        		} else if (doc0.isAutoEnrollment && !doc0.isValidAutoEnrollment()) {
//                        			docIndex = -2;
//                        		}
//
//                        	} else {
//                        		// 2 documents, pick the autoenrollment one if after active date, pick pre-autoenrollment one if before active date
//                        		doc1 = provPrefUtil.determineDocumentIndexCloud(response.getDocuments(), lenDocs, 1, currentDate, Encode.forJava(cid));
//            					docIndex = provPrefUtil.determineMulti(doc0, doc1);
//                        	}
//
//                        	if (docIndex >= 0) {
//                        		docId = response.getDocuments().get(docIndex).getDocumentId();
//    	                		OptOutFDSCloudDocument doc = response.getDocuments().get(docIndex);
//    	                		Metadata metadataObj = mapper.readValue(doc.getMetadata(), Metadata.class);
//    	                		activeDateStr = metadataObj.getActiveDate();
//                                subscribeToEmail = metadataObj.getSubscribeToEmail();
//
//
//                        		docToSend = provPrefUtil.createDocToSendWithClassifierCloud(masterPref, provPrefUtil.padWithLeadingZeros(currentMpin), currentTin, docId, activeDateStr,subscribeToEmail, classifier);
//                        		postRequest.setRequest(docToSend);
//                        		postRequest.setDocumentId(docId);
//
//                        		//fds cloud request
//                                try {
//                                	fdsCloudHandler.FDSCloudPutRequest(SESSION_ID_ALL, postRequest, Encode.forJava(cid));
//                                } catch (Exception e) {
//                                	Gson gson = new Gson();
//                                	String requestString = gson.toJson(postRequest.getRequest());
//                                	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", doc.getDocumentId(), requestString);
//                                    continue;
//                                }
//                        	}
//
//                        	if (docIndex == -2) {
//                        		// no pre-autoenrollment document in FDS, must create with null docId and null activeDate
//                        		docToSend = provPrefUtil.createDocToSendWithClassifierCloud(masterPref, provPrefUtil.padWithLeadingZeros(currentMpin), currentTin, null, null, null, classifier);
//                    			postRequest.setRequest(docToSend);
//
//                            	try {
//                            		fdsCloudHandler.FDSCloudPostRequest(SESSION_ID_ALL, postRequest, Encode.forJava(cid));
//                            	} catch (Exception e) {
//                            		Gson gson = new Gson();
//                                	String requestString = gson.toJson(postRequest.getRequest());
//                                	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", null, requestString);
//                                	continue;
//                                }
//
//                        	}
//
//                        } else {
//
//                        	docToSend = provPrefUtil.createDocToSendWithClassifierCloud(masterPref, provPrefUtil.padWithLeadingZeros(currentMpin), currentTin, null, null, null, classifier);
//                    		postRequest.setRequest(docToSend);
//
//                            try {
//                            	fdsCloudHandler.FDSCloudPostRequest(SESSION_ID_ALL, postRequest, Encode.forJava(cid));
//                            }
//                        	catch (Exception e) {
//                        		Gson gson = new Gson();
//                            	String requestString = gson.toJson(postRequest.getRequest());
//                            	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", null, requestString);
//                                continue;
//                            }
//
//                        }
//                    }
//
//                }
//
//            } else {
//                // update the specific preferences passed in
//                List<PreferenceType> prefList = providerPreferences.getPreferenceTypes();
//
//                // get oauth tokens and start timer
//                long startTime = System.currentTimeMillis();
//                ndbHandler.ndbWebServicePrep();
//
//                // FOR EVERY PROVIDER....
//                for (String currentMpin : providerPreferences.getSelectedProviders()) {
//                    currentMpin = provPrefUtil.padWithLeadingZeros(currentMpin);
//                    String currentTin = provPrefUtil.padWithLeadingZeros(providerPreferences.getCorporateTin());
//
//
//                    // FOR EVERY SPECIFIC PREFERENCE FOR CURRENT PROVIDER
//                    for (PreferenceType currentPref : prefList) {
//                        // UPDATE NDB FOR EVERY CLASSIFIER FOR CURRENT PROVIDER
//                        LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
//                        webRequest.setRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(currentMpin, currentTin, "U",
//                                currentPref.getDeliveryMethod(), currentPref.getClassifier()));
//                        webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));
//
//                        try {
//                            ndbHandler.updateProviderLetterPreferences(webRequest, currentMpin, currentTin, cid );
//                        } catch (JsonProcessingException e) {
//                            logger.warn("ERROR UPDATING TO NDB, error={}", e);
////                            throw e;
//                        }
//
//                        // UPDATE FDS FOR EVERY CLASSIFIER FOR CURRENT PROVIDER
//
//                        // get the current document in fds for the classifier, mpin, and tin
//
//
//                        Map<String, Object> metadataMap = new HashMap<>();
//                        metadataMap.put("tin", currentTin);
//                        metadataMap.put("mpin", currentMpin);
//                        metadataMap.put("fileName", currentPref.getClassifier());
//                        FDSCloudRequest searchTerms=fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap);
//    	                FDSCloudGETResponse response=fdsCloudHandler.FDSCloudGetRequest("testId", searchTerms, "", Encode.forJava(cid));
//                        // build document to add/update
//                        Map<String, Object> docToSend;
//            			FDSCloudRequest postRequest = new FDSCloudRequest();
//
//                        String docId;
//                        String activeDateStr;
//                        String subscribeToEmail;
//
//                        int lenDocs = response.getDocuments().size();
//
//                        if (lenDocs > 0) {
//                        	int docIndex = -1;
//                        	OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);
//
//                        	AutoEnrollment doc0 = provPrefUtil.determineDocumentIndexCloud(response.getDocuments(), lenDocs, 0, currentDate, Encode.forJava(cid));
//                        	AutoEnrollment doc1;
//
//                        	if (lenDocs == 1) {
//                        		// only 1 document
//                        		if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {  // document is pre-autoenrollment doc or autoenrollment doc and its past active date
//                        			docIndex = 0;
//                        		} else if (doc0.isAutoEnrollment && !doc0.isValidAutoEnrollment()) {
//                        			docIndex = -2;
//                        		}
//
//                        	} else {
//                        		// 2 documents, pick the autoenrollment one if after active date, pick pre-autoenrollment one if before active date
//                        		doc1 = provPrefUtil.determineDocumentIndexCloud(response.getDocuments(), lenDocs, 1, currentDate, Encode.forJava(cid));
//            					docIndex = provPrefUtil.determineMulti(doc0, doc1);
//                        	}
//
//                        	if (docIndex >= 0) {
//                        		docId = response.getDocuments().get(docIndex).getDocumentId();
//    	                		OptOutFDSCloudDocument doc = response.getDocuments().get(docIndex);
//    	                		Metadata metadataObj = mapper.readValue(doc.getMetadata(), Metadata.class);
//    	                		activeDateStr=metadataObj.getActiveDate();
//                                subscribeToEmail=metadataObj.getSubscribeToEmail();
//
//                        		docToSend = provPrefUtil.createDocToSendCloud(currentPref, provPrefUtil.padWithLeadingZeros(currentMpin), currentTin, docId, activeDateStr, subscribeToEmail);
//
//                        		postRequest.setRequest(docToSend);
//                        		postRequest.setDocumentId(docId);
//
//                                try {
//                                	fdsCloudHandler.FDSCloudPutRequest(SESSION_ID_ALL, postRequest, Encode.forJava(cid));
//                                } catch (Exception e) {
//                                	Gson gson = new Gson();
//                                	String requestString = gson.toJson(postRequest.getRequest());
//                                	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", doc.getDocumentId(), requestString);
//                                    continue;
//                                }
//                        	}
//
//                        	if (docIndex == -2) {
//                        		// no pre-autoenrollment document in FDS, must create with null docId and null activeDate
//                        		docToSend = provPrefUtil.createDocToSendCloud(currentPref, provPrefUtil.padWithLeadingZeros(currentMpin), currentTin, null, null, null);
//
//                    			postRequest.setRequest(docToSend);
//
//
//                            	try {
//                            		fdsCloudHandler.FDSCloudPostRequest(SESSION_ID_ALL, postRequest, Encode.forJava(cid));
//                                } catch (Exception e) {
//                                	Gson gson = new Gson();
//                                	String requestString = gson.toJson(postRequest.getRequest());
//                                	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", null, requestString);
//                                	continue;
//                                }
//
//                        	}
//
//                        } else {
//                        	// no document in FDS, must create with null docId
//                        	// send null activeDateStr because we should never create a document with activeDate
//                         	docToSend = provPrefUtil.createDocToSendCloud(currentPref, provPrefUtil.padWithLeadingZeros(currentMpin), currentTin, null, null, null);
//                         	postRequest.setRequest(docToSend);
//
//                            try {
//                            	fdsCloudHandler.FDSCloudPostRequest(SESSION_ID_ALL, postRequest, Encode.forJava(cid));
//                            } catch (Exception  e) {
//                            	Gson gson = new Gson();
//                            	String requestString = gson.toJson(postRequest.getRequest());
//                            	logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID -> \"documentID\":\"{}\", \"request\":{}", null, requestString);
//                                continue;
//                            }
//
//                        }
//                    }
//
//                }
//
//            }
//
//        } catch (ApplicationException | ParseException e) {
//        	logger.error("FATAL ERROR while updating provider preferences, providerPreferences={}, error={}", providerPreferences, e);
////        	throw e;
//
//        }
//
//    }


    //unused
//    private boolean isInExceptionList(String taxIdNumber, String corpOwnerId) {
//
//        String[] exceptionArray = EXCEPTION_LIST.split(",");
//
//        for (String entry : exceptionArray){
//            String[] parts = entry.split(":"); //format is TIN:MPIN
//            if(parts.length == 2 && parts[0].equals(taxIdNumber) && parts[1].equals(corpOwnerId))
//                return true;
//        }
//        return false;
//    }
    
// public Map<String, Object> createDocToSendCloud(PreferenceType masterPref, String mpin, String tin, String docId, String activeDateStr) throws ParseException {
//	
//	Document docToSend = new Document();
// 	Metadata metadata = new Metadata();
// 	
// 	if (docId != null) {
// 		docToSend.setId(docId);
// 	}
// 	if (masterPref.getActiveDate() != null) {
// 		// if PUT request contains activeDate
// 		// this will most likely never happen (scenario 1)
// 		metadata.setActiveDate(masterPref.getActiveDate());
// 	} else {
// 		// get activeDateStr from existing document (scenario 2)
// 		// if its null then that means the existing record doesn't have activeDate so it doesn't need it (scenario 3)
// 		if (activeDateStr != null) {
// 			metadata.setActiveDate(activeDateStr);
// 		}
// 	}
//     metadata.setDeliveryMethod(masterPref.getDeliveryMethod());
//     metadata.setFileName(masterPref.getClassifier());
//     metadata.setFileType(ClassifierDescription.getClassifierDescription(masterPref.getClassifier()));
//     metadata.setFrequency(masterPref.getFrequency());
//     metadata.setMpin(mpin);
//     metadata.setProviderEmailId(masterPref.getProviderEmailId());
//     metadata.setProviderName(masterPref.getProviderName());
//     metadata.setTin(tin);
//     metadata.setAutoEdelUpdateInd(masterPref.getAutoEdelUpdateInd());
//     metadata.setOkToChangePDOInd(masterPref.getOkToChangePDOInd());
//     
//     // TODO: add lastUpdatedById for optumUUID
//     metadata.setLastUpdatedBy(masterPref.getLastUpdatedBy());
//     metadata.setLastUpdatedById(masterPref.getLastUpdatedById());
//     metadata.setAutoOptOutInd(masterPref.getAutoOptOutInd());
//     metadata.setOptedOutDuration(masterPref.getOptedOutDuration());
//     metadata.setOptedOutDateTime(masterPref.getOptedOutDateTime());
//     
//     if (masterPref.getOptedOutDuration() != null 
//     		&& masterPref.getOptedOutDateTime() != null   
//     		&& (masterPref.getExpiryDate() == null 
//     		|| masterPref.getExpiryDate().isEmpty() 
//     		|| masterPref.getExpiryDate().length() < "2020-05-01T04:00:00.000Z".length())) {
//     	if (masterPref.getOptedOutDuration() == -1) {
//     		metadata.setExpiryDate("9999-12-31T23:59:59.000Z");
//     	}
//     	else {
//     		Calendar cal = Calendar.getInstance();
//     		Date optOutDate = parseDateString(masterPref.getOptedOutDateTime());
//         	cal.setTime(optOutDate);
//         	cal.add(Calendar.DATE, masterPref.getOptedOutDuration());
//         	metadata.setExpiryDate(formatDate(cal.getTime()));
//     	}
//     }
//     else {
//     	metadata.setExpiryDate(masterPref.getExpiryDate());
//     }
//
//     docToSend.setMetadata(metadata);
//
//     return mapper.convertValue(metadata, new TypeReference<Map<String, Object>>() {});
//     	
//    }
// private Document createDocToSendWithClassifier(PreferenceType masterPref, String mpin, String tin, String docId, String activeDateStr, String classifier) throws ParseException {
//    	
//    	Document docToSend = new Document();
//    	
//    	FDSCloudRequest cloudRequest = new FDSCloudRequest();
//    	Metadata metadata = new Metadata();
//    	
//    	if (docId != null) {
//    		docToSend.setId(docId);
//    	}
//    	if (masterPref.getActiveDate() != null) {
//    		// if PUT request contains activeDate
//    		// this will most likely never happen (scenario 1)
//    		metadata.setActiveDate(masterPref.getActiveDate());
//    	} else {
//    		// get activeDateStr from existing document (scenario 2)
//    		// if its null then that means the existing record doesn't have activeDate so it doesn't need it (scenario 3)
//    		if (activeDateStr != null) {
//    			metadata.setActiveDate(activeDateStr);
//    		}
//    	}
//        metadata.setDeliveryMethod(masterPref.getDeliveryMethod());
//        metadata.setFileName(classifier);
//        metadata.setFileType(ClassifierDescription.getClassifierDescription(classifier));
//        metadata.setFrequency(masterPref.getFrequency());
//        metadata.setMpin(mpin);
//        metadata.setProviderEmailId(masterPref.getProviderEmailId());
//        metadata.setProviderName(masterPref.getProviderName());
//        metadata.setTin(tin);
//        metadata.setAutoEdelUpdateInd(masterPref.getAutoEdelUpdateInd());
//        metadata.setOkToChangePDOInd(masterPref.getOkToChangePDOInd());
//        
//        metadata.setLastUpdatedBy(masterPref.getLastUpdatedBy());
//        metadata.setLastUpdatedById(masterPref.getLastUpdatedById());
//        metadata.setAutoOptOutInd(masterPref.getAutoOptOutInd());
//        metadata.setOptedOutDuration(masterPref.getOptedOutDuration());
//        metadata.setOptedOutDateTime(masterPref.getOptedOutDateTime());
//        
//        if (masterPref.getOptedOutDuration() != null 
//        		&& masterPref.getOptedOutDateTime() != null   
//        		&& (masterPref.getExpiryDate() == null 
//        		|| masterPref.getExpiryDate().isEmpty() 
//        		|| masterPref.getExpiryDate().length() < "2020-05-01T04:00:00.000Z".length())) {
//        	if (masterPref.getOptedOutDuration() == -1) {
//        		metadata.setExpiryDate("9999-12-31T23:59:59.000Z");
//        	}
//        	else {
//        		Calendar cal = Calendar.getInstance();
//        		Date optOutDate = parseDateString(masterPref.getOptedOutDateTime());
//            	cal.setTime(optOutDate);
//            	cal.add(Calendar.DATE, masterPref.getOptedOutDuration());
//            	metadata.setExpiryDate(formatDate(cal.getTime()));
//        	}
//        }
//        else {
//        	metadata.setExpiryDate(masterPref.getExpiryDate());
//        }
//        
//        docToSend.setMetadata(metadata);
//
//        return docToSend;
//    	
//    }
//
// public Map<String, Object> createDocToSendWithClassifierCloud(PreferenceType masterPref, String mpin, String tin, String docId, String activeDateStr, String classifier) throws ParseException {
//	
//	Document docToSend = new Document();
//	Metadata metadata = new Metadata();
//	
//	if (docId != null) {
//		docToSend.setId(docId);
//	}
//	if (masterPref.getActiveDate() != null) {
//		// if PUT request contains activeDate
//		// this will most likely never happen (scenario 1)
//		metadata.setActiveDate(masterPref.getActiveDate());
//	} else {
//		// get activeDateStr from existing document (scenario 2)
//		// if its null then that means the existing record doesn't have activeDate so it doesn't need it (scenario 3)
//		if (activeDateStr != null) {
//			metadata.setActiveDate(activeDateStr);
//		}
//	}
//    metadata.setDeliveryMethod(masterPref.getDeliveryMethod());
//    metadata.setFileName(classifier);
//    metadata.setFileType(ClassifierDescription.getClassifierDescription(classifier));
//    metadata.setFrequency(masterPref.getFrequency());
//    metadata.setMpin(mpin);
//    metadata.setProviderEmailId(masterPref.getProviderEmailId());
//    metadata.setProviderName(masterPref.getProviderName());
//    metadata.setTin(tin);
//    metadata.setAutoEdelUpdateInd(masterPref.getAutoEdelUpdateInd());
//    metadata.setOkToChangePDOInd(masterPref.getOkToChangePDOInd());
//    
//    metadata.setLastUpdatedBy(masterPref.getLastUpdatedBy());
//    metadata.setLastUpdatedById(masterPref.getLastUpdatedById());
//    metadata.setAutoOptOutInd(masterPref.getAutoOptOutInd());
//    metadata.setOptedOutDuration(masterPref.getOptedOutDuration());
//    metadata.setOptedOutDateTime(masterPref.getOptedOutDateTime());
//    
//    if (masterPref.getOptedOutDuration() != null 
//    		&& masterPref.getOptedOutDateTime() != null   
//    		&& (masterPref.getExpiryDate() == null 
//    		|| masterPref.getExpiryDate().isEmpty() 
//    		|| masterPref.getExpiryDate().length() < "2020-05-01T04:00:00.000Z".length())) {
//    	if (masterPref.getOptedOutDuration() == -1) {
//    		metadata.setExpiryDate("9999-12-31T23:59:59.000Z");
//    	}
//    	else {
//    		Calendar cal = Calendar.getInstance();
//    		Date optOutDate = parseDateString(masterPref.getOptedOutDateTime());
//        	cal.setTime(optOutDate);
//        	cal.add(Calendar.DATE, masterPref.getOptedOutDuration());
//        	metadata.setExpiryDate(formatDate(cal.getTime()));
//    	}
//    }
//    else {
//    	metadata.setExpiryDate(masterPref.getExpiryDate());
//    }
//    
//   
//    docToSend.setMetadata(metadata);
//
//    return mapper.convertValue(metadata, new TypeReference<Map<String, Object>>() {});
//}
//
//
//	
//	public synchronized String formatDate(Date date) {
//		SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
//		return isoDateFormat.format(date);
//	}
//	
//	public synchronized Date parseDateString(String date) throws ParseException {
//		SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
//		return isoDateFormat.parse(date);
//	}
//    
//    
//    public String padWithLeadingZeros(String currentMpin) throws ApplicationException
//    {
//        int currentMpinLength = currentMpin.length();
//        String stringOfZeros = "";
//        if (currentMpinLength == 9)
//        {
//            return currentMpin;
//        }
//        else if (currentMpinLength < 9)
//        {
//            int numberOfZerosNeeded = 9 - currentMpinLength;
//            for (int i = 0; i < numberOfZerosNeeded; i++)
//            {
//                stringOfZeros += "0";
//            }
//            currentMpin = stringOfZeros + currentMpin;
//            return currentMpin;
//        }
//        else
//        {
//            logger.error("MPIN longer than 9 digits, mpin={}", currentMpin);
//            throw new ApplicationException("MPIN longer than 9 digits");
//        }
//
//    }
//    
//	public AutoEnrollment determineDocumentIndex(List<Document> documentList, int documentCount, int index, OffsetDateTime currentDate) throws AssertionError {
// 		logger.info("Entering determineDocumentIndex: documentCount={}, index={}", documentCount, index);
// 		
// 		String documents=printDocument(documentList.get(index).getMetadata());
// 		// PDO have the assumption that a maximum of 2 documents will exist for a given MPIN/TIN/LetterType combination
// 		// them being the AutoEnrollment and the pre-AutoEnrollment records.
// 		// The niche scenario occurs where a preference only has an AutoEnrollment record with no pre-AutoEnrollment record for
// 		// it will create a new pre-AutoEnrollment record to store client changes between now and AutoEnrollment date.
// 		// Thus if we have > 2 records they will be ignore.
// 		
// 		String activeDateStr = documentList.get(index).getMetadata().getActiveDate();
// 		if (activeDateStr == null || activeDateStr.isEmpty()) {
// 			logger.info("AutoEnrollment not found: documentCount={}, index={}, {}",
// 					documentCount, index, documents);
// 			return this.new AutoEnrollment(false, index);
// 		}
//
// 		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"); 		
// 		OffsetDateTime activeDate = null;
// 		try {
// 			activeDate = OffsetDateTime.parse(activeDateStr, df);
// 		} catch(AssertionError e) {
// 			logger.error("checkDocumentIndex: ZonedDateTime; {}: {}", printDocument(documentList.get(index).getMetadata()), e);
// 			return this.new AutoEnrollment(true, -1);
// 		}
// 		if (currentDate.isAfter(activeDate)) {
// 			logger.info("AutoEnrollment active: documentCount={}, index={}, {}",
// 					documentCount, index, documents);
// 			return this.new AutoEnrollment(true, index);
// 		}
// 		logger.info("AutoEnrollment not active: documentCount={}, index={}, {}",
// 				documentCount, index, documents);
// 		return this.new AutoEnrollment(true, -1);
// 	}
//    
//	public AutoEnrollment determineDocumentIndexCloud(List<OptOutFDSCloudDocument> documentList, int documentCount, int index, OffsetDateTime currentDate) throws AssertionError, IOException {
// 		logger.info("Entering determineDocumentIndex: documentCount={}, index={}", documentCount, index);
// 		
// 		String metadataStr = documentList.get(index).getMetadata();
// 		// PDO have the assumption that a maximum of 2 documents will exist for a given MPIN/TIN/LetterType combination
// 		// them being the AutoEnrollment and the pre-AutoEnrollment records.
// 		// The niche scenario occurs where a preference only has an AutoEnrollment record with no pre-AutoEnrollment record for
// 		// it will create a new pre-AutoEnrollment record to store client changes between now and AutoEnrollment date.
// 		// Thus if we have > 2 records they will be ignore.
// 		Metadata metadata;
// 		try {
//			metadata = mapper.readValue(metadataStr, Metadata.class);
//		} catch (IOException e) {
//			logger.error("Unable to parse metadata string");
//			throw e;
//		}
// 		
// 		Long currentTimeEpoch = System.currentTimeMillis();
// 		Long optedOutExpiryEpoch = metadata.getExpiryDateEpoch();
// 		
// 		if (optedOutExpiryEpoch != null && currentTimeEpoch < optedOutExpiryEpoch) {
// 			logger.info("Valid Optout found: documentCount={}, index={}, {}",
// 					documentCount, index, metadataStr);
// 			return this.new AutoEnrollment(true, index); 			
// 		}
// 		
// 		String activeDateStr = metadata.getActiveDate();
// 		
// 		if (activeDateStr == null || activeDateStr.isEmpty()) {
// 			logger.info("AutoEnrollment not found: documentCount={}, index={}, {}",
// 					documentCount, index, metadataStr);
// 			return this.new AutoEnrollment(false, index);
// 		}
//
// 		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"); 		
// 		OffsetDateTime activeDate = null;
// 		try {
// 			activeDate = OffsetDateTime.parse(activeDateStr, df);
// 		} catch(AssertionError e) {
// 			logger.error("checkDocumentIndex: ZonedDateTime; {}: {}",activeDateStr, e.getMessage());
// 			return this.new AutoEnrollment(true, -1);
// 		}
// 		if (currentDate.isAfter(activeDate)) {
// 			logger.info("AutoEnrollment active: documentCount={}, index={}, {}",
// 					documentCount, index, metadataStr);
// 			return this.new AutoEnrollment(true, index);
// 		}
// 		logger.info("AutoEnrollment not active: documentCount={}, index={}, {}",
// 				documentCount, index, metadataStr);
// 		return this.new AutoEnrollment(true, -1);
// 	}
//	
//	public int determineMulti(AutoEnrollment autoEnrollment0, AutoEnrollment autoEnrollment1) {
// 		if (autoEnrollment0.isValidAutoEnrollment()) {
// 			return 0;
// 		}
// 		if (autoEnrollment1.isValidAutoEnrollment()) {
// 			return 1;
// 		}
// 		if (! autoEnrollment0.isAutoEnrollment()) {
// 			return 0;
// 		}
// 		if (! autoEnrollment1.isAutoEnrollment()) {
// 			return 1;
// 		}
// 		return -1;
// 	}
//    
//	protected String printDocument(Metadata metadata) {
//		return "providerEmailId = " + metadata.getProviderEmailId() + ", mpin = " + metadata.getMpin() + ", fileName= " + metadata.getFileName();
//	}
    
//    public class AutoEnrollment {
//    	
//    	protected boolean isAutoEnrollment;
//    	protected int index;
//    	
//    	public AutoEnrollment(Boolean isAutoEnrollment, int index) {
//    		this.isAutoEnrollment = isAutoEnrollment;
//    		this.index = index;
//		}
//    	
//    	public boolean isAutoEnrollment() { return isAutoEnrollment; }
//
// 		public boolean isValidAutoEnrollment() {
// 			return isAutoEnrollment && index != -1;
// 		}
//
//    }
//    
//    public class OptOut {
//    	private boolean isOptOut;
//    	private int index;
//    	
//    	public OptOut(Boolean isOptout, int index) {
//    		this.isOptOut = isOptOut;
//    		this.index = index;
//    		
//    	}
//    	
//    	public boolean isOptedOut() {
//    		return isOptOut && index != -1;
//    	}
//    	
//    }

}
