package com.optum.providerpreferences.rs.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinResponse;

public interface OptOutService {
	
	public Map<String, List<String>> updateOptOutDocuments(OptOutRequest optOutRequest, HttpHeaders headers) throws ApplicationException, JsonProcessingException, OAuthProblemException, OAuthSystemException, IOException;

	public OptOutTinResponse getTins(OptOutTinRequest optOutTinRequest, String cid) throws ApplicationException, JsonProcessingException;
	
	public FDSCloudGETResponse getOptOutAuditLog(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException;

	//unused
//	public OptOutFDSCloudDocument getFDSCloudDocument(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException, IOException;

	public ResponseEntity<OptOutFDSCloudPOSTResponse> addOptOutAuditLog(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException;

	//unused
//	public ResponseEntity<OptOutFDSCloudPOSTResponse> FDSCloudPut(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException;
	//unused
//	public Map<String, Boolean> FDSCloudDelete(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException;
	
	public Map<String, List<String>> getDocuments(List<String> providerMpins, List<String> categories, String tin, String cid) throws RestClientException, NullPointerException, ApplicationException, OAuthProblemException, OAuthSystemException, IOException;
	
	public String padWithLeadingZeros(String currentMpin) throws ApplicationException;
	
	public void updateDeliveryMethodNDB(List<String> providerMpins, List<String> categories, String tin, String cid) throws RestClientException, NullPointerException, ApplicationException, OAuthProblemException, OAuthSystemException, IOException;
	
	public Map<String, Object> createOptOutDocument(List<String> requestData, String lastUpdatedBy, String lastUpdatedById, int optedOutDuration);
}
