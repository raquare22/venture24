package com.optum.providerpreferences.rs.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.handler.PESHandler;
import com.optum.providerpreferences.rs.model.OONRequestModel;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.ProviderPreferencesObj;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesRequest;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesResponse;
import com.optum.providerpreferences.rs.model.ndb.preferences.MailPref;
import com.optum.providerpreferences.rs.model.ndb.preferences.RequestHeader;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinData;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.mongo.document.DeliveryPreference;
import com.optum.providerpreferences.rs.utility.ClassifierDescription;
import com.optum.providerpreferences.rs.utility.Converter;
import com.optum.providerpreferences.rs.utility.ProviderPreferencesUtil;
import com.optum.providerpreferences.rs.utility.ProviderPreferencesUtil.AutoEnrollment;
import com.optum.providerpreferences.rs.utility.SanitizeUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CompletableFuture;

@Component
public class AsyncComponent {
	
	@Autowired
	OptOutService optOutService;
	
	@Autowired
	ProviderPreferencesUtil provPrefUtil;
	
	@Autowired
	NDBHandler ndbHandler;
	
	@Autowired
	PESHandler pesHandler;
	
	@Autowired
	ObjectMapper mapper;
	
	@Autowired
	FDSCloudHandler fdsCloudHandler;

	@Autowired
	DocumentService documentService;

	@Value("${USE_FDSCLOUD}")
	protected boolean useFDSCloud;
	
	private static final String SESSION_ID_ALL = "allUpdate";
	private static final String FILENAME = "fileName";
	private static final String TEST_ID = "testId";
	private static final String ERROR_FDS_CLOUD = "TEST_ID: {}, {}, {}";
	
	private static final Logger LOGGER = LogManager.getLogger(AsyncComponent.class);
	
	
	@Async("threadPoolTaskExecutor")
	public CompletableFuture<List<PreferenceType>> getProviderPreferencesFDSCloudAsync(String tin, String mpin, List<PreferenceType> preferenceTypeList, String cid) throws ParseException, AssertionError, IOException, ApplicationException {
		for (PreferenceType prefType : preferenceTypeList) {
            prefType.setDescription(ClassifierDescription.getClassifierDescription(Converter.convertNullToString(prefType.getClassifier().toUpperCase())));
            prefType.setLob(ClassifierDescription.getLob(Converter.convertNullToString(prefType.getClassifier().toUpperCase())));
            

            Map<String, Object> metadataMap=new HashMap<>();
            metadataMap.put("tin", tin);
            metadataMap.put("mpin", mpin);
            metadataMap.put(FILENAME, prefType.getClassifier());

			FDSCloudRequest searchTerms=null;
			List<OptOutFDSCloudDocument> sortedDocsList;
			List<DeliveryPreference> sortedDocsMongo = documentService.getDocumentsBySearchTerms(metadataMap);
			if(sortedDocsMongo == null || sortedDocsMongo.isEmpty()) {
				searchTerms=fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap);
				FDSCloudGETResponse sortedDocs = fdsCloudHandler.FDSCloudGetRequest(TEST_ID, searchTerms, "", Encode.forJava(cid));
				sortedDocsList = (sortedDocs != null && sortedDocs.getDocuments() != null) ? sortedDocs.getDocuments() : Collections.emptyList();
			}
			else{
				sortedDocsList = provPrefUtil.convertDeliveryPrefsToOptOutDocs(sortedDocsMongo);
			}

			int lenSortedDocs = sortedDocsList.size();
            if (lenSortedDocs > 0) {
            	
            	int docIndex = -1;
            	OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);
            	
            	AutoEnrollment doc0 = provPrefUtil.determineDocumentIndexCloud(sortedDocsList, lenSortedDocs, 0, currentDate, Encode.forJava(cid));
            	AutoEnrollment doc1;
            	
            	if (lenSortedDocs == 1) {
            		if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {
            			docIndex = 0; // document is pre-autoenrollment doc or autoenrollment doc and its past active date     
            		}    		
            	} else {
            		// there are 2 documents found, if its past active date take the autoenrollment doc, if not then take the most recent updated doc
            		doc1 = provPrefUtil.determineDocumentIndexCloud(sortedDocsList, lenSortedDocs, 1, currentDate, Encode.forJava(cid));
					docIndex = provPrefUtil.determineMulti(doc0, doc1);
            	}
            	
            	if (docIndex >= 0) {
            		OptOutFDSCloudDocument doc = sortedDocsList.get(docIndex);
            		String metaDataString=doc.getMetadata();
            		Metadata metadataObj = mapper.readValue(metaDataString, Metadata.class);
            		
            		prefType.setDocumentId(doc.getDocumentId());
                    prefType.setProviderEmailId(metadataObj.getProviderEmailId());
                    prefType.setFrequency(metadataObj.getFrequency());
                    prefType.setOkToChangePDOInd(metadataObj.getOkToChangePDOInd());
                    prefType.setAutoEdelUpdateInd((metadataObj.getAutoEdelUpdateInd()));
					prefType.setLastOONPopUpDate(metadataObj.getLastOONPopUpDate());
                    
                    prefType.setLastUpdatedBy(metadataObj.getLastUpdatedBy());
                    prefType.setLastUpdatedById(metadataObj.getLastUpdatedById());
                    prefType.setAutoOptOutInd(metadataObj.getAutoOptOutInd());
                    prefType.setOptedOutDuration(metadataObj.getOptedOutDuration());
                    prefType.setOptedOutDateTime(metadataObj.getOptedOutDateTime());
					if(metadataObj.getSubscribeToEmail()==null){
						prefType.setSubscribeToEmail("Y");
					}
					else{
						prefType.setSubscribeToEmail(metadataObj.getSubscribeToEmail());
					}
					Instant instant = Instant.ofEpochMilli(doc.getModifiedOn());
					LocalDateTime modifiedDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
					String dateModified = modifiedDateTime.format(formatter);
					prefType.setDateModified(dateModified);
                    updateOptOutVals(metadataObj, prefType);

					prefType.setSecondaryProviderEmailIds(metadataObj.getSecondaryProviderEmailIds() != null
							? metadataObj.getSecondaryProviderEmailIds()
							: java.util.Collections.emptyList());

            	}
            	
            }
            
        }

        
        LOGGER.info("returnedProviderPreferencesList async={}", preferenceTypeList);
        return CompletableFuture.completedFuture(preferenceTypeList);
	}
	private void updateOptOutVals(Metadata metadataObj, PreferenceType prefType) throws ParseException {
		if (checkOptOut(metadataObj)) {
        	if (metadataObj.getOptedOutDuration() == -1) {
        		prefType.setExpiryDate("9999-12-31T23:59:59.000Z");
        	}
        	else {
        		Calendar cal = Calendar.getInstance();
        		Date optOutDate = parseDateString(metadataObj.getOptedOutDateTime());
            	cal.setTime(optOutDate);
            	cal.add(Calendar.DATE, metadataObj.getOptedOutDuration());
            	prefType.setExpiryDate(formatDate(cal.getTime()));
        	}
        }
        else {
        	prefType.setExpiryDate(metadataObj.getExpiryDate());
        }
	}

	private boolean checkOptOut(Metadata metadataObj) {
		return metadataObj.getOptedOutDuration() != null 
        		&& metadataObj.getOptedOutDateTime() != null   
        		&& metadataObj.getExpiryDate() == null 
        		|| (metadataObj.getExpiryDate() != null && (metadataObj.getExpiryDate().isEmpty() 
        		|| metadataObj.getExpiryDate().length() < "2020-05-01T04:00:00.000Z".length()));
	}

	@Async("threadPoolTaskExecutor")
	public void updateProviderPreferencesFDSCloudAsync(ProviderPreferencesObj providerPreferences, HttpHeaders headers)
			throws IOException, ApplicationException, OAuthProblemException, OAuthSystemException, ParseException {
		String cid = headers.getFirst("optum-cid-ext");

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("updateProviderPreferencesAsync --> providerPreferences.getCorporateName={}, providerPreferences.getCorporateTin={}, headers={}, CID={}",
					Encode.forJava(providerPreferences.getCorporateName()), Encode.forJava(providerPreferences.getCorporateTin()), Encode.forJava(headers.toString()), Encode.forJava(cid));
		}

		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		try {

			if (providerPreferences.getPreferenceTypes().size() == 1 && providerPreferences.getPreferenceTypes().get(0).getClassifier().equalsIgnoreCase("ALL")) {
				PreferenceType masterPref = providerPreferences.getPreferenceTypes().get(0);

				// get oauth tokens and start timer
				long startTime = System.currentTimeMillis();
				ndbHandler.ndbWebServicePrep();

				for (String currentMpin : providerPreferences.getSelectedProviders()) {
					currentMpin = provPrefUtil.padWithLeadingZeros(currentMpin);
					String currentTin = provPrefUtil.padWithLeadingZeros(providerPreferences.getCorporateTin());

					loopThroughAllClassifiersAsync(currentMpin, currentTin, masterPref, Encode.forJava(cid));
				}
			} else {
				List<PreferenceType> prefList = providerPreferences.getPreferenceTypes();

				ndbHandler.ndbWebServicePrep();

				for (String currentMpin : providerPreferences.getSelectedProviders()) {
					currentMpin = provPrefUtil.padWithLeadingZeros(currentMpin);
					String currentTin = provPrefUtil.padWithLeadingZeros(providerPreferences.getCorporateTin());

					// FOR EVERY SPECIFIC PREFERENCE FOR CURRENT PROVIDER
					loopThroughSomeClassifiers(currentMpin, currentTin, prefList, Encode.forJava(cid));
				}
			}
		} catch (ApplicationException | ParseException e) {
			LOGGER.error("FATAL ERROR while updating provider preferences, providerPreferences={}, error={}, CID={}",
					Encode.forJava(providerPreferences.toString()), e, Encode.forJava(cid));
		}
	}

	void loopThroughSomeClassifiers(String currentMpin, String currentTin, List<PreferenceType> prefList, String cid)
			throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException, ParseException {
		for (PreferenceType currentPref : prefList) {
			// UPDATE NDB FOR EVERY CLASSIFIER FOR CURRENT PROVIDER
			LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
			webRequest.setRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(
					currentMpin, currentTin, "U", currentPref.getDeliveryMethod(), currentPref.getClassifier()));
			webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));

			sendNDBRequest(currentMpin, currentTin, webRequest, Encode.forJava(cid));

			// Get current docs either from Mongo or FDS
			Map<String, Object> metadataMap = new HashMap<>();
			metadataMap.put("tin", currentTin);
			metadataMap.put("mpin", currentMpin);
			metadataMap.put(FILENAME, currentPref.getClassifier());

			FDSCloudRequest searchTerms = null;
			List<OptOutFDSCloudDocument> sortedDocsList;
			List<DeliveryPreference> sortedDocsMongo = documentService.getDocumentsBySearchTerms(metadataMap);

			if (sortedDocsMongo == null || sortedDocsMongo.isEmpty()) {
				searchTerms = fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap);
				FDSCloudGETResponse sortedDocs = fdsCloudHandler.FDSCloudGetRequest(
						TEST_ID, searchTerms, "", Encode.forJava(cid));
				sortedDocsList = (sortedDocs != null && sortedDocs.getDocuments() != null)
						? sortedDocs.getDocuments()
						: Collections.emptyList();
			} else {
				sortedDocsList = provPrefUtil.convertDeliveryPrefsToOptOutDocs(sortedDocsMongo);
			}

			Map<String, Object> docToSend;
			FDSCloudRequest postRequest = new FDSCloudRequest();

			int lenDocs = sortedDocsList.size();

			if (lenDocs > 0) {
				int docIndex = -1;
				OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);

				AutoEnrollment doc0 = provPrefUtil.determineDocumentIndexCloud(
						sortedDocsList, lenDocs, 0, currentDate, Encode.forJava(cid));

				docIndex = getDocIndex(lenDocs, doc0, sortedDocsList, currentDate, Encode.forJava(cid));

				if (docIndex >= 0) {
					String docId = sortedDocsList.get(docIndex).getDocumentId();
					OptOutFDSCloudDocument doc = sortedDocsList.get(docIndex);
					Metadata metadataObj = mapper.readValue(doc.getMetadata(), Metadata.class);

					String activeDateStr = metadataObj.getActiveDate();
					String subscribeToEmail = metadataObj.getSubscribeToEmail();

					docToSend = provPrefUtil.createDocToSendCloud(
							currentPref,
							provPrefUtil.padWithLeadingZeros(currentMpin),
							currentTin,
							docId,
							activeDateStr,
							subscribeToEmail
					);

					postRequest.setRequest(docToSend);
					postRequest.setDocumentId(docId);

					if (useFDSCloud) {
						sendFDSCloudPutRequest(postRequest, docId, Encode.forJava(cid));
					} else {
						Metadata metadataToSave = mapper.convertValue(docToSend, Metadata.class);
						metadataToSave.setTin(currentTin);
						metadataToSave.setMpin(provPrefUtil.padWithLeadingZeros(currentMpin));
						DeliveryPreference dpToSave = convertMetadataToDeliveryPreference(metadataToSave);
						dpToSave.setDocumentId(docId);
						documentService.updateDocument(docId, dpToSave);
					}
				}

				if (docIndex == -2) {
					docToSend = provPrefUtil.createDocToSendCloud(
							currentPref,
							provPrefUtil.padWithLeadingZeros(currentMpin),
							currentTin,
							null,
							null,
							null
					);

					postRequest.setRequest(docToSend);

					if (useFDSCloud) {
						sendFDSCloudPostRequest(postRequest, Encode.forJava(cid));
					} else {
						Metadata metadataToSave = mapper.convertValue(docToSend, Metadata.class);
						metadataToSave.setTin(currentTin);
						metadataToSave.setMpin(provPrefUtil.padWithLeadingZeros(currentMpin));
						documentService.createDocument(convertMetadataToDeliveryPreference(metadataToSave));
					}
				}
			} else {
				// No doc found anywhere -> create
				docToSend = provPrefUtil.createDocToSendCloud(
						currentPref,
						provPrefUtil.padWithLeadingZeros(currentMpin),
						currentTin,
						null,
						null,
						null
				);

				postRequest.setRequest(docToSend);

				if (useFDSCloud) {
					sendFDSCloudPostRequest(postRequest, Encode.forJava(cid));
				} else {
					Metadata metadataToSave = mapper.convertValue(docToSend, Metadata.class);
					metadataToSave.setTin(currentTin);
					metadataToSave.setMpin(provPrefUtil.padWithLeadingZeros(currentMpin));
					documentService.createDocument(convertMetadataToDeliveryPreference(metadataToSave));
				}
			}
		}
	}
	
	void loopThroughAllClassifiersAsync(String currentMpin, String currentTin, PreferenceType masterPref, String cid) throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException, ParseException {
		
		 
		List<String> classifierList = new ArrayList<>(ClassifierDescription.classifierDescriptionHash.keySet());
		
        List<List<String>> classifierListArray = Lists.partition(classifierList, 10);
        
        
        for (List<String> list : classifierListArray ){
	    	CompletableFuture.runAsync(() -> {
	    		try {
					loopThroughAllClassifiers(currentMpin, currentTin, masterPref, list, Encode.forJava(cid));
				} catch (ApplicationException | OAuthProblemException | OAuthSystemException | IOException
						| ParseException e) {
					if (LOGGER.isWarnEnabled()) {
						LOGGER.warn("ERROR updating the preferences for CID={}, MPIN={} TIN={}",  Encode.forJava(cid),
								SanitizeUtil.sanitizeStringConatinsOnlyDigits(currentMpin), SanitizeUtil.sanitizeStringConatinsOnlyDigits(currentTin));
					}
				}
	    	});
        }
        }
        
	
	@Async("threadPoolTaskExecutor")
    CompletableFuture<List<String>> loopThroughAllClassifiers(String currentMpin, String currentTin, PreferenceType masterPref, List<String> list, String cid) throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException, ParseException {

		for (String classifier : list)
        {
            // UPDATE NDB FOR EVERY CLASSIFIER FOR CURRENT PROVIDER

            LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
            webRequest.setRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(currentMpin, currentTin, "U",
                    masterPref.getDeliveryMethod(), classifier));
            webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));

            sendNDBRequest(currentMpin, currentTin, webRequest, Encode.forJava(cid));

            // UPDATE FDS FOR EVERY CLASSIFIER FOR CURRENT PROVIDER
            // get the current document in fds for the classifier, mpin, and tin

            Map<String, Object> metadataMap = new HashMap<>();
            metadataMap.put("tin", currentTin);
            metadataMap.put("mpin", currentMpin);
            metadataMap.put(FILENAME, classifier);

			FDSCloudRequest searchTerms=null;
			List<OptOutFDSCloudDocument> sortedDocsList;
			List<DeliveryPreference> sortedDocsMongo = documentService.getDocumentsBySearchTerms(metadataMap);
			if(sortedDocsMongo == null || sortedDocsMongo.isEmpty()) {
				searchTerms=fdsCloudHandler.createSearchTermsRequestFromMap(metadataMap);
				FDSCloudGETResponse sortedDocs = fdsCloudHandler.FDSCloudGetRequest(TEST_ID, searchTerms, "", Encode.forJava(cid));
				sortedDocsList = (sortedDocs != null && sortedDocs.getDocuments() != null) ? sortedDocs.getDocuments() : Collections.emptyList();
			}
			else{
				sortedDocsList = provPrefUtil.convertDeliveryPrefsToOptOutDocs(sortedDocsMongo);
			}
			int lenDocs = sortedDocsList.size();
            // build document to add/update
            Map<String, Object> docToSend;
			FDSCloudRequest postRequest = new FDSCloudRequest();
			
            String docId;
            String activeDateStr;
			String subscribeToEmail;

            if (lenDocs > 0) {
            	int docIndex = -1;
            	OffsetDateTime currentDate = OffsetDateTime.now(ZoneOffset.UTC);
            	
            	AutoEnrollment doc0 = provPrefUtil.determineDocumentIndexCloud(sortedDocsList, lenDocs, 0, currentDate, Encode.forJava(cid));
            	docIndex = getDocIndex(lenDocs, doc0, sortedDocsList, currentDate, Encode.forJava(cid));

            	if (docIndex >= 0) {
            		docId = sortedDocsList.get(docIndex).getDocumentId();
            		OptOutFDSCloudDocument doc = sortedDocsList.get(docIndex);
            		Metadata metadataObj = mapper.readValue(doc.getMetadata(), Metadata.class);
            		activeDateStr = metadataObj.getActiveDate();
					subscribeToEmail=metadataObj.getSubscribeToEmail();

					docToSend = provPrefUtil.createDocToSendWithClassifierCloud(masterPref, provPrefUtil.padWithLeadingZeros(currentMpin), currentTin, docId, activeDateStr, subscribeToEmail, classifier);
					postRequest.setRequest(docToSend);
					postRequest.setDocumentId(docId);

					if (useFDSCloud) {
						sendFDSCloudPutRequest(postRequest, docId, Encode.forJava(cid));
					} else {
						// Build a Metadata from the masterPref to get the fully resolved values
						Metadata metadataToSave = mapper.convertValue(docToSend, Metadata.class);
						metadataToSave.setTin(currentTin);
						metadataToSave.setMpin(provPrefUtil.padWithLeadingZeros(currentMpin));
						DeliveryPreference dpToSave = convertMetadataToDeliveryPreference(metadataToSave);
						dpToSave.setDocumentId(docId);
						documentService.updateDocument(docId, dpToSave);
					}
            	}

            	if (docIndex == -2) {
            		// no pre-autoenrollment document in FDS, must create with null docId and null activeDate
            		docToSend = provPrefUtil.createDocToSendWithClassifierCloud(masterPref, provPrefUtil.padWithLeadingZeros(currentMpin), currentTin, null, null, null, classifier);
        			postRequest.setRequest(docToSend);
					if (useFDSCloud) {
						sendFDSCloudPostRequest(postRequest, Encode.forJava(cid));
					}else{
						Metadata metadataToSave = mapper.convertValue(docToSend, Metadata.class);
						metadataToSave.setTin(currentTin);
						metadataToSave.setMpin(provPrefUtil.padWithLeadingZeros(currentMpin));
						documentService.createDocument(convertMetadataToDeliveryPreference(metadataToSave));
					}
            	}
            } else {

            	docToSend = provPrefUtil.createDocToSendWithClassifierCloud(masterPref, provPrefUtil.padWithLeadingZeros(currentMpin), currentTin, null, null,null, classifier);
        		postRequest.setRequest(docToSend);
				if (useFDSCloud) {
					sendFDSCloudPostRequest(postRequest, Encode.forJava(cid));
				} else {
					Metadata metadataToSave = mapper.convertValue(docToSend, Metadata.class);
					metadataToSave.setTin(currentTin);
					metadataToSave.setMpin(provPrefUtil.padWithLeadingZeros(currentMpin));
					documentService.createDocument(convertMetadataToDeliveryPreference(metadataToSave));
				}
            }
        }
		
		LOGGER.info("returnedProviderPreferencesList async={}", list);
        return CompletableFuture.completedFuture(list);
	}
	
	private void sendNDBRequest(String currentMpin, String currentTin, LetterPreferencesRequest webRequest, String cid) throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException {
		try {
            ndbHandler.updateProviderLetterPreferences(webRequest, currentMpin, currentTin, Encode.forJava(cid));
        } catch (JsonProcessingException e) {
        	LOGGER.warn("ERROR UPDATING TO NDB, CID={}, error={}", Encode.forJava(cid), e);
//            throw e;
        }
	}
	
	
	int getDocIndex(int lenDocs, AutoEnrollment doc0, List<OptOutFDSCloudDocument> docs, OffsetDateTime currentDate, String cid) throws AssertionError, IOException {
		int docIndex = -1;
		AutoEnrollment doc1 = null;
		
		if (lenDocs == 1) {
    		// only 1 document
    		if (doc0.isValidAutoEnrollment() || !doc0.isAutoEnrollment()) {  // document is pre-autoenrollment doc or autoenrollment doc and its past active date
    			docIndex = 0;
    		} else if (doc0.isAutoEnrollment && !doc0.isValidAutoEnrollment()) {
    			docIndex = -2;
    		}
    		
    	} else {
    		// 2 documents, pick the autoenrollment one if after active date, pick pre-autoenrollment one if before active date
    		doc1 = provPrefUtil.determineDocumentIndexCloud(docs, lenDocs, 1, currentDate, Encode.forJava(cid));
    		docIndex = provPrefUtil.determineMulti(doc0, doc1);
    	}
		
		return docIndex;
	}
	
	void sendFDSCloudPostRequest(FDSCloudRequest postRequest, String cid) {
		try {
        	fdsCloudHandler.FDSCloudPostRequest(SESSION_ID_ALL, postRequest, Encode.forJava(cid));
        } catch (Exception  e) {
        	Gson gson = new Gson();
        	String requestString = gson.toJson(postRequest.getRequest());
        	LOGGER.warn(ERROR_FDS_CLOUD,  Encode.forJava(cid), null, requestString);
            return;
        }
	}
	
	void sendFDSCloudPutRequest(FDSCloudRequest request, String docId, String cid) {
		//fds cloud request
        try {
        	fdsCloudHandler.FDSCloudPutRequest(SESSION_ID_ALL, request, Encode.forJava(cid));
        } catch (Exception e) {
        	Gson gson = new Gson();
        	String requestString = gson.toJson(request.getRequest());
        	LOGGER.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID CID={}, e={}, -> \"documentID\":\"{}\", \"request\":{}",  Encode.forJava(cid), ExceptionUtils.getStackTrace(e), docId, requestString);
        	return;
        }
	}
    
    @Async("threadPoolTaskExecutor")
    public void updateOptOutDocumentsVoid(OptOutRequest optOutRequest, HttpHeaders headers, String cid)
			throws ApplicationException, OAuthProblemException, OAuthSystemException,
			IOException {
		/**
		 * 1. get tin 2. get mpins from tin 3. loop through mpins and letter types 3a.
		 * update NDB 3b. search FDS to get documentId 4. use multi put to update all
		 * documents at once 5. send email to PODM with tin
		 */
    	
		String corpMpin = optOutRequest.getCorpMpin();
		String tin = optOutRequest.getTin();
		String lastUpdatedBy = optOutRequest.getLastUpdatedBy();
		String lastUpdatedById = optOutRequest.getLastUpdatedById();
		int optedOutDuration = optOutRequest.getOptedOutDuration();
		ndbHandler.ndbWebServicePrep();
		List<String> providerMpins = optOutRequest.getProviderMpins();
		List<String> categories = optOutRequest.getCategories();

		if (providerMpins.size() == 0) {
			RequestData request = new RequestData();
			request.setTaxIdNumber(tin);
			request.setCorpOwnerId(corpMpin);

			CorpMpinResponse corpMpinResponse = null;

			try {
				corpMpinResponse = ndbHandler.getProviderData(request, Encode.forJava(cid));
			} catch (ApplicationException | IOException | OAuthSystemException | OAuthProblemException | RestClientException e) {
				LOGGER.error("Error retrieving Provider Data from NDB, CID={}, error={}", Encode.forJava(cid), ExceptionUtils.getStackTrace(e));
				throw new ApplicationException("Error making service call to NDB");
			}

			Objects.requireNonNull(corpMpinResponse);

			providerMpins = new ArrayList<>();
			for (MpinData mpinData : corpMpinResponse.getResponse().getMpinList()) {
				providerMpins.add(optOutService.padWithLeadingZeros(mpinData.getProviderId()));
			}

		}
		
		// TODO: Redo logic, for every mpin in providerMpins, update all available documents for letter type to opted out
		optOutService.updateDeliveryMethodNDB(providerMpins, categories, tin, Encode.forJava(cid));
		Map<String, List<String>> documentIds = optOutService.getDocuments(providerMpins, categories, tin, Encode.forJava(cid));

		LOGGER.info("Sending PUT request to update FDS documents, docIdsFound={}", documentIds.size());

		// test for put, does it replace everything, otherwise going to have to do creation per record and remove the tin/mpin/filename per so you can reuse the call
		// after testing: require all data to be sent in put request to ensure none of them are randomly dropped.
		for (Map.Entry<String, List<String>> entry : documentIds.entrySet()) {
			
			Map<String, Object> docMetadata = optOutService.createOptOutDocument(entry.getValue(), lastUpdatedBy, lastUpdatedById, optedOutDuration);
			if (!useFDSCloud) {
				Metadata metadataToSave = mapper.convertValue(docMetadata, Metadata.class);
				DeliveryPreference dpToSave = convertMetadataToDeliveryPreference(metadataToSave);
				dpToSave.setDocumentId(entry.getKey());
				documentService.updateDocument(entry.getKey(), dpToSave);
			} else {
				FDSCloudRequest fdsRequest = new FDSCloudRequest();
				fdsRequest.setDocumentId(entry.getKey());
				fdsRequest.setRequest(docMetadata);
				try {
					fdsCloudHandler.FDSCloudPutRequest(SESSION_ID_ALL, fdsRequest, Encode.forJava(cid));
				} catch (RestClientException e) {
					LOGGER.error("ERROR UPDATING DOCUMENT ID, documentID={}", fdsRequest.getDocumentId());
					throw e;
				}
			}
		}
		List<String> logDocs = new ArrayList<String>(documentIds.keySet());
		LOGGER.info("Updated opt out documents: {}", logDocs);

	}

	public synchronized String formatDate(Date date) {
		SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		return isoDateFormat.format(date);
	}
	
	public synchronized Date parseDateString(String date) throws ParseException {
		SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		return isoDateFormat.parse(date);
	}

	public ProviderPreferencesObj getProviderPreferenceRequest(OONRequestModel oonRequest, String mpin, List<String> printClassifiers) throws ParseException {
		ProviderPreferencesObj obj = new ProviderPreferencesObj();
		List<PreferenceType> prefTypeList = new ArrayList<>();

		for (String classifier : printClassifiers){
			PreferenceType tempPrefType = new PreferenceType();
			if (oonRequest.getConvertToElectronic()) {
				tempPrefType.setProviderEmailId(oonRequest.getProviderEmail());
				tempPrefType.setDeliveryMethod("E");
			}
			else{
				Date currentDate = new Date();
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
				String formattedDate = dateFormat.format(currentDate);
				tempPrefType.setLastOONPopUpDate(formattedDate);
			}
			tempPrefType.setClassifier(classifier);
			prefTypeList.add(tempPrefType);
		}

		obj.setCorporateName(oonRequest.getCorpOwnerId());
		obj.setPreferenceTypes(prefTypeList);
		obj.setCorporateTin(oonRequest.getTaxIdNumber());
		obj.setSelectedProviders(new ArrayList<>());
		obj.setSelectedProviders(Collections.singletonList(mpin));

		return obj;
	}

	public List<String> getMpinsFromResponse(CorpMpinResponse mpinResponse) throws ApplicationException {
		List<String > mpins = new ArrayList<>();
		if (mpinResponse == null) {
			return null;
		}
		List<MpinData> mpinDataList = mpinResponse.getResponse().getMpinList();

		for (MpinData mpinData : mpinDataList) {
			try {
				mpins.add(provPrefUtil.padWithLeadingZeros(mpinData.getProviderId()));
			} catch (ApplicationException e) {
				throw new RuntimeException(e);
			}
		}
		return mpins;
	}

	public List<String> getPrintDeliveryClassifier(List<MailPref> ltrTypMailPrfList) {
		List<String> classifiers = new ArrayList<>();
		if (ltrTypMailPrfList == null) {
			return new ArrayList<>();
		}

		for (MailPref type : ltrTypMailPrfList) {
			if(type.getMailingPref().equals("P")){
				classifiers.add(type.getLetterType());
			}
		}
		return classifiers;
	}


	private DeliveryPreference convertMetadataToDeliveryPreference(Metadata m) {
		DeliveryPreference dp = new DeliveryPreference();
		dp.setTin(m.getTin());
		dp.setMpin(m.getMpin());
		dp.setFileName(m.getFileName());
		dp.setFileType(m.getFileType());
		dp.setDeliveryMethod(m.getDeliveryMethod());
		dp.setFrequency(m.getFrequency());
		dp.setProviderEmailId(m.getProviderEmailId());
		dp.setProviderName(m.getProviderName());
		dp.setSubscribeToEmail(m.getSubscribeToEmail());
		dp.setActiveDate(m.getActiveDate());
		dp.setOkTochangePDOInd(m.getOkToChangePDOInd());
		dp.setAutoEdelUpdateInd(m.getAutoEdelUpdateInd());
		dp.setLastUpdatedBy(m.getLastUpdatedBy());
		dp.setLastUpdatedById(m.getLastUpdatedById());
		dp.setAutoOptOutInd(m.getAutoOptOutInd());
		dp.setOptedOutDuration(m.getOptedOutDuration());
		dp.setOptedOutDateTime(m.getOptedOutDateTime());
		dp.setExpiryDate(m.getExpiryDate());
		dp.setExpiryDateEpoch(m.getExpiryDateEpoch());
		dp.setLastOONPopUpDate(m.getLastOONPopUpDate());
		dp.setSecondaryProviderEmailIds(m.getSecondaryProviderEmailIds());
		return dp;
	}

	@Async("threadPoolTaskExecutor")
	public void updatePopup(List<String> mpinList, OONRequestModel oonRequest, HttpHeaders headers) throws ApplicationException, OAuthProblemException, OAuthSystemException, IOException, ParseException {
		LetterPreferencesResponse ndbLetterPreferencesResponse = null;
		List<String> printClassifiers = new ArrayList<>();
		for (String mpin : mpinList) {
			ndbLetterPreferencesResponse = ndbHandler.getProviderLetterPreferences(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(mpin, oonRequest.getTaxIdNumber(), "I"), headers.getFirst("optum-cid-ext"));
			printClassifiers = getPrintDeliveryClassifier(ndbLetterPreferencesResponse.getRequestResponse().getLtrTypMailPrfList());
			ProviderPreferencesObj providerPreferences = getProviderPreferenceRequest(oonRequest, mpin, printClassifiers);
			updateProviderPreferencesFDSCloudAsync(providerPreferences, headers);
		}
	}

}


