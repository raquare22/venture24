package com.optum.providerpreferences.rs.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.Oauth2Handler;
import com.optum.providerpreferences.rs.handler.PEHandler;
import com.optum.providerpreferences.rs.model.PaymentPreference;
import com.optum.providerpreferences.rs.model.Token;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.util.*;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

@Service
public class PaymentPreferenceServiceImpl implements PaymentPreferenceService{

    @Autowired
    protected Oauth2Handler oauth2handler;

    @Autowired
    protected PEHandler peHandler;

    @Autowired
    private ObjectMapper objectMapper;

    static final Logger logger = LoggerFactory.getLogger(PaymentPreferenceServiceImpl.class);
    String oauthFailure="Failed to retrieve OAuth Token for Payment Engine API";
    private static final String ID = "id";
    private static final String PAYMENT_PREFERENCE_COLLECTION = "paymentPreference";
    private static final String AUTHORIZATION_STRING = "Authorization";
    private static final String BEARER_STRING = "Bearer ";

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired
    RestTemplate restTemplate;

    @Value("${MONGO_QUERY_MAX_MILLIS:90000}")
    String mongoQueryMaxMillis;

    @Value("${PaymentEngine_URL}")
    protected String PaymentEngine_URL;

    @Value("${PaymentEngine_Upstream_Env}")
    private String upstreamEnv;


    public void setMongoQueryMaxMillis(String mongoQueryMaxMillis) {
        this.mongoQueryMaxMillis = mongoQueryMaxMillis;
    }

        @Override
        public PaymentPreference insertPaymentPreference(PaymentPreference doc) {
            logger.debug("Entering insertPaymentPreference");
             MongoOperations op = mongoTemplate;
             PaymentPreference insertedDoc = null;
             String id = doc.getId();
                if (id == null || id.isEmpty()) {
                    // document doesn't exist, insert
                    insertedDoc = op.insert(doc, PAYMENT_PREFERENCE_COLLECTION);
                    return insertedDoc;
                } else {
                    // check document already exists in collection
                    PaymentPreference document = mongoTemplate.findOne(query(where("id").is(id)), PaymentPreference.class, PAYMENT_PREFERENCE_COLLECTION);
                    if (document != null) {
                        mongoTemplate.save(doc, PAYMENT_PREFERENCE_COLLECTION);
                        return doc;
                    } else {
                        insertedDoc = op.insert(doc, PAYMENT_PREFERENCE_COLLECTION);
                        return insertedDoc;
                    }
                }
        }

        @Override
        public PaymentPreference getPaymentPreference(String id) {
            logger.debug("Entering getPaymentPreference");
            PaymentPreference retVal = mongoTemplate.findOne(query(where(ID).is(id)), PaymentPreference.class);
            logger.debug("Leaving getPaymentPreference");
            return retVal;
        }

        @Override
        public void deletePaymentPreference(String id) {
            logger.debug("Entering deletePaymentPreference with id: {}", id);
            mongoTemplate.remove(query(where("id").is(id)), PaymentPreference.class, PAYMENT_PREFERENCE_COLLECTION);
            logger.debug("Exiting deletePaymentPreference with id: {}", id);
        }

        @Override
        public List<PaymentPreference> getPaymentPreferenceList(List<String> ids) {
            logger.debug("Entering getPaymentPreferenceList");
            List<PaymentPreference> retVal = mongoTemplate.find(query(where(ID).in(ids)), PaymentPreference.class, PAYMENT_PREFERENCE_COLLECTION);
            logger.debug("Leaving getPaymentPreferenceList");
            return retVal;
        }

        @Override
        public List<PaymentPreference> insertMultiPaymentPreferences(List<PaymentPreference> paymentPreferenceList) {
            logger.debug("Entering insertMultiPaymentPreferences");
            List<PaymentPreference> insertedDocs = (List<PaymentPreference>) mongoTemplate.insert(paymentPreferenceList, PAYMENT_PREFERENCE_COLLECTION);
            logger.debug("Exiting insertMultiPaymentPreferences");
            return insertedDocs;
        }

        @Override
        public PaymentPreference getPaymentPreferenceByTinAndMpin(String tin, String mpin) {
            logger.debug("Entering getPaymentPreferenceByTinAndMpin");
            PaymentPreference retVal = mongoTemplate.findOne(query(where("tin").is(tin).and("mpin").is(mpin)), PaymentPreference.class, PAYMENT_PREFERENCE_COLLECTION);
            logger.debug("Leaving getPaymentPreferenceByTinAndMpin");
            return retVal;
        }

        @Override
        public PaymentPreference updatePaymentPreference(String tin, String mpin, String paymentPref, String updatedBy, String updatedByName ) {
            logger.debug("Entering updatePaymentPreference");
            String optOut = "Y";
            PaymentPreference doc = mongoTemplate.findOne(query(where("tin").is(tin).and("mpin").is(mpin)), PaymentPreference.class, PAYMENT_PREFERENCE_COLLECTION);
            if (doc != null) {
                if (Objects.equals(paymentPref, "optOut")) {
                    try {
                        handleOptOutPreference(tin, optOut);
                    } catch (ApplicationException | JsonProcessingException e) {
                        logger.error("Failed to call PE Opt-Out API: {}", e.getMessage());
                    }
                }
                doc.setPaymentpref(paymentPref);
                doc.setUpdatedBy(updatedBy);
                doc.setDateModified(new java.util.Date());
                doc.setUpdatedByName(updatedByName);
                mongoTemplate.save(doc, PAYMENT_PREFERENCE_COLLECTION);
                logger.debug("Exiting updatePaymentPreference");

            } else {
                PaymentPreference insertDoc = new PaymentPreference();
                insertDoc.setTin(tin);
                insertDoc.setMpin(mpin);
                insertDoc.setPaymentpref("VCP");
                insertDoc.setUpdatedBy(updatedBy);
                insertDoc.setUpdatedByName(updatedByName);
                insertDoc.setDateCreated(new Date());
                mongoTemplate.insert(insertDoc, PAYMENT_PREFERENCE_COLLECTION);
                doc = mongoTemplate.findOne(query(where("tin").is(tin).and("mpin").is(mpin)), PaymentPreference.class, PAYMENT_PREFERENCE_COLLECTION);
            }
            return doc;
        }

        public void handleOptOutPreference(String tin, String optOut)
                throws ApplicationException, JsonProcessingException {
                UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(PaymentEngine_URL);
                HttpHeaders headers = new HttpHeaders();

                logger.info("PaymentPreferenceServiceImpl handleOptOutPreference, tin={}, optout={}", Encode.forJava(tin), Encode.forJava(optOut));
                headers.setContentType(MediaType.APPLICATION_JSON);
                headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
                if (upstreamEnv != null && !upstreamEnv.isEmpty()) {
                    headers.set("x-upstream-env", upstreamEnv);
                }
                ResponseEntity<String> response;
                try {

                    // Get Payment OAuth token
                    Token token = getPaymentEngineToken("PE");
                    headers.set(AUTHORIZATION_STRING, BEARER_STRING + token.getAccessToken());
                    Map<String, String> payload = new HashMap<>();
                    payload.put("tin", tin);
                    payload.put("optOut", optOut);
                    String jsonPayload = objectMapper.writeValueAsString(payload);

                HttpEntity<String> requestEntity = new HttpEntity<>(jsonPayload, headers);

                    response = (ResponseEntity<String>) peHandler.sendRequestPaymentEngine(builder.toUriString(), requestEntity, HttpMethod.POST);
                } catch (Exception e) {
                    logger.error("Error calling Payment Engine API, exception={}", ExceptionUtils.getStackTrace(e));
                    throw new ApplicationException("Error calling Payment Engine API: " + e.getMessage());
                }
        }

        public Token getPaymentEngineToken(String sessionId) throws ApplicationException {
            Token tempToken = null;
            try {
                tempToken = (Token) oauth2handler.getOauthToken(sessionId, "PE");
                Objects.requireNonNull(tempToken.getAccessToken());
            } catch (IOException | OAuthSystemException | OAuthProblemException e) {
                logger.error("getPaymentEngineToken -> Failed to get OAuth token");
                throw new ApplicationException(oauthFailure + e.toString());
            }
            return tempToken;

        }

}