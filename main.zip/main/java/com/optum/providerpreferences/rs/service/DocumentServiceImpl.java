package com.optum.providerpreferences.rs.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.mongo.document.DeliveryPreference;

@Service
public class DocumentServiceImpl implements DocumentService {

	private static final String PDO_DOCUMENT_COLLECTION = "deliveryPreference";
	private static final String ID = "id";

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public DeliveryPreference createDocument(DeliveryPreference document) throws ApplicationException {
		try {
			document.setDateCreated(new Date());
			document.setDateModified(new Date());

			mongoTemplate.insert(document, PDO_DOCUMENT_COLLECTION);
			return document;

		} catch (Exception e) {
			throw new ApplicationException("Failed to create PDO document: "+ e);
		}
	}

	@Override
	public DeliveryPreference getDocumentById(String id) throws ApplicationException {

		Query query = Query.query(Criteria.where(ID).is(id));
		DeliveryPreference entity = mongoTemplate.findOne(query, DeliveryPreference.class, PDO_DOCUMENT_COLLECTION);

		if (entity == null) {
			throw new ApplicationException("Document not found for Id: " + id);
		}
		return entity;
	}

	@Override
	public DeliveryPreference updateDocument(String id, DeliveryPreference updatedDocument)
			throws ApplicationException {

		Query query = Query.query(Criteria.where(ID).is(id));
		DeliveryPreference existing = mongoTemplate.findOne(query, DeliveryPreference.class, PDO_DOCUMENT_COLLECTION);

		if (existing == null) {
			throw new ApplicationException("Document not found Id: " + id);
		}

		java.util.Set<String> excludedFields = java.util.Set.of("id", "dateCreated", "dateModified");
		for (java.lang.reflect.Field field : DeliveryPreference.class.getDeclaredFields()) {
			if (excludedFields.contains(field.getName())) {
				continue;
			}

			field.setAccessible(true);
			try {
				Object newValue = field.get(updatedDocument);
				if (newValue == null) {
					continue;
				}
				if (newValue instanceof String && ((String) newValue).isEmpty()) {
					continue;
				}

				field.set(existing, newValue);
			} catch (IllegalAccessException e) {
				throw new ApplicationException("Failed to update field: " + field.getName() + ", error=" + e.getMessage());
			}
		}

		existing.setDateModified(new Date());

		mongoTemplate.save(existing, PDO_DOCUMENT_COLLECTION);
		return existing;
	}

	@Override
	public List<DeliveryPreference> getDocumentsBySearchTerms(Map<String, Object> searchCriteria) throws ApplicationException {
		try {
			Query query = new Query();

			// Build query from all provided criteria fields
			if (searchCriteria != null && !searchCriteria.isEmpty()) {
				searchCriteria.forEach((key, value) -> {
					if (value != null && !value.toString().isEmpty()) {
						query.addCriteria(Criteria.where(key).is(value));
					}
				});
			}
			query.with(org.springframework.data.domain.Sort.by(
					org.springframework.data.domain.Sort.Order.desc("dateCreated")
			));
			List<DeliveryPreference> documents = mongoTemplate.find(query, DeliveryPreference.class, PDO_DOCUMENT_COLLECTION);
			return documents;
		} catch (Exception e) {
			throw new ApplicationException("Failed to retrieve autoenrollment documents: " + e.getMessage());
		}
	}

	@Override
	public List<DeliveryPreference> getDocumentsByProvider(String tin, String mpin, String corpMpin, String email) throws ApplicationException {
		Map<String, Object> searchCriteria = new java.util.HashMap<>();
		if (tin != null && !tin.isEmpty()) searchCriteria.put("tin", tin);
		if (mpin != null && !mpin.isEmpty()) searchCriteria.put("mpin", mpin);
		if (corpMpin != null && !corpMpin.isEmpty()) searchCriteria.put("corpMpin", corpMpin);
		if (email != null && !email.isEmpty()) searchCriteria.put("providerEmailId", email);

		return getDocumentsBySearchTerms(searchCriteria);
	}


	@Override
	public void deleteDocument(String id) throws ApplicationException {
		Query query = Query.query(Criteria.where(ID).is(id));
		DeliveryPreference document = mongoTemplate.findOne(query, DeliveryPreference.class, PDO_DOCUMENT_COLLECTION);

		if (document == null) {
			throw new ApplicationException("Autoenrollment document not found for ID: " + id);
		}

		mongoTemplate.remove(document, PDO_DOCUMENT_COLLECTION);
	}
}