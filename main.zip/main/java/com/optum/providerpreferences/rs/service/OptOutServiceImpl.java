package com.optum.providerpreferences.rs.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.optum.providerpreferences.rs.mongo.document.DeliveryPreference;
import com.optum.providerpreferences.rs.utility.ProviderPreferencesUtil;
import org.owasp.encoder.Encode;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.handler.PESHandler;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesRequest;
import com.optum.providerpreferences.rs.model.ndb.preferences.RequestHeader;
import com.optum.providerpreferences.rs.model.ndb.provider.CorpMpinResponse;
import com.optum.providerpreferences.rs.model.ndb.provider.MpinData;
import com.optum.providerpreferences.rs.model.ndb.provider.RequestData;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudPOSTResponse;
import com.optum.providerpreferences.rs.model.optout.OptOutRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinRequest;
import com.optum.providerpreferences.rs.model.optout.OptOutTinResponse;
import com.optum.providerpreferences.rs.model.pes.PESResponse;
import com.optum.providerpreferences.rs.model.pes.PESTinRequest;
import com.optum.providerpreferences.rs.model.pes.TinObject;
import com.optum.providerpreferences.rs.utility.ApplicationUtil;

@Service
public class OptOutServiceImpl implements OptOutService {

	@Autowired
	NDBHandler ndbHandler;

	@Autowired
	PESHandler pesHandler;
	
	@Autowired
	ObjectMapper mapper;
	
	@Autowired
	FDSCloudHandler fdsCloudHandler;

	@Autowired
	DocumentService documentService;

	@Autowired
	ProviderPreferencesUtil provPrefUtil;

	@Value("${USE_FDSCLOUD}")
	protected boolean useFDSCloud;
	
	@Value("${PRUN_OPTOUT_EXPIRE_EMAIL_SUBJECT}")
    protected String PRUN_OPTOUT_EXPIRE_EMAIL_SUBJECT;
	
	@Value("${PRUN_OPTOUT_EXPIRE_EMAIL_MSG}")
    protected String PRUN_OPTOUT_EXPIRE_EMAIL_MSG;
	
	private ApplicationUtil app = new ApplicationUtil();


	private static final Logger LOGGER = LogManager.getLogger(OptOutServiceImpl.class);
	
	private static final String SESSION_ID_ALL = "allUpdate";
	
	@Override
	public FDSCloudGETResponse getOptOutAuditLog(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException{
		
		FDSCloudGETResponse response = fdsCloudHandler.FDSCloudGetRequest(sessionId, fdsCloudRequest, "", "");
		
		return response;
		
	}
	
//	@Override
//	public OptOutFDSCloudDocument getFDSCloudDocument(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException, IOException{
//
//		String documentId = fdsCloudRequest.getDocumentId();
//		OptOutFDSCloudDocument response = fdsCloudHandler.FDSCloudGetDocument(sessionId, documentId);
//
//		return response;
//
//	}
	
	@Override
	public ResponseEntity<OptOutFDSCloudPOSTResponse> addOptOutAuditLog(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException{
		
		ResponseEntity<OptOutFDSCloudPOSTResponse> response = fdsCloudHandler.FDSCloudPostRequest(sessionId, fdsCloudRequest, "");
		
		return response;
	}

	//unused
//	@Override
//	public ResponseEntity<OptOutFDSCloudPOSTResponse> FDSCloudPut(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException{
//
//		ResponseEntity<OptOutFDSCloudPOSTResponse> response = fdsCloudHandler.FDSCloudPutRequest(sessionId, fdsCloudRequest, "");
//
//		return response;
//	}

	//unused
//	@Override
//	public Map<String, Boolean> FDSCloudDelete(String sessionId, FDSCloudRequest fdsCloudRequest) throws ApplicationException{
//
//		String documentId = fdsCloudRequest.getRequest().get(PDOConstants.DOCUMENT_ID).toString();
//		Map<String, Boolean> response = fdsCloudHandler.FDSCloudDelete(sessionId, documentId);
//
//		return response;
//
//	}

	@Override
	public Map<String, List<String>> updateOptOutDocuments(OptOutRequest optOutRequest, HttpHeaders headers)
			throws ApplicationException, OAuthProblemException, OAuthSystemException,
			IOException {
		/**
		 * 1. get tin 2. get mpins from tin 3. loop through mpins and letter types 3a.
		 * update NDB 3b. search FDS to get documentId 4. use multi put to update all
		 * documents at once 5. send email to PODM with tin
		 */
		String cid = headers.getFirst("optum-cid-ext");
		String corpMpin = optOutRequest.getCorpMpin();
		String tin = optOutRequest.getTin();
		String lastUpdatedBy = optOutRequest.getLastUpdatedBy();
		String lastUpdatedById = optOutRequest.getLastUpdatedById();
		int optedOutDuration = optOutRequest.getOptedOutDuration();
		ndbHandler.ndbWebServicePrep();
		List<String> providerMpins = optOutRequest.getProviderMpins();
		List<String> categories = optOutRequest.getCategories();

		if (providerMpins.size() == 0) {
			RequestData request = new RequestData();
			request.setTaxIdNumber(tin);
			request.setCorpOwnerId(corpMpin);

			CorpMpinResponse corpMpinResponse = null;

			try {
				corpMpinResponse = ndbHandler.getProviderData(request, Encode.forJava(cid));
			} catch (ApplicationException | IOException | OAuthSystemException | OAuthProblemException | RestClientException e) {
				LOGGER.error("Error retrieving Provider Data from NDB, error={}", ExceptionUtils.getStackTrace(e));
				throw new ApplicationException("Error making service call to NDB");
			}

			Objects.requireNonNull(corpMpinResponse);

			providerMpins = new ArrayList<>();
			for (MpinData mpinData : corpMpinResponse.getResponse().getMpinList()) {
				providerMpins.add(padWithLeadingZeros(mpinData.getProviderId()));
			}

		}
		
		// TODO: Redo logic, for every mpin in providerMpins, update all available documents for letter type to opted out
		updateDeliveryMethodNDB(providerMpins, categories, tin, Encode.forJava(cid));
		Map<String, List<String>> documentIds = getDocuments(providerMpins, categories, tin, Encode.forJava(cid));

		LOGGER.info("Sending PUT request to update FDS documents, docIdsFound={}", documentIds.size());

		// test for put, does it replace everything, otherwise going to have to do creation per record and remove the tin/mpin/filename per so you can reuse the call
		// after testing: require all data to be sent in put request to ensure none of them are randomly dropped.
		for (Map.Entry<String, List<String>> entry : documentIds.entrySet()) {
			
			Map<String, Object> docMetadata = createOptOutDocument(entry.getValue(), lastUpdatedBy, lastUpdatedById, optedOutDuration);

			FDSCloudRequest fdsRequest = new FDSCloudRequest();
			fdsRequest.setDocumentId(entry.getKey());
			fdsRequest.setRequest(docMetadata);
			
			try {
	         	fdsCloudHandler.FDSCloudPutRequest(SESSION_ID_ALL, fdsRequest, Encode.forJava(cid));
	         } catch (RestClientException e) {
	             LOGGER.error("ERROR UPDATING DOCUMENT ID, documentID={}", fdsRequest.getDocumentId());
	             throw e;
	         }
			
			
		}
		return documentIds;  

	}
	
	@Override
	public void updateDeliveryMethodNDB(List<String> providerMpins, List<String> categories, String tin, String cid) throws RestClientException, NullPointerException, ApplicationException, OAuthProblemException, OAuthSystemException, IOException {
		
		for (String currentMpin : providerMpins) {
			for (String category : categories) {
				List<String> classifiers = getClassifiersForCategory(category);
			for (String classifier : classifiers) {
				// update NDB
				LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
				webRequest.setRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(
						currentMpin, tin, "U", "P", classifier));
				webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));

				boolean ndbRetry = false;
				while (!ndbRetry) {
					try {
						ndbRetry = ndbHandler.updateProviderLetterPreferences(webRequest, currentMpin, tin, Encode.forJava(cid));
					} catch (JsonProcessingException e) {

						LOGGER.error("ERROR UPDATING TO NDB, mpin={}, tin={}, error={}", Encode.forJava(currentMpin), Encode.forJava(tin), ExceptionUtils.getStackTrace(e));
						throw e;
					}
				}
			}
			}
		}
		
	}
	
	@Override
	public Map<String, List<String>> getDocuments(List<String> providerMpins, List<String> categories, String tin, String cid) throws RestClientException, NullPointerException, ApplicationException, OAuthProblemException, OAuthSystemException, IOException {
		
		Map<String, List<String>> documentIds = new HashMap<String, List<String>>();

		for (String currentMpin : providerMpins) {
				currentMpin = StringUtils.leftPad(currentMpin, 9, "0");
			for (String category : categories) {
				List<String> classifiers = getClassifiersForCategory(category);

				for (String classifier : classifiers) {

				// get FDS document ID and add to documentIds list

				List<OptOutFDSCloudDocument> sortedDocs = null;
				try {
					if (LOGGER.isInfoEnabled()) {
						LOGGER.info(">>>>>> TIN, MPIN, CLASSIFER: " + Encode.forJava(tin) + ", " + Encode.forJava(currentMpin) + ", " + Encode.forJava(classifier));
					}

					Map<String, Object> optOutRequest = new HashMap<String, Object>();
					optOutRequest.put("tin", tin);
					optOutRequest.put("mpin",currentMpin);
					optOutRequest.put("deliveryMethod", "E");
					optOutRequest.put("okToChangePDOInd", "N");
					optOutRequest.put("fileName", classifier);

					List<DeliveryPreference> sortedDocsMongo = documentService.getDocumentsBySearchTerms(optOutRequest);
					if(sortedDocsMongo == null || sortedDocsMongo.isEmpty()) {
						sortedDocs = fdsCloudHandler.getAvailableAutoenrolledForOptOut(tin, currentMpin, classifier, "Opt-Out", Encode.forJava(cid));
					}
					else{
						sortedDocs = provPrefUtil.convertDeliveryPrefsToOptOutDocs(sortedDocsMongo);
					}

				} catch (NullPointerException e) {
					// means there's nothing there, skip
					continue;
				} catch (IOException | OAuthProblemException | OAuthSystemException e) {
					LOGGER.error("Error retrieving document from FDS, tin={}, mpin={}, classifier={}, e={}", Encode.forJava(tin),
							Encode.forJava(currentMpin), Encode.forJava(classifier), ExceptionUtils.getStackTrace(e));
					throw e;
				}
				if (sortedDocs != null && !sortedDocs.isEmpty()) {

					List<String> requestData = new ArrayList<String>();
					requestData.add(tin);
					requestData.add(currentMpin);
					requestData.add(classifier);
					documentIds.put(sortedDocs.get(0).getDocumentId(), requestData);
				}
			}
			}
		}
		
		for (Map.Entry<String, List<String>> entry : documentIds.entrySet()) {
			LOGGER.info(">>>> document ID | data: " + entry.getKey() + " | " + entry.getValue());
		}

		return documentIds;
	}
	
	@Override
	public OptOutTinResponse getTins(OptOutTinRequest optOutTinRequest, String cid) throws ApplicationException, JsonProcessingException {
		
		try {
			
			PESTinRequest request = new PESTinRequest(optOutTinRequest.getCorporateMpin());
			
			PESResponse response = pesHandler.getTins(request, Encode.forJava(cid));
			
			final Predicate<TinObject> valueNotNullOrEmpty = e -> e != null && e.getKey() != null && !StringUtils.isEmpty(e.getKey().getTaxIdNumber());
			
			List<String> tins = Optional.ofNullable(response.getData())
					.orElseGet(Collections::emptyList)
					.stream()
					.filter(valueNotNullOrEmpty)
					.map(tinObj -> tinObj.getKey().getTaxIdNumber())
					.collect(Collectors.toList());			
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("tins retrieved from pes for CID={}, corpMpin={}, tins={}", Encode.forJava(cid), Encode.forJava(optOutTinRequest.getCorporateMpin()), Encode.forJava(tins.toString()));
			}
			
			return new OptOutTinResponse(tins);

		} catch (Exception e) {
			LOGGER.error("Error retrieving tins from PES API, CID={}, e={}", Encode.forJava(cid), ExceptionUtils.getStackTrace(e));
			throw e;
		}
		
		
		
	}
	
	
//	public void revertExpiredOptOutDocuments(String mpin, String cid) {
//		LOGGER.info("revertExpiredOptOutDocuments -- START");
//
//		// get all optOutDocuments with expiryDate < currentDate
//		try {
//
//			// pass in an mpin so GET request doesn't time out, or for testing purposes, if null then it won't search for mpin
//			// also for passing in mpin from cucumber test
//			FDSCloudGETResponse fdsResponse = fdsCloudHandler.getOptOutDocuments("GET_OPTOUT_DOCS", mpin, Encode.forJava(cid));
//
//			Set<String> tinsList = new HashSet<>();
//
//			for (OptOutFDSCloudDocument doc : fdsResponse.getDocuments()) {
//
//				Map<String, Object> metadata = fdsCloudHandler.getSearchTermsFromString(doc.getMetadata());
//
//
//				Instant expiryDate = parseExpiryDate(metadata.get(PDOConstants.EXPIRY_DATE).toString());
//
//				if (expiryDate.compareTo(new Date().toInstant()) <= 0) {
//
//					ndbHandler.ndbWebServicePrep();
//					// update NDB
//					LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
//					webRequest.setRequest(new com.optum.providerpreferences.rs.model.ndb.preferences.RequestData(
//							metadata.get(PDOConstants.MPIN).toString(),
//							metadata.get(PDOConstants.TIN).toString(),
//							"U",
//							"E",
//							metadata.get(PDOConstants.FILENAME).toString()
//							));
//					webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));
//
//					try {
//						ndbHandler.updateProviderLetterPreferences(webRequest, metadata.get(PDOConstants.MPIN).toString(), metadata.get(PDOConstants.TIN).toString(), Encode.forJava(cid));
//					} catch (JsonProcessingException e) {
//
//						LOGGER.error("ERROR UPDATING TO NDB, mpin={}, tin={}, error={}", metadata.get(PDOConstants.MPIN).toString(), metadata.get(PDOConstants.TIN).toString(), ExceptionUtils.getStackTrace(e));
//						return;
//					}
//
//					// update FDS
//					metadata.put(PDOConstants.DELIVERY_METHOD, "E");
//					metadata.put(PDOConstants.OK_TO_CHANGE_PDO_IND, "N");
//					metadata.put(PDOConstants.PROVIDER_EMAIL_ID, "");
//					metadata.put(PDOConstants.EXPIRY_DATE, "");
//
//					metadata.put(PDOConstants.LAST_UPDATED_BY, "");
//					metadata.put(PDOConstants.LAST_UPDATED_BY_ID, "");
//					metadata.put(PDOConstants.OPTED_OUT_DATE_TIME, "");
//					metadata.put(PDOConstants.OPTED_OUT_DURATION, "");
//
//					// TODO: replace with autoenrollment logic with above fields
//
////					MultiValueMap<String, Document> docsMapToSend = new LinkedMultiValueMap<>();
////					docsMapToSend.add("documents", doc);
////					HttpHeaders headers = new HttpHeaders();
////
////					try {
////                        fdsHandler.callFDSPutDocument(docsMapToSend, headers, doc.getId(), SESSION_ID_ALL);
////                    } catch (RestClientException| JsonProcessingException e) {
////                    	LOGGER.error("ERROR UPDATING DOCUMENT ID, documentID={}", doc.getId());
////                        return;
////                    }
//
//					// add tin to set
//					tinsList.add(metadata.get(PDOConstants.TIN).toString());
//				}
//			}
//
//			// send email to PODM
//			if (!tinsList.isEmpty()) {
//				String tins = String.join(", ", tinsList);
//				EmailUtils.sendEmailWithoutAttachment(tins, SftpUtil.createDateintoString(), PRUN_OPTOUT_EXPIRE_EMAIL_SUBJECT, PRUN_OPTOUT_EXPIRE_EMAIL_MSG);
//			}
//
//
//		} catch (Exception e) {
//			LOGGER.error("revertExpiredOptOutDocuments -> Error reverting expired opt out documents, error={}", ExceptionUtils.getStackTrace(e));
//		}
//	}

	@Override
	public Map<String, Object> createOptOutDocument(List<String> requestData, String lastUpdatedBy, String lastUpdatedById, int optedOutDuration) {
		
		Metadata metadata = new Metadata();
		
		// tin, mpin, classifier
		metadata.setTin(requestData.get(0));
		metadata.setMpin(requestData.get(1));
		metadata.setFileName(requestData.get(2));
		
		metadata.setLastUpdatedBy(lastUpdatedBy);
		metadata.setLastUpdatedById(lastUpdatedById);
		metadata.setOptedOutDuration(optedOutDuration);
		
		

		Calendar cal = Calendar.getInstance();
		metadata.setOptedOutDateTime(formatDate(cal.getTime()));

		if (optedOutDuration == -1) {
			metadata.setExpiryDate("9999-12-31T23:59:59.000Z");
			try {
			metadata.setExpiryDateEpoch(Long.valueOf("253402300799000"));
			} catch (NumberFormatException e) {
				LOGGER.error("e={}", e.getMessage());
			}
			
		} else {
			cal.add(Calendar.DATE, optedOutDuration);
			metadata.setExpiryDate(formatDate(cal.getTime()));
			metadata.setExpiryDateEpoch(cal.getTimeInMillis());
		}
		
		// hardcoded values
		metadata.setDeliveryMethod("P");
		metadata.setOkToChangePDOInd("Y");
		metadata.setAutoEdelUpdateInd("N");
		metadata.setAutoOptOutInd("Y");
		
		

		return mapper.convertValue(metadata, new TypeReference<Map<String, Object>>(){});
	}
	

	@Override
	public String padWithLeadingZeros(String currentMpin) throws ApplicationException {
		int currentMpinLength = currentMpin.length();
		String stringOfZeros = "";
		if (currentMpinLength == 9) {
			return currentMpin;
		} else if (currentMpinLength < 9) {
			int numberOfZerosNeeded = 9 - currentMpinLength;
			for (int i = 0; i < numberOfZerosNeeded; i++) {
				stringOfZeros += "0";
			}
			currentMpin = stringOfZeros + currentMpin;
			return currentMpin;
		} else {
			LOGGER.error("MPIN longer than 9 digits, mpin={}", currentMpin);
			throw new ApplicationException("MPIN longer than 9 digits");
		}

	}

	synchronized String formatDate(Date date) {
		SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		return isoDateFormat.format(date);
	}
	
//	private Instant parseExpiryDate(String date) {
//		DateTimeFormatter formatter = new DateTimeFormatterBuilder()
//        		.appendPattern("[yyyy-MM-dd'T'HH:mm:ss.SSS'Z']")
//                .appendPattern("[yyyy-MM-dd'T'HH:mm:ss.SSSxx]")
//                .parseDefaulting(ChronoField.MONTH_OF_YEAR, 01)
//                     .parseDefaulting(ChronoField.DAY_OF_MONTH, 01)
//                     .parseDefaulting(ChronoField.HOUR_OF_DAY, 0)
//                     .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 00)
//                     .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 00)
//                     .toFormatter();
//		return LocalDateTime.parse(date, formatter).atZone(ZoneId.of("UTC")).toInstant();
//	}

	List<String> getClassifiersForCategory(String category) {
		switch (category.toLowerCase()) {
			case "appeals":
				return Arrays.asList("X0", "X1", "X2", "X5", "X6", "X7", "X8", "X9", "Y2", "Y3", "Y4", "Y5", "Y6", "Y7");
			case "claims":
				return Arrays.asList("C1", "C2", "C3", "C4", "C6", "C7", "C8", "C9", "O6", "O7", "R0", "R1", "R2", "R3", "R7", "R8", "R9", "S0", "S1", "S2", "S6", "S7", "S8", "S9");
			case "overpayment":
				return Arrays.asList("C5", "O1", "O2", "R4", "R5", "R6", "S3", "S4", "S5");
			case "payment":
				return Arrays.asList("E1", "P0", "P1", "P2", "P3", "P4", "P6", "P7", "P8", "P9");
			case "priorauth":
				return Arrays.asList("A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8", "A9", "N1", "N2", "N3");
			case "housecalls":
				return Arrays.asList("H1", "HH");
			default:
				return Collections.emptyList();
		}	}

}
