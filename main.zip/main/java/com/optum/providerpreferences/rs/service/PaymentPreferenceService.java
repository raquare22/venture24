package com.optum.providerpreferences.rs.service;

import com.optum.providerpreferences.rs.model.PaymentPreference;

import java.util.List;

public interface PaymentPreferenceService {

        void deletePaymentPreference(String id);

        PaymentPreference insertPaymentPreference(PaymentPreference doc);

        PaymentPreference getPaymentPreference(String id);

        List<PaymentPreference> getPaymentPreferenceList(List<String> ids);

        List<PaymentPreference> insertMultiPaymentPreferences(List<PaymentPreference> paymentPreferenceList);

        PaymentPreference getPaymentPreferenceByTinAndMpin(String tin, String mpin);

        PaymentPreference updatePaymentPreference(String tin, String mpin, String paymentPref, String updatedBy, String updatedByName );


}