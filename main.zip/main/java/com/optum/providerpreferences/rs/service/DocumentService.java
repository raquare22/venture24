package com.optum.providerpreferences.rs.service;

import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.mongo.document.DeliveryPreference;

import java.util.List;
import java.util.Map;

public interface DocumentService {

	// DeliveryPreference Methods
	DeliveryPreference createDocument(DeliveryPreference document) throws ApplicationException;

	DeliveryPreference getDocumentById(String documentId) throws ApplicationException;

	DeliveryPreference updateDocument(String documentId, DeliveryPreference document) throws ApplicationException;

	List<DeliveryPreference> getDocumentsBySearchTerms(Map<String, Object> searchCriteria) throws ApplicationException;

	List<DeliveryPreference> getDocumentsByProvider(String tin, String mpin, String corpMpin, String email) throws ApplicationException;

	void deleteDocument(String id) throws ApplicationException;

}