package com.optum.providerpreferences.rs.service;

import com.optum.digitalsecurity.model.request.Org;
import com.optum.digitalsecurity.model.request.User;
import com.optum.digitalsecurity.model.response.*;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.handler.ServiceBase;
import com.optum.providerpreferences.rs.model.Token;
import com.optum.providerpreferences.rs.model.logging.LogMessage;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.util.*;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

@Service
public class DigitalSecurityServiceImpl extends ServiceBase implements DigitalSecurityService {
	
	private final Logger logger = LogManager.getLogger(DigitalSecurityServiceImpl.class);
	
	String oauthFailure="Failed to retrieve OAuth Token for Digital security API, CID={}";
	
	private static String AUTHORIZATION_STRING = "Authorization";
	private static String BEARER_STRING = "Bearer ";
	
	@Value("${DigiSec_User_URL}")
    protected String DigiSec_User_URL;

	@Value("${DigiSec_UserOrg_URL}")
    protected String DigiSec_UserOrg_URL;
	
	@Value("${DigiSec_PAA_URL}")
    protected String DigiSec_PAA_URL;

	@Override
	public PDOCorporates getCorporatesByPasswordOwner(String optumUUID, HttpHeaders headers, LogMessage logMessage)
			throws IOException, ApplicationException, OAuthSystemException, OAuthProblemException {
		String cid = headers.getFirst("optum-cid-ext");
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(DigiSec_User_URL);
		headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		Token token = null;
		ResponseEntity<ProviderProfile> response = null;
		try {
			token = getDigiSecToken(null, "DS");
			headers.set(AUTHORIZATION_STRING, BEARER_STRING + token.getAccessToken());
			User provRequest = new User();
			provRequest.setUuid(optumUUID);
			HttpEntity<User> requestEntity = new HttpEntity<>(provRequest, headers);
			response = (ResponseEntity<ProviderProfile>) sendRequest(builder.toUriString(), requestEntity, ProviderProfile.class, HttpMethod.POST, Encode.forJava(cid));
		} catch (Exception e) {
			logger.error("ERROR WITH DIGITAL SECURITY - CORPORATE MPIN CALL, CID={} error={}", Encode.forJava(cid), ExceptionUtils.getStackTrace(e));
			throw new ApplicationException("WEB SERVICE CALL FAILURE - DIGITAL SECURITY CORPORATE CALL");
		}

		List<ProviderOrg> users = response.getBody().getProviderOrg();
		Map<Boolean, List<ProviderOrg>> listByPaa = users.stream().collect(Collectors.groupingBy(ProviderOrg::isPaa));
		List<ProviderOrg> pwdOwnerProv = listByPaa.get(true);
		PDOCorporates metadata = new PDOCorporates();
		metadata.setOptumUUID(optumUUID);
		List<Corporate> corpList = new ArrayList<>();

		UnaryOperator<ProviderOrg> func = x -> {
			Corporate corp = new Corporate();
			corp.setUhcID(x.getUhcProviderId());
			corp.setMpin(x.getCorpMpin());
			String fName = x.getFirstName() != null ? x.getFirstName() : "";
			String lName = x.getLastName() != null ? x.getLastName() : "";
			corp.setCorporateName((fName + " " + lName).trim());
			corp.setProvId(x.getId());
			corpList.add(corp);
			return x;
		};
		metadata.setCorporates(corpList);
		long count = pwdOwnerProv
				.stream()
				.filter(x -> StringUtils.isNotBlank(x.getFirstName()) || StringUtils.isNotBlank(x.getLastName()))
				.map(func)
				.count();
		logger.info("provider count: {}, CID={}", count, Encode.forJava(cid));
		return metadata;
	}

	@Override
	public PDOTins getProvidersByCorporate(String uuid, String uhcId, String mpin, HttpHeaders headers,
		
		LogMessage logMessage) throws IOException, ApplicationException {

		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(DigiSec_UserOrg_URL);

		String cid = headers.getFirst("optum-cid-ext");
		headers = new HttpHeaders();
		
		headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        Token token = null;
        ResponseEntity<OrgData> response = null;
        try
        {
        token = getDigiSecToken(null, "DS");
        headers.set(AUTHORIZATION_STRING, BEARER_STRING+token.getAccessToken());
		Org provOrgReq = new Org();
		provOrgReq.setId(uuid);
		provOrgReq.setUhcProviderId(uhcId);
		provOrgReq.setCorpMpin(mpin);
		HttpEntity<Org> requestEntity = new HttpEntity<Org>(provOrgReq, headers);
			response = (ResponseEntity<OrgData>) sendRequest(builder.toUriString(), requestEntity, OrgData.class, HttpMethod.POST, Encode.forJava(cid));
        } catch (Exception e)
        {
            logger.error("ERROR WITH DIGITAL SECURITY - TIN CALL, CID={} error={}", Encode.forJava(cid), ExceptionUtils.getStackTrace(e));
            throw new ApplicationException("WEB SERVICE CALL FAILURE - DIGITAL SECURITY TIN CALL");
        }
		 List<Tin> tins = response.getBody().getTins();
		 logger.info("CID={}, provider tins count:{} ", Encode.forJava(cid), tins.size());
		 PDOTins pdoTins = new PDOTins();
		 pdoTins.setMpin(mpin);
		 pdoTins.setOptumUUID(uuid);
		 pdoTins.setUhcID(uhcId);
		 pdoTins.setProviders(tins);
		return pdoTins;
	}

	@Override

	public ResponseEntity<User> getEmailsByCorporate(String corporateMpin, HttpHeaders headers)
			throws IOException, ApplicationException, OAuthSystemException, OAuthProblemException {
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(DigiSec_PAA_URL);
		String cid = headers.getFirst("optum-cid-ext");

		logger.info("DigitalSecurityServiceImpl getEmailsByCorporate, CID={}, corpMpin={}", Encode.forJava(cid), Encode.forJava(corporateMpin));
		headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		Token token = null;
		ResponseEntity<User> response = new ResponseEntity<>(headers, HttpStatus.NOT_FOUND);
		try {
			token = getDigiSecToken("DS_PAA", Encode.forJava(cid));
			headers.set(AUTHORIZATION_STRING, BEARER_STRING + token.getAccessToken());
			Org provRequest = new Org();
			provRequest.setCorpMpin(corporateMpin);
			HttpEntity<Org> requestEntity = new HttpEntity<>(provRequest, headers);
			response = (ResponseEntity<User>) sendDigiSecRequest(builder.toUriString(), requestEntity, User.class, HttpMethod.POST, Encode.forJava(cid));
		} catch (Exception e) {
			logger.error("Issue with getting DigiSec PAA email, CID={}, exception={}", Encode.forJava(cid), ExceptionUtils.getStackTrace(e));
		}
		return response;
	}

	public Token getDigiSecToken(String sessionId, String cid) throws ApplicationException {
		Token tempToken = null;
		try {
			tempToken = (Token) oauth2handler.getOauthToken(sessionId, "DS");
			Objects.requireNonNull(tempToken.getAccessToken());
		} catch (IOException | OAuthSystemException | OAuthProblemException e) {
			logger.error("getDigiSecToken -> Failed to get OAuth token, CID={}", Encode.forJava(cid));
			throw new ApplicationException(oauthFailure + e.toString());
		}
		return tempToken;
	}

}
