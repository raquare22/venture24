package com.optum.providerpreferences.rs.optout;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.optum.providerpreferences.rs.handler.FDSCloudHandler;
import com.optum.providerpreferences.rs.handler.NDBHandler;
import com.optum.providerpreferences.rs.model.fds.FDSCloudGETResponse;
import com.optum.providerpreferences.rs.model.fds.FDSCloudRequest;
import com.optum.providerpreferences.rs.model.fds.PDOConstants;
import com.optum.providerpreferences.rs.model.ndb.preferences.LetterPreferencesRequest;
import com.optum.providerpreferences.rs.model.ndb.preferences.RequestData;
import com.optum.providerpreferences.rs.model.ndb.preferences.RequestHeader;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;
import com.optum.providerpreferences.rs.service.OptOutService;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.util.*;

@Component
public class SchedulerOptOut {

    private ObjectMapper mapper = new ObjectMapper();

    @Autowired
    OptOutService optOutService;

    @Autowired
    FDSCloudHandler fdsCloudHandler;

    @Autowired
    NDBHandler ndbHandler;

    private static final String SESSION_ID_ALL = "allUpdate";

    private SchedulerOptOut() {
        //private constructor to hide public one
    }

    private static Logger logger = LogManager.getLogger(SchedulerOptOut.class);

    @Scheduled(cron = "${SCHEDULER_OPT_OUT_CRON}") // default (prod) - 0 0 19 * * MON-FRI, testing (every minute) - 0 * * * * ?
    public void scheduleOptOut(){
        revertExpiredOptOutDocuments();
    }

    public void revertExpiredOptOutDocuments() {
        logger.info("revertExpiredOptOutDocuments -> START");

        try {
            FDSCloudGETResponse fdsResponse = getExpiredDocuments();
            logger.info("FDSCloudGET response={}",Encode.forJava(fdsResponse.toString()));

            for (OptOutFDSCloudDocument doc : fdsResponse.getDocuments()) {

                logger.info("document={}",doc);
                Map<String, Object> metadata = fdsCloudHandler.getSearchTermsFromString(doc.getMetadata());
                logger.debug("metadata BEFORE={}",metadata); // for debugging purpose

                // NDB UPDATE START
                ndbHandler.ndbWebServicePrep();
                LetterPreferencesRequest webRequest = new LetterPreferencesRequest();
                webRequest.setRequest(new RequestData(
                        metadata.get(PDOConstants.MPIN).toString(),
                        metadata.get(PDOConstants.TIN).toString(),
                        "U",
                        "E",
                        metadata.get(PDOConstants.FILENAME).toString()
                ));
                webRequest.setRequestHeader(new RequestHeader("PDO", " ", "938", "0"));
                try {
                    ndbHandler.updateProviderLetterPreferences(webRequest, metadata.get(PDOConstants.MPIN).toString(), metadata.get(PDOConstants.TIN).toString(), "");
                } catch (JsonProcessingException e) {
                    logger.error("ERROR UPDATING TO NDB, mpin={}, tin={}, error={}", metadata.get(PDOConstants.MPIN), metadata.get(PDOConstants.TIN), ExceptionUtils.getStackTrace(e));
                    return;
                }
                //NDB UPDATE FINISH

                //FDS CLOUD UPDATE START
                Map<String, Object> newMetadata = new HashMap<>();
                newMetadata.put(PDOConstants.FILENAME,metadata.get(PDOConstants.FILENAME));
                newMetadata.put(PDOConstants.DELIVERY_METHOD,"E");
                newMetadata.put(PDOConstants.TIN,metadata.get(PDOConstants.TIN));
                newMetadata.put(PDOConstants.PROVIDER_EMAIL_ID,metadata.get(PDOConstants.PROVIDER_EMAIL_ID));
                newMetadata.put(PDOConstants.ACTIVE_DATE,metadata.get(PDOConstants.ACTIVE_DATE));
                newMetadata.put(PDOConstants.OK_TO_CHANGE_PDO_IND,"N");
                newMetadata.put(PDOConstants.MPIN,metadata.get(PDOConstants.MPIN));
                newMetadata.put(PDOConstants.AUTO_EDEL_UPDATE_IND,"Y");
                newMetadata.put(PDOConstants.FILE_TYPE,metadata.get(PDOConstants.FILE_TYPE));
                newMetadata.put(PDOConstants.FREQUENCY,"D");
//                newMetadata.put(PDOConstants.OPTED_OUT_DURATION,""); // should this be included ??
//                newMetadata.put(PDOConstants.AUTO_OPT_OUT_IND,""); // should this be included ??
//                newMetadata.put(PDOConstants.EXPIRY_DATE,""); // should this be included ??
                newMetadata.put(PDOConstants.LAST_UPDATED_BY,"SchedulerOptout");
                newMetadata.put(PDOConstants.LAST_UPDATED_BY_ID,"SchedulerOptoutId");

                logger.debug("metadata AFTER={}",newMetadata); // for debugging purpose
                FDSCloudRequest postRequest = new FDSCloudRequest();

                postRequest.setRequest(newMetadata);
                postRequest.setDocumentId(doc.getDocumentId());
                sendFDSCloudPutRequest(postRequest,doc.getDocumentId());
                //FDS CLOUD UPDATE FINISH
            }
        } catch (Exception e) {
            logger.error("revertExpiredOptOutDocuments -> Error reverting expired opt out documents, error={}", ExceptionUtils.getStackTrace(e));
        }
        logger.info("revertExpiredOptOutDocuments -> END");
    }

    // function to get all optOutDocuments with expiryDate < currentDate
    public FDSCloudGETResponse getExpiredDocuments() {

        Long currentTimeEpoch = System.currentTimeMillis();
        String currentEpochTimeString = String.valueOf(currentTimeEpoch);
        String requestValue = "(expiryDateEpoch<" + currentEpochTimeString + ")";
//        String requestValue = "(expiryDateEpoch<1668008856194)"; // for debugging purpose
        logger.info("searchTerms with expiryDateEpoch = {}",requestValue);

        HashMap<String, Object> request =  new HashMap<>();
        request.put(PDOConstants.SEARCH_TERMS,requestValue);
        FDSCloudRequest fdsCloudRequest = new FDSCloudRequest();
        fdsCloudRequest.setRequest(request);

        FDSCloudGETResponse response =  new FDSCloudGETResponse();
        try{
            response = optOutService.getOptOutAuditLog("FDSCloudGET", fdsCloudRequest);
        } catch(Exception e)
        {
            logger.error("ERROR IN SEARCHING DOCUMENTS (FDSCloudGET), request={}, error={}",fdsCloudRequest ,ExceptionUtils.getStackTrace(e));
        }
        return response;
    }

    //fds cloud put request
    private void sendFDSCloudPutRequest(FDSCloudRequest request, String docId) {
        try {
            fdsCloudHandler.FDSCloudPutRequest(SESSION_ID_ALL, request, "");
        } catch (Exception e) {
            Gson gson = new Gson();
            String requestString = gson.toJson(request.getRequest());
            logger.warn("ERROR UPDATING FDSCLOUD DOCUMENT ID e={}, -> \"documentID\":\"{}\", \"request\":{}", ExceptionUtils.getStackTrace(e), docId, requestString);
        }
    }


    }