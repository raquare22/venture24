package com.optum.providerpreferences.rs.utility;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import kong.unirest.HttpRequestWithBody;

public final class SanitizeUtil {
	private static final String AUTHORIZATION = "Authorization";

	private SanitizeUtil() {}

	public static String sanitizeString(String input){
		if (input == null) {
			return null;
		}
		try {
			return JsonParser.parseString(input).toString().replaceAll("\\r|\\n", "");
		} catch (JsonSyntaxException e) {
			//return input.replaceAll("[^a-zA-Z0-9_-]", "");
			return "Sanitize Failure";
		}
	}

	public static HttpRequestWithBody sanitizeHttpRequestWithBody(HttpRequestWithBody requestEntity) {
		return requestEntity;
	}

	public static HttpEntity<?> sanitizeHttpEntityHeader(HttpEntity<?> requestEntity) {
		HttpEntity<?> newRequestEntity = new HttpEntity<>(requestEntity.getBody(),sanitizeHttpHeaders(requestEntity.getHeaders()));
		return newRequestEntity;
	}

	public static HttpHeaders sanitizeHttpHeaders(HttpHeaders headers) {
		return new HttpHeaders();
	}

	public static HttpEntity<?> sanitizeHttpEntityHeaderRmAuth(HttpEntity<?> requestEntity) {
		requestEntity = new HttpEntity<>(requestEntity.getHeaders());
		HttpHeaders httpHeaders = requestEntity.getHeaders();
		httpHeaders.remove(AUTHORIZATION);
		if (requestEntity.getHeaders().getContentType() != null) {
			httpHeaders.setContentType(new MediaType(sanitizeString(requestEntity.getHeaders().getContentType().toString())));
		}
		return requestEntity;
	}

	public static String sanitizeResponseEntityBody(ResponseEntity<?> response) {
		return response != null && response.getBody() != null ? sanitizeToString(response.getBody().toString()) : null;
	}
	
	public static String sanitizeStringConatinsOnlyDigits(String str) {
		return str.matches("\\d*") ? SanitizeUtil.sanitizeString(str) : "Sanitize failure not digits";
		}

	public static String sanitizeToString(String str){
		return str == null ? null : str.replaceAll("\\v", "");
	}

	public static String sanitizeNumericString(String input){
		if (input == null) {
			return null;
		}
		if (input.matches("[0-9]{9}")){return input.strip();}
		else{return "Sanitize failure";}
	}
}