package com.optum.providerpreferences.rs.utility;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.optum.providerpreferences.rs.mongo.document.DeliveryPreference;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.owasp.encoder.Encode;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.providerpreferences.rs.exception.ApplicationException;
import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.Metadata;
import com.optum.providerpreferences.rs.model.optout.OptOutFDSCloudDocument;

@Component
public class ProviderPreferencesUtil {
	
	private ObjectMapper mapper = new ObjectMapper();
	
	private static final Logger logger = LogManager.getLogger(ProviderPreferencesUtil.class);
	
	
	public Map<String, Object> createDocToSendCloud(PreferenceType masterPref, String mpin, String tin, String docId, String activeDateStr, String subscribeToEmail) throws ParseException {
		
		Document docToSend = new Document();
	 	Metadata metadata = new Metadata();
	 	List<String> secondaryEmails = masterPref.getSecondaryProviderEmailIds();
	 	
	 	if (docId != null) {
	 		docToSend.setId(docId);
	 	}
	 	if (masterPref.getActiveDate() != null) {
	 		// if PUT request contains activeDate
	 		// this will most likely never happen (scenario 1)
	 		metadata.setActiveDate(masterPref.getActiveDate());
	 	} else {
	 		// get activeDateStr from existing document (scenario 2)
	 		// if its null then that means the existing record doesn't have activeDate so it doesn't need it (scenario 3)
	 		if (activeDateStr != null) {
	 			metadata.setActiveDate(activeDateStr);
	 		}
	 	}

		if(masterPref.getSubscribeToEmail()!= null){
			metadata.setSubscribeToEmail(masterPref.getSubscribeToEmail());
		}
		else{
			if(subscribeToEmail!=null){
				metadata.setSubscribeToEmail(subscribeToEmail);
			}
			else{
				metadata.setSubscribeToEmail("Y");
			}
		}

	     metadata.setDeliveryMethod(masterPref.getDeliveryMethod());
	     metadata.setFileName(masterPref.getClassifier());
	     metadata.setFileType(ClassifierDescription.getClassifierDescription(masterPref.getClassifier()));
	     metadata.setFrequency(masterPref.getFrequency());
	     metadata.setMpin(mpin);
	     metadata.setProviderEmailId(masterPref.getProviderEmailId());
	     metadata.setProviderName(masterPref.getProviderName());
	     metadata.setTin(tin);
	     metadata.setAutoEdelUpdateInd(masterPref.getAutoEdelUpdateInd());
	     metadata.setOkToChangePDOInd(masterPref.getOkToChangePDOInd());
	     
	     // TODO: add lastUpdatedById for optumUUID
	     metadata.setLastUpdatedBy(masterPref.getLastUpdatedBy());
	     metadata.setLastUpdatedById(masterPref.getLastUpdatedById());
	     metadata.setAutoOptOutInd(masterPref.getAutoOptOutInd());
	     metadata.setOptedOutDuration(masterPref.getOptedOutDuration());
	     metadata.setOptedOutDateTime(masterPref.getOptedOutDateTime());
		 metadata.setLastOONPopUpDate(masterPref.getLastOONPopUpDate());
		 
		// INSERT: persist secondary recipient emails 
		metadata.setSecondaryProviderEmailIds((secondaryEmails == null) ? Collections.emptyList() : secondaryEmails);

		if (masterPref.getOptedOutDuration() != null
	     		&& masterPref.getOptedOutDateTime() != null   
	     		&& (masterPref.getExpiryDate() == null 
	     		|| masterPref.getExpiryDate().isEmpty() 
	     		|| masterPref.getExpiryDate().length() < "2020-05-01T04:00:00.000Z".length())) {
	     	if (masterPref.getOptedOutDuration() == -1) {
	     		metadata.setExpiryDate("9999-12-31T23:59:59.000Z");
	     	}
	     	else {
	     		Calendar cal = Calendar.getInstance();
	     		Date optOutDate = parseDateString(masterPref.getOptedOutDateTime());
	         	cal.setTime(optOutDate);
	         	cal.add(Calendar.DATE, masterPref.getOptedOutDuration());
	         	metadata.setExpiryDate(formatDate(cal.getTime()));
	     	}
	     }
	     else {
	     	metadata.setExpiryDate(masterPref.getExpiryDate());
	     }

	     docToSend.setMetadata(metadata);

	     return mapper.convertValue(metadata, new TypeReference<Map<String, Object>>() {});
	     	
	    }
	
	public Map<String, Object> createDocToSendWithClassifierCloud(PreferenceType masterPref, String mpin, String tin, String docId, String activeDateStr, String subscribeToEmail, String classifier) throws ParseException {
		
		Document docToSend = new Document();
		Metadata metadata = new Metadata();
		List<String> secondaryEmails = masterPref.getSecondaryProviderEmailIds();
		
		if (docId != null) {
			docToSend.setId(docId);
		}
		if (masterPref.getActiveDate() != null) {
			// if PUT request contains activeDate
			// this will most likely never happen (scenario 1)
			metadata.setActiveDate(masterPref.getActiveDate());
		} else {
			// get activeDateStr from existing document (scenario 2)
			// if its null then that means the existing record doesn't have activeDate so it doesn't need it (scenario 3)
			if (activeDateStr != null) {
				metadata.setActiveDate(activeDateStr);
			}
		}

		if(masterPref.getSubscribeToEmail()!= null){
			metadata.setSubscribeToEmail(masterPref.getSubscribeToEmail());
		}
		else{
			if(subscribeToEmail!=null){
				metadata.setSubscribeToEmail(subscribeToEmail);
			}
			else{
				metadata.setSubscribeToEmail("Y");
			}
		}

	    metadata.setDeliveryMethod(masterPref.getDeliveryMethod());
	    metadata.setFileName(classifier);
	    metadata.setFileType(ClassifierDescription.getClassifierDescription(classifier));
	    metadata.setFrequency(masterPref.getFrequency());
	    metadata.setMpin(mpin);
	    metadata.setProviderEmailId(masterPref.getProviderEmailId());
	    metadata.setProviderName(masterPref.getProviderName());
	    metadata.setTin(tin);
	    metadata.setAutoEdelUpdateInd(masterPref.getAutoEdelUpdateInd());
	    metadata.setOkToChangePDOInd(masterPref.getOkToChangePDOInd());
		metadata.setLastOONPopUpDate(masterPref.getLastOONPopUpDate());
	    
	    metadata.setLastUpdatedBy(masterPref.getLastUpdatedBy());
	    metadata.setLastUpdatedById(masterPref.getLastUpdatedById());
	    metadata.setAutoOptOutInd(masterPref.getAutoOptOutInd());
	    metadata.setOptedOutDuration(masterPref.getOptedOutDuration());
	    metadata.setOptedOutDateTime(masterPref.getOptedOutDateTime());

metadata.setSecondaryProviderEmailIds(
    (secondaryEmails == null) ? Collections.emptyList() : secondaryEmails
);

	    
	    if (masterPref.getOptedOutDuration() != null 
	    		&& masterPref.getOptedOutDateTime() != null   
	    		&& (masterPref.getExpiryDate() == null 
	    		|| masterPref.getExpiryDate().isEmpty() 
	    		|| masterPref.getExpiryDate().length() < "2020-05-01T04:00:00.000Z".length())) {
	    	if (masterPref.getOptedOutDuration() == -1) {
	    		metadata.setExpiryDate("9999-12-31T23:59:59.000Z");
	    	}
	    	else {
	    		Calendar cal = Calendar.getInstance();
	    		Date optOutDate = parseDateString(masterPref.getOptedOutDateTime());
	        	cal.setTime(optOutDate);
	        	cal.add(Calendar.DATE, masterPref.getOptedOutDuration());
	        	metadata.setExpiryDate(formatDate(cal.getTime()));
	    	}
	    }
	    else {
	    	metadata.setExpiryDate(masterPref.getExpiryDate());
	    }
	    
	   
	    docToSend.setMetadata(metadata);

	    return mapper.convertValue(metadata, new TypeReference<Map<String, Object>>() {});
	}


		
		public synchronized String formatDate(Date date) {
			SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			return isoDateFormat.format(date);
		}
		
		public synchronized Date parseDateString(String date) throws ParseException {
			SimpleDateFormat isoDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			return isoDateFormat.parse(date);
		}
	    
	    
	    public String padWithLeadingZeros(String currentMpin) throws ApplicationException
	    {
	        int currentMpinLength = currentMpin.length();
	        String stringOfZeros = "";
	        if (currentMpinLength == 9)
	        {
	            return currentMpin;
	        }
	        else if (currentMpinLength < 9)
	        {
	            int numberOfZerosNeeded = 9 - currentMpinLength;
	            for (int i = 0; i < numberOfZerosNeeded; i++)
	            {
	                stringOfZeros += "0";
	            }
	            currentMpin = stringOfZeros + currentMpin;
	            return currentMpin;
	        }
	        else
	        {
	            logger.error("MPIN longer than 9 digits, mpin={}", Encode.forJava(currentMpin));
	            throw new ApplicationException("MPIN longer than 9 digits");
	        }

	    }
	    
	    public AutoEnrollment determineDocumentIndex(List<Document> documentList, int documentCount, int index, OffsetDateTime currentDate) throws AssertionError {
	 		logger.debug("Entering determineDocumentIndex: documentCount={}, index={}", documentCount, index);
	 		
	 		String documents=printDocument(documentList.get(index).getMetadata());
	 		// PDO have the assumption that a maximum of 2 documents will exist for a given MPIN/TIN/LetterType combination
	 		// them being the AutoEnrollment and the pre-AutoEnrollment records.
	 		// The niche scenario occurs where a preference only has an AutoEnrollment record with no pre-AutoEnrollment record for
	 		// it will create a new pre-AutoEnrollment record to store client changes between now and AutoEnrollment date.
	 		// Thus if we have > 2 records they will be ignore.
	 		
	 		String activeDateStr = documentList.get(index).getMetadata().getActiveDate();
	 		if (activeDateStr == null || activeDateStr.isEmpty()) {
	 			logger.debug("AutoEnrollment not found: documentCount={}, index={}, {}",
	 					documentCount, index, documents);
	 			return new AutoEnrollment(false, index);
	 		}

	 		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX"); 		
	 		OffsetDateTime activeDate = null;
	 		try {
	 			activeDate = OffsetDateTime.parse(activeDateStr, df);
	 		} catch(Exception e) {
	 			logger.error("checkDocumentIndex: ZonedDateTime; {}: {}", printDocument(documentList.get(index).getMetadata()), e);
	 			return new AutoEnrollment(true, -1);
	 		}
	 		if (currentDate.isAfter(activeDate)) {
	 			logger.debug("AutoEnrollment active: documentCount={}, index={}, {}",
	 					documentCount, index, documents);
	 			return new AutoEnrollment(true, index);
	 		}
	 		logger.debug("AutoEnrollment not active: documentCount={}, index={}, {}",
	 				documentCount, index, documents);
	 		return new AutoEnrollment(true, -1);
	 	}

	public AutoEnrollment determineDocumentIndexCloud(List<OptOutFDSCloudDocument> documentList, int documentCount, int index, OffsetDateTime currentDate, String cid) throws AssertionError, IOException {
		logger.debug("Entering determineDocumentIndex: CID={}, documentCount={}, index={}", Encode.forJava(cid), documentCount, index);

		String metadataStr = documentList.get(index).getMetadata();
		// PDO have the assumption that a maximum of 2 documents will exist for a given MPIN/TIN/LetterType combination
		// them being the AutoEnrollment and the pre-AutoEnrollment records.
		// The niche scenario occurs where a preference only has an AutoEnrollment record with no pre-AutoEnrollment record for
		// it will create a new pre-AutoEnrollment record to store client changes between now and AutoEnrollment date.
		// Thus if we have > 2 records they will be ignore.
		Metadata metadata;
		try {
			metadata = mapper.readValue(metadataStr, Metadata.class);
		} catch (IOException e) {
			logger.error("Unable to parse metadata string, CID={}", Encode.forJava(cid));
			throw e;
		}

		long currentTimeEpoch = System.currentTimeMillis();
		Long optedOutExpiryEpoch = metadata.getExpiryDateEpoch();

		if (optedOutExpiryEpoch != null && currentTimeEpoch < optedOutExpiryEpoch) {
			logger.info("Valid Optout found: CID={}, documentCount={}, index={}, {}",
					Encode.forJava(cid), documentCount, index, metadataStr);
			return new AutoEnrollment(true, index);
		}

		String activeDateStr = metadata.getActiveDate();

		if (activeDateStr == null || activeDateStr.isEmpty()) {
			logger.debug("AutoEnrollment not found: CID={}, documentCount={}, index={}, {}",
					Encode.forJava(cid), documentCount, index, metadataStr);
			return new AutoEnrollment(false, index);
		}

		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		OffsetDateTime activeDate = null;
		try {
			activeDate = OffsetDateTime.parse(activeDateStr, df);
		} catch(AssertionError e) {
			logger.error("checkDocumentIndex: ZonedDateTime; CID={}, {}: {}", Encode.forJava(cid), activeDateStr, e.getMessage());
			return new AutoEnrollment(true, -1);
		}
		if (currentDate.isAfter(activeDate)) {
			logger.debug("AutoEnrollment active: CID={}, documentCount={}, index={}, {}",
					Encode.forJava(cid), documentCount, index, metadataStr);
			return new AutoEnrollment(true, index);
		}
		logger.debug("AutoEnrollment not active: CID={}, documentCount={}, index={}, {}",
				Encode.forJava(cid), documentCount, index, metadataStr);
		return new AutoEnrollment(true, -1);
	}
		
		public int determineMulti(AutoEnrollment autoEnrollment0, AutoEnrollment autoEnrollment1) {
	 		if (autoEnrollment0.isValidAutoEnrollment()) {
	 			return 0;
	 		}
	 		if (autoEnrollment1.isValidAutoEnrollment()) {
	 			return 1;
	 		}
	 		if (! autoEnrollment0.isAutoEnrollment()) {
	 			return 0;
	 		}
	 		if (! autoEnrollment1.isAutoEnrollment()) {
	 			return 1;
	 		}
	 		return -1;
	 	}
		
		protected String printDocument(Metadata metadata) {
			return "providerEmailId = " + metadata.getProviderEmailId() + ", mpin = " + metadata.getMpin() + ", fileName= " + metadata.getFileName();
		}

	public List<OptOutFDSCloudDocument> convertDeliveryPrefsToOptOutDocs(List<DeliveryPreference> mongoDocs) throws JsonProcessingException {
		List<OptOutFDSCloudDocument> converted = new ArrayList<>();
		if (mongoDocs == null) {
			return converted;
		}

		for (DeliveryPreference dp : mongoDocs) {
			if (dp == null) {
				continue;
			}

			OptOutFDSCloudDocument doc = new OptOutFDSCloudDocument();

			// IDs
			doc.setDocumentId(dp.getDocumentId() != null ? dp.getDocumentId() : dp.getId());
			doc.setSpaceId(dp.getSpaceId());

			// Timestamps / audit
			doc.setModifiedOn(dp.getModifiedOn() != null ? dp.getModifiedOn()
					: (dp.getDateModified() != null ? dp.getDateModified().getTime() : null));
			doc.setCreatedOn(dp.getCreatedOn() != null ? dp.getCreatedOn()
					: (dp.getDateCreated() != null ? dp.getDateCreated().getTime() : null));
			doc.setModifiedBy(dp.getModifiedBy());
			doc.setCreatedBy(dp.getCreatedBy());

			// Other top-level fields
			doc.setSearchTerms(dp.getSearchTerms());
			doc.setExternalId(dp.getExternalId());
			doc.setAttachments(dp.getAttachments());
			doc.setWorkflow(dp.getWorkflow());
			doc.setAccessToken(dp.getAccessToken());
			doc.setStatus(dp.getStatus());
			doc.setTransactionId(dp.getTransactionId());
			doc.setOnPremSpaceId(dp.getOnPremSpaceId());
			doc.setOnPremRecordType(dp.getOnPremRecordType());

			// metadata string expected by existing logic
			if (dp.getMetadata() != null && !dp.getMetadata().isEmpty()) {
				doc.setMetadata(dp.getMetadata());
			} else {
				Metadata metadata = new Metadata();
				metadata.setTin(dp.getTin());
				metadata.setMpin(dp.getMpin());
				metadata.setFileName(dp.getFileName());
				metadata.setDeliveryMethod(dp.getDeliveryMethod());
				metadata.setProviderEmailId(dp.getProviderEmailId());
				metadata.setFrequency(dp.getFrequency());
				metadata.setOkToChangePDOInd(dp.getOkTochangePDOInd() != null ? dp.getOkTochangePDOInd() : dp.getOkToChangePdoInd());
				metadata.setAutoEdelUpdateInd(dp.getAutoEdelUpdateInd());
				metadata.setActiveDate(dp.getActiveDate());
				metadata.setLastUpdatedBy(dp.getLastUpdatedBy());
				metadata.setLastUpdatedById(dp.getLastUpdatedById());
				metadata.setAutoOptOutInd(dp.getAutoOptOutInd());
				metadata.setOptedOutDuration(dp.getOptedOutDuration());
				metadata.setOptedOutDateTime(dp.getOptedOutDateTime());
				metadata.setExpiryDate(dp.getExpiryDate());
				metadata.setExpiryDateEpoch(dp.getExpiryDateEpoch());

				doc.setMetadata(mapper.writeValueAsString(metadata));
			}

			converted.add(doc);
		}
		return converted;
	}

	public static class AutoEnrollment {
	    	
	    	public boolean isAutoEnrollment;
	    	protected int index;
	    	
	    	public AutoEnrollment(Boolean isAutoEnrollment, int index) {
	    		this.isAutoEnrollment = isAutoEnrollment;
	    		this.index = index;
			}
	    	
	    	public boolean isAutoEnrollment() { return isAutoEnrollment; }

	 		public boolean isValidAutoEnrollment() {
	 			return isAutoEnrollment && index != -1;
	 		}

	    }
}
