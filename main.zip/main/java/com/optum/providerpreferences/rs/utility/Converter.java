/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.optum.providerpreferences.rs.model.PreferenceType;
import com.optum.providerpreferences.rs.model.fds.Document;
import com.optum.providerpreferences.rs.model.fds.Metadata;

/**
 * This utility is used to format preferences metadata to be stored in FDS.
 * 
 * @author Provider Paperless Letters
 */
public final class Converter
{
	private Converter() {
		//private constructor added to solve Sonar "Add a private constructor to hide the implicit public one"
	}
    public static String convertNullToString(String value)
    {
        return (value == null ? "" : value.trim());
    }

    public static Date convertStringToDate(String dateString) throws ParseException
    {

        SimpleDateFormat formatter = new SimpleDateFormat("E MMMM dd HH:mm:ss z yyyy");
        
        return formatter.parse(dateString);

    }

    public static Document convertPreferenceTypeToDoc(String docId, PreferenceType preferenceType, String providerTin, String mpin, String providerName)
    {
        Document document = new Document();
        document.setId(docId);
        document.setSpaceId(System.getenv("SPACE_ID"));
        Metadata metadata = new Metadata();
        metadata.setMpin(mpin);
        metadata.setFileName(Converter.convertNullToString(preferenceType.getClassifier()).toUpperCase());
        metadata.setFileType(ClassifierDescription.getClassifierDescription(Converter.convertNullToString(preferenceType.getClassifier()).toUpperCase()));
        metadata.setFrequency(Converter.convertNullToString(preferenceType.getFrequency()).toUpperCase());
        metadata.setProviderEmailId(Converter.convertNullToString(preferenceType.getProviderEmailId()));
        metadata.setTin(Converter.convertNullToString(providerTin));
        metadata.setProviderName(Converter.convertNullToString(providerName).toUpperCase());
        metadata.setDeliveryMethod(Converter.convertNullToString(preferenceType.getDeliveryMethod()).toUpperCase());
        metadata.setActiveDate(Converter.convertNullToString(preferenceType.getActiveDate()));
        document.setMetadata(metadata);

        return document;
    }
}
