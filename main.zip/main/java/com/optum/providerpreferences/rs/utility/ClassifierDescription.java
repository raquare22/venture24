/**
 * Copyright Optum Services Inc., 2017. All rights reserved. This software and documentation contain confidential and proprietary information owned by Optum
 * Services Inc., Unauthorized use and distribution are prohibited.
 */
package com.optum.providerpreferences.rs.utility;

import java.util.HashMap;
import java.util.Map;

/**
 * This class sets the descriptions for the 8 correspondence types.
 * 
 * @author Provider Paperless Letters
 */
public class ClassifierDescription {
    /**
     * API VERSION OF CLASSIFIER DESCRIPTION
     */
	private ClassifierDescription() {
		//private constructor added to solve Sonar "Add a private constructor to hide the implicit public one"
	}
    public static final Map<String, String> classifierDescriptionHash = new HashMap<>();

    private static final Map<String, String> lobMap = new HashMap<>();
    
    private static final String COMMERCIAL = "Commercial";
    private static final String UHC_WEST = "UHC West";
    private static final String UHCWEST = "UHCWest";
    private static final String MEDICARE = "Medicare";
    private static final String COMMUNITY_PLAN = "Community Plan";
    private static final String SPECIAL_NEEDS_PLAN = "Special Needs Plan";
    private static final String MEDICAID = "Medicaid";
    private static final String OTHER = "Other";
    private static final String HOUSE_CALLS = "House Calls";

    static {

        classifierDescriptionHash.put("C1", "Claim - Additional Info Needed");
        classifierDescriptionHash.put("C2", "Claim - Acknowledgements");
        classifierDescriptionHash.put("C3", "Claim Medicaid - Non covered");
        classifierDescriptionHash.put("C4", "Claim - Resubmit");
        classifierDescriptionHash.put("C5", "Overpayment Identified");
        classifierDescriptionHash.put("C6", "Claim - Recon Responses");
        classifierDescriptionHash.put("C7", "Claim - Therapy Authorizations");
        classifierDescriptionHash.put("C8", "Claim - Other");

        classifierDescriptionHash.put("A1", "Prior Auth - Approved");
        classifierDescriptionHash.put("A2", "Prior Auth - Denied");
        classifierDescriptionHash.put("A3", "Prior Auth - Lack of Information");
        classifierDescriptionHash.put("A4", "Prior Auth  - Approved");
        classifierDescriptionHash.put("A5", "Prior Auth - Denied");
        classifierDescriptionHash.put("A6", "Prior Auth - Lack of Information");
        classifierDescriptionHash.put("A7", "Prior Auth - Approved");
        classifierDescriptionHash.put("A8", "Prior Auth - Denied");
        classifierDescriptionHash.put("A9", "Prior Auth - Lack of Information");

        classifierDescriptionHash.put("N1", "Prior Auth - Approved");
        classifierDescriptionHash.put("N2", "Prior Auth - Denied");
        classifierDescriptionHash.put("N3", "Prior Auth - Lack of Information");
        
        classifierDescriptionHash.put("O1", "Overpayment Reconsideration Requests");
        classifierDescriptionHash.put("O2", "Overpayment Reconsideration Responses");

        classifierDescriptionHash.put("R1", "Claim Letters - Additional Info Needed");
        classifierDescriptionHash.put("R2", "Claim Letters - Reconsideration");
        classifierDescriptionHash.put("R3", "Claim Letters - Balance Billing");
        
        classifierDescriptionHash.put("R4", "Overpayment Identified");
        classifierDescriptionHash.put("R5", "Overpayment Reconsideration Requests");
        classifierDescriptionHash.put("R6", "Overpayment Reconsideration Responses");
        
        classifierDescriptionHash.put("R7", "Claim Letters - Initial Denial Letter");
        classifierDescriptionHash.put("R8", "Claim Letters - Post Payment Approval");
        classifierDescriptionHash.put("R9", "Claim Letters - Coding and Billing");
        classifierDescriptionHash.put("R0", "Claim Letters - Excluded from Readmission");
        
        classifierDescriptionHash.put("S3", "Overpayment Identified");
        classifierDescriptionHash.put("S4", "Overpayment Reconsideration Requests");
        classifierDescriptionHash.put("S5", "Overpayment Reconsideration Responses");

        classifierDescriptionHash.put("P1", "Detailed PRAs");
        classifierDescriptionHash.put("P2", "Virtual Card Payments and Info Only PRAs");
        classifierDescriptionHash.put("P3", "Detailed PRAs");
        classifierDescriptionHash.put("P4", "Virtual Card Payments & Info Only PRAs");
        classifierDescriptionHash.put("P5", "Payment Packages - Detailed Pmt Docs");
        classifierDescriptionHash.put("P6", "PRA");
        classifierDescriptionHash.put("P7", "Virtual Card Payments");
        classifierDescriptionHash.put("P8", "Payment Documents - Zero-Dollar PRAs");
        classifierDescriptionHash.put("P9", "Payment Documents - Zero-Dollar PRAs");
        classifierDescriptionHash.put("P0", "Payment Documents - Zero-Dollar PRAs");

        classifierDescriptionHash.put("E1", "Payment Documents - Zero-Dollar PRAs");
        
        classifierDescriptionHash.put("W4", "Overpayment Identified");
        classifierDescriptionHash.put("W5", "Overpayment Reconsideration Requests");
        classifierDescriptionHash.put("W6", "Overpayment Reconsideration Responses");
        
        classifierDescriptionHash.put("Y2", "Appeals and Disputes - Additional Information Needed (Rx)");
        classifierDescriptionHash.put("Y3", "Appeals and Disputes - Resolution (Rx)");
        classifierDescriptionHash.put("Y4", "Appeals and Disputes - Notification & Acknowledgement (Rx)");
        classifierDescriptionHash.put("Y5", "Additional Information Needed");
        classifierDescriptionHash.put("Y6", "Resolution");
        classifierDescriptionHash.put("Y7", "Notification and Acknowledgement");
        
        classifierDescriptionHash.put("X1", "Appeals and Disputes - Acknowledgement, Notification, and Response");
        classifierDescriptionHash.put("X2", "Appeals and Disputes - Acknowledgement, Notification, and Response");
        classifierDescriptionHash.put("X5", "Appeals and Disputes - Additional Information Needed");
        classifierDescriptionHash.put("X6", "Appeals and Disputes - Resolution");
        classifierDescriptionHash.put("X7", "Appeals and Disputes - Notification and Acknowledgement");
        classifierDescriptionHash.put("X8", "Appeals and Disputes - Additional Information Needed");
        classifierDescriptionHash.put("X9", "Appeals and Disputes - Resolution");
        classifierDescriptionHash.put("X0", "Appeals and Disputes - Notification and Acknowledgement");



        classifierDescriptionHash.put("S1", "Additional Info Needed");
        classifierDescriptionHash.put("S2", "Medical Reimbursement");
        classifierDescriptionHash.put("S6", "Medical Claim Review");
        classifierDescriptionHash.put("S7", "Medicaid Reconsiderations");
        classifierDescriptionHash.put("S8", "Individual & Family Plan Reconsiderations");
        classifierDescriptionHash.put("S9", "DSNP Reconsiderations");
        classifierDescriptionHash.put("S0", "Miscellaneous");
        classifierDescriptionHash.put("O5", "Optum Rx");
        classifierDescriptionHash.put("C9","Review Decision");
        classifierDescriptionHash.put("O6","Review Decision");
        classifierDescriptionHash.put("O7","Review Decision");

        classifierDescriptionHash.put("H1", "House Calls - Post Assessment Letters");
        classifierDescriptionHash.put("HH", "Other House Call Letter - Other");

        classifierDescriptionHash.put("E2", "Student Resources/Detailed PRAs");
        classifierDescriptionHash.put("E3", "Student Resources/Virtual Card Payments");
        classifierDescriptionHash.put("E4", "Student Resources/Zero Dollar PRAs");

        classifierDescriptionHash.put("M1", "Payments from Members/Remittance Documents");
        classifierDescriptionHash.put("M2", "Payments from Members/Virtual Card Payments and Remittance Documents");
        classifierDescriptionHash.put("M3", "Payments from Members/Remittance Documents");
        classifierDescriptionHash.put("M4", "Payments from Members/Virtual Card Payments and Remittance Documents");
        classifierDescriptionHash.put("M5", "Payments from Members/Remittance Documents");
        classifierDescriptionHash.put("M6", "Payments from Members/Remittance Documents");
        classifierDescriptionHash.put("M7", "Payments from Members/Virtual Card Payments and Remittance Documents");
    }

    static {
        lobMap.put("C1", COMMERCIAL);
        lobMap.put("C2", COMMERCIAL);
        lobMap.put("C3", COMMERCIAL);
        lobMap.put("C4", COMMERCIAL);
        lobMap.put("C5", COMMERCIAL);
        lobMap.put("C6", COMMERCIAL);
        lobMap.put("C7", COMMERCIAL);
        lobMap.put("C8", COMMERCIAL);

        lobMap.put("A1", COMMERCIAL);
        lobMap.put("A2", COMMERCIAL);
        lobMap.put("A3", COMMERCIAL);
        lobMap.put("A4", MEDICARE);
        lobMap.put("A5", MEDICARE);
        lobMap.put("A6", MEDICARE);
        lobMap.put("A7", UHC_WEST);
        lobMap.put("A8", UHC_WEST);
        lobMap.put("A9", UHC_WEST);

        lobMap.put("N1", COMMUNITY_PLAN);
        lobMap.put("N2", COMMUNITY_PLAN);
        lobMap.put("N3", COMMUNITY_PLAN);
        
        lobMap.put("O1", COMMERCIAL);
        lobMap.put("O2", COMMERCIAL);

        lobMap.put("R1", MEDICARE);
        lobMap.put("R2", MEDICARE);
        lobMap.put("R3", MEDICARE);
        lobMap.put("R4", MEDICARE);
        lobMap.put("R5", MEDICARE);
        lobMap.put("R6", MEDICARE);        
        lobMap.put("R7", MEDICARE);
        lobMap.put("R8", MEDICARE);
        lobMap.put("R9", MEDICARE);
        lobMap.put("R0", MEDICARE);

        lobMap.put("S3", COMMUNITY_PLAN);
        lobMap.put("S4", COMMUNITY_PLAN);
        lobMap.put("S5", COMMUNITY_PLAN);        
        
        lobMap.put("P1", COMMERCIAL);
        lobMap.put("P2", COMMERCIAL);
        lobMap.put("P3", MEDICARE);
        lobMap.put("P4", MEDICARE);
        lobMap.put("P5", UHC_WEST);
        lobMap.put("P6", COMMUNITY_PLAN);
        lobMap.put("P7", COMMUNITY_PLAN);
        lobMap.put("P8", COMMERCIAL);
        lobMap.put("P9", MEDICARE);
        lobMap.put("P0", COMMUNITY_PLAN);

        lobMap.put("E1", OTHER);
        lobMap.put("W4", UHC_WEST);
        lobMap.put("W5", UHC_WEST);
        lobMap.put("W6", UHC_WEST);
        
        lobMap.put("Y2", MEDICARE);
        lobMap.put("Y3", MEDICARE);
        lobMap.put("Y4", MEDICARE);
        lobMap.put("Y5", SPECIAL_NEEDS_PLAN);
        lobMap.put("Y6", SPECIAL_NEEDS_PLAN);
        lobMap.put("Y7", SPECIAL_NEEDS_PLAN);
        
        lobMap.put("X1", COMMERCIAL);
        lobMap.put("X2", COMMUNITY_PLAN);
        lobMap.put("X5", MEDICARE);
        lobMap.put("X6", MEDICARE);
        lobMap.put("X7", MEDICARE);
        lobMap.put("X8", UHC_WEST);
        lobMap.put("X9", UHC_WEST);
        lobMap.put("X0", UHC_WEST);
        
        lobMap.put("S1", COMMUNITY_PLAN);
        lobMap.put("S2", COMMUNITY_PLAN);
        lobMap.put("S6", COMMUNITY_PLAN);
        lobMap.put("S7", COMMUNITY_PLAN);
        lobMap.put("S8", COMMERCIAL);
        lobMap.put("S9", COMMUNITY_PLAN);
        lobMap.put("S0", COMMUNITY_PLAN);
        lobMap.put("O5", COMMUNITY_PLAN);
        lobMap.put("C9", COMMERCIAL);
        lobMap.put("O6", MEDICARE);
        lobMap.put("O7", COMMUNITY_PLAN);

        lobMap.put("H1", HOUSE_CALLS);
        lobMap.put("HH", HOUSE_CALLS);

        lobMap.put("E2", COMMERCIAL);
        lobMap.put("E3", COMMERCIAL);
        lobMap.put("E4", COMMERCIAL);

        lobMap.put("M1", COMMERCIAL);
        lobMap.put("M2", COMMERCIAL);
        lobMap.put("M3", MEDICARE);
        lobMap.put("M4", MEDICARE);
        lobMap.put("M5", UHC_WEST);
        lobMap.put("M6", COMMUNITY_PLAN);
        lobMap.put("M7", COMMUNITY_PLAN);
    }

    public static String getClassifierDescription(String classifier) {

        return classifierDescriptionHash.get(classifier);
    }

    public static String getLob(String lob) {
        return lobMap.get(lob);
    }

}
