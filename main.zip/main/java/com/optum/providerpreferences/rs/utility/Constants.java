package com.optum.providerpreferences.rs.utility;

public final class Constants
{
	private Constants() {
	      //private constructor added to solve Sonar "Add a private constructor to hide the implicit public one"
	   }
    public static final String UPDATE_PREFS_QUEUE = "update-prefs-amq";

    public static final String QUEUE_BROKER_URL = "tcp://" + System.getenv("QUEUE_HOST") + ":61616";

    public static final String PASSWORD = System.getenv("QUEUE_PASSWORD");

    public static final String USERNAME = "admin";

}
