package com.optum.digitalsecurity.model.response;

import java.util.List;

public class PDOCorporates {
	private String optumUUID;
	private List<Corporate> corporates;
    
	public String getOptumUUID() {
		return optumUUID;
	}
	public void setOptumUUID(String optumUUID) {
		this.optumUUID = optumUUID;
	}
	public List<Corporate> getCorporates() {
		return corporates;
	}
	public void setCorporates(List<Corporate> corporates) {
		this.corporates = corporates;
	}
	@Override
	public String toString() {
		return "PDOCorporates [optumUUID=" + optumUUID + ", corporates=" + corporates + "]";
	}
}
