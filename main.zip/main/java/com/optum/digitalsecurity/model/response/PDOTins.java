package com.optum.digitalsecurity.model.response;

import java.util.List;

public class PDOTins {
	private String optumUUID;
	private String uhcID;
	private String mpin;
	private List<Tin> providers;
	    
		public String getOptumUUID() {
			return optumUUID;
		}
		public void setOptumUUID(String optumUUID) {
			this.optumUUID = optumUUID;
		}
		public String getUhcID() {
			return uhcID;
		}
		public void setUhcID(String uhcID) {
			this.uhcID = uhcID;
		}
		public String getMpin() {
			return mpin;
		}
		public void setMpin(String mpin) {
			this.mpin = mpin;
		}
		public List<Tin> getProviders() {
			return providers;
		}
		public void setProviders(List<Tin> providers) {
			this.providers = providers;
		}
}
