def installDependencies() {
    sh 'yarn'
}

def getPackagesToBuildPR() {
    Set packagesToBuild = []
    def changeLogSets = sh returnStdout: true, script: "curl https://github.optum.com/api/v3/repos/optum-engineering-experience/engineering-platform/pulls/${CHANGE_ID}/files?per_page=100"
    def files = readJSON text: "$changeLogSets"

    for(int i = 0; i < files.size(); i++) {
        def file = files[i].filename
        
        if(file.startsWith('packages/') && !file.startsWith('packages/discovery-service')) {
            packagesToBuild.add(file.substring(0, file.indexOf('/', file.indexOf('/') + 1)))
        }
    }

    return packagesToBuild
}

def getPackagesToBuild() {
    Set packagesToBuild = []
    def changedFiles=sh(script: """
    git diff --name-only HEAD~1 HEAD | tr '\n' ',' | sed 's/.\$//'
    """, returnStdout: true)

    def changedFilesArray = changedFiles.split(',')

    for (int i = 0; i < changedFilesArray.size(); i++) {
        def file = changedFilesArray[i]
        print(file)

        if (file.startsWith('packages/') && !file.startsWith('packages/discovery-service')) {
            print(file.substring(0, file.indexOf('/', file.indexOf('/') + 1)))
            packagesToBuild.add(file.substring(0, file.indexOf('/', file.indexOf('/') + 1)))
        }     
    }

    return packagesToBuild
}

def commentOnPR(message, branch){
    sh """
        curl -u ${HCP_WEP_ADMIN}:${HCP_WEP_ADMIN_PW} -X POST https://github.optum.com/api/v3/repos/optum-engineering-experience/engineering-platform/issues/${branch.split('-')[1]}/comments -d '{"body": "${message}"}'
    """
}

def isCiSkip() {
    def lastCommit = sh returnStdout: true, script: "git log -1 --pretty=%B | cat | tr -d '\n'"
    ciSkipNotEscaped = lastCommit ==~ /.*\[ci skip\].*/
    return ciSkipNotEscaped
}

def handlePRCheckout(branch) {
    sh """
        git fetch origin pull/${branch.split('-')[1]}/head:${branch}
        git checkout ${branch}
    """
}

def handleBranchCheckout(branch) {
    sh """
        git fetch --no-tags --force --progress -- https://github.optum.com/optum-engineering-experience/engineering-platform.git
        git checkout -q ${branch}
    """
}

def buildPackages(packages, branch, isPR, baseBranch, targetBranch) {
    for (int i = 0; i < packages.size(); i++) {

        def path = determineJobPath(packages[i], branch, baseBranch, targetBranch);

        if(path == "" && packages[i] == "packages/shell"){
            echo "PR or master branch will not send to hcp-console-dev or hcp-console-stage-prod"
            return
        } else {

           build wait: false, 
                job: "/${packages[i].replace('packages', 'hcp-console')}${path}", 
                parameters: [
                    string(name: 'packageName', value: packages[i]), 
                    string(name: 'branch', value: branch),
                    booleanParam(name: 'isPR', value: isPR),
                    string(name: 'baseBranch', value: baseBranch),
                    string(name: 'targetBranch', value: targetBranch)
                    ]


        }
    }
}

def determineJobPath(packages, branch, baseBranch, targetBranch){
    
        if(packages == "packages/shell" && branch == "development"){

            return "/hcp-console-dev"
        }

        if(packages == "packages/shell" && branch == "crane"){

            return "/hcp-console-stage-prod"
        }

        if(packages == "packages/shell" && targetBranch == "master" && baseBranch.startsWith("hotfix") ){
            
            return "/hcp-console-hotfix"

        }

        if(packages != "packages/shell" ){
            // return empty string since partner packages don't have dev or stage pipelines
           return ""
        }

        return ""
}

def stashBuild() {
    sh 'yarn build'

    // Saving packages to a file to recall in future steps
    zip archive: true, dir: 'dist', zipFile: 'dist.zip'
    stash includes: 'dist.zip', name: 'dist'
}

def unstashDeploy(deployAsPR, branch, packageName, admin, pw) {    
    // Retrieve build from stash
    unstash 'dist'

    def packageJson = readJSON file: 'package.json'
    def repository = packageJson.com_uhc_repo1.repository
    def version = packageJson.version
    def path = deployAsPR 
        ? "${packageJson.com_uhc_repo1.path}/prs/${branch}"
        : packageJson.com_uhc_repo1.path

    // Deploy build to artifactory
    sh """
        curl -u ${admin}:${pw} -X PUT --header "X-Explode-Archive: true" --upload-file dist.zip "https://repo1.uhc.com/artifactory/${repository}/${path}/dist.zip"
    """

    // Update PR with comment on package location
    if (deployAsPR) {
        commentOnPR("Latest build now available at: https://repo1.uhc.com/artifactory/${repository}/${path}/${version}/remoteEntry.js", branch)
    } else {
        def prObj = getAssociatedPr(packageName)
        def relatedPrs = prObj.data.repository.commit.associatedPullRequests.edges
        def edgesLength = relatedPrs.size()

        if (edgesLength == 0) {
            println "NO ASSOCIATED PRs WERE FOUND.  NOTHING TO DO!"
            currentBuild.result = 'SUCCESS'
          return
        }
        else {
            def prNumber = relatedPrs[0].node.number
            println "FOUND THE ASSOCIATED PR $prNumber"
            commentOnPR("New Master version (${path}) -> [${version}] and Latest build now available at: https://repo1.uhc.com/artifactory/${repository}/${path}/${version}/remoteEntry.js", "PR-$prNumber")
        }
    }
}

def registerRemote(deployAsPR, branch, admin, pw) {    
    def packageJson = readJSON file: 'package.json'
    def discoveryJson = readJSON file: 'discovery.json'
    def repository = packageJson.com_uhc_repo1.repository
    def version = packageJson.version
    def path = deployAsPR 
        ? "${packageJson.com_uhc_repo1.path}/prs/${branch}"
        : packageJson.com_uhc_repo1.path
    def remoteEntry = "https://repo1.uhc.com/artifactory/${repository}/${path}/${version}/remoteEntry.js"

    // Updating the values in the discovery.json
    discoveryJson['version'] = version.toString()
    discoveryJson['remote'] = remoteEntry.toString()

    // Writing the values back to the discovery.json 
    writeJSON file: 'output.json', json: discoveryJson, pretty: 4

    sh """
        cat output.json
    """
    
    // Get an access token
    def response = readJSON text: sh(script: "curl -X POST https://devops-insights.optum.com/api/andromeda/login -H 'accept: application/json' -H 'Content-Type: application/json' -d '{ \"username\": \"${admin}\", \"password\": \"${pw}\"}'", returnStdout: true)
    
    // Deploy config to discovery service
    sh """
        curl -X PUT "https://devops-insights.optum.com/api/v2/insights/hcp-discovery" \
            -H "Accept: application/json" \
            -H "Authorization: ${response.access_token}" \
            -H "Content-Type: application/json" \
            -d @output.json
    """
}


def setVersion(){
    def packageJson = readJSON file: './packages/shell/package.json'
    MAJOR_MINOR_PATCH=packageJson['version']
    packageJson['version'] = "$MAJOR_MINOR_PATCH-$BUILD_VERSION".toString()
    writeJSON file: './packages/shell/package.json', json: packageJson
}


def getChangedFilesList() {
    changedFilesArray = []
    def changedFiles=sh(script: """
    git diff --name-only HEAD~1 HEAD | tr '\n' ',' | sed 's/.\$//'
    """, returnStdout: true)

    def changedFilesArray = changedFiles.split(',')

    return changedFilesArray
}

def isConfigOnlyChange(changedFiles, isImageBuildRequired) {
    for (file in changedFiles){
        // Jenkinsfile, OpenShift Template, Groovy or docs file was changed
        deployFileChanged = file.equalsIgnoreCase('packages/shell/Jenkinsfile-DEV') || file.equalsIgnoreCase('packages/shell/Jenkinsfile-STG-PRD') || file.equalsIgnoreCase('packages/shell/Jenkinsfile-Hotfix') || file.equalsIgnoreCase('bin/mobius.groovy') || file.toLowerCase().contains('docs/'.toLowerCase()) || file.toLowerCase().contains('packages/shell/helm/'.toLowerCase())
        
        // Properties file was changed
        propertyFileChanged = file ==~ /^.*\.(properties)$/
        
        // If a file is found that isn't a deploy file or a property file we can assume this is not a config only change.
        if (!deployFileChanged && !propertyFileChanged) {
            println "File $file was found in this builds commit history and is not a property or deploy file.  This will not be treated as a 'Config Only Change'."
            return false
        }
    }

    println "isImageBuildRequired -> ${isImageBuildRequired}"
    // If build triggered manually to make a complete Image build, config changes will be ignored.
    if(isImageBuildRequired == true){
        println "This is a manually triggered job to make a complete Image build."
        return false
    }

    println "All files found in this builds commit history are property files or deploy files.  This will treated as a 'Config Only Change'."
    return true
}


def getAssociatedPr(packageName) {
  def getLastPrShaScript = 'cd ../../ && git log -1 --pretty=format:"%H"  --invert-grep --grep=".*\\[ci skip\\].*"  --grep="Merge.pull.request" ' + packageName
  
  println "git command to get last merged PR for the package ($packageName) :- $getLastPrShaScript"

  def lastPRSha = sh(script: "$getLastPrShaScript", returnStdout: true)
  def lastPRCommited = lastPRSha.trim()

  def prData=sh(script: """
  curl -u ${HCP_WEP_ADMIN}:${HCP_WEP_ADMIN_PW} -s --location --request POST 'https://github.optum.com/api/graphql' \
  --header 'Content-Type: application/json' \
  --data '{"query":"query associatedPRs(\$sha: String){\\n  repository(name: \\"Engineering-Platform\\", owner: \\"optum-engineering-experience\\") {\\n    commit: object(expression: \$sha) {\\n      ... on Commit {\\n        associatedPullRequests(first:5){\\n          edges{\\n            node{\\n              title\\n              number\\n              body\\n            }\\n          }\\n        }\\n      }\\n    }\\n  }\\n}","variables":{"sha":"$lastPRCommited"}}'
  """, returnStdout: true)

  def prDataJson = readJSON text: prData
  println "prDataJson: $prDataJson"
  return prDataJson
}

def determineDockerImage(dockerImage) {
    if (dockerImage == "") {
        currentDc = command("kubectl get deployment build-platform-v1-dc --output json", true)
        dcJson = readJSON text: currentDc
        dockerImage = dcJson.spec.template.spec.containers[0].image
    }
    return dockerImage
}


def isRollbackNeeded(){ 
    def rollback = input(
        id: 'rollback', message: 'Rollback Needed?',
        parameters: [
                    booleanParam(name: 'IsRollbackNeeded', defaultValue: false),
                        ])
return rollback
}

def enterRollbackImage(){

    def dockerImage = input(
        id: 'dockerImage', message: 'Enter the image MAJOR_MINOR_PATCH-BUILD_VERSION ',
        parameters: [
                    string(defaultValue: '', name: 'UseDockerImage'),
                        ])

    return dockerImage
}

def validateRollbackOption(useDockerImage){

                    if(useDockerImage == ""){
                      throw new Exception("Docker image version cannot be blank");
                    }
}

def updateGithubStatus(githubToken, commit, context){
sh """ curl -X POST \
-H "Accept: application/vnd.github.v3+json" \
-H "Authorization: token $githubToken" \
https://github.optum.com/api/v3/repos/optum-engineering-experience/engineering-platform/statuses/$commit \
-d  '{"state": "failure", "context": "$context"}' """

}

def setK8Config(crtFile, crtFileName, contextUser, contextName, token, namespace, user, server){

sh """  echo "$crtFile"  > $crtFileName """                    
command("kubectl config set-cluster $contextUser --server=$server --certificate-authority=$crtFileName")
command("kubectl config set-credentials $user --token=$token")
command("kubectl config set-context $contextName --cluster=$contextUser --namespace=$namespace --user=$user")
command("kubectl config use-context $contextName")
command("kubectl get pods")

}


def helmPackage(){
    command("helm package ./packages/shell/helm")
}


def helmUpgrade(valuesYAML, dockerImage, pingClientSecret, jwtSigningPrivateKey, prmToken, ctcOrElr){
    command("helm upgrade --install hcp-console hcp-console-0.0.1.tgz -f $valuesYAML --set namespace=$ctcOrElr --set dockerImage=$dockerImage --set jwtSigningPrivateKey=$jwtSigningPrivateKey --set pingSecretClient=$pingClientSecret --set feedbackToken=$FEEDBACK_GITHUB_TOKEN --set artifactorySecret=$ARTIFACTORY_SECRET --set askCredential=$ASK_CREDENTIAL --set prmToken=$prmToken ")
}

def removeOldPods(){
    command("kubectl delete pods -l app=build-platform-v1")
    command("kubectl rollout status deployment build-platform-v1-dc")
}


return this