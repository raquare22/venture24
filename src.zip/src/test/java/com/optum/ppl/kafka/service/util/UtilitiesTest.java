package com.optum.ppl.kafka.service.util;

import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class UtilitiesTest {
    @Test
    public void testConstructorCoverage() {
        new Utilities();
    }
    @Test
    public void validateProviderEmail_shouldReturnFalse_whenEmailIsNull() {
        assertFalse(Utilities.validateProviderEmail(null));
    }

    @Test
    public void validateProviderEmail_shouldReturnFalse_whenEmailIsEmpty() {
        assertFalse(Utilities.validateProviderEmail(""));
    }

    @Test
    public void validateProviderEmail_shouldReturnTrue_forValidEmails() {
        assertTrue(Utilities.validateProviderEmail("test@example.com"));
        assertTrue(Utilities.validateProviderEmail("user.name+tag@sub.domain.com"));
        assertTrue(Utilities.validateProviderEmail("user_name@domain.co"));
        assertTrue(Utilities.validateProviderEmail("user-name@domain.org"));
        assertTrue(Utilities.validateProviderEmail("user123@domain123.com"));
    }

    @Test
    public void validateProviderEmail_shouldReturnFalse_forInvalidEmails() {
        assertFalse(Utilities.validateProviderEmail("plainaddress"));
        assertFalse(Utilities.validateProviderEmail("@missingusername.com"));
        assertFalse(Utilities.validateProviderEmail("username@.com"));
        assertFalse(Utilities.validateProviderEmail("username@domain..com"));
        assertFalse(Utilities.validateProviderEmail("username@domain,com"));
        assertFalse(Utilities.validateProviderEmail("username@domain@domain.com"));
        assertFalse(Utilities.validateProviderEmail(".username@domain.com"));
        assertFalse(Utilities.validateProviderEmail("username.@domain.com"));
        assertFalse(Utilities.validateProviderEmail("user name@domain.com"));
        assertFalse(Utilities.validateProviderEmail("test@ example.com"));
        assertFalse(Utilities.validateProviderEmail("test@@example.com"));
        assertFalse(Utilities.validateProviderEmail("test@example.com."));
    }
}