package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class USPClaimsConsumerServiceTest {

    @InjectMocks
    private USPClaimsConsumerService uspClaimsConsumerService;

    @Mock
    private ConsumerRecord<String, String> consumerRecord;

    private static final int TEST_SPACE_ID = 10902;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(
                uspClaimsConsumerService,
                "uspclaims_spaceId",
                TEST_SPACE_ID
        );
    }

    @Test
    public void testConsume_DelegatesToProcessMessage() {
        USPClaimsConsumerService spyService = Mockito.spy(uspClaimsConsumerService);

        doNothing()
                .when(spyService)
                .processMessage(consumerRecord, TEST_SPACE_ID);

        spyService.consume(consumerRecord);

        verify(spyService)
                .processMessage(consumerRecord, TEST_SPACE_ID);
    }

    @Test
    public void testConsume_ValidPayload_ProcessesWithConfiguredSpaceId() {

        ConsumerRecord<String, String> realRecord =
                new ConsumerRecord<>(
                        "uspclaims-topic",
                        0,
                        0L,
                        "test-key",
                        "{\"globalDocumentId\":\"g-123\","
                                + "\"documentClass\":\"u_clm_ltr\","
                                + "\"memberId\":\"m1\"}"
                );

        USPClaimsConsumerService spyService = Mockito.spy(uspClaimsConsumerService);

        doNothing()
                .when(spyService)
                .processMessage(realRecord, TEST_SPACE_ID);

        spyService.consume(realRecord);

        verify(spyService)
                .processMessage(realRecord, TEST_SPACE_ID);
    }
}