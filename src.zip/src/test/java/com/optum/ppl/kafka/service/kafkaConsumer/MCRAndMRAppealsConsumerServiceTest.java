package com.optum.ppl.kafka.service.kafkaConsumer;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.lang.reflect.Field;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class MCRAndMRAppealsConsumerServiceTest {

    @Spy
    @InjectMocks
    private MCRAndMRAppealsConsumerService consumerService;

    @Before
    public void setup() throws Exception {

        setField("mcr_spaceId", 100);
        setField("mrAppeals_SpaceId", 200);
        setField("enabled_mcr", true);
        setField("enabled_mrAppeals", true);

       
    }

    @Test
    public void shouldProcessPHSMessage() {

        ConsumerRecord<String, String> record =
                new ConsumerRecord<>(
                        "topic",
                        0,
                        0L,
                        "key1",
                        "{ \"attributes\":[{\"physicalName\":\"u_create_App\",\"value\":\"PHS\"}] }");

        consumerService.consume(record);

        verify(consumerService, times(1))
                .processMessage(record, 100);
    }

    @Test
    public void shouldProcessMNRMessage() {

        ConsumerRecord<String, String> record =
                new ConsumerRecord<>(
                        "topic",
                        0,
                        0L,
                        "key2",
                        "{ \"attributes\":[{\"physicalName\":\"u_create_App\",\"value\":\"MNR\"}] }");

        consumerService.consume(record);

        verify(consumerService, times(1))
                .processMessage(record, 200);
    }

    @Test
    public void shouldProcessMNR2Message() {

        ConsumerRecord<String, String> record =
                new ConsumerRecord<>(
                        "topic",
                        0,
                        0L,
                        "key3",
                        "{ \"attributes\":[{\"physicalName\":\"u_create_App\",\"value\":\"MNR2.0\"}] }");

        consumerService.consume(record);

        verify(consumerService, times(1))
                .processMessage(record,200);
    }

    @Test
    public void shouldProcessATSMessage() {

        ConsumerRecord<String, String> record =
                new ConsumerRecord<>(
                        "topic",
                        0,
                        0L,
                        "key4",
                        "{ \"attributes\":[{\"physicalName\":\"u_create_App\",\"value\":\"ATS\"}] }");

        consumerService.consume(record);

        verify(consumerService, times(1))
                .processMessage(record,200);
    }

    @Test
    public void shouldIgnoreUnsupportedCreateApp() {

        ConsumerRecord<String, String> record =
                new ConsumerRecord<>(
                        "topic",
                        0,
                        0L,
                        "key5",
                        "{ \"attributes\":[{\"physicalName\":\"u_create_App\",\"value\":\"ABC\"}] }");

        consumerService.consume(record);

        verify(consumerService, times(0))
                .processMessage(record,100);
    }

    @Test
    public void shouldIgnoreNullMessage() {

        consumerService.consume(null);

        verify(consumerService, times(0))
                .processMessage(org.mockito.ArgumentMatchers.any(), anyInt());
    }

    @Test
    public void shouldIgnoreEmptyMessage() {

        ConsumerRecord<String, String> record =
                new ConsumerRecord<>(
                        "topic",
                        0,
                        0L,
                        "key6",
                        "");

        consumerService.consume(record);

        verify(consumerService, times(0))
                .processMessage(record,200);
    }

    @Test
    public void shouldNotProcessPHSWhenMcrDisabled() throws Exception {

        setField("enabled_mcr", false);

        ConsumerRecord<String, String> record =
                new ConsumerRecord<>(
                        "topic",
                        0,
                        0L,
                        "key7",
                        "{ \"attributes\":[{\"physicalName\":\"u_create_App\",\"value\":\"PHS\"}] }");

        consumerService.consume(record);

        verify(consumerService, times(0))
                .processMessage(record,100);
    }

    @Test
    public void shouldNotProcessMnrWhenMrAppealsDisabled() throws Exception {

        setField("enabled_mrAppeals", false);

        ConsumerRecord<String, String> record =
                new ConsumerRecord<>(
                        "topic",
                        0,
                        0L,
                        "key8",
                        "{ \"attributes\":[{\"physicalName\":\"u_create_App\",\"value\":\"MNR\"}] }");

        consumerService.consume(record);

        verify(consumerService, times(0))
                .processMessage(record, 200);
    }
    
    @Test
    public void shouldSetMcrSpaceId() throws Exception {
    	
    	

    	String messageValue =
    		    "{ \"attributes\": [" +
    		        "{\"physicalName\":\"u_create_App\",\"value\":\"PHS\"}" +
    		    "] }";

    		ConsumerRecord<String, String> record =
    		    new ConsumerRecord<>("topic", 0, 0L, "key1", messageValue);

        consumerService.consume(record);

       
        verify(consumerService).processMessage(record,100);
       
    }

    private void setField(String fieldName, Object value) throws Exception {

        Field field =
                MCRAndMRAppealsConsumerService.class
                        .getDeclaredField(fieldName);

        field.setAccessible(true);
        field.set(consumerService, value);
    }
}