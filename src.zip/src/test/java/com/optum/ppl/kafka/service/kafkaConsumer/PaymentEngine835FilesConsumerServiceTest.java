package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PaymentEngine835FilesConsumerServiceTest {

    @InjectMocks
    private PaymentEngine835FilesConsumerService paymentEngine835FilesConsumerService;

    @Mock
    private ConsumerRecord<String, String> consumerRecord;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    private static final int TEST_SPACE_ID = 7202;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(
                paymentEngine835FilesConsumerService,
                "paymentEngine835Files_spaceId",
                TEST_SPACE_ID
        );
    }

    @Test
    public void testConsume_DelegatesToProcessMessage() {
        PaymentEngine835FilesConsumerService spyService = Mockito.spy(paymentEngine835FilesConsumerService);
        doNothing().when(spyService).processMessage(consumerRecord, TEST_SPACE_ID);

        spyService.consume(consumerRecord);

        verify(spyService).processMessage(consumerRecord, TEST_SPACE_ID);
    }

    @Test
    public void testConsume_ValidPayload_InsertsDocumentWithConfiguredSpaceId() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "payment-engine-835-files-topic",
                0,
                0L,
                "test-key",
                "{\"globalDocumentId\":\"g-835\",\"documentClass\":\"U_MR_RPTS\",\"memberId\":\"m1\"}"
        );

        when(documentMetaDataService.insertDocumentWithSpaceId(any(DocumentMetaData.class), eq(TEST_SPACE_ID)))
                .thenReturn("doc-835");

        paymentEngine835FilesConsumerService.consume(record);

        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData savedDocument = captor.getValue();
        assertEquals(MetaDataStatus.NEW, savedDocument.getStatus());
        assertEquals("g-835", savedDocument.getDoc360DocumentId());
        assertEquals("U_MR_RPTS", savedDocument.getDoc360DocClass());
    }

    @Test
    public void testConsume_MissingOptionalFields_InsertsDocument() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "payment-engine-835-files-topic",
                0,
                0L,
                "test-key",
                "{\"memberId\":\"m1\"}"
        );

        paymentEngine835FilesConsumerService.consume(record);

        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData savedDocument = captor.getValue();
        assertNull(savedDocument.getDoc360DocumentId());
        assertNull(savedDocument.getDoc360DocClass());
    }

    @Test
    public void testConsume_NullMessageValue_ShouldReturnEarly() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "payment-engine-835-files-topic",
                0,
                0L,
                "test-key",
                null
        );

        paymentEngine835FilesConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_EmptyMessageValue_ShouldReturnEarly() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "payment-engine-835-files-topic",
                0,
                0L,
                "test-key",
                ""
        );

        paymentEngine835FilesConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_InvalidJson_ShouldCatchAndSkipInsert() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "payment-engine-835-files-topic",
                0,
                0L,
                "test-key",
                "{ invalid-json-format }"
        );

        paymentEngine835FilesConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }
}

