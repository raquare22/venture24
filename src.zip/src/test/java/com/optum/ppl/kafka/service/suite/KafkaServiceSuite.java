package com.optum.ppl.kafka.service.suite;

import com.optum.ppl.kafka.service.ConfigDataTest;
import com.optum.ppl.kafka.service.controller.RootControllerTest;
import com.optum.ppl.kafka.service.domain.DocumentMetaDataServiceImplTest;
import com.optum.ppl.kafka.service.kafkaConsumer.*;
import com.optum.ppl.kafka.service.template.java.render.CustomStringRendererTest;
import com.optum.ppl.kafka.service.util.DocumentUtilTest;
import com.optum.ppl.kafka.service.util.UtilitiesTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.optum.ppl.kafka.service.KafkaServiceApplicationTest;
import com.optum.ppl.kafka.service.template.ATSKafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.AlinkKafkaTemplateTest;
import com.optum.ppl.kafka.service.template.ConsumerEngineeringKafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.GPSKafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.KafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.MnRKafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.TrackItConsumerServiceTemplateTest;

import junit.framework.TestCase;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	
	KafkaServiceApplicationTest.class,
	AlinkKafkaTemplateTest.class,
	ATSKafkaDocumentTemplateTest.class,
	ConsumerEngineeringKafkaDocumentTemplateTest.class,
	GPSKafkaDocumentTemplateTest.class,
	KafkaDocumentTemplateTest.class,
	MnRKafkaDocumentTemplateTest.class,
	TrackItConsumerServiceTemplateTest.class,
    DocumentMetaDataServiceImplTest.class,
    ADTCNSConsumerServiceTest.class,
    AlinkConsumerServiceTest.class,
    ConsumerEngineeringServiceTest.class,
    ConsumerServiceATSTest.class,
    GPSConsumerServiceTest.class,
    MnRConsumerServiceTest.class,
    TrackItConsumerServiceTest.class,
    CustomStringRendererTest.class,
    ConsumerEngineeringKafkaDocumentTemplateTest.class,
    DocumentUtilTest.class,
    UtilitiesTest.class,
    ConfigDataTest.class,
    RootControllerTest.class,
    HomeAndCommunityConsumerServiceTest.class,
		MemberPaymentPRAConsumerServiceTest.class,
    ReimbursementReportsConsumerServiceTest.class,
    TennCareConsumerServiceTest.class,
    LeifConsumerServiceTest.class,
    NicePraConsumerServiceTest.class
    RootControllerTest.class,
    ReimbursementReportsConsumerServiceTest.class

})

public class KafkaServiceSuite  extends TestCase {}
