package com.optum.ppl.kafka.service.suite;

import com.optum.ppl.kafka.service.ConfigDataTest;
import com.optum.ppl.kafka.service.CustomKafkaConsumerConfigTest;
import com.optum.ppl.kafka.service.beans.ProviderDocumentMetaDataTest;
import com.optum.ppl.kafka.service.beans.ProviderDocumentTest;
import com.optum.ppl.kafka.service.controller.RootControllerTest;
import com.optum.ppl.kafka.service.domain.DocumentMetaDataServiceImplTest;
import com.optum.ppl.kafka.service.exception.ErrorCodeTest;
import com.optum.ppl.kafka.service.kafka.model.EncounterDetailsTest;
import com.optum.ppl.kafka.service.kafkaConsumer.*;
import com.optum.ppl.kafka.service.model.MultiPutResponseTest;
import com.optum.ppl.kafka.service.mongo.DocumentAttachmentMetaDataTest;
import com.optum.ppl.kafka.service.mongo.DocumentMetaDataTest;
import com.optum.ppl.kafka.service.mongo.ErrorMetaDataTest;
import com.optum.ppl.kafka.service.mongo.ErrorRevisionTest;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataTest;
import com.optum.ppl.kafka.service.mongo.processors.RevisionTest;
import com.optum.ppl.kafka.service.template.java.render.CustomStringRendererTest;
import com.optum.ppl.kafka.service.template.listener.ErrorListenerTest;
import com.optum.ppl.kafka.service.util.DocumentUtilTest;
import com.optum.ppl.kafka.service.util.UtilitiesTest;
import com.optum.ppl.service.workflow.constants.WorkflowTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.optum.ppl.kafka.service.KafkaServiceApplicationTest;
import com.optum.ppl.kafka.service.template.ATSKafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.AlinkKafkaTemplateTest;
import com.optum.ppl.kafka.service.template.ConsumerEngineeringKafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.GPSKafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.KafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.MnRKafkaDocumentTemplateTest;
import com.optum.ppl.kafka.service.template.TrackItConsumerServiceTemplateTest;

import junit.framework.TestCase;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	
	KafkaServiceApplicationTest.class,
	AlinkKafkaTemplateTest.class,
	ATSKafkaDocumentTemplateTest.class,
	ConsumerEngineeringKafkaDocumentTemplateTest.class,
	GPSKafkaDocumentTemplateTest.class,
	KafkaDocumentTemplateTest.class,
	MnRKafkaDocumentTemplateTest.class,
	TrackItConsumerServiceTemplateTest.class,
    DocumentMetaDataServiceImplTest.class,
    ADTCNSConsumerServiceTest.class,
    AlinkConsumerServiceTest.class,
    ConsumerEngineeringServiceTest.class,
    ConsumerServiceATSTest.class,
    GPSConsumerServiceTest.class,
    MnRConsumerServiceTest.class,
    TrackItConsumerServiceTest.class,
    CustomStringRendererTest.class,
    ConsumerEngineeringKafkaDocumentTemplateTest.class,
    DocumentUtilTest.class,
    UtilitiesTest.class,
    ConfigDataTest.class,
    MultiPutResponseTest.class,
        ErrorCodeTest.class,
        WorkflowTest.class,
        DocumentAttachmentMetaDataTest.class,
    RootControllerTest.class,
        ErrorMetaDataTest.class,
        DocumentMetaDataTest.class,
        ErrorRevisionTest.class,
        EncounterDetailsTest.class,
        ProviderDocumentTest.class,
        ProviderDocumentMetaDataTest.class,
        TennCareConsumerServiceTest.class,
        PaySummaryConsumerServiceTest.class,
        CustomKafkaConsumerConfigTest.class,
        ErrorListenerTest.class,
        RevisionTest.class,
        MetaDataTest.class,
	NYPCMHConsumerServiceTest.class,
    HomeAndCommunityConsumerServiceTest.class,
    MemberPaymentPRAConsumerServiceTest.class,
    ReimbursementReportsConsumerServiceTest.class,
    TennCareConsumerServiceTest.class,
    LeifConsumerServiceTest.class,
    MCRAndMRAppealsConsumerServiceTest.class,
    NicePraConsumerServiceTest.class,
    USPPRAConsumerServiceTest.class,
    CosmosPRAConsumerServiceTest.class,
    UNETPRAConsumerServiceTest.class,
    CSPPRAConsumerServiceTest.class,
    PriorAuthNextGenConsumerServiceTest.class,
    PaymentEngine835FilesConsumerServiceTest.class,
    PriorAuthOCMConsumerServiceTest.class,
        TnMatReportConsumerServiceTest.class,
    PriorAuthCCSManualConsumerServiceTest.class
})

public class KafkaServiceSuite  extends TestCase {}
