package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PaySummaryConsumerServiceTest {

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @InjectMocks
    private PaySummaryConsumerService paySummaryConsumerService;

    private final int TEST_SPACE_ID = 12345;

    @Before
    public void setUp() {
        // Inject the @Value annotation field manually using Spring's ReflectionTestUtils
        ReflectionTestUtils.setField(paySummaryConsumerService, "paySummary_spaceId", TEST_SPACE_ID);
    }

    @Test
    public void testConsume_SuccessWithAllFields() {
        PaySummaryConsumerService spyService = Mockito.spy(new PaySummaryConsumerService());

        // set required @Value field(s) if needed
        ReflectionTestUtils.setField(spyService, "paySummary_spaceId", TEST_SPACE_ID);

        ConsumerRecord<String, String> message =
                new ConsumerRecord<>("pay-summary-topic", 0, 0L, "k1",
                        "{\"globalDocumentId\":\"doc-999\",\"documentClass\":\"ODAR\"}");

        // FIX: for void method use doNothing().when(...)
        doNothing().when(spyService).processMessage(any(ConsumerRecord.class), anyInt());

        // Act
        spyService.consume(message);

        // Assert delegation
        verify(spyService, times(1)).processMessage(message, TEST_SPACE_ID);
    }

    @Test
    public void testConsume_SuccessWithMissingOptionalFields() {
        // Arrange
        String jsonValue = "{ \"amount\": 150.00 }"; // Missing globalDocId and docClass
        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-2", jsonValue);

        // Act
        paySummaryConsumerService.consume(record);

        // Assert
        ArgumentCaptor<DocumentMetaData> documentCaptor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(documentCaptor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData capturedDoc = documentCaptor.getValue();
        assertNull(capturedDoc.getDoc360DocumentId());
        assertNull(capturedDoc.getDoc360DocClass());
    }

    @Test
    public void testConsume_NullMessageValue_ShouldReturnEarly() {
        // Arrange
        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-3", null);

        // Act
        paySummaryConsumerService.consume(record);

        // Assert
        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_EmptyMessageValue_ShouldReturnEarly() {
        // Arrange
        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-4", "");

        // Act
        paySummaryConsumerService.consume(record);

        // Assert
        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_InvalidJsonException_ShouldCatchAndLog() {
        // Arrange
        String invalidJson = "{ invalid-json-format }";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-5", invalidJson);

        // Act
        // This should not throw an exception out of the method because of the try-catch block
        paySummaryConsumerService.consume(record);

        // Assert
        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }
}
