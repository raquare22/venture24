package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PriorAuthCCSManualConsumerServiceTest {

	@InjectMocks
	private PriorAuthCCSManualConsumerService priorAuthCCSManualConsumerService;

	@Mock
	private ConsumerRecord<String, String> consumerRecord;

	@Mock
	private DocumentMetaDataService documentMetaDataService;

	private static final int TEST_SPACE_ID = 8938;

	@Before
	public void setUp() {
		ReflectionTestUtils.setField(priorAuthCCSManualConsumerService, "priorauthccsmanual_spaceId", TEST_SPACE_ID);
	}

	@Test
	public void testConsume_DelegatesToProcessMessage() {

		PriorAuthCCSManualConsumerService spyService = Mockito.spy(priorAuthCCSManualConsumerService);

		doNothing().when(spyService).processMessage(consumerRecord, TEST_SPACE_ID);

		spyService.consume(consumerRecord);

		verify(spyService).processMessage(consumerRecord, TEST_SPACE_ID);
	}

	@Test
	public void testConsume_ValidPayload_InsertsDocumentWithConfiguredSpaceId() {

		ConsumerRecord<String, String> realRecord = new ConsumerRecord<>("priorauthccsmanual-topic", 0, 0L, "test-key",
				"{\"globalDocumentId\":\"g-123\"," + "\"documentClass\":\"u_ccs_compliance\","
						+ "\"memberId\":\"m1\"}");

		when(documentMetaDataService.insertDocumentWithSpaceId(any(DocumentMetaData.class), eq(TEST_SPACE_ID)))
				.thenReturn("doc-1");

		priorAuthCCSManualConsumerService.consume(realRecord);

		ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);

		verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

		DocumentMetaData savedDocument = captor.getValue();

		assertEquals(MetaDataStatus.NEW, savedDocument.getStatus());
		assertEquals("g-123", savedDocument.getDoc360DocumentId());
		assertEquals("u_ccs_compliance", savedDocument.getDoc360DocClass());
	}
}