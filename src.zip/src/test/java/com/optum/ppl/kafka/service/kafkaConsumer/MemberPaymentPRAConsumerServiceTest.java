package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.*;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MemberPaymentPRAConsumerServiceTest {

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private ConsumerRecord<String, String> consumerRecord;

    @InjectMocks
    private MemberPaymentPRAConsumerService memberPaymentPRAConsumerService;

    private final int TEST_SPACE_ID = 7200;

    @Before
    public void setUp() {
        // Inject the @Value annotation field manually using Spring's ReflectionTestUtils
        ReflectionTestUtils.setField(memberPaymentPRAConsumerService, "memberPaymentPRA_spaceId", TEST_SPACE_ID);
    }

    @Test
    public void testGetSpaceId_ReturnsConfiguredValue() {
        assertEquals(TEST_SPACE_ID, memberPaymentPRAConsumerService.getSpaceId());
    }

    @Test
    public void testConsume_ValidPayload_InsertsDocumentWithConfiguredSpaceId() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "memberPaymenmtPRA-topic", 0, 0L, "test-key",
                "{\"globalDocumentId\":\"g-123\",\"documentClass\":\"U_MR_RPTS\",\"memberId\":\"m1\"}"
        );

        when(documentMetaDataService.insertDocumentWithSpaceId(any(DocumentMetaData.class), eq(TEST_SPACE_ID)))
                .thenReturn("doc-1");

        memberPaymentPRAConsumerService.consume(record);

        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData savedDocument = captor.getValue();
        assertEquals(MetaDataStatus.NEW, savedDocument.getStatus());
        assertEquals("g-123", savedDocument.getDoc360DocumentId());
        assertEquals("U_MR_RPTS", savedDocument.getDoc360DocClass());
    }

    @Test
    public void testConsume_MissingOptionalFields_InsertsDocument() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "memberPaymenmtPRA-topic", 0, 0L, "test-key", "{\"memberId\":\"m1\"}"
        );

        memberPaymentPRAConsumerService.consume(record);

        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData savedDocument = captor.getValue();
        assertNull(savedDocument.getDoc360DocumentId());
        assertNull(savedDocument.getDoc360DocClass());
    }

    @Test
    public void testConsume_NullMessageValue_ShouldReturnEarly() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("memberPaymenmtPRA-topic", 0, 0L, "test-key", null);

        memberPaymentPRAConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_EmptyMessageValue_ShouldReturnEarly() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("memberPaymenmtPRA-topic", 0, 0L, "test-key", "");

        memberPaymentPRAConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_InvalidJson_ShouldCatchAndSkipInsert() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "memberPaymenmtPRA-topic", 0, 0L, "test-key", "{ invalid-json-format }"
        );

        memberPaymentPRAConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }
}
