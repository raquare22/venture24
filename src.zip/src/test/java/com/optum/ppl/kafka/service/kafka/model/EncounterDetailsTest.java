package com.optum.ppl.kafka.service.kafka.model;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;

public class EncounterDetailsTest {

    @Test
    public void testAllSimpleGettersSettersAndToString() {
        EncounterDetails details = new EncounterDetails();

        details.setAdmitDate("2026-07-01");
        details.setDischargeDate("2026-07-02");
        details.setEmergencyDate("2026-07-03");
        details.setIsAdmitAcknowledged("Y");
        details.setIsDischargeAcknowledged("N");
        details.setIsEmergencyAcknowledged("Y");

        List<String> complaints = Arrays.asList("C1", "C2");
        details.setChiefComplaintList(complaints);

        List<String> disposition = new ArrayList<>(Arrays.asList("HOME", "OBS"));
        details.setDischargeDisposition(disposition);

        assertEquals("2026-07-01", details.getAdmitDate());
        assertEquals("2026-07-02", details.getDischargeDate());
        assertEquals("2026-07-03", details.getEmergencyDate());
        assertEquals("Y", details.getIsAdmitAcknowledged());
        assertEquals("N", details.getIsDischargeAcknowledged());
        assertEquals("Y", details.getIsEmergencyAcknowledged());
        assertEquals(complaints, details.getChiefComplaintList());
        assertEquals(Arrays.asList("HOME", "OBS"), details.getDischargeDisposition());

        String asString = details.toString();
        assertNotNull(asString);
        assertTrue(asString.contains("admitDate=2026-07-01"));
        assertTrue(asString.contains("dischargeDate=2026-07-02"));
        assertTrue(asString.contains("emergencyDate=2026-07-03"));
        assertTrue(asString.contains("isAdmitAcknowledged=Y"));
        assertTrue(asString.contains("isDischargeAcknowledged=N"));
        assertTrue(asString.contains("isEmergencyAcknowledged=Y"));
        assertTrue(asString.contains("dischargeDisposition=[HOME, OBS]"));
        assertTrue(asString.contains("chiefComplaintList=[C1, C2]"));
    }

    @Test
    public void testSetDischargeDisposition_nullInput() {
        EncounterDetails details = new EncounterDetails();

        details.setDischargeDisposition(null);

        assertNull(details.getDischargeDisposition());
    }

    @Test
    public void testSetDischargeDisposition_emptyInput() {
        EncounterDetails details = new EncounterDetails();

        List<String> empty = new ArrayList<>();
        details.setDischargeDisposition(empty);

        assertNotNull(details.getDischargeDisposition());
        assertTrue(details.getDischargeDisposition().isEmpty());
    }

    @Test
    public void testSetDischargeDisposition_removesBlankNullAndQuotedBlank() {
        EncounterDetails details = new EncounterDetails();

        List<String> values = new ArrayList<>(Arrays.asList("HOME", "", null, "\"\"", "OBS"));
        details.setDischargeDisposition(values);

        assertEquals(Arrays.asList("HOME", "OBS"), details.getDischargeDisposition());
    }

    @Test
    public void testSetChiefComplaintList_emptyList() {
        EncounterDetails details = new EncounterDetails();

        details.setChiefComplaintList(Collections.emptyList());

        assertNotNull(details.getChiefComplaintList());
        assertTrue(details.getChiefComplaintList().isEmpty());
    }
}