package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.*;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class NYPCMHConsumerServiceTest {
    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @InjectMocks
    private NYPCMHConsumerService nypcmhConsumerService;

    private final int TEST_SPACE_ID = 7000;

    @Before
    public void setUp() {
        // Inject the @Value annotation field manually using Spring's ReflectionTestUtils
        ReflectionTestUtils.setField(nypcmhConsumerService, "nypcmh_spaceId", TEST_SPACE_ID);
    }

    @Test
    public void testConsume_SuccessWithAllFields() {
        // Arrange
        String jsonValue = "{ \"globalDocumentId\": \"doc-999\", \"documentClass\": \"U_PROV_PAY_DOCS\", \"amount\": 150.00 }";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-1", jsonValue);

        // Act
        nypcmhConsumerService.consume(record);

        // Assert
        ArgumentCaptor<DocumentMetaData> documentCaptor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(documentCaptor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData capturedDoc = documentCaptor.getValue();
        assertNotNull(capturedDoc);
        assertEquals(MetaDataStatus.NEW, capturedDoc.getStatus());
        assertEquals("doc-999", capturedDoc.getDoc360DocumentId());
        assertEquals("U_PROV_PAY_DOCS", capturedDoc.getDoc360DocClass());
        assertNotNull(capturedDoc.getMetadata());
    }

    @Test
    public void testConsume_SuccessWithMissingOptionalFields() {
        // Arrange
        String jsonValue = "{ \"amount\": 150.00 }"; // Missing globalDocId and docClass
        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-2", jsonValue);

        // Act
        nypcmhConsumerService.consume(record);

        // Assert
        ArgumentCaptor<DocumentMetaData> documentCaptor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(documentCaptor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData capturedDoc = documentCaptor.getValue();
        assertNull(capturedDoc.getDoc360DocumentId());
        assertNull(capturedDoc.getDoc360DocClass());
    }

    @Test
    public void testConsume_NullMessageValue_ShouldReturnEarly() {
        // Arrange
        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-3", null);

        // Act
        nypcmhConsumerService.consume(record);

        // Assert
        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_EmptyMessageValue_ShouldReturnEarly() {
        // Arrange
        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-4", "");

        // Act
        nypcmhConsumerService.consume(record);

        // Assert
        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_InvalidJsonException_ShouldCatchAndLog() {
        // Arrange
        String invalidJson = "{ invalid-json-format }";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-5", invalidJson);

        // Act
        // This should not throw an exception out of the method because of the try-catch block
        nypcmhConsumerService.consume(record);

        // Assert
        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }
}
