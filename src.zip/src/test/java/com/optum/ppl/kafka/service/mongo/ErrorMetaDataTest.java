package com.optum.ppl.kafka.service.mongo;

import com.optum.ppl.kafka.service.exception.ErrorCode;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import org.bson.Document;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class ErrorMetaDataTest {

    @Test
    public void testGettersSettersAndBehavior() {
        ErrorMetaData metaData = new ErrorMetaData();

        metaData.setIdentifier("identifier-1");
        metaData.setTargetId("target-1");
        metaData.setTargetType("DOC");
        metaData.setSpaceId(10503);
        metaData.setQueue("queue1");
        metaData.setConnectionType("KAFKA");
        metaData.setSequenceNumber(10L);
        metaData.setCorrelationId("corr-1");
        metaData.setMessageId("msg-1");
        metaData.setReplyTo("replyQ");
        metaData.setReplyToIndex("1");
        metaData.setDeliveryCount(2L);
        metaData.setRetryCount(3);
        metaData.setErrorMessage("manual error");

        Document bson = new Document("k", "v");
        metaData.setMetadata(bson);

        ErrorCode errorCode = ErrorCode.PROCESS_METADATA_ERROR;
        metaData.setErrorCode(errorCode);

        assertEquals("identifier-1", metaData.getIdentifier());
        assertEquals("target-1", metaData.getTargetId());
        assertEquals("DOC", metaData.getTargetType());
        assertEquals(Integer.valueOf(10503), metaData.getSpaceId());
        assertEquals("queue1", metaData.getQueue());
        assertEquals("KAFKA", metaData.getConnectionType());
        assertEquals(Long.valueOf(10L), metaData.getSequenceNumber());
        assertEquals("corr-1", metaData.getCorrelationId());
        assertEquals("msg-1", metaData.getMessageId());
        assertEquals("replyQ", metaData.getReplyTo());
        assertEquals("1", metaData.getReplyToIndex());
        assertEquals(Long.valueOf(2L), metaData.getDeliveryCount());
        assertEquals(Integer.valueOf(3), metaData.getRetryCount());
        assertEquals("manual error", metaData.getErrorMessage());
        assertEquals(bson, metaData.getMetadata());
        assertEquals(errorCode, metaData.getErrorCode());
    }

    @Test
    public void testSetErrorCodeAndErrorMessageAndDefaultErrorStatus() {
        ErrorMetaData metaData = new ErrorMetaData();

        ErrorCode errorCode = ErrorCode.PROCESS_METADATA_ERROR;
        metaData.setErrorCodeAndErrorMessageAndDefaultErrorStatus(errorCode);

        assertEquals(errorCode, metaData.getErrorCode());
        assertEquals(errorCode.getDescription(), metaData.getErrorMessage());
        assertNotNull(metaData.getStatus());
    }

    @Test
    public void testSetCompleteStatus() {
        ErrorMetaData metaData = new ErrorMetaData();

        MetaDataStatus status = metaData.setCompleteStatus();

        assertEquals(MetaDataStatus.COMPLETE, status);
        assertEquals(MetaDataStatus.COMPLETE, metaData.getStatus());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetRevisions() {
        ErrorMetaData metaData = new ErrorMetaData();

        List<ErrorRevision> revisions = new ArrayList<>();
        ReflectionTestUtils.setField(metaData, "revisions", revisions);

        List<ErrorRevision> result = metaData.getRevisions();

        assertSame(revisions, result);
    }

    @Test
    public void testToString() {
        ErrorMetaData metaData = new ErrorMetaData();
        metaData.setIdentifier("id1");
        metaData.setTargetId("target1");
        metaData.setQueue("queue1");
        metaData.setConnectionType("KAFKA");
        metaData.setSequenceNumber(5L);
        metaData.setCorrelationId("corr1");
        metaData.setMessageId("msg1");
        metaData.setReplyTo("reply1");
        metaData.setDeliveryCount(1L);
        metaData.setRetryCount(2);
        metaData.setErrorMessage("err");
        ErrorCode errorCode = ErrorCode.PROCESS_METADATA_ERROR;
        metaData.setMetadata(new Document("field", "value"));

        String result = metaData.toString();

        assertNotNull(result);
        assertTrue(result.contains("identifier=id1"));
        assertTrue(result.contains("targetId=target1"));
        assertTrue(result.contains("queue=queue1"));
        assertTrue(result.contains("connectionType=KAFKA"));
        assertTrue(result.contains("sequenceNumber=5"));
        assertTrue(result.contains("correlationId=corr1"));
        assertTrue(result.contains("messageId=msg1"));
        assertTrue(result.contains("replyTo=reply1"));
        assertTrue(result.contains("deliveryCount=1"));
        assertTrue(result.contains("retryCount=2"));
        assertTrue(result.contains("errorMessage=err"));
        assertTrue(result.contains("metadata: {"));
    }
}