package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
public class COSMOSDoc1ConsumerServiceTest {

    @InjectMocks
    private COSMOSDoc1ConsumerService cosmosDoc1ConsumerService;

    @Mock
    private ConsumerRecord<String, String> consumerRecord;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    private static final int TEST_SPACE_ID = 10102;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(cosmosDoc1ConsumerService, "cosmosdoc1_spaceId", TEST_SPACE_ID);
    }



    @Test
    public void testConsume_DelegatesToProcessMessage() {
        COSMOSDoc1ConsumerService spyService = Mockito.spy(cosmosDoc1ConsumerService);
        doNothing().when(spyService).processMessage(consumerRecord,TEST_SPACE_ID);

        spyService.consume(consumerRecord);

        verify(spyService).processMessage(consumerRecord,TEST_SPACE_ID);
    }

    @Test
    public void testConsume_ValidPayload_InsertsDocumentWithConfiguredSpaceId() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "cosmosdoc1-topic", 0, 0L, "test-key",
                "{\"globalDocumentId\":\"g-123\",\"documentClass\":\"U_COSMOS_LTR_DOC\",\"memberId\":\"m1\"}"
        );

        when(documentMetaDataService.insertDocumentWithSpaceId(any(DocumentMetaData.class), eq(TEST_SPACE_ID)))
                .thenReturn("doc-1");

        cosmosDoc1ConsumerService.consume(record);

        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData savedDocument = captor.getValue();
        assertEquals(MetaDataStatus.NEW, savedDocument.getStatus());
        assertEquals("g-123", savedDocument.getDoc360DocumentId());
        assertEquals("U_COSMOS_LTR_DOC", savedDocument.getDoc360DocClass());
    }

    @Test
    public void testConsume_MissingOptionalFields_InsertsDocument() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "cosmosdoc1-topic", 0, 0L, "test-key", "{\"memberId\":\"m1\"}"
        );

        cosmosDoc1ConsumerService.consume(record);

        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData savedDocument = captor.getValue();
        assertNull(savedDocument.getDoc360DocumentId());
        assertNull(savedDocument.getDoc360DocClass());
    }

    @Test
    public void testConsume_NullMessageValue_ShouldReturnEarly() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("cosmosdoc1-topic", 0, 0L, "test-key", null);

        cosmosDoc1ConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_EmptyMessageValue_ShouldReturnEarly() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("cosmosdoc1-topic", 0, 0L, "test-key", "");

        cosmosDoc1ConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_InvalidJson_ShouldCatchAndSkipInsert() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "cosmosdoc1-topic", 0, 0L, "test-key", "{ invalid-json-format }"
        );

        cosmosDoc1ConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }
}
