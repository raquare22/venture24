package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.test.util.ReflectionTestUtils;

import java.lang.reflect.Method;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UNETPRAConsumerServiceTest {

    @InjectMocks
    private UNETPRAConsumerService unetpraConsumerService;

    @Mock
    private ConsumerRecord<String, String> consumerRecord;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    private final int TEST_SPACE_ID = 10074;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(unetpraConsumerService, "unetpra_spaceId", TEST_SPACE_ID);
    }

    @Test
    public void testConsumeEpsProvEob_DelegatesToProcessMessage() {
        UNETPRAConsumerService spyService = Mockito.spy(unetpraConsumerService);
        doNothing().when(spyService).processMessage(consumerRecord, TEST_SPACE_ID);

        spyService.consumeEpsProvEob(consumerRecord);

        verify(spyService).processMessage(consumerRecord, TEST_SPACE_ID);
    }

    @Test
    public void testConsume_ValidPayload_InsertsDocumentWithConfiguredSpaceId() {
        ConsumerRecord<String, String> realRecord = new ConsumerRecord<>(
                "unetpra-topic", 0, 0L, "test-key",
                "{\"globalDocumentId\":\"g-123\",\"documentClass\":\"UNETPRA\",\"memberId\":\"m1\"}"
        );

        when(documentMetaDataService.insertDocumentWithSpaceId(any(DocumentMetaData.class), eq(TEST_SPACE_ID)))
                .thenReturn("doc-1");

        unetpraConsumerService.consumeEpsProvEob(realRecord);

        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData savedDocument = captor.getValue();
        assertEquals(MetaDataStatus.NEW, savedDocument.getStatus());
        assertEquals("g-123", savedDocument.getDoc360DocumentId());
        assertEquals("UNETPRA", savedDocument.getDoc360DocClass());
    }

    @Test
    public void testConsume_EpsProvEobPayload_InsertsDocumentWithConfiguredSpaceId() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "unetpra-eps-prov-eob-topic", 0, 0L, "test-key",
                "{\"globalDocumentId\":\"g-124\",\"documentClass\":\"u_eps_prov_eob\",\"memberId\":\"m2\"}"
        );

        when(documentMetaDataService.insertDocumentWithSpaceId(any(DocumentMetaData.class), eq(TEST_SPACE_ID)))
                .thenReturn("doc-2");

        unetpraConsumerService.consumeEpsProvEob(record);

        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData savedDocument = captor.getValue();
        assertEquals("g-124", savedDocument.getDoc360DocumentId());
        assertEquals("u_eps_prov_eob", savedDocument.getDoc360DocClass());
    }

    @Test
    public void testConsume_UnetGflxEobPayload_InsertsDocumentWithConfiguredSpaceId() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "unetpra-gflx-eob-topic", 0, 0L, "test-key",
                "{\"globalDocumentId\":\"g-125\",\"documentClass\":\"u_unet_gflx_eob\",\"memberId\":\"m3\"}"
        );

        when(documentMetaDataService.insertDocumentWithSpaceId(any(DocumentMetaData.class), eq(TEST_SPACE_ID)))
                .thenReturn("doc-3");

        unetpraConsumerService.consumeUnetGflxEob(record);

        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData savedDocument = captor.getValue();
        assertEquals("g-125", savedDocument.getDoc360DocumentId());
        assertEquals("u_unet_gflx_eob", savedDocument.getDoc360DocClass());
    }

    @Test
    public void testConsume_SurestPraPayload_InsertsDocumentWithConfiguredSpaceId() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "unetpra-surest-pra-topic", 0, 0L, "test-key",
                "{\"globalDocumentId\":\"g-126\",\"documentClass\":\"u_surest_pra\",\"memberId\":\"m4\"}"
        );

        when(documentMetaDataService.insertDocumentWithSpaceId(any(DocumentMetaData.class), eq(TEST_SPACE_ID)))
                .thenReturn("doc-4");

        unetpraConsumerService.consumeSurestPra(record);

        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData savedDocument = captor.getValue();
        assertEquals("g-126", savedDocument.getDoc360DocumentId());
        assertEquals("u_surest_pra", savedDocument.getDoc360DocClass());
    }

    @Test
    public void testConsume_NullPayload_DoesNotInsertDocument() {
        ConsumerRecord<String, String> nullRecord = new ConsumerRecord<>(
                "unetpra-topic", 0, 0L, "test-key", null
        );

        unetpraConsumerService.consumeEpsProvEob(nullRecord);

        verify(documentMetaDataService, Mockito.never())
                .insertDocumentWithSpaceId(any(DocumentMetaData.class), eq(TEST_SPACE_ID));
    }

    @Test
    public void testConsume_EmptyPayload_DoesNotInsertDocument() {
        ConsumerRecord<String, String> emptyRecord = new ConsumerRecord<>(
                "unetpra-topic", 0, 0L, "test-key", ""
        );

        unetpraConsumerService.consumeEpsProvEob(emptyRecord);

        verify(documentMetaDataService, Mockito.never())
                .insertDocumentWithSpaceId(any(DocumentMetaData.class), eq(TEST_SPACE_ID));
    }

    @Test
    public void testKafkaListeners_SubscribeToOneTopicEach() throws NoSuchMethodException {
        assertListener("consumeEpsProvEob", "unetpraEpsProvEobConsumer",
                "${spring.kafka.topic.unetpra.u_eps_prov_eob}");
        assertListener("consumeUnetGflxEob", "unetpraUnetGflxEobConsumer",
                "${spring.kafka.topic.unetpra.u_unet_gflx_eob}");
        assertListener("consumeSurestPra", "unetpraSurestPraConsumer",
                "${spring.kafka.topic.unetpra.u_surest_pra}");
    }

    private void assertListener(String methodName, String listenerId, String topic) throws NoSuchMethodException {
        Method method = UNETPRAConsumerService.class.getMethod(methodName, ConsumerRecord.class);
        KafkaListener listener = method.getAnnotation(KafkaListener.class);

        assertEquals(listenerId, listener.id());
        assertEquals(false, listener.idIsGroup());
        assertEquals("secureKafkaListenerContainerFactory", listener.containerFactory());
        assertEquals(1, listener.topics().length);
        assertEquals(topic, listener.topics()[0]);
    }
}
