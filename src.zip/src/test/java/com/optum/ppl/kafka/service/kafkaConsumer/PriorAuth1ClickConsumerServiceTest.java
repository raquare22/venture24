package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PriorAuth1ClickConsumerServiceTest {

    @InjectMocks
    private PriorAuth1ClickConsumerService priorAuth1ClickConsumerService;

    @Mock
    private ConsumerRecord<String, String> consumerRecord;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    private final int TEST_SPACE_ID = 10056;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(priorAuth1ClickConsumerService, "priorauth1click_spaceId", TEST_SPACE_ID);
    }

    private ConsumerRecord<String, String> buildRecord(String payload) {
        return new ConsumerRecord<>("priorauth1click-topic", 0, 0L, "test-key", payload);
    }

    @Test
    public void testConsume_DelegatesToProcessMessageWithConfiguredSpaceId() {
        PriorAuth1ClickConsumerService spyService = Mockito.spy(priorAuth1ClickConsumerService);
        doNothing().when(spyService).processMessage(consumerRecord, TEST_SPACE_ID);

        spyService.consume(consumerRecord);

        verify(spyService).processMessage(consumerRecord, TEST_SPACE_ID);
    }

    @Test
    public void testConsume_ValidPayload_InsertsDocumentWithConfiguredSpaceId() {
        ConsumerRecord<String, String> record = buildRecord(
                "{\"globalDocumentId\":\"g-123\",\"documentClass\":\"u_clin_mr_medcr_apprv_ltr\","
                        + "\"notificationNumber\":\"N-001\",\"tin\":\"123456789\"}");

        when(documentMetaDataService.insertDocumentWithSpaceId(any(DocumentMetaData.class), eq(TEST_SPACE_ID)))
                .thenReturn("doc-1");

        priorAuth1ClickConsumerService.consume(record);

        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData savedDocument = captor.getValue();
        assertEquals(MetaDataStatus.NEW, savedDocument.getStatus());
        assertEquals("g-123", savedDocument.getDoc360DocumentId());
        assertEquals("u_clin_mr_medcr_apprv_ltr", savedDocument.getDoc360DocClass());
    }

    @Test
    public void testConsume_MissingOptionalFields_InsertsDocumentWithNullDoc360Fields() {
        priorAuth1ClickConsumerService.consume(buildRecord("{\"notificationNumber\":\"N-001\"}"));

        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(captor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData savedDocument = captor.getValue();
        assertNull(savedDocument.getDoc360DocumentId());
        assertNull(savedDocument.getDoc360DocClass());
    }

    @Test
    public void testConsume_NullMessageValue_ShouldReturnEarly() {
        priorAuth1ClickConsumerService.consume(buildRecord(null));

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_EmptyMessageValue_ShouldReturnEarly() {
        priorAuth1ClickConsumerService.consume(buildRecord(""));

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_InvalidJson_ShouldCatchAndSkipInsert() {
        priorAuth1ClickConsumerService.consume(buildRecord("{ invalid-json-format }"));

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }
}