package com.optum.ppl.kafka.service.exception;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class ErrorCodeTest {

    @Test
    public void allErrorCodes_shouldHaveDescription() {
        for (ErrorCode code : ErrorCode.values()) {
            assertNotNull(code.getDescription());
            assertTrue(code.getDescription().length() > 0);
        }
    }
}