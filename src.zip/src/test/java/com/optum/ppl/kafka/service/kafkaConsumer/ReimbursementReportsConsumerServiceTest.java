package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class ReimbursementReportsConsumerServiceTest {

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @InjectMocks
    private ReimbursementReportsConsumerService reimbursementReportsConsumerService;

    private final int TEST_SPACE_ID = 8910;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(reimbursementReportsConsumerService, "reimbursementReports_spaceId", TEST_SPACE_ID);
    }

    @Test
    public void testConsume_SuccessWithAllFields() {
        String jsonValue = "{ \"globalDocumentId\": \"doc-8910-001\", \"documentClass\": \"PRRPT\", \"tin\": \"123456789\" }";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-1", jsonValue);


        reimbursementReportsConsumerService.consume(record);


        ArgumentCaptor<DocumentMetaData> documentCaptor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(documentCaptor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData capturedDoc = documentCaptor.getValue();
        assertNotNull(capturedDoc);
        assertEquals(MetaDataStatus.NEW, capturedDoc.getStatus());
        assertEquals("doc-8910-001", capturedDoc.getDoc360DocumentId());
        assertEquals("PRRPT", capturedDoc.getDoc360DocClass());
        assertNotNull(capturedDoc.getMetadata());
        assertEquals("PRRPT", capturedDoc.getMetadata().getString("documentClass"));
    }

    @Test
    public void testConsume_SuccessWithMissingOptionalFields() {
        String jsonValue = "{ \"tin\": \"123456789\" }";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-2", jsonValue);


        reimbursementReportsConsumerService.consume(record);

        ArgumentCaptor<DocumentMetaData> documentCaptor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService).insertDocumentWithSpaceId(documentCaptor.capture(), eq(TEST_SPACE_ID));

        DocumentMetaData capturedDoc = documentCaptor.getValue();
        assertNull(capturedDoc.getDoc360DocumentId());
        assertNull(capturedDoc.getDoc360DocClass());
    }

    @Test
    public void testConsume_NullMessageValue_ShouldReturnEarly() {

        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-3", null);


        reimbursementReportsConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_EmptyMessageValue_ShouldReturnEarly() {

        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-4", "");


        reimbursementReportsConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }

    @Test
    public void testConsume_InvalidJson_ShouldCatchAndNotStore() {

        String invalidJson = "{ invalid-json-format }";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("test-topic", 0, 0L, "key-5", invalidJson);

        reimbursementReportsConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), any(Integer.class));
    }
}