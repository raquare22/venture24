package com.optum.ppl.kafka.service.mongo.processors;

import org.junit.Before;
import org.junit.Test;
import java.util.Arrays;
import java.util.Date;
import static org.junit.Assert.*;

public class MetaDataTest {

    private MetaData metaData;

    @Before
    public void setUp() {
        metaData = new MetaData();
    }

    @Test
    public void testConstructor_initializesDates() {
        assertNotNull(metaData.getDateCreated());
        assertNotNull(metaData.getDateModified());
    }

    @Test
    public void testSetAndGetId() {
        metaData.setId("id-001");
        assertEquals("id-001", metaData.getId());
    }

    @Test
    public void testSetAndGetAppIdentifier() {
        metaData.setAppIdentifier("myApp");
        assertEquals("myApp", metaData.getAppIdentifier());
    }

    @Test
    public void testSetAndGetClientId() {
        metaData.setClientId(99);
        assertEquals(99, metaData.getClientId());
    }

    @Test
    public void testSetAndGetName() {
        metaData.setName("docName");
        assertEquals("docName", metaData.getName());
    }

    @Test
    public void testSetAndGetRevisions() {
        metaData.setRevisions(Arrays.asList("rev1", "rev2"));
        assertEquals(2, metaData.getRevisions().size());
    }

    @Test
    public void testSetAndGetTransactionId() {
        metaData.setTransactionId("trx-xyz");
        assertEquals("trx-xyz", metaData.getTransactionId());
    }

    @Test
    public void testSetStatus_enum() {
        metaData.setStatus(MetaDataStatus.ACTIVE);
        assertEquals(MetaDataStatus.ACTIVE, metaData.getStatus());
    }

    @Test
    public void testSetStatus_string_valid() {
        metaData.setStatus("DONE");
        assertEquals(MetaDataStatus.DONE, metaData.getStatus());
    }

    @Test
    public void testSetVersion_empty_defaultsToOne() throws NumberFormatException {
        metaData.setVersion("");
        assertEquals("1", metaData.getVersion());
    }

    @Test
    public void testSetVersion_valid() throws NumberFormatException {
        metaData.setVersion("5");
        assertEquals("5", metaData.getVersion());
    }

    @Test
    public void testIncrementVersion() throws NumberFormatException {
        metaData.setVersion("3");
        metaData.incrementVersion();
        assertEquals("4", metaData.getVersion());
    }

    @Test
    public void testSetAndGetDateCreated() {
        Date d = new Date();
        metaData.setDateCreated(d);
        assertEquals(d, metaData.getDateCreated());
    }

    @Test
    public void testSetAndGetDateModified() {
        Date d = new Date();
        metaData.setDateModified(d);
        assertEquals(d, metaData.getDateModified());
    }
}