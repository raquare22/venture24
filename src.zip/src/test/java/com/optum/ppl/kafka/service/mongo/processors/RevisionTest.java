package com.optum.ppl.kafka.service.mongo.processors;

import org.junit.Before;
import org.junit.Test;
import java.util.Date;
import static org.junit.Assert.*;

public class RevisionTest {

    private Revision revision;

    @Before
    public void setUp() {
        revision = new Revision();
    }

    @Test
    public void testSetAndGetAppIdentifier() {
        revision.setAppIdentifier("app1");
        assertEquals("app1", revision.getAppIdentifier());
    }

    @Test
    public void testSetAndGetClientId() {
        revision.setClientId(42);
        assertEquals(42, revision.getClientId());
    }

    @Test
    public void testSetAndGetDateCreated_nonNull() {
        Date now = new Date();
        revision.setDateCreated(now);
        assertNotNull(revision.getDateCreated());
        assertNotSame(now, revision.getDateCreated()); // defensive copy
    }

    @Test
    public void testSetAndGetDateCreated_null() {
        revision.setDateCreated(null);
        assertNull(revision.getDateCreated());
    }

    @Test
    public void testSetAndGetDateModified_nonNull() {
        Date now = new Date();
        revision.setDateModified(now);
        assertNotNull(revision.getDateModified());
        assertNotSame(now, revision.getDateModified()); // defensive copy
    }

    @Test
    public void testSetAndGetDateModified_null() {
        revision.setDateModified(null);
        assertNull(revision.getDateModified());
    }

    @Test
    public void testSetAndGetName() {
        revision.setName("TestName");
        assertEquals("TestName", revision.getName());
    }

    @Test
    public void testSetSpaceId_int() {
        revision.setSpaceId(100);
        assertEquals(100, revision.getSpaceId());
    }

    @Test
    public void testSetSpaceId_string() {
        revision.setSpaceId("200");
        assertEquals(200, revision.getSpaceId());
    }

    @Test
    public void testSetStatus_enum() {
        revision.setStatus(MetaDataStatus.ACTIVE);
        assertEquals(MetaDataStatus.ACTIVE, revision.getStatus());
    }

    @Test
    public void testSetStatus_string() {
        revision.setStatus("IN_PROCESS");
        assertEquals(MetaDataStatus.IN_PROCESS, revision.getStatus());
    }

    @Test
    public void testSetAndGetTransactionId() {
        revision.setTransactionId("trx-001");
        assertEquals("trx-001", revision.getTransactionId());
    }

    @Test
    public void testSetAndGetVersion() throws NumberFormatException {
        revision.setVersion("3");
        assertEquals("3", revision.getVersion());
    }
}