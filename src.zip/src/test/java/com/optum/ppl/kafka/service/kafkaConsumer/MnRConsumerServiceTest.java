package com.optum.ppl.kafka.service.kafkaConsumer;

import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.Mockito.*;

@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
public class MnRConsumerServiceTest {

    @InjectMocks
    private MnRConsumerService mnRConsumerService;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Mock
    private TemplateHandler templateHandler;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(mnRConsumerService, "MnR_SPACEID", 123);
    }

    @Test
    public void testConsume_ValidMessage_InsertsDocument() throws Exception {
        String key = "txn1";
        String value = validMessageWithProviderTin("\"providerTin\": \"000001234\",");
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        mnRConsumerService.consume(record);

        verify(documentMetaDataService, times(1))
                .insertMultiDocumentsWithSpaceId(anyList(), eq(123));
    }

    @Test
    public void testConsume_InvalidJson_LogsErrorAndReturns() throws Exception {
        String key = "txn2";
        String value = "{invalid_json}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);

        mnRConsumerService.consume(record);

        // Should not call insertMultiDocumentsWithSpaceId due to parse error
        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsume_MissingRequiredFields_DoesNotStore() throws Exception {
        String key = "txn3";
        String value = "{\"field\":\"val\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, key, value);


        mnRConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsume_MissingTin_IgnoresMessage() throws Exception {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "topic",
                0,
                0L,
                "txn4",
                validMessageWithProviderTin(""));

        mnRConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsume_EmptyTin_IgnoresMessage() throws Exception {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "topic",
                0,
                0L,
                "txn5",
                validMessageWithProviderTin("\"providerTin\": \"   \","));

        mnRConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsume_NullProviderDetails_IgnoresMessage() throws Exception {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "topic",
                0,
                0L,
                "txn6",
                validMessageWithProviderDetails("null"));

        mnRConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsume_EmptyProviderDetails_IgnoresMessage() throws Exception {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "topic",
                0,
                0L,
                "txn7",
                validMessageWithProviderDetails("{}"));

        mnRConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    @Test
    public void testConsume_BlankProviderDetails_IgnoresMessage() throws Exception {
        ConsumerRecord<String, String> record = new ConsumerRecord<>(
                "topic",
                0,
                0L,
                "txn8",
                validMessageWithProviderDetails("\"   \""));

        mnRConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertMultiDocumentsWithSpaceId(anyList(), anyInt());
    }

    private String validMessageWithProviderTin(String providerTinLine) {
        return validMessageWithProviderDetails("""
          {
            "admittingProviderName": "BEBARTA VIKHYAT",
            %s
            "providerName": "LOFTON, SHERI A.",
            "facilityProvider": "INOVA - FAIRFAX HOSPITAL",
            "providerNpi": "1234567890"
          }""".formatted(providerTinLine));
    }

    private String validMessageWithProviderDetails(String providerDetails) {
        return """
        {
          "recordInfo": {
            "recordID": "540620889-825626883-1722095580000",
            "recordType": "EMERGENCY",
            "encounterID": "86af17358dbe9778f9830c39b6bdfe2f"
          },
          "providerDetails": %s,
          "memberDetails": {
            "patientFirstName": "test",
            "patientLastName": "test",
            "lob": "test",
            "state": "test",
            "patientDateOfBirth": "01/01/1900"
          },
          "encounterDetails": {
            "admitDate": "2024-05-22 12:46:00",
            "dischargeDisposition": [
              "disposition1",
              "disposition2"
            ],
            "chiefComplaintList": [
              "complaint1",
              "complaint2",
              "complaint3"
            ]
          }
        }
        """.formatted(providerDetails);
    }
}
