package com.optum.ppl.kafka.service.beans;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.junit.Test;

import static org.junit.Assert.*;

public class ProviderDocumentTest {

    @Test
    public void testGettersSettersAndFluentSetters() {
        ProviderDocument document = new ProviderDocument();
        ProviderDocumentMetaData metadata = new ProviderDocumentMetaData();

        document.setDocumentId("doc-1");

        ProviderDocument returnedFromSetId = document.setId("id-1");
        ProviderDocument returnedFromSetSpaceId = document.setSpaceId("10503");
        ProviderDocument returnedFromSetStatus = document.setStatus("ACTIVE");
        ProviderDocument returnedFromSetDateCreated = document.setDateCreated("2026-07-13T10:00:00Z");
        ProviderDocument returnedFromSetMetadata = document.setMetadata(metadata);

        assertSame(document, returnedFromSetId);
        assertSame(document, returnedFromSetSpaceId);
        assertSame(document, returnedFromSetStatus);
        assertSame(document, returnedFromSetDateCreated);
        assertSame(document, returnedFromSetMetadata);

        assertEquals("doc-1", document.getDocumentId());
        assertEquals("id-1", document.getId());
        assertEquals("10503", document.getSpaceId());
        assertEquals("ACTIVE", document.getStatus());
        assertEquals("2026-07-13T10:00:00Z", document.getDateCreated());
        assertSame(metadata, document.getMetadata());
    }

    @Test
    public void testSetMetadataFromJson_success() throws Exception {
        ProviderDocument document = new ProviderDocument();

        // Use empty JSON object to avoid tight coupling with ProviderDocumentMetaData fields
        document.setMetadata("{}");

        assertNotNull(document.getMetadata());
    }

    @Test(expected = JsonProcessingException.class)
    public void testSetMetadataFromJson_invalidJson_shouldThrow() throws Exception {
        ProviderDocument document = new ProviderDocument();
        document.setMetadata("{invalid-json");
    }

    @Test
    public void testToString_containsDocumentIdAndMetadata() {
        ProviderDocument document = new ProviderDocument();
        document.setDocumentId("doc-777");
        document.setMetadata(new ProviderDocumentMetaData());

        String text = document.toString();

        assertNotNull(text);
        assertTrue(text.contains("documentId: doc-777"));
        assertTrue(text.contains("metadata:"));
    }
}