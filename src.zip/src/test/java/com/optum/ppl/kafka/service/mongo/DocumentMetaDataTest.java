package com.optum.ppl.kafka.service.mongo;

import org.bson.Document;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

public class DocumentMetaDataTest {

    @Test
    public void testAllGettersSettersAndToString() {
        DocumentMetaData meta = new DocumentMetaData();

        meta.setDoc360DocumentId("doc360-1");
        meta.setDoc360DocClass("ODAR");
        meta.setFileType("pdf");
        meta.setFileName("file1.pdf");
        meta.setS3FilePath("/bucket/file1.pdf");
        meta.setFdsAttachmentId("att-1");
        meta.setFsId("fs-1");
        meta.setFdsDocumentId("fds-1");
        meta.setSpaceId(10503);
        meta.setExternalId("ext-1");
        meta.setParentId("parent-1");
        meta.setErrorMessage("none");

        Document bson = new Document("k", "v");
        meta.setMetadata(bson);

        Date expires = new Date();
        meta.setExpires(expires);

        DocumentAttachmentMetaData attachment = new DocumentAttachmentMetaData();
        attachment.setFsId("attachment-fs");
        List<DocumentAttachmentMetaData> attachments = new ArrayList<>();
        attachments.add(attachment);
        meta.setDocumentAttachments(attachments);

        assertEquals("doc360-1", meta.getDoc360DocumentId());
        assertEquals("ODAR", meta.getDoc360DocClass());
        assertEquals("pdf", meta.getFileType());
        assertEquals("file1.pdf", meta.getFileName());
        assertEquals("/bucket/file1.pdf", meta.getS3FilePath());
        assertEquals("att-1", meta.getFdsAttachmentId());
        assertEquals("fs-1", meta.getFsId());
        assertEquals("fds-1", meta.getFdsDocumentId());
        assertEquals(10503, meta.getSpaceId());
        assertEquals("ext-1", meta.getExternalId());
        assertEquals("parent-1", meta.getParentId());
        assertEquals("none", meta.getErrorMessage());
        assertEquals(bson, meta.getMetadata());

        Date returnedExpires = meta.getExpires();
        assertEquals(expires, returnedExpires);
        assertNotSame(expires, returnedExpires);

        List<DocumentAttachmentMetaData> returnedAttachments = meta.getDocumentAttachments();
        assertNotNull(returnedAttachments);
        assertEquals(1, returnedAttachments.size());
        assertEquals("attachment-fs", returnedAttachments.get(0).getFsId());
        assertNotSame(attachments, returnedAttachments);

        String text = meta.toString();
        assertNotNull(text);
        assertTrue(text.contains("externalId=ext-1"));
        assertTrue(text.contains("parentId=parent-1"));
        assertTrue(text.contains("spaceId=10503"));
        assertTrue(text.contains("fsId=fs-1"));
        assertTrue(text.contains("fdsAttachmentId=att-1"));
        assertTrue(text.contains("fdsDocumentId=fds-1"));
        assertTrue(text.contains("fileName=file1.pdf"));
        assertTrue(text.contains("s3FilePath=/bucket/file1.pdf"));
        assertTrue(text.contains("metadata=Document{{k=v}}"));
    }

    @Test
    public void testNullBranches() {
        DocumentMetaData meta = new DocumentMetaData();

        meta.setDocumentAttachments(null);
        meta.setExpires(null);
        meta.setSpaceId((Integer) null);

        assertNull(meta.getDocumentAttachments());
        assertNull(meta.getExpires());
        assertEquals(0, meta.getSpaceId());
    }

    @Test
    public void testSetSpaceIdIntegerNonNull() {
        DocumentMetaData meta = new DocumentMetaData();

        meta.setSpaceId(Integer.valueOf(200));

        assertEquals(200, meta.getSpaceId());
    }

    @Test
    public void testExpiresDefensiveCopyOnSet() {
        DocumentMetaData meta = new DocumentMetaData();

        Date original = new Date();
        meta.setExpires(original);

        original.setTime(original.getTime() + 100000L);

        Date stored = meta.getExpires();
        assertNotNull(stored);
        assertNotEquals(original, stored);
    }

    @Test
    public void testDocumentAttachmentsDefensiveCopyOnSetAndGet() {
        DocumentMetaData meta = new DocumentMetaData();

        List<DocumentAttachmentMetaData> original = new ArrayList<>();
        DocumentAttachmentMetaData attachment = new DocumentAttachmentMetaData();
        attachment.setFsId("a1");
        original.add(attachment);

        meta.setDocumentAttachments(original);

        original.clear(); // mutate original after set
        List<DocumentAttachmentMetaData> stored = meta.getDocumentAttachments();

        assertNotNull(stored);
        assertEquals(1, stored.size());

        stored.clear(); // mutate returned copy
        List<DocumentAttachmentMetaData> storedAgain = meta.getDocumentAttachments();
        assertEquals(1, storedAgain.size());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetRevisions() {
        DocumentMetaData meta = new DocumentMetaData();

        List<DocumentRevision> revisions = new ArrayList<>();
        ReflectionTestUtils.setField(meta, "revisions", revisions);

        List<DocumentRevision> result = meta.getRevisions();

        assertSame(revisions, result);
    }
}