package com.optum.ppl.kafka.service;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.junit.Before;
import org.junit.Test;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class CustomKafkaConsumerConfigTest {

    private CustomKafkaConsumerConfig config;

    @Before
    public void setUp() {
        config = new CustomKafkaConsumerConfig();

        ReflectionTestUtils.setField(config, "defaultGroupId", "test-group");
        ReflectionTestUtils.setField(config, "bootstrapServers", "localhost:9092");
        ReflectionTestUtils.setField(config, "securityProtocol", "SSL");
        ReflectionTestUtils.setField(config, "keystoreLocation", "/tmp/keystore.jks");
        ReflectionTestUtils.setField(config, "keystorePassword", "key-pass");
        ReflectionTestUtils.setField(config, "truststoreLocation", "/tmp/truststore.jks");
        ReflectionTestUtils.setField(config, "truststorePassword", "trust-pass");
    }

    @Test
    public void testDocumentConsumerFactory_buildsFactoryWithExpectedProperties() {
        ConsumerFactory<String, String> consumerFactory = config.documentConsumerFactory();

        assertNotNull(consumerFactory);
        assertTrue(consumerFactory instanceof DefaultKafkaConsumerFactory);

        @SuppressWarnings("unchecked")
        DefaultKafkaConsumerFactory<String, String> defaultFactory =
                (DefaultKafkaConsumerFactory<String, String>) consumerFactory;

        Map<String, Object> props = defaultFactory.getConfigurationProperties();
        assertNotNull(props);

        // Connection/group/deserializer properties
        assertEquals("localhost:9092", props.get(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG));
        assertEquals("test-group", props.get(ConsumerConfig.GROUP_ID_CONFIG));
        assertEquals(org.apache.kafka.common.serialization.StringDeserializer.class,
                props.get(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG));
        assertEquals(org.apache.kafka.common.serialization.StringDeserializer.class,
                props.get(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG));

        // SSL properties
        assertEquals("SSL", props.get(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG));
        assertEquals("/tmp/keystore.jks", props.get(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG));
        assertEquals("key-pass", props.get(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG));
        assertEquals("/tmp/truststore.jks", props.get(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG));
        assertEquals("trust-pass", props.get(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG));
    }

    @Test
    public void testSecureKafkaListenerContainerFactory_setsProvidedConsumerFactory() {
        ConsumerFactory<String, String> consumerFactory = config.documentConsumerFactory();

        ConcurrentKafkaListenerContainerFactory<String, String> factory =
                config.secureKafkaListenerContainerFactory(consumerFactory);

        assertNotNull(factory);
        assertSame(consumerFactory, factory.getConsumerFactory());
    }
}