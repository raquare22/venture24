package com.optum.ppl.kafka.service.template.listener;

import org.junit.Before;
import org.junit.Test;
import org.stringtemplate.v4.misc.STMessage;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ErrorListenerTest {

    private ErrorListener errorListener;
    private STMessage mockMessage;

    @Before
    public void setUp() {
        errorListener = new ErrorListener();
        mockMessage = mock(STMessage.class);
        when(mockMessage.toString()).thenReturn("template error detail");
    }

    // --- compileTimeError ---

    @Test(expected = RuntimeException.class)
    public void testCompileTimeError_throwsRuntimeException() {
        errorListener.compileTimeError(mockMessage);
    }

    @Test
    public void testCompileTimeError_messageFormat() {
        try {
            errorListener.compileTimeError(mockMessage);
            fail("Expected RuntimeException");
        } catch (RuntimeException e) {
            assertEquals(
                    "String template compile time error, template error detail",
                    e.getMessage()
            );
            assertTrue(e.getMessage().contains("compile time"));
        }
    }

    // --- runTimeError ---

    @Test(expected = RuntimeException.class)
    public void testRunTimeError_throwsRuntimeException() {
        errorListener.runTimeError(mockMessage);
    }

    @Test
    public void testRunTimeError_messageFormat() {
        try {
            errorListener.runTimeError(mockMessage);
            fail("Expected RuntimeException");
        } catch (RuntimeException e) {
            assertEquals(
                    "String template run time error, template error detail",
                    e.getMessage()
            );
            assertTrue(e.getMessage().contains("run time"));
        }
    }

    // --- IOError ---

    @Test(expected = RuntimeException.class)
    public void testIOError_throwsRuntimeException() {
        errorListener.IOError(mockMessage);
    }

    @Test
    public void testIOError_messageFormat() {
        try {
            errorListener.IOError(mockMessage);
            fail("Expected RuntimeException");
        } catch (RuntimeException e) {
            assertEquals(
                    "String template IO error, template error detail",
                    e.getMessage()
            );
            assertTrue(e.getMessage().contains("IO"));
        }
    }

    // --- internalError ---

    @Test(expected = RuntimeException.class)
    public void testInternalError_throwsRuntimeException() {
        errorListener.internalError(mockMessage);
    }

    @Test
    public void testInternalError_messageFormat() {
        try {
            errorListener.internalError(mockMessage);
            fail("Expected RuntimeException");
        } catch (RuntimeException e) {
            assertEquals(
                    "String template internal error, template error detail",
                    e.getMessage()
            );
            assertTrue(e.getMessage().contains("internal"));
        }
    }
}