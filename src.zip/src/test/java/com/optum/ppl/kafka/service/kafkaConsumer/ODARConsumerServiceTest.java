package com.optum.ppl.kafka.service.kafkaConsumer;


import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ODARConsumerServiceTest {


    @InjectMocks
    private ODARConsumerService odarConsumerService;

    @Mock
    private DocumentMetaDataService documentMetaDataService;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(odarConsumerService, "odar_spaceId", 123);
    }

    @Test
    public void testConsume_withValidMessage_insertsDocument() {
        String json = "{\"globalDocId\":\"docId\",\"docClass\":\"classA\"}";
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", json);

        odarConsumerService.consume(record);

        verify(documentMetaDataService, times(1)).insertDocumentWithSpaceId(any(DocumentMetaData.class), eq(123));
    }

    @Test
    public void testConsume_withNullValue_logsWarning() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", null);

        odarConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(DocumentMetaData.class), anyInt());
    }

    @Test
    public void testConsume_withEmptyValue_logsWarning() {
        ConsumerRecord<String, String> record = new ConsumerRecord<>("topic", 0, 0L, "key", "");

        odarConsumerService.consume(record);

        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(DocumentMetaData.class), anyInt());
    }


    @Test
    public void testConsume_NullMessage() {
        ConsumerRecord<String, String> record = mock(ConsumerRecord.class);
        when(record.value()).thenReturn(null);
        when(record.key()).thenReturn("testKey");

        odarConsumerService.consume(record);
        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), anyInt());
    }

    @Test
    public void testConsume_EmptyMessage() {
        ConsumerRecord<String, String> record = mock(ConsumerRecord.class);
        when(record.value()).thenReturn("");
        when(record.key()).thenReturn("testKey");

        odarConsumerService.consume(record);
        verify(documentMetaDataService, never()).insertDocumentWithSpaceId(any(), anyInt());
    }

    @Test
    public void testConsume_ValidMessageWithGlobalDocIdAndDocClass() {
        String json = "{\"globalDocumentId\":\"g123\",\"documentClass\":\"classA\"}";
        ConsumerRecord<String, String> record = mock(ConsumerRecord.class);
        when(record.value()).thenReturn(json);
        when(record.key()).thenReturn("testKey");

        odarConsumerService.consume(record);
        ArgumentCaptor<DocumentMetaData> captor = ArgumentCaptor.forClass(DocumentMetaData.class);
        verify(documentMetaDataService, times(1)).insertDocumentWithSpaceId(captor.capture(), eq(123));
        DocumentMetaData doc = captor.getValue();
        assertEquals(MetaDataStatus.NEW, doc.getStatus());
        assertEquals("g123", doc.getDoc360DocumentId());
        assertEquals("classA", doc.getDoc360DocClass());
    }
}
