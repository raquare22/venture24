package com.optum.ppl.kafka.service.beans;

import org.junit.Test;

import static org.junit.Assert.*;

public class ProviderDocumentMetaDataTest {

    @Test
    public void testAllGettersSettersAndFluentReturns() {
        ProviderDocumentMetaData meta = new ProviderDocumentMetaData();

        ProviderDocumentMetaData r1 = meta.setProviderEmailId("test@domain.com");
        ProviderDocumentMetaData r2 = meta.setWeekday("MONDAY");
        ProviderDocumentMetaData r3 = meta.setFrequency("WEEKLY");
        ProviderDocumentMetaData r4 = meta.setDeliveryMethod("EMAIL");
        ProviderDocumentMetaData r5 = meta.setMpin("123456");
        ProviderDocumentMetaData r6 = meta.setActiveDate("2026-07-13");
        ProviderDocumentMetaData r7 = meta.setSubsribeToEmail("Y");

        meta.setTin("TIN-999");

        // Fluent setters should return same instance
        assertSame(meta, r1);
        assertSame(meta, r2);
        assertSame(meta, r3);
        assertSame(meta, r4);
        assertSame(meta, r5);
        assertSame(meta, r6);
        assertSame(meta, r7);

        // Getter validations
        assertEquals("test@domain.com", meta.getProviderEmailId());
        assertEquals("MONDAY", meta.getWeekday());
        assertEquals("WEEKLY", meta.getFrequency());
        assertEquals("EMAIL", meta.getDeliveryMethod());
        assertEquals("123456", meta.getMpin());
        assertEquals("TIN-999", meta.getTin());
        assertEquals("2026-07-13", meta.getActiveDate());
        assertEquals("Y", meta.getSubscribeToEmail());
    }

    @Test
    public void testToStringContainsExpectedFields() {
        ProviderDocumentMetaData meta = new ProviderDocumentMetaData()
                .setProviderEmailId("provider@abc.com")
                .setMpin("MPIN123")
                .setSubsribeToEmail("N");
        meta.setTin("TIN123");

        String value = meta.toString();

        assertNotNull(value);
        assertTrue(value.contains("mpin : MPIN123"));
        assertTrue(value.contains("tin : TIN123"));
        assertTrue(value.contains("providerEmailId: provider@abc.com"));
        assertTrue(value.contains("subscribeToEmail: N"));
    }

    @Test
    public void testNullAssignments() {
        ProviderDocumentMetaData meta = new ProviderDocumentMetaData();

        meta.setProviderEmailId(null)
                .setWeekday(null)
                .setFrequency(null)
                .setDeliveryMethod(null)
                .setMpin(null)
                .setActiveDate(null)
                .setSubsribeToEmail(null);
        meta.setTin(null);

        assertNull(meta.getProviderEmailId());
        assertNull(meta.getWeekday());
        assertNull(meta.getFrequency());
        assertNull(meta.getDeliveryMethod());
        assertNull(meta.getMpin());
        assertNull(meta.getTin());
        assertNull(meta.getActiveDate());
        assertNull(meta.getSubscribeToEmail());

        String value = meta.toString();
        assertNotNull(value);
        assertTrue(value.contains("mpin : null"));
        assertTrue(value.contains("tin : null"));
    }
}