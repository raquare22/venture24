package com.optum.ppl.kafka.service.mongo;

import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.*;

public class DocumentAttachmentMetaDataTest {

    @Test
    public void testAllGettersSettersAndToString() {
        DocumentAttachmentMetaData meta = new DocumentAttachmentMetaData();

        meta.setFsId("fs-1");
        meta.setAttachmentId("att-1");
        meta.setIndex(2);
        meta.setName("file1.pdf");
        meta.setFileSize(12345L);
        meta.setContentType("application/pdf");
        meta.setCreatedBy("user1");
        meta.setModifiedBy("user2");
        meta.setVirusScanStatus("CLEAN");
        meta.setCloudStorageProvider("AWS");
        meta.setStatus("ACTIVE");
        meta.setExternalId("ext-1");
        meta.setErrorMessage("none");
        meta.setSpaceId("10503");
        meta.setUrl("http://test");
        meta.setUrlToken("token-1");
        meta.setSentToDocVault(true);

        Date createdOn = new Date();
        Date modifiedOn = new Date(createdOn.getTime() + 1000);
        Date expires = new Date(createdOn.getTime() + 2000);

        meta.setCreatedOn(createdOn);
        meta.setModifiedOn(modifiedOn);
        meta.setExpires(expires);

        assertEquals("fs-1", meta.getFsId());
        assertEquals("att-1", meta.getAttachmentId());
        assertEquals(2, meta.getIndex());
        assertEquals("file1.pdf", meta.getName());
        assertEquals(12345L, meta.getFileSize());
        assertEquals("application/pdf", meta.getContentType());
        assertEquals(createdOn, meta.getCreatedOn());
        assertEquals(modifiedOn, meta.getModifiedOn());
        assertEquals("user1", meta.getCreatedBy());
        assertEquals("user2", meta.getModifiedBy());
        assertEquals("CLEAN", meta.getVirusScanStatus());
        assertEquals("AWS", meta.getCloudStorageProvider());
        assertEquals("ACTIVE", meta.getStatus());
        assertEquals("ext-1", meta.getExternalId());
        assertEquals("none", meta.getErrorMessage());
        assertEquals("10503", meta.getSpaceId());
        assertEquals("http://test", meta.getUrl());
        assertEquals("token-1", meta.getUrlToken());
        assertTrue(meta.isSentToDocVault());

        // getExpires returns a clone, not same reference
        Date returnedExpires = meta.getExpires();
        assertEquals(expires, returnedExpires);
        assertNotSame(expires, returnedExpires);

        String text = meta.toString();
        assertNotNull(text);
        assertTrue(text.contains("fs-1"));
        assertTrue(text.contains("file1.pdf"));
        assertTrue(text.contains("ACTIVE"));
        assertTrue(text.contains("ext-1"));
        assertTrue(text.contains("none"));
        assertTrue(text.contains("true"));
    }

    @Test
    public void testExpiresNullHandling() {
        DocumentAttachmentMetaData meta = new DocumentAttachmentMetaData();

        meta.setExpires(null);
        assertNull(meta.getExpires());
    }

    @Test
    public void testExpiresDefensiveCopyOnSet() {
        DocumentAttachmentMetaData meta = new DocumentAttachmentMetaData();

        Date original = new Date();
        meta.setExpires(original);

        // mutate original after setting
        original.setTime(original.getTime() + 100000);

        Date stored = meta.getExpires();
        assertNotNull(stored);
        assertNotEquals(original, stored);
    }

    @Test
    public void testSetNameMapsToFileName() {
        DocumentAttachmentMetaData meta = new DocumentAttachmentMetaData();

        meta.setName("abc.txt");

        assertEquals("abc.txt", meta.getName());
    }

    @Test
    public void testBooleanDefaults() {
        DocumentAttachmentMetaData meta = new DocumentAttachmentMetaData();

        assertFalse(meta.isSentToDocVault());
    }
}