package com.optum.ppl.kafka.service.mongo;

import org.bson.Document;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.*;

public class ErrorRevisionTest {

    @Test
    public void testGettersAndSetters() {
        ErrorRevision revision = new ErrorRevision();

        revision.setExternalId("ext-1");
        revision.setErrorMessage("error-msg");

        Document metadata = new Document("k", "v");
        revision.setMetadata(metadata);

        Date inputDate = new Date();
        revision.setDateAttachmentUpdated(inputDate);

        assertEquals("ext-1", revision.getExternalId());
        assertEquals("error-msg", revision.getErrorMessage());
        assertEquals(metadata, revision.getMetadata());

        Date returnedDate = revision.getDateAttachmentUpdated();
        assertNotNull(returnedDate);
        assertEquals(inputDate, returnedDate);
        assertNotSame(inputDate, returnedDate); // defensive copy on get
    }

    @Test
    public void testDateAttachmentUpdated_nullHandling() {
        ErrorRevision revision = new ErrorRevision();

        revision.setDateAttachmentUpdated(null);

        assertNull(revision.getDateAttachmentUpdated());
    }

    @Test
    public void testDateAttachmentUpdated_defensiveCopyOnSet() {
        ErrorRevision revision = new ErrorRevision();

        Date original = new Date();
        revision.setDateAttachmentUpdated(original);

        // mutate original object after set
        long changed = original.getTime() + 10000L;
        original.setTime(changed);

        Date stored = revision.getDateAttachmentUpdated();
        assertNotNull(stored);
        assertNotEquals(original, stored); // value should not track mutated original reference
    }
}