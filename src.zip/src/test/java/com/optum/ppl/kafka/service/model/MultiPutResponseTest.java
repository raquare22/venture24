package com.optum.ppl.kafka.service.model;

import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class MultiPutResponseTest {

    @Test
    public void constructorAndGetters_shouldWork() {
        List<String> updated = Arrays.asList("id1", "id2");
        List<String> notUpdated = Arrays.asList("id3");

        MultiPutResponse response = new MultiPutResponse(updated, notUpdated);

        assertEquals(updated, response.getUpdated());
        assertEquals(notUpdated, response.getNotUpdated());
    }

    @Test
    public void setters_shouldUpdateValues() {
        MultiPutResponse response = new MultiPutResponse(null, null);

        List<String> updated = Arrays.asList("u1", "u2");
        List<String> notUpdated = Arrays.asList("n1", "n2");

        response.setUpdated(updated);
        response.setNotUpdated(notUpdated);

        assertEquals(updated, response.getUpdated());
        assertEquals(notUpdated, response.getNotUpdated());
    }

    @Test
    public void constructorWithNulls_shouldAllowNullValues() {
        MultiPutResponse response = new MultiPutResponse(null, null);

        assertNull(response.getUpdated());
        assertNull(response.getNotUpdated());
    }
}