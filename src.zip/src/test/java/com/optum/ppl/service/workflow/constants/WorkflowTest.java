package com.optum.ppl.service.workflow.constants;

import org.junit.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import static org.junit.Assert.*;

public class WorkflowTest {

    @Test
    public void constants_shouldHaveExpectedValues() {
        // Touch representative constants to ensure class init and static field coverage
        assertEquals("podName", Workflow.POD_NAME);
        assertEquals("numRetries", Workflow.NUM_RETRIES);
        assertEquals("oauth_token", Workflow.OAUTH_TOKEN);
        assertEquals("emailAlertReq", Workflow.EMAIL_ALERT_REQUEST);
        assertEquals("SSL", Workflow.SSL);
        assertEquals("ProcessorTransactions", Workflow.PROCCESSOR_TRANSACTIONS);
        assertEquals("skipDocumentGrouping", Workflow.SKIP_DOCUMENT_GROUPING);
    }

    @Test
    public void constructor_shouldBePrivate_andThrowAssertionError() throws Exception {
        Constructor<Workflow> constructor = Workflow.class.getDeclaredConstructor();

        assertTrue("Constructor must be private", Modifier.isPrivate(constructor.getModifiers()));

        constructor.setAccessible(true);

        try {
            constructor.newInstance();
            fail("Expected InvocationTargetException wrapping AssertionError");
        } catch (InvocationTargetException ex) {
            assertTrue(ex.getCause() instanceof AssertionError);
            assertEquals("cannot instantiate", ex.getCause().getMessage());
        }
    }
}