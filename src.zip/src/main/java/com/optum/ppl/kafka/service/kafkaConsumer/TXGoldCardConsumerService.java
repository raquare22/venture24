package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.TXGoldCard", havingValue = "true")
public class TXGoldCardConsumerService extends AbstractDocumentConsumer {

    @Value("${TXGoldCard_SPACEID}")
    private int txgoldcard_spaceId;

    @KafkaListener(
            topics = "${spring.kafka.topic.TXGoldCard}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, txgoldcard_spaceId);
    }
}
