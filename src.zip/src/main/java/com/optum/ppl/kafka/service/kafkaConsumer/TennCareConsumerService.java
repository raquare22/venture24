package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.tenncare", havingValue = "true")
public class TennCareConsumerService extends AbstractDocumentConsumer{
    @Value("${TENNCARE_SPACEID}")
    private int tenncare_spaceId;

    @Override
    protected int getSpaceId() {
        return this.tenncare_spaceId;
    }

    @KafkaListener(
            topics = "${spring.kafka.topic.tenncare}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message);
    }
}
