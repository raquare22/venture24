package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;


@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.usppra", havingValue = "true")
public class USPPRAconsumerService extends AbstractDocumentConsumer{

    @Value("${USPPRA_SPACEID}")
    private int usppra_spaceId;

    @Override
    protected int getSpaceId() {
        return this.usppra_spaceId;
    }

    @KafkaListener(
            topics = "${spring.kafka.topic.usppra}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message);
    }


}

