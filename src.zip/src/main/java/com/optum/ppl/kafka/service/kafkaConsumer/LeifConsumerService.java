package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.leif", havingValue = "true")
public class LeifConsumerService extends AbstractDocumentConsumer{
	
    @Value("${LEIF_SPACEID}")
    private int leif_spaceId;

    @Override
    protected int getSpaceId() {
        return this.leif_spaceId;
    }

    @KafkaListener(
            topics = "${spring.kafka.topic.leif}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message);
    }
}
