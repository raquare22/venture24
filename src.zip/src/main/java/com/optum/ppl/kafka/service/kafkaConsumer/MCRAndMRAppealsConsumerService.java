package com.optum.ppl.kafka.service.kafkaConsumer;

import java.util.List;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.mcrAndmrappeals", havingValue = "true")
public class MCRAndMRAppealsConsumerService  extends AbstractDocumentConsumer {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MCRAndMRAppealsConsumerService.class);
	private static final String CREATE_APP_PHS = "PHS";
	private static final String CREATE_APP_MNR = "MNR";
	private static final String CREATE_APP_MNR2 = "MNR2.0";
	private static final String CREATE_APP_ATS = "ATS";
	
	 @Value("${MCR_SPACEID}")
	 private int mcr_spaceId;
	 
	 @Value("${MR_APPEALS_SPACEID}")
	 private int mrAppeals_SpaceId;
	 
	 @Value("${MR_APPEALS_KAFKA_ENABLED}")
	 private boolean enabled_mrAppeals;
	 
	 @Value("${MCR_KAFKA_ENABLED}")
	 private boolean enabled_mcr;
	 
	
	 
	 @KafkaListener(
	      topics = "${spring.kafka.topic.mcrandmrappeals}",
	      containerFactory = "secureKafkaListenerContainerFactory" 
	 )
	 public void consume(ConsumerRecord<String, String> message) {
		 
		 try {
	            if (message == null || message.value() == null || message.value().trim().isEmpty()) {
	                return;
	            }

	            Document metadata = Document.parse(message.value());
	            
	            String createApp = null;
	            
	            List<Document> attributes = metadata.getList("attributes", Document.class);
	            if (attributes != null) {
	            	
	            	for (Document attribute : attributes) {
	            		if("u_create_App".equalsIgnoreCase(attribute.getString("physicalName"))) {
	            			createApp = attribute.getString("value");
	            			break;
	            		}

	            	}
	            	
	            }  

	            if (enabled_mcr && CREATE_APP_PHS.equalsIgnoreCase(createApp)) {
	            	LOGGER.debug("Processing message for key={} with u_create_App={}",message.key(), createApp);
	                super.processMessage(message, mcr_spaceId);
	            } else if( enabled_mrAppeals &&
	            		(CREATE_APP_MNR.equalsIgnoreCase(createApp) 
	            		|| CREATE_APP_MNR2.equalsIgnoreCase(createApp) 
	            		|| CREATE_APP_ATS.equalsIgnoreCase(createApp))) {
	            	LOGGER.debug("Processing message for key={} with u_create_App={}",message.key(), createApp);
	            	super.processMessage(message, mrAppeals_SpaceId);
	            	
	            }

	        } catch (Exception e) {
	            LOGGER.error("Error while validating MCR/MR APPEALS message. key={}",message != null ? message.key() : null,e);
	        } 
	  }

}