package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.homeandcommunity", havingValue = "true")
public class HomeAndCommunityConsumerService extends AbstractDocumentConsumer {

    @Value("${HOME_AND_COMMUNITY_SPACEID}")
    private int homeAndCommunity_spaceId;

    @Override
    protected int getSpaceId() {
        return this.homeAndCommunity_spaceId;
    }

    @KafkaListener(
            topics = "${spring.kafka.topic.homeandcommunity}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message);
    }
}
