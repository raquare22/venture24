package com.optum.ppl.kafka.service.template.java.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.kafka.model.KafkaMessage;
import com.optum.ppl.kafka.service.kafka.model.MemberDetails;
import com.optum.ppl.kafka.service.kafka.model.ProviderDetails;
import com.optum.ppl.kafka.service.kafka.model.RecordInfo;
import com.optum.ppl.kafka.service.template.Templates;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;

public class MnRKafkaDocumentTemplate extends TemplateHandler {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MnRKafkaDocumentTemplate.class);

	@Override
	public String convertWithTemplate(String jsonString) {
		return null;
	}

	@Override
	public String convertWithTemplateFromFilePath(String filePath) {
		return null;
	}

	@Override
	public String convertWithTemplate(Object pojo) {
		
		var st = this.templateLoader.getTemplate(Templates.KAFKA_MNR_DOCUMENT);
		ObjectMapper objectMapper = new ObjectMapper();
		 
	    Map<String, Object> kafkaResponse = (Map<String, Object>) pojo;
	    String key = (String) kafkaResponse.get("key");
	        
	    String kafkaMsgStr = (String) kafkaResponse.get("kafkaResponse");
	    
        String cleanedKafkaMsgStr = kafkaMsgStr.replace("\\\"", "");
        cleanedKafkaMsgStr = cleanedKafkaMsgStr.replace("\\\\T\\\\", "");
        cleanedKafkaMsgStr = cleanedKafkaMsgStr.replace("\\\\E\\\\", "");
        cleanedKafkaMsgStr = cleanedKafkaMsgStr.replace("\\\\", "");
        
	    KafkaMessage msg = new KafkaMessage();
	    
	    try{
            msg = objectMapper.readValue(cleanedKafkaMsgStr, KafkaMessage.class);
        } catch (JsonProcessingException e){ 
            LOGGER.error("MnRKafkaDocumentTemplate --> unable to convert json string to KafkaResponse, e={}", e.getMessage());
        }
		
	    RecordInfo recordInfo = msg.getRecordInfo();
        MemberDetails memberDetails = msg.getMemberDetails();
        ProviderDetails providerDetails = msg.getProviderDetails();
        
        Map<String, Object> encounterDetails = msg.getEncounterDetails();
        
        List<String> dischargeDispositionlist = (List<String>) encounterDetails.get("dischargeDisposition");
        List<String> chiefComplaintList = (List<String>) encounterDetails.get("chiefComplaintList");
        if (recordInfo == null || providerDetails == null) {
            LOGGER.warn("MnRKafkaDocumentTemplate --> recordInfo or providerDetails are null for transactionId: {}", key);
            return null;
        }

        return st.add("recordInfo", recordInfo)
        		.add("providerInfo", providerDetails)
                .add("memberInfo", memberDetails)
                .add("encounterDetails",encounterDetails)
                .add("dischargeDispositionlist",dischargeDispositionlist)
                .add("chiefComplaintList",chiefComplaintList)
                .add("transactionId", key)
                .render();
	}

}
