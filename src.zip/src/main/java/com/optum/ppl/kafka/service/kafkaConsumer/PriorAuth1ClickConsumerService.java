package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.priorauth1click", havingValue = "true")
public class PriorAuth1ClickConsumerService extends AbstractDocumentConsumer{

    @Value("${PRIORAUTH1CLICK_SPACEID}")
    private int priorauth1click_spaceId;

    protected int getSpaceId() {
        return this.priorauth1click_spaceId;
    }

    @KafkaListener(
            topics = "${spring.kafka.topic.priorauth1click}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message,priorauth1click_spaceId);
    }
}

