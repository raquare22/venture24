package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.cosmospra", havingValue = "true")
public class CosmosPRAConsumerService extends AbstractDocumentConsumer{

    @Value("${COSMOSPRA_SPACEID}")
    private int cosmospra_spaceId;

    @KafkaListener(
            topics = "${spring.kafka.topic.cosmospra}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, cosmospra_spaceId);
    }
}
