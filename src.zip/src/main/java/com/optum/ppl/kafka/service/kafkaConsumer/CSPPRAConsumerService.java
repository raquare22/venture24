package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.csppra", havingValue = "true")
public class CSPPRAConsumerService extends AbstractDocumentConsumer{

    @Value("${CSPPRA_SPACEID}")
    private int cspPra_spaceId;

    @KafkaListener(
            topics = "${spring.kafka.topic.cspPra}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, cspPra_spaceId);
    }
}
