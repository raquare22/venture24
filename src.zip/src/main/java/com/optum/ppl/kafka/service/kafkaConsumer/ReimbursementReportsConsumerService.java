package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.reimbursementreports", havingValue = "true")
public class ReimbursementReportsConsumerService  extends  AbstractDocumentConsumer{

    @Value("$REIMBURSEMENT_REPORTS_SPACEID")
    private int reimbursementReports_spaceId;

    @Override
    protected int getSpaceId(){
        return this.reimbursementReports_spaceId;
    }

    @KafkaListener(
            topics = "${spring.kafka.topic.reimbursementreports}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )

    public void consume(ConsumerRecord<String,String> message){
        super.processMessage(message);
    }
}
