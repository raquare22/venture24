package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.paymentEngine835Files", havingValue = "true")

public class PaymentEngine835FilesConsumerService extends AbstractDocumentConsumer{

    @Value("${PaymentEngine835Files_SPACEID}")
    private int paymentEngine835Files_spaceId;

    @KafkaListener(
            topics = "${spring.kafka.topic.paymentEngine835Files}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )

    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, paymentEngine835Files_spaceId);
    }


}
