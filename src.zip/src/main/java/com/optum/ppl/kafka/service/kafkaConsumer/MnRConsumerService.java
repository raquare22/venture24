package com.optum.ppl.kafka.service.kafkaConsumer;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.ppl.kafka.service.domain.DocumentMetaDataService;
import com.optum.ppl.kafka.service.mongo.DocumentMetaData;
import com.optum.ppl.kafka.service.mongo.processors.MetaDataStatus;
import com.optum.ppl.kafka.service.template.Templates;
import com.optum.ppl.kafka.service.template.java.TemplateFactory;
import com.optum.ppl.kafka.service.template.java.TemplateHandler;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.bson.Document;
import org.owasp.encoder.Encode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.MnR", havingValue = "true")
public final class MnRConsumerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MnRConsumerService.class);
    private static final String PROVIDER_DETAILS = "providerDetails";
    private static final String PROVIDER_TIN = "providerTin";

    @Autowired
    DocumentMetaDataService documentMetaDataService;

    @Value("${PRUN.MnR_SPACEID}") 
    private int MnR_SPACEID;

    @KafkaListener(
    		
    		topics = "${spring.kafka.topic.MnR}", 
    		groupId = "${kafkaGroupIdMnR}", 
            properties= {
    		   "bootstrap.servers=${MnRBootstrapServers}",
    		   "ssl.keystore.location=${MnRconsumerKeystorePath}", 
    		   "ssl.keystore.password=${MnRconsumerkeystorePassword}", 
    		   "ssl.truststore.location=${MnRconsumertruststorelocation}", 
    		   "ssl.truststore.password=${MnRconsumertruststorePassword}"
			}
    )
    public void consume(ConsumerRecord<String, String> message) {

        List<DocumentMetaData> insertedDocList = new ArrayList<>();
        String metadataStr = null;
        
        DocumentMetaData document = null;
        try {
        	

            // Validate JSON format
            ObjectMapper mapper = new ObjectMapper();
            JsonNode jsonNode = mapper.readTree(message.value()); 

            if (validateRequiredFields(jsonNode)) {
                LOGGER.warn("KafkaConsumerService --> Kafka MnR Consumer --> ignoring message with missing required fields for transactionId={}",
                        Encode.forJava(message.key()));
                return;
            }
        	
            Map<String, Object> kafkaResponseMap = new HashMap<>();
            kafkaResponseMap.put("kafkaResponse", message.value());
            kafkaResponseMap.put("key", message.key());
            
           LOGGER.info("KafkaConsumerService --> Kafka MnR Consumer message received --> kafkaResponseMap: {}", kafkaResponseMap);
       
        	TemplateHandler templateHandler = TemplateFactory.getInstance(Templates.KAFKA_MNR_DOCUMENT.getTemplate());
        	metadataStr = templateHandler.convertWithTemplate(kafkaResponseMap);
        	
        	if (metadataStr == null || metadataStr.isEmpty()) {
                LOGGER.warn("KafkaConsumerService --> Kafka MnR Consumer-->metadataStr is null or empty for transactionId={}", Encode.forJava(message.key()));
                return;
            }
        	org.bson.Document metadata = mapper.readValue(metadataStr, new TypeReference<org.bson.Document>(){});
        	document = new DocumentMetaData();
             
            document.setMetadata(metadata);
            document.setStatus(MetaDataStatus.AVAILABLE);   
            

            insertedDocList.add(document);
             
        } 
        
        catch (JsonParseException e) {
            LOGGER.error("Invalid JSON format in Kafka message: key={}, value={}, error={}",
                    Encode.forJava(message.key()), message.value(), ExceptionUtils.getStackTrace(e));
            return;
        } catch (Exception e) {
            LOGGER.error("KafkaConsumerService --> Kafka MnR Consumer --> unable to convert json string to documentMetaData, kafkaKey={}, e={}", 
            		Encode.forJava(message.key()), ExceptionUtils.getStackTrace(e));
        }
        if (CollectionUtils.isEmpty(insertedDocList)) {
            LOGGER.warn("KafkaConsumerService --> Kafka MnR Consumer-->documentMetaDataList is null or empty");
            return;
        }
        documentMetaDataService.insertMultiDocumentsWithSpaceId(insertedDocList, MnR_SPACEID);
        LOGGER.info("Kafka MnR Consumer --> document inserted to mongodb: transactionId={}", message.key());
        
    }

    private boolean validateRequiredFields(JsonNode jsonNode) {
        JsonNode providerDetailsNode = jsonNode.path(PROVIDER_DETAILS);
        if (providerDetailsNode.isMissingNode() || providerDetailsNode.isNull()) {
            return true;
        }
        if (providerDetailsNode.isValueNode()) {
            return StringUtils.isBlank(providerDetailsNode.asText());
        }
        if (!providerDetailsNode.isObject() || providerDetailsNode.size() == 0) {
            return true;
        }

        JsonNode tinNode = providerDetailsNode.path(PROVIDER_TIN);
        return tinNode.isMissingNode()
                || tinNode.isNull()
                || !tinNode.isValueNode()
                || StringUtils.isBlank(tinNode.asText());
    }
}
