package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.priorauthccsmanual", havingValue = "true")
public class PriorAuthCCSManualConsumerService extends AbstractDocumentConsumer {

	@Value("${PRIORAUTHCCSMANUAL_SPACEID}")
    private int priorauthccsmanual_spaceId;


    @KafkaListener(
            topics = "${spring.kafka.topic.priorauthccsmanual}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, priorauthccsmanual_spaceId);
    }
}