package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.priorauthocm", havingValue = "true")
public class PriorAuthOCMConsumerService extends AbstractDocumentConsumer {
	
	@Value("${PRIORAUTHOCM_SPACEID}")
    private int priorauthocm_spaceId;


    @KafkaListener(
            topics = "${spring.kafka.topic.priorauthocm}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, priorauthocm_spaceId);
    }
}
