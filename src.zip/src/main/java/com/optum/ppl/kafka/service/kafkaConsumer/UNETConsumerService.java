package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.unet", havingValue = "true")
public class UNETConsumerService extends AbstractDocumentConsumer {

    @Value("${UNET_SPACEID}")
    private int unet_spaceId;

    @KafkaListener(
            topics = "${spring.kafka.topic.unet}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, unet_spaceId);
    }
}
