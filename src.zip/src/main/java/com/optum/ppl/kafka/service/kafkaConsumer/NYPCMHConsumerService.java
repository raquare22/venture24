package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.nypcmh", havingValue = "true")
public class NYPCMHConsumerService extends AbstractDocumentConsumer {

    @Value("${NYPCMH_SPACEID}")
    private int nypcmh_spaceId;

    @KafkaListener(
            topics = "${spring.kafka.topic.nypcmh}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, nypcmh_spaceId);
    }
}
