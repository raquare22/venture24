package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.tnMatReport", havingValue = "true")
public class TnMatReportConsumerService extends AbstractDocumentConsumer {

    @Value("${TN_MAT_REPORT_SPACEID}")
    private int tnMatReportSpaceId;

    @KafkaListener(
            topics = "${spring.kafka.topic.tnMatReport}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, tnMatReportSpaceId);
    }
}

