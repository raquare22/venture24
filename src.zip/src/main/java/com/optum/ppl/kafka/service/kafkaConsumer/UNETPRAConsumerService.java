package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.unetpra", havingValue = "true")
public class UNETPRAConsumerService extends AbstractDocumentConsumer {

    @Value("${UNETPRA_SPACEID}")
    private int unetpra_spaceId;


    @KafkaListener(
            id = "unetpraEpsProvEobConsumer",
            idIsGroup = false,
            topics = "${spring.kafka.topic.unetpra.u_eps_prov_eob}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consumeEpsProvEob(ConsumerRecord<String, String> message) {
        super.processMessage(message, unetpra_spaceId);
    }

    @KafkaListener(
            id = "unetpraUnetGflxEobConsumer",
            idIsGroup = false,
            topics = "${spring.kafka.topic.unetpra.u_unet_gflx_eob}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consumeUnetGflxEob(ConsumerRecord<String, String> message) {
        super.processMessage(message, unetpra_spaceId);
    }

    @KafkaListener(
            id = "unetpraSurestPraConsumer",
            idIsGroup = false,
            topics = "${spring.kafka.topic.unetpra.u_surest_pra}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consumeSurestPra(ConsumerRecord<String, String> message) {
        super.processMessage(message, unetpra_spaceId);
    }
}
