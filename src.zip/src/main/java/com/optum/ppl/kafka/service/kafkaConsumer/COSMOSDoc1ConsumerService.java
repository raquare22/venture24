package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.COSMOSDoc1", havingValue = "true")
public class COSMOSDoc1ConsumerService extends AbstractDocumentConsumer{

    @Value("${COSMOSDoc1_SpaceId}")
    private int cosmosdoc1_spaceId;

    @KafkaListener(
            topics = "${spring.kafka.topic.COSMOSDoc1}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, cosmosdoc1_spaceId);
    }

}
