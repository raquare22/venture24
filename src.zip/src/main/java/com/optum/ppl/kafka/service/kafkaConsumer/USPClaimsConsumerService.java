package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.uspclaims", havingValue = "true")
public class USPClaimsConsumerService extends AbstractDocumentConsumer{
	
    @Value("${USPCLAIMS_SPACEID}")
    private int uspclaims_spaceId;


    @KafkaListener(
            topics = "${spring.kafka.topic.uspclaims}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, uspclaims_spaceId);
    }
}
