package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.ngscosmos", havingValue = "true")
public class NGSCosmosConsumerService extends AbstractDocumentConsumer{

@Value("${NGSCOSMOS_SPACEID}")
private int ngscosmos_spaceId;

@KafkaListener(
    topics = "${spring.kafka.topic.ngscosmos}",
    containerFactory = "secureKafkaListenerContainerFactory"
  )
   public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, ngscosmos_spaceId);
    }
}
