package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.memberPaymentPRA", havingValue = "true")
public class MemberPaymentPRAConsumerService extends AbstractDocumentConsumer{

    @Value("${MemberPaymentPRA_SPACEID}")
    private int memberPaymentPRA_spaceId;

    @Override
    protected int getSpaceId() {
        return this.memberPaymentPRA_spaceId;
    }

    @KafkaListener(
            topics = "${spring.kafka.topic.memberPaymentPRA}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message);
    }
}
