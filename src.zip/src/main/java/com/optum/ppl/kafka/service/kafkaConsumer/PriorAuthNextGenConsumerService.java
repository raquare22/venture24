package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.priorauthnextgen", havingValue = "true")
public class PriorAuthNextGenConsumerService extends AbstractDocumentConsumer {

	@Value("${PRIORAUTHNEXTGEN_SPACEID}")
    private int priorauthnextgen_spaceId;


    @KafkaListener(
            topics = "${spring.kafka.topic.priorauthnextgen}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message, priorauthnextgen_spaceId);
    }
}
