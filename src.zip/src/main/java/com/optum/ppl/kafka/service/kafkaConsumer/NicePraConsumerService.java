package com.optum.ppl.kafka.service.kafkaConsumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "feature.toggle.kafka.consumer.nicepra", havingValue = "true")
public class NicePraConsumerService extends AbstractDocumentConsumer{

    @Value("${NICEPRA_SPACEID}")
    private int nicepra_spaceId;

    @Override
    protected int getSpaceId() {
        return this.nicepra_spaceId;
    }

    @KafkaListener(
            topics = "${spring.kafka.topic.nicepra}",
            containerFactory = "secureKafkaListenerContainerFactory"
    )
    public void consume(ConsumerRecord<String, String> message) {
        super.processMessage(message);
    }
}